var BSIparam = ui.import && ui.import("BSIparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "bsi"
        ],
        "min": 9.901309494966227,
        "max": 89.91521631163606,
        "palette": [
          "fffae4",
          "797e2f"
        ]
      }
    }) || {"opacity":1,"bands":["bsi"],"min":9.901309494966227,"max":89.91521631163606,"palette":["fffae4","797e2f"]},
    AVIparam = ui.import && ui.import("AVIparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "avi"
        ],
        "min": 0.052439061178276646,
        "max": 0.32212631210511006,
        "palette": [
          "7ee1ff",
          "2395a7"
        ]
      }
    }) || {"opacity":1,"bands":["avi"],"min":0.052439061178276646,"max":0.32212631210511006,"palette":["7ee1ff","2395a7"]},
    VDparam = ui.import && ui.import("VDparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "pc1"
        ],
        "min": 11.515122225460857,
        "max": 94.90028292758151,
        "palette": [
          "ead8ff",
          "a15aff"
        ]
      }
    }) || {"opacity":1,"bands":["pc1"],"min":11.515122225460857,"max":94.90028292758151,"palette":["ead8ff","a15aff"]},
    SIparam = ui.import && ui.import("SIparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "si"
        ],
        "min": 9.987833742627398,
        "max": 95.1447729019521,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["si"],"min":9.987833742627398,"max":95.1447729019521,"gamma":1},
    SSIparam = ui.import && ui.import("SSIparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "pc1"
        ],
        "min": 5.975078021326012,
        "max": 95.25634413774992,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["pc1"],"min":5.975078021326012,"max":95.25634413774992,"gamma":1},
    FCDparam = ui.import && ui.import("FCDparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "FCD"
        ],
        "max": 100,
        "palette": [
          "ff3508",
          "d8ff04",
          "06700e"
        ]
      }
    }) || {"opacity":1,"bands":["FCD"],"max":100,"palette":["ff3508","d8ff04","06700e"]},
    TIparam = ui.import && ui.import("TIparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "constant"
        ],
        "min": 394.48348699325754,
        "max": 402.9623039696998,
        "palette": [
          "ffe7e4",
          "ff8e62"
        ]
      }
    }) || {"opacity":1,"bands":["constant"],"min":394.48348699325754,"max":402.9623039696998,"palette":["ffe7e4","ff8e62"]},
    mk = ui.import && ui.import("mk", "table", {
      "id": "users/lmathew/Kilimanjaro/mk_radius_50km"
    }) || ee.FeatureCollection("users/lmathew/Kilimanjaro/mk_radius_50km"),
    urt_eez = ui.import && ui.import("urt_eez", "table", {
      "id": "users/lmathew/Share/TZA"
    }) || ee.FeatureCollection("users/lmathew/Share/TZA"),
    mikoa = ui.import && ui.import("mikoa", "table", {
      "id": "users/lmathew/tza_regions"
    }) || ee.FeatureCollection("users/lmathew/tza_regions"),
    mawilaya = ui.import && ui.import("mawilaya", "table", {
      "id": "users/lmathew/tza_districts"
    }) || ee.FeatureCollection("users/lmathew/tza_districts"),
    urt_wards = ui.import && ui.import("urt_wards", "table", {
      "id": "users/lmathew/tza_kata"
    }) || ee.FeatureCollection("users/lmathew/tza_kata"),
    vlfr = ui.import && ui.import("vlfr", "table", {
      "id": "users/lmathew/Forest/TZA_VLFR"
    }) || ee.FeatureCollection("users/lmathew/Forest/TZA_VLFR"),
    cfma = ui.import && ui.import("cfma", "table", {
      "id": "users/lmathew/Seascape/CFMA-02-2018"
    }) || ee.FeatureCollection("users/lmathew/Seascape/CFMA-02-2018"),
    cwma = ui.import && ui.import("cwma", "table", {
      "id": "users/lmathew/TZA-WMA"
    }) || ee.FeatureCollection("users/lmathew/TZA-WMA"),
    wdpa = ui.import && ui.import("wdpa", "table", {
      "id": "WCMC/WDPA/current/polygons"
    }) || ee.FeatureCollection("WCMC/WDPA/current/polygons"),
    lsib = ui.import && ui.import("lsib", "table", {
      "id": "USDOS/LSIB_SIMPLE/2017"
    }) || ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017"),
    cwua = ui.import && ui.import("cwua", "table", {
      "id": "users/lmathew/tza_basins"
    }) || ee.FeatureCollection("users/lmathew/tza_basins"),
    elev = ui.import && ui.import("elev", "image", {
      "id": "USGS/GMTED2010"
    }) || ee.Image("USGS/GMTED2010"),
    operational_landscape = ui.import && ui.import("operational_landscape", "table", {
      "id": "users/lmathew/ROA/wwf_africa_operational_landscape"
    }) || ee.FeatureCollection("users/lmathew/ROA/wwf_africa_operational_landscape"),
    l4l_wards = ui.import && ui.import("l4l_wards", "table", {
      "id": "users/lmathew/SOKNOT/l4l_wards"
    }) || ee.FeatureCollection("users/lmathew/SOKNOT/l4l_wards"),
    l4l_geoscope = ui.import && ui.import("l4l_geoscope", "table", {
      "id": "users/lmathew/SOKNOT/L4L_Geoscope_4326"
    }) || ee.FeatureCollection("users/lmathew/SOKNOT/L4L_Geoscope_4326"),
    nchi = ui.import && ui.import("nchi", "table", {
      "id": "USDOS/LSIB_SIMPLE/2017"
    }) || ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017"),
    s2sr = ui.import && ui.import("s2sr", "imageCollection", {
      "id": "COPERNICUS/S2_SR"
    }) || ee.ImageCollection("COPERNICUS/S2_SR");
var palettes = require('users/gena/packages:palettes');
//Indices
//==============================================================================================================================================
//==============================================================================================================================================
// Create User Interface portion
// Create a panel to hold our widgets.
var panel = ui.Panel();
panel.style().set('width', '250px');
// Create an intro panel with labels.
var intro = ui.Panel([ ui.Label({ value: 'Spatial-Temporal Monitoring from Space', style: {fontSize: '20px', fontWeight: 'bold', position: 'top-center'}}) ]);
panel.add(intro);
///////////////////////////////////////////////////////////////////////////
//thank you Olha Danylo for the help!!
var map = ui.Map(); 
var geom = null;
var geom_cbo = null;
var geomjina = '';
var mwaka = '';
var mwaka_mwanzo = '';
var mwaka_mwisho = '';
var aina;
map.centerObject(l4l_geoscope, 8);
//Graph Panel
var panel_grafu = ui.Panel({ style: { width: '350px',position: 'top-right', padding: '10px 10px' } });
var panel_takwimu = ui.Panel({ style: { width: '350px',position: 'bottom-left', padding: '10px 10px' } });
map.add(panel_grafu);
map.add(panel_takwimu);
// Separator
var kitenganishia = ui.Label({ value: '=============',style: {fontSize: '5px', stretch:'horizontal'}});
var kitenganishib = ui.Label({ value: '-------------',style: {fontSize: '5px', stretch:'horizontal'}});
var kitenganishic = ui.Label({ value: '-------------',style: {fontSize: '5px', stretch:'horizontal'}});
var mradi = ui.Label({ value: '-Land for Life Wards-',style: {fontSize: '15px', stretch:'horizontal'}});
//==============================================================================================================================================
//----------------------------------------------------------------------------------------------------------------------------------------------
// Load a global elevation image.
var empty = ee.Image().byte(); //TZ	TZA	834
var countries = nchi.filter(ee.Filter.eq('country_co', 'TZ')).merge(nchi.filter(ee.Filter.eq('country_co', 'KE')));
var TZ_KE = empty.paint({featureCollection: countries, color: 1, width: 5 });
var TZ_KE_wdpa_a = wdpa.filter(ee.Filter.eq('PARENT_ISO', 'TZA')).merge(wdpa.filter(ee.Filter.eq('PARENT_ISO', 'KEN')));
var TZ_KE_wdpa_b = empty.paint({featureCollection: TZ_KE_wdpa_a, color: 1, width: 2 });
//var L4L = l4l_geoscope;
var L4L = empty.paint({featureCollection: l4l_geoscope, color: 1, width: 1 });
//JRC Water
var gsw = ee.Image('JRC/GSW1_1/GlobalSurfaceWater').select('occurrence').clip(urt_eez);
var maji = gsw.select('occurrence').unmask(ee.Image(0)).lte(0)
//map.addLayer(gsw,{palette: '0000ff'}, "Water",0);
elev = elev.clip(l4l_geoscope);
var shade = ee.Terrain.hillshade(elev);
var sea = elev.lte(0);
// Create a custom elevation palette from hex strings.
var elevationPalette = ['006600', '002200', 'fff700', 'ab7634', 'c4d0ff', 'ffffff'];
// Create a mosaic of the sea and the elevation data
var visParams = {min: 1, max: 3000, palette: elevationPalette};
var visualized = ee.ImageCollection([elev.mask(sea.not()).visualize(visParams),sea.mask(sea).visualize({palette:'000022'})]).mosaic();
// Convert the visualized elevation to HSV, first converting to [0, 1] data.
var hsv = visualized.divide(255).rgbToHsv();
var hs = hsv.select(0, 1); // Select only the hue and saturation bands.
var v = shade.divide(255);// Convert the hillshade to [0, 1] data, as expected by the HSV algorithm.
var rgb = hs.addBands(v).hsvToRgb().multiply(255).byte();
//map.addLayer(rgb, {}, 'Styled Elevation',0);
//Display Vector Data (Boundaries)
map.addLayer(visualized, {}, 'Elevations', 0);//// Note that the visualization image doesn't require visualization parameters.
map.addLayer(rgb, {}, 'Styled Elevation',0);
map.addLayer(gsw,{palette: '0000ff'}, "Water",0);
map.addLayer(TZ_KE_wdpa_b,{palette: '00ff00'},'TZA-KEN WDPAs',0); 
map.addLayer(L4L,{palette: '000000'},'Project Area',1);
map.addLayer(TZ_KE,{palette: '555555'},'Tanzania + Kenya',0);
//=====================================================================================================
//=====================================================================================================
//=====================================================================================================
//NDVI
function ndvi(image) { return image.normalizedDifference(['B8', 'B4']).rename('NDVI'); }
//------------------------------------------------------------------------
//NDWI
//https://custom-scripts.sentinel-hub.com/custom-scripts/sentinel-2/ndwi/
function ndwi(image) { return image.normalizedDifference(['B3', 'B8']).rename('NDWI'); }
//------------------------------------------------------------------------
//NDDI
function nddi(image)
{ 
  var vi = ndvi(image)
  var wi = ndwi(image);
  var di = vi.subtract(wi).divide(vi.add(wi));
  return di.rename('NDDI'); 
}
//------------------------------------------------------------------------
//NBR
function nbr(image) { image.normalizedDifference(['B8', 'B12']).rename('NBR'); }
//=====================================================================================================
//=====================================================================================================
//=====================================================================================================
//https://github.com/gee-community/ee-palettes
var palette_ndvi = ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
               '74A901', '66A000', '529400', '3E8601', '207401', '056201',
               '004C00', '023B01', '012E01', '011D01', '011301'];
//var palette_ndwi = ['00FFFF', '0000FF'];
//palettes.misc.tol_rainbow[7];
var palette_ndwi = palettes.colorbrewer.Blues[3,4,5,6,7,8,9];
var palette_nddi = palettes.colorbrewer.YlOrBr[3,4,5,6,7,8,9];
var palette_nbr = palettes.colorbrewer.Reds[3,4,5,6,7,8,9];
//==========================================================================================================
//==========================================================================================================
//==========================================================================================================
function L4L_Indices(mwaka_a,mwaka_b,eneo,jina,type)
{
var year = mwaka; 
var AOI = eneo.geometry();
var map_area = L4L;
var buffer = function(feature) {  return feature.buffer(1000); };
Map.centerObject(AOI, 8);
var studyArea = AOI;
var startYear = mwaka_a;
var endYear = mwaka_b;
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//Function for acquiring Sentinel 2 SR image collection
function getImageCollection(studyArea,startDate,endDate)
{
  var s2 = ee.ImageCollection('COPERNICUS/S2_SR').filterBounds(studyArea)
                  .filterDate(startDate,endDate).select('B1','B2','B3','B4','B5','B6','B7','B8','B8A','B9','B11','B12')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10));
  return s2
}
//=====================================================================================================
//=====================================================================================================
var index = ee.Image().byte();
var index_to_jpeg = index.visualize();
//var indexS = ee.ImageCollection([index, index]);
var indexJ = "";
var indexI = '';
var s2sr = getImageCollection(eneo,mwaka_a,mwaka_b);
if(type == "NDVI")
  {
    var s2sr_median = s2sr.median().clip(studyArea);
    index = ndvi(s2sr_median);
    //indexS = s2sr.map(ndvi);
    indexI = 'NDVI';
    indexJ = "NDVI";
    var index_to_jpeg = index.visualize({bands:indexI, min:-1, max:1, palette: palette_ndvi, forceRgbOutput:true});
  }
else if(type == "NDWI")
  {
    var s2sr_median = s2sr.median().clip(studyArea);
    index = ndwi(s2sr_median);
    indexI = 'NDWI';
    indexJ = "NDWI";
    var index_to_jpeg = index.visualize({bands:'NDWI',min:-1, max:1, palette: palette_ndwi, forceRgbOutput:true});
  }
else if(type == "NDDI")
  {
    var s2sr_median = s2sr.median().clip(studyArea);
    index = nddi(s2sr_median);
    indexI = 'NDDI';
    indexJ = "NDDI";
    var index_to_jpeg = index.visualize({bands:'NDDI', min:-1, max:1, palette: palette_nddi, forceRgbOutput:true});
  }
else if(type == "NBR")
  {
    var s2sr_median = s2sr.median().clip(studyArea);
    index = nbr(s2sr_median);
    indexI = 'NBR';
    indexJ = "NBR";
    var index_to_jpeg = index.visualize({bands:'NBR', min:-1, max:1, palette: palette_nbr, forceRgbOutput:true});
  }
//=====================================================================================================
//=====================================================================================================
var options = { title: jina + ' - Vegetation Index - (' + type + ')=> Date: ' + mwaka_a +  ' to ' + mwaka_b, fontSize: 12, hAxis: {title: 'Index'}, vAxis: {title: 'Pixels'},
                  legend: 'none', lineWidth: 1, pointSize: 4 };
// Make the histogram, set the options.
var histogram = ui.Chart.image.histogram(index, AOI, 1000).setOptions(options);
panel_grafu.widgets().set(1, histogram);   // Display the histogram.
// Create a time series chart.
//var series = ui.Chart.image.seriesByRegion(indexS, AOI,ee.Reducer.mean(),'nd',1000,'system:time_start', 'system:index')
//              .setChartType('LineChart').setOptions({title: type,hAxis: {title: 'Date'},vAxis: {title: type}
//});
//panel_grafu.widgets().set(3, series);   // Display the histogram.
var lebel_jina = ui.Label('Index of ' + jina, {textAlign: 'left', fontSize: '14px', fontWeight: 'bold'});
var lebel_tarehe = ui.Label('Date: ' + mwaka_a + ' - ' + mwaka_b, {textAlign: 'left', fontSize: '14px', fontWeight: 'bold'});
panel_takwimu.widgets().set(1, lebel_jina);
panel_takwimu.widgets().set(2, lebel_tarehe);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function downloadImg()
{
  var img_bound = ee.Geometry.Polygon(eneo.geometry().coordinates());
  var downloadArgs = {dimensions:1024,region:img_bound, format:"jpg"};
  var url = index_to_jpeg.getDownloadURL(downloadArgs);
  urlLabel.setUrl(url);
  urlLabel.style().set({shown: true});
  var s2sr_visualization = { min: 0.0, max: 0.3, bands: ['B4', 'B3', 'B2'],  forceRgbOutput:true};
  //var rgb_to_jpeg = s2sr.median().clip(studyArea).visualize({bands:'B4,B3,B2', 'min': 0.0,'max': 0.3, forceRgbOutput:true});
  var rgb_to_jpeg = s2sr.median().clip(studyArea).visualize(s2sr_visualization);
  var downloadArgsRGB = {dimensions:1024,region:img_bound, format:"jpg"};
  var urlrgb = rgb_to_jpeg.getDownloadURL(downloadArgsRGB);
  urlLabelrgb.setUrl(urlrgb);
  urlLabelrgb.style().set({shown: true});
}
// Add UI elements to the Map.
var downloadButton = ui.Button('Download ' + jina + ' - ' + indexJ, downloadImg);
var urlLabel = ui.Label('Download-Index', {shown: false});
var urlLabelrgb = ui.Label('Download-RGB', {shown: false});
downloadButton.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel_takwimu.widgets().set(3, downloadButton);
panel_takwimu.widgets().set(4, urlLabel);
panel_takwimu.widgets().set(5, urlLabelrgb);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
//Define Vegetation Indices
var index_majina = ee.List(['NDVI','NDWI','NDDI','NBR',]);
var chagua_index = ui.Select([],'Loading ...');    //Indices
//Mwaka
index_majina.evaluate(function(aina_jina)
{
  chagua_index.items().reset(aina_jina);
  chagua_index.setPlaceholder('Select Type of index');
  chagua_index.onChange(function(aina_jina)
  {
    aina = aina_jina;
  })
})
////////////////////////////////////////////////////////////////////////////////////////////////////////
//Define Years
var miaka = ee.List(["2017","2018","2019","2020","2021","2022"]);
var miezi = ee.List(["Year (January to December)",
                      "H1 (January to June)","H2 (July to December)",
                      "Q1 (January to March)","Q2 (April to June)",
                      "Q3 (July to September)","Q4 (October to December)"]);
//Load Years
var chagua_mwaka = ui.Select([],'Loading ...');    //Mwaka
var chagua_mwezi = ui.Select([],'Loading ...');    //Miezi
//Mwaka
miaka.evaluate(function(mwakaa)
{
  chagua_mwaka.items().reset(mwakaa);
  chagua_mwaka.setPlaceholder('Select Year');
  chagua_mwaka.onChange(function(mwakaa)
  {
    mwaka = mwakaa;
    //Mwezi
    miezi.evaluate(function(mwezia)
    {
      chagua_mwezi.items().reset(mwezia);
      chagua_mwezi.setPlaceholder('Select Months');
      chagua_mwezi.onChange(function(mwezia)
      {
        if(mwezia === "Year (January to December)") { mwaka_mwanzo = mwaka + '-01-01'; mwaka_mwisho = mwaka + '-12-31'; }
        if(mwezia === "H1 (January to June)") { mwaka_mwanzo = mwaka + '-01-01'; mwaka_mwisho = mwaka + '-06-30'; }
        if(mwezia === "H2 (July to December)") { mwaka_mwanzo = mwaka + '-07-01'; mwaka_mwisho = mwaka + '-12-31'; }
        if(mwezia === "Q1 (January to March)") { mwaka_mwanzo = mwaka + '-01-01'; mwaka_mwisho = mwaka + '-03-31'; }
        if(mwezia === "Q2 (April to June)") { mwaka_mwanzo = mwaka + '-04-01'; mwaka_mwisho = mwaka + '-06-30'; }
        if(mwezia === "Q3 (July to September)") { mwaka_mwanzo = mwaka + '-07-01'; mwaka_mwisho = mwaka + '-09-30'; }
        if(mwezia === "Q4 (October to December)") { mwaka_mwanzo = mwaka + '-10-01'; mwaka_mwisho = mwaka + '-12-31'; }
      })
    })
  })
})
///////////////////////////////////////////////////////////////////////////////////////////////////////////
// Load Landscape
var landscape_majina = operational_landscape.aggregate_array('Operationa').distinct();
var chagua_landscape = ui.Select([],'Loading ...');
landscape_majina.evaluate(function(landscape)
{
  chagua_landscape.items().reset(landscape);
  chagua_landscape.setPlaceholder('Select a Operational Landscape')
  chagua_landscape.onChange(function(landscape)
  {
    var geom_a = operational_landscape.filter(ee.Filter.eq('Operationa', landscape));
    var geom_b = empty.paint({featureCollection: geom_a.geometry(), width: 4});
    map.addLayer(geom_b,{palette: '000000'},landscape);
    map.centerObject(geom_a);
    geomjina = landscape;
    geom = geom_a;
  })
})
var chora_sasa_a  = ui.Button({label: '==-> Landscape Index <-==', style: { margin:'5px', stretch:'horizontal'},  onClick: bonyezoa,});
// Load Wards
var wards_majina = l4l_wards.aggregate_array('name').distinct();
var chagua_ward = ui.Select([],'Loading ...');
wards_majina.evaluate(function(kata)
{
  chagua_ward.items().reset(kata);
  chagua_ward.setPlaceholder('Select a Ward')
  chagua_ward.onChange(function(kata)
  {
    var geom_a = l4l_wards.filter(ee.Filter.eq('name', kata));
    var geom_b = empty.paint({featureCollection: geom_a.geometry(), width: 4});
    map.addLayer(geom_b,{palette: 'FFFF00'},kata);
    map.centerObject(geom_a);
    geomjina = kata;
    geom = geom_a;
  })
})
var chora_sasa_b  = ui.Button({label: '==-> Wards Index <-==', style: { margin:'5px', stretch:'horizontal'},  onClick: bonyezoa,});
//==============================================================================================================================================
chagua_index.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_index);
panel.add(kitenganishia);
chagua_mwaka.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_mwaka);
chagua_mwezi.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_mwezi);
panel.add(kitenganishib);
chagua_landscape.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_landscape);
panel.add(chora_sasa_a);
panel.add(kitenganishic);
panel.add(mradi);
chagua_ward.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_ward);
panel.add(chora_sasa_b);
//==============================================================================================================================================
function bonyezoa()
{
  panel_grafu.clear();
  panel_takwimu.clear();
  //function L4L_Indices(mwaka_a,mwaka_b,eneo,jina,aina)
  if(mwaka === "2017") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom,geomjina,aina);  }
  if(mwaka === "2018") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom,geomjina,aina);  }
  if(mwaka === "2019") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom,geomjina,aina);  }
  if(mwaka === "2020") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom,geomjina,aina);  }
  if(mwaka === "2021") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom,geomjina,aina);  }
  if(mwaka === "2022") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom,geomjina,aina);  }
}
//--------------------------------------------------------------------------
function bonyezob()
{
  panel_grafu.clear();
  panel_takwimu.clear();
  if(mwaka === "2017") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom_cbo,geomjina,aina);  }
  if(mwaka === "2018") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom_cbo,geomjina,aina);  }
  if(mwaka === "2019") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom_cbo,geomjina,aina);  }
  if(mwaka === "2020") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom_cbo,geomjina,aina);  }
  if(mwaka === "2021") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom_cbo,geomjina,aina);  }
  if(mwaka === "2022") { L4L_Indices(mwaka_mwanzo,mwaka_mwisho,geom_cbo,geomjina,aina);  }
}
//==============================================================================================================================================
var title = ui.Label('Land for Life - Indices', {
stretch: 'horizontal', textAlign: 'center', fontWeight: 'bold', fontSize: '30px' });
// Create a grid of maps.
var mapGrid = ui.Panel([ panel, ui.Panel(map, null, {stretch: 'both'}), ],
              ui.Panel.Layout.Flow('horizontal'), {width: '100%', stretch: 'both'});
ui.root.widgets().reset([title, mapGrid]);
ui.root.setLayout(ui.Panel.Layout.Flow('vertical'));