var countries = ui.import && ui.import("countries", "table", {
      "id": "USDOS/LSIB_SIMPLE/2017"
    }) || ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017"),
    ndvi_modis = ui.import && ui.import("ndvi_modis", "imageCollection", {
      "id": "MODIS/006/MOD13A1"
    }) || ee.ImageCollection("MODIS/006/MOD13A1"),
    urt_eez = ui.import && ui.import("urt_eez", "table", {
      "id": "users/lmathew/Share/TZA"
    }) || ee.FeatureCollection("users/lmathew/Share/TZA"),
    mikoa = ui.import && ui.import("mikoa", "table", {
      "id": "users/lmathew/tza_regions"
    }) || ee.FeatureCollection("users/lmathew/tza_regions"),
    mawilaya = ui.import && ui.import("mawilaya", "table", {
      "id": "users/lmathew/tza_districts"
    }) || ee.FeatureCollection("users/lmathew/tza_districts"),
    urt_wards = ui.import && ui.import("urt_wards", "table", {
      "id": "users/lmathew/tza_kata"
    }) || ee.FeatureCollection("users/lmathew/tza_kata"),
    dom_tree_planting = ui.import && ui.import("dom_tree_planting", "table", {
      "id": "users/lmathew/Freshwater/DODOMA_TREE_PLANTING-SITE_COORDINATES"
    }) || ee.FeatureCollection("users/lmathew/Freshwater/DODOMA_TREE_PLANTING-SITE_COORDINATES"),
    firms = ui.import && ui.import("firms", "imageCollection", {
      "id": "FIRMS"
    }) || ee.ImageCollection("FIRMS"),
    vlfr = ui.import && ui.import("vlfr", "table", {
      "id": "users/lmathew/Forest/TZA_VLFR"
    }) || ee.FeatureCollection("users/lmathew/Forest/TZA_VLFR"),
    cfma = ui.import && ui.import("cfma", "table", {
      "id": "users/lmathew/Seascape/CFMA-02-2018"
    }) || ee.FeatureCollection("users/lmathew/Seascape/CFMA-02-2018"),
    cwma = ui.import && ui.import("cwma", "table", {
      "id": "users/lmathew/TZA-WMA"
    }) || ee.FeatureCollection("users/lmathew/TZA-WMA"),
    CHIRPS = ui.import && ui.import("CHIRPS", "imageCollection", {
      "id": "UCSB-CHG/CHIRPS/DAILY"
    }) || ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY"),
    s1 = ui.import && ui.import("s1", "imageCollection", {
      "id": "COPERNICUS/S1_GRD"
    }) || ee.ImageCollection("COPERNICUS/S1_GRD"),
    s2 = ui.import && ui.import("s2", "imageCollection", {
      "id": "COPERNICUS/S2_SR"
    }) || ee.ImageCollection("COPERNICUS/S2_SR"),
    s3 = ui.import && ui.import("s3", "imageCollection", {
      "id": "COPERNICUS/S3/OLCI"
    }) || ee.ImageCollection("COPERNICUS/S3/OLCI"),
    s5co = ui.import && ui.import("s5co", "imageCollection", {
      "id": "COPERNICUS/S5P/OFFL/L3_CO"
    }) || ee.ImageCollection("COPERNICUS/S5P/OFFL/L3_CO"),
    s5sd = ui.import && ui.import("s5sd", "imageCollection", {
      "id": "COPERNICUS/S5P/OFFL/L3_SO2"
    }) || ee.ImageCollection("COPERNICUS/S5P/OFFL/L3_SO2"),
    s5no = ui.import && ui.import("s5no", "imageCollection", {
      "id": "COPERNICUS/S5P/OFFL/L3_NO2"
    }) || ee.ImageCollection("COPERNICUS/S5P/OFFL/L3_NO2"),
    ls8 = ui.import && ui.import("ls8", "imageCollection", {
      "id": "LANDSAT/LO08/C01/T1"
    }) || ee.ImageCollection("LANDSAT/LO08/C01/T1"),
    bahari = ui.import && ui.import("bahari", "imageCollection", {
      "id": "NASA/OCEANDATA/MODIS-Aqua/L3SMI"
    }) || ee.ImageCollection("NASA/OCEANDATA/MODIS-Aqua/L3SMI"),
    wdpa = ui.import && ui.import("wdpa", "table", {
      "id": "WCMC/WDPA/current/polygons"
    }) || ee.FeatureCollection("WCMC/WDPA/current/polygons");
var text = require('users/gena/packages:text');
var map = ui.Map();
var mwakaA = ''; 
var mwakaB = '';
var picha_a = '';
var geom = null;
var geom_cbo = null;
var geomjina = '';
map.centerObject(urt_eez,6);
//----------------------------------------------------------------------------------------
var empty = ee.Image().byte(); //TZ	TZA	834
var Tanzania = empty.paint({featureCollection: urt_eez, color: 1, width: 3 });
var urt_wdpa_a = ee.FeatureCollection(wdpa.filter(ee.Filter.eq('PARENT_ISO', 'TZA')));
var urt_wdpa_b = empty.paint({featureCollection: urt_wdpa_a, color: 1, width: 1 });
//Display Vector Data (Boundaries)
map.addLayer(Tanzania,{palette: '555555'},'Tanzania + EEZ',1);
map.addLayer(urt_wdpa_b,{palette: '00ff00'},'URT-WDPAs',0);
//=======================================================================================
//======================================================================================
var yeara = ee.Date('2015-01-01');
var yearb = ee.Date('2020-06-30');
var yearc = ee.Date('2018-07-01');
var yeard = ee.Date('2020-06-30');
var months = ee.List.sequence(1, 12);
var years = ee.List.sequence(2015, 2020);
//==============================================================================================================================================
//==============================================================================================================================================
var modis_ndvi = ee.ImageCollection("MODIS/006/MOD13Q1").filterDate(yeara, yearb).filterBounds(urt_eez).select('NDVI');
var modis_evi = ee.ImageCollection("MODIS/006/MOD13Q1").filterDate(yeara, yearb).filterBounds(urt_eez).select('EVI');
var modis_lst_day = ee.ImageCollection('MODIS/006/MOD11A1').filterDate(yeara, yearb).filterBounds(urt_eez).select('LST_Day_1km');
var modis_lst_night = ee.ImageCollection('MODIS/006/MOD11A1').filterDate(yeara, yearb).filterBounds(urt_eez).select('LST_Night_1km');
var modis_ssm = ee.ImageCollection("NASA_USDA/HSL/soil_moisture").filterDate(yeara, yearb).filterBounds(urt_eez).select('ssm');
var modis_susm = ee.ImageCollection("NASA_USDA/HSL/soil_moisture").filterDate(yeara, yearb).filterBounds(urt_eez).select('susm');
var modis_fire = firms.filterDate(yeara, yearb).select('T21');
var chirps_pre = CHIRPS.filterDate(yeara, yearb);//.select('susm');
//----------------------------------------------------------------------------------------------------------------------------------------------
var s1a = s1.filterDate(yeara, yearb).filterBounds(urt_eez).filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
            .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH')).filter(ee.Filter.eq('instrumentMode', 'IW'));
var s2a = s2.filterDate(yeara, yearb).filterBounds(urt_eez).select('B[1-7]');
var baharia = bahari.filterDate(yeara, yearb).filterBounds(urt_eez);
var ls8a = ls8.filterDate(yeara, yearb).filterBounds(urt_eez).select('B[1-7]');
var s5coa = s5co.filterDate(yearc, yeard).filterBounds(urt_eez);
var s5sda = s5sd.filterDate(yearc, yeard).filterBounds(urt_eez);
var s5noa = s5no.filterDate(yearc, yeard).filterBounds(urt_eez);
//==============================================================================================================================================
//==============================================================================================================================================
var modis_ndvi_clip = modis_ndvi.mean().clip(urt_eez).multiply(0.0001);
var modis_evi_clip = modis_evi.mean().clip(urt_eez).multiply(0.0001);
var modis_lst_clip = modis_lst_day.mean().clip(urt_eez).multiply(0.02);
var modis_lst_night_clip = modis_lst_night.mean().clip(urt_eez).multiply(0.02);
var modis_ssm_clip = modis_ssm.mean().clip(urt_eez);
var modis_susm_clip = modis_susm.mean().clip(urt_eez);
var modis_fire_clip = modis_fire.count().clip(urt_eez);
var chirps_pre_clip = chirps_pre.mean().clip(urt_eez);
//---------------------------------------------------------------------------------------------------------------------------------------
var s1bA = s1a.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));
var s1bD = s1a.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
// Create a composite from means at different polarizations and look angles.
var s1b = ee.Image.cat([ s1bA.select('VH').mean(),
                ee.ImageCollection(s1bA.select('VV').merge(s1bD.select('VV'))).mean(),
                s1bD.select('VH').mean()]).focal_median().clip(urt_eez);
var s2b = s2a.mean().clip(urt_eez);
//var s3b = s3a.mean().clip(urt_eez);
var s5cob = s5coa.mean().clip(urt_eez);
var s5sdb = s5sda.mean().clip(urt_eez);
var s5nob = s5noa.mean().clip(urt_eez);
var ls8b = ls8a.mean().clip(urt_eez);
//==============================================================================================================================================
//==============================================================================================================================================
//https://github.com/gee-community/ee-palettes
var palettes = require('users/gena/packages:palettes');
var NDVI_Vis = { min: -2000, max: 10000, palette: [
    'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901', '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01', '011301' ], };
//----------------------------------------------------------------------------------------------------------------------------------------------
//map.addLayer(modis_ndvi_clip,NDVI_Vis,'Mean NDVI',0);
//map.addLayer(modis_evi_clip,NDVI_Vis,'Mean EVI',0);
//map.addLayer(modis_lst_clip,{},'Mean LST-DAY',0);
//map.addLayer(modis_lst_night_clip,{},'Mean LST-NIGHT',0);
//map.addLayer(modis_ssm_clip,{},'Mean SSM',0);
//map.addLayer(modis_susm_clip,{},'Mean SUSM',0);
//map.addLayer(modis_fire_clip,{},'Fire Incidences',0);
//Map.addLayer(chirps_pre_clip,{},'Mean Precipitation',0);
//----------------------------------------------------------------------------------------------------------------------------------------------
map.addLayer(s1b, {min: [-25, -20, -25], max: [0, 10, 0]}, 'Sentinel 1(RGB->VH-VV-VH)',0);
//==============================================================================================================================================
//==============================================================================================================================================
// Create User Interface portion
// Create a panel to hold our widgets.
var panel = ui.Panel();
panel.style().set('width', '250px');
// Create an intro panel with labels.
var intro = ui.Panel([ ui.Label({ value: 'Spatial-Temporal Results', style: {fontSize: '20px', fontWeight: 'bold', position: 'top-center'}}) ]);
panel.add(intro);
// On Click results.
var jira = ui.Panel([ ui.Label({ value: 'Click a Point on the Map ...', style: {fontSize: '15px', fontWeight: 'bold', stretch:'horizontal'}}) ]);
panel.add(jira);
// panels to hold lon/lat values
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon], ui.Panel.Layout.flow('horizontal')));
panel.add(ui.Panel([lat], ui.Panel.Layout.flow('horizontal')));
///////////////////////////////////////////////////////////////////////////
//Graph Panel
var panel_grafu = ui.Panel({ style: { width: '350px',position: 'top-right', padding: '10px 10px' } });
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//Satellite Data
var chagua_data = ee.List(["T: S1->VH-VV-VH",
                            "T: S2->B1-B7",
                            "T: LS8->B1-B7",
                            "T: S5-Carbon Monoxide","T: S5-Sulpher Dioxide","T: S5-Nitrogen Dioxide",
                            "T: MODIS-Fire","T: MODIS-NDVI","T: MODIS-EVI",
                            "T: MODIS-LST-Day","T: MODIS-LST-Night","T: MODIS-SSM",
                            "T: MODIS-SuSM","T: Precipitation",
                            "O: MODIS-Chlorophyll","O: MODIS-POC","O: MODIS-SST",]);
//Miaka
var chagua_mwaka = ee.List(["2015","2016","2017","2018","2019","2020"]);
///////////////////////////////////////////////////////////////////////////////////////////////////////////
// Load Administrative Names
//var mikoa_majina =  mikoa.reduceColumns(ee.Reducer.toList(), ['Name']).get('list');
//var mikoa_majinaa = ee.Feature(urt_wards.filterMetadata('Region_Nam').first())
var mikoa_majina = urt_wards.aggregate_array('Region_Nam').distinct();
var chagua_mkoa = ui.Select([],'Loading ...');    //Mkoa
var chagua_wilaya = ui.Select([],'Loading ...');    //Wilaya
var chagua_kata = ui.Select([],'Loading ...');      //Kata
// Load Mikoa
mikoa_majina.evaluate(function(mikoaa)
{
  chagua_mkoa.items().reset(mikoaa);
  chagua_mkoa.setPlaceholder('Select a Region')
  chagua_mkoa.onChange(function(mikoaa)
  {
    var geom_a = urt_wards.filter(ee.Filter.eq('Region_Nam', mikoaa));
    var geom_b = empty.paint({featureCollection: geom_a.geometry(), width: 4});
    map.addLayer(geom_b,{palette: '000000'},mikoaa);
    map.centerObject(geom_a);
    //var mikoa_wilaya = mkoa.aggregate_array('District_N')
    var mikoa_wilaya_a = ee.FeatureCollection(urt_wards.filterMetadata('Region_Nam', 'equals', mikoaa));
    var wilaya_majina = mikoa_wilaya_a.aggregate_array('District_N').distinct();
    wilaya_majina.evaluate(function(wilayaa)
    {
      chagua_wilaya.items().reset(wilayaa);
      chagua_wilaya.setPlaceholder('Select a District')
      chagua_wilaya.onChange(function(wilayaa)
      {
        var geom_a = urt_wards.filter(ee.Filter.eq('District_N', wilayaa));
        var geom_b = empty.paint({featureCollection: geom_a.geometry(), width: 4 });
        map.addLayer(geom_b,{palette: 'ffff00'},wilayaa);
        map.centerObject(geom_a);
        var kata_majina_a = ee.FeatureCollection(urt_wards.filterMetadata('District_N', 'equals', wilayaa));
        var kata_majina = kata_majina_a.aggregate_array('Ward_Name').distinct();
        kata_majina.evaluate(function(kataa)
        {
            chagua_kata.items().reset(kataa);
            chagua_kata.setPlaceholder('Select a Ward')
            chagua_kata.onChange(function(kataa)
            {
              var geom_a = urt_wards.filter(ee.Filter.eq('Ward_Name', kataa));
              var geom_b = empty.paint({featureCollection: geom_a, width: 3 });
              map.addLayer(geom_b,{palette: 'ff00ff'},kataa);
              map.centerObject(geom_a);
              geomjina = kataa;
              geom = geom_a;
            })
        })
      })
    })
  })
})
//-----------------------------------------------------------------------------
//Satellite/Platform
var chagua_sat = ui.Select([],'Loading ...');
// Load Platform
chagua_data.evaluate(function(dataa)
{
  chagua_sat.items().reset(dataa);
  chagua_sat.setPlaceholder('Select Data Type')
  chagua_sat.onChange(function(dataa)
  {
    // once you select a state (onChange) get all counties and fill the dropdown
    //countiesDD.setPlaceholder('Loading...')
    print('ok');
  })
})
//-------------------------------------------------------------------------------------------------------
// Separator
var kitenganishia = ui.Label({ value: '-------------',style: {fontSize: '5px', stretch:'horizontal'}});
var kitenganishib = ui.Label({ value: '-------------',style: {fontSize: '5px', stretch:'horizontal'}});
//Hifadhi za Jamii (Misitu, Wanyapori,Bahari)
var vlfr_majina = vlfr.aggregate_array('Village').distinct(); 
var cwma_majina = cwma.aggregate_array('Name').distinct(); 
var cfma_majina = cfma.aggregate_array('FGD_NAMES').distinct(); 
var wdpa_majina = urt_wdpa_a.aggregate_array('NAME').distinct(); 
var chagua_vlfr = ui.Select([],'Loading ...');
var chagua_cwma = ui.Select([],'Loading ...');
var chagua_cfma = ui.Select([],'Loading ...');
var chagua_wdpa = ui.Select([],'Loading ...');
//VLFRs
vlfr_majina.evaluate(function(vlfra)
{
  chagua_vlfr.items().reset(vlfra);
  chagua_vlfr.setPlaceholder('Select a VLFR')
  chagua_vlfr.onChange(function(vlfra)
  {
    var geom_a = vlfr.filter(ee.Filter.eq('Village', vlfra));
    var geom_b = empty.paint({featureCollection: geom_a, width: 4 });
    map.addLayer(geom_b,{palette: 'ffff00'},vlfra);
    map.centerObject(geom_a);
    geomjina = vlfra;
    geom_cbo = geom_a;
    chagua_cwma.items().reset(); cwma_majina.evaluate(function(cfmaa){ chagua_cwma.items().reset(cwmaa);  })
    chagua_cfma.items().reset(); cfma_majina.evaluate(function(cfmaa){ chagua_cfma.items().reset(cfmaa);  })
    chagua_wdpa.items().reset(); wdpa_majina.evaluate(function(wdpaa){ chagua_wdpa.items().reset(wdpaa);  })
  })
})
//CWMAs
cwma_majina.evaluate(function(cwmaa)
{
  chagua_cwma.items().reset(cwmaa);
  chagua_cwma.setPlaceholder('Select a CWMA')
  chagua_cwma.onChange(function(cwmaa)
  {
    var geom_a = cwma.filter(ee.Filter.eq('Name', cwmaa));
    var geom_b = empty.paint({featureCollection: geom_a, width: 4 });
    map.addLayer(geom_b,{palette: 'ffff00'},cwmaa);
    map.centerObject(geom_a);
    geomjina = cwmaa;
    geom_cbo = geom_a;
    chagua_vlfr.items().reset(); vlfr_majina.evaluate(function(vlfra){ chagua_vlfr.items().reset(vlfra);  })
    chagua_cfma.items().reset(); cfma_majina.evaluate(function(cfmaa){ chagua_cfma.items().reset(cfmaa);  })
    chagua_wdpa.items().reset(); wdpa_majina.evaluate(function(wdpaa){ chagua_wdpa.items().reset(wdpaa);  })
  })
})
//CFMAs
cfma_majina.evaluate(function(cfmaa)
{
  chagua_cfma.items().reset(cfmaa);
  chagua_cfma.setPlaceholder('Select a CFMA')
  chagua_cfma.onChange(function(cfmaa)
  {
    var geom_a = cfma.filter(ee.Filter.eq('FGD_NAMES', cfmaa));
    var geom_b = empty.paint({featureCollection: geom_a, width: 4 });
    map.addLayer(geom_b,{palette: 'ffff00'},cfmaa);
    map.centerObject(geom_a);
    geomjina = cfmaa;
    geom_cbo = geom_a;
    chagua_vlfr.items().reset(); vlfr_majina.evaluate(function(vlfra){ chagua_vlfr.items().reset(vlfra);  })
    chagua_cwma.items().reset(); cwma_majina.evaluate(function(cwmaa){ chagua_cwma.items().reset(cwmaa);  })
    chagua_wdpa.items().reset(); wdpa_majina.evaluate(function(wdpaa){ chagua_wdpa.items().reset(wdpaa);  })
  })
})
//WDPAs
wdpa_majina.evaluate(function(wdpaa)
{
  chagua_wdpa.items().reset(wdpaa);
  chagua_wdpa.setPlaceholder('Select a PA')
  chagua_wdpa.onChange(function(wdpaa)
  {
    var geom_a = urt_wdpa_a.filter(ee.Filter.eq('NAME', wdpaa));
    var geom_b = empty.paint({featureCollection: geom_a, width: 4 });
    map.addLayer(geom_b,{palette: 'ffff00'},wdpaa);
    map.centerObject(geom_a);
    geomjina = wdpaa;
    geom_cbo = geom_a;
    chagua_vlfr.items().reset(); vlfr_majina.evaluate(function(vlfra){ chagua_vlfr.items().reset(vlfra);  })
    chagua_cwma.items().reset(); cwma_majina.evaluate(function(cwmaa){ chagua_cwma.items().reset(cwmaa);  })
    chagua_cfma.items().reset(); cfma_majina.evaluate(function(cfmaa){ chagua_cfma.items().reset(cfmaa);  })
  })
})
var chora_sasa_a  = ui.Button({label: '==- LG(Graph it!) -==', style: { margin:'5px', stretch:'horizontal'},  onClick: bonyezoa,});
var chora_sasa_b  = ui.Button({label: '==- CBOs(Graph it!) -==', style: { margin:'5px', stretch:'horizontal'},  onClick: bonyezob,});
//-------------------------------------------------------------------------------------------------------
chagua_sat.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_sat);
panel.add(kitenganishia);
chagua_mkoa.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_mkoa);
chagua_wilaya.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_wilaya);
chagua_kata.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_kata);
panel.add(chora_sasa_a);
panel.add(kitenganishib);
chagua_vlfr.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_vlfr);
chagua_cwma.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_cwma);
chagua_cfma.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_cfma);
chagua_wdpa.style().set({textAlign:'center', stretch:'horizontal', margin:'5px'});
panel.add(chagua_wdpa);
panel.add(chora_sasa_b);
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// Register a callback on the default map to be invoked when the map is clicked
map.onClick(function(coords)
{
  panel_grafu.clear();
  picha_a = chagua_sat.getValue();
  // Update the lon/lat panel with values from the click event.
  lon.setValue('Longitude: ' + coords.lon.toFixed(5)),
  lat.setValue('Latitude: ' + coords.lat.toFixed(5));
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var eneoJ  = point.buffer(100);
  var jira = empty.paint({featureCollection: eneoJ, color: 1, width: 5 });
  map.addLayer(jira ,{palette: 'FFFF00'}, "Point!");
//Imagesextract
  if(picha_a === "T: S1->VH-VV-VH")
  {
    var s1_Chart = ui.Chart.image.series(s1a, point, ee.Reducer.mean(), 250);
    s1_Chart.setOptions({ title: 'Sentinel 1 - SAR Data', vAxis: {title: 'Polorazation', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, s1_Chart);
  }
  else if(picha_a === "T: S2->B1-B7")
  {
    var s2_Chart = ui.Chart.image.series(s2a, point, ee.Reducer.mean(), 250);
    s2_Chart.setOptions({ title: 'Sentinel 2 - B1->B7', vAxis: {title: 'DN', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, s2_Chart);
  }
  if(picha_a === "T: LS8->B1-B7")
  {
    var ls8a_Chart = ui.Chart.image.series(ls8a, point, ee.Reducer.mean(), 250);
    ls8a_Chart.setOptions({ title: 'Landsat 8 OLI - B1->B7', vAxis: {title: 'DN', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, ls8a_Chart);
  }
  else if(picha_a === "T: S5-Carbon Monoxide")
  {
    var s5coa_Chart = ui.Chart.image.series(s5coa.select("CO_column_number_density"), point, ee.Reducer.mean(), 250);
    s5coa_Chart.setOptions({ title: 'Sentinel 5 - Carbon Monoxide', vAxis: {title: 'mol/m^2', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, s5coa_Chart);
  }
  else if(picha_a === "T: S5-Sulpher Dioxide")
  {                                                     
    var s5sda_Chart = ui.Chart.image.series(s5sda.select("SO2_column_number_density"), point, ee.Reducer.mean(), 250);
    s5sda_Chart.setOptions({ title: 'Sentinel 5 - Sulpher Dioxide', vAxis: {title: 'mol/m^2', maxValue: 0, minValue: 2},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, s5sda_Chart);
  }
  else if(picha_a === "T: S5-Nitrogen Dioxide")
  {
    var s5noa_Chart = ui.Chart.image.series(s5noa.select("NO2_column_number_density"), point, ee.Reducer.mean(), 250);
    s5noa_Chart.setOptions({ title: 'Sentinel 5 - Nitrogen Dioxide', vAxis: {title: 'mol/m^2', maxValue: 0, minValue: 2},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, s5noa_Chart);
  }
  //=====================================================================================================
  else if(picha_a === "T: MODIS-NDVI")
  {
    var modis_ndvi_Chart = ui.Chart.image.series(modis_ndvi, point, ee.Reducer.mean(), 250);
    modis_ndvi_Chart.setOptions({ title: 'MODIS - Normalized Difference Vegetation Index(NDVI)', vAxis: {title: 'NDVI(x0.0001)', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_ndvi_Chart);
  }
  else if(picha_a === "T: MODIS-EVI")
  {
    var evi_Chart = ui.Chart.image.series(modis_evi, point, ee.Reducer.mean(), 250);
    evi_Chart.setOptions({ title: 'MODIS - Enhanced Vegetation Index', vAxis: {title: 'EVI(x0.0001)', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, evi_Chart);
  }
  else if(picha_a === "T: MODIS-LST-Day")
  {
    var modis_lst_day_Chart = ui.Chart.image.series(modis_lst_day, point, ee.Reducer.mean(), 250);
    modis_lst_day_Chart.setOptions({ title: 'MODIS Land Surface Temperature - DAY', vAxis: {title: 'LST-DAY(x0.02) Kelvin', maxValue: 20000, minValue: 10000},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_lst_day_Chart);
  }
  else if(picha_a === "T: MODIS-LST-Night")
  {
    var modis_lst_night_Chart = ui.Chart.image.series(modis_lst_night, point, ee.Reducer.mean(), 250);
    modis_lst_night_Chart.setOptions({ title: 'MODIS Land Surface Temperature - NIGHT', vAxis: {title: 'LST-NIGHT(x0.02) Kelvin', maxValue: 20000, minValue: 10000},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_lst_night_Chart);
  }
  else if(picha_a === "T: MODIS-SSM")
  {
    var modis_ssm_Chart = ui.Chart.image.series(modis_ssm, point, ee.Reducer.mean(), 250);
    modis_ssm_Chart.setOptions({ title: 'MODIS Surface Soil Moisture', vAxis: {title: 'SSM', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_ssm_Chart);
  }
  else if(picha_a === "T: MODIS-SuSM")
  {
    var modis_susm_Chart = ui.Chart.image.series(modis_susm, point, ee.Reducer.mean(), 250);
    modis_susm_Chart.setOptions({ title: 'MODIS Sub Surface Soil Moisture', vAxis: {title: 'SuSSM', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_susm_Chart);
  }
  else if(picha_a === "T: MODIS-Fire")
  {                                                     
    var modis_fire_Chart = ui.Chart.image.series(modis_fire, point, ee.Reducer.count(), 250);
    modis_fire_Chart.setOptions({ title: 'MODIS Wildfire Activities', vAxis: {title: 'Fire Incidences', maxValue: 0, minValue: 2},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_fire_Chart);
  }
  else if(picha_a === "T: Precipitation")
  {
    var chirps_pre_Chart = ui.Chart.image.series(chirps_pre, point, ee.Reducer.sum(), 250);
    chirps_pre_Chart.setOptions({ title: 'CHIRPS-Precipitation (Estimations)', vAxis: {title: 'mm/day', maxValue: 0, minValue: 2},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, chirps_pre_Chart);
  }
  else if(picha_a === "O: MODIS-Chlorophyll")
  {
    var baharia_Chart = ui.Chart.image.series(baharia.select('chlor_a'), point, ee.Reducer.mean(), 250);
    baharia_Chart.setOptions({ title: 'MODIS - Chlorophyll a concentration', vAxis: {title: 'mg m-3', maxValue: 0, minValue: 100},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, baharia_Chart);
  }
  else if(picha_a === "O: MODIS-POC")
  {
    var baharia_Chart = ui.Chart.image.series(baharia.select('poc'), point, ee.Reducer.mean(), 250);
    baharia_Chart.setOptions({ title: 'MODIS - Particulate organic carbon', vAxis: {title: 'mg m-3', maxValue: -2000, minValue: 12000},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, baharia_Chart);
  }
  else if(picha_a === "O: MODIS-SST")
  {
    var baharia_Chart = ui.Chart.image.series(baharia.select('sst'), point, ee.Reducer.mean(), 250);
    baharia_Chart.setOptions({ title: 'MODIS - Sea surface temperature', vAxis: {title: '°C', maxValue: 0, minValue: 50},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, baharia_Chart);
  }
  else
  {
    alert('Select Data type, Left-the first dropdown box');
  }
});
//=================================================================================================
//=================================================================================================
//Function for selected Wards or CBOs
function kata_cbnrm(eneo,jinalaneo,picha_a)
{
  if(picha_a === "T: S1->VH-VV-VH")
  {
    //var s1_Chart = ui.Chart.image.histogram(s1a, AOI, 1000).setOptions(options);
    var s1_Chart = ui.Chart.image.series(s1a, eneo, ee.Reducer.mean(), 1000);
    s1_Chart.setOptions({ title: jinalaneo + ': Sentinel 1 - SAR Data', vAxis: {title: 'Polorazation', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, s1_Chart);
  }
  else if(picha_a === "T: S2->B1-B7")
  {
    var s2_Chart = ui.Chart.image.series(s2a, eneo, ee.Reducer.mean(), 1000);
    s2_Chart.setOptions({ title: jinalaneo + ': Sentinel 2 - B1->B7', vAxis: {title: 'DN', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, s2_Chart);
  }
  if(picha_a === "T: LS8->B1-B7")
  {
    var ls8a_Chart = ui.Chart.image.series(ls8a, eneo, ee.Reducer.mean(), 1000);
    ls8a_Chart.setOptions({ title: jinalaneo + ': Landsat 8 OLI - B1->B7', vAxis: {title: 'DN', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, ls8a_Chart);
  }
  else if(picha_a === "T: S5-Carbon Monoxide")
  {
    var s5coa_Chart = ui.Chart.image.series(s5coa.select("CO_column_number_density"), eneo, ee.Reducer.mean(), 1000);
    s5coa_Chart.setOptions({ title: jinalaneo + ': Sentinel 5 - Carbon Monoxide', vAxis: {title: 'mol/m^2', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, s5coa_Chart);
  }
  else if(picha_a === "T: S5-Sulpher Dioxide")
  {                                                     
    var s5sda_Chart = ui.Chart.image.series(s5sda.select("SO2_column_number_density"), eneo, ee.Reducer.mean(), 1000);
    s5sda_Chart.setOptions({ title: jinalaneo + ': Sentinel 5 - Sulpher Dioxide', vAxis: {title: 'mol/m^2', maxValue: 0, minValue: 2},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, s5sda_Chart);
  }
  else if(picha_a === "T: S5-Nitrogen Dioxide")
  {
    var s5noa_Chart = ui.Chart.image.series(s5noa.select("NO2_column_number_density"), eneo, ee.Reducer.mean(), 1000);
    s5noa_Chart.setOptions({ title: jinalaneo + ': Sentinel 5 - Nitrogen Dioxide', vAxis: {title: 'mol/m^2', maxValue: 0, minValue: 2},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, s5noa_Chart);
  }
  //=====================================================================================================
  else if(picha_a === "T: MODIS-NDVI")
  {
    var modis_ndvi_Chart = ui.Chart.image.series(modis_ndvi, eneo, ee.Reducer.median(), 1000);
    modis_ndvi_Chart.setOptions({ title: jinalaneo + ': MODIS - Normalized Difference Vegetation Index(NDVI)', vAxis: {title: 'NDVI(x0.0001)', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_ndvi_Chart);
    var modis_ndvi_viz = modis_ndvi.median().clip(eneo).multiply(0.0001);
    var viz_a = {min:0, max:1,palette:["ff3508","d8ff04","06700e"]}
    map.addLayer(modis_ndvi_viz,viz_a, jinalaneo +'-> NDVI(Median)',1)
    var kala = modis_ndvi_viz.visualize({bands:"NDVI", min:0, max:1, palette:["ff3508","d8ff04","06700e"], forceRgbOutput:true});
    picha(eneo, kala, jinalaneo);
  }
  else if(picha_a === "T: MODIS-EVI")
  {
    var evi_Chart = ui.Chart.image.series(modis_evi, eneo, ee.Reducer.median(), 1000);
    evi_Chart.setOptions({ title: jinalaneo + ': MODIS - Enhanced Vegetation Index', vAxis: {title: 'EVI(x0.0001)', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, evi_Chart);
    var modis_evi_viz = modis_evi.median().clip(eneo).multiply(0.0001);
    var viz_a = {min:0, max:1,palette:["ff3508","d8ff04","06700e"]}
    map.addLayer(modis_evi_viz,viz_a, jinalaneo +'-> EVI(Median)',1)
    var kala = modis_evi_viz.visualize({bands:"EVI", min:0, max:1, palette:["ff3508","d8ff04","06700e"], forceRgbOutput:true});
    picha(eneo, kala, jinalaneo);
  }
  else if(picha_a === "T: MODIS-LST-Day")
  {
    var modis_lst_day_Chart = ui.Chart.image.series(modis_lst_day, eneo, ee.Reducer.median(), 1000);
    modis_lst_day_Chart.setOptions({ title: jinalaneo + ': MODIS Land Surface Temperature - DAY', vAxis: {title: 'LST-DAY(x0.02) Kelvin', maxValue: 20000, minValue: 10000},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_lst_day_Chart);
    var modis_lstd_viz = modis_lst_day.median().clip(eneo).multiply(0.0001);
    var viz_a = {min:0, max:1,palette:["ff3508","d8ff04","06700e"]}
    map.addLayer(modis_lstd_viz,viz_a, jinalaneo +'-> LST-Day(Median)',1)
    var kala = modis_lstd_viz.visualize({bands:"LST_Day_1km", min:0, max:1, palette:["ff3508","d8ff04","06700e"], forceRgbOutput:true});
    picha(eneo, kala, jinalaneo);
  }
  else if(picha_a === "T: MODIS-LST-Night")
  {
    var modis_lst_night_Chart = ui.Chart.image.series(modis_lst_night, eneo, ee.Reducer.median(), 1000);
    modis_lst_night_Chart.setOptions({ title: jinalaneo + ': MODIS Land Surface Temperature - NIGHT', vAxis: {title: 'LST-NIGHT(x0.02) Kelvin', maxValue: 20000, minValue: 10000},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_lst_night_Chart);
    var modis_lstn_viz = modis_lst_night.median().clip(eneo).multiply(0.0001);
    var viz_a = {min:0, max:1,palette:["ff3508","d8ff04","06700e"]}
    map.addLayer(modis_lstn_viz,viz_a, jinalaneo +'-> LST-Day(Median)',1)
    var kala = modis_lstn_viz.visualize({bands:"LST_Night_1km", min:0, max:1, palette:["ff3508","d8ff04","06700e"], forceRgbOutput:true});
    picha(eneo, kala, jinalaneo);
  }
  else if(picha_a === "T: MODIS-SSM")
  {
    var modis_ssm_Chart = ui.Chart.image.series(modis_ssm, eneo, ee.Reducer.median(), 1000);
    modis_ssm_Chart.setOptions({ title: jinalaneo + ': MODIS Surface Soil Moisture', vAxis: {title: 'SSM', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_ssm_Chart);
  }
  else if(picha_a === "T: MODIS-SuSM")
  {
    var modis_susm_Chart = ui.Chart.image.series(modis_susm, eneo, ee.Reducer.median(), 1000);
    modis_susm_Chart.setOptions({ title: jinalaneo + ': MODIS Sub Surface Soil Moisture', vAxis: {title: 'SuSSM', maxValue: 1, minValue: -1},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_susm_Chart);
  }
  else if(picha_a === "T: MODIS-Fire")
  {                                                     
    var modis_fire_Chart = ui.Chart.image.series(modis_fire, eneo, ee.Reducer.count(), 1000);
    modis_fire_Chart.setOptions({ title: jinalaneo + ': MODIS Wildfire Activities', vAxis: {title: 'Fire Incidences', maxValue: 0, minValue: 2},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, modis_fire_Chart);
  }
  else if(picha_a === "T: Precipitation")
  {
    var chirps_pre_Chart = ui.Chart.image.series(chirps_pre, eneo, ee.Reducer.sum(), 1000);
    chirps_pre_Chart.setOptions({ title: jinalaneo + ': CHIRPS-Precipitation (Estimations)', vAxis: {title: 'mm/day', maxValue: 0, minValue: 2},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, chirps_pre_Chart);
  }
  else if(picha_a === "O: MODIS-Chlorophyll")
  {
    var baharia_Chart = ui.Chart.image.series(baharia.select('chlor_a'), eneo, ee.Reducer.median(), 1000);
    baharia_Chart.setOptions({ title: jinalaneo + ': MODIS - Chlorophyll a concentration', vAxis: {title: 'mg m-3', maxValue: 0, minValue: 100},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, baharia_Chart);
  }
  else if(picha_a === "O: MODIS-POC")
  {
    var baharia_Chart = ui.Chart.image.series(baharia.select('poc'), eneo, ee.Reducer.median(), 1000);
    baharia_Chart.setOptions({ title: jinalaneo + ': MODIS - Particulate organic carbon', vAxis: {title: 'mg m-3', maxValue: -2000, minValue: 12000},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, baharia_Chart);
  }
  else if(picha_a === "O: MODIS-SST")
  {
    var baharia_Chart = ui.Chart.image.series(baharia.select('sst'), eneo, ee.Reducer.median(), 1000);
    baharia_Chart.setOptions({ title: jinalaneo + ': MODIS - Sea surface temperature', vAxis: {title: '°C', maxValue: 0, minValue: 50},hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}}, });
    panel_grafu.widgets().set(1, baharia_Chart);
  }
}
//=================================================================================================
function bonyezoa()
{
  panel_grafu.clear();
  var picha_a = chagua_sat.getValue();
  kata_cbnrm(geom,geomjina,picha_a);
}
//--------------------------------------------------------------------------
function bonyezob()
{
  panel_grafu.clear();
  var picha_a = chagua_sat.getValue();
  kata_cbnrm(geom_cbo,geomjina,picha_a);
}
function picha(eneo_sasa, ndvi_to_jpeg, jina_sasa)
{
  var img_bound = ee.Geometry.Polygon(eneo_sasa.geometry().coordinates());
  var downloadArgsRGB = {dimensions:1024,region:img_bound, format:"jpg"};
  var urlrgb = ndvi_to_jpeg.getDownloadURL(downloadArgsRGB);
  var urlLabelrgb = ui.Label('Download-NDVI', {shown: false});
  urlLabelrgb.setUrl(urlrgb);
  urlLabelrgb.style().set({shown: true});
  panel_grafu.widgets().set(2, urlLabelrgb);
}
//=================================================================================================
map.setControlVisibility({zoomControl: true});
map.setControlVisibility({layers: true});
var title = ui.Label('Tanzania CBNRM - Monitoring from Space', {
stretch: 'horizontal', textAlign: 'center', fontWeight: 'bold', fontSize: '30px' });
// Create a grid of maps.
var mapGrid = ui.Panel(
[
panel,
ui.Panel(map, null, {stretch: 'both'}),
],
ui.Panel.Layout.Flow('horizontal'), {width: '100%', stretch: 'both'}
);
map.add(panel_grafu);
ui.root.widgets().reset([title, mapGrid]);
ui.root.setLayout(ui.Panel.Layout.Flow('vertical'));
map.style().set('cursor', 'crosshair');
// Add the panel to the ui.root.i
//ui.root.insert(0, panel);