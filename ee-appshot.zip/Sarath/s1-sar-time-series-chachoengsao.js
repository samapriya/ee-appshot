var chs = ee.FeatureCollection("users/Sarath/Chachoengsao");
//======================== Rice Yield Mapping at Chachoengsao ================================
//-------------------------- Select Polarization ---------------------------------------------
              //------------ Select VV Polarization ----------------
var imgVV = ee.ImageCollection('COPERNICUS/S1_GRD')
        .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
        .filter(ee.Filter.eq('instrumentMode', 'IW'))
        .select('VV')
        .map(function(image) {
          var edgeVV = image.lt(-30.0);
          var maskedImageVV = image.mask().and(edgeVV.not());
          return image.updateMask(maskedImageVV);
        });
var descVV = imgVV.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
var ascVV = imgVV.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));
              //------------ Select VH Polarization ----------------
var imgVH = ee.ImageCollection('COPERNICUS/S1_GRD')
        .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
        .filter(ee.Filter.eq('instrumentMode', 'IW'))
        .select('VH')
        .map(function(image) {
          var edgeVH = image.lt(-30.0);
          var maskedImageVH = image.mask().and(edgeVH.not());
          return image.updateMask(maskedImageVH);
        });
var descVH = imgVH.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
var ascVH = imgVH.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));
//------------------------------ Mean Time Series 2017 ---------------------------------------
              //---------------- VV Mean Time Series ---------------
var springVV7 = ee.Filter.date('2017-03-01', '2017-04-20');
var lateSpringVV7 = ee.Filter.date('2017-04-21', '2017-06-10');
var summerVV7 = ee.Filter.date('2017-06-11', '2017-08-31');
var descChangeVV7 = ee.Image.cat(
        descVV.filter(springVV7).mean(),
        descVV.filter(lateSpringVV7).mean(),
        descVV.filter(summerVV7).mean());
var ascChangeVV7 = ee.Image.cat(
        ascVV.filter(springVV7).mean(),
        ascVV.filter(lateSpringVV7).mean(),
        ascVV.filter(summerVV7).mean());
Map.centerObject(chs, 10);
Map.addLayer(ascChangeVV7.clip(chs), {min: -25, max: 5}, 'VV ASC Mean Time series 2017',0);
Map.addLayer(descChangeVV7.clip(chs), {min: -25, max: 5}, 'VV DESC Mean Time series 2017',0);
              //---------------- VH Mean Time Series ---------------
var springVH7 = ee.Filter.date('2017-03-01', '2017-04-20');
var lateSpringVH7 = ee.Filter.date('2017-04-21', '2017-06-10');
var summerVH7 = ee.Filter.date('2017-06-11', '2017-08-31');
var descChangeVH7 = ee.Image.cat(
        descVH.filter(springVH7).mean(),
        descVH.filter(lateSpringVH7).mean(),
        descVH.filter(summerVH7).mean());
var ascChangeVH7 = ee.Image.cat(
        ascVH.filter(springVH7).mean(),
        ascVH.filter(lateSpringVH7).mean(),
        ascVH.filter(summerVH7).mean());
Map.addLayer(ascChangeVH7.clip(chs), {min: -25, max: 5}, 'VH ASC Mean Time series 2017', 0);
Map.addLayer(descChangeVH7.clip(chs), {min: -25, max: 5}, 'VH DESC Mean Time series 2017');
//------------------------------ Mean Time Series 2018 ---------------------------------------
              //---------------- VV Mean Time Series ---------------
var springVV8 = ee.Filter.date('2018-03-01', '2018-04-20');
var lateSpringVV8 = ee.Filter.date('2018-04-21', '2018-06-10');
var summerVV8 = ee.Filter.date('2018-06-11', '2018-08-31');
var descChangeVV8 = ee.Image.cat(
        descVV.filter(springVV8).mean(),
        descVV.filter(lateSpringVV8).mean(),
        descVV.filter(summerVV8).mean());
var ascChangeVV8 = ee.Image.cat(
        ascVV.filter(springVV8).mean(),
        ascVV.filter(lateSpringVV8).mean(),
        ascVV.filter(summerVV8).mean());
Map.addLayer(ascChangeVV8.clip(chs), {min: -25, max: 5}, 'VV ASC Mean Time series 2018',0);
Map.addLayer(descChangeVV8.clip(chs), {min: -25, max: 5}, 'VV DESC Mean Time series 2018',0);
              //---------------- VH Mean Time Series ---------------
var springVH8 = ee.Filter.date('2018-03-01', '2018-04-20');
var lateSpringVH8 = ee.Filter.date('2018-04-21', '2018-06-10');
var summerVH8 = ee.Filter.date('2018-06-11', '2018-08-31');
var descChangeVH8 = ee.Image.cat(
        descVH.filter(springVH8).mean(),
        descVH.filter(lateSpringVH8).mean(),
        descVH.filter(summerVH8).mean());
var ascChangeVH8 = ee.Image.cat(
        ascVH.filter(springVH8).mean(),
        ascVH.filter(lateSpringVH8).mean(),
        ascVH.filter(summerVH8).mean());
Map.addLayer(ascChangeVH8.clip(chs), {min: -25, max: 5}, 'VH ASC Mean Time series 2018', 0);
Map.addLayer(descChangeVH8.clip(chs), {min: -25, max: 5}, 'VH DESC Mean Time series 2018');
//---------------------------S1-Composite-2019---------------------------------------------------