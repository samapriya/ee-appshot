var bare = /* color: #d63000 */ee.Geometry.Polygon(
        [[[139.7706413269043, 35.68930003252],
          [139.77252960205078, 35.686790395584616],
          [139.77167129516602, 35.682119472193015],
          [139.76703643798828, 35.676820780304936],
          [139.75862503051758, 35.66887208278222],
          [139.76119995117188, 35.66691965002161],
          [139.77845191955566, 35.68469897115985],
          [139.77639198303223, 35.69027598111645],
          [139.777250289917, 35.69689817401091],
          [139.7706413269043, 35.69682846958083],
          [139.76463317871094, 35.694597895648705]]]),
    vegetation = /* color: #98ff00 */ee.Geometry.Polygon(
        [[[139.48328018188477, 35.645788484330524],
          [139.47821617126465, 35.6446027417394],
          [139.4717788696289, 35.644951491387054],
          [139.46791648864746, 35.64244045994719],
          [139.46722984313965, 35.6393015596771],
          [139.46585655212402, 35.637139134432616],
          [139.47152137756348, 35.62841908418471],
          [139.47555541992188, 35.629256250286076],
          [139.47538375854492, 35.63288386875377],
          [139.484224319458, 35.635534716602635],
          [139.48225021362305, 35.6393015596771],
          [139.48104858398438, 35.6427892190328]]]),
    water = /* color: #0b4a8b */ee.Geometry.Polygon(
        [[[139.84703063964844, 35.606230988442306],
          [139.8401641845703, 35.5593226935561],
          [139.91260528564453, 35.57244861562281],
          [139.85698699951172, 35.62437265777844]]]),
    s2 = ee.ImageCollection("COPERNICUS/S2"),
    camb = ee.FeatureCollection("users/Sarath/Cam_Boundary"),
    srtm = ee.Image("USGS/SRTMGL1_003"),
    l8 = ee.ImageCollection("LANDSAT/LC08/C01/T1_RT_TOA"),
    wwf = ee.Image("WWF/HydroSHEDS/03CONDEM"),
    cam = ee.FeatureCollection("users/Sarath/Cambodia_buffer"),
    m1 = ee.Image("users/Sarath/Sketchy");
var alos = ee.Image("JAXA/ALOS/AW3D30_V1_1");
// Import the ALOS DEM
var elev = alos.select(0);
// Add the elevation to the map.  Play with the visualization tools
// to get a better visualization.
//Map.addLayer(elev.clip(camb), {}, 'elev', false);
// Use the terrain algorithms to compute a hillshade with 8-bit values.
var shade = ee.Terrain.hillshade(elev);
Map.addLayer(shade.clip(camb), {}, 'JAXA Hillshade', false);
// Create an "ocean" variable to be used for cartographic purposes
var ocean = elev.lte(0);
//Map.addLayer(ocean.mask(ocean), {palette:'000022'}, 'ocean', false);
// Create a custom elevation palette from hex strings.
var elevationPalette = ['006600', '002200', 'fff700', 'ab7634', 'c4d0ff', 'ffffff'];
// Use these visualization parameters, customized by location.
var visParams = {min: 1, max: 3000, palette: elevationPalette};
// Create a mosaic of the ocean and the elevation data
var visualized = ee.ImageCollection([
  // Mask the elevation to get only land
  elev.mask(ocean.not()).visualize(visParams), 
  // Use the ocean mask directly to display ocean.
  ocean.mask(ocean).visualize({palette:'000022'})
]).mosaic();
// Note that the visualization image doesn't require visualization parameters.
//Map.addLayer(visualized.clip(camb), {}, 'elev palette', false);
// Convert the visualized elevation to HSV, first converting to [0, 1] data.
var hsv = visualized.divide(255).rgbToHsv();
// Select only the hue and saturation bands.
var hs = hsv.select(0, 1);
// Convert the hillshade to [0, 1] data, as expected by the HSV algorithm.
var v = shade.divide(255);
// Create a visualization image by converting back to RGB from HSV.
// Note the cast to byte in order to export the image correctly.
var rgb = hs.addBands(v).hsvToRgb().multiply(255).byte();
Map.addLayer(rgb.clip(camb), {}, 'JAXA DEM', false);
// Export an area of interest, defined as the area in the map viewport.
// Map.setCenter(-121.069, 50.709, 6);
Export.image.toDrive({
  image: rgb.clip(cam), 
  description: 'JAXA DEM Cambodia', 
  scale: 30,
  crs: 'EPSG:3857'
});
// Function to mask clouds using the Sentinel-2 QA band. 
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = ee.Number(2).pow(10).int();
  var cirrusBitMask = ee.Number(2).pow(11).int();
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0));
  // Return the masked and scaled data.
  return image.updateMask(mask).divide(10000);
}
  // Map the function over one year of data and take the median.
var composite = s2
      .filterDate('2019-01-01', '2019-04-09')
      // Pre-filter to get less cloudy granules.
      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
      .filterBounds(camb)
      .map(maskS2clouds)
      //.multiply(100)
      .median();
Map.centerObject(camb, 8);
var dem = wwf.clip(camb);
// Use the normalizedDifference(A, B) to compute (A - B) / (A + B)
   // Calculate EVI
var roi = composite.clip(camb);
var evi = roi.expression(
    '2.5 * ((NIR-RED) / (NIR + 6 * RED -7.5 * BLUE))', {
      'NIR':roi.select('B8'),
      'RED':roi.select('B4'),
      'BLUE':roi.select('B2')
    });
  // Calculate NDVI
var ndvi = roi.expression(
    '(NIR-RED)/(NIR+RED)',{
    'NIR':roi.select('B8'),
    'RED':roi.select('B4')
    });
var EVI = evi.multiply(5).toInt16();
/* var EVI = evi.multiply(100).uint16()
var meanDictionary = EVI.reduceRegion({
  reducer: ee.Reducer.mean(),
  geometry: chs.geometry(),
  scale: 20,
  maxPixels: 1e9
});
print(meanDictionary);*/
// Make a palette: a list of hex strings.
var palet = ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
               '74A901', '66A000', '529400', '3E8601', '207401', '056201',
               '004C00', '023B01', '012E01', '011D01', '011301'];
var palett = ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
               '74A901', '66A000', '529400', '3E8601', '207401', '056201',
               '004C00', '023B01', '012E01', '011D01', '011301'];
var dempalet = ['3ae237', 'b5e22e', 'd6e21f', 'fff705', 'ffd611', 'ffb613', 'ff8b13',
    'ff6e08', 'ff500d', 'ff0000', 'de0101', 'c21301', '0602ff', '235cb1',
    '307ef3', '269db1', '30c8e2', '32d3ef', '3be285', '3ff38f', '86e26f'];
print(EVI);
// Display the results.
Map.addLayer(m1.clip(camb),{},'Sketchy DEM');
Map.addLayer(dem,{min:-20, max:1800, palette: dempalet},'SRTM 30m', false);
Map.addLayer(roi, {bands: ['B4', 'B3', 'B2'], min: 0, max: 0.3, gamma: 1.5},'S2-RGB', false);
Map.addLayer(roi, {bands: ['B11', 'B8', 'B2'], min: 0, max: 0.4},'S2-Agriculture',false);
Map.addLayer(roi, {bands: ['B8', 'B11', 'B2'], min: 0, max: 0.4},'S2-Healthy Vegetation', false);
//Map.addLayer(roi, {bands: ['B8', 'B11', 'B4'], min: 0, max: 0.3},'Land/Water');
Map.addLayer(roi, {bands: ['B11', 'B8', 'B4'], min: 0, max: 0.3},'Vegetation Analysis', false);
//Map.addLayer(roi, {bands: ['B4', 'B8', 'B3'], min: 0, max: 0.3},'False');
Map.addLayer(roi, {bands: ['B8', 'B4', 'B3'], min: 0, max: 0.3},'S2-NIR', false);
Map.addLayer(ndvi,{min: 0, max: 1, palette: palett},'S2-NDVI', false);
//Map.addLayer(EVI,{min: -125, max: 125, palette: palet},'EVI', false);
// Load the Sentinel-1 ImageCollection.
var sentinel1 = ee.ImageCollection('COPERNICUS/S1_GRD')
      .filterDate('2019-01-01', '2019-04-09');
// Filter by metadata properties.
var vh = sentinel1
  // Filter to get images with VV and VH dual polarization.
  .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
  .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
  // Filter to get images collected in interferometric wide swath mode.
  .filter(ee.Filter.eq('instrumentMode', 'IW'));
// Filter to get images from different look angles.
var vhAscending = vh.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));
var vhDescending = vh.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
// Create a composite from means at different polarizations and look angles.
var composite = ee.Image.cat([
  vhAscending.select('VH').mean(),
  ee.ImageCollection(vhAscending.select('VV').merge(vhDescending.select('VV'))).mean(),
  vhDescending.select('VH').mean()
]).focal_median();
// Display as a composite of polarization and backscattering characteristics.
Map.addLayer(composite.clip(camb), {min: [-25, -20, -25], max: [0, 10, 0]}, 'S1-SAR VV-VH', false);
// The purpose of this script is to estimate sub-pixel fractions
// of identifiable spectral "endmembers".  This involves finding
// "pure" areas to estimate the endmembers, some matrix algebra
// followed by the mapping of the fractional cover.
// Use the reflective bands.
var bands = ['B2', 'B3', 'B4', 'B5', 'B6', 'B7'];
// Load Landsat 8 surface reflectance data
var l8sr = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR');
// Function to cloud mask from the Fmask band of Landsat 8 SR data.
function maskL8sr(image) {
  // Bits 3 and 5 are cloud shadow and cloud, respectively.
  var cloudShadowBitMask = ee.Number(2).pow(3).int();
  var cloudsBitMask = ee.Number(2).pow(5).int();
  // Get the pixel QA band.
  var qa = image.select('pixel_qa');
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudShadowBitMask).eq(0)
      .and(qa.bitwiseAnd(cloudsBitMask).eq(0));
  // Return the masked image, scaled to [0, 1].
  return image.updateMask(mask).divide(10000);
}
// Map the function over one year of data and take the median.
var image = l8sr.filterDate('2018-01-01', '2018-12-31')
                    .map(maskL8sr)
                    .median()
                    .select(bands);
// Display the results.
Map.addLayer(image.clip(camb), {bands: ['B4', 'B3', 'B2'], min: 0, max: 0.3}, 'L8 RGB',0);
// Now, delineate polygons of 'pure' regions.  Click +New Layer for 
// each polygon.  Name the imports 'bare', 'vegetation' and 'water'.
// Get the mean spectrum in each of the endmember polygons.
var bareMean = image.reduceRegion(ee.Reducer.mean(), bare, 30).values();
var waterMean = image.reduceRegion(ee.Reducer.mean(), water, 30).values();
var vegMean = image.reduceRegion(ee.Reducer.mean(), vegetation, 30).values();
// Optional: plot the endmembers
var chart = ui.Chart.image.regions({
  image: image, 
  regions: ee.FeatureCollection([
    ee.Feature(bare, {label: 'bare'}),
    ee.Feature(vegetation, {label: 'vegetation'}),
    ee.Feature(water, {label: 'water'})
  ]), 
  reducer: ee.Reducer.mean(), 
  scale: 30, 
  seriesProperty: 'label', 
  xLabels: [0.48, 0.56, 0.65, 0.86, 1.61, 2.2]
}).setOptions({
  series: {
    0: { color: 'red' },
    1: { color: 'green' },
    2: { color: 'blue' }
  }
});
print(chart);
// Turn the endmember lists into an array that can be used in unmixing.
// Concatenate the lists along the 1-axis to make an array.
var endmembers = ee.Array.cat([bareMean, vegMean, waterMean], 1);
// Turn the image into an array image, in which each pixel has a 2-D matrix.
var arrayImage = image.toArray().toArray(1);
// Perform the unmixing in array space using the matrixSolve image method.  
// Note the need to cast the endmembers into an array image.
var unmixed = ee.Image(endmembers).matrixSolve(arrayImage);
// Convert the result from an array image back to a multi-band image.
var unmixedImage = unmixed.arrayProject([0])
    .arrayFlatten([['bare', 'veg', 'water']]);
// Display the result.
Map.addLayer(unmixedImage.clip(camb), {}, 'L8 Fractions', false);
// Constrained:
var constrained = image.unmix([bareMean, vegMean, waterMean], true, true);
//Map.addLayer(constrained, {}, 'constrained fractions');
/* Export maps
Export.image.toDrive({
  image:EVI,
  description: 'EVI_Chachoengsao',
  scale: 10,
 region: camb,
  maxPixels:34089663741
  }); */