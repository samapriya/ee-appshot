var samburu = ee.FeatureCollection("users/astokes2/samburu_county"),
    points = ee.FeatureCollection("users/astokes2/samburu_points"),
    conservancies = ee.FeatureCollection("users/astokes2/Kenyan_Conservancies_WGS84"),
    NDVI = ee.ImageCollection("MODIS/006/MOD13Q1");
// Can run for any drought between 2000 and present
//Selecting NDVI band from terra image collection
NDVI = NDVI.select("NDVI");
print("NDVI Complete",NDVI);
//creating buffer around conservancies
//var boundary =ee.Geometry.Point(37.52, 1.00).buffer(90000);
var boundary = samburu;
//var boundary = ee.Geometry.Point(37.13547851562498,1.3679627821240812).buffer(100000)
//Uncomment to print Conservancy data
//print(conservancies.filterMetadata("County",'equals','Samburu'), "Conservancies");
//Setting center at boundary
Map.setCenter(37.52, 1.00,8.5); 
//List initiation
var seasonStart = ee.List([1,4,6,11]);
var seasonEnd = ee.List([3,5,10,12]);
var seasonNames = ee.List(["Short Dry", "Short Rain", "Long Dry", "Long Rain"]);
var index = ee.List([0,1,2,3]);
var years = ee.List.sequence(2001,2018);  //Edit which drought here
var months = ee.List.sequence(1,12);
//Seasonal Anomaly
var seasonalAnomaly = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return index.map(function (m) {
      return NDVI
        .filter(ee.Filter.calendarRange(y, y, 'year'))
        .filter(ee.Filter.calendarRange(ee.Number(seasonStart.get(m)),ee.Number(seasonEnd.get(m)), 'month'))
        .mean()
        .clip(boundary)
        .subtract(NDVI.filter(ee.Filter.calendarRange(ee.Number(seasonStart.get(m)),
              ee.Number(seasonEnd.get(m)),'month')).mean().clip(boundary))
        .set('season', seasonNames.get(m))
        .set('year', y)
        .set('system:time_start',ee.Date.fromYMD(y,ee.Number(seasonStart.get(m)).add(ee.Number(seasonEnd.get(m))).divide(2).toInt(),1))
        ;
  });
}).flatten());
print("Seasonal Anomaly", seasonalAnomaly);
//Monthly Anomaly
var monthlyAnomaly = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return months.map(function (m) {
      return NDVI
        .filter(ee.Filter.calendarRange(m, m, 'month'))
        .filter(ee.Filter.calendarRange(y,y,'year'))
        .mean()
        .clip(boundary)
        .subtract(NDVI.filter(ee.Filter.calendarRange(m,m, 'month')).mean().clip(boundary))
        .set('month', m)
        .set('year', y)
        .set('system:time_start',ee.Date.fromYMD(y,m,1))
        ;
  });
}).flatten());
print("Monthly Anomaly",monthlyAnomaly);
//Seasonal NDVI
var seasonalNDVI = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return index.map(function (m) {
      return NDVI
        .filter(ee.Filter.calendarRange(y, y, 'year'))
        .filter(ee.Filter.calendarRange(ee.Number(seasonStart.get(m)),ee.Number(seasonEnd.get(m)), 'month'))
        .mean()
        .clip(boundary)
        .set('season', seasonNames.get(m))
        .set('year', y)
        .set('system:time_start',ee.Date.fromYMD(y,ee.Number(seasonStart.get(m)).add(ee.Number(seasonEnd.get(m))).divide(2).toInt(),1))
        ;
  });
}).flatten());
print("Seasonal NDVI", seasonalNDVI);
//Monthly NDVI 
var monthlyNDVI = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return months.map(function (m) {
      return NDVI
        .filter(ee.Filter.calendarRange(m, m, 'month'))
        .filter(ee.Filter.calendarRange(y,y,'year'))
        .mean()
        .clip(boundary)
        .set('month', m)
        .set('year', y)
        .set('system:time_start',ee.Date.fromYMD(y,m,1))
        ;
  });
}).flatten());
print("Monthly NDVI",monthlyNDVI);
//Animations
var visANOM = {min:-2000, max:2500, 
                  palette:  ['730000','E60000','FFAA00','FCD37F',
                            'FFFF00','FFFFFF','FFFFFF','FFFFFF','FFFFFF',
                            'FFFFFF','FFFFFF','FFFFFF']};
var visNDVI = {min: -2000, max: 11000, 
                  palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555',
                            'FCD163', '99B718', '74A901', '66A000', '529400',
                            '3E8601', '207401', '056201', '004C00','023B01', '012E01', '011D01', '011301']};
var year = ui.Textbox({style:{position: 'top-left'},
  placeholder: 'Enter year here...',
  onChange: function(value) {
    // set value with a dedicated method
    year.setValue(value);
    return(value);
  }
});
Map.add(year);
var month = ui.Textbox({style:{position: 'top-left'},
  placeholder: 'Enter month here...',
  onChange: function(value) {
    // set value with a dedicated method
    month.setValue(value);
    return(value);
  }
});
Map.add(month);
var y;
var m;
var button = ui.Button({style:{position: 'top-left'},
  label: 'Generate Map',
  onClick: function() {
    // you don't have to convert it into EE objects since you are
    // working on the client side
    y = parseFloat(year.getValue());
    print(y);
    m = parseFloat(month.getValue());
    print(m)
    // Split Panel
    Map.addLayer(monthlyNDVI.filter(ee.Filter.eq('year',y)).filter(ee.Filter.eq('month',m)), visNDVI, 'Monthly NDVI');
  var linkedMap = ui.Map();
  // Add anomaly image to the map.
  linkedMap.addLayer(monthlyAnomaly.filter(ee.Filter.eq('year',y)).filter(ee.Filter.eq('month',m)), visANOM, 'Monthly Anomaly');
  // Link the default Map to the other map.
  var linker = ui.Map.Linker([ui.root.widgets().get(0), linkedMap]);
  // Make an inset map and add it to the linked map.
 // var inset = ui.Map({style: {position: "bottom-right"}});
 // linkedMap.add(inset);
  // Register a function to the linked map to update the inset map.
  //linkedMap.onChangeBounds(function() {
   // var bounds =  ee.Geometry.Rectangle(Map.getBounds());
    //inset.centerObject(bounds);
    //inset.layers().set(0, bounds);
  //});
  // Create a SplitPanel which holds the linked maps side-by-side.
  var splitPanel = ui.SplitPanel({
    firstPanel: linker.get(0),
    secondPanel: linker.get(1),
    orientation: 'horizontal',
    wipe: true,
    style: {stretch: 'both'}
  });
  // Set the SplitPanel as the only thing in root.
  ui.root.widgets().reset([splitPanel]);
  linkedMap.setCenter(37.52, 1.00,8.5);
    }
});
Map.add(button);