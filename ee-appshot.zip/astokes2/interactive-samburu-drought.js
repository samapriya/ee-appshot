var samburu = ee.FeatureCollection("users/astokes2/samburu_county"),
    points = ee.FeatureCollection("users/astokes2/samburu_points"),
    conservancies = ee.FeatureCollection("users/astokes2/Kenyan_Conservancies_WGS84"),
    NDVI = ee.ImageCollection("MODIS/006/MOD13Q1");
// Can run for any drought between 2000 and present
//Selecting NDVI band from terra image collection
NDVI = NDVI.select("NDVI");
print("NDVI Complete",NDVI);
//creating buffer around conservancies
//var boundary =ee.Geometry.Point(37.52, 1.00).buffer(90000);
var boundary = samburu;
//var boundary = ee.Geometry.Point(37.13547851562498,1.3679627821240812).buffer(100000)
//Uncomment to print Conservancy data
//print(conservancies.filterMetadata("County",'equals','Samburu'), "Conservancies");
//Setting center at boundary
Map.setCenter(37.52, 1.00,8.5); 
//List initiation
var seasonStart = ee.List([1,4,6,11]);
var seasonEnd = ee.List([3,5,10,12]);
var seasonNames = ee.List(["Short Dry", "Short Rain", "Long Dry", "Long Rain"]);
var index = ee.List([0,1,2,3]);
var years = ee.List.sequence(2008,2012);  //Edit which drought here
var months = ee.List.sequence(1,12);
//Seasonal Anomaly
var seasonalAnomaly = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return index.map(function (m) {
      return NDVI
        .filter(ee.Filter.calendarRange(y, y, 'year'))
        .filter(ee.Filter.calendarRange(ee.Number(seasonStart.get(m)),ee.Number(seasonEnd.get(m)), 'month'))
        .mean()
        .clip(boundary)
        .subtract(NDVI.filter(ee.Filter.calendarRange(ee.Number(seasonStart.get(m)),
              ee.Number(seasonEnd.get(m)),'month')).mean().clip(boundary))
        .set('season', seasonNames.get(m))
        .set('year', y)
        .set('system:time_start',ee.Date.fromYMD(y,ee.Number(seasonStart.get(m)).add(ee.Number(seasonEnd.get(m))).divide(2).toInt(),1))
        ;
  });
}).flatten());
print("Seasonal Anomaly", seasonalAnomaly);
//Monthly Anomaly
var monthlyAnomaly = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return months.map(function (m) {
      return NDVI
        .filter(ee.Filter.calendarRange(m, m, 'month'))
        .filter(ee.Filter.calendarRange(y,y,'year'))
        .mean()
        .clip(boundary)
        .subtract(NDVI.filter(ee.Filter.calendarRange(m,m, 'month')).mean().clip(boundary))
        .set('month', m)
        .set('year', y)
        .set('system:time_start',ee.Date.fromYMD(y,m,1))
        ;
  });
}).flatten());
print("Monthly Anomaly",monthlyAnomaly);
//Seasonal NDVI
var seasonalNDVI = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return index.map(function (m) {
      return NDVI
        .filter(ee.Filter.calendarRange(y, y, 'year'))
        .filter(ee.Filter.calendarRange(ee.Number(seasonStart.get(m)),ee.Number(seasonEnd.get(m)), 'month'))
        .mean()
        .clip(boundary)
        .set('season', seasonNames.get(m))
        .set('year', y)
        .set('system:time_start',ee.Date.fromYMD(y,ee.Number(seasonStart.get(m)).add(ee.Number(seasonEnd.get(m))).divide(2).toInt(),1))
        ;
  });
}).flatten());
print("Seasonal NDVI", seasonalNDVI);
//Monthly NDVI 
var monthlyNDVI = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return months.map(function (m) {
      return NDVI
        .filter(ee.Filter.calendarRange(m, m, 'month'))
        .filter(ee.Filter.calendarRange(y,y,'year'))
        .mean()
        .clip(boundary)
        .set('month', m)
        .set('year', y)
        .set('system:time_start',ee.Date.fromYMD(y,m,1))
        ;
  });
}).flatten());
print("Monthly NDVI",monthlyNDVI);
//Animations
var visANOM = {min:-2000, max:2500, 
                  palette:  ['730000','E60000','FFAA00','FCD37F',
                            'FFFF00','FFFFFF','FFFFFF','FFFFFF','FFFFFF',
                            'FFFFFF','FFFFFF','FFFFFF']};
var visNDVI = {min: -2000, max: 11000, 
                  palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555',
                            'FCD163', '99B718', '74A901', '66A000', '529400',
                            '3E8601', '207401', '056201', '004C00','023B01', '012E01', '011D01', '011301']};
var animation = require('users/gena/packages:animation');
animation.animate(monthlyNDVI, {maxFrames: 100, vis: visNDVI, timestep:300});
animation.animate(monthlyAnomaly, {maxFrames: 100, vis: visANOM, timeStep: 300});
// Time Series
var plotNDVI = ui.Chart.image.seriesByRegion(monthlyNDVI, boundary, ee.Reducer.mean(),
'NDVI',500,'system:time_start', 'system:index')
              .setChartType('LineChart').setOptions({
                title: 'NDVI Time Series by Month',
                hAxis: {title: 'Date'},
                vAxis: {title: 'NDVI'}
});
print("NDVI Plot", plotNDVI);
var plotANOM = ui.Chart.image.seriesByRegion(monthlyAnomaly, boundary, ee.Reducer.mean(),
'NDVI',500,'system:time_start', 'system:index')
              .setChartType('LineChart').setOptions({
                title: 'Monthly NDVI Anomaly',
                hAxis: {title: 'Date'},
                vAxis: {title: 'Anomaly'}
});
print("Anomaly Plot", plotANOM);
//Individual conservancies
var Kalama = conservancies.filterMetadata("NAME","equals","Kalama");
Map.addLayer(Kalama, {color:"blue"}, "Kalama");
var Sera = conservancies.filterMetadata("NAME","equals","Sera");
Map.addLayer(Sera, {color:"blue"}, "Sera");
var Westgate = conservancies.filterMetadata("NAME","equals","West Gate");
Map.addLayer(Westgate, {color:"blue"}, "Westgate");
var Meibae = conservancies.filterMetadata("NAME","equals","Meibae");
Map.addLayer(Meibae, {color:"blue"}, "Meibae");
var Namunyak = conservancies.filterMetadata("NAME",'equals','Namunyak');
Map.addLayer(Namunyak,{color:"blue"},"Namunyak")
  //User Interface 
//Allows user to look at NDVI time series for specific point
// Create a panel to hold our widgets.
var panel = ui.Panel();
panel.style().set('width', '300px');
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: 'Two Chart Inspector',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
  ui.Label('Click a point on the map to inspect.')
]);
panel.add(intro);
// panels to hold lon/lat values
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// Register a callback on the default map to be invoked when the map is clicked
Map.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2)),
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  // Create an NDVI chart.
  var ndviChart = ui.Chart.image.series(NDVI, point, ee.Reducer.mean(), 250);
  ndviChart.setOptions({
    title: 'Point NDVI',
    vAxis: {title: 'NDVI', maxValue: 1, minValue: -1},
    hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
  });
  panel.widgets().set(3, ndviChart);
});
Map.style().set('cursor', 'crosshair');
// Add the panel to the ui.root.
ui.root.insert(0, panel);