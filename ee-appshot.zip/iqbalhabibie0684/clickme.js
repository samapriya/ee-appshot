var button =ui.Button('Click Me!');
button.onClick(function(){
  print('Hello World!');
});
print(button);