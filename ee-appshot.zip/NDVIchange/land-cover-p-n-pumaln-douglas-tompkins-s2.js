var images = ee.Image("users/NDVIchange/Logo_tiff"),
    visParams = {"opacity":1,"bands":["b1","b2","b3"],"gamma":1},
    box = /* color: #98ff00 */ee.Geometry.Polygon(
        [[[-70.65365064987122, -33.449107006599704],
          [-70.65365064987122, -33.44956075386307],
          [-70.65316248783051, -33.44956075386307],
          [-70.65316248783051, -33.449107006599704]]], null, false),
    aspb = ee.FeatureCollection("users/NDVIchange/1001119_PN_Pumalin/Limite_PNPDT"),
    aspb2 = ee.FeatureCollection("users/NDVIchange/1001119_PN_Pumalin/Limite_PNPDT"),
    image = ee.Image("users/NDVIchange/1001119_PN_Pumalin/Clasificacion_PNPDT_S2"),
    parametros = {"opacity":1,"bands":["mode"],"min":1,"max":10,"palette":["0014ff","a1753e","ffc31b","77ff4b","b4b4b4","5a7eb4","59b122","ffffff","f8ff93","b4b4b4"]},
    puntos = ee.FeatureCollection("users/NDVIchange/1001119_PN_Pumalin/Puntos_PNPDT"),
    aspbv = ee.FeatureCollection("users/NDVIchange/1001119_PN_Pumalin/Limite_y_buffer_clases__simplificado_PNPDT_S2"),
    tabla = ee.Image("users/NDVIchange/1001119_PN_Pumalin/Tabla_PNPDT_S2"),
    tabla2 = /* color: #d63000 */ee.Geometry.Polygon(
        [[[-71.20896526484631, -32.87987850335756],
          [-71.20896526484631, -33.052373030295136],
          [-70.95279579605915, -33.052373030295136],
          [-70.95279579605915, -32.87987850335756]]], null, false),
    Vis_paramas_tabla = {"opacity":1,"bands":["b1","b2","b3"],"max":255,"gamma":1},
    table = ee.FeatureCollection("users/NDVIchange/1001119_PN_Pumalin/Puntos_PNPDT");
Map.setOptions("satellite");
Map.centerObject(image, 9);
Map.style().set('cursor', 'crosshair');
var mode = image.reduce(ee.Reducer.mode());
Map.addLayer(mode.clip(aspb2), parametros, 'Clasififación PNPDT S2');
var empty = ee.Image().byte();
var empty2 = ee.Image().byte();
var limite2 = empty.paint({featureCollection: aspb,color: 1, width: 3});
Map.addLayer(limite2,{},"Limite PNPDT",true);
var buffer = empty2.paint({featureCollection: aspb2,color: 1, width: 3});
var limite_estilo = {color: '26458d', fillColor: '00000000', opacity: 0};
Map.addLayer(table,{},"Puntos de control",false);
Map.add(ui.Label(
    'Land cover Parque Nacional Pumalín Douglas Tompkins', {fontWeight: 'bold', fontSize: '24px'}));
// Agregar leyenda
var legend = ui.Panel({style: {position: 'top-left', padding: '8px 15px'}});
// Crea Título "Clases PNPDT S2"
var legendTitle = ui.Label({value: 'Clases PNPDT S2', style: {fontWeight: 'bold',fontSize: '20px',
    margin: '0 0 4px 0',padding: '0'}});
// Agrega el Título
legend.add(legendTitle); 
// Crea y edita 1 fila de la leyenda
var makeRow = function(color, name) {
      var colorBox = ui.Label({ style: {backgroundColor: '#' + color, padding: '8px',margin: '0 0 8px 0'}});
      var description = ui.Label({value: name, style: {margin: '0 0 4px 6px',fontSize: '18px'}});
      return ui.Panel({
      widgets: [colorBox, description], layout: ui.Panel.Layout.Flow('horizontal')});};
// Crea paleta de colores y nombres
var palette = [
  '0014ff', //'Cuerpos de agua'
  'a1753e', //'Bosque de alerce'
  'ffc31b', //'Bosque caducifolio'
  '77ff4b', //'Bosque siempreverde'
  'b4b4b4', //'Suelos sin vegetación'
  '5a7eb4', //'Mallín'
  '59b122', //'Nalcas'
  'ffffff', //'Nieve'
  'f8ff93', //'Pradera' 
  ];
var names = [
  'Cuerpos de agua',
  'Bosque de alerce',
  'Bosque caducifolio',
  'Bosque siempreverde',
  'Suelos sin vegetación', 
  'Mallín',
  'Nalcas',
  'Nieve',
  'Pradera'
];
for (var i = 0; i < 9; i++) {legend.add(makeRow(palette[i], names[i]));}  // Agrega colores y nombres 
Map.add(legend); // Agrega la leyenda al mapa
///////////////////////////////////////////////////////////////////////////////////////////////////
Map.add(ui.Label(
    'Reconocimiento-No comercial CC BY-NC', 
    {fontWeight: 'bold', fontSize: '10px',position: 'bottom-center'}));
///////LOGO///////////////
// Titulos
var introPanel = ui.Panel([
  ui.Label({
    value: 'Corporacion Nacional Forestal (CONAF)',
    style: {fontWeight: 'bold', fontSize: '12px', margin: '5px 5px'}
  }),
   ui.Label({
     value: 'Gerencia de Áreas Silvestres Protegidas (GASP) - 2019', 
     style: {fontSize: '10px', margin: '5px 5px'}
   })
]);
// Helper function to combine two JavaScript dictionaries.
function combine(a, b) {
  var c = {};
  for (var key in a) c[key] = a[key];
  for (var key in b) c[key] = b[key];
  return c;
}
//Opciones para modificar el tamaño de la imagen
var thumbnail = ui.Thumbnail({
  params: combine(visParams, {
    dimensions: '500x500',
    region: box,
  }),
  style: {height: '100px', width: '100px'} // tamaño logo
});
var imagePanel = ui.Panel([thumbnail]);
var mainPanel = ui.Panel({
  widgets: [introPanel, imagePanel], //se agrega el titulo y la imagen
  style: {position: 'bottom-left', width: '150px'} // Posicion y tanaño del panel.
});
Map.add(mainPanel);
var setImageByIndex = function(index) {
  var image = ee.Image(images);
  thumbnail.setImage(image);
};
setImageByIndex(0);
///////LOGO///////////////
// Titulos
var introPanel = ui.Panel([
  ui.Label({
    value: 'Corporacion Nacional Forestal (CONAF)',
    style: {fontWeight: 'bold', fontSize: '12px', margin: '5px 5px'}
  }),
   ui.Label({
     value: 'Gerencia de Áreas Silvestres Protegidas (GASP) - 2019', 
     style: {fontSize: '10px', margin: '5px 5px'}
   })
]);
// Helper function to combine two JavaScript dictionaries.
function combine(a, b) {
  var c = {};
  for (var key in a) c[key] = a[key];
  for (var key in b) c[key] = b[key];
  return c;
}
//Opciones para modificar el tamaño de la imagen
var thumbnail2 = ui.Thumbnail({
  params: combine(Vis_paramas_tabla, {
    dimensions: '900x650',
    region: tabla2,
  }),
  style: {height: '300px', width: '450px'} // tamaño logo
});
var imagePanel2 = ui.Panel([thumbnail2]);
var mainPanel2 = ui.Panel({
  widgets: [imagePanel2], //se agrega el titulo y la imagen
  style: {position: 'bottom-right', width: '480px'} // Posicion y tanaño del panel.
});
Map.add(mainPanel2);
var setImageByIndex = function(index) {
  var image = ee.Image(tabla);
  thumbnail2.setImage(tabla);
};
setImageByIndex(0);