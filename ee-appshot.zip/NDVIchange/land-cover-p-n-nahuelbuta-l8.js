var images = ee.Image("users/NDVIchange/Logo_tiff"),
    visParams = {"opacity":1,"bands":["b1","b2","b3"],"gamma":1},
    box = /* color: #98ff00 */ee.Geometry.Polygon(
        [[[-70.65365064987122, -33.449107006599704],
          [-70.65365064987122, -33.44956075386307],
          [-70.65316248783051, -33.44956075386307],
          [-70.65316248783051, -33.449107006599704]]], null, false),
    aspb2 = ee.FeatureCollection("users/NDVIchange/1000905_PN_Nahuelbuta/Buffer_PNN"),
    image = ee.Image("users/NDVIchange/1000905_PN_Nahuelbuta/Clasificacion_PNN_L8"),
    aspbv = ee.FeatureCollection("users/NDVIchange/1000905_PN_Nahuelbuta/Limite_y_buffer_clases_PNN_L8"),
    aspb = ee.FeatureCollection("users/NDVIchange/1000905_PN_Nahuelbuta/Limite_PNN"),
    parametros = {"opacity":1,"bands":["b1"],"min":1,"max":10,"palette":["a16de7","199b11","8face2","89e238","ccf8ff","bc0606","665034","fffb8b","f3ffe6","0417ff"]},
    table = ee.FeatureCollection("users/NDVIchange/1000905_PN_Nahuelbuta/Puntos_PNN");
Map.setOptions("satellite");
Map.centerObject(image, 12);
Map.style().set('cursor', 'crosshair');
var mode = image;
Map.addLayer(mode.clip(aspb2),parametros, 'Clasififación PNN L8');
var empty = ee.Image().byte();
var empty2 = ee.Image().byte();
var limite2 = empty.paint({featureCollection: aspb,color: 1, width: 3});
Map.addLayer(limite2,{},"Limite PNN");
var buffer = empty2.paint({featureCollection: aspb2,color: 1, width: 3});
var limite_estilo = {color: '26458d', fillColor: '00000000', opacity: 0};
Map.addLayer(aspbv,limite_estilo,"limite",false);
Map.addLayer(table,{},"Puntos de control",false);
Map.add(ui.Label(
    'Land cover Parque Nacional Nahuelbuta', {fontWeight: 'bold', fontSize: '24px'}));
// Agregar leyenda
var legend = ui.Panel({style: {position: 'top-left', padding: '8px 15px'}});
// Crea Título "Clases PNN L8"
var legendTitle = ui.Label({value: 'Clases PNN L8', style: {fontWeight: 'bold',fontSize: '18px',
    margin: '0 0 4px 0',padding: '0'}});
// Agrega el Título
legend.add(legendTitle); 
// Crea y edita 1 fila de la leyenda
var makeRow = function(color, name) {
      var colorBox = ui.Label({ style: {backgroundColor: '#' + color, padding: '8px',margin: '0 0 4px 0'}});
      var description = ui.Label({value: name, style: {margin: '0 0 1px 4px',fontSize: '16px'}});
      return ui.Panel({
      widgets: [colorBox, description], layout: ui.Panel.Layout.Flow('horizontal')});};
// Crea paleta de colores y nombres
var palette = [
  'a16de7', //'Bosque de araucaria'
  '199b11', //'Bosque de coihue'
  '8face2', //'Bosque de araucaria - coihue'
  '89e238', //'Renovales de RO-RA-CO'
  'ccf8ff', //'Renovales de ñirre'
  'bc0606', //'Plantación de pino'
  '665034', //'Plantación de eucalipto'
  'fffb8b', //'Praderas'
  'f3ffe6', //'Mallines'
  '0417ff' // 'Cuerpos de agua'
  ];
var names = [
  'Bosque de araucaria',
  'Bosque de coihue',
  'Bosque de araucaria - coihue',
  'Renovales de RO-RA-CO',
  'Renovales de ñirre', 
  'Plantación de pino',
  'Plantación de eucalipto',
  'Praderas',
  'Mallines',
  'Cuerpos de agua'
];
for (var i = 0; i < 10; i++) {legend.add(makeRow(palette[i], names[i]));}  // Agrega colores y nombres 
Map.add(legend); // Agrega la leyenda al mapa
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////Agregar graficos de superficies
var HIGHLIGHT_STYLE = {color: 'ff7a7a'};
var selectedPoints = [];
// Devuelve una lista de los usos que el usuario selecciona.
function getSelectedCountries() {
  return aspbv.filterBounds(ee.Geometry.MultiPoint(selectedPoints));
}
// Crea un grafico de barras de las superficies.
function makeResultsBarChart(aspbv) {
  var chart = ui.Chart.feature.byFeature(aspbv, 'Codigo');
  chart.setChartType('BarChart');
  chart.setOptions({
    title: 'Comparación de superficies(ha)',
    vAxis: {title: 'Superficie(ha)'},
    hAxis: {title: 'Superficie(ha) aproximada Land cover PNN 2019', minValue: 0}
  });
  chart.style().set({stretch: 'both'});
  return chart;
}
// Makes a table of the given FeatureCollection of countries by name.
function makeResultsTable(aspbv) {
  var table = ui.Chart.feature.byFeature(aspbv, 'Codigo');
  table.setChartType('Table');
  table.setOptions({allowHtml: true, pageSize: 5});
  table.style().set({stretch: 'both'});
  return table;
}
// Updates the map overlay using the currently-selected countries.
function updateOverlay() {
  var overlay = getSelectedCountries().style(HIGHLIGHT_STYLE);
  Map.layers().set(3, ui.Map.Layer(overlay));
}
// Updates the chart using the currently-selected charting function,
function updateChart() {
  var chartBuilder = chartTypeToggleButton.value;
  var chart = chartBuilder(getSelectedCountries());
  resultsPanel.clear().add(chart).add(Botones1);
}
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  selectedPoints = [];
  Map.layers().remove(Map.layers().get(2));
  var instructionsLabel = ui.Label('Seleccione un uso al interior del parque o en el área buffer para comparar superficies.');
  resultsPanel.widgets().reset([instructionsLabel]);
}
// Register a click handler for the map that adds the clicked point to the
// list and updates the map overlay and chart accordingly.
function handleMapClick(location) {
  selectedPoints.push([location.lon, location.lat]);
  updateOverlay();
  updateChart();
}
Map.onClick(handleMapClick);
// A button widget that toggles (or cycles) between states.
// To construct a ToggleButton, supply an array of objects describing
// the desired states, each with 'label' and 'value' properties.
function ToggleButton(states, onClick) {
  var index = 0;
  var button = ui.Button(states[index].label);
  button.value = states[index].value;
  button.onClick(function() {
    index = ++index % states.length;
    button.setLabel(states[index].label);
    button.value = states[index].value;
    onClick();
  });
  return button;
}
// Boton para cambiar de tabla a grafico viceversa
var chartTypeToggleButton = ToggleButton(
    [
      {
        label: 'Mostrar resultados en tabla',
        value: makeResultsBarChart,
      },
      {
        label: 'Mostrar resultados en gráficos',
        value: makeResultsTable,
      }
    ],
    updateChart);
// A panel containing the two buttons .
var Botones1 = ui.Panel(
    [ui.Button('Resetear', clearResults), chartTypeToggleButton],
    ui.Panel.Layout.Flow('horizontal'), {margin: '0 0 0 auto', width: '500px'});
var resultsPanel = ui.Panel({style: {position: 'bottom-right', height: '300px'}});
Map.add(resultsPanel);
clearResults();
// Map.add(ui.Label(
//     'Corporación Nacional Forestal (CONAF) - Gerencia de Áreas Silvestres Protegidas (GASP) - 2019', 
//     {fontWeight: 'bold', fontSize: '10px',position: 'bottom-left'}));
Map.add(ui.Label(
    'Reconocimiento-No comercial CC BY-NC', 
    {fontWeight: 'bold', fontSize: '10px',position: 'bottom-center'}));
///////LOGO///////////////
// Titulos
var introPanel = ui.Panel([
  ui.Label({
    value: 'Corporacion Nacional Forestal (CONAF)',
    style: {fontWeight: 'bold', fontSize: '12px', margin: '5px 5px'}
  }),
   ui.Label({
     value: 'Gerencia de Áreas Silvestres Protegidas (GASP) - 2019', 
     style: {fontSize: '10px', margin: '5px 5px'}
   })
]);
// Helper function to combine two JavaScript dictionaries.
function combine(a, b) {
  var c = {};
  for (var key in a) c[key] = a[key];
  for (var key in b) c[key] = b[key];
  return c;
}
//Opciones para modificar el tamaño de la imagen
var thumbnail = ui.Thumbnail({
  params: combine(visParams, {
    dimensions: '500x500',
    region: box,
  }),
  style: {height: '100px', width: '100px'} // tamaño logo
});
var imagePanel = ui.Panel([thumbnail]);
var mainPanel = ui.Panel({
  widgets: [introPanel, imagePanel], //se agrega el titulo y la imagen
  style: {position: 'bottom-left', width: '150px'} // Posicion y tanaño del panel.
});
Map.add(mainPanel);
// Agrega el logo.
var setImageByIndex = function(index) {
  var image = ee.Image(images);
  thumbnail.setImage(image);
};
setImageByIndex(0);