var grip4_africa = ui.import && ui.import("grip4_africa", "table", {
      "id": "projects/sat-io/open-datasets/GRIP4/Africa"
    }) || ee.FeatureCollection("projects/sat-io/open-datasets/GRIP4/Africa"),
    grip4_central_south_america = ui.import && ui.import("grip4_central_south_america", "table", {
      "id": "projects/sat-io/open-datasets/GRIP4/Central-South-America"
    }) || ee.FeatureCollection("projects/sat-io/open-datasets/GRIP4/Central-South-America"),
    grip4_europe = ui.import && ui.import("grip4_europe", "table", {
      "id": "projects/sat-io/open-datasets/GRIP4/Europe"
    }) || ee.FeatureCollection("projects/sat-io/open-datasets/GRIP4/Europe"),
    grip4_north_america = ui.import && ui.import("grip4_north_america", "table", {
      "id": "projects/sat-io/open-datasets/GRIP4/North-America"
    }) || ee.FeatureCollection("projects/sat-io/open-datasets/GRIP4/North-America"),
    grip4_oceania = ui.import && ui.import("grip4_oceania", "table", {
      "id": "projects/sat-io/open-datasets/GRIP4/Oceania"
    }) || ee.FeatureCollection("projects/sat-io/open-datasets/GRIP4/Oceania"),
    grip4_south_east_asia = ui.import && ui.import("grip4_south_east_asia", "table", {
      "id": "projects/sat-io/open-datasets/GRIP4/South-East-Asia"
    }) || ee.FeatureCollection("projects/sat-io/open-datasets/GRIP4/South-East-Asia"),
    grip4_middle_east_central_asia = ui.import && ui.import("grip4_middle_east_central_asia", "table", {
      "id": "projects/sat-io/open-datasets/GRIP4/Middle-East-Central-Asia"
    }) || ee.FeatureCollection("projects/sat-io/open-datasets/GRIP4/Middle-East-Central-Asia");
//print('Grip4 South East Asia size',grip4_south_east_asia.size())
//print('Grip4 Middle East Central Asia size',grip4_middle_east_central_asia.size())
var dataset = ee.ImageCollection('NOAA/VIIRS/001/VNP46A1').filter(
  ee.Filter.date('2023-02-01', '2023-03-01'));
// At-sensor Day/night Band radiance (DNB).
var dnb = dataset.select('DNB_At_Sensor_Radiance_500m');
var dnbVis = {
  min: 0,
  max: 50,
  palette: ['black', 'purple', 'cyan', 'green', 'yellow', 'red', 'white'],
  opacity: 0.8  // Set transparency to 70%
};
Map.addLayer(dnb, dnbVis, 'Day-Night Band (DNB) at sensor radiance 500m');
Map.addLayer(ee.FeatureCollection(grip4_south_east_asia).style({color: '#FFFFFF',width:1}),{},'Grip4 South East Asia')
Map.addLayer(ee.FeatureCollection(grip4_middle_east_central_asia).style({color: '#FFFFFF',width:1}),{},'Grip4 Middle East and Central Asia')
Map.setOptions('TERRAIN')
// Define road colors and widths based on GP_RTP attribute
function getRoadStyle(feature) {
  var roadType = ee.Number(feature.get('GP_RTP'));
  var color = ee.Dictionary({
    '1': 'red',       // Highways
    '2': 'orange',    // Primary Roads
    '3': 'yellow',    // Secondary Roads
    '4': 'green',     // Tertiary Roads
    '5': 'blue',      // Local Roads
    '0': 'gray'       // Unspecified
  }).get(roadType.format());
  var width = ee.Dictionary({
    '1': 2.5,
    '2': 2.0,
    '3': 1.5,
    '4': 1.5,
    '5': 1.0,
    '0': 1.0
  }).get(roadType.format());
  return feature.set({style: {color: color, width: width}});
}
// Apply styles to road datasets
var styledSEAroads = grip4_south_east_asia.map(getRoadStyle);
var styledMECAroads = grip4_middle_east_central_asia.map(getRoadStyle);
// Function to create a legend
function createLegend() {
  var legendPanel = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical'),
    style: { margin: '10px 0' }
  });
  legendPanel.add(ui.Label({
    value: 'Road Type Legend',
    style: { fontSize: '14px', fontWeight: 'bold' }
  }));
  var roadStyles = [
    {color: 'red', label: 'Highways'},
    {color: 'orange', label: 'Primary Roads'},
    {color: 'yellow', label: 'Secondary Roads'},
    {color: 'green', label: 'Tertiary Roads'},
    {color: 'blue', label: 'Local Roads'},
    {color: 'gray', label: 'Unspecified'}
  ];
  roadStyles.forEach(function(style) {
    var colorBox = ui.Label({
      style: {
        backgroundColor: style.color,
        padding: '5px',
        margin: '0 10px 0 0',
        width: '20px'
      }
    });
    var label = ui.Label({
      value: style.label,
      style: { fontSize: '12px' }
    });
    var row = ui.Panel({
      widgets: [colorBox, label],
      layout: ui.Panel.Layout.flow('horizontal')
    });
    legendPanel.add(row);
  });
  return legendPanel;
}
// Create the UI panel
var panel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: { width: '300px', padding: '10px' }
});
// Add a title
panel.add(ui.Label({
  value: 'Night Roads Monitor',
  style: { fontSize: '20px', fontWeight: 'bold' }
}));
// Add description about DNB data
panel.add(ui.Label({
  value: 'This visualization uses NOAA VIIRS Day/Night Band (DNB) data to display nighttime lights.\n\n' +
         'DNB measures radiance at 500m resolution, capturing sources like city lights, gas flares, and moonlight reflection.\n\n' +
         'Higher values (yellow to white) indicate brighter lights, while lower values (black to purple) represent darker regions.',
  style: { fontSize: '12px', margin: '10px 0' }
}));
// Add DNB legend
var legendTitle = ui.Label({
  value: 'Nighttime Light Radiance (nW/cm²/sr)',
  style: { fontSize: '14px', fontWeight: 'bold', margin: '10px 0' }
});
var legendColors = ['black', 'purple', 'cyan', 'green', 'yellow', 'red', 'white'];
var legendLabels = ['0', '5', '10', '20', '30', '40', '50+'];
var legendPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: { margin: '10px 0' }
});
for (var i = 0; i < legendColors.length; i++) {
  var colorBox = ui.Label({
    style: {
      backgroundColor: legendColors[i],
      padding: '5px',
      margin: '0 10px 0 0'
    }
  });
  var label = ui.Label({
    value: legendLabels[i],
    style: { fontSize: '12px' }
  });
  var row = ui.Panel({
    widgets: [colorBox, label],
    layout: ui.Panel.Layout.flow('horizontal')
  });
  legendPanel.add(row);
}
// Add DNB legend and road legend to the panel
panel.add(legendTitle);
panel.add(legendPanel);
panel.add(createLegend());
// Create the map
var map = ui.Map();
map.addLayer(dnb, dnbVis, 'Day-Night Band (DNB) Radiance');
map.addLayer(styledSEAroads.style({styleProperty: 'style'}), {}, 'Grip4 South East Asia Roads');
map.setOptions('TERRAIN');
// Set center at Roorkee, India
map.setCenter(77.8939, 29.8643, 8);
// Add map to the UI
var app = ui.root;
app.clear();
app.add(panel);
app.add(map);