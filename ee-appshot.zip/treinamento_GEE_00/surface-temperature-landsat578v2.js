var brasil = ui.import && ui.import("brasil", "table", {
      "id": "users/christhianscunha/brasil_limites"
    }) || ee.FeatureCollection("users/christhianscunha/brasil_limites"),
    CALDEIRAV = ui.import && ui.import("CALDEIRAV", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -25.496777718330776,
            37.78009777145608
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "name": "CALDEIRAV"
      },
      "color": "#ccff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ccff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-25.496777718330776, 37.78009777145608]),
            {
              "name": "CALDEIRAV",
              "system:index": "0"
            })]),
    GFOG3 = ui.import && ui.import("GFOG3", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -25.50569,
            37.80101
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "name": "GFOG3",
        "system:index": "0"
      },
      "color": "#99ff99",
      "mode": "Feature",
      "shown": false,
      "locked": false
    }) || 
    /* color: #99ff99 */
    /* shown: false */
    ee.Feature(
        ee.Geometry.Point([-25.50569, 37.80101]),
        {
          "name": "GFOG3",
          "system:index": "0"
        }),
    GFOG4 = ui.import && ui.import("GFOG4", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -25.490166527786243,
            37.79661562745368
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "name": "GFOG4",
        "system:index": "0"
      },
      "color": "#9999ff",
      "mode": "Feature",
      "shown": false,
      "locked": false
    }) || 
    /* color: #9999ff */
    /* shown: false */
    ee.Feature(
        ee.Geometry.Point([-25.490166527786243, 37.79661562745368]),
        {
          "name": "GFOG4",
          "system:index": "0"
        }),
    GFUR2 = ui.import && ui.import("GFUR2", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -25.33019,
            37.76965
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "name": "GFUR2",
        "system:index": "0"
      },
      "color": "#ffff99",
      "mode": "Feature",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffff99 */
    /* shown: false */
    ee.Feature(
        ee.Geometry.Point([-25.33019, 37.76965]),
        {
          "name": "GFUR2",
          "system:index": "0"
        }),
    GFUR3 = ui.import && ui.import("GFUR3", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -25.30427,
            37.77331
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "name": "GFUR3",
        "system:index": "0"
      },
      "color": "#99ffff",
      "mode": "Feature",
      "shown": false,
      "locked": false
    }) || 
    /* color: #99ffff */
    /* shown: false */
    ee.Feature(
        ee.Geometry.Point([-25.30427, 37.77331]),
        {
          "name": "GFUR3",
          "system:index": "0"
        }),
    area_estudo = ui.import && ui.import("area_estudo", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -25.93870973097657,
                37.96478083633828
              ],
              [
                -25.93870973097657,
                37.64360661701754
              ],
              [
                -24.99388551222657,
                37.64360661701754
              ],
              [
                -24.99388551222657,
                37.96478083633828
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ff038e",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff038e */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Polygon(
                [[[-25.93870973097657, 37.96478083633828],
                  [-25.93870973097657, 37.64360661701754],
                  [-24.99388551222657, 37.64360661701754],
                  [-24.99388551222657, 37.96478083633828]]], null, false),
            {
              "system:index": "0"
            })]);
/*************************************************Curso de Gooogle Earth Engine*****************************************
    Autor: Christhian Santana Cunha
    Bacharel em Gestão Ambiental - UNIPAMPA (2012)
    Mestre em Engenharia Civil, Recursos Hídricos - UFSM (2014)
    Doutorando Sensoriamento Remoto -UFGRS
   Aplicativo série histórica de temperatura de superfície 
    O objetivo deste app permite que o usuário consiga:
    1) Delimitar uma área de interesse por meio de uma geometria/ponto
    2) Importar uma coleção de imagens, aplicar filtros, remover núvens e extrair uma imagem de uma ano qualquer
    3) Construir funções 
    4) Construir gráficos 
    5) Exportar imagens 
    6) Criar Legenda
    7 Construir um APP
 * *********************************************************************************************************************/
/********************************************DEFINIÇÃO DAS VARIÁVEIS***************************************************/
/*********DEFINIÇÃO DO INTERVALO DE TEMPO PARA ANALISE - ANO X E ANO X+1**********************************************/
var startyear = 1985;
var endyear = 2020;
/******************************* CRIAR LISTA DE MESES E ANOS PARA UTILIZAR NAS FUNÇÕES********************************/ 
var months = ee.List.sequence(1,12);
var startdate = ee.Date.fromYMD(startyear,1,1);
var enddate = ee.Date.fromYMD(endyear,12,1);
var years = ee.List.sequence(startyear,endyear);
/************************************DEFINIÇÃO DA ÁREA DE ESTUDO****************************************************/ 
var area_de_estudo = ee.FeatureCollection('users/christhianscunha/brasil_limites');
var area_estudo = area_estudo
var estacoes = [
  ee.Feature(
      ee.Geometry.Point([-25.50569, 37.80101]),
      {'name': 'GFOG3'}),
  ee.Feature(
      ee.Geometry.Point([-25.490166527786243, 37.79661562745368]), {'name': 'GFOG4'}),
  ee.Feature(
      ee.Geometry.Point([-25.33019, 37.76965]),
      {'name': 'GFUR2'}),
  ee.Feature(
      ee.Geometry.Point([-25.30427, 37.77331]), {'name': 'GFUR3'})
];
var amostras = CALDEIRAV.merge(GFUR3).merge(GFOG3).merge(GFOG4)
var Tectonica = ee.FeatureCollection("users/jessicaguchoa/Tectonica_FOGO");
Tectonica = Tectonica.geometry();
Map.centerObject(Tectonica);
var Desgaseificacao = ee.FeatureCollection("users/jessicaguchoa/Desgaseificacao_FOGO");
Desgaseificacao = Desgaseificacao.geometry();
Map.centerObject(Desgaseificacao);
var Fumarolas = ee.FeatureCollection("users/jessicaguchoa/Fumarolas");
Fumarolas=Fumarolas.geometry();
var Fenda = ee.FeatureCollection("users/jessicaguchoa/CPX")
Fenda=Fenda.geometry();
/****************************************PROCESSAMENTO IMAGENS LANDSAT******************************************************/
var cloudmasklandsat7and5and8= function(image){
    var Qlandsat5and7= image.select('pixel_qa');
    var cloudShadowBitMask = (1 << 3);
    var cloudsBitMask = (1 << 5);
    var mask5and7=Qlandsat5and7.clip(area_estudo).bitwiseAnd(cloudShadowBitMask).eq(0)
                                   .and(Qlandsat5and7.bitwiseAnd(cloudsBitMask).eq(0));
    return image.updateMask(mask5and7);
};
// coleção imagens (1984,2013) mascarando a nuvem (landsat7and5)
var landsat5= ee.ImageCollection('LANDSAT/LT05/C01/T1_SR')
                  .filterDate('1984-01-01', '2013-12-31')
                  .filterBounds(area_estudo)
                  .filterMetadata('CLOUD_COVER','less_than', 20)
                  .map(cloudmasklandsat7and5and8);
var landsat7= ee.ImageCollection('LANDSAT/LE07/C01/T1_SR')
                  .filterDate('2000-01-01', '2013-12-31')
                  .filterBounds(area_estudo)
                  .filterMetadata('CLOUD_COVER','less_than', 20)
                  .map(cloudmasklandsat7and5and8);
//merge landsat5 and landsat7 
var landsat7and5=landsat7.merge(landsat5);
// Coleção Landst 8 (2013,2019) mascarando a nuvem (landsat8)
var hoje= ee.Date(Date.now()) //manterá o app sempre atualizado para a data de hoje. 
var landsat8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
                  .filterDate('2013-05-11', hoje)
                  .filterBounds(area_estudo)
                  .filterMetadata('CLOUD_COVER','less_than', 20)
                  .map(cloudmasklandsat7and5and8);
/*******************Função de Correção de Temperatura de Brilho para Superfície************/
// cálculo NDVI para cada imagem separadamente
// função minmax
var setNdviMinMax=function (img) {
  var minMax = img
    .select('NDVI')
    .reduceRegion({
      reducer: ee.Reducer.minMax(),
      scale: 30,
      maxPixels: 1e13
    });
  return img.set({
    'NDVI_min': minMax.get('NDVI_min'),
    'NDVI_max': minMax.get('NDVI_max'),
  }).toFloat();
};
// calcula NDVI para cada imagem coletada de landsat8
// Function landsat8 NDVI
var NDVI8=function(image){
  var ndvi = image.addBands(image.normalizedDifference(['B5', 'B4']).rename('NDVI'));
  return setNdviMinMax(ndvi).clip(area_estudo).toFloat();
};
// Function landsat7and5 NDVI
var NDVI7and5=function(image){
  var ndvi = image.addBands(image.normalizedDifference(['B4', 'B3']).rename('NDVI'));
  return setNdviMinMax(ndvi).clip(area_estudo).toFloat();
};
// Mapeando as funções NDVI em todas as imagens coletadas separadamente
var landsat8Ndvi = landsat8.map(NDVI8)
  .filter(ee.Filter.notNull(['NDVI_min', 'NDVI_max']));
var landsat5Ndvi = landsat5.map(NDVI7and5)
  .filter(ee.Filter.notNull(['NDVI_min', 'NDVI_max']));
var landsat7Ndvi = landsat7.map(NDVI7and5)
  .filter(ee.Filter.notNull(['NDVI_min', 'NDVI_max']));
var landsat7and5Ndvi = landsat7and5.map(NDVI7and5)
  .filter(ee.Filter.notNull(['NDVI_min', 'NDVI_max']));
// calculando a emissividade
// 1: estimativa mín. E máx. De cada imagem na camada NDVI: adicionando a banda mín. Máx.
  var addMinMaxBands=function (img) {
  var minMaxBands = ee.Image.constant([
    img.get('NDVI_min'),
    img.get('NDVI_max')])
    .rename(['NDVImin', 'NDVImax']);
  return img.clip(area_estudo).addBands(minMaxBands).toFloat();
  };
// 2: mapeia a função min max na coleção
var landsat8Ndviminmax = landsat8Ndvi.map(addMinMaxBands);
var landsat7and5Ndviminmax= landsat7and5Ndvi.map(addMinMaxBands);
// 3; vegetação fracionada para cada imagem
  var addFVband=function (img) {
  var ndvi = img.select('NDVI');
  var ndviMin = img.select('NDVImin');
  var ndviMax = img.select('NDVImax');
  var fvBand = ndvi
    .subtract(ndviMin)
    .divide(ndviMax.subtract(ndviMin))
    .rename('FV');
  return img.addBands(fvBand).toFloat();
  };
// COLEÇÃO 4: fv PARA CADA LANDSAT
var landsat8fv= landsat8Ndviminmax.map(addFVband);
var landsat7and5fv= landsat7and5Ndviminmax.map(addFVband);
//5: Emissividade
var addEMband=function (img){
  var FVb = img.select('FV');
  var a= ee.Number(0.004);
  var b= ee.Number(0.986);
  var EMBand = FVb
    .multiply(a).add(b).rename('EM');
  return img.addBands(EMBand).toFloat();
};
// 5: COLEÇÃO EM PARA CADA LANDSAT
var landsat8EM= landsat8fv.select('FV').map(addEMband);
var landsat7AND5EM= landsat7and5fv.select('FV').map(addEMband);
//6: Thermal landsat 8
var LST8=function(image){
  var Thermal10 = image.addBands(image.select('B10').multiply(0.1).rename('Thermal8'));
  return Thermal10};
var landsat8thermal= landsat8.select('B10').map(LST8)
// Thermal landsat 7and5
var LST7and5=function(image){
  var Thermal5and7= image.addBands(image.select('B6').multiply(0.1).rename('Thermal5and7'));
  return Thermal5and7};
var landsat7and5thermal= landsat7and5.select('B6').map(LST7and5);
// 7: LST ainda está trabalhando nesta parte
////////A: Landsat8
// Use um filtro igual para definir como as coleções correspondem.
var filter = ee.Filter.equals({
  leftField: 'system:index',
  rightField: 'system:index'
});
// Crie a junção.
var simpleJoin = ee.Join.simple();
// Aplicar adesão
var thermalband8 = ee.ImageCollection(simpleJoin.apply(landsat8thermal, landsat8EM, filter));
var thermalband82 = ee.ImageCollection(simpleJoin.apply(landsat8EM, landsat8thermal, filter));
  var final_col8 = thermalband8.select('Thermal8').map(function(img){
// Cria uma coleção com 1 imagem
  var temp = ee.ImageCollection(ee.List([img]));
// Aplicar junção à coleção 2
// A coleção resultante terá 1 imagem com exatamente a mesma data que img
  var join = simpleJoin.apply(thermalband82.select('EM'), temp, filter);
// Obter imagem resultante
  var i2 = ee.Image(join.first());
  return img.addBands(i2);
});
//FUnção de Correção de Imagens Landsat8 
var LSt8function = function(image){
  var LST8EQ=image.expression(
    '(Tb/(1 + (0.001145* (Tb / 1.438))*log(Ep)))-273.15', {
      'Tb': image.select('Thermal8'),
      'Ep': image.select('EM')}).rename('LST');
 return  image.addBands(LST8EQ)};
var LST8= final_col8.map(LSt8function);
////////A: Landsat 7 e  5
// Use um filtro igual para definir como as coleções correspondem.
var filter = ee.Filter.equals({
  leftField: 'system:index',
  rightField: 'system:index'
});
// Crie a junção.
var simpleJoin = ee.Join.simple();
// Aplicar adesão
var thermalband5and7 = ee.ImageCollection(simpleJoin.apply(landsat7and5thermal, landsat7AND5EM, filter));
var thermalband5and7_2 = ee.ImageCollection(simpleJoin.apply(landsat7AND5EM, landsat7and5thermal, filter));
  var final_col5and7 = thermalband5and7.map(function(img){
  // Cria uma coleção com 1 imagem
  var temp = ee.ImageCollection(ee.List([img]));
  // Aplicar junção à coleção 2
  // A coleção resultante terá 1 imagem com exatamente a mesma data que img
  var join = simpleJoin.apply(thermalband5and7_2, temp, filter);
  // Obter imagem resultante
  var i2 = ee.Image(join.first());
  return img.addBands(i2);
});
//FUnção de Correção de Imagens Landsat 5 e 7 
var LSt7and5function = function(image){
  var LST7and5EQ=image.expression(
    '(Tb/(1 + (0.001145* (Tb / 1.438))*log(Ep)))-273.15', {
      'Tb': image.select('Thermal5and7'),
      'Ep': image.select('EM')
    }).rename('LST');
 return  image.addBands(LST7and5EQ)};
var LST7and5= final_col5and7.map(LSt7and5function);
/*************************Coleção Corrigida**************************************/
var collection_corrigida = LST7and5.merge(LST8)
var temperatura_collection_max = collection_corrigida.map(function(image){
   var temp = image.select('LST').reduce(ee.Reducer.max()).rename('LST')
   return image
})
var temperatur_max = collection_corrigida.select('LST').reduce(ee.Reducer.max()).rename('LST maxima')
var temperatur_mean = collection_corrigida.select('LST').reduce(ee.Reducer.mean()).rename('LST media')
var temperatur_min = collection_corrigida.select('LST').reduce(ee.Reducer.min()).rename('LST minima')
//Merge the dataseries
var composites = ee.ImageCollection(landsat5.merge(landsat7).merge(landsat8));
var count = composites.size();
print('Número de Imagens:' , count);
//Aplique um redutor a cada elemento de uma coleção, usando os seletores fornecidos para determinar as entradas.
//Retorna um dicionário de resultados, codificado com os nomes de saída.
var range = composites.reduceColumns(ee.Reducer.minMax(), ["system:time_start"]) 
print('Intervalo de datas: ', ee.Date(range.get('min')), ee.Date(range.get('max')))
/****************************************Suavização do Gráfico*************************************************/
var LST_anual =  ee.ImageCollection.fromImages(  //RETORNA A IMAGEM PARA COLEÇÃO 
  years.map(function (ano) { // APLICAR A FUNÇÃO MAP (LOOP) PARA  A VARIÁVEL YEARS
   var LST_anual = collection_corrigida.select('LST').filter(ee.Filter.calendarRange(ano, ano, 'year'))  //filtro por ano,
           .max() // MÉDIA NDVI TODOS OS VALORES DA COLEÇÃO NO MÊS 
           .clip(area_estudo)
    return LST_anual
          .set('year', ano) // INTERVALO ANO = Y
           .set('date', ee.Date.fromYMD(ano,1,1)) // DATE É A DATA QUE VEM DE Y ANO, M MÊS E 1 DIA 1.
           .set('system:time_start',ee.Date.fromYMD(ano,1,1)); // INTERVALO SYSTEM TIME_START DAS COLEÇÕES
                     }).flatten()
          ); /// EMPILHAR COLEÇÕES 
print('Temperatura máxima',LST_anual)
var LST_anual_mean =  ee.ImageCollection.fromImages(  //RETORNA A IMAGEM PARA COLEÇÃO 
  years.map(function (ano) { // APLICAR A FUNÇÃO MAP (LOOP) PARA  A VARIÁVEL YEARS
   var LST_anual_mean = collection_corrigida.select('LST').filter(ee.Filter.calendarRange(ano, ano, 'year'))  //filtro por ano,
           .mean() // MÉDIA NDVI TODOS OS VALORES DA COLEÇÃO NO MÊS 
           .clip(area_estudo)
    return LST_anual_mean
          .set('year', ano) // INTERVALO ANO = Y
           .set('date', ee.Date.fromYMD(ano,1,1)) // DATE É A DATA QUE VEM DE Y ANO, M MÊS E 1 DIA 1.
           .set('system:time_start',ee.Date.fromYMD(ano,1,1)); // INTERVALO SYSTEM TIME_START DAS COLEÇÕES
                     }).flatten()
          ); /// EMPILHAR COLEÇÕES 
print('Temperatura média',LST_anual_mean)
/******************************************PARÂMETROS DE VISUALIZAÇÃO******************************************************/
var VisLST= {min: 12.52, max: 26.791, palette: ['white','blue','green','yellow' ,'red']}
var VisLST7and5 = {min: 9.64, max: 23.92, palette: ['white','blue','green','yellow' ,'red']}
var Viscollection_corrigida= {min: 12.52, max: 25.48, palette: ['white','blue','green','yellow' ,'red']}
var VisMax= {min: 13, max: 34.6, palette: ['white','blue','green','yellow' ,'red']}
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: area_estudo,
  color: 1,
  width: 2
});
/******************************************ADICIONANDO LAYERS*****************************************************/
Map.addLayer(LST8.select('LST').median(),VisLST,'LST8');
Map.addLayer(LST7and5.select('LST').median(),VisLST7and5,'LST7and5');
Map.addLayer(collection_corrigida.select('LST').median(),Viscollection_corrigida,'Coleção Completa')
Map.addLayer(LST_anual.median(),VisMax,'LST máxima');
Map.addLayer(outline, {palette: 'FF0000'}, 'Área de interesse');
/*****************************************Features*******************************************************/
Map.addLayer(Tectonica, {color: 'black'}, 'Tectônica');
Map.addLayer(Desgaseificacao, {color: 'black'}, 'Desgaseificação');
Map.addLayer(Fumarolas,{color: 'red'}, 'Fumarolas' )
Map.addLayer(Fenda,{color: 'purple'}, 'Fenda' )
Map.centerObject(area_estudo,10); 
Map.setOptions("HYBRID" )
/******************************************************CRIANDO PAINEL PARA OS GRÁFICOS******************************************************/
var panel = ui.Panel();
panel.style().set('width', '380px');
var intro = ui.Panel([
ui.Label({
    value: 'APP Temperatura de Superfície - L578',
    style: {fontSize: '20px', fontWeight: 'bold'}}),
ui.Label('Neste painel são apresentados os gráficos das séries de Temperatura de Superfície obtidas a partir de 1985 até 2020.'+
'Foram utlizadas as coleções Landsat 5, Landsat 7 e Landsat 8 Surface Reflectance.'+ 
  'O processidimento metodologico parao o cálculo da Temperatura de Superfície pode ser consultado em:'),
ui.Label('INSERIR LINK'),
ui.Label('Para fazer o download das informações que constam nos gráficos, basta maximizar a figura e selecionar a opção Download .CSV'),
ui.Label('Autora: Jessica Garcia Uchoa.'),
//  ui.Label('Co-autor: Christhian Cunha.')
]);
panel.add(intro);
/******************************** FUNÇÃO PARA INSERIR GRÁFICO DE SÉRIES POR REGIÃO ******************************/  
/*************************Gráfico**********************************************/
var tempChart = ui.Chart.image.seriesByRegion(temperatura_collection_max ,amostras, ee.Reducer.max(),
'LST', 30, 'system:time_start', 'name').setChartType('LineChart').setOptions({
    title: 'Temperatura máxima ao longo do tempo',
    vAxis: {title: 'Temperatura'},
    hAxis: {title: 'Data', format: 'MM-yy', gridlines: {count: 7}},
    series: {
          0: { color: 'green'},//
          1: { color: 'blue'},// 
          2: { color: 'yellow'},//
          3: { color: 'red'}}// 
            });
//print(tempChart);
panel.widgets().set(2, tempChart); 
/**********************************Média anual suavizado***************************************/
var tempChart = ui.Chart.image.seriesByRegion(LST_anual, amostras, ee.Reducer.max(),
'LST', 30, 'system:time_start', 'name').setChartType('LineChart').setOptions({
    title: 'Temperatura máxima anual ao longo do tempo',
    vAxis: {title: 'Temperatura'},
    hAxis: {title: 'Data', format: 'MM-yy', gridlines: {count: 7}},
    series: {
          0: { color: 'green'},//
          1: { color: 'blue'},// 
          2: { color: 'yellow'},//
          3: { color: 'red'}}// 
            });
//print(tempChart);
panel.widgets().set(3, tempChart); 
/********************************************máximas*****************************************/
var chart_maximas = ui.Chart.image.regions({
  image: temperatur_max,
  regions: amostras,
  scale: 30,
  seriesProperty: 'name'
});
chart_maximas.setChartType('ScatterChart');
chart_maximas.setOptions({
  title: 'Temperatura Máxima área de interesse',
  hAxis: {
    title: 'Tempereatura ºC'
  },
  vAxis: {
    title: 'Máximas'
  },
  lineWidth: 1,
  pointSize: 4,
  series: {
          0: { color: 'green'},
          1: { color: 'blue'},// 
          2: { color: 'yellow'},//
          3: { color: 'red'}}// 
             });
//print(chart_maximas);
panel.widgets().set(4, chart_maximas); 
/********************************************máximas*****************************************/
var chart_media = ui.Chart.image.regions({
  image: temperatur_mean,
  regions: amostras,
  scale: 30,
  seriesProperty: 'name'
});
chart_media.setChartType('ScatterChart');
chart_media.setOptions({
  title: 'Temperatura Média área de interesse',
  hAxis: {
    title: 'Tempereatura ºC'
  },
  vAxis: {
    title: 'Média'
  },
  lineWidth: 1,
  pointSize: 4,
  series: {
          0: { color: 'green'},
          1: { color: 'blue'},// 
          2: { color: 'yellow'},//
          3: { color: 'red'}}// 
             });
//print(chart_media);
panel.widgets().set(5, chart_media); 
/********************************************mínima*****************************************/
var chart_min = ui.Chart.image.regions({
  image: temperatur_min,
  regions: amostras,
  scale: 30,
  seriesProperty: 'name'
});
chart_min.setChartType('ScatterChart');
chart_min.setOptions({
  title: 'Temperatura Mínima área de interesse',
  hAxis: {
    title: 'Tempereatura ºC'
  },
  vAxis: {
    title: 'Média'
  },
  lineWidth: 1,
  pointSize: 4,
  series: {
          0: { color: 'green'},
          1: { color: 'blue'},// 
          2: { color: 'yellow'},//
          3: { color: 'red'}}// 
             });
//print(chart_min);
panel.widgets().set(6, chart_min); 
ui.root.insert(0, panel);
/************************Legenda************************************/
// Cria uma imagem em miniatura da barra de cores para uso na legenda da cor fornecida
// paleta.
var vis = {min: 0, max: 40, palette:['white','blue','green','yellow' ,'red']}
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 40, 10],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 40,
    palette: palette,
  };
}
// Crie a barra de cores para a legenda.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(vis.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Crie um painel com três números para a legenda.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(vis.min, {margin: '4px 8px'}),
    ui.Label(
        (vis.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(vis.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Legenda Índices: valores mínimos e máximos ',
  style: {fontWeight: 'bold'}
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
panel.widgets().set(7, legendPanel);
/********************************************************Gráfico que ao clicar será gerado********************************/
// Crie um painel de introdução com rótulos.
var intro = ui.Panel([
   ui.Label({
    value: 'Click na imagem e adicione gráficos para direntes pontos.',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
]);
panel.add(intro);
// Crie painéis para manter os valores lon / lat.
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// Registre um retorno de chamada no mapa padrão a ser invocado quando o mapa for clicado.
Map.onClick(function(coords) {
  // Atualize o painel lon / lat com valores do evento de clique.
  lon.setValue('lon: ' + coords.lon.toFixed(2)),
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  // Adicione um ponto vermelho para o ponto clicado.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'FF0000'});
  Map.layers().set(1, dot);
  // Crie um gráfico NDVI.
  var tempChart_new = ui.Chart.image.seriesByRegion(collection_corrigida, point, ee.Reducer.mean(),
'LST', 30, 'system:time_start', 'name').setChartType('LineChart').setOptions({
    title: 'Temperatura média do ponto de interesse ao longo do tempo',
    vAxis: {title: 'Temperatura'},
    hAxis: {title: 'Data', format: 'MM-yy', gridlines: {count: 7}},
              });
//print(tempChart);
panel.widgets().set(9, tempChart_new);
/********************************************máximas*****************************************/
var chart_maximas = ui.Chart.image.regions({
  image: temperatur_max,
  regions: point,
  scale: 30,
  seriesProperty: 'name'
});
chart_maximas.setChartType('ScatterChart');
chart_maximas.setOptions({
  title: 'Temperatura Máxima área de interesse',
  hAxis: {
    title: 'Tempereatura ºC'
  },
  vAxis: {
    title: 'Máximas'
  },
  lineWidth: 1,
  pointSize: 4,
  series: {
          0: { color: 'green'},
          1: { color: 'blue'},// 
          2: { color: 'yellow'},//
          3: { color: 'red'}}// 
             });
//print(chart_maximas);
panel.widgets().set(10, chart_maximas); 
/********************************************máximas*****************************************/
var chart_media = ui.Chart.image.regions({
  image: temperatur_mean,
  regions: point,
  scale: 30,
  seriesProperty: 'name'
});
chart_media.setChartType('ScatterChart');
chart_media.setOptions({
  title: 'Temperatura Média área de interesse',
  hAxis: {
    title: 'Tempereatura ºC'
  },
  vAxis: {
    title: 'Média'
  },
  lineWidth: 1,
  pointSize: 4,
             });
//print(chart_media);
panel.widgets().set(11, chart_media); 
/********************************************mínima*****************************************/
var chart_min = ui.Chart.image.regions({
  image: temperatur_min,
  regions: point,
  scale: 30,
  seriesProperty: 'name'
});
chart_min.setChartType('ScatterChart');
chart_min.setOptions({
  title: 'Temperatura Mínima área de interesse',
  hAxis: {
    title: 'Tempereatura ºC'
  },
  vAxis: {
    title: 'Média'
  },
  lineWidth: 1,
  pointSize: 4,
             });
//print(chart_min);
panel.widgets().set(12, chart_min); 
});
Map.style().set('cursor', 'crosshair');
// Fim do App