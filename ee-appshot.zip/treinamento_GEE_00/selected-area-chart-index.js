var fao = ui.import && ui.import("fao", "table", {
      "id": "FAO/GAUL/2015/level0"
    }) || ee.FeatureCollection("FAO/GAUL/2015/level0"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -45.20198110622208,
                -9.249295923406786
              ],
              [
                -45.51509145778458,
                -9.108302483291743
              ],
              [
                -45.26515249294083,
                -9.398362123093406
              ],
              [
                -45.11683706325333,
                -9.333322887078301
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#000000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #000000 */ee.Geometry.Polygon(
        [[[-45.20198110622208, -9.249295923406786],
          [-45.51509145778458, -9.108302483291743],
          [-45.26515249294083, -9.398362123093406],
          [-45.11683706325333, -9.333322887078301]]]);
var limite = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017')
              .filterMetadata('country_co','equals','BR')
Map.centerObject(limite,3)
/********************************** GEOMETRIA PARA DOWNLOAD - CONFIG INICIAL ****************************************/
var drawingTools = Map.drawingTools();
var layers = drawingTools.layers();
drawingTools.setShown(true);
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
var dummyGeometry =
    ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: 'black',shown: false});
drawingTools.layers().set(0,dummyGeometry);
function clearGeometry() {
  var layers = drawingTools.layers();
  layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
}
function drawRectangle() {
  clearGeometry();
  drawingTools.setShape('polygon');
  drawingTools.draw();
}
drawingTools.onDraw(ui.util.debounce(GRAFICO_ITERATIVO_PANEL, 1000));
drawingTools.onEdit(ui.util.debounce(GRAFICO_ITERATIVO_PANEL, 1000));
/********************************** GEOMETRIA PARA DOWNLOAD - CONFIG INICIAL ****************************************/
// DEFINIR A BORDA DO LAYER DAS ÁREAS DE ESTUDO
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: limite,
  color: 1,
  width: 2
});
Map.addLayer(outline, {palette: '#000000'}, 'Área de Interesse',1);
Map.setOptions("HYBRID")
//Função dos índices
function indices (image) {
  var ndvi =  image.normalizedDifference(['B8', 'B4']).rename('NDVI');// Rouse 1973
  var evi = image.expression('2.5 * ((N - R) / (N + (6 * R) - (7.5 * B) + 1))', { //Huete 2002
        'N': image.select('B8'), 'R': image.select('B4'), 'B': image.select('B2')}).rename('EVI');
  var savi = image.expression('(1 + L ) * float(nir - red)/ (nir + red + L)',{ 'nir': image.select('B8'),
        'red': image.select('B4'),'L':1}).rename('SAVI');
  return image.addBands([ndvi, evi,savi])
  .clip(limite)
  }
/*****************************************Máscaras de nuvem***************************************************/
// Function to mask clouds using the Sentinel-2 QA band.
function maskS2clouds(image) {
  var qa = image.select('QA60')
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0))
  // Return the masked and scaled data, without the QA bands.
  return image.updateMask(mask).divide(10000)
      .select("B.*")
      .copyProperties(image, ["system:time_start"])
}
/***********************************************FIM Download*****************************************************/
//Importando coleção de imagens
var hoje= ee.Date(Date.now())
var startyear = 2018;
var endyear = 2021;
var startDate = ui.Textbox({
  value: "2017-03-28", 
  placeholder:"yyyy-mm-dd",
  style: { color: "#000000"}});
  //END DATE\
  var endDate = ui.Textbox({
    value: "2021-12-31", 
    placeholder:"yyyy-mm-dd" ,
    style: { color: "#000000"}});
/******************************* CRIAR LISTA DE MESES E ANOS PARA UTILIZAR NAS FUNÇÕES********************************/ 
var months = ee.List.sequence(1,12);
var years = ee.List.sequence(startyear,endyear);
var sentinel = ee.ImageCollection("COPERNICUS/S2_SR")
                .filterBounds(limite)
                .filterDate(startDate.getValue(), endDate.getValue())
                .filter(ee.Filter.calendarRange(1,12,"month"))
                .filterMetadata('CLOUDY_PIXEL_PERCENTAGE','less_than',1)// avaliação de cobertura de nuvem
                .map(maskS2clouds)
               // .map(function(image){return image.divide(10000).copyProperties(image, ["system:time_start"])})
                .map(function(image){return image.set({date: image.date().format('yyyy-MM-dd')})})
                .map(indices)
//Adicionando o layer
//Map.addLayer(sentinel.first(),{bands: ['B4', 'B3', 'B2'], min: 0.02, max: 0.4},'Sentinel RGB',true);
//Map.addLayer(sentinel.select('EVI').first(), {palette:['red','orange','yellow','green'], min:-0.02, max:0.59},'EVI',true);
//Map.addLayer(sentinel.select('NDVI').first(), {palette:['red','orange','yellow','green'], min:-0.13, max:0.82},'NDVI',true);
/*****************************Cálculo de dados mensais*****************************************************************/
var collection_download = ee.ImageCollection.fromImages(
  years.map(function (year) {
    var anual =  sentinel.select(['NDVI','EVI']).filter(ee.Filter.calendarRange(year, year, 'year'))
        .mean()
        .clip(limite);
    return anual.set('year', year) // INTERVALO ANO = Y
                .set('date', ee.Date.fromYMD(year,1,1)) // DATE É A DATA QUE VEM DE Y ANO, M MÊS E 1 DIA 1.
                .set('system:time_start',ee.Date.fromYMD(year,1,1)); // INTERVALO SYSTEM TIME_START DAS COLEÇÕES
                }).flatten()
                ); /// EMPILHAR COLEÇÕES 
/*
var collection_download = ee.ImageCollection.fromImages(  //RETORNA A IMAGEM PARA COLEÇÃO 
  years.map(function (ano) { // APLICAR A FUNÇÃO MAP (LOOP) PARA  A VARIÁVEL YEARS
  return months.map(function(mes){ //  returnar a variável months com a seguinte função P:  
  var ndvi_month = sentinel.select(['NDVI','EVI']).filter(ee.Filter.calendarRange(ano, ano, 'year'))  //filtro por ano,
           .filter(ee.Filter.calendarRange(mes, mes, 'month')) //  filtro por mês
           .median() // MÉDIA NDVI TODOS OS VALORES DA COLEÇÃO NO MÊS 
           .clip(limite)
  return ndvi_month.set('year', ano) // INTERVALO ANO = Y
           .set('month', mes) // INTERVALO MONTH = m 
           .set('date', ee.Date.fromYMD(ano,mes,1)) // DATE É A DATA QUE VEM DE Y ANO, M MÊS E 1 DIA 1.
           .set('system:time_start',ee.Date.fromYMD(ano,mes,1)); // INTERVALO SYSTEM TIME_START DAS COLEÇÕES
            })
            }).flatten()
          ); /// EMPILHAR COLEÇÕES 
//print(collection_download.limit(1),'Ndvi médio mensal')
*/
/*****************************************CRIANDO PAINEL PARA OS GRÁFICOS***************************************/
var panel = ui.Panel();
panel.style().set('width', '380px');
var intro = ui.Panel([
ui.Label({
    value: 'NDVI and EVI- Inspect the area - V0',
    style: {fontSize: '20px', fontWeight: 'bold'}}),
ui.Label('In this app the user can select an area to inspect and obtain information about a form biomass from the NDVI and EVI indices.'+
'Sentinel-2 MSI images were used: MultiSpectral Instrument, Level-2A images available from data 28-03-2017 to date.'),
ui.Label('To download the information contained in the graphics, just maximize the figure and select the option Download .CSV'),
ui.Label({value:'Prepared by: Christhian Santana Cunha - Environmental Manager, MSc Water Resources',
          style: {fontSize: '14px', fontWeight: 'bold'}})
]);
panel.add(intro);
/********************************FUNCAO PARA SELECIONAR UMA AREA DE INTERESSE E GERAR GRAFICO********************/
var symbol = {
  rectangle: '⬛',
};
var AREA_DOWNLOAD_GRAFICO =  ui.Panel({
    layout:ui.Panel.Layout.flow("vertical"), 
    style: {position: 'top-center',margin: 'auto', width: '100%'},
    widgets:[ui.Label({
      value:'🖱️Select a specific area to view the graphical 📊 analysis the images:',
      style:{fontSize: '16px',}
      }),
      ui.Label({value:'⚠ Attention! Will not work for large areas.', style: {fontSize: '16px', fontWeight: 'bold',color:'red'}}),
      ui.Button({
      label: symbol.rectangle + ' Selected Area',
      onClick: drawRectangle,
      style: {stretch: 'horizontal',
         textAlign: 'center',
      }})
    ]}
  );  
panel.widgets().set(3, AREA_DOWNLOAD_GRAFICO)
/*****************************************Label*************************************************/
var label = ui.Label({
  value:'Select an area, generate a graph, click on the graph and generate images.',
  style: {fontSize: '12px', fontWeight: 'bold'}})
Map.add(label)
/******************************************GRÁFICO***********************************************/
var GRAFICO_ITERATIVO =  ui.Panel({
    layout:ui.Panel.Layout.flow("vertical"), 
    widgets:[
    ]}
  );
panel.add(GRAFICO_ITERATIVO)
function GRAFICO_ITERATIVO_PANEL() {
//Adicionando gráfico iterativo 
//Referência Luis Sadeck (2020) - https://www.youtube.com/watch?v=qao-qdi5gyA
var aoi = drawingTools.layers().get(0).getEeObject();
drawingTools.setShape(null);
//var Amostras = sentinel.sample({ region: aoi, scale: 1000, numPixels: 2000,geometries :true}) 
var chart = ui.Chart.image.series({
  imageCollection: sentinel.select(['NDVI','EVI']), 
  region: aoi, 
  reducer: ee.Reducer.mean(), 
  scale:1000, 
  xProperty:'date'
  })
  .setOptions({
    tile:'Biomass according to indices',
    hAxis:{'title':'Date'},
    vAxis:{'title':'Medium values'},
    lineWidth: 2
  })
/*****************************Link Download*****************************/
//Orientação ao gráfico para gerar a interatividade
chart.onClick(function(xValue, yValue, seriesName){
  if (!xValue) return;
  var equalDate =ee.Filter.equals('date', xValue);
  var ndvi = ee.Image(sentinel.filterBounds(aoi).select('NDVI').filter(equalDate).median()).clip(aoi);
  var evi = ee.Image(sentinel.filterBounds(aoi).select('EVI').filter(equalDate).median()).clip(aoi);
  var rgb = ee.Image(sentinel.filterBounds(aoi).filter(equalDate).median()).clip(aoi);
  var limiar = evi.gt(0.5).and(ndvi.lt(1)).rename('vegetacao')
  limiar = limiar.updateMask(limiar)
  var veg_limiar = ee.Image(limiar)
  Map.layers().reset()
  Map.addLayer(ndvi,{palette:['red','orange','yellow','green'], min:-0.13, max:0.82},'NDVI')
  Map.addLayer(evi,{palette:['red','orange','yellow','green'], min:-0.02, max:0.59},'EVI')
  Map.addLayer(rgb,{bands: ['B4', 'B3', 'B2'], min: 0.010, max: 0.2},'Sentinel RGB')
  Map.addLayer(veg_limiar,{palette:['purple']},'Threshold')
  label.setValue((new Date(xValue)).toUTCString())
  var area = veg_limiar.multiply(ee.Image.pixelArea()).divide(10000)
  var means = area.reduceRegions({
    collection: aoi, 
    reducer: ee.Reducer.sum(),
    scale: 20
  })
  var area_total = ee.Number(means);
  print('Total area in hectares:',area_total);
 var panel_area = ui.Label({
  value:'Total area in hectares:',
  style: {fontSize: '14px', fontWeight: 'bold'}
 })
  var ara_label = ui.Label(area_total.getInfo());
  ara_label.style().set({fontSize: '14px',padding:'0px 0px',})
  panel.add(panel_area)
  panel.add(ara_label)
})      
GRAFICO_ITERATIVO.widgets().reset([chart])
}      
/************************Legenda************************************/
// Cria uma imagem em miniatura da barra de cores para uso na legenda da cor fornecida
// paleta.
var vis = {min: -1, max: 1, palette:['red','orange','yellow','green']}
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Crie a barra de cores para a legenda.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(vis.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Crie um painel com três números para a legenda.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(vis.min, {margin: '4px 8px'}),
    ui.Label(
        (vis.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(vis.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Legend: Indices minimum and maximum values',
  style: {fontWeight: 'bold'}
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
panel.widgets().set(4, legendPanel);
/*********************************************FIM DO PAINEL**************************************************************/
ui.root.insert(0, panel);
/******************************************Download****************************************************************/
var Download_Panel= ui.Panel({
  layout:ui.Panel.Layout.flow("vertical"), 
    style: {position: 'top-center',margin: 'auto', width: '100%'},
    widgets:[ui.Label({value:'Download an annual image', style: {fontSize: '16px', fontWeight: 'bold'}}),
    ui.Label('The same will hold for the selected area to generate the chart. Annual NDVI and EVI value available')]
})
var year_image_Image=ui.Textbox({ 
 value: '2018', 
 style: { color: "#000000"}}); 
/* 
var month_image_Image=ui.Textbox({ 
 value: '1', 
 style: { color: "#000000"}}); 
*/
var Link_download_Image=ui.Label({ 
 value: 'Download ⭳', 
 style: { color: "#000000",shown:false}}); 
var select_year_Image = ui.Select({
   items: ['2018','2019','2020','2021'
   ],
   placeholder: '2018',
   onChange:function(year_value) {
   Link_download_Image.style().set({shown:false})
   year_image_Image.setValue(year_value)
}})
var button = ui.Button({
  label: 'Download Image',
  onClick: function() {
var aoi = drawingTools.layers().get(0).getEeObject();
var link = collection_download.median().clip(aoi).getDownloadURL({
  name: 'Image_'+year_image_Image.getValue(),
  scale: 20,
  maxPixels: 1e113,
  region: aoi
});
  Link_download_Image.setUrl(link)
  Link_download_Image.style().set({shown:true})
}
});
var Panel_Button_Image = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style:{
    color: "#000000", 
    margin: '2px 10px'},//border: '0.5px solid #000000' 
  widgets:[select_year_Image,button,Link_download_Image]
})
Download_Panel.add(Panel_Button_Image);
panel.add(Panel_Button_Image)
/*********************************************ADICIONANDO LOGO**********************************************/
var Url = 'https://www.instagram.com/scriptsremote/'
var Urlyoutube = 'https://youtube.com/playlist?list=PLsur3nWlLefuJoKhI_e-JC7HPZRn8u_xd'
var logo_panel= ui.Panel({
  layout:ui.Panel.Layout.flow("vertical"), 
    style: {position: 'top-center',margin: 'auto', width: '100%'},
    widgets:[ui.Label({value:'Prepared by', style: {fontSize: '14px', fontWeight: 'bold'}}),
    ui.Label('📱 https://www.instagram.com/scriptsremote/', {fontSize: '12px', fontWeight: 'bold'},Url),
    ui.Label('🎬 https://youtube.com/playlist?list=PLsur3nWlLefuJoKhI_e-JC7HPZRn8u_xd',{},Urlyoutube)]
})
panel.add(logo_panel)
var logo = ee.Image('users/treinamento_GEE_00/Logos/logo_redonda_scripts');
	var thumb = ui.Thumbnail({
image: logo,
params:{bands:['b3','b2','b1'],min:0,max:255},
style: {height: '120px', width: '190px',padding :'0'}
});
panel.widgets().set(6, thumb);