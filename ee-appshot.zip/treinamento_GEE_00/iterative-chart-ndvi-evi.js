var roi = ui.import && ui.import("roi", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -47.960852839310874,
                -16.713253828027224
              ],
              [
                -47.960852839310874,
                -16.938690098249396
              ],
              [
                -47.45960161860775,
                -16.938690098249396
              ],
              [
                -47.45960161860775,
                -16.713253828027224
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {
        "classe": 0,
        "label": "area de estudo"
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Polygon(
                [[[-47.960852839310874, -16.713253828027224],
                  [-47.960852839310874, -16.938690098249396],
                  [-47.45960161860775, -16.938690098249396],
                  [-47.45960161860775, -16.713253828027224]]], null, false),
            {
              "classe": 0,
              "label": "area de estudo",
              "system:index": "0"
            })]);
//Autor: Christhian Santana Cunha
//Bacharel em Gestão Ambiental - UNIPAMPA (2012)
//Mestre em Engenharia Civil, Recursos Hídricos - UFSM (2014)
//Doutorando Sensoriamento Remoto -UFGRS
// DEFINIR A BORDA DO LAYER DAS ÁREAS DE ESTUDO
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: roi,
  color: 1,
  width: 2
});
Map.addLayer(outline, {palette: '#000000'}, 'Área de Interesse',1);
Map.centerObject(roi,10)
Map.setOptions("HYBRID")
//Função dos índices
function indices (image) {
  var ndvi =  image.normalizedDifference(['B8', 'B4']).rename('NDVI');// Rouse 1973
  var evi = image.expression('2.5 * ((N - R) / (N + (6 * R) - (7.5 * B) + 1))', { //Huete 2002
        'N': image.select('B8'), 'R': image.select('B4'), 'B': image.select('B2')}).rename('EVI');
  var savi = image.expression('(1 + L ) * float(nir - red)/ (nir + red + L)',{ 'nir': image.select('B8'),
        'red': image.select('B4'),'L':1}).rename('SAVI');
  return image.addBands([ndvi, evi,savi])
  .clip(roi)
  }
//Importando coleção de imagens
var sentinel = ee.ImageCollection("COPERNICUS/S2_SR")
                .filterBounds(roi)
                .filterDate('2018-01-01', '2020-12-31')
                .filter(ee.Filter.calendarRange(1,12,"month"))
                .filterMetadata('CLOUDY_PIXEL_PERCENTAGE','less_than',1)// avaliação de cobertura de nuvem
                .map(function(image){return image.divide(10000).copyProperties(image, ["system:time_start"])})
                .map(function(image){return image.set({date: image.date().format('yyyy-MM-dd')})})
                .map(indices)
//Adicionando o layer
//Map.addLayer(sentinel.first(),{bands: ['B4', 'B3', 'B2'], min: 0.02, max: 0.4},'Sentinel RGB',true);
//Map.addLayer(sentinel.select('EVI').first(), {palette:['red','orange','yellow','green'], min:-0.02, max:0.59},'EVI',true);
//Map.addLayer(sentinel.select('NDVI').first(), {palette:['red','orange','yellow','green'], min:-0.13, max:0.82},'NDVI',true);
//Adicionando gráfico iterativo 
//Referência Luis Sadeck (2020) - https://www.youtube.com/watch?v=qao-qdi5gyA
var chart = ui.Chart.image.series({
  imageCollection: sentinel.select(['NDVI','EVI']), 
  region: roi, 
  reducer: ee.Reducer.mean(), 
  scale:100, 
  xProperty:'date'
  })
  .setOptions({
    tile:'Biomassa de acordo com os índices',
    hAxis:{'title':'Data'},
    vAxis:{'title':'Valores médios'},
    lineWidth: 2
  })
//Add o Gráfico no Painel
chart.style().set({
  position:'bottom-right',
  width:'500px',
  height:'300px'
})
//Plotando o gráfico no Map
Map.add(chart)
//Orientação ao gráfico para gerar a interatividade
chart.onClick(function(xValue, yValeu, seriesName){
  if (!xValue) return;
  var equalDate =ee.Filter.equals('date', xValue);
  var ndvi = ee.Image(sentinel.select('NDVI').filter(equalDate).first()).clip(roi);
  var evi = ee.Image(sentinel.select('EVI').filter(equalDate).first()).clip(roi);
  var rgb = ee.Image(sentinel.filter(equalDate).first()).clip(roi);
  var limiar = ndvi.gt(0.8).rename('vegetacao')
  limiar = limiar.updateMask(limiar)
  var veg_limiar = ee.Image(limiar)
  Map.layers().reset()
  Map.addLayer(ndvi,{palette:['red','orange','yellow','green'], min:-0.13, max:0.82},'NDVI')
  Map.addLayer(evi,{palette:['red','orange','yellow','green'], min:-0.02, max:0.59},'EVI')
  Map.addLayer(rgb,{bands: ['B4', 'B3', 'B2'], min: 0.010, max: 0.2},'Sentinel RGB')
  Map.addLayer(veg_limiar,{palette:['purple']},'Limiar')
})