var ponto = ui.import && ui.import("ponto", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            13.68330005674732,
            4.581550677947334
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([13.68330005674732, 4.581550677947334]);
//Saccomano - Área agrícola Bertoua Camarrões
//Autor: Christhia Santana Cunha 
//Data: 16-06-2021
//Versão 00
/***************************Definição da área de estudo****************************/ 
var area_estudo = ponto.buffer(35000)
//Desenhando o Contorno da ROIA
var empty = ee.Image().byte();
var contorno = empty.paint({
  featureCollection: area_estudo,
  color: 1,
  width: 2
});
/*****************************Máscara de núvens***********************************/
/* Usa a banda de QA do Sentinel-2 para máscara de nuvem
  a coleção. Os sinalizadores de nuvem Sentinel-2 são menos
  seletiva, então a coleção também é pré-filtrada pelo
  Sinalizador CLOUDY_PIXEL_PERCENTAGE, para usar apenas relativamente
  grânulo livre de nuvem.*/
// Função para mascarar nuvens usando a banda Sentinel-2 QA.
function maskS2clouds(image) {
  var qa = image.select('QA60')
  // Os bits 10 e 11 são nuvens e cirros, respectivamente.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Ambos os sinalizadores devem ser definidos como zero, indicando condições claras.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0))
  //Retorne os dados mascarados e dimensionados, sem as bandas de controle de qualidade.
  return image.updateMask(mask).divide(10000)
      .select("B.*")
      .copyProperties(image, ["system:time_start"])
}
//Índices de vegetação 
function indices (image) {
  var ndvi =  image.normalizedDifference(['B8', 'B4']).rename('NDVI');// Rouse 1973
  var lswi =  image.normalizedDifference(['B8', 'B11']).rename('LSWI'); //Xiao 2002
  var mndwi = image.normalizedDifference(['B3', 'B11']).rename('MNDWI'); // Xu 2005
  var ndwi = image.normalizedDifference(['B3', 'B8']).rename ('NDWI'); //Mc Feeters 1996
  var evi = image.expression('2.5 * ((N - R) / (N + (6 * R) - (7.5 * B) + 1))', { //Huete 2002
        'N': image.select('B8'), 'R': image.select('B4'), 'B': image.select('B2')}).rename('EVI');
  var savi = image.expression('(1 + L ) * float(nir - red)/ (nir + red + L)',{ 'nir': image.select('B8'),
        'red': image.select('B4'),'L':1}).rename('SAVI');
  return image.addBands([ndvi,lswi, mndwi, ndwi, evi,savi]).clip(area_estudo)
  }
//Importando Coleção Sentinel 2 C
var collection = ee.ImageCollection("COPERNICUS/S2_SR")
      .filterDate('2017-01-01', '2021-5-31')
      .filterBounds(area_estudo)
      // Pré-filtrar para obter grânulos menos turvos.
      .filterMetadata('CLOUDY_PIXEL_PERCENTAGE','less_than',10)// avaliação de cobertura de nuvem
      .map(maskS2clouds)// máscaras de núves
      .map(indices)
//Máscara de água 
var mndwiMasked_max = collection.select('MNDWI').reduce(ee.Reducer.max())
var maskwater = mndwiMasked_max.updateMask(mndwiMasked_max.gt(0));
//Importando coleção do Global Surface Water
var agua = ee.Image("JRC/GSW1_3/GlobalSurfaceWater")
//Importando SRTM 
var elevation = ee.Image("USGS/SRTMGL1_003").clip(area_estudo)
var zones = ee.Image(0)
    .where(elevation.gt(600), 1)
    .where(elevation.gt(700), 2)
    .where(elevation.gt(800), 3)
    .where(elevation.gt(860), 4)
// Calcule as medidas de terreno do SRTM DEM.
var terrain = ee.Algorithms.Terrain(ee.Image("USGS/SRTMGL1_003"));
//Adicionando Layers
Map.setOptions('Hybrid')
//Map.addLayer(collection.median(), {bands: ['B4', 'B3', 'B2'], min: 0.021, max: 0.17}, 'RGB')
Map.addLayer(contorno, {palette: 'red'}, 'Buffer 35 km')
//Map.addLayer(elevation, {palette:['green', 'yellow','purple', 'cyan','red'], min:600, max:900},'SRTM Elevation');
//Map.addLayer(terrain.select('slope').clip(area_estudo),{palette:['green', 'purple'], min: 0, max: 2}, 'Declividade em graus');
//Map.addLayer(zones.clip(area_estudo),{palette:['green', 'yellow','cyan', 'red'], min: 1, max: 4}, 'Zonas de elevação');
//Map.addLayer(collection.select('LSWI').median(), {palette:['red','orange','yellow','green'], min:-0.20, max:0.329},'LSWI');
//Map.addLayer(collection.select('NDVI').median(), {palette:['red','orange','yellow','green'], min:0.22, max:0.813},'NDVI');
//Map.addLayer(collection.select('EVI').median(), {palette:['red','orange','yellow','green'], min:0.11, max:0.47},'EVI');
Map.addLayer(agua.select('occurrence'), {palette:['ffffff', 'ffbbbb', '0000ff'], min:0, max:100},'Global Surface Water');
/******************************************************Visualização das coleções**********************************************/
// Create a dictionary of labels and visualizations.
var vis = {
  'RGB': {bands: ['B4', 'B3', 'B2'], min: 0.021, max: 0.17},
  'NDVI': {bands: ['NDVI'], palette:['red','orange','yellow','green'], min:0.14804917573928833, max:0.8135509490966797},
  'EVI': {bands: ['EVI'], palette:['red','orange','yellow','green'], min:0.08463442207216844, max:0.47927852983437946},
  'LSWI': {bands: ['LSWI'], palette:['red','orange','yellow','green'], min:-0.23025670647621155, max:0.33522191643714905}
};
// Set up the maps.
var maps = [];
Object.keys(vis).forEach(function(name) {
  var map = ui.Map();
  map.add(ui.Label(name));
  map.addLayer(collection.select('B4','B3','B2','NDVI','EVI','LSWI').median(), vis[name], name);
  map.setOptions('Hybrid')
  map.setControlVisibility(false);
  maps.push(map);
});
var linker = ui.Map.Linker(maps);
// Ative o zoom no mapa superior esquerdo.
maps[0].setControlVisibility({zoomControl: true});
// Mostre a escala (por exemplo, '500 m') no mapa inferior direito.
maps[3].setControlVisibility({scaleControl: true});
// Crie uma grade de mapas.
var mapGrid = ui.Panel(
    [
      ui.Panel([maps[0], maps[1]], null, {stretch: 'both'}),
      ui.Panel([maps[2], maps[3]], null, {stretch: 'both'})
    ],
    ui.Panel.Layout.Flow('horizontal'), {stretch: 'both'});
// Centralize o mapa em um ponto interessante.
// Outros mapas se alinharão a este mapa pai.
maps[0].centerObject(ponto, 9);
//*********************************Painel de gráfico e Legenda*************************************************/
// Crie um painel para conter os componentes de título, texto de introdução, gráfico e legenda.
var inspectorPanel = ui.Panel({style: {width: '30%'}});
var vis = {min: 0, max: 1, palette:['green','yellow','red']}
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: 'Visualização de Imagens Sentinel 2 - RGB, NDVI, EVI, LSWI.' + 
            ' Área de Estudo: Bertoua - Camarões -África',
    style: {fontSize: '16px', fontWeight: 'bold'}
  }),
  ui.Label('O Gráfico abaixo representa o valor médio de cada índice (NDVI, EVI e LSWI) para a Área de Estudo em um raio de 35 km.')
]);
inspectorPanel.add(intro);
// Adicione espaços reservados para o gráfico e a legenda.
//inspectorPanel.add(ui.Label('[Legend]'));
var ndviChart = ui.Chart.image.series(collection.select('NDVI','EVI','LSWI'), area_estudo, ee.Reducer.mean(), 100);
  ndviChart.setOptions({
    title: 'Respostas dos Índices ao longo do tempo',
    vAxis: {title: 'Índices'},
    hAxis: {title: 'Data', format: 'MM-yy', gridlines: {count: 7}},
  });
  inspectorPanel.widgets().set(1, ndviChart);
/*
 * Legenda
 */
// Cria uma imagem em miniatura da barra de cores para uso na legenda da cor fornecida
// paleta.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Crie a barra de cores para a legenda.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(vis.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Crie um painel com três números para a legenda.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(vis.min, {margin: '4px 8px'}),
    ui.Label(
        (vis.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(vis.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Legenda Índices: valores mínimos (-1) e máximos (1)',
  style: {fontWeight: 'bold'}
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
inspectorPanel.widgets().set(3, legendPanel);
/*
 * Inicialize o aplicativo
 */
// Fim do App
ui.root.clear();
ui.root.widgets().reset([inspectorPanel,mapGrid])