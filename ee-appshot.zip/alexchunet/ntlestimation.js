var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                30.628867435629296,
                30.394572429976392
              ],
              [
                30.628867435629296,
                29.728982919797712
              ],
              [
                31.661582279379296,
                29.728982919797712
              ],
              [
                31.661582279379296,
                30.394572429976392
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#23cba7",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || 
    /* color: #23cba7 */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[30.628867435629296, 30.394572429976392],
          [30.628867435629296, 29.728982919797712],
          [31.661582279379296, 29.728982919797712],
          [31.661582279379296, 30.394572429976392]]], null, false);
/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var geometry = /* color: #23cba7 */ee.Geometry.Polygon(
        [[[29.361770935005097, 31.042524961474435],
          [29.581497497505097, 28.69920432974999],
          [32.6796420287551, 28.583500230331445],
          [32.7675326537551, 30.400303188811588]]]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// OBJECTIVE: Calculate variation of NDVI on a specific period
///////////////// CODE FOR CALCULATING NDVI ///////////////////////
var drawingTools = Map.drawingTools();
drawingTools.setShown(false);
Map.setOptions('SATELLITE');
Map.setCenter(13.58, 20.31, 3);
//Map.setCenter(-77.1056, 38.8904, 8);
// Setup a while loop to clear all existing geometries that have been added as imports from drawing tools (from previously running the script). The design of the app is to handle charting a time series for a single geometry, so remove any that exist.
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
var dummyGeometry =
    ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: '23cba7'});
drawingTools.layers().add(dummyGeometry);
function clearGeometry() {
  var layers = drawingTools.layers();
  layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
}
function drawRectangle() {
  clearGeometry();
  drawingTools.setShape('rectangle');
  drawingTools.draw();
}
function drawPolygon() {
  clearGeometry();
  drawingTools.setShape('polygon');
  drawingTools.draw();
}
var chartPanel = ui.Panel({
  style:
      {height: '235px', width: '600px', position: 'bottom-right', shown: false}
});
Map.add(chartPanel);
function chartNdviTimeSeries() {
  // Make the chart panel visible the first time a geometry is drawn.
  if (!chartPanel.style().get('shown')) {
    chartPanel.style().set('shown', true);
  }
  // Get the drawn geometry; it will define the reduction region.
  var aoi = drawingTools.layers().get(0).getEeObject();
  // Set the drawing mode back to null; turns drawing off.
  drawingTools.setShape(null);
  // Reduction scale is based on map scale to avoid memory/timeout errors.
  var mapScale = Map.getScale();
  var scale = mapScale > 5000 ? mapScale * 2 : 5000;
  // Chart NDVI time series for the selected area of interest.
  var chart = ui.Chart.image
                  .seriesByRegion({
                    imageCollection: ee.ImageCollection("NOAA/VIIRS/DNB/MONTHLY_V1/VCMCFG"),
                    regions: aoi,
                    reducer: ee.Reducer.sum(),
                    band: 'avg_rad',
                    scale: scale,
                    xProperty: 'system:time_start'
                  })
                  .setOptions({
                    titlePostion: 'none',
                    legend: {position: 'none'},
                    hAxis: {title: 'Date'},
                    vAxis: {title: 'VIIRS (x1e4)'},
                    series: {0: {color: '23cba7'}}
                  });
  // Replace the existing chart in the chart panel with the new chart.
  chartPanel.widgets().reset([chart]);
}
drawingTools.onDraw(ui.util.debounce(chartNdviTimeSeries, 500));
drawingTools.onEdit(ui.util.debounce(chartNdviTimeSeries, 500));
var symbol = {
  rectangle: '⬛',
  polygon: '🔺',
};
var controlPanel = ui.Panel({
  widgets: [
    ui.Label('1. Select a drawing mode.'),
    ui.Button({
      label: symbol.rectangle + ' Rectangle',
      onClick: drawRectangle,
      style: {stretch: 'horizontal'}
    }),
    ui.Button({
      label: symbol.polygon + ' Polygon',
      onClick: drawPolygon,
      style: {stretch: 'horizontal'}
    }),
    ui.Label('2. Draw a geometry.'),
    ui.Label('3. Wait for chart to render.'),
    ui.Label(
        '4. Repeat 1-3 or edit/move\ngeometry for a new chart.',
        {whiteSpace: 'pre'})
  ],
  style: {position: 'bottom-left'},
  layout: null,
});
Map.add(controlPanel);
Map.add(ui.Label('Night Time Light Estimation (VIIRS)', {fontWeight: 'bold', fontSize: '24px'}))
var img2020 = ee.ImageCollection("NOAA/VIIRS/DNB/MONTHLY_V1/VCMCFG").filter(ee.Filter.date('2017-05-01', '2017-05-31')).select('avg_rad');
var VIIRSVis = {
    min: 0.0,
    max: 60.0,
    opacity: 0.6,
    //palette: ['24126c', 'd4ff50', '1fff4f'],
    };
Map.addLayer(img2020, VIIRSVis, 'VIIRS')
///////////////////////////////////////////////////////////////////