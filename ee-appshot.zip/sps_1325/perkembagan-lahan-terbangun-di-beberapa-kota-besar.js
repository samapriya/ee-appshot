//var panel_atas = ui.Panel({ layout: ui.Panel.Layout.flow('vertical'),});
//var judul = ui.Label('Peta Lahan Terbangun Yogyakarta, Surabaya, dan Bandung')
//Map.add(panel_atas);
//panel_atas.add(judul);
//Map.setControlVisibility({ layerList: 1, zoomControl: 0, scaleControl: 0, mapTypeControl: 0, fullscreenControl: 0, drawingToolsControl: 0 });
//var panel_atas = ui.Panel({ layout: ui.Panel.Layout.flow('vertical'), style: { width: '50%',height: '28%',position: 'bottom-left',backgroundColor: 'rgba(255, 255, 255, 0.8)'}});
//var places = { 'Yogyakarta': [110.3831, -7.7958], 'Surabaya': [112.7456, -7.2858], 'Bandung': [107.6072, -6.9324] };
//var select = ui.Select({ items: Object.keys(places), onChange: function(key) { Map.setCenter(places[key][0], places[key][1], 12); } }).setPlaceholder('Pilih Lokasi');
//var panel_atas = ui.Panel({ layout: ui.Panel.Layout.flow('vertical'), }); 
//var panel_bawah = ui.Panel({ layout: ui.Panel.Layout.flow('vertical'), }); Map.add(panel_bawah); Map.add(panel_atas);
//var judul = ui.Label('Peta Lahan Terbangun Yogyakarta, Surabaya, dan Bandung'); var paragraf = ui.Label('Aplikasi ini digunakan untuk mengetahui perkembangan perkotaan'); panel_atas.add(judul); panel_atas.add(paragraf);
//var pilih_lokasi = ui.Label('Lokasi'); var ket_lokasi = ui.Label('Pilih lokasi kajian yang ingin ditampilkan'); panel_bawah.add(pilih_lokasi); panel_bawah.add(ket_lokasi);
//var places = { 'Yogyakarta': [110.3831, -7.7958], 'Surabaya': [112.7456, -7.2858], 'Bandung': [107.6072, -6.9324] };
//var select = ui.Select({ items: Object.keys(places), style: {width: '90%',}, onChange: function(key) { Map.setCenter(places[key][0], places[key][1], 12); } }).setPlaceholder('Pilih Lokasi'); panel_bawah.add(select);
//var palette =["8d5524","ffdbac"]; var names = ['Lahan Terbangun', 'Lahan Non Terbangun'];
//var makeRow = function(color, name) {var colorBox = ui.Label({ style: {backgroundColor: '#' + color, padding: '12px', width: '50px', margin: '0 0 4px 8px', } });
//var description = ui.Label({ value: name, }); 
//return ui.Panel({ widgets: [colorBox, description], layout: ui.Panel.Layout.Flow('horizontal'), }); };
//var legend = ui.Panel();for (var i = 0; i <= 1; i++) { legend.add(makeRow(palette[i], names[i])); }
//panel_bawah.add(legend);
var style= require('users/sps_1325/Pelatihan_GEE_Apps:style2')
var analisis= require('users/sps_1325/Pelatihan_GEE_Apps:analisis2')
print(analisis)
//panel atas
var panel_atas = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    width: '30%',
    height: '18%',
    position: 'bottom-right'
  }
});
// panel bawah
var panel_bawah = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    width: '30%',
    height: '60%',
    position: 'bottom-right'
  }
});
Map.add(panel_bawah);
Map.add(panel_atas);
//isi panel atas
var judul =ui.Label({
  value: 'Peta Lahan Terbangun',
  style: {fontWeight:'bold',
  fontSize:'15px'
  },
});
var ket_peta = ui.Label('Aplikasi ini digunakan untuk mengidentifikasi perkembangan kawasan terbangun');
panel_atas.add(judul);
panel_atas.add(ket_peta);
//isi panel bawah
var sub_judul1 = ui.Label('Lokasi');
var ket_sub_judul1 = ui.Label('Pilih lokasi yang akan diidentifikasi');
panel_bawah.add(sub_judul1);
panel_bawah.add(ket_sub_judul1);
//select buton lokasi
var tempat = {
  'Jakarta': [106.8469, -6.2119],
  'Bandung': [107.6033, -6.9216],
  'Yogyakarta': [110.3776, -7.7951],
  'Surabaya': [112.7347, -7.2689]
};
// Membuat select button
var pilih_tempat = ui.Select({ // select button dengan ui.Select
  items: Object.keys(tempat), // ambil key dari dictionaries tempat
  style: {
    width: '90%' // lebar 90%
  },
  onChange: function(key){
    Map.setCenter(tempat[key][0], tempat[key][1], 12) // Mengatur set center dg zoom 12 ke koordinat di dictionaries
  }
}).setPlaceholder('Pilih lokasi') // setting place holder atau teks sebelum select dipilih
panel_bawah.add(pilih_tempat) //tambahkan ke panel bawah
//select button tahun
var sub_judul2 = ui.Label({ // buat label
  value: 'Tahun', // isi label
  style: style.sub_judul_style // style
});
  var tahun = {
  '2019': [2019],
  '2020': [2020],
  '2021': [2021]
};
//data select tahun
var pilih_tahun = ui.Select({
  items: Object.keys(tahun),
  style: {
    width: '90%'
  },
  onChange: function(key) {
    var img = ee.Image(tahun[key][0])
    var tahun_ke = tahun[key][1];
    Map.addLayer(img, imageVisParam, 'Lahan Terbangun '+tahun_ke);
  }
}).setPlaceholder('Pilih tahun');
panel_bawah.add(pilih_tahun);
var pilih_tahun = ui.Select({
  items: Object.keys(tahun),
  style: {
    width: '90%'
  }
})
// panel atas
var panel_atas = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    width: '30%',
    height: '18%',
    position: 'bottom-left',
    backgroundColor: 'rgba(255, 255, 255, 0.8)'
  }
});
//base map
Map.setOptions('Retro',{'Retro':style.basemap_style});
var sub_judul3 =ui.Label({
  value: 'Legenda',
  style: {fontWeight:'bold',
  fontSize:'12px'
  },
});
panel_bawah.add(sub_judul3)
//Legenda
var color = ["8d5524","ffdbac"];
var nama = ['Lahan Terbangun', 'Lahan Non Terbangun']
var legenda = ui.Panel({
  style: {
    backgroundColor: 'rgba(255, 255, 255, 0)'
  }
})
function membuat_baris(color, nama) {
      // Membuat color box
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#'+color,
          padding: '12px',
          width: '50px',
          margin: '0 0 4px 8px',
        }
      });
  // label legenda
  var deskripsi = ui.Label({
    value: nama, 
    style: style.paragraf_style
  });
  // return widgets dalam panel
  return ui.Panel({
    widgets: [colorBox, deskripsi], 
    layout: ui.Panel.Layout.flow('horizontal'), 
    style: {
      backgroundColor: 'rgba(255, 255, 255, 0)'
    }
  });
}
for(var i = 0; i<2; i++){
  legenda.add(membuat_baris(color[i], nama[i]))
}
panel_bawah.add(legenda)