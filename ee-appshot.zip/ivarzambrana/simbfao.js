var chiquitania = ui.import && ui.import("chiquitania", "table", {
      "id": "users/ivarzambrana/chiquitania"
    }) || ee.FeatureCollection("users/ivarzambrana/chiquitania"),
    AP_Nacional = ui.import && ui.import("AP_Nacional", "table", {
      "id": "users/ivarzambrana/AP_NACIONAL"
    }) || ee.FeatureCollection("users/ivarzambrana/AP_NACIONAL"),
    table = ui.import && ui.import("table", "table", {
      "id": "users/ivarzambrana/departamentos"
    }) || ee.FeatureCollection("users/ivarzambrana/departamentos"),
    table2 = ui.import && ui.import("table2", "table", {
      "id": "users/ivarzambrana/Municipios"
    }) || ee.FeatureCollection("users/ivarzambrana/Municipios"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "nd"
        ],
        "min": -500,
        "max": 700,
        "palette": [
          "1a9850",
          "91cf60",
          "d9ef8b",
          "fee08b",
          "fc8d59",
          "d73027"
        ]
      }
    }) || {"opacity":1,"bands":["nd"],"min":-500,"max":700,"palette":["1a9850","91cf60","d9ef8b","fee08b","fc8d59","d73027"]},
    rioblanco = ui.import && ui.import("rioblanco", "table", {
      "id": "users/ivarzambrana/RIOBLANCO"
    }) || ee.FeatureCollection("users/ivarzambrana/RIOBLANCO"),
    imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "COPERNICUS/S2_SR_HARMONIZED"
    }) || ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED");
// Load required modules and datasets
var VisNBR = {
  "opacity": 1,
  "bands": ["NBR"],
  "min": -0.305812066793441,
  "max": 0.4710094729065895,
  "palette": ["ff0000", "ffdc22", "f2ff4d", "68ff1e", "097f13"]
};
// Load the MapBiomas Bolivia collection
var dataset = ee.Image('projects/mapbiomas-public/assets/bolivia/collection2/mapbiomas_bolivia_collection2_integration_v1');
// Initialize mapbiomasImage variable
var mapbiomasImage = ee.Image();
// Variable global para mantener la referencia de la gráfica
var currentChart = null;
// Parámetros de NBR y Capas
var preNBR = ee.FeatureCollection([]);
var minNBR = ee.Image([]);
var tools = require('users/fitoprincipe/geetools:tools');
var fecha = new Date();
var m = {};
m.opciones = {
  limites: {
    municipios: "users/ivarzambrana/Municipios",
    departamentos: "users/ivarzambrana/departamentos",
    pais: 'users/ivarzambrana/bolivia',
    AP: 'users/ivarzambrana/AP_NACIONAL'
  },
  departamentos: null,
  municipios: null,
  limiteActivo: null, // Inicializar como null
  nombreActivo: "",
  nombreMunicipio: [],
  nombreDepartamento: {
    "Ninguno": "Ninguno",
    "Beni": "10",
    "Chuquisaca": "20",
    "Cochabamba": "30",
    "La Paz": "40",
    "Oruro": "50",
    "Pando": "60",
    "Potosí": "70",
    "Santa Cruz": "80",
    "Tarija": "90",
  }
};
m.opciones.municipios = ee.FeatureCollection(m.opciones.limites.municipios);
m.opciones.departamentos = ee.FeatureCollection(m.opciones.limites.departamentos);
m.opciones.pais = ee.FeatureCollection(m.opciones.limites.pais);
m.opciones.apnacional = ee.FeatureCollection(m.opciones.limites.AP);
m.fechas = {
  'hoy': fecha,
  'ayer': new Date(new Date().setDate(new Date().getDate() - 15)),
  'año': fecha.getFullYear(),
  'mes': fecha.getMonth() + 1,
  'dia': fecha.getDate(),
  'dateRange': '',
  'Start_period': '',
  'End_period': '',
  'FechaPre': '',
  'FechaPost': '',
  'FechaPreImg': '',
  'FechaPostImg': '',
  'SensorSelect': 0,
  'ImagenPre': ee.Image([]), // La imagen seleccionada Pre
  'ImagenPost': ee.Image([]), // La imagen seleccionada Post
  'Quema': ee.Image([]),
  'layerPre': '',
  'layerPost': '',
  'dNBR': '',
  'CLASEQUEMA': 390,
};
m.logo = ee.Image('users/ivarzambrana/logo').visualize({
  bands: ['b1', 'b2', 'b3'],
  min: 0,
  max: 255
});
m.table = ee.FeatureCollection("users/ivarzambrana/Municipios");
m.fechaini = '';
m.fechapreNBR = ee.Date(m.fechas.FechaPre);
m.fechapostNBR = ee.Date(m.fechas.FechaPost);
m.prefuego_fin = ee.Date(m.fechaini);
m.prefuego_ini = m.prefuego_fin.advance(-1, 'month');
// Escoja la fecha cuando termina la quema.
m.fechafin = '';
m.postfuego_ini = ee.Date(m.fechafin);
m.postfuego_end = m.postfuego_ini.advance(1, 'month');
m.mun = "";
m.Limite = m.table.filter(ee.Filter.eq('MUNICIPIO', m.mun));
m.prefuego_CM_ImCol = ee.FeatureCollection([]);
m.preNBR = ee.Image([]);
m.postNBR = ee.Image([]);
m.dNBR = ee.Image([]);
m.postfuego_CM_ImCol = ee.FeatureCollection([]);
m.quemas = ee.Image([]);
m.clasificado = "";
m.areacicatriz = "";
m.areaquema = "";
// Declaración de variables globales para exportación
var BA_vector = null;
var imagenVisualizadamin = null;
var area = null;
// Añadimos la variable global para el valor del umbral
m.thresholdValue = 2300; // Valor inicial
/*******************************************************************************
 * Components *
 ******************************************************************************/
var mask = "";
var NBRVisParam = {
  "opacity": 1,
  "bands": ["nd"],
  "min": -500,
  "max": 700,
  "palette": ['#1a9850', '#91cf60', '#d9ef8b', '#fee08b', '#fc8d59', '#d73027']
};
var VisNBR = {
  "opacity": 1,
  "bands": ["NBR"],
  "min": -0.305812066793441,
  "max": 0.4710094729065895,
  "palette": ["ff0000", "ffdc22", "f2ff4d", "68ff1e", "097f13"]
};
var ParamSensor = {
  'Label': ['Sentinel 2',
    'Landsat 8'],
  'Inicial': ['S2', 'L8'],
  'Id': ['COPERNICUS/S2_SR',
    'LANDSAT/LC08/C02/T1_TOA'
  ],
  'Bandas': [
    ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'B8A', 'B11', 'B12'], //S2
    ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B10', 'B11']
  ], //L8
  'Periodo': [
    [2016, m.fechas.año], //S2
    [2013, m.fechas.año], //L8
  ],
  'BandaCloud': [
    ['CLOUDY_PIXEL_PERCENTAGE', 'QA60', 11, 10],
    ['CLOUD_COVER', 'QA_PIXEL', 3, 5]
  ],
  'Vis': [{
    bands: ['B11', 'B8A', 'B4'],
    min: [0, 1000, 0],
    max: [5000, 6000, 5000]
  },
  {
    bands: ['B6', 'B5', 'B4'],
    min: [0, 0.1, 0],
    max: [0.6, 0.6, 0.6]
  }]
};
var areacicatriz = null;
// Define un objeto JSON para almacenar los componentes de la interfaz de usuario.
var c = {};
c.controlPanel = ui.Panel({
  style: {
    width: "280px",
    padding: "10px"
  }
});
c.map = ui.Map();
c.map.setCenter(-66.22436635629889, -17.293714540188354, 7);
c.logo = ui.Thumbnail({
  image: m.logo,
  params: {
    dimensions: '642x291',
    format: 'png'
  },
  style: {
    height: '120px',
    width: '260px',
    padding: '0'
  }
});
c.info = {};
c.info.titulo = ui.Label({
  "value": "CÁLCULO DE CICATRICES DE QUEMA",
  "style": {
    "fontWeight": 'bold',
    "textAlign": 'center',
    "fontSize": "14px",
  }
});
c.info.descripcion = ui.Label({
  "value": "Herramienta para el cálculo de cicatrices de quema a partir de imágenes satelitales Landsat 8 y Sentinel 2 Generado por SIMB y FAO-BOLIVIA",
  "style": {
    'stretch': 'horizontal',
    "fontSize": "11px",
    'padding': '4px'
  }
});
c.info.panel = ui.Panel([c.info.titulo, c.info.descripcion]);
c.labelSensor = ui.Label({
  "value": "Sensor:",
  "style": {
    'stretch': 'horizontal',
    "fontSize": "11px",
    'padding': '4px'
  }
});
c.dateSensor = ui.Select({
  'items': ParamSensor.Label,
  'placeholder': ParamSensor.Label[m.fechas.SensorSelect],
  'onChange': function (s) {
    var AntSen = ParamSensor.Label[m.fechas.SensorSelect];
    var f;
    m.fechas.SensorSelect = ParamSensor.Label.indexOf(s);
    // Recalculamos el rango del periodo
    var y = ParamSensor.Periodo[m.fechas.SensorSelect][0];
    m.fechas.Start_period = ee.Date(y + '-01-01');
    var y_end = ParamSensor.Periodo[m.fechas.SensorSelect][1];
    m.fechas.End_period = ee.Date(m.fechas.FechaPost).advance(1, 'day');
    if (y_end === 2011) {
      m.fechas.End_period = ee.Date(y_end + '-12-31');
      c.fechas["textFechaImgPre"].setValue(y_end + '-12-17');
      c.fechas["textFechaImgPost"].setValue(y_end + '-12-31');
    }
    else {
      if (AntSen === ParamSensor.Label[4]) { // Asegúrate de que este índice es correcto
        m.fechas.hoy = new Date();
        m.fechas.ayer = new Date(new Date().setDate(new Date().getDate() - 15));
        m.fechas.FechaPost = m.fechas.año + '-' + GetMesT(m.fechas.mes) + '-' + GetDiaT(m.fechas.dia);
        m.fechas.FechaPre = m.fechas.ayer.getFullYear() + '-' + GetMesT(m.fechas.ayer.getMonth() + 1) + '-' + GetDiaT(m.fechas.ayer.getDate());
        m.fechas.Start_period = ee.Date(m.fechas.FechaPre);
        m.fechas.End_period = ee.Date(m.fechas.FechaPost);
        c.fechas["textFechaImgPre"].setValue(m.fechas.FechaPre);
        c.fechas["textFechaImgPost"].setValue(m.fechas.FechaPost);
      }
    }
    m.fechas.dateRange = ee.DateRange(m.fechas.Start_period, m.fechas.End_period);
    m.fechas.GenImg = false;
  },
  'style': {
    'stretch': 'horizontal',
  }
});
c.dateSensor.panel = ui.Panel([c.labelSensor, c.dateSensor]);
c.fechas = {
  labelFechaImgPre: ui.Label({
    "value": "Fecha inicio:",
    "style": {
      "fontSize": "10px",
      'stretch': 'horizontal',
    }
  }),
  textFechaImgPre: ui.Textbox({
    //'placeholder': '',
    'value': "2023-08-01",
    'onChange': function (text) {
      m.fechas.FechaPre = text;
    },
  }),
  labelFechaImgPost: ui.Label({
    "value": "Fecha fin:",
    "style": {
      'stretch': 'horizontal',
      "fontSize": "10px",
    }
  }),
  textFechaImgPost: ui.Textbox({
    //'placeholder': '',
    'value': "2023-10-01",
    'onChange': function (text) {
      m.fechas.FechaPost = text;
    },
  }),
  FIRMS: ui.Checkbox({
    label: "Active los focos de calor (FIRMS)",
    onChange: function (checked) {
      if (checked === true) {
        var dataset = ee.ImageCollection('FIRMS').filter(
          ee.Filter.date(c.fechas["textFechaImgPre"].getValue(), c.fechas["textFechaImgPost"].getValue()));
        var fires = dataset.select('T21');
        var firesVis = {
          min: 325.0,
          max: 400.0,
          palette: ['red', 'orange', 'yellow'],
        };
        var FIRMS_LAYER = ui.Map.Layer(fires, firesVis, "FIRMS");
        c.map.layers().set(4, FIRMS_LAYER);
      }
      else {
        tools.map.removeLayerByName("FIRMS", c.map);
      }
    }, "style": {
      'stretch': 'horizontal',
      "fontSize": "12px",
    }
  })
};
c.selectarea = {};
c.selectarea.departamento = {};
c.selectarea.departamento.label = ui.Label("Seleccione el departamento y municipio");
c.selectarea.departamento.selector = ui.Select({
  'items': [
    "Ninguno", "Beni", "Chuquisaca", "Cochabamba", "La Paz", "Oruro", "Pando", "Potosí", "Santa Cruz", "Tarija"
  ],
  'placeholder': 'Seleccione Departamento',
  'onChange': function (state) {
    if (state != 'Ninguno') {
      m.opciones.nombreActivo = state;
      updateDep();
      loadMunicipalitiesList(m.opciones.nombreDepartamento[state]);
    } else {
      // Si se selecciona 'Ninguno', limpiar el mapa y desactivar el municipio
      c.map.clear();
      m.opciones.limiteActivo = null;
      c.selectarea.municipio.selector.items().reset(["Ninguno"]);
      c.selectarea.municipio.selector.setDisabled(true);
    }
  },
  'style': {
    'stretch': 'horizontal'
  }
});
c.selectarea.municipio = {};
c.selectarea.municipio.label = ui.Label("Seleccione su municipio");
c.selectarea.municipio.selector = ui.Select({
  'items': ["Ninguno"],
  'placeholder': 'Ninguno',
  'style': {
    'stretch': 'horizontal'
  },
  "onChange": function (municipio) {
    if (municipio != "Ninguno") {
      m.opciones.nombreActivo = municipio;
      loadMunicipalitie(municipio);
    } else {
      // Si se selecciona 'Ninguno', utilizar el límite del departamento
      updateDep();
    }
  }
});
c.selectarea.panel = ui.Panel([
  c.selectarea.departamento.label,
  c.selectarea.departamento.selector,
  c.selectarea.municipio.label,
  c.selectarea.municipio.selector
]);
// Crear las herramientas de dibujo y añadirlas al mapa
var drawingTools = c.map.drawingTools();
// Configurar las herramientas de dibujo para permitir solo polígonos
drawingTools.setDrawModes(['polygon']);
drawingTools.setShape('polygon'); // Establece el modo inicial en polígono
drawingTools.layers().set(0, ui.Map.GeometryLayer({ name: 'Área dibujada', geometries: [] }));
// Crear una capa para los polígonos dibujados
drawingTools.onDraw(function (e) {
  var geometry = e; // Directamente usar e, ya que e es la geometría en este contexto
  // Actualizar m.opciones.limiteActivo con la geometría dibujada
  var feature = ee.Feature(geometry);
  var featureCollection = ee.FeatureCollection([feature]);
  m.opciones.limiteActivo = featureCollection;
  // Opcional: Añadir la geometría al mapa
  c.map.layers().set(0, ui.Map.Layer(ee.Image().byte().paint(featureCollection, 1, 2), {
    'palette': 'ffffff,ff0000',
    'min': 0,
    'max': 1
  }, 'Área Dibujada', true));
});
/*******************************************************************************
 * Funciones de Enmascaramiento *
 ******************************************************************************/
function maskS2sr(image) {
  // Seleccionar la banda SCL (Scene Classification Layer)
  var scl = image.select('SCL');
  // Usar MapBiomas para identificar áreas de agua (IDs de clase 26 y 33)
  var water = mapbiomasImage.eq(26).or(mapbiomasImage.eq(33));
  // Crear una máscara que identifique las sombras de nubes (valor 3), nubes de alta probabilidad (valor 9) y nubes de mediana probabilidad (valor 8)
  var cloudShadowMask = scl.eq(3); // Sombras de nubes
  var highProbCloudsMask = scl.eq(9); // Nubes de alta probabilidad
  var medProbCloudsMask = scl.eq(8); // Nubes de mediana probabilidad
  // Combinar las máscaras: los valores deben ser 0 para indicar zonas sin nubes ni sombras
  var mask = cloudShadowMask.or(highProbCloudsMask).or(medProbCloudsMask).or(water).not();
  // Aplicar la máscara a la imagen
  return image.updateMask(mask)
    .copyProperties(image, ["system:time_start"]);
}
function maskL8sr(image) {
  // Bits 3 y 5 son nubes y sombra de nubes, respectivamente.
  var cloudShadowBitMask = 1 << 3;
  var cloudsBitMask = 1 << 5;
  var snowBitMask = 1 << 4;
  // Extraer valores de la banda QA_PIXEL.
  var qa = image.select('QA_PIXEL');
  // Todos los valores deben ser definidos como cero, lo que indica buenas condiciones climáticas.
  var mask = qa.bitwiseAnd(cloudShadowBitMask).eq(0)
    .and(qa.bitwiseAnd(cloudsBitMask).eq(0))
    .and(qa.bitwiseAnd(snowBitMask).eq(0));
  // Regresa la imagen cortada y escalada a reflectancia en el tope de la atmósfera, sin las bandas QA.
  return image.updateMask(mask)
    .select("B[0-9]*")
    .copyProperties(image, ["system:time_start"]);
}
// Función para calcular NBR según el satélite
function calcularNBR(imagen) {
  if (m.fechas.SensorSelect === 0) {
    return imagen.normalizedDifference(['B8', 'B12']).rename('NBR');
  }
  else {
    return imagen.normalizedDifference(['B5', 'B7']).rename('NBR');
  }
}
var panelChart = ui.Panel({
  style: {
    width: '400px',
    padding: '8px'
  }
});
function getMapBiomasImageByYear(year) {
  // Si el año es mayor a 2023, usa la clasificación de 2023
  if (year > 2023) {
    year = 2023;
  }
  return dataset.select('classification_' + year);
}
/*******************************************************************************
 * Botón para Generar las Capas *
 ******************************************************************************/
c.crearcapas = ui.Button({
  label: "Generar índices de quema",
  onClick: function GenCQ() {
    // Comprobar si m.opciones.limiteActivo está definido
    if (!m.opciones.limiteActivo) {
      ui.alert('Por favor, seleccione un área de interés dibujándola en el mapa o seleccionando un departamento y municipio.');
      return;
    }
    // Obtener fechas de inicio y fin
    m.fechas.FechaPost = c.fechas["textFechaImgPost"].getValue();
    m.fechas.FechaPre = c.fechas["textFechaImgPre"].getValue();
    var prefuego = ee.Date(m.fechas.FechaPre);
    var postfuego = ee.Date(m.fechas.FechaPost);
    area = m.opciones.limiteActivo;
    c.map.centerObject(m.opciones.limiteActivo);
    // Obtener el año para MapBiomas
    var year = parseInt(m.fechas.FechaPost.substring(0, 4));
    mapbiomasImage = getMapBiomasImageByYear(year).clip(area);
    // Filtrar la colección de imágenes según el sensor seleccionado
    var prefuegoCol = ee.ImageCollection(ParamSensor.Id[m.fechas.SensorSelect])
      .filterDate(prefuego, postfuego)
      .filterBounds(area);
    if (m.fechas.SensorSelect === 0) { // Sentinel-2
      m.prefuego_CM_ImCol = prefuegoCol.map(maskS2sr).filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 30));
      var preNBR = m.prefuego_CM_ImCol.map(calcularNBR);
      m.minNBR = preNBR.min().clip(area);
      // Generar la capa de banda 8A con valores menores al umbral seleccionado
      m.banda8aMin = m.prefuego_CM_ImCol.select('B8A').min().clip(area);
      var banda8aMask = m.banda8aMin.lt(m.thresholdValue);
    } else { // Landsat 8
      m.prefuego_CM_ImCol = prefuegoCol.map(maskL8sr).filter(ee.Filter.lt('CLOUD_COVER', 30));
      var preNBR = m.prefuego_CM_ImCol.map(calcularNBR);
      m.minNBR = preNBR.min().clip(area);
      // Para Landsat 8, ajusta según sea necesario
      var banda8aMask = ee.Image(0);
    }
    // Combinar máscaras de NBR y banda 8A
    var quemasClasificadas = m.minNBR.lt(-0.20).or(banda8aMask).rename('quemas');
    // Aplicar filtro de mayoría
    var majorityKernel = ee.Kernel.square({ radius: 1 });
    var quemasSuavizadas = quemasClasificadas.focal_mode({ kernel: majorityKernel, iterations: 3 });
    // Enmascarar áreas de agua usando MapBiomas
    var water = mapbiomasImage.eq(26).or(mapbiomasImage.eq(33));
    quemasSuavizadas = quemasSuavizadas.updateMask(water.not());
    // Crear la máscara final
    mask = quemasSuavizadas.updateMask(quemasSuavizadas);
    // Visualizar la capa de clasificación de quemas
    m.clasificado = ui.Map.Layer(mask, { palette: ["#252525"] }, "Clasificación de quema");
    if (m.fechas.SensorSelect === 0) { // Sentinel-2
      // Seleccionar solo las bandas 11, 8A y 4 para el mosaico mínimo
      imagenVisualizadamin = m.prefuego_CM_ImCol.min().select(['B11', 'B8A', 'B4']).clip(area).toFloat();
    } else { // Landsat 8
      imagenVisualizadamin = null; // Ajusta según sea necesario
    }
    // Crear capa del mosaico mínimo
    if (imagenVisualizadamin !== null) {
      m.fechas.layerPre = ui.Map.Layer(imagenVisualizadamin, ParamSensor.Vis[m.fechas.SensorSelect], 'Mosaico de valores mínimos');
      c.map.layers().set(0, m.fechas.layerPre);
    } else {
      c.map.layers().set(0, ui.Map.Layer());
    }
    c.map.layers().set(1, m.clasificado);
    // Calcular el área quemada en hectáreas
    var areaLayer = ee.Image.pixelArea().divide(10000); // Convertir a hectáreas
    var areaImage = quemasSuavizadas.multiply(areaLayer);
    var areaha = areaImage.reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: area,
      bestEffort: true,
      scale: 30,
      maxPixels: 1e13
    });
    areacicatriz = Math.round(areaha.get('quemas').getInfo());
    print(areacicatriz + " Hectáreas");
    // Generar BA_vector para exportación con escala de 100 metros
    BA_vector = mask.reduceToVectors({
      geometry: area,
      scale: 30, // Ajustamos la escala a 100 metros
      geometryType: 'polygon',
      eightConnected: false,
      maxPixels: 1e13
    });
    // Generar el enlace de descarga para BA_vector en formato 'shp'
    var urlClass = BA_vector.getDownloadURL('shp', null, 'AQ-Municipio_' + m.opciones.nombreActivo);
    print(urlClass); // Para verificar que se genera el URL
    // Mostrar el enlace en la interfaz de usuario
    var downloadLink = ui.Label({
      value: 'Descargar Cicatrices de Quema (SHP)',
      targetUrl: urlClass,
      style: { fontSize: '14px', color: 'blue' }
    });
    c.controlPanel.add(downloadLink);
    // Generar URL de descarga para el mosaico mínimo (imagen)
    if (imagenVisualizadamin !== null) {
      var urlImage = imagenVisualizadamin.getDownloadURL({
        name: 'Mosaico_Minimo',
        scale: 100, // Ajustamos la escala a 100 metros
        region: area.geometry().bounds(),
        crs: 'EPSG:4326', // Puedes especificar el sistema de coordenadas
        format: 'GeoTIFF', // Formato GeoTIFF
      });
      print(urlImage); // Para verificar que se genera el URL
      // Mostrar el enlace de descarga para la imagen
      var downloadLinkImage = ui.Label({
        value: 'Descargar Mosaico Mínimo (GeoTIFF)',
        targetUrl: urlImage,
        style: { fontSize: '14px', color: 'blue' }
      });
      c.controlPanel.add(downloadLinkImage);
    }
    // Mostrar el área de cicatriz en el panel
    if (c.areaquemas) {
      c.controlPanel.remove(c.areaquemas);
    }
    c.areaquemas = ui.Label('Área de quemas: ' + areacicatriz + ' Hectáreas');
    c.controlPanel.add(c.areaquemas);
    // Ajustar el diccionario de tipos de cobertura según MapBiomas
    var landCoverTypes = {
      'Formación boscosa': 1,
      'Bosque': 3,
      'Bosque abierto': 4,
      'Bosque inundable': 6,
      'Formación natural no forestal': 10,
      'Formación natural no forestal inundable': 11,
      'Formación campestre o herbazal': 12,
      'Afloramiento rocoso': 29,
      'Matorral': 66,
      'Otra formación natural no forestal': 13,
      'Agropecuario': 14,
      'Pastura': 15,
      'Agricultura': 18,
      'Mosaico de usos': 21,
      'Área sin vegetación': 22,
      'Playa, duna o banco de arena': 23,
      'Infraestructura urbana': 24,
      'Otra área antrópica sin vegetación': 25,
      'Cuerpo de agua': 26,
      'Río, lago': 33,
      'Glaciar': 34,
      'Salar': 61,
      'Otra área sin vegetación': 68,
      'No observado': 27
    };
    if (currentChart !== null) {
      c.controlPanel.remove(currentChart);
    }
    // Función para calcular el área quemada por tipo de cobertura
    var calculateBurnedAreaByLandCover = function (landCoverType, landCoverValue, callback) {
      // Crear una máscara para el tipo de cobertura actual
      var landCoverMask = mapbiomasImage.eq(landCoverValue);
      // Superponer la máscara de cobertura con la máscara de quemas
      var burnedAreaByLandCover = mask.updateMask(landCoverMask);
      var burnedAreaPixel = burnedAreaByLandCover.multiply(ee.Image.pixelArea().divide(10000)); // Hectáreas
      // Calcular el área total quemada en este tipo de cobertura
      var totalBurnedArea = burnedAreaPixel.reduceRegion({
        reducer: ee.Reducer.sum(),
        geometry: area,
        scale: 30,
        maxPixels: 1e11
      });
      // Usar evaluate para obtener el resultado de forma asíncrona
      totalBurnedArea.evaluate(function (result) {
        var areaBurned = result.quemas;
        // Verificar si el resultado es válido antes de llamar al callback
        if (areaBurned) {
          var areaBurnedRounded = Math.round(areaBurned);
          callback(landCoverType, areaBurnedRounded);
        } else {
          callback(landCoverType, 0); // Enviar 0 si el resultado no es válido
        }
      });
    };
    // Inicializar una lista para almacenar los datos del gráfico
    var chartData = [];
    var asyncCounter = 0;
    // Función de callback llamada cuando una operación asíncrona completa
    var onCalculateBurnedAreaComplete = function (landCoverType, areaBurned) {
      // Añadir resultados a la lista de datos del gráfico
      chartData.push({ landCoverType: landCoverType, "area quemada": areaBurned });
      asyncCounter++;
      // Verificar si todas las operaciones asíncronas han completado
      if (asyncCounter === Object.keys(landCoverTypes).length) {
        // Todas las cálculos han finalizado, generar el gráfico
        var chartFeatureCollection = ee.FeatureCollection(chartData.map(function (item) {
          return ee.Feature(null, item);
        }));
        var burnedAreaChart = ui.Chart.feature.byFeature(chartFeatureCollection, 'landCoverType', 'area quemada')
          .setChartType('ColumnChart')
          .setOptions({
            title: 'Área Quemada por Tipo de Cobertura',
            hAxis: { title: 'Tipo de Cobertura' },
            vAxis: { title: 'Área Quemada (Ha)' },
            legend: { position: 'none' }
          });
        // Añadir el gráfico al panel de control
        currentChart = burnedAreaChart;
        c.controlPanel.add(currentChart);
      }
    };
    // Iterar sobre el diccionario y calcular el área quemada para cada tipo de cobertura
    for (var landCoverType in landCoverTypes) {
      var landCoverValue = landCoverTypes[landCoverType];
      calculateBurnedAreaByLandCover(landCoverType, landCoverValue, onCalculateBurnedAreaComplete);
    }
    m.fechas.GenImg = true;
  }
});
/*******************************************************************************
 * Control Deslizante para Ajustar el Umbral *
 ******************************************************************************/
c.thresholdLabel = ui.Label('Umbral para Banda 8A Mask');
c.thresholdSlider = ui.Slider({
  min: 1000,
  max: 3000,
  value: m.thresholdValue,
  step: 10,
  onChange: function (value) {
    m.thresholdValue = value;
    // Recalcular la capa de cicatriz de quema
    if (m.fechas.SensorSelect === 0 && m.minNBR && m.banda8aMin) {
      // Recalcular banda8aMask con el nuevo umbral
      var banda8aMask = m.banda8aMin.lt(m.thresholdValue);
      // Recalcular quemasClasificadas
      var quemasClasificadas = m.minNBR.lt(-0.20).or(banda8aMask).rename('quemas');
      // Aplicar filtro de mayoría
      var majorityKernel = ee.Kernel.square({ radius: 1 });
      var quemasSuavizadas = quemasClasificadas.focal_mode({ kernel: majorityKernel, iterations: 3 });
      // Enmascarar áreas de agua usando MapBiomas
      var water = mapbiomasImage.eq(26).or(mapbiomasImage.eq(33));
      quemasSuavizadas = quemasSuavizadas.updateMask(water.not());
      // Actualizar la máscara
      mask = quemasSuavizadas.updateMask(quemasSuavizadas);
      // Crear nueva capa de clasificación de quemas
      m.clasificado = ui.Map.Layer(mask, { palette: ["#252525"] }, "Clasificación de quema");
      // Reemplazar la capa existente en el mapa
      c.map.layers().set(1, m.clasificado);
      // Recalcular el área
      var areaLayer = ee.Image.pixelArea().divide(10000); // Hectáreas
      var areaImage = quemasSuavizadas.multiply(areaLayer);
      var areaha = areaImage.reduceRegion({
        reducer: ee.Reducer.sum(),
        geometry: area,
        bestEffort: true,
        scale: 30,
        maxPixels: 1e13
      });
      areacicatriz = Math.round(areaha.get('quemas').getInfo());
      // Actualizar la etiqueta del área en la UI
      if (c.areaquemas) {
        c.controlPanel.remove(c.areaquemas);
      }
      c.areaquemas = ui.Label('Área de quemas: ' + areacicatriz + ' Hectáreas');
      c.controlPanel.add(c.areaquemas);
    }
  },
  style: {
    stretch: 'horizontal'
  }
});
/*******************************************************************************
 * Composición de la Interfaz de Usuario *
 ******************************************************************************/
ui.root.clear();
ui.root.add(ui.SplitPanel(c.controlPanel, c.map));
// Añadir elementos al panel de control
c.controlPanel.add(c.logo);
c.controlPanel.add(c.info.panel);
c.controlPanel.add(c.dateSensor.panel);
c.controlPanel.add(c.fechas.labelFechaImgPre);
c.controlPanel.add(c.fechas.textFechaImgPre);
c.controlPanel.add(c.fechas.labelFechaImgPost);
c.controlPanel.add(c.fechas.textFechaImgPost);
c.controlPanel.add(c.fechas.FIRMS);
// Añadir el control deslizante al panel de control
c.controlPanel.add(c.thresholdLabel);
c.controlPanel.add(c.thresholdSlider);
// Añadir el panel de selección de área al panel de control
c.controlPanel.add(c.selectarea.panel);
// Añadir el botón para generar capas al panel de control
c.controlPanel.add(c.crearcapas);
/*******************************************************************************
 * Estilización *
 ******************************************************************************/
var s = {};
c.controlPanel.style().set({
  width: "275px"
});
/*******************************************************************************
 * Funciones Auxiliares *
 ******************************************************************************/
function updateDep() {
  var dep = c.selectarea.departamento.selector.getValue();
  if (dep != 'Ninguno') {
    var lim = m.opciones.departamentos.filter(ee.Filter.eq("DEPARTAMEN", dep));
    // Actualizar m.opciones.limiteActivo al límite del departamento seleccionado
    m.opciones.limiteActivo = lim;
    c.map.clear();
    var limite = ui.Map.Layer(ee.Image().byte().paint(lim, 1, 2), {
      'palette': 'ffffff,ff0000',
      'min': 0,
      'max': 1
    },
      'Departamento de ' + dep,
      true);
    c.map.layers().set(0, limite);
    c.map.centerObject(lim);
  } else {
    // Si se selecciona 'Ninguno', limpiar el mapa y desactivar el municipio
    c.map.clear();
    m.opciones.limiteActivo = null;
    c.selectarea.municipio.selector.items().reset(["Ninguno"]);
    c.selectarea.municipio.selector.setDisabled(true);
  }
}
function loadMunicipalitiesList(state) {
  c.selectarea.municipio.selector.setPlaceholder('Cargando Nombres...');
  ee.List(m.opciones.municipios
    .filterMetadata('UF', 'equals', parseInt(state, 10))
    .reduceColumns(ee.Reducer.toList(), ['MUNICIPIO'])
    .get('list'))
    .sort()
    .evaluate(function (municipio, errorMsg) {
      m.opciones.nombresMunicipio = municipio;
      // Actualizar el selector de municipios con el onChange adecuado
      c.selectarea.municipio.selector.items().reset(["Ninguno"].concat(municipio));
      c.selectarea.municipio.selector.setDisabled(false);
    });
}
function loadMunicipalitie(municipio) {
  var uf = m.opciones.nombreDepartamento[c.selectarea.departamento.selector.getValue()];
  // Actualizar m.opciones.limiteActivo al municipio seleccionado
  m.opciones.limiteActivo = m.opciones.municipios
    .filterMetadata('MUNICIPIO', 'equals', municipio)
    .filterMetadata('UF', 'equals', parseInt(uf, 10));
  c.map.clear();
  c.map.addLayer(ee.Image().byte().paint(m.opciones.limiteActivo, 1, 2), {
    'palette': 'ffffff,ff0000',
    'min': 0,
    'max': 1
  },
    'Municipio de ' + municipio,
    true);
  c.map.centerObject(m.opciones.limiteActivo);
  return m.opciones.limiteActivo;
}
c.selectarea.departamento.selector.onChange(updateDep);
c.selectarea.municipio.selector.onChange(function (municipio) {
  if (municipio != 'Ninguno') {
    m.opciones.nombreActivo = municipio;
    loadMunicipalitie(municipio);
  } else {
    // Si se selecciona 'Ninguno', utilizar el límite del departamento
    updateDep();
  }
});
// Asegurarnos de que al inicio, el selector de municipios está vacío y deshabilitado
c.selectarea.municipio.selector.items().reset(["Ninguno"]);
c.selectarea.municipio.selector.setDisabled(true);
/*******************************************************************************
 * Funciones para Formatear Mes y Día *
 ******************************************************************************/
function GetMesT(mes) {
  var r = '';
  if (mes < 10)
    r = '0' + mes;
  else
    r = mes.toString();
  return r;
}
function GetDiaT(dia) {
  var r = '';
  if (dia < 10)
    r = '0' + dia;
  else
    r = dia.toString();
  return r;
}