var valiapp = require('users/fitoprincipe/ValiApp:main')
var app = new valiapp.App()
app.run()