var padang = ui.import && ui.import("padang", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                100.32441803621248,
                -0.91619535363189
              ],
              [
                100.33782644906103,
                -0.9821485070796748
              ],
              [
                100.32669434649816,
                -1.117035642650335
              ],
              [
                100.36042086927671,
                -1.146293040822041
              ],
              [
                100.3980958354774,
                -1.1312703572175002
              ],
              [
                100.44288915167738,
                -1.0668980818356424
              ],
              [
                100.376791889786,
                -0.9282097649417186
              ],
              [
                100.30443459388376,
                -0.802736559197458
              ],
              [
                100.2950305959053,
                -0.8072868105444445
              ],
              [
                100.29135855341251,
                -0.8043267643137978
              ],
              [
                100.28883589044187,
                -0.8067087337951456
              ],
              [
                100.29169442803038,
                -0.8124482868605353
              ],
              [
                100.28622738075039,
                -0.8193034891835381
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[100.32441803621248, -0.91619535363189],
          [100.33782644906103, -0.9821485070796748],
          [100.32669434649816, -1.117035642650335],
          [100.36042086927671, -1.146293040822041],
          [100.3980958354774, -1.1312703572175002],
          [100.44288915167738, -1.0668980818356424],
          [100.376791889786, -0.9282097649417186],
          [100.30443459388376, -0.802736559197458],
          [100.2950305959053, -0.8072868105444445],
          [100.29135855341251, -0.8043267643137978],
          [100.28883589044187, -0.8067087337951456],
          [100.29169442803038, -0.8124482868605353],
          [100.28622738075039, -0.8193034891835381]]]);
//center map to padang
Map.setCenter(100.3533, -1.0076, 11);
//import data from asset
var mangrove2000 = ee.ImageCollection('LANDSAT/MANGROVE_FORESTS').filterBounds(padang)
                  .map(function(image){return image.clip(padang)});
var mangrove2016 = ee.Image ('users/fakhrurrozi/padang/mangrove_2016');
var mangrove2017 = ee.Image ('users/fakhrurrozi/padang/mangrove_2017');
var mangrove2018 = ee.Image ('users/fakhrurrozi/padang/mangrove_2018');
var mangrove2019 = ee.Image ('users/fakhrurrozi/padang/mangrove_2019');
var mangrove2020 = ee.Image ('users/fakhrurrozi/padang/mangrove_2020');
var mangrove2021 = ee.Image ('users/fakhrurrozi/padang/mangrove_2021');
//Map.addLayer(mangrove2000)
//set up a satellite background
Map.setOptions('satellite')
//change style of cursor to 'crosshair'
Map.style().set('cursor', 'crosshair');
//create variables for GUI layers for each layer
//set to false, so the user can turn them on later
var mang2000 = ui.Map.Layer (mangrove2000, {palette: ['#ff0404'], min:1, max:1}, 'Tahun 2000',false);
var mang2016 = ui.Map.Layer (mangrove2016, {palette: ['#ffac14'], min:1, max:1}, 'Tahun 2016',false);
var mang2017 = ui.Map.Layer (mangrove2017, {palette: ['#f1ff16'], min:1, max:1}, 'Tahun 2017',false);
var mang2018 = ui.Map.Layer (mangrove2018, {palette: ['#6dff12'], min:1, max:1}, 'Tahun 2018',false);
var mang2019 = ui.Map.Layer (mangrove2019, {palette: ['#08e8ff'], min:1, max:1}, 'Tahun 2019',false);
var mang2020 = ui.Map.Layer (mangrove2020, {palette: ['#083dff'], min:1, max:1}, 'Tahun 2020',false);
var mang2021 = ui.Map.Layer (mangrove2021, {palette: ['#a900ff'], min:1, max:1}, 'Tahun 2021',false);
//add layer to map
Map.add(mang2000)
Map.add(mang2016)
Map.add(mang2017)
Map.add(mang2018)
Map.add(mang2019)
Map.add(mang2020)
Map.add(mang2021)
//3.1) Set up title and summary widgets
//App title
var header = ui.Label('Mangrove Inspector', {fontSize: '25px', fontWeight: 'bold', color: '4A997E'});
//App summary
var text = ui.Label(
  'This tool maps mangrove extent at Padang in 2000 until 2021 using Random forest classification derived from landsat and sentinel imagery. ' +
  'Use the tools below to explore changes in mangrove extent',
    {fontSize: '15px'});
//3.2) Create a panel to hold text
var panel = ui.Panel({
  widgets:[header, text],//Adds header and text
  style:{width: '300px',position:'middle-right'}});
//3.3) Create variable for additional text and separators
//This creates another panel to house a line separator and instructions for the user
var intro = ui.Panel([
  ui.Label({
    value: '____________________________________________',
    style: {fontWeight: 'bold',  color: '4A997E'},
  }),
  ui.Label({
    value:'Select layers to display.',
    style: {fontSize: '15px', fontWeight: 'bold'}
  })]);
//Add this new panel to the larger panel we created 
panel.add(intro)
//3.4) Add our main panel to the root of our GUI
ui.root.insert(1,panel)
///////////////////////////////////////////////////////////////
//         4) Add checkbox widgets and legends               //
///////////////////////////////////////////////////////////////
//4.1) Create a new label for this series of checkboxes
var extLabel = ui.Label({value:'Mangrove Extent',
style: {fontWeight: 'bold', fontSize: '16px', margin: '10px 5px'}
});
//4.2) Add checkboxes to our display
//Create checkboxes that will allow the user to view the extent map for different years
//Creating the checkbox will not do anything yet, we add functionality further 
// in the code
var extCheck = ui.Checkbox('2000').setValue(false); //false = unchecked
var extCheck2 = ui.Checkbox('2016').setValue(false);
var extCheck3 = ui.Checkbox('2017').setValue(false);
var extCheck4 = ui.Checkbox('2018').setValue(false);
var extCheck5 = ui.Checkbox('2019').setValue(false);
var extCheck6 = ui.Checkbox('2020').setValue(false);
var extCheck7 = ui.Checkbox('2021').setValue(false);
//4.3) Create legends
//The following code creates legends we can add to the panel
//Extent Legend
///////////////
// Set position of panel
var extentLegend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// The following creates and styles 1 row of the legend.
var makeRowa = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create a label with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // Return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//Create a palette using the same colors we used for each extent layer
var paletteMAPa = [
'ff0404',//2000
'ffac14',//2016
'f1ff16',//2017
'6dff12',//2018
'08e8ff',//2019
'083dff',//2020
'a900ff',//2021
];
// Name of each legend value
var namesa = ['2000','2016','2017', '2018', '2019', '2020', '2021']; 
// Add color and names to legend
for (var i = 0; i < 7; i++) {
  extentLegend.add(makeRowa(paletteMAPa[i], namesa[i]));
  }  
//4.4) Add these new widgets to the panel in the order you want them to appear
panel.add(extLabel)
      .add(extCheck)
      .add(extCheck2)
      .add(extCheck3)
      .add(extCheck4)
      .add(extCheck5)
      .add(extCheck6)
      .add(extCheck7)
      .add(extentLegend);
///////////////////////////////////////////////////////////////
//          5) Add functionality to widgets                  //
///////////////////////////////////////////////////////////////
//For each checkbox we create function so that clicking the checkbox
//Turns on layers of interest
//Mangrove 2000
var doCheckbox = function() {
  extCheck.onChange(function(checked){
  mang2000.setShown(checked);
  });
};
doCheckbox();
//Mangrove 2016
var doCheckbox = function() {
  extCheck2.onChange(function(checked){
  mang2016.setShown(checked);
  });
};
doCheckbox();
//Mangrove 2017
var doCheckbox = function() {
  extCheck3.onChange(function(checked){
  mang2017.setShown(checked);
  });
};
doCheckbox();
//Mangrove 2018
var doCheckbox = function() {
  extCheck4.onChange(function(checked){
  mang2018.setShown(checked);
  });
};
doCheckbox();
//Mangrove 2019
var doCheckbox = function() {
  extCheck5.onChange(function(checked){
  mang2019.setShown(checked);
  });
};
doCheckbox();
//Mangrove 2020
var doCheckbox = function() {
  extCheck6.onChange(function(checked){
  mang2020.setShown(checked);
  });
};
doCheckbox();
//Mangrove 2021
var doCheckbox = function() {
  extCheck7.onChange(function(checked){
  mang2021.setShown(checked);
  });
};
doCheckbox();