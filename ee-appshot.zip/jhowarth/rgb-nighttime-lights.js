//  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  name:     rgbLights.js
//  purpose:  RGB of stable nighttime lights (1993-2013)
//
//  author:   Jeff Howarth
//  update:   11/20/2021  
//  license:  Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
//  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  load images, select stable lights band, rename after year
var lights93 = ee.Image('NOAA/DMSP-OLS/NIGHTTIME_LIGHTS/F101993')
  .select('stable_lights').rename('1993');
var lights03 = ee.Image('NOAA/DMSP-OLS/NIGHTTIME_LIGHTS/F152003')
  .select('stable_lights').rename('2003');
var lights13 = ee.Image('NOAA/DMSP-OLS/NIGHTTIME_LIGHTS/F182013')
  .select('stable_lights').rename('2013');
//  construct three band image
var changeImage = lights13.addBands(lights03).addBands(lights93);
//  add image to map
Map.setCenter(126.8, 33.485, 5);
Map.setOptions('HYBRID');
Map.setControlVisibility({drawingToolsControl: false});
Map.addLayer(changeImage, {min:0,max:63}, "RGB composite", 1, 1);
//  
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px',
    backgroundColor: '#000000'
  }
});
var title = ui.Label({
  value: "LIGHTS AT NIGHT",
  style: {
    fontWeight: '900',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0',
    color:'FFF3DD',
    backgroundColor:'#000000'
    }
  });
var red = ui.Label({
  value: "2013",
  style: {
    fontWeight: '800',
    fontSize: '12px',
    margin: '0 0 4px 0',
    padding: '0',
    color:'Red',
    backgroundColor:'#000000'
    }
  });
var green = ui.Label({
  value: "2003",
  style: {
    fontWeight: '800',
    fontSize: '12px',
    margin: '0 0 4px 0',
    padding: '0',
    color:'Green',
    backgroundColor:'#000000'
    }
  });
var blue = ui.Label({
  value: "1993",
  style: {
    fontWeight: '800',
    fontSize: '12px',
    margin: '0 0 4px 0',
    padding: '0',
    color:'Blue',
    backgroundColor:'#000000'
    }
  });
var credits = ui.Label({
  value: "more info",
  style: {
    fontWeight: '100',
    fontSize: '10px',
    margin: '0 0 4px 0',
    padding: '0',
    color:'FFF3DD',
    backgroundColor:'#000000'
    },
  targetUrl: 'https://github.com/jeffhowarth/gimplements/blob/main/RGB/lights.md'
  });
legend.add(title).add(red).add(green).add(blue).add(credits);
Map.add(legend);