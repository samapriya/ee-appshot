// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  TITLE:   Changes in the Night App
//  AUTHOR:  Jeff Howarth
//  DATE:    11/28/2023
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
//  Define type taxonomy
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
// Dictionary for typeface (common styles for all labels)
var typeface = 
  {
    sans: 'Helevetica, sans-serif',
    padding: '12px',
    margin: '4px',
    textAlign: 'left',
    position: 'top-left',
    whiteSpace: 'wrap',
    backgroundColor: 'black',
    color: 'LightYellow'
  }
;
// Dictionary for visual hierarchy.
var hierarchy = {
  title: {
    padding: typeface.padding,
    margin: typeface.margin,
    backgroundColor: typeface.backgroundColor,
    color: typeface.color,
    fontSize: '32px',
    fontWeight: 'bold',
    fontFamily: typeface.sans,
    textAlign: typeface.textAlign,
    position: typeface.position,
    whiteSpace: typeface.whiteSpace,
    stretch: 'horizontal'
    },
  body: {
    padding: typeface.padding,
    margin: typeface.margin,
    backgroundColor: typeface.backgroundColor,
    color: typeface.color,
    fontSize: '14px',
    fontWeight: 'normal',
    fontFamily: typeface.sans,
    textAlign: typeface.textAlign,
    position: typeface.position,
    whiteSpace: typeface.whiteSpace,
    stretch: 'horizontal'
  },
  note: {
    padding: typeface.padding,
    margin: typeface.margin,
    backgroundColor: typeface.backgroundColor,
    color: typeface.color,
    fontSize: '10px',
    fontWeight: 'normal',
    fontFamily: typeface.sans,
    textAlign: typeface.textAlign,
    position: typeface.position,
    whiteSpace: 'pre',
    stretch: 'horizontal'
  },
}
;
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
//  Labels 
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
// Write a title for your map.
var title = ui.Label(
  {
    value: "Changes in the Night",
    style: hierarchy.title
  });
// Write a short description of the purpose of the map. 
var abstract = ui.Label(
  {
    value: "This image uses additive color to show changes in the average annual magnitude of stable nighttime lights between 1993 and 2013.",
    style: hierarchy.body
  });
// Provide instructions for using the map. 
var instructions = ui.Label(
  {
    value: "Click on the link below for an overview of the different patterns of changes that are visible in the image and select a name from the list below to zoom to different examples.",
    style: hierarchy.body
  });
// Provide a link to a narrative that helps people interpret what the map shows. 
var storyLink = ui.Label(
  {
    value: "Link to descriptions of patterns",
    targetUrl: "https://jeffhowarth.github.io/eeprimer/glossary/nighttime-light-patterns/",
    style: hierarchy.body
  });
//  Give credit to yourself and the course
var credits = ui.Label(
  {
    value: "Jeff Howarth\nGeography 251\nFall 2023\nMiddlebury College",
    style: hierarchy.note
  });
var source = ui.Label(
  {
    value: "source",
    targetUrl: "https://jeffhowarth.github.io/eeprimer/workflows/changes-in-the-night/",
    style: hierarchy.note
  });
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
//  Side Panel
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
var side_panel = ui.Panel(
  {
    widgets: [
      title,
      abstract, 
      instructions,
      storyLink,
      credits,
      source
      ],
    layout: ui.Panel.Layout.flow('vertical'),
    style: {
      width: '25%',
      backgroundColor: 'black'
    }
  }
  )
;
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
//  Map Widget 
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
var map = ui.Map()
;    
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
//  Split Panel
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
var split_panel = ui.SplitPanel(
  {
    firstPanel: side_panel,
    secondPanel: map,
    orientation: 'horizontal',
    wipe: false
  })
;
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
//  Initialize Layout
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
ui.root.clear();
ui.root.add(split_panel);
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
//  Recycle map content from script.
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  Name:     changes_in_the_night.js 
//  Author:   Jeff Howarth
//  Date:     10/10/2023 
//  Purpose:  Introduce additive color, nighttime lights, and patterns of change.
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
// -----------------------------------------------------------------------
//  Load image collection and select a band.  
// -----------------------------------------------------------------------
// Image Collection pathname: "NOAA/DMSP-OLS/NIGHTTIME_LIGHTS"
// Band: "stable_lights"
var collection = ee.ImageCollection("NOAA/DMSP-OLS/NIGHTTIME_LIGHTS")
  .select(["stable_lights"])
;
// print(
//   "Collection",
//   collection,
//   collection.size(),                            
//   collection.first(),
//   collection.first().bandNames()                
//   )
// ;
// -----------------------------------------------------------------------
//  Create a dictionary for study years to assign band 1, 2, 3
// -----------------------------------------------------------------------
// Your goal is to display pixel values in each layer with these colors:
//  2013 with red,
//  2003 with green,
//  1992 with blue.
var yrs = {
  b1: 2013,           // Display with red channel
  b2: 2003,           // Display with green channel
  b3: 1993,           // Display with blue channel
  unit: "year"
};
// print(
//   "Study years:",
//   yrs
// );
// // -----------------------------------------------------------------------
// //  Make an image for band 1  
// // -----------------------------------------------------------------------
// var b1 = collection.filter(ee.Filter.calendarRange(yrs.b1, yrs.b1, yrs.unit))
//   .first()
//   .rename(String(yrs.b1))
// ;
// print(
//   "Band 1:",
//   b1
//   )
// ;
// // -----------------------------------------------------------------------
// //  Display image as layer on the map.
// // -----------------------------------------------------------------------
// Map.setCenter(126.8, 33.485, 5);
// Map.setOptions('HYBRID');
// var viz = {min: 0, max: 63};
// Map.addLayer(b1, viz, String(yrs.b1), false);
// // -----------------------------------------------------------------------
// //  Make and display image for band 2.  
// // -----------------------------------------------------------------------
// var b2 = collection.filter(ee.Filter.calendarRange(yrs.b2, yrs.b2, yrs.unit))
//   .mean()
//   .rename(String(yrs.b2))
// ;
// print(
//   "Band 2:",
//   b2
//   )
// ;
// Map.addLayer(b2, viz, String(yrs.b2), false);
// -----------------------------------------------------------------------
//  Write a function  
// -----------------------------------------------------------------------
var makeImageForBand = function(yr) {
  var band = collection.filter(ee.Filter.calendarRange(yr, yr, yrs.unit))
    .mean()
    .rename(String(yr));
  return band;
};
// // Call the function
// var b1_test = makeImageForBand(yrs.b1) ;
// print(
//   "Function Test B1:",
//   b1_test
// );
// // Display result as a layer. 
// Map.addLayer(b1_test, viz, String(yrs.b1), false);
// // -----------------------------------------------------------------------
// //  Test generality of function.  
// // -----------------------------------------------------------------------
// // Does .first() and .mean() deliver identical results for b1 case?
// var test = b1.subtract(b1_test);
// Map.addLayer(test, {min: -10, max: 10}, "Difference layer");
 // -----------------------------------------------------------------------
//  Revise script to apply function. 
// -----------------------------------------------------------------------
// 1. Comment out sections above that made and drew b1 and b2;
// 2. Redefine map options and viz parameters (that were commented out).
map.setCenter(126.8, 33.485, 5);
map.setOptions('HYBRID');
var viz = {min:0, max: 63};
// 3. Call function to remake all bands
var b1 = makeImageForBand(yrs.b1);
var b2 = makeImageForBand(yrs.b2);
var b3 = makeImageForBand(yrs.b3);
// print(
//   "Bands:",
//   b1,
//   b2,
//   b3
//   )
// ;
// 4. Add results as layers to map.
// Map.addLayer(b1, viz, String(yrs.b1), false);
// Map.addLayer(b2, viz, String(yrs.b2), false);
// Map.addLayer(b3, viz, String(yrs.b3), false);
// 
// -----------------------------------------------------------------------
//  Construct and display three band image from the three images.  
// -----------------------------------------------------------------------
// Create image. 
var change_image = b1   // Red channel
  .addBands(b2)         // Green channel
  .addBands(b3)         // Blue channel
;
// print(
//   "Change Image",
//   change_image
//   )
// ;
// Display result as a map layer. 
map.addLayer(change_image, viz, "Change Image");
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
//  Select Widget
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
var select_style = 
  {
    padding: typeface.padding,
    margin: typeface.margin,
    stretch: 'horizontal',
    backgroundColor: typeface.backgroundColor,
    fontFamily: typeface.sans
  }
;
var patterns = {
  'Flame': [121.454780, 31.222945, 6],
  'Aurora': [129.869311, 34.755374, 6],
  'Holiday lights': [75.171582, 62.896614, 6],
  'Holiday lights (2)': [6.600422, 5.053419, 6],
  'Red giant': [-103.072580, 48.261784, 6],
  'Political lines': [74.341854, 30.785147, 6]
};
var select_pattern = ui.Select({
  items: Object.keys(patterns),
  placeholder: 'Explore a pattern',
  style: select_style,
  onChange: function(key) {
    map.setCenter(patterns[key][0], patterns[key][1], patterns[key][2]);
  }
});
side_panel.insert(4, select_pattern);