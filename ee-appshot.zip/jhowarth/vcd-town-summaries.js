//  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  name:     vcd.js
//  purpose:  Make image from VCD vector components
//
//  author:   Jeff Howarth 
//  update:   2/25/2022  
//  license:  Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
//  To do: remove lakes
//  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Load modules
var data = require('users/jhowarth/cd-usa-vt-middlebury:modules/data.js');
var cart = require('users/jhowarth/cd-usa-vt-middlebury:modules/cart.js');
// Load prior layers to build on. 
var study_regions = require('users/jhowarth/cd-usa-vt-middlebury:layers/study_regions.js');
// var lc = require('users/jhowarth/cd-usa-vt-middlebury:layers/land-cover.js');
// var lidar = require('users/jhowarth/cd-usa-vt-middlebury:layers/hillshades.js');
// var pro = require('users/jhowarth/cd-usa-vt-middlebury:layers/parcels-with-protections.js');
// -------------------------------------------------------------------------------------
// Config dictionary
// -------------------------------------------------------------------------------------
var config = 
  {
    town: "CORNWALL",
    zoom: 12,
    select_style: {color: '#FFFF00', fillColor: '00000000', width: 5}
  }
;
// -------------------------------------------------------------------------------------
// Make study regions. 
// -------------------------------------------------------------------------------------
// Load the administrative regions dictionary from study regions layer module. 
var region = study_regions.region;
// print('REGIONS', region);
// Define study region here to facilitate changing it later. 
region.town.fc = ee.FeatureCollection(region.town.fc_address);
// print(
//   'TOWNS', 
//   region.town.fc.aggregate_array('TOWNNAME').distinct().sort()
//   )
// ;
var makeTargetTown = function(name){
  var target = region.town.fc
    .filter(ee.Filter.eq('TOWNNAME', name))
    ;
  return target;
};
// -------------------------------------------------------------------------------------
// Make town list
// -------------------------------------------------------------------------------------
var makeString = function(input) {
  return ee.String(input);
};
var town_list = region.town.fc.aggregate_array('TOWNNAME').distinct().sort().map(makeString);
// print(town_list);
var town_dictionary = ee.Dictionary.fromLists(town_list, ee.List.sequence(0, town_list.length().subtract(1)));
// print(town_dictionary);
// -------------------------------------------------------------------------------------
// Compose layout
// -------------------------------------------------------------------------------------
// Use cart tool to make layout dictionary.  
var layout = cart.makeLayout();
// Print the dictionary. 
// print('LAYOUT', layout);
//  Clear root.
//  Then add split panel from layout dictionary to root.
ui.root.clear();
ui.root.add(layout.split_panel);
layout.map.setOptions('HYBRID');
// -------------------------------------------------------------------------------------
// Add title and subtitle to panel. 
// -------------------------------------------------------------------------------------
// Make label dictionary. 
// Use cart tool to populate with title, subtitle, land acknowledgement, and credits. 
var labels = {
  title: cart.makeTitle('Vermont Conservation Design'), 
  ack: cart.makeAck('Middlebury is unceded Abenaki land.'),
  vcd: cart.makeCredits('background', 'https://vtfishandwildlife.com/conserve/vermont-conservation-design'),
  credits: cart.makeCredits('Jeff Howarth\nGeography Dept\nMiddlebury College', 'https://jeffhowarth.github.io/')
};
// Print the dictionary to inspect. 
// print('LABELS', labels);
// Make dynamic panel
var dyno = ui.Panel();
// Add the title and subtitle to the layout panel. 
layout.panel
  .add(labels.title)
  .add(labels.vcd)
  .add(dyno)
;
// -------------------------------------------------------------------------------------
// Define study regions.  
// -------------------------------------------------------------------------------------
// Load the administrative regions dictionary from study regions layer module. 
var region = study_regions.region;
// print('REGIONS', region);
// Define study region here to facilitate changing it later. 
var study_region = region.planning.ac;
// Center layout on study region with z 12.
layout.map.centerObject(makeTargetTown(config.town), 11);
// -------------------------------------------------------------------------------------
// Make image  
// -------------------------------------------------------------------------------------
// Initialize a dictionary.
var vcd = data.vcd;
// Make a binary image from each element feature collection. 
vcd.L1a.i = data.fcMakeBinaryImage(data.fcFilterByRegion(vcd.L1a.fc_address, study_region))
  .unmask().rename(vcd.L1a.layer_name);
vcd.L1b.i = data.fcMakeBinaryImage(data.fcFilterByRegion(vcd.L1b.fc_address, study_region))
.unmask().rename(vcd.L1b.layer_name);
vcd.L2a.i = data.fcMakeBinaryImage(data.fcFilterByRegion(vcd.L2a.fc_address, study_region))
  .unmask().rename(vcd.L2a.layer_name);
vcd.L2b.i = data.fcMakeBinaryImage(data.fcFilterByRegion(vcd.L2b.fc_address, study_region))
  .unmask().rename(vcd.L2b.layer_name);
vcd.L3a.i = data.fcMakeBinaryImage(data.fcFilterByRegion(vcd.L3a.fc_address, study_region))
  .unmask().rename(vcd.L3a.layer_name);
vcd.L3b.i = data.fcMakeBinaryImage(data.fcFilterByRegion(vcd.L3b.fc_address, study_region))
  .unmask().rename(vcd.L3b.layer_name);
vcd.L4a.i = data.fcMakeBinaryImage(data.fcFilterByRegion(vcd.L4a.fc_address, study_region))
  .unmask().rename(vcd.L4a.layer_name);
vcd.L5.i = data.fcMakeBinaryImage(data.fcFilterByRegion(vcd.L5.fc_address, study_region))
  .unmask().rename(vcd.L5.layer_name);
vcd.L6.i = data.fcMakeBinaryImage(data.fcFilterByRegion(vcd.L6.fc_address, study_region))
  .unmask().rename(vcd.L6.layer_name);
// Create a single multiband image. 
vcd.i = vcd.L1a.i
  .addBands(vcd.L1b.i)
  .addBands(vcd.L2a.i)
  .addBands(vcd.L2b.i)
  .addBands(vcd.L3a.i)
  .addBands(vcd.L3b.i)
  .addBands(vcd.L4a.i)
  .addBands(vcd.L5.i)
  .addBands(vcd.L6.i)
;
// Define layer names with a dictionary.
var vcd_layers = {
  L1a: "Interior_Forest_Blocks_Highest_Priority",
  L1b: "Interior_Forest_Blocks_High_Priority",
  L2a: "Connectivity_Blocks_Highest_Priority",
  L2b: "Connectivity_Blocks_High_Priority",
  L3a: "Surface_Water_and_Riparian_Areas_Highest_Priority",
  L3b: "Surface_Water_and_Riparian_Areas_High_Priority",
  L4a: "Riparian_Wildlife_Connectivity",
  L5: "Physical_Landscape_Diversity",
  L6: "Physical_Landscape_Blocks"
};
// Make summary elements
vcd.summary = {};
vcd.summary.blocks = vcd.L1a.i
  .max(vcd.L1b.i)
  .max(vcd.L2a.i)  
  .max(vcd.L2b.i)  
  .max(vcd.L6.i)  
;
vcd.summary.rip = vcd.L3a.i
  .max(vcd.L3b.i)
  .max(vcd.L4a.i)  
;
vcd.summary.combined = vcd.summary.blocks
  .add(vcd.summary.rip.multiply(10))
  .remap(
    [0,1,10,11],
    [0,1,3,2]
);
vcd.summary.viz = {
  min:0,
  max: 3, 
  palette: ['#DCDCDC', 'MediumSeaGreen', 'Orchid', 'SkyBlue']
};
vcd.summary.class_names = ['Not a VCD element', 'Upland forest block', 'Wet Forest Block', 'Surface water/valley bottom corridor'];
layout.map.addLayer(vcd.summary.rip.selfMask(), {min:0, max:1, palette: ['Black', 'SkyBlue']}, 'Surface Water and Riparian',0);
layout.map.addLayer(vcd.summary.blocks.selfMask(), {min:0, max:1, palette: ['#DCDCDC', 'MediumSeaGreen']}, 'Forest Blocks', 0);
layout.map.addLayer(vcd.summary.combined.selfMask(), vcd.summary.viz, 'VCD Summary',1);
var middoutlines = cart.paintOutlines(ee.FeatureCollection(region.town.fc), 0.5);
layout.map.addLayer(middoutlines, {min:0, max:1, palette: 'white'}, "Town Boundaries");
layout.map.addLayer(makeTargetTown(config.town).style(config.select_style), {}, "Selected town", false);
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
//  Select Widget
// ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><
var select_style 
;
var towns = {
  'BRIDPORT': ['BRIDPORT'], 
  'BRISTOL': ['BRISTOL'],
  'CORNWALL': ['CORNWALL'],
  'GOSHEN': ['GOSHEN'],
  'MIDDLEBURY': ['MIDDLEBURY'],
  'LEICESTER': ['LEICESTER'],
  'NEW HAVEN': ['NEW HAVEN'],
  'RIPTON': ['RIPTON'],
  'SALISBURY': ['SALISBURY'],
  'SHOREHAM': ['SHOREHAM'],
  'WEYBRIDGE': ['WEYBRIDGE'],
  'WHITING': ['WHITING']
};
var select_pattern = ui.Select({
  items: Object.keys(towns),
  placeholder: 'Select a town',
  style: select_style,
  onChange: function(key) {
    config.town = towns[key][0];
    makeChart();
    layout.map.centerObject(makeTargetTown(config.town), config.zoom);
    layout.map.layers().set(4, ui.Map.Layer(makeTargetTown(config.town).style(config.select_style)).setName(config.town));
  }
});
// layout.panel.insert(2, select_pattern);
// --------------------
// make a click handler
// --------------------
var selectTown = function(){
  var target = region.town.fc
    .filterBounds(config.point)
    ;
  return target;
};
function handleMapClick(coordinates) {
  config.point = ee.Geometry.Point([coordinates.lon, coordinates.lat]);
  config.target = selectTown();
  updateSelection();
}
// --------------------
// make update function
// --------------------
var updateSelection = function() 
  {
    makeChart();
    layout.map.centerObject(config.target, config.zoom);
    layout.map.layers().set(4, ui.Map.Layer(config.target.style(config.select_style), {}, 'SELECTED TOWN'));
  };
// add interactivity to map
// ------------------------
layout.map.onClick(handleMapClick);
// -------------------------------------------------------------------------------------
// Chart vcd summary in Midd
// -------------------------------------------------------------------------------------
vcd.summary.layer_name = 'VCD Summary';
// Create stack for class method. 
var makeChart = function(name) {
  vcd.summary.stack_class = ee.Image
    .pixelArea().divide(4046.86).rename('acres')                                              // Each pixel stores pixel area.
    .addBands(vcd.summary.combined.rename(vcd.summary.layer_name))     // Bottom layer must have class values.
  ;
  // Create dictionary of chart arguments.
  vcd.summary.chart_params_class = {
    image: vcd.summary.stack_class,                        // Image with dough bands and cutter band.
    classBand: vcd.summary.layer_name,                     // Name of the band to use as cutter.  
    region: selectTown(),                           // Region to perform operation.  
    reducer: ee.Reducer.sum(),                        // Type of zonal statistic to calculate.  
    scale: 30,                                        // Scale to carry out operation.
    classLabels: vcd.summary.class_names,                  // Labels of cutters to use in chart.
    }
  ;
  // Create the chart.  
  vcd.summary.chart_class = ui.Chart.image.byClass(vcd.summary.chart_params_class)                                    // Dictionary of chart arguments.  
      .setChartType('BarChart')                                                                             // Type of chart.
      .setOptions(cart.makeBarChartStyle(
        vcd.summary.viz.palette, 
        vcd.summary.layer_name, 
        'percent', 
        '30%', 
        '50%',
        'bottom')
    )
  ;
  // Inspect chart.
  dyno.clear();
  dyno
    // .add(cart.makeSubTitle(config.target.getString('TOWNNAME')))
    .add(vcd.summary.chart_class)
  ;
};
// -------------------------------------------------------------------------------------
// Credits
// -------------------------------------------------------------------------------------
layout.panel
  .add(labels.credits)
;
// -------------------------------------------------------------------------------------
// Make dictionary a module.
// -------------------------------------------------------------------------------------
// print("VCD", vcd);
exports.vcd = vcd;
// // -------------------------------------------------------------------------------------
// // Export as asset
// // -------------------------------------------------------------------------------------
// // var x_name = "VCD_Forest_Blocks_0614_2023";
// // var x_data = vcd.summary.blocks;
// var x_name = "VCD_Riparian_Corridor_0614_2023";
// var x_data = vcd.summary.rip;
// var xi = {
//   image:  x_data.selfMask(), 
//   description: x_name, 
//   assetId: x_name, 
//   pyramidingPolicy: 'mode', 
//   // dimensions, 
//   region: study_region, 
//   scale: 3, 
//   // crs, crsTransform, 
//   maxPixels: 1e12, 
//   // shardSize
// };
// Export.image.toAsset(xi);