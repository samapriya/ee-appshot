//  ----------------------------------------------------------------------------
//  TITLE:    middAtlas.js
//  PURPOSE:  To help town community do conservation planning
//  AUTHOR:   Jeff Howarth
//  ----------------------------------------------------------------------------
//  Load modules
//  ----------------------------------------------------------------------------
var geoTools = require('users/jhowarth/conservation:modules/geoTools.js');
var cart = require('users/jhowarth/conservation:modules/cart.js');
var style = require('users/jhowarth/conservation:modules/styles.js');
//  ----------------------------------------------------------------------------
//  Define study region
//  ----------------------------------------------------------------------------
var towns = ee.FeatureCollection('users/jhowarth/middCC/vermontTownsUTM18');
var midd = towns.filter(ee.Filter.eq('TOWNNAME', 'MIDDLEBURY'));
var middOutline = cart.paintOutlines(midd,0.5);
//  ----------------------------------------------------------------------------
//  Layout
//  ----------------------------------------------------------------------------
// Initialize side panel
var panelSide = ui.Panel({
  style: {
    width: '20%'
  }
});
// initialize map and options 
var map = ui.Map();
map.setOptions('HYBRID');
// map.style().set({cursor: 'crosshair'});
// initialize split panel for main layout
var splitPanel = ui.SplitPanel({
  firstPanel: panelSide,
  secondPanel: map,
});
// clear root and add split panel
ui.root.clear();
ui.root.add(splitPanel);
//  ----------------------------------------------------------------------------
//  Lettering
//  ----------------------------------------------------------------------------
//  Compose title
var title = cart.makeTitle("Conservation Atlas");
//  Compose sources and credits  
var src = {
  plan: 'DRAFT Conservation Plan\nTown of Middlebury, VT',
  page: 'Go to section in plan',
  nativeLand: 'Middlebury is unceded ancestral Abenaki land.',
  author: 'Jeff Howarth\nGeography Dept, Middlebury College\njhowarth@middlebury.edu'
};
var link = {
  plan: 'https://conservation-plan.github.io/middlebury-vermont/',
  cadastre: 'https://conservation-plan.github.io/middlebury-vermont/parcels/',
  forest: 'https://conservation-plan.github.io/middlebury-vermont/forests/',
  riverine: 'https://conservation-plan.github.io/middlebury-vermont/riverine/',
  habitatConnector: 'https://conservation-plan.github.io/middlebury-vermont/connectors/',
  field: 'https://conservation-plan.github.io/middlebury-vermont/fields/',
  corridor: 'https://conservation-plan.github.io/middlebury-vermont/corridors/',
  wetland: 'https://conservation-plan.github.io/middlebury-vermont/wetlands/',
  urban: 'https://conservation-plan.github.io/middlebury-vermont/urban/',
  paths: 'https://conservation-plan.github.io/middlebury-vermont/paths/'
};
var plan = cart.makeSource(src.plan, link.plan); 
var linkCadastre = cart.makeSource(src.page, link.cadastre);
linkCadastre.style().set('shown',false);
var linkForest = cart.makeSource(src.page, link.forest);
linkForest.style().set('shown',false);
var linkRiverine = cart.makeSource(src.page, link.riverine);
linkRiverine.style().set('shown',false);
var linkHabitatConnector = cart.makeSource(src.page, link.habitatConnector);
linkHabitatConnector.style().set('shown',false);
var linkField = cart.makeSource(src.page, link.field);
linkField.style().set('shown',false);
var linkCorridor = cart.makeSource(src.page, link.corridor);
linkCorridor.style().set('shown',false);
var linkWetland = cart.makeSource(src.page, link.wetland);
linkWetland.style().set('shown',false);
var linkUrban = cart.makeSource(src.page, link.urban);
linkUrban.style().set('shown',false);
var linkPaths = cart.makeSource(src.page, link.paths);
linkPaths.style().set('shown',false);
var landAck = cart.makeCredit(src.nativeLand);
var author = cart.makeCredit(src.author);
//  ----------------------------------------------------------------------------
//  Layers
//  ----------------------------------------------------------------------------
//  vizSchemes
// var gradientVis = {
//   hli: {min:0.4,max:1,palette:style.hliPalette}
// };
//  Layer order
var lo = {
  slopeDEM: 0,
  slopeDSM: 1,
  ortho42: 2,
  deBeers: 3,
  rem: 4, 
  lc: 5,
  lf: 6,
  natCom: 7,
  hli: 8,
  slopeClass: 9,
  mlud:10,
  flood: 11,
  surfaceRip: 12,
  farmSoils: 13,
  farmLands: 14,
  scenicRds:15,
  wet: 16,
  riverineConnector:17,
  hb: 18,
  hb_nc: 19,
  db:20,
  anrLand: 21,
  proLand: 22,
  rivCor: 23,
  parcelOutlines: 24,
  placeHolder: 25,
  town: 26,
  tam: 27
};
//  Images
var images = {
  natCom: ee.Image('users/jhowarth/midd_conservation_plan/preNatCom'),
  parcels: ee.FeatureCollection('users/jhowarth/midd_conservation_plan/vt_parcels_ee'),
  deBeers: ee.Image('users/jhowarth/vt_images/beersMidd71'),
  flood: ee.Image('projects/conservation-atlas/assets/hydrology/iFloodZones_01052022'),
  surfaceRip: ee.Image('projects/conservation-atlas/assets/hydrology/iSurfaceDitchRiparian_010522'),
  ortho42: ee.Image('users/jhowarth/middCC/Middlebury_1942_Ortho'),
  farmSoils: ee.Image('projects/conservation-atlas/assets/soils/iSoils_12162021'),
  farmLands: ee.Image('projects/conservation-atlas/assets/landUse/iAg_01052021'),
  mlud: ee.Image('projects/conservation-atlas/assets/landUse/iMLUD_01062022'),
  anrLand: ee.Image('projects/conservation-atlas/assets/landscape/CbD_composite_03252022')
};
// Masks 
var anrMask = images.anrLand
  .select('Landscape_diversity')
  .add(images.anrLand.select('Forest_habitat_blocks'))
  .add(images.anrLand.select('Wet_habitat_connectors'))
  .neq(0)
  ;
//  Features
var features = {
    parcelOutlines: cart.paintOutlines(images.parcels,1),
    placeHolder: ee.Feature(ee.Geometry.Point([-73, 44]))
};
//  TAM
var tam = ee.FeatureCollection('users/jhowarth/middCC/TAM');
var tamList = geoTools.tokenList(tam, 'Trail_Type');
var tamIDs = geoTools.tagIDs(tamList);
var tamDict = geoTools.tagDict(tamList, tamIDs);
var tamTagged = tam.map(geoTools.tagNominalClasses(tamDict, 'Trail_Type', 'TAG'));
var tamImage = geoTools.makeImageFromFeatures(tamTagged, 'TAG');
//  Viz schemes
var viz = {
  natCom: {min:0,max:8,palette:style.ncPalette},
  deBeers: {min:50,max:255,bands: ['b1', 'b2', 'b3'],gamma: 2.5},
  hli: {min:0.4,max:1,palette:style.hliPalette},
  flood: {palette:style.floodPalette},
  surfaceRip: {min:1,max:3,palette:style.surfaceRipPalette},
  ortho42: {min:0,max:255},
  farmSoils: {min:2,max:7,palette:style.farmSoilsPalette},
  tam: {min:0,max:4,palette:style.tamPalette},
  mlud: {min:0,max:13,palette:style.mludPalette},
  anrLand: {min:0, max:255, bands: ['Landscape_diversity', 'Forest_habitat_blocks', 'Wet_habitat_connectors']}
};
//  Layers
var layers = {
  anrLand: [lo.anrLand, 'ANR Conservation Design Components', images.anrLand, viz.anrLand],
  mlud: [lo.mlud, 'Land Use Districts', images.mlud, viz.mlud],
  tam: [lo.tam, 'Trail Around Middlebury', tamImage, viz.tam],
  farmLands: [lo.farmLands, 'Farmed and mowed lands', images.farmLands, viz.farmSoils],
  farmSoils: [lo.farmSoils, 'Soil farmland rating', images.farmSoils, viz.farmSoils],
  ortho42: [lo.ortho42, '1942 air photos', images.ortho42, viz.ortho42],
  surfaceRip: [lo.surfaceRip, 'Surface waters with riparian buffer', images.surfaceRip, viz.surfaceRip],
  flood: [lo.flood, 'Flood zones', images.flood, viz.flood],
  deBeers: [lo.deBeers, 'DeBeers 1871', images.deBeers, viz.deBeers],
  parcelOutlines: [lo.parcelOutlines, "Parcels", features.parcelOutlines, {palette:['white']}],
  placeHolder: [lo.placeHolder, 'Selected Parcel', features.placeHolder,{color: '#FFFF00'}],
  wet: [lo.wet, 'Wetlands', ee.Image('projects/conservation-atlas/assets/wetlands/_wetlandsConfidence_12272021'),
    {min:1,max:4,palette:style.wetPalette}],
  rem: [lo.rem, 'Relative elevation model', ee.Image('projects/conservation-atlas/assets/elevation/iREM_12212021'), 
    {min:0, max:15, palette:style.remPalette}],
  satBase: [null, 'Google Satelitte', null, null],
  slopeDSM: [lo.slopeDSM, 'Slope-shaded surface model', ee.Image('projects/conservation-atlas/assets/elevation/slopeDSM_12152021'),
    {min:60,max:0,palette:['#333333','white']}],
  slopeDEM: [lo.slopeDEM, 'Slope-shaded terrain model', ee.Image('projects/conservation-atlas/assets/elevation/slopeDEM_12152021'),
    {min:60,max:0}],
  riverineConnector: [lo.riverineConnector, 'Riverine habitat connectors', ee.Image('projects/conservation-atlas/assets/landscape/iSurfaceRiparian_12092021'),
    {min:1,max:5,palette:style.ripPalette}],
  rivCor: [lo.rivCor, 'River Corridors', ee.Image('projects/conservation-atlas/assets/protections/riverCorridorImage_12072021'),
    {min:0,max:1,palette:['black','#79B1BA']}],
  nc: [lo.natCom,'Natural communities from soils', images.natCom, viz.natCom],
  lc: [lo.lc,'Land cover 2016', ee.Image('projects/conservation-atlas/assets/landCover/iLandCover_midd_12152021'),
    {min:0,max:10,palette:style.lcd}],
  lf: [lo.lf,'Land forms', ee.Image('projects/conservation-atlas/assets/landforms/lf300'),
    {min:50, max:10, palette:style.lf}],
  proLand:[lo.proLand,'Parcels with protections',ee.Image('projects/conservation-atlas/assets/protections/proStackFlat_12072021b'),
    {min:1, max:2, palette:style.proLand}],
  hli: [lo.hli,'Heat load index', ee.Image('projects/conservation-atlas/assets/elevation/heatLoadIndex'),
    viz.hli],     
  sc: [lo.slopeClass,'Slope classes', ee.Image('projects/conservation-atlas/assets/elevation/slopeClass'),
    {min:0,max:8,palette:style.slopeClassPalette}], 
  town: [lo.town,'Middlebury', middOutline],
  hb: [lo.hb,'Continguous forest land cover',ee.Image('projects/conservation-atlas/assets/landscape/_habitatBlocks_12102021')],
  hb_nc: [lo.hb_nc, "Contiguous forest natural communities", images.natCom, viz.natCom],
  db: [lo.db,'Residential density in developed regions', ee.Image('projects/conservation-atlas/assets/landUse/resDensityQuantiles_12152021'),
    {min:1,max:4, palette:style.dbPalette}],
  scenicRds: [lo.scenicRds, 'Visible from scenic roads', ee.Image('projects/conservation-atlas/assets/views/scenicRoadsViz_12172021').selfMask(),
    {min:1,max:2,palette:style.visPalette}]
};
//  ----------------------------------------------------------------------------
//  Map composition
//  ----------------------------------------------------------------------------
map.setControlVisibility({layerList: false});
map.setOptions('Light Base',{'Light Base':style.lightBase});
map.setOptions('HYBRID');
map.centerObject(midd, 13);
map.addLayer(layers.slopeDEM[2], layers.slopeDEM[3], layers.slopeDEM[1],0);
map.addLayer(layers.slopeDSM[2], layers.slopeDSM[3], layers.slopeDSM[1],0);
map.addLayer(layers.ortho42[2], layers.ortho42[3], layers.ortho42[1],0);
map.addLayer(layers.deBeers[2], layers.deBeers[3], layers.deBeers[1],0);
map.addLayer(layers.rem[2], layers.rem[3], layers.rem[1],0);
map.addLayer(layers.lc[2], layers.lc[3], layers.lc[1],0);
map.addLayer(layers.lf[2], layers.lf[3], layers.lf[1],0);
map.addLayer(layers.nc[2], layers.nc[3], layers.nc[1],0);
map.addLayer(layers.hli[2],layers.hli[3],layers.hli[1],0);
map.addLayer(layers.sc[2], layers.sc[3], layers.sc[1],0);
map.addLayer(layers.mlud[2], layers.mlud[3], layers.mlud[1],0);
map.addLayer(layers.flood[2], layers.flood[3], layers.flood[1], 0);
map.addLayer(layers.surfaceRip[2], layers.surfaceRip[3], layers.surfaceRip[1], 0);
map.addLayer(layers.farmSoils[2].updateMask(layers.farmSoils[2].gte(2)), layers.farmSoils[3], layers.farmSoils[1],0);
map.addLayer(layers.farmSoils[2].updateMask((layers.farmSoils[2].gte(2)).multiply(layers.farmLands[2])), layers.farmSoils[3], layers.farmLands[1],0);
map.addLayer(layers.scenicRds[2], layers.scenicRds[3], layers.scenicRds[1],0);
map.addLayer(layers.wet[2].selfMask(),layers.wet[3], layers.wet[1],0);
map.addLayer(layers.lc[2].updateMask(layers.riverineConnector[2].neq(4)), layers.lc[3], layers.riverineConnector[1],0);  //  connector 
map.addLayer(layers.lc[2].updateMask(layers.hb[2].gt(0)), layers.lc[3], layers.hb[1],0);          //  block
map.addLayer(layers.hb_nc[2].updateMask(layers.hb[2].gt(0)), layers.hb_nc[3], layers.hb_nc[1],0);
map.addLayer(layers.db[2], layers.db[3], layers.db[1],0);
map.addLayer(layers.anrLand[2].updateMask(anrMask), layers.anrLand[3], layers.anrLand[1],0);
map.addLayer(layers.proLand[2],layers.proLand[3],layers.proLand[1],0);
map.addLayer(layers.rivCor[2],layers.rivCor[3],layers.rivCor[1],0);
map.addLayer(layers.parcelOutlines[2], layers.parcelOutlines[3], layers.parcelOutlines[1],0,0.3);
map.addLayer(layers.placeHolder[2], layers.placeHolder[3], layers.placeHolder[1],0);
map.addLayer(layers.town[2], {palette:'white'}, layers.town[1], 1);
map.addLayer(layers.tam[2], layers.tam[3], layers.tam[1],0);
//  ----------------------------------------------------------------------------
//  Make layer panels
//  ----------------------------------------------------------------------------
//  exports.makePanelWithWidgets(widgets, width, position, shown, padding, direction)
var lpC = {
  wi: '300px',
  po: 'top-left',
  sh: false,
  pa: '10px',
  di: 'vertical'
};
//  -------------------------------------------------
//  Cadastre
//  -------------------------------------------------
//  parcels
//  --------------------------
var parcel_Check = cart.makeCheckBox(layers.parcelOutlines[1], cart.h3);
parcel_Check.onChange(function(checked) {
  map.layers().get(layers.parcelOutlines[0]).setShown(checked);
  map.layers().get(layers.placeHolder[0]).setShown(checked);
  parcelChartPanel.style().set('shown',checked);
});
var parcel_PanelWidgets = [parcel_Check]; 
var parcel_Panel =cart.makePanelWithWidgets(parcel_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Protected lands
//  ---------------
var proLegend = cart.makeLegend(null, style.proLand, style.proLandLabels);
proLegend.style().set({shown: false});
var proSlider = cart.makeOpacitySlider(map, layers.proLand[0]);
var proCheck = cart.makeCheckBox(layers.proLand[1], cart.h3);
proCheck.onChange(function(checked) {
  map.layers().get(layers.proLand[0]).setShown(checked);
  proSlider.style().set('shown', checked);
  proLegend.style().set('shown', checked);
});
var proPanelWidgets = [proCheck, proSlider, proLegend]; 
var proPanel =cart.makePanelWithWidgets(proPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Middlebury Land Use Districts 
//  -----------------------------
var mludLegend = cart.makeLegend(null, style.mludPalette, style.mludLabels);
mludLegend.style().set({shown: false});
var mludSlider = cart.makeOpacitySlider(map, layers.mlud[0]);
var mludCheck = cart.makeCheckBox(layers.mlud[1], cart.h3);
mludCheck.onChange(function(checked) {
  map.layers().get(layers.mlud[0]).setShown(checked);
  mludSlider.style().set('shown', checked);
  mludLegend.style().set('shown', checked);
});
var mludPanelWidgets = [mludCheck, mludSlider, mludLegend]; 
var mludPanel =cart.makePanelWithWidgets(mludPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  -------------------------------------------------
//  Landscape components 
//  -------------------------------------------------
//  ANR Conservation Design landscape components
//  --------------------------------------------
var anrLandLegend = cart.makeLegend(null, style.anrLand_colors, style.anrLand_labels);
anrLandLegend.style().set({shown: false});
var anrLandSlider = cart.makeOpacitySlider(map, layers.anrLand[0]);
var anrLandCheck = cart.makeCheckBox(layers.anrLand[1], cart.h3);
anrLandCheck.onChange(function(checked) {
  map.layers().get(layers.anrLand[0]).setShown(checked);
  anrLandSlider.style().set('shown', checked);
  anrLandLegend.style().set('shown', checked);
});
var anrLandPanelWidgets = [anrLandCheck, anrLandSlider, anrLandLegend]; 
var anrLandPanel =cart.makePanelWithWidgets(anrLandPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  -------------------------------------------------
//  Riverine habitats
//  -------------------------------------------------
//  Relative elevation model
//  --------------------------
var rem_Legend = cart.makeGradientLegend(layers.rem[3],'height above water surface (ft)');
rem_Legend.style().set({shown: false});
var rem_Slider = cart.makeOpacitySlider(map, layers.rem[0]);
var rem_Check = cart.makeCheckBox(layers.rem[1], cart.h3);
rem_Check.onChange(function(checked) {
  map.layers().get(layers.rem[0]).setShown(checked);
  rem_Slider.style().set('shown', checked);
  rem_Legend.style().set('shown',checked);
});
var rem_PanelWidgets = [rem_Check, rem_Slider, rem_Legend]; 
var rem_Panel =cart.makePanelWithWidgets(rem_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Flood zones
//  -----------_
var floodLegend = cart.makeLegend(null, style.floodPalette, style.floodLabels);
floodLegend.style().set({shown: false});
var floodSlider = cart.makeOpacitySlider(map, layers.flood[0]);
var floodCheck = cart.makeCheckBox(layers.flood[1], cart.h3);
floodCheck.onChange(function(checked) {
  map.layers().get(layers.flood[0]).setShown(checked);
  floodSlider.style().set('shown', checked);
  floodLegend.style().set('shown',checked);
});
var floodPanelWidgets = [floodCheck, floodSlider, floodLegend]; 
var floodPanel =cart.makePanelWithWidgets(floodPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Surface waters with riparian buffer zones
//  -----------------------------------------
var surfaceRipLegend = cart.makeLegend(null, style.surfaceRipPalette, style.surfaceRipLabels);
surfaceRipLegend.style().set({shown: false});
var surfaceRipSlider = cart.makeOpacitySlider(map, layers.surfaceRip[0]);
var surfaceRipCheck = cart.makeCheckBox(layers.surfaceRip[1], cart.h3);
surfaceRipCheck.onChange(function(checked) {
  map.layers().get(layers.surfaceRip[0]).setShown(checked);
  surfaceRipSlider.style().set('shown', checked);
  surfaceRipLegend.style().set('shown',checked);
});
var surfaceRipPanelWidgets = [surfaceRipCheck, surfaceRipSlider, surfaceRipLegend]; 
var surfaceRipPanel =cart.makePanelWithWidgets(surfaceRipPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  River Corridors
//  -------------------
// var ripLegend = cart.makeLegend(null, style.proLand, style.proLandLabels);
// proLegend.style().set({shown: false});
var rivCorSlider = cart.makeOpacitySlider(map, layers.rivCor[0]);
var rivCorCheck = cart.makeCheckBox(layers.rivCor[1], cart.h3);
rivCorCheck.onChange(function(checked) {
  map.layers().get(layers.rivCor[0]).setShown(checked);
  rivCorSlider.style().set('shown', checked);
});
var rivCorPanelWidgets = [rivCorCheck, rivCorSlider]; 
var rivCorPanel =cart.makePanelWithWidgets(rivCorPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  -------------------------------------------------
//  Forest blocks
//  -------------------------------------------------
//  Habitat blocks with land cover
//  -------------------------------
var hbLegend = cart.makeLegend(null, style.lcd, style.lcdLabels);
hbLegend.style().set({shown: false});
var hbSlider = cart.makeOpacitySlider(map, layers.hb[0]);
var hbCheck = cart.makeCheckBox(layers.hb[1], cart.h3);
hbCheck.onChange(function(checked) {
  map.layers().get(layers.hb[0]).setShown(checked);
  hbSlider.style().set('shown', checked);
  hbLegend.style().set('shown', checked);
});
var hbPanelWidgets = [hbCheck, hbSlider, hbLegend];
var hbPanel = cart.makePanelWithWidgets(hbPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Natural communities in habitat blocks
//  -------------------------------------
var hb_ncLegend = cart.makeLegend(null, style.ncPalette, style.natComLabels);
hb_ncLegend.style().set({shown: false});
var hb_ncSlider = cart.makeOpacitySlider(map, layers.hb_nc[0]);
var hb_ncCheck = cart.makeCheckBox(layers.hb_nc[1], cart.h3);
hb_ncCheck.onChange(function(checked) {
  map.layers().get(layers.hb_nc[0]).setShown(checked);
  hb_ncSlider.style().set('shown', checked);
  hb_ncLegend.style().set('shown', checked);
});
var hb_nc_PanelWidgets = [hb_ncCheck, hb_ncSlider, hb_ncLegend];
var hb_nc_Panel = cart.makePanelWithWidgets(hb_nc_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Heat load index
//  ----------------------
var hliLegend = cart.makeGradientLegend(viz.hli, null);
hliLegend.style().set({shown: false});
var hliSlider = cart.makeOpacitySlider(map, layers.hli[0]);
var hliCheck = cart.makeCheckBox(layers.hli[1], cart.h3);
hliCheck.onChange(function(checked) {
  map.layers().get(layers.hli[0]).setShown(checked);
  hliSlider.style().set('shown', checked);
  hliLegend.style().set('shown', checked);
});
var hliPanelWidgets = [hliCheck, hliSlider, hliLegend];
var hliPanel =cart.makePanelWithWidgets(hliPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  -------------------------------------------------
//  Habitat connectors
//  -------------------------------------------------
//  Riverine connectors
//  -------------------
var riverineConnectorLegend = cart.makeLegend(null, style.lcd, style.lcdLabels);
riverineConnectorLegend.style().set({shown: false});
var riverineConnectorSlider = cart.makeOpacitySlider(map, layers.riverineConnector[0]);
var riverineConnectorCheck = cart.makeCheckBox(layers.riverineConnector[1], cart.h3);
riverineConnectorCheck.onChange(function(checked) {
  map.layers().get(layers.riverineConnector[0]).setShown(checked);
  riverineConnectorSlider.style().set('shown', checked);
  riverineConnectorLegend.style().set('shown',checked);
});
var riverineConnectorPanelWidgets = [riverineConnectorCheck, riverineConnectorSlider, riverineConnectorLegend]; 
var riverineConnectorPanel =cart.makePanelWithWidgets(riverineConnectorPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  -------------------------------------------------
//  Field blocks
//  -------------------------------------------------
//  Visibility from scenic roads
//  ----------------------------
var scenicRds_Legend = cart.makeLegend(null, style.visPalette, style.visLabels);
scenicRds_Legend.style().set({shown: false});
var scenicRds_Slider = cart.makeOpacitySlider(map, layers.scenicRds[0]);
var scenicRds_Check = cart.makeCheckBox(layers.scenicRds[1], cart.h3);
scenicRds_Check.onChange(function(checked) {
  map.layers().get(layers.scenicRds[0]).setShown(checked);
  scenicRds_Slider.style().set('shown', checked);
  scenicRds_Legend.style().set('shown', checked);
});
var scenicRds_PanelWidgets = [scenicRds_Check, scenicRds_Slider, scenicRds_Legend];
var scenicRds_Panel =cart.makePanelWithWidgets(scenicRds_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Farm soil rating
//  ----------------------------
var farmSoils_Legend = cart.makeLegend(null, style.farmSoilsPalette, style.farmSoilsLabels);
farmSoils_Legend.style().set({shown: false});
var farmSoils_Slider = cart.makeOpacitySlider(map, layers.farmSoils[0]);
var farmSoils_Check = cart.makeCheckBox(layers.farmSoils[1], cart.h3);
farmSoils_Check.onChange(function(checked) {
  map.layers().get(layers.farmSoils[0]).setShown(checked);
  farmSoils_Slider.style().set('shown', checked);
  farmSoils_Legend.style().set('shown', checked);
});
var farmSoils_PanelWidgets = [farmSoils_Check, farmSoils_Slider, farmSoils_Legend];
var farmSoils_Panel =cart.makePanelWithWidgets(farmSoils_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Farmed and mowed lands
//  ----------------------------
var farmLands_Legend = cart.makeLegend(null, style.farmSoilsPalette, style.farmSoilsLabels);
farmLands_Legend.style().set({shown: false});
var farmLands_Slider = cart.makeOpacitySlider(map, layers.farmLands[0]);
var farmLands_Check = cart.makeCheckBox(layers.farmLands[1], cart.h3);
farmLands_Check.onChange(function(checked) {
  map.layers().get(layers.farmLands[0]).setShown(checked);
  farmLands_Slider.style().set('shown', checked);
  farmLands_Legend.style().set('shown', checked);
});
var farmLands_PanelWidgets = [farmLands_Check, farmLands_Slider, farmLands_Legend];
var farmLands_Panel =cart.makePanelWithWidgets(farmLands_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  -------------------------------------------------
//  Wetland habitats
//  -------------------------------------------------
//  wetlands
//  --------------------------
var wet_Legend = cart.makeLegend('Confidence',style.wetPalette,style.wetLabels);
wet_Legend.style().set({shown: false});
var wet_Slider = cart.makeOpacitySlider(map, layers.wet[0]);
var wet_Check = cart.makeCheckBox(layers.wet[1], cart.h3);
wet_Check.onChange(function(checked) {
  map.layers().get(layers.wet[0]).setShown(checked);
  wet_Slider.style().set('shown', checked);
  wet_Legend.style().set('shown',checked);
});
var wet_PanelWidgets = [wet_Check, wet_Slider, wet_Legend]; 
var wet_Panel =cart.makePanelWithWidgets(wet_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  -------------------------------------------------
//  Urban districts
//  -------------------------------------------------
//  Developed blocks
//  --------------
var db_Legend = cart.makeLegend(null, style.dbPalette, style.dbLabels);
db_Legend.style().set({shown: false});
var db_Slider = cart.makeOpacitySlider(map, layers.db[0]);
var db_Check = cart.makeCheckBox(layers.db[1], cart.h3);
db_Check.onChange(function(checked) {
  map.layers().get(layers.db[0]).setShown(checked);
  db_Slider.style().set('shown', checked);
  db_Legend.style().set('shown', checked);
});
var db_PanelWidgets = [db_Check, db_Slider, db_Legend];
var db_Panel = cart.makePanelWithWidgets(db_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  -------------------------------------------------
//  Paths
//  -------------------------------------------------
//  TAM
//  -----------_
var tamLegend = cart.makeLegend(null, style.tamPalette, style.tamLabels);
tamLegend.style().set({shown: false});
var tamSlider = cart.makeOpacitySlider(map, layers.tam[0]);
var tamCheck = cart.makeCheckBox(layers.tam[1], cart.h3);
tamCheck.onChange(function(checked) {
  map.layers().get(layers.tam[0]).setShown(checked);
  tamSlider.style().set('shown', checked);
  tamLegend.style().set('shown',checked);
});
var tamPanelWidgets = [tamCheck, tamSlider, tamLegend]; 
var tamPanel =cart.makePanelWithWidgets(tamPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  -------------------------------------------------
//  Historical images
//  -------------------------------------------------
//  deBeers
//  --------------------------
var deBeers_Slider = cart.makeOpacitySlider(map, layers.deBeers[0]);
var deBeers_Check = cart.makeCheckBox(layers.deBeers[1], cart.h3);
deBeers_Check.onChange(function(checked) {
  map.layers().get(layers.deBeers[0]).setShown(checked);
  deBeers_Slider.style().set('shown', checked);
});
var deBeers_PanelWidgets = [deBeers_Check, deBeers_Slider]; 
var deBeers_Panel =cart.makePanelWithWidgets(deBeers_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  1942 air photos
//  --------------------------
var ortho42_Slider = cart.makeOpacitySlider(map, layers.ortho42[0]);
var ortho42_Check = cart.makeCheckBox(layers.ortho42[1], cart.h3);
ortho42_Check.onChange(function(checked) {
  map.layers().get(layers.ortho42[0]).setShown(checked);
  ortho42_Slider.style().set('shown', checked);
});
var ortho42_PanelWidgets = [ortho42_Check, ortho42_Slider]; 
var ortho42_Panel =cart.makePanelWithWidgets(ortho42_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  -------------------------------------------------
//  Base layers
//  -------------------------------------------------
//  Land cover
//  ----------
var lcLegend = cart.makeLegend(null, style.lcd, style.lcdLabels);
lcLegend.style().set({shown: false});
var lcSlider = cart.makeOpacitySlider(map, layers.lc[0]);
var lcCheck = cart.makeCheckBox(layers.lc[1], cart.h3);
lcCheck.onChange(function(checked) {
  map.layers().get(layers.lc[0]).setShown(checked);
  lcSlider.style().set('shown', checked);
  lcLegend.style().set('shown', checked);
});
var lcPanelWidgets = [lcCheck, lcSlider, lcLegend];
var lcPanel =cart.makePanelWithWidgets(lcPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Slope DEM
//  ----------
var slopeDEM_Slider = cart.makeOpacitySlider(map, layers.slopeDEM[0]);
var slopeDEM_Check = cart.makeCheckBox(layers.slopeDEM[1], cart.h3);
slopeDEM_Check.onChange(function(checked) {
  map.layers().get(layers.slopeDEM[0]).setShown(checked);
  slopeDEM_Slider.style().set('shown', checked);
});
var slopeDEM_PanelWidgets = [slopeDEM_Check, slopeDEM_Slider];
var slopeDEM_Panel =cart.makePanelWithWidgets(slopeDEM_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Slope DSM
//  ----------
var slopeDSM_Slider = cart.makeOpacitySlider(map, layers.slopeDSM[0]);
var slopeDSM_Check = cart.makeCheckBox(layers.slopeDSM[1], cart.h3);
slopeDSM_Check.onChange(function(checked) {
  map.layers().get(layers.slopeDSM[0]).setShown(checked);
  slopeDSM_Slider.style().set('shown', checked);
});
var slopeDSM_PanelWidgets = [slopeDSM_Check, slopeDSM_Slider];
var slopeDSM_Panel =cart.makePanelWithWidgets(slopeDSM_PanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Land form
//  ---------
var lfLegend = cart.makeLegend(null, style.lf, style.lfLabels);
lfLegend.style().set({shown: false});
var lfSlider = cart.makeOpacitySlider(map, layers.lf[0]);
var lfCheck = cart.makeCheckBox(layers.lf[1], cart.h3);
lfCheck.onChange(function(checked) {
  map.layers().get(layers.lf[0]).setShown(checked);
  lfSlider.style().set('shown', checked);
  lfLegend.style().set('shown', checked);
});
var lfPanelWidgets = [lfCheck, lfSlider, lfLegend];
var lfPanel =cart.makePanelWithWidgets(lfPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Natural communities from soils
//  ------------------------------
var ncLegend = cart.makeLegend(null, style.ncPalette, style.natComLabels);
ncLegend.style().set({shown: false});
var ncSlider = cart.makeOpacitySlider(map, layers.nc[0]);
var ncCheck = cart.makeCheckBox(layers.nc[1], cart.h3);
ncCheck.onChange(function(checked) {
  map.layers().get(layers.nc[0]).setShown(checked);
  ncSlider.style().set('shown', checked);
  ncLegend.style().set('shown', checked);
});
var ncPanelWidgets = [ncCheck, ncSlider, ncLegend];
var ncPanel =cart.makePanelWithWidgets(ncPanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
//  Slope Class (percent)
//  ----------------------
var slopeLegend = cart.makeLegend(null, style.slopeClassPalette, style.slopeClassLabels);
slopeLegend.style().set({shown: false});
var slopeSlider = cart.makeOpacitySlider(map, layers.sc[0]);
var slopeCheck = cart.makeCheckBox(layers.sc[1], cart.h3);
slopeCheck.onChange(function(checked) {
  map.layers().get(layers.sc[0]).setShown(checked);
  slopeSlider.style().set('shown', checked);
  slopeLegend.style().set('shown', checked);
});
var slopePanelWidgets = [slopeCheck, slopeSlider, slopeLegend];
var slopePanel =cart.makePanelWithWidgets(slopePanelWidgets, lpC.wi, lpC.po, lpC.sh, lpC.pa, lpC.di);
// --------------------------
//
// QUERY BY LOCATION 
//
// --------------------------
// make dictionary to keep track of variables
// ------------------------------------------
var selectValues = {
  point: null,
  targetParcel: images.parcels,
  selectParcelName: 'Selected Parcel',
};
// --------------------
// make a click handler
// --------------------
function handleMapClick(coordinates) {
  selectValues.point = ee.Geometry.Point([coordinates.lon, coordinates.lat]);
  updateSelection();
}
// --------------------
// make update function
// --------------------
var updateSelection = function(){
  var selectParcel = selectValues.targetParcel.filterBounds(selectValues.point);
  cart.updateOverlay(selectValues.point, selectValues.targetParcel, {color: '#FFFF00', fillColor: '00000000'}, lo.placeHolder, selectValues.selectParcelName, map);
  cart.getAttributeText(selectParcel, 'owner1').evaluate(function(val){ownerLabel.setValue('OWNER:       ' + val)});
  cart.getAttributeText(selectParcel, 'e911addr').evaluate(function(val){e911Label.setValue('ADDRESS:   ' + val)});
  cart.getAttributeNumber(selectParcel, 'acres', '%.2f').evaluate(function(val){acresLabel.setValue('ACRES:        ' + val)});
  cart.getAttributeText(selectParcel, 'span').evaluate(function(val){valueLabel.setValue('SPAN:          ' + val)});
  parcelChartPanel.clear();
  parcelChartPanel
    .add(cart.makeLabel("SELECTED PARCEL", cart.s1))
    .add(ownerLabel)
    .add(e911Label)
    .add(acresLabel)
    .add(valueLabel);
 };
// ------------------------
// add interactivity to map
// ------------------------
map.onClick(handleMapClick);
// ------------------------
// Make labels
// ------------------------
var selectLabel = cart.makeLabel("Click map for info about parcel...", cart.s1);
var ownerLabel = cart.makeLabel("", cart.s2);
var acresLabel = cart.makeLabel("", cart.s2);
var valueLabel = cart.makeLabel("", cart.s2);
var e911Label = cart.makeLabel("", cart.s2);
// Make parcel attribute panel
// --------------------------------------
var parcelChartPanel = cart.makePanel(style.insideLeft, 'bottom-left', false, style.pad3, style.vert);
parcelChartPanel.add(selectLabel);
//  ----------------------------------------------------------------------------
//  Make element Panels
//  ----------------------------------------------------------------------------
//  -------------------------
//  Cadastre panel
//  -------------------------
var cadastre_Check = cart.makeCheckBox('Land parcels', cart.h2);
cadastre_Check.onChange(function(checked) {
  linkCadastre.style().set('shown',checked);
  parcel_Panel.style().set('shown',checked);
  proPanel.style().set('shown',checked);
  mludPanel.style().set('shown',checked);
});
var cadastre_Panel = cart.makeLayerPanel(
  [cadastre_Check,
  linkCadastre,
  parcel_Panel,
  parcelChartPanel,
  proPanel,
  mludPanel
  ]);
//  -------------------------
//  Landscape component panel
//  -------------------------
var landscape_Check = cart.makeCheckBox('Landcape components', cart.h2);
landscape_Check.onChange(function(checked) {
  // linkCadastre.style().set('shown',checked);
  anrLandPanel.style().set('shown',checked);
});
var landscape_Panel = cart.makeLayerPanel(
  [landscape_Check,
  anrLandPanel
  ]);
//  -------------------------
//  Riverine elements panel
//  -------------------------
var riverineCheck = cart.makeCheckBox('Riverine elements', cart.h2);
riverineCheck.onChange(function(checked) {
    linkRiverine.style().set('shown',checked);
    surfaceRipPanel.style().set('shown',checked);
    floodPanel.style().set('shown',checked);
    rivCorPanel.style().set('shown',checked);
    rem_Panel.style().set('shown',checked);
});
var riverinePanel = cart.makeLayerPanel(
  [riverineCheck,
  linkRiverine,
  surfaceRipPanel,
  floodPanel,
  rivCorPanel, 
  rem_Panel
  ]);
//  -------------------------
//  Forest panel
//  -------------------------
var forestBlockCheck = cart.makeCheckBox('Forest elements', cart.h2);
forestBlockCheck.onChange(function(checked) {
  linkForest.style().set('shown',checked);
  hbPanel.style().set('shown',checked);
  hb_nc_Panel.style().set('shown',checked);
  hliPanel.style().set('shown',checked);
});
var forestBlockPanel = cart.makeLayerPanel(
  [forestBlockCheck,
  linkForest,
  hbPanel, 
  hb_nc_Panel,
  hliPanel
  ]);
//  -------------------------
//  Habitat connector
//  -------------------------
var habitatConnectorCheck = cart.makeCheckBox('Habitat connectors', cart.h2);
habitatConnectorCheck.onChange(function(checked) {
  linkHabitatConnector.style().set('shown',checked);
  riverineConnectorPanel.style().set('shown',checked);
});
var habitatConnectorPanel = cart.makeLayerPanel(
  [habitatConnectorCheck,
  linkHabitatConnector,
  riverineConnectorPanel
  ]);
//  -------------------------
//  Field blocks panel
//  -------------------------
var fieldBlockCheck = cart.makeCheckBox('Field blocks', cart.h2);
fieldBlockCheck.onChange(function(checked) {
  linkField.style().set('shown',checked);  scenicRds_Panel.style().set('shown',checked);
  farmLands_Panel.style().set('shown',checked);
  farmSoils_Panel.style().set('shown',checked);
});
var fieldBlockPanel = cart.makeLayerPanel(
  [fieldBlockCheck,
  linkField,
  scenicRds_Panel,
  farmLands_Panel,
  farmSoils_Panel,
  ]);
//  -------------------------
//  Wetlands panel
//  -------------------------
var wetHabitatCheck = cart.makeCheckBox('Wetland habitat', cart.h2);
wetHabitatCheck.onChange(function(checked) {
    linkWetland.style().set('shown',checked);
    wet_Panel.style().set('shown',checked);
});
var wetHabitat_Panel = cart.makeLayerPanel(
  [wetHabitatCheck,
  linkWetland,
  wet_Panel
  ]);
//  -------------------------
//  urban panel
//  -------------------------
var urbanBlockCheck = cart.makeCheckBox('Urban districts', cart.h2);
urbanBlockCheck.onChange(function(checked) {
  linkUrban.style().set('shown',checked);
  db_Panel.style().set('shown',checked);
});
var urbanBlockPanel = cart.makeLayerPanel([
  urbanBlockCheck,
  linkUrban,
  db_Panel
  ]);
//  Paths panel
//  -------------------------
var pathsCheck = cart.makeCheckBox('Paths', cart.h2);
pathsCheck.onChange(function(checked) {
  linkPaths.style().set('shown',checked);
  tamPanel.style().set('shown',checked);
});
var pathsPanel = cart.makeLayerPanel(
  [pathsCheck, 
  linkPaths,
  tamPanel
  ]);
//  Historical images panel
//  -------------------------
var historicalCheck = cart.makeCheckBox('Historical images', cart.h2);
historicalCheck.onChange(function(checked) {
  deBeers_Panel.style().set('shown',checked);
  ortho42_Panel.style().set('shown',checked);
});
var historicalPanel = cart.makeLayerPanel(
  [historicalCheck, 
  deBeers_Panel,
  ortho42_Panel,
  ]);
//  Base layers panel
//  -------------------------
var baseCheck = cart.makeCheckBox('Base layers', cart.h2);
baseCheck.onChange(function(checked) {
  ncPanel.style().set('shown',checked);
  lcPanel.style().set('shown',checked);
  lfPanel.style().set('shown',checked);
  slopePanel.style().set('shown',checked);
  slopeDSM_Panel.style().set('shown',checked);
  slopeDEM_Panel.style().set('shown',checked);
});
var basePanel = cart.makeLayerPanel(
  [baseCheck, 
  ncPanel, 
  lcPanel,
  lfPanel, 
  slopePanel,
  slopeDSM_Panel,
  slopeDEM_Panel]);
//  ----------------------------------------------------------------------------
//  Side panel widgets
//  ----------------------------------------------------------------------------
panelSide.add(title)
  .add(plan)
  .add(cadastre_Panel)
  .add(landscape_Panel)
  .add(riverinePanel)
  .add(forestBlockPanel)
  .add(habitatConnectorPanel)
  .add(fieldBlockPanel)
  .add(wetHabitat_Panel)
  .add(urbanBlockPanel)
  .add(pathsPanel)
  .add(historicalPanel)
  .add(basePanel)
  .add(landAck)
  .add(author);