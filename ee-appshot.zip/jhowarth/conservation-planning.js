var county = ui.import && ui.import("county", "table", {
      "id": "TIGER/2018/Counties"
    }) || ee.FeatureCollection("TIGER/2018/Counties");
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//
// CONSERVATION PLANNING FOR ADDISON COUNTY, VERMONT
//
// Jeff Howarth
// Geography Dept, Middlebury College
//
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
// Load toolbox module
// -------------------
var  tool = require('users/jhowarth/toolbox:eeToolbox.js'); // point to module script
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
// LOAD AND PREP DATA
//
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// --------------
// cadastre layer  
// --------------
// import data
// -----------
var town = ee.FeatureCollection('users/jhowarth/midd_conservation_plan/VT_Data_-_Town_Boundaries')
  .filter(ee.Filter.eq('CNTY', 1));
var os = ee.FeatureCollection('users/jhowarth/midd_conservation_plan/addison_blocks');
var parcels = ee.FeatureCollection('users/jhowarth/midd_conservation_plan/vt_parcels_ee');
// make outlines of parcels
// ------------------------
var parcelOutlines = tool.paintOutlines(parcels);
var townOutlines = tool.paintOutlines(town);
var osOutlines = tool.paintOutlines(os);
// import thematic stacks
// ----------
var lcStack = ee.Image('users/jhowarth/midd_conservation_plan/lcStack');
var proStack = ee.Image('users/jhowarth/midd_conservation_plan/proStackProj');
var pncStack = ee.Image('users/jhowarth/midd_conservation_plan/pncStack');
var agStack = ee.Image('users/jhowarth/midd_conservation_plan/agStack');
// Make dictionary for layer labels (for legends)
// ----------------------------------------------
var layerLabels = {
    pro: 'Protected Lands',
    nc: 'Natural Community Soils',
    pa: 'Prime Agriculture Soils',
    lc: 'Land Cover (2016)'
};
// ----------------
// Style map layers
// ----------------
// For each layer:
// 1. Define colors
// 2. Collect colors into a palette
// 3. Define min and max values to map palette
// 4. Define category labels for legend  
// 5. Make legend
// 6. Make opacity slider
// Natural Communities from Soils
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Define colors
var hydro = '#4FA7A8';
var swamp = '#618BB0';
var ff = '#5C6199'; //key color in adobe H235 S40 V60
var wvc = '#7F61B0';
var vc = '#9A5BA6';
var nhf = '#66995C'; //key color in adobe H110 S40 B60 for uplands
var opnhf = '#61B07C';
var rocky = '#9DB061';
var mine = '#A89F4F';
// create a flat image
var pncU = pncStack.unmask();
var pncFlat = pncU.select(0)
  .add(pncU.select(1).multiply(2))
  .add(pncU.select(2).multiply(3))
  .add(pncU.select(3).multiply(4))
  .add(pncU.select(4).multiply(5))
  .add(pncU.select(5).multiply(6))
  .add(pncU.select(6).multiply(7))
  .add(pncU.select(7).multiply(8))
  .add(pncU.select(8).multiply(9))
;
// Collect colors into a palette
var pncPalette = [hydro, swamp, ff, wvc, vc, nhf, opnhf, rocky, mine];
// Define min and max to stretch palette
var pncViz = {
  min: 1,
  max: 9,
  palette: pncPalette
};
// define category labels for legend
var pncLabels = [
  'Water',
  'Swamp Forest and Marsh',
  'Floodplain Forest',
  'Wet Valley Clayplain Forest',
  'Valley Clayplain Forest',
  'Northern Hardwood Forest',
  'Oak-Pine-NH Forest',
  'Rocky',
  'Quarry'
  ];
//  make legend
var pncLegend = tool.makeLegend(pncPalette, pncLabels, 9);
pncLegend.style().set({shown: false});
// ---------------------
// protected lands layer
// ---------------------
var proStackU = proStack.unmask();
var proFlat = proStackU.select(0)
  .add(proStackU.select(1).multiply(2))
  .add(proStackU.select(2).multiply(3))
  ;
var proPalette = [
  '#F2E16D',
  '#A2BF43',
  '#878C77'];
var proViz = {
  min: 1,
  max: 3,
  palette: proPalette
};
// define labels// define category labels for legend
var proLabels = [
  'Protected in agriculture',
  'Protected not in agriculture',
  'Not protected'
  ];
//  make legend
var proLegend = tool.makeLegend(proPalette, proLabels, 3);
proLegend.style().set({shown: false});
// --------------------
// prime ag soils layer
// --------------------
// var primeAg = ee.Image('users/jhowarth/midd_conservation_plan/agPrimeBinaryStack');
var agStackU = agStack.unmask();
var agFlat = agStackU.select(0)
  .add(agStackU.select(1).multiply(2))
  .add(agStackU.select(2).multiply(3))
  .add(agStackU.select(3).multiply(4))
  .add(agStackU.select(4).multiply(5))
  .add(agStackU.select(5).multiply(6))
  ;
var paPalette = [
  '#76B04F', // analogous to key
  '#86994D', // key color H75 S50 B60
  '#5C9499', // from key square
  '#5C7499', // from key triad
  '#99493D', // from key triad
  '#B0AD4F' // from key analogous
  ];
var paVis = {
  min: 1,
  max: 6,
  palette: paPalette
};
// define category labels for legend
var paLabels = [
  'Prime',
  'Statewide',
  'Wet unless drained',
  'Flooded',
  'Too steep',
  'Not important'
  ];
//  make legend
var paLegend = tool.makeLegend(paPalette, paLabels, 6);
paLegend.style().set({shown: false});
// ----------
// Land Cover
// ----------
var lcStack = ee.Image('users/jhowarth/midd_conservation_plan/lcStack');
// landCover vis
var lcLabels = [
  'Tree canopy',
  'Water',
  'Grass/Shrub',
  'Agriculture',
  'Developed'];
var lcPalette = [
  '#7C995C', // key H88 S40 V60
  '#5B85A6', // Analogous to key
  '#61B08A', // Analogous to key
  '#DBC97F', // Analogous to key
  '#905C99']; // complementary to key 
var lcFlat = lcStack.select(0)
  .add(lcStack.select(1).multiply(2))
  .add(lcStack.select(2).multiply(3))
  .add(lcStack.select(3).multiply(4))
  .add(lcStack.select(4).multiply(5))
  ;
var lcVis = {
  min: 1,
  max: 5,
  palette: lcPalette
};
//  make legend
var lcLegend = tool.makeLegend(lcPalette, lcLabels, 5);
lcLegend.style().set({shown: false});
// ---------------
// Dough and masks
// ---------------
// natural communities
var swampForest = pncStack.select(1).unmask();
var floodForest = pncStack.select(2).unmask();
var wetClayplainForest = pncStack.select(3).unmask();
var valleyClayplainForest = pncStack.select(4).unmask();
var nhForest = pncStack.select(6).unmask();
var oakPineForest = pncStack.select(5).unmask();
var pncWet = pncStack.select(0).unmask()
  .add(pncStack.select(1).unmask())
  .add(pncStack.select(2).unmask())
  .add(pncStack.select(3).unmask());
var pncUp = pncStack.select(4).unmask()
  .add(pncStack.select(5).unmask())
  .add(pncStack.select(6).unmask())
  .add(pncStack.select(7).unmask());
var pncClay = pncStack.select(3).unmask()
  .add(pncStack.select(4).unmask());
// protected lands
var pro = proStack.select(0).unmask()
  .add(proStack.select(1).unmask());
var notPro = proStack.select(2).unmask();
var agPro = proStack.select(0).unmask();
var natPro = proStack.select(1).unmask();
// land cover
var dev = lcStack.select(4).unmask();
var notDev = lcStack.select(0)
  .add(lcStack.select(1).unmask())
  .add(lcStack.select(2).unmask())
  .add(lcStack.select(3)).unmask();
var ag = lcStack.select(3).unmask();
var notAg = lcStack.select(0).unmask()
  .add(lcStack.select(1).unmask())
  .add(lcStack.select(2).unmask())
  .add(lcStack.select(4).unmask())
  .rename(['f_not_ag']);
var notAgOrDev = lcStack.select(0).unmask()
  .add(lcStack.select(1).unmask())
  .add(lcStack.select(2).unmask());
var tree = lcStack.select(0).unmask();
var allLands = lcStack.reduce(ee.Reducer.max());
// ag soils
var primeAg = agStack.select(0).unmask();
var stateAg = agStack.select(1).unmask();
var wetAg = agStack.select(2).unmask();
var floodAg = agStack.select(3).unmask();
var restoreAg = agStack.select(2).unmask()
  .add(agStack.select(3).unmask())
  ;
var importantAg = agStack.select(0).unmask()
  .add(agStack.select(1).unmask())
  .add(agStack.select(2).unmask())
  .add(agStack.select(3).unmask())
  ;
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
// COMPOSE MAP
//
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Initialize map
// --------------
var map = ui.Map();
// Reset layout
// --------------
ui.root.clear(); // Clear default layout
ui.root.add(map); // Add map to layout
// Set map properties
// ------------------
map.setOptions('HYBRID'); // change default basemap to satellite with labels
map.setControlVisibility({all: false}); // hide all default controls except for full extent
map.centerObject(parcels, 11); // center and zoom the map on the parcels dataset
// Make a dictioanary for layer names
// ----------------------------------
var layerNames = {
  pro: "Protected lands",
  pnc: 'Natural communities from soils',
  primeAg: 'Agricultural soils',
  lc: 'Land Cover',
  thematicMask: 'Thematic Mask',
  lcChoro: 'Land cover choropleth',
  pncChoro: 'Natural community choropleth',
  paChoro: 'Agriculture soil choropleth',
  parcelB: 'Parcels',
  blockB: 'Open space block',
  townB: 'Town '
};
// create place holders for selection layers
// -----------------------------------------
var placeHolder = ee.Feature(ee.Geometry.Point([-73, 44]));
// Add layers to the map
// ---------------------
map.addLayer(agFlat, paVis, layerNames.primeAg, 0,1);
map.addLayer(pncFlat, pncViz, layerNames.pnc, 0,1);
map.addLayer(lcFlat, lcVis, layerNames.lc, 0, 1);
map.addLayer(proFlat, proViz, layerNames.pro, 0, 1);
map.addLayer(placeHolder, {color: '#FFFF00'}, layerNames.paChoro,0);
map.addLayer(placeHolder, {color: '#FFFF00'}, layerNames.pncChoro,0);
map.addLayer(placeHolder, {color: '#FFFF00'}, layerNames.lcChoro,0);
map.addLayer(placeHolder, {color: '#FFFF00'}, layerNames.thematicMask,0);
map.addLayer(parcelOutlines, {palette: 'white'}, layerNames.parcelB, 1, 0.3);
map.addLayer(townOutlines, {palette: '#b3b3b3'}, layerNames.townB, 1, 0.75);
map.addLayer(placeHolder, {color: '#FFFF00'}, 'Selected Parcel',0);
map.addLayer(placeHolder, {color: '#FFFF00'}, 'Selected Block',0);
map.addLayer(placeHolder, {color: '#FFFF00'}, 'Selected Town',0);
// create a dictionary to track layer drawing order
// ------------------------------------------------
var layers = {
  pa:0,
  pnc: 1,
  lc:2,
  pro: 3,
  paChoro: 4,
  pncChoro: 5,
  lcChoro: 6,
  thematicMask: 7,
  parcelOutlines: 8,
  townOutlines: 9,
  selectParcel: 10,
  selectBlock: 11,
  selectTown: 12
  };
// NOTE: This dictionary make more sense later when we use it to make the map interactive.
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
// MAKE WIDGET LAYOUT
//
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// -----------------------
// Global layout variables
// -----------------------
var layoutStyle = {
  vert: 'vertical',
  horz: 'horizontal', 
  stub: '150px',
  inset: '75px',
  left: '330px',
  insideLeft: '300',
  right: '220px',
  insideRight: '180px',
  pad1: '2px 2px 2px 2px',
  pad2: '1px 2px 1px 2px',
  pad3: '1px 1px 1px 1px'
};
// ----------------------------------
// START LAYOUT
// ----------------------------------
// ----------------------------------
// Make Level 1 widgets
// ----------------------------------
// make dictionary for labels
// --------------------------
var labelsL1 = {
  startInfo: "Show options"
};
// make panel - top left
// ---------------------
var startPanel = tool.makePanel(layoutStyle.stub, 'top-left', true, layoutStyle.pad1, layoutStyle.vert);
// make checkbox
// -------------
var startCheck = tool.makeCheckBox(labelsL1.startInfo, tool.h2);
// make actions
// ------------
startCheck.onChange(function(checked) {
  actionPanel.style().set('shown', checked);
  exploreTownPanel.style().set('shown', checked);
  layerPanel.style().set('shown', checked);
  selectPanel.style().set('shown', checked);
  choroplethPanel.style().set('shown', checked);
  gapPanel.style().set('shown', checked);
  creditsPanel.style().set('shown', checked);
});
// compose widget layout
// ---------------------
map.add(startPanel);
startPanel.add(startCheck); // Add check to panel
// ----------------------------------
// Make Level 2 widgets
// ----------------------------------
// make dictionary for labels
// --------------------------
var labelsL2 = {
  title: "Conservation Atlas\nAddison County, VT",
  exploreTownInstructions: 'Explore a town',
  selectInstructions: "Explore a location",
  layerInstructions: "Explore layers",
  author: 'Jeff Howarth\nGeography Dept\nMiddlebury College\njhowarth@middlebury.edu',
  abenaki: 'This is Abenaki land.'
};
// make main ACTIONS panel
var actionPanel = tool.makePanel(layoutStyle.left, 'top-left', false, layoutStyle.pad1, layoutStyle.vert);  
// add widget to map
map.add(actionPanel);
// ----------------------------
// TITLE component
// ----------------------------
// Make label
var titleLabel = tool.makeLabel(labelsL2.title, tool.h1);
// add widget to map
actionPanel.add(titleLabel);
// --------------------------
//
// SHOW LAYERS component
//
// --------------------------
// make panel
var layerPanel = tool.makePanel(layoutStyle.left, 'top-right', true, layoutStyle.pad1, layoutStyle.vert);
var layerOptionsPanel = tool.makePanel(layoutStyle.right, 'top-right', false, layoutStyle.pad1, layoutStyle.vert);
var maskPanel = tool.makePanel(layoutStyle.left, 'top-left', false, layoutStyle.pad1, layoutStyle.vert);
var maskLegendPanel = tool.makePanel(layoutStyle.left, 'top-left', false, layoutStyle.pad1, layoutStyle.vert);
var proTLPanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad1, layoutStyle.vert);
var ncTLPanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad1, layoutStyle.vert);
var paTLPanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad1, layoutStyle.vert);
var lcTLPanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad1, layoutStyle.vert);
// make label
var thematicLayersLabel = tool.makeLabel('Thematic layers', tool.h2);
// make checkbox
var layerCheck = tool.makeCheckBox(labelsL2.layerInstructions, tool.h2);
layerCheck.onChange(function(checked) {
  // exploreTownPanel.style().set('shown', !(checked)); // hide this level
  layerOptionsPanel.style().set('shown', checked); // show self sub-level
  maskPanel.style().set('shown', checked);
  // selectPanel.style().set('shown', !(checked)); // hide this level
  // creditsPanel.style().set('shown', !(checked));
  // choroplethPanel.style().set('shown', !(checked)); // added with choropleth addition
});
// protected lands 
var proCheck = tool.makeCheckBox(layerLabels.pro, tool.h3);
proCheck.onChange(function(checked) {
  map.layers().get(layers.pro).setShown(checked);
  proSlider.style().set('shown', checked);
  proLegend.style().set('shown', checked);
  ncTLPanel.style().set('shown', !(checked));
  paTLPanel.style().set('shown', !(checked));
  lcTLPanel.style().set('shown', !(checked));
});
// land cover 
var lcCheck = tool.makeCheckBox(layerLabels.lc, tool.h3);
lcCheck.onChange(function(checked) {
  map.layers().get(layers.lc).setShown(checked);
  lcSlider.style().set('shown', checked);
  lcLegend.style().set('shown', checked);
  proTLPanel.style().set('shown', !(checked));
  ncTLPanel.style().set('shown', !(checked));
  paTLPanel.style().set('shown', !(checked));
});
// natural communities
var ncCheck = tool.makeCheckBox(layerLabels.nc, tool.h3);
ncCheck.onChange(function(checked) {
  map.layers().get(layers.pnc).setShown(checked);
  ncSlider.style().set('shown', checked);
  pncLegend.style().set('shown', checked);
  proTLPanel.style().set('shown', !(checked));
  paTLPanel.style().set('shown', !(checked));
  lcTLPanel.style().set('shown', !(checked));
});
// prime ag soils
var paCheck = tool.makeCheckBox(layerLabels.pa, tool.h3);
paCheck.onChange(function(checked) {
  map.layers().get(layers.pa).setShown(checked);
  paSlider.style().set('shown', checked);
  paLegend.style().set('shown', checked);
  proTLPanel.style().set('shown', !(checked));
  ncTLPanel.style().set('shown', !(checked));
  lcTLPanel.style().set('shown', !(checked));
});
// make sliders
var ncSlider = tool.makeOpacitySlider(map, layers.pnc);
var proSlider = tool.makeOpacitySlider(map, layers.pro);
var paSlider = tool.makeOpacitySlider(map, layers.pa);
var lcSlider = tool.makeOpacitySlider(map, layers.lc);
var maskSlider = tool.makeOpacitySlider(map, layers.thematicMask);
// make masks
var maskPalette = ['black'];
var maskImageVis = {min:0, max:1, palette:maskPalette};
var maskHolderVis = {color: 'black'};
var thematicMasks = {
  'No mask': ['Show all', placeHolder, maskHolderVis , 0],
  'Lands in agriculture': ['In agricultural', ag.selfMask(), maskImageVis, 1.0],
  'Lands not in agriculture': ['Not in agriculture', ag.eq(0).selfMask(), maskImageVis, 1.0],
  'Developed lands':  ['Developed lands', dev.selfMask(), maskImageVis, 1.0],
  'With tree canopy': ['With tree canopy', tree.selfMask(), maskImageVis, 1.0],
  'Without tree canopy': ['Without tree canopy', tree.eq(0).selfMask(), maskImageVis, 1.0]
 };
var maskVis = {
  vis: maskImageVis,
  shown:1,
  opacity:1,
  label: ''
};
// select masks
var thematicMaskSelect = ui.Select({
  items: Object.keys(thematicMasks),
  style: {
    shown: true,
    width: layoutStyle.insideRight
  },
  placeholder: 'BLACK OUT OPTIONS',
  onChange: function(key) {
    // selectStyles.parcelStyle = parcelStyleOptions[key][0];
    maskVis.label = thematicMasks[key][0];
    maskVis.vis = thematicMasks[key][2];
    maskVis.shown = thematicMasks[key][3];
    map.layers().set(layers.thematicMask, ui.Map.Layer(thematicMasks[key][1])
      .setVisParams(maskVis.vis)
      .setShown(maskVis.shown)
      .setName(maskVis.label));
    maskSlider.style().set('shown', true);
    maskLegendPanel.clear();
    maskLegendPanel.add(tool.makeLegend(maskPalette, [maskVis.label], 1));
    maskLegendPanel.style().set('shown', true);
  }
});
// add widgets to layout
actionPanel.add(layerPanel);
layerPanel.add(layerCheck);
map.add(layerOptionsPanel);
layerOptionsPanel.add(thematicLayersLabel);
layerOptionsPanel.add(proTLPanel);
proTLPanel.add(proCheck);
proTLPanel.add(proSlider);
proTLPanel.add(proLegend);
layerOptionsPanel.add(lcTLPanel);
lcTLPanel.add(lcCheck);
lcTLPanel.add(lcSlider);
lcTLPanel.add(lcLegend);
layerOptionsPanel.add(ncTLPanel);
ncTLPanel.add(ncCheck);
ncTLPanel.add(ncSlider);
ncTLPanel.add(pncLegend);
layerOptionsPanel.add(paTLPanel);
paTLPanel.add(paCheck);
paTLPanel.add(paSlider);
paTLPanel.add(paLegend);
layerOptionsPanel.add(maskPanel);
maskPanel.add(thematicMaskSelect);
maskPanel.add(maskSlider);
maskPanel.add(maskLegendPanel);
// --------------------------
// --------------------------
//
// EXPLORE TOWN component
//
// --------------------------
// --------------------------
// function to move into toolbox
var centerRegion = function(region, townField, townName, scale) {
  map.centerObject(region.filter(ee.Filter.eq(townField, townName)), scale);
};
//var townList = tool.listUniqueAttributes(town, townNameProperty);
var regionVariables = {
  townField: 'TOWNNAME',
  townPrompt: 'Select a town...'
};
var townTargets = {
  'Addison': 'ADDISON',
  'Bridport': 'BRIDPORT',
  'Bristol': 'BRISTOL',
  'Cornwall': 'CORNWALL',
  'Ferrisburgh': 'FERRISBURGH',
  'Goshen': 'GOSHEN',
  'Granville': 'GRANVILLE',
  'Hancock': 'HANCOCK',
  'Leicester': 'LEICESTER',
  'Lincoln': 'LINCOLN',
  'Middlebury': 'MIDDLEBURY',
  'Monkton': 'MONKTON',
  'New Haven': 'NEW HAVEN',
  'Orwell': 'ORWELL',
  'Panton': 'PANTON',
  'Ripton': 'RIPTON',
  'Salisbury': 'SALISBURY',
  'Shoreham': 'SHOREHAM',
  'Starksboro': 'STARKSBORO',
  'Vergennes': 'VERGENNES',
  'Waltham': 'WALTHAM',
  'Weybridge': 'WEYBRIDGE',
  'Whiting': 'WHITING'
  };
var makeSelectList = function(target, prompt) {
  return ui.Select({
    items: Object.keys(target),
    placeholder: prompt,
    style: {
      shown: true,
      width: '300px',
      fontSize: '14px',
      fontWeight: 'bold'}
      });
    };
var townTargetSelect = makeSelectList(townTargets, regionVariables.prompt);
townTargetSelect.onChange(function(key) {
    zonalVariables.townName = townTargets[key];
    centerRegion(town, regionVariables.townField, zonalVariables.townName, 13);
    map.layers().get(layers.parcelOutlines).setShown(true);
    var selectTown = town.filter(ee.Filter.eq(regionVariables.townField, zonalVariables.townName));
    map.layers().set(layers.selectTown, ui.Map.Layer(selectTown.style({color: '#FFCF0D', fillColor: '00000000'})).setName(zonalVariables.townName));
    townChartPanel.clear();
    townChartPanel.add(tool.makeStackedChart(proStack, selectTown, 'TOWNNAME', proPalette, layerNames.pro));
    townChartPanel.add(tool.makeStackedChart(lcStack, selectTown, 'TOWNNAME', lcPalette, layerNames.lc));
    townChartPanel.add(tool.makeStackedChart(pncStack, selectTown, 'TOWNNAME', pncPalette, layerNames.pnc));
    // townChartPanel.add(tool.makeStackedChart(pncStack.updateMask(proFlat.eq(2)), selectTown, 'TOWNNAME', pncPalette, 'Nat Com protected & not ag'));
    townChartPanel.add(tool.makeStackedChart(agStack, selectTown, 'TOWNNAME', paPalette, layerNames.primeAg));
  });
// ****************************************************************
// NOTE: Zonal variable dictionary is defined in Choropleth section
// ****************************************************************
// make panel
var exploreTownPanel = tool.makePanel(layoutStyle.left, 'top-left', false, layoutStyle.pad1, layoutStyle.vert);
var exploreTownOptionsPanel = tool.makePanel(layoutStyle.left, 'top-left', false, layoutStyle.pad1, layoutStyle.vert);
var townResultsPanel = tool.makePanel(layoutStyle.insideLeft, 'top-left', true, layoutStyle.pad3, layoutStyle.vert);
var townChartPanel = tool.makePanel(layoutStyle.insideLeft, 'top-left', true, layoutStyle.pad3, layoutStyle.vert);
// make label
// var townLabel = tool.makeLabel("Click map for info about town...", tool.h3);
// var exploreTownInstructionsLabel = tool.makeLabel(labelsL3.exploreTownInstructions, tool.h3);
//make checkbox
var exploreTownCheck = tool.makeCheckBox(labelsL2.exploreTownInstructions, tool.h2);
exploreTownCheck.onChange(function(checked) {
  exploreTownOptionsPanel.style().set('shown', checked); // show self sub-level
  selectPanel.style().set('shown', !(checked)); // hide this level
  // layerPanel.style().set('shown', !(checked)); // hide this level
  creditsPanel.style().set('shown', !(checked)); 
  choroplethPanel.style().set('shown', !(checked)); // added with choropleth addition
  gapPanel.style().set('shown', !(checked));
});
// add widgets to layout
actionPanel.add(exploreTownPanel);
exploreTownPanel.add(exploreTownCheck);
exploreTownPanel.add(exploreTownOptionsPanel);
exploreTownOptionsPanel.add(townTargetSelect);
exploreTownOptionsPanel.add(townResultsPanel);
// townResultsPanel.add(townLabel);
townResultsPanel.add(townChartPanel);
// --------------------------
// --------------------------
//
// QUERY BY LOCATION component
//
// --------------------------
// --------------------------
// make dictionary to keep track of variables
// ------------------------------------------
var selectValues = {
  point: null,
  targetParcel: parcels,
  targetTown: town,
  targetBlock: os,
  parcelName: 'ACREAGE',
  targetName: 'TOWNNAMEMC',
  blockName: 'name',
  selectParcelName: 'Selected Parcel',
  selectBlockName: 'Selected Block',
  selectTownName: 'Selected Name'
};
// --------------------
// make a click handler
// --------------------
function handleMapClick(coordinates) {
  selectValues.point = ee.Geometry.Point([coordinates.lon, coordinates.lat]);
  updateSelection();
}
// make update function
// --------------------
var updateSelection = function(){
  var selectParcel = selectValues.targetParcel.filterBounds(selectValues.point);
  var selectBlock = selectValues.targetBlock.filterBounds(selectValues.point);
  checkVis.parcel = true; 
  checkVis.block = false;
  selectBlockCheck.setValue(checkVis.block);
  selectParcelCheck.setValue(checkVis.parcel);
  // var selectTown = selectValues.targetTown.filterBounds(selectValues.point);
  tool.updateOverlay(selectValues.point, selectValues.targetParcel, selectStyles.parcelStyle, layers.selectParcel, selectValues.selectParcelName, map);
  //tool.updateOverlay(selectValues.point, selectValues.targetBlock, selectStyles.blockStyle, layers.selectBlock, selectValues.selectBlockName, map);
  // tool.updateOverlay(selectValues.point, selectValues.targetTown, selectStyles.townStyle, layers.selectTown, selectValues.selectTownName, map);
  tool.getAttributeText(selectParcel, 'owner1').evaluate(function(val){ownerLabel.setValue('OWNER:   ' + val)});
  tool.getAttributeText(selectParcel, 'e911addr').evaluate(function(val){e911Label.setValue('ADDRESS: ' + val)});
  tool.getAttributeNumber(selectParcel, 'acres', '%.2f').evaluate(function(val){acresLabel.setValue('ACRES:    ' + val)});
  tool.getAttributeText(selectParcel, 'span').evaluate(function(val){valueLabel.setValue('SPAN:      ' + val)});
  // tool.getAttributeText(selectTown, 'TOWNNAMEMC').evaluate(function(val){townLabel.setValue('TOWN: ' + val)});
  tool.getAttributeText(selectBlock, 'name').evaluate(function(val){blockLabel.setValue('BLOCK: ' + val)}); 
  tool.getAttributeNumber(selectBlock, 'acres', '%.2f').evaluate(function(val){blockAcreLabel.setValue('ACRES:    ' + val)});
  parcelChartPanel.clear();
  parcelChartPanel.add(tool.makeStackedChart(proStack, selectParcel, 'owner1', proPalette, layerNames.pro));
  parcelChartPanel.add(tool.makeStackedChart(lcStack, selectParcel, 'owner1', lcPalette, layerNames.lc));
  parcelChartPanel.add(tool.makeStackedChart(pncStack, selectParcel, 'owner1', pncPalette, layerNames.pnc));
  parcelChartPanel.add(tool.makeStackedChart(agStack, selectParcel, 'owner1', paPalette, layerNames.primeAg));
  blockChartPanel.clear();
  blockChartPanel.add(tool.makeStackedChart(proStack, selectBlock, 'name', proPalette, layerNames.pro));
  blockChartPanel.add(tool.makeStackedChart(lcStack, selectBlock, 'name', lcPalette, layerNames.lc));
  blockChartPanel.add(tool.makeStackedChart(pncStack, selectBlock, 'name', pncPalette, layerNames.pnc));
  blockChartPanel.add(tool.makeStackedChart(agStack, selectBlock, 'name', paPalette, layerNames.primeAg));
};
// add interactivity to map
// ------------------------
map.onClick(handleMapClick);
// ------------------------
// UI development
// ------------------------
//check visibility configuration
var checkVis = {
  parcel: true,
  block: false
} ;
// make panel
// -----------
var selectPanel = tool.makePanel(layoutStyle.left, 'top-left', false, layoutStyle.pad1, layoutStyle.vert);
var queryPanel = tool.makePanel(layoutStyle.left, 'top-left', false, layoutStyle.pad1, layoutStyle.vert);
var selectLayerPanel = tool.makePanel(layoutStyle.right, 'top-right', false, layoutStyle.pad1, layoutStyle.vert);
// select detail group
var selectDetailPanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad2, layoutStyle.vert);
var selectDetailParcelPanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad2, layoutStyle.horz);
var selectDetailBlockPanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad2, layoutStyle.horz);
// select layer group
var appParcelLabelPanel = tool.makePanel(layoutStyle.inset, 'top-left', true, layoutStyle.pad2, layoutStyle.vert);
var appBlockLabelPanel = tool.makePanel(layoutStyle.inset, 'top-left', true, layoutStyle.pad2, layoutStyle.vert);
var appParcelPickPanel = tool.makePanel(layoutStyle.right, 'top-left', true, layoutStyle.pad2, layoutStyle.vert);
var appBlockPickPanel = tool.makePanel(layoutStyle.right, 'top-left', true, layoutStyle.pad2, layoutStyle.vert);
// var selectDetailTownPanel = tool.makePanel(layoutStyle.inset, 'top-left', true, layoutStyle.pad2, layoutStyle.vert);
// selection appearance panel
// var selectAppearancePanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad1, layoutStyle.vert);
// parcel appearance group
// var appParcelPanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad2, layoutStyle.horz);
// block appearance group
// var appBlockPanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad2, layoutStyle.horz);
// // town appearance group
// var appTownPanel = tool.makePanel(layoutStyle.left, 'top-left', true, layoutStyle.pad2, layoutStyle.horz);
// var appTownLabelPanel = tool.makePanel(layoutStyle.inset, 'top-left', true, layoutStyle.pad2, layoutStyle.vert);
// var appTownPickPanel = tool.makePanel(layoutStyle.inset, 'top-left', true, layoutStyle.pad2, layoutStyle.vert);
// make checkboxes
// ---------------
// Let people work with selected features
var selectCheck = tool.makeCheckBox(labelsL2.selectInstructions, tool.h2);
selectCheck.onChange(function(checked) {
  queryPanel.style().set('shown', checked);
  // selectPanel.style().set('shown', checked);
  selectLayerPanel.style().set('shown', checked);
  exploreTownPanel.style().set('shown', !(checked));
  creditsPanel.style().set('shown', !(checked));
  choroplethPanel.style().set('shown', !(checked));
  gapPanel.style().set('shown', !(checked));
});
var selectParcelCheck = tool.makeCheckBox('Selected parcel', tool.h3);
selectParcelCheck.onChange(function(checked) {
  checkVis.parcel = checked;
  map.layers().get(layers.selectParcel).setShown(checkVis.parcel);
});
var selectBlockCheck = tool.makeCheckBox('Selected block', tool.h3);
selectBlockCheck.onChange(function(checked) {
  checkVis.block = checked;
  map.layers().get(layers.selectBlock).setShown(checkVis.block);
});
// make labels
// -----------
var labelsL3 = {
  // exploreTownInstructions: "Select a town from the list",
  selectInstructions: "Click a location on the map.",
  selectLayers: 'Selected regions',
  // selectDetails: '2. Show details of a selected region',
  // changeStyle: '1. Choose appearance of selected regions',
  // showLayers: '2. Show a thematic layer',
  // appearanceParcel: "Show parcel details:",
  // appearanceBlock: 'Show block details:',
  // appearanceTown: 'Town:',
  parcelDetail: "Parcel details",
  blockDetail: "Block details",
  parcelChart: "Parcel charts",
  blockChart: "Block charts"
  // town: "Town
};
var selectLayersLabel = tool.makeLabel(labelsL3.selectLayers, tool.h2);
var selectInstructionsLabel = tool.makeLabel(labelsL3.selectInstructions, tool.h3);
var selectDetailLabel = tool.makeLabel(labelsL3.selectDetails, tool.h3);
var changeStyleLabel = tool.makeLabel(labelsL3.changeStyle, tool.h3);
var showLayerLabel = tool.makeLabel(labelsL3.showLayers, tool.h3);
// var appParcelLabel = tool.makeLabel(labelsL3.appearanceParcel, tool.h3);
// var appBlockLabel = tool.makeLabel(labelsL3.appearanceBlock, tool.h3);
// var appTownLabel = tool.makeLabel(labelsL3.appearanceTown, tool.h3);
// Make selected region style pick lists
// --------------------------------------
var selectStyles = {
  parcelStyle: {color: '#FFFF00', fillColor: '00000000'},
  blockStyle: {color: '00000000', fillColor: '#9CE80C59'},
  // townStyle: {color: '#FFCF0D', fillColor: '00000000'} 
};
var parcelStyleOptions = {
  "Show boundary": [{color: '#FFFF00', fillColor: '00000000'}],
  "Show fill": [{color: '00000000', fillColor: '#FFFF0059'}]
};
var blockStyleOptions = {
  "Show boundary": [{color: '#9CE80C', fillColor: '00000000'}],
  "Show fill": [{color: '00000000', fillColor: '#9CE80C59'}],
};
// var townStyleOptions = {
//   Boundary: [{color: '#FFCF0D', fillColor: '00000000'}],
//   Fill: [{color: '00000000', fillColor: '#FFCF0D59'}],
//   Blank: [{color: '00000000', fillColor: '00000000'}]
// };
var parcelSelectStyle = ui.Select({
  items: Object.keys(parcelStyleOptions),
  style: {
    shown: true,
    width: layoutStyle.insideRight
  },
  placeholder: 'Boundary',
  onChange: function(key) {
    selectStyles.parcelStyle = parcelStyleOptions[key][0];
    tool.updateOverlay(selectValues.point, selectValues.targetParcel, selectStyles.parcelStyle, layers.selectParcel, selectValues.selectParcelName, map);
  }
});
var blockSelectStyle = ui.Select({
  items: Object.keys(blockStyleOptions),
  style: {
    shown: true,
    width: layoutStyle.insideRight
  },
  placeholder: 'Fill',
  onChange: function(key) {
    selectStyles.blockStyle = blockStyleOptions[key][0];
    tool.updateOverlay(selectValues.point, selectValues.targetBlock, selectStyles.blockStyle, layers.selectBlock, selectValues.selectBlockName, map);
  }
});
// var townSelectStyle = ui.Select({
//   items: Object.keys(townStyleOptions),
//   style: {
//     shown: true
//   },
//   placeholder: 'Boundary',
//   onChange: function(key) {
//     selectStyles.townStyle = townStyleOptions[key][0];
//     tool.updateOverlay(selectValues.point, selectValues.targetTown, selectStyles.townStyle, layers.selectTown, selectValues.selectTownName, map);
//   }
// });
// make checkboxes
// ---------------
// selection layers
// -----------------
// parcels
var parcelDetailCheck = tool.makeCheckBox(labelsL3.parcelDetail, tool.h3);
parcelDetailCheck.onChange(function(checked) {
  parcelResultsPanel.style().set('shown', checked);
  // parcelChartPanel.style().set('shown', checked);
});
var parcelChartCheck = tool.makeCheckBox(labelsL3.parcelChart, tool.h3);
parcelChartCheck.onChange(function(checked) {
  // parcelResultsPanel.style().set('shown', checked);
  parcelChartPanel.style().set('shown', checked);
});
// blocks
var blockDetailCheck = tool.makeCheckBox(labelsL3.blockDetail, tool.h3);
blockDetailCheck.onChange(function(checked) {
  blockResultsPanel.style().set('shown', checked);
  // blockChartPanel.style().set('shown', checked);
});
var blockChartCheck = tool.makeCheckBox(labelsL3.blockChart, tool.h3);
blockChartCheck.onChange(function(checked) {
  // blockResultsPanel.style().set('shown', checked);
  blockChartPanel.style().set('shown', checked);
});
// // town
// var townCheck = tool.makeCheckBox(labelsL3.town, tool.h3);
// townCheck.onChange(function(checked) {
//   townResultsPanel.style().set('shown', checked);
//   townChartPanel.style().set('shown', checked);
// });
// add widgets to layout
// ---------------------
actionPanel.add(selectPanel);
selectPanel.add(selectCheck);
selectPanel.add(queryPanel);
queryPanel.add(selectInstructionsLabel);
// queryPanel.add(selectDetailLabel);
queryPanel.add(selectDetailPanel);
selectDetailPanel.add(selectDetailParcelPanel);
selectDetailParcelPanel.add(parcelDetailCheck);
selectDetailParcelPanel.add(parcelChartCheck);
// selectDetailParcelPanel.add(appParcelLabelPanel);
// appParcelLabelPanel.add(appParcelLabel);
appParcelPickPanel.add(parcelSelectStyle);
selectDetailPanel.add(selectDetailBlockPanel);
selectDetailBlockPanel.add(blockDetailCheck);
selectDetailBlockPanel.add(blockChartCheck);
// selectDetailBlockPanel.add(appBlockLabelPanel);
// appBlockLabelPanel.add(appBlockLabel);
appBlockPickPanel.add(blockSelectStyle);
map.add(selectLayerPanel);
selectLayerPanel.add(selectLayersLabel);
selectLayerPanel.add(selectParcelCheck);
selectLayerPanel.add(appParcelPickPanel);
selectLayerPanel.add(selectBlockCheck);
selectLayerPanel.add(appBlockPickPanel);
// selectDetailPanel.add(selectDetailTownPanel);
// selectDetailTownPanel.add(townCheck);
// queryPanel.add(selectAppearancePanel);
// selectAppearancePanel.add(changeStyleLabel);
// selectAppearancePanel.add(appParcelPanel);
// selectAppearancePanel.add(appBlockPanel);
// selectAppearancePanel.add(appTownPanel);
// // appTownPanel.add(appTownLabelPanel);
// // appTownPanel.add(appTownPickPanel);
// // appTownLabelPanel.add(appTownLabel);
// // appTownPickPanel.add(townSelectStyle);
// // layerOptionsPanel.add(showLayerLabel);
// ----------------------------------
// Make sub-panels
// ----------------------------------
// make labels
// -----------
var labelsL4 = {
  instructions: 'Adjust opacity',
  town: "Town",
  block: "Block",
  parcel: "Parcel"
};
// make panels - right margin
var parcelResultsPanel = tool.makePanel(layoutStyle.insideLeft, 'top-left', false, layoutStyle.pad3, layoutStyle.vert);
var parcelChartPanel = tool.makePanel(layoutStyle.insideLeft, 'top-left', false, layoutStyle.pad3, layoutStyle.vert);
var blockResultsPanel = tool.makePanel(layoutStyle.insideLeft, 'top-left', false, layoutStyle.pad3, layoutStyle.vert);
var blockChartPanel = tool.makePanel(layoutStyle.insideLeft, 'top-left', false, layoutStyle.pad3, layoutStyle.vert);
// make result labels
// ------------------
// parcel
var ownerLabel = tool.makeLabel("Click map for info about parcel...", tool.h3);
var acresLabel = tool.makeLabel("", tool.h3);
var valueLabel = tool.makeLabel("", tool.h3);
var e911Label = tool.makeLabel("", tool.h3);
// block
var blockLabel = tool.makeLabel("Click map for info about block", tool.h3);
var blockAcreLabel = tool.makeLabel("", tool.h3);
// town
// Add widgets to panels
// ------------------------
// selection results panels
queryPanel.add(parcelResultsPanel);
queryPanel.add(parcelChartPanel);
parcelResultsPanel.add(ownerLabel);
parcelResultsPanel.add(e911Label);
parcelResultsPanel.add(acresLabel);
parcelResultsPanel.add(valueLabel);
queryPanel.add(blockResultsPanel);
queryPanel.add(blockChartPanel);
blockResultsPanel.add(blockLabel);
blockResultsPanel.add(blockAcreLabel);
// ----------------------------
//
// CREDITS component
//
// ----------------------------
// make panel
var creditsPanel = tool.makePanel(layoutStyle.stub, 'bottom-left', false, layoutStyle.pad1, layoutStyle.vert);
// Make labels
var authorLabel = tool.makeLabel(labelsL2.author, tool.credits);
var abenakiLabel = tool.makeLabel(labelsL2.abenaki, tool.credits);
// Add widgets to layout
map.add(creditsPanel);
creditsPanel.add(authorLabel);
creditsPanel.add(abenakiLabel);
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
// Make Choropleths component 
//
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// functions for toolbox
// ---------------------
var makeAcresImage = function() {
  return ee.Image.pixelArea().divide(4046.86);
};
var maskDoughLand = function(d, m) {
  return d.multiply(m);
};
var pncMaskDough = function(d, lm, pm) {
  return d.multiply(lm).multiply(pm);
};
var zonalOperation = function(d, c) {
  var zonalOptions = {
    collection: c,
    reducer: ee.Reducer.sum(),
    scale: 5
  };
  return d.multiply(makeAcresImage()).reduceRegions(zonalOptions);
};
var normFeatures = function(fc1, fc2, field) {
  return tool.makeImageFromFeatures(fc1, field)
    .divide(tool.makeImageFromFeatures(fc2, field));
};
var mapPercentThemeByRegion = function(theme, region) {
  var t = zonalOperation(theme, region);
  var b = zonalOperation(ee.Image(1).byte(), region);
  return normFeatures(t, b, 'sum');
};
var mapPercentParcelOfTown = function(theme, townName) {
  var t = zonalOperation(theme, parcels.filter(ee.Filter.eq('town', townName)));
  var b = zonalOperation(theme, town.filter(ee.Filter.eq('TOWNNAME', townName)));
  return normFeatures(t, b, 'sum');
};
var test = mapPercentParcelOfTown(wetClayplainForest, 'MIDDLEBURY', ag);
// choose variables
// ----------------
var cutterList = {
  'Parcel': ['Percent of parcel', parcels],
  'Open space block': ['Percent of open space block', os],
  'Town': ['Percent of town', town]
};
var landDoughList = {
  'All lands and waters': ['', ee.Image(1).byte(), '#75676B', 1.0],
  'Lands in agriculture': [' in agriculture', ag, '#DBD580', 1.0],
  'Lands not in agriculture': [' not in agriculture', ag.eq(0), '#7FA851', 1.0],
  'Developed land':  [' in development', dev, '#A8405C', 0.2],
  'Undeveloped lands': [' with no development', notDev, '#A8A248', 1.0],
  'With tree canopy': [' with tree canopy', tree, '#59A864', 1.0]
 };
var pncDoughList = {
  'Swamp Forest and Marsh': [' with swamp forest soils', swampForest, '#618BB0', 0.5],
  'Floodplain Forest': [' with floodplain forest soils', floodForest, '#5C6199', 0.5],
  'Wet Clayplain Forest': [' with wet clayplain forest soils', wetClayplainForest, '#7F61B0', 0.5],
  'Valley Clayplain Forest': [' with valley clayplain forest soils', valleyClayplainForest, '#9A5BA6', 0.5],
  'Northern Hardwood Forest': [' with northern hardwood forest soils', nhForest, '#66995C', 0.5],
  'Oak-Pine-NH Forest': [' with oak-pine-NH forest soils', oakPineForest, '#61B07C', 0.5],
  'All wetland Forests': [' with wetland forest soils', pncWet, '#5C6199', 0.5],
  'Clayplain Forest': [' with clayplain forest soils', pncClay, '#7F61B0', 0.5],
  'All Upland Forests': [' with upland forest soils', pncUp, '#66995C', 0.5],
};
var proMaskList = {
  'With or without protection': ['', ee.Image(1).byte()],
  'Protected from development': [' and protected from development', pro],
  'Not protected from development': [' and not protected from development', notPro]
};
var paDoughList = {
  'Prime soils': [' with prime ag importance', primeAg, '#76B04F', 0.3],
  'Statewide soils': [' with statewide ag importance', stateAg, '#86994D', 0.3],
  'All important soils': [' with important ag soils', importantAg, '#76B04F', 0.3],
  'Important but too wet unless drained': [' with important soil that is too wet unless drained', wetAg, '#5C9499', 0.3],
  'Important but often flooded': [' with prime soil that frequently floods', floodAg, '#5C7499', 0.3],
  'Potential wetland restoration': [' with wet soils that could be restored', restoreAg, '#5C7499', 0.3]
};
// master config dictionary
var tempHolder = ee.Image(1).byte();
var zonalVariables = {
  dLand: landDoughList['All lands and waters'][1],
  dLandTitle: '',
  cLand: cutterList['Town'][1],
  cLandTitle: '',
  mLand: landDoughList['All lands and waters'][1],
  mLandTitle: '',
  dPnc: proMaskList['With or without protection'][1],
  dPncTitle: '',
  cPnc: tempHolder,
  cPncTitle: '',
  lmPnc: tempHolder,
  lmPncTitle: '',
  pmPnc: tempHolder,
  pmPncTitle: '',
  dPa: tempHolder,
  dPaTitle: '',
  cPa: tempHolder,
  cPaTitle: '',
  lmPa: tempHolder,
  lmPaTitle: '',
  pmPa: tempHolder,
  pmPaTitle: '',
  landMax: 1,
  pncMax: 1,
  paMax: 0.3,
  landColorMax: '#CB69DB',
  pncColorMax: '#61B07C',
  paColorMax: '#76B04F',
  townName: 'MIDDLEBURY'
};
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// UI Development
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Label list
// ----------
var labelList = {
  title: 'Choropleth layers',
  lcTitle: 'Land cover',
  pncTitle: 'Community soils',
  paTitle: 'Agricultural soils',
  theme: 'Map theme',
  unit: 'Mapping unit',
  constraints: 'Constraints',
  landCover: 'Land Cover',
  pro: 'Protections',
  patience: 'Layers may be slow...\nPlease be patient...',
  displayMax: 'Max:',
  displayMin: 'Min:',
  opacity: 'Opacity:',
};
// -------------
// ACTION WIDGET
// -------------
// land panel
var landDoughLabel = tool.makeLabel(labelList.theme, tool.h3);
var landCutterLabel = tool.makeLabel(labelList.unit, tool.h3);
var landMaskLabel = tool.makeLabel(labelList.constraints, tool.h3);
// pnc panel
var pncDoughLabel = tool.makeLabel(labelList.theme, tool.h3);
var pncCutterLabel = tool.makeLabel(labelList.unit, tool.h3);
var pncLandMaskLabel = tool.makeLabel(labelList.landCover, tool.h3);
var pncProMaskLabel = tool.makeLabel(labelList.pro, tool.h3);
// pnc panel
var paDoughLabel = tool.makeLabel(labelList.theme, tool.h3);
var paCutterLabel = tool.makeLabel(labelList.unit, tool.h3);
var paLandMaskLabel = tool.makeLabel(labelList.landCover, tool.h3);
var paProMaskLabel = tool.makeLabel(labelList.pro, tool.h3);
// pick lists for land
// --------------------
// dough
var landSelectDough = ui.Select({
  items: Object.keys(landDoughList),
  placeholder: 'Choose land type...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.dLandTitle = landDoughList[key][0];
    zonalVariables.dLand = landDoughList[key][1];
    zonalVariables.landColorMax = landDoughList[key][2];
    zonalVariables.landMax = landDoughList[key][3];
  }
});
// cutter
var landSelectCutter = ui.Select({
  items: Object.keys(cutterList),
  placeholder: 'Choose a region...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.cLandTitle = cutterList[key][0];
    zonalVariables.cLand = cutterList[key][1];
  }
});
// land mask
var landSelectMask = ui.Select({
  items: Object.keys(proMaskList),
  placeholder: 'Choose a mask...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.mLandTitle = proMaskList[key][0];
    zonalVariables.mLand = proMaskList[key][1];
  }
});
// pick lists for pnc
// ------------------
// dough
var pncSelectDough = ui.Select({
  items: Object.keys(pncDoughList),
  placeholder: 'Choose natural community...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.dPncTitle = pncDoughList[key][0];
    zonalVariables.dPnc = pncDoughList[key][1];
    zonalVariables.pncColorMax = pncDoughList[key][2];
    zonalVariables.pncMax = pncDoughList[key][3];
  }
});
// cutter
var pncSelectCutter = ui.Select({
  items: Object.keys(cutterList),
  placeholder: 'Choose a region...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.cPncTitle = cutterList[key][0];
    zonalVariables.cPnc = cutterList[key][1];
  }
});
// land mask
var pncSelectLandMask = ui.Select({
  items: Object.keys(landDoughList),
  placeholder: 'Choose a land mask...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.lmPncTitle = landDoughList[key][0];
    zonalVariables.lmPnc = landDoughList[key][1];
  }
});
// pro mask
var pncSelectProMask = ui.Select({
  items: Object.keys(proMaskList),
  placeholder: 'Choose a land mask...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.pmPncTitle = proMaskList[key][0];
    zonalVariables.pmPnc = proMaskList[key][1];
  }
});
// pick lists for pa
// -----------------
// dough
var paSelectDough = ui.Select({
  items: Object.keys(paDoughList),
  placeholder: 'Choose ag soil...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.dPaTitle = paDoughList[key][0];
    zonalVariables.dPa = paDoughList[key][1];
    zonalVariables.paColorMax = paDoughList[key][2];
    zonalVariables.paMax = paDoughList[key][3];
  }
});
// land mask
var paSelectLandMask = ui.Select({
  items: Object.keys(landDoughList),
  placeholder: 'Choose a land mask...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.lmPaTitle = landDoughList[key][0];
    zonalVariables.lmPa = landDoughList[key][1];
  }
});
// pro mask
var paSelectProMask = ui.Select({
  items: Object.keys(proMaskList),
  placeholder: 'Choose a land mask...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.pmPaTitle = proMaskList[key][0];
    zonalVariables.pmPa = proMaskList[key][1];
  }
});
// cutter
var paSelectCutter = ui.Select({
  items: Object.keys(cutterList),
  placeholder: 'Choose a region...',
  style: {shown: true},
  onChange: function(key) {
    zonalVariables.cPaTitle = cutterList[key][0];
    zonalVariables.cPa = cutterList[key][1];
  }
});
// make checkboxes
// ---------------
var selectCheckLabel = {
  map: 'Make choropleth maps',
  pnc: 'Map by natural community soils',
  pa: 'Map by agricultural soil',
  land: 'Map by land type'
};
var choroSelectCheck = tool.makeCheckBox(selectCheckLabel.map, tool.h2);
choroSelectCheck.onChange(function(checked) {
  chorOptionsPanel.style().set('shown', checked);
  choroLayerPanel.style().set('shown', checked);
  // layerPanel.style().set('shown', !(checked));
  selectPanel.style().set('shown', !(checked));
  exploreTownPanel.style().set('shown', !(checked));
  gapPanel.style().set('shown', !(checked));
});
var landSelectCheck = tool.makeCheckBox(selectCheckLabel.land, tool.h3);
landSelectCheck.onChange(function(checked) {
  pncPanel.style().set('shown', !(checked));
  paPanel.style().set('shown', !(checked));
  landOptionsPanel.style().set('shown', checked);
  makeMapButtonLand.style().set('shown', checked);
  // opacityPanel.style().set('shown', checked);
  // opacitySlider.style().set('shown', checked);
});
var pncSelectCheck = tool.makeCheckBox(selectCheckLabel.pnc, tool.h3);
pncSelectCheck.onChange(function(checked) {
  pncOptionsPanel.style().set('shown', checked);
  pncMakeMapButton.style().set('shown', checked);
  landPanel.style().set('shown', !(checked));
  paPanel.style().set('shown', !(checked));
  // opacityPanel.style().set('shown', checked);
  // opacitySlider.style().set('shown', checked);
});
var paSelectCheck = tool.makeCheckBox(selectCheckLabel.pa, tool.h3);
paSelectCheck.onChange(function(checked) {
  pncPanel.style().set('shown', !(checked));
  paOptionsPanel.style().set('shown', checked);
  paMakeMapButton.style().set('shown', checked);
  landPanel.style().set('shown', !(checked));
  // opacityPanel.style().set('shown', checked);
  // opacitySlider.style().set('shown', checked);
});
var lcChoroConfig = {
  dMin: 0,
  dMax: 1,
  opacity: 1,
  palette: '',
  title: '',
};
var pncChoroConfig = {
  dMin: 0,
  dMax: 1,
  opacity: 1,
  palette: '',
  title: '',
};
var paChoroConfig = {
  dMin: 0,
  dMax: 1,
  opacity: 1,
  palette: '',
  title: '',
};
// button to make map
// ------------------
var makeMapLand = function() {
    choroLayerPanel.style().set('shown', true);
    choroLayerDetailsPanel.style().set('shown', true);
    lcChoroLayerPanel.style().set('shown', true);
    var d = zonalVariables.dLand;
    var c = zonalVariables.cLand;
    var m = zonalVariables.mLand;
    lcChoroConfig.palette = ['white', 'green']; //zonalVariables.landColorMax];
    var mapLayer = mapPercentThemeByRegion(maskDoughLand(d,m),c);
    var vis = {min:lcChoroConfig.dMin, max:lcChoroConfig.dMax, palette: lcChoroConfig.palette};
    lcChoroConfig.title = String(zonalVariables.cLandTitle + zonalVariables.dLandTitle + zonalVariables.mLandTitle);
    map.layers().set(layers.lcChoro, ui.Map.Layer(mapLayer, vis, zonalVariables.title, 1, lcChoroConfig.opacity));
    lcChoroLayerCheck.setValue(true);
    lcLegendPanel.clear();
    lcLegendPanel.add(tool.makeGradientLegend(vis, lcChoroConfig.title, layoutStyle.insideRight));
  };
var pncMakeMap = function() {
    choroLayerPanel.style().set('shown', true);
    choroLayerDetailsPanel.style().set('shown', true);
    pncChoroLayerPanel.style().set('shown', true);
    var d = zonalVariables.dPnc;
    var c = zonalVariables.cPnc;
    var lm = zonalVariables.lmPnc;
    var pm = zonalVariables.pmPnc;
    pncChoroConfig.palette = ['white', 'blue']; //zonalVariables.pncColorMax];
    pncChoroConfig.title = String(zonalVariables.cPncTitle + zonalVariables.dPncTitle + zonalVariables.lmPncTitle + zonalVariables.pmPncTitle);
    var mapLayer = mapPercentThemeByRegion(pncMaskDough(d,lm,pm),c);
    var vis = {min:pncChoroConfig.dMin, max:pncChoroConfig.dMax, palette: pncChoroConfig.palette};
    map.layers().set(layers.pncChoro, ui.Map.Layer(mapLayer, vis, zonalVariables.title, 1, pncChoroConfig.opacity));
    pncChoroLayerCheck.setValue(true);
    pncLegendPanel.clear();
    pncLegendPanel.add(tool.makeGradientLegend(vis, pncChoroConfig.title, layoutStyle.insideRight));
  };
var paMakeMap = function() {
    choroLayerPanel.style().set('shown', true);
    choroLayerDetailsPanel.style().set('shown', true);
    paChoroLayerPanel.style().set('shown', true);
    var d = zonalVariables.dPa;
    var c = zonalVariables.cPa;
    var lm = zonalVariables.lmPa;
    var pm = zonalVariables.pmPa;
    paChoroConfig.palette = ['white', 'red']; // zonalVariables.paColorMax];
    paChoroConfig.title = String(zonalVariables.cPaTitle + zonalVariables.dPaTitle + zonalVariables.lmPaTitle + zonalVariables.pmPaTitle);
    var mapLayer = mapPercentThemeByRegion(pncMaskDough(d,lm, pm),c);
    var vis = {min:paChoroConfig.dMin, max:paChoroConfig.dMax, palette: paChoroConfig.palette};
    map.layers().set(layers.paChoro, ui.Map.Layer(mapLayer, vis, zonalVariables.title, 1, paChoroConfig.opacity));
    paChoroLayerCheck.setValue(true);
    paLegendPanel.clear();
    paLegendPanel.add(tool.makeGradientLegend(vis, paChoroConfig.title, layoutStyle.insideRight));
  };
var makeMapButtonLand = ui.Button({
  label: 'Make map',
  style: {
    width: '280px',
    padding: '4px',
    shown: false
  },
  onClick: makeMapLand
});
var pncMakeMapButton = ui.Button({
  label: 'Make map',
  style: {
    width: '280px',
    padding: '4px',
    shown: false
  },
  onClick: pncMakeMap
});
var paMakeMapButton = ui.Button({
  label: 'Make map',
  style: {
    width: '280px',
    padding: '4px',
    shown: false
  },
  onClick: paMakeMap
});
// -----------
// make panels
// -----------
var choroplethPanel = tool.makePanel('300px', 'top-left', true, '4px', 'vertical');
var chorOptionsPanel = tool.makePanel('300px', 'top-left', false, '4px', 'vertical');
// land theme
var landPanel = tool.makePanel('300px', 'top-left', true, '4px', 'vertical');
var landOptionsPanel = tool.makePanel('300px', 'top-left', false, '0px', 'vertical');
var landDoughPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var landCutterPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var landMaskPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var landDoughPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
var landCutterPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
var landMaskPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
//pnc theme
var pncPanel = tool.makePanel('300px', 'top-left', true, '4px', 'vertical');
var pncOptionsPanel = tool.makePanel('300px', 'top-left', false, '0px', 'vertical');
var pncDoughPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var pncCutterPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var pncLandMaskPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var pncProMaskPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var pncDoughPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
var pncCutterPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
var pncLandMaskPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
var pncProMaskPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
// pa theme
var paPanel = tool.makePanel('300px', 'top-left', true, '4px', 'vertical');
var paOptionsPanel = tool.makePanel('300px', 'top-left', false, '0px', 'vertical');
var paDoughPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var paCutterPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var paLandMaskPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var paProMaskPanel = tool.makePanel('300px', 'top-left', true, '4px', 'horizontal');
var paDoughPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
var paCutterPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
var paLandMaskPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
var paProMaskPanelLabel = tool.makePanel('100px', 'top-left', true, '4px', 'vertical');
// ------------
// LAYER WIDGET
// ------------
// layer panels
// ------------
var patienceLabel = tool.makeLabel(labelList.patience, tool.h3);
var choroLayerLabel = tool.makeLabel(labelList.title, tool.h2);
var lcChoroOpacityLabel = tool.makeLabel(labelList.opacity, tool.c1);
var lcChoroMinLabel = tool.makeLabel(labelList.displayMin, tool.c1);
var lcChoroMaxLabel = tool.makeLabel(labelList.displayMax, tool.c1);
var pncChoroOpacityLabel = tool.makeLabel(labelList.opacity, tool.c1);
var pncChoroMinLabel = tool.makeLabel(labelList.displayMin, tool.c1);
var pncChoroMaxLabel = tool.makeLabel(labelList.displayMax, tool.c1);
var paChoroOpacityLabel = tool.makeLabel(labelList.opacity, tool.c1);
var paChoroMinLabel = tool.makeLabel(labelList.displayMin, tool.c1);
var paChoroMaxLabel = tool.makeLabel(labelList.displayMax, tool.c1);
// layer checks
// ------------
var lcChoroLayerCheck = tool.makeCheckBox(labelList.lcTitle, tool.h3);
lcChoroLayerCheck.onChange(function(checked) {
    map.layers().get(layers.lcChoro).setShown(checked);
    lcChoroLayerDetailsPanel.style().set('shown', checked);
});
var pncChoroLayerCheck = tool.makeCheckBox(labelList.pncTitle, tool.h3);
pncChoroLayerCheck.onChange(function(checked) {
    map.layers().get(layers.pncChoro).setShown(checked);
    pncChoroLayerDetailsPanel.style().set('shown', checked);
});
var paChoroLayerCheck = tool.makeCheckBox(labelList.paTitle, tool.h3);
paChoroLayerCheck.onChange(function(checked) {
    map.layers().get(layers.paChoro).setShown(checked);
    paChoroLayerDetailsPanel.style().set('shown', checked);
});
// opacity sliders
// ---------------
var makeOpacitySlider = function() {
  var sliderOptions = {
    value: 1,
    disabled: false,
    style: tool.sliderStyle,
    step: 0.1
    };
  return ui.Slider(sliderOptions);
};
var lcChoroOpacitySlider = makeOpacitySlider();
lcChoroOpacitySlider.style().set('shown', true);
lcChoroOpacitySlider.onChange(function(value) {
  lcChoroConfig.opacity = value;
  map.layers().get(layers.lcChoro).setOpacity(lcChoroConfig.opacity);
  });
var pncChoroOpacitySlider = makeOpacitySlider();
pncChoroOpacitySlider.style().set('shown', true);
pncChoroOpacitySlider.onChange(function(value) {
  pncChoroConfig.opacity = value;
  map.layers().get(layers.pncChoro).setOpacity(pncChoroConfig.opacity);
  });
var paChoroOpacitySlider = makeOpacitySlider();
paChoroOpacitySlider.style().set('shown', true);
paChoroOpacitySlider.onChange(function(value) {
  paChoroConfig.opacity = value;
  map.layers().get(layers.paChoro).setOpacity(paChoroConfig.opacity);
  });
// viz sliders
// -----------
var sliderStyle = {
  fontSize: '12px',
  fontWeight: 'bold',
  fontFamily: tool.styles.fontFamily,
  color: 'black',
  padding: '4px',
  margin: '4px 24px',
  width: '60%',
  shown: true
  };
var makeSlider = function(value) {
  var sliderOptions = {
    min: 0,
    max: 1, 
    value: value,
    disabled: false,
    style: sliderStyle,
    step: 0.1
    };
  return ui.Slider(sliderOptions);
};
var lcChoroMaxSlider = makeSlider(1);
lcChoroMaxSlider.onChange(function(value) {
  lcChoroConfig.dMax = value + 0.001;
  map.layers().get(layers.lcChoro).setVisParams({min:lcChoroConfig.dMin, max:lcChoroConfig.dMax, palette: lcChoroConfig.palette});
  lcLegendPanel.clear();
  lcLegendPanel.add(tool.makeGradientLegend({min:lcChoroConfig.dMin, max:lcChoroConfig.dMax, palette: lcChoroConfig.palette}, lcChoroConfig.title, layoutStyle.insideRight));
  });
var pncChoroMaxSlider = makeSlider(1);
pncChoroMaxSlider.onChange(function(value) {
  pncChoroConfig.dMax = value + 0.001;
  map.layers().get(layers.pncChoro).setVisParams({min:pncChoroConfig.dMin, max:pncChoroConfig.dMax, palette: pncChoroConfig.palette});
  pncLegendPanel.clear();
  pncLegendPanel.add(tool.makeGradientLegend({min:pncChoroConfig.dMin, max:pncChoroConfig.dMax, palette: pncChoroConfig.palette}, pncChoroConfig.title, layoutStyle.insideRight));
  });
var paChoroMaxSlider = makeSlider(1);
paChoroMaxSlider.onChange(function(value) {
  paChoroConfig.dMax = value + 0.001;
  map.layers().get(layers.paChoro).setVisParams({min:paChoroConfig.dMin, max:paChoroConfig.dMax, palette: paChoroConfig.palette});
  paLegendPanel.clear();
  paLegendPanel.add(tool.makeGradientLegend({min:paChoroConfig.dMin, max:paChoroConfig.dMax, palette: paChoroConfig.palette}, paChoroConfig.title, layoutStyle.insideRight));
  });
var lcChoroMinSlider = makeSlider(0);
lcChoroMinSlider.onChange(function(value) {
  lcChoroConfig.dMin = value;
  map.layers().get(layers.lcChoro).setVisParams({min:lcChoroConfig.dMin, max:lcChoroConfig.dMax, palette: lcChoroConfig.palette});
  lcLegendPanel.clear();
  lcLegendPanel.add(tool.makeGradientLegend({min:lcChoroConfig.dMin, max:lcChoroConfig.dMax, palette: lcChoroConfig.palette}, lcChoroConfig.title, layoutStyle.insideRight));
  });
var pncChoroMinSlider = makeSlider(0);
pncChoroMinSlider.onChange(function(value) {
  pncChoroConfig.dMin = value;
  map.layers().get(layers.pncChoro).setVisParams({min:pncChoroConfig.dMin, max:pncChoroConfig.dMax, palette: pncChoroConfig.palette});
  pncLegendPanel.clear();
  pncLegendPanel.add(tool.makeGradientLegend({min:pncChoroConfig.dMin, max:pncChoroConfig.dMax, palette: pncChoroConfig.palette}, pncChoroConfig.title, layoutStyle.insideRight));
  });
var paChoroMinSlider = makeSlider(0);
paChoroMinSlider.onChange(function(value) {
  paChoroConfig.dMin = value;
  map.layers().get(layers.paChoro).setVisParams({min:paChoroConfig.dMin, max:paChoroConfig.dMax, palette: paChoroConfig.palette});
  paLegendPanel.clear();
  paLegendPanel.add(tool.makeGradientLegend({min:paChoroConfig.dMin, max:paChoroConfig.dMax, palette: paChoroConfig.palette}, paChoroConfig.title, layoutStyle.insideRight));
  });
// -----------
// panels
// -----------
// patience
var patiencePanel = tool.makePanelWithWidgets(patienceLabel, layoutStyle.insideRight, 'top-right', true, layoutStyle.pad1, layoutStyle.vert);
// opacity slider
// var opacityPanel = tool.makePanel(layoutStyle.insideRight, 'top-right', false, layoutStyle.pad1, layoutStyle.vert);
// var opacityLabelPanel = tool.makePanel(layoutStyle.insideRight, 'top-right', true, layoutStyle.pad1, layoutStyle.vert);
//\, choroMaxPanel, choroOpacityPanel];
// choroLayerPanel.add(choroLayerCheck);
// choroLayerPanel.add(patiencePanel);
// choroLayerPanel.add(legendPanel);
// choroLayerPanel.add(opacityPanel);
// opacityPanel.add(opacityLabelPanel);
// opacityLabelPanel.add(opacityLabel);
// opacityPanel.add(opacitySlider);
// choroLayerPanel.add(visMaxSlider);
// choroLayerPanel.add(visMinSlider);
var lcLegendPanel = tool.makePanel('300px', 'top-left', true, '4px', 'vertical');
var lcChoroOpacityPanel = tool.makePanelWithWidgets([lcChoroOpacityLabel, lcChoroOpacitySlider], layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.horz);
var lcChoroMaxPanel = tool.makePanelWithWidgets([lcChoroMaxLabel, lcChoroMaxSlider], layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.horz);
var lcChoroMinPanel = tool.makePanelWithWidgets([lcChoroMinLabel, lcChoroMinSlider], layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.horz);
var lcWidgetList = [lcLegendPanel, lcChoroMinPanel,lcChoroMaxPanel, lcChoroOpacityPanel]; 
var lcChoroLayerDetailsPanel = tool.makePanelWithWidgets(lcWidgetList, layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.vert);
var lcChoroLayerPanel = tool.makePanelWithWidgets([lcChoroLayerCheck, lcChoroLayerDetailsPanel], layoutStyle.right, 'top-right', false, layoutStyle.pad1, layoutStyle.vert);
var pncLegendPanel = tool.makePanel('300px', 'top-left', true, '4px', 'vertical');
var pncChoroOpacityPanel = tool.makePanelWithWidgets([pncChoroOpacityLabel, pncChoroOpacitySlider], layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.horz);
var pncChoroMinPanel = tool.makePanelWithWidgets([pncChoroMinLabel, pncChoroMinSlider], layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.horz);
var pncChoroMaxPanel = tool.makePanelWithWidgets([pncChoroMaxLabel, pncChoroMaxSlider], layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.horz);
var pncWidgetList = [pncLegendPanel,  pncChoroMinPanel, pncChoroMaxPanel, pncChoroOpacityPanel]; 
var pncChoroLayerDetailsPanel = tool.makePanelWithWidgets(pncWidgetList, layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.vert);
var pncChoroLayerPanel = tool.makePanelWithWidgets([pncChoroLayerCheck, pncChoroLayerDetailsPanel], layoutStyle.right, 'top-right', false, layoutStyle.pad1, layoutStyle.vert);
var paLegendPanel = tool.makePanel('300px', 'top-left', true, '4px', 'vertical');
var paChoroOpacityPanel = tool.makePanelWithWidgets([paChoroOpacityLabel, paChoroOpacitySlider], layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.horz);
var paChoroMinPanel = tool.makePanelWithWidgets([paChoroMinLabel, paChoroMinSlider], layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.horz);
var paChoroMaxPanel = tool.makePanelWithWidgets([paChoroMaxLabel, paChoroMaxSlider], layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.horz);
var paWidgetList = [paLegendPanel, paChoroMinPanel, paChoroMaxPanel, paChoroOpacityPanel]; 
var paChoroLayerDetailsPanel = tool.makePanelWithWidgets(paWidgetList, layoutStyle.right, 'top-right', true, layoutStyle.pad1, layoutStyle.vert);
var paChoroLayerPanel = tool.makePanelWithWidgets([paChoroLayerCheck, paChoroLayerDetailsPanel], layoutStyle.right, 'top-right', false, layoutStyle.pad1, layoutStyle.vert);
var choroLayerDetailsPanel = tool.makePanelWithWidgets([lcChoroLayerPanel, pncChoroLayerPanel, paChoroLayerPanel], layoutStyle.right, 'top-right', false, layoutStyle.pad1, layoutStyle.vert);
var choroLayerPanel = tool.makePanelWithWidgets([choroLayerLabel, choroLayerDetailsPanel], layoutStyle.right, 'top-right', false, layoutStyle.pad1, layoutStyle.vert);
//print(choroMaxPanel);
// ~~~~~~~~~~~~~~~~~~~~
// Map composition
// ~~~~~~~~~~~~~~~~~~~~
actionPanel.add(choroplethPanel);
choroplethPanel.add(choroSelectCheck);
choroplethPanel.add(chorOptionsPanel);
chorOptionsPanel.add(landPanel);
landPanel.add(landSelectCheck);
landPanel.add(landOptionsPanel);
landOptionsPanel.add(landDoughPanel);
landDoughPanel.add(landDoughPanelLabel);
landDoughPanelLabel.add(landDoughLabel);
landDoughPanel.add(landSelectDough);
landOptionsPanel.add(landCutterPanel);
landCutterPanel.add(landCutterPanelLabel);
landCutterPanelLabel.add(landCutterLabel);
landCutterPanel.add(landSelectCutter);
landOptionsPanel.add(landMaskPanel);
landMaskPanel.add(landMaskPanelLabel);
landMaskPanelLabel.add(landMaskLabel);
landMaskPanel.add(landSelectMask);
landOptionsPanel.add(makeMapButtonLand);
chorOptionsPanel.add(pncPanel);
pncPanel.add(pncSelectCheck);
pncPanel.add(pncOptionsPanel);
pncOptionsPanel.add(pncDoughPanel);
pncDoughPanel.add(pncDoughPanelLabel);
pncDoughPanelLabel.add(pncDoughLabel);
pncDoughPanel.add(pncSelectDough);
pncOptionsPanel.add(pncCutterPanel);
pncCutterPanel.add(pncCutterPanelLabel);
pncCutterPanelLabel.add(pncCutterLabel);
pncCutterPanel.add(pncSelectCutter);
pncOptionsPanel.add(pncLandMaskPanel);
pncLandMaskPanel.add(pncLandMaskPanelLabel);
pncLandMaskPanelLabel.add(pncLandMaskLabel);
pncLandMaskPanel.add(pncSelectLandMask);
pncOptionsPanel.add(pncProMaskPanel);
pncProMaskPanel.add(pncProMaskPanelLabel);
pncProMaskPanelLabel.add(pncProMaskLabel);
pncProMaskPanel.add(pncSelectProMask);
pncOptionsPanel.add(pncMakeMapButton);
//
chorOptionsPanel.add(paPanel);
paPanel.add(paSelectCheck);
paPanel.add(paOptionsPanel);
paOptionsPanel.add(paDoughPanel);
paDoughPanel.add(paDoughPanelLabel);
paDoughPanelLabel.add(paDoughLabel);
paDoughPanel.add(paSelectDough);
paOptionsPanel.add(paCutterPanel);
paCutterPanel.add(paCutterPanelLabel);
paCutterPanelLabel.add(paCutterLabel);
paCutterPanel.add(paSelectCutter);
paOptionsPanel.add(paLandMaskPanel);
paLandMaskPanel.add(paLandMaskPanelLabel);
paLandMaskPanelLabel.add(paLandMaskLabel);
paLandMaskPanel.add(paSelectLandMask);
paOptionsPanel.add(paProMaskPanel);
paProMaskPanel.add(paProMaskPanelLabel);
paProMaskPanelLabel.add(paProMaskLabel);
paProMaskPanel.add(paSelectProMask);
paOptionsPanel.add(paMakeMapButton);
// add to choropleth layer panel on right
map.add(choroLayerPanel);
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
// GAP COMPONENT
//
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// label dictionary 
var gapLabels = {
  check: 'Gap analyses',
  town: 'In this town:',
  townPick: 'Select a town...',
  base: 'Thematic base:',
  theme: 'Theme:',
  under: 'UNDER CONSTRUCTION'
};
var gapTownLabel = tool.makeLabel(gapLabels.town, tool.c1);
var gapBaseLabel = tool.makeLabel(gapLabels.base, tool.c1);
var gapThemeLabel = tool.makeLabel(gapLabels.theme, tool.c1);
var gapUnderLabel = tool.makeLabel(gapLabels.under, tool.h3);
// make check
var gapCheck = tool.makeCheckBox(gapLabels.check, tool.h2);
gapCheck.onChange(function(checked) {
  exploreTownPanel.style().set('shown', !(checked));
  selectPanel.style().set('shown', !(checked));
  choroplethPanel.style().set('shown', !(checked)); // added with choropleth addition
  gapOptions.style().set('shown', checked);
  creditsPanel.style().set('shown', !(checked));
});
// select list
var gapTownSelect = makeSelectList(townTargets, gapLabels.townPick);
gapTownSelect.style().set({width: '60%'});
// make panels
var gapTownPanel = tool.makePanelWithWidgets([gapTownLabel, gapTownSelect], layoutStyle.insideLeft, 'top-left', true, layoutStyle.pad1, 'horizontal');
var gapBasePanel = tool.makePanelWithWidgets([gapBaseLabel], layoutStyle.insideLeft, 'top-left', true, layoutStyle.pad1, 'horizontal');
var gapThemePanel = tool.makePanelWithWidgets([gapThemeLabel], layoutStyle.insideLeft, 'top-left', true, layoutStyle.pad1, 'horizontal');
var gapScalePanel = tool.makePanel(layoutStyle.insideLeft, 'top-left', true, layoutStyle.pad1, 'horizontal');
var gapOptions = tool.makePanelWithWidgets(gapUnderLabel, layoutStyle.insideLeft, 'top-left', false, layoutStyle.pade1, 'vertical');
var gapPanel = tool.makePanelWithWidgets([gapCheck, gapOptions], layoutStyle.insideLeft, 'top-left', false, layoutStyle.pad1, 'vertical');
actionPanel.add(gapPanel);