var image = ui.import && ui.import("image", "image", {
      "id": "UMD/hansen/global_forest_change_2019_v1_7"
    }) || ee.Image("UMD/hansen/global_forest_change_2019_v1_7"),
    roadarea = ui.import && ui.import("roadarea", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -72.80499267578125,
                -2.6423064840619217
              ],
              [
                -73.01922607421875,
                -2.801428470020833
              ],
              [
                -73.11260986328125,
                -2.944071214807143
              ],
              [
                -73.27191162109375,
                -3.0044146221379093
              ],
              [
                -73.16754150390625,
                -3.1854245647840362
              ],
              [
                -72.95330810546875,
                -3.103151154502735
              ],
              [
                -72.90386962890625,
                -2.86726579595779
              ],
              [
                -72.62371826171875,
                -2.658768345921454
              ],
              [
                -72.57427978515625,
                -2.428282910311087
              ],
              [
                -72.81597900390625,
                -2.4063298068747807
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-72.80499267578125, -2.6423064840619217],
          [-73.01922607421875, -2.801428470020833],
          [-73.11260986328125, -2.944071214807143],
          [-73.27191162109375, -3.0044146221379093],
          [-73.16754150390625, -3.1854245647840362],
          [-72.95330810546875, -3.103151154502735],
          [-72.90386962890625, -2.86726579595779],
          [-72.62371826171875, -2.658768345921454],
          [-72.57427978515625, -2.428282910311087],
          [-72.81597900390625, -2.4063298068747807]]]),
    roadbm = ui.import && ui.import("roadbm", "table", {
      "id": "users/jodaurmu/buffer_BM"
    }) || ee.FeatureCollection("users/jodaurmu/buffer_BM");
//area
var empty = ee.Image().byte();
var roadbm2 = empty.paint({
  featureCollection: roadbm,
  color: 1,
  width: 3
});
// Select band
var treeCover=image.select(['treecover2000']) //cobetura boscosa 
var tcUp10 = image.select(['treecover2000']).gte(10); //cobertura boscosa mayor igual a 10
var tcless10 = image.select(['treecover2000']).lt(10); // cobertura boscosa menos a 10
var lossImage = image.select(['loss']); //pérdida
var gainImage = image.select(['gain']); //ganancia
var datamask = image.select(['datamask']); //tierra
//Stratification map
var NF1= datamask.eq(1).and(treeCover.lt(10))
var forest1 = tcUp10.and(datamask.eq(1));
var water1 = datamask.eq(2);
var loss1 = datamask.eq(1).and(lossImage);
var gain1 = datamask.eq(1).and(gainImage);
var gainAndLoss1 = gainImage.and(lossImage);
var NF= ee.Image(NF1);
var forest = ee.Image(forest1);
var water = ee.Image(water1);
var loss = ee.Image(loss1);
var gain = ee.Image(gain1);
var gainAndLoss = ee.Image(gainAndLoss1);
//var AD= NF.add(forest).add(water).add(gain.eq(1)).add(loss.eq(1))
var ADD  = ee.Image([NF,water,loss,gain,forest]).rename(
                    ['NF','water','loss','gain','forest'])
//var ad= ADD.toBands();
// some stats
var stats = lossImage.reduceRegion({
  reducer: ee.Reducer.sum(),
  geometry: roadbm,
  scale: 30,
  maxPixels:1e9
});
print('pixels representing loss: ', stats.get('loss'),"Square meters");
var stats2 = gainImage.reduceRegion({
  reducer: ee.Reducer.sum(),
  geometry: roadbm,
  scale: 30,
  maxPixels:1e9
});
print('pixels representing gain: ', stats2.get('gain'),"Square meters");
var igbpPalette = [
  '615f55',//'No bosque'
  '1ce80e',//'Bosque'
  '0e48e8',//'Cuerpos de agua'
  'e8102a',//'Perdida de bosques'
  'FF00FF',//'Areas dinamicas'
  ];
//visualization 
Map.setCenter(-73, -2.8010, 10); // carretera 
//Map.addLayer(AD.clip(roadbm),igbpPalette, 'Datos de actividad');
var gainAndLoss = gainImage.and(lossImage);
Map.addLayer(forest.updateMask(forest).clip(roadbm),
    {palette: ['035e08', '035e08'], max: 100}, 'Cobertura de Bosque');
Map.addLayer(loss.updateMask(loss).clip(roadbm),
    {palette: ['FF0000']}, 'Perdida');
Map.addLayer(gain.updateMask(gain).clip(roadbm),
    {palette: ['0000FF']}, 'Ganancia');
Map.addLayer(gainAndLoss.updateMask(gainAndLoss).clip(roadbm),
    {palette: 'FF00FF'}, 'Areas dinamica');
Map.addLayer(roadbm2,
    {palette: '1a1f0f',strokeWidth: 10}, 'Area de Influencia')
////////////////////////////////////////////////
var legend = ui.Panel({
  style: {
    position: 'middle-left',
    padding: '8px 15px'}});
var legendTitle = ui.Label({
  value: 'Datos de actividad ',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }});
legend.add(legendTitle);
var makeRow = function(color, name) {
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          padding: '8px',
          margin: '0 0 4px 0'
        }});
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}});
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')});
};
var palette =['615f55','035e08','e8102a','0000FF','FF00FF' ];
var names = ['No bosque','Bosque','Perdida de bosques','Ganancia de cobertura arborea', 'Areas dinamicas'];
for (var i = 0; i < 5; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
Map.add(legend);
var header = ui.Label('Modelamiento de los impactos socioambientales (En desarrollo)', {fontSize: '15px', color: 'red'});
var text = ui.Label('IBC-Proyecto Putumayo Amazonas ',
    {fontSize: '12px',fontWeight: 'bold'});
var text2 = ui.Label(' J. David Urquiza-Muñoz, Ana Rosa Sanez Rodriguez, Jose Jibaja Aspajo',
    {fontSize: '12px',fontWeight: 'italyc'});
var text3 = ui.Label(' Fuentes: Hansen et. al, 2013, RAISG (en desarrollo)',
    {fontSize: '12px',fontWeight: 'italyc'});
var logoAll=ui.Chart(
  [['<img src=https://ibcperu.org/wp-content/uploads/2019/12/logo-300x130.png width=120px heigth=100px>']],
  'Table',{allowHtml:true});
var toolPanel = ui.Panel([header,logoAll,text,text2,text3], 'flow', {width: '250px', padding:'1px'});
ui.root.insert(1,toolPanel)