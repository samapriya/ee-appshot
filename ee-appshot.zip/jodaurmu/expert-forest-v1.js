var depa = ui.import && ui.import("depa", "table", {
      "id": "users/jodaurmu/DEPARTAMENTOS"
    }) || ee.FeatureCollection("users/jodaurmu/DEPARTAMENTOS"),
    nicfi = ui.import && ui.import("nicfi", "imageCollection", {
      "id": "projects/planet-nicfi/assets/basemaps/americas"
    }) || ee.ImageCollection("projects/planet-nicfi/assets/basemaps/americas"),
    hansen = ui.import && ui.import("hansen", "image", {
      "id": "UMD/hansen/global_forest_change_2023_v1_11"
    }) || ee.Image("UMD/hansen/global_forest_change_2023_v1_11");
/////////perturbation analisys V1.0///////
/** * @license
 * Copyright 2022 David Urquiza - Universidad Nacional de la Amazonia Peruana
 **
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 ///////////////////////////////////////
var complements=require('users/jodaurmu/unap_gerfor:complements');
////////////////////////////////////////
var header = ui.Label({value:'ExPert Forest V1',style: {fontWeight: 'bold', fontSize: '22px', 
margin: '0px 0px 10px 80px',color:'green', textAlign:'center', backgroundColor:'white'}});
var toolPanel=complements.toolPanel
var Panel2=complements.Panel2
ui.root.insert(1,toolPanel)
//ui.root.insert(0,Panel2)
toolPanel.add(header)
//toolPanel.add(text2)
//////////base map
var baseChange = complements.baseChange
Map.setOptions('baseChange', {'baseChange': baseChange});
Map.setCenter(-73.5, -3.5, 7);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var logo2 = complements.logo2
var thumb2 = ui.Thumbnail({
    image: logo2,
    params: {
        dimensions: '1142x380',
        format: 'png'
        },
    style: {height: '90px', width: '330px',padding :'0',margin: '0px 0px 00px 0px'}
    });
var label_uiLoadJSON = ui.Label({value:'Ingrese geoJSON del TH:', style:complements.tittle_fonts});
var uiLoadJSON = ui.Textbox({placeholder: 'Pegar geoJSON aquí (lat/long)',  style: {position: 'top-center', width: '300px', backgroundColor:'222222', fontWeight:'bold'}})
toolPanel.add(label_uiLoadJSON)
toolPanel.add(uiLoadJSON)
var label_uiLoadJSON2 = ui.Label({value:'Ingrese geoJSON de los arboles:', style:complements.tittle_fonts});
var uiLoadJSON21= ui.Textbox({placeholder: 'Pegar geoJSON aquí (lat/long)',  style: {position: 'top-center', width: '300px', backgroundColor:'222222', fontWeight:'bold'}})
toolPanel.add(label_uiLoadJSON2)
toolPanel.add(uiLoadJSON21)
var panel = ui.Panel();
panel.style().set({
  width: '300px',
  position: 'bottom-left',
  backgroundColor:'white'
});
ui.root.insert(0,panel)
var AddButton = function(){
      var button = ui.Button('Analisis por geoJSON');
      button.style().set({
        position: 'top-right',
        border : '1px solid #000000',
      });
      button.onClick(function(){return analysis()});
      Map.add(button);
}
AddButton(toolPanel);
//var analysis_tittle = ui.Label('Defina el Período y nubosidad de las imagenes: ',complements.tittle_fonts);
//toolPanel.add(analysis_tittle)
var label_Start = ui.Label({value:'Inicio:',style: complements.sub_tittle_fonts});
//toolPanel.add(label_Start)
var Start_select = ui.Textbox({
  value: '2024-06-01',
  style: {width : '90px'},
  onChange: function(text) {
    var Start_second = text
  }});
//toolPanel.add(Start_select)
var label_End = ui.Label({value:'Final:',style: complements.sub_tittle_fonts});
//toolPanel.add(label_End)
var End_select = ui.Textbox({
  value: '2024-09-30',
  style: {width : '90px'},
  onChange: function(text) {
    var End_second = text
  }});
var semi_panel=ui.Panel({
    widgets: [
      ui.Label({value:'Defina el Período y nubosidad de las imagenes: ', style:complements.tittle_fonts}),
      ui.Panel([
        label_Start,
        Start_select,
        label_End,
        End_select
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    });
toolPanel.add(semi_panel)
var label_cloudlevel_select = ui.Label({value:'Nubosidad (5%-90%):',style: complements.sub_tittle_fonts});
var cloudlevel_select = ui.Slider({
  min: 5,
  max: 90, 
  value: 20, 
  step: 1,
  onChange: function(value) {
    var cloudcover = value
  },style: {fontWeight: 'normal', fontSize: '16px', margin: '10px 5px', backgroundColor:'white',color:'black',width: '150px'}
      });
var semi_panel_cloud=ui.Panel({
    widgets: [
      //ui.Label({value:'Defina el Período y nubosidad de las imagenes: ', style:complements.tittle_fonts}),
      ui.Panel([
        label_cloudlevel_select,
        cloudlevel_select
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    });
toolPanel.add(semi_panel_cloud)
var uimeses =  ui.Textbox({
  value: '5',
  style: {width: '50px'},
  onChange: function(text) {
    var uimeses_second = text
  }});
var meses_label = ui.Label({value:'Meses pre-disturbio:', style:complements.sub_tittle_fonts});
var semi_panel_meses=ui.Panel({
    widgets: [
      //ui.Label({value:'Defina el Período y nubosidad de las imagenes: ', style:complements.tittle_fonts}),
      ui.Panel([
        meses_label,
        uimeses
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    });
toolPanel.add(semi_panel_meses)
var umbral_label = ui.Label({value:'Umbral de cambio:', style:complements.sub_tittle_fonts});
var uiumbral =  ui.Textbox({
  value:'20',
  style: {width: '50px'},
  onChange: function(text) {
    var uiumbral_second = text
  }});
var semi_panel_umbral=ui.Panel({
    widgets: [
      //ui.Label({value:'Defina el Período y nubosidad de las imagenes: ', style:complements.tittle_fonts}),
      ui.Panel([
        umbral_label,
        uiumbral
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    });
toolPanel.add(semi_panel_umbral)
var label_bufflevel_select = ui.Label({value:'Buffer de inspección (m):',style: complements.sub_tittle_fonts});
var bufferlevel_select = ui.Slider({
  min: 0,
  max: 50, 
  value: 50, 
  step: 1,
  onChange: function(value) {
    var buffercover = value
  },style: {fontWeight: 'normal', fontSize: '16px', margin: '10px 10px', backgroundColor:'white',color:'black',width: '130px'}
      });
var semi_panel_buff=ui.Panel({
    widgets: [
      //ui.Label({value:'Defina el Período y nubosidad de las imagenes: ', style:complements.tittle_fonts}),
      ui.Panel([
        label_bufflevel_select,
        bufferlevel_select
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    });
toolPanel.add(semi_panel_buff)
var site_tittle = ui.Label('Defina el periodo para la perdida de bosque',complements.tittle_fonts);
toolPanel.add(site_tittle)
var year_init_titlle=ui.Label('Inicio:',complements.subtittle_fonts)
var year_init=ui.Textbox({
  value: '2020',
  style: {width : '50px'},
  onChange: function(text) {
    var Start_second = text
  }});
var year_fin_titlle=ui.Label('Final:',complements.subtittle_fonts)
var year_fin=ui.Textbox({
  value: '2023',
  style: {width : '50px'},
  onChange: function(text) {
    var Start_second = text
  }});
var semi_panel_def=ui.Panel({
    widgets: [
      //ui.Label({value:'Defina el Período y nubosidad de las imagenes: ', style:complements.tittle_fonts}),
      ui.Panel([
        year_init_titlle,
        year_init,
        year_fin_titlle,
        year_fin
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    });
toolPanel.add(semi_panel_def)
var  ref = ui.Label('Guia de uso', {textAlign:'center',fontWeight: 'bold', fontSize: '16px', margin: '10px 5px', backgroundColor:'white',color:'blue'},
'https://docs.google.com/document/d/1acsey_gPQTK9uj_YH7eLrYuEcmMjdyAONmtZ6psGQpk/edit?usp=sharing');
var  example = ui.Label('Ejemplos', {textAlign:'center',fontWeight: 'bold', fontSize: '16px', margin: '10px 5px', backgroundColor:'white',color:'blue'},
'https://drive.google.com/uc?export=download&id=1-SzPUqY1n5MaiU29-9ZgpyBwi24RFK0_');
var  metadata = ui.Label('Metadata', {textAlign:'center',fontWeight: 'bold', fontSize: '16px', margin: '10px 5px', backgroundColor:'white',color:'blue'},
'https://docs.google.com/spreadsheets/d/1o8yGgRFI7S5M6yUOEKo1nEwzBEX26dDo/edit?usp=sharing&ouid=112134852363008889636&rtpof=true&sd=true');
var semi_ref=ui.Panel({
    widgets: [
      //ui.Label({value:'Defina el Período y nubosidad de las imagenes: ', style:complements.tittle_fonts}),
      ui.Panel([
        ref,
        example,
        metadata
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    });
var consul1=ui.Label({
        value: '_______________________________________________________________________________',
        style: {fontWeight: 'bold', fontSize: '9px', margin: '0px 0px 0px 0px',backgroundColor:'white',color:'black'}
      });
var consul11=ui.Label({
        value: '_______________________________________________________________________________',
        style: {fontWeight: 'bold', fontSize: '9px', margin: '0px 0px 0px 0px',backgroundColor:'white',color:'black'}
      });
var consul111=ui.Label({
        value: '-',
        style: {fontWeight: 'bold', fontSize: '10px', margin: '0px 0px 0px 0px',backgroundColor:'white',color:'black'}
      });
var consul2=ui.Label({
        value: 'Desarrollado por: J. D. Urquiza-Muñoz, C. Michael Vasquez, Jordi Garcia',
        style: {fontWeight: 'bold', fontSize: '12px', margin: '00px 0px 0px 0px',backgroundColor:'white',color:'black'}});
toolPanel.add(consul1)
toolPanel.add(semi_ref)
toolPanel.add(consul11)
toolPanel.add(consul111)
toolPanel.add(thumb2)
toolPanel.add(consul2)
////////////////////////////
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
//////////////////////////////geoJSON function/////////////////+ app start
function analysis(){
                  panel.clear()
                 Map.clear()
//Years
var Start_second = Start_select.getValue();
    var Start_second_number = ee.Number.parse(Start_second.replace(/-/g,'')).getInfo()
var End_second = End_select.getValue();
    var End_second_number = ee.Number.parse(End_second.replace(/-/g,'')).getInfo();
var cloudcover = cloudlevel_select.getValue()
var areas = uiLoadJSON.getValue()
var filter_a = ee.List(ee.Dictionary(ee.String(areas).decodeJSON()).get("features")).map(function(item){item = ee.Dictionary(item)
return ee.Feature(ee.Geometry.MultiPolygon(ee.Dictionary(item.get("geometry")).get("coordinates")), 
	 item.get("properties"))})
var filteredArea = ee.FeatureCollection(filter_a);
var arboles_geo=uiLoadJSON21.getValue()
//print(arboles_geo,'gjson value')
var arboles = ee.List(ee.Dictionary(ee.String(arboles_geo).decodeJSON()).get("features")).map(function(item){item = ee.Dictionary(item)
return ee.Feature(ee.Geometry.Point(ee.Dictionary(item.get("geometry")).get("coordinates")), 
	 item.get("properties"))})
//var ccff_name=countiesDD.getValue()///to the chart name
//print(arboles)
var arboles2=ee.FeatureCollection(arboles)
//sentinel//////////////////////////////////////////////////////
/**
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */
var S2_c2=ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
                  .filterDate(Start_second,End_second)
                  .filterBounds(filteredArea)
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloudcover))
                  .map(maskS2clouds)
//print('cantidad de imagenes S2',S2_c2)
var previus_img = Start_select.getValue();
    var previus_date= ee.Date(previus_img).advance((uimeses.getValue())*-1, 'month').format('YYYY-MM');
    previus_date=ee.String(previus_date.getInfo()+'-01')
var S2_c22=ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
                  .filterDate(previus_date,Start_second)
                  .filterBounds(filteredArea)
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloudcover))
                  .map(maskS2clouds)
//print('cantidad de imagenes S2_early',ee.ImageCollection(S2_c22))
var s2_vis = {
  min: 0,
  max: 0.4,
 bands: ['B4', 'B3', 'B2'],
  //bands: ['B4', 'B3', 'B2'],
  gamma: 1.65,
};
//Map.addLayer(S2_c2.median().clip(filteredArea),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
//Map.addLayer(S2_c2.reduce(ee.Reducer.percentile([10])).clip(filteredArea),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
Map.addLayer(S2_c22.median().clip(filteredArea),s2_vis,'S2A Mediana pre disturbio: '+previus_date.getInfo()+' - '+Start_second)
Map.addLayer(S2_c2.median().clip(filteredArea),s2_vis,'S2A Mediana postdisturbio: '+Start_second+' - '+End_second)
////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////Forestry Indexes/////////////////////////////////////
var f_NDVI= require('users/jodaurmu/geetools:forestry_indexes_tools/JD_Urquiza_M_NDVI_sentinel')
var f_EVI= require('users/jodaurmu/geetools:forestry_indexes_tools/JD_Urquiza_M_EVI_sentinel')
//https://www.indexdatabase.de/db/si-single.php?sensor_id=96&rsindex_id=576
var mergedNDVI= S2_c2.map(f_NDVI.f_NDVI_s);
//print(mergedNDVI,'mergedNDVI')
var mergedEVI= S2_c2.map(f_EVI.f_EVI_s);
var mergedNDVI2= S2_c22.map(f_NDVI.f_NDVI_s);
//print(mergedNDVI2,'mergedNDVI2')
var mergedEVI2= S2_c22.map(f_EVI.f_EVI_s);
var NDVI_select=mergedNDVI.select('NDVI')
var EVI_select=mergedEVI.select('EVI')
var NDVI_select2=mergedNDVI2.select('NDVI')
var EVI_select2=mergedEVI2.select('EVI')
///show images
//Map.addLayer(NDWI_select.median().clip(geometry),ndwipalette,'S2-NDWI period: '+Start_second+' - '+End_second).setShown(0)
var NDVIpalette = {
  min: 0.0,
  max: 1.0,
palette: ['red','orange','yellow','lightgreen','green','darkgreen']};
Map.addLayer(NDVI_select.median().clip(filteredArea),NDVIpalette,'S2A NDVI postdisturbio: '+Start_second+' - '+End_second).setShown(0)
Map.addLayer(NDVI_select2.median().clip(filteredArea),NDVIpalette,'S2A NDVI predisturbio: '+previus_date.getInfo()+' - '+Start_second).setShown(0)
var EVIpalette = {
  min: 0.0,
  max: 1.0,
palette: ['red','orange','yellow','lightgreen','green','darkgreen']};
//Map.addLayer(EVI_select.median().clip(filteredArea),EVIpalette,'S2-EVI period: '+Start_second+' - '+End_second).setShown(0)
/////differences between pre and post disturbance
var lateNDVI=NDVI_select.median().clip(filteredArea)
var earlyNDVI=NDVI_select2.median().clip(filteredArea)
var diffBand = earlyNDVI.subtract(lateNDVI)
var NDVI_threshold = ee.Number.parse(uiumbral.getValue());
var cambios_percent=diffBand.multiply(100).divide(earlyNDVI).rename('Porcentual')
var threshBand = cambios_percent.gte(NDVI_threshold).rename('Cambio_NDVI'); 
var threshBandMasked = threshBand.updateMask(threshBand)
//diffBand=diffBand.addBands(cambios_percent.select('porcentual'))
//print(threshBandMasked)
//print(diffBand)
var threshViz = {min:0, max:1, palette:['000000', '990000']}
var threshViz2 = {min:1, max:uiumbral.getValue(), palette:['000000', '#e3e216','990000']}
//Map.addLayer(diffBand.select('NDVI'),threshViz,'Img de cambio absoluto: ').setShown(0)
Map.addLayer(cambios_percent.select('Porcentual'),threshViz2,'Img de cambio porcentual: ').setShown(1)
var ndvi_style='<RasterSymbolizer>' +'<ColorMap  type="intervals" extended="false" >' +
      '<ColorMapEntry color="#000000" quantity="0" opacity="1" label="No perturbado" />' + 
      '<ColorMapEntry color="#ff0000" quantity="1" opacity="1" label="Perturbado" />'+
    '</ColorMap>' + '</RasterSymbolizer>';
var threshBand_v=threshBand.sldStyle(ndvi_style)
Map.addLayer(threshBand_v, {}, 'Umbral de Cambios').setShown(0);
var ndvi_all=cambios_percent.addBands(diffBand.rename('Cambio_NDVI')).addBands(lateNDVI.rename('Post_NDVI')).addBands(earlyNDVI.rename('Pre_NDVI'))
/*
//////////////////////////planet//////////////////////////////
var planet1= nicfi.filter(ee.Filter.date(previus_date,End_second));
var planet2=nicfi.filter(ee.Filter.date(Start_second,End_second));
var vis_p = {"bands":["R","G","B"],"min":200,"max":3000,"gamma":1.8};
Map.addLayer(planet1.median().clip(filteredArea), vis_p, 'Planet mediana: '+previus_date.getInfo()+' - '+Start_second,false).setShown(0);
Map.addLayer(planet2.median().clip(filteredArea), vis_p, 'Planet mediana: '+Start_second+' - '+End_second,false).setShown(0);
var f_NDVI_p= require('users/jodaurmu/geetools:forestry_indexes_tools/JD_Urquiza_M_NDVI_planet')
var planet_ndvi1=planet1.map(f_NDVI_p.f_NDVI_p).median().clip(filteredArea)
var planet_ndvi2=planet2.map(f_NDVI_p.f_NDVI_p).median().clip(filteredArea)
var vis_pla_ndvi={min:0,max:1,palette: [
        '8bc4f9', 'c9995c', 'c7d270','8add60','097210']}
Map.addLayer(planet_ndvi1, vis_pla_ndvi, 'Planet ndvi mediana: '+previus_date.getInfo()+' - '+Start_second,false).setShown(0);
Map.addLayer(planet_ndvi2, vis_pla_ndvi, 'Planet ndvi mediana: '+Start_second+' - '+End_second,false).setShown(0);
var diffBandp = planet_ndvi1.subtract(planet_ndvi2)
var NDVI_threshold = ee.Number.parse(uiumbral.getValue());
var cambios_percentp=diffBandp.multiply(100).divide(planet_ndvi1).rename('Porcentual_PE')
var threshBandp= cambios_percentp.gte(NDVI_threshold).rename('Cambio_NDVI_PE'); 
var threshBandMaskedp = threshBandp.updateMask(threshBandp)
Map.addLayer(cambios_percentp.select('Porcentual_PE'),threshViz2,'Img de cambio porcentual Planet').setShown(0)
Map.addLayer(threshBandMaskedp, {pallete:'red'}, 'Umbral de Cambios planet');
var ndvi_allp=cambios_percentp.addBands(diffBandp.rename('Cambio_NDVI')).addBands(planet_ndvi2.rename('Post_NDVI')).addBands(planet_ndvi2.rename('Pre_NDVI'))
*/
////////////////////topo and landforms
// Load the SRTM image.
var srtm = ee.Image('USGS/SRTMGL1_003').select('elevation');
var elev_min= srtm.reduceRegion( {reducer: ee.Reducer.min(),  geometry: filteredArea,  scale: 30,  maxPixels: 1e9})
var elev_max= srtm.reduceRegion( {reducer: ee.Reducer.max(),  geometry: filteredArea,  scale: 30,  maxPixels: 1e9})
// Apply an algorithm to an image.
var slope = ee.Terrain.slope(srtm).clip(filteredArea)
// Get the aspect (in degrees).
var aspect = ee.Terrain.aspect(srtm).clip(filteredArea);
// Convert to radians, compute the sin of the aspect.
var sinImage = aspect.divide(180).multiply(Math.PI).sin();
// Display the result.
///var viz_elev = {
 // min: elev_min.get('elevation').getInfo(),
  //max: elev_max.get('elevation').getInfo(),
  //palette: ['blue','#5f6339','green','#38ed0e'  ]};
var viz_slp = {
  min: 0,
  max: 90,
  palette: ['green','orange','red'  ]};
//Map.addLayer(srtm.clip(filteredArea), viz_elev, 'Elevation').setShown(0)
//Map.addLayer(slope.clip(filteredArea), viz_slp, 'slope').setShown(0)
//Map.addLayer(sinImage.clip(filteredArea), {min: -1, max: 1,opacity:0.1}, 'Aspect').setShown(0);
//var xxx= elev_min.get('elevation').getInfo()
//////forest loss
var gfc2021 =hansen.clip(filteredArea)
var dif1=year_init.getValue()-2000
//print(dif1)
var dif2=year_fin.getValue()-2000
//print(dif2)
var gfc2021_loss=gfc2021.select(['lossyear'])
var gfc2021_anos= gfc2021_loss.gte(dif1).and(gfc2021_loss.lte(dif2))
var treeLossVisParam = {
  bands: ['lossyear'],
  min: 0,
  max: 21,
  palette: ['yellow', 'red']
};
var treeLossVisParam2 = {
  bands: ['lossyear'],
  min:dif1,
  max: dif2,
  palette: ['yellow', 'red']}
//Map.addLayer(gfc2021_loss.clip(filteredArea), treeLossVisParam, 'Perdida de bosques completa 2000-2021').setShown(0);
Map.addLayer(gfc2021_anos.select('lossyear').selfMask().clip(filteredArea), treeLossVisParam2, 'Perdida de bosques año definido').setShown(0);
//////////base map
var baseChange = [{featureType: 'all', stylers: [{invert_lightness: true}]}];
Map.setOptions('satellite', {'baseChange': baseChange});
Map.centerObject(filteredArea);
////////////////////////////////////////to add on the new panel left//////////////////////////////////////////////////////
var n_names=ui.Label({value:'Resultados del Análisis',style: {fontWeight: 'bold', fontSize: '22px', 
margin: '0px 0px 10px 20px',color:'green', textAlign:'center', backgroundColor:'white'}});
panel.widgets().set(1,n_names)
var names= S2_c2.aggregate_array('system:index')
var names2= S2_c22.aggregate_array('system:index')
var n_imgs=ui.Label({value:'Se analizó un total de '+names.size().getInfo()+' imagenes post-disturbio y un total de '+
names2.size().getInfo()+' imagenes-predisturbio. Todas ellas con un porcentaje menor al '+ cloudcover+'%.',
                style: {textAlign:'justify'}})
panel.widgets().set(2,n_imgs)
var ndvi_title=ui.Label({value:'Cambios en el NDVI: '+' Para el periodo: '+Start_select.getValue()+'-'+End_select.getValue(),
                style: {textAlign:'justify',fontWeight: 'bold', fontSize: '14px', margin: '10px 5px', backgroundColor:'white',color:'black'}})
//panel.widgets().set(4,ndvi_title)    
var arbol_cambio=earlyNDVI.select('NDVI').reduceRegions(arboles2,ee.Reducer.first().setOutputs(['zPre_NDVI']),  10)
arbol_cambio=lateNDVI.select('NDVI').reduceRegions(arbol_cambio,ee.Reducer.first().setOutputs(['zPos_NDVI']),  10)
arbol_cambio=diffBand.select('NDVI').reduceRegions(arbol_cambio,ee.Reducer.first().setOutputs(['zCam_NDVI']),  10)
arbol_cambio=cambios_percent.select('Porcentual').reduceRegions(arbol_cambio,ee.Reducer.first().setOutputs(['zPorcen']),  10)
/*arbol_cambio=planet_ndvi1.select('NDVI').reduceRegions(arbol_cambio,ee.Reducer.first().setOutputs(['zPre_NDVI_P']),  4.7)
arbol_cambio=planet_ndvi2.select('NDVI').reduceRegions(arbol_cambio,ee.Reducer.first().setOutputs(['zPos_NDVI_P']),  4.7)
arbol_cambio=diffBandp.select('NDVI').reduceRegions(arbol_cambio,ee.Reducer.first().setOutputs(['zCam_NDVI_P']),  4.7)
arbol_cambio=cambios_percentp.select('Porcentual_PE').reduceRegions(arbol_cambio,ee.Reducer.first().setOutputs(['zPorcen_P']),  4.7)
*/
var area_buff=bufferlevel_select.getValue()
var area_m2=area_buff*area_buff
var buffer=function(feature){return ee.Feature(feature.buffer(ee.Number(area_m2).sqrt().divide(2),1).bounds())}
var buffer_centroides=arbol_cambio.map(buffer)
Map.addLayer(buffer_centroides,{color:'blue'},'Buffer de inspección')
Map.addLayer(arboles2,{color:'red'}, 'Arboles');
buffer_centroides=cambios_percent.reduceRegions(buffer_centroides,ee.Reducer.max().setOutputs(['zPor_S2_'+area_buff+'m']),10)
//buffer_centroides=cambios_percentp.reduceRegions(buffer_centroides,ee.Reducer.max().setOutputs(['zPor_PS_'+area_buff+'m']),10)
var n_names=ui.Label({value:'Se analizaron '+arboles.size().getInfo()+' árboles, de los cuales '+arboles.filter(ee.Filter.gt('zPorcen',uiumbral.getValue())).size().getInfo()+
' tienen un porcentaje de cambio mayor o igual a '+uiumbral.getValue()+'% que podrían cosiderarse perturbados',
                style: {textAlign:'justify',margin: '10px 5px'}})
panel.widgets().set(3,n_names)
var n_names=ui.Label({value:'Cuando analizamos en una area de inspección de '+area_buff+'m, tenemos que '+buffer_centroides.filter(ee.Filter.gt('zPor_S2_'+area_buff+'m',ee.Number.parse(uiumbral.getValue()))).size().getInfo()+
' tienen un porcentaje de cambio mayor o igual a '+uiumbral.getValue()+'% que podrían cosiderarse perturbados. El análisis completo puede encontrarlo en los siguientes enlaces:',
                style: {textAlign:'justify',margin: '10px 5px'}})
panel.widgets().set(4,n_names)
// Get a download URL for the FeatureCollection.https://developers.google.com/earth-engine/apidocs/ee-featurecollection-getdownloadurl
var downloadUrl_ndvi = arbol_cambio.getDownloadURL({
  format: 'CSV',
  //selectors: ['capacitymw', 'fuel1'],
  filename: 'Analisis de cambios'
}); 
var download_label=ui.Label('Descargar Análisis por arbol ',complements.sub_tittle_fonts).setUrl(downloadUrl_ndvi)
panel.widgets().set(5,download_label) 
// Get a download URL for the FeatureCollection buffer
var downloadUrl_ndvi_b = buffer_centroides.getDownloadURL({
  format: 'CSV',
  //selectors: ['capacitymw', 'fuel1'],
  filename: 'Analisis de cambios en buffer'
}); 
var download_label_b=ui.Label('Descargar Análisis en area buffer de '+area_buff+'m',complements.sub_tittle_fonts).setUrl(downloadUrl_ndvi_b)
panel.widgets().set(6,download_label_b) 
var url_img_SA=ndvi_all.getDownloadURL({
    name: 'Img_cambio_'+previus_date.getInfo()+'_'+Start_second+'_'+Start_second+'_'+End_second,
    //bands: ['B3', 'B8', 'B11'],
    region: filteredArea.geometry(),
    scale: 10,
    //crs:'4326',
    filePerBand: false
  })
var download_label_img=ui.Label('Descargar Imagen S2A: Aqui ',complements.sub_tittle_fonts).setUrl(url_img_SA)
//panel.widgets().set(6,download_label_img) 
//function to export list of scenes  https://gis.stackexchange.com/questions/460465/export-list-of-lists-as-a-featurecollection-csv-in-gee
var post_imagenes_list= ee.FeatureCollection(S2_c2.map(function(list) {
    list = ee.List(list);
    var dict = {};
    return ee.Algorithms.If(list, ee.Feature(null, dict), null);
}));
var downloadUrl_escenasS2A_pre = post_imagenes_list.getDownloadURL({
  format: 'CSV',filename: 'Imagenes sentinel 2A post disturbio'
}); 
var download_label_scenas=ui.Label('Descargar lista de images Sentinel (post)',complements.sub_tittle_fonts).setUrl(downloadUrl_escenasS2A_pre)
panel.widgets().set(7,download_label_scenas) 
////////////////////
var pre_imagenes_list= ee.FeatureCollection(S2_c22.map(function(list) {
    list = ee.List(list);
    var dict = {};
    return ee.Algorithms.If(list, ee.Feature(null, dict), null);
}));
var downloadUrl_escenasS2A = pre_imagenes_list.getDownloadURL({
  format: 'CSV',  filename: 'Imagenes sentinel 2A pre disturbio'
}); 
var download_label_scenas=ui.Label('Descargar lista de images Sentinel (pre)',complements.sub_tittle_fonts).setUrl(downloadUrl_escenasS2A)
panel.widgets().set(8,download_label_scenas) 
var url_img_SA=ndvi_all.getDownloadURL({
    name: 'Img_cambio_'+previus_date.getInfo()+'_'+Start_second+'_'+Start_second+'_'+End_second,
    //bands: ['B3', 'B8', 'B11'],
    region: filteredArea.geometry(),
    scale: 10,
    //crs:'4326',
    filePerBand: false
  })
var download_label_img=ui.Label('Descargar Img S2A: Aqui ',complements.sub_tittle_fonts).setUrl(url_img_SA)
panel.widgets().set(9,download_label_img) 
//////////////////////////////////
/*Export.image.toDrive({
image: ndvi_all, 
description: 'Img_cambio_'+previus_date.getInfo()+'_'+Start_second+'_'+Start_second+'_'+End_second,
fileNamePrefix:'Img_cambio_'+previus_date.getInfo()+'_'+Start_second+'_'+Start_second+'_'+End_second,
region: filteredArea,
crs: 'EPSG:4326',
scale:10,
folder:'Perturbaciones',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: ndvi_allp, 
description: 'Img_cambio_PE_'+previus_date.getInfo()+'_'+Start_second+'_'+Start_second+'_'+End_second,
fileNamePrefix:'Img_cambio_PE_'+previus_date.getInfo()+'_'+Start_second+'_'+Start_second+'_'+End_second,
region: filteredArea,
crs: 'EPSG:4326',
scale:5,
folder:'Perturbaciones',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.table.toDrive({
collection:ee.FeatureCollection(arbol_cambio),
description: 'arboles',
//fileNamePrefix: 'Windthrows_'+date1.getInfo()+' to '+date4.getInfo(),
folder:'Perturbaciones',
fileFormat: 'SHP',
});
Export.table.toDrive({
collection:ee.FeatureCollection(buffer_centroides),
description: 'arboles_buffer',
//fileNamePrefix: 'Windthrows_'+date1.getInfo()+' to '+date4.getInfo(),
folder:'Perturbaciones',
fileFormat: 'SHP',
});
*/
var AddButton = function(){
      var button = ui.Button('Analisis por geoJSON');
      button.style().set({
        position: 'top-right',
        border : '1px solid #000000',
      });
      button.onClick(function(){return analysis()});
      Map.add(button);
}
AddButton(toolPanel);
}//end function geojson+app
////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////