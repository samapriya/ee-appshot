var ccff = ui.import && ui.import("ccff", "table", {
      "id": "users/jodaurmu/OSINFOR/OSINFOR_POLY_2022"
    }) || ee.FeatureCollection("users/jodaurmu/OSINFOR/OSINFOR_POLY_2022"),
    depa = ui.import && ui.import("depa", "table", {
      "id": "users/jodaurmu/DEPARTAMENTOS"
    }) || ee.FeatureCollection("users/jodaurmu/DEPARTAMENTOS"),
    hansen = ui.import && ui.import("hansen", "image", {
      "id": "UMD/hansen/global_forest_change_2021_v1_9"
    }) || ee.Image("UMD/hansen/global_forest_change_2021_v1_9"),
    nicfi = ui.import && ui.import("nicfi", "imageCollection", {
      "id": "projects/planet-nicfi/assets/basemaps/americas"
    }) || ee.ImageCollection("projects/planet-nicfi/assets/basemaps/americas"),
    PNCB_04 = ui.import && ui.import("PNCB_04", "image", {
      "id": "users/jodaurmu/PNCB_ATD_UTM_04_365_R"
    }) || ee.Image("users/jodaurmu/PNCB_ATD_UTM_04_365_R"),
    PNCB_01 = ui.import && ui.import("PNCB_01", "image", {
      "id": "users/jodaurmu/PNCB_ATD_UTM_01_212_R"
    }) || ee.Image("users/jodaurmu/PNCB_ATD_UTM_01_212_R"),
    logo = ui.import && ui.import("logo", "image", {
      "id": "users/jodaurmu/logos/gerfor"
    }) || ee.Image("users/jodaurmu/logos/gerfor");
/////////image downloader V1.0///////
/** * @license
 * Copyright 2022 David Urquiza - Universdad Nacional de la Amazonia Peruana
 **
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 ///////////////////////////////////////
var complements=require('users/jodaurmu/OSINFOR:complements');
////////////////////////////////////////
var header = ui.Label({value:'ENA Explorer V1',style: {fontWeight: 'bold', fontSize: '26px', 
margin: '0px 0px 10px 60px',color:'green', textAlign:'center', backgroundColor:'white'}});
var text2 = ui.Label('J. David Urquiza-Muñoz*');
var toolPanel=complements.toolPanel
var Panel2=complements.Panel2
ui.root.insert(1,toolPanel)
//ui.root.insert(0,Panel2)
toolPanel.add(header)
//toolPanel.add(text2)
//////////base map
var baseChange = [{featureType: 'all', stylers: [{invert_lightness: true}]}];
Map.setOptions('satellite', {'baseChange': baseChange});
Map.setCenter(-76, -5, 5);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var logo2 = logo.visualize({
   bands:  ['b1', 'b2', 'b3'],
    min: 0,
    max: 255
        });
var thumb2 = ui.Thumbnail({
    image: logo2,
    params: {
        dimensions: '1142x380',
        format: 'png'
        },
    style: {height: '120px', width: '100px',padding :'0',margin: '0px 4px 00px 100px'}
    });
toolPanel.add(thumb2)
var label_uiLoadJSON = ui.Label({value:'Ingrese geoJSON:', style:complements.tittle_fonts});
var uiLoadJSON = ui.Textbox({placeholder: 'Pegar geoJSON aquí (lat/long)',  style: {position: 'top-center', width: '350px', backgroundColor:'222222', fontWeight:'bold'}})
toolPanel.add(label_uiLoadJSON)
toolPanel.add(uiLoadJSON)
var AddButton = function(){
      var button = ui.Button('ver imagenes GeoJSON');
      button.style().set({
        position: 'top-center',
        border : '1px solid #000000',
      });
      button.onClick(function(){return analysis()});
      Map.add(button);
}
AddButton(toolPanel);
var analysis_tittle = ui.Label('Defina el Período y nubosidad de las imagenes: ',complements.tittle_fonts);
toolPanel.add(analysis_tittle)
var label_Start = ui.Label({value:'Inicio:',style: complements.sub_tittle_fonts});
toolPanel.add(label_Start)
var Start_select = ui.Textbox({
  value: '2019-01-01',
  style: {width : '90px'},
  onChange: function(text) {
    var Start_second = text
  }});
toolPanel.add(Start_select)
var label_End = ui.Label({value:'Final:',style: complements.sub_tittle_fonts});
toolPanel.add(label_End)
var End_select = ui.Textbox({
  value: '2019-12-31',
  style: {width : '90px'},
  onChange: function(text) {
    var End_second = text
  }});
toolPanel.add(End_select)
var label_cloudlevel_select = ui.Label({value:'Nubosidad menor a (5% - 90%):',style: complements.sub_tittle_fonts});
var cloudlevel_select = ui.Slider({
  min: 5,
  max: 90, 
  value: 10, 
  step: 1,
  onChange: function(value) {
    var cloudcover = value
  },style: {fontWeight: 'normal', fontSize: '16px', margin: '10px 5px', backgroundColor:'#06360d',color:'white',width: '180px'}
      });
toolPanel.add(label_cloudlevel_select)
toolPanel.add(cloudlevel_select)
var site_tittle = ui.Label('Defina el periodo para la perdida de bosque',complements.tittle_fonts);
toolPanel.add(site_tittle)
var year_init_titlle=ui.Label('Año de inicio',complements.tittle_fonts)
toolPanel.add(year_init_titlle)
var year_init=ui.Textbox({
  value: '2020',
  style: {width : '90px'},
  onChange: function(text) {
    var Start_second = text
  }});
toolPanel.add(year_init)
var year_fin_titlle=ui.Label('Año de final',complements.tittle_fonts)
toolPanel.add(year_fin_titlle)
var year_fin=ui.Textbox({
  value: '2021',
  style: {width : '90px'},
  onChange: function(text) {
    var Start_second = text
  }});
toolPanel.add(year_fin)
var consul1=ui.Label({
        value: '_______________________________________________________________________________',
        style: {fontWeight: 'bold', fontSize: '9px', margin: '100px 0px 0px 50px',backgroundColor:'#06360d',color:'white'}
      });
var consul2=ui.Label({
        value: 'Desarrollado por:',
        style: {fontWeight: 'bold', fontSize: '9px', margin: '10px 0px 0px 50px',backgroundColor:'#06360d',color:'white'}});
var consul3=ui.Label({value:'J. D. Urquiza Muñoz. En el marco del Proyecto Supervisiones Optimizadas - OSINFOR 2022', style: {fontWeight: 'bold', fontSize: '12px',color:'white', margin: '10px 50px',backgroundColor:'#06360d'}});
toolPanel.add(consul1)
toolPanel.add(consul2)
toolPanel.add(consul3)
////////////////////////////
var app = function() {
   var tool = new DrawAreaTool(Map)
  // subscribe to selection
  tool.onFinished(function(geometry) {
    checkbox.setValue(false, false)
    print(geometry)
    //Map.addLayer(geometry,{ color:'red' }, "Section")
Map.centerObject(geometry)
Map.setControlVisibility({
  drawingToolsControl:false
})
//Years
var Start_second = Start_select.getValue();
    var Start_second_number = ee.Number.parse(Start_second.replace(/-/g,'')).getInfo()
var End_second = End_select.getValue();
    var End_second_number = ee.Number.parse(End_second.replace(/-/g,'')).getInfo();
var cloudcover = cloudlevel_select.getValue()
//sentinel//////////////////////////////////////////////////////
/**
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
var S2_c2=ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate(Start_second,End_second)
                  .filterBounds(geometry)
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloudcover))
                  .map(maskS2clouds)
print('cantidad de imagenes S2',S2_c2)
var s2_vis = {
  min: 0,
  max: 0.4,
 bands: ['B4', 'B3', 'B2'],
  //bands: ['B4', 'B3', 'B2'],
  gamma: 1.65,
};
//Map.addLayer(S2_c2.median().clip(filteredArea),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
//Map.addLayer(S2_c2.reduce(ee.Reducer.percentile([10])).clip(filteredArea),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
Map.addLayer(S2_c2.median().clip(geometry),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
var planet= nicfi.filter(ee.Filter.date(Start_second,End_second)).median();
var vis_p = {"bands":["R","G","B"],"min":200,"max":3000,"gamma":1.8};
Map.addLayer(planet.clip(geometry), vis_p, 'Planet mosaic: '+Start_second+' - '+End_second,false).setShown(0);
// This example demonstrates the use of the Landsat 8 Collection 2, Level 2
// QA_PIXEL band (CFMask) to mask unwanted pixels.
function maskL8sr(image) {
  // Bit 0 - Fill
  // Bit 1 - Dilated Cloud
  // Bit 2 - Cirrus
  // Bit 3 - Cloud
  // Bit 4 - Cloud Shadow
  var qaMask = image.select('QA_PIXEL').bitwiseAnd(parseInt('11111', 2)).eq(0);
  var saturationMask = image.select('QA_RADSAT').eq(0);
  // Apply the scaling factors to the appropriate bands.
  var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
  // Replace the original bands with the scaled ones and apply the masks.
  return image.addBands(opticalBands, null, true)
      .addBands(thermalBands, null, true)
      .updateMask(qaMask)
      .updateMask(saturationMask);
}
var landsat = ee.ImageCollection("LANDSAT/LC08/C02/T1_L2")
  .filterDate(Start_second,End_second )
  .filterBounds(geometry)
  .filterMetadata("CLOUD_COVER","less_than",cloudcover)
  .map(maskL8sr)
print('cantidad de imagenes L8',landsat)
var trueColor432Vis = {
  bands: ['SR_B4', 'SR_B3', 'SR_B2'],
  'min': 0, 
  'max': 0.3
};
Map.addLayer(landsat.median().clip(geometry), trueColor432Vis, 'Landsat8 '+Start_second+' - '+End_second).setShown(0);
////////////////////////////////////////////////////////
///////////////////////////Forestry Indexes/////////////////////////////////////
var f_CCCI = function (image){
  return image.expression(
    '((B8 - B5)/(B8 + B5))/((B8-B4)/(B8+B4))', 
    {'B4': image.select('B4'),
    'B5': image.select('B5'),
      'B8': image.select('B8')}).rename('CCCI').copyProperties(image, image.propertyNames());
};
var f_NDVI_s = function(image) {
  return image.expression(
    '(NIR - RED) / (NIR + RED)', 
    {
      'NIR': image.select('B8'), 
      'RED': image.select('B4'), 
    }).rename('NDVI').copyProperties(image, image.propertyNames());
};
var f_EVI_s=function(image) {
  return image.expression(
    '2.5 * (B8 - B4) / (B8 + 6*B4-7.5* B2 + 1.0)', 
    {
      'B8': image.select('B8'), 
      'B4': image.select('B4'), 
      'B2':image.select('B2'),
    }).rename('EVI').copyProperties(image, image.propertyNames());
};///https://www.indexdatabase.de/db/si-single.php?sensor_id=96&rsindex_id=576
var f_NDWI_s = function (image){
  return image.expression(
    '(B3 - B8)/(B3 + B8)', 
    {'B3': image.select('B3'),
      'B8': image.select('B8')}).rename('NDWI').copyProperties(image, image.propertyNames());
};
var f_sipi_s=function (image){
  return image.expression(
    '(B8 - B1) / (B8 - B4)', 
    {'B8': image.select('B8'),
      'B1': image.select('B1'),
      'B4': image.select('B4')}).rename('SIPI').copyProperties(image, image.propertyNames());
};
var mergedCCI = S2_c2.map(f_CCCI);
var mergedNDVI= S2_c2.map(f_NDVI_s);
var mergedNDWI= S2_c2.map(f_NDWI_s);
var mergedEVI= S2_c2.map(f_EVI_s);
var mergedSIPI=S2_c2.map(f_sipi_s);
var CCCI_select=mergedCCI.select('CCCI')
var NDVI_select=mergedNDVI.select('NDVI')
var NDWI_select=mergedNDWI.select('NDWI')
var EVI_select=mergedEVI.select('EVI')
var SIPI_select=mergedSIPI.select('SIPI')
///show images
var cccipalette = {
  min: 0,
  max: 1,
palette: ['darkblue','blue','lightblue','lightgreen','green','darkgreen']};
Map.addLayer(CCCI_select.median().clip(geometry),cccipalette,'S2- Canopy Chlorophyll Content Index period: '+Start_second+' - '+End_second).setShown(0)
var ndwipalette = {
  min: -0.9,
  max: 0.2,
palette: ['darkgreen','green','lightgreen','lightblue','blue','darkblue']};
Map.addLayer(NDWI_select.median().clip(geometry),ndwipalette,'S2-NDWI period: '+Start_second+' - '+End_second).setShown(0)
var NDVIpalette = {
  min: 0.0,
  max: 1.0,
palette: ['red','orange','yellow','lightgreen','green','darkgreen']};
Map.addLayer(NDVI_select.median().clip(geometry),NDVIpalette,'S2-NDVI period: '+Start_second+' - '+End_second).setShown(0)
////////////////////topo and landforms
// Load the SRTM image.
var srtm = ee.Image('USGS/SRTMGL1_003').select('elevation');
var elev_min= srtm.reduceRegion( {reducer: ee.Reducer.min(),  geometry: geometry,  scale: 30,  maxPixels: 1e9})
var elev_max= srtm.reduceRegion( {reducer: ee.Reducer.max(),  geometry: geometry,  scale: 30,  maxPixels: 1e9})
// Apply an algorithm to an image.
var slope = ee.Terrain.slope(srtm).clip(geometry)
// Get the aspect (in degrees).
var aspect = ee.Terrain.aspect(srtm).clip(geometry);
// Convert to radians, compute the sin of the aspect.
var sinImage = aspect.divide(180).multiply(Math.PI).sin();
// Display the result.
var viz_elev = {
  min: elev_min.get('elevation').getInfo(),
  max: elev_max.get('elevation').getInfo(),
  palette: ['blue','#5f6339','green','#38ed0e'  ]};
var viz_slp = {
  min: 0,
  max: 90,
  palette: ['green','orange','red'  ]};
Map.addLayer(srtm.clip(geometry), viz_elev, 'Elevation').setShown(0)
Map.addLayer(slope.clip(geometry), viz_slp, 'slope').setShown(0)
Map.addLayer(sinImage.clip(geometry), {min: -1, max: 1,opacity:0.1}, 'Aspect').setShown(0);
var xxx= elev_min.get('elevation').getInfo()
//////forest loss
var gfc2021 =hansen.clip(geometry)
var dif1=year_init.getValue()-2000
print(dif1)
var dif2=year_fin.getValue()-2000
print(dif2)
var gfc2021_loss=gfc2021.select(['lossyear'])
var gfc2021_anos= gfc2021_loss.gte(dif1).and(gfc2021_loss.lte(dif2))
var treeLossVisParam = {
  bands: ['lossyear'],
  min: 0,
  max: 21,
  palette: ['yellow', 'red']
};
var treeLossVisParam2 = {
  bands: ['lossyear'],
  min:dif1,
  max: dif2,
  palette: ['yellow', 'red']}
Map.addLayer(gfc2021_loss.clip(geometry), treeLossVisParam, 'Perdida de bosques completa').setShown(0);
Map.addLayer(gfc2021_anos.select('lossyear').selfMask().clip(geometry), treeLossVisParam2, 'Perdida de bosques ano definido');
var vectors = gfc2021_anos.select('lossyear').selfMask().clip(geometry).reduceToVectors({
  reducer:ee.Reducer.countEvery(),
  geometry: geometry,
  crs: 'EPSG:4326',
  scale: 10,
  //geometryType: 'polygon',
  eightConnected: false,
  labelProperty: 'lossyear',
  //reducer: ee.Reducer.first(),
  tileScale:1,
  maxPixels:1e8,
  bestEffort:true,
  geometryInNativeProjection:true
});
// Make a display image for the vectors, add it to the map.
var display = ee.Image(0).updateMask(0).paint(vectors, 'red', 3);
Map.addLayer(display,{palette:'red'}, 'Perdida de bosques vector');
Map.addLayer(PNCB_01.clip(geometry),{}, 'Alertas 1');
var vectors1 = PNCB_01.clip(geometry).reduceToVectors({
  reducer:ee.Reducer.countEvery(),
  geometry: geometry,
  //crs: dnpv_mask_cor.projection(),
  scale: 30,
  //geometryType: 'polygon',
  eightConnected: false,
  labelProperty: 'zone',
  //reducer: ee.Reducer.first(),
  maxPixels:1e8
  //bestEffort:true,
});
// Make a display image for the vectors, add it to the map.
var display2 = ee.Image(0).updateMask(0).paint(vectors1, 'red', 3);
Map.addLayer(display2,{}, 'Alerta 1 vector');
Map.addLayer(PNCB_04.clip(geometry),{}, 'Alertas 2')
//////////base map
var baseChange = [{featureType: 'all', stylers: [{invert_lightness: true}]}];
Map.setOptions('satellite', {'baseChange': baseChange});
Map.centerObject(geometry);
//////////////////////////////////////////////////////////////////////////////////////////////
Export.image.toDrive({
image: planet.clip(geometry), 
description: 'Planet_mosaic_'+Start_second+'_'+End_second+'_',
fileNamePrefix:'Planet_mosaic_'+Start_second+'_'+End_second+'_',
region: geometry,
crs: 'EPSG:4326',
scale:5,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: S2_c2.median().clip(geometry), 
description: 'S2_Periodo_'+Start_second+'_'+End_second+'_',
fileNamePrefix:'S2_Periodo_'+Start_second+'_'+End_second+'_',
region: geometry,
crs: 'EPSG:4326',
scale:10,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: srtm.clip(geometry), 
description: 'Elevacion_SRTM_30m'+'_',
fileNamePrefix:'Elevacion_SRTM_30m'+'_',
region: geometry,
crs: 'EPSG:4326',
scale:30,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: hansen.select('lossyear').clip(geometry), 
description: 'Hansen_2022_30m'+'_',
fileNamePrefix:'Hansen_2022_30m'+'_',
region: geometry,
crs: 'EPSG:4326',
scale:30,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: landsat.median().clip(geometry), 
description: 'L8_30m'+'_',
fileNamePrefix:'L8_30m'+'_',
region: geometry,
crs: 'EPSG:4326',
scale:30,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.table.toDrive({
collection:ee.FeatureCollection(vectors),
description: 'Perdida_bosques',
//fileNamePrefix: 'Windthrows_'+date1.getInfo()+' to '+date4.getInfo(),
folder:'Imagenes OSINFOR',
fileFormat: 'SHP',
});
Export.table.toDrive({
collection:ee.FeatureCollection(vectors1),
description: 'Alertas',
//fileNamePrefix: 'Windthrows_'+date1.getInfo()+' to '+date4.getInfo(),
folder:'Imagenes OSINFOR',
fileFormat: 'SHP',
});
})
  // add checkbox to activate selector when checkbox is clicked
  var checkbox = ui.Checkbox({label: 'Analisis por area', 
                              style: {fontFamily:'serif',backgroundColor:'white',fontWeight:'bold',whiteSpace:'pre'}});
  checkbox.onChange(function(checked) {
    if(checked) {
      tool.startDrawing()
    } else {
      tool.stopDrawing()
    }
  });
//var description=ui.Label('Check/uncheck bellow to draw/remove a transect',{fontWeight: 'normal', fontSize: '10px', margin: '10px 5px', backgroundColor:'white',color:'black'})
var panel_c = ui.Panel({
  widgets: [checkbox],
  //layout: ui.Panel.Layout.flow('vertical','top-left'),
  style: {backgroundColor:'white',fontFamily:'monospace',position:'top-right',stretch:'both'},
});
Map.add(panel_c);
}//end app funtions
var DrawAreaTool = function(draw) {
  this.map = draw
  this.layer = ui.Map.Layer({name: 'Section', visParams: { color:'red' }}).setShown(1)
  this.selection = null
  this.active = false
  this.points = []
  this.area = null
  this.listeners = []
  var tool = this;
  this.initialize = function() {
    this.map.onClick(this.onMouseClick)
    this.map.layers().add(this.layer)
  }
  this.startDrawing = function() {
    this.active = true
    this.points = []
    this.map.style().set('cursor', 'crosshair');
    this.layer.setShown(true)
  }
  this.stopDrawing = function() {
    tool.active = false
    tool.map.style().set('cursor', 'hand');
    if(tool.points.length < 2) {
      return
    }
    tool.area = ee.Geometry.Polygon(tool.points)
    tool.layer.setEeObject(tool.area)
    tool.listeners.map(function(listener) {
      listener(tool.area)
    })
  }
  /***
  * Mouse click event handler
  */
  this.onMouseClick = function(coords) {
    if(!tool.active) {
      return
    }
    tool.points.push([coords.lon, coords.lat])
    var geom = tool.points.length > 1 ? ee.Geometry.LineString(tool.points) : ee.Geometry.Point(tool.points[0])
    tool.layer.setEeObject(geom)
    var l = ee.Geometry.LineString([tool.points[0], tool.points[tool.points.length-1]]).length(1).getInfo()
    if(tool.points.length > 1 && l / Map.getScale() < 5) {
      tool.stopDrawing()
    }
  }
  /***
  * Adds a new event handler, fired on feature selection. 
  */
  this.onFinished = function(listener) {
    tool.listeners.push(listener)
  }
  this.initialize()
}
app()
/////////////////////////////
//////////////////////////////geoJSON function/////////////////+ app start
function analysis(){
//var sensor0=Sensor.getValue()
                 Map.clear()
//Years
var Start_second = Start_select.getValue();
    var Start_second_number = ee.Number.parse(Start_second.replace(/-/g,'')).getInfo()
var End_second = End_select.getValue();
    var End_second_number = ee.Number.parse(End_second.replace(/-/g,'')).getInfo();
var cloudcover = cloudlevel_select.getValue()
var areas = uiLoadJSON.getValue()
var filter_a = ee.List(ee.Dictionary(ee.String(areas).decodeJSON()).get("features")).map(function(item){item = ee.Dictionary(item)
return ee.Feature(ee.Geometry.MultiPolygon(ee.Dictionary(item.get("geometry")).get("coordinates")), 
	 item.get("properties"))})
var filteredArea = ee.FeatureCollection(filter_a);
//var ccff_name=countiesDD.getValue()///to the chart name
//sentinel//////////////////////////////////////////////////////
/**
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
var S2_c2=ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate(Start_second,End_second)
                  .filterBounds(filteredArea)
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloudcover))
                  .map(maskS2clouds)
print('cantidad de imagenes S2',S2_c2)
var s2_vis = {
  min: 0,
  max: 0.4,
 bands: ['B4', 'B3', 'B2'],
  //bands: ['B4', 'B3', 'B2'],
  gamma: 1.65,
};
//Map.addLayer(S2_c2.median().clip(filteredArea),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
//Map.addLayer(S2_c2.reduce(ee.Reducer.percentile([10])).clip(filteredArea),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
Map.addLayer(S2_c2.median().clip(filteredArea),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
var planet= nicfi.filter(ee.Filter.date(Start_second,End_second)).median();
var vis_p = {"bands":["R","G","B"],"min":200,"max":3000,"gamma":1.8};
Map.addLayer(planet.clip(filteredArea), vis_p, 'Planet mosaic: '+Start_second+' - '+End_second,false).setShown(0);
// This example demonstrates the use of the Landsat 8 Collection 2, Level 2
// QA_PIXEL band (CFMask) to mask unwanted pixels.
function maskL8sr(image) {
  // Bit 0 - Fill
  // Bit 1 - Dilated Cloud
  // Bit 2 - Cirrus
  // Bit 3 - Cloud
  // Bit 4 - Cloud Shadow
  var qaMask = image.select('QA_PIXEL').bitwiseAnd(parseInt('11111', 2)).eq(0);
  var saturationMask = image.select('QA_RADSAT').eq(0);
  // Apply the scaling factors to the appropriate bands.
  var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
  // Replace the original bands with the scaled ones and apply the masks.
  return image.addBands(opticalBands, null, true)
      .addBands(thermalBands, null, true)
      .updateMask(qaMask)
      .updateMask(saturationMask);
}
var landsat = ee.ImageCollection("LANDSAT/LC08/C02/T1_L2")
  .filterDate(Start_second,End_second )
  .filterBounds(filteredArea)
  .filterMetadata("CLOUD_COVER","less_than",cloudcover)
  .map(maskL8sr)
print('cantidad de imagenes L8',landsat)
var trueColor432Vis = {
  bands: ['SR_B4', 'SR_B3', 'SR_B2'],
  'min': 0, 
  'max': 0.3
};
Map.addLayer(landsat.median().clip(filteredArea), trueColor432Vis, 'Landsat8 '+Start_second+' - '+End_second).setShown(0);
////////////////////////////////////////////////////////
///////////////////////////Forestry Indexes/////////////////////////////////////
var f_CCCI = function (image){
  return image.expression(
    '((B8 - B5)/(B8 + B5))/((B8-B4)/(B8+B4))', 
    {'B4': image.select('B4'),
    'B5': image.select('B5'),
      'B8': image.select('B8')}).rename('CCCI').copyProperties(image, image.propertyNames());
};
var f_NDVI_s = function(image) {
  return image.expression(
    '(NIR - RED) / (NIR + RED)', 
    {
      'NIR': image.select('B8'), 
      'RED': image.select('B4'), 
    }).rename('NDVI').copyProperties(image, image.propertyNames());
};
var f_EVI_s=function(image) {
  return image.expression(
    '2.5 * (B8 - B4) / (B8 + 6*B4-7.5* B2 + 1.0)', 
    {
      'B8': image.select('B8'), 
      'B4': image.select('B4'), 
      'B2':image.select('B2'),
    }).rename('EVI').copyProperties(image, image.propertyNames());
};///https://www.indexdatabase.de/db/si-single.php?sensor_id=96&rsindex_id=576
var f_NDWI_s = function (image){
  return image.expression(
    '(B3 - B8)/(B3 + B8)', 
    {'B3': image.select('B3'),
      'B8': image.select('B8')}).rename('NDWI').copyProperties(image, image.propertyNames());
};
var f_sipi_s=function (image){
  return image.expression(
    '(B8 - B1) / (B8 - B4)', 
    {'B8': image.select('B8'),
      'B1': image.select('B1'),
      'B4': image.select('B4')}).rename('SIPI').copyProperties(image, image.propertyNames());
};
var mergedCCI = S2_c2.map(f_CCCI);
var mergedNDVI= S2_c2.map(f_NDVI_s);
var mergedNDWI= S2_c2.map(f_NDWI_s);
var mergedEVI= S2_c2.map(f_EVI_s);
var mergedSIPI=S2_c2.map(f_sipi_s);
var CCCI_select=mergedCCI.select('CCCI')
var NDVI_select=mergedNDVI.select('NDVI')
var NDWI_select=mergedNDWI.select('NDWI')
var EVI_select=mergedEVI.select('EVI')
var SIPI_select=mergedSIPI.select('SIPI')
///show images
var cccipalette = {
  min: 0,
  max: 1,
palette: ['darkblue','blue','lightblue','lightgreen','green','darkgreen']};
Map.addLayer(CCCI_select.median().clip(filteredArea),cccipalette,'S2- Canopy Chlorophyll Content Index period: '+Start_second+' - '+End_second).setShown(0)
var ndwipalette = {
  min: -0.9,
  max: 0.2,
palette: ['darkgreen','green','lightgreen','lightblue','blue','darkblue']};
Map.addLayer(NDWI_select.median().clip(filteredArea),ndwipalette,'S2-NDWI period: '+Start_second+' - '+End_second).setShown(0)
var NDVIpalette = {
  min: 0.0,
  max: 1.0,
palette: ['red','orange','yellow','lightgreen','green','darkgreen']};
Map.addLayer(NDVI_select.median().clip(filteredArea),NDVIpalette,'S2-NDVI period: '+Start_second+' - '+End_second).setShown(0)
////////////////////topo and landforms
// Load the SRTM image.
var srtm = ee.Image('USGS/SRTMGL1_003').select('elevation');
var elev_min= srtm.reduceRegion( {reducer: ee.Reducer.min(),  geometry: filteredArea,  scale: 30,  maxPixels: 1e9})
var elev_max= srtm.reduceRegion( {reducer: ee.Reducer.max(),  geometry: filteredArea,  scale: 30,  maxPixels: 1e9})
// Apply an algorithm to an image.
var slope = ee.Terrain.slope(srtm).clip(filteredArea)
// Get the aspect (in degrees).
var aspect = ee.Terrain.aspect(srtm).clip(filteredArea);
// Convert to radians, compute the sin of the aspect.
var sinImage = aspect.divide(180).multiply(Math.PI).sin();
// Display the result.
var viz_elev = {
  min: elev_min.get('elevation').getInfo(),
  max: elev_max.get('elevation').getInfo(),
  palette: ['blue','#5f6339','green','#38ed0e'  ]};
var viz_slp = {
  min: 0,
  max: 90,
  palette: ['green','orange','red'  ]};
Map.addLayer(srtm.clip(filteredArea), viz_elev, 'Elevation').setShown(0)
Map.addLayer(slope.clip(filteredArea), viz_slp, 'slope').setShown(0)
Map.addLayer(sinImage.clip(filteredArea), {min: -1, max: 1,opacity:0.1}, 'Aspect').setShown(0);
var xxx= elev_min.get('elevation').getInfo()
//////forest loss
var gfc2021 =hansen.clip(filteredArea)
var dif1=year_init.getValue()-2000
print(dif1)
var dif2=year_fin.getValue()-2000
print(dif2)
var gfc2021_loss=gfc2021.select(['lossyear'])
var gfc2021_anos= gfc2021_loss.gte(dif1).and(gfc2021_loss.lte(dif2))
var treeLossVisParam = {
  bands: ['lossyear'],
  min: 0,
  max: 21,
  palette: ['yellow', 'red']
};
var treeLossVisParam2 = {
  bands: ['lossyear'],
  min:dif1,
  max: dif2,
  palette: ['yellow', 'red']}
Map.addLayer(gfc2021_loss.clip(filteredArea), treeLossVisParam, 'Perdida de bosques completa 2000-2021').setShown(0);
Map.addLayer(gfc2021_anos.select('lossyear').selfMask().clip(filteredArea), treeLossVisParam2, 'Perdida de bosques ano definido');
var vectors = gfc2021_anos.select('lossyear').selfMask().clip(filteredArea).reduceToVectors({
  reducer:ee.Reducer.countEvery(),
  geometry: filteredArea,
  crs: 'EPSG:4326',
  scale: 10,
  //geometryType: 'polygon',
  eightConnected: false,
  labelProperty: 'lossyear',
  //reducer: ee.Reducer.first(),
  tileScale:1,
  maxPixels:1e8,
  bestEffort:true,
  geometryInNativeProjection:true
});
// Make a display image for the vectors, add it to the map.
var display = ee.Image(0).updateMask(0).paint(vectors, 'red', 3);
Map.addLayer(display,{palette:'red'}, 'Perdida de bosques vector');
Map.addLayer(PNCB_01.clip(filteredArea),{}, 'Alertas 1');
var vectors1 = PNCB_01.clip(filteredArea).reduceToVectors({
  reducer:ee.Reducer.countEvery(),
  geometry: filteredArea,
  //crs: dnpv_mask_cor.projection(),
  scale: 30,
  //geometryType: 'polygon',
  eightConnected: false,
  labelProperty: 'zone',
  //reducer: ee.Reducer.first(),
  maxPixels:1e8
  //bestEffort:true,
});
// Make a display image for the vectors, add it to the map.
var display2 = ee.Image(0).updateMask(0).paint(vectors1, 'red', 3);
Map.addLayer(display2,{}, 'Alerta 1 vector');
Map.addLayer(PNCB_04.clip(filteredArea),{}, 'Alertas 2')
//////////base map
var baseChange = [{featureType: 'all', stylers: [{invert_lightness: true}]}];
Map.setOptions('satellite', {'baseChange': baseChange});
Map.centerObject(filteredArea);
//////////////////////////////////////////////////////////////////////////////////////////////
var AddButton = function(){
      var button = ui.Button('Ver imagenes GeoJSON');
      button.style().set({
        position: 'top-center',
        border : '1px solid #000000',
      });
      button.onClick(function(){return analysis()});
      Map.add(button);
}
AddButton(toolPanel);
Export.image.toDrive({
image: planet.clip(filteredArea), 
description: 'Planet_mosaic_'+Start_second+'_'+End_second+'_',
fileNamePrefix:'Planet_mosaic_'+Start_second+'_'+End_second+'_',
region: filteredArea,
crs: 'EPSG:4326',
scale:5,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: S2_c2.median().clip(filteredArea), 
description: 'S2_Periodo_'+Start_second+'_'+End_second+'_',
fileNamePrefix:'S2_Periodo_'+Start_second+'_'+End_second+'_',
region: filteredArea,
crs: 'EPSG:4326',
scale:10,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: srtm.clip(filteredArea), 
description: 'Elevacion_SRTM_30m'+'_',
fileNamePrefix:'Elevacion_SRTM_30m'+'_',
region: filteredArea,
crs: 'EPSG:4326',
scale:30,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: hansen.select('lossyear').clip(filteredArea), 
description: 'Hansen_2022_30m'+'_',
fileNamePrefix:'Hansen_2022_30m'+'_',
region: filteredArea,
crs: 'EPSG:4326',
scale:30,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: landsat.median().clip(filteredArea), 
description: 'L8_30m'+'_',
fileNamePrefix:'L8_30m'+'_',
region: filteredArea,
crs: 'EPSG:4326',
scale:30,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.table.toDrive({
collection:ee.FeatureCollection(vectors),
description: 'Perdida_bosques',
//fileNamePrefix: 'Windthrows_'+date1.getInfo()+' to '+date4.getInfo(),
folder:'Imagenes OSINFOR',
fileFormat: 'SHP',
});
Export.table.toDrive({
collection:ee.FeatureCollection(vectors1),
description: 'Alertas',
//fileNamePrefix: 'Windthrows_'+date1.getInfo()+' to '+date4.getInfo(),
folder:'Imagenes OSINFOR',
fileFormat: 'SHP',
});
////////////////////////////
var app = function() {
   var tool = new DrawAreaTool(Map)
    // subscribe to selection
  tool.onFinished(function(geometry) {
    checkbox.setValue(false, false)
    print(geometry)
    Map.addLayer(geometry,{ color:'red' }, "Section")
Map.centerObject(geometry)
Map.setControlVisibility({
  drawingToolsControl:false
})
//Years
var Start_second = Start_select.getValue();
    var Start_second_number = ee.Number.parse(Start_second.replace(/-/g,'')).getInfo()
var End_second = End_select.getValue();
    var End_second_number = ee.Number.parse(End_second.replace(/-/g,'')).getInfo();
var cloudcover = cloudlevel_select.getValue()
//sentinel//////////////////////////////////////////////////////
/**
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
var S2_c2=ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate(Start_second,End_second)
                  .filterBounds(geometry)
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloudcover))
                  .map(maskS2clouds)
print('cantidad de imagenes S2',S2_c2)
var s2_vis = {
  min: 0,
  max: 0.4,
 bands: ['B4', 'B3', 'B2'],
  //bands: ['B4', 'B3', 'B2'],
  gamma: 1.65,
};
//Map.addLayer(S2_c2.median().clip(filteredArea),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
//Map.addLayer(S2_c2.reduce(ee.Reducer.percentile([10])).clip(filteredArea),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
Map.addLayer(S2_c2.median().clip(geometry),s2_vis,'SENTINEL 2 Period: '+Start_second+' - '+End_second)
var planet= nicfi.filter(ee.Filter.date(Start_second,End_second)).median();
var vis_p = {"bands":["R","G","B"],"min":200,"max":3000,"gamma":1.8};
Map.addLayer(planet.clip(geometry), vis_p, 'Planet mosaic: '+Start_second+' - '+End_second,false).setShown(0);
// This example demonstrates the use of the Landsat 8 Collection 2, Level 2
// QA_PIXEL band (CFMask) to mask unwanted pixels.
function maskL8sr(image) {
  // Bit 0 - Fill
  // Bit 1 - Dilated Cloud
  // Bit 2 - Cirrus
  // Bit 3 - Cloud
  // Bit 4 - Cloud Shadow
  var qaMask = image.select('QA_PIXEL').bitwiseAnd(parseInt('11111', 2)).eq(0);
  var saturationMask = image.select('QA_RADSAT').eq(0);
  // Apply the scaling factors to the appropriate bands.
  var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
  // Replace the original bands with the scaled ones and apply the masks.
  return image.addBands(opticalBands, null, true)
      .addBands(thermalBands, null, true)
      .updateMask(qaMask)
      .updateMask(saturationMask);
}
var landsat = ee.ImageCollection("LANDSAT/LC08/C02/T1_L2")
  .filterDate(Start_second,End_second )
  .filterBounds(geometry)
  .filterMetadata("CLOUD_COVER","less_than",cloudcover)
  .map(maskL8sr)
print('cantidad de imagenes L8',landsat)
var trueColor432Vis = {
  bands: ['SR_B4', 'SR_B3', 'SR_B2'],
  'min': 0, 
  'max': 0.3
};
Map.addLayer(landsat.median().clip(geometry), trueColor432Vis, 'Landsat8 '+Start_second+' - '+End_second).setShown(0);
////////////////////////////////////////////////////////
///////////////////////////Forestry Indexes/////////////////////////////////////
var f_CCCI = function (image){
  return image.expression(
    '((B8 - B5)/(B8 + B5))/((B8-B4)/(B8+B4))', 
    {'B4': image.select('B4'),
    'B5': image.select('B5'),
      'B8': image.select('B8')}).rename('CCCI').copyProperties(image, image.propertyNames());
};
var f_NDVI_s = function(image) {
  return image.expression(
    '(NIR - RED) / (NIR + RED)', 
    {
      'NIR': image.select('B8'), 
      'RED': image.select('B4'), 
    }).rename('NDVI').copyProperties(image, image.propertyNames());
};
var f_EVI_s=function(image) {
  return image.expression(
    '2.5 * (B8 - B4) / (B8 + 6*B4-7.5* B2 + 1.0)', 
    {
      'B8': image.select('B8'), 
      'B4': image.select('B4'), 
      'B2':image.select('B2'),
    }).rename('EVI').copyProperties(image, image.propertyNames());
};///https://www.indexdatabase.de/db/si-single.php?sensor_id=96&rsindex_id=576
var f_NDWI_s = function (image){
  return image.expression(
    '(B3 - B8)/(B3 + B8)', 
    {'B3': image.select('B3'),
      'B8': image.select('B8')}).rename('NDWI').copyProperties(image, image.propertyNames());
};
var f_sipi_s=function (image){
  return image.expression(
    '(B8 - B1) / (B8 - B4)', 
    {'B8': image.select('B8'),
      'B1': image.select('B1'),
      'B4': image.select('B4')}).rename('SIPI').copyProperties(image, image.propertyNames());
};
var mergedCCI = S2_c2.map(f_CCCI);
var mergedNDVI= S2_c2.map(f_NDVI_s);
var mergedNDWI= S2_c2.map(f_NDWI_s);
var mergedEVI= S2_c2.map(f_EVI_s);
var mergedSIPI=S2_c2.map(f_sipi_s);
var CCCI_select=mergedCCI.select('CCCI')
var NDVI_select=mergedNDVI.select('NDVI')
var NDWI_select=mergedNDWI.select('NDWI')
var EVI_select=mergedEVI.select('EVI')
var SIPI_select=mergedSIPI.select('SIPI')
///show images
var cccipalette = {
  min: 0,
  max: 1,
palette: ['darkblue','blue','lightblue','lightgreen','green','darkgreen']};
Map.addLayer(CCCI_select.median().clip(geometry),cccipalette,'S2- Canopy Chlorophyll Content Index period: '+Start_second+' - '+End_second).setShown(0)
var ndwipalette = {
  min: -0.9,
  max: 0.2,
palette: ['darkgreen','green','lightgreen','lightblue','blue','darkblue']};
Map.addLayer(NDWI_select.median().clip(geometry),ndwipalette,'S2-NDWI period: '+Start_second+' - '+End_second).setShown(0)
var NDVIpalette = {
  min: 0.0,
  max: 1.0,
palette: ['red','orange','yellow','lightgreen','green','darkgreen']};
Map.addLayer(NDVI_select.median().clip(geometry),NDVIpalette,'S2-NDVI period: '+Start_second+' - '+End_second).setShown(0)
////////////////////topo and landforms
// Load the SRTM image.
var srtm = ee.Image('USGS/SRTMGL1_003').select('elevation');
var elev_min= srtm.reduceRegion( {reducer: ee.Reducer.min(),  geometry: geometry,  scale: 30,  maxPixels: 1e9})
var elev_max= srtm.reduceRegion( {reducer: ee.Reducer.max(),  geometry: geometry,  scale: 30,  maxPixels: 1e9})
// Apply an algorithm to an image.
var slope = ee.Terrain.slope(srtm).clip(geometry)
// Get the aspect (in degrees).
var aspect = ee.Terrain.aspect(srtm).clip(geometry);
// Convert to radians, compute the sin of the aspect.
var sinImage = aspect.divide(180).multiply(Math.PI).sin();
// Display the result.
var viz_elev = {
  min: elev_min.get('elevation').getInfo(),
  max: elev_max.get('elevation').getInfo(),
  palette: ['blue','#5f6339','green','#38ed0e'  ]};
var viz_slp = {
  min: 0,
  max: 90,
  palette: ['green','orange','red'  ]};
Map.addLayer(srtm.clip(geometry), viz_elev, 'Elevation').setShown(0)
Map.addLayer(slope.clip(geometry), viz_slp, 'slope').setShown(0)
Map.addLayer(sinImage.clip(geometry), {min: -1, max: 1,opacity:0.1}, 'Aspect').setShown(0);
var xxx= elev_min.get('elevation').getInfo()
//////forest loss
var gfc2021 =hansen.clip(geometry)
var dif1=year_init.getValue()-2000
print(dif1)
var dif2=year_fin.getValue()-2000
print(dif2)
var gfc2021_loss=gfc2021.select(['lossyear'])
var gfc2021_anos= gfc2021_loss.gte(dif1).and(gfc2021_loss.lte(dif2))
var treeLossVisParam = {
  bands: ['lossyear'],
  min: 0,
  max: 21,
  palette: ['yellow', 'red']
};
var treeLossVisParam2 = {
  bands: ['lossyear'],
  min:dif1,
  max: dif2,
  palette: ['yellow', 'red']}
Map.addLayer(gfc2021_loss.clip(geometry), treeLossVisParam, 'Perdida de bosques completa').setShown(0);
Map.addLayer(gfc2021_anos.select('lossyear').selfMask().clip(geometry), treeLossVisParam2, 'Perdida de bosques ano definido');
var vectors = gfc2021_anos.select('lossyear').selfMask().clip(geometry).reduceToVectors({
  reducer:ee.Reducer.countEvery(),
  geometry: geometry,
  crs: 'EPSG:4326',
  scale: 10,
  //geometryType: 'polygon',
  eightConnected: false,
  labelProperty: 'lossyear',
  //reducer: ee.Reducer.first(),
  tileScale:1,
  maxPixels:1e8,
  bestEffort:true,
  geometryInNativeProjection:true
});
// Make a display image for the vectors, add it to the map.
var display = ee.Image(0).updateMask(0).paint(vectors, '000000', 3);
Map.addLayer(display,{palette:'red'}, 'Perdida de bosques vector');
Map.addLayer(PNCB_01.clip(geometry),{}, 'Alertas 1');
var vectors1 = PNCB_01.clip(geometry).reduceToVectors({
  reducer:ee.Reducer.countEvery(),
  geometry: geometry,
  //crs: dnpv_mask_cor.projection(),
  scale: 30,
  //geometryType: 'polygon',
  eightConnected: false,
  labelProperty: 'zone',
  //reducer: ee.Reducer.first(),
  maxPixels:1e8
  //bestEffort:true,
});
// Make a display image for the vectors, add it to the map.
var display2 = ee.Image(0).updateMask(0).paint(vectors1, 'red', 3);
Map.addLayer(display2,{}, 'Alerta 1 vector');
Map.addLayer(PNCB_04.clip(geometry),{}, 'Alertas 2')
//////////base map
var baseChange = [{featureType: 'all', stylers: [{invert_lightness: true}]}];
Map.setOptions('satellite', {'baseChange': baseChange});
Map.centerObject(geometry);
//////////////////////////////////////////////////////////////////////////////////////////////
Export.image.toDrive({
image: planet.clip(geometry), 
description: 'Planet_mosaic_'+Start_second+'_'+End_second+'_',
fileNamePrefix:'Planet_mosaic_'+Start_second+'_'+End_second+'_',
region: geometry,
crs: 'EPSG:4326',
scale:5,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: S2_c2.median().clip(geometry), 
description: 'S2_Periodo_'+Start_second+'_'+End_second+'_',
fileNamePrefix:'S2_Periodo_'+Start_second+'_'+End_second+'_',
region: geometry,
crs: 'EPSG:4326',
scale:10,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: srtm.clip(geometry), 
description: 'Elevacion_SRTM_30m'+'_',
fileNamePrefix:'Elevacion_SRTM_30m'+'_',
region: geometry,
crs: 'EPSG:4326',
scale:30,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: hansen.select('lossyear').clip(geometry), 
description: 'Hansen_2022_30m'+'_',
fileNamePrefix:'Hansen_2022_30m'+'_',
region: geometry,
crs: 'EPSG:4326',
scale:30,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.image.toDrive({
image: landsat.median().clip(geometry), 
description: 'L8_30m'+'_',
fileNamePrefix:'L8_30m'+'_',
region: geometry,
crs: 'EPSG:4326',
scale:30,
folder:'Imagenes OSINFOR',
maxPixels: 1e13,fileFormat: 'GeoTIFF',skipEmptyTiles: true});
Export.table.toDrive({
collection:ee.FeatureCollection(vectors),
description: 'Perdida_bosques',
//fileNamePrefix: 'Windthrows_'+date1.getInfo()+' to '+date4.getInfo(),
folder:'Imagenes OSINFOR',
fileFormat: 'SHP',
});
Export.table.toDrive({
collection:ee.FeatureCollection(vectors1),
description: 'Alertas',
//fileNamePrefix: 'Windthrows_'+date1.getInfo()+' to '+date4.getInfo(),
folder:'Imagenes OSINFOR',
fileFormat: 'SHP',
});
})
  // add checkbox to activate selector when checkbox is clicked
  var checkbox = ui.Checkbox({label: 'Analisis por area', 
                              style: {fontFamily:'serif',backgroundColor:'white',fontWeight:'bold',whiteSpace:'pre'}});
  checkbox.onChange(function(checked) {
    if(checked) {
      Map.layers().reset()
      tool.startDrawing()
      } else {
      tool.stopDrawing()
    }
  });
//var description=ui.Label('Check/uncheck bellow to draw/remove a transect',{fontWeight: 'normal', fontSize: '10px', margin: '10px 5px', backgroundColor:'white',color:'black'})
var panel_c = ui.Panel({
  widgets: [checkbox],
  //layout: ui.Panel.Layout.flow('vertical','top-left'),
  style: {backgroundColor:'white',fontFamily:'monospace',position:'top-right',stretch:'both'},
});
Map.add(panel_c);
}//end app funtions
var DrawAreaTool = function(draw) {
  this.map = draw
  this.layer = ui.Map.Layer({name: 'Section', visParams: { color:'red' }}).setShown(1)
  this.selection = null
  this.active = false
  this.points = []
  this.area = null
  this.listeners = []
  var tool = this;
  this.initialize = function() {
    this.map.onClick(this.onMouseClick)
    this.map.layers().add(this.layer)
  }
  this.startDrawing = function() {
    this.active = true
    this.points = []
    this.map.style().set('cursor', 'crosshair');
    this.layer.setShown(true)
  }
  this.stopDrawing = function() {
    tool.active = false
    tool.map.style().set('cursor', 'hand');
    if(tool.points.length < 2) {
      return
    }
    tool.area = ee.Geometry.Polygon(tool.points)
    tool.layer.setEeObject(tool.area)
    tool.listeners.map(function(listener) {
      listener(tool.area)
    })
  }
  /***
  * Mouse click event handler
  */
  this.onMouseClick = function(coords) {
    if(!tool.active) {
      return
    }
    tool.points.push([coords.lon, coords.lat])
    var geom = tool.points.length > 1 ? ee.Geometry.LineString(tool.points) : ee.Geometry.Point(tool.points[0])
    tool.layer.setEeObject(geom)
    var l = ee.Geometry.LineString([tool.points[0], tool.points[tool.points.length-1]]).length(1).getInfo()
    if(tool.points.length > 1 && l / Map.getScale() < 5) {
      tool.stopDrawing()
    }
  }
  /***
  * Adds a new event handler, fired on feature selection. 
  */
  this.onFinished = function(listener) {
    tool.listeners.push(listener)
  }
  this.initialize()
}
app()
}//end function geojson+app
////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////