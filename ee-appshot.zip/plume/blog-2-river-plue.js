// DEFINE FUNCTIONS
function landsat_scaler(Image) {
  var optical = Image.select('SR_B.').multiply(0.0000275).add(-0.2);
  var thermal = Image.select('ST_B.*').multiply(0.00341802).add(149);
  Image = Image.addBands(optical, null, true).addBands(thermal, null, true);
  return Image;
}
function landsat_cloud_mask(Image) {
  var qa = Image.select('QA_PIXEL');
  var cirrus = qa.bitwiseAnd((1 << 2)).eq(0);
  var cloud = qa.bitwiseAnd((1 << 3)).eq(0);
  var shadow = qa.bitwiseAnd((1 << 4)).eq(0);
  var snow = qa.bitwiseAnd((1 << 5)).eq(0);
  Image = Image.updateMask(cirrus).updateMask(cloud).updateMask(shadow).updateMask(snow);
  return Image;
}
function montlhy_calc(ImageCollection, band) {
  var months = ee.List.sequence(1, 12);
  function filter_calc(month) {
    var data = ImageCollection.filter(ee.Filter.calendarRange(month, month, 'month'));
    data = data.select(band).reduce(ee.Reducer.mean()).set('month', month);
    return data;
  }
  var monthly = ee.ImageCollection.fromImages(months.map(filter_calc));
  return monthly;
}
function plume_characterization(Image) {
  Image = Image.addBands(Image.expression(
        "(b('GREEN_mean') - b('NIR_mean'))/(b('GREEN_mean') + b('NIR_mean'))"
    ).rename('NDWI'), null, true);
    var mask = Image.select('NDWI').gt(0);
    Image = Image.updateMask(mask);
    var reducer = ee.Reducer.min().combine({reducer2:ee.Reducer.max(), sharedInputs:true});
    var limits = Image.select(['BLUE_mean', 'GREEN_mean', 'RED_mean']).reduceRegion({
      reducer:reducer,
      geometry:san_juan,
      scale:30
    });
    Image = Image.addBands(Image.expression(
        "(b('BLUE_mean') > MINI && b('BLUE_mean') < MAXI) ? 1 : 0",
        {
            'MAXI': limits.getNumber('BLUE_mean_max'), 
            'MINI': limits.getNumber('BLUE_mean_min')
        }
    ).rename('plume_blue'), null, true);
    Image = Image.addBands(Image.expression(
        "(b('GREEN_mean') > MINI && b('GREEN_mean') < MAXI) ? 1 : 0",
        {
            'MAXI': limits.getNumber('GREEN_mean_max'), 
            'MINI': limits.getNumber('GREEN_mean_min')
        }
    ).rename('plume_green'), null, true);
    Image = Image.addBands(Image.expression(
        "(b('RED_mean') > MINI && b('RED_mean') < MAXI) ? 1 : 0",
        {
            'MAXI': limits.getNumber('RED_mean_max'), 
            'MINI': limits.getNumber('RED_mean_min')
        }
    ).rename('plume_red'), null, true);
    Image = Image.addBands(Image.expression(
        "(b('plume_blue') + b('plume_green') + b('plume_red'))/3"
    ).rename('plume'), null, true);
    var plume_mask = Image.select('plume').gt(0.5);
    var pixel_count = plume_mask.select(0).connectedPixelCount(100, false);
    var count_mask = pixel_count.select(0).gt(50);
    Image = Image.updateMask(plume_mask).updateMask(count_mask);
    return Image;
}
// LOAD DATA
var samples = ee.FeatureCollection('projects/ee-river-plume/assets/samples');
var san_juan = samples.filter(ee.Filter.eq('name', 'San Juan')).first().geometry();
var L5 = ee.ImageCollection('LANDSAT/LT05/C02/T1_L2').filterDate('1986-01-01', '1999-12-31');
L5 = L5.filterBounds(san_juan).map(landsat_cloud_mask).map(landsat_scaler);
L5 = L5.map(function(image) {
  image = image.addBands(image.select('SR_B1').rename('BLUE'));
  return image;
});
L5 = L5.map(function(image) {
  image = image.addBands(image.select('SR_B2').rename('GREEN'));
  return image;
});
L5 = L5.map(function(image) {
  image = image.addBands(image.select('SR_B3').rename('RED'));
  return image;
});
L5 = L5.map(function(image) {
  image = image.addBands(image.select('SR_B4').rename('NIR'));
  return image;
});
L5 = L5.select(['BLUE', 'GREEN', 'RED', 'NIR']);
var L7 = ee.ImageCollection('LANDSAT/LE07/C02/T1_L2').filterDate('2000-01-01', '2013-12-31');
L7 = L7.filterBounds(san_juan).map(landsat_cloud_mask).map(landsat_scaler);
L7 = L7.map(function(image) {
  image = image.addBands(image.select('SR_B1').rename('BLUE'));
  return image;
});
L7 = L7.map(function(image) {
  image = image.addBands(image.select('SR_B2').rename('GREEN'));
  return image;
});
L7 = L7.map(function(image) {
  image = image.addBands(image.select('SR_B3').rename('RED'));
  return image;
});
L7 = L7.map(function(image) {
  image = image.addBands(image.select('SR_B4').rename('NIR'));
  return image;
});
L7 = L7.select(['BLUE', 'GREEN', 'RED', 'NIR']);
var L8 = ee.ImageCollection('LANDSAT/LC08/C02/T1_L2').filterDate('2014-01-01', '2021-12-31');
L8 = L8.filterBounds(san_juan).map(landsat_cloud_mask).map(landsat_scaler);
L8 = L8.map(function(image) {
  image = image.addBands(image.select('SR_B2').rename('BLUE'));
  return image;
});
L8 = L8.map(function(image) {
  image = image.addBands(image.select('SR_B3').rename('GREEN'));
  return image;
});
L8 = L8.map(function(image) {
  image = image.addBands(image.select('SR_B4').rename('RED'));
  return image;
});
L8 = L8.map(function(image) {
  image = image.addBands(image.select('SR_B5').rename('NIR'));
  return image;
});
L8 = L8.select(['BLUE', 'GREEN', 'RED', 'NIR']);
// MERGE IMAGECOLLECTION
var IC = L5.merge(L7).merge(L8);
// CALCULATE MONTHLY MEAN
var monthly_mean = montlhy_calc(IC, ['BLUE', 'GREEN', 'RED', 'NIR']);
// GENERATE PLUMES
var plumes = monthly_mean.map(plume_characterization);
// VISUALIZATION
var vis_SR = {
    'bands': ['RED_mean', 'GREEN_mean', 'BLUE_mean'],
    'min': 0.0,
    'max': 0.3
}
var vis_plume = {
    'bands': ['plume'],
    'min': 0.0,
    'max': 1.0,
    'palette': ['blue', 'cyan']
}
// WIDGETS
var checkbox_l = ui.Checkbox('Plume in Low Flow', true);
var checkbox_h = ui.Checkbox('Plume in High Flow', false);
checkbox_l.onChange(function(checked) {Map.layers().get(0).setShown(checked)});
checkbox_h.onChange(function(checked) {Map.layers().get(1).setShown(checked)});
var panel = ui.Panel();
panel.style().set({
  position: 'bottom-right'
});
panel.add(checkbox_l);
panel.add(checkbox_h);
Map.add(panel);
var title = ui.Label('River Plume of San Juan River (Chocó)');
title.style().set({fontSize: '16pt', fontWeight: 'bold'});
var panel_2 = ui.Panel();
panel_2.style().set({
  position: 'bottom-left'
});
panel_2.add(title);
Map.add(panel_2);
// MAP
var valid_months = [2, 4, 6, 7, 9, 11];
Map.addLayer(plumes.filter(ee.Filter.eq('month', 2)), vis_plume, 'Plume low flow', true);
Map.addLayer(plumes.filter(ee.Filter.eq('month', 9)), vis_plume, 'Plume high flow', false);
Map.centerObject(san_juan, 10);
Map.setOptions('SATELLITE');
Map.setControlVisibility(false);