/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var imageCollection = ee.ImageCollection("projects/gee-test-gee-atmcorr-s2/assets/ten_images"),
    table = ee.FeatureCollection("projects/ee-river-plume/assets/AOI");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
ui.root.setLayout(ui.Panel.Layout.absolute());
var FC = ee.FeatureCollection(table);
var AOI = FC.first().geometry();
var dates = ee.List(imageCollection.reduceColumns(ee.Reducer.toList(), ["system:time_start"]).get("list"));
var datesSize = dates.size().getInfo() - 1;
function getVisParams(selectorValue) {
  if (selectorValue == "Temperatura") {
    return {bands: ["TEMPERATURE"], min: 28, max: 32, palette: ['#2c7bb6','#abd9e9','#ffffbf','#fdae61','#d7191c']};
  } else if (selectorValue == "Salinidad") {
    return {bands: ["SALINITY"], min: 30, max: 38, palette: ['#feebe2','#fbb4b9','#f768a1','#c51b8a','#7a0177']};
  } else if (selectorValue == "Clorofila (Chl-a)") {
    return {bands: ["CHL-A"], min: 10, max: 20, palette: ['#ffffcc','#c2e699','#78c679','#31a354','#006837']};    
  } else if (selectorValue == "Sedimento en suspensión (CSS)") {
    return {bands: ["CSS"], min: 2, max: 8, palette: ['#ffffd4','#fed98e','#fe9929','#d95f0e','#993404']};
  } else {
    return {bands: ["RED", "GREEN", "BLUE"], min: 0.00, max: 0.25, gamma: 1.50};
  }
}
function updateColorbar(selectorValue) {
  if (selectorValue != "Imagen Real") {
    var vis = getVisParams(selectorValue);
    var palette = vis.palette;
    var title = ui.Label(selectorValue);
    var minLabel = ui.Label(vis.min, {margin: "0 auto 0 0"});
    var per25Label = ui.Label((vis.max - vis.min) / 4 + vis.min, {margin: "0 auto 0 auto"});
    var per75Label = ui.Label(vis.max - (vis.max - vis.min) / 4, {margin: "0 auto 0 auto"});
    var maxLabel = ui.Label(vis.max, {margin: "0 0 0 auto"});
    var colorbar = ui.Thumbnail({
      image: ee.Image.pixelLonLat().select('longitude'),
      params: {dimensions: '1000x10',format: 'png', min: 0, max: 5, bbox: [0, 0, 5, 0.1], palette: palette},
      style: {stretch: 'vertical', position: 'top-left', border: "1px solid black"}
    });
    var labelPanel = ui.Panel({
      widgets: [minLabel, per25Label, per75Label, maxLabel],
      layout: ui.Panel.Layout.flow("horizontal"),
      style: {stretch: "horizontal"}
    });
    var colorbarPanel = ui.Panel({
      widgets: [title, colorbar, labelPanel],
      layout: ui.Panel.Layout.flow("vertical"),
      style: {
        position: "bottom-left",
        width: "20vw",
        height: "11vh",
        margin: "1vw",
        border: "5px solid rgba(0, 80, 200, 0.5)",
      },
    });
    ui.root.add(colorbarPanel);
  } else {
    for (var i = ui.root.widgets().length() - 1; i > 2; i--) {
      ui.root.remove(ui.root.widgets().get(i));
    }
  }
}
function updateImage(sliderValue) {
  var date = ee.Date(dates.get(sliderValue));
  var image = imageCollection.filterDate(date, date.advance(1, "day"));
  var dateString = date.format("MMM dd YYYY").getInfo();
  var vis = getVisParams(selector.getValue());
  Map.clear();
  Map.setOptions('SATELLITE');
  Map.setControlVisibility({all: false});
  Map.setControlVisibility({fullscreenControl: true, scaleControl: true});
  Map.addLayer(AOI, {color: "yellow"});
  Map.addLayer(image, vis, dateString);
  Map.onClick(handleClick);
  dateLabel.setValue("Fecha: " + dateString);
}
function updateImageSelector(selectorValue) {
  updateImage(slider.getValue());
  updateColorbar(selectorValue);
}
var dateLabel = ui.Label("Fecha: ", {fontSize: "18px", fontWeight: "bold"});
var slider = ui.Slider({
  min: 0,
  max: datesSize,
  value: datesSize,
  step: 1,
  onChange: updateImage,
  style: {fontSize: 0, width: "18vw", margin: "1rem 1rem"},
});
var selector = ui.Select({
  items: ["Imagen Real", "Temperatura", "Salinidad", "Clorofila (Chl-a)", "Sedimento en suspensión (CSS)"],
  placeholder: "Seleccione una imagen: ",
  value: "Imagen Real",
  onChange: updateImageSelector,
});
var controlPanel = ui.Panel(
  [dateLabel, slider, selector],
  ui.Panel.Layout.flow("vertical", true),
  {
    position: "top-left",
    width: "20vw",
    height: "15vh",
    margin: "1vw",
    stretch: "vertical",
    textAlign: "center",
    border: "5px solid rgba(0, 80, 200, 0.5)",
  }
);
function getChart(point, variable, title, label, color) {
  var chart = ui.Chart.image.series({
    imageCollection: imageCollection.select(variable),
    region: point,
  }).setOptions({
    title: title,
    hAxis: {title: "Tiempo", titleTextStyle: {italic: false, bold: true}},
    vAxis: {title: label, titleTextStyle: {italic: false, bold: true}},
    legend: {position: "none"},
    colors: [color],
    pointSize: 5,
    lineSize: 2 
  });
  return chart;
}
function updateCharts(point) {
  var tempChart = getChart(point, "TEMPERATURE", "Temperatura a través del tiempo", "Temperatura (°C)", "#d7191c");
  var saltChart = getChart(point, "SALINITY", "Salinidad a través del tiempo", "Salinidad (PSU)", "#c51b8a");
  var chlChart = getChart(point, "CHL-A", "Clorofila a través del tiempo", "Chl-A (ppm)", "#31a354");
  var cssChart = getChart(point, "CSS", "Sedimento en suspensión a través del tiempo", "CSS (ppm)", "#d95f0e");
  chartPanel.clear();
  chartPanel.add(tempChart);
  chartPanel.add(saltChart);
  chartPanel.add(chlChart);
  chartPanel.add(cssChart);
}
function handleClick(coords) {
  var pixelLon = coords.lon;
  var pixelLat = coords.lat;
  var point = ee.Geometry.Point(pixelLon, pixelLat);
  updateCharts(point);
}
var chartPanel = ui.Panel({
  widgets: [],
  layout: ui.Panel.Layout.flow("vertical"),
  style: {
    position: "top-right",
    width: "30vw",
    height: "60vh",
    margin: "1vw",
    stretch: "vertical",
    textAlign: "center",
    border: "5px solid rgba(0, 80, 200, 0.5)",
  }
});
Map.centerObject(imageCollection);
ui.root.add(controlPanel);
ui.root.add(chartPanel);
updateCharts(AOI);
updateImage(datesSize);