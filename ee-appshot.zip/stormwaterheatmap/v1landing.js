var imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 0.9,
        "bands": [
          "TSS_ug_L"
        ],
        "max": 60000,
        "palette": [
          "440154",
          "414487",
          "2a788e",
          "22a884",
          "7ad151",
          "fde725"
        ]
      }
    }) || {"opacity":0.9,"bands":["TSS_ug_L"],"max":60000,"palette":["440154","414487","2a788e","22a884","7ad151","fde725"]},
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 0.9,
        "bands": [
          "TSS_ug_L"
        ],
        "min": 10000,
        "max": 60000,
        "palette": [
          "440154",
          "433e85",
          "25858e",
          "1e9b8a",
          "2ab07f",
          "52c569",
          "86d549",
          "c2df23",
          "fde725"
        ]
      }
    }) || {"opacity":0.9,"bands":["TSS_ug_L"],"min":10000,"max":60000,"palette":["440154","433e85","25858e","1e9b8a","2ab07f","52c569","86d549","c2df23","fde725"]};
//ui.root.clear();
//sandbox 
ui.root.setLayout(ui.Panel.Layout.absolute());
// data 
var data = require('users/stormwaterheatmap/apps:data/data_dict_v3')
var Style = require('users/stormwaterheatmap/apps:Modules/Style')
var helpers = require('users/stormwaterheatmap/apps:Modules/helpers')
var fonts = Style.fonts 
var rasters = data.rasters
print(rasters)
var layer_types = {"Input Data Layers": {}, "Hydrology Data Layers": {}}; 
layer_types["Input Data Layers"] = {
  "Soils": rasters.Soils, 
  "Age of Imperviousness": rasters["Age of Imperviousness"], 
  "HSPF Land Cover Type": rasters["HSPF Land Cover Type"], 
  "Imperviousness": rasters["Imperviousness"], 
  "Land Cover": rasters["Land Cover"], 
  "Land Use": rasters["Land Use"], 
  "Population": rasters["Population"], 
  "Population Density": rasters["Population Density"], 
  "Precipitation (in)": rasters["Precipitation (in)"], 
  "Precipitation (mm)": rasters["Precipitation (mm)"], 
  "Runoff (in)": rasters["Runoff (in)"], 
  "Runoff (mm)": rasters["Runoff (mm)"], 
  "Slope": rasters["Slope"], 
  "Slope Categories": rasters["Slope Categories"], 
  "Traffic": rasters["Traffic"]}
layer_types["Hydrology Data Layers"]={
  "Flow Duration Index": rasters["Flow Duration Index"], 
  "Hydrologic Response Units": rasters["Hydrologic Response Units"], 
  "Runoff (in)": rasters["Runoff (in)"], 
  "Runoff (mm)": rasters["Runoff (mm)"]
}
//var test_list = (Object.keys(rasters["Input Data Layers"]))
layer_types["Pollutant Loading"]={
  "Total Suspended Solids Concentration": rasters["Total Suspended Solids Concentration"], 
  "Total Suspended Solids Load": rasters["Total Suspended Solids Load"], 
}
/* ----------------------------
WIDGETS 
*/
/* Select */ 
var panel = ui.Panel();
/* Label */ 
var panel_label = helpers.info_panel("Select Layer Type:","null")
var layer_label = ui.Label({value:"Display Layer:"})
var panel_layout = ui.Panel.Layout.absolute("bottom-left")
/* Style */ 
panel_label.style().set('fontWeight','500')
var panel_style = {position: 'bottom-left'}//,width:'300px', height:"80%"}
/* Panel */ 
var panel = ui.Panel({style:panel_style})//, layout:panel_layout})//, })
//Map.add(panel)
var legendPanel = ui.Panel({style:{position:'bottom-right',shown:false, minWidth: "200px", maxWidth: "300px"}
})
Map.add(legendPanel)
var select_layer_type = ui.Select({
  items: Object.keys(layer_types),
  placeholder: "Select Layer Type", 
  value: Object.keys(layer_types)[0], 
  onChange: function() {
    var layer_dict = layer_types[select_layer_type.getValue()]; 
    //print(layer_dict)
    var layers_list = Object.keys(layer_dict); 
      secondname_select = ui.Select({
        items: layers_list,//select_layer_type.getValue()], 
        onChange: function() {
          var layer_obj = layer_dict[secondname_select.getValue()]
          legendPanel.style().set({shown:true})
          helpers.clear_map_add_layer(layer_obj,legendPanel)
        }
      });
    panel.widgets().set(3, secondname_select);
  }
  });
var secondname_select = ui.Select({items: 
  Object.keys(layer_types["Input Data Layers"]),
  onChange: function(result) {
          var layer_obj = data.rasters[result]
          legendPanel.style().set({shown:true})
          helpers.clear_map_add_layer(layer_obj,legendPanel)
        }
});
panel.widgets().set(0, panel_label); 
panel.widgets().set(1, select_layer_type);
panel.widgets().set(2,layer_label); 
panel.widgets().set(3, secondname_select);
var map_init = function(map){
 var m = map || Map
 //m.clear()
 //m.add(panel)
 //m.add(legendPanel)
 select_layer_type.setValue("Pollutant Loading")
 secondname_select.setValue("Total Suspended Solids Concentration")
 //legendPanel.style().set({shown:true})
          //helpers.clear_map_add_layer(layer_obj,legendPanel)
}
helpers.make_tnc_map()
map_init()
var mainPanel = helpers.makeMainPanel("View Data Layers");
mainPanel.add(panel)
Map.add(mainPanel)