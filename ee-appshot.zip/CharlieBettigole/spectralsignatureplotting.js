var ls8 = ui.import && ui.import("ls8", "imageCollection", {
      "id": "LANDSAT/LC08/C02/T1_TOA"
    }) || ee.ImageCollection("LANDSAT/LC08/C02/T1_TOA"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B4",
          "B3",
          "B2"
        ],
        "max": 0.165,
        "gamma": 1.6
      }
    }) || {"opacity":1,"bands":["B4","B3","B2"],"max":0.165,"gamma":1.6},
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -123.49004711644712,
                49.65669721800917
              ],
              [
                -123.49004711644712,
                48.75388323117929
              ],
              [
                -121.45894970433775,
                48.75388323117929
              ],
              [
                -121.45894970433775,
                49.65669721800917
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#00ffff",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-123.49004711644712, 49.65669721800917],
          [-123.49004711644712, 48.75388323117929],
          [-121.45894970433775, 48.75388323117929],
          [-121.45894970433775, 49.65669721800917]]], null, false);
var lscoll = ls8
                // .filterBounds(geometry)
                .filterDate('2020-06-15','2025-10-01')
                .filter(ee.Filter.lt('CLOUD_COVER', 20))
                .filter(ee.Filter.calendarRange(6,9,'month'));
var maskClouds = function(image) {
  var scored = ee.Algorithms.Landsat.simpleCloudScore(image);
  return image.updateMask(scored.select(['cloud']).lt(10));
};
// Function to mask clouds using the quality band of Landsat 8.
var maskL8 = function(image) {
  var qa = image.select('QA_PIXEL');
  /// Check that the cloud bit is off.
  // See https://www.usgs.gov/media/files/landsat-8-9-olitirs-collection-2-level-1-data-format-control-book
  var mask = qa.bitwiseAnd(1 << 3).eq(0)
                .bitwiseAnd(1<<4).eq(0)
                .bitwiseAnd(1<<2).eq(0)
                .bitwiseAnd(1<<1).eq(0);
  return image.updateMask(mask);
};
var lsMask = lscoll.map(maskL8)
var lsComp = lsMask.median()//.clip(geometry)
Map.addLayer(lsComp,{bands:['B4','B3','B2'],max:0.165, gamma:1.6},"somelayer")
Map.centerObject(geometry,10)
var panel = ui.Panel({
  style: {position:'bottom-right',
     width: '400px'}
})
var title = ui.Label({value:"Cloud Free Vancouver",
       style:{fontWeight:'bold',fontSize:'24px'}
			     });
var subTitle = ui.Label({value:"Click on map to generate spectral profile",
       style:{fontSize:'18px'}
			     });
panel.add(title).add(subTitle)
Map.add(panel);		     
////  Training data and spectral charting //////
var bandSelect = ['B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7']
// --- Accumulator for clicked points (each with a label) ---
var clicked = [];
// Placeholder inside your existing panel to host the live chart
var chartHolder = ui.Panel({style: {margin: '8px 0 0 0'}});
panel.add(chartHolder);
// Optional: clear button to reset clicks & markers
var toolsRow = ui.Panel({layout: ui.Panel.Layout.flow('horizontal')});
var clearBtn = ui.Button({
  label: 'Clear chart & markers',
  onClick: function () {
    clicked = [];
    chartHolder.clear();
    // remove click markers
    var layers = Map.layers();
    for (var i = layers.length() - 1; i >= 0; i--) {
      var lyr = layers.get(i);
      var name = lyr.getName();              // might be null/undefined
      if (typeof name === 'string' && name.indexOf('Click') === 0) {
        layers.remove(lyr);
      }
    }
  },
  style: {margin: '6px 0 0 0'}
});
toolsRow.add(clearBtn);
panel.add(toolsRow);
// Chart options (tweak as you like)
var liveChartOptions = {
  title: 'Landsat 8 spectral profiles (clicked points)',
  hAxis: {title: 'Band', slantedText: true},
  vAxis: {title: 'Reflectance'},
  legend: {position: 'right'},
  lineWidth: 2,
  pointSize: 5
};
// Handy formatter
function fmt(n){ return ee.Number(n).format('%.5f'); }
// Update/rebuild the chart from all clicked points
function updateChart() {
  if (clicked.length === 0) {
    chartHolder.clear();
    return;
  }
  var regions = ee.FeatureCollection(clicked);
  var chart = ui.Chart.image.regions({
      image: lsComp.select(bandSelect),  // ['B1'...'B7']
      regions: regions,
      reducer: ee.Reducer.mean(),
      scale: 30,
      seriesProperty: 'label',
      xLabels: bandSelect
    })
    .setChartType('LineChart') // multiple series = multiple lines
    .setOptions(liveChartOptions);
  chartHolder.clear();
  chartHolder.add(chart);
}
// Click handler: add a point + label, then refresh chart
Map.onClick(function(coords){
  var pt = ee.Geometry.Point([coords.lon, coords.lat]);
  var label = 'Pt ' + (clicked.length + 1) + '  (' +
              coords.lat.toFixed(5) + ', ' + coords.lon.toFixed(5) + ')';
  // store the new region with a label for series naming
  clicked.push(ee.Feature(pt, {label: label}));
  // add a small visual marker so you can see clicked locations
  var marker = ee.FeatureCollection([ee.Feature(pt)]);
  Map.addLayer(marker.style({color: 'red', pointSize: 6}),
               {}, 'Click ' + Date.now());
  updateChart();
});