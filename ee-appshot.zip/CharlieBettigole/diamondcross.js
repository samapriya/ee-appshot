/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var User_Defined_Comp = /* color: #98ff00 */ee.Geometry.MultiPoint(),
    usa = ee.FeatureCollection("ft:1ZZ8j0NDbs2dilcQWjLh9xI7qIJso6DgYAoGTbA"),
    User_Defined = /* color: #d63000 */ee.Geometry.MultiPoint(),
    cva_wc = ee.ImageCollection("users/CharlieBettigole/willowcreek/cva_wc"),
    cva_wy = ee.ImageCollection("users/CharlieBettigole/AllWY/CVA_WY"),
    daymet = ee.ImageCollection("NASA/ORNL/DAYMET_V3"),
    geomer = /* color: #d63000 */ee.Geometry.Point([-110.37088394165039, 43.00364283472864]),
    maindisplayoptions = {"opacity":1,"bands":["NDVI"],"min":-0.3,"max":0.3,"palette":["5d127c","f6ffb4","4a8d30"]},
    ndviviz = {"opacity":1,"bands":["NDVI"],"palette":["eb6525","fffdbe","edf574","afde72","53a53f"]},
    varviz = {"opacity":1,"bands":["NDVI"],"min":0.021211424812979666,"max":0.15234769291277966,"palette":["e7e3d9","f6ffb4","acc42a"]};
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var panel1 = ui.Panel({
    style: {width: '300px',position: 'bottom-left',fontSize:'10px'}
   });
var panel2 = ui.Panel({
    style: {width: '300px',position: 'bottom-right',fontSize:'10px'}
   });
var panel3 = ui.Panel({
  style: {width: '650px',position: 'bottom-center',fontSize:'10px'}
 });
var panel4 = ui.Panel({
  style: {width: '450px',position: 'top-center',fontSize:'10px'}
});
Map.setOptions('terrain')
Map.add(panel1).add(panel2).add(panel3).add(panel4)
//}
var nlcd = ee.Image("USGS/NLCD/NLCD2011")
var tkmask = nlcd.select('percent_tree_cover').lt(30) //set threshold for tree cover masking
var uifunction = function (rancher) {
Map.layers().reset()
Map.setOptions('terrain')
panel1.clear()
panel2.clear()
panel3.clear()
panel4.clear()
panel1.add(title)
      .add(desc)
      .add(ui.Label('1. Select Ranch to Analyze'))
      .add(ranchselect)
      // .add(ui.Label('1a. Select Pasture to Analyze'))
      // .add(pastureselect)
      // .add(ftinput)
      // .add(bufferbuttlab)
      // .add(bufferbutt)
app()      
panel1.add(label1)
      .add(select1)
      .add(label2)
      .add(select2)
      // .add(maskpan)
      .add(chartbutton)
      .add(precipchartbutton)
      .add(button1)
panel2.add(title2)
      .add(ui.Label('4. Run CVA for buffer around selected ranch?'))
      .add(buffercheck)
      .add(ui.Label('5. Select buffer distance (meters)'))
      .add(buffdistslide)
      .add(ui.Label('6. Run CVA for study area vs. comparison ranch?'))
      .add(compcheck)
      .add(ui.Label('7. Select comparison ranch'))
      .add(compselect)
      // .add(ui.Label('7a. Select comparison pasture'))
      // .add(pasturecompselect)
      // .add(ui.Label('8. Select Soil or Vegetation'))
      // .add(planepan)
      .add(button2)
var year1 = select1.getValue()
var year2 = select2.getValue()
// Select your plane of interest
// var planeselection = planepan.getValue()
var ranch = ranchselect.getValue()
//Specify Comparison Ranch or no
var comparison = compcheck.getValue()
var compselecter = compselect.getValue()
//If no comparison ranch is available, specify User Defined ROI or Buffer ("Yes" if buffer, "No" if ROI) and set buffer distance (m)
var roibuff = buffercheck.getValue()
var buffdist = buffdistslide.getValue()
//If you want to compare a Region of Interest from within the boundary of the Study Area to the study area as a whole, indicate that here:
var roiinternal = "No"
// Below are the available Geometries for testing:
var bx = ee.FeatureCollection('ft:1Ilq_JIz4uboxSrlxLZsbIdZA1nMPl2lgo4QUR4_P')//Bar Cross WY
var wc = ee.FeatureCollection('ft:1DiZC-_H5AX2Durr28Wy5lC56Id60yX8HLRrtVEcJ')//Willow Crek WY
var ucross = ee.FeatureCollection('ft:1v8kQnZT2D8v6-0QTh8-ocdoic8f6UHhnRxwzh4_3');
var ucrossmult = ee.FeatureCollection('ft:1BwFN4C8T-_20F_A-f-YSV2FWgdINXvuoddZt-ckx');
var noland = ee.FeatureCollection('ft:1gBBYYLpqgyk_jZ6NbNCx8Vfvb7WMFwOmVMT5AmmG') //Noland Pasture Area
var currant = ee.FeatureCollection('ft:1xPGC1hYnPGdX_CcHX-iwIcO7pVIhRvR4juOE5tEk');
var boot = ee.FeatureCollection('ft:1k5owxXBPmQWhz3WXShFZPmn8mvNYImbw8uw_T1X1');// // Boot Ranch Upper Place
var inhold = ee.FeatureCollection('ft:1Nri3DwIgDaEXfvZ_W1L29FIIoPYTlIvLoD7_zQ4d');
var tnc_deeded = ee.FeatureCollection('ft:123yY1lHutT-P4k2K0QkXWzTyVP6MagUNo39Iuho2');
var tensleep = tnc_deeded.filterMetadata('name','equals','Tensleep Preserve');
var heart = tnc_deeded.filterMetadata('name','equals','Heart Mountain Ranch');
var redcanyon = tnc_deeded.filterMetadata('name','equals','Red Canyon Ranch');
var sweet = tnc_deeded.filterMetadata('name','equals','Sweetwater Preserve');
var forksWY =  ee.FeatureCollection('ft:1bNfYmaepL2MVqdGHyEe2xXVYBrDUUj7nWZW2NXi4')
var dx = ee.FeatureCollection('ft:1S3c_esohBjSQuI6gfbu2QsUimg0c1sNevfKOcGne')
if (ranchselect.getValue() == 'Diamond Cross - All') {
      var ranchoutline = dx}
    else if (ranchselect.getValue() == 'Diamond Cross - River Unit Grazing Cell') {
      var ranchoutline = dx.filterMetadata('name','equals','River Unit Grazing Cell')}
    else if (ranchselect.getValue() == 'Diamond Cross - Hanging Woman Grazing Cell') {
      var ranchoutline = dx.filterMetadata('name','equals','Hanging Woman Grazing Cell')}
    else if (ranchselect.getValue() == 'Diamond Cross - Double Circle Grazing Unit') {
      var ranchoutline = dx.filterMetadata('name','equals','Double Circle Grazing Unit')}      
var ranchoutline2 = ranchoutline
var ranchoutline = ranchoutline.geometry()
if (ranchselect.getValue() == "Select a Willow Creek Pasture") {
  var ranchoutline = wc.filterMetadata
                        ('PastureNam','equals',pastureselect.getValue())
                        .geometry() 
  var ranch = pastureselect.getValue()
}
var comp = "Testinger"
if (compselect.getValue() == "Diamond Cross - All"){
      var comp = dx.geometry()}
    else if (compselect.getValue() == "Diamond Cross - River Unit Grazing Cell"){
      var comp = dx.filterMetadata('name','equals','River Unit Grazing Cell').geometry()}
    else if (compselect.getValue() == "Diamond Cross - Hanging Woman Grazing Cell"){
      var comp = dx.filterMetadata('name','equals','Hanging Woman Grazing Cell').geometry()}
    else if (compselect.getValue() == "Diamond Cross - Double Circle Grazing Unit"){
      var comp = dx.filterMetadata('name','equals','Double Circle Grazing Unit').geometry()}
if (compselect.getValue() == "Select a Willow Creek Pasture") {
  var comp = wc.filterMetadata
                        ('PastureNam','equals',pasturecompselect.getValue())
                        .geometry() 
  var compselecter = pasturecompselect.getValue()
}
// print(ranchoutline,'post assignment')
if (comparison=="Yes"){
  var ranchoutline1 = ranchoutline
  var ranchoutline = ee.FeatureCollection([ranchoutline,comp]).geometry();
  // print("test",ranchoutline)
}
  else if (roibuff=="Yes"){var ranchoutline1 = ranchoutline
          var ranchoutline = ranchoutline1.buffer(buffdist)
          }
  else{var ranchoutline = ranchoutline}
//Run NDVI Functionality in here{
var collrad = ee.ImageCollection("users/charlieyale/WY_MT/wymt_radimage");
var collist = collrad.toList(40)
var lister2 = []
for  (var i = 0; i < 32 ; i++) {
var yearly = i + 1986
var imagern1 = ee.Image(collist.get(i))
if (yearly<2014) {var imagern2 = imagern1.expression('(b("B4")-b("B3"))/(b("B4")+b("B3"))').select(['B4'],['NDVI'])}
  else {var imagern2 = imagern1.expression('(b("B5")-b("B4"))/(b("B5")+b("B4"))').select(['B5'],['NDVI'])}
var imagern = imagern2.set('Year',yearly)
lister2.push(imagern)
}
print(lister2,'lister2')
var fwdFilter = ee.Filter.greaterThan({
    leftField: 'Year',
    rightField: 'Year'
});
var joinvar = ee.Join.saveFirst({
    matchKey: 'PrecedingImage',
    ordering: 'Year',
    ascending: false
});
// Final function call to create the output variable
var prepcoll = ee.ImageCollection(joinvar.apply(lister2,lister2,fwdFilter));
print(prepcoll,'prepcoll')
var changelist = []
var lister3 = []
var ndvichange = function (imgcoll){
var inner = function(img) {  
    var precer = ee.Image(img.get('PrecedingImage'))
    var change = img.subtract(precer)
    return change
    }
var changecollist = imgcoll.map(inner).toList(40)
for  (var i = 0; i < 31 ; i++) {
    var yearl1 = i + 1987
    var imagern = ee.Image(changecollist.get(i)).set('Year',yearly)
    lister3.push(imagern)
    }
return lister3
}
var ndvichangecoll = ee.ImageCollection(ndvichange(prepcoll))
//}
        // Print all outputs and add images to the map
var clipper = function (img) {return img.clip(ranchoutline)}
var tkcva2 = ndvichangecoll.map(clipper)
// if (maskpan.getValue() == true) {var masker = function (img) {return img.mask(tkmask).clip(ranchoutline)}
//   var tkcva2 = tkcva2.map(masker)}
var tkcvalist = tkcva2.toList(40)
// print(tkcvalist)
var tkcvafinal = ee.ImageCollection(tkcvalist.slice(year1-1986,year2-1986))
// print(tkcvafinal)
var scriptfinal = tkcvafinal.sum()
var scriptmean = tkcvafinal.mean()
var meandiff = function (img) {
var differ = img.subtract(scriptmean).multiply(img.subtract(scriptmean))  
return differ}
var tkcvafinalsetter = tkcvafinal.map(meandiff)
var yeargap = ee.Number(year2-year1)
var scriptsd = tkcvafinalsetter.sum().divide(yeargap).sqrt()
// var scriptsd = tkcvafinal.mean()
var meanprop = function (img) {
  var meanchangerz = img.reduceRegion({reducer:ee.Reducer.mean(),geometry:ranchoutline,scale:30,maxPixels:1605610600})
  var meanchangerz2 = ee.Number(meanchangerz.get(ee.List(meanchangerz.keys()).get(0)))
  return img.set({'MeanChangePerPixel': meanchangerz2})}
var tkcvafinal = tkcvafinal.map(meanprop)
// print(scriptsd)
var finalval = ee.Number(scriptfinal.reduceRegion({reducer:ee.Reducer.mean(),geometry:ranchoutline,scale:30,maxPixels:1605610600})
                .get("NDVI")).multiply(1000).round().divide(1000).getInfo()
var y1ndvi = ee.ImageCollection(lister2).filterMetadata('Year','equals',year1).mean()
var y2ndvi = ee.ImageCollection(lister2).filterMetadata('Year','equals',year2).mean()
var compndviy1 = ee.Number(y1ndvi.reduceRegion({'reducer':ee.Reducer.mean(),'geometry':ranchoutline,'scale':30,'maxPixels':1e13})
                              .get('NDVI')).multiply(1000).round().divide(1000).getInfo()
var compndviy2 = ee.Number(y2ndvi.reduceRegion({'reducer':ee.Reducer.mean(),'geometry':ranchoutline,'scale':30,'maxPixels':1e13})
                              .get('NDVI')).multiply(1000).round().divide(1000).getInfo()
var fval = ui.Label("Change in NDVI Across Study Area: " + finalval)
var y1val = ui.Label("Mean NDVI in year " + year1 + ': ' + compndviy1)
var y2val = ui.Label("Mean NDVI in year " + year2 + ': ' + compndviy2)
panel3.add(ui.Label({value:"Statistical Outputs: "+year1+" vs. "+year2,
                    style: {fontSize: '18px', fontWeight: 'bold',textAlign:'center'}}))
        Map.centerObject(ranchoutline,11)
        Map.addLayer(y1ndvi.clip(ranchoutline),ndviviz,"Year "+year1+" NDVI Values (<0.2 is bare ground)",false)
        Map.addLayer(y2ndvi.clip(ranchoutline),ndviviz,"Year "+year2+" NDVI Values (<0.2 is bare ground)",false)
        Map.addLayer(scriptfinal, maindisplayoptions, "Change in NDVI "+year1+" to " +year2);
        Map.addLayer(scriptsd, varviz, "Variance in NDVI change "+year1+" to " +year2,false);
// var exportimagefun = function (img) {
// Export.image.toDrive({image:img,
//                       description:ranch+"_CVA_"+year1+" to " +year2,
//                       scale:30,
//                       region:ranchoutline,
//                       maxPixels:1e13})
// }
  var exportimagefun = function () {
              var urltableget = scriptfinal.getDownloadURL({
                      region: JSON.stringify(ranchoutline.bounds().getInfo()), 
                      name: 'CVA_Image', 
                      crs: 'EPSG:4326', 
                      scale: 30 })
              var printout = ui.Label('IMAGE DOWNLOAD LINK: '+urltableget)
              panel4.add(printout)
              }
var exportimage = ui.Button({
  label:"Export Final Image",
  onClick:exportimagefun})
  // panel2.add(exportimage)
if (comparison=="No" && roibuff=="No" && roiinternal=="No" && ranchselect.getValue() != "Select a Willow Creek Pasture") {
        panel3.add(fval).add(y1val).add(y2val)
  //Pasture Means and Legend{
  var finalregions = scriptfinal.reduceRegions({reducer:ee.Reducer.mean(),
                                                collection:ranchoutline2
                                                ,scale:30})
  var regionsimg = finalregions.reduceToImage(['mean'],'mean').rename(['NDVI'])
  var finalregionsbound = ee.Image().toByte().paint(ranchoutline2, 1, 1); 
  // Map.addLayer(regionsimg,maindisplayoptions,"Pasture Means",false)
  Map.addLayer(finalregionsbound,{palette:'0000FF'},"Pasture Boundaries",false)
  // var exportertablefun = function (collection) {
  //   Export.table.toDrive({collection:collection,
  //                               description:ranch+"_Mean_Change_Values_"+year1+" to " +year2})
  //                             }
  var exportertablefun = function () {
              var urltableget = finalregions.getDownloadURL()
              var printout = ui.Label('CSV DOWNLOAD LINK: '+urltableget)
              panel4.add(printout)
              }
  var exporttable = ui.Button({
  label:"Export Table of Mean Values",
  onClick:exportertablefun})
  // panel2.add(exporttable)
  //}
  };
///////////////////////////////If Else Statements for Output Calculation///////////////////////////////////{
//Extract mean values from comparison property and compare to study area
if (comparison=="Yes") {
var compranchextract = ee.Number(scriptfinal.reduceRegion({'reducer':ee.Reducer.mean(),'geometry':comp,'scale':30,'maxPixels':100000000}).get('NDVI'))
var cre = compranchextract.multiply(1000).round().divide(1000).getInfo()
var compfull = ee.Number(scriptfinal.reduceRegion({'reducer':ee.Reducer.mean(),'geometry':ranchoutline1,'scale':30,'maxPixels':100000000}).get("NDVI"))
var crf = compfull.multiply(1000).round().divide(1000).getInfo()
var compall = ee.Number(scriptfinal.reduceRegion({reducer:ee.Reducer.mean(),geometry:ranchoutline,scale:30,maxPixels:1605610600}).get("NDVI"))//.add(1).divide(2)
var crp = compfull
      .subtract(compranchextract)
      .divide(compfull.add(compranchextract).divide(2).abs())
      .multiply(1000)
      .round()
      .divide(10)
      .getInfo()
var y1ndvi = ee.ImageCollection(lister2).filterMetadata('Year','equals',year1).mean()
var y2ndvi = ee.ImageCollection(lister2).filterMetadata('Year','equals',year2).mean()
var compranchndviy1 = ee.Number(y1ndvi.reduceRegion({'reducer':ee.Reducer.mean(),'geometry':ranchoutline1,'scale':30,'maxPixels':1e13})
                              .get('NDVI')).multiply(1000).round().divide(1000).getInfo()
var compranchndviy2 = ee.Number(y2ndvi.reduceRegion({'reducer':ee.Reducer.mean(),'geometry':ranchoutline1,'scale':30,'maxPixels':1e13})
                              .get('NDVI')).multiply(1000).round().divide(1000).getInfo()
var y1ranchval = ui.Label("Mean NDVI in year " + year1 + ': ' + compndviy1)
var y2ranchval = ui.Label("Mean NDVI in year " + year2 + ': ' + compndviy2)
var y1ndvi = ee.ImageCollection(lister2).filterMetadata('Year','equals',year1).mean()
var y2ndvi = ee.ImageCollection(lister2).filterMetadata('Year','equals',year2).mean()
var comperndviy1 = ee.Number(y1ndvi.reduceRegion({'reducer':ee.Reducer.mean(),'geometry':comp,'scale':30,'maxPixels':1e13})
                              .get('NDVI')).multiply(1000).round().divide(1000).getInfo()
var comperndviy2 = ee.Number(y2ndvi.reduceRegion({'reducer':ee.Reducer.mean(),'geometry':comp,'scale':30,'maxPixels':1e13})
                              .get('NDVI')).multiply(1000).round().divide(1000).getInfo()
var y1compval = ui.Label('Mean NDVI on '+ranch+' in year ' + year1 + ': ' + compranchndviy1)
var y2compval = ui.Label('Mean NDVI on '+ranch+' in year ' + year2 + ': ' + compranchndviy2)
var y1comperval = ui.Label('Mean NDVI on '+compselecter+' in year ' + year1 + ': ' + comperndviy1)
var y2comperval = ui.Label('Mean NDVI on '+compselecter+' in year ' + year2 + ': ' + comperndviy2)
var comppan = ui.Panel([
  ui.Label("Change in NDVI Across "+ranch+" and "+compselecter+": " + finalval),
  ui.Label('Change in NDVI on '+ranch+': '+crf),
  ui.Label('Change in NDVI on '+compselecter+': '+cre),
  ui.Label('Percent Difference - '+ranch+' vs. '+compselecter+': '+crp+'%'),
  y1compval,
  y2compval,
  y1comperval,
  y2comperval
])
panel3.add(comppan)
  var compoutline = ee.Image().toByte().paint(comp, 3, 5)
  var origoutline = ee.Image().toByte().paint(ranchoutline1, 3, 5); 
  Map.addLayer(origoutline,{palette:'0000FF'},"Study Ranch - "+ranch,false)
  Map.addLayer(compoutline,{palette:'FF0000'},"Comparison Ranch - "+compselecter,false)
}
else {
//Extract values from ROI
if (roibuff=="Yes") {
  var roiextract = ee.Number(scriptfinal.reduceRegion({reducer:ee.Reducer.mean(),geometry:ranchoutline1,scale:30,maxPixels:160561060}).get('NDVI'))
  var roifull = ee.Number(scriptfinal.reduceRegion({reducer:ee.Reducer.mean(),geometry:ranchoutline,scale:30,maxPixels:160561060}).get("NDVI"))
  var roibuffer = ee.Number(scriptfinal.reduceRegion({reducer:ee.Reducer.mean(),geometry:ranchoutline.difference(ranchoutline1),scale:30,maxPixels:160561060}).get("NDVI"))
  var percvalue = roiextract
      .subtract(roibuffer)
      .divide(roibuffer.add(roiextract).divide(2).abs())
      .multiply(1000)
      .round()
      .divide(10)
      .getInfo()
var buffex = roiextract.multiply(1000).round().divide(1000).getInfo()
var buffall = roibuffer.multiply(1000).round().divide(1000).getInfo()
      // print(percvalue,"Percent Difference: mean change in buffer vs.","mean change in study area")
      // print("If "+buffdist+" meter Buffer has greater mean positive", "change than study area, this number will be NEGATIVE")
      Map.addLayer(ee.Image().toByte().paint(ranchoutline1, 3, 2),{palette:'0000FF'},"Ranch Boundaries Non-Buff",true)
var bufftext = "Percent Difference - "+ranch+" vs. buffer: "+percvalue+'%'
var buffpan = ui.Panel([
  ui.Label("Change in NDVI "+ranch+": " + buffex),
  ui.Label("Change in NDVI Buffered Area: " + buffall),
  ui.Label(bufftext)])
panel3.add(buffpan)  
}
else {
  if (roiinternal=="Yes") {
  var roi = RegionOfInterest
  var roiextract = ee.Number(scriptfinal.reduceRegion({reducer:ee.Reducer.mean(),geometry:roi,scale:30,maxPixels:1605610600}).get('NDVI'))
  // print(roiextract)
  var roifull = ee.Number(scriptfinal.reduceRegion({reducer:ee.Reducer.mean(),geometry:ranchoutline,scale:30,maxPixels:1605610600}).get("NDVI"))
  var roiperc = roiextract.subtract(roifull).divide(roifull.abs()).multiply(1000).round().divide(10).getInfo()
  var roisa = roifull.getInfo()
  var roifu = roiextract.getInfo()
var roipan = ui.Panel([
  ui.Label("Percent Difference - If ROI has greater mean positive change than study area, this number will be positive: "+roiperc),
  ui.Label("Mean ROI Value: " + roifu),
  ui.Label("Mean Study Area Value: " + roisa)
])
panel3.add(roipan)
Map.addLayer(ee.Image().toByte().paint(roi, 3, 2),{palette:'FFFF00'},"ROI Boundaries",false)
  }}}
//}
// Charting Function { Store the average change per year (across all years) as an array variable
        if (chartbutton.getValue() == true) {
        var changeperyear = ee.Array(tkcvafinal.aggregate_array('MeanChangePerPixel'))
            .repeat(1, 1);
        // print("Change per year", changeperyear);
        // Create an array of the analyzed years
        var yeararray = ee.Array(ee.List.sequence(ee.Number(year1).add(1), ee.Number(year2)))
            .repeat(1, 1);
        // print("Year Array",yeararray);
        // Store the first and last years being analyzed as a variable
        var yeararrayreduced = yeararray.reduce(ee.Reducer.minMax(), [0], 1);
        // print("X-Axis Year Range", yeararrayreduced);
        // Use the first and last years being analyzed to create the upper and lower
        // bounds for the chart's x-axis
        var yearlowerbound = yeararrayreduced.get([0, 0])
            .subtract(2)
            .getInfo();
        // print("X-Axis Year Range Lower Bound", yearlowerbound);
        var yearupperbound = yeararrayreduced.get([0, 1])
            .add(2)
            .getInfo();
        // print("X-Axis Year Range Upper Bound", yearupperbound);
        // Find the cumulative change values across the entire year range of interest
        var cumulativechange = changeperyear.accum(0);
if (roibuff == "Yes") {
        var clipperbuff = function (img) {
                  var meanreduce = img.reduceRegion({reducer:ee.Reducer.mean(),geometry:ranchoutline.difference(ranchoutline1),scale:30,maxPixels:1605610600})
                  var meanchange = ee.Number(meanreduce.get(ee.List(meanreduce.keys()).get(0)))
                    return img.clip(ranchoutline.difference(ranchoutline1))
                              .set({'MeanChangePerPixel': meanchange})}   
        var tkcvafinalbuff = tkcvafinal.map(clipperbuff)
        var clipperstudy = function (img) {
                  var meanreduce2 = img.reduceRegion({reducer:ee.Reducer.mean(),geometry:ranchoutline1,scale:30,maxPixels:1605610600})
                  var meanchange2 = ee.Number(meanreduce2.get(ee.List(meanreduce2.keys()).get(0)))
                    return img.clip(ranchoutline1)
                              .set({'MeanChangePerPixel': meanchange2})} 
        var tkcvafinalstudy = tkcvafinal.map(clipperstudy)
        var changeperyearbuff = ee.Array(tkcvafinalbuff.aggregate_array('MeanChangePerPixel'))
            .repeat(1, 1);
        var cumulativechangebuff = changeperyearbuff.accum(0);  
        var changeperyearstudy = ee.Array(tkcvafinalstudy.aggregate_array('MeanChangePerPixel'))
            .repeat(1, 1);
        var cumulativechangestudy = changeperyearstudy.accum(0);  
  var arraystoinclude = ee.Array.cat([cumulativechangestudy, cumulativechangebuff], 1);
      // var arraystoinclude = ee.Array.cat([changeperyearstudy, changeperyearbuff], 1);
  var chartcum = ui.Chart.array.values(arraystoinclude, 0, yeararray)
            .setSeriesNames([ranch,'Buffer Area'])
            .setOptions({
                // title: 'Study (blue) vs. Buffer (red)',
                hAxis: {'title': 'Year','format': '####',
                viewWindow: {'max': yearupperbound,
                        'min': yearlowerbound}},
                vAxis: {'title': 'Change Value'},
                pointSize: 4,
                trendlines: {0: {type: 'linear',
                            showR2: true,
                            visibleInLegend: true},
                            1: {type: 'linear',
                            showR2: true,
                            visibleInLegend: true}
                            }})}
    else if (comparison=="Yes") {
        var clippercomp = function (img) {
                  var meanreduce = img.reduceRegion({reducer:ee.Reducer.mean(),geometry:comp,scale:30,maxPixels:1605610600})
                  var meanchange = ee.Number(meanreduce.get(ee.List(meanreduce.keys()).get(0)))
                    return img.clip(comp)
                              .set({'MeanChangePerPixel': meanchange})}   
        var tkcvafinalcomp = tkcvafinal.map(clippercomp)
        var clipperstudy = function (img) {
                  var meanreduce2 = img.reduceRegion({reducer:ee.Reducer.mean(),geometry:ranchoutline,scale:30,maxPixels:1605610600})
                  var meanchange2 = ee.Number(meanreduce2.get(ee.List(meanreduce2.keys()).get(0)))
                    return img.clip(ranchoutline)
                              .set({'MeanChangePerPixel': meanchange2})} 
        var tkcvafinalstudy = tkcvafinal.map(clipperstudy)
        var changeperyearcomp = ee.Array(tkcvafinalcomp.aggregate_array('MeanChangePerPixel'))
            .repeat(1, 1);
        var cumulativechangecomp = changeperyearcomp.accum(0);  
        var changeperyearstudy = ee.Array(tkcvafinalstudy.aggregate_array('MeanChangePerPixel'))
            .repeat(1, 1);
        var cumulativechangestudy = changeperyearstudy.accum(0);  
  var arraystoinclude = ee.Array.cat([cumulativechangestudy, cumulativechangecomp], 1);
    // var arraystoinclude = ee.Array.cat([changeperyearstudy, changeperyearcomp], 1);
  var chartcum = ui.Chart.array.values(arraystoinclude, 0, yeararray)
            .setSeriesNames([ranch,compselecter])
            .setOptions({
                title: 'Study (blue) vs. Comparison (red)',
                hAxis: {'title': 'Year','format': '####',
                viewWindow: {'max': yearupperbound,
                        'min': yearlowerbound}},
                vAxis: {'title': 'Change Value'},
                pointSize: 4,
                trendlines: {0: {type: 'linear',
                            showR2: true,
                            visibleInLegend: false},
                            1: {type: 'linear',
                            showR2: true,
                            visibleInLegend: false}
                            }})}
            else {
                  var chartcum = ui.Chart.array.values(cumulativechange, 0, yeararray)
                      .setSeriesNames(['Cumulative Change Value'])
                      .setOptions({
                          title: 'Cumulative Change Values',
                          hAxis: {'title': 'Year','format': '####',
                          viewWindow: {'max': yearupperbound,
                                  'min': yearlowerbound}},
                          vAxis: {'title': 'Change Value'},
                          pointSize: 4,
                          trendlines: {0: {type: 'linear',
                                  showR2: true,
                                  visibleInLegend: true}}})}
panel3.add(chartcum);
}
///////////Precip Charting//{
///////////
if (precipchartbutton.getValue() == true) {
var preciplist = [];
for (var i = year1; i <= year2; i++) {
    // var spring = i+growingseasonstart
    // var fall = i+growingseasonend
    var spring = i+'-01-01'
    var fall = i+'-12-31'
    var precip = ee.Number(daymet.filterDate(spring,fall).filterBounds(ranchoutline).select('prcp').sum().reduceRegion(ee.Reducer.mean(),ranchoutline,1000).get('prcp')).divide(25.4)
    preciplist.push(precip);
}
var preciplistarray = ee.Array(preciplist)
var yeararray = ee.Array(ee.List.sequence(year1, ee.Number(year2)
                // .add(1)
                ))
            .repeat(1, 1)
var precipcharter = ui.Chart.array.values(preciplistarray,0,yeararray)
            .setSeriesNames(['Precipitation (in)'])
            .setOptions({
                title: 'Mean Annual Precipitation Over Study Area',
                hAxis: {
                    'title': 'Year',
                    'format': '####',
                    viewWindow: {
                        'max': year1-1,
                        'min': year2+1
                    }
                },
                vAxis: {
                    'title': 'Precipitation (in)'
                },
                pointSize: 4
                }
            )
panel3.add(precipcharter)
}
//}
var minusfun = function () {panel3.clear()}
                            // panel3.remove(chartcum)
                            // panel3.remove(precipcharter)}
var removebutt = ui.Button({label:"Hide Chart(s)",onClick:minusfun})
panel3.add(removebutt)
var rancher = ee.Geometry.MultiPolygon([])
//}            
};
//UI Panel Stuff{
var title = ui.Label({
    value:"Rangeland Change Detection",
    style: {fontSize: '20px', fontWeight: 'bold'}
  });
var desc = ui.Label({value:"This tool detects changes in rangeland productivity over time using time-series analysis of Landsat Data stretching back to the 1980's"});
var title2 = ui.Label({
    value:"Select CVA Analytics",
    style: {fontSize: '18px', fontWeight: 'bold'}
  });
var title3 = ui.Label({
    value:"Statistical Outputs",
    style: {fontSize: '18px', fontWeight: 'bold',textAlign:'center'}
  });
// Specify two years of comparison between 2002 and 2015 (year1 should be lower of the two years)
var addval1 = function (year){
var yr1 = year
return yr1
};
var addval2 = function (year){
var yr2 = year
return yr2
};
var ftinput = ui.Textbox({//value:'1dyKEZ5ccAQ0gLHRsIrUPOOblAqKv2EfQ-JG0dNao',
                          placeholder:'Input Fusion Table ID',
                          onChange: function (fusion) {
                            var layerz = ee.FeatureCollection('ft:'+fusion);
                            Map.centerObject(layerz,10);
                            Map.addLayer(layerz);
                          }});
var bufferbuttlab = ui.Label("Set buffer distance from point");
var bufferbutt = ui.Slider({min:100,max:10000,value:1000,step:100});
var select1 = ui.Slider({
  min:1986,
  max:2016,
  value:2001,
  step:1,
onChange: addval1
});
var label1 = ui.Label('2. Select Year 1 for CVA (1985-2015')
var select2 = ui.Slider({
  min:1987,
  max:2017,
  value:2017,
  step:1,
  onChange: addval2
});
var label2 = ui.Label('3. Select Year 2 for CVA (1986-2016')
var ranchselect = ui.Select({
  items:['Diamond Cross - All',
'Diamond Cross - River Unit Grazing Cell',
'Diamond Cross - Hanging Woman Grazing Cell',
'Diamond Cross - Double Circle Grazing Unit',
        'User Defined'],
  placeholder:'Choose a Ranch to Analyze',
  value:'Diamond Cross - All',
  onChange: function (ranch){return ranch}
});
var pastureselect = ui.Select({
  items:["BLM",
"Coates - 1",
"Coates 2",
"Coates 3",
"Dumpy",
"East Pape Place",
"Forest",
"Horse",
"House",
"Lower State",
"Middle Pape Place",
"Noble",
"North Field",
"Pond",
"Rocky Ridge",
"Scale",
"Seedings",
"Smith",
"South Field",
"State",
"Upper Willow Patch",
"West Pape Place",
"West Rocky Ridge"],
  placeholder:'Choose a Pasture to Analyze',
  value:'Horse',
  onChange: function (ranch){return ranch}
});
var button1 = ui.Button({label:'Click to Run CVA',
                          onClick: uifunction});
var button2 = ui.Button({label:'Click to Run CVA',
                          onClick: uifunction})
var buffercheck = ui.Select({
  items:['Yes','No'],
  placeholder:'No',
  value:'No'
});
var buffdistslide = ui.Slider({
  min:500,
  max:10000,
  value:2000,
  step:500
});
var compcheck = ui.Select({
  items:['Yes','No'],
  placeholder:'No',
  value:'No'
});
var compselect = ui.Select({
  items:['Willow Creek','Diamond Cross - All',
'Diamond Cross - River Unit Grazing Cell',
'Diamond Cross - Hanging Woman Grazing Cell',
'Diamond Cross - Double Circle Grazing Unit'],
  placeholder:'Choose a Ranch to Analyze',
  value:'Diamond Cross - All',
  onChange: function (ranch){return ranch}
});
var pasturecompselect = ui.Select({
  items:["BLM",
"Coates - 1",
"Coates 2",
"Coates 3",
"Dumpy",
"East Pape Place",
"Forest",
"Horse",
"House",
"Lower State",
"Middle Pape Place",
"Noble",
"North Field",
"Pond",
"Rocky Ridge",
"Scale",
"Seedings",
"Smith",
"South Field",
"State",
"Upper Willow Patch",
"West Pape Place",
"West Rocky Ridge"],
  placeholder:'Choose a Pasture to Compare',
  value:'Horse',
  onChange: function (ranch){return ranch}
});
var maskpan = ui.Checkbox({label:'4. Mask out Developed Areas and Forests',value:false})
var planepan = ui.Select({
  items:['Soils','Vegetation','Hybrid'],
  value:'Hybrid'
})
var chartbutton = ui.Checkbox({label:'Display Chart?',
                          value:true})
var precipchartbutton = ui.Checkbox({label:'Display Precip Chart?',
                          value:false})                          
var exporttable = ui.Button()
var exportimage = ui.Button()
panel1.add(title)
      .add(desc)
      .add(ui.Label('1. Select Ranch to Analyze'))
      .add(ranchselect)
      // .add(ui.Label('1a. Select Pasture to Analyze'))
      // .add(pastureselect)
      // .add(ftinput)
      // .add(bufferbuttlab)
      // .add(bufferbutt)
      //////Drawing User Defined Areas:{
var rancher = ee.Geometry.MultiPolygon([])
// print(rancher,'clear poly')
var app = function() {
var tool = new DrawAreaTool(Map)
  // subscribe to selection
  tool.onFinished(function(area) {
    checkbox.setValue(false, false)
    // print(area.getInfo())
  // uifunctionuser(area)
  print(rancher,'rancher0')
  // var rancher = rancher.union(area)
  // print(rancher,'rancher1')
  uifunction(area)
  })
  // add checkbox to activate selector when checkbox is clicked
  var checkbox = ui.Checkbox({label: 'DRAW AREA (only check if using -User-Defined- option above, script will run immediately upon completion of drawing polygon', style: {position: 'top-center'}});
  checkbox.onChange(function(checked) {
    if(checked) {
      tool.startDrawing()
    } else {
      tool.stopDrawing()
    }
  })
panel1.add(checkbox)  
};
var DrawAreaTool = function(map) {
  this.map = map
  this.layer = ui.Map.Layer({name: 'area selection tool', visParams: { color:'yellow' }})
  this.selection = null
  this.active = false
  this.points = []
  this.area = null
  this.listeners = []
  var tool = this;
  this.initialize = function() {
    this.map.onClick(this.onMouseClick)
    this.map.layers().add(this.layer)
  }
  this.startDrawing = function() {
    this.active = true
    this.points = []
    this.map.style().set('cursor', 'crosshair');
    this.layer.setShown(true)
  }
  this.stopDrawing = function() {
    tool.active = false
    tool.map.style().set('cursor', 'hand');
    if(tool.points.length < 2) {
      return
    }
    tool.area = ee.Geometry.Polygon(tool.points)
    rancher = rancher.union(tool.area)//Charlie added this in here. Fingers crossed!!!
    print(rancher,'post drawing')
    tool.layer.setEeObject(tool.area)
    tool.listeners.map(function(listener) {
      listener(tool.area)
    })
  }
  /***
  * Mouse click event handler
  */
  this.onMouseClick = function(coords) {
    if(!tool.active) {
      return
    }
    tool.points.push([coords.lon, coords.lat])
    var geom = tool.points.length > 1 ? ee.Geometry.LineString(tool.points) : ee.Geometry.Point(tool.points[0])
    tool.layer.setEeObject(geom)
    var l = ee.Geometry.LineString([tool.points[0], tool.points[tool.points.length-1]]).length(1).getInfo()
    if(tool.points.length > 1 && l / Map.getScale() < 5) {
      tool.stopDrawing()
    }
  }
  /***
  * Adds a new event handler, fired on feature selection. 
  */
  this.onFinished = function(listener) {
    tool.listeners.push(listener)
  }
  this.initialize()
}
app()
//////}
panel1.add(label1)
      .add(select1)
      .add(label2)
      .add(select2)
      // .add(maskpan)
      .add(chartbutton)
      .add(precipchartbutton)
      .add(button1)
panel2.add(title2)
      .add(ui.Label('4. Run CVA for buffer around Study Area?'))
      .add(buffercheck)
      .add(ui.Label('5. Select buffer distance (meters)'))
      .add(buffdistslide)
      .add(ui.Label('6. Run CVA for Study Area vs. Comparison Ranch?'))
      .add(compcheck)
      .add(ui.Label('7. Select Comparison Ranch'))
      .add(compselect)      
      // .add(ui.Label('7a. Select Comparison Pasture'))
      // .add(pasturecompselect)
      // .add(ui.Label('8. Select Soil or Vegetation'))
      // .add(planepan)
      .add(button2)
      // .add(exporttable)
      // .add(exportimage)
// panel3.add(title3)
Map.setCenter(-106.7186, 45.1767,10)
  // Create the panel for the legend items.
var legend = ui.Panel({
  style: {
    position: 'top-left',
    padding: '8px 15px'
  }
});
// Create and add the legend title.
var legendTitle = ui.Label({
  value: 'Map Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '12px',
    margin: '0 0 4px 0',
    padding: '0'
  }
});
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0 0 4px 0',
    }
  });
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px',fontSize:'10px'}
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal'),
  });
};
function pad(n, width, z) {
  z = z || '0';
  n = n + '';
  return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
}
  // add legend items  
var  valueser = ['','Negative Change','\xa0\xa0\xa0\xa0\xa0\xa0\xa0^','No Change','\xa0\xa0\xa0\xa0\xa0\xa0\xa0^','Positive Change']
var  colorzer = ['ffffff',"5d127c",'A98898',"f6ffb4",'A0C672',"4a8d30"]
  for (var i = 0; i < 6; i++) {
    legend.add(makeRow(colorzer[i], valueser[i]));
  }
Map.add(legend);
// Map.onClick(function(coords) {
//   centerZoom(coords.lon, coords.lat);
//   geomer = ee.Geometry.Point(coords.lon, coords.lat).buffer(bufferbutt.getValue());
//   print(geomer)
//   return geomer;
// });  
// var centerZoom = function(lon, lat) {
//   // Map.setCenter(lon, lat, 13);
//   var geom = ee.Geometry.Point([lon,lat]);
//   var geompainter = ee.Image().toByte().paint(geom.buffer(bufferbutt.getValue()), 1, 1);
//   var layer = ui.Map.Layer(geompainter, {color: 'FF0000'}, 'Center Point');
//   Map.layers().set(1, layer);
// };
//}