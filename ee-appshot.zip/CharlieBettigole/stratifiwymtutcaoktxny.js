var elevation = ee.Image("USGS/NED"),
    geom = /* color: #d63000 */ee.Geometry.Point([-111.60135269165039, 40.71457387021076]),
    soiltaxa = ee.Image("users/CharlieBettigole/TAXOUSDA_250m"),
    l8AnnualBAI = ee.ImageCollection("LANDSAT/LC8_L1T_ANNUAL_BAI"),
    l8AnnualEVI = ee.ImageCollection("LANDSAT/LC8_L1T_ANNUAL_EVI"),
    l8AnnualNBRT = ee.ImageCollection("LANDSAT/LC8_L1T_ANNUAL_NBRT"),
    l8AnnualNDSI = ee.ImageCollection("LANDSAT/LC8_L1T_ANNUAL_NDSI"),
    l8AnnualNDVI = ee.ImageCollection("LANDSAT/LC8_L1T_ANNUAL_NDVI"),
    l8AnnualNDWI = ee.ImageCollection("LANDSAT/LC8_L1T_ANNUAL_NDWI"),
    nlcd = ee.ImageCollection("USGS/NLCD"),
    l8annual = ee.ImageCollection("LANDSAT/LC8_L1T_ANNUAL_GREENEST_TOA"),
    naip = ee.ImageCollection("USDA/NAIP/DOQQ"),
    txgssurgo = ee.Image("users/CharlieBettigole/OK/TX_gssurgo"),
    okgssurgo = ee.Image("users/charlieyale/gssurgo/OK_NoPan"),
    WY_E_gssurgo = ee.Image("users/charlieyale/gssurgo/gssurgo_WY_E"),
    MT_E_gssurgo = ee.Image("users/sabrinaszeto/MT_gssurgoE10m"),
    MT_C_gssurgo = ee.Image("users/sabrinaszeto/MT_gssurgoC10m"),
    cagssurgo_S = ee.Image("users/charlieyale/gssurgo/CA_Co_gssurgo_S"),
    cagssurgo_N = ee.Image("users/charlieyale/gssurgo/CA_Co_gssurgo_N"),
    utgssurgo_N = ee.Image("users/charlieyale/gssurgo/UT_N_gssurgo"),
    utgssurgo_S = ee.Image("users/charlieyale/gssurgo/UT_S_gssurgo"),
    nygssurgo_SE = ee.Image("users/charlieyale/gssurgo/NY_SE_gssurgo"),
    CA_C_E_gssurgo = ee.Image("users/charlieyale/CA_C_E_gssurgo"),
    CA_C_W_gssurgo = ee.Image("users/charlieyale/CA_C_W_gssurgo"),
    CA_N_gssurgo = ee.Image("users/charlieyale/CA_N_gssurgo"),
    CA_S_gssurgo = ee.Image("users/charlieyale/CA_S_gssurgo"),
    TX_NE_gssurgo = ee.Image("users/charlieyale/TX_NE_gssurgo"),
    TX_N_C_gssurgo = ee.Image("users/charlieyale/TX_N_C_gssurgo"),
    TN_gssurgo = ee.Image("users/charlieyale/gssurgo/TN_gssurgo"),
    KS_gssurgo = ee.Image("users/charlieyale/gssurgo/KS_SOC_30m");
//NEED TO SCALE VARIABLES AFTER CLIPPED TO BOUNDARY!
//Stratifi Application: 
//shift+click to close all layers{
//Layers{inpu
var elevation2 = ee.Image("USGS/NED")
var elevation = elevation2.divide(4000)//.multiply(10000)
// var gssurgo = ee.ImageCollection([MT_E_gssurgo,MT_C_gssurgo,WY_E_gssurgo]).mosaic().select('b1')
var gssurgo = ee.ImageCollection([
utgssurgo_N,
utgssurgo_S,
nygssurgo_SE,
CA_C_E_gssurgo,
CA_C_W_gssurgo,
CA_N_gssurgo,
CA_S_gssurgo,
TX_NE_gssurgo,
TX_N_C_gssurgo,
MT_E_gssurgo,
MT_C_gssurgo,
WY_E_gssurgo,
txgssurgo,
okgssurgo,
TN_gssurgo,
KS_gssurgo.divide(1000).int()//reproject({crs:'EPSG:4326',scale:10}).int()
]).mosaic().select('b1').rename('gssurgo');
var soiltaxa = soiltaxa.rename('soiltaxa')
// Calculate elevation products
var allProducts = ee.Terrain.products(elevation2);
var slope = allProducts.select('slope').divide(90)//.multiply(1000);
var aspect = allProducts.select('aspect').divide(360)//.multiply(1000);
// Make a new filter for 2017
var filter2017 = ee.Filter.date(ee.Date.fromYMD(2017,01,01));
// Filter imported ImageCollections, return a Image
var bai = ee.Image(l8AnnualBAI.filter(filter2017).first());
var evi = ee.Image(l8AnnualEVI.filter(filter2017).first());
var nbrt = ee.Image(l8AnnualNBRT.filter(filter2017).first());
var ndsi = ee.Image(l8AnnualNDSI.filter(filter2017).first()).rename('ndsi');
var ndwi = ee.Image(l8AnnualNDWI.filter(filter2017).first()).rename('ndwi');
var img = ee.ImageCollection("LANDSAT/LC8_L1T_ANNUAL_GREENEST_TOA");
var ndvi = ee.Image(img.first()).expression('(b(4)-b(3))/(b(4)+b(3))').rename('ndvi')
var nlcd = ee.Image(nlcd.first()).rename('nlcd')
//}
Map.centerObject(geom,13);
var randlist = []
/////////////The Function////////////////
//Record entrykeeping {
var runstrat = function () {
Map.add(inspector);
  inspector.style().set('shown', true);
  inspector.add(ui.Label('Loading...', {color: 'gray'}));
Map.unlisten(drawOnClick())
if (regselect.getValue() == "User Defined Polygon") {var region = geometry}
if (regselect.getValue() == "Fusion Table") {var region = ee.FeatureCollection('ft:'+ftinput.getValue()).geometry()}
if (regselect.getValue() == "GeoJSON"){
  var textval1 = gjinput.getValue() //Extract value from textbox
  var textval = ee.String(textval1).replace(',0','','g') //Cast to server side
  var split = textval.split('coordinates":','g') //split text at the word 'coordinates:'
  var split1 = split.slice({start:1})//remove the first bit of text before first set of coordinates
//Function to extract coordinate information as String and parse into geometry    
    var mapGeom = split1.map(function (objGeo) {
      var splitter = ee.String(objGeo) //cast to string
      var closedIndex = splitter.rindex(']]]');//search for end of coordinate list
      var tester1 = splitter.slice(0,closedIndex).cat(']]]')//slice coordinate string text and add on brackets
      var tester = tester1.decodeJSON()//convert from string to JSON
    return tester
    })
  var region = ee.Geometry.MultiPolygon(mapGeom)
}
// var region = region.buffer(-50)
var slopenum = ee.Number.parse(slopeFilter.getValue())
var slopemask = allProducts.select('slope').lt(slopenum)
Map.layers().reset();
Map.addLayer(ndvi,vis,"NDVI",false);
Map.addLayer(ndwi,vis,"NDWI",false);
Map.addLayer(ndsi,vis,"NDSI",false);
Map.addLayer(soiltaxa,{opacity:0.5},"Soil Taxa",false);
Map.addLayer(elevation2,{min:0,max:4000,palette:[
  'FFFFFF', 'CE7E45', 'FCD163', '66A000', '207401',
  '056201', '004C00', '023B01', '012E01', '011301'],opacity:0.5},"Elevation",false);
Map.addLayer(slope,{min: 0, max: 90, gamma: 2, opacity:0.5},"Slope",false);
Map.addLayer(aspect,{min: 0, max: 360, gamma: 2, opacity:0.5},"Aspect",false);
Map.addLayer(gssurgo.randomVisualizer(),{opacity:0.5},"Soils - GSSURGO",false)
var lister = [];
if (ndvicheck.getValue() === true) {lister.push(ndvi)}
if (ndwicheck.getValue() === true) {lister.push(ndwi)}
if (ndsicheck.getValue() === true) {lister.push(ndsi)}
if (elevcheck.getValue() === true) {lister.push(elevation)}
if (slopecheck.getValue() === true) {lister.push(slope)}
if (aspectcheck.getValue() === true) {lister.push(aspect)}
if (taxacheck.getValue() === true) {lister.push(soiltaxa)}
if (ssurgocheck.getValue() == true) {lister.push(gssurgo)}
if (nlcdcheck.getValue()=== true) {lister.push(nlcd)}
var inputer = ee.Image(lister[0]).addBands(lister.slice(1))
                .mask(slopemask)
                .clip(region); //Automatically add in bands
var imgMinMax = inputer.reduceRegion({
                geometry:region,
                reducer:ee.Reducer.minMax(),
                scale:30,
                maxPixels:1e13})
//changing this to min/max and doing full stretch from 0 to 1
// var meanImg = inputer.reduceRegion({reducer:ee.Reducer.mean(), geometry:region,scale:30})//.get('elevation');
// var sigmaImg = inputer.reduceRegion({reducer:ee.Reducer.stdDev(), geometry:region,scale:30})//.get('elevation');
var maxImg = inputer.reduceRegion({reducer:ee.Reducer.max(), geometry:region,scale:30})//.get('elevation');
var minImg = inputer.reduceRegion({reducer:ee.Reducer.min(), geometry:region,scale:30})//.get('elevation');
var varList = ee.Dictionary(maxImg).keys()
var keysMap = ee.ImageCollection(varList.map(function(label){
    var max = ee.Image.constant(maxImg.get(label))
    var min = ee.Image.constant(minImg.get(label))
    // return inputer.select([label]).subtract(mean).divide(sigma.multiply(3)).add(0.5)
      return ee.Image(0).expression(
        '((img - min) / (max - min))', {
          'img': inputer.select([label]),
          'max': max,
          'min': min
        })
    })).toBands().rename(varList)
// var keysMap = ee.ImageCollection(varList.map(function(label){
//     var mean = ee.Image.constant(meanImg.get(label))
//     var sigma = ee.Image.constant(sigmaImg.get(label))
//     // return inputer.select([label]).subtract(mean).divide(sigma.multiply(3)).add(0.5)
//       return ee.Image(0).expression(
//         '((img - mean) / (sigma * 3)) + 0.5', {
//           'img': inputer.select([label]),
//           'mean': mean,
//           'sigma': sigma
//         })
//     })).toBands().rename(varList)
//WORKING HERE = NEED TO MERGE ALL NORMALIZED BANDS INTO ONE IMAGE AND THEN PASS THAT TO REST OF ALGORITHM
//make sure to sample either keysMap or inputer
var training = keysMap.sample({
    region: region,
    scale: 30,
    numPixels: 5000
});
  var maxval = maxbins.getValue()
  var clusterers = ee.Clusterer.wekaXMeans(5,maxval);
  var clusterer = clusterers.train(training);
// Map.addLayer(inputer,{},'inputer')
// Map.addLayer(keysMap,{},'keys')
  // var result = inputer.cluster(clusterer);
  var result = keysMap.cluster(clusterer);
  var resultvect = result.reduceToVectors({scale:30,eightConnected:false,maxPixels:1e13})
  resultvect.evaluate(function(){Map.remove(inspector)})
  Map.addLayer(result.randomVisualizer().clip(region),{opacity:0.5},"Similar Classes",true);
  Map.centerObject(result,13)
//}
// Calculate points by acre vs. total points {
var numstot = ee.Number.parse(numpointstext.getValue()) //change this to total points per property
var areavect = resultvect.geometry().area({maxError:10})
var areaacre = areavect.multiply(0.000247105)
var numsacre = areaacre.divide(numstot).round()
if (numpointsopt.getValue() == 'Acres per Sample') {
var nums = numsacre
}
else {var nums = numstot}
print('Total Samples',nums)
print('Total Acres',areaacre)
// print('Acres in Strata 1',resultvect.filterMetadata('label','equals',4).geometry().area({maxError:10}).multiply(0.000247105))
//}
//Create a random list{
var rando = ee.FeatureCollection(region).randomColumn('random',1)
var rando1 = ee.Number(rando.first().get('random')).multiply(10000).round()
randlist.push(rando1)
var rando2 = ee.Number(randlist[-0]).divide(ee.List(randlist).length()).round()
//}
//Randomly sample by strata {
var edgeDist = -20
var numclust = result.reduceRegion(
                  {reducer:ee.Reducer.max(),
                    geometry:region,scale:30}).get('cluster')//.keys()
var clustList = ee.List.sequence({start:0,end:numclust})
//THIS IS ACTUALLY TAKING EACH VECTOR AS ITS OWN THING. NEED TO DISSOLVE INTO HAVING EACH STRATA AS A FEATURE
var samPointFun = ee.FeatureCollection(clustList.map(function(strata){
var cluStrArea = resultvect.filterMetadata('label','equals',strata).geometry()
var clustemp = ee.Number(cluStrArea
                            .area({maxError:10})
                            .divide(areavect)
                            .multiply(nums)
                            .round())
    var sampoints = ee.FeatureCollection.randomPoints({region:cluStrArea.buffer(edgeDist),points:clustemp,seed:rando2}) //Buffer here, not above
    var sampointsmap = sampoints.map(function(feat){return feat.set('strata',strata)})
    return sampointsmap
})).flatten()
Map.addLayer(samPointFun,{color:"white"},"Stratified, equal area samples",false)
// Convert lat long points to geometry object:
var samplePoints = samPointFun.map(function(feat){
  var long = feat.geometry().coordinates().get(0);
  var lat = feat.geometry().coordinates().get(1);
  // var id = ee.Number.parse(point.id()).add(1);  //So that the list of IDs starts with 1, not 0
  return feat.set({'longitude':long,'latitude':lat});
});
//}
//Export functions {
// title.clear() 
// title.add(stratitle)
panel1.clear()
  panel1.add(stratitle)
        .add(ui.Label({value:"Select Input Layers",style:{color:'darkblue',fontWeight:'bold',fontSize:'16px'}}))
        .add(lsFilter)
        .add(soilFilter)
        .add(physFilter)
        .add(slopebigFilter)
        .add(areaFilter)
        .add(goFilter);
 var exportimagefun = function () {
              var urlimgget = result.clip(region).getDownloadURL({
                      // region: JSON.stringify(region.bounds().getInfo()),
                      name: 'Stratifi_Map', 
                      crs: 'EPSG:4326', 
                      scale: 30 })
              var urltableget = samplePoints.getDownloadURL({
                      filename: 'Stratifi_Points',
                      selectors: ['strata','latitude','longitude']
                      })
              // print(urltableget)
              // var printout = ui.Label({value:'IMAGE DOWNLOAD LINK: '+urlimgget,style:({fontSize:'10px'})})
              // var printout2 = ui.Label({value:'POINTS DOWNLOAD LINK: '+urltableget,style:({fontSize:'10px'})})
              // var printimg = 'Image Download Link'
              // var printpoints = 'Points Download Link'
              // var printout = ui.Label(printimg.link(urlimgget))
              // var printout2 = ui.Label(printpoints.link(urltableget))
          var link = ui.Chart(
                        [
                          ['Download Data Here'],
                          ['<a target="_blank" href='+urlimgget+'>' +
                           'Image Download</a>'],
                          ['<a target="_blank" href='+urltableget+'>' +
                           'Points Download</a>']
                        ],
                        'Table', {allowHtml: true});
                    var linkPanel = ui.Panel([link], 'flow', {width: '300px', height: '125px'});
              panel1.add(linkPanel)//.add(printout).add(printout2)
              panel1.remove(exportimage)
              }
Export.table.toDrive({collection:samplePoints,
                      description: 'Stratifi_Points', 
                      fileFormat:'KML'})                      
var exportimage = ui.Button({
  label:"Export Final Image",
  onClick:exportimagefun})
  panel1.add(exportimage)
  // title.add(exportimage)
};
//}
/////Make checkbox functions//{
var variables = [
  'NDVI',
  'NDSI',
  'NDWI',
  'Elevation',
  'Soil Type'
  ];
var descriptions = [
  'Landsat Vegetation Index',
  'Landsat Vegetation Index',
  'Landsat Vegetation Index',
  'National Elevation Dataset - 10m',
  'Soil Grids Soil Type North America - 250m'
  ];
// Creates and styles 1 row of the legend.
var makeCheck = function(variable, description) {
  // Create the label that is actually the colored box.
  var labelz = variable + ' - ' + description;
  return ui.Checkbox({
    label: labelz
  });
};
var makeCheckviz = function(variable, description) {
  // Create the label that is actually the colored box.
  var labelz = variable + ' - ' + description;
  return ui.Checkbox({
    label: labelz
  });
};
//}
/////Add in Panels and Widgets//{
/////Stratifi Panel//{  
// var panel1 = ui.Panel({
//     style: {width: '300px',position: 'bottom-left',fontSize:'10px'}
//   });
var panel1 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {width: '340px',position: 'bottom-left',fontSize:'10px'}
});
var ndvicheck = ui.Checkbox({label:'NDVI - Vegetation Index',value:true});
var ndwicheck = ui.Checkbox('NDWI - Wetness Index');
var ndsicheck = ui.Checkbox('NDSI - Snow Index\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0');
var nlcdcheck = ui.Checkbox('NLCD - Land Cover');
var taxacheck = ui.Checkbox('Soil Taxa - SoilGrids\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0');
var ssurgocheck = ui.Checkbox({label:'Soils - GSSURGO',value:true});
var elevcheck = ui.Checkbox({label:'Elevation\xa0\xa0',value:true});
var slopecheck = ui.Checkbox({label:'Slope\xa0\xa0',value:true});
var aspectcheck = ui.Checkbox('Aspect');
var gobutton = ui.Button({label:'Click Here',
                          onClick: runstrat,
                          style:{fontWeight:'bold',fontSize:'18px'}
                          });
var areatextlab = ui.Label({value:"\xa0\xa0\xa01c. Click below to create custom polygons",style:{fontWeight:'bold',fontSize:'12px'}});
var ftlab = ui.Label({value:"\xa0\xa0\xa01b. Or input Fusion Table ID:\xa0\xa0",style:{fontWeight:'bold',fontSize:'12px'}});
var slopeText = ui.Label({value:"4. Restrict analysis to slopes below:",style:{fontWeight:'bold',fontSize:'12px'}})
var slopeFilter = ui.Textbox({value:'20',placeholder:'Degrees',style:{width:'40px',fontWeight:'bold',fontSize:'12px'}})
var slopeDegree = ui.Label({value:"degrees",style:{fontWeight:'bold',fontSize:'12px'}})
var ftinput = ui.Textbox({value:'1mfKbGHzAczwQJ_KCzpmc6-LQ0dRXDyUsOFa3b6Vb',
                          placeholder:'Paste Here',
                          onChange: function (fusion) {
                            var layerz = ee.FeatureCollection('ft:'+fusion);
                            Map.centerObject(layerz,13);
                            Map.addLayer(layerz);
                          }});
var gjlab = ui.Label({value:"\xa0\xa0\xa01c. Input GeoJSON:\xa0\xa0\xa0\xa0",style:{fontWeight:'bold',fontSize:'12px'}});
var gjinput = ui.Textbox({//value:'1dILd3FXRc4o9PZmyZ9QNg4pkXJwP1rPS4q0ZmCG_',
                          placeholder:'Input GeoJSON',
                          onChange: function (fusion) {
                            var textval1 = fusion //Extract value from textbox
                            var textval = ee.String(textval1).replace(',0','','g') //Cast to server side
                            var split = textval.split('coordinates":','g') //split text at the word 'coordinates:'
                            var split1 = split.slice({start:1})//remove the first bit of text before first set of coordinates
                          //Function to extract coordinate information as String and parse into geometry    
                              var mapGeom = split1.map(function (objGeo) {
                                var splitter = ee.String(objGeo) //cast to string
                                var closedIndex = splitter.rindex(']]]');//search for end of coordinate list
                                var tester1 = splitter.slice(0,closedIndex).cat(']]]')//slice coordinate string text and add on brackets
                                var tester = tester1.decodeJSON()//convert from string to JSON
                              return tester
                              })
                            var layerz = ee.Geometry.MultiPolygon(mapGeom)
                            Map.centerObject(layerz,13);
                            Map.addLayer(layerz);
                          }});    
var ftbutt = ui.Button({label:'Upload Fusion Table',
                          onClick: function () {
                          panel1.add(ftinput);  
                          }
                          });
var numdesc = ui.Label({value:"3. Choose either:\xa0\xa0",style:{fontWeight:'bold',fontSize:'12px'}})
var numpointsopt = ui.Select({items:['Total # Samples','Acres per Sample'],value:'Acres per Sample'})
var numpointstext = ui.Textbox({value:'100',placeholder:'# Samples/Acres',style:{width:'65px',fontWeight:'bold',fontSize:'12px'}})
var maxbinslab = ui.Label({value:"2. Set max # of bins for clustering",style:{fontWeight:'bold',fontSize:'12px'}});
var maxbins = ui.Slider({min:5,max:20,value:20,step:1,style:{fontWeight:'bold',fontSize:'12px'}})
var regselect = ui.Select({items:["User Defined Polygon","Fusion Table","GeoJSON"],value:"Fusion Table"});
var polygon = []
var geometry = null;
var drawOnClick = function() {
    var polygon = []
    Map.onClick(
    function (coords) {
        // remove last polygon from map
        for (var i = 0; i < Map.layers().length(); i++) {
            var layer = Map.layers().get(i);
            if ('polygon' === layer.get('name')) {
                Map.remove(layer);
            }
        }
        // add coordinates to polygon
        polygon.push([coords.lon, coords.lat]);
        // manage the constructor type and build the geometry
        if (polygon.length < 3) {
            if (polygon.length == 1) {
                geometry = ee.Geometry.Point(polygon[0]);
            } else {
                geometry = ee.Geometry.LineString(polygon);
            }
        } else {
            geometry = ee.Geometry.MultiPolygon([polygon]);
        }
        // create layer
        var polygonLayer = ui.Map.Layer({
            'eeObject': ee.FeatureCollection(geometry).style({
                color: 'ff0000',
                fillColor: 'ff000000'
            }),
            'visParams': {},
            'name': 'polygon',
            'shown': true,
            'opacity': 1.0
        });
        // var training = training.union(geometry)
        // add layer to map
        Map.layers().insert(Map.layers().length(), polygonLayer);
    })}
var drawpoly = function() {
  Map.style().set('cursor', 'crosshair');
  drawOnClick()
  }
var polyreset = function() {
Map.style().set('cursor', 'hand');
  for (var i = 0; i < Map.layers().length(); i++) {
              var layer = Map.layers().get(i);
              if ('polygon' === layer.get('name')) {
                  Map.remove(layer);
              }}
Map.unlisten(drawOnClick())
}
var polyresetbutt = ui.Button({label:'Clear Polygon',
onClick:polyreset})
var polybutt = ui.Button({label:'Add User Defined Polygon',
onClick:drawpoly})
// var addBufferPoint = ui.Button({label:'Add Buffered Point',
// onClick:bufferedPoint})
var polyText = ui.Label({value:'\xa0\xa0\xa01a.\xa0',style:{fontWeight:'bold',fontSize:'12px'}})
var firstb = ui.Panel([polyText,polybutt,polyresetbutt],ui.Panel.Layout.Flow('horizontal'))
var lsFilter = ui.Panel([
ui.Label({value:'1. Landsat Indices (30 meter Resolution)',style:{fontSize:'12px',fontWeight:'bold'}}),
ui.Panel([
ndvicheck,
ndwicheck
],ui.Panel.Layout.Flow('horizontal'), {stretch: 'horizontal', padding: '0px 0px 0px 20px'}
),
ui.Panel([
ndsicheck,
nlcdcheck
],ui.Panel.Layout.Flow('horizontal'), {stretch: 'horizontal', padding: '0px 0px 0px 20px'}
)
],
null,
{stretch:'horizontal'}
  )
var soilFilter = ui.Panel([
ui.Label({value:'2. Soil Indices (10/250 meter Resolutions)',style:{fontSize:'12px',fontWeight:'bold'}}),
ui.Panel([
taxacheck,
ssurgocheck
],ui.Panel.Layout.Flow('horizontal'), {stretch: 'horizontal', padding: '0px 0px 0px 20px'}
)
],
null,
{stretch:'horizontal'}
  )
var physFilter = ui.Panel([
ui.Label({value:'3. Physical Indices (10 meter Resolution)',style:{fontSize:'12px',fontWeight:'bold'}}),
ui.Panel([
elevcheck,
slopecheck,
aspectcheck
],ui.Panel.Layout.Flow('horizontal'), {stretch: 'horizontal', padding: '0px 0px 0px 20px'}
)
],
null,
{stretch:'horizontal'}
  )
var slopebigFilter = ui.Panel([
ui.Panel([
slopeText,
slopeFilter,
slopeDegree
],ui.Panel.Layout.Flow('horizontal'), {stretch: 'horizontal'}
)
],
null,
{stretch:'horizontal'}
  )
var areaFilter = ui.Panel([
// ui.Label(''),
ui.Label({value:'Define Study Area',style:{color:'darkblue',fontWeight:'bold',fontSize:'16px'}}),
ui.Panel([ui.Label({value:'1. Select Study Area Type:\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0',style:{fontWeight:'bold',fontSize:'12px'}}),
regselect],ui.Panel.Layout.Flow('horizontal')),
firstb,
ui.Panel([ftlab,ftinput],ui.Panel.Layout.Flow('horizontal')),
ui.Panel([gjlab,gjinput],ui.Panel.Layout.Flow('horizontal')),
// areatextlab,
ui.Panel([maxbinslab,maxbins],ui.Panel.Layout.Flow('horizontal')),
ui.Panel([numdesc,numpointsopt,numpointstext],ui.Panel.Layout.Flow('horizontal')
// ui.Label({value:"Click on Map to set center point",style:{fontWeight:'bold'}})
)
],
null,
{width:300,stretch:'horizontal'}
  )
var goFilter = ui.Panel([
ui.Panel([
ui.Label({value:'Run Stratification:\xa0\xa0',style:{color:'darkblue',fontWeight:'bold',fontSize:'18px'}}),
gobutton],ui.Panel.Layout.Flow('horizontal'), {stretch: 'horizontal'}
)
],
null,
{stretch:'horizontal'}
  )
var stratitle = ui.Panel([ui.Label({value:"Stratifi - Beta v1.1",style:{color:'darkblue',fontWeight:'bold',fontSize:'19px'}}),
ui.Label({value:"Stratified random sampling using Weka X-Means clustering and freely available remote sensing products. Developed by quickcarbon.org and highplainsstewardship.org at Yale F&ES",style:{color:'darkblue',fontSize: '10px'}})
])
// Add widgets to Clustering Panel  
  panel1.add(stratitle)
        .add(ui.Label({value:"Select Input Layers",style:{color:'darkblue',fontWeight:'bold',fontSize:'16px'}}))
        .add(lsFilter)
        .add(soilFilter)
        .add(physFilter)
        .add(slopebigFilter)
        .add(areaFilter)
        .add(goFilter);
//}  
/////Visualization Panel//{
var title = ui.Panel({
    style: {width: '500px',position: 'top-center',fontSize:'20px'}
   });
// Map.add(title);
// title.add(stratitle)
var exportimage = ui.Button({
  label:""})
var inspector = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal')
});
  // title.add(exportimage)
ui.root.add(panel1);
// Map.add(panel1);
// Visualization palette for vegetation indices
var vis = {min: 0, max: 1, palette: [
  'FFFFFF', 'CE7E45', 'FCD163', '66A000', '207401',
  '056201', '004C00', '023B01', '012E01', '011301'],
  opacity:0.5
};
// Add all layers to map, but turn off Visibility
Map.addLayer(ndvi,vis,"NDVI",false);
Map.addLayer(ndwi,vis,"NDWI",false);
Map.addLayer(ndsi,vis,"NDSI",false);
Map.addLayer(soiltaxa,{opacity:0.5},"Soil Taxa",false);
Map.addLayer(gssurgo.randomVisualizer(),{opacity:0.5},"Soils - GSSURGO",false);
Map.addLayer(elevation2,{min:0,max:4000,
            palette:[ 'FFFFFF', 'CE7E45', 'FCD163', '66A000', '207401','056201', '004C00', '023B01', '012E01', '011301'],
            opacity:0.5},"Elevation",false);
Map.addLayer(slope,{min: 0, max: 90, gamma: 2, opacity:0.5},"Slope",false);
Map.addLayer(aspect,{min: 0, max: 360, gamma: 2, opacity:0.5},"Aspect",false);
Map.addLayer(nlcd,{},"Land Cover",false);  
//}  
//}
//}