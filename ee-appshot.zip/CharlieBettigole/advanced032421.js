/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var ls8 = ee.ImageCollection("LANDSAT/LC08/C01/T1_TOA"),
    geometry = /* color: #d63000 */ee.Geometry.Point([-89.7554354752254, 17.343712835496117]),
    viz = {"opacity":1,"bands":["B4","B3","B2"],"min":0.02679898403584957,"max":0.13602995872497559,"gamma":1.3800000000000001},
    elevation = ee.Image("CGIAR/SRTM90_V4");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var lscoll = ls8.filterBounds(geometry)
                 		 .filterDate('2020-06-15','2020-10-30')
                		 .filterMetadata('CLOUD_COVER',"less_than",80)
var maskClouds = function(image) {
  var scored = ee.Algorithms.Landsat.simpleCloudScore(image);
  return image.updateMask(scored.select(['cloud']).lt(20));
};
var lsMask = lscoll.map(maskClouds)
var lsComp = lsMask.median()
Map.addLayer(lsComp,viz,"Landsat",true)
Map.centerObject(geometry, 12)
var title = ui.Button({label:'For Cloud Free Imagery, Click This Button',
       style:{fontWeight:'bold',fontSize:'24px'}
  })
Map.add(title)