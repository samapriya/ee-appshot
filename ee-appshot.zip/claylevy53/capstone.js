var woolsey_polygon = ui.import && ui.import("woolsey_polygon", "table", {
      "id": "users/claylevy53/California_Fire_Perimeters_Woolsey"
    }) || ee.FeatureCollection("users/claylevy53/California_Fire_Perimeters_Woolsey"),
    thomas_polygon = ui.import && ui.import("thomas_polygon", "table", {
      "id": "users/claylevy53/California_Fire_Perimeters"
    }) || ee.FeatureCollection("users/claylevy53/California_Fire_Perimeters"),
    creek_polygon = ui.import && ui.import("creek_polygon", "table", {
      "id": "users/claylevy53/California_Fire_Perimeters_creek"
    }) || ee.FeatureCollection("users/claylevy53/California_Fire_Perimeters_creek"),
    dixie_polygon = ui.import && ui.import("dixie_polygon", "table", {
      "id": "users/claylevy53/California_Fire_Perimeters_dixie"
    }) || ee.FeatureCollection("users/claylevy53/California_Fire_Perimeters_dixie"),
    august_polygon = ui.import && ui.import("august_polygon", "table", {
      "id": "users/claylevy53/California_Fire_Perimeters_august"
    }) || ee.FeatureCollection("users/claylevy53/California_Fire_Perimeters_august");
/*******************************************************************************
 * Model *
/*******************************************************************************/
var woolsey_polygon = ee.FeatureCollection("users/claylevy53/California_Fire_Perimeters_Woolsey");
var thomas_polygon = ee.FeatureCollection("users/claylevy53/California_Fire_Perimeters");
var creek_polygon = ee.FeatureCollection("users/claylevy53/California_Fire_Perimeters_creek");
var dixie_polygon = ee.FeatureCollection("users/claylevy53/California_Fire_Perimeters_dixie");
var august_polygon = ee.FeatureCollection("users/claylevy53/California_Fire_Perimeters_august");
var m = {};
var ndwi = ee.ImageCollection("MODIS/MOD09GA_006_NDWI")
.filter(ee.Filter.date('2017-01-01', '2022-03-01'))
.select(['NDWI'])
var imagery = ee.ImageCollection("MODIS/MYD09GA_006_BAI")
.filter(ee.Filter.date('2017-01-01', '2022-03-01'))
.select(['BAI'])
// //////// Maybe Real Imgery?
// var addNdvi = function(image) { 
//   var ndvi = image.expression(
//     '(NIR - RED) / (NIR + RED)', {
//       'NIR': image.select('sur_refl_b05'),
//       'RED': image.select('sur_refl_b04')
//   })
//   .rename('NDVI');
//   return image
//     .addBands(ndvi)
// }  
// var imageryndvi = imagery.map(addNdvi)
// var ndviParams = {min: -0.5, max: 0.8, palette: ['blue', 'white', 'green']}
// Map.addLayer(imageryndvi.select('NDVI'), ndviParams, 'NDVI image first')
print(imagery)
// ///////////////////////
// Code Starts // 
var mult = function(image) { 
  return image
    .select(['NDWI'])
    .multiply(5000)
    .copyProperties(image, ['system:time_start']);
}
var ndwi_mult = ndwi.map(mult)
print(ndwi_mult.first())
// Define the image collection.
var col = ee.ImageCollection('MODIS/006/MOD13A1')
.filter(ee.Filter.date('2017-01-01', '2022-03-01'))
.select(['EVI','NDVI'])
// print(col.first())
var combined_Ic  = ndwi_mult.combine(col,true).combine(imagery,true)
print(combined_Ic.first())
// Define info about the bands in this collection that the app will present.
m.imgInfo = {
  bands: {
    'NDVI': {
      bname: 'NDVI',
      color: '46d811',
      vis: {
        min:-2000,
        max: 5000,
        palette: ['red', 'white', 'green']
      }
    },
  'EVI': {
      bname: 'EVI',
      color: 'e3ef04',
      vis: {
        min: -2000,
        max: 5000,
        palette: ['blue', 'yellow', 'green']
      }
    },
    'NDWI': {
      bname: 'NDWI',
      color: '049def',
      vis: {
        min: -2000,
        max:  2000,
        palette: ['red', 'green', 'blue']
      }
    },
    'BAI': {
      bname: 'BAI',
      color: 'ff0000',
      vis: {
        min:-1000,
        max:2000,
        palette: ['black', 'red', 'purple']
      }
    }
  },
  startYear: 2017,
  endYear: 2022,
};
// Define information for example locations.
m.exLocInfo = {
  'Woolsey Fire': {
    lon: -118.8079, lat: 34.0833, zoom: 11,
    desc: 'Woolsey Fire Burn Area: 96,949 Acres        ' + 'Date Active: 11-8-2018 - 11-21-2018'
  },
  'Thomas Fire': {
    lon: -119.3998, lat: 34.5163, zoom:10,
    desc: 'Thomas Fire Burn Area: 281,893 Acres        ' + 'Date Active: 12-4-2017 - 3-22-2018'
  },
  'Creek Fire': {
    lon: -119.3951, lat: 37.1746, zoom:9,
    desc: '   Creek Fire Burn Area: 379,895 Acres         /        Date Active:  9-4-2020 - 12-24-2020' 
    },
  'Dixie Fire': {
    lon: -121.253, lat: 40.254, zoom:9,
    desc: 'Dixie Fire Burn Area: 963,309 Acres      /  Date Active: 7-13-2021 - 10-25-2021'      
  },
  'August Complex': {
    lon: -122.917, lat: 39.753, zoom:9,
    desc: 'August Complex Fire Burn Area: 1,032,648 Acres         /   Date Active: 8-16-2020 - 11-12-2020'
}
}
/*******************************************************************************
* Components *
******************************************************************************/
// Define a JSON object for storing UI components.
var c = {};
// Define a control panel for user input.
c.controlPanel = ui.Panel();
// Define a series of panel widgets to be used as horizontal dividers.
c.dividers = {};
c.dividers.divider1 = ui.Panel();
c.dividers.divider2 = ui.Panel();
c.dividers.divider3 = ui.Panel();
c.dividers.divider4 = ui.Panel();
// Define the main interactive map.
c.map = ui.Map();
// Define an app info widget group.
c.info = {};
c.info.titleLabel = ui.Label('California Fire Vegetation Analysis');
c.info.aboutLabel = ui.Label(
  'This app was designed to display vegetation visualizations according to band combinations for specified fires and display interactive charting. Showing metrics on past and current vegetation conditions will aid in monitoring areas heavily affected by fires. Simply select a fire, a band to display and the desired buffer radius to display a chart, clicking on an area within a fire will generate the chart.');
c.info.contactinfo = ui.Label({
  value: 'Link to Paper',
  targetUrl: 'https://docs.google.com/document/d/1oM6AAhKTaQ3nFuFibqATbXZrZGISwyaeqTOgKkV3obQ/edit'
});
c.info.panel = ui.Panel([
  c.info.titleLabel, c.info.aboutLabel,
  c.info.contactinfo
]);
// Define a data band selector widget group.
c.selectBand = {};
c.selectBand.label = ui.Label('Select a band to display :');
c.selectBand.selector = ui.Select(Object.keys(m.imgInfo.bands));
c.selectBand.panel = ui.Panel([c.selectBand.label, c.selectBand.selector]);
// Define a reduction region radius selector widget group (for charting).
c.selectRadius = {};
c.selectRadius.label = ui.Label('Select chart region radius (m) :');
c.selectRadius.slider = ui.Slider({
  min: 50,
  max: 300,
  step: 50
});
c.selectRadius.panel = ui.Panel([c.selectRadius.label, c.selectRadius.slider]);
// Define an example location selector widget group.
c.selectFire = {};
c.selectFire.label = ui.Label('Select Desired Fire :');
c.selectFire.selector = ui.Select({
  items: Object.keys(m.exLocInfo),
  placeholder: 'Select a Fire...',
});
c.selectFire.descLabel = ui.Label();
c.selectFire.panel = ui.Panel([
  c.selectFire.label,
  c.selectFire.selector,
  c.selectFire.descLabel
]);
// Define a legend widget group.
c.legend = {};
c.legend.title = ui.Label();
c.legend.colorbar = ui.Thumbnail(ee.Image.pixelLonLat().select(0));
c.legend.leftLabel = ui.Label('[min]');
c.legend.centerLabel = ui.Label();
c.legend.rightLabel = ui.Label('[max]');
c.legend.labelPanel = ui.Panel({
  widgets: [
    c.legend.leftLabel,
    c.legend.centerLabel,
    c.legend.rightLabel,
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
c.legend.panel = ui.Panel([
  c.legend.title,
  c.legend.colorbar,
  c.legend.labelPanel
]);
// Define a panel for displaying a chart.
c.chart = {};
c.chart.shownButton = ui.Button('Hide chart');
c.chart.container = ui.Panel();  // will hold the dynamically generated chart. 
c.chart.chartPanel = ui.Panel([c.chart.shownButton, c.chart.container]);
//
// * Composition *
//
c.controlPanel.add(c.info.panel);
c.controlPanel.add(c.dividers.divider1);
c.controlPanel.add(c.selectFire.panel);
c.controlPanel.add(c.dividers.divider2);
c.controlPanel.add(c.selectBand.panel);
c.controlPanel.add(c.dividers.divider3);
c.controlPanel.add(c.selectRadius.panel);
c.controlPanel.add(c.dividers.divider4);
c.map.add(c.legend.panel);
c.map.add(c.chart.chartPanel);
ui.root.clear();
ui.root.add(c.controlPanel);
ui.root.add(c.map);
/*******************************************************************************
* Styling *
/*******************************************************************************/
// Define CSS-like class style properties for widgets; reusable styles.
var s = {};
s.opacityWhiteMed = {
  backgroundColor: 'rgba(255, 234, 0, 0.82)'
};
s.opacityWhiteNone = {
  backgroundColor: 'rgba(255, 255, 255, 0)'
};
s.aboutText = {
  fontSize: '13px',
  color: '505050'
};
s.widgetTitle = {
  fontSize: '15px',
  fontWeight: 'bold',
  margin: '8px 8px 0px 8px',
  color: '383838'
};
s.stretchHorizontal = {
  stretch: 'horizontal'
};
s.noTopMargin = {
  margin: '8px 8px 8px 8px'
};
s.smallBottomMargin = {
  margin: '8px 8px 8px 8px'
};
s.bigTopMargin = {
  margin: '40px 8px 8px 8px'
};
s.divider = {
  backgroundColor: 'FF0000',
  height: '8px',
  margin: '40px 0px'
};
// Set widget style.
c.info.titleLabel.style().set({
  fontSize: '20px',
  fontWeight: 'bold'
});
c.info.titleLabel.style().set(s.bigTopMargin);
c.info.aboutLabel.style().set(s.aboutText);
c.info.contactinfo.style().set(s.aboutText);
c.info.contactinfo.style().set(s.noTopMargin);
c.selectBand.selector.style().set(s.stretchHorizontal);
c.selectBand.label.style().set(s.widgetTitle);
c.selectRadius.slider.style().set(s.stretchHorizontal);
c.selectRadius.label.style().set(s.widgetTitle);
c.selectFire.selector.style().set(s.stretchHorizontal);
c.selectFire.label.style().set(s.widgetTitle);
c.selectFire.descLabel.style().set(s.aboutText);
c.selectFire.descLabel.style().set(s.noTopMargin);
c.controlPanel.style().set({
  width: '275px',
  padding: '11px'
});
c.map.style().set({
  cursor: 'crosshair'
});
c.map.setOptions('HYBRID');
c.chart.chartPanel.style().set({
  position: 'bottom-right',
  shown: false
});
c.chart.chartPanel.style().set(s.opacityWhiteMed);
c.chart.shownButton.style().set({
  margin: '0px 0px',
});
c.legend.title.style().set({
  fontWeight: 'bold',
  fontSize: '12px',
  color: '383838'
});
c.legend.title.style().set(s.opacityWhiteNone);
c.legend.colorbar.style().set({
  stretch: 'horizontal',
  margin: '0px 8px',
  maxHeight: '20px'
});
c.legend.leftLabel.style().set({
  margin: '4px 8px',
  fontSize: '12px'
});
c.legend.leftLabel.style().set(s.opacityWhiteNone);
c.legend.centerLabel.style().set({
  margin: '4px 8px',
  fontSize: '12px',
  textAlign: 'center',
  stretch: 'horizontal'
});
c.legend.centerLabel.style().set(s.opacityWhiteNone);
c.legend.rightLabel.style().set({
  margin: '4px 8px',
  fontSize: '12px'
});
c.legend.rightLabel.style().set(s.opacityWhiteNone);
c.legend.panel.style().set({
  position: 'bottom-left',
  width: '200px',
  padding: '0px'});
c.legend.panel.style().set(s.opacityWhiteMed);
c.legend.labelPanel.style().set(s.opacityWhiteNone);
// Loop through setting divider style.
Object.keys(c.dividers).forEach(function(key) {
  c.dividers[key].style().set(s.divider);
});
/*******************************************************************************
* Behaviors *
******************************************************************************/
function clipImage(bnd) {
  function wrap (image) {
    return image.clip(bnd);
  }
  return wrap
}
function getPropertyValueList(dataModelDict, propertyName){
  // Get a list of values for a specified property name.
  var result = [];
  for (var key in dataModelDict) {
    result.push(dataModelDict[key][propertyName]);
  }
  return result;
}
// Handles drawing the legend when band selector changes.
function updateLegend() {
  c.legend.title.setValue(c.selectBand.selector.getValue() + ' Value');
  c.legend.colorbar.setParams({
    bbox: [0, 0, 1, 0.1],
    dimensions: '200x200',
    format: 'png',
    min: 0,
    max: 1,
    palette: m.imgInfo.bands[c.selectBand.selector.getValue()].vis.palette
  });
  c.legend.leftLabel.setValue(
    m.imgInfo.bands[c.selectBand.selector.getValue()].vis.min);
  c.legend.centerLabel.setValue(
    m.imgInfo.bands[c.selectBand.selector.getValue()].vis.max / 2);
  c.legend.rightLabel.setValue(
    m.imgInfo.bands[c.selectBand.selector.getValue()].vis.max);
}
// Handles year and band selection for new map layer display.
function updateMap() {
  var bands = c.selectBand.selector.getValue();
  var Woolsey_boundary = ee.FeatureCollection(woolsey_polygon);
  var Thomas_boundary = ee.FeatureCollection(thomas_polygon);
  var Creek_boundary =  ee.FeatureCollection(creek_polygon);
  var Dixie_boundary = ee.FeatureCollection(dixie_polygon)
  var August_Boundary = ee.FeatureCollection(august_polygon)
  var fire_boundaries_col = Woolsey_boundary.merge(Thomas_boundary).merge(Creek_boundary).merge(Dixie_boundary).merge(August_Boundary)
  var img = (combined_Ic.select(m.imgInfo.bands[bands].bname))
    .map(clipImage(fire_boundaries_col))
  var layer = ui.Map.Layer(
    img, m.imgInfo.bands[bands].vis, bands);
  c.map.layers().set(0, layer);
}
// Handles map clicks for charting.
function drawChart(coords) {
  // Get out if call to drawChart did not come from map click and the chart
  // has not been drawn previously.
  if (!coords.lon) {
    return null;
  }
  // Get out if the clicked point intersects invalid data.
  var point = ee.Geometry.Point([coords.lon, coords.lat]);
  var validDataTest = combined_Ic.first().select(0).reduceRegion({
    reducer: ee.Reducer.first(),
    geometry: point,
    scale: combined_Ic.first().projection().nominalScale()
  });
  // if (!validDataTest.get(validDataTest.keys().get(0)).getInfo()) {
  //   return null;
  // }
  // Show the chart panel if this is the first time a point is clicked.
  if (!c.chart.chartPanel.style().get('shown')) {
    c.chart.chartPanel.style().set('shown', true);
  }
  // Show chart if hidden; assuming user wants to see updates to chart.
  if (c.chart.shownButton.getLabel() == 'Show chart') {
    c.chart.container.style().set({shown: true});
    c.chart.shownButton.setLabel('Hide chart');
  }
  var radius = c.selectRadius.slider.getValue();
  var layer = ui.Map.Layer(
    point.buffer(radius), null, 'Chart region');
  c.map.layers().set(1, layer);
  var styleChartAxis = {
    italic: false,
    bold: true
  };
  var styleChartArea = {
    width: '500px',
    height: '255px',
    margin: '0px',
    padding: '0px'
  }; 
  var chart = ui.Chart.image.series({
    imageCollection: combined_Ic.select(
      getPropertyValueList(m.imgInfo.bands, 'bname')),
    region: point.buffer(radius),
    reducer: ee.Reducer.mean(),
    scale: combined_Ic.first().projection().nominalScale()
  })
  .setSeriesNames(Object.keys(m.imgInfo.bands))
  .setChartType('LineChart')
  .setOptions({
    titlePosition: 'none',
    colors: getPropertyValueList(m.imgInfo.bands, 'color'),
    hAxis: {
      title: 'Year',
      titleTextStyle: styleChartAxis
    },
    vAxis: {
      title: 'Values',
      titleTextStyle: styleChartAxis,
    },
    legend: {maxLines: 5}
  });
  chart.style().set(styleChartArea);
  c.chart.container.widgets().reset([chart]);
}
// Handles example location selection.
function zoomToLoc(loc) {
  c.selectFire.descLabel.setValue(m.exLocInfo[loc].desc);
  c.map.setCenter(
    m.exLocInfo[loc].lon + 0.05,  // shift map left to avoid chart.
    m.exLocInfo[loc].lat,
    m.exLocInfo[loc].zoom);
  c.selectRadius.slider.setValue(300);
  var coords = {lon: m.exLocInfo[loc].lon, lat: m.exLocInfo[loc].lat};
  drawChart(coords);
  updateUrlParamChart(coords);
}
function showHideChart() {
  var shown = true;
  var label = 'Hide chart';
  if (c.chart.shownButton.getLabel() == 'Hide chart') {
    shown = false;
    label = 'Show chart';
  }
  c.chart.container.style().set({shown: shown});
  c.chart.shownButton.setLabel(label);
}
c.chart.shownButton.onClick(showHideChart);
function updateUrlParamBand(newValue) {
  var bands = getPropertyValueList(m.imgInfo.bands, 'bname');
  ui.url.set('band', m.imgInfo.bands[newValue].bname);
}
c.selectBand.selector.onChange(updateUrlParamBand);
c.selectBand.selector.onChange(updateMap);
c.selectBand.selector.onChange(updateLegend);
function updateUrlParamRadius(newValue) {
  ui.url.set('radius', newValue);
}
c.selectRadius.slider.onChange(updateUrlParamRadius);
c.selectRadius.slider.onChange(function(value) {
  drawChart({lon: ui.url.get('chart_lon'), lat: ui.url.get('chart_lat')})});
function updateUrlParamExample(newValue) {
  ui.url.set('example', m.exLocInfo[newValue].urlSlug);
}
c.selectFire.selector.onChange(updateUrlParamExample);
c.selectFire.selector.onChange(zoomToLoc);
function updateUrlParamMap(newMapParams) {
  ui.url.set('lat', newMapParams.lat);
  ui.url.set('lon', newMapParams.lon);
  ui.url.set('zoom', newMapParams.zoom);
}
c.map.onChangeBounds(ui.util.debounce(updateUrlParamMap, 100));
function updateUrlParamChart(newChartParams) {
  ui.url.set('chart_lat', newChartParams.lat);
  ui.url.set('chart_lon', newChartParams.lon);
}
c.map.onClick(drawChart);
c.map.onClick(updateUrlParamChart);
/*******************************************************************************
* Initialize *
******************************************************************************/
function findKey(dataModelDict, propertyName, propertyValue){
  // Find the first dictionary key for a specified property value.
  for (var key in dataModelDict) {
    if (dataModelDict[key][propertyName] == propertyValue) {
      return key;
    }
  }
  return null;
}
// Set model state based on URL parameters or default values.
c.map.setCenter({
  lon: ui.url.get('lon', -119.0),
  lat: ui.url.get('lat', 37.0),
  zoom: ui.url.get('zoom', 7)
});
c.selectBand.selector.setValue(
  findKey(m.imgInfo.bands, 'bname', ui.url.get('band', 'EVI')), 
  false);
c.selectRadius.slider.setValue(ui.url.get('radius', 30), false);
c.selectFire.selector.setValue('Thomas Fire');
if (ui.url.get('example')) {
  c.selectFire.descLabel.setValue(
    m.exLocInfo[c.selectFire.selector.getValue()].desc);
}
// Render the map and legend.
updateMap();
updateLegend();
// Render the chart if applicable (chart_lon exists as URL param).
drawChart({lon: ui.url.get('chart_lon'), lat: ui.url.get('chart_lat')});