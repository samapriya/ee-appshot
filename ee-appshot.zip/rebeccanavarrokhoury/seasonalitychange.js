var AOILarge = ui.import && ui.import("AOILarge", "table", {
      "id": "users/rebeccanavarrokhoury/AOI_Large"
    }) || ee.FeatureCollection("users/rebeccanavarrokhoury/AOI_Large"),
    aoi = ui.import && ui.import("aoi", "table", {
      "id": "users/rebeccanavarrokhoury/AOI_SAISS"
    }) || ee.FeatureCollection("users/rebeccanavarrokhoury/AOI_SAISS");
var AOILarge = aoi;
//--------Data preparation  ---------------------------------------------------
// Apply cloud mask and filter on entire dataset
var S2 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterBounds(AOILarge)
                  .filterDate('2015-08-01', '2020-08-30')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
// Add NDVI and time bands
var timeField = 'system:time_start';
// Add variables: 
var addVariables = function(image) {
  // Compute time in fractional years since the epoch.
  var date = ee.Date(image.get(timeField));
  var years = date.difference(ee.Date('1970-01-01'), 'year');
  // Return the image with the added bands.
  return image
    // Add an NDVI band.
    .addBands(image.normalizedDifference(['B8', 'B4']).rename('NDVI')).float()
    // Add a time band.
    .addBands(ee.Image(years).rename('t').float())
    // Add a constant band.
    .addBands(ee.Image.constant(1));
};
var S2 = S2
  .map(addVariables);
// NDVI time series for selected point------------------------------------------------------
// Linear trend
// List of the independent variable names
var independents = ee.List(['constant', 't']);
// Name of the dependent variable.
var dependent = ee.String('NDVI');
// Compute a linear trend.  This will have two bands: 'residuals' and 
// a 2x1 band called coefficients (columns are for dependent variables).
var trend = S2.select(independents.add(dependent))
    .reduce(ee.Reducer.linearRegression(independents.length(), 1));
// Flatten the coefficients into a 2-band image
var coefficients = trend.select('coefficients')
  .arrayProject([0])
  .arrayFlatten([independents]);
// Harmonic trend 
// Use these independent variables in the harmonic regression.
var harmonicIndependents = ee.List(['constant', 't', 'cos', 'sin']);
// Add harmonic terms as new image bands.
var harmonicS2 = S2.map(function(image) {
  var timeRadians = image.select('t').multiply(2 * Math.PI);
  return image
    .addBands(timeRadians.cos().rename('cos'))
    .addBands(timeRadians.sin().rename('sin'));
});
// The output of the regression reduction is a 4x1 array image.
var harmonicTrend = harmonicS2
  .select(harmonicIndependents.add(dependent))
  .reduce(ee.Reducer.linearRegression(harmonicIndependents.length(), 1));
// Turn the array image into a multi-band image of coefficients.
var harmonicTrendCoefficients = harmonicTrend.select('coefficients')
  .arrayProject([0])
  .arrayFlatten([harmonicIndependents]);
// Compute fitted values.
var fittedHarmonicS2 = harmonicS2.map(function(image) {
  return image.addBands(
    image.select(harmonicIndependents)
      .multiply(harmonicTrendCoefficients)
      .reduce('sum')
      .rename('fitted'));
});
// Compute phase and amplitude.
var phase = harmonicTrendCoefficients.select('cos').atan2(
            harmonicTrendCoefficients.select('sin'))
var amplitude = harmonicTrendCoefficients.select('cos').hypot(
                harmonicTrendCoefficients.select('sin'));
// Use the HSV to RGB transform to display phase and amplitude
var rgb = phase.unitScale(-Math.PI, Math.PI).addBands(
          amplitude.multiply(2.5)).addBands(
          ee.Image(1)).hsvToRgb();
// Display
//Map.centerObject(aoi, 12);  
//Map.addLayer(rgb.clip(aoi), {}, 'Sentinel 2 NDVI phase (hue), amplitude (saturation) map');
        ///////////////////////////
        /////////LANDSAT///////////
        ///////////////////////////
// Data preparation -------------------------------------------------------------------------------------------------------------------------
// Merge Landsat 5, 7  and 8 imagery 
// Assign a common name to the sensor-specific bands.
var LC8_BANDS = ['B2',   'B3',    'B4',  'B5',  'B6',    'B7',    'B10']; //Landsat 8
var LC7_BANDS = ['B1',   'B2',    'B3',  'B4',  'B5',    'B7',    'B6']; //Landsat 7
var LC5_BANDS = ['B1',   'B2',    'B3',  'B4',  'B5',    'B7',    'B6']; //Llandsat 5
var STD_NAMES = ['blue', 'green', 'red', 'nir', 'swir1', 'swir2', 'temp'];
/* Function to mask clouds based on the pixel_qa band of Landsat 8 SR data.
 * @param {ee.Image} image input Landsat 8 SR image
 * @return {ee.Image} cloudmasked Landsat 8 image
 */
function maskL8sr(image) {
  // Bits 3 and 5 are cloud shadow and cloud, respectively.
  var cloudShadowBitMask = (1 << 3);
  var cloudsBitMask = (1 << 5);
  // Get the pixel QA band.
  var qa = image.select('pixel_qa');
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudShadowBitMask).eq(0)
                 .and(qa.bitwiseAnd(cloudsBitMask).eq(0));
  return image.updateMask(mask);
}
var l8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR').map(maskL8sr);
var l8 = l8.filterBounds(AOILarge);
var l8 = l8.select(LC8_BANDS, STD_NAMES);
// Mask Landsat 7 clouds
var maskL7sr = function(image) {
  var qa = image.select('pixel_qa');
  // If the cloud bit (5) is set and the cloud confidence (7) is high
  // or the cloud shadow bit is set (3), then it's a bad pixel.
  var cloud = qa.bitwiseAnd(1 << 5)
                  .and(qa.bitwiseAnd(1 << 7))
                  .or(qa.bitwiseAnd(1 << 3));
  // Remove edge pixels that don't occur in all bands
  var mask2 = image.mask().reduce(ee.Reducer.min());
  return image.updateMask(cloud.not()).updateMask(mask2);
};
var l7 = ee.ImageCollection('LANDSAT/LE07/C01/T1_SR')
                  .filterDate('2011-11-01', '2013-12-31')
                  .map(maskL7sr);
var l7 = l7.filterBounds(AOILarge);
var l7 = l7.select(LC7_BANDS, STD_NAMES);
// Mask clouds in Landsat 5 imagery
var maskL5sr = function(image) {
  var qa = image.select('pixel_qa');
  // If the cloud bit (5) is set and the cloud confidence (7) is high
  // or the cloud shadow bit is set (3), then it's a bad pixel.
  var cloud = qa.bitwiseAnd(1 << 5)
                  .and(qa.bitwiseAnd(1 << 7))
                  .or(qa.bitwiseAnd(1 << 3));
  // Remove edge pixels that don't occur in all bands
  var mask2 = image.mask().reduce(ee.Reducer.min());
  return image.updateMask(cloud.not()).updateMask(mask2);
};
var l5 = ee.ImageCollection('LANDSAT/LT05/C01/T1_SR').map(maskL5sr);
var l5 = l5.filterBounds(AOILarge);
var l5 = l5.select(LC5_BANDS, STD_NAMES);
// Merge all Landsat filtered collections:
var lall = ee.ImageCollection(l5.merge(l8).merge(l7));
// Add NDVI and time bands
// Use this function to add variables for NDVI, time and a constant
var addVariables = function(image) {
  // Compute time in fractional years since the epoch.
  var date = ee.Date(image.get(timeField));
  var years = date.difference(ee.Date('1970-01-01'), 'year');
  // Return the image with the added bands.
  return image
    // Add an NDVI band.
    .addBands(image.normalizedDifference(['nir', 'red']).rename('NDVI')).float()
    // Add a time band.
    .addBands(ee.Image(years).rename('t').float())
    // Add a constant band.
    .addBands(ee.Image.constant(1));
};
var LandsatNDVI = lall
  .map(addVariables);
// Linear trend --------------------------------------------------------------------------------------------------------------------------
// List of the independent variable names
var independents = ee.List(['constant', 't']);
// Name of the dependent variable.
var dependent = ee.String('NDVI');
// Compute a linear trend.  This will have two bands: 'residuals' and 
// a 2x1 band called coefficients (columns are for dependent variables).
var trend = LandsatNDVI.select(independents.add(dependent))
    .reduce(ee.Reducer.linearRegression(independents.length(), 1));
// Flatten the coefficients into a 2-band image
var coefficients = trend.select('coefficients')
  .arrayProject([0])
  .arrayFlatten([independents]);
// Harmonic trend ---------------------------------------------------------------------------------------------------------------------------
// Use these independent variables in the harmonic regression.
var harmonicIndependents = ee.List(['constant', 't', 'cos', 'sin']);
// Add harmonic terms as new image bands.
var harmonicLandsat = LandsatNDVI.map(function(image) {
  var timeRadians = image.select('t').multiply(2 * Math.PI);
  return image
    .addBands(timeRadians.cos().rename('cos'))
    .addBands(timeRadians.sin().rename('sin'));
});
// The output of the regression reduction is a 4x1 array image. Filter date for a 3-year period to obtain a good
// model fit
var harmonicTrend9902 = harmonicLandsat
  .filterDate('1999-01-01','2002-12-31')
  .select(harmonicIndependents.add(dependent))
  .reduce(ee.Reducer.linearRegression(harmonicIndependents.length(), 1));
var harmonicTrend1013 = harmonicLandsat
  .filterDate('2010-01-01','2013-12-31')
  .select(harmonicIndependents.add(dependent))
  .reduce(ee.Reducer.linearRegression(harmonicIndependents.length(), 1));
// Turn the array image into a multi-band image of coefficients.
var harmonicTrendCoefficients9902 = harmonicTrend9902.select('coefficients')
  .arrayProject([0])
  .arrayFlatten([harmonicIndependents]);
var harmonicTrendCoefficients1013 = harmonicTrend1013.select('coefficients')
  .arrayProject([0])
  .arrayFlatten([harmonicIndependents]);
// Compute fitted values.
var fittedHarmonic9902 = harmonicLandsat.map(function(image) {
  return image.addBands(
    image.select(harmonicIndependents)
      .multiply(harmonicTrendCoefficients9902)
      .reduce('sum')
      .rename('fitted'));
});
var fittedHarmonic1013 = harmonicLandsat.map(function(image) {
  return image.addBands(
    image.select(harmonicIndependents)
      .multiply(harmonicTrendCoefficients1013)
      .reduce('sum')
      .rename('fitted'));
});
// Visualize -----------------------------------------------------------------------------------------------------------------------------
// Compute phase and amplitude for visualization.
var phase9902 = harmonicTrendCoefficients9902.select('cos').atan2(
            harmonicTrendCoefficients9902.select('sin'));
var amplitude9902 = harmonicTrendCoefficients9902.select('cos').hypot(
                harmonicTrendCoefficients9902.select('sin'));
// Compute phase and amplitude.
var phase1013 = harmonicTrendCoefficients1013.select('cos').atan2(
            harmonicTrendCoefficients1013.select('sin'));
var amplitude1013 = harmonicTrendCoefficients1013.select('cos').hypot(
                harmonicTrendCoefficients1013.select('sin'));
// Use the HSV to RGB transform to display phase and amplitude
var rgb9902 = phase9902.unitScale(-Math.PI, Math.PI).addBands(
          amplitude9902.multiply(2.5)).addBands(
          ee.Image(1)).hsvToRgb();
var rgb1013 = phase1013.unitScale(-Math.PI, Math.PI).addBands(
          amplitude1013.multiply(2.5)).addBands(
          ee.Image(1)).hsvToRgb();
// Create User Interface portion --------------------------------------------------
// Create a panel for one site of the split screen to hold our widgets.
var panelchart1 = ui.Panel();
panelchart1.style().set('width', '400px');
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: 'Landsat 2010-2013 seasonal composite',
    style: {fontSize: '15px'}
  }),
]);
panelchart1.add(intro);
panelchart1.style().set('position', 'bottom-left')
// panels to hold lon/lat values
var lon = ui.Label();
var lat = ui.Label();
panelchart1.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// Add the panel to the left map
Map.add(panelchart1)
Map.style().set('cursor', 'crosshair');
// Register a callback on the default map to be invoked when the map is clicked
Map.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2)),
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  var point = ee.Geometry.Point(coords.lon, coords.lat);
 linkedMap.layers().set(1, ui.Map.Layer(point, {color: 'FF0000'}));
 Map.layers().set(1, ui.Map.Layer(point, {color: 'FF0000'}));
var harmonicTSlall1013 = ui.Chart.image.series(
  fittedHarmonic1013.select(['fitted','NDVI']).filterDate('2010-01-01','2013-12-31'), point, ee.Reducer.mean(), 30)
    .setSeriesNames(['NDVI', 'fitted'])
    .setOptions({
      title: 'NDVI Harmonic model: original and fitted values 2010-2013',
      lineWidth: 1,
      pointSize: 2,
});
panelchart1.widgets().set(1,harmonicTSlall1013);
});
Map.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2)),
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  var point = ee.Geometry.Point(coords.lon, coords.lat);
 var harmonicS2 = ui.Chart.image.series(
  fittedHarmonicS2.select(['fitted','NDVI']), point, ee.Reducer.mean(), 10)
    .setSeriesNames(['NDVI', 'fitted'])
    .setOptions({
      title: 'NDVI Harmonic model: original and fitted values 2017-2020',
      lineWidth: 0.5,
      pointSize: 1,
}); 
panelchart2.widgets().set(1,harmonicS2);
});
// Clip the seasonal composites to the study area 
var Landsat9902 = rgb9902.clip(AOILarge);
var Landsat1013 = rgb1013.clip(AOILarge);
var Sentinel1720 = rgb.clip(AOILarge);
// Add the layer to compare on the left map
Map.addLayer(Landsat1013, {}, 'Landsat 2010-2013 NDVI based seasonal composite');
//Map.addLayer(Landsat9902, {}, 'Landsat 1999-2002 NDVI based seasonal composite', false);
// Create the title label.
var title = ui.Panel([
   ui.Label({
    value: 'Attendez que la carte soit chargée.',
    style: {fontSize: '15px', fontWeight: 'bold'}
  }),
]);
title.style().set('position', 'top-left');
Map.add(title);
// Make another map and define some visual parameters
var linkedMap = ui.Map();
linkedMap.setOptions('HYBRID');
linkedMap.style().set('cursor', 'crosshair');
// Add the other composite
linkedMap.addLayer(Sentinel1720, {}, 'Sentinel 2 2017-2020 NDVI based seasonality');
// Add a title to the map on the right
//var titlelinkedMap = ui.Label('Sentinel 2 2017-2020 seasonal composite');
//titlelinkedMap.style().set('position', 'top-right');
//linkedMap.add(titlelinkedMap);
// Link the default Map to the other map.
var linker = ui.Map.Linker([ui.root.widgets().get(0), linkedMap]);
// Create a panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: 'Sentinel 2 2017-2020 seasonal composite',
    style: {fontSize: '15px'}
  }),
]);
// Create a 2nd panel chart for the map on the right
var panelchart2 = ui.Panel();
panelchart2.style().set('width', '400px');
panelchart2.add(intro);
panelchart2.style().set('position', 'bottom-right')
// panels to hold lon/lat values
var lon = ui.Label();
var lat = ui.Label();
panelchart2.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// Register a callback on the default map to be invoked when the map is clicked
linkedMap.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2)),
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  var point = ee.Geometry.Point(coords.lon, coords.lat);
 linkedMap.layers().set(1, ui.Map.Layer(point, {color: 'FF0000'}));
 Map.layers().set(1, ui.Map.Layer(point, {color: 'FF0000'}));
 var harmonicS2 = ui.Chart.image.series(
  fittedHarmonicS2.select(['fitted','NDVI']), point, ee.Reducer.mean(), 10)
    .setSeriesNames(['NDVI', 'fitted'])
    .setOptions({
      title: 'NDVI Harmonic model: original and fitted values 2017-2020',
            lineWidth: 0.5,
      pointSize: 1,
}); 
panelchart2.widgets().set(1,harmonicS2);
});
linkedMap.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2)),
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  var point = ee.Geometry.Point(coords.lon, coords.lat);
var harmonicTSlall1013 = ui.Chart.image.series(
  fittedHarmonic1013.select(['fitted','NDVI']).filterDate('2010-01-01','2013-12-31'), point, ee.Reducer.mean(), 30)
    .setSeriesNames(['NDVI', 'fitted'])
    .setOptions({
      title: 'NDVI Harmonic model: original and fitted values 2010-2013',
      lineWidth: 1,
      pointSize: 2,
});
panelchart1.widgets().set(1,harmonicTSlall1013);
});
// Add the panel to the right  map
linkedMap.add(panelchart2) 
// Create a SplitPanel which holds the linked maps side-by-side.
var splitPanel = ui.SplitPanel({
  firstPanel: linker.get(0),
  secondPanel: linker.get(1),
  orientation: 'horizontal',
  wipe: true,
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in root.
ui.root.widgets().reset([splitPanel]);
linkedMap.centerObject(AOILarge,13);
Map.setOptions('HYBRID')
var drawingTools = Map.drawingTools();
drawingTools.setShown(false);