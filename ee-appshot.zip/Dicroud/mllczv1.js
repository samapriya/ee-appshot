/************************************************************
 *    VERSAO CIDADE ANO - PROJETO TESES - LCZ PARANÁ 2023
 *
 * Visualização Classificação LCZ 2023
 * Data: 04/07/2024
************************************************************/
// Define the list of cities and years
var Lista_Cidades_Selec = ["Curitiba", "Londrina", "Maringa"];
var yearList = [1988, 1998, 2008, 2018, 2023];
// Create a dictionary of images for each city and year
var images = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  yearList.forEach(function(year) {
    var key = cidade + '_' + year;
    images[key] = ee.Image("users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/Classificacao_LCZ/2_Rodada/CLASS_OBJETOS_LCZ_ASSET_" + cidade + "_" + year + "_V1");
  });
});
// Visualization parameters for LCZ classification
var Vis_Class_LCZ = {
  min: 1,
  max: 17,
  palette: [
    '8c0000','d10000','ff0000','bf4d00','ff6600',
    'ff9955','faee05','bcbcbc','ffccaa','555555',
    '006a00','00aa00','648525','b9db79','000000',
    'fbf7ae','6a6aff'
  ]
};
// Dictionary for city zoom levels
var dicZoom = {
  "Curitiba": 11,
  "Londrina": 10,
  "Maringa": 11,
};
// Dictionary for city centers (approximate coordinates)
var dicCenter = {
  "Curitiba": [-49.2671, -25.4295],
  "Londrina": [-51.1718, -23.3045],
  "Maringa": [-51.9381, -23.4210],
};
// Create the left map, and have it display the first image
var leftMap = ui.Map();
leftMap.setControlVisibility(false);
// Create the right map, and have it display the second image
var rightMap = ui.Map();
rightMap.setControlVisibility(false);
// Function to add layer selector to the map
function addLayerSelector(mapToChange, position) {
  var cityLabel = ui.Label('Selecione a Cidade:');
  var yearLabel = ui.Label('Selecione o Ano:');
  var citySelect = ui.Select({
    items: Lista_Cidades_Selec,
    onChange: function(city) {
      updateMap(city, yearSelect.getValue());
      mapToChange.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
    }
  });
  var yearSelect = ui.Select({
    items: yearList.map(String),
    onChange: function(year) {
      updateMap(citySelect.getValue(), year);
    }
  });
  function updateMap(city, year) {
    if (city && year) {
      var key = city + '_' + year;
      var image = images[key];
      mapToChange.layers().set(0, ui.Map.Layer(image, Vis_Class_LCZ, key));
    }
  }
  citySelect.setValue(Lista_Cidades_Selec[0], true);
  yearSelect.setValue(yearList[yearList.length - 1].toString(), true);
  var controlPanel = ui.Panel({
    widgets: [cityLabel, citySelect, yearLabel, yearSelect],
    style: {position: position}
  });
  mapToChange.add(controlPanel);
  return {citySelect: citySelect, yearSelect: yearSelect, updateMap: updateMap};
}
var leftSelector = addLayerSelector(leftMap, 'top-left');
var rightSelector = addLayerSelector(rightMap, 'top-right');
// Function to sync selectors
function syncSelectors(selector1, selector2) {
  selector1.citySelect.onChange(function(city) {
    selector2.citySelect.setValue(city, false);
    var year1 = selector1.yearSelect.getValue();
    var year2 = selector2.yearSelect.getValue();
    leftMap.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
    rightMap.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
    selector1.updateMap(city, year1);
    selector2.updateMap(city, year2);
  });
  selector2.citySelect.onChange(function(city) {
    selector1.citySelect.setValue(city, false);
    var year1 = selector1.yearSelect.getValue();
    var year2 = selector2.yearSelect.getValue();
    leftMap.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
    rightMap.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
    selector1.updateMap(city, year1);
    selector2.updateMap(city, year2);
  });
}
// Sync the selectors
syncSelectors(leftSelector, rightSelector);
// Create a SplitPanel to hold the adjacent, linked maps
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in the UI root
ui.root.widgets().reset([splitPanel]);
// Link the maps
var linker = ui.Map.Linker([leftMap, rightMap]);
// Add legend
var Legenda = require('users/joaovsiqueira1/packages:Legend.js');
var Parametros_Legenda = {
    "title": 'CLASSIFICAÇÃO LCZ',
    "layers": [
      ["8c0000", 1 ,"Compact highrise"],
      ["d10000", 2 ,"Compact midrise"],
      ["ff0000", 3 ,"Compact lowrise"],
      ["bf4d00", 4 ,"Open highrise"],
      ["ff6600", 5 ,"Open midrise"],
      ["ff9955", 6 ,"Open lowrise"],
      ["faee05", 7 ,"Lightweight lowrise"],
      ["bcbcbc", 8 ,"Large lowrise"],
      ["ffccaa", 9 ,"Sparsely built"],
      ["555555", 10 ,"Heavy industry"],
      ["006a00", 11 ,"Dense Trees"],
      ["00aa00", 12 ,"Scattered Trees"],
      ["648525", 13 ,"Bush, scrub"],
      ["b9db79", 14 ,"Low plants"],
      ["000000", 15 ,"Bare rock or paved"],
      ["fbf7ae", 16 ,"Bare soil or sand"],
      ["6a6aff", 17 ,"Water"],
    ],
    "style": {
        "backgroundColor": "#ffffff",
        "color": "#212121"
    },
    "orientation": "vertical"
};
leftMap.add(Legenda.getLegend(Parametros_Legenda));