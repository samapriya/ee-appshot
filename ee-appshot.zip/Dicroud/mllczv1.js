// Define the list of cities and years
var Lista_Cidades_Selec = ["Curitiba", "Londrina", "Maringa"];
var Lista_Anos = [1988, 1999, 2008, 2018, 2023];
var Lista_Produtos = ["LCZ", "LCZ*", "NDVI", "NDVI*", "NDVI_Class", "NDVI_Class*", "LST", "LST*", "MTHI", "MTHI*"]// , "MOSAICO", "MOSAICO*"
// var CAMINHO_MOSAICOS = "users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/Mosaicos_P24/"
var GEOMETRIAS = ee.FeatureCollection("users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/Geometrias_P24/Cidades_3_Estudo_ASSET_V2")
// var CAMINHO_NDVI_CLASS = 'users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/NDVI_CLASS/'
// var CAMINHO_NDVI = 'users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/NDVI_P24/'
// var CAMINHO_LST = "users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/LST_P24/"
var CAMINHO_NDMI = "users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/NDMI_P24/" // NAO TEMOS DADOS GERADOS PARA O VERAO (16/05/2025)
// var CAMINHO_MTHI = "users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/MTHI_P24/"
var CAMINHO_MOSAICOS = "users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/Teste_Verao_Inverno/MOSAICOS/MOSAICOS_Teste_Verao/"
var CAMINHO_LST = "users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/Teste_Verao_Inverno/LST/LST_Teste_Verao/"
var CAMINHO_NDVI = "users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/Teste_Verao_Inverno/NDVI/NDVI_Teste_Verao/"
var CAMINHO_NDVI_CLASS = "users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/Teste_Verao_Inverno/NDVI_Class/NDVI_Class_Teste_Verao/"
var CAMINHO_MTHI = "users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/Teste_Verao_Inverno/MTHI/MTHI_Teste_Verao/"
var CAMINHO_PRODMASCARAS = "users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/Teste_Verao_Inverno/PRODMASCARAS/PRODMASCARAS_Teste_Verao/"
// var Dic_NDWI = {};
// Lista_Cidades_Selec.forEach(function(cidade) {
//   Lista_Anos.forEach(function(year) {
//     var key = "NDWI_" + cidade + '_' + year;
//     var Img = ee.Image(CAMINHO_MOSAICOS + "Mosaico_L456789_" + cidade + "_" + year + "_V1")
//                     // .select(["NDVI_median"], ["NDVI"])
//                     .set("Cidade", cidade)
//                     .set("Ano", year);
//     Dic_NDWI[key] = Img.normalizedDifference(["B5_median", "B3_median"])
//                     .rename("NDWI")
//                     .set("Cidade", cidade)
//                     .set("Ano", year);
//   });
// });
// print("Dic_NDWI", Dic_NDWI)
// PRODUTOS COM MASCARA
// MOSAICO MASCARA
var Dic_MOSAICO_MASCARA = {};
// var Dic_MinMax = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "MOSAICO*_" + cidade + '_' + year;
    var Geo_Cidade = GEOMETRIAS.filter(ee.Filter.eq("ADM2_NAME", cidade))
    Dic_MOSAICO_MASCARA[key] = ee.Image(CAMINHO_PRODMASCARAS + "MOSAICO_MASCARA_" + cidade + "_" + year)
                    // .select(["NDVI_median"], ["NDVI"])
                    .set("Cidade", cidade)
                    .set("Ano", year)
                    .set("Tipo", "Mascara")
                    .clip(Geo_Cidade)
  });
});
print("Dic_MOSAICO_MASCARA", Dic_MOSAICO_MASCARA)
// NDVI MASCARA
var Dic_NDVI_MASCARA = {};
// var Dic_MinMax = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "NDVI*_" + cidade + '_' + year;
    var Geo_Cidade = GEOMETRIAS.filter(ee.Filter.eq("ADM2_NAME", cidade))
    Dic_NDVI_MASCARA[key] = ee.Image(CAMINHO_PRODMASCARAS + "NDVI_MASCARA_" + cidade + "_" + year)
                    // .select(["NDVI_median"], ["NDVI"])
                    .set("Cidade", cidade)
                    .set("Ano", year)
                    .set("Tipo", "Mascara")
                    .clip(Geo_Cidade)
  });
});
print("Dic_NDVI_MASCARA", Dic_NDVI_MASCARA)
// NDVI_Class MASCARA
var Dic_NDVI_Class_MASCARA = {};
// var Dic_MinMax = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "NDVI_Class*_" + cidade + '_' + year;
    var Geo_Cidade = GEOMETRIAS.filter(ee.Filter.eq("ADM2_NAME", cidade))
    Dic_NDVI_Class_MASCARA[key] = ee.Image(CAMINHO_PRODMASCARAS + "NDVI_Class_MASCARA_" + cidade + "_" + year)
                    // .select(["NDVI_median"], ["NDVI"])
                    .set("Cidade", cidade)
                    .set("Ano", year)
                    .set("Tipo", "Mascara")
                    .clip(Geo_Cidade)
  });
});
print("Dic_NDVI_Class_MASCARA", Dic_NDVI_Class_MASCARA)
// LST MASCARA
var Dic_LST_MASCARA = {};
// var Dic_MinMax = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "LST*_" + cidade + '_' + year;
    var Geo_Cidade = GEOMETRIAS.filter(ee.Filter.eq("ADM2_NAME", cidade))
    Dic_LST_MASCARA[key] = ee.Image(CAMINHO_PRODMASCARAS + "LST_MASCARA_" + cidade + "_" + year)
                    // .select(["NDVI_median"], ["NDVI"])
                    .set("Cidade", cidade)
                    .set("Ano", year)
                    .set("Tipo", "Mascara")
                    .clip(Geo_Cidade)
  });
});
print("Dic_LST_MASCARA", Dic_LST_MASCARA)
// MTHI MASCARA
var Dic_MTHI_MASCARA = {};
// var Dic_MinMax = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "MTHI*_" + cidade + '_' + year;
    var Geo_Cidade = GEOMETRIAS.filter(ee.Filter.eq("ADM2_NAME", cidade))
    Dic_MTHI_MASCARA[key] = ee.Image(CAMINHO_PRODMASCARAS + "MTHI_MASCARA_" + cidade + "_" + year)
                    // .select(["NDVI_median"], ["NDVI"])
                    .set("Cidade", cidade)
                    .set("Ano", year)
                    .set("Tipo", "Mascara")
                    .clip(Geo_Cidade)
  });
});
print("Dic_MTHI_MASCARA", Dic_MTHI_MASCARA)
// MTHI MASCARA
var Dic_LCZ_MASCARA = {};
// var Dic_MinMax = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "LCZ*_" + cidade + '_' + year;
    var Geo_Cidade = GEOMETRIAS.filter(ee.Filter.eq("ADM2_NAME", cidade))
    Dic_LCZ_MASCARA[key] = ee.Image(CAMINHO_PRODMASCARAS + "LCZ_MASCARA_" + cidade + "_" + year)
                    // .select(["NDVI_median"], ["NDVI"])
                    .set("Cidade", cidade)
                    .set("Ano", year)
                    .set("Tipo", "Mascara")
                    .clip(Geo_Cidade)
  });
});
print("Dic_LCZ_MASCARA", Dic_LCZ_MASCARA)
// Lista_Produtos.push("MOSAICO*"); // Produto com Mascara
// Lista_Produtos.push("NDVI*"); // Produto com Mascara
// Lista_Produtos.push("NDVI_Class*"); // Produto com Mascara
// Lista_Produtos.push("LST*"); // Produto com Mascara
// Lista_Produtos.push("MTHI*"); // Produto com Mascara
// Lista_Produtos.push("LCZ*"); // Produto com Mascara
//###################################
// NDMI
var Dic_NDMI = {};
// var Dic_MinMax = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "NDMI*_" + cidade + '_' + year;
    var Geo_Cidade = GEOMETRIAS.filter(ee.Filter.eq("ADM2_NAME", cidade))
    Dic_NDMI[key] = ee.Image(CAMINHO_NDMI + "NDMI_" + cidade + "_" + year + "_V2")
                    // .select(["NDVI_median"], ["NDVI"])
                    .set("Cidade", cidade)
                    .set("Ano", year)
                    .clip(Geo_Cidade)
      //   var Min_NDMI = ee.Number(Dic_NDMI[key].reduceRegion({
      //                           reducer: ee.Reducer.min(),
      //                           scale: 30,
      //                           maxPixels: 1e9,
      //                           geometry: Geo_Cidade.geometry()
      //                 })
      //                 .values().get(0));
      //   var Max_NDMI = ee.Number(Dic_NDMI[key].reduceRegion({
      //                           reducer: ee.Reducer.max(),
      //                           scale: 30,
      //                           maxPixels: 1e9,
      //                           geometry: Geo_Cidade.geometry()
      //                 })
      //                 .values().get(0));
      // var Key_Min_NDMI = 'Min_NDMI_' + cidade + "_" + year  
      // Dic_MinMax[Key_Min_NDMI] = Min_NDMI
      // var Key_Max_NDMI = 'Max_NDMI_' + cidade + "_" + year  
      // Dic_MinMax[Key_Max_NDMI] = Max_NDMI
  });
});
// Lista_Produtos.push("NDMI*");
print("Dic_NDMI", Dic_NDMI)
var Vis_NDMI = {
  min: 0,
  max: 0.3,
  palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']
}
var Vis_LST = {
  min: 20,
  max: 45,
  palette: ['blue', 'yellow', 'darkorange', 'red']
}
var Vis_MTHI = {
  min: 55,
  max: 75,
  palette: ['green', 'yellow', 'red']
}
// Lista_Produtos.push("NDMI");
// LST
var Dic_LST = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "LST_" + cidade + '_' + year;
    Dic_LST[key] = ee.Image(CAMINHO_LST + "LST_Verao_" + cidade + '_' + year + '_V1')
                    // .select(["NDVI_median"], ["NDVI"])
                    .set("Cidade", cidade)
                    .set("Ano", year)
                    .clip(GEOMETRIAS.filter(ee.Filter.eq("ADM2_NAME", cidade)))
  });
});
print("Dic_LST", Dic_LST)
// Lista_Produtos.push("LST");
// MTHI
var Dic_MTHI = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "MTHI_" + cidade + '_' + year;
    Dic_MTHI[key] = ee.Image(CAMINHO_MTHI + "MTHI_Verao_" + cidade + '_' + year + '_V1')
                    // .select(["NDVI_median"], ["NDVI"])
                    .set("Cidade", cidade)
                    .set("Ano", year)
                    .clip(GEOMETRIAS.filter(ee.Filter.eq("ADM2_NAME", cidade)))
  });
});
print("Dic_MTHI", Dic_MTHI)
// Lista_Produtos.push("MTHI");
// LCZ
var images = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "LCZ_" + cidade + '_' + year;
    images[key] = ee.Image("users/Dicroud/Doutorado_UTFPR23/Projeto_Teses_24/Classificacao_LCZ/2_Rodada/CLASS_OBJETOS_LCZ_ASSET_" + cidade + "_" + year + "_V1");
  });
});
print("Dic_Class_LCZ", images)
// Adicionar a opção de classificação NDVI ao seletor de produtos
// Lista_Produtos.push("NDVI_class");
var Dic_NDVI = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "NDVI_" + cidade + '_' + year;
    Dic_NDVI[key] = ee.Image(CAMINHO_NDVI + "NDVI_Verao_" + cidade + '_' + year + '_V1');
  });
});
print("Dic_NDVI", Dic_NDVI)
var Dic_NDVI_Classificado = {};
Lista_Cidades_Selec.forEach(function(cidade) {
  Lista_Anos.forEach(function(year) {
    var key = "NDVI_class_" + cidade + '_' + year;
    Dic_NDVI_Classificado[key] = ee.Image(CAMINHO_NDVI_CLASS + "NDVI_Class_Verao_" + cidade + '_' + year + '_V1');
  });
});
print("Dic_NDVI_Classificado", Dic_NDVI_Classificado)
// Función para combinar diccionarios
function mergeDicts(dicts) {
  var merged = {};
  dicts.forEach(function(dict) {
    for (var key in dict) {
      if (dict.hasOwnProperty(key)) {
        merged[key] = dict[key];
      }
    }
  });
  return merged;
}
// Uniendo los tres diccionarios en uno solo
var images = mergeDicts([images, Dic_NDVI, Dic_NDMI, Dic_NDVI_Classificado, Dic_LST, Dic_MTHI,  
                         Dic_LCZ_MASCARA, Dic_MTHI_MASCARA, Dic_LST_MASCARA, Dic_NDVI_Class_MASCARA, Dic_NDVI_MASCARA]); //Dic_MOSAICO, Dic_MOSAICO_MASCARA
print("Dic_Class_UNIDOS", images)
// throw("")
// PAQUETES
var Palettes = require('users/gena/packages:palettes');
// var text = require('users/gena/packages:text');
var Palette_NDVI = Palettes.colorbrewer.RdYlGn[11];
var Palette_NDWI = Palettes.cmocean.Balance[7];
print(Palette_NDVI)
// PARAMETROS VISULIAZACIÓN
var VIS_NDVI_L8 = {
  // bands: ['NDVI'],
  min: 0,
  max: 0.7,
  palette: Palette_NDVI//['red', 'orange', 'yellow', 'green']
};
var VIS_NDWI_L8 = {
  // bands: ['TVDI'],
  min: -0.5,
  max: 0.7,
  palette: Palette_NDWI
};
// Visualization parameters for LCZ classification
var Vis_Class_LCZ = {
  min: 1,
  max: 17,
  palette: [
    '8c0000','d10000','ff0000','bf4d00','ff6600',
    'ff9955','faee05','bcbcbc','ffccaa','555555',
    '006a00','00aa00','648525','b9db79','000000',
    'fbf7ae','6a6aff'
  ]
};
var Dic_Vis ={
  "LCZ"     : Vis_Class_LCZ,
  "LCZ*"     : Vis_Class_LCZ,
  "MTHI": Vis_MTHI,
  "MTHI*": Vis_MTHI,
  "LST": Vis_LST,
  "LST*": Vis_LST,
  "NDVI"    : VIS_NDVI_L8,
  "NDVI*"    : VIS_NDVI_L8,
  "NDVI_class": Vis_NDVI_Class,
  "NDVI_class*": Vis_NDVI_Class,
  // "NDWI"    : VIS_NDWI_L8,
}
// throw("")
// Adicionar parâmetros de visualização para a classificação NDVI
var Vis_NDVI_Class = {
  min: 1,
  max: 6,
  palette: ['0000FF', 'BEBEBE', '8B4513', 'FFFF00', '00FF00', '006400']
};
// Atualizar o dicionário de visualização
// Dic_Vis["NDVI_class"] = Vis_NDVI_Class;
// // Dic_Vis["NDMI"] = Vis_NDMI;
// Dic_Vis["LST"] = Vis_LST;
// Dic_Vis["MTHI"] = Vis_MTHI;
print("Dic_Vis", Dic_Vis)
// Dictionary for city zoom levels
var dicZoom = {
  "Curitiba": 11,
  "Londrina": 10,
  "Maringa": 11,
};
// Dictionary for city centers (approximate coordinates)
var dicCenter = {
  "Curitiba": [-49.2671, -25.4295],
  "Londrina": [-51.1718, -23.3045],
  "Maringa": [-51.9381, -23.4210],
};
// Create the left map, and have it display the first image
var leftMap = ui.Map();
leftMap.setControlVisibility(false);
// Create the right map, and have it display the second image
var rightMap = ui.Map();
rightMap.setControlVisibility(false);
// Atualizar os seletores de camada para alternar as legendas
function addLayerSelector(mapToChange, position) {
  var Titulo_Label = ui.Label({
    value: 'MOSAICOS VERÃO',
    style: {
      fontWeight: 'bold',
      fontSize: '11px',
      margin: '10px 25px'
    }
  });
  var cityLabel = ui.Label({value: 'SELECIONE A CIDADE:', style: {fontSize: '10px', margin: '0px 10px'}});
  var yearLabel = ui.Label({value: 'SELECIONE O ANO:', style: {fontSize: '10px', margin: '0px 10px'}});
  var AnotMascara_Label = ui.Label({
  value: '* Produto com a Máscara Aplicada',
    style: {
      fontWeight: 'bold',
      fontSize: '10px',
      margin: '10px 5px'
    }
  });
  var ProductLabel = ui.Label({value: 'SELECIONE O PRODUTO', style: {fontSize: '10px', margin: '0px 10px'}});
  var citySelect = ui.Select({
    items: Lista_Cidades_Selec,
    onChange: function(city) {
      updateMap(city, yearSelect.getValue());
      mapToChange.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
    }
  });
  var yearSelect = ui.Select({
    items: Lista_Anos.map(String),
    onChange: function(year) {
      updateMap(citySelect.getValue(), year);
    }
  });  
  var ProductSelect = ui.Select({
    items: Lista_Produtos.map(String),
    onChange: function(Product) {
      updateMap(citySelect.getValue(), yearSelect.getValue(), Product);
      // toggleLegend(mapToChange, Product);
    }
  });
  function updateMap(city, year, Product) {
    if (city && year && Product) {
      var key = Product + "_" + city + '_' + year;
      // var Key_MinMax = '' + key
      var image = images[key];
      var Vis_Product = Dic_Vis[Product]
      mapToChange.layers().set(0, ui.Map.Layer(image, Vis_Product, key));
    }
  }
  citySelect.setValue(Lista_Cidades_Selec[0], true);
  yearSelect.setValue(Lista_Anos[Lista_Anos.length - 1].toString(), true);
  ProductSelect.setValue(Lista_Produtos[0], true);
  var controlPanel = ui.Panel({
    widgets: [Titulo_Label, cityLabel, citySelect, ProductLabel, ProductSelect, yearLabel, yearSelect, AnotMascara_Label],
    style: {
      position: position, //|| 'bottom-right',
      padding: '2px', // Reduzido de 4px para 2px
      border: '1px solid black',
      backgroundColor: 'white',
      stretch: 'horizontal',
      margin: '1px 0px', // Adicionar margem mínima entre legendas
      }
  });
  mapToChange.add(controlPanel);
  return {citySelect: citySelect, yearSelect: yearSelect, ProductSelect: ProductSelect, updateMap: updateMap};
}
var leftSelector = addLayerSelector(leftMap, 'top-left');
var rightSelector = addLayerSelector(rightMap, 'top-right');
// // Function to sync selectors
// function syncSelectors(selector1, selector2) {
//   selector1.citySelect.onChange(function(city) {
//     selector2.citySelect.setValue(city, false);
//     var year1 = selector1.yearSelect.getValue();
//     var Product1 = selector1.ProductSelect.getValue();
//     var year2 = selector2.yearSelect.getValue();
//     var Product2 = selector2.ProductSelect.getValue();
//     leftMap.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
//     rightMap.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
//     selector1.updateMap(city, year1, Product1);
//     selector2.updateMap(city, year2, Product2);
//   });
//   selector2.citySelect.onChange(function(city) {
//     selector1.citySelect.setValue(city, false);
//     var year1 = selector1.yearSelect.getValue();
//     var Product1 = selector1.ProductSelect.getValue();
//     var year2 = selector2.yearSelect.getValue();
//     var Product2 = selector2.ProductSelect.getValue();
//     leftMap.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
//     rightMap.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
//     selector1.updateMap(city, year1, Product1);
//     selector2.updateMap(city, year2, Product2);
//   });
// }
// // Sync the selectors
// syncSelectors(leftSelector, rightSelector);
// Ajustar los selectores para sincronizar solo la ciudad
function syncSelectors(selector1, selector2) {
  // Sincronizar la ciudad entre los dos mapas
  selector1.citySelect.onChange(function (city) {
    selector2.citySelect.setValue(city, false); // Actualizar el selector derecho sin disparar su evento
    leftMap.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
    rightMap.setCenter(dicCenter[city][0], dicCenter[city][1], dicZoom[city]);
    // Actualizar ambos mapas con la nueva ciudad
    var year1 = selector1.yearSelect.getValue();
    var product1 = selector1.ProductSelect.getValue();
    var year2 = selector2.yearSelect.getValue();
    var product2 = selector2.ProductSelect.getValue();
    selector1.updateMap(city, year1, product1);
    selector2.updateMap(city, year2, product2);
  });
  // Cambios en producto o año no sincronizan los mapas
  selector1.yearSelect.onChange(function (year) {
    var city = selector1.citySelect.getValue();
    var product = selector1.ProductSelect.getValue();
    selector1.updateMap(city, year, product);
  });
  selector1.ProductSelect.onChange(function (product) {
    var city = selector1.citySelect.getValue();
    var year = selector1.yearSelect.getValue();
    selector1.updateMap(city, year, product);
  });
  selector2.yearSelect.onChange(function (year) {
    var city = selector2.citySelect.getValue();
    var product = selector2.ProductSelect.getValue();
    selector2.updateMap(city, year, product);
  });
  selector2.ProductSelect.onChange(function (product) {
    var city = selector2.citySelect.getValue();
    var year = selector2.yearSelect.getValue();
    selector2.updateMap(city, year, product);
  });
}
// Sincronizar solo la ciudad entre los selectores
syncSelectors(leftSelector, rightSelector);
// Create a SplitPanel to hold the adjacent, linked maps
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in the UI root
ui.root.widgets().reset([splitPanel]);
// Link the maps
var linker = ui.Map.Linker([leftMap, rightMap]);
//////////////////////////////////////// LEGENDA HORIZONTAL BARRA
// Função para criar uma legenda horizontal
function createHorizontalLegend(params) {
  var legendPanel = ui.Panel({
    style: {
      position: params.position || 'bottom-right',
      padding: '8px',
      border: '1px solid black',
      backgroundColor: 'white',
      stretch: 'horizontal',
    },
    layout: ui.Panel.Layout.flow('horizontal'),
  });
  // Adicionar título da legenda acima da barra
  legendPanel.add(ui.Label({
    value: params.title || 'Legenda',
    style: {
      fontWeight: 'bold',
      fontSize: '11px',
      margin: '0 0 6px 0',
      textAlign: 'center',
    },
  }));
  // Criar gradiente horizontal
  var gradient = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0), // Gradiente simples
    params: {
      bbox: [0, 0, 1, 1], // Orientação horizontal
      dimensions: '100x10', // Largura x Altura
      min: 0,
      max: 1,
      palette: params.palette,
    },
    style: { stretch: 'horizontal', margin: '0 8px' },
  });
  // Painel para os rótulos
  var labelsPanel = ui.Panel({
    layout: ui.Panel.Layout.flow('horizontal'),
    widgets: [
      ui.Label({ value: params.minValue || '0', style: { margin: '0 10px', textAlign: 'center' } }),
      ui.Label({ value: params.midValue || '0.5', style: { margin: '0 60px', textAlign: 'center' } }),
      ui.Label({ value: params.maxValue || '1', style: { margin: '0 10px', textAlign: 'center' } }),
    ],
  });
  // Adicionar gradiente e rótulos à legenda
  var container = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical'),
  });
  container.add(gradient);
  container.add(labelsPanel);
  legendPanel.add(container);
  return legendPanel;
}
// Adicionar a legenda ao mapa
var horizontalLegend = createHorizontalLegend({
  title: 'NDVI',
  palette: ['red', 'orange', 'green'], // Paleta personalizada
  minValue: '0',
  midValue: '0.5',
  maxValue: '1',
  position: 'bottom-left',
});
// Adicionar a legenda ao mapa direito - NDVI
leftMap.add(horizontalLegend);
// PARA LST
// Adicionar a legenda ao mapa
var Leg_LST = createHorizontalLegend({
  title: 'LST',
  palette: ['blue', 'yellow', 'darkorange', 'red'], // Paleta personalizada
  minValue: '20',
  midValue: '35',
  maxValue: '50',
  position: 'bottom-right',
});
// Adicionar a legenda ao mapa direito
rightMap.add(Leg_LST);
// PARA MTH
// Adicionar a legenda ao mapa
var Leg_MTHI = createHorizontalLegend({
  title: 'MTHI',
  palette: ['green', 'yellow', 'red'], // Paleta personalizada
  minValue: '60',
  midValue: '70',
  maxValue: '80',
  position: 'bottom-right',
});
// Adicionar a legenda ao mapa direito
rightMap.add(Leg_MTHI);
///////////////////////////////////////////// LEGENDA DIVIDIDA POR COLUNAS
// Class color and label info.
var classInfo =[
  [ // Primeiro grupo de 10
    {name: "Compact highrise", color: "#8c0000"},
    {name: "Compact midrise", color: "#d10000"},
    {name: "Compact lowrise", color: "#ff0000"},
    {name: "Open highrise", color: "#bf4d00"},
    {name: "Open midrise", color: "#ff6600"},
    {name: "Open lowrise", color: "#ff9955"},
    {name: "Lightweight lowrise", color: "#faee05"},
    {name: "Large lowrise", color: "#bcbcbc"},
    {name: "Sparsely built", color: "#ffccaa"},
    {name: "Heavy industry", color: "#555555"}
  ],
  [ // Segundo grupo com os restantes
    {name: "Dense Trees", color: "#006a00"},
    {name: "Scattered Trees", color: "#00aa00"},
    {name: "Bush, scrub", color: "#648525"},
    {name: "Low plants", color: "#b9db79"},
    {name: "Bare rock or paved", color: "#000000"},
    {name: "Bare soil or sand", color: "#fbf7ae"},
    {name: "Water", color: "#6a6aff"}
  ]
]
// Function to create a legend entry: color and label side-by-side in a panel.
function legendEntry(info, index) {
  var color = ui.Panel({style: {
    width: '20px',
    height: '20px',
    backgroundColor: info.color,
    margin: '6px 0px 0px 0px'
  }});
  var label = ui.Label({
    value: index + '. ' + info.name,
    style: {margin: '6px 6px 0px 6px',
            fontSize: '11px'
    }
  });
  return ui.Panel({
    widgets: [color, label],
    layout: ui.Panel.Layout.flow('horizontal'),
    style: {
      stretch: 'horizontal',
      margin: '-6px 0px 0px 0px'
    }
  });
}
function Legenda_Colunas(DIC_classInfo, Titulo, Pos_Leg){
// Create a grid of legend entries with sequential numbering.
    var columns = [];
    var counter = 1; // Sequential counter
    DIC_classInfo.forEach(function(column) {
      var rows = [];
      column.forEach(function(row) {
        rows.push(legendEntry(row, counter));
        counter++; // Increment the counter for each entry
      });
      columns.push(ui.Panel(rows));
    });
    // Add the legend components grid to a parent legend panel.
    var legend = ui.Panel({
      widgets: columns,
      layout: ui.Panel.Layout.flow('horizontal'),
      style: {
        padding: '8px',
        position: 'bottom-left'
      }
    });
    // Add a title to the legend.
    var legendTitle = ui.Label({
      value: Titulo || 'Legenda',
      style: {
        fontWeight: 'bold',
        fontSize: '11px',
        margin: '0 0 8px 0',
        padding: '0',
        backgroundColor: 'rgba(255, 255, 255, 0)'
      }
    });
    var legendPanel = ui.Panel({
      widgets: [legendTitle, legend],
      style: {
        position: Pos_Leg || 'bottom-left',
        padding: '8px',
        backgroundColor: 'rgba(255, 255, 255, 0.5)'
      }
    });
return legendPanel
}
var Panel_Legenda = Legenda_Colunas(classInfo, "Legenda LCZ")
// Create a panel to contain the title and the legend.
leftMap.add(Panel_Legenda);
// throw("")
// PARA CLASS NDVI
var Dados_Leg_ClassNDVI = [
  [ // Primeiro grupo de 10
    {name: "[-0.28 - 0.015] Água",                color: "#0000FF"},
    {name: "[0.015 - 0.140] Área Construída",     color: "#BEBEBE"},
    {name: "[0.140 - 0.180] Solo Exposto",        color: "#8B4513"},
    {name: "[0.180 - 0.270] Arbustos e Gramados", color: "#FFFF00"},
    {name: "[0.270 - 0.360] Vegetação Esparsa",   color: "#00FF00"},
    {name: "[0.360 - 0.740] Vegetação Densa",     color: "#006400"},
  ]
]
var Panel_Legenda_ClassNDVI = Legenda_Colunas(Dados_Leg_ClassNDVI, "Legenda CLASS NDVI", "bottom-right")
// Create a panel to contain the title and the legend.
rightMap.add(Panel_Legenda_ClassNDVI);
var retro = [
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#ebe3cd"
      }
    ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#523735"
      }
    ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#f5f1e6"
      }
    ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#c9b2a6"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#dcd2be"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#ae9e90"
      }
    ]
  },
  {
    "featureType": "landscape.natural",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#93817c"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#a5b076"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#447530"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f5f1e6"
      }
    ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#fdfcf8"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f8c967"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#e9bc62"
      }
    ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#e98d58"
      }
    ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#db8555"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#806b63"
      }
    ]
  },
  {
    "featureType": "transit.line",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
    ]
  },
  {
    "featureType": "transit.line",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#8f7d77"
      }
    ]
  },
  {
    "featureType": "transit.line",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#ebe3cd"
      }
    ]
  },
  {
    "featureType": "transit.station",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#b9d3c2"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#92998d"
      }
    ]
  }
]
leftMap.setOptions("retro", {retro: retro})
rightMap.setOptions("retro", {retro: retro})