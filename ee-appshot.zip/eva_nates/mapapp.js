// #############################################################################
// ### 0 NOTES ###
// #############################################################################
// #############################################################################
// ### 1 VARIABLES & PARAMETERS ###
// #############################################################################
// ### USER-DEFINED ###
// aoi
var defaultZoom = '4';
var defaultCenterPoint = [9.502, 45.566];  // Lon, Lat
// dates
var defaultStartDate = '2020-01-01';
var defaultEndDate = '2020-02-01';
// misc
var titleText = 'Title goes here';
var descriptionText = 'Description goes here';
// ABOUT PANEL about_Panel_visible
// true to start visible
// false to start collapsed
var aboutPanel_visible = true;
// styling and display
// Define default vis palette:
// var palette = ['000004', '2C105C', '711F81', 'B63679', 'EE605E', 'FDAE78', 'FCFDBF'];
var magma = ['000005','080616','110B2D','1E0848','300060','43006A','57096E','6B116F','81176D','981D69','B02363','C92D59','E03B50','ED504A','F66B4D','FA8657','FBA368','FBC17D','FCDF96', 'FCFFB2']
var viridris = ['440154', '46085c', '471063', '481769', '481d6f', '482475', '472a7a', '46307e', '453781', '433d84', '414287', '3f4889', '3d4e8a', '3a538b', '38598c', '355e8d', '33638d', '31688e', '2e6d8e', '2c718e', '2a768e', '297b8e', '27808e', '25848e', '23898e', '218e8d', '20928c', '1f978b', '1e9c89', '1fa188', '21a585', '24aa83', '28ae80', '2eb37c', '35b779', '3dbc74', '46c06f', '50c46a', '5ac864', '65cb5e', '70cf57', '7cd250', '89d548', '95d840', 'a2da37', 'b0dd2f', 'bddf26', 'cae11f', 'd8e219', 'e5e419', 'f1e51d', 'fde725'];
var AI = ['black', 'blue', 'purple', 'cyan', 'green', 'yellow', 'red'];
var CH4 = ['purple','blue', 'cyan', 'yellow', 'orange', 'red'];
// ### GENERAL ###
// Define data options.
var dataInfo = {
  'Nitrogen dioxide': {
    'Near-real-time': 'COPERNICUS/S5P/NRTI/L3_NO2',
    Offline: 'COPERNICUS/S5P/OFFL/L3_NO2',
    colId: 'COPERNICUS/S5P/NRTI/L3_NO2',
    band: 'tropospheric_NO2_column_number_density',
    cloudBand: 'cloud_fraction',
    maskVal: 0.00007,
    scalar: 1e6,
    legendLabel: 'NO2 tropospheric vertical column density (μmol/m²)',
    unitsLabel: 'Tropospheric NO2 (μmol/m²)',
    visParams: {
      palette: magma,
      min: 0.0,
      max: 100.0,
    },
  },
  'Carbon monoxide': {
    'Near-real-time': 'COPERNICUS/S5P/NRTI/L3_CO',
    Offline: 'COPERNICUS/S5P/OFFL/L3_CO',
    colId: 'COPERNICUS/S5P/NRTI/L3_CO',
    band: 'CO_column_number_density',
    cloudBand: '',
    maskVal: 0,
    scalar: 1e6,
    legendLabel: 'CO vertical column density (μmol/m²)',
    unitsLabel: 'CO (mol/m²)',
    visParams: {
      palette: viridris,
      min: 0.0,
      max: 50000,
    },
  },
  'Sulphur Dioxide': {
    'Near-real-time': 'COPERNICUS/S5P/NRTI/L3_SO2',
    Offline: 'COPERNICUS/S5P/OFFL/L3_SO2',
    colId: 'COPERNICUS/S5P/NRTI/L3_SO2',
    band: 'SO2_column_number_density',
    cloudBand: 'cloud_fraction',
    maskVal: 0,
    scalar: 1e6,
    legendLabel: 'SO2 vertical column density (μmol/m²)',
    unitsLabel: 'SO2 (μmol/m²)',
    visParams: {
      palette: magma,
      min: 0.0,
      max: 1000.0,
    },
  },
  'Methane': {
  'Near-real-time': 'COPERNICUS/S5P/OFFL/L3_CH4',
    Offline: 'COPERNICUS/S5P/OFFL/L3_CH4',
    colId: 'COPERNICUS/S5P/OFFL/L3_CH4',
    band: 'CH4_column_volume_mixing_ratio_dry_air',
    cloudBand: '',
    maskVal: 1750,
    scalar: 1,
    legendLabel: 'Methane column averaged dry air mixing ratio (ppbV)',
    unitsLabel: 'Methane (ppbV)',
    visParams: {
      palette: CH4,
      min: 1700.0,
      max: 1950.0,
    },
  },
    'Formaldehyde': {
    'Near-real-time': 'COPERNICUS/S5P/NRTI/L3_HCHO',
    Offline: 'COPERNICUS/S5P/OFFL/L3_HCHO',
    colId: 'COPERNICUS/S5P/NRTI/L3_HCHO',
    band: 'tropospheric_HCHO_column_number_density',
    cloudBand: '',
    maskVal: 0,
    scalar: 1e6,
    legendLabel: 'HCHO tropospheric column density (μmol/m²)',
    unitsLabel: 'Tropospheric HCHO (μmol/m²)',
    visParams: {
      palette: AI,
      min: 0,
      max: 300,
    },
  },
  'Aerosol Index': {
    'Near-real-time': 'COPERNICUS/S5P/NRTI/L3_AER_AI',
    Offline: 'COPERNICUS/S5P/OFFL/L3_AER_AI',
    colId: 'COPERNICUS/S5P/NRTI/L3_AER_AI',
    band: 'absorbing_aerosol_index',
    cloudBand: '',
    maskVal: 0,
    scalar: 1,
    legendLabel: 'Absorbing aerosol index',
    unitsLabel: 'Absorbing aerosol index',
    visParams: {
      palette: AI,
      min: -2.0,
      max: 1.0,
    },
  }
};
var dateInfo = {
  start: {selected: ''},
  end: {selected: ''}
};
var dataSelector = ui.Select({
  items: Object.keys(dataInfo)
});
var colSelector = ui.Select({
  items: ['Near-real-time', 'Offline']
});
// Get data information - used globally in functions.
var datasetUrl = ui.url.get('dataset', 'Nitrogen dioxide');
ui.url.set('dataset', datasetUrl); // need to set in case this is the initial load.
var thisData = dataInfo[datasetUrl];
dataSelector.set({placeholder: datasetUrl, value: datasetUrl});
// Set the datatype.
var dataTypeUrl = ui.url.get('datatype', 'Near-real-time');
ui.url.set('datatype', dataTypeUrl);
thisData.colId = thisData[dataTypeUrl];
colSelector.set({placeholder: dataTypeUrl, value: dataTypeUrl});
// Get initial map bounds from the url parameter.
var initPoint = ee.Geometry.Point(defaultCenterPoint).toGeoJSONString();
var center = ui.url.get('center', initPoint);
ui.url.set('center', dataTypeUrl);
var zoom = ui.url.get('zoom', defaultZoom);
ui.url.set('center', zoom);
var startSliderDateUrl = ui.url.get('startdate', defaultStartDate);
ui.url.set('startdate', startSliderDateUrl);
var endSliderDateUrl = ui.url.get('enddate', defaultEndDate);
ui.url.set('enddate', endSliderDateUrl);
dateInfo.start.selected = startSliderDateUrl;
dateInfo.end.selected = endSliderDateUrl;
thisData.visParams.min = ui.url.get('min', 0);
thisData.visParams.max = ui.url.get('max', 100);
var currentImage; // global variable to store current image
// #############################################################################
// ### 2 FUNCTIONS ###
// #############################################################################
// ## UI
// This needs to be run on load and each time a dataset changes.
function updateStartSliderDate() {
  startDatePanel.widgets().get(1).setDisabled(true); 
  var dateRange = getMinMaxDate(); // min/max date for selected collection
  var firstDate = ee.Date(dateRange.get('firstDate'));
  var firstDateMillis = ee.Date(dateRange.get('firstDate')).millis();
  var lastDate = ee.Date(dateRange.get('lastDate'));
  var lastDateMillis = ee.Date(dateRange.get('lastDate')).millis();
  var selectedDate = ee.Date(dateInfo.start.selected);
  var selectedDateMillis = ee.Date(dateInfo.start.selected).millis();
  // check if selected date fall within possible date range, else force it
  selectedDate = ee.Date(ee.Algorithms.If(
    firstDateMillis.gt(selectedDateMillis),
    firstDate,
    selectedDate
  ));
  selectedDate = ee.Date(ee.Algorithms.If(
    lastDateMillis.lt(selectedDateMillis),
    lastDate,
    selectedDate
  ));
  var startDate = selectedDate;
  var endDate = dateInfo.end.selected;
  currentImage = compositeImages(startDate, endDate);
  Map.layers().set(0, ui.Map.Layer(currentImage, thisData.visParams, null, true, 0.7));
  ee.Dictionary({
    firstDate: firstDate.format('YYYY-MM-dd'),
    lastDate: lastDate.format('YYYY-MM-dd'),
    selectedDate: selectedDate.format('YYYY-MM-dd')
  })
  .evaluate(function(dates){
    var dateSelector = ui.DateSlider({
      start: dates.firstDate,
      end: dates.lastDate,
      value: dates.selectedDate,
      period: 1,
      style: {stretch: 'horizontal'},
      onChange: startDateHandler
    });
    startDatePanel.widgets().set(1, dateSelector);
  });
}
function updateEndSliderDate() {
  endDatePanel.widgets().get(1).setDisabled(true);
  var dateRange = getMinMaxDate(); // min/max date for selected collection
  var firstDate = ee.Date(dateRange.get('firstDate'));
  var firstDateMillis = ee.Date(dateRange.get('firstDate')).millis();
  var lastDate = ee.Date(dateRange.get('lastDate'));
  var lastDateMillis = ee.Date(dateRange.get('lastDate')).millis();
  var selectedDate = ee.Date(dateInfo.end.selected);
  var selectedDateMillis = ee.Date(dateInfo.end.selected).millis();
  // check if selected date fall within possible date range, else force it
  selectedDate = ee.Date(ee.Algorithms.If(
    firstDateMillis.gt(selectedDateMillis), 
    firstDate,
    selectedDate
  ));
  selectedDate = ee.Date(ee.Algorithms.If(
    lastDateMillis.lt(selectedDateMillis),
    lastDate,
    selectedDate
  ));
  var startDate = dateInfo.start.selected;
  var endDate = selectedDate;
  currentImage = compositeImages(startDate, endDate);
  Map.layers().set(0, ui.Map.Layer(currentImage, thisData.visParams, null, true, 0.7));
  ee.Dictionary({
    firstDate: firstDate.format('YYYY-MM-dd'),
    lastDate: lastDate.format('YYYY-MM-dd'),
    selectedDate: selectedDate.format('YYYY-MM-dd')
  })
  .evaluate(function(dates){
    var dateSelector = ui.DateSlider({
      start: dates.firstDate,
      end: dates.lastDate,
      value: dates.selectedDate,
      period: 1,
      style: {stretch: 'horizontal'},
      onChange: endDateHandler
    });
    endDatePanel.widgets().set(1, dateSelector);
  });
}
// ### MAP LEGEND SETUP ###
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
function makeLegend() {
  // Create the color bar for the legend.
  var colorBar = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: makeColorBarParams(thisData.visParams.palette),
    style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '20px'},
  });
  // Create a panel with three numbers for the legend.
  var legendLabels = ui.Panel({
    widgets: [
      ui.Label(thisData.visParams.min, {margin: '4px 8px', fontSize: '12px'}), //
      ui.Label(
          (thisData.visParams.min + ((thisData.visParams.max -  thisData.visParams.min) / 2 )), //
          {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal', fontSize: '12px'}),
      ui.Label(thisData.visParams.max, {margin: '4px 8px', fontSize: '12px'})
    ],
    layout: ui.Panel.Layout.flow('horizontal')
  });
  var legendTitle = ui.Label({
    value: thisData.legendLabel,// + " mean",// + ' n-day mean',
    style: {fontWeight: 'bold', fontSize: '12px'}
  });
  var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
  controlPanel.widgets().set(legendIndex, legendPanel);
}
// # UI Handlers
function dataSelectorHandler(e) {
  var datasetFromClick = dataSelector.getValue();
  var dataTypeFromClick = colSelector.getValue();
  ui.url.set('dataset', datasetFromClick);
  ui.url.set('datatype', dataTypeFromClick);
  thisData = dataInfo[datasetFromClick];
  thisData.colId = thisData[dataTypeFromClick];
  ui.url.set('min', thisData.visParams.min);
  ui.url.set('max', thisData.visParams.max);
  // Update map data
  updateStartSliderDate();
  updateEndSliderDate();
  // Update legend elements
  makeLegend();
}
function startDateHandler() {
  var selectedDate = ee.Date(ee.List(startDatePanel.widgets().get(1).getValue()).get(0));
  selectedDate.format('YYYY-MM-dd').evaluate(function(date) {
    ui.url.set('startdate', date);
    dateInfo.start.selected = date;
    var startDate = dateInfo.start.selected;
    var endDate = dateInfo.end.selected;
    currentImage = compositeImages(startDate, endDate);
    Map.layers().set(0, ui.Map.Layer(currentImage, thisData.visParams, null, true, 0.7));
  });
}
function endDateHandler() {
  var selectedDate = ee.Date(ee.List(endDatePanel.widgets().get(1).getValue()).get(0));
  selectedDate.format('YYYY-MM-dd').evaluate(function(date) {
    ui.url.set('enddate', date);
    dateInfo.end.selected = date;
    var startDate = dateInfo.start.selected;
    var endDate = dateInfo.end.selected;
    currentImage = compositeImages(startDate, endDate);
    Map.layers().set(0, ui.Map.Layer(currentImage, thisData.visParams, null, true, 0.7));
  });
}
Map.onClick(function(coords) {
  pointInfoPanel.clear();
  placeHolder.style().set('shown', true);
  placeHolder.setValue('Getting value...');
  var latitude = 'Latitude: ' + coords.lat.toFixed(4);
  var longitude = 'Longitude: ' + coords.lon.toFixed(4);
  var click_point = ee.Geometry.Point(coords.lon, coords.lat);
 latitude = {value: latitude, style: {fontSize: '13px'}};
 longitude = {value: longitude, style: {fontSize: '13px'}};
  //We need the layer casted to image to be able to use reduceRegion on it
  var mapValue = currentImage.reduceRegion(ee.Reducer.mean(), click_point, 100)
  .get(thisData.band + "_mean")//.aside(print)
  //Asynchronous Event for the query
  .evaluate(
      function(val) {
        if (val === null) {
          val = 'no valid measurements';
        } else {
          val = val.toFixed(4);
        }
        var mapvalueText = thisData.unitsLabel + ": " + val;
        mapvalueText= {value: mapvalueText,style: {fontSize: '13px'}};
        placeHolder.style().set('shown', false);
        pointInfoPanel.widgets().set(1, ui.Label(latitude));
        pointInfoPanel.widgets().set(2, ui.Label(longitude));
        pointInfoPanel.widgets().set(3, ui.Label(mapvalueText));
      }
    );
});
// MAP CLICK END
// ## DATA
// get min and max dates for dataset.
function getMinMaxDate() {
  var col = ee.ImageCollection(thisData.colId);
    // .filterBounds(aoi);
  var dataDateRange = ee.Dictionary(col.reduceColumns(
    {reducer: ee.Reducer.minMax(), selectors: ['system:time_start']}));
  var firstDate = ee.Date(dataDateRange.get('min'));
  var lastDate = ee.Date(dataDateRange.get('max'));
  return ee.Dictionary({firstDate: firstDate, lastDate: lastDate});
}
function compositeImages(startDate, endDate) {
  var dateFilter = ee.Filter.date(startDate, endDate);
  var col = ee.ImageCollection(thisData.colId).filter(dateFilter);
  return col.select(thisData.band).reduce(ee.Reducer.mean()).multiply(thisData.scalar);
}
// #############################################################################
// ### 3 VISUALIZATION ###
// #############################################################################
// UI
// Create an introduction panel.
var introPanel = ui.Panel([
  ui.Label({
    value: titleText,
    style: {fontSize: '24px', fontWeight: 'bold'}
  }),
  ui.Label({
    value: descriptionText,
  })
]);
var dataSelectPanel = ui.Panel({
  widgets: [dataSelector, colSelector],
  layout: ui.Panel.Layout.flow('horizontal'), style: {stretch: 'horizontal'}
});
dataSelector.onChange(dataSelectorHandler);
colSelector.onChange(dataSelectorHandler);
var dateSliderLabelWidth = '45px';
var startDateLabel = ui.Label({value: 'START:', style: {width: dateSliderLabelWidth, color: '000', fontWeight: 'bold', padding: '25px 0px 0px 0px'}});
var startSliderDate = ui.DateSlider({
  start: '2020-01-01',
  end: '2020-02-01',
  value: '2020-01-15',
  period: 1,
  style: {stretch: 'horizontal', shown: true}});
  startSliderDate.setDisabled(true);
var endDateLabel = ui.Label({value: 'END:', style: {width: dateSliderLabelWidth, color: '000', fontWeight: 'bold', padding: '25px 0px 0px 0px'}});
var endSliderDate = ui.DateSlider({
  start: '2020-01-01',
  end: '2020-02-01',
  value: '2020-01-15',
  period: 1,
  style: {stretch: 'horizontal', shown: true}});
  endSliderDate.setDisabled(true); 
var startDatePanel = ui.Panel({
  widgets: [startDateLabel, startSliderDate],
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {stretch: 'horizontal'}
});
var endDatePanel = ui.Panel({
  widgets: [endDateLabel, endSliderDate],
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {stretch: 'horizontal'}
});
//INSPECTOR PANEL START
var inspectorPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
});
var inspectorTitle = ui.Label({
  value: 'Value at Point',
  style: {margin: '4px 8px', fontWeight: 'bold', fontSize: '13px'}
});
inspectorPanel.add(inspectorTitle);
 var placeHolder = ui.Label({
    value: 'Click a point to get value',
    style: {margin: '4px 8px', fontSize: '13px'},
    });
inspectorPanel.add(placeHolder);
var pointInfoPanel = ui.Panel();
inspectorPanel.add(pointInfoPanel);
//INSPECTOR PANEL END
var panelCloseButton = ui.Button({
  label: 'Close',
  onClick: function() {
    panelOpenButton.style().set('shown', true);
    controlPanel.style().set('shown', false);
  },
  // style: {width: '95%'},
});
var panelBreak0 = ui.Panel(null, null, {stretch: 'horizontal', height: '1px', backgroundColor: '000', margin: '8px 0px 8px 0px'});
var panelBreak1 = ui.Panel(null, null, {stretch: 'horizontal', height: '1px', backgroundColor: '000', margin: '8px 0px 8px 0px'});
var panelBreak2 = ui.Panel(null, null, {stretch: 'horizontal', height: '1px', backgroundColor: '000', margin: '8px 0px 8px 0px'});
var panelBreak3 = ui.Panel(null, null, {stretch: 'horizontal', height: '1px', backgroundColor: '000', margin: '8px 0px 8px 0px'});
var legendIndex = 10;
var controlPanel = ui.Panel({
  widgets: 
  [ 
    introPanel,
    panelBreak0,
    ui.Label({value: 'Select dataset:'}),
    dataSelectPanel,
    panelBreak1,
    ui.Label({value: 'Select dates:'}),
    startDatePanel,
    endDatePanel,
    panelBreak2,
    inspectorPanel,
    ui.Panel(null, null), // legend placeholder
    panelBreak3,
    panelCloseButton,
  ],
  style: {width: '23%', margin: '10px', 'shown': aboutPanel_visible}
});
var panelOpenButton = ui.Button({
  label: 'Open Control Panel',
  onClick: function() {
    panelOpenButton.style().set('shown', false);
    controlPanel.style().set('shown', true);
  },
  style: {position: 'bottom-left', 'shown': !aboutPanel_visible}
});
// Map
// Set map properties
Map.setControlVisibility({all: false, zoomControl: true});
Map.style().set('cursor', 'crosshair');
// Set url params for map bounds.
Map.onChangeBounds(function(e) {
  ui.url.set('center', ee.Geometry.Point(e.lon, e.lat).toGeoJSONString());
  ui.url.set('zoom', e.zoom);
});
ui.root.insert(0, controlPanel);
Map.add(panelOpenButton);
// Update map data
updateStartSliderDate();
updateEndSliderDate();
// Update legend elements
makeLegend();