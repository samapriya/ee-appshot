var imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "LANDSAT/LC08/C02/T1_TOA"
    }) || ee.ImageCollection("LANDSAT/LC08/C02/T1_TOA"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -67.58204227546209,
                6.291320678948053
              ],
              [
                -67.58204227546209,
                6.1274926298291055
              ],
              [
                -67.36231571296209,
                6.1274926298291055
              ],
              [
                -67.36231571296209,
                6.291320678948053
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-67.58204227546209, 6.291320678948053],
          [-67.58204227546209, 6.1274926298291055],
          [-67.36231571296209, 6.1274926298291055],
          [-67.36231571296209, 6.291320678948053]]], null, false),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B5",
          "B4",
          "B3"
        ],
        "min": 0.036142337046681516,
        "max": 0.22467458176047783,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B5","B4","B3"],"min":0.036142337046681516,"max":0.22467458176047783,"gamma":1},
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B6",
          "B5",
          "B2"
        ],
        "min": 0.036142337046681516,
        "max": 0.22467458176047783,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B6","B5","B2"],"min":0.036142337046681516,"max":0.22467458176047783,"gamma":1},
    imageVisParam4 = ui.import && ui.import("imageVisParam4", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B5"
        ],
        "min": 0.12658162645300697,
        "max": 0.715938993904487,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B5"],"min":0.12658162645300697,"max":0.715938993904487,"gamma":1},
    imageVisParam3 = ui.import && ui.import("imageVisParam3", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B5"
        ],
        "min": 0.08266556771189809,
        "max": 0.8380359321221242,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B5"],"min":0.08266556771189809,"max":0.8380359321221242,"gamma":1},
    imageVisParam5 = ui.import && ui.import("imageVisParam5", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B5"
        ],
        "min": -0.2114403685927391,
        "max": 0.8182561388611793,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B5"],"min":-0.2114403685927391,"max":0.8182561388611793,"gamma":1},
    imageVisParam6 = ui.import && ui.import("imageVisParam6", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B5",
          "B5_1",
          "B5_2"
        ],
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B5","B5_1","B5_2"],"gamma":1};
var ColeccionLandsat=ee.ImageCollection("LANDSAT/LC08/C02/T1_TOA")
.filterDate('2021-12-06','2022-02-02')
.filterBounds(geometry)
.filterMetadata('CLOUD_COVER_LAND','Less_than',10);
print(ColeccionLandsat);
var Llanos_LS8=ee.Image('LANDSAT/LC08/C02/T1_TOA/LC08_004056_20220127');
print(Llanos_LS8);
//COMBINACIONES
//Map.addLayer (Llanos_LS8,imageVisParam,'IMG_543');
//Map.addLayer (Llanos_LS8,imageVisParam2,'IMG_652');
//NDVI
var NDVI = Llanos_LS8.expression('float (NIR-ROJO)/float(NIR+ROJO)',
{'ROJO':Llanos_LS8.select('B4'),
'NIR':Llanos_LS8.select('B5')});
//ADICIONAMOS EL INDICE NDVI AL ESPEACIO DE TRABAJO
Map.addLayer(NDVI,imageVisParam3,'NDVI');
//GNDVI
var GNDVI =  Llanos_LS8.expression('float (NIR-VERDE) / float (NIR + VERDE)',{
  'VERDE':  Llanos_LS8.select('B3'),
  'NIR': Llanos_LS8.select('B5')});
Map.addLayer(GNDVI,imageVisParam4,'GNVI');
//NBRI
var NBRI =  Llanos_LS8.expression ('float (NIR - SWIR) / float (NIR + SWIR)',{
  'SWIR':  Llanos_LS8.select('B7'),
  'NIR':  Llanos_LS8.select('B5')});
  Map.addLayer (NBRI,imageVisParam5,'NBRI');
//COMPOSICIONES
var COMPOSICION = NDVI.addBands(GNDVI).addBands(NBRI);
Map.addLayer (COMPOSICION, imageVisParam6, 'COMPOSICION')
//DESCARGA
Export.image.toDrive({
  image: COMPOSICION.select("B5","B5_1","B5_2"),
  description: 'Landsat8_descarga' ,
  scale: 30,
  region: geometry
});
//TITULO 
var TITULO_MAPA = ui.Label ({
  value: ' VISUALIZACION DE CUERPOS DE AGUA EN PUERTO CARREÑO',
  style:{
    color: 'black',
    backgroundColor: '33FFFF',
    fontFamily: 'serif',
    fontSize:'20px',
    fontWeight:'bold'
  }
});
TITULO_MAPA.style().set('position', 'top-left');
Map.add(TITULO_MAPA);
//DESCRIPCION
var DESCRIPCION = ui.Label({
  value:'Descripcion:' +
  'Esta aplicacion fue creada para buscar,' + 
  'carcaterizar y ubicar los cuerpos de agua' + 
  'en la region de la orinoquia, especialmente'+
  'en los cuerpos de agua de la jurisprudencia'+
  'del municipio de Puerto Carreño.'+
  'Las imagenes utilizadas corresponden al sensor'+
  'LANDSAT 8. Se realizo la composicion de indices'+
  'en la que se usaron los indices GNDVI, NDVI Y NBRI.'+
  'Como resultado podemos apreciar de color azul'+
  'los cuerpos de agua y su cauce, de color verde'+
  'se visaulizan las coberturas de vegetacion y urbana,'+
  'finalmente de colores pardos claros observamos el suelo expuesto',
  style:{
    fontSize: '12px',
    fontWeight: 'bold',
  }
});
DESCRIPCION.style().set('position', 'bottom-right');
Map.add(DESCRIPCION);