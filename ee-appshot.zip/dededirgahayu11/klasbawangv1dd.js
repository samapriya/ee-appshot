var S1_GRD = ui.import && ui.import("S1_GRD", "imageCollection", {
      "id": "COPERNICUS/S1_GRD"
    }) || ee.ImageCollection("COPERNICUS/S1_GRD"),
    Kec_Brebes = ui.import && ui.import("Kec_Brebes", "table", {
      "id": "projects/ee-dededirgahayu11/assets/Shp/AOI_Kec1_Brebes"
    }) || ee.FeatureCollection("projects/ee-dededirgahayu11/assets/Shp/AOI_Kec1_Brebes"),
    LokSur_Bawang_Jul2023_Brebes = ui.import && ui.import("LokSur_Bawang_Jul2023_Brebes", "table", {
      "id": "projects/ee-panganpusfatja2/assets/Shp/LokSur_Bawang_Jul2023_Brebes"
    }) || ee.FeatureCollection("projects/ee-panganpusfatja2/assets/Shp/LokSur_Bawang_Jul2023_Brebes"),
    S2_Stk_Bawang_Jul23 = ui.import && ui.import("S2_Stk_Bawang_Jul23", "table", {
      "id": "projects/ee-salmanddd14/assets/Shp/S2_Stk_Bawang_Jul2023_Brebes"
    }) || ee.FeatureCollection("projects/ee-salmanddd14/assets/Shp/S2_Stk_Bawang_Jul2023_Brebes");
/* Cek Distribusi Samples per Kelas Train Samples
  by Dr Dede Dirgahayu 
*/ 
var Sav = require('users/dededirgahayu11/Fungsi:DD_IO.js'); 
var Klas = require('users/dededirgahayu11/Fungsi:DD_Klas.js');
var GImg = require('users/dededirgahayu11/Fungsi:DD_GetImg.js');
var Adm = require('users/dededirgahayu11/Fungsi:DD_Admin20.js');
var Geom = require('users/dededirgahayu11/Fungsi:DD_Geom.js');
var Leg = require('users/dededirgahayu11/Fungsi:DD_Legend.js');
var PTgl = require('users/dededirgahayu11/Fungsi:DD_PrdTglMltYear.js');
var Graf = require('users/dededirgahayu11/Fungsi:DD_Grafik2.js');
var GUI = require('users/dededirgahayu11/Fungsi:DD_UI.js');
//##########################################################
var FC1 = LokSur_Bawang_Jul2023_Brebes,FC,FC_Pros=ProFC(FC1),Trn_Samps,Data,Tgl_R,Img_Pil, ImgC,
    RadBuf=15,FC_Buf, FC_n,FC_Pil,Flt_Par=[],Lst_Fea, LstImgs_Foto,Lst_LatLon,Lst_IDLok, Point_Pil,Idx_Pil; 
  FC = FC1.filter("Type=='Point'"); FC_Buf = FC1.filter("Type=='Poly'") ;
    print('Points',FC,'Buf',FC_Buf);
LstImgs_Foto = LstProNU(FC,'Foto_Name').getInfo(); Lst_Fea = LstObj(FC);
Lst_IDLok = LstProNU(FC,'ID_Lok').getInfo(); FC_n = JumEl(FC);
Lst_LatLon = LstPros(FC,['Lat','Lon'],",").getInfo();
print('Jum Rec = '+FC_n ,'Pros',FC_Pros,'FC_Buf',FC_Buf,Lst_LatLon);
var i,BtsUmur_Fase = [-1,20,40,64,90,120],
    Nam_Kls=['Air','Veg Awal','Veg-1','Veg-2','Gen-1','Gen-2','Bera','Non Padi'],
    Wrn_Kls=['blue','cyan','00ff00','00aa00','aaaa00','yellow','brown','darkgray'];
Tgl_R = ['2023-03-01','2023-09-30'],LstPrdTgl15 = PTgl.Prd15d(2023,3,2023,9);
print('15d',LstPrdTgl15);
var NCC_S1 = {bands:['API','RPI','NDPI'],min:[0.01,0.01,0.1],max:[0.05,0.4,0.7]},Vis_Pil,Clp_Crp,
    NCC_Opt = {bands:['Swir1','Nir','Green'],min:[0.01,0.01,0.1],max:[0.45,0.55,0.33]};
Data = GImg.PilSat('S2k',Tgl_R,FC_Buf); Vis_Pil= NCC_Opt; ImgC=Data.Coll;
Img_Pil = ee.Image(Data.Imgs.get(0)); Clp_Crp = FC_Buf.filter('Id < 11');
//print('Clp_Crp',Clp_Crp);
var Tgl,Redu,Redu_Mean=ee.Reducer.mean(),Redu_Std=ee.Reducer.stdDev(),Redu_MeanStd,FC_Stk;
Redu_MeanStd = Redu_Mean.combine(Redu_Std,null,true); Redu = Redu_MeanStd;
Tgl = ImgC.first().get('system:time_start');
print('n ImgC awal = ' + JumEl(ImgC));
FC_Stk = S2_Stk_Bawang_Jul23;
/*
var FC_Stk = StkImgRegs(ImgC,Clp_Crp,Redu); // Cek yg clear dulu
print('FC_Stk',FC_Stk);
var Lst_Fea1,Lst_Fea2, Seq,FC2_Stk,nStk; 
 Clp_Crp = FC_Buf.filter('Id >= 11');
FC2_Stk = StkImgRegs(ImgC,Clp_Crp,Redu);
FC_Stk = FC_Stk.merge(FC2_Stk); Sav.SaveFeat2Ast(FC_Stk,'S2_Stk_Bawang_Jul2023_Brebes','Shp');
nStk=JumEl(FC_Stk);
Lst_Fea1=FC_Stk.toList(FC_Stk.size()); Seq=ee.List.sequence(0,nStk-1);
print('Stks',FC_Stk);
var ImgC1 = CekDtClr(ImgC),nClr= JumEl(ImgC1);
 print('Data Clear = '+nClr,ImgC1);
print('Hit Stk');
//ImgC1 = CekDtClr(ImgC); nClr= JumEl(ImgC1); 
*/
print('FC_Stk : ' + JumEl(FC_Stk),FC_Stk.limit(5000));
var Stk_Qual,Img_Qual= ImgC.qualityMosaic('NDVI').set('system:time_start',Tgl);
print('Img_Qual',Img_Qual);
var Shp_Larang = Geom.GetShpAdm('Des').filter('KECAMATAN=="LARANGAN"'),
    Shp_Wanasari = Geom.GetShpAdm('Des').filter('KECAMATAN=="WANASARI"'),Shp_Pil_Kec;
Shp_Pil_Kec = Shp_Larang.merge(Shp_Wanasari); print("Shp_Pil_Kec",Shp_Pil_Kec);
Map.setOptions('HYBRID');
Map.centerObject(FC.first(),19); 
SetMap(0,Img_Qual.clip(Shp_Pil_Kec),Vis_Pil,'S2 Temp Komposit ' + Tgl_R,0);
SetMap(1,FC2Img(FC_Buf,1,2),{palette:'darkcyan'},'Buffer '+ RadBuf + ' m',1,0.5);
SetMap(2,FC,{color:'magenta'},'Points Bawang');
SetMap(3,FC2Img(Kec_Brebes,1,2),{palette:'orange'},'AOI Kec-1');
SetMap(4,Point_Pil,{color: 'red'},'Lokasi Terpilih');
var Judul = "IDENTIFIKASI TANAMAN BAWANG MERAH MENGGUNAKAN DATA SATELIT PENGINDERAAN JAUH",
    Inv = "Creator: Dr Dede Dirgahayu Domiri, M.Si; PRGI, OREI-BRIN" ;
var Lbl_App = Lbl(Judul,'darkblue',15,'center','bold','88ffff','1px solid red',4),Lbl_Inv = Lbl(Inv,'darkred',11,'center','bold');
var Sel_Lok = Sel(Lst_IDLok,'Lokasi Sampel'),Lbl_Stk=Lbl('','red',11,'center'),Lbl_EVI=Lbl('Mean,CoeVar EVI','green',11);
var Pnl_Stk = Pnl([Lbl_EVI,Lbl_Stk],'v','120px',null,'1px solid blue'),Pnl_Main = Pnl([Lbl_App,Lbl_Inv,Sel_Lok],'v');
Lbl_EVI.style().set('margin','2px'); Lbl_Stk.style().set('margin','2px');
Map.add(Pnl_Stk); ui.root.insert(0,Pnl_Main);
Sel_Lok.onChange(function(Lok){
  Idx_Pil = Lst_IDLok.indexOf(Lok); //if(Idx_Pil<10)Shp_Pil_Kec=Shp_Larang; else Shp_Pil_Kec=Shp_Wanasari;
  Point_Pil = ee.Feature(Lst_Fea.get(Idx_Pil));
  print('Point_Pil',Point_Pil);
  Map.centerObject(Point_Pil,20); 
  SetMap(4,Point_Pil,{color:'red'},'Lokasi Terpilih');
  Lbl_Stk.setValue("Get EVI CoeVar ...");
  var Val,Stk =  FC_Stk.filter("ID_Lok== '"+Lok +"'").first();
  Val = ee.List([Stk.get('EVI_mean'),Stk.get('EVI_CoeV')]);
 // print('Val',Val);
  Val.evaluate(function (stk){
    Lbl_Stk.setValue(stk[0].toFixed(3) + ',' + stk[1].toFixed(1)+'%');
  });
});
function StkImg1(img,redu,geom,Sc) {
  Sc = Sc || img.select(0).projection().nominalScale();
  var Bnds = img.bandNames().getInfo();
  var stk = img.reduceRegion(redu,geom);
  return stk;
}
function AddCoeVars(stk){
  var i,n,FMean = stk.select('*.mean'),FStd = stk.select('*.stdDev'),Coe;
  n = FMean.size().getInfo(); 
  for(i=0; i < n; i++) { Coe = ee.Number(FStd.get(i)).divide(FMean.get(i))     }
  return 1;
}
//************ EKSTRAK
function AddEVICoeV(stk){
  var std = stk.get("EVI_stdDev"),mean =stk.get("EVI_mean");
  var CoeV = ee.Number(std).divide(mean).multiply(100).format('%.1f'); 
  return stk.set('EVI_CoeV',ee.Number.parse(CoeV));
}
function StkImgReg(img,FC,redu,Bnds_CoeV){ Bnds_CoeV = Bnds_CoeV || 'EVI';
  var Tgl,Stk,Redu,CoeV,mean,std;
  Tgl = img.date().format('YYYY-MM-dd HH:MM'); 
  Tgl = ee.List(Tgl.split(' ')); Tgl = ee.String(Tgl.get(0)).cat('T').cat(Tgl.get(1));
  redu = redu || ee.Reducer.mean();
  if(redu=='MeanStd') Redu = ee.Reducer.mean().combine(ee.Reducer.stdDev(),null,true);
  else if(redu=='minMax')Redu = ee.Reducer.minMax(); else if(redu=='Mean') Redu = ee.Reducer.mean();
  else if(redu=='Std') Redu = ee.Reducer.stdDev(); else Redu = redu;
  Stk = img.reduceRegions(FC,Redu).map(AddEVICoeV); 
  Stk= AddImgDt(Stk,Tgl);
return Stk;
  }
function AddImgDt(St,Tgl){
  St = St.map(function(s){return s.set('Img_Date',Tgl)}); return St;
}
function StkImgRegs(ImgC,FC,redu,Bnds_CoeV) { Bnds_CoeV = Bnds_CoeV || 'EVI';
  var i,Tgl,img,Redu,Stk,Stks,n=JumEl(ImgC), Imgs = ImgC.toList(n); redu = redu || ee.Reducer.mean();
  if(redu=='MeanStd') Redu = ee.Reducer.mean().combine(ee.Reducer.stdDev(),null,true);
  else if(redu=='minMax')Redu = ee.Reducer.minMax(); else if(redu=='Mean') Redu = ee.Reducer.mean();
  else if(redu=='Std') Redu = ee.Reducer.stdDev(); else Redu = redu;
  img=ee.Image(Imgs.get(0)); Stks = StkImgReg(img,FC,Redu); 
  for (i=1; i < n; i++) {img=ee.Image(Imgs.get(i)); 
  Stk = StkImgReg(img,FC,Redu); Stks = Stks.merge(Stk) }
  return Stks;
}
function Img2Tgl(img) {
  var Tgl = img.date().format('YYYY-MM-dd HH:MM');
  Tgl = ee.List(Tgl.split(' ')); Tgl = ee.String(Tgl.get(0)).cat('T').cat(Tgl.get(1));
  return Tgl;
}
function AddTgl(img) {
  var Tgl = ee.Image(img).date().format('YYYY-MM-dd HH:MM');
  Tgl = ee.List(Tgl.split(' ')); Tgl = ee.String(Tgl.get(0)).cat('T').cat(Tgl.get(1));
  return img.set('Img_Date',Tgl);
}
function AddCoeVar(Fc_stk,BndCoeV){ BndCoeV = BndCoeV || 'EVI';
  var Lst_Stk = Fc_stk.toList(Fc_stk.size());
  Fc_stk = Lst_Stk.map(function(stk) { stk= ee.Feature(stk);
  var std = stk.get(BndCoeV + "_stdDev"),mean =stk.get(BndCoeV + "_mean");
  var CoeV = ee.Number(std).divide(mean).multiply(100).format('%.1f'); 
  return stk.set(BndCoeV + '_CoeV',ee.Number.parse(CoeV)) });
 return ee.FeatureCollection(Fc_stk);
  }
function CekDtClr(ImgC){
  var LstImgs = ImgC.toList(ImgC.size());
  ImgC = ee.ImageCollection(LstImgs.map(CekEVI)).filter("EVI_mod != 0");
  return ImgC;
}
function CekEVI(img){ // img diclip dulu
  var img2 = ee.Image(img).select('EVI').clip(Clp_Crp).unmask();
  //var Rek = img2.expression('v > 0 ? 1:0',{v:img2});
  var Stk = StkImg1(img2,ee.Reducer.mode(),Clp_Crp).get('EVI') ; //.reduceColumns(ee.Reducer.mode());
  //print('Stk',Stk);
  return ee.Image(img).set('EVI_mod',Stk);
}
//&&&&&&&&&&&&&&&&
function JumEl(ObjArr,Opsi) { Opsi = Opsi || 0;
  if(Opsi > 0) return ee.List(ObjArr).length().getInfo(); else return ObjArr.size().getInfo();
}
function LstProNU(FC,Pro) { // List Properties FeatColl, yg berulang dijadikan 1
  return FC.aggregate_array(Pro).distinct();
}
function LstPro(Fc,Pro) { //List Properties FeatColl apa adanya
  var Lst,LstFea = Fc.toList(Fc.size());
  Lst = LstFea.map(function(f) {
    return ee.Feature(f).get(Pro);
  });
  return Lst; 
  }
function LstPros(Fc,Pros,Pemisah) { //List Properties FeatColl apa adanya
  var Lst,i,JumPro,Pro2,LstFea = Fc.toList(Fc.size());
  JumPro = JumEl(Pros,1); Pemisah = Pemisah || "_";
  Lst = LstFea.map(function(f) { Pro2 = ee.String(ee.Feature(f).get(Pros[0]));
  for(i=1; i < JumPro; i++) {Pro2 = Pro2.cat(Pemisah).cat(ee.Feature(f).get(Pros[i])) }
    return Pro2;
  });
  return Lst; 
  }
function ProFC(FC){
  return FC.first().propertyNames().getInfo();
}
//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
function LstObj(Obj){ return Obj.toList(Obj.size()) }
function LstImgsInfo(ImgCol,Fmt) { Fmt = Fmt || 'YYYY-MM-dd HH:MM:ss';
   var Info,Tgl,Tgls,Id,Ids,Img,Fmts,Imgs = LstObj(ImgCol);
   Tgls = Imgs.map(function(im){
     Img = ee.Image(im); Tgl =  Img.date().format(Fmt);
    return Tgl;
   });
   Ids = Imgs.map(function(im){
     Img = ee.Image(im); Id = Img.id();
     return Id;
   }); 
  return [Tgls,Ids];
}
function GetLstImgs(LstImgs,Idx,Opsi) {
  var Img = ee.Image(LstImgs.get(Idx));
  if(Opsi=='Tgl') return Img.date().format('YYYY-DD-mm');
  else if(Opsi=='Id') return Img.id();
  else return Img;
}
function LstIdFea(FC) {
  var Lst = FC.toList(FC.size()),Ids;
  Ids = Lst.map(function(l){
    return ee.Feature(l).id();
  }); return Ids;
}
function FC2Img(Fc,Warna_Pro,Tebal) { // FeatCol -> Img OutLine atw Poligon terIsi
 var Img = ee.Image().toByte(); // Warna_Pro : 1,2,4 ... atw Property FC numeric
 var Par = {featureCollection : Fc, color : Warna_Pro || 0, 
    width : Tebal   || null  }; // Null : fill
 return Img.paint(Par);
 }
function SeqArr(ValMax,s1){ s1=s1||0;
  return ee.List.sequence(s1,ValMax).getInfo();
}
//$$$$$$$$$$$$ SAMPLES
function JumSamp(FC,Lst_Umur,ProUmur,ProVal) {
ProUmur = ProUmur || 'UMUR' ; ProVal = ProVal || 'RPI';
var LstJumSamp = Lst_Umur.map(function(u){
  var Flt = "UMUR == " + u;
  var FC_Pil1 = FC.filter(Flt).sort('UMUR');
  var Mean_RPI = FC_Pil.aggregate_mean('RPI'),
      Std_RPI = FC_Pil1.aggregate_sample_sd('RPI'),
      CoeVar_RPI = ee.Number(Std_RPI).divide(Mean_RPI).multiply(100).format('%.2f');
  var n_CoeVar = ee.String('' + u).cat(',').cat(FC_Pil1.size()).cat(',').cat(Mean_RPI.format('%.3f')).cat(',').cat(CoeVar_RPI);
  return n_CoeVar;
}); return LstJumSamp;
}
function Csv2FC(Csv,ProLon,ProLat,ProsKet,Ops,RadBuf){ Ops=Ops || 'Point'; 
  var FC,Point,Pros,Lon,Lat,Lst_Id,Id,No,Lst = Csv.toList(Csv.size());
  Pros = Csv.first().propertyNames(); Lst_Id = LstIdFea(Csv);
  FC = Lst.map(function (f){ Id = Lst_Id.indexOf(ee.Feature(f).id());
    No = ee.Algorithms.If(Id.lt(9),ee.String('0').cat(Id.add(1)),Id.add(1));
    var Ket,Fea,Undef = ee.String(ee.Feature(f).get(ProLon));
   Ket = ee.String(No).cat('_').cat(ee.Feature(f).get(ProsKet[0]));
   Lon = ee.Algorithms.If(Undef.equals('#N/A'),0,ee.Number.parse(ee.Feature(f).get(ProLon)));
    Undef = ee.String(ee.Feature(f).get(ProLat));
   Lat = ee.Algorithms.If(Undef.equals('#N/A'),0,ee.Number.parse(ee.Feature(f).get(ProLat)));
  if(ee.Number(Lon).neq(0) || ee.Number(Lat).neq(0))Point = ee.Feature(ee.Geometry.Point([Lon,Lat])).copyProperties(ee.Feature(f),Pros);
    if(Ops != 'Point') {Fea = ee.Feature(Point.geometry().buffer(RadBuf)).copyProperties(ee.Feature(f),Pros); 
      Fea = Fea.set('Area_m2',ee.Feature(Fea).area()) } else Fea = Point;
    return Fea.set('ID_Lok',Ket);
  }); return ee.FeatureCollection(FC);
}
function SetMap(NoLyr,Img,VisPar,KetLyr,OnOf,Opac) {
  return Map.layers().set(NoLyr,ui.Map.Layer(Img,VisPar,KetLyr,OnOf,Opac));
} 
//&&&&&&&&&& GRAFIK
function Grf_ImgSer(ImgCol,Bnds,Sc,Geom,Redu,Judul,Warna,Typ) {
Redu = Redu || ee.Reducer.mean() ; Judul = Judul || 'Time Series Data ';
Typ = Typ || Grf_Typ[1];
var chart = ui.Chart.image.series({
  imageCollection: ImgCol.select(Bnds),
  region:  Geom , //Point.buffer(0.5*Sc),
  reducer: Redu || ee.Reducer.mean(),
  scale: Sc
})//.setChartType('LineChart')
//.setSeriesNames(Bnds)
;
var Grf_Par = {title: Judul,
    //lineWidth: 3,
      //    colors: Warna || ['green','brown','orange','red','magenta'],
     //     curveType: 'function'
        } ;
return chart.setOptions(Grf_Par);
}
function Grf_Spc(img,sc,lblx,regs,pro,redu,Judul,HTitle,VTitle,Warna){
  return Graf.Grf_Spc(img,sc,lblx,regs,pro,redu,Judul,HTitle,VTitle,Warna);
}
//$$$$$$$$$$$$ Simple GUI
function Lbl(Txt,Warna,Siz,Algn,Tebal,WarBG,Bord,Pad) { 
 // return ui.Label(Txt,{color:Warna|| 'blue',fontSize:(Siz + 'px') || '11px',fontWeight: Tebal });
 return GUI.Lbl(Txt,Warna,Siz,Algn,Tebal,WarBG,Bord,Pad);
}
function TB(Txt,PH,Lebar) { PH = PH || " ";
Lebar = (Lebar + 'px') || '85px';
var Tb = ui.Textbox({placeholder: PH,value: Txt});
Tb.style().set({color:'darkblue',width : Lebar,fontSize:'10px'});
return Tb;
  }
//ui.Select(items, placeholder, value, onChange, disabled, style)
function Sel(itm,PH) {
  return ui.Select(itm,PH);
}
//ui.Panel(widgets, layout, style)
function Pnl(Wgt,Flw,Lebar,Tinggi,Bord){ if(Flw=='h')Flw = 'horizontal'; else Flw = 'vertical';
  Flw = Flw || 'vertical'; Lebar = Lebar ||'275px'; Tinggi = Tinggi ||null;
  return ui.Panel({widgets: Wgt,layout : ui.Panel.Layout.flow(Flw),style : {width:Lebar,height:Tinggi,border:Bord || '3px solid red'}});
}
//ui.Button(label, onClick, disabled, style, imageUrl)
function Btn(Lbl,Warna) {
  var Gui = ui.Button(Lbl); Gui.style().set({color : Warna || 'red',fontWeight :'bold'});
  return Gui;
}
function Shw(UI,Ops) { Ops = Ops || true;
  return UI.style().set({shown : Ops});
}
function CBx(label,val,Warna,Siz) {
  return ui.Checkbox(label || '', val || false,{color : Warna,fontSize: (Siz + 'px') || '12px'});
  }
function StyUI(UI,Warna,Siz,Ltr,Alg,Tebal,Bord,Pad) { // Pengaturan Style
  return UI.style().set({color : Warna || 'blue',fontSize:Siz + 'px' || '12px',
      backgroundColor:Ltr || 'white',fontWeight: Tebal || 'normal',textAlign : Alg || 'left'
      ,border : Bord || '',padding: Pad || '' });
}