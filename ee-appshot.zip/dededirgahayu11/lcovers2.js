var L8_SR = ui.import && ui.import("L8_SR", "imageCollection", {
      "id": "LANDSAT/LC08/C01/T1_SR"
    }) || ee.ImageCollection("LANDSAT/LC08/C01/T1_SR"),
    S2_SR = ui.import && ui.import("S2_SR", "imageCollection", {
      "id": "COPERNICUS/S2_SR"
    }) || ee.ImageCollection("COPERNICUS/S2_SR"),
    S1_GRD = ui.import && ui.import("S1_GRD", "imageCollection", {
      "id": "COPERNICUS/S1_GRD"
    }) || ee.ImageCollection("COPERNICUS/S1_GRD"),
    DKI_No1000 = ui.import && ui.import("DKI_No1000", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                106.68197091332874,
                -6.074391697701958
              ],
              [
                106.68197091332874,
                -6.376292182590916
              ],
              [
                106.97460360666486,
                -6.376292182590916
              ],
              [
                106.97460360666486,
                -6.074391697701958
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[106.68197091332874, -6.074391697701958],
          [106.68197091332874, -6.376292182590916],
          [106.97460360666486, -6.376292182590916],
          [106.97460360666486, -6.074391697701958]]], null, false),
    Pmk17Bgn_DKI = ui.import && ui.import("Pmk17Bgn_DKI", "table", {
      "id": "users/salmanddd14/shp/Pmk17Bgn_DKI"
    }) || ee.FeatureCollection("users/salmanddd14/shp/Pmk17Bgn_DKI"),
    Indo10_Prv = ui.import && ui.import("Indo10_Prv", "table", {
      "id": "users/salmanddd14/shp/Indo10_Pv"
    }) || ee.FeatureCollection("users/salmanddd14/shp/Indo10_Pv"),
    Indo10_Kab = ui.import && ui.import("Indo10_Kab", "table", {
      "id": "users/salmanddd14/shp/Indo10_Kb"
    }) || ee.FeatureCollection("users/salmanddd14/shp/Indo10_Kb"),
    Log_BRIN8 = ui.import && ui.import("Log_BRIN8", "image", {
      "id": "users/dededirgahayu11/Foto/Log_BRIN_LPN_WRI"
    }) || ee.Image("users/dededirgahayu11/Foto/Log_BRIN_LPN_WRI");
// *** LAND COVER CLASSIFICATION USING Landsat-8 & SENTINEL-2
//$$$$$$$ Created By Dr Ir Dede Dirgahayu Domiri, M.Si 
// *** LAND COVER CLASSIFICATION USING Landsat-8 & SENTINEL-2
//$$$$$$$ Created By Dr Ir Dede Dirgahayu Domiri, M.Si 
var Waktu = require('users/salmanddd14/AFungsi_1:Waktu.js');
var GUI = require('users/salmanddd14/AFungsi_1:GUI_GEE.js');
var Citra = require('users/salmanddd14/AFungsi_1:OlhCitra.js');
var Area = require('users/salmanddd14/AFungsi_1:AreaName.js');
var Str = require('users/dededirgahayu11/Fungsi:DD_String.js');
var FTxt = require('users/dededirgahayu11/Fungsi:DD_FeaText.js');
var Grid_Indo_1 = FTxt.GridIndo_1(); 
var Ekstrak = require('users/dededirgahayu11/Fungsi:DD_Ekstrak.js');
var CMsk = require('users/dededirgahayu11/Fungsi:DD_CMask.js');
var Radar = require('users/dededirgahayu11/Fungsi:DD_Radar_ed.js'); 
var Tmb_Log8WRI = Img2Thumbz(Log_BRIN8,880,322,0.25); 
// Awal Program center DKI
Map.setCenter(106.846,-6.2238,9); 
var Thn1,Thn,Bln,Tgl,Tgl_Prd=[],Pd,Prd,Prd1,IdxPrd,ThnT,BlnT,TglT,Judul,Periode,Tgl_Range,
    PrdList,PrdList1,i,j,k,Img_S1,Img_S2,NamPrv,BtsPrv,BtsArea,Shp,NamPrvPil,RGB_S2,Build_S2,SlopMsk_BU,
    RGB_L8,L8,S2,S1,Shp_Kab,VisRGB,Air_Th,Bera_Th,Veg_Th,Mask,Build_S2,Build_L8,Idx_S2,Build_L8,RunPros=1,
    Trend,AOI,Pilih,MaxPd,NamPrvPil,SelDate,DateSelect,WaterBare,Bare,Komposit,Idx_L8,ImgLereng,List_S2,S2_VRT
;
exports.S2_Data = function() { return S2;  }
exports.RGBS2_Data = function() { return RGB_S2;  }
var Sawit_Kls = ee.ImageCollection('BIOPAMA/GlobalOilPalm/v1')
.select('classification').mosaic();
var mask = Sawit_Kls.neq(3); mask = mask.where(mask.eq(0), 0);
Sawit_Kls = Sawit_Kls.updateMask(mask);
var ViS_SwtKls = {min:1,max:3,palette:['green','88ff00', 'yellow'] }
var WADMPR = Area.NamProv(1), Pulau_Prv = Area.PulauProv(), PilPrv = Area.PilihProv(),Bts_Plu=Area.BatasPlu();
var Arr_NamPrv = FTxt.ListObjPro(Indo10_Prv.sort('PRV_ID'),'NAMA_PROV'); 
print('Arr_NamPrv',Arr_NamPrv);
var MeanEVI = 0.561,StdEVI= 0.108; 
var Nama_Fase_Kls = ['Water','Veg1','Veg2','Gen1','Gen2','Bare','Non Paddy/Data'];
var Fase_palette = ['0000ff','88FF00','00aa00','eedd00','ffff44','d28d4f','aaaaaa'] ;
var VisFase1 = {min:1,max:8,palette:['blue','88ff00', 'green','888800', 'yellow','ffddaa','red','dedede']};
var VisFase = {min:1,max:7,palette:Fase_palette};
var SCL_Kls = ['Water Body','Bare,Build Up Land','Vegetation (Oil Palm)'], // 6,5,4
SCL_Kls1 = ['Water Body','Bare land','Build Up','Vegetation (Oil Palm)'];
var LCover_palette1 =['0088ff','d28d4f','10d22c'], LCover_palette =['0088ff','ff8800','ff0000','48ff48']  ;
var Vis_SCL = {min:1,max:11,palette :['ff0004','868686','774b0a','48ff48',
'ff8800','0088ff','818181','c0c0c0','f1f1f1','bac5eb','52fff9'] };
// Par Display
var VisRGB1_S1 = {min:[-12.23,-9.19 ,4.54],max :[-1.55,-4.89,9.54]}; //VV_Lee,VH-VV,VV-VH
var VisRGB_S1 = {min:[-12.23,-9.19 ,1.58],max :[-1.55,-4.89,5.53]}; //VV_Lee,VH-VV,VV-0.75*VH
var VisRGB_S2 = {bands:['B11','B8','B4'],min:[0.08,0.14,0.01],max :[0.29, 0.36,0.14]};
var VisRGB_L8 = {bands:['B6','B5','B4'],min:[0.06,0.12,0.01],max :[0.29, 0.38,0.14]};
var Bnd_S2 = ['B.*','NDBI','EVI','NDWI'],Bnd_L8 = Bnd_S2,
Bnd_S2k = ['B.*','NDBI','EVI','NDWI','SCL'] // SR terkoreksi atmosfir
;
var Bnd_S1 = ['VV_Cor','VH-VV','VV-VH','MeanBS','VH_Cor','NDPI'],
BndRGB_S1 = ['VV_Cor','VH-VV','VV-VH'];
//Batas Prov
var Bts_Prv = Area.BatasPrv(),Bts1Prv;
AOI = ee.Geometry.Rectangle(Bts_Prv[12]); // AOI def = Jawa Barat
var i,ft,NamProv,PrvId,ListProv = [], Jam,HariniTxt,TglRange=[],TglSEt ;
var TglBln20,Start_Date,End_Date,FiltDate,TglS,TglE,Fmt = 'YYYY-MM-dd',Fmt2 = 'YYYY-DDD';
End_Date = ee.Date(Date.now()).format(Fmt); Start_Date = ee.Date(End_Date).advance(-2,'year').format(Fmt);
TglS = Start_Date.getInfo(); TglE = End_Date.getInfo();  
 Thn = ee.Date(End_Date).get('year').getInfo() ; Thn1 = Thn-2; 
TglSEt = TglS + "," + TglE;  
Prd = Waktu.TglPrd(Thn,Pd,1);PrdList = Waktu.TglPrd(Thn,Pd,2);
var Pulau = {'Sumatera':1,'Jawa_Bali':2,'NTB_NTT':3,'Kalimantan':4,'Sulawesi':5,'Maluku':6,'Papua':7},
Nama_Pulau = ['Sumatera','Jawa_Bali','NTB_NTT','Kalimantan','Sulawesi','Maluku','Papua'],NamaPulau,
Plu,PluId
;
// Deteksi BuildUp berdasrkan EVI,NDBI & Lereng. Data Sentinel level-2A sdh ada Mask Air,Bare & Vegetasi
var ThBuild_L8 = -0.101,ThBuild_S2 = -0.055,Slope_BU = 5.0; 
// Buat GUI
var Judul = 'SENTINEL for AGRICULTURAL CROP',
Author = 'Inventor : Dr Dede Dirgahayu, Pusfatja,LAPAN-BRIN',
Members = 'Members: Bukti Bagja, Chandra Irawadi Wijaya, Fajri Ramdhani, Edwine Setia P'; 
//Author2 = 'Pusfatja LAPAN & WRI Indonesia'; // margin 42px
Judul = 'SENTINEL for OIL PALM CLASSIFICATION';
var TB_Thn = GUI.TxtBnm(TglSEt,'Start,End Date',10,'blue',100,150,''),
    TB_BuildUpS2 = GUI.TxtBnm(ThBuild_S2,'Treshold for BuildUp S2',10,'red',30,55,''),
    TB_BuildUpL8 = GUI.TxtB(ThBuild_L8,'Treshold for BuiUp L8',10,'green','-33px 10px 5px 65px',30,55,''),
    Lbl_Th = GUI.Lbl('Treshold Build-Up S2,L8',12,'blue','-33px 10px 5px 125px','bold','left'),
    Lbl_App = GUI.Lblnm(Judul,15,'#00AA00','bold','center'),
    Lbl_Author = GUI.Lbl(Author,11,'red','0 0 0 12px','bold','center'),
    Lbl_Members = GUI.Lbl(Members,11,'blue','0 0 0 12px','bold','center'),
    PilProv = GUI.Pilih(PilPrv,'Select Province',13,'DD0000','8px 10px 0px 8px','bold',110,""),
    PilPulau = GUI.Pilih(Pulau,'Select Island',13,'00DD00','-28px 10px 0px 120px','bold',100,""),
    SelDateLbl = GUI.Lbl('Start,End Date',10,'#0000dd','-53px 0px 0px 165px',150,120,""),
Btn_Pros = GUI.CmdBtn1('RUN !',14,'DD0000','dddddd','10px 10px 0px 8px','bold',110,'center',4,
'2px dashed #ff0000'),dateSlider = ui.DateSlider({start:'2019-01-01',end: TglE,value: null,period: 30*6}), 
Btn_Save = GUI.CmdBtn1('SAVE RESULT',14,'0000DD','dddddd','-41px 10px 0px 80px','bold',100,'center',4,
'2px dashed #ff0000'),Panel = ui.Panel()
;
Panel.style().set('width', '300px'); 
var intro = ui.Panel([Tmb_Log8WRI,Lbl_App,Lbl_Author,Lbl_Members,TB_Thn,dateSlider,PilProv,PilPulau,Btn_Pros,Btn_Save]);
Panel.add(intro);ui.root.insert(0, Panel);
// Event pada GUI
dateSlider.onChange(function (Cek) {
  print('Start Date',ee.Date(Cek.start()).format(Fmt));
  TglS = ee.Date(Cek.start()).format(Fmt).getInfo();
  TB_Thn.set({value:TglS+','+TglE});
} );
TB_Thn.onChange(
  function () {
  SelDate = TB_Thn.getValue();
 } );
PilProv.onChange(
  function (key) {
  var Cek = parseInt(key, 9);
 NamPrvPil = PilProv.getValue(); PrvId = PilPrv[NamPrvPil];
 NamPrv = WADMPR[PrvId-1]; 
 print('Selected : ' + (PrvId ) + "_" + NamPrv);
 Shp_Kab=Indo10_Kab.filter(ee.Filter.eq('NAMA_PROV',NamPrv));
  ft = Indo10_Prv.filter(ee.Filter.eq('PRV_ID',PrvId));
Bts1Prv =  ee.Geometry.Rectangle(Bts_Prv[PrvId-1]);
if (PrvId == 11)Bts1Prv = DKI_No1000;
 //Mask = ee.Image(LBS_Prv.get(PrvId-1));  
  }
  );
PilProv.set({value:Arr_NamPrv[12]});
PilPulau.onChange(
  function (key) {
  var Cek = parseInt(key, 9);
Plu = PilPulau.getValue(); PluId = Pulau[Plu] - 1;
NamaPulau = Nama_Pulau[PluId]; NamPrvPil = Plu;
print('Selected : ' + (PluId+1 ) + "_" + NamaPulau);
 ft=Indo10_Prv.filter(ee.Filter.eq('PLU_ID',PluId+1));
Shp_Kab = Indo10_Kab.filter(ee.Filter.inList('NAMA_PROV',Pulau_Prv[PluId]));
//Mask = LBS_Pulau[PluId];  
Bts1Prv =  ee.Geometry.Rectangle(Bts_Plu[PluId]);     
  }
  );
Btn_Pros.onClick(
  function() {
SelDate = TB_Thn.getValue(); FiltDate = SelDate.split(","); 
DateSelect = [FiltDate[0],FiltDate[1]]; Thn1=(FiltDate[0].slice(0,4));
ImgLereng = Lereng(ft); print('Img Lereng di ' + NamPrv,ImgLereng);
//SlopMsk_BU = ImgLereng.lt(Slope_BU); 
//Thn=(FiltDate[1].slice(0,4)); var dTh = Thn-Thn1;
//print('Tahun 1,2 '+ (Thn1).toString() + ',' + (Thn).toString()  ) ;
Map.centerObject(Bts1Prv,10);
Komposit = 'Qual' ; // 'Qual': Komposit metode qualityMosaic('NDVI_Max'); 'Med' : median()
//L8 = ee.Image(Pilih_L8(DateSelect,Bnd_L8,Komposit,'L8',Bts1Prv));
S2_VRT = S2_SR.filterBounds(Bts1Prv).filterDate(DateSelect[0],DateSelect[1]);
List_S2 = FTxt.ListObjPro(S2_VRT.sort('system:time_start'),'system:index');
S2 = ee.Image(Pilih_S2k(DateSelect,Bnd_S2k,Komposit,'S2',Bts1Prv));
print('List_S2 :',List_S2);
WaterBare = Citra.NoPilSCL(S2,4).clip(ft); Bare = Citra.PilSCL(S2,5).clip(ft);
Idx_S2 = S2.select('NDBI','EVI','NDWI').clip(ft).mask(Bare) ; 
//Idx_L8 = L8.select('NDBI','EVI','NDWI').clip(ft).mask(Bare);
Build_S2 = DetBuild(Idx_S2,ThBuild_S2,ImgLereng,Slope_BU,'S2'); 
//Build_L8 = DetBuild(Idx_L8,ThBuild_L8,ImgLereng,Slope_BU,'L8');
// Cek Statistik Index2 L8 & S2 di Permukiman DKI
if (PrvId == 11) { // Cek Permukiman/Bangunan di DKI th 2017/18
Idx_S2 = S2.select('NDBI','EVI','NDWI').mask(Bare).clip(Pmk17Bgn_DKI);
//Idx_L8 = L8.select('NDBI','EVI','NDWI').mask(Bare).clip(Pmk17Bgn_DKI);
Build_S2 = DetBuild1(Idx_S2,ThBuild_S2,'S2'); 
//Build_L8 = DetBuild1(Idx_L8,ThBuild_L8,'L8');
var StkBare_S2 = StkImgRed(Idx_S2.mask(Build_S2),30,DKI_No1000);
//var StkBare_L8 = StkImgRed(Idx_L8.mask(Build_L8),90,DKI_No1000);
print('Statistik Index2 S2 pd Permukiman : ',StkBare_S2);
//print('Statistik Index2 L8 pd Permukiman : ',StkBare_L8);
}
//var BuildCek_S2 = TB_BuildUpS2.getValue(), BuildCek_L8 = TB_BuildUpL8.getValue();
//print('Cek Th : ',BuildCek_S2-BuildCek_L8);
//print('Treshold Build, S2 & L8 : ',Th_Build[0].toString() + ',' + Th_Build[1].toString());
//var SNIC = Citra.SegImg(S2.select(Bnd_S2),32,6 ,8,256,36);
//print('Segmentasi : ',SNIC)
Map.clear(); 
//Map.addLayer(L8.select('NDBI','EVI','NDWI').clip(ft),{},'(NDBI,EVI,NDWI) L8 '+ SelDate,0);
//Map.addLayer(Build_L8,{palette : 'cyan'},'Build-Up L8 '+ SelDate,0);
Map.addLayer(ImgLereng,{palette : 'cc8800'},'Slope',0);
//var clusters = SNIC.select('clusters');
//Map.addLayer(clusters.randomVisualizer(), {}, 'clusters', false);
//Map.addLayer(SNIC.randomVisualizer(), {}, 'means');
Map.addLayer(S2.select(Bnd_S2).mask(Sawit_Kls).clip(ft),VisRGB_S2,'RGB S2 '+ SelDate);
Map.addLayer(Sawit_Kls.clip(ft),ViS_SwtKls,'Oil palm plantation type');
Map.addLayer(WaterBare.clip(ft),Vis_SCL,'Water,Bare Land S2 '+ SelDate);
Map.addLayer(Build_S2,{palette :'red'},'Build-Up S2 '+ SelDate);
// Map.addLayer(Shp_Kab, {color : '00ffff'},'Kabupaten',0,0.7);
Map.addLayer(ft, {},'Province Area',0);
Citra.Tab2Map_OutL(Shp_Kab,1,'black','District Boundary');
Citra.Tab2Map_OutL(ft,2,'aa0000','Province Boundary');
Map.addLayer(ee.Image().toByte().paint(Bts1Prv, 0, 2), {palette : 'blue'},'AOI Rectangle');
//var LegendaFase = Legenda('Fase Tanaman',PrdList[IdxPrd][0],Nama_Fase_Kls,Fase_palette,7); 
var LegendaFase = Legenda('Land Cover Class',TglSEt,SCL_Kls1,LCover_palette,4); 
//Map.add(LegendaFase);
if (RunPros == 1) Panel.add(LegendaFase);
Map.setControlVisibility(1);
 RunPros += 1;   
  }
  );
Btn_Save.onClick(
  function() {
  var NoP = IdxPrd+1; if (NoP < 10)NoP = '0' + NoP;
  VisRGB = VisRGB_S2;
  // Provinsi harus dipilih, jk tdk dipilih defaultnya Jabar
  if (NamPrvPil === '') {NamPrvPil = 'Jawa_Barat'; Bts1Prv = ee.Geometry.Rectangle(Bts_Prv[12]);}
RGB_S2 = S2.visualize(VisRGB);   
 var S2Out = 'S2_Mosa_'+ Thn + '_' +  NamPrvPil,RGB_S2Out = 'RGBS2_'+ Thn + '_' +  NamPrvPil;
 var IdxS2Out = 'Idx_S2_Mosa_'+ Thn + '_' +  NamPrvPil;
 var S2_Sim = S2.multiply(1000).toUint16().set('Scld',1000);
 // var RGB_S1 = S1.visualize(VisRGB_S1), RGB_S1Out = 'RGBS1_'+ Thn + '_p' + NoP + '_' +  NamPrvPil;  
 // var WaterBare_Prv = WaterBare.clip(ft), WaBare_Out = 'WaterBare_'+ Thn + '_p' + NoP + '_' +  NamPrvPil;
  var WaterBare_Prv = WaterBare.clip(ft), WaBare_Out = 'WaterBare_'+ Thn + '_' +  NamPrvPil;
 // var IdxL8Sim=L8.select('NDBI','EVI','NDWI').mask(Bare).clip(ft).multiply(125).add(128).toByte();
  var IdxS2Sim=S2.select('NDBI','EVI','NDWI').mask(Bare).clip(ft).multiply(125).add(128).toByte();
  SaveImg2Drv(WaterBare_Prv,WaBare_Out,10,Bts1Prv,ft,'','Byte');  
SaveImg2Drv(IdxS2Sim,IdxS2Out,10,Bts1Prv,ft,'','Byte');
SaveImg2Ast(IdxS2Sim,IdxS2Out+NamPrvPil,10,Bts1Prv,ft,'','Byte');
//SaveImg2Drv(IdxL8Sim,'IdxL8_2019_'+NamPrvPil,10,Bts1Prv,ft,'','Byte');
 // SaveImg2Drv(RGB_S1,RGB_S1Out,10,Bts1Prv,ft,'','Byte');  
SaveImg2Drv(RGB_S2,RGB_S2Out,10,Bts1Prv,ft,'','Byte');
SaveImg2Ast(RGB_S2,RGB_S2Out,10,Bts1Prv,ft,'','Byte');  
  //SaveImg2Ast(RGB_S1,RGB_S1Out,10,Bts1Prv,ft,'','Byte'); 
SaveImg2Drv(S2_Sim,S2Out,10,Bts1Prv,ft,'','U16');
SaveImg2Ast(S2_Sim,S2Out,10,Bts1Prv,ft,'','U16');
  }
  );
  // FUNGSI2
  function Pilih_L8(TglRange,PilBnd,Komp,Nama,AOI) {
    //CLOUD_COVER_LAND (awan di darat)
    // .filter(ee.Filter.lt('CLOUD_COVER_LAND',30))
    var Tgl1 = ee.Date(TglRange[0]),Tgl2 = ee.Date(TglRange[1]);
    var L8 = L8_SR.filterDate(TglRange[0],TglRange[1]).filterBounds(AOI)
    .map(Citra.MskAwan_L8).map(Citra.AddIdx_L8)
   .set("system:time_start",Tgl1).set("system:time_end",Tgl2);
    if (Komp !== '')L8 = Citra.Komposit(L8,Komp); // Jika tdk direduce/komposit , jdi virtual Time Series data
    if (Nama !=='')L8 =L8.set('name',Nama+ '_' + TglRange[0]);
    return L8.select(PilBnd)
    ;
  }
// SENTINEL-2 SURFACE REFLECTANCE
// .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 30)
exports.Pilih_S2k=function(TglRange,PilBnd,Komp,Nama,AOI) 
{return Pilih_S2k(TglRange,PilBnd,Komp,Nama,AOI);  }
function Pilih_S2k(TglRange,PilBnd,Komp,Nama,AOI) {
  var S2 = S2_SR.filterDate(TglRange[0],TglRange[1]).map(Citra.MskAwan_S2k).map(Citra.AddIdx_S2)
  .filterBounds(AOI).set("system:time_start",TglRange[0]).set("system:time_end",TglRange[1]);
if (Komp !== '')  S2 = Citra.Komposit(S2,Komp);
if (Nama !== '') S2 = S2.set({name:Nama + '_' + TglRange[0]});
return S2.select(PilBnd);
}
// SENTINEL-1
function Pilih_S1(Tgl_Range,Pass,PilBnd,Komp,Nama,roi) {
var S1 =  S1_GRD
.filterDate(Tgl_Range[0],Tgl_Range[1])
.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
.filter(ee.Filter.eq('instrumentMode', 'IW'))
.map(Citra.KorIncAngl)
.map(Citra.RemNoBord)
/*
.map(function(Img){
  var VV_Lee = Citra.RefinedLee(Img.select('VV_Cor')).rename('VV_Lee');
  var VH_Lee = Citra.RefinedLee(Img.select('VH_Cor')).rename('VH_Lee');
  return Img.addBands(VH_Lee).addBands(VV_Lee);
}
   ) */
.map(Citra.AddIdx_S1);
if (Pass == 'DSC') S1 = S1.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
if (Pass == 'ASC') S1 = S1.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));
S1 = S1.set("system:time_start",Tgl_Range[0]).set("system:time_end",Tgl_Range[1]);
if (Nama !== '') S1 = S1.set({name:Nama + '_' + Tgl_Range[0]}); 
if (roi !== '') S1 = S1.filterBounds(roi);
//S1 = Citra.Pilih_S1_Komp(S1,'MeanMed');
if (Komp !== '') S1 = Citra.Pilih_S1_Komp(S1,Komp);
if (PilBnd !=='') S1 = S1.select(PilBnd);
//return (S1.select('VV_Lee','VH_Lee','VH-VV','MeanBS','NDPI','RPI'));
return S1;
}
// Simpan Img ke Asset
exports.SaveImg2Ast=function(ImgIn,ImgOut,Sc,Bts,Clip,KoefKon,TypOut) 
{ return SaveImg2Ast; }
function SaveImg2Ast(ImgIn,ImgOut,Sc,Bts,Clip,KoefKon,TypOut) {
var ImgIn2 = ImgIn;
if (Clip !== '') ImgIn2 = ImgIn.clip(Clip);
if (KoefKon !== '') { if (KoefKon == 'Vis') ImgIn2 = ImgIn2.visualize(VisRGB); 
else ImgIn2 = ImgIn2.multiply(KoefKon[1]).add(KoefKon[0]); 
  if (TypOut == 'U16') ImgIn2 = ImgIn2.toUint16(); 
  else if (TypOut == 'S16') ImgIn2 = ImgIn2.toInt16(); else ImgIn2 = ImgIn2.toByte();  
}
Export.image.toAsset({
  image:ImgIn2,
  description: 'Ast_' + ImgOut,
  //folder : 'LBS_Kls30m',
  assetId: ImgOut,
  scale: Sc,
  maxPixels: 1e13,
  region: Bts,
 });
 }
exports.SaveImg2Drv=function(ImgIn,ImgOut,Sc,Bts,Clip,KoefKon,TypOut) 
{ return SaveImg2Drv; }
function SaveImg2Drv(ImgIn,ImgOut,Sc,Bts,Clip,KoefKon,TypOut) {
var ImgIn2 = ImgIn;
if (Clip !== '') ImgIn2 = ImgIn.clip(Clip);
if (KoefKon !== '') { if (KoefKon == 'Vis') ImgIn2 = ImgIn2.visualize(Vis2RGB); 
else ImgIn2 = ImgIn2.multiply(KoefKon[1]).add(KoefKon[0]); 
  if (TypOut == 'U16') ImgIn2 = ImgIn2.toUint16(); 
  else if (TypOut == 'S16') ImgIn2 = ImgIn2.toInt16(); else ImgIn2 = ImgIn2.toByte();  
} 
  Export.image.toDrive({ 
  image:ImgIn2,
  description:ImgOut,
  scale: Sc, 
  maxPixels: 1e13,
  region: Bts});
}
function Legenda(Titel1,Titel2,NamKls,Palet,JumKls){
var legend = GUI.PosPanel('LL','8px 15px');
var legendTitle1 = GUI.Lbl(Titel1,16,'black','0 0 4px 0','bold','');
var legendTitle2 = GUI.Lbl(Titel2,14,'black','0 0 4px 0','bold','');
legend.add(legendTitle1).add(legendTitle2);
for (i = 0; i < JumKls; i++) {
 legend.add( Box1War(Palet[i], NamKls[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)  
// Map.add(legend);  
return legend;
}
function Box1War(color, name) {
var colorBox = GUI.WarnaBox(color,8);
// Create the label filled with the description text.
    var description = GUI.Lbl(name,12,'black','0 0 4px 6px','bold','',color,8);   
// return the panel
return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
}
function FiltData(Sat,TglRange,AOI) {
var Id,ImgCol ;
if (Sat == 'L8r') Id = L8_SR ;
if (Sat == 's2') Id = S2_TOA ;
if (Sat == 's2k') Id = S2_SR;
if (Sat == 's1') Id = S1_GRD;
if (Sat == 'CHRP1')Id = 'UCSB-CHG/CHIRPS/DAILY/' ;
if (Sat == 'GSMAP')Id = 'JAXA/GPM_L3/GSMaP/v6/operational/';
ImgCol = (Id).filterDate(TglRange[0],TglRange[1]);
if (AOI != 't' || AOI != 'T' ) ImgCol = ImgCol.filterBounds(AOI);
return (ImgCol);
}
exports.StkImgRed = function(Img,Sc,Geom) {return StkImgRed(Img,Sc,Geom); }
function StkImgRed(Img,Sc,Geom) {
var minmaxReducer = ee.Reducer.minMax(),medReducer = ee.Reducer.median(),
sigmaReducer = ee.Reducer.stdDev(), meanReducer = ee.Reducer.mean(),
countReducer = ee.Reducer.count(),sumReducer = ee.Reducer.sum()
;
var MinMaxMed = minmaxReducer.combine({reducer2:medReducer,sharedInputs: true});
var MeanStd = meanReducer.combine({reducer2:sigmaReducer,sharedInputs: true});
var StkImgGab = MinMaxMed.combine({reducer2:MeanStd,sharedInputs: true});
var SumCountRed = sumReducer.combine({reducer2:countReducer,sharedInputs: true} );
var StkImg = Img.reduceRegion({
  reducer: StkImgGab,bestEffort:true,scale:Sc, geometry:Geom
}); return StkImg;
}
function StkImgReg(Img,Reg,Sc) { // Hitung Statistik Img dg Batas Region Geometry
var minmaxReducer = ee.Reducer.minMax(),medReducer = ee.Reducer.median(),
sigmaReducer = ee.Reducer.stdDev(), meanReducer = ee.Reducer.mean(),
countReducer = ee.Reducer.count(),sumReducer = ee.Reducer.sum()
;
var MinMaxMed = minmaxReducer.combine({reducer2:medReducer,sharedInputs: true});
var MeanStd = meanReducer.combine({reducer2:sigmaReducer,sharedInputs: true});
var StkImgGab = MinMaxMed.combine({reducer2:MeanStd,sharedInputs: true});
var SumCountRed = sumReducer.combine({reducer2:countReducer,sharedInputs: true} );
var StkImg = Img.reduceRegions({
  collection: Reg,reducer:StkImgGab,scale:Sc 
}); return StkImg;
}
function DetBuild(Img,BI_Th,ImgSlp,Slp,Sat) {
// Deteksi BuildUp/Permukiman, dg kriteria Lereng/Slop
var IV1,IV2,IW; 
if (Sat == 'L8') {IV1 = 0.186 ; IV2 = 0.278; IW = 0.062; }
if (Sat == 'S2') {IV1 = 0.172 ; IV2 = 0.294; IW = 0.016; } 
var BuildUp = Img.expression("(BI >= BI_Th && VI <= IV2 && WI < IW && ISlp < Slp ) ? 1:0",
{BI:Img.select('NDBI'),VI:Img.select('EVI'),WI:Img.select('NDWI'),IV1:IV1,IV2:IV2,
BI_Th:BI_Th,IW:IW,ISlp:ImgSlp,Slp:Slp}); BuildUp=BuildUp.focal_mode();
return BuildUp.updateMask(BuildUp).toByte().rename('BuildUp');
}
function DetBuild1(Img,BI_Th,Sat) {
/* Deteksi BuildUp/Permukiman, tanpa kriteria Lereng/Slop
  Sat : Sentinel-2 atw Landsat 8. Slp : Kelerengan permukiman biasanya <= 5 %
  Khusus S2 sdh ada mask Veg,BareLand & Water pd data Surf Reflectan (Level-2A)
Treshold utk Bare(Kering), Pengecekan di Lahan Sawah
L8 : EVI = 0.188 sd 0.273 ; NDWI < 0.065
S2 : EVI = 0.172 sd 0.282 ; NDWI < 0.065
Pengeceken di DKI Data Komposit Th 2019
L8 : NDBI >= -0.101 ; EVI > 0.186 sd <=0.278 ; NDWI < 0.062 } 
S2 : NDBI >= -0.055 ;	EVI > 0.172 sd	<=0.294 ;NDWI < 0.016 }
*/
var IV1,IV2,IW; 
if (Sat == 'L8') {IV1 = 0.186 ; IV2 = 0.278; IW = 0.062; }
if (Sat == 'S2') {IV1 = 0.172 ; IV2 = 0.294; IW = 0.016; } 
//var MaskSlop = ImgSlop.lt(Slop);  
//var BuildUp = Img.expression("(BI >= BI_Th && VI > IV1 && VI <= IV2 && WI < IW) ? 1:0",
var BuildUp = Img.expression("(BI >= BI_Th && VI <= IV2 && WI < IW) ? 1:0",
{BI:Img.select('NDBI'),VI:Img.select('EVI'),WI:Img.select('NDWI'),IV1:IV1,IV2:IV2,
BI_Th:BI_Th,IW:IW}); BuildUp=BuildUp.focal_mode(); // Filter Rank Mayority
return BuildUp.mask(BuildUp).toByte().rename('BuildUp');
}
function Lereng(AOI) {
var hydrosheds = ee.Image('WWF/HydroSHEDS/03VFDEM');
var Terrain = ee.Algorithms.Terrain(hydrosheds), Slope = Terrain.select('slope').rename('Slope_%').clip(AOI);
return Slope;
}
function Img2Thumbz(Img,Lx,Ly,FZoom) {
var Lxz=Math.round(Lx*FZoom),Lyz=Math.round(Ly*FZoom);
var thumb = ui.Thumbnail({
    image: (Img), //Img2Vis(Img),
    params: {
        dimensions: Lxz + "x" + Lyz,
        format: 'png'
        },
    style: {height: Lyz + 'px', width:  + 'px',padding :'3'}
    });
return thumb;
  }
function Img2Thumb(Img,FZoom) {
var Lx = GetImg_Ref(Img).Width,Ly = GetImg_Ref(Img).Height; 
var Lxz=Math.round(Lx*FZoom),Lyz=Math.round(Ly*FZoom);
var thumb = ui.Thumbnail({
    image: Img, //Img2Vis(Img),
    params: {
        dimensions: Lxz + "x" + Lyz,
        format: 'png'
        },
    style: {height: Lyz + 'px', width: Lxz + 'px',padding :'3'}
    });
return thumb;
  }
function GetImg_Ref(Img){
var imgDescription = ee.Algorithms.Describe(Img);
var Width  = ee.List(ee.Dictionary(ee.List(ee.Dictionary(imgDescription).get("bands")).get(0)).get("dimensions")).get(0);
var Height = ee.List(ee.Dictionary(ee.List(ee.Dictionary(imgDescription).get("bands")).get(0)).get("dimensions")).get(1);
var GeoRef = Img.geometry().bounds().coordinates().get(0).getInfo();
var Cc = [GeoRef[3][0] + (GeoRef[1][0]-GeoRef[3][0])/2,GeoRef[3][1]-(GeoRef[3][1]-GeoRef[1][1])/2];    
print ("GeoRef",GeoRef,Cc);
return {LLxy:GeoRef[0],LRxy:GeoRef[1],URxy:GeoRef[2],ULxy:GeoRef[3],Cc:Cc,Width:Width,Height:Height };
   }
exports.Set_Map=function(No,Obj,Vis,Ket,Opsi,Opac){return Set_Map(No,Obj,Vis,Ket,Opsi,Opac);}
function Set_Map(No,Obj,Vis,Ket,Opsi,Opac) {
return Map.layers().set(No, ui.Map.Layer(Obj, Vis,Ket,Opsi,Opac));
} 
function SlidTgl(start, end,Fungsi) {
var dateRange = ee.DateRange(start, end).evaluate(function(range) {
  dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,period: 365,
    onChange: Fungsi
  }); 
});
}