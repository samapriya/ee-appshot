var table = ui.import && ui.import("table", "table", {
      "id": "users/lezanacd/26_segm_selecc_viv"
    }) || ee.FeatureCollection("users/lezanacd/26_segm_selecc_viv"),
    table2 = ui.import && ui.import("table2", "table", {
      "id": "users/lezanacd/viv_x_segm25"
    }) || ee.FeatureCollection("users/lezanacd/viv_x_segm25");
var opacity_viv = {
  Opacity: 80
};
var opacity_segm = {
  Opacity: 80
};
var opacity_catastro = {
  Opacity: 20
};
//var dpto_style = {width:5, color: '000000', fillColor: ' #ffffff22'};
//var frac_style =  {width:4, color: '10760B', fillColor: ' #80ff8022'};
var segm_style =  {width:3, color: 'CB0312', fillColor: ' #E74C3C22'};
var viv_style = {width:2 , color: '#E7D40A', fillColor: '#CCD1D1'};
/*======================================
inicio de la app
======================================*/
/*======================================
diccionario de objetos
======================================*/
//diccionario de Segmentos
var dic_segm ={
 '001': ['001'],
 '002': ['002'],
 '003': ['003'],
 '004': ['004'],
 '005': ['005'],
 '006': ['006'],
 '007': ['007'],
 '008': ['008'],
 '009': ['009'],
 '010': ['010'],
 '011': ['011'],
 '012': ['012'],
 '013': ['013'],
 '014': ['014'],
 '015': ['015'],
 '016': ['016'],
 '017': ['017'],
 '018': ['018'],
 '019': ['019'],
 '020': ['020'],
 '021': ['021'],
 '022': ['022'],
 '023': ['023'],
 '024': ['024'],
 '025': ['025'],
 '026': ['026'],
}
var dicobjetos = {
  select:{
    segmento: ui.Select({
    items: Object.keys(dic_segm).sort(), 
    placeholder:'Seleccione Segmento', 
    onChange: function(k){
    (table.filter(ee.Filter.inList('Segmento', [k])))
    //Map.centerObject(table2.filter(ee.Filter.inList('NOM_DPTO', [k])), 10)
    }}),
    label3: ui.Label('Segmentos:', {}),
    }
}  
//Objetos del panel
var panelv = ui.Panel({widgets:[dicobjetos.select.segmento],
layout: ui.Panel.Layout.Flow('horizontal'), style: {backgroundColor: '00000000'}});
var k = (dicobjetos.select.segmento.getValue());
var x = ee.Feature(k);
/*
-----------------------------------
Boton de segmento
-----------------------------------
*/
var boton = ui.Button({label:'ver Segmento', onClick:function(k){
  print( dicobjetos.select.segmento.getValue()),
  x = (dicobjetos.select.segmento.getValue()),
  k = (dicobjetos.select.segmento.getValue()),
  pointsTable = (table2.filter(ee.Filter.inList('Segmento', [x])));
  //print('boton ver segm',k),
 // print(pointsTable),
  Map.addLayer(table.filter(ee.Filter.inList('Segmento', [k])).style(segm_style)),
  Map.addLayer(table2.filter(ee.Filter.inList('Segmento', [k])).style(viv_style)),
  mostrarEtiquetas(),
  Map.centerObject(table.filter(ee.Filter.inList('Segmento', [dicobjetos.select.segmento.getValue()])));
}})
/*
-----------------------------------
Boton de CATASTRO
-----------------------------------
*/
/*
var boton5 = ui.Button({label:'ver Catastro', onClick:function(u){
 // print( dicobjetos.select.dptos.getValue(),dicobjetos.select.frac.getValue(),dicobjetos.select.rad.getValue()),
  //Map.clear();
  u = ('22'+dicobjetos.select.dptos.getValue()+dicobjetos.select.frac.getValue()+dicobjetos.select.rad.getValue()),
  print(u),
  Map.addLayer(table4.filter(ee.Filter.inList('LINK', [u])).style(catastro_style),opacity_catastro),
  Map.centerObject(table4.filter(ee.Filter.inList('LINK', [u])), 10)
}})
*/
/*
-----------------------------------
Boton de limpiar
-----------------------------------
*/
var boton4 = ui.Button({label:'Limpiar', onClick:function(p){
 Map.clear();
 Map.add(panel)
}})
//Panel Principal
var panel = ui.Panel({widgets:[
panelv,  
boton, boton4], 
layout: ui.Panel.Layout.Flow('vertical'), style: {backgroundColor: '00005555', position: 'bottom-right'}})
Map.add(panel)
// Create the application title bar.
Map.add(ui.Label(
    'Segmentos según Radios Rurales - Redimensión 2022', {fontWeight: 'bold', fontSize: '20px'}));
// Styling for the legend title.
var LEGEND_TITLE_STYLE = {
  fontSize: '20px',
  fontWeight: 'bold',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '4px',
};
// Styling for the legend footnotes.
var LEGEND_FOOTNOTE_STYLE = {
  fontSize: '10px',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '4px',
};
// Assemble the legend panel.
Map.add(ui.Panel(
    [
      ui.Label(
          'Fuente: Viviendas: Muestra para relevamiento encuesta', LEGEND_FOOTNOTE_STYLE),
      ui.Label('Cobertura de Radios del CNPVyH - 2022(Base 2010)', LEGEND_FOOTNOTE_STYLE)
    ],
    ui.Panel.Layout.flow('vertical'),
    {width: '230px', position: 'bottom-left'}));
////*****************************************/////
var text = require('users/gena/packages:text');
var scale = Map.getScale() * 0.005; // You can adjust the scale as needed
//var table3 = (table2.filter(ee.Filter.inList('Segmento', [k])));
//var pointsTable = ee.FeatureCollection(table2.select('IN_FID'));
var pointsTable = ee.FeatureCollection(table2);
/*
var etiqueta = pointsTable.map(function(eti) {
  var iti = (table2.filter(ee.Filter.inList('Segmento', [k])));
  var name2 = ee.String(iti.get("Segmento"));
  return name2;
  });
print(etiqueta);  */
//var pointsTable2 = ee.FeatureCollection(table2.select('IN_FID','Segmento'));
//var pointsTable = (table2.filter(ee.Filter.inList('Segmento', [x])));
//print(pointsTable);
//print(k);
// Also filter the collection by the CLOUD_COVER property.
//var pointsTable2 = pointsTable3.filter(ee.Filter.eq('Segmento', '001'));
//print(pointsTable);
/////////////////////////////////////////////////
// Load your shapefile (replace 'Vegetation_points' with your actual feature collection)
//var shp = ee.FeatureCollection('Vegetation_points');
function mostrarEtiquetas() {
// Map over each feature in the collection
  var labels = pointsTable.map(function(feat) {
    feat = ee.Feature(feat);
    var name = ee.String(feat.get("IN_FID")); // Assuming "Name" is the attribute column
    var centroid = feat.geometry().centroid();
  // Create the label
    var t = text.draw(name, centroid, scale, {
      fontName: "Times New Roman",
      fontSize: 10, // Font size (can be scaled using the 'scale' variable)
      textColor: 'red',
      outlineWidth: 0.5,
      outlineColor: 'black'
    });
    return t;
  });
// Create an image collection from the labels
  var labels_final = ee.ImageCollection(labels);
//var labels_final = ee.ImageCollection(labels.filter(ee.Filter.inList('Segmento', [k])));
// Add the labels to the map
//Map.addLayer(labels_final, {}, "bing_IA");
  Map.addLayer(labels_final, {}, "ID_viviendas");
}
//para version v04
//////////////////////////////////////////////////