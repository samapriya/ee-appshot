var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.MultiPoint(),
    exclusion = ui.import && ui.import("exclusion", "image", {
      "id": "users/mrdaryl_90/raster_exclusion"
    }) || ee.Image("users/mrdaryl_90/raster_exclusion"),
    incendios_2020 = ui.import && ui.import("incendios_2020", "table", {
      "id": "users/mrdaryl_90/incendios_validos"
    }) || ee.FeatureCollection("users/mrdaryl_90/incendios_validos"),
    prox_main_rivers = ui.import && ui.import("prox_main_rivers", "image", {
      "id": "users/mrdaryl_90/Prox_Main_rivers"
    }) || ee.Image("users/mrdaryl_90/Prox_Main_rivers"),
    prox_non_paved_roads = ui.import && ui.import("prox_non_paved_roads", "image", {
      "id": "users/mrdaryl_90/Prox_Non_Paved_roads"
    }) || ee.Image("users/mrdaryl_90/Prox_Non_Paved_roads"),
    prox_paved_roads = ui.import && ui.import("prox_paved_roads", "image", {
      "id": "users/mrdaryl_90/Prox_Paved_roads"
    }) || ee.Image("users/mrdaryl_90/Prox_Paved_roads"),
    prox_sec_rivers = ui.import && ui.import("prox_sec_rivers", "image", {
      "id": "users/mrdaryl_90/Prox_Sec_rivers"
    }) || ee.Image("users/mrdaryl_90/Prox_Sec_rivers"),
    prox_settelements = ui.import && ui.import("prox_settelements", "image", {
      "id": "users/mrdaryl_90/Prox_Settlements"
    }) || ee.Image("users/mrdaryl_90/Prox_Settlements"),
    prox_trails = ui.import && ui.import("prox_trails", "image", {
      "id": "users/mrdaryl_90/Prox_Trails"
    }) || ee.Image("users/mrdaryl_90/Prox_Trails"),
    incendios_alea = ui.import && ui.import("incendios_alea", "table", {
      "id": "users/mrdaryl_90/incendios_alea"
    }) || ee.FeatureCollection("users/mrdaryl_90/incendios_alea"),
    Limite_HN = ui.import && ui.import("Limite_HN", "table", {
      "id": "users/mrdaryl_90/Limite_HN"
    }) || ee.FeatureCollection("users/mrdaryl_90/Limite_HN");
//Entradas de información para el modelo de incedios 
var Limite_HN = ee.FeatureCollection (Limite_HN);
var incendios_alea = ee.FeatureCollection (incendios_alea).filterMetadata('Mes_Occuri', 'equals', 'Random');
var Prox_Paved_roads = ee.Image(prox_non_paved_roads);
var Prox_Non_Paved_roads = ee.Image(prox_non_paved_roads);
var Prox_Trails = ee.Image(prox_trails);
var Prox_Main_rivers = ee.Image(prox_main_rivers);
var Prox_Sec_rivers = ee.Image(prox_sec_rivers);
var Prox_Settlements = ee.Image(prox_settelements);
var Reflectancia = ee.ImageCollection('MODIS/006/MOD09A1');
var NDVI_colleccion = ee.ImageCollection('MODIS/006/MOD13A1');
var Temperatura = ee.ImageCollection('MODIS/006/MOD11A2');
var Elevaciones = ee.Image("USGS/SRTMGL1_003");
var Precipitacion_diaria = ee.ImageCollection('JAXA/GPM_L3/GSMaP/v6/operational');
var Radiacion_coleccion = ee.ImageCollection('NOAA/GFS0P25');
var FIRMS_colection = ee.ImageCollection('FIRMS');
//incendios_alea = incendios_alea.map(function(f) {
  //return f.set('ocurrencia', 0)});
//Fechas en Año, mes, dia
var start_mes = '2020-12-15';
var end_mes = '2021-01-14';
var start = '2020-12-15';
var end = '2021-01-14';
//GENERACIÓN DE PROCESOS DE LAS CAPAS BASE
//CORTE DE ELEVACIÓN
var corteDEM = Elevaciones.clip(Limite_HN);
// PENDIENTES
var pendiente = ee.Algorithms.Terrain(Elevaciones).select('slope').clip(Limite_HN);
//TEMPERATURA SUPERFICIAL
var LSTday_K = Temperatura.select('LST_Day_1km');
var LSTday_C = LSTday_K.map(function(img) {
  return img.multiply(0.02).subtract(273.15).copyProperties(img,['system:time_start','system:time_end']); 
});
var filtro_fecha = ee.ImageCollection(LSTday_C.filterDate(start, end));
var Media_T = filtro_fecha.mean().clip(Limite_HN).rename('grados_C');
print (Media_T, 'temperatura')
//ÍNDICE DE VEGETACIÓN DIFERENCIAL NORMALIZADO (NDVI)
var modisNDVI = NDVI_colleccion
  .select("NDVI", "SummaryQA")
  .filterDate(start_mes, end_mes)
   .map(function(image) {
      return image.multiply (0.0001).clip(Limite_HN);});
       //Enmascarar NDVI por nube
var maskClouds = function(image) {
  var quality = image.select('SummaryQA');
  var mask = quality.eq(3).not();
  return image.updateMask(mask);
};
var NDVI_mask = modisNDVI
  .map(maskClouds)
  .select('NDVI').min();
//PRECIPITACIÓN DEL RANGO DE FECHAS SELECCIONADA
var Precipitacion_fecha = Precipitacion_diaria
                          .filterDate('2018-03-23', '2018-03-29').select('hourlyPrecipRateGC');
var sumaP =Precipitacion_fecha.sum().clip(Limite_HN);
//print(sumaP);
/*var Precipitacion_fecha = Precipitacion_diaria
                          .filterDate('2018-02-01', '2018-04-04').select('precipitation');
var sumaP =Precipitacion_fecha.sum().clip(Limite_HN);
print(sumaP)*/
//Create a summed precipitation image for every January from 1980 to 2015
var precip_jan =  ee.ImageCollection(ee.List.sequence(2000, 2020).map(function (year){
  var date_start = ee.Date.fromYMD(year, 3, 1);
  var date_end = ee.Date.fromYMD(year, 3, 31);
  return  ee.ImageCollection('NASA/ORNL/DAYMET_V3')
                        .select('prcp')
                        .filterDate(date_start, date_end)
                        .sum()
                        .set({year: year, 'system:time_start':date_start})
                        .clip(Limite_HN);
}));
var precip_jan_mean = precip_jan.reduce(ee.Reducer.mean());
//CÁLCULO NMDI
var Filtro_NMDI = Reflectancia
                 .filterDate(start, end)
                 .filterBounds(Limite_HN);
//print('Filtro_NMDI', Filtro_NMDI);
var Ima_NMDI =ee.Image('MODIS/006/MOD09A1/2020_01_01').clip(Limite_HN);
var NMDI = Ima_NMDI.expression(
    '(b2 - (b6 -b7)) / (b2 + (b6 -b7))',{
    'b2' : Ima_NMDI.select('sur_refl_b02'),
    'b6' : Ima_NMDI.select('sur_refl_b06'),
    'b7' : Ima_NMDI.select('sur_refl_b07')
  }).rename('NMDI');
//CÁLCULO RADIACION
var radiación_12 = Radiacion_coleccion.filterDate('2020-12-15', '2021-01-14').filter(ee.Filter.eq('forecast_hours', 13));
var Rmedia = radiación_12.select("downward_shortwave_radiation_flux").mean().clip(Limite_HN);
//CÁLCULO FOCOS INCENDIOS
var FIRMS =FIRMS_colection
  .select(['T21'])
  .filterDate('2020-12-15','2021-01-14')
  .filterBounds(Limite_HN);
// Reduce MODIS fire alerts to single binary image
var FIRMScount = ee.Image(FIRMS.count()).clip(Limite_HN);
var FIRMSbinary = FIRMScount.eq(FIRMScount).rename('FIRMS_binary_alert');
var crs = ee.Image(FIRMS.first()).projection().crs();
var scale = ee.Image(FIRMS.first()).projection().nominalScale();
// MODIS fire vectors
var FIRMSpoint = FIRMSbinary.reduceToVectors({
  geometry: Limite_HN,
  eightConnected:true,
  labelProperty:'modis_fire',
  maxPixels:2e8,
  crs:crs,
  scale:scale,
  geometryType: 'centroid',
});
//MASCARAS
var mProx_Paved_roads = Prox_Paved_roads.mask(exclusion)
print (mProx_Paved_roads, 'mascara caminos pavimentados')
var mProx_Non_Paved_roads = Prox_Non_Paved_roads.mask(exclusion)
var mProx_Trails = Prox_Trails.mask(exclusion)
var mProx_Main_rivers = Prox_Main_rivers.mask(exclusion)
var mProx_Sec_rivers = Prox_Sec_rivers.mask(exclusion)
var mProx_Settlements = Prox_Settlements.mask(exclusion)
var mcorteDEM = corteDEM.mask(exclusion)
var mpendiente = pendiente.mask(exclusion)
var mMedia_T = Media_T.mask(exclusion)
var mNDVI_mask = NDVI_mask.mask(exclusion)
var msumaP = sumaP.mask(exclusion)
var mNMDI = NMDI.mask(exclusion)
var mRmedia = Rmedia.mask(exclusion)
//MOSAICO DE TODAS LAS CAPAS
var Mosaico_capas = mProx_Paved_roads.addBands(mProx_Non_Paved_roads).addBands(mProx_Trails).addBands(mProx_Main_rivers).addBands(mProx_Sec_rivers).addBands(mProx_Settlements)
                    .addBands(mcorteDEM).addBands(mpendiente).addBands(mMedia_T).addBands(mNDVI_mask).addBands(msumaP).addBands(mNMDI).addBands(mRmedia);
// Set selection bands
var predictionBands = Mosaico_capas.bandNames();
var classFeatures= incendios_2020.randomColumn()
                   .merge(incendios_alea.randomColumn());
// Split class feature collection in training (60%) and validation data (40%)
var trainingFeatures = classFeatures;
// var trainingSamples = sampleRegions(Mosaico_capas, trainingFeatures, 10000);
var trainingSamples = Mosaico_capas.reduceRegions({
  collection: trainingFeatures,
  reducer: 'mean',
  scale: 10000
});
//Los rásteres tienen píxeles sin datos, que deben filtrarse
trainingSamples = trainingSamples.filter(
  ee.Filter.and(
    ee.Filter.neq('hourlyPrecipRateGC', null),
    ee.Filter.neq('NDVI', null),
    ee.Filter.neq('b1', null)
  )
);
// Train the classifier
var classifier = ee.Classifier.randomForest(50).train(trainingSamples, 'ocurrencia', predictionBands).setOutputMode('PROBABILITY');
// Classify the training image stack
var classified = Mosaico_capas.classify(classifier);
var riesgoPalette = ["2a7730", "ece63b", "ffa64b", "d63000"];
Map.addLayer(classified, {min:0, max:1, palette: riesgoPalette}, "riesgo_incendios", false);
print (classified, 'claisificacion')
//Centra Mapa
Map.centerObject(Limite_HN);
//Descarga
Export.image.toDrive({
  image: classified, 
  description: "promedio_2020",
  scale: 500, 
  maxPixels:1e13,
  crs: "EPSG:32616"
})
Map.addLayer(FIRMSpoint,{color: 'd63000'},'alertas de Incendios'    ,false);