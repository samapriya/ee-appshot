var landCover = ui.import && ui.import("landCover", "imageCollection", {
      "id": "GOOGLE/DYNAMICWORLD/V1"
    }) || ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1"),
    counties = ui.import && ui.import("counties", "table", {
      "id": "TIGER/2018/Counties"
    }) || ee.FeatureCollection("TIGER/2018/Counties"),
    states = ui.import && ui.import("states", "table", {
      "id": "TIGER/2018/States"
    }) || ee.FeatureCollection("TIGER/2018/States"),
    WA = ui.import && ui.import("WA", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -124.98892587466659,
                49.041671422923486
              ],
              [
                -124.98892587466659,
                45.44878737918226
              ],
              [
                -116.59537118716659,
                45.44878737918226
              ],
              [
                -116.59537118716659,
                49.041671422923486
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-124.98892587466659, 49.041671422923486],
          [-124.98892587466659, 45.44878737918226],
          [-116.59537118716659, 45.44878737918226],
          [-116.59537118716659, 49.041671422923486]]], null, false);
// This script will generate and display land cover maps by county
    // using the Dynamic World data set generated from Sentinel-2 imagery
    // it is globally available. 
    // from tutorial: https://developers.google.com/earth-engine/tutorials/community/introduction-to-dynamic-world-pt-1
//Before running, create or modify the hand-drawn geometry named "studyArea"
// Enter the dates of imagery you wish to query
var startDate = '2024-06-01';
var endDate = '2024-08-31';
var geometry = WA;   //this is the hand-drawn geometry
// The lines below are to query the Sentinel-2 image collection.
  // This script does not call these lines, but one could 
  // for example, generate a composite image and add it to the map
var s2 = ee.ImageCollection('COPERNICUS/S2_HARMONIZED')
             .filterDate(startDate, endDate)
             .filterBounds(geometry)
             .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)); //adjust cloudy pixel % as desired
// Query the Dynamic World data set for the timeframe and area of interest
var dw = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1')
            .filterDate(startDate, endDate)
            .filterBounds(geometry)
// select the band containing cover class labels
var classification = dw.select('label');
// create composite classified image
var dwComposite = classification.reduce(ee.Reducer.mode());
//set parameters to visualize the map
var dwVisParams = {
  min: 0,
  max: 8,
  palette: [
    '#419BDF', '#397D49', '#88B053', '#7A87C6', '#E49635', '#DFC35A',
    '#C4281B', '#A59B8F', '#B39FE1'
  ],
  opacity: 0.8
};
// Create map and center on area of interest at specified zoom level
Map.centerObject(WA, 7); //optional, or use Map.setCenter with lat/long
// Clip the composite and add it to the Map.
//Map.addLayer(classification, dwVisParams, 'Classified Image');
Map.addLayer(dwComposite.clip(geometry), dwVisParams, 'Classified Composite');
  //Create county & state outlines and display.
  var empty = ee.Image().byte();
  var countyOutlines = empty.paint({
    featureCollection: counties,
    color: 1,
    width: 1
  });
   var stateOutlines = empty.paint({
    featureCollection: states,
    color: 1,
    width: 2
  });
  var NWcounties = countyOutlines.clip(WA);
  var NWstates = stateOutlines.clip(WA);
  Map.addLayer(NWcounties, {}, "US Counties (Census 2018)");
  Map.addLayer(NWstates, {}, "US States (Census 2018)");