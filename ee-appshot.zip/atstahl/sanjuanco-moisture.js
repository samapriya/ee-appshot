//This script computes NDVI, NDMI for San Juan county
  // from Sentinel-2 imagery
    // Look up county 5-digit FP code 
// Load a Census Table of state boundaries and filter to county (by 5-digit FP code).
// https://www.nrcs.usda.gov/wps/portal/nrcs/detail/id/home/?cid=nrcs143_013697
  // San Juan County = '53055'
var county = ee.FeatureCollection('TIGER/2018/Counties')
        .filter(ee.Filter.eq('GEOID', '53055'));
    // Set visualization parameters for NDVI.
    var ndviParams = {min: 0, max: 0.8, palette: ['white', 'green']};
    // Set visualization parameters for NDMI.
    var ndmiParams = {min: 0, max: 0.8, palette: ['white', 'blue']};
// ***Query, mask clouds, composite, clip Sentinel imagery. ***
      // Function to mask clouds using the Sentinel-2 QA band.
      function maskS2clouds(image) {
        var qa = image.select('QA60');
        // Bits 10 and 11 are clouds and cirrus, respectively.
        var cloudBitMask = 1 << 10;
        var cirrusBitMask = 1 << 11;
        // Both flags should be set to zero, indicating clear conditions.
        var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
                   qa.bitwiseAnd(cirrusBitMask).eq(0));
        // Return the masked and scaled data, without the QA bands.
        return image.updateMask(mask).divide(10000)
            .select("B.*")
            .copyProperties(image, ["system:time_start"]);
      }
// Map the cloud function over time period, create median composites, clip to ROI.
var collection = ee.ImageCollection('COPERNICUS/S2_HARMONIZED').filter(ee.Filter.bounds(county))
    // Pre-filter to get less cloudy granules, apply cloud mask.
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
    .map(maskS2clouds);
var mayjune24 = collection.filterDate('2024-05-01', '2024-06-30').median().clip(county);
var augsept24 = collection.filterDate('2024-08-01', '2024-09-30').median().clip(county);
var mayjune23 = collection.filterDate('2023-05-01', '2023-06-30').median().clip(county);
var augsept23 = collection.filterDate('2023-08-01', '2023-09-30').median().clip(county);
    //Compute NDVI and NDMI and add as bands to Sentinel median composite image.
      // Use the normalizedDifference(A, B) to compute (A - B) / (A + B) for each index.
    var addNDVI = function(image) {
      var ndvi = image.normalizedDifference(['B8', 'B4']).rename('NDVI');
      return image.addBands(ndvi);
    };
     var addNDMI = function(image) {
      var ndmi = image.normalizedDifference(['B8', 'B11']).rename('NDMI');
      return image.addBands(ndmi);
    };
    // Add NDVI and NDRE bands to image composites.
      // assign each vegetation index to a variable, apply the function
        // to add it to the image as a band, then select that band.
    var ndvi_mayjune24 = addNDVI(mayjune24).select('NDVI');
    var ndmi_mayjune24 = addNDMI(mayjune24).select('NDMI');
    var ndvi_augsept24 = addNDVI(augsept24).select('NDVI');
    var ndmi_augsept24 = addNDMI(augsept24).select('NDMI');
    var ndvi_mayjune23 = addNDVI(mayjune23).select('NDVI');
    var ndmi_mayjune23 = addNDMI(mayjune23).select('NDMI');
    var ndvi_augsept23 = addNDVI(augsept23).select('NDVI');
    var ndmi_augsept23 = addNDMI(augsept23).select('NDMI');
// *** The lines below set up the map. ***
  // Center map on county.
  Map.centerObject(county, 11);
  Map.addLayer(ndvi_mayjune24, ndviParams, 'May-June 2024 NDVI', false);
  Map.addLayer(ndmi_mayjune24, ndmiParams, 'May-June 2024 NDMI');
  Map.addLayer(ndvi_augsept24, ndviParams, 'Aug-Sept 2024 NDVI', false);
  Map.addLayer(ndmi_augsept24, ndmiParams, 'Aug-Sept 2024 NDMI');
  Map.addLayer(ndvi_mayjune23, ndviParams, 'May-June 2023 NDVI', false);
  Map.addLayer(ndmi_mayjune23, ndmiParams, 'May-June 2023 NDMI', false);
  Map.addLayer(ndvi_augsept23, ndviParams, 'Aug-Sept 2023 NDVI', false);
  Map.addLayer(ndmi_augsept23, ndmiParams, 'Aug-Sept 2023 NDMI', false);
  //Create county outline and display.
  var empty = ee.Image().byte();
  var countyOutline = empty.paint({
    featureCollection: county,
    color: 1,
    width: 2
  });
  Map.addLayer(countyOutline, {}, "County boundary");
  //***Add legends to map display
  //**Legend for NDVI
  // set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'NDVI, NDMI from Sentinel-2 imagery (select "Layers" to choose map)',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
  // Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors of Cover classes
var palette =["FFFFFF","3BB143",'0000FF'];
// name of the legend
var names = ['white = low NDVI or NDMI','active green vegetation','high moisture'];
// Add color and and names
for (var i = 0; i < 3; i++) {
  legend.add(makeRow(palette[i], names[i]));
}
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend);