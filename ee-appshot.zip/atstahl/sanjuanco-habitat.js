//This script finds and displays available NAIP imagery for San Juan county
    // Look up county 5-digit FP code
// Load a Census Table of state boundaries and filter to county (by 5-digit FP code).
// https://www.nrcs.usda.gov/wps/portal/nrcs/detail/id/home/?cid=nrcs143_013697
  // San Juan County = '53055'
var county = ee.FeatureCollection('TIGER/2018/Counties')
        .filter(ee.Filter.eq('GEOID', '53055'));
    // Set visualization parameters for NAIP in true color.
    var visParams = {bands: ['R', 'G', 'B']};
    // Set visualization parameters for NAIP NDVI.
    var ndviParams = {min: 0, max: 0.5, palette: ['white', 'green']};
// *** Use these lines to query collection, change dates as desired. ***
    // Load NAIP imagery and filter it to time period & area of interest.
    var naip = ee.ImageCollection('USDA/NAIP/DOQQ')
        .filter(ee.Filter.bounds(county))
        .filterDate('2023-09-01', '2023-10-31');
    print('Collection: ', naip);
    // Get the number of images. (Should equal the no. of elements 
                             // in the filtered collection.)
    var count = naip.size();
    print('Count: ', count);
// Reduce the collection by taking the median, clip to county area.
var sjco_naip = naip.median().clip(county);
    //Compute NDVI and NDRE and add as bands to Sentinel median composite image.
      // Use the normalizedDifference(A, B) to compute (A - B) / (A + B) for each index.
    var addNDVI = function(image) {
      var ndvi = image.normalizedDifference(['N', 'R']).rename('NDVI');
      return image.addBands(ndvi);
    };
    // Add NDVI and NDRE bands to image composites.
      // assign each vegetation index to a variable, apply the function
        // to add it to the image as a band, then select that band.
    var sjco_ndvi = addNDVI(sjco_naip).select('NDVI');
// *** The lines below set up the map. ***
  // Center map on county.
  Map.centerObject(county, 11);
  Map.addLayer(sjco_naip, visParams, 'NAIP 2023 RGB');
  Map.addLayer(sjco_ndvi, ndviParams, 'NAIP 2023 NDVI');
  //Create county outline and display.
  var empty = ee.Image().byte();
  var countyOutline = empty.paint({
    featureCollection: county,
    color: 1,
    width: 2
  });
  Map.addLayer(countyOutline, {}, "County boundary");
  //***Add legends to map display
  //**Legend for NDVI
  // set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'NDVI from NAIP imagery (select "Layers" to view NAIP imagery)',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
  // Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors of Cover classes
var palette =["FFFFFF","3BB143"];
// name of the legend
var names = ['non-vegetated (white = water; light green is less active vegetation)','active green vegetation'];
// Add color and and names
for (var i = 0; i < 2; i++) {
  legend.add(makeRow(palette[i], names[i]));
}
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend);