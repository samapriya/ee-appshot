var table = ui.import && ui.import("table", "table", {
      "id": "users/atstahl/HUC8_outline"
    }) || ee.FeatureCollection("users/atstahl/HUC8_outline"),
    whitco = ui.import && ui.import("whitco", "table", {
      "id": "users/atstahl/WhitmanCo"
    }) || ee.FeatureCollection("users/atstahl/WhitmanCo"),
    garco = ui.import && ui.import("garco", "table", {
      "id": "users/atstahl/GarfieldCo"
    }) || ee.FeatureCollection("users/atstahl/GarfieldCo"),
    areaInterest = ui.import && ui.import("areaInterest", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -118.43603167902462,
                47.32918852427803
              ],
              [
                -118.43603167902462,
                45.96799818032082
              ],
              [
                -116.63427386652462,
                45.96799818032082
              ],
              [
                -116.63427386652462,
                47.32918852427803
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-118.43603167902462, 47.32918852427803],
          [-118.43603167902462, 45.96799818032082],
          [-116.63427386652462, 45.96799818032082],
          [-116.63427386652462, 47.32918852427803]]], null, false);
//This script finds and displays available NAIP imagery by county
    // Whitman/Garfield Co have NAIP coverage in 2003 (RGB) and 2004, 2005, 2006, 2009, 2011, 2013, 2015, 2017, 2019, 2021 (RGBN)
// *** The lines below set up the map. ***
    // Center map on Whitman County.
    Map.setCenter(-117.55, 46.65, 9);
    // Set visualization parameters for NAIP in true color.
    var visParams = {bands: ['R', 'G', 'B']};
    // Set visualization parameters for NAIP in color infrared.
    var CIRParams = {bands: ['N', 'R', 'G']};
// *** Use these lines to query collection, change dates as desired. ***
    // Load NAIP imagery and filter it to time period & area of interest.
    var collection = ee.ImageCollection('USDA/NAIP/DOQQ')
        .filter(ee.Filter.bounds(areaInterest))
        .filterDate('2021-01-01', '2021-12-31');
    //print('Collection: ', collection);
    // Get the number of images. (Should equal the no. of elements 
                             // in the filtered collection.)
    var count = collection.size();
    //print('Count: ', count);
    // Display the images.
    //Map.addLayer(collection, visParams, 'raw NAIP');
// Load NAIP imagery, filter it to year (2003, 04, 05, 06, 07, 09, 11, 13, 15, 17, 19, 21).
var raw = ee.ImageCollection('USDA/NAIP/DOQQ').filter(ee.Filter.bounds(areaInterest));
var raw03 = raw.filterDate('2003-01-01', '2003-12-31');
var raw04 = raw.filterDate('2004-01-01', '2004-12-31');
var raw05 = raw.filterDate('2005-01-01', '2005-12-31');
var raw06 = raw.filterDate('2006-01-01', '2006-12-31');
var raw09 = raw.filterDate('2009-01-01', '2009-12-31');
var raw11 = raw.filterDate('2011-01-01', '2011-12-31');
var raw13 = raw.filterDate('2013-01-01', '2013-12-31');
var raw15 = raw.filterDate('2015-01-01', '2015-12-31');
var raw17 = raw.filterDate('2017-01-01', '2017-12-31');
var raw19 = raw.filterDate('2019-01-01', '2019-12-31');
var raw21 = raw.filterDate('2021-01-01', '2021-12-31');
// Reduce the collection by taking the median, clip to area of interest.
var NAIP03 = raw03.median().clip(areaInterest);
var NAIP04 = raw04.median().clip(areaInterest);
var NAIP05 = raw05.median().clip(areaInterest);
var NAIP06 = raw06.median().clip(areaInterest);
var NAIP09 = raw09.median().clip(areaInterest);
var NAIP11 = raw11.median().clip(areaInterest);
var NAIP13 = raw13.median().clip(areaInterest);
var NAIP15 = raw15.median().clip(areaInterest);
var NAIP17 = raw17.median().clip(areaInterest);
var NAIP19 = raw19.median().clip(areaInterest);
var NAIP21 = raw21.median().clip(areaInterest);
// Display the result in true color.
Map.addLayer(NAIP03, visParams, 'NAIP 2003 RGB', false);
Map.addLayer(NAIP04, visParams, 'NAIP 2004 RGB', false);
Map.addLayer(NAIP05, visParams, 'NAIP 2005 RGB', false);
Map.addLayer(NAIP06, visParams, 'NAIP 2006 RGB', false);
Map.addLayer(NAIP09, visParams, 'NAIP 2009 4-band', false);
Map.addLayer(NAIP11, visParams, 'NAIP 2011 4-band', false);
Map.addLayer(NAIP13, visParams, 'NAIP 2013 4-band', false);
Map.addLayer(NAIP15, visParams, 'NAIP 2015 4-band', false);
Map.addLayer(NAIP17, visParams, 'NAIP 2017 4-band', false);
Map.addLayer(NAIP19, visParams, 'NAIP 2019 4-band', false);
Map.addLayer(NAIP21, visParams, 'NAIP 2021 4-band');
  //Create county outline and display.
  var empty = ee.Image().byte();
  var whitcoOutline = empty.paint({
    featureCollection: whitco,
    color: 1,
    width: 2.5
  });
  Map.addLayer(whitcoOutline, {}, "Whitman Co.");
  var garcoOutline = empty.paint({
    featureCollection: garco,
    color: 1,
    width: 2.5
  });
  Map.addLayer(garcoOutline, {}, "Garfield Co.");
// set position of panel for legend
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'annual NAIP true color composites (select year in "Layers")',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
 // Add the title to the panel
legend.add(legendTitle);
Map.add(legend);