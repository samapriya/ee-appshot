var Whitman = ui.import && ui.import("Whitman", "table", {
      "id": "users/atstahl/WhitmanCo"
    }) || ee.FeatureCollection("users/atstahl/WhitmanCo"),
    Garfield = ui.import && ui.import("Garfield", "table", {
      "id": "users/atstahl/GarfieldCo"
    }) || ee.FeatureCollection("users/atstahl/GarfieldCo"),
    update = ui.import && ui.import("update", "image", {
      "id": "projects/ee-atstahl/assets/ClassifiedImages/WC2022Update"
    }) || ee.Image("projects/ee-atstahl/assets/ClassifiedImages/WC2022Update"),
    USCounties = ui.import && ui.import("USCounties", "table", {
      "id": "TIGER/2018/Counties"
    }) || ee.FeatureCollection("TIGER/2018/Counties"),
    table = ui.import && ui.import("table", "table", {
      "id": "USFS/GTAC/MTBS/burned_area_boundaries/v1"
    }) || ee.FeatureCollection("USFS/GTAC/MTBS/burned_area_boundaries/v1");
// This script is for an app that displays the outcome of a cover change  
    // classification to compare 2020-2021 to previous VSP reporting for Whitman & Garfield Counties.
    // *** The lines below set up the map. ***
    // Center map on Whitman County.
    Map.setCenter(-117.55, 46.665, 9);
    // Color palette for cover classes.
      var palette = 
              ['5b5b5b', // 0 = areas of unknown/undetermined change (dark gray) 
              'fae5d3', // 1 = all years brown veg (tan)
              '2ecc71', // 2 = all years green veg (green)
              '17202a', // 3 = all years nonVeg (black)
              'a933ff', // 4 = all flipping green/brown (magenta)
              'ff8133', // 5 = green in baseline but not in 2020-2021 (orange)
              '33fffc', // 6 = brown in baseline, green in 2020 or 2021 (cyan)
              'd8dbdb']; // 7 = nonVeg sometimes in all years (light gray)
    // Display imported raster.
    Map.addLayer(update, {min: 0, max: 7, opacity: 0.7, palette: palette}, 'Comparing 2020-21 with the 2016-19 baseline');
  //Create county outlines and display.
  var empty = ee.Image().byte();
    //Display all US Counties for reference
   var countyOutlines = empty.paint({
    featureCollection: USCounties,
    color: 1,
    width: 1
  });
  Map.addLayer(countyOutlines, {}, "US Counties");
  var WCOutline = empty.paint({
    featureCollection: Whitman,
    color: 1,
    width: 2.5
  });
    var GCOutline = empty.paint({
    featureCollection: Garfield,
    color: 1,
    width: 2.5
  });
  Map.addLayer(WCOutline, {}, "Whitman Co.");
  Map.addLayer(GCOutline, {}, "Garfield Co.");
//MTBS for reference
ui.Map.FeatureViewLayer("USFS/GTAC/MTBS/burned_area_boundaries/v1_FeatureView")
  // set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Categories of possible change or no change from 2016-2019 to 2020-2021',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette =['5b5b5b', 'fae5d3', '2ecc71', '17202a', 'a933ff', 'ff8133', '33fffc','d8dbdb'];
// name of the legend
var names = ['other areas of change (not categorized)','brown vegetation all years (no change)','green vegetation all years (no change)', 
            'non-vegetated all years (no change)','consistently green or brown (change is within baseline variability)','green in 2016-2019 but not in either 2020 or 2021 (possible change, natural or management)', 
            'brown in 2016-2019, green in either 2020 or 2021 (possible change, natural or management)', 'occasionally classified as non-vegetated (may be error due to imperfect images)'];
// Add color and and names
for (var i = 0; i < 8; i++) {
  legend.add(makeRow(palette[i], names[i]));
}
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend);