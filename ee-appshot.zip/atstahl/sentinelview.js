var table = ui.import && ui.import("table", "table", {
      "id": "users/atstahl/HUC8_outline"
    }) || ee.FeatureCollection("users/atstahl/HUC8_outline"),
    county = ui.import && ui.import("county", "table", {
      "id": "users/atstahl/WhitmanCo"
    }) || ee.FeatureCollection("users/atstahl/WhitmanCo"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B4",
          "B3",
          "B2"
        ],
        "min": 0.03680000081658363,
        "max": 0.3181999921798706,
        "gamma": 1.945
      }
    }) || {"opacity":1,"bands":["B4","B3","B2"],"min":0.03680000081658363,"max":0.3181999921798706,"gamma":1.945},
    imageCIRParam = ui.import && ui.import("imageCIRParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B8",
          "B4",
          "B3"
        ],
        "min": 0.017999999225139618,
        "max": 0.396699994802475,
        "gamma": 1.945
      }
    }) || {"opacity":1,"bands":["B8","B4","B3"],"min":0.017999999225139618,"max":0.396699994802475,"gamma":1.945};
//This script finds and displays available Sentinel imagery by county
    // here we create late summer composites for 2016-2020
    // filter and mask clouds, median composite and clip to county.
// *** The lines below set up the map. ***
    // Center map on Whitman County.
    Map.setCenter(-117.5, 46.87, 10);
// ***Query, mask clouds, composite, clip Sentinel imagery. ***
      // Function to mask clouds using the Sentinel-2 QA band.
      function maskS2clouds(image) {
        var qa = image.select('QA60');
        // Bits 10 and 11 are clouds and cirrus, respectively.
        var cloudBitMask = 1 << 10;
        var cirrusBitMask = 1 << 11;
        // Both flags should be set to zero, indicating clear conditions.
        var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
                   qa.bitwiseAnd(cirrusBitMask).eq(0));
        // Return the masked and scaled data, without the QA bands.
        return image.updateMask(mask).divide(10000)
            .select("B.*")
            .copyProperties(image, ["system:time_start"]);
      }
// Map the cloud function over time period, create median composites, clip to ROI.
  // "Late Season" = 08/15 to 10/01
var collection = ee.ImageCollection('COPERNICUS/S2').filter(ee.Filter.bounds(county))
    // Pre-filter to get less cloudy granules, apply cloud mask.
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
    .map(maskS2clouds);
var sent16 = collection.filterDate('2016-08-15', '2016-10-01').median().clip(county);
var sent17 = collection.filterDate('2017-08-15', '2017-10-01').median().clip(county);
var sent18 = collection.filterDate('2018-08-15', '2018-10-01').median().clip(county);
var sent19 = collection.filterDate('2019-08-15', '2019-10-01').median().clip(county);
var sent20 = collection.filterDate('2020-08-15', '2020-10-01').median().clip(county);
Map.addLayer(sent16, imageVisParam, "Sentinel 2016 late season, RGB", false);
Map.addLayer(sent16, imageCIRParam, "Sentinel 2016 late season, CIR", false);
Map.addLayer(sent17, imageVisParam, "Sentinel 2017 late season, RGB", false);
Map.addLayer(sent17, imageCIRParam, "Sentinel 2017 late season, CIR", false);
Map.addLayer(sent18, imageVisParam, "Sentinel 2018 late season, RGB", false);
Map.addLayer(sent18, imageCIRParam, "Sentinel 2018 late season, CIR", false);
Map.addLayer(sent19, imageVisParam, "Sentinel 2019 late season, RGB", false);
Map.addLayer(sent19, imageCIRParam, "Sentinel 2019 late season, CIR", false);
Map.addLayer(sent20, imageVisParam, "Sentinel 2020 late season, RGB", false);
Map.addLayer(sent20, imageCIRParam, "Sentinel 2020 late season, CIR", false);
  //Create county outline and display.
  var empty = ee.Image().byte();
  var countyOutline = empty.paint({
    featureCollection: county,
    color: 1,
    width: 2
  });
  Map.addLayer(countyOutline, {}, "Whitman Co.");