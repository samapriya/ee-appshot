// Import the FeatureView asset as a FeatureViewLayer.
var assetId = 'users/gponce/usda_ars/assets/ft_views/ftv_prism800normal_detla_blm_allotments'
var layer = ui.Map.FeatureViewLayer(assetId);
var layer2 = ui.Map.FeatureViewLayer('users/gponce/usda_ars/assets/ft_views/ftv_prism800normal_detla_blm_allotments')
// Set visualization properties for the defined layer.
layer.setVisParams({
  color: {
    property: 'ppt_delta', // Property to visualize
    mode: 'interval', // Visualization mode
    palette: [
      [-237.16, 'CA592F'], // Define the range and corresponding color
      [-137.66, 'D57E41'],
      [-74.21, 'DFA061'], // Add additional ranges as needed
      [-36.91, 'E9C083'],
      [-16.14, 'F5E0A5'],
      [1.25, 'CEC88C'],
      [18.74, 'A8B173'],
      [39.55, '829A5C'],
      [75.52, '5B834B'],
    ]
  },
  width: 0.5, // Outline width
  fillOpacity: 0.99, // Fill opacity
});
// Add the FeatureViewLayer to the map.
Map.add(layer);
layer2.setVisParams({
  width: 0.8,
  polygonStrokeType:'dashed',
  fillOpacity: 0
})
// Add the FeatureViewLayer to the map.
Map.add(layer2);
// Define the legend colors and corresponding ranges
var legendColors = [
  'CA592F', // -237.16 to -137.66
  'D57E41', // -137.66 to -74.21
  'DFA061', // -74.21 to -36.91
  'E9C083', // -36.91 to -16.14
  'F5E0A5', // -16.14 to 1.25
  'CEC88C', // 1.25 to 18.74
  'A8B173', // 18.74 to 39.55
  '829A5C', // 39.55 to 75.52
  '5B834B'  // 75.52 to 259.64
];
var legendLabels = [
  '-237.17 to -137.66',
  '-137.66 to -74.21',
  '-74.21 to -36.91',
  '-36.91 to -16.14',
  '-16.14 to 1.25',
  '1.25 to 18.74',
  '18.74 to 39.55',
  '39.55 to 75.52',
  '75.52 to 259.64'
];
// Create a legend panel with title
var legendPanel = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px'
  }
});
var legendTitle = ui.Label({
  value: ' Δ Precip. (Norm91 - Norm81) [mm] ',
  style: {
    fontWeight: 'bold',
    fontSize: '16px',
    margin: '0 0 4px 0',
    padding: '0'
  }
});
legendPanel.add(legendTitle);
// Add legend entries
for (var i = 0; i < legendColors.length; i++) {
  var color = legendColors[i];
  var label = legendLabels[i];
  var legendEntry = ui.Panel({
    style: {
      backgroundColor: color,
      padding: '5px',
      margin: '2px 0',
      fontSize: '12px',
      fontWeight: 'bold'
    }
  });
  legendEntry.add(ui.Label(label));
  legendPanel.add(legendEntry);
}
// Add legend to the map
Map.add(legendPanel);
Map.setOptions('HYBRID')
Map.setCenter(-115.7129, 39.8283, 6)