// Load data
var table = ee.FeatureCollection("users/gponce/usda_ars/shapefiles/MHERNANDEZ/polygons_soilsa_nrcs");
// Load soil data layers (same as original script)
// Clay data
var clay_p_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/claytotal_0_cm_p.tif').rename('clay_p');
var clay_h_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/claytotal_0_cm_h.tif').rename('clay_h');
var clay_l_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/claytotal_0_cm_l.tif').rename('clay_l');
var clay_rpi_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/claytotal_0_cm_rpi.tif').rename('clay_rpi');
// Sand data
var sand_h_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/sandtotal_0_cm_h.tif').rename('sand_h');
var sand_l_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/sandtotal_0_cm_l.tif').rename('sand_l');
var sand_p_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/sandtotal_0_cm_p.tif').rename('sand_p');
var sand_rpi_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/sandtotal_0_cm_rpi.tif').rename('sand_rpi');
// Silt data
var silt_h_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/silttotal_0_cm_h.tif').rename('silt_h');
var silt_l_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/silttotal_0_cm_l.tif').rename('silt_l');
var silt_p_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/silttotal_0_cm_p.tif').rename('silt_p');
var silt_rpi_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/silttotal_0_cm_rpi.tif').rename('silt_rpi');
// Load pre-calculated soil texture layer
var texture_p_0_cm = ee.Image("users/gponce/usda_ars/images/solus/soil_texture_0cm_p").rename('texture');
// Create a data dictionary for easy access
var soilData = {
  'clay': {
    'p': clay_p_0_cm,
    'h': clay_h_0_cm,
    'l': clay_l_0_cm,
    'rpi': clay_rpi_0_cm
  },
  'sand': {
    'p': sand_p_0_cm,
    'h': sand_h_0_cm,
    'l': sand_l_0_cm,
    'rpi': sand_rpi_0_cm
  },
  'silt': {
    'p': silt_p_0_cm,
    'h': silt_h_0_cm,
    'l': silt_l_0_cm,
    'rpi': silt_rpi_0_cm
  }
};
// Filter the table to include only target area symbols
var target_areasymbols = ['MN031', 'MN075', 'NH605', 'VT007', 'MN115', 'MT640', 'WY603', 'WY617',
                         'MT642', 'WY661', 'ID701', 'ID720', 'ID671', 'ID700', 'WA762', 'OR608',
                         'WA706', 'WA760', 'OR607', 'OR631', 'WA714', 'OR645', 'NV792', 'OR605',
                         'OR657', 'OR603', 'OR622', 'OR683', 'OR680', 'CA704', 'CA601', 'NV782',
                         'UT626', 'CA793', 'UT646', 'CA663', 'CA682', 'CA695', 'CA698', 'CA805',
                         'CA803', 'CA804', 'AZ647', 'AZ648', 'AZ691', 'AZ723', 'NM622', 'CO657',
                         'NM694', 'NM696', 'AZ687', 'AZ639', 'AZ693', 'UT636', 'WY630', 'UT625',
                         'UT648', 'WY737', 'UT647', 'UT650', 'UT607', 'WY723', 'CO031', 'GA637',
                         'GA648', 'KY643', 'WI079', 'FL623', 'FL687', 'TN125', 'FL624', 'HT600',
                         'NY109', 'NY664'];
table = table.filter(ee.Filter.inList('areasymbol', target_areasymbols));
// Set map view
Map.centerObject(table, 5);
Map.setOptions('HYBRID');
// Define color palettes for different soil particles
var colorPalettes = {
  'clay': ['#2E0854', '#3A0CA3', '#480CA8', '#4361EE', '#4CC9F0', 
           '#00B4D8', '#0096C7', '#02C39A', '#8AC926', '#FFFF00'],
  'sand': ['#2E0854', '#3A0CA3', '#480CA8', '#4361EE', '#4CC9F0', 
           '#00B4D8', '#0096C7', '#02C39A', '#8AC926', '#FFFF00'],
  'silt': ['#2E0854', '#3A0CA3', '#480CA8', '#4361EE', '#4CC9F0', 
           '#00B4D8', '#0096C7', '#02C39A', '#8AC926', '#FFFF00']
};
// Updated texture colors using exact color meter values
var textureColors = {
  'c': '#BBFDD9',     // Clay
  'sc': '#FA3FCA',    // Sandy Clay
  'cl': '#8AFDE2',    // Clay Loam
  'sic': '#FDE6A8',   // Silty Clay
  'scl': '#FCAFEA',   // Sandy Clay Loam
  'l': '#FDEB4C',     // Loam
  'sicl': '#F1BE5A',  // Silty Clay Loam
  'sl': '#DFD8FD',    // Sandy Loam
  'sil': '#3CF7AA',   // Silt Loam
  'ls': '#FDD8F2',    // Loamy Sand
  'si': '#D4FA4B',    // Silt
  's': '#FCB0D3'      // Sand
};
// Create texture palette array for visualization
var textureColorList = [
  textureColors['si'],    // 1: Silt
  textureColors['sil'],   // 2: Silt Loam
  textureColors['sicl'],  // 3: Silty Clay Loam
  textureColors['sic'],   // 4: Silty Clay
  textureColors['c'],     // 5: Clay
  textureColors['cl'],    // 6: Clay Loam
  textureColors['l'],     // 7: Loam
  textureColors['scl'],   // 8: Sandy Clay Loam
  textureColors['sc'],    // 9: Sandy Clay
  textureColors['s'],     // 10: Sand
  textureColors['ls'],    // 11: Loamy Sand
  textureColors['sl']     // 12: Sandy Loam
];
// Define texture class names for the legend
var textureNames = {
  1: 'Silt (si)',
  2: 'Silt Loam (sil)',
  3: 'Silty Clay Loam (sicl)',
  4: 'Silty Clay (sic)',
  5: 'Clay (c)',
  6: 'Clay Loam (cl)',
  7: 'Loam (l)',
  8: 'Sandy Clay Loam (scl)',
  9: 'Sandy Clay (sc)',
  10: 'Sand (s)',
  11: 'Loamy Sand (ls)',
  12: 'Sandy Loam (sl)'
};
// Define metric types
var metricTypes = [
  {label: 'Predicted (p)', value: 'p'},
  {label: 'Upper Interval (h)', value: 'h'},
  {label: 'Lower Interval (l)', value: 'l'},
  {label: 'Relative Interval (rpi)', value: 'rpi'}
];
// Create UI components
var app = {};
// Store the current area name
app.currentAreaName = null;
// ---- NEW UI DESIGN BEGINS HERE ----
// Create the main panel as a container with tabs
app.mainPanel = ui.Panel({
  style: {
    width: '360px',  // Adjusted to a more reasonable width that won't cause scrollbars
    padding: '0',
    position: 'top-left',
    maxHeight: '90%'
  }
});
// Header panel
app.headerPanel = ui.Panel({
  widgets: [
    ui.Label({
      value: '🌎 SOLUS Properties Stats',
      style: {
        fontSize: '18px',
        fontWeight: 'bold',
        padding: '10px',
        backgroundColor: '#2F3E46',  // Deep slate blue-gray
        color: '#CAD2C5',            // Soft mint/sage
        width: '100%',
        margin: '0'
      }
    }),
    ui.Label({
      value: 'Present soil properties map and stats within selected NRCS polygons',
      style: {
        fontSize: '11px',
        padding: '0 10px 10px 10px',
        backgroundColor: '#2F3E46',  // Deep slate blue-gray
        color: '#CAD2C5',            // Soft mint/sage
        width: '100%',
        margin: '0'
      }
    })
  ],
  style: {
    padding: '0',
    margin: '0',
    backgroundColor: '#2F3E46',
    width: '100%',
    stretch: 'horizontal'
  }
});
// Tab buttons panel
app.tabButtons = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    backgroundColor: '#f5f5f5',
    padding: '0',
    margin: '0'
  }
});
// Create tab buttons with better contrast
// Data tab starts as active
app.dataTabButton = ui.Button({
  label: 'Data Selection',
  style: {
    backgroundColor: '#FFFFFF',
    color: '#2F3E46',           // Matching header color scheme
    padding: '8px 5px',
    margin: '0 0 -1px 0',
    border: '1px solid #aaa',
    width: '120px',
    textAlign: 'center',
    fontWeight: 'bold'
  }
});
app.resultsTabButton = ui.Button({
  label: 'Results',
  style: {
    backgroundColor: '#e0e0e0',
    color: '#666666',
    padding: '8px 5px',
    margin: '0',
    border: '1px solid #aaa',
    width: '120px',
    textAlign: 'center'
  }
});
app.referenceTabButton = ui.Button({
  label: 'Reference',
  style: {
    backgroundColor: '#e0e0e0',
    color: '#666666',
    padding: '8px 5px',
    margin: '0',
    border: '1px solid #aaa',
    width: '120px',
    textAlign: 'center'
  }
});
// Add buttons to tab panel
app.tabButtons.add(app.dataTabButton);
app.tabButtons.add(app.resultsTabButton);
app.tabButtons.add(app.referenceTabButton);
// Content panels for each tab
app.dataContentPanel = ui.Panel({
  style: {
    shown: true,
    padding: '10px',
    margin: '0'
  }
});
app.resultsContentPanel = ui.Panel({
  style: {
    shown: false,
    padding: '10px',
    margin: '0'
  }
});
app.referenceContentPanel = ui.Panel({
  style: {
    shown: false,
    padding: '10px',
    margin: '0'
  }
});
// Add tab switching logic with better visibility
app.dataTabButton.onClick(function() {
  app.dataContentPanel.style().set('shown', true);
  app.resultsContentPanel.style().set('shown', false);
  app.referenceContentPanel.style().set('shown', false);
  // Active tab (Data)
  app.dataTabButton.style().set({
    'backgroundColor': '#FFFFFF',
    'color': '#2F3E46',
    'fontWeight': 'bold',
    'margin': '0 0 -1px 0'
  });
  // Inactive tabs
  app.resultsTabButton.style().set({
    'backgroundColor': '#e0e0e0',
    'color': '#666666',
    'fontWeight': 'normal',
    'margin': '0'
  });
  app.referenceTabButton.style().set({
    'backgroundColor': '#e0e0e0',
    'color': '#666666',
    'fontWeight': 'normal',
    'margin': '0'
  });
});
app.resultsTabButton.onClick(function() {
  app.dataContentPanel.style().set('shown', false);
  app.resultsContentPanel.style().set('shown', true);
  app.referenceContentPanel.style().set('shown', false);
  // Inactive tab
  app.dataTabButton.style().set({
    'backgroundColor': '#e0e0e0',
    'color': '#666666',
    'fontWeight': 'normal',
    'margin': '0'
  });
  // Active tab (Results)
  app.resultsTabButton.style().set({
    'backgroundColor': '#FFFFFF',
    'color': '#2F3E46',
    'fontWeight': 'bold',
    'margin': '0 0 -1px 0'
  });
  // Inactive tab
  app.referenceTabButton.style().set({
    'backgroundColor': '#e0e0e0',
    'color': '#666666',
    'fontWeight': 'normal',
    'margin': '0'
  });
});
app.referenceTabButton.onClick(function() {
  app.dataContentPanel.style().set('shown', false);
  app.resultsContentPanel.style().set('shown', false);
  app.referenceContentPanel.style().set('shown', true);
  // Inactive tabs
  app.dataTabButton.style().set({
    'backgroundColor': '#e0e0e0',
    'color': '#666666',
    'fontWeight': 'normal',
    'margin': '0'
  });
  app.resultsTabButton.style().set({
    'backgroundColor': '#e0e0e0',
    'color': '#666666',
    'fontWeight': 'normal',
    'margin': '0'
  });
  // Active tab (Reference)
  app.referenceTabButton.style().set({
    'backgroundColor': '#FFFFFF',
    'color': '#2F3E46',
    'fontWeight': 'bold',
    'margin': '0 0 -1px 0'
  });
});
// Construct the DATA SELECTION tab
// 1. Soil Data Selection section
var soilDataPanel = ui.Panel({
  style: {
    margin: '0 0 10px 0',
    padding: '6px',
    border: '1px solid #ddd',
    backgroundColor: '#fafafa'
  }
});
soilDataPanel.add(ui.Label({
  value: 'Select soil data:',
  style: {
    fontSize: '14px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  }
}));
// Create particle selector
soilDataPanel.add(ui.Label('Soil Particle:', {margin: '0 0 2px 0', fontSize: '12px'}));
app.particleSelect = ui.Select({
  items: ['clay', 'sand', 'silt'],
  value: 'clay',
  style: {width: '100%', margin: '0 0 8px 0'}
});
soilDataPanel.add(app.particleSelect);
// Create metric selector
soilDataPanel.add(ui.Label('Metric:', {margin: '4px 0 2px 0', fontSize: '12px'}));
app.metricSelect = ui.Select({
  items: metricTypes.map(function(item) { return item.label; }),
  value: 'Predicted (p)',
  style: {width: '100%'}
});
soilDataPanel.add(app.metricSelect);
// 2. Location Selection section
var locationPanel = ui.Panel({
  style: {
    margin: '0 0 10px 0',
    padding: '6px',
    border: '1px solid #ddd',
    backgroundColor: '#fafafa'
  }
});
locationPanel.add(ui.Label({
  value: 'Select an area:',
  style: {
    fontSize: '14px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  }
}));
// State selector
locationPanel.add(ui.Label('State:', {margin: '0 0 2px 0', fontSize: '12px'}));
app.stateSelect = ui.Select({
  placeholder: 'Choose a state',
  style: {width: '100%', margin: '0 0 8px 0'}
});
locationPanel.add(app.stateSelect);
// Area symbol selector
locationPanel.add(ui.Label('Area Symbol:', {margin: '4px 0 2px 0', fontSize: '12px'}));
app.areaSelect = ui.Select({
  placeholder: 'Choose an area symbol',
  style: {width: '100%'}
});
locationPanel.add(app.areaSelect);
// Add reset button
app.resetButton = ui.Button({
  label: 'Reset View',
  onClick: function() {
    Map.centerObject(table, 5);
  },
  style: {
    margin: '10px 0 0 0',
    backgroundColor: '#4393C3',
    color: 'white',
    width: '100%'
  }
});
// Add reset button to location panel
locationPanel.add(app.resetButton);
// Add both panels to data content panel
app.dataContentPanel.add(soilDataPanel);
app.dataContentPanel.add(locationPanel);
// Construct the RESULTS tab content - Statistics and histograms
// Stats panel
app.statsPanel = ui.Panel({
  style: {
    margin: '0 0 10px 0',
    padding: '8px',
    border: '1px solid #ddd',
    backgroundColor: '#fafafa'
  }
});
app.statsPanel.add(ui.Label({
  value: 'Soil Statistics:',
  style: {
    fontSize: '14px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  }
}));
// Add placeholders for statistics
app.minLabel = ui.Label('Min: -');
app.maxLabel = ui.Label('Max: -');
app.meanLabel = ui.Label('Mean: -');
app.stdLabel = ui.Label('Std Dev: -');
app.statsPanel.add(app.minLabel);
app.statsPanel.add(app.maxLabel);
app.statsPanel.add(app.meanLabel);
app.statsPanel.add(app.stdLabel);
// Histogram panel
app.histogramPanel = ui.Panel({
  style: {
    margin: '0 0 10px 0',
    padding: '8px',
    border: '1px solid #ddd',
    backgroundColor: '#fafafa'
  }
});
app.histogramPanel.add(ui.Label({
  value: 'Distribution:',
  style: {
    fontSize: '14px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  }
}));
// Add stats panels to results content panel
app.resultsContentPanel.add(app.statsPanel);
app.resultsContentPanel.add(app.histogramPanel);
// Construct the REFERENCE tab content - Soil triangle
// Triangle panel
app.trianglePanel = ui.Panel({
  style: {
    margin: '0',
    padding: '8px',
    border: '1px solid #ddd',
    backgroundColor: '#fafafa'
  }
});
app.trianglePanel.add(ui.Label({
  value: 'Soil Texture Triangle:',
  style: {
    fontSize: '14px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  }
}));
// Load soil texture triangle from Earth Engine asset
var triangleImage = ee.Image("users/gponce/soil_texture_triangle");
// Create a thumbnail to display the triangle
var triangleThumbnail = ui.Thumbnail({
  image: triangleImage,
  params: {
    bands: ['b1', 'b2', 'b3'],
    min: 0,
    max: 255,
    dimensions: 2500
  },
  style: {
    width: '100%',
    margin: '0 auto 5px auto'
  }
});
// Add the thumbnail to the panel
app.trianglePanel.add(triangleThumbnail);
// Add a compact texture class legend directly below the triangle for reference
app.trianglePanel.add(ui.Label({
  value: 'Soil Texture Classes:',
  style: {
    fontSize: '13px',
    fontWeight: 'bold',
    margin: '8px 0 5px 0'
  }
}));
// Create a 3-column layout for more compact display in the left panel
var triangleColumnsPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {width: '100%', padding: '0', margin: '0'}
});
var triangleLeftColumn = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {width: '33%', padding: '0', margin: '0'}
});
var triangleMiddleColumn = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {width: '33%', padding: '0', margin: '0'}
});
var triangleRightColumn = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {width: '33%', padding: '0', margin: '0'}
});
// Add legend items for each texture class in the triangle panel - more compact
for (var i = 1; i <= 12; i++) {
  var item = ui.Panel({
    layout: ui.Panel.Layout.flow('horizontal'),
    style: {
      margin: '0 0 2px 0',
      padding: '0'
    }
  });
  // Color box - smaller for compact display
  var colorBox = ui.Label({
    style: {
      backgroundColor: textureColorList[i-1],
      padding: '4px',
      margin: '0 2px 0 0',
      width: '8px',
      height: '8px'
    }
  });
  // Text label - smaller font for compact display
  var textLabel = ui.Label({
    value: textureNames[i],
    style: {
      margin: '0',
      fontSize: '9px',
      fontWeight: 'normal', // consistent normal weight for all items
      color:"#000000"
    }
  });
  item.add(colorBox);
  item.add(textLabel);
  // Distribute 4 items per column for 3-column layout
  if (i <= 4) {
    triangleLeftColumn.add(item);
  } else if (i <= 8) {
    triangleMiddleColumn.add(item);
  } else {
    triangleRightColumn.add(item);
  }
}
triangleColumnsPanel.add(triangleLeftColumn);
triangleColumnsPanel.add(triangleMiddleColumn);
triangleColumnsPanel.add(triangleRightColumn);
app.trianglePanel.add(triangleColumnsPanel);
// Add a note about using the triangle
app.trianglePanel.add(ui.Label({
  value: 'Soil texture is determined by the relative percentages of sand, silt, and clay particles.',
  style: {
    fontSize: '11px',
    margin: '8px 0 0 0',
    color: '#666',
    fontStyle: 'italic'
  }
}));
// Add the triangle panel to the reference content panel
app.referenceContentPanel.add(app.trianglePanel);
// Add copyright at the bottom of the reference panel
app.referenceContentPanel.add(ui.Label({
  value: '© USDA-ARS SWRC ' + new Date().getFullYear(),
  style: {
    fontSize: '11px',
    color: '#999',
    margin: '15px 0 0 0',
    textAlign: 'center'
  }
}));
// Assemble the main panel
app.mainPanel.add(app.headerPanel);
app.mainPanel.add(app.tabButtons);
app.mainPanel.add(app.dataContentPanel);
app.mainPanel.add(app.resultsContentPanel);
app.mainPanel.add(app.referenceContentPanel);
// Create the legend panel with collapsible feature
app.legendPanel = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px',
    backgroundColor: 'white',
    border: '1px solid #ddd',
    maxWidth: '350px',
    maxHeight: '450px'
  }
});
// Create a header with controls for the legend panel
var legendHeaderPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    margin: '0 0 8px 0',
    padding: '0'
  }
});
// Add legend title
var legendTitle = ui.Label({
  value: 'Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0'
  }
});
// Create toggle button for legend
var legendExpanded = true;
var legendToggleButton = ui.Button({
  label: '−',
  onClick: function() {
    legendExpanded = !legendExpanded;
    app.legendContentPanel.style().set('shown', legendExpanded);
    legendToggleButton.setLabel(legendExpanded ? '−' : '+');
  },
  style: {
    padding: '0 4px',
    margin: '0 0 0 auto',
    fontSize: '16px'
  }
});
legendHeaderPanel.add(legendTitle);
legendHeaderPanel.add(legendToggleButton);
app.legendPanel.add(legendHeaderPanel);
// Create content panel for legend that can be collapsed
app.legendContentPanel = ui.Panel({
  style: {
    padding: '0',
    margin: '0'
  }
});
app.legendPanel.add(app.legendContentPanel);
// Create the distribution panel with collapsible feature
app.distributionPanel = ui.Panel({
  style: {
    position: 'top-right',
    padding: '8px',
    backgroundColor: 'white',
    border: '1px solid #ddd',
    width: '500px',
    maxHeight: '450px'
  }
});
// Create a header with controls for the distribution panel
var distHeaderPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    margin: '0 0 8px 0',
    padding: '0',
    width: '100%'
  }
});
// Create toggle button for distribution panel and place it first
var distExpanded = false; // Start minimized
app.distToggleButton = ui.Button({
  label: '+', // Start with + button since it's collapsed
  onClick: function() {
    distExpanded = !distExpanded;
    app.distributionContentPanel.style().set('shown', distExpanded);
    app.distToggleButton.setLabel(distExpanded ? '−' : '+');
    // Update the title based on state
    if (distExpanded) {
      // Try to restore the area name if it was previously shown
      if (app.currentAreaName) {
        app.distTitle.setValue('Soil Texture Distribution: ' + app.currentAreaName);
      } else {
        app.distTitle.setValue('Soil Texture Distribution');
      }
    } else {
      app.distTitle.setValue('Show soil texture area distribution');
    }
  },
  style: {
    padding: '0 6px',
    margin: '0 8px 0 0',
    fontSize: '16px'
  }
});
// Title container to take remaining space
var titleContainer = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    margin: '0',
    padding: '0',
    width: '90%'
  }
});
// Add distribution title (starts with collapsed message)
app.distTitle = ui.Label({
  value: 'Show soil texture area distribution',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0'
  }
});
// Add components in the new order
titleContainer.add(app.distTitle);
distHeaderPanel.add(app.distToggleButton);  // Button first
distHeaderPanel.add(titleContainer);        // Then title
app.distributionPanel.add(distHeaderPanel);
// Create content panel for distribution that starts collapsed
app.distributionContentPanel = ui.Panel({
  style: {
    padding: '0',
    margin: '0',
    shown: false  // Start hidden
  }
});
app.distributionContentPanel.add(ui.Label('Select an area to view soil texture distribution.'));
app.distributionPanel.add(app.distributionContentPanel);
// Add panels to map
Map.add(app.mainPanel);
Map.add(app.legendPanel);
Map.add(app.distributionPanel);
// Helper function to get metric value from label
function getMetricValue(label) {
  for (var i = 0; i < metricTypes.length; i++) {
    if (metricTypes[i].label === label) {
      return metricTypes[i].value;
    }
  }
  return 'p'; // Default
}
// Helper function to get display name for soil particle
function getParticleDisplayName(particle) {
  return particle.charAt(0).toUpperCase() + particle.slice(1);
}
// Helper function to get display name for the metric
function getMetricDisplayName(metricCode) {
  for (var i = 0; i < metricTypes.length; i++) {
    if (metricTypes[i].value === metricCode) {
      return metricTypes[i].label;
    }
  }
  return 'Predicted';
}
// Function to create a histogram chart (same as original)
function createHistogram(values, min, max, title) {
  // Create our own bins and count frequencies
  var numBins = 8;
  var binWidth = (max - min) / numBins;
  // Initialize bin counts
  var binCounts = [];
  var binLabels = [];
  // Create bin labels and initialize counts
  for (var i = 0; i < numBins; i++) {
    var binStart = min + i * binWidth;
    binLabels.push(Math.round(binStart));
    binCounts.push(0);
  }
  // Add the last bin edge
  binLabels.push(Math.round(max));
  // Count values in each bin
  values.forEach(function(value) {
    if (value >= min && value <= max) {
      var binIndex = Math.min(Math.floor((value - min) / binWidth), numBins - 1);
      binCounts[binIndex]++;
    }
  });
  // Create a DataTable for the chart
  var dataTable = [['Bin', 'Frequency']];
  for (var i = 0; i < numBins; i++) {
    dataTable.push([binLabels[i].toString(), binCounts[i]]);
  }
  // Create the chart
  var histChart = ui.Chart(dataTable)
    .setChartType('ColumnChart')
    .setOptions({
      title: '',
      titleTextStyle: {fontSize: '13px'},
      legend: {position: 'none'},
      hAxis: {
        title: title,
        titleTextStyle: {fontSize: '11px'},
        textStyle: {fontSize: '9px'},
        gridlines: {count: 4, color: '#f5f5f5'},
        showTextEvery: 2
      },
      vAxis: {
        title: 'Frequency',
        titleTextStyle: {fontSize: '11px'},
        textStyle: {fontSize: '9px'},
        gridlines: {count: 3, color: '#f5f5f5'},
        minValue: 0,
        baselineColor: '#999'
      },
      chartArea: {width: '85%', height: '75%', left: '12%', top: '15%'},
      width: '100%',
      height: '200px',
      colors: ['#4393c3'],
      backgroundColor: {fill: '#FFFFFF'},
      bar: {groupWidth: '85%'},
      axisTitlesPosition: 'out'
    });
  return histChart;
}
// Update Map Function - Modified to work with the new UI layout
function updateMap() {
  // Clear previous layers
  Map.layers().reset();
  // Reset distribution panel
  app.distributionContentPanel.clear();
  app.distributionContentPanel.add(ui.Label('Loading soil texture data...'));
  // Get selected values
  var selectedParticle = app.particleSelect.getValue();
  var selectedMetricLabel = app.metricSelect.getValue();
  var selectedAreaSymbol = app.areaSelect.getValue();
  // If any selection is missing, return
  if (!selectedParticle || !selectedMetricLabel || !selectedAreaSymbol) {
    app.distributionContentPanel.clear();
    app.distributionContentPanel.add(ui.Label('Select an area to view soil texture distribution.'));
    return;
  }
  // Get metric value
  var selectedMetric = getMetricValue(selectedMetricLabel);
  // Filter the feature collection to get features with the selected area symbol
  var selectedFeatures = table.filter(ee.Filter.eq('areasymbol', selectedAreaSymbol));
  // Get the area name for displaying in the legend
  selectedFeatures.first().get('areaname').evaluate(function(areaName) {
    // Add the selected features to the map with hollow style (only borders)
    Map.addLayer(selectedFeatures.style({
      color: '#00E050',
      width: 2,
      fillColor: '00000000'
    }), {}, 'Selected Area');
    // Get the soil particle data
    var soilImage = soilData[selectedParticle][selectedMetric];
    // Clip the soil data to the selected features
    var clippedSoil = soilImage.clip(selectedFeatures);
    // Mask pixels with no data
    clippedSoil = clippedSoil.updateMask(clippedSoil.gt(0));
    // Get statistics of soil data within the area
    var stats = clippedSoil.reduceRegion({
      reducer: ee.Reducer.mean().combine({
        reducer2: ee.Reducer.stdDev(),
        sharedInputs: true
      }).combine({
        reducer2: ee.Reducer.minMax(),
        sharedInputs: true
      }),
      geometry: selectedFeatures.geometry(),
      scale: 100,
      maxPixels: 1e13
    });
    // Get the pre-calculated texture layer for the area
    var textureImage = texture_p_0_cm.clip(selectedFeatures);
    // Mask pixels with no data
    textureImage = textureImage.updateMask(textureImage.gt(0));
    // Update distribution panel with actual pie chart
    app.distributionContentPanel.clear();
    // Create a histogram of the texture classes
    var textureHist = textureImage.reduceRegion({
      reducer: ee.Reducer.frequencyHistogram(),
      geometry: selectedFeatures.geometry(),
      scale: 100,
      maxPixels: 1e9
    });
    // Process the histogram data for the pie chart
    textureHist.get('texture').evaluate(function(textureCounts) {
      if (!textureCounts) {
        app.distributionContentPanel.add(ui.Label('No texture data available for this area.'));
        return;
      }
      // Store the current area name for use when toggle happens
      app.currentAreaName = areaName;
      // Update title to include area name (only when expanded)
      if (distExpanded) {
        app.distTitle.setValue('Soil Texture Distribution: ' + areaName);
      }
      // Process data for the chart
      var pixelArea = 10000; // 100m x 100m
      var totalPixels = 0;
      var chartData = [['Texture Class', 'Area']];
      var colors = [];
      // Extract data for the chart
      for (var classValue in textureCounts) {
        var classIndex = parseInt(classValue) - 1;
        if (classIndex >= 0 && classIndex < 12) {
          var pixels = textureCounts[classValue];
          if (pixels > 0) {
            totalPixels += pixels;
            try {
              var className = textureNames[parseInt(classValue)].split(' (')[0];
              if (className && className.length > 0) {
                chartData.push([className, pixels]);
                colors.push(textureColorList[classIndex]);
              }
            } catch (e) {
              console.log('Error processing texture class:', e);
              continue;
            }
          }
        }
      }
      // Create chart if we have data
      if (chartData.length > 1) {
        var chart = ui.Chart(chartData)
          .setChartType('PieChart')
          .setOptions({
            colors: colors,
            is3D: true,
            height: 220,
            width: 420,
            legend: {position: 'right'},
            backgroundColor: {fill: '#FFFFFF'}
          });
        app.distributionContentPanel.add(chart);
        // Calculate and display total area
        var totalAreaAcres = (totalPixels * pixelArea / 10000) * 2.47105;
        var totalAreaHectares = (totalPixels * pixelArea / 10000);
        app.distributionContentPanel.add(ui.Label({
          value: 'Total Area: ' + totalAreaAcres.toFixed(1) + ' acres (' + 
                totalAreaHectares.toFixed(1) + ' hectares)',
          style: {
            fontSize: '13px',
            fontWeight: 'bold',
            margin: '8px 0 0 0'
          }
        }));
        // Create a data table showing the breakdown by texture class
        var tablePanel = ui.Panel({
          style: {
            margin: '10px 0 0 0',
            maxHeight: '150px'
          }
        });
        // Add table header
        var headerPanel = ui.Panel({
          layout: ui.Panel.Layout.flow('horizontal'),
          style: {
            padding: '3px',
            margin: '0',
            backgroundColor: '#eee',
            fontWeight: 'bold',
            fontSize: '12px'
          }
        });
        headerPanel.add(ui.Label('Texture Class', {width: '160px'}));
        headerPanel.add(ui.Label('Acres', {width: '80px', textAlign: 'right'}));
        headerPanel.add(ui.Label('Hectares', {width: '80px', textAlign: 'right'}));
        headerPanel.add(ui.Label('%', {width: '50px', textAlign: 'right'}));
        tablePanel.add(headerPanel);
        // Sort data for presentation (largest to smallest)
        var sortedData = [];
        for (var i = 1; i < chartData.length; i++) {
          var className = chartData[i][0];
          var pixels = chartData[i][1];
          var classIndex = -1;
          // Find class index based on name
          for (var j = 1; j <= 12; j++) {
            if (textureNames[j].split(' (')[0] === className) {
              classIndex = j - 1;
              break;
            }
          }
          if (classIndex >= 0) {
            sortedData.push({
              label: className,
              value: pixels,
              color: textureColorList[classIndex],
              area: {
                hectares: (pixels * pixelArea / 10000),
                acres: (pixels * pixelArea / 10000) * 2.47105
              }
            });
          }
        }
        // Sort by area (largest first)
        sortedData.sort(function(a, b) {
          return b.value - a.value;
        });
        // Add rows for each texture class
        sortedData.forEach(function(item) {
          var rowPanel = ui.Panel({
            layout: ui.Panel.Layout.flow('horizontal'),
            style: {
              padding: '3px',
              margin: '0',
              backgroundColor: 'white',
              fontSize: '11px',
              // borderBottom: '1px solid #eee'
            }
          });
          // Create color box and label
          var itemLabelPanel = ui.Panel({
            layout: ui.Panel.Layout.flow('horizontal'),
            style: {width: '160px'}
          });
          var colorBox = ui.Label({
            style: {
              backgroundColor: item.color,
              padding: '6px',
              margin: '0 5px 0 0',
              width: '10px',
              height: '10px',
              border: '1px solid #ddd'
            }
          });
          itemLabelPanel.add(colorBox);
          itemLabelPanel.add(ui.Label(item.label));
          rowPanel.add(itemLabelPanel);
          // Add area values
          var acres = item.area.acres.toFixed(1);
          var hectares = item.area.hectares.toFixed(1);
          var percentage = ((item.value / totalPixels) * 100).toFixed(1) + '%';
          rowPanel.add(ui.Label(acres, {width: '80px', textAlign: 'right'}));
          rowPanel.add(ui.Label(hectares, {width: '80px', textAlign: 'right'}));
          rowPanel.add(ui.Label(percentage, {width: '50px', textAlign: 'right'}));
          tablePanel.add(rowPanel);
        });
        app.distributionContentPanel.add(tablePanel);
      } else {
        app.distributionContentPanel.add(ui.Label('No soil texture classes found in this area.'));
      }
    });
    // Get band name for selected soil particle
    var bandName = selectedParticle + '_' + selectedMetric;
    // Sample points for histogram
    var samples = clippedSoil.sample({
      region: selectedFeatures.geometry(),
      scale: 100,
      numPixels: 5000,
      seed: 123
    });
    // Get sample values
    var sampleValues = samples.aggregate_array(bandName);
    // Use the computed statistics to update the UI
    stats.evaluate(function(statsValues) {
      // Clear the legend content
      app.legendContentPanel.clear();
      // Clear histogram panel
      app.histogramPanel.clear();
      app.histogramPanel.add(ui.Label({
        value: 'Distribution:',
        style: {
          fontSize: '14px',
          fontWeight: 'bold',
          margin: '0 0 8px 0'
        }
      }));
      // Extract stats for the selected band
      var minKey = bandName + '_min';
      var maxKey = bandName + '_max';
      var meanKey = bandName + '_mean';
      var stdKey = bandName + '_stdDev';
      if (!statsValues || typeof statsValues[minKey] === 'undefined') {
        // Show a message if no data is available
        app.legendContentPanel.add(ui.Label('No data available for this area.'));
        app.histogramPanel.add(ui.Label('No data available for histogram.'));
        app.minLabel.setValue('Min: No data');
        app.maxLabel.setValue('Max: No data');
        app.meanLabel.setValue('Mean: No data');
        app.stdLabel.setValue('Std Dev: No data');
        return;
      }
      var min = statsValues[minKey];
      var max = statsValues[maxKey];
      var mean = statsValues[meanKey];
      var stdDev = statsValues[stdKey];
      // Update statistics labels
      app.minLabel.setValue('Min: ' + min.toFixed(2) + '%');
      app.maxLabel.setValue('Max: ' + max.toFixed(2) + '%');
      app.meanLabel.setValue('Mean: ' + mean.toFixed(2) + '%');
      app.stdLabel.setValue('Std Dev: ' + stdDev.toFixed(2) + '%');
      // Get display names for the legend
      var particleDisplay = getParticleDisplayName(selectedParticle);
      var metricDisplay = getMetricDisplayName(selectedMetric);
      // Create visualization parameters
      var visParams = {
        min: min,
        max: max,
        palette: colorPalettes[selectedParticle]
      };
      // Add the soil layer to the map with the custom visualization
      Map.addLayer(clippedSoil, visParams, particleDisplay + ' ' + metricDisplay);
      // Add the texture classification layer
      Map.addLayer(textureImage, {
        min: 1,
        max: 12,
        palette: textureColorList
      }, 'Soil Texture Classification');
      // Zoom to the selected area
      Map.centerObject(selectedFeatures, 8.5);
      // Add title (area name) to the legend
      app.legendContentPanel.add(ui.Label({
        value: areaName,
        style: {
          fontWeight: 'bold',
          fontSize: '16px',
          margin: '0 0 8px 0',
          padding: '0'
        }
      }));
      // Add subtitle with soil type and metric
      app.legendContentPanel.add(ui.Label({
        value: particleDisplay + ' ' + metricDisplay + ' (%) & Soil Texture',
        style: {
          fontSize: '14px',
          margin: '0 0 8px 0'
        }
      }));
      // Create a fixed-width container for the color bar
      var colorBarContainer = ui.Panel({
        style: {
          width: '100%',
          margin: '0 0 8px 0'
        }
      });
      // Create the color gradient for the legend
      var colorBar = ui.Thumbnail({
        image: ee.Image.pixelLonLat().select(0),
        params: {
          bbox: [0, 0, 1, 0.1],
          dimensions: '300x20',
          format: 'png',
          min: 0,
          max: 1,
          palette: colorPalettes[selectedParticle]
        },
        style: {width: '100%', stretch: 'horizontal'}
      });
      colorBarContainer.add(colorBar);
      app.legendContentPanel.add(colorBarContainer);
      // Add min, mid, and max labels in a panel
      var labelsPanel = ui.Panel({
        widgets: [
          ui.Label(min.toFixed(1) + '%', {margin: '0 0 0 0'}),
          ui.Label(((min + max) / 2).toFixed(1) + '%', {
            margin: '0 0 0 0',
            textAlign: 'center',
            stretch: 'horizontal'
          }),
          ui.Label(max.toFixed(1) + '%', {margin: '0 0 0 0'})
        ],
        layout: ui.Panel.Layout.flow('horizontal'),
        style: {stretch: 'horizontal'}
      });
      app.legendContentPanel.add(labelsPanel);
      // Get the sample values and create histogram
      sampleValues.evaluate(function(values) {
        // Only proceed if we have values
        if (values && values.length > 0) {
          var histChart = createHistogram(values, min, max, particleDisplay + ' %');
          app.histogramPanel.add(histChart);
          // Also show the results tab since we have results now
          // Instead of trying to click the button programmatically,
          // we'll manually trigger the content display
          app.dataContentPanel.style().set('shown', false);
          app.resultsContentPanel.style().set('shown', true);
          app.referenceContentPanel.style().set('shown', false);
          // Update tab styling
          app.dataTabButton.style().set({
            'backgroundColor': '#e0e0e0',
            'color': '#666666',
            'fontWeight': 'normal',
            'margin': '0'
          });
          app.resultsTabButton.style().set({
            'backgroundColor': '#FFFFFF',
            'color': '#2F3E46',
            'fontWeight': 'bold',
            'margin': '0 0 -1px 0'
          });
          app.referenceTabButton.style().set({
            'backgroundColor': '#e0e0e0',
            'color': '#666666',
            'fontWeight': 'normal',
            'margin': '0'
          });
        } else {
          app.histogramPanel.add(ui.Label('Insufficient data for histogram'));
        }
      });
      // Add texture class legend with enhanced visual style
      var legendItems = ui.Panel({
        layout: ui.Panel.Layout.flow('vertical'),
        style: {
          padding: '8px',
          margin: '10px 0 0 0',
          border: '1px solid #eee',
          backgroundColor: '#fafafa'
        }
      });
      // Add title with icon
      legendItems.add(ui.Label({
        value: '🔍 Soil Texture Classes:',
        style: {
          fontSize: '14px',
          fontWeight: 'bold',
          margin: '0 0 8px 0'
        }
      }));
      // Create two columns for texture classes
      var leftColumn = ui.Panel({
        layout: ui.Panel.Layout.flow('vertical'),
        style: {width: '50%', padding: '0', margin: '0'}
      });
      var rightColumn = ui.Panel({
        layout: ui.Panel.Layout.flow('vertical'),
        style: {width: '50%', padding: '0', margin: '0'}
      });
      var columnsPanel = ui.Panel({
        layout: ui.Panel.Layout.flow('horizontal'),
        style: {width: '100%', padding: '0', margin: '0'}
      });
      // Add legend items for each texture class with enhanced visual style
      for (var i = 1; i <= 12; i++) {
        var item = ui.Panel({
          layout: ui.Panel.Layout.flow('horizontal'),
          style: {
            margin: '0 0 5px 0',
            padding: '0'
          }
        });
        // Color box - slightly larger than left panel
        var colorBox = ui.Label({
          style: {
            backgroundColor: textureColorList[i-1],
            padding: '8px',
            margin: '0 5px 0 0',
            width: '14px',
            height: '14px',
            border: '1px solid #ddd'
          }
        });
        // Text label
        var textLabel = ui.Label({
          value: textureNames[i],
          style: {
            margin: '0',
            fontSize: '12px',
            fontWeight: 'normal',
            color: '#000000'
          }
        });
        item.add(colorBox);
        item.add(textLabel);
        // Add to left or right column based on index
        if (i <= 6) {
          leftColumn.add(item);
        } else {
          rightColumn.add(item);
        }
      }
      columnsPanel.add(leftColumn);
      columnsPanel.add(rightColumn);
      legendItems.add(columnsPanel);
      // Add a helpful note about interpretation
      legendItems.add(ui.Label({
        value: 'These colors represent the soil texture classification on the map.',
        style: {
          fontSize: '11px',
          margin: '8px 0 0 0',
          color: '#444',
          fontStyle: 'italic'
        }
      }));
      // Add to legend panel
      app.legendContentPanel.add(legendItems);
    });
  });
}
// Initialize area symbols dictionary
var stateAreaSymbols = {};
// Load state and area data
table.aggregate_array('areasymbol').distinct().evaluate(function(symbols) {
  var states = [];
  // Process all area symbols
  symbols.forEach(function(symbol) {
    var state = symbol.substring(0, 2);
    // Add state to the list if it's not already there
    if (states.indexOf(state) === -1) {
      states.push(state);
    }
    // Add area symbol to the state's list
    if (!stateAreaSymbols[state]) {
      stateAreaSymbols[state] = [];
    }
    stateAreaSymbols[state].push(symbol);
  });
  // Sort states alphabetically
  states.sort();
  // Sort area symbols within each state
  for (var state in stateAreaSymbols) {
    stateAreaSymbols[state].sort();
  }
  // Set up the state dropdown
  app.stateSelect.items().reset(states);
  // Add state change handler
  app.stateSelect.onChange(function(state) {
    var areaSymbols = stateAreaSymbols[state] || [];
    app.areaSelect.items().reset(areaSymbols);
    if (areaSymbols.length > 0) {
      app.areaSelect.setValue(areaSymbols[0]);
    }
  });
  // Add area change handlers
  app.areaSelect.onChange(updateMap);
  // Add data change handlers
  app.particleSelect.onChange(updateMap);
  app.metricSelect.onChange(updateMap);
  // Set initial state
  if (states.length > 0) {
    app.stateSelect.setValue(states[0]);
  }
});