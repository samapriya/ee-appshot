// Load data
var table = ee.FeatureCollection("users/gponce/usda_ars/shapefiles/MHERNANDEZ/polygons_soilsa_nrcs");
// Load all soil data layers
// Clay data
var clay_p_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/claytotal_0_cm_p.tif').rename('clay_p');
var clay_h_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/claytotal_0_cm_h.tif').rename('clay_h');
var clay_l_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/claytotal_0_cm_l.tif').rename('clay_l');
var clay_rpi_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/claytotal_0_cm_rpi.tif').rename('clay_rpi');
// Sand data
var sand_h_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/sandtotal_0_cm_h.tif').rename('sand_h');
var sand_l_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/sandtotal_0_cm_l.tif').rename('sand_l');
var sand_p_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/sandtotal_0_cm_p.tif').rename('sand_p');
var sand_rpi_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/sandtotal_0_cm_rpi.tif').rename('sand_rpi');
// Silt data
var silt_h_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/silttotal_0_cm_h.tif').rename('silt_h');
var silt_l_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/silttotal_0_cm_l.tif').rename('silt_l');
var silt_p_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/silttotal_0_cm_p.tif').rename('silt_p');
var silt_rpi_0_cm = ee.Image.loadGeoTIFF('gs://gee_solus/silttotal_0_cm_rpi.tif').rename('silt_rpi');
// Create a data dictionary for easy access
var soilData = {
  'clay': {
    'p': clay_p_0_cm,
    'h': clay_h_0_cm,
    'l': clay_l_0_cm,
    'rpi': clay_rpi_0_cm
  },
  'sand': {
    'p': sand_p_0_cm,
    'h': sand_h_0_cm,
    'l': sand_l_0_cm,
    'rpi': sand_rpi_0_cm
  },
  'silt': {
    'p': silt_p_0_cm,
    'h': silt_h_0_cm,
    'l': silt_l_0_cm,
    'rpi': silt_rpi_0_cm
  }
};
// Filter the table to only include target area symbols
var target_areasymbols = ['MN031', 'MN075', 'NH605', 'VT007', 'MN115', 'MT640', 'WY603', 'WY617',
                         'MT642', 'WY661', 'ID701', 'ID720', 'ID671', 'ID700', 'WA762', 'OR608',
                         'WA706', 'WA760', 'OR607', 'OR631', 'WA714', 'OR645', 'NV792', 'OR605',
                         'OR657', 'OR603', 'OR622', 'OR683', 'OR680', 'CA704', 'CA601', 'NV782',
                         'UT626', 'CA793', 'UT646', 'CA663', 'CA682', 'CA695', 'CA698', 'CA805',
                         'CA803', 'CA804', 'AZ647', 'AZ648', 'AZ691', 'AZ723', 'NM622', 'CO657',
                         'NM694', 'NM696', 'AZ687', 'AZ639', 'AZ693', 'UT636', 'WY630', 'UT625',
                         'UT648', 'WY737', 'UT647', 'UT650', 'UT607', 'WY723', 'CO031', 'GA637',
                         'GA648', 'KY643', 'WI079', 'FL623', 'FL687', 'TN125', 'FL624', 'HT600',
                         'NY109', 'NY664'];
table = table.filter(ee.Filter.inList('areasymbol', target_areasymbols));
// Set map view
Map.centerObject(table, 5);
Map.setOptions('HYBRID');
// Define color palettes for different soil particles
var colorPalettes = {
  'clay': ['#2E0854', '#3A0CA3', '#480CA8', '#4361EE', '#4CC9F0', 
           '#00B4D8', '#0096C7', '#02C39A', '#8AC926', '#FFFF00'],
  'sand': ['#2E0854', '#3A0CA3', '#480CA8', '#4361EE', '#4CC9F0', 
           '#00B4D8', '#0096C7', '#02C39A', '#8AC926', '#FFFF00'],
  'silt': ['#2E0854', '#3A0CA3', '#480CA8', '#4361EE', '#4CC9F0', 
           '#00B4D8', '#0096C7', '#02C39A', '#8AC926', '#FFFF00']
};
// Define metric types
var metricTypes = [
  {label: 'Predicted (p)', value: 'p'},
  {label: 'Upper Interval (h)', value: 'h'},
  {label: 'Lower Interval (l)', value: 'l'},
  {label: 'Relative Interval (rpi)', value: 'rpi'}
];
// Helper function to extract state from area symbol (first two characters)
function getStateFromSymbol(symbol) {
  return symbol.substring(0, 2);
}
// Function to create a histogram chart
function createHistogram(values, min, max, title) {
  // Create our own bins and count frequencies
  var numBins = 8;  // Reduced number of bins for clearer display
  var binWidth = (max - min) / numBins;
  // Initialize bin counts (without using Array.fill which isn't supported)
  var binCounts = [];
  var binLabels = [];
  // Create bin labels and initialize counts
  for (var i = 0; i < numBins; i++) {
    var binStart = min + i * binWidth;
    // Use fewer decimal places for cleaner display
    binLabels.push(Math.round(binStart));
    binCounts.push(0);  // Initialize count to 0
  }
  // Add the last bin edge
  binLabels.push(Math.round(max));
  // Count values in each bin
  values.forEach(function(value) {
    if (value >= min && value <= max) {
      var binIndex = Math.min(Math.floor((value - min) / binWidth), numBins - 1);
      binCounts[binIndex]++;
    }
  });
  // Create a DataTable for the chart
  var dataTable = [['Bin', 'Frequency']];
  for (var i = 0; i < numBins; i++) {
    dataTable.push([binLabels[i].toString(), binCounts[i]]);
  }
  // Create the chart
  var histChart = ui.Chart(dataTable)
    .setChartType('ColumnChart')
    .setOptions({
      title: '',
      titleTextStyle: {fontSize: '13px'},
      legend: {position: 'none'},
      hAxis: {
        title: title, //'Clay %',
        titleTextStyle: {fontSize: '11px'},
        textStyle: {fontSize: '9px'},
        gridlines: {count: 4, color: '#f5f5f5'},
        showTextEvery: 2  // Show every second label to avoid crowding
      },
      vAxis: {
        title: 'Frequency',
        titleTextStyle: {fontSize: '11px'},
        textStyle: {fontSize: '9px'},
        gridlines: {count: 3, color: '#f5f5f5'},
        minValue: 0,
        baselineColor: '#999'
      },
      chartArea: {width: '85%', height: '75%', left: '12%', top: '15%'},
      height: '230px',
      width: '185px',
      colors: ['#4393c3'],
      backgroundColor: {fill: '#FFFFFF'},
      bar: {groupWidth: '85%'},
      axisTitlesPosition: 'out'
    });
  return histChart;
}
// Create UI components
var app = {};
// Main panel
app.mainPanel = ui.Panel({
  style: {
    width: '400px',
    padding: '10px',
    position: 'top-left'
  }
});
// Title
app.mainPanel.add(ui.Label({
  value: '🌎 SOLUS Properties Stats',
  style: {
    fontSize: '20px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  }
}));
app.mainPanel.add(ui.Label({
  value: 'Present soil properties map and stats within selected NRCS polygons. Source: doi.org/10.1002/saj2.20769',
  style: {
    fontSize: '13px',
    margin: '0 0 15px 0'
  }
}));
// Data selection panel
app.dataPanel = ui.Panel({
  style: {
    margin: '0 0 15px 0',
    padding: '10px',
    border: '1px solid #ddd'
  }
});
app.dataPanel.add(ui.Label({
  value: 'Select soil data:',
  style: {
    fontSize: '14px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  }
}));
// Create particle selector
app.dataPanel.add(ui.Label('Soil Particle:', {margin: '0 0 2px 0', fontSize: '12px'}));
app.particleSelect = ui.Select({
  items: ['clay', 'sand', 'silt'],
  value: 'clay',
  style: {width: '100%', margin: '0 0 8px 0'}
});
app.dataPanel.add(app.particleSelect);
// Create metric selector
app.dataPanel.add(ui.Label('Metric:', {margin: '4px 0 2px 0', fontSize: '12px'}));
app.metricSelect = ui.Select({
  items: metricTypes.map(function(item) { return item.label; }),
  value: 'Predicted (p)',
  style: {width: '100%'}
});
app.dataPanel.add(app.metricSelect);
// Add data panel to main panel
app.mainPanel.add(app.dataPanel);
// Location selection panel
app.locationPanel = ui.Panel({
  style: {
    margin: '0 0 15px 0',
    padding: '10px',
    border: '1px solid #ddd'
  }
});
app.locationPanel.add(ui.Label({
  value: 'Select an area:',
  style: {
    fontSize: '14px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  }
}));
// State selector
app.locationPanel.add(ui.Label('State:', {margin: '0 0 2px 0', fontSize: '12px'}));
app.stateSelect = ui.Select({
  placeholder: 'Choose a state',
  style: {width: '100%', margin: '0 0 8px 0'}
});
app.locationPanel.add(app.stateSelect);
// Area symbol selector
app.locationPanel.add(ui.Label('Area Symbol:', {margin: '4px 0 2px 0', fontSize: '12px'}));
app.areaSelect = ui.Select({
  placeholder: 'Choose an area symbol',
  style: {width: '100%'}
});
app.locationPanel.add(app.areaSelect);
// Add location panel to main panel
app.mainPanel.add(app.locationPanel);
// Statistics container
app.statsContainer = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    margin: '0 0 15px 0',
    width: '380px'
  }
});
// Stats panel
app.statsPanel = ui.Panel({
  style: {
    margin: '0 0 0 0',
    padding: '10px',
    border: '1px solid #ddd',
    width: '170px'
  }
});
app.statsPanel.add(ui.Label({
  value: 'Soil Statistics:',
  style: {
    fontSize: '14px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  }
}));
// Add placeholders for statistics
app.minLabel = ui.Label('Min: -');
app.maxLabel = ui.Label('Max: -');
app.meanLabel = ui.Label('Mean: -');
app.stdLabel = ui.Label('Std Dev: -');
app.statsPanel.add(app.minLabel);
app.statsPanel.add(app.maxLabel);
app.statsPanel.add(app.meanLabel);
app.statsPanel.add(app.stdLabel);
// Histogram panel
app.histogramPanel = ui.Panel({
  style: {
    margin: '0 0 0 5px',
    padding: '10px',
    border: '1px solid #ddd',
    width: '195px'
  }
});
// Add stats container
app.statsContainer.add(app.statsPanel);
app.statsContainer.add(app.histogramPanel);
app.mainPanel.add(app.statsContainer);
// Add reset button
app.resetButton = ui.Button({
  label: 'Reset View',
  onClick: function() {
    Map.centerObject(table, 5);
  },
  style: {
    margin: '10px 0 0 0'
  }
});
app.mainPanel.add(app.resetButton);
// Add copyright
app.mainPanel.add(ui.Label({
  value: '© USDA-ARS SWRC ' + new Date().getFullYear(),
  style: {
    fontSize: '11px',
    color: '#999',
    margin: '15px 0 0 0'
  }
}));
// Legend panel
app.legendPanel = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '10px',
    backgroundColor: 'white',
    border: '1px solid #ddd',
    maxWidth: '500px'
  }
});
// Add panels to map
Map.add(app.mainPanel);
Map.add(app.legendPanel);
// Helper function to get metric value from label
function getMetricValue(label) {
  for (var i = 0; i < metricTypes.length; i++) {
    if (metricTypes[i].label === label) {
      return metricTypes[i].value;
    }
  }
  return 'p'; // Default
}
// Helper function to get display name for soil particle
function getParticleDisplayName(particle) {
  return particle.charAt(0).toUpperCase() + particle.slice(1);
}
// Helper function to get display name for the metric
function getMetricDisplayName(metricCode) {
  for (var i = 0; i < metricTypes.length; i++) {
    if (metricTypes[i].value === metricCode) {
      return metricTypes[i].label;
    }
  }
  return 'Predicted';
}
// Function to update map with selected data
function updateMap() {
  // Clear previous layers
  Map.layers().reset();
  // Get selected values
  var selectedParticle = app.particleSelect.getValue();
  var selectedMetricLabel = app.metricSelect.getValue();
  var selectedAreaSymbol = app.areaSelect.getValue();
  // If any selection is missing, return
  if (!selectedParticle || !selectedMetricLabel || !selectedAreaSymbol) {
    return;
  }
  // Get metric value
  var selectedMetric = getMetricValue(selectedMetricLabel);
  // Get the corresponding data
  var soilImage = soilData[selectedParticle][selectedMetric];
  // Filter the feature collection to get features with the selected area symbol
  var selectedFeatures = table.filter(ee.Filter.eq('areasymbol', selectedAreaSymbol));
  // Get the area name for displaying in the legend
  selectedFeatures.first().get('areaname').evaluate(function(areaName) {
    // Add the selected features to the map with hollow style (only borders)
    Map.addLayer(selectedFeatures.style({
      // Set only the border properties with transparent fill
      color: '#00E050',      // Bright/shiny green color
      width: 2,              // Border width of 2 pixels
      fillColor: '00000000'  // Transparent fill (the last 00 is for 0% opacity)
    }), {}, 'Selected Area');
    // Clip the soil data to the selected features
    var clippedSoil = soilImage.clip(selectedFeatures);
    // Mask pixels with no data
    clippedSoil = clippedSoil.updateMask(clippedSoil.gt(0));
    // Get statistics of soil data within the area
    var stats = clippedSoil.reduceRegion({
      reducer: ee.Reducer.mean().combine({
        reducer2: ee.Reducer.stdDev(),
        sharedInputs: true
      }).combine({
        reducer2: ee.Reducer.minMax(),
        sharedInputs: true
      }),
      geometry: selectedFeatures.geometry(),
      scale: 30,
      maxPixels: 1e9
    });
    // Sample points for histogram
    var samples = clippedSoil.sample({
      region: selectedFeatures.geometry(),
      scale: 30,
      numPixels: 5000,
      seed: 123
    });
    // Get band name
    var bandName = selectedParticle + '_' + selectedMetric;
    // Get sample values
    var sampleValues = samples.aggregate_array(bandName);
    // Use the computed statistics to update the UI
    stats.evaluate(function(statsValues) {
      // Clear the legend
      app.legendPanel.clear();
      // Clear histogram panel
      app.histogramPanel.clear();
      // Extract stats for the selected band
      var minKey = bandName + '_min';
      var maxKey = bandName + '_max';
      var meanKey = bandName + '_mean';
      var stdKey = bandName + '_stdDev';
      if (!statsValues || typeof statsValues[minKey] === 'undefined') {
        // Show a message if no data is available
        app.legendPanel.add(ui.Label('No data available for this area.'));
        app.histogramPanel.add(ui.Label('No data available for histogram.'));
        app.minLabel.setValue('Min: No data');
        app.maxLabel.setValue('Max: No data');
        app.meanLabel.setValue('Mean: No data');
        app.stdLabel.setValue('Std Dev: No data');
        return;
      }
      var min = statsValues[minKey];
      var max = statsValues[maxKey];
      var mean = statsValues[meanKey];
      var stdDev = statsValues[stdKey];
      // Update statistics labels
      app.minLabel.setValue('Min: ' + min.toFixed(2) + '%');
      app.maxLabel.setValue('Max: ' + max.toFixed(2) + '%');
      app.meanLabel.setValue('Mean: ' + mean.toFixed(2) + '%');
      app.stdLabel.setValue('Std Dev: ' + stdDev.toFixed(2) + '%');
      // Get display names for the legend
      var particleDisplay = getParticleDisplayName(selectedParticle);
      var metricDisplay = getMetricDisplayName(selectedMetric);
      // Create visualization parameters
      var visParams = {
        min: min,
        max: max,
        palette: colorPalettes[selectedParticle]
      };
      // Add the soil layer to the map with the custom visualization
      Map.addLayer(clippedSoil, visParams, particleDisplay + ' ' + metricDisplay);
      // Zoom to the selected area
      Map.centerObject(selectedFeatures, 10);
      // Add title (area name) to the legend
      app.legendPanel.add(ui.Label({
        value: areaName,
        style: {
          fontWeight: 'bold',
          fontSize: '16px',
          margin: '0 0 8px 0',
          padding: '0'
        }
      }));
      // Add subtitle with soil type and metric
      app.legendPanel.add(ui.Label({
        value: particleDisplay + ' ' + metricDisplay + ' (%)',
        style: {
          fontSize: '14px',
          margin: '0 0 8px 0'
        }
      }));
      // Create a fixed-width container for the color bar
      var colorBarContainer = ui.Panel({
        style: {
          width: '100%',
          margin: '0 0 8px 0'
        }
      });
      // Create the color gradient for the legend
      var colorBar = ui.Thumbnail({
        image: ee.Image.pixelLonLat().select(0),
        params: {
          bbox: [0, 0, 1, 0.1],
          dimensions: '300x20',
          format: 'png',
          min: 0,
          max: 1,
          palette: colorPalettes[selectedParticle]
        },
        style: {width: '100%', stretch: 'horizontal'}
      });
      colorBarContainer.add(colorBar);
      app.legendPanel.add(colorBarContainer);
      // Add min, mid, and max labels in a panel
      var labelsPanel = ui.Panel({
        widgets: [
          ui.Label(min.toFixed(1) + '%', {margin: '0 0 0 0'}),
          ui.Label(((min + max) / 2).toFixed(1) + '%', {
            margin: '0 0 0 0',
            textAlign: 'center',
            stretch: 'horizontal'
          }),
          ui.Label(max.toFixed(1) + '%', {margin: '0 0 0 0'})
        ],
        layout: ui.Panel.Layout.flow('horizontal'),
        style: {stretch: 'horizontal'}
      });
      app.legendPanel.add(labelsPanel);
      // Display histogram
      app.histogramPanel.add(ui.Label({
        value: particleDisplay + ' Distribution:',
        style: {
          fontSize: '14px',
          fontWeight: 'bold',
          margin: '0 0 8px 0'
        }
      }));
      // Get the sample values and create histogram
      sampleValues.evaluate(function(values) {
        // Only proceed if we have values
        if (values && values.length > 0) {
          var histChart = createHistogram(values, min, max, particleDisplay + ' %');
          app.histogramPanel.add(histChart);
        } else {
          app.histogramPanel.add(ui.Label('Insufficient data for histogram'));
        }
      });
    });
  });
}
// Initialize area symbols dictionary
var stateAreaSymbols = {};
// Load state and area data
table.aggregate_array('areasymbol').distinct().evaluate(function(symbols) {
  var states = [];
  // Process all area symbols
  symbols.forEach(function(symbol) {
    var state = getStateFromSymbol(symbol);
    // Add state to the list if it's not already there
    if (states.indexOf(state) === -1) {
      states.push(state);
    }
    // Add area symbol to the state's list
    if (!stateAreaSymbols[state]) {
      stateAreaSymbols[state] = [];
    }
    stateAreaSymbols[state].push(symbol);
  });
  // Sort states alphabetically
  states.sort();
  // Sort area symbols within each state
  for (var state in stateAreaSymbols) {
    stateAreaSymbols[state].sort();
  }
  // Set up the state dropdown
  app.stateSelect.items().reset(states);
  // Add state change handler
  app.stateSelect.onChange(function(state) {
    var areaSymbols = stateAreaSymbols[state] || [];
    app.areaSelect.items().reset(areaSymbols);
    if (areaSymbols.length > 0) {
      app.areaSelect.setValue(areaSymbols[0]);
    }
  });
  // Add area change handler
  app.areaSelect.onChange(updateMap);
  // Add data change handlers
  app.particleSelect.onChange(updateMap);
  app.metricSelect.onChange(updateMap);
  // Set initial state
  if (states.length > 0) {
    app.stateSelect.setValue(states[0]);
  }
});