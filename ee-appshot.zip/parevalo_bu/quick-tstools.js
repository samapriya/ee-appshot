/* ////////////////////////////////////////////////////////////////
Simple time series explorer with CCDC results
   Author: Paulo Arevalo
           parevalo@bu.edu
*/ ////////////////////////////////////////////////////////////////
/**
 * Import utility functions.  
 * 
 * These imports are used to facilitate pre-processing of the Landsat data.
 * The tools are within the GLANCE repo and were created by Eric Bullock,
 * Paulo Arevalo, Zhiqiang Yang, and Noel Gorelick. 
 */ 
var uiUtils = require('users/parevalo_bu/gee-ccdc-tools:ccdcUtilities/ui') 
var map = ui.Map().setControlVisibility({drawingToolsControl: false})
// If no ccd params dict is passed, it will run with the defaults
ui.root.widgets().set(0, uiUtils.initializeTSViewer(map))