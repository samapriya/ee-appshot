var NK_border = ui.import && ui.import("NK_border", "table", {
      "id": "users/armkhudinyan/NK_shape"
    }) || ee.FeatureCollection("users/armkhudinyan/NK_shape"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                45.51370783388579,
                40.652729644668504
              ],
              [
                45.51370783388579,
                38.811043236917996
              ],
              [
                47.64505549013579,
                38.811043236917996
              ],
              [
                47.64505549013579,
                40.652729644668504
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Polygon(
        [[[45.51370783388579, 40.652729644668504],
          [45.51370783388579, 38.811043236917996],
          [47.64505549013579, 38.811043236917996],
          [47.64505549013579, 40.652729644668504]]], null, false);
// Demonstrates before/after imagery comparison with a variety of dates.
var AOI = geometry
// // define borderlines
// var countries_name = ['Armenia', 'Azerbaijan'] 
// var HKM_region = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017').filter(ee.Filter.inList('country_na', countries_name));
// var border = ee.Image().toByte()
//     //.paint(HKM_region, 'fill') // Get color from property named 'fill'
//     .paint(HKM_region, 1, 2); // Outline using color 3, width 5.
// var border_clip = border.clip(AOI).visualize({palette: ['yellow'], max: 0.3, opacity: 0.6})
var nk_border = ee.Image().toByte()
    .paint(NK_border.filter(ee.Filter.eq('OBJECTID', 2)), 1, 2) // Outline using color 3, width 5.
    .visualize({palette: ['red'], max: 0.3, opacity: 0.6})
// Define clipping function
var clip2AOI = function(image){
  return image.clip(AOI);
};
// Define map title
var left_title = ui.Label('Infrastructure changes Artsakh | NK' ,{fontWeight: 'bold', fontSize: '14px' })
var right_title = ui.Label('Infrastructure changes Artsakh | NK' ,{fontWeight: 'bold', fontSize: '14px' })
/*
* Configure the imagery
*/
var bands = ['B4', 'B3', 'B2']
var vis_param_Sentinel = {min: 200, max: 3000, bands: bands};
var vis_param_Sentinel2 = {min: 1100, max: 4000, bands: bands};
// /*
// * Select the images to visualize ##################################################
// */
// Sentinel 2 data
var S2_coll = ee.ImageCollection('COPERNICUS/S2')
                  // Pre-filter to get less cloudy granules.
                  .filterBounds(AOI)
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10))
                  .filterDate('2020-09-01', '2025-10-10')
                  .select(bands)
                  .map(clip2AOI)
// CHeck the available Sentinel images in a given time interval
print(S2_2023, '2023 Sentinel 2 images available')
var S2_2020 = S2_coll.filter(ee.Filter.date('2020-09-01', '2020-10-01')).median()
var S2_2021 = S2_coll.filter(ee.Filter.date('2021-08-01', '2021-09-01')).median()
var S2_2022 = S2_coll.filter(ee.Filter.date('2022-09-01', '2022-10-01')).median()
var S2_2023 = S2_coll.filter(ee.Filter.date('2023-08-01', '2023-09-01')).median()
var S2_2024 = S2_coll.filter(ee.Filter.date('2024-09-01', '2024-10-01')).median()
var S2_2025 = S2_coll.filter(ee.Filter.date('2025-01-01', '2025-10-10')).median()
print(S2_coll.filter(ee.Filter.date('2025-01-01', '2025-10-10')))
// var S2_1 = ee.Image('COPERNICUS/S2/20200705T074621_20200705T075705_T38TNL')
// var S2_2 = ee.Image('COPERNICUS/S2/20200715T074621_20200715T075644_T38TNL')
// make a dictionary from the selected images to visualize
var images = {
  'Sentinel2 | Sep 2025': S2_2025.visualize(vis_param_Sentinel2),
  'Sentinel2 | Sep 2024': S2_2024.visualize(vis_param_Sentinel2),
  'Sentinel2 | Aug 2023': S2_2023.visualize(vis_param_Sentinel2),
  'Sentinel2 | Sep 2022': S2_2022.visualize(vis_param_Sentinel2),
  'Sentinel2 | Aug 2021': S2_2021.visualize(vis_param_Sentinel),
  'Sentinel2 | Sep 2020': S2_2020.visualize(vis_param_Sentinel),
};
// /*
// * Set up the maps and control widgets
// */
// Create the left map, and have it display layer 0.
var leftMap = ui.Map();
leftMap.setControlVisibility(true);
var leftSelector = addLayerSelector(leftMap, 5, 'top-left');
// leftMap.addLayer(border_clip);
leftMap.addLayer(nk_border);
leftMap.add(left_title);
// leftMap.addLayer(land_modif,{palette: ['red'], max: 0.3}, '', true, 0.4)
// Create the right map, and have it display layer 1.
var rightMap = ui.Map();
rightMap.setControlVisibility(false);
var rightSelector = addLayerSelector(rightMap, 0, 'top-right');
// rightMap.addLayer(border_clip);
rightMap.addLayer(nk_border);
rightMap.add(right_title);
// rightMap.addLayer(land_modif,{palette: ['red'], max: 0.3},'', true, 0.4)
// Adds a layer selection widget to the given map, to allow users to change
// which image is displayed in the associated map.
function addLayerSelector(mapToChange, defaultValue, position) {
  var label = ui.Label('Choose an image to visualize');
  // This function changes the given map to show the selected image.
  function updateMap(selection) {
    mapToChange.layers().set(0, ui.Map.Layer(images[selection]));
  }
  // Configure a selection dropdown to allow the user to choose between images,
  // and set the map to update when a user makes a selection.
  var select = ui.Select({items: Object.keys(images), onChange: updateMap});
  select.setValue(Object.keys(images)[defaultValue], true);
  var controlPanel =
      ui.Panel({widgets: [label, select], style: {position: position}});
  mapToChange.add(controlPanel);
}
/*
* Tie everything together
*/
// Create a SplitPanel to hold the adjacent, linked maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in the UI root.
ui.root.widgets().reset([splitPanel]);
var linker = ui.Map.Linker([leftMap, rightMap]);
// leftMap.setCenter(45.8, 39.8, 12);
leftMap.centerObject(geometry,  9)