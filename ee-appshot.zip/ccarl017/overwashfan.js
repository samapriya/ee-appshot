var overwashfan = /* color: #98ff00 */ee.Geometry.Polygon(
        [[[-75.48303723335266, 35.6861891166781],
          [-75.48325181007385, 35.685884118398896],
          [-75.4835844039917, 35.68593640390101],
          [-75.48383116722107, 35.68598868936885],
          [-75.48390626907349, 35.68504754570482],
          [-75.48432469367981, 35.684969116564986],
          [-75.48463582992554, 35.68505626004893],
          [-75.48521518707275, 35.6850998317552],
          [-75.48557996749878, 35.6850998317552],
          [-75.48597693443298, 35.68522183240617],
          [-75.4863953590393, 35.68508240307555],
          [-75.48656702041626, 35.684829686792675],
          [-75.48686742782593, 35.684742543061255],
          [-75.4874575138092, 35.684847115527546],
          [-75.48789739608765, 35.68485582989354],
          [-75.48839092254639, 35.684742543061255],
          [-75.48892736434937, 35.684611827285636],
          [-75.48941016197205, 35.68454211211772],
          [-75.48977494239807, 35.68475125743868],
          [-75.48987150192261, 35.68509111741585],
          [-75.49025774002075, 35.68570983314439],
          [-75.4906439781189, 35.6835399498471],
          [-75.49001097679138, 35.683757812281115],
          [-75.48922777175903, 35.68369681085957],
          [-75.4886269569397, 35.68378395573321],
          [-75.48819780349731, 35.683801384696544],
          [-75.48755407333374, 35.68368809636696],
          [-75.48683524131775, 35.68353123533737],
          [-75.48625588417053, 35.68336565947154],
          [-75.48579454421997, 35.68340051757711],
          [-75.4855477809906, 35.68342666114631],
          [-75.4850435256958, 35.68340051757711],
          [-75.48463582992554, 35.683348230413046],
          [-75.48433542251587, 35.68328722867833],
          [-75.48391699790955, 35.6831303668606],
          [-75.48382043838501, 35.683051935836076],
          [-75.48350930213928, 35.6834963772889],
          [-75.48309087753296, 35.68353123533737],
          [-75.48271536827087, 35.683470233742554]]]);
// Computes the distance difference between marsh and beach at New Inlet, NC
//Add Long,Lat Points
var marsh = ee.FeatureCollection([ee.Geometry.Point(-75.488,35.68430)])
var beach = ee.FeatureCollection([ee.Geometry.Point(-75.483904,35.68415)]);
// var overwashwdith_road = prompt('Width of Overwash Fan near ROAD');
// var overwashwidth_marsh = prompt('Width of Overwash Fan near MARSH');
//Create Buffer (Radius)
// ========== Alter Buffer Size so the circle covers all of New Inlet
var buffer_size_road = 50;
var buffer_size_marsh = 90;
//Map Properties
Map.setCenter(-75.485305, 35.6845, 17);           //Center map
Map.addLayer(overwashfan);                        //Outlines overwash fan
Map.addLayer(beach.distance(buffer_size_road));  //Adds beach buffer
Map.addLayer(marsh.distance(buffer_size_marsh));  //Adds marsh buffer
Map.addLayer(beach);                              //Adds beach point
Map.addLayer(marsh);                              //Adds marsh point
//print('Your initial guess was '+abs(response_guess-buffer_size_road)+'meters off');
print('Road circle radius: '+buffer_size_road+' meters')
print('Marsh circle radius: '+buffer_size_marsh+' meters')
print('Diameter of marsh is '+buffer_size_marsh*2+' meters')
print('Circumference of marsh is ',2*3.1416*buffer_size_marsh)
print('The road radius is '+buffer_size_road/buffer_size_marsh,'times larger')