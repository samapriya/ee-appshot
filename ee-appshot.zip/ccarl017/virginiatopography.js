var elevation = ee.Image("srtm90_v4"),
    Virginia_waypoints = ee.FeatureCollection("ft:1sS4afOlfSaRzae3Ame8gbAF9Ue5FfxS78zBur-Qo");
// Virginia Topography.
var Virginia_waypoints =
    ee.FeatureCollection('ft:1sS4afOlfSaRzae3Ame8gbAF9Ue5FfxS78zBur-Qo');
var Virginia_waypoints_detailed =
    ee.FeatureCollection('ft:1ezwmz2Fc8b0XchJP6GtYmocmGoGakqFeD_acKGfJ');
var chart = ui.Chart.image.byRegion({
  image: elevation,
  regions: Virginia_waypoints,
  regions: Virginia_waypoints_detailed,
  scale: 200,
  xProperty: 'name'
});
chart.setOptions({
  title: 'Virginia Topographic Cross Section',
  hAxis: {
    direction: '-1'
  },
  vAxis: {
    title: 'Elevation (meters)'
  },
  legend: 'none',
  lineWidth: 1,
  pointSize: 4
});
print(chart);
Map.addLayer(elevation,{min: 0, max: 1200});
Map.addLayer(Virginia_waypoints, {color: 'FF0000'});
//Map.addLayer(Virginia_waypoints_detailed, {color: '0000FF'});
Map.setCenter(-79, 38, 7);