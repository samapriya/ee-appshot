var elevation = ee.Image("srtm90_v4"),
    image = ee.Image("NOAA/NGDC/ETOPO1"),
    AtlanticBathyWaypoints = ee.FeatureCollection("ft:1gtVNv58jM2dVOIhagbX7Od6PP6A02Di-zfMo6ppb"),
    imageVisParam = {"opacity":1,"bands":["bedrock"],"min":-8000,"max":1200,"gamma":0.609};
// Mid Ocean Ridge Bathymetry
var chart = ui.Chart.image.byRegion({
  image: image,
  regions: AtlanticBathyWaypoints,
  scale: 20000,
  xProperty: 'name'
});
chart.setOptions({
  title: 'Atlantic Bathymetry',
  vAxis: {
    title: 'Elevation (meters)'
  },
  legend: 'none',
  lineWidth: 1,
  pointSize: 4
});
print(chart);
Map.addLayer(image,{min: -8000, max: 1200}, 'custom visualization');
Map.addLayer(AtlanticBathyWaypoints, {color: 'FF0000'});
Map.setCenter(-50, 38, 4);