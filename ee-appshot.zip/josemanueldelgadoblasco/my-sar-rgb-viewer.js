var S1 = ui.import && ui.import("S1", "imageCollection", {
      "id": "COPERNICUS/S1_GRD"
    }) || ee.ImageCollection("COPERNICUS/S1_GRD"),
    AOI = ui.import && ui.import("AOI", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -10.141832704300162,
                44.24502002662472
              ],
              [
                -10.141832704300162,
                35.75522560464326
              ],
              [
                4.766614561324838,
                35.75522560464326
              ],
              [
                4.766614561324838,
                44.24502002662472
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-10.141832704300162, 44.24502002662472],
          [-10.141832704300162, 35.75522560464326],
          [4.766614561324838, 35.75522560464326],
          [4.766614561324838, 44.24502002662472]]], null, false);
var start_day='2019-01-01'
var stop_day='2019-12-31'
var thr_VV=-16;
var thr_VH=-20;
S1=S1.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
  .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
  .filter(ee.Filter.eq('instrumentMode', 'IW'));
//var S1filteredVV = S1.filterDate(start_day,stop_day).filterBounds(AOI).select('VV').filter(ee.Filter.eq('relativeOrbitNumber_start',track)).mean()
var S1filteredVV = S1.filterDate(start_day,stop_day).filterBounds(AOI).select('VV').mean()
//var S1filteredVH = S1.filterDate(start_day,stop_day).filterBounds(AOI).select('VH').filter(ee.Filter.eq('relativeOrbitNumber_start',track)).mean()
var S1filteredVH = S1.filterDate(start_day,stop_day).filterBounds(AOI).select('VH').mean()
Map.addLayer(S1filteredVV, {min: -20, max: -5}, 'S1averageVV');
Map.addLayer(S1filteredVH, {min: -30, max: -10}, 'S1averageVH');
//var permanentwater=S1filteredVH.lt(-20).and(S1filteredVV.lt(-16).and(S1filteredVVstd.gt(2)))
var permanentwater=S1filteredVH.lt(thr_VH).and(S1filteredVV.lt(thr_VV))
Map.addLayer(permanentwater,{min:0,max:1},'permanent water');
var vizParams = {
bands: ['VV', 'VH', 'VH_1'],
min: [-15, -20, 0],
max: [0, -5, 1],
gamma: [0.95, 1.1, 1]
};
var RGB=S1filteredVV.addBands(S1filteredVH).addBands(permanentwater);
Map.addLayer(RGB,vizParams,'RGB');
// Export a cloud-optimized GeoTIFF.
Export.image.toDrive({
  image: RGB,
  description: 'RGB_SAR_COG',
  scale: 20,
  region: AOI,
  fileFormat: 'GeoTIFF',
  formatOptions: {
    cloudOptimized: true
  }
});