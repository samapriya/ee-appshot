var Cafe_Zecao = /* color: #e5e5e5 */ee.Geometry({
      "type": "GeometryCollection",
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -47.03980235724117,
                -20.5048380745018
              ],
              [
                -47.03628329901363,
                -20.500255623191094
              ],
              [
                -47.03482417730953,
                -20.50049680825561
              ],
              [
                -47.0345666852441,
                -20.499612461163245
              ],
              [
                -47.03460960058834,
                -20.49832612900973
              ],
              [
                -47.03576831488277,
                -20.499813449586906
              ],
              [
                -47.03761367468502,
                -20.499290879137057
              ],
              [
                -47.03825740484859,
                -20.50033601825478
              ],
              [
                -47.03778533606197,
                -20.501139966571838
              ],
              [
                -47.03890113501217,
                -20.50202430484895
              ],
              [
                -47.03954486517574,
                -20.501702727884144
              ],
              [
                -47.040231510683554,
                -20.501421347486353
              ],
              [
                -47.04066066412594,
                -20.50101937459317
              ],
              [
                -47.04160480169918,
                -20.50109976925616
              ],
              [
                -47.04254893927242,
                -20.50057720319278
              ],
              [
                -47.04516677527096,
                -20.503511589532184
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -47.03703458341408,
                -20.494285961333652
              ],
              [
                -47.03754956754494,
                -20.494285961333652
              ],
              [
                -47.03788216146279,
                -20.495602476470157
              ],
              [
                -47.03854734929848,
                -20.496456697800138
              ],
              [
                -47.038472247446066,
                -20.497180269790746
              ],
              [
                -47.037216973627096,
                -20.49754205450506
              ],
              [
                -47.03661615880776,
                -20.495773321116996
              ],
              [
                -47.03539307149697,
                -20.49602456289879
              ],
              [
                -47.03493173154641,
                -20.4946276533716
              ],
              [
                -47.035725665414816,
                -20.49418546353048
              ],
              [
                -47.03533942731667,
                -20.49338147873323
              ],
              [
                -47.03544671567727,
                -20.491632797240367
              ],
              [
                -47.0361548188572,
                -20.491914195608818
              ],
              [
                -47.03640158208657,
                -20.491773496489152
              ],
              [
                -47.03664834531594,
                -20.49172324677227
              ],
              [
                -47.03695948156167,
                -20.491914195608818
              ],
              [
                -47.037528109872824,
                -20.49205489459935
              ],
              [
                -47.03764612706948,
                -20.492316192382056
              ],
              [
                -47.037013125741964,
                -20.492838786611397
              ],
              [
                -47.03732426198769,
                -20.493039783917578
              ],
              [
                -47.03731353315163,
                -20.493502076721622
              ],
              [
                -47.03629429372597,
                -20.493532226203918
              ],
              [
                -47.036015343988424,
                -20.493974417929376
              ],
              [
                -47.03614409002114,
                -20.494336210210523
              ],
              [
                -47.03654105695534,
                -20.494215612878357
              ],
              [
                -47.036734176004416,
                -20.49493919544828
              ],
              [
                -47.036734176004416,
                -20.4957934204747
              ],
              [
                -47.03706676992226,
                -20.495843668857418
              ],
              [
                -47.03703458341408,
                -20.49511004083439
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -47.033706849596,
                -20.49174551965513
              ],
              [
                -47.03416818954656,
                -20.4925696128125
              ],
              [
                -47.03447932579229,
                -20.49299170759219
              ],
              [
                -47.03449005462835,
                -20.493393701539986
              ],
              [
                -47.034629529497124,
                -20.493876092885866
              ],
              [
                -47.03499430992315,
                -20.494137387564397
              ],
              [
                -47.034854835054375,
                -20.494559478027337
              ],
              [
                -47.03406090118597,
                -20.495011716519322
              ],
              [
                -47.034339850923516,
                -20.49620762965755
              ],
              [
                -47.034136003038384,
                -20.49629807649017
              ],
              [
                -47.03380340912054,
                -20.495875990814714
              ],
              [
                -47.03371757843206,
                -20.495202661259796
              ],
              [
                -47.03342789985845,
                -20.495363456646214
              ],
              [
                -47.034082358858086,
                -20.497091996397057
              ],
              [
                -47.03396434166143,
                -20.49737338474406
              ],
              [
                -47.03347081520269,
                -20.497473880457083
              ],
              [
                -47.03293437339971,
                -20.495725245648934
              ],
              [
                -47.03147525169561,
                -20.49402683987015
              ],
              [
                -47.031582540056206,
                -20.493876092885866
              ],
              [
                -47.03131431915472,
                -20.493554498823936
              ],
              [
                -47.03306311943243,
                -20.491866118930464
              ],
              [
                -47.033342069169976,
                -20.49201686789122
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -44.462915188212094,
                -21.5740982096935
              ],
              [
                -44.46274352683514,
                -21.604904538850153
              ],
              [
                -44.427209621805844,
                -21.60474493746021
              ],
              [
                -44.43150115622967,
                -21.57473674933925
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "coordinates": []
    }),
    geometry = /* color: #98ff00 */ee.Geometry.MultiPoint();
// This example uses the Sentinel-2 QA band to cloud mask
// the collection.  The Sentinel-2 cloud flags are less
// selective, so the collection is also pre-filtered by the
// CLOUDY_PIXEL_PERCENTAGE flag, to use only relatively
// cloud-free granule.
// Function to mask clouds using the Sentinel-2 QA band.
function maskS2clouds(image) {
  var qa = image.select('QA60')
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = ee.Number(2).pow(10).int()
  var cirrusBitMask = ee.Number(2).pow(11).int()
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0))
  // Return the masked and scaled data, without the QA bands.
  return image.updateMask(mask).divide(10000)
      .select("B.*")
      .copyProperties(image, ["system:time_start"])
}
//
var point = Cafe_Zecao;
// Map the function over one year of data and take the median.
var collection = ee.ImageCollection('COPERNICUS/S2')
    .filterDate('2016-07-01', '2016-12-31')
    // Pre-filter to get less cloudy granules.
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 0.1))
    .map(maskS2clouds)
 .filterBounds(point);
 var composite = collection.median();
// Load Sentinel-2 TOA reflectance data.
var collection = ee.ImageCollection('COPERNICUS/S2')
    .filterDate('2017-01-01', '2017-06-30')
    // Pre-filter to get less cloudy granules.
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 0.1))
    .map(maskS2clouds)
 .filterBounds(point);
var composite1 = collection.median();
var collection = ee.ImageCollection('COPERNICUS/S2')
    .filterDate('2017-07-01', '2017-12-31')
    // Pre-filter to get less cloudy granules.
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 0.1))
    .map(maskS2clouds)
 .filterBounds(point);
var composite2 = collection.median();
//
var collection = ee.ImageCollection('COPERNICUS/S2')
    .filterDate('2018-01-01', '2018-06-30')
    // Pre-filter to get less cloudy granules.
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 0.1))
    .map(maskS2clouds)
 .filterBounds(point);
var composite3 = collection.median();
//
// Make a palette: a list of hex strings.
var palette = ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
               '74A901', '66A000', '529400', '3E8601', '207401', '056201',
               '004C00', '023B01', '012E01', '011D01', '011301'];
var evi = composite.expression(
    '2.5 * (nir - red) / (nir + 6 * red - 7.5 * blue + 1)',
    {
        red: composite.select('B4'),    // 620-670nm, RED
        nir: composite.select('B8'),    // 841-876nm, NIR
        blue: composite.select('B2')    // 459-479nm, BLUE
    });
// Center the map.
var evi1 = composite.expression(
    '2.5 * (nir - red) / (nir + 6 * red - 7.5 * blue + 1)',
    {
        red: composite1.select('B4'),    // 620-670nm, RED
        nir: composite1.select('B8'),    // 841-876nm, NIR
        blue: composite1.select('B2')    // 459-479nm, BLUE
    });
var evi2 = composite.expression(
    '2.5 * (nir - red) / (nir + 6 * red - 7.5 * blue + 1)',
    {
        red: composite2.select('B4'),    // 620-670nm, RED
        nir: composite2.select('B8'),    // 841-876nm, NIR
        blue: composite2.select('B2')    // 459-479nm, BLUE
    });
var evi3 = composite3.expression(
    '2.5 * (nir - red) / (nir + 6 * red - 7.5 * blue + 1)',
    {
        red: composite3.select('B4'),    // 620-670nm, RED
        nir: composite3.select('B8'),    // 841-876nm, NIR
        blue: composite3.select('B2')    // 459-479nm, BLUE
    });
var roi = Cafe_Zecao;
// Display the input image and the EVI computed from it.
Map.addLayer(evi.clip(roi), {min: 0.1, max: 1, palette: palette}, 'EVI 2 2016');
Map.addLayer(evi1.clip(roi), {min: 0.2, max: 0.8, palette: palette}, 'EVI 1 2017');
Map.addLayer(evi2.clip(roi), {min: 0.2, max: 0.8, palette: palette}, 'EVI 2 2017');
Map.addLayer(evi3.clip(roi), {min: 0.25, max: 1, palette: palette}, 'EVI 1 2018');
///////////////
// Make a button widget.
var button = ui.Button('Click me!');
// Set a callback function to run when the
// button is clicked.
button.onClick(function() {
  print('Hello, world!');
});
// Display the button in the console.
print(button);
// Set another callback function on the button.
button.onClick(function() {
  print('Oh, yeah!');
});
var button = ui.Button({
  label: 'Get Map Center',
  onClick: function() {
    print(Map.getCenter());
  }
});
print(button);
///
var places = {
  MUZ: [-46.53, -21.35],
  PC: [-46.59, -21.82],
  CASSIA: [-46.94, -20.59]
};
var select = ui.Select({
  items: Object.keys(places),
  onChange: function(key) {
    Map.setCenter(places[key][0], places[key][1],10);
  }
});
// Set a place holder.
select.setPlaceholder('ESCOLHA A LOCALIZAÇÃO');
print(select);