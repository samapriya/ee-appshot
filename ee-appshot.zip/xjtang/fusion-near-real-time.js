var example = ui.import && ui.import("example", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -55.355242216747605,
                -6.355486582325627
              ],
              [
                -55.3343012449688,
                -6.345250554790472
              ],
              [
                -55.33704764901131,
                -6.323412863643333
              ],
              [
                -55.36353448732132,
                -6.331260678097867
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Polygon(
        [[[-55.355242216747605, -6.355486582325627],
          [-55.3343012449688, -6.345250554790472],
          [-55.33704764901131, -6.323412863643333],
          [-55.36353448732132, -6.331260678097867]]]);
// Fusion Near Real-time
// Near real-time monitoring of forest disturbance by fusion of multi-sensor data
// Fusion Near Real-time
// ---------------------------------------------------------------
// Imports and predefined variables:
var listener = 0;
var utChart = require('users/xjtang/fnrt:Utilities/Chart');
var utParam = require('users/xjtang/fnrt:Utilities/Parameters');
var utCommon = require('users/xjtang/fnrt:Utilities/Common');
var trainPeriod = utParam.trainPeriod;
var monitorPeriod = utParam.monitorPeriod;
var fullPeriod = utParam.fullPeriod;
// ---------------------------------------------------------------
// Main functions:
  // run and plot CCD for a pixel
var chartCCD = function(coords) {
  resetAll();
  var sensor = ccdSelect.getValue();
  tsPanel.add(ui.Label('Running CCD on ' + sensor + ' data...'));
  var pixel = ee.Geometry.Point([coords.lon, coords.lat]);
  var trainData = utCommon.getData(pixel, trainPeriod, sensor);
  var monitorData = utCommon.getData(pixel, monitorPeriod, sensor);
  utCommon.addPixel(mapPanel, coords, 0.000135, '0000FF', 'Clicked');
  var ccdParam = utParam.getCCDParam(sensor);
  var runParam = utParam.getRunParam(sensor);
  var ccd = utChart.runCCD(ccdParam, trainData);
  var ccdTS = utChart.getTimeSeries(trainData, monitorData, ccd, pixel, ccdParam.dateFormat, runParam.band, 0.1);
  var segList = utChart.genSegList(runParam.nSeg);
  var ccdTable = utChart.getCCDTable(ccdTS, segList);
  ccdTable.evaluate(function(t, e) {
    var chart = utChart.getCCDChart(t, runParam.band, coords.lat, coords.lon, runParam.nSeg);
    chart.onClick(
      function(date) {
        if (date === null) {
          utCommon.removeLayer(mapPanel, '_');
        } else {
          var img = ee.Image(utCommon.getImage(pixel, date, sensor));
          var imgVis = utParam.getVisParam(sensor);
          mapPanel.addLayer(img, imgVis, img.get('system:index').getInfo());
          utCommon.removeLayer(mapPanel, 'Clicked');
          utCommon.addPixel(mapPanel, coords, 0.000135, '0000FF', 'Clicked');
        }
      }
    );
    resetTSPanel();
    tsPanel.add(chart);
  });
};
  // run sensor specifi near real time
var runSensorNRT = function(pixel, sensor) {
  var train = utCommon.getData(pixel, trainPeriod, sensor);
  var monitor = utCommon.getData(pixel, monitorPeriod, sensor);
  var ccdParam = utParam.getCCDParam(sensor);
  var runParam = utParam.getRunParam(sensor);
  var nrtParam = utParam.getNRTParam(sensor);
  var ccd = utChart.runCCD(ccdParam, train);
  var ccdTS = utChart.getTimeSeries(train, monitor, ccd, pixel, ccdParam.dateFormat, nrtParam.band);
  return utChart.checkZ(utChart.addZ(ccdTS), nrtParam);
};
  // add image when nrt chart is clicked
var addNRTImage = function(pixel, date, sensor) {
  var img = utCommon.getImage(pixel, date, sensor);
  if (img.getInfo() != null) {
    var imgVis = utParam.getVisParam(sensor);
    img = ee.Image(img);
    mapPanel.addLayer(img, imgVis, img.get('system:index').getInfo());
  } 
};
  // run and plot NRT for a pixel
var chartNRT = function(coords) {
  resetAll();
  tsPanel.add(ui.Label('Running NRT...'));
  var pixel = ee.Geometry.Point([coords.lon, coords.lat]);
  utCommon.addPixel(mapPanel, coords, 0.000135, '0000FF', 'Clicked');
  var nrtParam = utParam.getNRTParam('Common');
  var nrtTS = ee.ImageCollection([]);
  if (S2Check.getValue()) {nrtTS = nrtTS.merge(runSensorNRT(pixel, 'Sentinel-2'))}
  if (S1Check.getValue()) {nrtTS = nrtTS.merge(runSensorNRT(pixel, 'Sentinel-1'))}
  if (MODISCheck.getValue()) {nrtTS = nrtTS.merge(runSensorNRT(pixel, 'MODIS'))}
  if (LSTCheck.getValue()) {nrtTS = nrtTS.merge(runSensorNRT(pixel, 'Landsat'))}
  nrtTS = nrtTS.filterMetadata('x', 'not_equals', null);
  if (nrtTS.size().gt(0)) {
    var nrtMonitor = ee.ImageCollection(utChart.getNRTMonitor(nrtTS.sort('system:time_start'), nrtParam));
    var nrtList = ["dateString", "Z_train", "Ball", 'Strike', 'StrikeOut'];
    var nrt = utChart.getCCDTable(nrtMonitor, nrtList);
    nrt.evaluate(function(t, e) {
      var chart = utChart.getNRTChart(t, nrtParam.band, coords.lat, coords.lon);
      chart.onClick(
        function(date) {
          if (date === null) {
            utCommon.removeLayer(mapPanel, '_');
          } else {
            if (S2Check.getValue()) {addNRTImage(pixel, date, 'Sentinel-2')}
            if (S1Check.getValue()) {addNRTImage(pixel, date, 'Sentinel-1')}
            if (MODISCheck.getValue()) {addNRTImage(pixel, date, 'MODIS')}
            if (LSTCheck.getValue()) {addNRTImage(pixel, date, 'Landsat')}
            utCommon.removeLayer(mapPanel, 'Clicked');
            utCommon.addPixel(mapPanel, coords, 0.000135, '0000FF', 'Clicked');
          }
        }
      );
      resetTSPanel();
      tsPanel.add(chart);
    });
  } else {
    tsPanel.add(ui.Label('No sensor was selected.'));
  }
};
  // reset the time series panel
var resetTSPanel = function() {
  tsPanel.clear();
  utCommon.removeLayer(mapPanel, '_');
};
  // reset all
var resetAll = function() {
  resetTSPanel();
  utCommon.removeLayer(mapPanel, 'Clicked');
};
// ---------------------------------------------------------------
// UIs:
  // map panel
var mapPanel = ui.Map({style: {cursor: 'crosshair'}});
mapPanel.setCenter(-55.18418807329864, -6.3470237218092995, 10);
mapPanel.setOptions('SATELLITE');
  // menu panel
var resetButton = ui.Button('Reset');
var ccdButton = ui.Button('CCD');
var nrtButton = ui.Button('NRT');
var addButton = ui.Button('Add');
var menuSet = ui.Panel([resetButton, ccdButton, nrtButton, addButton], 
                        ui.Panel.Layout.Flow('vertical'));
var ccdSelect = ui.Select(['Landsat', 'Sentinel-2', 'MODIS'], 'Select sensor for CCD.', 'Landsat');
var LSTCheck = ui.Checkbox('Landsat', true);
var S2Check = ui.Checkbox('Sentinel-2', true);
var S1Check = ui.Checkbox('Sentinel-1', false);
var MODISCheck = ui.Checkbox('MODIS', false);
var selectSet = ui.Panel([ccdSelect, LSTCheck, S2Check, S1Check, MODISCheck], 
                        ui.Panel.Layout.Flow('vertical'));
var menuUISet = ui.Panel([menuSet, selectSet], ui.Panel.Layout.Flow('horizontal'));
var menuPanel = ui.Panel({
  widgets: [ui.Label('Menu'), menuUISet],
  layout: ui.Panel.Layout.Flow('vertical'),
  style: {width: '20%'}});
  // ts panel
var tsPanel = ui.Panel({
  widgets: [],
  style: {position: 'bottom-right', width: '80%'}});
  // ui panel
var controlPanel = ui.Panel({
  style: {height: '30%'},
  widgets:[ui.SplitPanel(tsPanel, menuPanel, 'horizontal', false)]});
var mapPanel2 = ui.Panel({
  style: {height: '70%'},
  widgets:[mapPanel]});
var uiPanel = ui.SplitPanel(mapPanel2, controlPanel, 'vertical');
// ---------------------------------------------------------------
// Runtime functions:
ccdButton.onClick(function() {
  if (listener == 1) {
    ccdButton.setLabel('CCD');
    listener = 0;
  } else {
    nrtButton.setLabel('NRT');
    ccdButton.setLabel('Cancel');
    listener = 1;
  }
});
nrtButton.onClick(function() {
  if (listener == 2) {
    nrtButton.setLabel('NRT');
    listener = 0;
  } else {
    nrtButton.setLabel('Cancel');
    ccdButton.setLabel('CCD');
    listener = 2;
  }
});
addButton.onClick(function() {
  var flagVis = utParam.getVisParam('Flag');
  var result = ee.Image("users/xjtang/fnrt/flag");
  mapPanel.addLayer(result, flagVis, 'Result');
});
resetButton.onClick(function() {
  resetAll();
});
mapPanel.onClick(function(coords) {
  if (listener == 1) {
    chartCCD(coords);
  } else if (listener == 2) {
    chartNRT(coords);
  }
});
// ---------------------------------------------------------------
// Initialization:
ui.root.clear();
ui.root.add(uiPanel);
S1Check.setDisabled(true);
mapPanel.addLayer(example, {color: 'red'}, 'Example');
// End