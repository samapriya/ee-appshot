// Showcase of CHART project
// ---------------------------------------------------------------
// Imports and predefined variables:
var emission = ee.Image("users/xjtang/chart/archive/mekong/carbon/emission");
var uptake = ee.Image("users/xjtang/chart/archive/mekong/carbon/uptake");
var net = ee.Image("users/xjtang/chart/archive/mekong/carbon/net");
var RdYlGn = 'a50026, d73027, f46d43, fdae61, fee08b, ffffbf, d9ef8b, a6d96a, 66bd63, 1a9850, 006837';
var em_vis = {"max":-200, "min":200, 'palette': RdYlGn};
var ut_vis = {"max":-200, "min":200, 'palette': RdYlGn};
var nt_vis = {"max":-200, "min":200, 'palette': RdYlGn};
var change = ee.Image("users/xjtang/chart/archive/mekong/changes/change");
var chgPal = '000000, 1E942E, F279F2, 98B611, 88F58A, D1A4F6, F67965, CFCCB7, 2A43F7, 2AF7D8, F7CC2A, F7CC2A, F7CC2A, F7CC2A, F7CC2A, F7CC2A';
var chgVis = {"max":15, "min":0, 'palette': chgPal};
var lc_2001 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2001");
var lc_2002 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2002");
var lc_2003 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2003");
var lc_2004 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2004");
var lc_2005 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2005");
var lc_2006 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2006");
var lc_2007 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2007");
var lc_2008 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2008");
var lc_2009 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2009");
var lc_2010 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2010");
var lc_2011 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2011");
var lc_2012 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2012");
var lc_2013 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2013");
var lc_2014 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2014");
var lc_2015 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2015");
var lc_2016 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2016");
var lc_2017 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2017");
var lc_2018 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2018");
var lc_2019 = ee.Image("users/xjtang/chart/archive/mekong/lcmaps/lc_2019");
var lcPal = '000000, 1E942E, 1E942E, 1E942E, 1E942E, 1E942E, 000000, 000000, 000000, 98B611, 88F58A, D1A4F6, F279F2, F67965, 000000, 000000, CFCCB7, F279F2, 2AF7D8, D1A4F6, D1A4F6, F279F2, 000000, 000000, 000000, 2A43F7';
var lcVis = {"max":25, "min":0, 'palette': lcPal};
// ---------------------------------------------------------------
// Initialization:
emission = emission.updateMask(emission.gt(5));
uptake = uptake.updateMask(uptake.lt(-5));
net = net.updateMask(net.gt(5));
Map.setCenter(104.535, 14.462, 6);
Map.setOptions('SATELLITE');
Map.style().set('cursor', 'crosshair');
Map.addLayer(lc_2001, lcVis, "LULC Map 2001", false);
Map.addLayer(lc_2002, lcVis, "LULC Map 2002", false);
Map.addLayer(lc_2003, lcVis, "LULC Map 2003", false);
Map.addLayer(lc_2004, lcVis, "LULC Map 2004", false);
Map.addLayer(lc_2005, lcVis, "LULC Map 2005", false);
Map.addLayer(lc_2006, lcVis, "LULC Map 2006", false);
Map.addLayer(lc_2007, lcVis, "LULC Map 2007", false);
Map.addLayer(lc_2008, lcVis, "LULC Map 2008", false);
Map.addLayer(lc_2009, lcVis, "LULC Map 2009", false);
Map.addLayer(lc_2010, lcVis, "LULC Map 2010", false);
Map.addLayer(lc_2011, lcVis, "LULC Map 2011", false);
Map.addLayer(lc_2012, lcVis, "LULC Map 2012", false);
Map.addLayer(lc_2013, lcVis, "LULC Map 2013", false);
Map.addLayer(lc_2014, lcVis, "LULC Map 2014", false);
Map.addLayer(lc_2015, lcVis, "LULC Map 2015", false);
Map.addLayer(lc_2016, lcVis, "LULC Map 2016", false);
Map.addLayer(lc_2017, lcVis, "LULC Map 2017", false);
Map.addLayer(lc_2018, lcVis, "LULC Map 2018", false);
Map.addLayer(lc_2019, lcVis, "LULC Map 2019", false);
Map.addLayer(emission, em_vis, "Emission (Mg/ha)");
Map.addLayer(uptake, ut_vis, "Uptake (Mg/ha)");
Map.addLayer(net, nt_vis, "Net (Mg/ha)");
Map.addLayer(change, chgVis, "Change Map");
// End