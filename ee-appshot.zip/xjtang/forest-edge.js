var maine = ui.import && ui.import("maine", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -71.06391667716616,
                44.19297222148151
              ],
              [
                -71.04194402091616,
                43.38402716563023
              ],
              [
                -70.77827214591616,
                43.047751190934584
              ],
              [
                -70.39375066154116,
                43.264141490050875
              ],
              [
                -69.15229558341616,
                43.84535835739176
              ],
              [
                -67.96577214591616,
                44.20872442487299
              ],
              [
                -66.93305730216616,
                44.77299841607045
              ],
              [
                -67.03193425529116,
                45.068608466378485
              ],
              [
                -67.33955144279116,
                45.231319399066905
              ],
              [
                -67.36152409904116,
                45.57073141078378
              ],
              [
                -67.68012761466616,
                45.66294446724674
              ],
              [
                -67.76801823966616,
                46.455774049337336
              ],
              [
                -67.76801823966616,
                47.12521849181285
              ],
              [
                -68.11958073966616,
                47.38620306322727
              ],
              [
                -68.75678777091616,
                47.34899829887017
              ],
              [
                -69.05341863029116,
                47.48281264877532
              ],
              [
                -69.87739323966616,
                46.90799940107325
              ],
              [
                -70.28388738029116,
                45.953952171786945
              ],
              [
                -71.05293034904116,
                45.34725711120511
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-71.06391667716616, 44.19297222148151],
          [-71.04194402091616, 43.38402716563023],
          [-70.77827214591616, 43.047751190934584],
          [-70.39375066154116, 43.264141490050875],
          [-69.15229558341616, 43.84535835739176],
          [-67.96577214591616, 44.20872442487299],
          [-66.93305730216616, 44.77299841607045],
          [-67.03193425529116, 45.068608466378485],
          [-67.33955144279116, 45.231319399066905],
          [-67.36152409904116, 45.57073141078378],
          [-67.68012761466616, 45.66294446724674],
          [-67.76801823966616, 46.455774049337336],
          [-67.76801823966616, 47.12521849181285],
          [-68.11958073966616, 47.38620306322727],
          [-68.75678777091616, 47.34899829887017],
          [-69.05341863029116, 47.48281264877532],
          [-69.87739323966616, 46.90799940107325],
          [-70.28388738029116, 45.953952171786945],
          [-71.05293034904116, 45.34725711120511]]]);
// Forest Edge Effect
// ---------------------------------------------------------------
// Imports and predefined variables:
var dataset = ee.Image('UMD/hansen/global_forest_change_2019_v1_7').clip(maine);
var treeGain = dataset.select('gain');
var treeCoverVisParam = {bands: ['treecover2000'], min: 0, max: 100, palette: ['black', 'green']};
var treeLossVisParam = {bands: ['lossyear'], min: 0, max: 19, palette: ['yellow', 'red']};
var treeGainVisParam = {min: 0, max: 1, palette: ['blue']};
var edgeVisParam = {min: 0, max: 1, palette: ['black', 'white']};
var forest = dataset.select('treecover2000').gt(50);
var nonForest = dataset.select('treecover2000').lte(50);
var proj = forest.projection().getInfo();
var result = ee.Image("users/xjtang/edge/maine_edge");
// ---------------------------------------------------------------
// UIs:
var saveButton = ui.Button('Save');
saveButton.onClick(function(){
  Export.image.toAsset({
    image: edge, 
    description: 'SaveMap', 
    assetId: 'maine_edge', 
    region: maine, 
    crs: proj.crs,
    crsTransform: proj.transform,
    maxPixels: 6000000000});
});
var savePanel = ui.Panel({
  widgets: [saveButton],
  style: {position: 'bottom-left'}
});
// ---------------------------------------------------------------
// Main functions:
var getNeighbours = function(img){
  var kernel = ee.Kernel.square(1);
  return img.neighborhoodToBands(kernel).reduce(ee.Reducer.sum());
};
var getEdge = function(f, nf){
  return f.multiply(getNeighbours2(nf).eq(1)).rename('edge');
};
var getNeighbours2 = function(img){
  return img.reduceNeighborhood({
    reducer: ee.Reducer.max(), 
    kernel: ee.Kernel.square(img.projection().nominalScale(), 'meters')});
};
// ---------------------------------------------------------------
// Initialization:
var treeGainMasked = treeGain.updateMask(treeGain.eq(1));
var forestMasked = forest.updateMask(forest.eq(1));
var nfMasked = nonForest.updateMask(nonForest.eq(1));
//var edge = getEdge(forest, nonForest);
//var edgeMasked = edge.updateMask(edge.eq(1));
var resultMasked = result.updateMask(result.eq(1));
Map.addLayer(dataset, treeCoverVisParam, 'Tree Cover', false);
Map.addLayer(dataset, treeLossVisParam, 'Tree Loss (Year)', false);
Map.addLayer(treeGainMasked, treeGainVisParam, 'Tree Gain (Binary)', false);
Map.addLayer(nfMasked, treeGainVisParam, 'Non-forest (Binary)', false);
Map.addLayer(forestMasked, treeGainVisParam, 'Forest (Binary)');
Map.addLayer(resultMasked, edgeVisParam, 'Edge');
Map.setOptions('SATELLITE');
//Map.add(savePanel);
print(proj.transform);
// End