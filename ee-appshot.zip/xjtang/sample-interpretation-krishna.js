// CHART Sample Interpretation 
// ---------------------------------------------------------------
// Imports and predefined variables:
var utilities = require('users/xjtang/chart:Utilities');
var samples = ee.FeatureCollection('users/xjtang/chart/samples/samples_krishna');
var sampleID = 'SID';
var visParams = {bands: ['B3', 'B2', 'B1'], min: 0, max: 1400};
var studyPeriod = ee.Dictionary({
     'start': '2000-01-01',
     'end': '2016-01-01',
      });
var stretches = {
    Stretch_321: {bands: ['B3', 'B2', 'B1'], min: 0, max: 1400},
    Stretch_543: {bands: ['B5', 'B4', 'B3'], min: 0, max: 5000}
  };
var currentSU = 0;
var maxSU = 1999;
var userEntered = '';
var enterFor = 0;
var listener = 0;
var drawGeos = ee.List([]);
var drawFeatures = ee.List([]);
var events = ee.List([]);
// ---------------------------------------------------------------
// UIs:
// Panel for moving between sample units
var IDBox = ui.Textbox({
  placeholder: 'Search ID',
  style: {width: '80px',margin: '2px'}
});
var prevButton = ui.Button('Previous', null, false, {margin: '0 auto 0 0'});
var nextButton = ui.Button('Next', null, false, {margin: '0 0 0 auto'});
var moveSet = ui.Panel([prevButton, IDBox, nextButton], 
                        ui.Panel.Layout.Flow('horizontal'));
var movePanel = ui.Panel({
  widgets: [moveSet],
  style: {position: 'bottom-center', width: '250px'}
});
// Panel for displaying time series
var resetButton = ui.Button('Reset');
var clickButton = ui.Button('Click to get TS');
var clickSet = ui.Panel([clickButton, resetButton], 
                        ui.Panel.Layout.Flow('horizontal'));
var stretchSelect = ui.Select({
  items: Object.keys(stretches),
  placeholder: 'Select Stretch'
});
var tsUISet = ui.Panel([ui.Label('Time Series'), clickSet, stretchSelect]);
var tsPanel = ui.Panel({
  widgets: [tsUISet],
  style: {width: '600px'}
});
// Panel for recording
var importButton = ui.Button('Import');
var saveButton = ui.Button('Save');
var ioSet = ui.Panel([importButton, saveButton], 
                      ui.Panel.Layout.Flow('horizontal'));
var suSelect = ui.Select({
  placeholder: 'Select Recorded Events'
});
var idBox = ui.Textbox({placeholder: 'Sample ID', 
                        value: '',
                        style: {stretch: 'horizontal'}});
var idSet = ui.Panel([ui.Label('SID:'), idBox], 
                      ui.Panel.Layout.Flow('horizontal'));
var dateBox = ui.Textbox({placeholder: 'Disturbance Date',
                          value: '',
                          style: {stretch: 'horizontal'}});
var dateSet = ui.Panel([ui.Label('Date:'), dateBox], 
                      ui.Panel.Layout.Flow('horizontal'));
var drawButton = ui.Button('Draw');
var clearButton = ui.Button('Clear');
var drawSet = ui.Panel([drawButton, clearButton], 
                      ui.Panel.Layout.Flow('horizontal'));
var addButton = ui.Button('Add');
var updateButton = ui.Button('Update');
var deleteButton = ui.Button('Delete');
var recordSet = ui.Panel([addButton, updateButton, deleteButton], 
                      ui.Panel.Layout.Flow('horizontal'));
var recordPanel = ui.Panel({
  widgets: [ui.Label('Record Events'), ioSet, suSelect, idSet, 
            dateSet, drawSet, recordSet],
  style: {width: '220px'}
});
// Panel for user entering
var submitButton = ui.Button('Submit');
var cancelButton = ui.Button('Cancel');
var inputBox = ui.Textbox({style: {stretch: 'horizontal'}});
var inputSet = ui.Panel([inputBox, submitButton, cancelButton], 
                          ui.Panel.Layout.Flow('horizontal'));
var inputPanel = ui.Panel({
  widgets: [inputSet],
  style: {position: 'top-center', width: '400px', height: '46px', 
          shown: false, padding: '0px'}
});
// Panel for messager
var messager = ui.Label('System information...');
var messagerPanel = ui.Panel({
  widgets: [messager],
  style: {position: 'bottom-left', width: '250px', height: '34px',
          padding: '0px'}
});
// ---------------------------------------------------------------
// Runtime Functions:
prevButton.onClick(function(button){ 
  moveToPixel(currentSU - 1);
});
nextButton.onClick(function(button){
  moveToPixel(currentSU + 1);
});
IDBox.onChange(function(input){
  moveToPixel(parseInt(input, 10));
});
clickButton.onClick(function(){
  if (listener == 1) {
    clickButton.setLabel('Click to get TS');
    listener = 0;
  } else if (listener === 0) {
    clickButton.setLabel('Cancel');
    listener = 1;
  } else {
    messager.setValue('Something else is working.');
  }
});
stretchSelect.onChange(function(key){
  visParams = stretches[key];
});
resetButton.onClick(function(){
  if (listener === 0 || listener == 1) {
    tsPanel.clear();
    tsPanel.add(tsUISet);
    removeLayer('Clicked');
    removeLayer('_L.0._');
  } else {
    messager.setValue('Cannot reset.');
  }
});
importButton.onClick(function(){
  inputBox.setPlaceholder('Import from...');
  userEntered = '';
  enterFor = 1;
  inputPanel.style().set('shown', true);
});
saveButton.onClick(function(){
  inputBox.setPlaceholder('Save as...');
  userEntered = '';
  enterFor = 2;
  inputPanel.style().set('shown', true);
});
submitButton.onClick(function(){
  if (userEntered !== ''){
    if (enterFor == 1) {
      print('Import from: ' + userEntered);
    } else if (enterFor == 2) {
      print('Save as: ' + userEntered);
    }
    inputBox.setValue('');
    inputPanel.style().set('shown', false);
  }
});
cancelButton.onClick(function(){
  inputBox.setValue('');
  enterFor = 0;
  inputPanel.style().set('shown', false);
});
inputBox.onChange(function(text){
  userEntered = text;
});
drawButton.onClick(function(){
  if (listener == 2) {
    drawGeos = ee.List([]);
    removeLayer('Vertex');
    removeLayer('Edge');
    drawButton.setLabel('Draw');
    listener = 0;
  } else if (listener === 0) {
    drawButton.setLabel('Done');
    listener = 2;
  } else {
    messager.setValue('Something else is working.');
  }
});
clearButton.onClick(function(){
  drawGeos = ee.List([]);
  drawFeatures = ee.List([]);
  removeLayer('Vertex');
  removeLayer('Edge');
  removeLayer('Event');
  idBox.setValue('');
  dateBox.setValue('');
});
addButton.onClick(function(){
  if (listener == 2) { 
    messager.setValue('Complete drawing first.');
  } else {
    var thisSID = idBox.getValue();
    if (thisSID === '') {
      messager.setValue('Must enter an SID.');
    } else {
      var thisDate = dateBox.getValue();
      if (thisDate === '') {
        messager.setValue('Must enter an Date.');
      } else {
        if (drawFeatures.length().getInfo() > 0) {
          var thisGeo = ee.Geometry.MultiPolygon(drawFeatures);
          events = events.add(ee.Feature(thisGeo, {SID: thisSID, Date: thisDate}));
          messager.setValue('Event for ' + thisSID + ' added.');
          idBox.setValue('');
          dateBox.setValue('');
          drawGeos = ee.List([]);
          drawFeatures = ee.List([]);
          removeLayer('Event');
        } else {
          messager.setValue('Must draw an event.');
        }
      }
    }
  }
});
Map.onClick(function(coords){
  if (listener == 1) {
    // Click on the map and load a new time series
    tsPanel.clear();
    tsPanel.add(tsUISet);
    removeLayer('Clicked');
    removeLayer('_L.0._');
    var pgeo = ee.Geometry.Point([coords.lon, coords.lat]);
    // Create or update the location label
    var location = 'Lon: ' + coords.lon.toFixed(2) + ' ' +
                   'Lat: ' + coords.lat.toFixed(2);
    messager.setValue(location);
    var landsatData = getLandsatTS(pgeo, studyPeriod);
    var modisVI = getMODISVI(pgeo, studyPeriod);
    var modisLC = getMODISLC(pgeo);
    addPixel(coords, 0.00106, '00FF00', 'Clicked (MODIS)');
    addPixel(coords, 0.000135, '0000FF', 'Clicked (Landsat)');
    reloadSamples();
    plotLandsat(landsatData, pgeo, 'EVI', -0.5, 1);
    plotLandsat(landsatData, pgeo, 'NDVI', -0.5, 1);
    plotMODIS(modisVI, pgeo, 'EVI', -5000, 10000);
    plotMODIS(modisVI, pgeo, 'NDVI', -5000, 10000);
    plotMODIS(modisVI, pgeo, 'Red', 0, 3000);
    plotMODIS(modisVI, pgeo, 'NIR', 0, 5000);
    plotMODIS(modisVI, pgeo, 'MIR', 0, 3000);
    plotMODIS(modisLC, pgeo, 'Land Cover', 0, 25);
  } else if (listener == 2) {
    // Click on the map tp draw
    var drawPoint = ee.Geometry.Point([coords.lon, coords.lat]);
    if (drawGeos.length().getInfo() >= 1) {
      if (drawPoint.distance(drawGeos.get(0)).getInfo() < 25) {
        if (drawGeos.length().getInfo() >= 3) {
          // polygon completed
          drawFeatures = drawFeatures.add(ee.Geometry.Polygon(drawGeos));
          drawGeos = ee.List([]);
          removeLayer('Vertex');
          removeLayer('Edge');
          removeLayer('Event');
          Map.addLayer(ee.Geometry.MultiPolygon(drawFeatures), {color: '00FF00'}, 'Event');
        } else {
          drawGeos = ee.List([]);
          removeLayer('Vertex');
          removeLayer('Edge');
        }
      } else {
        // add a point to drawing
        drawGeos = drawGeos.add(drawPoint);
        removeLayer('Vertex');
        removeLayer('Edge');
        Map.addLayer(ee.Geometry.MultiPoint(drawGeos), {color: '00FF00'}, 'Vertex');
        Map.addLayer(ee.Geometry.LineString(drawGeos), {color: '00FF00'}, 'Edge');
      }
    } else {
      // first point
      drawGeos = drawGeos.add(drawPoint);
      Map.addLayer(ee.Geometry.MultiPoint(drawGeos), {color: '00FF00'}, 'Vertex');
    }
  }
});
// ---------------------------------------------------------------
// Functions:
var getLandsatImage = function(region, date) {
  // Get Landsat image at a given date and location
  var collection4 = ee.ImageCollection('LANDSAT/LT04/C01/T1_SR')
      .filterBounds(region);
  var collection5 = ee.ImageCollection('LANDSAT/LT05/C01/T1_SR')
      .filterBounds(region);
  var collection7 = ee.ImageCollection('LANDSAT/LE07/C01/T1_SR')
      .filterBounds(region);
  var collection8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
      .filterBounds(region);
  var col4NoClouds = collection4.map(utilities.mask457);
  var col5NoClouds = collection5.map(utilities.mask457);
  var col7NoClouds = collection7.map(utilities.mask457);
  var col8NoClouds = collection8.map(utilities.mask8);
  var colNoClouds = col4NoClouds
                      .merge(col5NoClouds)
                      .merge(col7NoClouds)
                      .merge(col8NoClouds);
  var imDate = ee.Date(date);
  var befDate = imDate.advance(-1, 'day');
  var aftDate = imDate.advance(1, 'day');
  var selectedImage = colNoClouds.filterDate(befDate, aftDate).first();
  var image_id = selectedImage.get('system:index').getInfo();
  Map.addLayer(ee.Image(selectedImage), visParams, image_id);
  return selectedImage;
};
var getLandsatTS = function(region, params) {
  // Get Landsat time series for a given location
  var collection4 = ee.ImageCollection('LANDSAT/LT04/C01/T1_SR')
      .filterBounds(region).filterDate(params.get('start'), params.get('end'));
  var collection5 = ee.ImageCollection('LANDSAT/LT05/C01/T1_SR')
      .filterBounds(region).filterDate(params.get('start'), params.get('end'));
  var collection7 = ee.ImageCollection('LANDSAT/LE07/C01/T1_SR')
      .filterBounds(region).filterDate(params.get('start'), params.get('end'));
  var collection8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
      .filterBounds(region).filterDate(params.get('start'), params.get('end'));
  var col4NoClouds = collection4.map(utilities.mask457);
  var col5NoClouds = collection5.map(utilities.mask457);
  var col7NoClouds = collection7.map(utilities.mask457);
  var col8NoClouds = collection8.map(utilities.mask8);
  var colNoClouds = col4NoClouds
                      .merge(col5NoClouds)
                      .merge(col7NoClouds)
                      .merge(col8NoClouds);
  var colIndices = ee.ImageCollection(utilities.doIndices(colNoClouds));
  return colIndices;
};
var getMODISVI = function(region, params) {
  // Get MODIS time series for a given location
  var collection = ee.ImageCollection('MODIS/006/MOD13Q1')
      .filterBounds(region).filterDate(params.get('start'), params.get('end'));
  var modisNOClouds = collection.map(utilities.maskMOD13Q1);
  return modisNOClouds;
};
var getMODISLC = function(region) {
  // Get MODIS Land Cover for a given location
  var collection =  ee.ImageCollection('MODIS/006/MCD12Q1').filterBounds(region);
  var modisSelect = collection.map(utilities.selectMOD12Q1);
  return modisSelect;
};
var plotMODIS = function(iCol, region, bandName, ymin, ymax) {
  // Make time series plot from image collection
  var chart = ui.Chart.image.series(ee.ImageCollection(iCol).select(bandName), region, ee.Reducer.mean(), 30)
                .setOptions({
                  title: 'MODIS ' + bandName,
                  vAxis: {title: bandName, viewWindow: {min: ymin, max: ymax}},
                  lineWidth: 0,
                  pointSize: 4,
                 });
  tsPanel.add(chart); 
};
var plotLandsat = function(iCol, region, bandName, ymin, ymax) {
  // Make time series plot from image collection
  var chart = ui.Chart.image.series(ee.ImageCollection(iCol).select(bandName), region, ee.Reducer.mean(), 30)
                .setOptions({
                  title: 'Landsat ' + bandName,
                  vAxis: {title: bandName, viewWindow: {min: ymin, max: ymax}},
                  lineWidth: 0,
                  pointSize: 4,
                 });
  chart.onClick(
    function(date) {
      if (date === null) {
        removeLayer('_L.0._');
      } else {
        getLandsatImage(region, date);
      }
      reloadSamples();
    }
  );
  tsPanel.add(chart); 
};
var moveToPixel = function(SU) {
  if (SU > maxSU) {
    print('Last sample unit reached.');
  } else if (SU < 0) {
    print('First sample unit reached');
  } else {
    var samplePixel = samples.filterMetadata(sampleID, 'equals', SU);
    Map.centerObject(samplePixel, 15);
    currentSU = SU;
    messager.setValue('Sample unit: ' + SU);
  }
};
var addPixel = function(coords, pixelSize, color, name) {
  var pixel = ee.Geometry.Rectangle([coords.lon-pixelSize, coords.lat-pixelSize, 
                                      coords.lon+pixelSize, coords.lat+pixelSize]);
  Map.addLayer(pixel, {color: color}, name);
};
var removeLayer = function(name) {
  var layers = Map.layers();
  var nLayer = layers.length();
  for (var i = nLayer-1; i >= 0; i--) {
    var layer = layers.get(i);
    if (layer.getName().match(name)) {
      layers.remove(layer);
    }
  }
};
var reloadSamples = function() {
  removeLayer('Samples');
  Map.addLayer(samples, {color: 'FF0000'}, 'Samples');
};
var refreshEventList = function() {
  print('working');
};
// ---------------------------------------------------------------
// Initialization:
Map.setOptions('SATELLITE');
Map.style().set('cursor', 'crosshair');
Map.add(movePanel);
Map.add(inputPanel);
Map.add(messagerPanel);
//ui.root.add(recordPanel);
ui.root.add(tsPanel);
Map.addLayer(samples, {color: 'FF0000'}, 'Samples');
moveToPixel(currentSU);
// End