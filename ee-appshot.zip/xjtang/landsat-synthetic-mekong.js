// CHART Landsat Synthetic Image
// ---------------------------------------------------------------
// Imports and predefined variables:
var mekong = ee.FeatureCollection('users/xjtang/chart/area/mekong_boundary');
var ut = require('users/xjtang/ccdc:Utilities');
var ccdc = ee.ImageCollection('projects/CCDC/v2')
            .filterMetadata('system:index', 'starts_with', 'z')
            .filterBounds(mekong)
            .mosaic();
// ---------------------------------------------------------------
// Main functions:
var createSyntParam = function(date) {
  var synt = {};
  synt.red = 'SWIR1';
  synt.green = 'NIR';
  synt.blue = 'RED';
  synt.stretch = [0, 0.6];
  synt.nSeg = 10;
  synt.bands = [synt.red, synt.green, synt.blue];
  synt.date = date;
  return synt;
};
var createSynthetic = function(ccdc, synt) {
  var ccdcImg = ut.genCCDCImage(ccdc, synt.nSeg, synt.bands);
  var syntImg = ut.genMultiSyntImg(ccdcImg, synt.date, synt.bands, synt.nSeg);
  return(syntImg);
};
// ---------------------------------------------------------------
// Initialization:
var syntParam2001 = createSyntParam(2001.7);
var syntImg2001 = createSynthetic(ccdc, syntParam2001).clip(mekong);
Map.addLayer(syntImg2001, {bands: syntParam2001.bands, min: syntParam2001.stretch[0], 
              max: syntParam2001.stretch[1]}, 'Synthetic ' + syntParam2001.date);
var syntParam2016 = createSyntParam(2016.7);
var syntImg2016 = createSynthetic(ccdc, syntParam2016).clip(mekong);
Map.addLayer(syntImg2016, {bands: syntParam2001.bands, min: syntParam2001.stretch[0], 
              max: syntParam2001.stretch[1]}, 'Synthetic ' + syntParam2016.date);
Map.setCenter(103.834, 15.991, 5);
Map.setOptions('SATELLITE');
Map.style().set('cursor', 'crosshair');
//End