var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                68.67887260788147,
                5.294500849180299
              ],
              [
                82.21402885788147,
                4.418758812829938
              ],
              [
                101.19840385788147,
                4.068160625897758
              ],
              [
                111.92106010788147,
                10.170097727098177
              ],
              [
                108.58121635788147,
                38.29514941148791
              ],
              [
                61.99918510788147,
                37.60208621857304
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[68.67887260788147, 5.294500849180299],
          [82.21402885788147, 4.418758812829938],
          [101.19840385788147, 4.068160625897758],
          [111.92106010788147, 10.170097727098177],
          [108.58121635788147, 38.29514941148791],
          [61.99918510788147, 37.60208621857304]]]);
// CHART Mekong Mapped Area Stats
// ---------------------------------------------------------------
// Imports and predefined variables:
var lc_2001 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2001");
var lc_2002 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2002");
var lc_2003 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2003");
var lc_2004 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2004");
var lc_2005 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2005");
var lc_2006 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2006");
var lc_2007 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2007");
var lc_2008 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2008");
var lc_2009 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2009");
var lc_2010 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2010");
var lc_2011 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2011");
var lc_2012 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2012");
var lc_2013 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2013");
var lc_2014 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2014");
var lc_2015 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2015");
var lc_2016 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2016");
var region = 'mekong';
var fromClass = [2,4,5];
var toClass = [12];
// ---------------------------------------------------------------
// Main functions:
var getChange = function(map1, map2, class1, class2) { 
  return inList(map1, class1)
          .and(inList(map2, class2))
          .reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: geometry,
    maxPixels: 500000000,
    tileScale: 8
  });
};
var inList = function(img, values) {
  return ee.ImageCollection(values.map(function(x){return img.eq(ee.Number(x))}))
          .toBands().reduce('sum');
};
var stringToList = function(x) {
  return ee.String(x).split(',').map(ee.Number.parse);
};
// ---------------------------------------------------------------
// UIs:
var regionSelect = ui.Select(['mekong','krishna','all'], 'Select a region');
var regionSet = ui.Panel([regionSelect], ui.Panel.Layout.Flow('horizontal'));
var loadButton = ui.Button({label: 'Load', disabled: true});
var loadPanel = ui.Panel({
  widgets: [ui.Label('Calculate Mapped Area of Change'), 
            regionSet, loadButton],
  style: {width: '220px'}
});
var fromBox = ui.Textbox({placeholder: 'From', 
                        value: '2,4,5',
                        style: {stretch: 'horizontal'}});
var fromSet = ui.Panel([ui.Label('From:'), fromBox], 
                      ui.Panel.Layout.Flow('horizontal'));
var toBox = ui.Textbox({placeholder: 'To',
                          value: '12',
                          style: {stretch: 'horizontal'}});
var toSet = ui.Panel([ui.Label('To:'), toBox], 
                      ui.Panel.Layout.Flow('horizontal'));
var runButton = ui.Button('Run');
var runPanel = ui.Panel({
  widgets: [ui.Label('Calculate Mapped Area of Change'), 
            fromSet, toSet, runButton],
  style: {width: '220px'}
});
var resultPanel = ui.Panel({widgets: [], style: {width: '220px'}});
// ---------------------------------------------------------------
// Runtime Functions:
fromBox.onChange(function(text){
  fromClass = stringToList(text);
});
toBox.onChange(function(text){
  toClass = stringToList(text);
});
regionSelect.onChange(function(text){
  region = text;
  loadButton.setDisabled(false);
});
loadButton.onClick(function(button){
  lc_2001 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2001");
  lc_2002 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2002");
  lc_2003 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2003");
  lc_2004 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2004");
  lc_2005 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2005");
  lc_2006 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2006");
  lc_2007 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2007");
  lc_2008 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2008");
  lc_2009 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2009");
  lc_2010 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2010");
  lc_2011 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2011");
  lc_2012 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2012");
  lc_2013 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2013");
  lc_2014 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2014");
  lc_2015 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2015");
  lc_2016 = ee.Image("users/xjtang/chart/annual/" + region + "/lc_2016");
  var change = ee.Image('users/xjtang/chart/modis/strata_' + region);
  Map.addLayer(change, stVis, '2003-2014 Change');
  ui.root.remove(loadPanel);
  ui.root.add(runPanel);
  ui.root.add(resultPanel);
});
runButton.onClick(function(button){ 
  resultPanel.clear();
  resultPanel.add(ui.Label('2001 Change: ' + getChange(lc_2001, lc_2002, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2002 Change: ' + getChange(lc_2002, lc_2003, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2003 Change: ' + getChange(lc_2003, lc_2004, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2004 Change: ' + getChange(lc_2004, lc_2005, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2005 Change: ' + getChange(lc_2005, lc_2006, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2006 Change: ' + getChange(lc_2006, lc_2007, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2007 Change: ' + getChange(lc_2007, lc_2008, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2008 Change: ' + getChange(lc_2008, lc_2009, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2009 Change: ' + getChange(lc_2009, lc_2010, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2010 Change: ' + getChange(lc_2010, lc_2011, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2011 Change: ' + getChange(lc_2011, lc_2012, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2012 Change: ' + getChange(lc_2012, lc_2013, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2013 Change: ' + getChange(lc_2013, lc_2014, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2014 Change: ' + getChange(lc_2014, lc_2015, fromClass, toClass).get('sum').getInfo()));
  resultPanel.add(ui.Label('2015 Change: ' + getChange(lc_2015, lc_2016, fromClass, toClass).get('sum').getInfo()));
});
// ---------------------------------------------------------------
// Initialization:
Map.setCenter(103.834, 15.991, 5);
Map.setOptions('SATELLITE');
ui.root.add(loadPanel);
Map.style().set('cursor', 'crosshair');
var stPal = '000000, 1E942E, F279F2, 98B611, 88F58A, D1A4F6, F67965, CFCCB7, 2A43F7, 2AF7D8, F7CC2A, F7CC2A, F7CC2A, F7CC2A, F7CC2A, F7CC2A';
var stVis = {"max":15, "min":0, 'palette': stPal};
// End