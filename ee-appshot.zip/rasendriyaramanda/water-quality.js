//-------------------------------------------------------------------------------
// Pallete
var rgbVis = {
  min: 0.0,
  max: 0.3,
  gamma: 1.2,
  bands: ['B4', 'B3', 'B2'],
};
var vizTSS = {
  min: 0,
  max: 10,
  palette: ['white', 'lightblue', 'green', 'yellow', 'red'],
};
var styleParams = {
  fillColor: 'b5ffb4',
  color: '00909F',
  width: 1.0,
};
//-------------------------------------------------------------------------------
// Batas Wilayah
// Menggunakan Gaul
var dataset_prov = ee.FeatureCollection('FAO/GAUL_SIMPLIFIED_500m/2015/level1');
// Filter untuk DKI Jakarta
var provinsi = dataset_prov.filter(ee.Filter.eq('ADM1_NAME', 'Dki Jakarta'));
Map.addLayer(provinsi, {color: 'purple'}, 'Provinsi');
// Menampilkan di peta
Map.centerObject(provinsi);
// Center Map
Map.centerObject(provinsi);
//-------------------------------------------------------------------------------
// Citra Satelit Sentinel-2 
var s2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
  .filter(ee.Filter.date('2023-08-30', '2023-09-30'));
// Ekstrak Proyeksi
var s2Projection = ee.Image(s2.first()).select('B4', 'B3', 'B2').projection();
// Apply Scale Factor
// Pixel values to reflectances
var scaleBands = function(image) {
  return image.multiply(0.0001).copyProperties(image, ['system:time_start']);
};
// Use Cloud Score+ cloud mask
var csPlus = ee.ImageCollection('GOOGLE/CLOUD_SCORE_PLUS/V1/S2_HARMONIZED');
var csPlusBands = csPlus.first().bandNames();
// Function to mask pixels with low CS+ QA scores.
function maskLowQA(image) {
  var qaBand = 'cs';
  var clearThreshold = 0.5;
  var mask = image.select(qaBand).gte(clearThreshold);
  return image.updateMask(mask);
}
// Need to add Cloud Score+ bands to each Sentinel-2
var filteredS2WithCs = s2.linkCollection(csPlus, csPlusBands);
// Order in which the functions are applied is important
var s2Processed = filteredS2WithCs
  .map(maskLowQA)
  .select('B.*')
  .map(scaleBands);
// Create the S2 composite
var image = s2Processed.median().setDefaultProjection(s2Projection);
Map.addLayer(image, rgbVis, 'Sentinel-2 Composite');
//-------------------------------------------------------------------------------
// Ekstrak CSV
var table = ee.FeatureCollection('projects/ee-rasendriyaramanda/assets/validasi');
// Mengambil nilai TSS dari citra berdasarkan titik koordinat
var getTSSValue = function(feature, formula) {
  var point = feature.geometry();
  // Mendefinisikan formula yang akan dimasukkan
  var tssCitra = image.expression(formula, {
    'B2': image.select('B2'),
    'B3': image.select('B3'),
    'B4': image.select('B4'),
    'B5': image.select('B5')
  }).rename('TSS_citra'); 
  // Sample citra pada titik koordinat
  var tssCitra2 = tssCitra.sample(point, 30).first();
  // Mengambil band pada masing-masing feature
  return feature.set({
    'TSS_citra': tssCitra2.get('TSS_citra'),
    'TSS': feature.get('TSS')  
  });
};
// Fungsi untuk menghitung RMSE
var calculateRMSE = function(feature) {
  var tssCitra = feature.get('TSS_citra');
  var tssAktual = feature.get('TSS');
  // Memastikan tidak ada nilai null
  tssCitra = ee.Algorithms.If(ee.Algorithms.IsEqual(tssCitra, null), 0, tssCitra);
  tssAktual = ee.Algorithms.If(ee.Algorithms.IsEqual(tssAktual, null), 0, tssAktual);
  // Rumus (y-x)^2
  var error = ee.Number(tssCitra).subtract(ee.Number(tssAktual));
  var squaredError = error.multiply(error);
  return feature.set({
    'squared_error': squaredError
  });
};
// Menghitung RMSE
var computeRMSE = function(tableWithSquaredError) {
  var meanSquaredError = tableWithSquaredError.aggregate_mean('squared_error');
  var rmse = ee.Number(meanSquaredError).sqrt();
  return rmse;
};
// Input Rumus
var formulaLabel = ui.Label('Masukkan rumus TSS :');
var formulaInput = ui.Textbox({
  placeholder: 'Masukkan rumus',
  onChange: function(formula) {
    // Menjalankan rumus pada kedua nilai TSS
    var tableWithTSS = table.map(function(feature) {
      return getTSSValue(feature, formula);
    });
    // (y-x)^2
    var tableWithSquaredError = tableWithTSS.map(calculateRMSE);
    // RMSE
    var rmse = computeRMSE(tableWithSquaredError);
    // Menampilkan RMSE
    rmseLabel.setValue('RMSE: ' + rmse.format('%.4f').getInfo());
    console.log('RMSE:', rmse.getInfo());
    // Export table
    Export.table.toDrive({
      collection: tableWithSquaredError,
      description: 'TSS_Squared_Error_Export',
      fileFormat: 'CSV',
      folder: 'EarthEngine_Exports'
    });
    // Menambahkan Layer TSS Rumus ke peta
    var tssImage = image.expression(formula, {
      'B2': image.select('B2'),
      'B3': image.select('B3'),
      'B4': image.select('B4'),
      'B5': image.select('B5')
    }).rename('TSS_citra');
    var layerName = formulaInput.getValue()
    Map.addLayer(tssImage, vizTSS, 'Rumus TSS' + ' : ' + layerName);
  }
});
// Label RMSE
var rmseLabel = ui.Label('RMSE :');
// Layout 
var panel = ui.Panel({
  widgets: [
    formulaLabel,
    formulaInput,
    rmseLabel
  ],
  style: {
    position: 'top-right',
    width: '300px',
    padding: '10px',
  }
});
Map.add(panel);