var table = ee.FeatureCollection("users/Scarlettlee33/AWATer/awater_glob"),
    geometry = /* color: #d63000 */ee.Geometry.Point([90.39416237659162, 30.601258424884723]);
Map.centerObject(geometry,6)
Map.addLayer(table.filterBounds(geometry))