var JRC_water = ui.import && ui.import("JRC_water", "image", {
      "id": "JRC/GSW1_3/GlobalSurfaceWater"
    }) || ee.Image("JRC/GSW1_3/GlobalSurfaceWater"),
    JRC_monthly = ui.import && ui.import("JRC_monthly", "imageCollection", {
      "id": "JRC/GSW1_3/MonthlyHistory"
    }) || ee.ImageCollection("JRC/GSW1_3/MonthlyHistory"),
    JRC_yearly = ui.import && ui.import("JRC_yearly", "imageCollection", {
      "id": "JRC/GSW1_3/YearlyHistory"
    }) || ee.ImageCollection("JRC/GSW1_3/YearlyHistory"),
    WorldCover = ui.import && ui.import("WorldCover", "imageCollection", {
      "id": "ESA/WorldCover/v100"
    }) || ee.ImageCollection("ESA/WorldCover/v100"),
    esri_lulc2020 = ui.import && ui.import("esri_lulc2020", "imageCollection", {
      "id": "projects/sat-io/open-datasets/landcover/ESRI_Global-LULC_10m"
    }) || ee.ImageCollection("projects/sat-io/open-datasets/landcover/ESRI_Global-LULC_10m"),
    WorldPop = ui.import && ui.import("WorldPop", "imageCollection", {
      "id": "WorldPop/GP/100m/pop"
    }) || ee.ImageCollection("WorldPop/GP/100m/pop"),
    HRSL = ui.import && ui.import("HRSL", "imageCollection", {
      "id": "projects/sat-io/open-datasets/hrsl/hrslpop"
    }) || ee.ImageCollection("projects/sat-io/open-datasets/hrsl/hrslpop"),
    GAUL = ui.import && ui.import("GAUL", "table", {
      "id": "FAO/GAUL_SIMPLIFIED_500m/2015/level0"
    }) || ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level0"),
    country = ui.import && ui.import("country", "table", {
      "id": "users/arjenhaag/BangladeshErosion/Bangladesh_coast_buffered"
    }) || ee.FeatureCollection("users/arjenhaag/BangladeshErosion/Bangladesh_coast_buffered"),
    rivers_test = ui.import && ui.import("rivers_test", "table", {
      "id": "users/kymoslager/river_buf"
    }) || ee.FeatureCollection("users/kymoslager/river_buf"),
    polders_old = ui.import && ui.import("polders_old", "table", {
      "id": "users/kymoslager/polders_embank"
    }) || ee.FeatureCollection("users/kymoslager/polders_embank"),
    polders = ui.import && ui.import("polders", "table", {
      "id": "users/arjenhaag/BangladeshErosion/Polderspoly_ori_3857"
    }) || ee.FeatureCollection("users/arjenhaag/BangladeshErosion/Polderspoly_ori_3857"),
    polders_new = ui.import && ui.import("polders_new", "table", {
      "id": "users/arjenhaag/BangladeshErosion/Polderspoly_2021_3857"
    }) || ee.FeatureCollection("users/arjenhaag/BangladeshErosion/Polderspoly_2021_3857"),
    polders_line = ui.import && ui.import("polders_line", "table", {
      "id": "users/arjenhaag/BangladeshErosion/Poldersline_ori_3857"
    }) || ee.FeatureCollection("users/arjenhaag/BangladeshErosion/Poldersline_ori_3857"),
    polders_line_new = ui.import && ui.import("polders_line_new", "table", {
      "id": "users/arjenhaag/BangladeshErosion/Poldersline_2021_3857"
    }) || ee.FeatureCollection("users/arjenhaag/BangladeshErosion/Poldersline_2021_3857"),
    eroded_embankments = ui.import && ui.import("eroded_embankments", "table", {
      "id": "users/arjenhaag/BangladeshErosion/eroded_embank"
    }) || ee.FeatureCollection("users/arjenhaag/BangladeshErosion/eroded_embank"),
    split_embankments = ui.import && ui.import("split_embankments", "table", {
      "id": "users/arjenhaag/BangladeshErosion/split_embank_1"
    }) || ee.FeatureCollection("users/arjenhaag/BangladeshErosion/split_embank_1"),
    ferry_terminals = ui.import && ui.import("ferry_terminals", "table", {
      "id": "users/arjenhaag/BangladeshErosion/ferry_terminals"
    }) || ee.FeatureCollection("users/arjenhaag/BangladeshErosion/ferry_terminals"),
    biwta_ghats = ui.import && ui.import("biwta_ghats", "table", {
      "id": "users/arjenhaag/BangladeshErosion/biwta_ghats"
    }) || ee.FeatureCollection("users/arjenhaag/BangladeshErosion/biwta_ghats"),
    transition_1988_2020 = ui.import && ui.import("transition_1988_2020", "image", {
      "id": "users/arjenhaag/BangladeshErosion/transition_1988_2020"
    }) || ee.Image("users/arjenhaag/BangladeshErosion/transition_1988_2020");
// Bangladesh erosion/sedimentation monitor
// NOTES:
/*
- water boundaries as lines for certain periods (e.g. 10 years)?
- currently removing clicked item/info when period is changed, could also re-calculate for new period?
- dynamics OK, or change? (currently same weight perm.<->seas. as seas.<->land) include in analysis/charts?
- hydrologic year instead of calendar year? (1st of August used by Gena/Sanjay?) (Monsoon end May - end Sep / start Oct)
- export no data filling (makes app quite slow)?
  -> also check how data filling affects charts, etc. 
- cumulative erosion/sedimentation? total change (sedimentation-erosion)?
*/
// To-Do:
/*
- current country bounds has issue at southwestern delta, now cuts into India, fix!
- convert legend to function (would greatly reduce total lines of code)
*/
// ---------------------------------------------------------------------------------------------------- //
// Parameters
// ---------------------------------------------------------------------------------------------------- //
// defaults
var default_start_year  = 1988;
var default_end_year    = 2020;
// var default_start_month = 1;
// var default_end_month   = 12;
var default_start_year_current_polders = 1988;
var buffer_border = 10000;
var buffer_embankments = 200;
// UI
var fontSize_sub = '12px';
var selector_message = {
  // 'Polders (original)': 'Click on a (original) polder to query an analysis over the area within the polder.',
  // 'Polders (current)': 'Click on a (current) polder to query an analysis over the area within the polder and the embankment around it.',
  'Polders': "Click on a polder to query an analysis over the area within the original polder and the embankment around the current polder.\
              'Reduction of area' refers to the change in area when comparing the original to the current polders. 'Land -> Water' refers to area\
              that changed from being classified as land to water within the chosen time period (and vice versa). All values are shown in\
              hectares (ha).",
  'Point': '',
};
// landcover processing and visualization
var lc_remap_in = [10,20,30,40,50,60,70,80,90,95,100];
var lc_remap_out = [1,2,3,4,5,6,7,8,9,10,11];
var lc_names  = ["Trees","Shrubland","Grassland","Cropland","Built-up","Barren / sparse vegetation","Snow and ice","Open water","Herbaceous wetland","Mangroves","Moss and lichen"];
var lc_colors = ["#006400","#ffbb22","#ffff4c","#f096ff","#fa0000","#b4b4b4","#f0f0f0","#0064c8","#0096a0","#00cf75","#fae6a0"];
// var lc_remap_in = [10,20,30,40,50,60,80,90];
// var lc_remap_out = [1,2,3,4,5,6,7,8];
// var lc_names  = ["Trees","Shrubland","Grassland","Cropland","Built-up","Barren / sparse vegetation","Open water","Herbaceous wetland"];
// var lc_colors = ["#006400","#ffbb22","#ffff4c","#f096ff","#fa0000","#b4b4b4","#0064c8","#0096a0"];
// population processing and visualization
var pop_thresh = 5;  // 10 used before
// chart visuals
var color_land       = 'brown';
var color_seas_water = 'blue';
var color_perm_water = 'purple';
var color_sediment   = '#109618';  // default Google chart green
var color_erosion    = '#3366CC';  // default Google chart blue 
// map visuals
var vals_erode_polder    = [0,2000,4000,6000,8000,10000];
// var vals_pcnt_erode_embank    = [0,20,40,60,80,100];
// var palette_pcnt_erode_embank = ['1a9850','91cf60','d9ef8b','fee08b','fc8d59','d73027'];
var vals_pcnt_erode_embank    = [10,30,50,70,90];
var palette_pcnt_erode_embank = ['1a9641','a6d96a','ffffbf','fdae61','d7191c'];
var visParams_mask_black = {min:0, max:1, palette:['white','black']};
var visParams_mask_white = {min:0, max:1, palette:['black','white']};
var visParams_monthly = {min:0, max:2, palette:['grey','white','blue']};
var visParams_yearly = {min:0, max:3, palette:['grey','white','lightblue','blue']};
var visParams_dynamics = {min:0, max:16, palette:['white','green','yellow','orange','red']};
var visParams_trans = {min:-2, max:3, palette:['green','white','white','white','blue','lightblue']};
var visParams_lc = {min:lc_remap_out[0], max:lc_remap_out[-1], palette:lc_colors};
var visParams_pop = {min:pop_thresh, max:100, palette:['#fff7ec','#fdbb84','#d7301f']};
// ---------------------------------------------------------------------------------------------------- //
// Processing
// ---------------------------------------------------------------------------------------------------- //
// align name property
// print(polders.first());
// print(polders_new.first());
polders = polders.select(['SNAME'], ['name']);
polders_new = polders_new.select(['SNAME'], ['name']);
// get country boundaries
// var country = GAUL.filter(ee.Filter.eq('ADM0_NAME', 'Bangladesh'));
// var other_countries = GAUL.filter(ee.Filter.eq('ADM0_NAME', 'Bangladesh').not());
// background layer
var background_bbox = ee.Geometry.Rectangle({coords:[60,0,120,40], geodesic:false});
var background_other = ee.Image.constant(0).clip(background_bbox.difference(country.geometry(), ee.ErrorMargin(100)));
var background = ee.Image.constant(0).clipToCollection(country);
// landcover
WorldCover = WorldCover.filterBounds(country.geometry().bounds());
WorldCover = WorldCover.mosaic().clip(country.geometry()).remap(lc_remap_in, lc_remap_out);
// population
WorldPop = WorldPop.filterBounds(country.geometry().bounds());
WorldPop = WorldPop.mosaic().clip(country.geometry());
HRSL = HRSL.filterBounds(country.geometry().bounds());
HRSL = HRSL.mosaic().clip(country.geometry());
// convert current polders to raster
var polders_raster = polders_new.map(function(f) {
  return f.set('pixelVal', ee.Number(1));
}).reduceToImage(['pixelVal'], ee.Reducer.first());
polders_raster = polders_raster.reproject({crs:JRC_yearly.first().projection().crs(), scale:30});
// prepare JRC data
// - fill in 'no data' -> commented out for now, for visualization speed in app
// - remove water within polders -> commented out for now, also removes actual erosion, added as separate map layer
var JRC_yearly_2_raw = JRC_yearly.filter(ee.Filter.gte('year', default_start_year))
                                 .filter(ee.Filter.lte('year', default_end_year));
var JRC_monthly_2_raw = JRC_monthly.filter(ee.Filter.gte('year', default_start_year))
                              .filter(ee.Filter.lte('year', default_end_year));
                              // .filter(ee.Filter.gte('month', default_start_month))
                              // .filter(ee.Filter.lte('month', default_end_month));
var JRC_yearly_2 = JRC_yearly.map(function(img) {
  // img = img.where(img.and(polders_raster), 1);  // remove water within polders -> commented out for now (see above)
  return img.updateMask(img);
});
// JRC_yearly_2 = JRC_yearly_2.map(function(img) {
//   var tmp_imgs = JRC_yearly_2.filter(ee.Filter.lte('year', img.get('year'))).sort('system:time_start');
//   var img_filled = tmp_imgs.reduce(ee.Reducer.lastNonNull()).rename('water');
//   return img_filled.copyProperties(img).copyProperties(img, ['system:index','system:time_start']);
//                   // .set('img_count', tmp_imgs.size());
// });
JRC_yearly_2 = JRC_yearly_2.filter(ee.Filter.gte('year', default_start_year));
// print(JRC_yearly_2.first());
// JRC_yearly_2 = JRC_yearly_2.map(function(img) {
//   return img.updateMask(img);
// });
var JRC_monthly_2 = JRC_monthly.map(function(img) {
  // img = img.where(img.and(polders_raster), 1);  // remove water within polders -> commented out for now (see above)
  return img.updateMask(img);
});
// JRC_monthly_2 = JRC_monthly_2.map(function(img) {
//   var tmp_imgs = JRC_monthly_2.filterDate('1984-01-01', img.date()).sort('system:time_start');
//   var img_filled = tmp_imgs.reduce(ee.Reducer.lastNonNull()).rename('water');
//   return img_filled.copyProperties(img).copyProperties(img, ['system:index','system:time_start']);
//                   // .set('img_count', tmp_imgs.size());
// });
JRC_monthly_2 = JRC_monthly_2.filter(ee.Filter.gte('year', default_start_year));
// print(JRC_monthly_2.first());
// JRC_monthly_2 = JRC_monthly_2.map(function(img) {
//   return img.updateMask(img);
// });
// ---------------------------------------------------------------------------------------------------- //
// Functions
// ---------------------------------------------------------------------------------------------------- //
function updateApp() {
  // clear map and UI
  // Map.clear();
  // clearLayers(['dynamics', 'situation start year', 'situation end year', 'transition']);
  charts.clear();
  analyser_name.setValue('');
  analyser_lost_total.setValue('');
  analyser_eroded.setValue('');
  analyser_sedimented.setValue('');
  // get time period
  var start_year = ee.Number(year_slider_1.getValue());
  var end_year = ee.Number(year_slider_2.getValue());
  var show_years_warning = ee.Algorithms.If(end_year.lte(start_year), true, false).getInfo();
  years_warning_box.style().set('shown', show_years_warning);
  // get time series
  var JRC_yearly_2_raw = JRC_yearly.filter(ee.Filter.gte('year', start_year))
                               .filter(ee.Filter.lte('year', end_year));
  var JRC_yearly_2_tmp = JRC_yearly_2.filter(ee.Filter.gte('year', start_year))
                               .filter(ee.Filter.lte('year', end_year));
  var JRC_monthly_2_raw = JRC_monthly.filter(ee.Filter.gte('year', start_year))
                                .filter(ee.Filter.lte('year', end_year));
                                // .filter(ee.Filter.gte('month', start_month))
                                // .filter(ee.Filter.lte('month', end_month));
  // var JRC_monthly_2 = JRC_monthly.map(function(img) {
  //   return img.updateMask(img);
  // });
  // JRC_monthly_2 = JRC_monthly_2.map(function(img) {
  //   var tmp_imgs = JRC_monthly_2.filterDate('1984-01-01', img.date()).sort('system:time_start');
  //   var img_filled = tmp_imgs.reduce(ee.Reducer.lastNonNull()).rename('water');
  //   return img_filled.copyProperties(img).copyProperties(img, ['system:index','system:time_start']);
  //                   // .set('img_count', tmp_imgs.size());
  // });
  // JRC_monthly_2 = JRC_monthly_2.filter(ee.Filter.gte('year', default_start_year));
  // // print(JRC_monthly_2.first());
  // JRC_monthly_2 = JRC_monthly_2.map(function(img) {
  //   return img.updateMask(img);
  // });
  var JRC_monthly_2_tmp = JRC_monthly_2.filter(ee.Filter.gte('year', start_year))
                                .filter(ee.Filter.lte('year', end_year));
                                // .filter(ee.Filter.gte('month', start_month))
                                // .filter(ee.Filter.lte('month', end_month));
  // get dynamics/variability
  var dynamics = calcDynamics(start_year, end_year);
  updateLayer(dynamics, 'dynamics', visParams_dynamics, false);
  // get transition
  // var transition = calcTransition(start_year, end_year);
  var transition_data = calcTransition(start_year, end_year);
  // var transition = ee.Image(transition_data.get('transition'));
  var transition = ee.Image(transition_data.select('transition'));
  // updateLayer(ee.Image(JRC_yearly_2_raw.filter(ee.Filter.eq('year', start_year)).first()), 'situation start year (JRC yearly, raw)', visParams_yearly, false);
  // updateLayer(ee.Image(JRC_yearly_2_raw.filter(ee.Filter.eq('year', end_year)).first()), 'situation end year (JRC yearly, raw)', visParams_yearly, false);
  // updateLayer(ee.Image(JRC_yearly_2_tmp.filter(ee.Filter.eq('year', start_year)).first()), 'situation start year (JRC yearly)', visParams_yearly, false);
  // updateLayer(ee.Image(JRC_yearly_2_tmp.filter(ee.Filter.eq('year', end_year)).first()), 'situation end year (JRC yearly)', visParams_yearly, false);
  // updateLayer(ee.Image(transition_data.get('start_data')), 'situation start year', visParams_monthly, false);
  // updateLayer(ee.Image(transition_data.get('end_data')), 'situation end year', visParams_monthly, false);
  updateLayer(ee.Image(transition_data.select('start_data')), 'situation start year', visParams_monthly, false);
  updateLayer(ee.Image(transition_data.select('end_data')), 'situation end year', visParams_monthly, false);
  updateLayer(transition_1988_2020.select('transition'), 'transition 1988-2020', visParams_trans, false);
  updateLayer(transition, 'transition', visParams_trans, true);
  // get classes
  var erosion  = transition.eq(2);
  var sediment = transition.eq(-2);
  var thesame  = transition.eq(0);
  var no_data  = transition.eq(-3).or(transition.eq(-1)).or(transition.eq(1)).or(transition.eq(3));
  // aggregate to polders
  var polders_withdata = aggregateToFeatures(polders, transition);
  var polders_new_withdata = aggregateToFeatures(polders_new, transition);
  // var polders_new_embankments_buffered_withdata = aggregateToFeatures(polders_new_embankments_buffered, transition);
  // aggregate to river segments
  // var rivers_withdata = aggregateToFeatures(rivers_test, transition);
  // merge features
  // polders_withdata = polders_withdata.map(function(f) {return f.set('feature_type', 'Polders')});
  // rivers_withdata = rivers_withdata.map(function(f) {return f.set('feature_type', 'River segments')});
  // var all_features = polders_withdata.merge(rivers_withdata);
  // map click functionality
  Map.unlisten();
  Map.onClick(function(coords) {
    // clear previously clicked layer
    clearLayer('clicked feature');
    // clear UI
    charts.clear();
    charts_loading_mssg.style().set('shown', true);
    analyser_name.setValue('');
    analyser_lost_total.setValue('');
    analyser_eroded.setValue('');
    analyser_sedimented.setValue('');
    // get clicked point
    var clicked_point = ee.Geometry.Point(coords.lon, coords.lat);
    // get clicked feature(s)
    var clicked_polder_1 = polders.filterBounds(clicked_point);
    var clicked_polder_2 = polders_new.filterBounds(clicked_point);
    var clicked_polder_3 = clicked_polder_1.merge(clicked_polder_2);
    var clicked_polder_name = clicked_polder_3.aggregate_histogram('name').keys().get(0);
    var clicked_polder = polders.filter(ee.Filter.eq('name', clicked_polder_name));
    // var clicked_polder = polders_withdata.filterBounds(clicked_point).first();
    Map.addLayer(clicked_polder, {}, 'clicked feature', true, 0.5);
    // var clicked_river = rivers_withdata.filterBounds(clicked_point).first();
    // print(clicked_polder);
    // print(clicked_river);
    // var to_be_clicked_features = all_features.filter(ee.Filter.eq('feature_type', analysis_selector.getValue()));
    // print(to_be_clicked_features);
    // var clicked_feature = to_be_clicked_features.filterBounds(clicked_point);
    // var clicked_feature = getClickedFeatureValues(polders_withdata, clicked_point);
    // var clicked_point = getClickedPointCharts(clicked_point, JRC_yearly_2_tmp, JRC_yearly_2_raw, JRC_monthly_2_tmp, JRC_monthly_2_raw);
    // if (analysis_selector.getValue() == 'Polders (original)') {
    //   getClickedFeatureValues(polders_withdata, clicked_point);
    //   getClickedFeatureCharts(polders_stats, clicked_point);
    // }
    // if (analysis_selector.getValue() == 'Polders (current)') {
    //   getClickedFeatureValues(polders_new_withdata, clicked_point);
    //   getClickedFeatureCharts(polders_new_stats, clicked_point);
    //   getClickedFeatureEmbankmentCharts(clicked_point);
    // }
    if (analysis_selector.getValue() == 'Polders') {
      getClickedFeatureValues(polders_withdata, clicked_point);
      getClickedFeatureCharts(polders_stats, clicked_point);
      getClickedFeatureEmbankmentCharts(clicked_point);
    }
    if (analysis_selector.getValue() == 'Point') {
      getClickedPointCharts(clicked_point, JRC_yearly_2_tmp, JRC_yearly_2_raw, JRC_monthly_2_tmp, JRC_monthly_2_raw);
    }
  });
}
function aggregateToFeatures(features, transition) {//, name) {
  // get classes
  var erosion  = transition.eq(2);
  var sediment = transition.eq(-2);
  var thesame  = transition.eq(0);
  var no_data  = transition.eq(-3).or(transition.eq(-1)).or(transition.eq(1)).or(transition.eq(3));
  // aggregate to features
  var features_withdata = features;
  function calcFeatures(img, prop_name) {
    var props = ee.Feature(features_withdata.first()).propertyNames();
    var props_old = props.add('sum');
    var props_new = props.add('sum_' + prop_name);
    var result = img.multiply(ee.Image.pixelArea()).reduceRegions(features_withdata, ee.Reducer.sum(), 30);
    return result.select(props_old, props_new);
  }
  features_withdata = calcFeatures(erosion, 'erosion');
  features_withdata = calcFeatures(sediment, 'sedimentation');
  features_withdata = calcFeatures(thesame, 'nochange');
  features_withdata = calcFeatures(no_data, 'nodata');
  // print(name, features_withdata.first());
  // print(name, features_withdata);
  // // Map.addLayer(ee.FeatureCollection(features_withdata), {}, name, true, 0.5);
  // // Map.addLayer(ee.FeatureCollection(features_withdata), {}, name + ' (with data)', false, 0.5);
  return features_withdata;
}
function getClickedFeatureValues(features, clicked_point) {
  // var clicked_feature = features.filterBounds(clicked_point);
  var clicked_polder_1 = polders.filterBounds(clicked_point);
  var clicked_polder_2 = polders_new.filterBounds(clicked_point);
  var clicked_polder_3 = clicked_polder_1.merge(clicked_polder_2);
  var clicked_polder_name = clicked_polder_3.aggregate_histogram('name').keys().get(0);
  var clicked_feature = features.filter(ee.Filter.eq('name', clicked_polder_name));
  // Map.addLayer(ee.Image().byte().paint(clicked_feature,0,2), {}, 'clicked feature', true);
  // Map.addLayer(clicked_feature, {}, 'clicked feature', true, 0.5);
  clicked_feature = clicked_feature.first();
  // print(clicked_feature);
  // get relevant values for display in app
  // var clicked_name = clicked_polder.get('SNAME');
  var clicked_name = clicked_feature.get('name');
  var clicked_erosion_total = ee.Number(polders_new.filter(ee.Filter.eq('name', clicked_polder_name)).first().get('eroded_total_area_ha'));
  var clicked_erosion_total_pcnt = clicked_erosion_total.divide(clicked_feature.geometry().area().divide(1e4)).multiply(100);
  clicked_erosion_total = clicked_erosion_total.format("%.0f").cat(' (').cat(clicked_erosion_total_pcnt.format("%.2f")).cat('%)');
  // var clicked_nodata = ee.Number(clicked_feature.get('sum_nodata'));
  // var clicked_nochange = ee.Number(clicked_feature.get('sum_nochange'));
  var clicked_erosion = ee.Number(clicked_feature.get('sum_erosion')).divide(10000).round();
  var clicked_sedimentation = ee.Number(clicked_feature.get('sum_sedimentation')).divide(10000).round();
  var eroded_pcnt = ee.Number(clicked_feature.get('sum_erosion')).divide(clicked_feature.geometry().area()).multiply(100);
  var sedimented_pcnt = ee.Number(clicked_feature.get('sum_sedimentation')).divide(clicked_feature.geometry().area()).multiply(100);
  clicked_erosion = clicked_erosion.format("%.0f").cat(' (').cat(eroded_pcnt.format("%.2f")).cat('%)');
  clicked_sedimentation = clicked_sedimentation.format("%.0f").cat(' (').cat(sedimented_pcnt.format("%.2f")).cat('%)');
  // display values in app
  clicked_name.evaluate(function(val, err) {
    analyser_name.setValue(val);
  });
  clicked_erosion_total.evaluate(function(val, err) {
    analyser_lost_total.setValue(val);
  });
  clicked_erosion.evaluate(function(val, err) {
    analyser_eroded.setValue(val);
  });
  clicked_sedimentation.evaluate(function(val, err) {
    analyser_sedimented.setValue(val);
  });
  return clicked_feature;
}
function getClickedFeatureCharts(features, clicked_point) {
  // var clicked_feature_timeseries = features.filterBounds(clicked_point).first();
  // var clicked_feature_name = clicked_feature_timeseries.get('name');
  var clicked_polder_1 = polders.filterBounds(clicked_point);
  var clicked_polder_2 = polders_new.filterBounds(clicked_point);
  var clicked_polder_3 = clicked_polder_1.merge(clicked_polder_2);
  var clicked_feature_name = clicked_polder_3.aggregate_histogram('name').keys().get(0);
  var clicked_feature_timeseries = features.filter(ee.Filter.eq('name', clicked_feature_name)).first();
  var clicked_feature_chart_yearly_JRC = ui.Chart.array.values(
    ee.Array.cat([
      clicked_feature_timeseries.get('yearly_land'),
      clicked_feature_timeseries.get('yearly_seas'),
      clicked_feature_timeseries.get('yearly_perm')
    ], 1),
    0,
    clicked_feature_timeseries.get('years_JRC'))
    .setSeriesNames(['land','seasonal water','permanent water'])
    .setOptions({
      title: 'Time series of land/water within clicked polder',
      vAxis: {title: 'Area (ha)'},
      series:{
        0: {lineWidth:2,pointSize:4},
        1: {lineWidth:2,pointSize:4},
        2: {lineWidth:2,pointSize:4}
      }
    });
  var clicked_feature_chart_yearly_transition = ui.Chart.array.values(
    ee.Array.cat([
      // clicked_feature_timeseries.get('yearly_nochange'),
      clicked_feature_timeseries.get('yearly_sedimentation'),
      clicked_feature_timeseries.get('yearly_erosion')
    ], 1),
    0,
    clicked_feature_timeseries.get('years_transition'))
    // .setSeriesNames(['no change','sedimentation','erosion'])
    .setSeriesNames(['sedimentation','erosion'])
    .setChartType('ColumnChart')
    .setOptions({
      title: 'Time series of sedimentation/erosion within clicked polder',
      vAxis: {title: 'Area (ha)'},
      bar: {groupWidth: '75%'}
      // series:{
      //   0: {lineWidth:2,pointSize:4},
      //   1: {lineWidth:2,pointSize:4},
      //   // 2: {lineWidth:2,pointSize:4}
      // }
    });
  // charts.add(clicked_feature_chart_yearly_JRC);
  // charts.add(clicked_feature_chart_yearly_transition);
  // instead of two separate charts, merge into a single (combo) chart
  // https://developers.google.com/chart/interactive/docs/gallery/combochart
  var clicked_feature_chart_combo = ui.Chart.array.values(
    // ee.Array.cat([
    //   ee.List(clicked_feature_timeseries.get('yearly_land')).slice(1, ee.List(clicked_feature_timeseries.get('years_transition')).length().add(1)),
    //   ee.List(clicked_feature_timeseries.get('yearly_seas')).slice(1, ee.List(clicked_feature_timeseries.get('years_transition')).length().add(1)),
    //   ee.List(clicked_feature_timeseries.get('yearly_perm')).slice(1, ee.List(clicked_feature_timeseries.get('years_transition')).length().add(1)),
    //   clicked_feature_timeseries.get('yearly_sedimentation'),
    //   clicked_feature_timeseries.get('yearly_erosion')
    // ], 1),
    // 0,
    // clicked_feature_timeseries.get('years_transition'))
    ee.Array.cat([
      clicked_feature_timeseries.get('yearly_land'),
      clicked_feature_timeseries.get('yearly_seas'),
      clicked_feature_timeseries.get('yearly_perm'),
      clicked_feature_timeseries.get('yearly_sedimentation'),
      clicked_feature_timeseries.get('yearly_erosion')
    ], 1),
    0,
    clicked_feature_timeseries.get('years_JRC'))
    .setSeriesNames(['land','seasonal water','permanent water','sedimentation','erosion'])
    .setChartType('ComboChart');
    // .setOptions({
    //   title: 'Time series within clicked polder',
    //   seriesType: 'bars',
    //   series: {
    //     0: {type:'line', targetAxisIndex:0},
    //     1: {type:'line', targetAxisIndex:0},
    //     2: {type:'line', targetAxisIndex:0},
    //     3: {targetAxisIndex:1},
    //     4: {targetAxisIndex:1}
    //   },
    //   vAxes: {
    //     0: {title:'Total area land/water (ha)'},
    //     1: {title:'Total area erosion/sedimentation (ha)'}
    //   }
    // });
  // charts.add(clicked_feature_chart_combo);
  clicked_feature_name.evaluate(function(val, err) {
    clicked_feature_chart_combo.setOptions({
      title: 'Time series within original ' + val,
      seriesType: 'bars',
      series: {
        0: {type:'line', color:color_land, targetAxisIndex:0},
        1: {type:'line', color:color_seas_water, targetAxisIndex:0},
        2: {type:'line', color:color_perm_water, targetAxisIndex:0},
        3: {color:color_sediment, targetAxisIndex:1},
        4: {color:color_erosion, targetAxisIndex:1}
      },
      vAxes: {
        0: {title:'Total area land/water (ha)'},
        1: {title:'Total area erosion/sedimentation (ha)'}
      }
    });
    charts_loading_mssg.style().set('shown', false);
    charts.add(clicked_feature_chart_combo);
  });
  return clicked_feature_timeseries;
}
function getClickedFeatureEmbankmentCharts(clicked_point) {
  // var clicked_polder = polders_new.filterBounds(clicked_point).first();
  // var clicked_polder_name = clicked_polder.get('name');
  var clicked_polder_1 = polders.filterBounds(clicked_point);
  var clicked_polder_2 = polders_new.filterBounds(clicked_point);
  var clicked_polder_3 = clicked_polder_1.merge(clicked_polder_2);
  var clicked_polder_name = clicked_polder_3.aggregate_histogram('name').keys().get(0);
  // var split_embankments_org = splitLine(ee.Feature(polders_line_new.filter(ee.Filter.eq('SNAME', clicked_polder_name)).first()));
  // print(polders_line_new.filter(ee.Filter.eq('SNAME', clicked_polder_name)).first());
  // Map.addLayer(split_embankments_org);
  var clicked_embankment = polders_new_embankments_buffered_stats.filter(ee.Filter.eq('SNAME', clicked_polder_name)).first();
  // var clicked_feature_chart_yearly_JRC = ui.Chart.array.values(
  //   ee.Array.cat([
  //     clicked_embankment.get('yearly_land'),
  //     clicked_embankment.get('yearly_seas'),
  //     clicked_embankment.get('yearly_perm')
  //   ], 1),
  //   0,
  //   clicked_embankment.get('years_JRC'))
  //   .setSeriesNames(['land','seasonal water','permanent water'])
  //   .setOptions({
  //     title: 'Time series of land/water near embankment around clicked polder (buffer of ' + buffer_embankments + 'm)',
  //     vAxis: {title: 'Area (ha)'},
  //     series:{
  //       0: {lineWidth:2,pointSize:4},
  //       1: {lineWidth:2,pointSize:4},
  //       2: {lineWidth:2,pointSize:4}
  //     }
  //   });
  // var clicked_feature_chart_yearly_transition = ui.Chart.array.values(
  //   ee.Array.cat([
  //     // clicked_embankment.get('yearly_nochange'),
  //     clicked_embankment.get('yearly_sedimentation'),
  //     clicked_embankment.get('yearly_erosion')
  //   ], 1),
  //   0,
  //   clicked_embankment.get('years_transition'))
  //   // .setSeriesNames(['no change','sedimentation','erosion'])
  //   .setSeriesNames(['sedimentation','erosion'])
  //   .setChartType('ColumnChart')
  //   .setOptions({
  //     title: 'Time series of sedimentation/erosion near embankment around clicked polder (buffer of ' + buffer_embankments + 'm)',
  //     vAxis: {title: 'Area (ha)'},
  //     bar: {groupWidth: '75%'}
  //     // series:{
  //     //   0: {lineWidth:2,pointSize:4},
  //     //   1: {lineWidth:2,pointSize:4},
  //     //   // 2: {lineWidth:2,pointSize:4}
  //     // }
  //   });
  // charts.add(clicked_feature_chart_yearly_JRC);
  // charts.add(clicked_feature_chart_yearly_transition);
  // instead of two separate charts, merge into a single (combo) chart
  // https://developers.google.com/chart/interactive/docs/gallery/combochart
  var clicked_feature_chart_combo = ui.Chart.array.values(
    // ee.Array.cat([
    //   ee.List(clicked_embankment.get('yearly_land')).slice(1, ee.List(clicked_embankment.get('years_transition')).length().add(1)),
    //   ee.List(clicked_embankment.get('yearly_seas')).slice(1, ee.List(clicked_embankment.get('years_transition')).length().add(1)),
    //   ee.List(clicked_embankment.get('yearly_perm')).slice(1, ee.List(clicked_embankment.get('years_transition')).length().add(1)),
    //   clicked_embankment.get('yearly_sedimentation'),
    //   clicked_embankment.get('yearly_erosion')
    // ], 1),
    // 0,
    // clicked_embankment.get('years_transition'))
    ee.Array.cat([
      clicked_embankment.get('yearly_land'),
      clicked_embankment.get('yearly_seas'),
      clicked_embankment.get('yearly_perm'),
      clicked_embankment.get('yearly_sedimentation'),
      clicked_embankment.get('yearly_erosion')
    ], 1),
    0,
    clicked_embankment.get('years_JRC'))
    .setSeriesNames(['land','seasonal water','permanent water','sedimentation','erosion'])
    .setChartType('ComboChart');
    // .setOptions({
    //   title: 'Time series near current embankment around clicked polder (within buffer of ' + buffer_embankments + 'm)',
    //   seriesType: 'bars',
    //   series: {
    //     0: {type:'line', targetAxisIndex:0},
    //     1: {type:'line', targetAxisIndex:0},
    //     2: {type:'line', targetAxisIndex:0},
    //     3: {targetAxisIndex:1},
    //     4: {targetAxisIndex:1}
    //   },
    //   vAxes: {
    //     0: {title:'Total area land/water (ha)'},
    //     1: {title:'Total area erosion/sedimentation (ha)'}
    //   }
    // });
  // charts.add(clicked_feature_chart_combo);
  clicked_polder_name.evaluate(function(val, err) {
    clicked_feature_chart_combo.setOptions({
      title: 'Time series near current embankment around ' + val + ' (within buffer of ' + buffer_embankments + 'm)',
      seriesType: 'bars',
      series: {
        0: {type:'line', color:color_land, targetAxisIndex:0},
        1: {type:'line', color:color_seas_water, targetAxisIndex:0},
        2: {type:'line', color:color_perm_water, targetAxisIndex:0},
        3: {color:color_sediment, targetAxisIndex:1},
        4: {color:color_erosion, targetAxisIndex:1}
      },
      vAxes: {
        0: {title:'Total area land/water (ha)'},
        1: {title:'Total area erosion/sedimentation (ha)'}
      }
    });
    charts_loading_mssg.style().set('shown', false);
    charts.add(clicked_feature_chart_combo);
  });
  return clicked_embankment;
}
function getClickedPointCharts(clicked_point, JRC_yearly_2_tmp, JRC_yearly_2_raw, JRC_monthly_2_tmp, JRC_monthly_2_raw) {
  // Map.addLayer(clicked_point);
  // get time series at clicked point
  var point_chart = getPointChart(JRC_yearly_2_tmp, clicked_point, 'Yearly water classification at clicked point');
  var point_chart_raw = getPointChart(JRC_yearly_2_raw, clicked_point, 'Yearly water classification (raw) at clicked point');
  var point_chart_2 = getPointChart(JRC_monthly_2_tmp, clicked_point, 'Monthly water classification at clicked point', [{v:0, f:'no data'}, {v:1, f:'land'}, {v:2, f:'water'}]);
  var point_chart_2_raw = getPointChart(JRC_monthly_2_raw, clicked_point, 'Monthly water classification (raw) at clicked point', [{v:0, f:'no data'}, {v:1, f:'land'}, {v:2, f:'water'}]);
  // var point_chart_transition = getPointChart(transition_yearly, clicked_point, 'Yearly erosion/sedimentation at clicked point');  // UPDATE!
  // display charts in app
  charts_loading_mssg.style().set('shown', false);
  charts.add(point_chart);
  // charts.add(point_chart_raw);
  charts.add(point_chart_2);
  // charts.add(point_chart_2_raw);
  // charts.add(point_chart_transition);
  return clicked_point;
}
function calcDynamics(start_year, end_year, start_month, end_month) {
  // defaults
  if (typeof start_month == 'undefined') start_month = 1;
  if (typeof end_month == 'undefined') end_month = 12;
  // filter dates
  // var JRC_monthly_2 = JRC_monthly.filter(ee.Filter.gte('year', start_year))
  //                               .filter(ee.Filter.lte('year', end_year))
  //                               .filter(ee.Filter.gte('month', start_month))
  //                               .filter(ee.Filter.lte('month', end_month));
  // var JRC_yearly_2 = JRC_yearly.filter(ee.Filter.gte('year', start_year))
  //                             .filter(ee.Filter.lte('year', end_year));
  // remove zeros?
  // JRC_monthly_2 = JRC_monthly_2.map(function(img) {
  //   return img.updateMask(img);
  // });
  // JRC_yearly_2 = JRC_yearly_2.map(function(img) {
  //   return img.updateMask(img);
  // });
  // var JRC_yearly_shifted = JRC_yearly_2.map(function(img) {
  //   var curr_year = img.get('year');
  //   var 
  // });
  var years = ee.List.sequence(ee.Number(start_year).add(1), end_year);
  var dynamics = ee.ImageCollection(years.map(function(i) {
    var temp_year = ee.Number(i);
    var data_year = ee.Image(JRC_yearly.filter(ee.Filter.eq('year', temp_year)).first());
    // var data_prev = ee.Image(JRC_yearly.filter(ee.Filter.lt('year', temp_year)).sort('year', false).first());
    var data_prevs = JRC_yearly.filter(ee.Filter.lt('year', temp_year))
                               .map(function(img) {return img.updateMask(img)})
                               .sort('year', false);
    var data_prev = ee.Image(data_prevs.first());
    data_year = data_year.updateMask(data_year);
    data_prev = data_prev.updateMask(data_prev);
    data_prev = data_prev.unmask(data_prevs.reduce(ee.Reducer.firstNonNull()));
    return data_year.subtract(data_prev).abs().copyProperties(data_year).copyProperties(data_year, ['system:time_start', 'system:index', 'system:footprint']);
  }));
  var data_start = ee.Image(JRC_yearly.filter(ee.Filter.eq('year', start_year)).first());
  data_start = data_start.subtract(data_start).copyProperties(data_start).copyProperties(data_start, ['system:time_start', 'system:index', 'system:footprint']);
  dynamics = dynamics.merge(ee.ImageCollection([data_start])).sort('year');
  // print(dynamics);
  dynamics = dynamics.sum();
  dynamics = dynamics.updateMask(dynamics);
  dynamics = dynamics.clipToCollection(country);
  var visParams_dynamics_max = years.length().divide(1.5).round();
  // print(visParams_dynamics_max);
  // visParams_dynamics_max.evaluate(function(val, err) {
  //   visParams_dynamics.max = val;
  // });
  visParams_dynamics.max = visParams_dynamics_max.getInfo();
  // print(visParams_dynamics);
  // Map.addLayer(dynamics, visParams_dynamics, 'dynamics', false);
  // updateLayer(dynamics, 'dynamics', visParams_dynamics, false);
  return dynamics;
}
function calcTransition(start_year, end_year, start_month, end_month) {
  // defaults
  if (typeof start_month == 'undefined') start_month = 1;
  if (typeof end_month == 'undefined') end_month = 12;
  // filter dates
  // var JRC_monthly_2 = JRC_monthly.filter(ee.Filter.gte('year', start_year))
  //                               .filter(ee.Filter.lte('year', end_year))
  //                               .filter(ee.Filter.gte('month', start_month))
  //                               .filter(ee.Filter.lte('month', end_month));
  // var JRC_yearly_2 = JRC_yearly.filter(ee.Filter.gte('year', start_year))
  //                             .filter(ee.Filter.lte('year', end_year));
  // // remove zeros?
  // JRC_monthly_2 = JRC_monthly_2.map(function(img) {
  //   return img.updateMask(img);
  // });
  // // make our own transition layer
  // // var start_data = ee.Image(JRC_monthly_2.filter(ee.Filter.eq('year', start_year)).filter(ee.Filter.eq('month', start_month)).first());
  // // var end_data = ee.Image(JRC_monthly_2.filter(ee.Filter.eq('year', end_year)).filter(ee.Filter.eq('month', end_month)).first());
  // var start_data = JRC_monthly_2.filter(ee.Filter.eq('year', start_year)).mode();
  // var end_data = JRC_monthly_2.filter(ee.Filter.eq('year', end_year)).mode();
  // var JRC_monthly_2 = JRC_monthly.map(function(img) {
  //   return img.updateMask(img);
  // });
  // JRC_monthly_2 = JRC_monthly_2.map(function(img) {
  //   var tmp_imgs = JRC_monthly_2.filterDate('1984-01-01', img.date()).sort('system:time_start');
  //   var img_filled = tmp_imgs.reduce(ee.Reducer.lastNonNull());
  //   return img_filled.copyProperties(img).copyProperties(img, ['system:index','system:time_start']);
  //                   // .set('img_count', tmp_imgs.size());
  // });
  // JRC_monthly_2 = JRC_monthly_2.filter(ee.Filter.gte('year', default_start_year));
  // // print(JRC_monthly_2.first());
  // JRC_monthly_2 = JRC_monthly_2.map(function(img) {
  //   return img.updateMask(img);
  // });
  var start_data = JRC_monthly_2.filter(ee.Filter.eq('year', start_year)).mode();
  var end_data = JRC_monthly_2.filter(ee.Filter.eq('year', end_year)).mode();
  // print(start_data);
  // Map.addLayer(start_data, visParams_monthly, 'situation start year', false);
  // Map.addLayer(end_data, visParams_monthly, 'situation end year', false);
  // unmask for remap
  var start_data_calc = start_data.unmask(0);
  var end_data_calc = end_data.unmask(0);
  // update mask for visualization
  // start_data = start_data.updateMask(start_data.neq(1));
  // end_data = end_data.updateMask(end_data.neq(1));
  // Map.addLayer(start_data, visParams_monthly, 'situation start year', false);
  // Map.addLayer(end_data, visParams_monthly, 'situation end year', false);
  // updateLayer(start_data, 'situation start year', visParams_monthly, false);
  // updateLayer(end_data, 'situation end year', visParams_monthly, false);
  // remap (so different classes can be easily distinguished after calculation)
  // nodata = 0, land = 1, water = 3
  start_data_calc = start_data_calc.remap([0,1,2], [0,1,3]);
  end_data_calc = end_data_calc.remap([0,1,2], [0,1,3]);
  // erosion = 2, sedimentation = -2, no change = 0, no data = other (-3, -1, 1 or 3)
  var transition = end_data_calc.subtract(start_data_calc);
  // add end water
  // erosion = 2, sedimentation = -2, no change = 0, end water = 3, no data = other (-3, -1, or 1)
  transition = transition.where(transition.eq(0).multiply(end_data_calc.eq(3)), end_data_calc);
  transition = transition.updateMask(transition.neq(0));
  transition = transition.clipToCollection(country);
  // Map.addLayer(transition, {min:-3, max:3}, 'transition', false);
  // Map.addLayer(transition, visParams_trans, 'transition', true);
  // updateLayer(transition, 'transition', visParams_trans, true);
  // return transition;
  // return ee.Dictionary({
  //   'start_data': start_data,
  //   'end_data': end_data,
  //   'transition': transition
  // });
  return transition.rename('transition').addBands(start_data.rename('start_data')).addBands(end_data.rename('end_data'));
}
function getPointChart(data, point, title, v_ticks) {//, reducer, scale) {
  // default(s)
  if (typeof title == 'undefined') title = 'Time series at clicked point';
  if (typeof v_ticks == 'undefined') v_ticks = [{v:0, f:'no data'}, {v:1, f:'land'}, {v:2, f:'seasonal water'}, {v:3, f:'permanent water'}];
  // if (typeof reducer == 'undefined') reducer = ee.Reducer.mode();
  // if (typeof scale == 'undefined') scale = 30;
  // chart
  var point_chart = ui.Chart.image.series({
    imageCollection: data,
    region: point,
    // reducer: reducer,
    reducer: ee.Reducer.mode(),
    // scale: scale,
    scale: 30,
    // xProperty: 'system:time_start'
  });
  point_chart.setOptions({
    // title: 'Time series at clicked point',
    title: title,
    // hAxis: {title: 'Time'},
    hAxis: {title: ''},
    vAxis: {title: 'Water class', ticks: v_ticks},
    legend: 'none'
  });
  // print(point_chart);
  return point_chart;
}
function updateSelector() {
  analyser_mssg.setValue(selector_message[analysis_selector.getValue()]);
  var selected_feature_name = analysis_selector.getValue().toLowerCase();
  if (selected_feature_name == 'polders') {
    analyser_mssg.style().set('shown', true);
    analysis_panel_1.style().set('shown', true);
    Map.layers().forEach(function(layer) {
      // if (layer.get('name') == selected_feature_name) {
      //   layer.setShown(true);
      // }
      if ((layer.get('name') == 'Polders (original)') || (layer.get('name') == 'Polders (current)')) {
        layer.setShown(true);
      }
    });
  }
  if (selected_feature_name == 'point') {
    analyser_mssg.style().set('shown', false);
    analysis_panel_1.style().set('shown', false);
    charts.style().set('shown', true);
  // } else {
  //   analyser_mssg.style().set('shown', true);
  //   analysis_panel_1.style().set('shown', true);
  }
}
function clearLayer(name) {
  Map.layers().forEach(function(layer) {
    if (layer.get('name') == name) {
      Map.layers().remove(layer);
    }
  });
}
function clearLayers(layers) {
  layers.map(function(n) {
    clearLayer(n);
  });
}
function updateLayer(new_layer, name, visParams, shown) {
  var found_layer = true;
  Map.layers().forEach(function(layer) {
    if (layer.get('name') == name) {
      // Map.layers().remove(layer);
      layer.setEeObject(new_layer);
      found_layer = false;
    }
  });
  if (found_layer) {
    Map.addLayer(new_layer, visParams, name, shown);
  }
}
var toggleLegends = function() {
  legends.style().set('shown', !legends.style().get('shown'));
};
var toggleCharts = function() {
  charts.style().set('shown', !charts.style().get('shown'));
};
var toggleLogos = function() {
  logos.style().set('shown', !logos.style().get('shown'));
};
var toggleRefs = function() {
  refs.style().set('shown', !refs.style().get('shown'));
};
// helper function to make Point Feature(s)
var makePointFeature = function(coord, offset) {
  var pt = ee.Algorithms.GeometryConstructors.Point(coord);
  return new ee.Feature(pt).set('offset', offset);
};
// split line
function splitLine(line, res, increase_factor) {
  // default(s)
  if (typeof res == 'undefined') res = 30;
  if (typeof increase_factor == 'undefined') increase_factor = 0.75;
  // calculate required distance per line segment
  var length = line.length();
  // var distances = ee.List.sequence(0, length, res);  // specified resolution
  var distances = ee.List.sequence(0, length, ee.Number(res).multiply(increase_factor));  // increase nr of points
  // split single line into multiple lines with calculated distance
  var lines = line.cutLines(distances).geometry().geometries();
  // construct points from each split line
  var points = lines.zip(distances).map(function(s) {
    var line   = ee.List(s).get(0);
    var offset = ee.List(s).get(1);
    return makePointFeature(ee.Geometry(line).coordinates().get(0), offset);
  });
  points = points.add(makePointFeature(line.geometry().coordinates().get(-1), length));
  // return as new FeatureCollection
  line = new ee.FeatureCollection(points);
  return line;
}
// ---------------------------------------------------------------------------------------------------- //
// Pre-calculate data
// ---------------------------------------------------------------------------------------------------- //
// buffer country geometry to not loose information along coastlines
// country = country.map(function(f) {
//   var new_geom = f.geometry().buffer(buffer_border);
//   var land_borders = GAUL.filterBounds(new_geom).filter(ee.Filter.neq('ADM0_NAME', 'Bangladesh'));
//   new_geom = new_geom.difference(land_borders);
//   return f.setGeometry(new_geom);
// });
// Export.table.toAsset(country, 'Bangladesh_coast_buffered', 'users/arjenhaag/Bangladesh_coast_buffered');
// style embankments based on offline analysis on erosion risk (percentage eroded in full time period per 1km stretch)
function findClosestMatch(values_list, to_match_val) {
  var tmp_diffs = ee.List(values_list).map(function(i) {
    return ee.Number(i).divide(to_match_val).subtract(1).abs();
  });
  var diff_min = tmp_diffs.reduce(ee.Reducer.min());
  var closest_match_idx = tmp_diffs.indexOf(diff_min);
  return closest_match_idx;
}
split_embankments = split_embankments.map(function(f) {
  var tmp_pcnt_erode_embank = ee.Number(f.get('Split_i_36')).multiply(100);
  var closest_match_idx = findClosestMatch(vals_pcnt_erode_embank, tmp_pcnt_erode_embank);
  return f.set('style', {'color': ee.List(palette_pcnt_erode_embank).get(closest_match_idx), 'width':3});
});
// total erosion current vs original polders
// var polders_new_total_erosion = polders_new.map(function(f) {
polders_new = polders_new.map(function(f) {
  var f_org = polders.filter(ee.Filter.eq('name', f.get('name')));
  var f_erosion_geom = f_org.geometry().difference(f.geometry()).dissolve();
  var f_erosion = ee.Number(f_erosion_geom.area()).divide(1e4).multiply(100).round().divide(100);
  var f_erosion_pcnt = f_erosion.divide(f_org.geometry().area().divide(1e4)).multiply(100);
  var closest_match_idx_val  = findClosestMatch(vals_erode_polder, f_erosion);
  var closest_match_idx_pcnt = findClosestMatch(vals_pcnt_erode_embank, f_erosion_pcnt);
  // return f.setGeometry(f_erosion_geom);
  return f.set(
    'eroded_total_area_ha', f_erosion, 'eroded_total_area_pcnt', f_erosion_pcnt,
    'style_val', {'color': ee.List(palette_pcnt_erode_embank).get(closest_match_idx_val)},
    'style_pcnt', {'color': ee.List(palette_pcnt_erode_embank).get(closest_match_idx_pcnt)}
  );
});
// print(polders_new.aggregate_max('eroded_total_area_ha'));
// print(polders_new.aggregate_max('eroded_total_area_pcnt'));
// transition (erosion/sedimentation)
// var transition = calcTransition(default_start_year, default_end_year);
// var transition = ee.Image(calcTransition(default_start_year, default_end_year).get('transition'));
// var transition = ee.Image(calcTransition(default_start_year, default_end_year).select('transition'));
var transition = ee.Image(calcTransition(default_start_year, default_end_year));
// Export.image.toDrive({
//   image: transition,
//   description: 'BangladeshErosion_transition_' + default_start_year + '_' + default_end_year,
//   folder: 'GEE',
//   // fileNamePrefix: '',
//   region: country,
//   scale: 30,
//   maxPixels: 1e12,
//   crs: 'EPSG:3857'
// });
// Export.image.toAsset({
//   image: transition.set('start_year', default_start_year, 'end_year', default_end_year, 'fill_nodata', 'false', 'remove_water_in_polders', 'false'),
//   description: 'BangladeshErosion_transition_' + default_start_year + '_' + default_end_year,
//   assetId: 'users/arjenhaag/BangladeshErosion/transition_' + default_start_year + '_' + default_end_year,
//   // pyramidingPolicy: 'mean',  // mean (default), sample, min, max, or mode
//   region: country,
//   scale: 30,
//   maxPixels: 1e12
// });
// calculate polder erosion statistics
var years = ee.List.sequence(ee.Number(default_start_year), default_end_year);
// print('years', years);
var transition_yearly = ee.ImageCollection.fromImages(ee.List.sequence(1, years.length().subtract(1)).map(function(i) {
  // var tmp_start_year = years.get(ee.Number(i));
  // var tmp_end_year = years.get(ee.Number(i).add(1));
  var tmp_start_year = years.get(ee.Number(i).subtract(1));
  var tmp_end_year = years.get(ee.Number(i));
  // var tmp_transition = ee.Image(calcTransition(tmp_start_year, tmp_end_year).get('transition'));
  var tmp_transition = ee.Image(calcTransition(tmp_start_year, tmp_end_year)).select('transition');
  tmp_transition = tmp_transition.eq(0).rename('nochange')
    .addBands(tmp_transition.eq(2).rename('erosion'))
    .addBands(tmp_transition.eq(-2).rename('sedimentation'))
    .addBands(tmp_transition.eq(-3).or(tmp_transition.eq(-1)).or(tmp_transition.eq(1)).or(tmp_transition.eq(3)).rename('nodata'));
  return ee.Image(tmp_transition).set(
    'start_year', tmp_start_year,
    'end_year', tmp_end_year,
    'fill_nodata', 'lastNonNull',
    'remove_water_in_polders', 'false',
    'system:time_start', ee.Date.fromYMD(tmp_start_year,1,1).millis(),
    'system:time_end', ee.Date.fromYMD(tmp_end_year,1,1).millis()
  );
}));
// print('transition yearly (size):', transition_yearly.size());
// print('transition yearly (start years):', transition_yearly.aggregate_array('start_year'));
// print('transition yearly:', transition_yearly);
// insert zero image as first year (to make combo charts work for any period)
var transition_yearly_insert = transition_yearly.first().unmask(0).add(10).lt(0).set(
  'start_year', default_start_year-1,
  'end_year', default_start_year,
  'fill_nodata', 'lastNonNull',
  'remove_water_in_polders', 'false',
  'system:time_start', ee.Date.fromYMD(default_start_year-1,1,1).millis(),
  'system:time_end', ee.Date.fromYMD(default_start_year,1,1).millis()
);
transition_yearly = transition_yearly.merge(transition_yearly_insert).sort('start_year');
// print('transition yearly (size):', transition_yearly.size());
// print('transition yearly (start years):', transition_yearly.aggregate_array('start_year'));
// print('transition yearly:', transition_yearly);
function getPolderStats(fc, start_year) {
  // var transition_yearly_tmp = transition_yearly.filter(ee.Filter.gte('start_year', start_year));
  var transition_yearly_tmp = transition_yearly.filter(ee.Filter.gte('end_year', start_year));
  var JRC_yearly_2_tmp = JRC_yearly_2.filter(ee.Filter.gte('year', start_year));
  var JRC_monthly_2_tmp = JRC_monthly_2.filter(ee.Filter.gte('year', start_year));
  var polders_stats = fc.map(function(f) {
    // transition yearly
    var transition_data_yearly = transition_yearly_tmp.map(function(img) {
      // var area_nodata = img.select('nodata').multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
      var area_nochange = img.select('nochange').multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
      var area_sediment = img.select('sedimentation').multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
      var area_erosion = img.select('erosion').multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
      return img.set(
        // 'area_nodata', area_nodata.values().get(0),
        'area_nochange', area_nochange.values().get(0),
        'area_sedimentation', area_sediment.values().get(0),
        'area_erosion', area_erosion.values().get(0)
      );
    }).sort('start_year');
    var yearly_nodata = transition_data_yearly.aggregate_array('area_nodata');
    var yearly_nochange = transition_data_yearly.aggregate_array('area_nochange');
    var yearly_sedimentation = transition_data_yearly.aggregate_array('area_sedimentation');
    var yearly_erosion = transition_data_yearly.aggregate_array('area_erosion');
    // JRC yearly
    var JRC_data_yearly = JRC_yearly_2_tmp.map(function(img) {
      // var area_nodata = img.eq(0).multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
      // var area_land = img.eq(1).multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
      var area_seas = img.eq(2).multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
      var area_perm = img.eq(3).multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
      var area_land = f.geometry().area().divide(1e4).subtract(ee.Number(area_seas.values().get(0)).add(area_perm.values().get(0)));
      return img.set(
        // 'area_nodata', area_nodata.values().get(0),
        // 'area_land', area_land.values().get(0),
        'area_land', area_land,
        'area_seasonal', area_seas.values().get(0),
        'area_permanent', area_perm.values().get(0)
      );
    }).sort('year');
    // var yearly_nodata_JRC = JRC_data_yearly.aggregate_array('area_nodata');
    var yearly_land = JRC_data_yearly.aggregate_array('area_land');
    var yearly_seas = JRC_data_yearly.aggregate_array('area_seasonal');
    var yearly_perm = JRC_data_yearly.aggregate_array('area_permanent');
    // JRC monthly
    // var JRC_data_monthly = JRC_monthly_2_tmp.map(function(img) {
    //   var area_nodata = img.eq(0).multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
    //   var area_land = img.eq(1).multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
    //   var area_water = img.eq(2).multiply(ee.Image.pixelArea()).divide(1e4).reduceRegion(ee.Reducer.sum(), f.geometry(), 30);
    //   return img.set(
    //     'area_nodata', area_nodata.values().get(0),
    //     'area_land', area_land.values().get(0),
    //     'area_water', area_water.values().get(0)
    //   );
    // }).sort('system:time_start');
    // var monthly_nodata_JRC = JRC_data_monthly.aggregate_array('area_nodata');
    // var monthly_land = JRC_data_monthly.aggregate_array('area_land');
    // var monthly_water = JRC_data_monthly.aggregate_array('area_water');
    return f.set(
      // 'years_transition', transition_yearly_tmp.aggregate_array('end_year'),
      'years_transition', transition_yearly_tmp.aggregate_array('system:time_end'),
      // 'yearly_nodata', yearly_nodata,
      'yearly_nochange', yearly_nochange,
      'yearly_sedimentation', yearly_sedimentation,
      'yearly_erosion', yearly_erosion,
      // 'years_JRC', JRC_yearly_2_tmp.aggregate_array('year'),
      'years_JRC', JRC_yearly_2_tmp.aggregate_array('year').map(function(i) {return ee.Date.fromYMD(i,1,1).millis()}),
      // 'years_JRC', JRC_yearly_2_tmp.aggregate_array('system:time_start'),
      // 'yearly_nodata_JRC', yearly_nodata_JRC,
      'yearly_land', yearly_land,
      'yearly_seas', yearly_seas,
      'yearly_perm', yearly_perm
      // 'months_JRC', JRC_monthly_2_tmp.aggregate_array('system:time_start'),
      // 'monthly_nodata_JRC', monthly_nodata_JRC,
      // 'monthly_land', monthly_land,
      // 'monthly_water', monthly_water
    );
  });
  polders_stats = polders_stats.set('start_year', start_year, 'end_year', default_end_year);
  // print(polders_stats.first());
  return polders_stats;
}
var polders_stats = getPolderStats(polders, default_start_year);
// Export.table.toAsset({
//   collection: polders_stats,
//   description: 'BangladeshErosion_polders_stats',
//   assetId: 'users/arjenhaag/BangladeshErosion/polders_stats_v0'
// });
var polders_new_stats = getPolderStats(polders_new, default_start_year_current_polders);
// print(polders_line_new.first());
var polders_new_embankments_buffered = polders_line_new.map(function(f) {
  // return f.buffer(100);
  // var tmp_polder = polders_new.filter(ee.Filter.eq('SNAME', f.get('SNAME')));
  var tmp_polder = polders_new.filter(ee.Filter.eq('name', f.get('SNAME')));
  return f.buffer(buffer_embankments).difference(tmp_polder.first().geometry());
});
var polders_new_embankments_buffered_stats = getPolderStats(polders_new_embankments_buffered, default_start_year_current_polders);
// split embankment lines (to analyze each resulting line segment)
// var split_embankments_org = polders_line.map(splitLine);
// var split_embankments_new = polders_line_new.map(splitLine);
// Map.addLayer(split_embankments_org);
// Map.addLayer(split_embankments_new);
// throw(1)
// ---------------------------------------------------------------------------------------------------- //
// UI
// ---------------------------------------------------------------------------------------------------- //
// intro text
var intro = ui.Panel([
  ui.Label({
    value: 'Bangladesh Erosion Monitor',
    style: {fontSize:'20px', fontWeight:'bold'}
  }),
  ui.Label({
    value: "This application shows areas in Bangladesh that have eroded and/or sedimented using the Landsat satellite archive.",
    style: {fontSize:fontSize_sub, padding:'0px'}
  }),
  ui.Label({
    value: "You can inspect the map and the data, change the analysis period and query a more detailed analysis of relevant polders, river segments and embankments.",
    style: {fontSize:fontSize_sub, padding:'0px'}
  }),
  ui.Label({
    value: "WORK-IN-PROGRESS! You might have to zoom in for some of the map layers to be shown.",
    style: {fontSize:fontSize_sub, padding:'0px'}
  })
]);
// period
var year_slider_labels = ui.Panel(
  [ui.Label('Start', {margin:'0px 90px 0px 7px'}), ui.Label('End', {margin:'0px'})],
  ui.Panel.Layout.flow('horizontal')
);
var year_slider_1 = ui.Slider(1988, 2020, default_start_year, 1);
var year_slider_2 = ui.Slider(1988, 2020, default_end_year, 1);
var year_slider = ui.Panel(
  [year_slider_1, year_slider_2],
  ui.Panel.Layout.flow('horizontal')
);
var years_warning_box = ui.Label('Start year should be less than end year!', {padding:'0px', margin:'0px 7px', color:'red', shown:false});
var period_panel = ui.Panel([
  ui.Label({value: 'Select period:', style: {fontWeight: 'bold'}}),
  year_slider_labels,
  year_slider,
  years_warning_box
]);
// update button
var updateButton = ui.Button('Update', updateApp);
// map layer inspection
var analysis_label = ui.Label({value: 'Data analysis:', style: {fontWeight: 'bold'}});
var analysis_selector = ui.Select({
  // items: ['Polders', 'River segments', 'Embankments'],
  // items: ['Polders (original)', 'Point'],
  // items: ['Polders (original)', 'Polders (current)', 'Point'],
  items: ['Polders', 'Point'],
  // placeholder ,
  // value: 'Polders (original)',
  value: 'Polders',
  onChange: updateSelector
});
var analyser_mssg = ui.Label({value:'', style:{fontSize:fontSize_sub, padding:'0px'}});
var analyser_name = ui.Label('');
var analyser_lost_total = ui.Label('');
var analyser_eroded = ui.Label('');
var analyser_sedimented = ui.Label('');
// var analyser_eroded_embank = ui.Label('');
var analysis_panel_1 = ui.Panel([
  ui.Panel([
    ui.Label('Name:'),
    ui.Label('Reduction of area:'),
    ui.Label('Land -> Water:'),
    ui.Label('Water -> Land:'),
    // ui.Label('Eroded embankments [km]:')
  ]),
  ui.Panel([
    analyser_name,
    analyser_lost_total,
    analyser_eroded,
    analyser_sedimented,
    // analyser_eroded_embank
  ])
], ui.Panel.Layout.flow('horizontal'));
var analysis_panel = ui.Panel([analysis_label, analysis_selector, analyser_mssg, analysis_panel_1]);
// charts
// var charts = ui.Panel({widgets:[], style:{shown:false}});
var charts = ui.Panel({widgets:[], style:{shown:true}});
var charts_loading_mssg = ui.Label({value:'Calculating...', style:{fontSize:fontSize_sub, padding:'0px', shown:false}});
var charts_panel = ui.Panel([
  ui.Button('Show/hide charts', toggleCharts, false, {fontWeight: 'bold'}),
  // ui.Label('Charts:', {fontWeight:'bold'}),
  charts_loading_mssg,
  charts
]);
// legend(s)
var legend_transition = ui.Panel({widgets:[
  ui.Label({value: 'Transition classes:', style: {fontWeight: 'bold'}}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: 'white',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: 'no change',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: 'lightblue',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: 'water',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: 'blue',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      // value: 'land -> water',
      value: 'erosion',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: 'green',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      // value: 'water -> land',
      value: 'sedimentation',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ], style:{margin: '0px 0px 10px 0px'}
});
var legend_dynamics = ui.Panel({widgets:[
  ui.Label({value: 'Dynamics:', style: {fontWeight: 'bold'}}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: 'white',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: 'no changes',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: 'green',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: 'relatively stable',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: 'yellow',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: 'occasional changes',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: 'orange',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: 'dynamic',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
   ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: 'red',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: 'very dynamic',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ], style:{margin: '0px 0px 10px 0px'}
});
var legend_population = ui.Panel({widgets:[
  ui.Label({value: 'Population:', style: {fontWeight: 'bold'}}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: '#fff7ec',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: '5',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: '#fdbb84',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: '50',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: '#d7301f',
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: '100+',
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ], style:{margin: '0px 0px 10px 0px'}
});
var legend_WorldCover = ui.Panel({widgets:[
  ui.Label({value: 'Landcover:', style: {fontWeight: 'bold'}}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[0],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[0],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[1],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[1],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[2],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[2],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[3],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[3],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[4],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[4],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[5],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[5],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[6],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[6],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[7],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[7],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[8],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[8],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[9],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[9],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ui.Panel({widgets:[
    ui.Label({
      style: {
        backgroundColor: lc_colors[10],
        padding: '8px',
        margin: '0 0 4px 8px',
        border: '1px solid black'
      }
    }),
    ui.Label({
      value: lc_names[10],
      style: {margin: '0 0 4px 6px'}
    })], layout: ui.Panel.Layout.Flow('horizontal')}),
  ], style:{margin: '0px 0px 10px 0px'}
});
var legends = ui.Panel({
  widgets: [legend_transition, legend_dynamics, legend_population, legend_WorldCover],
  style: {shown:true}
});
var legends_panel = ui.Panel([
  ui.Button('Show/hide legends', toggleLegends, false, {fontWeight: 'bold'})
]);
// logos
var logo_WMKIP = ui.Thumbnail({
  image: ee.Image('users/arjenhaag/BangladeshErosion/logo_WMKIP'),
  params:{bands:['b1','b2','b3'],min:0,max:255},
  style:{width:'250px', height:'90px', margin:'0px 0px 0px 10px'}
});
var logo_Deltares = ui.Thumbnail({
  image: ee.Image('users/arjenhaag/logo_Deltares'),
  params:{bands:['b1','b2','b3'],min:0,max:255},
  style:{width:'230px', height:'90px', margin:'0px 0px 0px 20px'}
});
var logo_IWM = ui.Thumbnail({
  image: ee.Image('users/arjenhaag/BangladeshErosion/logo_iwm'),
  params:{bands:['b1','b2','b3'],min:0,max:255},
  style:{width:'140px', height:'90px', margin:'0px 0px 10px 60px'}
});
var logos = ui.Panel([
  logo_WMKIP, logo_Deltares, logo_IWM
]);
var logos_panel = ui.Panel([
  ui.Button('Show/hide logos', toggleLogos, false, {fontWeight: 'bold'}),
  logos
]);
// references
var refs = ui.Panel([
  ui.Panel([
    ui.Label({
      value: "- Landsat:",
      style: {fontSize:fontSize_sub, padding:'0px', margin:'0px 0px 0px 8px'}
    }),
    ui.Label({
      value: "U.S. Geological Survey",
      targetUrl: "https://www.usgs.gov/core-science-systems/nli/landsat",
      style: {fontSize:fontSize_sub, padding:'0px', margin:'0px 0px 0px 3px'}
    })
  ], ui.Panel.Layout.flow('horizontal')),
  ui.Panel([
    ui.Label({
      value: "- JRC Surface Water:",
      style: {fontSize:fontSize_sub, padding:'0px', margin:'0px 0px 0px 8px'}
    }),
    ui.Label({
      value: "Pekel et al. (2016)",
      targetUrl: "https://www.nature.com/articles/nature20584.epdf?author_access_token=C5JSvooRop4jWxyp_qRPLNRgN0jAjWel9jnR3ZoTv0MqBuzCNsmw_DFxRd7sX93nfPzcbm_xTiPLlZMl7XrUhadm6EiT9cGdDNgn1s6EWrPWH3IeadLUjApplBoaS6xH",
      style: {fontSize:fontSize_sub, padding:'0px', margin:'0px 0px 0px 8px'}
    }),
  ], ui.Panel.Layout.flow('horizontal')),
  ui.Panel([
    ui.Label({
      value: "- polders/embankments:",
      style: {fontSize:fontSize_sub, padding:'0px', margin:'0px 0px 0px 8px'}
    }),
    ui.Label({
      value: "BWDB, NWRD",
      // targetUrl: "",
      style: {fontSize:fontSize_sub, padding:'0px', margin:'0px 0px 0px 8px'}
    }),
  ], ui.Panel.Layout.flow('horizontal')),
  ui.Panel([
    ui.Label({
      value: "- Population:",
      style: {fontSize:fontSize_sub, padding:'0px', margin:'0px 0px 0px 8px'}
    }),
    ui.Label({
      value: "WorldPop",
      targetUrl: "https://www.worldpop.org",
      style: {fontSize:fontSize_sub, padding:'0px', margin:'0px 0px 0px 8px'}
    }),
  ], ui.Panel.Layout.flow('horizontal')),
  ui.Panel([
    ui.Label({
      value: "- Landcover:",
      style: {fontSize:fontSize_sub, padding:'0px', margin:'0px 0px 0px 8px'}
    }),
    ui.Label({
      value: "ESA WorldCover",
      targetUrl: "https://esa-worldcover.org/en",
      style: {fontSize:fontSize_sub, padding:'0px', margin:'0px 0px 0px 8px'}
    }),
  ], ui.Panel.Layout.flow('horizontal')),
  ui.Label({
    value: "© ESA WorldCover project 2020 / Contains modified Copernicus Sentinel data (2020) processed by ESA WorldCover consortium",
    style: {fontSize:fontSize_sub, padding:'0px', margin:'3px 0px 0px 8px'}
  }),
  ui.Label({
    value: "Source of Administrative boundaries: The Global Administrative Unit Layers (GAUL) dataset, implemented by FAO within the CountrySTAT and Agricultural Market Information System (AMIS) projects.\
            Adapted for this application to fully include the estuary/delta.",
    style: {fontSize:fontSize_sub, padding:'0px', margin:'3px 0px 0px 8px'}
  })
], ui.Panel.Layout.flow('vertical'), {shown:false});
var refs_panel = ui.Panel([
  ui.Panel([
    ui.Button({label:'Show/hide references', onClick:toggleRefs})
  ], ui.Panel.Layout.flow('horizontal')),
  refs
]);
var outro = ui.Label({
  value: "For more information on this application, please contact kymo.slager@deltares.nl, arjen.haag@deltares.nl and/or sam@iwmbd.org",
  style: {fontSize:fontSize_sub, padding:'0px', margin:'3px 0px 8px 8px'}
});
// panel combining relevant UI elements for the ui.root
var panel = ui.Panel({
  widgets: [intro, period_panel, updateButton, analysis_panel, charts_panel, legends_panel, legends, logos_panel, refs_panel, outro],
  // widgets: [intro, period_panel, updateButton, analysis_panel, charts_panel, legends, refs_panel, outro],
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    position: 'top-left',
    width: '290px'
  }
});
// add the panel to the ui.root
ui.root.insert(0, panel);
// ---------------------------------------------------------------------------------------------------- //
// Map
// ---------------------------------------------------------------------------------------------------- //
// Map.centerObject(country);
// Map.centerObject(polders);
Map.centerObject(polders_new);
Map.setZoom(9);  // higher zoom level required for transition layer to show?!
// add default layers
// Map.addLayer(background_bbox, {}, 'background bbox', false);
Map.addLayer(background_other, {palette:['grey']}, 'background (other)', true, 0.5);
Map.addLayer(background, {palette:['white']}, 'background (focus)', true, 0.5);
// Map.addLayer(esri_lulc2020, {}, 'ESRI landcover', false);
Map.addLayer(WorldCover, visParams_lc, 'landcover (ESA WorldCover)', false);
Map.addLayer(WorldPop.updateMask(WorldPop.gte(pop_thresh)), visParams_pop, 'population (WorldPop)', false);
// Map.addLayer(HRSL.updateMask(HRSL.gte(pop_thresh)), visParams_pop, 'population (HRSL)', false);
Map.addLayer(JRC_water, {bands:'occurrence', min:0, max:100, palette:['white','blue']}, 'JRC water occurrence', false);
// Map.addLayer(JRC_yearly, visParams_monthly, 'JRC water (yearly)', false);
// Map.addLayer(JRC_monthly, visParams_monthly, 'JRC water (monthly)', false);
// Map.addLayer(JRC_water.select('transition'), {}, 'JRC water transition', false);
updateApp();
analyser_mssg.setValue(selector_message[analysis_selector.getValue()]);
charts.add(ui.Label({value:'Click on the map to query a timeseries analysis for that polder or point', style:{fontSize:fontSize_sub, padding:'0px'}}));
Map.addLayer(polders_raster, visParams_mask_white, 'polders internal mask', false);
Map.addLayer(ferry_terminals, {}, 'ferry terminals', false);
Map.addLayer(biwta_ghats, {}, 'biwta ghats', false);
Map.addLayer(ee.Image().byte().paint(polders, 0, 2), {palette:'grey'}, 'polders (original)', true);
Map.addLayer(ee.Image().byte().paint(polders_new, 0, 2), {}, 'polders (current)', true);
// Map.addLayer(ee.Image().byte().paint(polders_new_total_erosion, 0, 2), {}, 'polders (eroded area)', true);
// Map.addLayer(polders_new.style({styleProperty:'style_val'}), {}, 'polders (current) [area lost]', false);
// Map.addLayer(polders_new.style({styleProperty:'style_pcnt'}), {}, 'polders (current) [% area lost]', false);
// Map.addLayer(rivers_test, {'color': 'orange'}, 'river segments', false, 0.5);
// Map.addLayer(eroded_embankments, {color:'red'}, 'eroded embankments', false);
Map.addLayer(ee.Image().byte().paint(eroded_embankments, 0, 3), {palette:'red'}, 'completely eroded embankments', true);
Map.addLayer(split_embankments.style({styleProperty:'style'}), {}, 'embankment erosion risk', false);
Map.addLayer(polders_new_embankments_buffered, {}, 'polder embankments buffer', false);
Map.addLayer(ee.Image().byte().paint(country, 0, 2), {}, 'Bangladesh', false);
// Map.addLayer(other_countries, {}, 'Bangladesh focus', true, 0.7);
Map.style().set('cursor','crosshair');