var L4 = ui.import && ui.import("L4", "imageCollection", {
      "id": "LANDSAT/LT04/C02/T1_L2"
    }) || ee.ImageCollection("LANDSAT/LT04/C02/T1_L2"),
    L5 = ui.import && ui.import("L5", "imageCollection", {
      "id": "LANDSAT/LT05/C02/T1_L2"
    }) || ee.ImageCollection("LANDSAT/LT05/C02/T1_L2"),
    L7 = ui.import && ui.import("L7", "imageCollection", {
      "id": "LANDSAT/LE07/C02/T1_L2"
    }) || ee.ImageCollection("LANDSAT/LE07/C02/T1_L2"),
    L8 = ui.import && ui.import("L8", "imageCollection", {
      "id": "LANDSAT/LC08/C02/T1_L2"
    }) || ee.ImageCollection("LANDSAT/LC08/C02/T1_L2"),
    L9 = ui.import && ui.import("L9", "imageCollection", {
      "id": "LANDSAT/LC09/C02/T1_L2"
    }) || ee.ImageCollection("LANDSAT/LC09/C02/T1_L2"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#23cba7",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #23cba7 */ee.Geometry.MultiPoint();
// yearly cloud-free Landsat mosaics
// NOTES:
/*
- Quite some strips because of Landsayt 7...
	-> removing Landsat 7 causes some years to have no data at all (e.g. 2003-2007)
	-> defringing also leaves some years nearly without any data
	-> defringe and then fill up gaps using previous year(s)?
- Cannot see changes within a year...
	-> other method than median used now? lower percentile? mean?
	-> smaller timestep?
	-> update using each individual image?
- 
*/
// ----------------------------------------------------------------------------------------- //
// Parameters
// ----------------------------------------------------------------------------------------- //
// predefined geometries
var geometry1 = ee.Geometry.Polygon(
        [[[67.26075577676308, 27.91045772309373],
          [67.26075577676308, 25.29784905549454],
          [69.65577530801308, 25.29784905549454],
          [69.65577530801308, 27.91045772309373]]], null, false),
    geometry2 = ee.Geometry.Polygon(
        [[[67.07516081637179, 28.07046454203457],
          [67.07516081637179, 26.975626142591985],
          [69.71187956637179, 26.975626142591985],
          [69.71187956637179, 28.07046454203457]]], null, false);
// dates
var start = '1988-01-01';
// var start = '2000-01-01';
var end = '2023-01-01';
// bands
var L457_BANDS = ['SR_B1','SR_B2','SR_B3','SR_B4','SR_B5','SR_B7','QA_PIXEL'];
var L89_BANDS = ['SR_B2','SR_B3','SR_B4','SR_B5','SR_B6','SR_B7','QA_PIXEL'];
var STD_NAMES = ['blue','green','red','nir','swir1','swir2','pixel_qa'];
var sel_names = ['swir1','nir','green'];
// animation
// var timeStep = 500;  // default is 100
var timeStep = 200;  // default is 100
var compact  = true;  // default is false
var a_width  = '400px';   // default is 600px
var position = 'bottom-right';  // default is top-center
// visual parameter(s)
// var visParams = {bands:['swir1','nir','green'], min:10000, max:25000, gamma:1.0};
var visParams = {min:10000, max:25000, gamma:1.0};
// ----------------------------------------------------------------------------------------- //
// Functions / initial processing
// ----------------------------------------------------------------------------------------- //
// modules
// var animation = require('users/gena/packages:animation');
var animation = require('users/arjenhaag/modules:animation');
// var Landsat_funcs = require('users/arjenhaag/modules:Landsat');
// defringing
// L5 = L5.map(Landsat_funcs.defringe);
// L7 = L7.map(Landsat_funcs.defringe);
// align band names
L4 = L4.select(L457_BANDS, STD_NAMES);
L5 = L5.select(L457_BANDS, STD_NAMES);
L7 = L7.select(L457_BANDS, STD_NAMES);
L8 = L8.select(L89_BANDS, STD_NAMES);
L9 = L9.select(L89_BANDS, STD_NAMES);
// merge and filter images
// var images = L4.merge(L5).merge(L8).merge(L9);  // without Landsat 7 (to remove striping pattern without defringing)
var images = L4.merge(L5).merge(L7).merge(L8).merge(L9);
// images = images.filterBounds(geometry1).filterDate(start, end);
// print('images:', images.size());
// Landsat 8 CFMask cloud masking
function applyCFMask(img) {
  // bits 3 and 5 are cloud shadow and cloud, respectively
  var cloudShadowBitMask = (1 << 3);
  var cloudsBitMask = (1 << 5);
  // get the pixel QA band
  var qa = img.select('pixel_qa');
  // both flags should be set to zero, indicating clear conditions
  var shadows = qa.bitwiseAnd(cloudShadowBitMask).eq(0);
  var clouds = qa.bitwiseAnd(cloudsBitMask).eq(0);
  var mask = clouds.and(shadows);
  return img.updateMask(mask);
}
function cFmaskCloud(img){
  var cloud = img.select('pixel_qa').bitwiseAnd(32).neq(0);
  return img.updateMask(cloud.not());
}
function cFmaskCloudShadow(img){
  var cloud_shadow = img.select('pixel_qa').bitwiseAnd(8).neq(0);
  return img.updateMask(cloud_shadow.not());
}
// images = images.map(cFmaskCloud);
// images = images.map(cFmaskCloudShadow);
images = images.map(applyCFMask);
images = images.select(sel_names);
// var images_yearly = ee.ImageCollection(ee.List.sequence(1988, 2022).map(function(i) {
//   var start_year  = ee.Date.fromYMD(i,1,1);
//   var end_year    = ee.Date.fromYMD(ee.Number(i).add(1),1,1);
//   var images_year = images.filterDate(start_year, end_year);
//   // var mosaic = images_year.mean();
//   var mosaic = images_year.median();
//   return mosaic.set('year', i, 'year_str', ee.Number(i).format('%d'), 'image_count', images_year.size());
// }));
// // print(images_yearly);
// // throw(1);
// var img_count_chart = ui.Chart.array.values(images_yearly.aggregate_array('image_count'), 0, images_yearly.aggregate_array('year_str'));
// img_count_chart.setChartType('ColumnChart');
// print(img_count_chart);
// map
// Map.centerObject(geometry1);
// Map.centerObject(geometry2);
// animation.animate(images_yearly, {
//   'maxFrames': images_yearly.size(),
//   'vis': visParams,
//   'prefix': 'Landsat',
//   'label': 'year_str',
//   // 'label': '{{year}}',
//   'timeStep': timeStep,
//   'compact': compact,
//   'position': position,
//   'width': a_width,
//   'map': Map,
//   'chart': img_count_chart
// });
// load individual images to the map
// for (var i=1988; i<2023; i++) {
// // for (var i=2000; i<2023; i++) {
// // for (var i=2018; i<2023; i++) {
//   // var start_year  = i + '-01-01';
//   // var end_year    = (i+1) + '-01-01';
//   // var images_year = images.filterDate(start_year, end_year);
//   // var images_mean = images_year.mean();
//   // var images_median = images_year.median();
//   // // Map.addLayer(images_mean, visParams, 'mean ' + i, true);
//   // Map.addLayer(images_median, visParams, 'median ' + i, true);
//   var images_year = images_yearly.filter(ee.Filter.eq('year', i)).first();
//   Map.addLayer(images_year, visParams, 'Landsat ' + i, false);
// }
// Map.addLayer(ee.Image().byte().paint(geometry1,0,2), {}, 'AoI', false);
// Map.addLayer(ee.Image().byte().paint(geometry2,0,2), {}, 'AoI', false);
// turn some map control elements off
// Map.setControlVisibility({
//   zoomControl: false,
//   mapTypeControl: false,
//   drawingToolsControl: false
// });
// ----------------------------------------------------------------------------------------- //
// User Interface
// ----------------------------------------------------------------------------------------- //
// drawing tools
var drawingTools = Map.drawingTools();  // get the drawing tools widget object
drawingTools.setShown(false);  // hide by default to customize
Map.setControlVisibility({zoomControl: false});
// clear existing geometries
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
// geometry clearing and drawing functions
function clearGeometry() {
  var layers = drawingTools.layers();
  // layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
  layers.get(0).geometries().reset();
}
function drawRectangle() {
  clearGeometry();
  drawingTools.setShape('rectangle');
  drawingTools.draw();
}
// drawing tools listener
// (note that ui.util.debounce wraps the function to reduce the frequency of it being invoked while drawing and editing a geometry)
function drawOff() {
  drawingTools.setShape(null);
}
drawingTools.onDraw(ui.util.debounce(drawOff, 100));
// add placeholder geometry
var dummyGeometry = ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: '23cba7'});
drawingTools.layers().add(dummyGeometry);
// drawing tools control
var drawing_control = ui.Panel({
  widgets: [
    ui.Button({
      label: 'Draw rectangle',
      onClick: drawRectangle,
      style: {stretch: 'horizontal'}
    })
  ],
  layout: null,
});
// time period
var year_slider_labels = ui.Panel(
  [ui.Label('Start', {margin:'0px 90px 0px 7px'}), ui.Label('End (inclusive)', {margin:'0px'})],
  ui.Panel.Layout.flow('horizontal')
);
var year_slider_1 = ui.Slider(1988, 2022, 1988, 1);
var year_slider_2 = ui.Slider(1988, 2022, 2022, 1);
var year_slider = ui.Panel(
  [year_slider_1, year_slider_2],
  ui.Panel.Layout.flow('horizontal')
);
var years_warning_box = ui.Label('Start year should be less than end year!', {padding:'0px', margin:'0px 7px', color:'red', shown:false});
var period_panel = ui.Panel([
  ui.Label({value: 'Select period:', style: {fontWeight: 'bold'}}),
  year_slider_labels,
  year_slider,
  years_warning_box
]);
// mosaics functions
var mosaic_funcs_dict = {
  'Median': ee.Reducer.median(),
  'Mean': ee.Reducer.mean()
};
var mosaics_functions = ui.Select(['Median', 'Mean']);
// update function
function updateAll() {
  // clean up
  Map.layers().reset();
  Map.widgets().reset();
  // get values from UI
  var bounds = drawingTools.layers().get(0).getEeObject();
  var year_start = year_slider_1.getValue();
  var year_end = year_slider_2.getValue();
  var mosaic_func = mosaic_funcs_dict[mosaics_functions.getValue()];
  // filter and mosaic images
  var images_user = images.filterBounds(bounds);
  var mosaics_user = ee.ImageCollection(ee.List.sequence(year_start, year_end).map(function(i) {
    var start_year  = ee.Date.fromYMD(i,1,1);
    var end_year    = ee.Date.fromYMD(ee.Number(i).add(1),1,1);
    var images_year = images_user.filterDate(start_year, end_year);
    var mosaic = images_year.reduce(mosaic_func);
    return mosaic.set('year', i, 'year_str', ee.Number(i).format('%d'), 'image_count', images_year.size());
  }));
  animation.animate(mosaics_user, {
    'maxFrames': mosaics_user.size(),
    'vis': visParams,
    'prefix': 'Landsat',
    'label': 'year_str',
    // 'label': '{{year}}',
    'timeStep': timeStep,
    'compact': compact,
    'position': position,
    'width': a_width,
    'map': Map,
    // 'chart': img_count_chart
  });
  clearGeometry();
}
// toggle UI elements
var toggledUI = true;
function toggleUI() {
  toggledUI = !toggledUI;
  Map.setControlVisibility({
    layerList: toggledUI,
    mapTypeControl: toggledUI
  });
}
// UI panel
var ui_panel = ui.Panel({
  widgets: [
    ui.Label('Yearly Landsat Mosaics Animation', {fontWeight:'bold', fontSize:'20px'}),
    ui.Label('Follow these steps to start loading an animation:'),
    ui.Label('1. Draw bounding box'),
    ui.Label('2. Select start and end year'),
    ui.Label('3. Select function to create yearly mosaics'),
    ui.Label('4. Press the update button'),
    ui.Label("5. Wait for all the images to load (see grey bars at top right 'Layers' element; go do something else in the meantime)"),
    ui.Label('You can record your screen to save an animation to your local drive. We recommend minimizing all UI elements and going into fullscreen view before doing so.'),
    ui.Label('You can zoom in and out and pan around the map, but keep in mind this will require loading (parts of) the data again.'),
    ui.Label('1. Bounding box', {fontWeight:'bold'}),
    drawing_control,
    ui.Label('2. Time period', {fontWeight:'bold'}),
    period_panel,
    ui.Label('3. Mosaic function', {fontWeight:'bold'}),
    mosaics_functions,
    ui.Label('4. Load images', {fontWeight:'bold'}),
    ui.Button('Update', updateAll),
    ui.Button('Toggle UI', toggleUI),
  ],
  style: {width: '350px', position: 'top-left'}
});
// Map.add(ui_panel);
ui.root.insert(0, ui_panel);