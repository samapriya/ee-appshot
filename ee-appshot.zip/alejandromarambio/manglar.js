var roi = ui.import && ui.import("roi", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -91.742881352994,
                14.419197267910537
              ],
              [
                -91.742881352994,
                13.787048654185725
              ],
              [
                -90.25663715133385,
                13.787048654185725
              ],
              [
                -90.25663715133385,
                14.419197267910537
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-91.742881352994, 14.419197267910537],
          [-91.742881352994, 13.787048654185725],
          [-90.25663715133385, 13.787048654185725],
          [-90.25663715133385, 14.419197267910537]]], null, false);
// BASE
//Map.setOptions('SATELLITE');
//Map.setControlVisibility(false);
//Map.setControlVisibility({
//  zoomControl: false, 
//  layerList: true, 
//  fullscreenControl: false, 
//  mapTypeControl: true, 
//  drawingToolsControl: false 
//});
Map.centerObject(roi, 10);
var palettes = require('users/gena/packages:palettes');
var style = require('users/gena/packages:style')
style.SetMapStyleDark()
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Sentinel-2
var s2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED');
var csPlus = ee.ImageCollection('GOOGLE/CLOUD_SCORE_PLUS/V1/S2_HARMONIZED');
var QA_BAND = 'cs_cdf';
var CLEAR_THRESHOLD = 0.60;
// Function to compute NDVI and process Sentinel-2 imagery
function getNDVI_s2(startDate, endDate, name) {
  var sentinel2_filtered = s2
    .filterBounds(roi)
    .filterDate(startDate, endDate)
    .select(['B2', 'B3', 'B4', 'B8', 'B11', 'B12']) // Ensure band selection is consistent
    .map(function (img) {
      var csImg = csPlus.filterDate(startDate, endDate)
                        .filterBounds(roi)
                        .filter(ee.Filter.eq('system:index', img.get('system:index')))
                        .first();
      return img.addBands(csImg.select(QA_BAND)).updateMask(csImg.select(QA_BAND).gte(CLEAR_THRESHOLD));
    })
    .median()
    .clip(roi);
  // Calculate NDVI using NIR (B8) and Red (B4) bands
  var ndvi = sentinel2_filtered
    .normalizedDifference(['B8', 'B4'])
    .rename('ndvi_' + name);
  return { image: sentinel2_filtered, ndvi: ndvi };
}
// Compute NDVI composites
var s2_t1 = getNDVI_s2('2019-10-01', '2020-03-25', '2020');
var s2_t2 = getNDVI_s2('2023-10-01', '2024-03-25', '2024');
// Create a multi-band image combining both NDVIs
var s2_RGBndvi = s2_t1.ndvi.addBands(s2_t2.ndvi).rename(['ndvi_2020', 'ndvi_2024']);
// Visualization parameters
var s2_ndviVisParams = { bands: ['ndvi_2020', 'ndvi_2024', 'ndvi_2024'], min: 0.4, max: 0.8 };
var s2_visParams = { bands: ['B4', 'B3', 'B2'], min: 250, max: 1500, gamma: 1 };
// Optionally display the layers on the map
Map.addLayer(s2_RGBndvi.clip(roi), s2_ndviVisParams, 'Sentinel NDVI 2020 vs 2024', false);
Map.addLayer(s2_t2.image.clip(roi), s2_visParams, 'Sentinel 2024', false);
Map.addLayer(s2_t1.image.clip(roi), s2_visParams, 'Sentinel 2020', false);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Global Mangrove Watch
var extent_raster = ee.ImageCollection("projects/earthengine-legacy/assets/projects/sat-io/open-datasets/GMW/extent/GMW_V3");
Map.addLayer(
  extent_raster.filterDate('1996-01-01','1996-12-31').first().clip(roi), 
  {"opacity":1,"bands":["b1"],"min":1,"max":1,"palette":["#40edb5"]}, 
  'mangrove 1996'
);
var raster_extent = ee.ImageCollection("projects/sat-io/open-datasets/GMW/annual-extent/GMW_MNG_2020");
Map.addLayer(
  raster_extent.median().clip(roi), 
  {"opacity":1,"bands":["b1"],"min":1,"max":1,"palette":["#258969"]}, 
  'mangrove 2020'
);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Google buildings
var feature = ee.FeatureCollection("GOOGLE/Research/open-buildings/v3/polygons")
              .filterBounds(roi);
var polygons = feature
    .map(function (f) { 
      return ee.Feature(f).set('geometry_type', ee.Feature(f).geometry().type()); 
    })
    .filter(ee.Filter.equals('geometry_type', 'Polygon'));
polygons = ee.FeatureCollection(polygons);
var imagex = ee.Image(0).paint(polygons, 255);
Map.addLayer(imagex.clip(roi).selfMask(), {palette: ['red']}, 'builtup');
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// DTM
var aw3d30 = ee.Image('JAXA/ALOS/AW3D30_V1_1');
var aw3d30Hillshade = ee.Terrain.hillshade(aw3d30.select('MED'), 315, 45);
var aw3d30Slope = ee.Terrain.slope(aw3d30.select('MED'));
// Load MERIT Hydro flow accumulation dataset
var meritHydro = ee.Image('MERIT/Hydro/v1_0_1');
var flowAccumulation = meritHydro.select('upa'); // 'upa' is the upstream area (flow accumulation)
var flowAccumulationClipped = flowAccumulation.clip(roi);
// TWI calculation
var slopeRadians = aw3d30Slope.multiply(Math.PI).divide(180);
var slopeCorrected = slopeRadians.updateMask(slopeRadians.gt(0)).rename('slope_corrected');
var twi = flowAccumulationClipped.divide(slopeCorrected.tan()).log().rename('TWI');
var twiMasked = twi.updateMask(twi.gt(3));
Map.addLayer(twiMasked.clip(roi), {min: 3, max: 15, palette: palettes.cmocean.Ice[7]}, 'TWI', false);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Add a label to the map
var label = ui.Label({
  value: 'Mangrove / Guatemala',
  style: {
    fontSize: '16px',
    fontWeight: 'bold',
    color: 'black',
    backgroundColor: 'white',
    padding: '10px',
    position: 'bottom-right'
  }
});
Map.add(label);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
var dataset = ee.ImageCollection('ESA/WorldCereal/2021/MODELS/v100')
// Function to mask the "other" class (value 0) in the images
function mask_other(img) {
  return img.updateMask(img.neq(0));
}
// Apply the mask_other function to the collection
dataset = dataset.map(mask_other);
// Visualization specifics for classification
var visualization_class = {
  bands: ['classification'],
  max: 100,
  palette: ['yellow']
};
// Function to filter, mosaic, clip, and select the 'classification' band
function getClassificationMosaic(productName) {
  return dataset
    .filter(ee.Filter.eq('product', productName))
    .mosaic()
    .clip(roi)
    .select('classification');
}
// Get global mosaics for each product
var temporarycrops = getClassificationMosaic('temporarycrops');
var maize = getClassificationMosaic('maize');
var wintercereals = getClassificationMosaic('wintercereals');
var springcereals = getClassificationMosaic('springcereals');
var irrigation = getClassificationMosaic('irrigation');
// Show global classification mosaics
//Map.addLayer(temporarycrops, visualization_class, 'temporary crops',false);
Map.addLayer(maize, visualization_class, 'sugarcane',false);
//Map.addLayer(wintercereals, visualization_class, 'wintercereals');
//Map.addLayer(springcereals, visualization_class, 'springcereals');
//Map.addLayer(irrigation, visualization_class, 'irrigation',false);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
var oil_palm_2019 = ee.ImageCollection("projects/sat-io/open-datasets/landcover/oil_palm_industrial_smallholder_2019");
var oil_palm = oil_palm_2019.mosaic().clip(roi).updateMask(oil_palm_2019.mosaic().neq(3))
Map.addLayer(oil_palm,{min:1,max:2,"palette":["ff6218","ff3ba7"]},'oil palm 2019',false)