ui.root.clear();
var panel = ui.Panel({style: {width: '560px'}});
var map = ui.Map();
ui.root.add(map).add(panel);
map.style().set('cursor', 'crosshair');
panel.add(ui.Label(
  'ILSM Visualization and Interactive Map',
  {fontWeight: 'bold', fontSize:'18px'}
));
// Add the logo to the control panel
// Upload a GeoTiff of the label and visualize it as RGB, then create a Thumbnail and add to the Panel
var logo = ee.Image('projects/ee-hydrosenselabs/assets/upload').visualize({
    bands:  ['b1','b2','b3'],
    min: 0,
    max: 255
    });
var thumb = ui.Thumbnail({
    image: logo,
    params: {
        dimensions: '1500x1500',
        format: 'png'
        },
    style: {height: '500px', width: '530px',padding :'0'}
    });
var toolPanel = ui.Panel(thumb, 'flow', {width: '550px'});
var image= ee.Image("projects/ee-nirdeshsharmanith1/assets/ILSM")  
var FeatureCollection =ee.FeatureCollection("projects/ee-hydrosenselabs/assets/ILSM_state")
var fc=FeatureCollection.map(function(feature){
  var l0 = ee.Number(feature.get('0'));
  var l1 = ee.Number(feature.get('1'));
  var l2 = ee.Number(feature.get('2'));
  var l3 = ee.Number(feature.get('3'));
  var l4 = ee.Number(feature.get('4'));
  return feature.set({ '01':l0.multiply(ee.Number(100)),'02':l1.multiply(ee.Number(100)),
  '03':l2.multiply(ee.Number(100)),'04':l3.multiply(ee.Number(100)),'05':l4.multiply(ee.Number(100))
  })
})
FeatureCollection=fc
var viz= { min:0,
max:4,
palette:['#2b83ba','#abdda4','#ffffbf','#fdae61','#d7191c']
}
map.addLayer(image,viz,'ILSM') // adding ilsm as background
var STYLE = {color: '000000', fillColor: '00000000', width: 0};
map.addLayer(FeatureCollection.style(STYLE))
map.setControlVisibility(false);
map.setControlVisibility({scaleControl: true, zoomControl: true});
map.style().set({cursor: 'crosshair'});
map.add(ui.Label(
    'Indian Landslide Susceptibility Map (ILSM) (100m)', {fontWeight: 'bold', fontSize: '24px'}));
// Set center to India at a zoom of 4.5
map.setCenter(78,23, 4.75);
function makeResultsBarChart(location) {
// Creates a bar chart by Features.
// The plotted features must be of same type
// The selected features can contain a feature of String type but it must be set as x property
  var chart = ui.Chart.feature.byFeature({features: location.select(['01','02','03','04','05','ST_NM']),
    xProperty: 'ST_NM'
  }).setSeriesNames(['Very Low','Low','Medium','High','Very High']);
  chart.setChartType('BarChart');
  chart.setOptions({
    title: 'Landslide Susceptibility Class',
    // vAxis: {title: 'Landslide susceptibility Category'},
    hAxis: {title: 'Percentage area susceptible to Landslides', minValue: 0,maxValue: 1}, //set min max values
    colors: ['#2b83ba','#abdda4','#ffffbf','#fdae61','#d7191c'],  });
  chart.style().set({stretch: 'both'});
  // print(chart);
  return chart
}
var chartPanel = ui.Panel({style: {position: 'bottom-left', width:'570px'}});
var chartIntro = ui.Label({value:"Click on a state to plot the category-wise distribution of landslide susceptibility ",
   style: {height: '30px',width:'530px' ,fontSize: '15px', color: 'ff0000'}
})
chartIntro.style().set({border: '2px solid darkgray'})
chartPanel.add(chartIntro)
map.onClick(function handleMapClick(coords){
  var lat = coords.lat
  var long = coords.lon
  var pointSelection = ee.Geometry.Point([long,lat])
  var selectedRegion = FeatureCollection.filterBounds(pointSelection)
  var selectedAOI = ui.Map.Layer(ee.Feature(selectedRegion.first()), {color: '8856a7', fillColor: '8856a7C0'}, 'User Selection');
  map.layers().set(2,selectedAOI);
  var chart = makeResultsBarChart(selectedRegion);
  var Copy=ui.Label('Source: Indian Landslide Susceptibility Map (ILSM, 100m), HydroSense Lab, IIT Delhi')
  chartPanel.clear().add(chart).add(Copy)
}
);
panel.add(chartPanel)
var credit = ui.Label('Developed by: ');
var lab=ui.Label('Hydrosense Lab, IIT-Delhi',{},'https://hydrosense.iitd.ac.in/');
var link1 = ui.Label('Prof. Manabendra Saharia', {},'mailto: msaharia@iitd.ac.in');
var link2 = ui.Label('Nirdesh Sharma', {},'mailto: nirdesh@civil.iitd.ac.in');
var c=ui.Label('Contact: ');
var panell = ui.Panel([c,link2,link1],ui.Panel.Layout.flow('horizontal'));
var panel1 = ui.Panel([credit,lab],ui.Panel.Layout.flow('horizontal'));
var paper= ui.Label('Citation: Sharma, N., Saharia, M., Ramana, G.V., 2023. "High resolution landslide susceptibility mapping using ensemble machine learning and geospatial big data", CATENA.')
var paper_panel=ui.Panel([paper])
var panel2=ui.Panel([panel1,panell],ui.Panel.Layout.flow('vertical'))
var Zenodo=ui.Label('Raw Data: ');
var zlink=ui.Label('Zenodo',{},'https://zenodo.org/records/10085272')
var zenodo_panel = ui.Panel([Zenodo,zlink],ui.Panel.Layout.flow('horizontal'));
panel.add(toolPanel);
panel.add(paper_panel);
panel.add(zenodo_panel)
panel.add(panel2);
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'top-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Landslide Class',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor:color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette =['#2b83ba','#abdda4','#ffffbf','#fdae61','#d7191c'];
// name of the legend
var names = ['Very Low','Low','Medium','High','Very High'];
// Add color and and names
for (var i = 0; i < 5; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)  
map.add(legend);