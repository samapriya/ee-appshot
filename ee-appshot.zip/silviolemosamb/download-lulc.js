var cities = ee.FeatureCollection('users/silviolemosamb/NE_PA');
// Import the dataset of land cover
//var landCover = ee.Image('USGS/NLCD/NLCD2016').select('landcover');b
// Import the dataset of city boundaries
//var cities = ee.FeatureCollection('users/seu_usuario/dataset/limites_cidades');
var landCover = ee.Image('projects/mapbiomas-workspace/public/collection_S2_beta/collection_LULC_S2_beta');
// Criar um seletor de cidades
var citySelector = ui.Select({
  items: cities.aggregate_array('NM_MUN').getInfo(),
  onChange: onCitySelect
});
// Criar um botão de download
var downloadButton = ui.Button({
  label: 'Download',
  onClick: downloadLandCover
});
// Criar um painel de controle
var controlPanel = ui.Panel({
  widgets: [
    ui.Label('Selecione uma cidade:'),
    citySelector,
    downloadButton
  ],
  layout: ui.Panel.Layout.flow('vertical'),
  style: {position: 'top-left'}
});
// Adicionar o painel de controle ao mapa
Map.add(controlPanel);
// Variável global para armazenar o uso do solo filtrado
var filteredLandCover;
// Definir a função de callback para a seleção da cidade
function onCitySelect(city) {
  var selectedCity = cities.filter(ee.Filter.eq('NM_MUN', city)).first();
  var roi = selectedCity.geometry();
  filteredLandCover = landCover.clip(roi);
  // Visualizar o uso do solo filtrado no mapa
  Map.layers().reset();
  //Map.addLayer(filteredLandCover, {}, 'Uso do Solo');
  Map.addLayer(filteredLandCover, {min: 0, max: 62}, 'Uso do Solo');
  Map.setOptions({stretch: 'None'});
}
// Definir a função de callback para o botão de download
function downloadLandCover() {
  if (filteredLandCover) {
    // Exportar o uso do solo filtrado para o Google Drive
    Export.image.toDrive({
      image: filteredLandCover,
      description: 'uso_do_solo_filtrado',
      scale: 10,
      region: filteredLandCover.geometry().bounds(),
      maxPixels: 1e13
    });
  } else {
    print('Nenhum uso do solo filtrado disponível para download.');
  }
}
// Definir o centro do mapa
Map.setCenter(-47.6488955, -2.0414464, 7);