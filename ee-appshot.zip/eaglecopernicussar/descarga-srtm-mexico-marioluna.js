var table = ui.import && ui.import("table", "table", {
      "id": "users/eaglecopernicussar/Division_Estatal_Mexico"
    }) || ee.FeatureCollection("users/eaglecopernicussar/Division_Estatal_Mexico");
// App para visualizar datos SRTM y descarga por drive de los 32 estados de la Republica Mexicana.
// 
var app_inspector = ui.Panel([ui.Label('')]);
var legend = ui.Panel({style: {position: 'bottom-left'}});
var descargar = ui.Panel({style: {position: 'bottom-center' }});
var sd_label33 =ui.Panel([ui.Label('')]);
var sd_label44 =ui.Panel([ui.Label('')]);
var sd_label55 =ui.Panel([ui.Label('')]);
var sd_label66 =ui.Panel([ui.Label('')]);
Map.setOptions("HYBRID");
////////////////////////////////////////////Dictionary Conversion Tool//////////////////////////////////////////////////////////////////////////////////////////////
var tools = require('users/fitoprincipe/geetools:tools');
////////////////////////////////////////////////Centro de la República Mexicana/////////////////////////////////////////////////////////////////////////////////////////////////////
Map.centerObject(table,5);
///////////////////////////////////////Diccionario de los Estados/////////////////////////////////////////////////////////////////////////////////////////////
var Diccionario_Estados = tools.featureCollection.toDictionary(table, {idField:'NOMBRE_EST'} ).getInfo();
/////////////////////////////////Función del objeto central del Estado////////////////////////////////////////////////////////////////////////////////////////
var centro_edo = function(estado){var object = table.filter(ee.Filter.eq('NOMBRE_EST', estado));
Map.centerObject(object);
Map.clear();
legend.clear();
sd_label33.clear();
sd_label44.clear();
sd_label55.clear();
descargar.clear();
Map.setOptions("HYBRID");
Map.addLayer(object.style({color:'black', width:3, fillColor:'00000000'}), {}, estado);
return object;};
////////////////////////////////////////////////Variables///////////////////////////////////////////////////////////////////////////////////////////////////////////
var moda      = {width:'250px',fontWeight: 'bold',color: 'blue',fontSize: '30',fontFamily: 'monospace',stretch: 'horizontal',border: "thick double #312D2C",backgroundColor: "yellow",margin: '0px 100px 30px 80px',};
/////////////////////////////////////////Seleccionar los Estados por diccionario//////////////////////////////////////////////////////////////////////////////
var seleccionar_edo = ui.Select({placeholder: 'Estado',items: Object.keys(Diccionario_Estados),
onChange: function(key) {centro_edo(key);
var SRTMDEM = ee.Image('USGS/SRTMGL1_003');
//print('Scale in meters:', SRTMDEM.projection().nominalScale());
var SRTM = SRTMDEM.select('elevation');
var elevationVis = {min: 0,max: 5610,palette: ['0602ff', '235cb1', '307ef3', '269db1', '30c8e2', '32d3ef', '3ae237','b5e22e', 'd6e21f', 'fff705', 'ffd611', 'ffb613', 'ff8b13', 'ff6e08','ff500d', 'ff0000', 'de0101', 'c21301'],};
//Map.addLayer(SRTM.clip(centro_departamento(key)), elevationVis, 'SRTM');
var dataset = ee.Image('JAXA/ALOS/AW3D30/V2_2');
var alos = dataset.select('AVE_DSM');
Map.addLayer(SRTM.clip(centro_edo(key)), elevationVis, 'SRTM');
//Map.addLayer(alos.clip(centro_departamento(key)), elevationVis, 'ALOS DSM')
var legend5 = ui.Panel({style: {position: 'bottom-right'}});
var label4 = ui.Label("Seleccione un Punto en el Mapa");
var inspector = ui.Panel([label4],ui.Panel.Layout.flow("horizontal"));
legend5.add(inspector);
Map.add(legend5);
function showElevation(elev){inspector.clear();
var titleLabel = ui.Label({value: "Elevación : ",style: {fontWeight: "bold",stretch: "vertical"}});
var elevationLabel = ui.Label(elev +' '+ 'm', {stretch: "vertical"});
var closeButton = ui.Button("Cerrar", function(){
inspector.clear();
inspector.style().set("shown",false);});
inspector.add(titleLabel);
inspector.add(elevationLabel);
inspector.add(closeButton);}
function inspect(coords){inspector.clear();
inspector.style().set("shown", true);
var pt = ee.Geometry.Point(coords.lon, coords.lat);
var elevation = SRTM.reduceRegion({reducer: ee.Reducer.first(),geometry: pt,scale: 30}).get("elevation");
elevation.evaluate(showElevation);
}
Map.onClick(inspect);
var data = {
'Aguascalientes'            : 'https://drive.google.com/u/0/uc?id=19_oSup-_01EuzZszuYrYRIJwNn9_NMkI&export=download',
'Baja California'           : 'https://drive.google.com/u/0/uc?id=1CdWhNaoZjWJze13ItGpOFdP3FQ2ZRI34&export=download',
'Baja California Sur'       : 'https://drive.google.com/u/0/uc?id=1t7wlZFrMyh9jTTR6tWgmXs4p9-Ejp2e0&export=download',
'Campeche'                  : 'https://drive.google.com/u/0/uc?id=1EsdlJ_n3IYxY6T5An6Rqvroab2FjahS4&export=download',
'Chiapas'                   : 'https://drive.google.com/u/0/uc?id=1kQeMmfXB5P6pWuDfcKiI17nlLMkuoe7b&export=download',
'Chihuahua'                 : 'https://drive.google.com/u/0/uc?id=10YNKYMEimW0HwuLLRCa7ITQej2fKjW_F&export=download',
'Ciudad de México'          : 'https://drive.google.com/u/0/uc?id=1_n02XzmJxVkAcJNPyeh_nKDcwznOMwLe&export=download',
'Coahuila de Zaragoza'      : 'https://drive.google.com/u/0/uc?id=1yO2wRr1celvkrEmsNOX2csPJUvJSS6na&export=download',
'Colima'                    : 'https://drive.google.com/u/0/uc?id=1XAsAHzN3rWTic5Vu7K6F15JevepDAxm3&export=download',
'Durango'                   : 'https://drive.google.com/u/0/uc?id=18KrVEJiigMis9kiXXwqyjav69ibf25KW&export=download',
'Estado de México'          : 'https://drive.google.com/u/0/uc?id=1bif9y8Ue4e0x0Jxp4WL4OO48qDu9Q8Zk&export=download',
'Guanajuato'                : 'https://drive.google.com/u/0/uc?id=1Ykl_oHqDqsDw_zIKubFzyHZ_nXG1dFGY&export=download',
'Guerrero'                  : 'https://drive.google.com/u/0/uc?id=1G-YOyhLpoCZpPLUDBn5wQ-Oxq5FT-RWe&export=download',
'Hidalgo'                   : 'https://drive.google.com/u/0/uc?id=1BYbD_xQ_q6m--FVDrm_Mb8XbNGIhasWu&export=download',
'Jalisco'                   : 'https://drive.google.com/u/0/uc?id=1NGkxdhcZFVlSSwzGW8BZ1GswuecmYKIA&export=download',
'Michoacán de Ocampo'       : 'https://drive.google.com/u/0/uc?id=11qQIIGkD1RodHxGa0RTRAQPZlTDQsrag&export=download',
'Morelos'                   : 'https://drive.google.com/u/0/uc?id=1Tz2Mnhy1b_aZO1Zo7vUBISv5q6Rlh0pM&export=download',
'Nayarit'                   : 'https://drive.google.com/u/0/uc?id=1QIN-L5A3aD7MqadkwWvblO6HVc8GvlGY&export=download',
'Nuevo León'                : 'https://drive.google.com/u/0/uc?id=1cADJM4MX-5fgFfu0cqutxt4PSYao4wK0&export=download',
'Oaxaca'                    : 'https://drive.google.com/u/0/uc?id=1vYFbCuPgW-5OE9FPsBNAnF59pJfPM3Tf&export=download',
'Puebla'                    : 'https://drive.google.com/u/0/uc?id=1z7KoMSokJ9hz06FAZ0fXMAf6qidnv2Y-&export=download',
'Querétaro'                 : 'https://drive.google.com/u/0/uc?id=1-q6MuDQ3Dvxf5Q2C_3l_TVG2gEHy0TV9&export=download',
'Quintana Roo'              : 'https://drive.google.com/u/0/uc?id=1wyBW1Wgj90vEra5k2IoDyTdCqQyDjKUc&export=download',
'San Luis Potosí'           : 'https://drive.google.com/u/0/uc?id=1Wyxd6fWxu_a-V8pC88fNCXwUlkEiYFTY&export=download',
'Sinaloa'                   : 'https://drive.google.com/u/0/uc?id=1aDaCWfXHmVMx8W15xX5lvSmEuBkVsyKS&export=download',
'Sonora'                    : 'https://drive.google.com/u/0/uc?id=1FV5uV9OZ9C59yoXDH6CGOa1sQhgMTquP&export=download',
'Tabasco'                   : 'https://drive.google.com/u/0/uc?id=1ysFTAx3q0230_UlL--p46Ciwc_BFfw9_&export=download',
'Tamaulipas'                : 'https://drive.google.com/u/0/uc?id=1vHFKcUjDsP8HykCzR7A8t_dNRJPTrKAP&export=download',
'Tlaxcala'                  : 'https://drive.google.com/u/0/uc?id=1Kya6LlUUQfQb5IZDrPY8Jg07E4ZmAeCN&export=download',
'Veracruz de Ignacio de la Llave': 'https://drive.google.com/u/0/uc?id=1RvzBiRqvnbM7Pv4CCkOThC0HJ64PizGl&export=download',
'Yucatán'                   : 'https://drive.google.com/u/0/uc?id=1KHCJ_E6oE3KffLxacQxfeyBeYC3fnU-8&export=download',
'Zacatecas'                 : 'https://drive.google.com/u/0/uc?id=1EdTsyOJT4pz_WmROLQNeDLS5WMsiE_vv&export=download',
};
var urlLabel = ui.Label('DESCARGAR', {shown: true});
urlLabel.setUrl(data[key]).style().set({
fontWeight: 'bold',
textAlign: 'center',
fontSize: '30',
color: "#fffb85",
margin: '30px 0px 0px 120px',
backgroundColor: "#fffb85",
border: "thick double #312D2C",
width: '150px', height: '30px',}).set({shown: true});
var panel = ui.Panel([urlLabel.setUrl(data[key])]);
var lon = ui.Label();
var lat = ui.Label();
Map.onClick(function(coords) {
app_inspector.clear();
var click_point = ee.Geometry.Point(coords.lon, coords.lat); 
var dot = ui.Map.Layer(click_point, {color: '#080808'},'PUNTO'); 
Map.layers().set(2, dot);
app_inspector.widgets().set(0, ui.Label({value: ['Latitud : ' + coords.lat.toFixed(3) +' y'+' Longitud : ' + coords.lon.toFixed(3)],
style:{textAlign: 'center',fontSize: '13px',fontWeight: 'bold' }}));});
var legend7 = ui.Panel({style: {position: 'bottom-left'}});
var Paleta = {min: 0, max: 5000, palette:['0602ff', '235cb1', '307ef3', '269db1', '30c8e2', '32d3ef', '3ae237','b5e22e', 'd6e21f', 'fff705', 'ffd611', 'ffb613', 'ff8b13', 'ff6e08','ff500d', 'ff0000', 'de0101', 'c21301']};
function makeColorBarParams(palette) {return {bbox: [0, 0, 1, 0.1],dimensions: '200x50',format: 'png',min: 0,max: 1,palette: palette,};}
var colorBar = ui.Thumbnail({image: ee.Image.pixelLonLat().select(0),params: makeColorBarParams(Paleta.palette),style: {stretch: 'horizontal',margin: '0px 70px',width: '270px', height: '20px'},});
var legendLabels = ui.Panel({widgets: [ui.Label('<'+' '+Paleta.min, {margin: '0px 0px 0px 57px' }),ui.Label(Paleta.max+' '+'>', {margin: '0px 0px 0px 240px'})],layout: ui.Panel.Layout.flow('horizontal')});
var legendTitle = ui.Label({value:'Elevación (m)',style: {textAlign: 'center',fontWeight: 'bold', fontSize: '14px', margin: '5px 150px',padding: '0' }});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
legend7.add(legendPanel);
Map.add(legend7);
descargar.add(panel);
var sd_label3 = ui.Label({value: '2. Descargar los datos SRTM:',style: {textAlign: 'center',fontWeight: 'bold',fontSize: '16px', margin: '0px 15px',color : 'black' }});
var sd_label4 = ui.Label({value: '3. Referencia:',style: {textAlign: 'center',fontWeight: 'bold',fontSize: '16px', margin: '20px 15px',color : 'black' }});
var sd_label5 = ui.Label('https://developers.google.com/earth'+'-'+'engine/datasets/catalog/USGS_SRTMGL1_003#description',{color: '#000000',fontSize: '12px', margin: '10px 0px 50px 12px',textAlign: 'justify', fontFamily: 'Agency FB'}).setUrl('https://developers.google.com/earth-engine/datasets/catalog/USGS_SRTMGL1_003#description');
sd_label33.add(sd_label3);
sd_label44.add(sd_label4);
sd_label55.add(sd_label5)}});
seleccionar_edo.style().set(moda);
////////////////////////////////////////////////Etiqueta para seleccionar el Estado////////////////////////////////////////////////////////////////////////////////////
var sd_label2 = ui.Label({value: '1. Seleccione el Estado:',style: {textAlign: 'center',fontWeight: 'bold',fontSize: '16px', margin: '30px 15px',color : 'black' }});
var sd_label3 = ui.Label({value: '2. Descargar los datos SRTM:'  ,style: {textAlign: 'center',fontWeight: 'bold',fontSize: '16px', margin: '0px 15px',color : 'black' }});
var sd_label4 = ui.Label({value: '3. Referencia:'                ,style: {textAlign: 'center',fontWeight: 'bold',fontSize: '16px', margin: '0px 15px',color : 'black' }});
//var sd_label =ui.Label({value: 'DESCARGA DE DATOS DEM',style: { fontWeight: 'bold',  fontSize: '30px', margin: '10px 65px', textAlign: 'center', color: '#58422b', fontFamily: 'Agency FB' }});
//var sd_tuto  =ui.Label({value: '→ TUTORIAL ←',style: { fontWeight: 'bold',  fontSize: '30px', margin: '10px 110px', textAlign: 'center', color: '#c21301', fontFamily: 'Agency FB' }}).setUrl('https://youtu.be/JOg85hAGx68');
var subtitulo = ui.Label({value: 'Esta app permite la búsqueda y descarga de los datos de elevación SRTM.', style: {  margin: '10px 15px', textAlign: 'justify', fontFamily: 'Agency FB',  fontSize: '20px' }});
var subtitulo2 = ui.Label({value: 'Los vectores de selección son a nivel Estatal sobre el territorio de la República Mexicana.', style: {  margin: '0px 50px', textAlign: 'justify', fontFamily: 'Agency FB',  fontSize: '20px' }});
//////////////////////////////////////////////Panel para seleccionar Estados//////////////////////////////////////////////////////////////////////////////////
var sd_panel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {width: '160px', border: '1px solid black',stretch: 'horizontal',backgroundColor: "#fffb85" }});
//////////////////////////////////////Panel dividido para seleccionar Estados//////////////////////////////////////////////////////////////////////
var split_panel1 = ui.SplitPanel({firstPanel: sd_panel,style: {width: '400px',height: '50px',stretch: 'horizontal',backgroundColor: "#fffb85" }});
//////////////////////////////////////////////Panel para mostrar los Estados y botones/////////////////////////////////////////////////////////////////////////
var ghsl_panel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {position: 'top-right',width: '400px', height: '600px'}});
//ghsl_panel.add(sd_label);
ghsl_panel.add(subtitulo);
ghsl_panel.add(subtitulo2);
//ghsl_panel.add(sd_tuto);
ghsl_panel.add(sd_label2);
ghsl_panel.add(seleccionar_edo);
ghsl_panel.add(sd_label33);
ghsl_panel.add(descargar);
ghsl_panel.add(sd_label44);
ghsl_panel.add(sd_label55);
//ghsl_panel.add(legend);
Map.style().set('cursor', 'crosshair');
ui.root.add(ghsl_panel);
//////Agregar leyenda al visor del mapa////
var TituloVisor = 
ui.Label(
          {
            value: 'MAPA PARA DESCARGAR MODELOS DIGITALES DE ELEVACIÓN', 
            style:{
                    position: 'top-center', 
                    fontWeight: 'bold',
                    fontSize: '15px', 
                    color: '#9D0C2C',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid black',
                  }  
          }       
        );
//Incorporar el titulo en el visor
Map.add(TituloVisor);