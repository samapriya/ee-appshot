// การโหลดขอบเขตประเทศและตัดเฉพาะขอบเขตของประเทศไทย
var WBD = ee.FeatureCollection('USDOS/LSIB/2017');
var setExtent = WBD.filterMetadata('COUNTRY_NA', 'equals', 'Thailand');
Map.addLayer(setExtent, {}, 'Thailand Boundary');
var chirps = ee.ImageCollection("UCSB-CHG/CHIRPS/PENTAD")
// การคำนวณปริมาณน้ำฝนรายปีในปี ค.ศ. 20220 ในพื้นที่ประเทศไทย
var P = chirps.select("precipitation").filterDate('2020-01-01', '2020-12-31').sum().clip(setExtent)
// การกำหนดรูปแบบการแสดงผลสี
var viz = {min:0, max:5500, palette:['ffffff','b7f0ae','21f600','0000FF','FDFF92','FF2700','d600ff']};
// การแสดงผลแผนที่และกำหนดจุดกึ่งกลางแผนที่
Map.setCenter(98.356624,13.094194, 6);
Map.addLayer(P, viz);
// การกำหนดตำแหน่ง Legend
var legend = ui.Panel({
style: {
position: 'bottom-left',
padding: '8px 15px'
}
});
// การสร้างป้าย Legend และรูปแบบ
var legendTitle = ui.Label({
value: 'Rainfall (mm)',
style: {
fontWeight: 'bold',
fontSize: '18px',
margin: '0 0 4px 0',
padding: '0'
}
});
// การเพิ่มชื่อ Legend ลงในแผนที่
legend.add(legendTitle);
// การสร้าง Legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// การสร้างป้ายค่าสูงสุดด้านบน
var panel = ui.Panel({
widgets: [
ui.Label(viz['max'])
],
});
legend.add(panel);
// การสร้าง thumbnail จากภาพ
var thumbnail = ui.Thumbnail({
image: legendImage,
params: {bbox:'0,0,10,100', dimensions:'10x200'},
style: {padding: '1px', position: 'bottom-center'}
});
// การเพิ่ม thumbnai ลงใน Legend
legend.add(thumbnail);
// การสร้างป้ายค่าต่ำสุดด้านล่าง
var panel = ui.Panel({
widgets: [
ui.Label(viz['min'])
],
});
// การเพิ่ม Legend ในแผนที่ 
legend.add(panel);
Map.add(legend);