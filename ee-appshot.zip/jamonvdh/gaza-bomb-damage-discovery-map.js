var table = ui.import && ui.import("table", "table", {
      "id": "USDOS/LSIB_SIMPLE/2017"
    }) || ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017");
/**
 * UI Pattern Template
 *  
 * This script is a template for organizing code into distinct sections
 * to improve readability/maintainability:
 *   Model, Components, Composition, Styling, Behaviors, Initialization
 * 
 * @author Tyler Erickson (tylere@google.com)
 */
/*******************************************************************************
 * Model *
 * 
 * A section to define information about the data being presented in your
 * app.
 * 
 * Guidelines: Use this section to import assets and define information that
 * are used to parameterize data-dependant widgets and control style and
 * behavior on UI interactions.
 ******************************************************************************/
// Create a JSON object for storing the data model.
var m = {};
m.col = ee.ImageCollection('COPERNICUS/S2_SR');
m.border = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017')
  .filter(ee.Filter.eq('wld_rgn', 'SW Asia'));
m.center = [34.46561, 31.5025, 13];
m.aoi = ee.Geometry.Polygon(
        [[[34.47094999824959, 31.648713206068717],
          [34.47094999824959, 31.5329045886949],
          [34.55884062324959, 31.5329045886949],
          [34.55884062324959, 31.648713206068717]]], null, false);
m.geomMatch = ee.Geometry.Polygon(
        [[[34.463617871852556, 31.554886812134058],
          [34.437697003932634, 31.52269979587873],
          [34.41314942702834, 31.497966780369573],
          [34.41126115188185, 31.477033732907508],
          [34.4220758186299, 31.45609600197358],
          [34.44525010451857, 31.450238456001294],
          [34.485075543971696, 31.483767951536706],
          [34.51236970290724, 31.50967553253873],
          [34.53434235915724, 31.51933414897511],
          [34.52593095168654, 31.553424006708987],
          [34.486620496364274, 31.565125807899726]]]);
m.firstPossibleDate = ee.Date('2021-05-05');
m.today = ee.Date('2021-05-16')//ee.Date(Date.now());
m.dates = [
  '2021-05-05',
  '2021-05-10',
  '2021-05-15',
];
m.visInfo = {
  'False Color: NIR, Red, Green': {
    bands: ['R', 'G', 'B'],
    min: 462 / 10000,
    max: 5552 / 10000,
    select: ['B8', 'B4', 'B3']
  },
  'False Color: SWIR1, NIR, Green': {
    bands: ['R', 'G', 'B'],
    min: 1183 / 10000,
    max: 4784 / 10000,
    select: ['B11', 'B8', 'B3']    
  },
  'True Color: Red, Green, Blue': {
    bands: ['R', 'G', 'B'],
    min: 441 / 10000,
    max: 3776 / 10000,
    select: ['B4', 'B3', 'B2']    
  },
};
/*******************************************************************************
* Components *
* 
* A section to define the widgets that will compose your app.
* 
* Guidelines:
* 1. Except for static text and constraints, accept default values;
*    initialize them in the initialization section.
* 2. Limit composition of widgets to those belonging to an inseparable unit
*    (i.e. a group of widgets that would make no sense out of order). 
******************************************************************************/
// Create a JSON object for storing UI components.
var c = {};
c.controlPanel = ui.Panel();
c.info = {};
c.info.title = ui.Label('Gaza bomb damage discovery map');
c.info.desc1 = ui.Label(
  'This app displays Sentinel-2 satellite images collected ' +
  'every five days during the May 2021 Israeli-Gaza Conflict. '+ 
  'Use the swipe tool to compare any two image dates, and pan '+
  'and zoom to investigate potential damage to cities, ' +
  'villages, farms, and trees. Damage is usually shown as '+
  'darkened or burned patches of land.');
c.info.desc2 = ui.Label(
  'Please send suggestions/comments to @JamonVDH');
c.info.links = ui.Label('Learn more about the bombing of Gaza');
c.info.link1 = ui.Label(
  'Israel-Gaza Conflict: What You Need to Know (NYTimes)',
  null, 'https://www.nytimes.com/article/israel-gaza-what-we-know.html');
c.info.link2 = ui.Label(
  'Gaza (Democracy Now)',
  null, 'https://www.democracynow.org/topics/gaza');  
c.info.link3 = ui.Label(
  'Israel-Palestine conflict (Al Jazeera)',
  null, 'https://www.aljazeera.com/israel-palestine-conflict');    
c.info.link4 = ui.Label(
  '2021 in the Israeli–Palestinian conflict (Wikipedia)',
  null, 'https://en.wikipedia.org/wiki/2021_in_the_Israeli%E2%80%93Palestinian_conflict');  
c.info.panel = ui.Panel([
  c.info.title,
  c.info.desc1,
  c.info.desc2,
  c.info.links,
  c.info.link1,
  c.info.link2,
  c.info.link3,
  // c.info.link4
]);
c.appLoadM1 = ui.Label('Fetching images, please wait ⚙️');
c.appLoadM2 = ui.Label('Fetching images, please wait ⚙️');
c.dateSelection = {};
c.dateSelection.title = ui.Label('Select dates to explore for damage');
c.dateSelection.warning = ui.Label('"From" date must be earlier than "To" date');
c.dateSelection.fromLabel = ui.Label('From:');
c.dateSelection.toLabel = ui.Label('To:');
c.dateSelection.fromSelector = ui.Select();
c.dateSelection.toSelector = ui.Select();
c.dateSelection.fromPanel = ui.Panel([
  c.dateSelection.fromLabel, c.dateSelection.fromSelector]);
c.dateSelection.toPanel = ui.Panel([
  c.dateSelection.toLabel, c.dateSelection.toSelector]);
c.dateSelection.panel = ui.Panel([
  c.dateSelection.title,
  c.dateSelection.warning,
  c.dateSelection.fromPanel,
  c.dateSelection.toPanel
]);
c.vizSelection = {};
c.vizSelection.title = ui.Label('Select image visualization (RGB)');
c.vizSelection.selector = ui.Select(
  Object.keys(m.visInfo), null, Object.keys(m.visInfo)[0]);
c.vizSelection.panel = ui.Panel([
  c.vizSelection.title, c.vizSelection.selector]);
c.transSelection = {};
c.transSelection.title = ui.Label('Adjust image overlay transparency');
c.transSelection.slider = ui.Slider(0, 1, 1, 0.1);
c.transSelection.panel = ui.Panel([
  c.transSelection.title, c.transSelection.slider]);
c.m1 = {};
c.m1.map = ui.Map();
c.m1.label = ui.Label();
c.m2 = {};
c.m2.map = ui.Map();
c.m2.label = ui.Label();
c.linker = ui.Map.Linker([c.m1.map, c.m2.map]);
c.split = ui.SplitPanel({
  firstPanel: c.m1.map,
  secondPanel: c.m2.map,
  orientation: 'horizontal',
  wipe: true
});
c.splitControl = ui.SplitPanel({
  firstPanel: c.controlPanel,
  secondPanel: ui.Panel(c.split),
  orientation: 'horizontal',
  wipe: false
});
c.dividers = {};
c.dividers.divider1 = ui.Panel();
c.dividers.divider2 = ui.Panel();
c.dividers.divider3 = ui.Panel();
/*******************************************************************************
* Composition *
* 
* A section to compose the app i.e. add child widgets and widget groups to
* first-level parent components like control panels and maps.
* 
* Guidelines: There is a gradient between components and composition. There
* are no hard guidelines here; use this section to help conceptually break up
* the composition of complicated apps with many widgets and widget groups.
******************************************************************************/
ui.root.clear();
c.m1.map.setCenter(m.center[0], m.center[1], m.center[2]);
c.m1.map.setOptions('SATELLITE');
c.m2.map.setOptions('SATELLITE');
c.m1.map.add(c.m1.label);
c.m2.map.add(c.m2.label);
c.controlPanel.add(c.info.panel);
c.controlPanel.add(c.dividers.divider1);
c.controlPanel.add(c.dateSelection.panel);
c.controlPanel.add(c.dividers.divider2);
c.controlPanel.add(c.vizSelection.panel);
c.controlPanel.add(c.dividers.divider3);
c.controlPanel.add(c.transSelection.panel);
c.m1.map.add(c.appLoadM1);
c.m2.map.add(c.appLoadM2);
ui.root.add(c.splitControl);
c.dateSelection.fromPanel.setLayout(ui.Panel.Layout.flow('horizontal'));
c.dateSelection.toPanel.setLayout(ui.Panel.Layout.flow('horizontal'));
/*******************************************************************************
* Styling *
* 
* A section to define and set widget style properties.
* 
* Guidelines:
* 1. At the top, define styles for widget "classes" i.e. styles that might be
*    applied to several widgets, like text styles or margin styles.
* 2. Set "inline" style properties for single-use styles.
* 3. You can add multiple styles to widgets, add "inline" style followed by
*    "class" styles. If multiple styles need to be set on the same widget, do
*    it consecutively to maintain order.
******************************************************************************/
// Create a JSON object for defining CSS-like class style properties.
var s = {};  
s.mapLabel = {
  fontSize: '26px',
  fontWeight: 'bold',
  shown: false
};
s.infoText = {
  fontSize: '14'
};
s.appLoad = {
  fontSize: '20px',
  fontWeight: 'bold'  
};
s.divider = {
  backgroundColor: 'F0F0F0',
  height: '4px',
  margin: '5px 8px'
};
s.fromTo = {
  width: '40px'
};
s.selectorTitle = {
  fontSize: '16px',
  fontWeight: 'bold'  
};
c.appLoadM1.style().set(s.appLoad);
c.appLoadM2.style().set(s.appLoad);
c.dateSelection.fromLabel.style().set(s.fromTo);
c.dateSelection.toLabel.style().set(s.fromTo);
c.dateSelection.title.style().set(s.selectorTitle);
c.vizSelection.title.style().set(s.selectorTitle);
c.transSelection.title.style().set(s.selectorTitle);
c.m1.label.style().set(s.mapLabel);
c.m1.label.style().set({position: 'top-left'});
c.m2.label.style().set(s.mapLabel);
c.m2.label.style().set({position: 'top-right'});
c.controlPanel.style().set({
  maxWidth: '360px'
});
c.info.title.style().set({
  fontSize: '20px',
  fontWeight: 'bold',
  whiteSpace: 'pre'
});
c.info.desc1.style().set(s.infoText);
c.info.desc2.style().set(s.infoText);
c.info.links.style().set({
  fontSize: '16px',
  fontWeight: 'bold' 
});
c.info.link1.style().set(s.infoText);
c.dateSelection.warning.style().set({
  shown: false,
  color: 'red',
  fontWeight: 'bold'
});
c.transSelection.slider.style().set({stretch: 'horizontal'});
// Loop through setting divider style.
Object.keys(c.dividers).forEach(function(key) {
  c.dividers[key].style().set(s.divider);
});
/*******************************************************************************
* Behaviors *
* 
* A section to define app behavior on UI activity.
* 
* Guidelines:
* 1. At the top, define helper functions and functions that will be used as
*    callbacks for multiple events.
* 2. For single-use callbacks, define them just prior to assignment. If multiple
*    callbacks are required for a widget, add them consecutively to maintain
*    order; single-use followed by multi-use.
* 3. As much as possible, include callbacks that update URL parameters.
******************************************************************************/
function lookup(sourceHist, targetHist) {
  var sourceValues = sourceHist.slice(1, 0, 1).project([0]);
  var sourceCounts = sourceHist.slice(1, 1, 2).project([0]);
  sourceCounts = sourceCounts.divide(sourceCounts.get([-1]));
  var targetValues = targetHist.slice(1, 0, 1).project([0]);
  var targetCounts = targetHist.slice(1, 1, 2).project([0]);
  targetCounts = targetCounts.divide(targetCounts.get([-1]));
  var lu = sourceCounts.toList().map(function(n) {
    var index = targetCounts.gte(n).argmax();
    return targetValues.get(index);
  });
  return {x: sourceValues.toList(), y: lu};
}
function histogramMatch(sourceImg, targetImg, geom) {
  var args = {
    reducer: ee.Reducer.autoHistogram({maxBuckets: 256, cumulative: true}), 
    geometry: geom,
    scale: 20,
    maxPixels: 65536 * 4 - 1,
    bestEffort: true
  };
  var source = sourceImg.reduceRegion(args);
  var target = targetImg.updateMask(sourceImg.mask()).reduceRegion(args);
  return ee.Image.cat(
    sourceImg.select(['R']).interpolate(lookup(source.getArray('R'), target.getArray('R'))),
    sourceImg.select(['G']).interpolate(lookup(source.getArray('G'), target.getArray('G'))),
    sourceImg.select(['B']).interpolate(lookup(source.getArray('B'), target.getArray('B')))
  );
}
function addDate(img) {
  return img.set('date', img.date().format('YYYY-MM-dd'));
}
function mosaicImgs(col, date) {
  return col.filter(ee.Filter.eq('date', date))
    // .map(maskS2clouds)
    .map(function(img){return img.divide(10000)}) // must be commented out if using cloud mask
    .median();
}
function maskS2clouds(img) {
  var qa = img.select('QA60');
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return img.updateMask(mask).divide(10000);
}
function getCol(aoi, startDate, endDate) {
  return m.col
    .filterBounds(aoi)
    .filterDate(startDate, endDate)
    .map(addDate);
}
function init() {
  // Get the collection.
  var col = getCol(m.aoi, m.firstPossibleDate, m.today);
  // Get widget values.  
  var dateFrom = c.dateSelection.fromSelector.getValue();
  var dateTo = c.dateSelection.toSelector.getValue();
  var vizBands = c.vizSelection.selector.getValue();
  // Make sure the dates selected are in proper order.
  var dateFromJs = new Date(dateFrom);
  var dateToJs = new Date(dateTo);
  if(dateFromJs >= dateToJs) {
    c.dateSelection.warning.style().set({shown: true});
    c.m1.map.layers().reset();
    c.m2.map.layers().reset();
    c.m1.label.style().set({shown: false});
    c.m2.label.style().set({shown: false});
    return null;
  } else {
    c.dateSelection.warning.style().set({shown: false});
    c.m1.label.style().set({shown: true});
    c.m2.label.style().set({shown: true});
  }
  // Set image date labels.
  c.m1.label.setValue(dateFrom);
  c.m2.label.setValue(dateTo);
  // Viz images
  var t1 = mosaicImgs(col, dateFrom).clipToCollection(m.border);
  var t2 = mosaicImgs(col, dateTo).clipToCollection(m.border);
  var t2viz = histogramMatch(t2.select(m.visInfo[vizBands].select, ['R', 'G', 'B']),
                      t1.select(m.visInfo[vizBands].select, ['R', 'G', 'B']),
                      m.geomMatch);
  // Map layers.
  var t1l = ui.Map.Layer(t1.select(m.visInfo[vizBands].select, ['R', 'G', 'B']),
                        m.visInfo[vizBands],
                        dateFrom);
  var t2l = ui.Map.Layer(t2viz,
                        m.visInfo[vizBands],
                        dateTo);
  // Add layers.
  c.m1.map.layers().set(0, t1l);
  c.m2.map.layers().set(0, t2l);
}
c.dateSelection.fromSelector.onChange(init);
c.dateSelection.toSelector.onChange(init);
c.vizSelection.selector.onChange(init);
function updateTrans(value) {
  if (c.m1.map.layers().length() === 0) {
    return null;
  }
  c.m1.map.layers().get(0).setOpacity(value);
  c.m2.map.layers().get(0).setOpacity(value);
}
c.transSelection.slider.onChange(updateTrans);
/*******************************************************************************
* Initialize *
* 
* A section to initialize the app state on load.
* 
* Guidelines:
* 1. At the top, define any helper functions.
* 2. As much as possible, use URL params to initial the state of the app.
******************************************************************************/
// Get possible dates to show.
var dates = getCol(m.aoi, m.firstPossibleDate, m.today)
  .aggregate_array('date').distinct();
var possibleDates = ee.List(dates);
// Initialize the date selectors - set defaults.
possibleDates.evaluate(function(dates) {
  c.dateSelection.fromSelector.items().reset(dates);
  c.dateSelection.toSelector.items().reset(dates);
  c.dateSelection.fromSelector.setValue(dates[0], false);
  c.dateSelection.toSelector.setValue(dates[dates.length - 1], false);
  c.appLoadM1.style().set({shown: false});
  c.appLoadM2.style().set({shown: false});
  c.m1.label.style().set({shown: true});
  c.m2.label.style().set({shown: true});
  init();
});