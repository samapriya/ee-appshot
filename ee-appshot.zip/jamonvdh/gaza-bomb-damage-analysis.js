/**
 * UI Pattern Template
 *  
 * This script is a template for organizing code into distinct sections
 * to improve readability/maintainability:
 *   Model, Components, Composition, Styling, Behaviors, Initialization
 * 
 * @author Tyler Erickson (tylere@google.com)
 */
/*******************************************************************************
 * Model *
 * 
 * A section to define information about the data being presented in your
 * app.
 * 
 * Guidelines: Use this section to import assets and define information that
 * are used to parameterize data-dependant widgets and control style and
 * behavior on UI interactions.
 ******************************************************************************/
// Create a JSON object for storing the data model.
var m = {};
m.col = ee.ImageCollection("COPERNICUS/S2_SR");
m.border = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017')
  .filter(ee.Filter.eq('wld_rgn', 'SW Asia'));
m.gaza = ee.Geometry.Polygon(
        [[[34.21935515324325, 31.32269497267563],
          [34.23562771426215, 31.29665560177895],
          [34.23975258804688, 31.296026767726513],
          [34.26754908482284, 31.219659174618755],
          [34.29122213710785, 31.240606197860878],
          [34.317310584511546, 31.25173790334159],
          [34.326235987611945, 31.25729055346795],
          [34.335157121998286, 31.266296259045895],
          [34.34304991592656, 31.279025091569924],
          [34.36743222929172, 31.29068547730294],
          [34.37363581577987, 31.30637960989639],
          [34.36488192593415, 31.36454203701245],
          [34.367112812636115, 31.369638776604155],
          [34.370545910994714, 31.369572150810548],
          [34.38086721178947, 31.389854550959054],
          [34.402870285851975, 31.411745608894886],
          [34.404875370167716, 31.412940351152248],
          [34.406708819510065, 31.413036300331587],
          [34.40920312419706, 31.415501575376823],
          [34.41152584519684, 31.41606232819063],
          [34.41299561791797, 31.417330311582106],
          [34.41340867618908, 31.418568572379353],
          [34.415195060523374, 31.420319547579375],
          [34.4168795988006, 31.421184637592646],
          [34.422190065876485, 31.424694499866142],
          [34.424325030700615, 31.427032364045346],
          [34.42662095365241, 31.42760654404116],
          [34.43181422021999, 31.4329293814436],
          [34.43239410540938, 31.434656966275963],
          [34.43486234335601, 31.43770273665168],
          [34.43769545890269, 31.441023048879252],
          [34.43975621809974, 31.44229289654186],
          [34.44598525371249, 31.444139519191108],
          [34.453553593266555, 31.452738758554116],
          [34.46457454863303, 31.461735306773882],
          [34.47632346190598, 31.474748960006334],
          [34.47994401027773, 31.477942666915],
          [34.4863114130441, 31.48077021676502],
          [34.50582980950698, 31.496378549544158],
          [34.51216654698104, 31.500220848619627],
          [34.525798646361764, 31.502803133936503],
          [34.531285186722194, 31.50658139401568],
          [34.53805963978471, 31.509700762811494],
          [34.54696153849648, 31.51200578571798],
          [34.55927800112738, 31.528321611776413],
          [34.56468754829819, 31.53227090395549],
          [34.5676131717369, 31.540755171972982],
          [34.491095112960046, 31.593079873324726],
          [34.48235453098449, 31.581161642870356],
          [34.472843734817346, 31.569389007729406],
          [34.4684324968994, 31.56289905792501],
          [34.46558338836874, 31.55972714514737],
          [34.463077774185244, 31.55692085573135],
          [34.46133405861859, 31.55407796179687],
          [34.459590449319165, 31.551600727928346],
          [34.456924288063874, 31.54890404512977],
          [34.454065173341455, 31.54582329915284],
          [34.44981675550381, 31.540905874835268],
          [34.44537565151977, 31.536317436565188],
          [34.43675233675375, 31.527067014625896],
          [34.421204512250014, 31.510683071013545],
          [34.418316098687285, 31.50718591632871],
          [34.41517046162417, 31.503249637631974],
          [34.41169859926649, 31.500238573129213],
          [34.40865605868821, 31.497300640352204],
          [34.40351554861324, 31.492083271231333],
          [34.37888103577709, 31.465711146048108],
          [34.34743723731043, 31.434531283353255],
          [34.33613035756526, 31.42312010389353],
          [34.32192191981823, 31.410764817253675],
          [34.30808201029553, 31.39890242431453],
          [34.30344685406234, 31.396879691349824],
          [34.29761048176245, 31.391486604146266],
          [34.28222044221365, 31.377054933633417],
          [34.27607790172272, 31.371000911268148],
          [34.26959282247655, 31.36538627999724],
          [34.255809868646615, 31.3529831983788],
          [34.237987314817936, 31.338115276564835],
          [34.228734882808176, 31.330277164886585]]])
// m.gaza = ee.Geometry.Polygon(
//         [[[34.21909766117782, 31.32313489837656],
//           [34.23562771426215, 31.29665560177895],
//           [34.23975258804688, 31.296026767726513],
//           [34.26754908482284, 31.219659174618755],
//           [34.29122213710785, 31.240606197860878],
//           [34.317310584511546, 31.25173790334159],
//           [34.326235987611945, 31.25729055346795],
//           [34.335157121998286, 31.266296259045895],
//           [34.34304991592656, 31.279025091569924],
//           [34.36743222929172, 31.29068547730294],
//           [34.37363581577987, 31.30637960989639],
//           [34.36488192593415, 31.36454203701245],
//           [34.367112812636115, 31.369638776604155],
//           [34.370545910994714, 31.369572150810548],
//           [34.38086721178947, 31.389854550959054],
//           [34.402870285851975, 31.411745608894886],
//           [34.404875370167716, 31.412940351152248],
//           [34.406708819510065, 31.413036300331587],
//           [34.40920312419706, 31.415501575376823],
//           [34.41152584519684, 31.41606232819063],
//           [34.41299561791797, 31.417330311582106],
//           [34.41340867618908, 31.418568572379353],
//           [34.415195060523374, 31.420319547579375],
//           [34.4168795988006, 31.421184637592646],
//           [34.422190065876485, 31.424694499866142],
//           [34.424325030700615, 31.427032364045346],
//           [34.42662095365241, 31.42760654404116],
//           [34.43181422021999, 31.4329293814436],
//           [34.43239410540938, 31.434656966275963],
//           [34.43486234335601, 31.43770273665168],
//           [34.43769545890269, 31.441023048879252],
//           [34.43975621809974, 31.44229289654186],
//           [34.44598525371249, 31.444139519191108],
//           [34.453553593266555, 31.452738758554116],
//           [34.46457454863303, 31.461735306773882],
//           [34.47632346190598, 31.474748960006334],
//           [34.47994401027773, 31.477942666915],
//           [34.4863114130441, 31.48077021676502],
//           [34.50582980950698, 31.496378549544158],
//           [34.51216654698104, 31.500220848619627],
//           [34.525798646361764, 31.502803133936503],
//           [34.531285186722194, 31.50658139401568],
//           [34.53805963978471, 31.509700762811494],
//           [34.54696153849648, 31.51200578571798],
//           [34.55927800112738, 31.528321611776413],
//           [34.56468754829819, 31.53227090395549],
//           [34.5676131717369, 31.540755171972982],
//           [34.490408467452234, 31.593445421310218],
//           [34.481667885476675, 31.58167347511095],
//           [34.47250041206344, 31.569900904611053],
//           [34.46783168208007, 31.5634841234183],
//           [34.46515423492636, 31.560165959533744],
//           [34.46247695936591, 31.557505958722643],
//           [34.45898963449983, 31.55225900607107],
//           [34.45365747757119, 31.546463331477746],
//           [34.444967955749505, 31.536939245630883],
//           [34.43580819918051, 31.527487692293946],
//           [34.42077535880763, 31.510975767872118],
//           [34.41771528386795, 31.50769815439563],
//           [34.41422632405093, 31.50383507698815],
//           [34.41144110720106, 31.500750849264957],
//           [34.40857022799973, 31.497812932584456],
//           [34.40351554861324, 31.492888345536397],
//           [34.37819439026928, 31.46651644727949],
//           [34.347179745245, 31.43504391916788],
//           [34.33587286549983, 31.4238525290501],
//           [34.321578597064324, 31.411570590737988],
//           [34.30773868754162, 31.3994885161585],
//           [34.2977821431394, 31.39214600929813],
//           [34.28187711945974, 31.377567883518324],
//           [34.26959282247655, 31.36538627999724],
//           [34.25546654589271, 31.353789467685456],
//           [34.23755816137555, 31.338628438935938],
//           [34.2286490521197, 31.33101031419215]]]);
m.center = [34.46561, 31.5025, 13];
m.aoi = ee.Geometry.Polygon(
        [[[34.47094999824959, 31.648713206068717],
          [34.47094999824959, 31.5329045886949],
          [34.55884062324959, 31.5329045886949],
          [34.55884062324959, 31.648713206068717]]], null, false);
m.geomMatch = ee.Geometry.Polygon(
        [[[34.463617871852556, 31.554886812134058],
          [34.437697003932634, 31.52269979587873],
          [34.41314942702834, 31.497966780369573],
          [34.41126115188185, 31.477033732907508],
          [34.4220758186299, 31.45609600197358],
          [34.44525010451857, 31.450238456001294],
          [34.485075543971696, 31.483767951536706],
          [34.51236970290724, 31.50967553253873],
          [34.53434235915724, 31.51933414897511],
          [34.52593095168654, 31.553424006708987],
          [34.486620496364274, 31.565125807899726]]]);
m.firstPossibleDate = ee.Date('2021-05-05');
m.today = ee.Date('2021-05-16')//ee.Date(Date.now());
m.metrics = ['NDVI', 'NBR'];
m.thresh = {
  min: 0,
  max: 0.3,
  step: 0.02,
  value: 0.12
};
m.mmu = {
  min: 0,
  max: 2000,
  step: 100,
  value: 300
};
m.maxmu = {
  min: 1000,
  max: 50000,
  step: 1000,
  value: 50000
};
m.visInfo = {
  'False Color: NIR, Red, Green': {
    bands: ['R', 'G', 'B'],
    min: 462 / 10000,
    max: 5552 / 10000,
    select: ['B8', 'B4', 'B3']
  },
  'False Color: SWIR1, NIR, Green': {
    bands: ['R', 'G', 'B'],
    min: 1183 / 10000,
    max: 4784 / 10000,
    select: ['B11', 'B8', 'B3']    
  },
  'True Color: Red, Green, Blue': {
    bands: ['R', 'G', 'B'],
    min: 441 / 10000,
    max: 3776 / 10000,
    select: ['B4', 'B3', 'B2']    
  },
};
m.changeComp = {
  min: -0.1,
  max: 0.7
};
m.allbands = ['B11', 'B8', 'B3', 'B4', 'NDVI', 'NBR'];
/*******************************************************************************
* Components *
* 
* A section to define the widgets that will compose your app.
* 
* Guidelines:
* 1. Except for static text and constraints, accept default values;
*    initialize them in the initialization section.
* 2. Limit composition of widgets to those belonging to an inseparable unit
*    (i.e. a group of widgets that would make no sense out of order). 
******************************************************************************/
// Create a JSON object for storing UI components.
var c = {};
c.controlPanel = ui.Panel();
c.info = {};
c.info.title = ui.Label('Gaza bomb damage analysis');
c.info.desc = ui.Label(
  'This app helps you detect, visualize, and document sites of prominent landscape change in Gaza during the May 2021 Israeli-Gaza Conflict. '+ 
  'Detected changes could result from bomb damage or agricultural land use and require external verification.')
c.info.desc2 = ui.Label(  
  'To detect prominent change sites, select any two Sentinel-2 image dates, a vegetation metric (NDVI or NBR), '+
  'a change threshold (default: -0.12), and minimum and maximum change patch sizes (default: 300 m² and 50,000 m²). ' )
c.info.desc3 = ui.Label(    
  'Sites that meet your change threshold criteria are shown in orange on the map. Detected sites that meet your '+
  'size criteria are shown as purple dots. Click "Download CSV" below to export the locations and areas of detected sites.');
c.info.desc4 = ui.Label(
  'Please send suggestions/comments to @JamonVDH');
c.info.links = ui.Label('Learn more about the conflict (ANY BETTER/MORE LINKS?)');
c.info.links = ui.Label('Learn more about the conflict');
c.info.link1 = ui.Label(
  'Israel-Gaza violence: The conflict explained (BBC)',
  null, 'https://www.bbc.com/news/newsbeat-44124396');
c.info.panel = ui.Panel([
  c.info.title,
  c.info.desc,
  c.info.desc2,
  c.info.desc3,
  c.info.desc4
]);
c.appLoadM1 = ui.Label('Fetching images, please wait ⚙️');
c.dateSelection = {};
c.dateSelection.title = ui.Label('Select change period');
c.dateSelection.warning = ui.Label('"From" date must be earlier than "To" date');
c.dateSelection.fromLabel = ui.Label('From:');
c.dateSelection.toLabel = ui.Label('To:');
c.dateSelection.fromSelector = ui.Select();
c.dateSelection.toSelector = ui.Select();
c.dateSelection.fromPanel = ui.Panel([
  c.dateSelection.fromLabel, c.dateSelection.fromSelector]);
c.dateSelection.toPanel = ui.Panel([
  c.dateSelection.toLabel, c.dateSelection.toSelector]);
c.dateSelection.panel = ui.Panel([
  c.dateSelection.warning,
  c.dateSelection.title,
  c.dateSelection.fromPanel,
  c.dateSelection.toPanel
]);
c.metricSelection = {};
c.metricSelection.title = ui.Label('Select metric for change');
// c.metricSelection.desc1 = ui.Label('NDVI: Normalized Difference Vegetation Index')
// c.metricSelection.desc2 = ui.Label('NBR: Normalized Burn Ratio')
c.metricSelection.selector = ui.Select(m.metrics, null, m.metrics[0]);
c.metricSelection.panel = ui.Panel([
  c.metricSelection.title, c.metricSelection.selector]);
c.threshSelection = {};
c.threshSelection.title = ui.Label('Select change threshold (metric loss)');
c.threshSelection.selector = ui.Slider(m.thresh);
c.threshSelection.panel = ui.Panel([
  c.threshSelection.title, c.threshSelection.selector]);
c.mmuSelection = {};
c.mmuSelection.title = ui.Label('Select minimum change patch size (m²)');
c.mmuSelection.warning = ui.Label('Minimum patch size must be smaller than maximum patch size');
c.mmuSelection.selector = ui.Slider(m.mmu);
c.mmuSelection.panel = ui.Panel([
    c.mmuSelection.warning,c.mmuSelection.title, c.mmuSelection.selector]);
c.maxmuSelection = {};
c.maxmuSelection.title = ui.Label('Select maximum change patch size (m²)');
c.maxmuSelection.warning = ui.Label('Maximum patch size must be smaller than minimum patch size');
c.maxmuSelection.selector = ui.Slider(m.maxmu);
c.maxmuSelection.panel = ui.Panel([
  c.maxmuSelection.warning,c.maxmuSelection.title, c.maxmuSelection.selector]);
c.vizSelection = {};
c.vizSelection.title = ui.Label('Select image visualization (RGB)');
c.vizSelection.selector = ui.Select(
  Object.keys(m.visInfo), null, Object.keys(m.visInfo)[0]);
c.vizSelection.panel = ui.Panel([
  c.vizSelection.title, c.vizSelection.selector]);
c.urlPanel = ui.Panel();
c.m1 = {};
c.m1.map = ui.Map();
c.splitControl = ui.SplitPanel({
  firstPanel: c.controlPanel,
  secondPanel: c.m1.map,
  orientation: 'horizontal',
  wipe: false
});
c.dividers = {};
c.dividers.divider1 = ui.Panel();
c.dividers.divider2 = ui.Panel();
c.dividers.divider3 = ui.Panel();
c.dividers.divider4 = ui.Panel();
c.dividers.divider5 = ui.Panel();
c.dividers.divider6 = ui.Panel();
/*******************************************************************************
* Composition *
* 
* A section to compose the app i.e. add child widgets and widget groups to
* first-level parent components like control panels and maps.
* 
* Guidelines: There is a gradient between components and composition. There
* are no hard guidelines here; use this section to help conceptually break up
* the composition of complicated apps with many widgets and widget groups.
******************************************************************************/
ui.root.clear();
// c.m1.map.setCenter(m.center[0], m.center[1], m.center[2]);
// print(m.center[0], m.center[1], m.center[2])
c.m1.map.setCenter(34.46561, 31.5025, 13);
c.m1.map.setOptions('SATELLITE');
c.controlPanel.add(c.info.panel);
c.controlPanel.add(c.dividers.divider1);
c.controlPanel.add(c.dateSelection.panel);
c.controlPanel.add(c.dividers.divider2);
c.controlPanel.add(c.metricSelection.panel);
c.controlPanel.add(c.dividers.divider3);
c.controlPanel.add(c.threshSelection.panel);
c.controlPanel.add(c.dividers.divider4);
c.controlPanel.add(c.mmuSelection.panel);
c.controlPanel.add(c.maxmuSelection.panel);
c.controlPanel.add(c.dividers.divider5);
c.controlPanel.add(c.vizSelection.panel);
c.controlPanel.add(c.dividers.divider6);
c.controlPanel.add(c.urlPanel);
// c.m1.map.add(c.controlPanel);
c.m1.map.add(c.appLoadM1);
ui.root.add(c.splitControl);
c.dateSelection.fromPanel.setLayout(ui.Panel.Layout.flow('horizontal'));
c.dateSelection.toPanel.setLayout(ui.Panel.Layout.flow('horizontal'));
/*******************************************************************************
* Styling *
* 
* A section to define and set widget style properties.
* 
* Guidelines:
* 1. At the top, define styles for widget "classes" i.e. styles that might be
*    applied to several widgets, like text styles or margin styles.
* 2. Set "inline" style properties for single-use styles.
* 3. You can add multiple styles to widgets, add "inline" style followed by
*    "class" styles. If multiple styles need to be set on the same widget, do
*    it consecutively to maintain order.
******************************************************************************/
// Create a JSON object for defining CSS-like class style properties.
var s = {};  
s.mapLabel = {
  fontSize: '26px',
  fontWeight: 'bold',
  shown: false
};
s.infoText = {
  fontSize: '14'
};
s.appLoad = {
  fontSize: '20px',
  fontWeight: 'bold'  
};
s.divider = {
  backgroundColor: 'F0F0F0',
  height: '4px',
  margin: '5px -8px'
};
s.fromTo = {
  width: '40px'
};
s.selectorTitle = {
  fontSize: '16px',
  fontWeight: 'bold'  
};
c.appLoadM1.style().set(s.appLoad);
c.dateSelection.fromLabel.style().set(s.fromTo);
c.dateSelection.toLabel.style().set(s.fromTo);
c.dateSelection.title.style().set(s.selectorTitle);
c.metricSelection.title.style().set(s.selectorTitle);
c.threshSelection.title.style().set(s.selectorTitle);
c.mmuSelection.title.style().set(s.selectorTitle);
c.maxmuSelection.title.style().set(s.selectorTitle);
c.vizSelection.title.style().set(s.selectorTitle);
c.threshSelection.selector.style().set({stretch: 'horizontal'});
c.mmuSelection.selector.style().set({stretch: 'horizontal'});
c.maxmuSelection.selector.style().set({stretch: 'horizontal'});
c.controlPanel.style().set({
  // position: 'bottom-left',
  maxWidth: '360px'
});
c.info.title.style().set({
  fontSize: '20px',
  fontWeight: 'bold',
  whiteSpace: 'pre'
});
c.info.desc.style().set(s.infoText);
c.info.links.style().set({
  fontSize: '16px',
  fontWeight: 'bold' 
});
c.info.link1.style().set(s.infoText);
c.dateSelection.warning.style().set({
  shown: false,
  color: 'red',
  fontWeight: 'bold'
});
c.mmuSelection.warning.style().set({
  shown: false,
  color: 'red',
  fontWeight: 'bold'
});
c.maxmuSelection.warning.style().set({
  shown: false,
  color: 'red',
  fontWeight: 'bold'
});
// Loop through setting divider style.
Object.keys(c.dividers).forEach(function(key) {
  c.dividers[key].style().set(s.divider);
});
/*******************************************************************************
* Behaviors *
* 
* A section to define app behavior on UI activity.
* 
* Guidelines:
* 1. At the top, define helper functions and functions that will be used as
*    callbacks for multiple events.
* 2. For single-use callbacks, define them just prior to assignment. If multiple
*    callbacks are required for a widget, add them consecutively to maintain
*    order; single-use followed by multi-use.
* 3. As much as possible, include callbacks that update URL parameters.
******************************************************************************/
function lookup(sourceHist, targetHist) {
  var sourceValues = sourceHist.slice(1, 0, 1).project([0]);
  var sourceCounts = sourceHist.slice(1, 1, 2).project([0]);
  sourceCounts = sourceCounts.divide(sourceCounts.get([-1]));
  var targetValues = targetHist.slice(1, 0, 1).project([0]);
  var targetCounts = targetHist.slice(1, 1, 2).project([0]);
  targetCounts = targetCounts.divide(targetCounts.get([-1]));
  var lu = sourceCounts.toList().map(function(n) {
    var index = targetCounts.gte(n).argmax();
    return targetValues.get(index);
  });
  return {x: sourceValues.toList(), y: lu};
}
function histogramMatch(sourceImg, targetImg, geom) {
  var args = {
    reducer: ee.Reducer.autoHistogram({maxBuckets: 256, cumulative: true}), 
    geometry: geom,
    scale: 20,
    maxPixels: 65536 * 4 - 1,
    bestEffort: true
  };
  var source = sourceImg.reduceRegion(args);
  var target = targetImg.updateMask(sourceImg.mask()).reduceRegion(args);
  return ee.Image.cat(
    sourceImg.select(['R']).interpolate(lookup(source.getArray('R'), target.getArray('R'))),
    sourceImg.select(['G']).interpolate(lookup(source.getArray('G'), target.getArray('G'))),
    sourceImg.select(['B']).interpolate(lookup(source.getArray('B'), target.getArray('B')))
  );
}
function addDate(img) {
  return img.set('date', img.date().format('YYYY-MM-dd'));
}
function mosaicImgs(col, date) {
  return col.filter(ee.Filter.eq('date', date))
    .map(maskS2clouds)
    .map(addMetrics)
    .select(m.allbands)
    .median();
}
function maskS2clouds(img) {
  var qa = img.select('QA60');
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return img.updateMask(mask).divide(10000);
}
function addMetrics(img){
  var ndvi = img.normalizedDifference(['B8','B4']).rename('NDVI');
  var nbr = img.normalizedDifference(['B8','B12']).rename('NBR');
  return img.addBands(ee.Image([ndvi, nbr]));
}
function addCoordsArea(feat){
  var lon = feat.geometry().coordinates().get(0);
  var lat = feat.geometry().coordinates().get(1);
  var area = ee.Number(feat.get('count')).multiply(ee.Number(100));
  return feat.set({'lat': lat, 'lon': lon, 'area': area});
}
function getCol(aoi, startDate, endDate) {
  return m.col
    .filterBounds(aoi)
    .filterDate(startDate, endDate)
    .map(addDate);
}
function init() {
  c.urlPanel.clear();
  // Get the collection.
  var col = getCol(m.aoi, m.firstPossibleDate, m.today);
  // Get widget values.  
  var dateFrom = c.dateSelection.fromSelector.getValue();
  var dateTo = c.dateSelection.toSelector.getValue();
  var metric = c.metricSelection.selector.getValue();
  var thresh = c.threshSelection.selector.getValue() * -1;  // Need to inverse;
  var mmu = c.mmuSelection.selector.getValue() / 100; // Convert m2 to 10 pixels (S2)
  var maxmu = c.maxmuSelection.selector.getValue() / 100; // Convert m2 to 10 pixels (S2)
  var vizBands = c.vizSelection.selector.getValue();
  // Make sure the dates selected are in proper order.
  var dateFromJs = new Date(dateFrom);
  var dateToJs = new Date(dateTo);
  if(dateFromJs >= dateToJs) {
    c.dateSelection.warning.style().set({shown: true});
    c.m1.map.layers().reset();
    return null;
  } else {
    c.dateSelection.warning.style().set({shown: false});
  }
  // Make sure the dates selected are in proper order.
  var mmuFromJs = new Date(mmu);
  var maxmuFromJs = new Date(maxmu);
  if(mmuFromJs >= maxmuFromJs) {
    c.mmuSelection.warning.style().set({shown: true});
    c.m1.map.layers().reset();
    return null;
  } else {
    c.mmuSelection.warning.style().set({shown: false});
  }
  // Viz images
  var t1 = mosaicImgs(col, dateFrom).clipToCollection(m.border);
  var t2 = mosaicImgs(col, dateTo).clipToCollection(m.border);
  var t2viz = histogramMatch(t2.select(m.visInfo[vizBands].select, ['R', 'G', 'B']),
                      t1.select(m.visInfo[vizBands].select, ['R', 'G', 'B']),
                      m.geomMatch);
  // Change composite.
  var changeComp = ee.Image([t1.select(metric),t2.select(metric),t2.select(metric)]);
  // Difference image.
  var t1Metric = t1.select(metric).clip(m.gaza);
  var t2Metric = t2.select(metric).clip(m.gaza);
  var difMetric = t2Metric.subtract(t1Metric)
  var ndvi_water_thresh = 0.25
  difMetric = difMetric.multiply(t1.select('NDVI').gt(ndvi_water_thresh)); //Remove water with simple mask
  var difMetricThresh = difMetric.lt(thresh);
  var difMetricThreshMasked = difMetric.mask(difMetricThresh)
  // Object identification.
  var nPixels = difMetricThresh.connectedPixelCount({maxSize:maxmu}) //init at 500 px (40,000 m2)
    .reproject({crs: 'EPSG:32636', scale: 10});
  var nPixelsMmu = nPixels
    .mask(nPixels.gt(mmu))
  var nPixelsMmuVector = nPixelsMmu.reduceToVectors(
    {scale: 10, maxPixels: 1e10, geometryType: 'centroid'});
  // Map layers.
  var t1l = ui.Map.Layer(t1.select(m.visInfo[vizBands].select, ['R', 'G', 'B']),
                        m.visInfo[vizBands],
                        'S2 image ' + dateFrom,false);
  var t2l = ui.Map.Layer(t2viz,
                        m.visInfo[vizBands],
                        'S2 image ' + dateTo,false);
  var ccl = ui.Map.Layer(changeComp,
                        m.changeComp,
                        'Difference composite');
  var changeThreshL = ui.Map.Layer(difMetricThreshMasked,
                        {min: -1, max:1, palette: 'orange'},
                        'Change sites meeting criteria');
  var changeLocationsL1 = ui.Map.Layer(nPixelsMmuVector, {color: 'purple'}, 'Detected change site centroids');
  // Add layers.
  c.m1.map.layers().set(0, t1l);
  c.m1.map.layers().set(1, t2l);
  c.m1.map.layers().set(2, ccl);
  c.m1.map.layers().set(3, changeThreshL);
  c.m1.map.layers().set(4, changeLocationsL1);
  // Download.
  nPixelsMmuVector = nPixelsMmuVector.filterMetadata('count','less_than',10000) //remove erroneously large clusters
    .map(function(feature) {
      var coords = feature.geometry().coordinates();
      var vectorArea = ee.Number(feature.get('count')).multiply(ee.Number(100))
      return feature.set({lon: coords.get(0), lat: coords.get(1), area:vectorArea});
  });
  var url = nPixelsMmuVector.getDownloadURL({
    selectors: ['lon', 'lat', 'area'],
    format: 'CSV',
    filename: 'gaza_damage_centroids_'+dateFrom+'_'+dateTo+'_'+metric+'_'+thresh+'_'+mmu*100+'_'+maxmu*100
  });
  var downloadLabel = ui.Label('Download CSV of detected change sites', null, url);
  c.urlPanel.add(downloadLabel);
}
c.dateSelection.fromSelector.onChange(init);
c.dateSelection.toSelector.onChange(init);
c.metricSelection.selector.onChange(init);
c.threshSelection.selector.onChange(init);
c.mmuSelection.selector.onChange(init);
c.maxmuSelection.selector.onChange(init);
c.vizSelection.selector.onChange(init);
/*******************************************************************************
* Initialize *
* 
* A section to initialize the app state on load.
* 
* Guidelines:
* 1. At the top, define any helper functions.
* 2. As much as possible, use URL params to initial the state of the app.
******************************************************************************/
// Get possible dates to show.
var dates = getCol(m.aoi, m.firstPossibleDate, m.today)
  .aggregate_array('date').distinct();
var possibleDates = ee.List(dates);
// Initialize the date selectors - set defaults.
possibleDates.evaluate(function(dates) {
  c.dateSelection.fromSelector.items().reset(dates);
  c.dateSelection.toSelector.items().reset(dates);
  c.dateSelection.fromSelector.setValue(dates[dates.length - 2], false);
  c.dateSelection.toSelector.setValue(dates[dates.length - 1], false);
  c.appLoadM1.style().set({shown: false});
  init();
});