var HUC_12_Data = ui.import && ui.import("HUC_12_Data", "table", {
      "id": "users/PrioritizationCobenefitsTool/HUC_12_Master2"
    }) || ee.FeatureCollection("users/PrioritizationCobenefitsTool/HUC_12_Master2"),
    counties = ui.import && ui.import("counties", "table", {
      "id": "TIGER/2018/Counties"
    }) || ee.FeatureCollection("TIGER/2018/Counties"),
    F_HUC_Scores = ui.import && ui.import("F_HUC_Scores", "table", {
      "id": "users/PrioritizationCobenefitsTool/F_HUC_Scores"
    }) || ee.FeatureCollection("users/PrioritizationCobenefitsTool/F_HUC_Scores"),
    NF_HUC_Scores = ui.import && ui.import("NF_HUC_Scores", "table", {
      "id": "users/PrioritizationCobenefitsTool/NF_HUC_Scores"
    }) || ee.FeatureCollection("users/PrioritizationCobenefitsTool/NF_HUC_Scores"),
    F_HUC_Scores2 = ui.import && ui.import("F_HUC_Scores2", "table", {
      "id": "users/PrioritizationCobenefitsTool/F_HUC_Scores2"
    }) || ee.FeatureCollection("users/PrioritizationCobenefitsTool/F_HUC_Scores2"),
    NF_HUC_Scores2 = ui.import && ui.import("NF_HUC_Scores2", "table", {
      "id": "users/PrioritizationCobenefitsTool/NF_HUC_Scores2"
    }) || ee.FeatureCollection("users/PrioritizationCobenefitsTool/NF_HUC_Scores2"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#23cba7",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #23cba7 */ee.Geometry.MultiPoint();
/////////////////
//// READ ME ////
/////////////////
// This script lacks annotation except for headers for sections. To read a detailed 
// account of the functional code please consult the PrioritizerBetaAnnotated Script
// or direct any questions to Israel Golden at israelagolden@gmail.com
// Last updated: July 2022
//////////////////////////////
////  Global Variables    ////
//////////////////////////////
var priority_number, NumberOfElementsAdded, HUC_12_Data2, SelectedSheds,
  CarbonWeight, PotCarbWeight, FlowWeight, NCNHPWeight, PDCWeight, PHWeight, 
  ProAreaWeight, ResilienceWeight, SVIDistWeight, Area12Weight, Area32Weight, FloodWeight,
  county1, county2, county3, county4, county5, county6, county7, county8, county9, county10,
  ChartPanel, aoi, HUC_Math, geometry;
////////////////////////////////////////////
////  Basic Map Visualization Settings  ////
////////////////////////////////////////////
// Basemap style :) 
var snazzyBlack = [
  {
    featureType: 'administrative',
    elementType: 'all',
    stylers: [{visibility: 'off'}]
  },
  {
    featureType: 'administrative',
    elementType: 'labels.text.fill',
    stylers: [{color: '#444444'}]
  },
  {
    featureType: 'landscape',
    elementType: 'all',
    stylers: [{color: '#000000'}, {visibility: 'on'}]
  },
  {featureType: 'poi', elementType: 'all', stylers: [{visibility: 'off'}]}, {
    featureType: 'road',
    elementType: 'all',
    stylers: [{saturation: -100}, {lightness: 45}]
  },
  {
    featureType: 'road',
    elementType: 'geometry.fill',
    stylers: [{color: '#ffffff'}]
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{color: '#eaeaea'}]
  },
  {featureType: 'road', elementType: 'labels', stylers: [{visibility: 'off'}]},
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{color: '#dedede'}]
  },
  {
    featureType: 'road',
    elementType: 'labels.icon',
    stylers: [{visibility: 'off'}]
  },
  {
    featureType: 'road.highway',
    elementType: 'all',
    stylers: [{visibility: 'simplified'}]
  },
  {
    featureType: 'road.arterial',
    elementType: 'labels.icon',
    stylers: [{visibility: 'off'}]
  },
  {featureType: 'transit', elementType: 'all', stylers: [{visibility: 'off'}]},
  {
    featureType: 'water',
    elementType: 'all',
    stylers: [{color: '#434343'}, {visibility: 'on'}]
  }
];
Map.setOptions(
    'snazzyBlack', {snazzyBlack: snazzyBlack});
Map.setControlVisibility({scaleControl: true, zoomControl: false});
var drawingTools = Map.drawingTools();
drawingTools.setShown(false);
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
var dummyGeometry =
    ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: '23cba7'});
drawingTools.layers().add(dummyGeometry);
Map.centerObject(HUC_12_Data);
Map.style().set({cursor: 'crosshair'});
var HUC_STYLE = {color: '1086dd', fillColor: '00000000', width:1.5};
var originalHUCLayer = HUC_12_Data.style(HUC_STYLE);
Map.addLayer(originalHUCLayer);
///////////////////////////////////////
////  Explore HUC Attributes Tool  ////
///////////////////////////////////////
var HIGHLIGHT_STYLE = {color: '81ecf1', fillColor: '81ecf1C0'};
var SEARCH_DISTANCE = 1;
function getProps(loc) {
  loc = ee.Dictionary(loc);
  var point = ee.Geometry.Point(loc.getNumber('lon'), loc.getNumber('lat'));
  var thisHUC = F_HUC_Scores2.filterBounds(point.buffer(SEARCH_DISTANCE));
  var thisHUCAttributes = thisHUC
    .select({
      propertySelectors: ['NAME', 'CARB', 'POTSEQ', 'FLOW', 'RESILI', 
      'BIODIV', 'PH', 'PH_PCT', 'PDC','PDC_PCT', 'UNPRO_PCT', 'SVIDIST_PC', 'FLOOD_AC', 'ACRES12', 'GRID12_PCT', 'ACRES32', 'GRID32_PCT'],
      newProperties: ['Subwatershed', 'Tons of Carbon per acre', 'Kg of C sequestered/ac/year', 
      'Mean TNC Flow Score', 'Mean TNC Resilience Score', 'NCNHP Biodiversity Score', 
      'Pollinator Habitat Area (acres)','Percentage of HUC as Pollinator Habitat', 'Pollinator-dependent Crop Area (acres)', 
      'Percentage of HUC as Pollinator-dependent Cropland', 'Percent Unprotected', 'Socially vulnerable percentage of HUC without access to green space', 'Acres at risk of flooding',
      'Working Lands at risk of conversion (acres)', 'Percentage of Working Lands at risk of conversion', 'Natural space at risk of conversion (acres)', 'Percentage of Natural space at risk of conversion']
    })
      .map(function(ft) {
            return ft.set('system:click_distance', point.distance(ft.geometry()));
        })
      .sort('system:click_distance').first();
  var props = thisHUCAttributes.toDictionary();
    props.evaluate(function(props) {
    var str = "Sub-watershed: "  + props.Subwatershed + '\n';
      delete props.Subwatershed;
      Object.keys(props).forEach(function(i) {
        str = str + i + ': ' + props[i].toFixed(2) + '\n';
      });
      info.setValue(str);
    });
  handleMapClick();
    function updateOverlay() {
      var overlay = thisHUC.style(HIGHLIGHT_STYLE);
      Map.layers().set(1, ui.Map.Layer(overlay));
    }
    function clearResults() {
      Map.layers().remove(Map.layers().get(1));
    }
  function handleMapClick() {
    clearResults();
    updateOverlay();
  }
}
var inspectbutton1 = ui.Button({
  label:'Explore HUC attributes',
  style: {position: 'bottom-left'},
  onClick: function() {
  Map.remove(inspectbutton1);
  Map.add(summarypanel);
  Map.onClick(getProps);
  }
});
var summarypanel = ui.Panel({style: {position: 'bottom-left', width: '22.5rem', height: '10rem'}});
var info = ui.Label({value: 'Click on a feature', style: {whiteSpace: 'pre'}});
var collapsebutton = ui.Button({
  label: 'Collapse HUC Summary',
  style: {position: 'bottom-left'},
  onClick: function() {
    Map.layers().remove(Map.layers().get(1));
    Map.remove(summarypanel);
    Map.add(inspectbutton1);
  }
});
summarypanel.add(info).add(collapsebutton);
Map.add(inspectbutton1);
///////////////////////////////////////////
////  GUI Construction + Functionality ////
///////////////////////////////////////////
/// * TITLE & DESCRIPTION * ///
var panel = ui.Panel({style: {width:'25%'}});
ui.root.insert(0, panel);
var intro = ui.Label('NC HUC-12 Conservation Prioritization Tool',
  {fontWeight: 'bold', fontSize: '24px', margin: '10px 5px'});
var subtitle = ui.Label('This tool takes ecosystem services datasets'+
  ' summarized  at the HUC-12 sub-watershed level and allows users'+
  ' to prioritize HUCs within their area of interest based on their conservation goals.', {});
var subtitle2 = ui.Label('Click here to be directed to the NC Conservation Tools User Guide.',{}).setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a');
var line = ui.Label({value:'__________________________________________________________', style:{fontWeight:'bold'},});
panel.add(intro).add(subtitle).add(subtitle2).add(line);
/// * INCLUDE/EXCLUDE ALREADY PROTECTED LANDS * ///
var filterLabel = ui.Label('Include or Exclude Protected Areas from Prioritization',
  {fontWeight:'bold', fontSize: '18px', margin:'10px 5px'});
var filterDescription = ui.Label('Use the drop-down menu below to either include or exclude already-protected' +
 ' areas (e.g. National Parks, conservation easements) from prioritization calculations. Default excludes protected lands.');
var filterChoice = ui.Select({
  items: ['Exclude already protected lands', 'Include already protected lands']
}).setValue('Exclude already protected lands');
panel.add(filterLabel).add(filterDescription).add(filterChoice);
/// * AOI SELECTION * ///
var AOIChoiceIndex = 10;
var AOILabel = ui.Label('Choose your Area of Interest', 
  {fontWeight:'bold', fontSize: '18px', margin:'10px 5px'});
var AOIDescription = ui.Label({value: 'Use the dropdown menu below to select your area of interest. ' +
  'Options include selection by county, river basin, user-defined geometry, or the entire state.'
});
function addAOIPanelElements(AOIPanelElements, AOIChoiceIndex) {
  for (var i = 0; i < AOIPanelElements.length; i++) {
    panel.insert(AOIChoiceIndex + i, AOIPanelElements[i]);
  }
  return AOIPanelElements.length;
}
function ClearAOIPanel(AOIChoiceIndex, NumberOfElementsAdded) {
  var allWidgets = panel.widgets();
  for(var i = AOIChoiceIndex; i < NumberOfElementsAdded + AOIChoiceIndex; i++){
    panel.remove(allWidgets.get(AOIChoiceIndex));
  }
}
var AOIChoice = ui.Select({items: 
      ['County',
      'River Basin',
      'User-defined Geometry',
      'Entire State'],
  onChange: function(key) {
    ClearAOIPanel(AOIChoiceIndex, NumberOfElementsAdded);
    if (key == 'County') NumberOfElementsAdded = 
      addAOIPanelElements(CountyPanelElements, AOIChoiceIndex);
    else if (key == 'River Basin') NumberOfElementsAdded = 
      addAOIPanelElements(basinPanelElements, AOIChoiceIndex);
    else if (key == 'User-defined Geometry') NumberOfElementsAdded = 
      addAOIPanelElements(geomPanelElements, AOIChoiceIndex);
    else if (key == 'Entire State') NumberOfElementsAdded = 0;
  }
});
panel.add(AOILabel).add(AOIDescription).add(AOIChoice);
/// * DROPDOWN MENU SELECTION OPTION RESULTS * ///
// AOI: COUNTY SELECTION
  var selectCOI = ui.Label({value:'Select counties of interest',
    style: {fontSize: '18px', fontWeight: 'bold'}});
  var CountyRules = ui.Label('Select at least one county to consider HUC-12 units within.');
    var NC_Counties = counties.filter(ee.Filter.eq('STATEFP', '37'));
  var NC_County_List = NC_Counties.aggregate_array('NAME').distinct().sort();
  function CountyDDListener() {
    CountyPanelElements[CountyPanelElements.length - 1].unlisten();
    if((basinPanelElements.length - 2) >= 100) {
      return;
    }
    var newDD = ui.Select({items: [], 
        placeholder:'Choose a county', onChange: CountyDDListener}
      );
    NC_County_List.evaluate(function(HUC_12_Data){
      newDD.items().reset(HUC_12_Data)});
    panel.insert(AOIChoiceIndex + CountyPanelElements.length, newDD);
    CountyPanelElements.push(newDD);
    NumberOfElementsAdded++;
    print(CountyPanelElements.length);
  }
    var InitialCountyDD = ui.Select({items: [],
    placeholder: 'Choose a county', onChange: CountyDDListener});
    NC_County_List.evaluate(function(HUC_12_Data){
    InitialCountyDD.items().reset(HUC_12_Data)});
  var CountyPanelElements = [selectCOI, CountyRules, InitialCountyDD];
// AOI: River Basin Selection
  var NC_Rivers_List = HUC_12_Data.aggregate_array('DWQ_Basin').distinct().sort();
  var SelectBasinOfInterest = ui.Label({value:'Select river basins of interest',
    style: {fontSize: '18px', fontWeight: 'bold'}});
  var BasinRules = ui.Label('Select at least one river Basin to consider HUC-12 units within.');
  function RiverDDListener() {
    basinPanelElements[basinPanelElements.length - 1].unlisten();
    if((basinPanelElements.length - 2) >= 17) {
      return;
    }
    var newDD = ui.Select({items: [], 
        placeholder:'Choose a basin', onChange: RiverDDListener}
      );
    NC_Rivers_List.evaluate(function(HUC_12_Data){
      newDD.items().reset(HUC_12_Data)});
    panel.insert(AOIChoiceIndex + basinPanelElements.length, newDD);
    basinPanelElements.push(newDD);
    NumberOfElementsAdded++;
  }
  var InitialBasinDD = ui.Select({items: [],
    placeholder: 'Choose a basin', onChange: RiverDDListener});
  NC_Rivers_List.evaluate(function(HUC_12_Data){
    InitialBasinDD.items().reset(HUC_12_Data)});
  var basinPanelElements = [SelectBasinOfInterest, BasinRules, InitialBasinDD];
/// AOI: USER-DEFINED GEOMETRY
  var aoi = drawingTools.layers().get(0).getEeObject();
  function clearGeometry() {
    var layers = drawingTools.layers();
    layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
  }
  function drawRectangle() {
    clearGeometry();
    drawingTools.setShape('rectangle');
    drawingTools.draw();
  }
  function drawPolygon() {
    clearGeometry();
    drawingTools.setShape('polygon');
    drawingTools.draw();
  }
  function stopDrawing() {
    drawingTools.stop();
  }
  var symbol = {
    rectangle: '⬛',
    polygon: '🔺',
    nodraw: '🙅️✏️'
  };
  var controlPanel = ui.Panel({
    widgets: [
      ui.Label('1. Select a drawing mode.'),
      ui.Button({
        label: symbol.rectangle + ' Rectangle',
        onClick: drawRectangle,
        style: {stretch: 'horizontal'}
      }),
      ui.Button({
        label: symbol.polygon + ' Polygon',
        onClick: drawPolygon,
        style: {stretch: 'horizontal'}
      }),
      ui.Button({
        label: symbol.nodraw + ' Stop Drawing',
        onClick: stopDrawing,
        style: {stretch: 'horizontal'}
      }),
      ui.Label('2. Draw a geometry.'),
      ui.Label('3. Once finished, click "Stop Drawing."'),
      ui.Label(
          '4. Repeat 1-3 to edit/move\ngeometry or proceed to weights.',
          {whiteSpace: 'pre'})
    ],
    layout: null,
  });
  var geomPanelElements = [controlPanel];
// AOI: ENTIRE STATE
/// * WEIGHT SLIDER SECTION * ///
var SpecifyWeights = ui.Label({value:'Specify weights for data layers',
style: {fontSize: '18px', fontWeight: 'bold'}});
var WeightExplanation = ui.Label({value:'In this section, weight your conservation ' + 
    'interests relative to other conservation metrics. Click the title of any slider ' + 
    'to learn more about the associated data.'});
// Create 11 Weight sliders, one for each of the data layers 
var WeightSlider = ui.Slider({min: 0, max: 10, value: 1, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider.style().set('stretch', 'horizontal');  
var WeightSlider1 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider1.style().set('stretch', 'horizontal');  
var WeightSlider2 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider2.style().set('stretch', 'horizontal'); 
var WeightSlider3 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider3.style().set('stretch', 'horizontal');
var WeightSlider4 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider4.style().set('stretch', 'horizontal');
var WeightSlider5 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider5.style().set('stretch', 'horizontal');
var WeightSlider6 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider6.style().set('stretch', 'horizontal');
var WeightSlider7 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider7.style().set('stretch', 'horizontal');
var WeightSlider8 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider8.style().set('stretch', 'horizontal');
var WeightSlider9 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider9.style().set('stretch', 'horizontal');
var WeightSlider10 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider10.style().set('stretch', 'horizontal');
var WeightSlider11 = ui.Slider({min: 0, max: 10, value: 0, step: 1, 
  style: {margin: '3px 8px 8px 14px'}});
  WeightSlider11.style().set('stretch', 'horizontal');
var SpecifyWeights = ui.Label({value:'Specify weights for data layers',
style: {fontSize: '18px', fontWeight: 'bold'}});
// Create labels for each of the sliders
var CarbLabel = ui.Label({value:'Standing forest carbon', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-IAYMOu');
var PotCarbLabel = ui.Label({value:'Carbon sequestration potential', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-vFYEJL');
var FlowLabel = ui.Label({value:'Connectivity', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-t0jVdB');
var NCNHPLabel = ui.Label({value:'Biodiversity', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-eJeamY');
var PDCLabel = ui.Label({value:'Pollinator-dependent cropland', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-CURsUl');
var PHLabel = ui.Label({value:'Pollinator habitat', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-uOaDJ3');
var ProAreaLabel = ui.Label({value:'Unprotected area', 
  style: {fontSize: '16px'}})
  .setUrl('https://www.ncnhp.org/activities/conservation/managed-areas');
var ResLabel = ui.Label({value:'Climate resilience', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-ZwcLxj');
var SVIDLabel = ui.Label({value:'Lack of green space in socially vulnerable areas', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-83GvGx');
var Area12Label = ui.Label({value:'Working land conversion risk', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-D09u1t');
var Area32Label = ui.Label({value:'Natural land conversion risk', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-G6cV68');
var FloodLabel = ui.Label({value:'Demand for downstream flood attenuation', 
  style: {fontSize: '16px'}})
  .setUrl('https://storymaps.arcgis.com/stories/6ac20916c67b4164901b50ac3e640d6a#ref-n-ZH7exi');
panel.add(SpecifyWeights).add(WeightExplanation).add(CarbLabel).add(WeightSlider)
  .add(PotCarbLabel).add(WeightSlider1).add(FlowLabel).add(WeightSlider2)
  .add(NCNHPLabel).add(WeightSlider3).add(PDCLabel).add(WeightSlider4).add(PHLabel)
  .add(WeightSlider5)//.add(ProAreaLabel).add(WeightSlider6)
  .add(ResLabel).add(WeightSlider7)
  .add(SVIDLabel).add(WeightSlider8).add(Area12Label).add(WeightSlider9)
  .add(Area32Label).add(WeightSlider10).add(FloodLabel).add(WeightSlider11);
/// * SELECT PRIORITY HUCS NUMBER * ///
var PriorityHUCsLabel = ui.Label('Select priority number',
{fontWeight:'bold', fontSize: '18px', margin:'10px 5px'});
var priorityHUCsValue = ui.Label('Upon running the scenario, the top-ranking HUCs based ' + 
  'on your inputs will be added to a series of charts on the right side of the screen. ' + 
  'To enhance legibility, select how many of the top HUCs you wish to include in the ' + 
  'charts (e.g., the top 3, top 5, or top 100). These HUCs will also be outlined in ' + 
  'purple on the map. To add labels to the top HUCs, check the "High performing ' + 
  'HUC labels" checkbox in the "Layers" dropdown menu in the top right.');
var HUCNumberbox = ui.Textbox("Default value is 3");
panel.add(PriorityHUCsLabel).add(priorityHUCsValue).add(HUCNumberbox);
/// * SUBMIT SCENARIO + CREDITS * ///
var ScenarioSection = ui.Label({value:'Scenario Submission', 
style: {fontWeight: 'bold', fontSize: '18px'}
});
var ScenarioLabel = ui.Label({value:'Once you have selected your your area of interest, relative weights, and number of top-performing HUCs ' +
'press the "Run Scenario" button. Scenario outputs include a visualized map of prioritized HUCs, a series of charts of top performing HUCs ' + 
'and associated co-benefits, and a downloadable spreadsheet of the attributes of all HUCs within the area of interest.  ' + 
'Press the "Reset Map" button to submit another scenario. Allow 5-10 seconds for calculations.'
});
var SubmitScenario = ui.Button('Run Scenario', PrioritizerTool);
var line2 = ui.Label({value:'__________________________________________________________', style:{fontWeight:'bold'},});
panel.add(ScenarioSection).add(ScenarioLabel).add(SubmitScenario).add(line2);
var survey = ui.Label('Please share your experience with this tool and ideas for updates & improvements in a brief survey.',{}).setUrl('https://duke.qualtrics.com/jfe/form/SV_cusdmggWxkkOrum?jfefe=new');
panel.add(survey)
var credits = ui.Label({
  value: 'Version 1.0, 2023\nDeveloped by Israel Golden\nContact: katie.warnell@duke.edu\n\nThis project was funded by the Open Space Institute Land and Climate \nCatalyst Planning Program. Some of the included datasets were \noriginally developed with support from the Southeast Climate Adaptation \nScience Center.',
  style: {color: 'gray',
          whiteSpace: 'pre',
          fontSize: '8 px'
  }
});
panel.add(credits);
//////////////////////////////////////////////
////  PRIORITIZER TOOL FUNCTION + INPUTS  ////
//////////////////////////////////////////////
function GetCurrentValues() {
  priority_number = Number(HUCNumberbox.getValue());
    if (!priority_number) priority_number = 3; 
  aoi = drawingTools.layers().get(0).getEeObject();
  CarbonWeight = WeightSlider.getValue();
  PotCarbWeight = WeightSlider1.getValue();
  FlowWeight = WeightSlider2.getValue();
  NCNHPWeight = WeightSlider3.getValue();
  PDCWeight = WeightSlider4.getValue();
  PHWeight = WeightSlider5.getValue();
  ProAreaWeight = WeightSlider6.getValue();
  ResilienceWeight = WeightSlider7.getValue();
  SVIDistWeight = WeightSlider8.getValue();
  Area12Weight = WeightSlider9.getValue();
  Area32Weight = WeightSlider10.getValue();
  FloodWeight = WeightSlider11.getValue();
}
function PrioritizerTool()
{
  Map.clear();
  Map.setControlVisibility({scaleControl: true, zoomControl: false});
  drawingTools.setShown(false);
  stopDrawing();
  GetCurrentValues();
  Map.setOptions(
    'snazzyBlack', {snazzyBlack: snazzyBlack});
/// * HUC EXPLORER * ///
var SEARCH_DISTANCE = 1; 
function getProps(loc) {
  loc = ee.Dictionary(loc);
  var point = ee.Geometry.Point(loc.getNumber('lon'), loc.getNumber('lat'));
  var thisHUC = HUC_Math.filterBounds(point.buffer(SEARCH_DISTANCE));
  var thisHUCAttributes = thisHUC
    .select({
      propertySelectors: ['NAME', 'CARB', 'POTSEQ', 'FLOW', 'RESILI', 
      'BIODIV', 'PH', 'PH_PCT', 'PDC','PDC_PCT', 'UNPRO_PCT', 'SVIDIST_PC', 'FLOOD_AC', 'ACRES12', 'GRID12_PCT', 'ACRES32', 'GRID32_PCT'],
      newProperties: ['Subwatershed', 'Tons of Carbon per acre', 'Kg of C sequestered/ac/year', 
      'Mean TNC Flow Score', 'Mean TNC Resilience Score', 'NCNHP Biodiversity Score', 
      'Pollinator Habitat Area (acres)','Percentage of HUC as Pollinator Habitat', 'Pollinator-dependent Crop Area (acres)', 
      'Percentage of HUC as Pollinator-dependent Cropland', 'Percent Unprotected', 'Socially vulnerable percentage of HUC without access to green space', 'Acres at risk of flooding',
      'Working Lands at risk of conversion (acres)', 'Percentage of Working Lands at risk of conversion', 'Natural space at risk of conversion (acres)', 'Percentage of Natural space at risk of conversion']
    })
    .map(function(ft) {
      return ft.set('system:click_distance', point.distance(ft.geometry()));
  })
  .sort('system:click_distance').first();
  var props = thisHUCAttributes.toDictionary();
  props.evaluate(function(props) {
    var str = "Sub-watershed: "  + props.Subwatershed + '\n';
    delete props.Subwatershed;
    Object.keys(props).forEach(function(i) {
      str = str + i + ': ' + props[i].toFixed(2) + '\n';
    });
    info.setValue(str);
  });
  handleMapClick();
  function updateOverlay() {
    var HIGHLIGHT_STYLE = {color: '81ecf1', fillColor: '81ecf1C0'};
    var overlay = thisHUC.style(HIGHLIGHT_STYLE);
    Map.layers().set(4, ui.Map.Layer(overlay));
  }
  function clearResults() {
    Map.layers().remove(Map.layers().get(4));
  }
  function handleMapClick() {
    clearResults();
    updateOverlay();
  }
}
var inspectbutton = ui.Button({
  label:'Explore HUC attributes',
  style: {position: 'bottom-left'},
  onClick: function() {
  Map.remove(inspectbutton);
  Map.add(summarypanel);
  Map.onClick(getProps);
  }
});
var summarypanel = ui.Panel({style: {position: 'bottom-left', width: '300px', height: '200px'}});
var info = ui.Label({value: 'Click on a feature', style: {whiteSpace: 'pre'}});
var collapsebutton = ui.Button({
  label: 'Collapse HUC Summary',
  onClick: function() {
    Map.layers().remove(Map.layers().get(4));
    Map.remove(summarypanel);
    Map.add(inspectbutton);
  }
});
summarypanel.add(info).add(collapsebutton);
Map.add(inspectbutton);
/// * INCLUDE/EXCLUDE ALREADY PROTECTED LANDS * ///
    if (filterChoice.getValue() == 'Exclude already protected lands'){ 
    HUC_12_Data2 = F_HUC_Scores2;
      }
    else if (filterChoice.getValue() == 'Include already protected lands'){
    HUC_12_Data2 = NF_HUC_Scores2;
      }
    else if (filterChoice.getValue() === ''){
      HUC_12_Data2 == F_HUC_Scores2;
    }
/// * AOI SELECTION * ///
  if (AOIChoice.getValue() == 'County'){
    var SelectedCounties = [];
    for (var i=2; i < CountyPanelElements.length; i++){
      SelectedCounties.push(
          CountyPanelElements[i].getValue());
    }
    var CountySelection = NC_Counties.filter(
      ee.Filter.inList('NAME', SelectedCounties)
    );
    SelectedSheds = HUC_12_Data2.filterBounds(CountySelection);
  } 
  else if (AOIChoice.getValue() == 'River Basin') {
    var SelectedBasins = [];
    for (var i=2; i < basinPanelElements.length; i++){
      SelectedBasins.push(
          basinPanelElements[i].getValue());
    }
    SelectedSheds = HUC_12_Data2.filter(SelectedBasins);
    SelectedSheds = HUC_12_Data2.filter(
      ee.Filter.inList('DWQ_Basin', SelectedBasins)
    );
  }
  else if (AOIChoice.getValue() == 'User-defined Geometry') {
    SelectedSheds = HUC_12_Data2.filterBounds(aoi);// so the issue is that it's not picking up a geometry value
    clearGeometry();
  }
  else if (AOIChoice.getValue() == 'Entire State') {
    SelectedSheds = HUC_12_Data2;
  }
  var addField = function(feature) {
      var wCarbon = ee.Number(feature.get('P_CARB')).multiply(ee.Number(CarbonWeight));
      var wPotCarb = ee.Number(feature.get('P_POTSEQ')).multiply(ee.Number(PotCarbWeight));
      var wFlow = ee.Number(feature.get('P_FLOW')).multiply(ee.Number(FlowWeight));
      var wNCNHP = ee.Number(feature.get('P_BIODIV')).multiply(ee.Number(NCNHPWeight));
      var wPDC = ee.Number(feature.get('P_PDC')).multiply(ee.Number(PDCWeight));
      var wPH = ee.Number(feature.get('P_PH')).multiply(ee.Number(PHWeight));
      var wProArea = ee.Number(feature.get('P_UNPRO')).multiply(ee.Number(ProAreaWeight));
      var wResili = ee.Number(feature.get('P_RESILI')).multiply(ee.Number(ResilienceWeight));
      var wSVIDist = ee.Number(feature.get('P_SVIDIST')).multiply(ee.Number(SVIDistWeight));
      var wArea12 = ee.Number(feature.get('P_GRID12')).multiply(ee.Number(Area12Weight));
      var wArea32 = ee.Number(feature.get('P_GRID32')).multiply(ee.Number(Area32Weight));
      var wFlood = ee.Number(feature.get('P_FLOOD')).multiply(ee.Number(FloodWeight));
      var weight = wCarbon.add(wPotCarb).add(wFlow).add(wNCNHP).add(wPDC).add(wPH)
      .add(wProArea).add(wResili).add(wSVIDist).add(wArea12).add(wArea32).add(wFlood);
    return feature.set({'weight': weight});
  };
  var HUC_Math = SelectedSheds.map(addField);
    var highPriority = HUC_Math
    .sort('weight', false)
    .limit(priority_number);
//2. Visualization
  // Determine max and min for visualization
      var WeightMax = ee.Number(HUC_Math.aggregate_stats('weight').get('max'));
      var visMax = WeightMax.getInfo();
      var WeightMin = ee.Number(HUC_Math.aggregate_stats('weight').get('min'));
      var visMin = WeightMin.getInfo();
    // High priority HUCs
      var WeightMax2 = ee.Number(highPriority.aggregate_stats('weight').get('max'));
      var visMax2 = WeightMax2.getInfo();
      var WeightMin2 = ee.Number(highPriority.aggregate_stats('weight').get('min'));
      var visMin2 = WeightMin2.getInfo();
  // First Visualize all HUC-12 units on gradient
    // Visualize the result by painting with the weight column
    var result = ee.Image().byte();
    var NC_result = result.paint({
      featureCollection: HUC_Math,
      color: 'weight',
    });
    var palette = ['#440154', '#433982', '#30678D', '#218F8B', '#36B677', 
        '#8ED542', '#FDE725'];
    Map.addLayer(NC_result, {palette: palette, min: visMin, max: visMax}, 
        'HUC prioritization');
  var shown = false; // true or false, 1 or 0 
  var opacity = 0.001; // number [0-1]
  var nameLayer = 'HUCs within AOI'; // string
  var visParams = {color: 'black', fillColor: 'ffffff'}; // dictionary: 
  Map.addLayer(SelectedSheds, visParams, nameLayer, shown, opacity);
  var HUCref = ee.Image().byte();
  var HUCref_layer = HUCref.paint({
    featureCollection: HUC_Math,
    color: 'white',
    width: 1
  });
  Map.addLayer(HUCref_layer, {palette: 'black', opacity: 0.1}, 'HUC Reference Layer');
    var result2 = ee.Image().byte();
    var high_pri = result2.paint({
      featureCollection: highPriority,
      color: 'weight',
      width: 2
    });
    var palette2 = ['ffff74','fcfc55','fcfc2e','ffff00'];
    Map.addLayer(high_pri, {palette: '8856a7', min: visMin2, max: visMax2}, 'High priority HUCs');
    Map.centerObject(HUC_Math);
    var text = require('users/gena/packages:text');
    var scale = Map.getScale() * 1;
      var labels = highPriority.map(function(feat) {
        feat = ee.Feature(feat);
        var name = ee.String(feat.get("NAME"));
        var centroid = feat.geometry().centroid();
        var t = text.draw(name, centroid, scale, {
          fontSize:16, 
          textColor:'white',
          outlineWidth: 2,
          outlineColor: 'black'
        });
        return t;
      });
      labels = ee.ImageCollection(labels);
      Map.addLayer(labels, {},'High performing HUC labels', false);
// 3. Table information for .csv download
    var highPriorityList = highPriority
      .reduceColumns(ee.Reducer.toList(), ['NAME']).get('list');
    var rankedTable = HUC_Math.sort('weight', false).select({
      propertySelectors: ['NAME','HUC12_1', 'ACRES','CARB', 'POTSEQ', 'FLOW', 'RESILI',
      'BIODIV', 'PH', 'PH_PCT', 'PDC','PDC_PCT', 'UNPRO_PCT', 'SVIDIST_PC', 'FLOOD_AC', 'ACRES12', 'GRID12_PCT', 'ACRES32', 'GRID32_PCT','weight'],
      newProperties: ['Subwatershed','HUC 12 code', 'Acres', 'Tons of forest carbon per acre', 'Kg of C sequestered/ac/year',
      'Mean TNC flow score', 'Mean TNC resilience score', 'Mean NCNHP biodiversity score',
      'Pollinator habitat area (acres)','Percentage of HUC as pollinator habitat', 'Pollinator-dependent crop area (acres)',
      'Percentage of HUC as pollinator-dependent cropland', 'Percent unprotected', 'Percentage of HUC meeting SVI/green space conditions',
      'Acres at risk of flooding','Working lands at risk of conversion (acres)', 'Percentage of working lands at risk of conversion',
      'Natural space at risk of conversion (acres)', 'Percentage of natural space at risk of conversion', 'Weighted score']
    });
var table = ui.Chart.feature.byFeature(rankedTable, 'Subwatershed');
  table.setChartType('Table');
  table.setOptions({allowHtml: true, pageSize: 10});
  table.style().set({stretch: 'both'});
//4. Graphs
    // Standing forest carbon
    var CarbonChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('CARB|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'Tons per acre'
            ])
            .setChartType('ColumnChart')
            .setOptions({
              title: 'Tons of Carbon per acre in HUCs',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Tons of Carbon',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                'fbd524'
              ]
            });
    // potential sequestration
    var PotSeqChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('POTSEQ|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'Kilograms'
            ])
            .setChartType('ColumnChart')
            .setOptions({
              title: 'Potential sequestered carbon by HUC (kg/ac/year)',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Kg of Carbon/acre/year',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                'fdb42f'
              ]
            });
    // Mean Flow
    var FlowChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('FLOW|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'HUC Score'
            ])
            .setChartType('ScatterChart')
            .setOptions({
              title: 'Mean TNC Flow Score by HUC',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Mean Flow',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                'f89540'
              ]
            });
    // Mean resilience
    var ResChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('RESILI|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'HUC Score'
            ])
            .setChartType('ScatterChart')
            .setOptions({
              title: 'Mean TNC Resilience Score by HUC',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Mean TNC Resilience Score',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                'ed7953'
              ]
            });
    // NCNHP Biodiversity
    var BiodivChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('BIODIV|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'HUC Score'
            ])
            .setChartType('ScatterChart')
            .setOptions({
              title: 'Mean NCNHP Biodiversity Score by HUC',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Mean NCNHP Biodiversity Score',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                'de5f65'
              ]
            });
    // Pollinator Habitat
    var PHChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('PH|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'Acres'
            ])
            .setChartType('ColumnChart')
            .setOptions({
              title: 'Pollinator Habitat (acres) by HUC',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Pollinator Habitat (acres)',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                'cc4778'
              ]
            });
    // Pollinator Dependent Cropland
    var PDCChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('PDC|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'Acres'
            ])
            .setChartType('ColumnChart')
            .setOptions({
              title: 'Pollinator Dependent Cropland (acres) by HUC',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Pollinator Dependent Cropland (acres)',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                'b52f8c'
              ]
            });
    // SVI + Dist Chart
    var SVIDChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('SVIDIST|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'Acres'
            ])
            .setChartType('ColumnChart')
            .setOptions({
              title: 'Acres of socially vulnerable areas without access to greenspace by HUC',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'High SVI without greenspace (acres)',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                '9c179e'
              ]
            });
    // UNPRO Chart
    var UNPRO_Chart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('UNPRO_PCT|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'Percent'
            ])
            .setChartType('ColumnChart')
            .setOptions({
              title: 'Percentage of HUC that is unprotected',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Percentage of HUC that is unprotected',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                '7e03a8'
              ]
            });
    // Working Land Conversion
    var WLChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('ACRES12|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'Acres'
            ])
            .setChartType('ColumnChart')
            .setOptions({
              title: 'Working Lands projected to be developed by 2050 by HUC (acres)',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Projected Development (acres)',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                '5c01a6'
              ]
            });
    // Natural Land Conversion
    var NLChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('ACRES32|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'Acres'
            ])
            .setChartType('ColumnChart')
            .setOptions({
              title: 'Natural Lands projected to be developed by 2050 by HUC (acres)',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Projected Development (acres)',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                '3a049a'
              ]
            });
    // Flood Risk
    var FloodChart =
        ui.Chart.feature
            .byFeature({
              features: highPriority.select('FLOOD_AC|NAME'),
              xProperty: 'NAME',
            })
            .setSeriesNames([
              'Acres'
            ])
            .setChartType('ColumnChart')
            .setOptions({
              title: 'Acres at risk of flooding',
              hAxis:
                  {title: 'HUC 12 Unit', titleTextStyle: {italic: false, bold: true}},
              vAxis: {
                title: 'Flood risk area (acres)',
                titleTextStyle: {italic: false, bold: true}
              },
              colors: [
                '2c0376'
              ]
            });
/// * Results Panel * ///
var ChartLabel = ui.Label({value:'Co-benefits charts', 
  style: {fontWeight:'bold', fontSize: '18px', margin:'10px 5px'}
});
var ChartDescription = ui.Label('HUCs are arranged on each chart in order of descending ' +
'conservation priority based on user input weight values.');
var TableLabel = ui.Label({value:'HUC attribute table', 
  style: {fontWeight:'bold', fontSize: '18px', margin:'10px 5px'}
});
var TableDescription = ui.Label('This table includes all HUC-12 units within the area of interest and sorts them by weighted score ' +
  'in descending order. Click the expansion button in the top right to open the full table in another tab. Once opened, the table ' +
  'containing the HUC attributes can be downloaded as a .csv file and attached to a shapefile on a desktop GIS.');
var ChartPanel = ui.Panel({style: {width:'20%'}});
ui.root.insert(2, ChartPanel);
ChartPanel.add(ChartLabel).add(ChartDescription).add(CarbonChart)
.add(PotSeqChart).add(FlowChart).add(ResChart).add(BiodivChart).add(PHChart)
.add(PDCChart).add(SVIDChart).add(UNPRO_Chart).add(WLChart).add(NLChart).add(FloodChart)
.add(TableLabel).add(TableDescription).add(table);
// 5. Legend!
var viz = {min:visMin, max:visMax, 
  palette:['#440154', '#433982', '#30678D', '#218F8B', '#36B677', '#8ED542', '#FDE725']};
var legend = ui.Panel({
style: {
position: 'bottom-right',
padding: '4px 8px'
}
});
var legendTitle = ui.Label({
value: 'HUC Ranking',
style: {
fontWeight: 'bold',
fontSize: '14px',
margin: '0 0 2px 0',
padding: '0'
}
});
legend.add(legendTitle);
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
var legendpanel = ui.Panel({
widgets: [
ui.Label({
  value: 'Highest priority',
  style: {
    fontSize: '10px'
  }
  })
],
});
legend.add(legendpanel);
 var thumbnail = ui.Thumbnail({
image: legendImage,
params: {bbox:'0,0,10,100', dimensions:'33x99'},
style: {padding: '1px', position: 'bottom-center'}
});
legend.add(thumbnail);
var legendpanel = ui.Panel({
widgets: [
ui.Label({
  value: 'Lowest priority',
  style: {
    fontSize: '10px'
  }
})],
});
legend.add(legendpanel);
Map.add(legend);
// 6. Reset Button
function reset(){
    Map.clear();
    clearGeometry();
    drawingTools.setShown(false);
    Map.setControlVisibility({scaleControl: true, zoomControl: false});
    Map.setOptions(
    'snazzyBlack', {snazzyBlack: snazzyBlack});
    ui.root.remove(ChartPanel);
    Map.addLayer(originalHUCLayer);
    Map.add(inspectbutton1);
    panel.remove(resetButton);
    panel.remove(line2);
    panel.remove(survey);
    panel.remove(credits);
    panel.add(SubmitScenario);
    panel.add(line2);
    panel.add(survey);
    panel.add(credits);
  }
panel.remove(SubmitScenario);
panel.remove(line2)
panel.remove(survey)
panel.remove(credits);
var resetButton = ui.Button('Reset Map', reset);
panel.add(resetButton);
panel.add(line2);
panel.add(survey);
panel.add(credits);
}
/////////////////////////////
//Google Analytics
/////////////////////////////
/////////////////////////////
//GA code
// Copyright 2012 Google Inc. All rights reserved.
(function(){
var data = {
"resource": {
  "version":"1",
  "macros":[{"function":"__e"},{"vtp_signal":0,"function":"__c","vtp_value":0},{"function":"__c","vtp_value":""},{"function":"__c","vtp_value":0},{"vtp_signal":0,"function":"__c","vtp_value":0},{"function":"__c","vtp_value":""},{"function":"__c","vtp_value":0}],
  "tags":[{"function":"__ogt_1p_data_v2","priority":13,"vtp_cityType":"CSS_SELECTOR","vtp_manualEmailEnabled":false,"vtp_firstNameType":"CSS_SELECTOR","vtp_countryType":"CSS_SELECTOR","vtp_cityValue":"","vtp_isAutoEnabled":true,"vtp_autoCollectExclusionSelectors":["list",["map","exclusionSelector",""]],"vtp_emailType":"CSS_SELECTOR","vtp_regionType":"CSS_SELECTOR","vtp_postalCodeValue":"","vtp_lastNameValue":"","vtp_phoneType":"CSS_SELECTOR","vtp_phoneValue":"","vtp_streetType":"CSS_SELECTOR","vtp_postalCodeType":"CSS_SELECTOR","vtp_emailValue":"","vtp_firstNameValue":"","vtp_streetValue":"","vtp_lastNameType":"CSS_SELECTOR","vtp_isEnabled":true,"vtp_regionValue":"","vtp_countryValue":"","vtp_autoEmailEnabled":true,"tag_id":10},{"function":"__ccd_ga_first","priority":12,"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":24},{"function":"__set_product_settings","priority":11,"vtp_instanceDestinationId":"G-P81QF1533Q","vtp_foreignTldMacroResult":["macro",5],"vtp_isChinaVipRegionMacroResult":["macro",6],"tag_id":23},{"function":"__ogt_google_signals","priority":10,"vtp_googleSignals":"DISABLED","vtp_instanceDestinationId":"G-P81QF1533Q","vtp_serverMacroResult":["macro",4],"tag_id":22},{"function":"__ccd_ga_regscope","priority":9,"vtp_settingsTable":["list",["map","redactFieldGroup","DEVICE_AND_GEO","disallowAllRegions",false,"disallowedRegions",""],["map","redactFieldGroup","GOOGLE_SIGNALS","disallowAllRegions",true,"disallowedRegions",""]],"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":21},{"function":"__ccd_em_download","priority":8,"vtp_includeParams":true,"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":20},{"function":"__ccd_em_form","priority":7,"vtp_includeParams":true,"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":19},{"function":"__ccd_em_outbound_click","priority":6,"vtp_includeParams":true,"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":18},{"function":"__ccd_em_page_view","priority":5,"vtp_historyEvents":true,"vtp_includeParams":true,"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":17},{"function":"__ccd_em_scroll","priority":4,"vtp_includeParams":true,"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":16},{"function":"__ccd_em_site_search","priority":3,"vtp_searchQueryParams":"q,s,search,query,keyword","vtp_includeParams":true,"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":15},{"function":"__ccd_em_video","priority":2,"vtp_includeParams":true,"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":14},{"function":"__ccd_conversion_marking","priority":1,"vtp_conversionRules":["list",["map","matchingRules","{\"type\":5,\"args\":[{\"stringValue\":\"purchase\"},{\"contextValue\":{\"namespaceType\":1,\"keyParts\":[\"eventName\"]}}]}"]],"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":13},{"function":"__gct","vtp_trackingId":"G-P81QF1533Q","vtp_sessionDuration":0,"vtp_googleSignals":["macro",1],"vtp_foreignTld":["macro",2],"vtp_restrictDomain":["macro",3],"vtp_eventSettings":["map"],"tag_id":7},{"function":"__ccd_ga_last","priority":0,"vtp_instanceDestinationId":"G-P81QF1533Q","tag_id":12}],
  "predicates":[{"function":"_eq","arg0":["macro",0],"arg1":"gtm.js"},{"function":"_eq","arg0":["macro",0],"arg1":"gtm.init"}],
  "rules":[[["if",0],["add",13]],[["if",1],["add",0,14,12,11,10,9,8,7,6,5,4,3,2,1]]]
},
"runtime":[[50,"__ccd_conversion_marking",[46,"a"],[50,"t",[46,"u"],[52,"v",[2,[15,"q"],"parse",[7,[15,"u"]]]],[22,[30,[30,[28,[15,"v"]],[28,[16,[15,"v"],"args"]]],[21,[17,[16,[15,"v"],"args"],"length"],2]],[46,[36]]],[52,"w",[16,[16,[16,[15,"v"],"args"],1],"contextValue"]],[22,[30,[30,[30,[28,[15,"w"]],[21,[16,[15,"w"],"namespaceType"],1]],[21,[17,[16,[15,"w"],"keyParts"],"length"],1]],[21,[16,[16,[15,"w"],"keyParts"],0],"eventName"]],[46,[36,[44]]]],[52,"x",[16,[16,[15,"v"],"args"],0]],[36,[1,[15,"x"],[16,[15,"x"],"stringValue"]]]],[22,[30,[28,[17,[15,"a"],"conversionRules"]],[20,[17,[17,[15,"a"],"conversionRules"],"length"],0]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"b",["require","internal.copyPreHit"]],[52,"c",["require","internal.evaluateBooleanExpression"]],[52,"d",[13,[41,"$0"],[3,"$0",["require","internal.getFlags"]],["$0"]]],[52,"e",["require","internal.registerCcdCallback"]],[52,"f","is_conversion"],[52,"g","is_first_visit"],[52,"h","is_first_visit_conversion"],[52,"i","is_session_start"],[52,"j","is_session_start_conversion"],[52,"k","syn_or_mod"],[52,"l","first_visit"],[52,"m","session_start"],[22,[16,[15,"d"],"enableCcdGaConversions"],[46,[53,[41,"u"],[41,"v"],["e",[17,[15,"a"],"instanceDestinationId"],[51,"",[7,"w"],[22,[2,[15,"w"],"getMetadata",[7,[15,"k"]]],[46,[36]]],[52,"x",[8,"preHit",[15,"w"]]],[65,"y",[17,[15,"a"],"conversionRules"],[46,[22,["c",[17,[15,"y"],"matchingRules"],[15,"x"]],[46,[2,[15,"w"],"setMetadata",[7,[15,"f"],true]],[4]]]]],[22,[2,[15,"w"],"getMetadata",[7,[15,"g"]]],[46,[22,[28,[15,"u"]],[46,[53,[52,"y",["b",[15,"w"],[8,"omitHitData",true,"omitMetadata",true]]],[2,[15,"y"],"setEventName",[7,[15,"l"]]],[3,"u",[8,"preHit",[15,"y"]]]]]],[65,"y",[17,[15,"a"],"conversionRules"],[46,[22,["c",[17,[15,"y"],"matchingRules"],[15,"u"]],[46,[2,[15,"w"],"setMetadata",[7,[15,"h"],true]],[4]]]]]]],[22,[2,[15,"w"],"getMetadata",[7,[15,"i"]]],[46,[22,[28,[15,"v"]],[46,[53,[52,"y",["b",[15,"w"],[8,"omitHitData",true,"omitMetadata",true]]],[2,[15,"y"],"setEventName",[7,[15,"m"]]],[3,"v",[8,"preHit",[15,"y"]]]]]],[65,"y",[17,[15,"a"],"conversionRules"],[46,[22,["c",[17,[15,"y"],"matchingRules"],[15,"v"]],[46,[2,[15,"w"],"setMetadata",[7,[15,"j"],true]],[4]]]]]]]]],[2,[15,"a"],"gtmOnSuccess",[7]],[36]]]],[52,"n",["require","internal.setProductSettingsParameter"]],[52,"o",["require","internal.getProductSettingsParameter"]],[52,"p",["require","getContainerVersion"]],[52,"q",["require","JSON"]],[52,"r",[30,[17,[15,"a"],"instanceDestinationId"],[17,["p"],"containerId"]]],[52,"s",[30,["o",[15,"r"],"event_settings"],[8]]],[53,[41,"u"],[3,"u",0],[63,[7,"u"],[23,[15,"u"],[17,[17,[15,"a"],"conversionRules"],"length"]],[33,[15,"u"],[3,"u",[0,[15,"u"],1]]],[46,[53,[52,"v",["t",[16,[16,[17,[15,"a"],"conversionRules"],[15,"u"]],"matchingRules"]]],[22,[28,[15,"v"]],[46,[6]]],[41,"w"],[3,"w",[16,[15,"s"],[15,"v"]]],[22,[28,[15,"w"]],[46,[3,"w",[8]],[43,[15,"s"],[15,"v"],[15,"w"]]]],[43,[15,"w"],"conversion",true]]]]],["n",[15,"r"],"event_settings",[15,"s"]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ccd_em_download",[46,"a"],[50,"s",[46,"y"],[36,[1,[15,"y"],[21,[2,[2,[15,"y"],"toLowerCase",[7]],"match",[7,[15,"r"]]],[45]]]]],[50,"t",[46,"y"],[52,"z",[2,[17,[15,"y"],"pathname"],"split",[7,"."]]],[52,"ba",[39,[18,[17,[15,"z"],"length"],1],[16,[15,"z"],[37,[17,[15,"z"],"length"],1]],""]],[36,[16,[2,[15,"ba"],"split",[7,"/"]],0]]],[50,"u",[46,"y"],[36,[39,[12,[2,[17,[15,"y"],"pathname"],"substring",[7,0,1]],"/"],[17,[15,"y"],"pathname"],[0,"/",[17,[15,"y"],"pathname"]]]]],[50,"v",[46,"y"],[41,"z"],[3,"z",""],[22,[1,[15,"y"],[17,[15,"y"],"href"]],[46,[53,[41,"ba"],[3,"ba",[2,[17,[15,"y"],"href"],"indexOf",[7,"#"]]],[3,"z",[39,[23,[15,"ba"],0],[17,[15,"y"],"href"],[2,[17,[15,"y"],"href"],"substring",[7,0,[15,"ba"]]]]]]]],[36,[15,"z"]]],[50,"x",[46,"y"],[52,"z",[8]],[43,[15,"z"],[15,"j"],true],[43,[15,"z"],[15,"f"],true],[43,[15,"y"],"eventMetadata",[15,"z"]]],[52,"b",[13,[41,"$0"],[3,"$0",["require","internal.getFlags"]],["$0"]]],[52,"c",["require","internal.getProductSettingsParameter"]],[52,"d",["require","internal.registerCcdCallback"]],[52,"e",["require","templateStorage"]],[52,"f","speculative"],[52,"g","ae_block_downloads"],[52,"h","file_download"],[52,"i","isRegistered"],[52,"j","em_event"],[52,"k",[17,[15,"a"],"instanceDestinationId"]],[22,["c",[15,"k"],[15,"g"]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"l",[28,[28,[16,[15,"b"],"enableCcdEnhancedMeasurement"]]]],[22,[15,"l"],[46,["d",[15,"k"],[51,"",[7,"y"],[22,[30,[21,[2,[15,"y"],"getEventName",[7]],[15,"h"]],[28,[2,[15,"y"],"getMetadata",[7,[15,"j"]]]]],[46,[36]]],[22,["c",[15,"k"],[15,"g"]],[46,[2,[15,"y"],"abort",[7]],[36]]],[2,[15,"y"],"setMetadata",[7,[15,"f"],false]],[22,[28,[17,[15,"a"],"includeParams"]],[46,[2,[15,"y"],"setHitData",[7,"link_id",[44]]],[2,[15,"y"],"setHitData",[7,"link_url",[44]]],[2,[15,"y"],"setHitData",[7,"link_text",[44]]],[2,[15,"y"],"setHitData",[7,"file_name",[44]]],[2,[15,"y"],"setHitData",[7,"file_extension",[44]]]]]]]]],[22,[1,[15,"l"],[2,[15,"e"],"getItem",[7,[15,"i"]]]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"m",["require","internal.addDataLayerEventListener"]],[52,"n",["require","internal.enableAutoEventOnLinkClick"]],[52,"o",["require","internal.getDestinationIds"]],[52,"p",["require","parseUrl"]],[52,"q",["require","internal.sendGtagEvent"]],[41,"r"],[3,"r",[0,"pdf|xlsx?|docx?|txt|rtf|csv|exe|key|pp(s|t|tx)|7z|pkg|rar|gz|zip|avi|","mov|mp4|mpe?g|wmv|midi?|mp3|wav|wma"]],[22,[16,[15,"b"],"enableFileDownloadExtensionRegexFullMatch"],[46,[3,"r",[0,[0,"^(",[15,"r"]],")$"]]]],[52,"w",["n",[8,"checkValidation",true]]],[22,[28,[15,"w"]],[46,[2,[15,"a"],"gtmOnFailure",[7]],[36]]],[2,[15,"e"],"setItem",[7,[15,"i"],true]],["m","gtm.linkClick",[51,"",[7,"y","z"],["z"],[52,"ba",[8,"eventId",[16,[15,"y"],"gtm.uniqueEventId"]]],[52,"bb",[16,[15,"y"],"gtm.elementUrl"]],[52,"bc",["p",[15,"bb"]]],[22,[28,[15,"bc"]],[46,[36]]],[52,"bd",["t",[15,"bc"]]],[22,[28,["s",[15,"bd"]]],[46,[36]]],[52,"be",[39,[30,[28,[28,[17,[15,"a"],"includeParams"]]],[15,"l"]],[8,"link_id",[16,[15,"y"],"gtm.elementId"],"link_url",["v",[15,"bc"]],"link_text",[16,[15,"y"],"gtm.elementText"],"file_name",["u",[15,"bc"]],"file_extension",[15,"bd"]],[8]]],[22,[15,"l"],[46,["x",[15,"ba"]],["q",["o"],[15,"h"],[15,"be"],[15,"ba"]]],[46,["q",[15,"k"],[15,"h"],[15,"be"],[15,"ba"]]]]],[15,"w"]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ccd_em_form",[46,"a"],[50,"s",[46,"w"],[52,"x",[30,[16,[15,"w"],[15,"l"]],[8]]],[43,[15,"x"],"event_usage",[7,8]],[43,[15,"w"],[15,"l"],[15,"x"]]],[50,"t",[46,"w"],[52,"x",[30,[16,[15,"w"],[15,"l"]],[8]]],[43,[15,"x"],[15,"k"],true],[43,[15,"x"],[15,"f"],true],[43,[15,"w"],[15,"l"],[15,"x"]]],[52,"b",[13,[41,"$0"],[3,"$0",["require","internal.getFlags"]],["$0"]]],[52,"c",["require","internal.getProductSettingsParameter"]],[52,"d",["require","internal.registerCcdCallback"]],[52,"e",["require","templateStorage"]],[52,"f","speculative"],[52,"g","ae_block_form"],[52,"h","form_submit"],[52,"i","form_start"],[52,"j","isRegistered"],[52,"k","em_event"],[52,"l","eventMetadata"],[52,"m",[17,[15,"a"],"instanceDestinationId"]],[22,["c",[15,"m"],[15,"g"]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"n",[28,[28,[16,[15,"b"],"enableCcdEnhancedMeasurement"]]]],[22,[15,"n"],[46,["d",[15,"m"],[51,"",[7,"w"],[52,"x",[2,[15,"w"],"getEventName",[7]]],[52,"y",[30,[20,[15,"x"],[15,"i"]],[20,[15,"x"],[15,"h"]]]],[22,[30,[28,[15,"y"]],[28,[2,[15,"w"],"getMetadata",[7,[15,"k"]]]]],[46,[36]]],[22,["c",[15,"m"],[15,"g"]],[46,[2,[15,"w"],"abort",[7]],[36]]],[2,[15,"w"],"setMetadata",[7,[15,"f"],false]],[22,[28,[17,[15,"a"],"includeParams"]],[46,[2,[15,"w"],"setHitData",[7,"form_id",[44]]],[2,[15,"w"],"setHitData",[7,"form_name",[44]]],[2,[15,"w"],"setHitData",[7,"form_destination",[44]]],[2,[15,"w"],"setHitData",[7,"form_length",[44]]],[22,[20,[15,"x"],[15,"h"]],[46,[2,[15,"w"],"setHitData",[7,"form_submit_text",[44]]]],[46,[22,[20,[15,"x"],[15,"i"]],[46,[2,[15,"w"],"setHitData",[7,"first_field_id",[44]]],[2,[15,"w"],"setHitData",[7,"first_field_name",[44]]],[2,[15,"w"],"setHitData",[7,"first_field_type",[44]]],[2,[15,"w"],"setHitData",[7,"first_field_position",[44]]]]]]]]]]]]],[22,[1,[15,"n"],[2,[15,"e"],"getItem",[7,[15,"j"]]]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[2,[15,"e"],"setItem",[7,[15,"j"],true]],[52,"o",["require","internal.addFormInteractionListener"]],[52,"p",["require","internal.addFormSubmitListener"]],[52,"q",["require","internal.getDestinationIds"]],[52,"r",["require","internal.sendGtagEvent"]],[52,"u",[8]],[52,"v",[51,"",[7,"w"],[52,"x",[16,[15,"w"],"gtm.elementId"]],[22,[16,[15,"u"],[15,"x"]],[46,[36]]],[43,[15,"u"],[15,"x"],true],[52,"y",[39,[30,[28,[28,[17,[15,"a"],"includeParams"]]],[15,"n"]],[8,"form_id",[15,"x"],"form_name",[16,[15,"w"],"gtm.interactedFormName"],"form_destination",[16,[15,"w"],"gtm.elementUrl"],"form_length",[16,[15,"w"],"gtm.interactedFormLength"],"first_field_id",[16,[15,"w"],"gtm.interactedFormFieldId"],"first_field_name",[16,[15,"w"],"gtm.interactedFormFieldName"],"first_field_type",[16,[15,"w"],"gtm.interactedFormFieldType"],"first_field_position",[16,[15,"w"],"gtm.interactedFormFieldPosition"]],[8]]],[52,"z",[8,"eventId",[17,[15,"a"],"gtmEventId"]]],["s",[15,"z"]],[22,[15,"n"],[46,["t",[15,"z"]],["r",["q"],[15,"i"],[15,"y"],[15,"z"]]],[46,["r",[15,"m"],[15,"i"],[15,"y"],[15,"z"]]]]]],["o",[15,"v"]],["p",[51,"",[7,"w","x"],[22,[16,[15,"b"],"enableAlwaysSendFormStart"],[46,["v",[15,"w"]]]],[52,"y",[39,[30,[28,[28,[17,[15,"a"],"includeParams"]]],[15,"n"]],[8,"form_id",[16,[15,"w"],"gtm.elementId"],"form_name",[16,[15,"w"],"gtm.interactedFormName"],"form_destination",[16,[15,"w"],"gtm.elementUrl"],"form_length",[16,[15,"w"],"gtm.interactedFormLength"],"form_submit_text",[16,[15,"w"],"gtm.formSubmitButtonText"]],[8]]],[43,[15,"y"],"event_callback",[15,"x"]],[52,"z",[8,"eventId",[17,[15,"a"],"gtmEventId"]]],["s",[15,"z"]],[22,[15,"n"],[46,["t",[15,"z"]],["r",["q"],[15,"h"],[15,"y"],[15,"z"]]],[46,["r",[15,"m"],[15,"h"],[15,"y"],[15,"z"]]]]],[8,"waitForCallbacks",false,"checkValidation",true]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ccd_em_outbound_click",[46,"a"],[50,"t",[46,"z"],[22,[28,[15,"z"]],[46,[36,[44]]]],[41,"ba"],[3,"ba",""],[22,[1,[15,"z"],[17,[15,"z"],"href"]],[46,[53,[41,"bb"],[3,"bb",[2,[17,[15,"z"],"href"],"indexOf",[7,"#"]]],[3,"ba",[39,[23,[15,"bb"],0],[17,[15,"z"],"href"],[2,[17,[15,"z"],"href"],"substring",[7,0,[15,"bb"]]]]]]]],[36,[15,"ba"]]],[50,"u",[46,"z"],[22,[28,[15,"z"]],[46,[36,[44]]]],[41,"ba"],[3,"ba",[17,[15,"z"],"hostname"]],[52,"bb",[2,[15,"ba"],"match",[7,"^www\\d*\\."]]],[22,[1,[15,"bb"],[16,[15,"bb"],0]],[46,[3,"ba",[2,[15,"ba"],"substring",[7,[17,[16,[15,"bb"],0],"length"]]]]]],[36,[15,"ba"]]],[50,"v",[46,"z"],[22,[28,[15,"z"]],[46,[36,false]]],[52,"ba",[2,[17,[15,"z"],"hostname"],"toLowerCase",[7]]],[41,"bb"],[3,"bb",[2,["u",["r",["q"]]],"toLowerCase",[7]]],[41,"bc"],[3,"bc",[37,[17,[15,"ba"],"length"],[17,[15,"bb"],"length"]]],[22,[1,[18,[15,"bc"],0],[29,[2,[15,"bb"],"charAt",[7,0]],"."]],[46,[32,[15,"bc"],[3,"bc",[37,[15,"bc"],1]]],[3,"bb",[0,".",[15,"bb"]]]]],[22,[1,[19,[15,"bc"],0],[12,[2,[15,"ba"],"indexOf",[7,[15,"bb"],[15,"bc"]]],[15,"bc"]]],[46,[36,false]]],[36,true]],[50,"y",[46,"z"],[52,"ba",[8]],[43,[15,"ba"],[15,"j"],true],[43,[15,"ba"],[15,"f"],true],[43,[15,"z"],"eventMetadata",[15,"ba"]]],[52,"b",[13,[41,"$0"],[3,"$0",["require","internal.getFlags"]],["$0"]]],[52,"c",["require","internal.getProductSettingsParameter"]],[52,"d",["require","internal.registerCcdCallback"]],[52,"e",["require","templateStorage"]],[52,"f","speculative"],[52,"g","ae_block_outbound_click"],[52,"h","click"],[52,"i","isRegistered"],[52,"j","em_event"],[52,"k",[17,[15,"a"],"instanceDestinationId"]],[22,["c",[15,"k"],[15,"g"]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"l",[28,[28,[16,[15,"b"],"enableCcdEnhancedMeasurement"]]]],[22,[15,"l"],[46,["d",[15,"k"],[51,"",[7,"z"],[22,[30,[21,[2,[15,"z"],"getEventName",[7]],[15,"h"]],[28,[2,[15,"z"],"getMetadata",[7,[15,"j"]]]]],[46,[36]]],[22,["c",[15,"k"],[15,"g"]],[46,[2,[15,"z"],"abort",[7]],[36]]],[2,[15,"z"],"setMetadata",[7,[15,"f"],false]],[22,[28,[17,[15,"a"],"includeParams"]],[46,[2,[15,"z"],"setHitData",[7,"link_id",[44]]],[2,[15,"z"],"setHitData",[7,"link_classes",[44]]],[2,[15,"z"],"setHitData",[7,"link_url",[44]]],[2,[15,"z"],"setHitData",[7,"link_domain",[44]]],[2,[15,"z"],"setHitData",[7,"outbound",[44]]]]]]]]],[22,[1,[15,"l"],[2,[15,"e"],"getItem",[7,[15,"i"]]]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"m",["require","internal.addDataLayerEventListener"]],[52,"n",["require","internal.enableAutoEventOnLinkClick"]],[52,"o",["require","internal.getDestinationIds"]],[52,"p",["require","internal.getRemoteConfigParameter"]],[52,"q",["require","getUrl"]],[52,"r",["require","parseUrl"]],[52,"s",["require","internal.sendGtagEvent"]],[52,"w",["p",[15,"k"],"cross_domain_conditions"]],[52,"x",["n",[8,"affiliateDomains",[15,"w"],"checkValidation",true,"waitForTags",false]]],[22,[28,[15,"x"]],[46,[2,[15,"a"],"gtmOnFailure",[7]],[36]]],[2,[15,"e"],"setItem",[7,[15,"i"],true]],["m","gtm.linkClick",[51,"",[7,"z","ba"],[52,"bb",["r",[16,[15,"z"],"gtm.elementUrl"]]],[22,[28,["v",[15,"bb"]]],[46,["ba"],[36]]],[52,"bc",[39,[30,[28,[28,[17,[15,"a"],"includeParams"]]],[15,"l"]],[8,"link_id",[16,[15,"z"],"gtm.elementId"],"link_classes",[16,[15,"z"],"gtm.elementClasses"],"link_url",["t",[15,"bb"]],"link_domain",["u",[15,"bb"]],"outbound",true],[8]]],[43,[15,"bc"],"event_callback",[15,"ba"]],[52,"bd",[8,"eventId",[16,[15,"z"],"gtm.uniqueEventId"]]],[22,[15,"l"],[46,["y",[15,"bd"]],["s",["o"],[15,"h"],[15,"bc"],[15,"bd"]]],[46,["s",[15,"k"],[15,"h"],[15,"bc"],[15,"bd"]]]]],[15,"x"]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ccd_em_page_view",[46,"a"],[50,"s",[46,"t"],[52,"u",[8]],[43,[15,"u"],[15,"k"],true],[43,[15,"u"],[15,"g"],true],[43,[15,"t"],"eventMetadata",[15,"u"]]],[22,[28,[17,[15,"a"],"historyEvents"]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"b",[13,[41,"$0"],[3,"$0",["require","internal.getFlags"]],["$0"]]],[52,"c",["require","internal.getProductSettingsParameter"]],[52,"d",["require","internal.registerCcdCallback"]],[52,"e",["require","internal.setRemoteConfigParameter"]],[52,"f",["require","templateStorage"]],[52,"g","speculative"],[52,"h","ae_block_history"],[52,"i","page_view"],[52,"j","isRegistered"],[52,"k","em_event"],[52,"l",[17,[15,"a"],"instanceDestinationId"]],[22,["c",[15,"l"],[15,"h"]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"m",[28,[28,[16,[15,"b"],"enableCcdEnhancedMeasurement"]]]],[22,[15,"m"],[46,["d",[15,"l"],[51,"",[7,"t"],[22,[30,[21,[2,[15,"t"],"getEventName",[7]],[15,"i"]],[28,[2,[15,"t"],"getMetadata",[7,[15,"k"]]]]],[46,[36]]],[22,["c",[15,"l"],[15,"h"]],[46,[2,[15,"t"],"abort",[7]],[36]]],[2,[15,"t"],"setMetadata",[7,[15,"g"],false]],["e",[15,"l"],"page_referrer",[2,[15,"t"],"getHitData",[7,"page_referrer"]]],[22,[28,[17,[15,"a"],"includeParams"]],[46,[2,[15,"t"],"setHitData",[7,"page_location",[44]]],[2,[15,"t"],"setHitData",[7,"page_referrer",[44]]]]]]]]],[22,[1,[15,"m"],[2,[15,"f"],"getItem",[7,[15,"j"]]]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"n",["require","internal.addDataLayerEventListener"]],[52,"o",["require","internal.enableAutoEventOnHistoryChange"]],[52,"p",["require","internal.getDestinationIds"]],[52,"q",["require","internal.sendGtagEvent"]],[52,"r",["o",[8,"interval",1000]]],[22,[28,[15,"r"]],[46,[2,[15,"a"],"gtmOnFailure",[7]],[36]]],[2,[15,"f"],"setItem",[7,[15,"j"],true]],["n","gtm.historyChange-v2",[51,"",[7,"t","u"],["u"],[52,"v",[16,[15,"t"],"gtm.oldUrl"]],[22,[20,[16,[15,"t"],"gtm.newUrl"],[15,"v"]],[46,[36]]],[52,"w",[16,[15,"t"],"gtm.historyChangeSource"]],[22,[1,[1,[21,[15,"w"],"pushState"],[21,[15,"w"],"popstate"]],[21,[15,"w"],"replaceState"]],[46,[36]]],[52,"x",[39,[30,[28,[28,[17,[15,"a"],"includeParams"]]],[15,"m"]],[8,"page_location",[16,[15,"t"],"gtm.newUrl"],"page_referrer",[15,"v"]],[8]]],[52,"y",[8,"eventId",[16,[15,"t"],"gtm.uniqueEventId"]]],[22,[15,"m"],[46,["s",[15,"y"]],["q",["p"],[15,"i"],[15,"x"],[15,"y"]]],[46,["q",[15,"l"],[15,"i"],[15,"x"],[15,"y"]],["e",[15,"l"],"page_referrer",[15,"v"]]]]],[15,"r"]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ccd_em_scroll",[46,"a"],[50,"r",[46,"s"],[52,"t",[8]],[43,[15,"t"],[15,"j"],true],[43,[15,"t"],[15,"f"],true],[43,[15,"s"],"eventMetadata",[15,"t"]]],[52,"b",[13,[41,"$0"],[3,"$0",["require","internal.getFlags"]],["$0"]]],[52,"c",["require","internal.getProductSettingsParameter"]],[52,"d",["require","internal.registerCcdCallback"]],[52,"e",["require","templateStorage"]],[52,"f","speculative"],[52,"g","ae_block_scroll"],[52,"h","scroll"],[52,"i","isRegistered"],[52,"j","em_event"],[52,"k",[17,[15,"a"],"instanceDestinationId"]],[52,"l",[28,[28,[16,[15,"b"],"enableCcdEnhancedMeasurement"]]]],[22,["c",[15,"k"],[15,"g"]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[22,[15,"l"],[46,["d",[15,"k"],[51,"",[7,"s"],[22,[30,[21,[2,[15,"s"],"getEventName",[7]],[15,"h"]],[28,[2,[15,"s"],"getMetadata",[7,[15,"j"]]]]],[46,[36]]],[22,["c",[15,"k"],[15,"g"]],[46,[2,[15,"s"],"abort",[7]],[36]]],[2,[15,"s"],"setMetadata",[7,[15,"f"],false]],[22,[28,[17,[15,"a"],"includeParams"]],[46,[2,[15,"s"],"setHitData",[7,"percent_scrolled",[44]]]]]]]]],[22,[1,[15,"l"],[2,[15,"e"],"getItem",[7,[15,"i"]]]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"m",["require","internal.addDataLayerEventListener"]],[52,"n",["require","internal.enableAutoEventOnScroll"]],[52,"o",["require","internal.getDestinationIds"]],[52,"p",["require","internal.sendGtagEvent"]],[52,"q",["n",[8,"verticalThresholdUnits","PERCENT","verticalThresholds",90]]],[22,[28,[15,"q"]],[46,[2,[15,"a"],"gtmOnFailure",[7]],[36]]],[2,[15,"e"],"setItem",[7,[15,"i"],true]],["m","gtm.scrollDepth",[51,"",[7,"s","t"],["t"],[52,"u",[8,"eventId",[16,[15,"s"],"gtm.uniqueEventId"]]],[22,[28,[15,"l"]],[46,[53,[52,"w",[39,[28,[28,[17,[15,"a"],"includeParams"]]],[8,"percent_scrolled",[16,[15,"s"],"gtm.scrollThreshold"]],[8]]],["p",[15,"k"],[15,"h"],[15,"w"],[15,"u"]],[36]]]],[52,"v",[8,"percent_scrolled",[16,[15,"s"],"gtm.scrollThreshold"]]],["r",[15,"u"]],["p",["o"],[15,"h"],[15,"v"],[15,"u"]]],[15,"q"]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ccd_em_site_search",[46,"a"],[50,"e",[46,"j"],[52,"k",[2,[30,[15,"j"],""],"split",[7,","]]],[53,[41,"l"],[3,"l",0],[63,[7,"l"],[23,[15,"l"],[17,[15,"k"],"length"]],[33,[15,"l"],[3,"l",[0,[15,"l"],1]]],[46,[53,[52,"m",["b",[2,[16,[15,"k"],[15,"l"]],"trim",[7]]]],[22,[21,[15,"m"],[44]],[46,[36,[15,"m"]]]]]]]]],[50,"f",[46,"j","k"],[52,"l",[8,"search_term",[15,"j"]]],[52,"m",[2,[30,[15,"k"],""],"split",[7,","]]],[53,[41,"n"],[3,"n",0],[63,[7,"n"],[23,[15,"n"],[17,[15,"m"],"length"]],[33,[15,"n"],[3,"n",[0,[15,"n"],1]]],[46,[53,[52,"o",[2,[16,[15,"m"],[15,"n"]],"trim",[7]]],[52,"p",["b",[15,"o"]]],[22,[21,[15,"p"],[44]],[46,[43,[15,"l"],[0,"q_",[15,"o"]],[15,"p"]]]]]]]],[36,[15,"l"]]],[52,"b",["require","getQueryParameters"]],[52,"c",["require","internal.sendGtagEvent"]],[52,"d",["require","getContainerVersion"]],[52,"g",["e",[17,[15,"a"],"searchQueryParams"]]],[52,"h",[30,[17,[15,"a"],"instanceDestinationId"],[17,["d"],"containerId"]]],[52,"i",[8,"deferrable",true,"eventId",[17,[15,"a"],"gtmEventId"]]],[22,[15,"g"],[46,[53,[52,"j",[39,[28,[28,[17,[15,"a"],"includeParams"]]],["f",[15,"g"],[17,[15,"a"],"additionalQueryParams"]],[8]]],["c",[15,"h"],"view_search_results",[15,"j"],[15,"i"]]]]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ccd_em_video",[46,"a"],[50,"t",[46,"u"],[52,"v",[8]],[43,[15,"v"],[15,"l"],true],[43,[15,"v"],[15,"f"],true],[43,[15,"u"],"eventMetadata",[15,"v"]]],[52,"b",[13,[41,"$0"],[3,"$0",["require","internal.getFlags"]],["$0"]]],[52,"c",["require","internal.getProductSettingsParameter"]],[52,"d",["require","internal.registerCcdCallback"]],[52,"e",["require","templateStorage"]],[52,"f","speculative"],[52,"g","ae_block_video"],[52,"h","video_start"],[52,"i","video_progress"],[52,"j","video_complete"],[52,"k","isRegistered"],[52,"l","em_event"],[52,"m",[17,[15,"a"],"instanceDestinationId"]],[22,["c",[15,"m"],[15,"g"]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"n",[28,[28,[16,[15,"b"],"enableCcdEnhancedMeasurement"]]]],[22,[15,"n"],[46,["d",[15,"m"],[51,"",[7,"u"],[52,"v",[2,[15,"u"],"getEventName",[7]]],[52,"w",[30,[30,[20,[15,"v"],[15,"h"]],[20,[15,"v"],[15,"i"]]],[20,[15,"v"],[15,"j"]]]],[22,[30,[28,[15,"w"]],[28,[2,[15,"u"],"getMetadata",[7,[15,"l"]]]]],[46,[36]]],[22,["c",[15,"m"],[15,"g"]],[46,[2,[15,"u"],"abort",[7]],[36]]],[2,[15,"u"],"setMetadata",[7,[15,"f"],false]],[22,[28,[17,[15,"a"],"includeParams"]],[46,[2,[15,"u"],"setHitData",[7,"video_current_time",[44]]],[2,[15,"u"],"setHitData",[7,"video_duration",[44]]],[2,[15,"u"],"setHitData",[7,"video_percent",[44]]],[2,[15,"u"],"setHitData",[7,"video_provider",[44]]],[2,[15,"u"],"setHitData",[7,"video_title",[44]]],[2,[15,"u"],"setHitData",[7,"video_url",[44]]],[2,[15,"u"],"setHitData",[7,"visible",[44]]]]]]]]],[22,[1,[15,"n"],[2,[15,"e"],"getItem",[7,[15,"k"]]]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"o",["require","internal.addDataLayerEventListener"]],[52,"p",["require","internal.enableAutoEventOnYouTubeActivity"]],[52,"q",["require","internal.getDestinationIds"]],[52,"r",["require","internal.sendGtagEvent"]],[52,"s",["p",[8,"captureComplete",true,"captureStart",true,"progressThresholdsPercent",[7,10,25,50,75]]]],[22,[28,[15,"s"]],[46,[2,[15,"a"],"gtmOnFailure",[7]],[36]]],[2,[15,"e"],"setItem",[7,[15,"k"],true]],["o","gtm.video",[51,"",[7,"u","v"],["v"],[52,"w",[16,[15,"u"],"gtm.videoStatus"]],[41,"x"],[22,[20,[15,"w"],"start"],[46,[3,"x",[15,"h"]]],[46,[22,[20,[15,"w"],"progress"],[46,[3,"x",[15,"i"]]],[46,[22,[20,[15,"w"],"complete"],[46,[3,"x",[15,"j"]]],[46,[36]]]]]]],[52,"y",[39,[30,[28,[28,[17,[15,"a"],"includeParams"]]],[15,"n"]],[8,"video_current_time",[16,[15,"u"],"gtm.videoCurrentTime"],"video_duration",[16,[15,"u"],"gtm.videoDuration"],"video_percent",[16,[15,"u"],"gtm.videoPercent"],"video_provider",[16,[15,"u"],"gtm.videoProvider"],"video_title",[16,[15,"u"],"gtm.videoTitle"],"video_url",[16,[15,"u"],"gtm.videoUrl"],"visible",[16,[15,"u"],"gtm.videoVisible"]],[8]]],[52,"z",[8,"eventId",[16,[15,"u"],"gtm.uniqueEventId"]]],[22,[15,"n"],[46,["t",[15,"z"]],["r",["q"],[15,"x"],[15,"y"],[15,"z"]]],[46,["r",[15,"m"],[15,"x"],[15,"y"],[15,"z"]]]]],[15,"s"]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ccd_ga_first",[46,"a"],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ccd_ga_last",[46,"a"],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ccd_ga_regscope",[46,"a"],[50,"k",[46,"m"],[22,[30,[28,[15,"i"]],[21,[17,[15,"i"],"length"],2]],[46,[36,false]]],[52,"n",["l",[15,"m"]]],[53,[41,"o"],[3,"o",0],[63,[7,"o"],[23,[15,"o"],[17,[15,"n"],"length"]],[33,[15,"o"],[3,"o",[0,[15,"o"],1]]],[46,[53,[52,"p",[16,[15,"n"],[15,"o"]]],[52,"q",[17,[15,"p"],"countryCode"]],[52,"r",[17,[15,"p"],"regionCode"]],[52,"s",[20,[15,"q"],[15,"i"]]],[52,"t",[30,[28,[15,"r"]],[20,[15,"r"],[15,"j"]]]],[22,[1,[15,"s"],[15,"t"]],[46,[36,true]]]]]]],[36,false]],[50,"l",[46,"m"],[52,"n",[7]],[22,[28,[15,"m"]],[46,[36,[15,"n"]]]],[52,"o",[2,[15,"m"],"split",[7,","]]],[53,[41,"p"],[3,"p",0],[63,[7,"p"],[23,[15,"p"],[17,[15,"o"],"length"]],[33,[15,"p"],[3,"p",[0,[15,"p"],1]]],[46,[53,[52,"q",[2,[16,[15,"o"],[15,"p"]],"trim",[7]]],[22,[28,[15,"q"]],[46,[6]]],[52,"r",[2,[15,"q"],"split",[7,"-"]]],[52,"s",[16,[15,"r"],0]],[52,"t",[39,[20,[17,[15,"r"],"length"],2],[15,"q"],[44]]],[22,[30,[28,[15,"s"]],[21,[17,[15,"s"],"length"],2]],[46,[6]]],[22,[1,[21,[15,"t"],[44]],[30,[23,[17,[15,"t"],"length"],4],[18,[17,[15,"t"],"length"],6]]],[46,[6]]],[2,[15,"n"],"push",[7,[8,"countryCode",[15,"s"],"regionCode",[15,"t"]]]]]]]],[36,[15,"n"]]],[52,"b",["require","getContainerVersion"]],[52,"c",["require","internal.setRemoteConfigParameter"]],[52,"d",["require","internal.getCountryCode"]],[52,"e",["require","internal.getRegionCode"]],[22,[28,[17,[15,"a"],"settingsTable"]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[41,"f"],[52,"g",[8,"GOOGLE_SIGNALS",[7,[8,"name","allow_google_signals","value",false]],"DEVICE_AND_GEO",[7,[8,"name","geo_granularity","value",true],[8,"name","redact_device_info","value",true]]]],[52,"h",[30,[17,[15,"a"],"instanceDestinationId"],[17,["b"],"containerId"]]],[52,"i",["d"]],[52,"j",["e"]],[53,[41,"m"],[3,"m",0],[63,[7,"m"],[23,[15,"m"],[17,[17,[15,"a"],"settingsTable"],"length"]],[33,[15,"m"],[3,"m",[0,[15,"m"],1]]],[46,[53,[52,"n",[16,[17,[15,"a"],"settingsTable"],[15,"m"]]],[22,[30,[17,[15,"n"],"disallowAllRegions"],["k",[17,[15,"n"],"disallowedRegions"]]],[46,[53,[52,"o",[16,[15,"g"],[17,[15,"n"],"redactFieldGroup"]]],[22,[28,[15,"o"]],[46,[6]]],[53,[41,"p"],[3,"p",0],[63,[7,"p"],[23,[15,"p"],[17,[15,"o"],"length"]],[33,[15,"p"],[3,"p",[0,[15,"p"],1]]],[46,[53,[52,"q",[16,[15,"o"],[15,"p"]]],["c",[15,"h"],[17,[15,"q"],"name"],[17,[15,"q"],"value"]]]]]]]]]]]]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ogt_1p_data_v2",[46,"a"],[50,"j",[46,"l","m"],[52,"n",[16,[15,"a"],[15,"l"]]],[41,"o"],[22,[20,[15,"n"],"CSS_SELECTOR"],[46,[3,"o","css_selector"]],[46,[22,[20,[15,"n"],"JS_VAR"],[46,[3,"o","js_variable"]]]]],[36,[8,"selector_type",[15,"o"],"value",[16,[15,"a"],[15,"m"]]]]],[50,"k",[46,"l","m","n","o"],[22,[28,[16,[15,"a"],[15,"o"]]],[46,[36]]],[43,[15,"l"],[15,"m"],["j",[15,"n"],[15,"o"]]]],[22,[28,[17,[15,"a"],"isEnabled"]],[46,[2,[15,"a"],"gtmOnSuccess",[7]],[36]]],[52,"b",[13,[41,"$0"],[3,"$0",["require","internal.getFlags"]],["$0"]]],[52,"c",["require","internal.getDestinationIds"]],[52,"d",["require","internal.getProductSettingsParameter"]],[52,"e",["require","internal.locateUserData"]],[52,"f",["require","internal.setRemoteConfigParameter"]],[52,"g",["require","internal.registerCcdCallback"]],[52,"h",[30,["c"],[7]]],[52,"i",[8,"enable_code",true]],[22,[17,[15,"a"],"isAutoEnabled"],[46,[53,[52,"l",[7]],[22,[1,[17,[15,"a"],"autoCollectExclusionSelectors"],[17,[17,[15,"a"],"autoCollectExclusionSelectors"],"length"]],[46,[53,[41,"m"],[3,"m",0],[63,[7,"m"],[23,[15,"m"],[17,[17,[15,"a"],"autoCollectExclusionSelectors"],"length"]],[33,[15,"m"],[3,"m",[0,[15,"m"],1]]],[46,[53,[52,"n",[17,[16,[17,[15,"a"],"autoCollectExclusionSelectors"],[15,"m"]],"exclusionSelector"]],[22,[15,"n"],[46,[2,[15,"l"],"push",[7,[15,"n"]]]]]]]]]]],[43,[15,"i"],"auto_detect",[8,"email",[17,[15,"a"],"autoEmailEnabled"],"phone",[17,[15,"a"],"autoPhoneEnabled"],"address",[17,[15,"a"],"autoAddressEnabled"],"exclude_element_selectors",[15,"l"]]]]]],[22,[17,[15,"a"],"isManualEnabled"],[46,[53,[52,"l",[8]],[22,[17,[15,"a"],"manualEmailEnabled"],[46,["k",[15,"l"],"email","emailType","emailValue"]]],[22,[17,[15,"a"],"manualPhoneEnabled"],[46,["k",[15,"l"],"phone","phoneType","phoneValue"]]],[22,[17,[15,"a"],"manualAddressEnabled"],[46,[53,[52,"m",[8]],["k",[15,"m"],"first_name","firstNameType","firstNameValue"],["k",[15,"m"],"last_name","lastNameType","lastNameValue"],["k",[15,"m"],"street","streetType","streetValue"],["k",[15,"m"],"city","cityType","cityValue"],["k",[15,"m"],"region","regionType","regionValue"],["k",[15,"m"],"country","countryType","countryValue"],["k",[15,"m"],"postal_code","postalCodeType","postalCodeValue"],[43,[15,"l"],"name_and_address",[7,[15,"m"]]]]]],[43,[15,"i"],"selectors",[15,"l"]]]]],[65,"l",[15,"h"],[46,[53,[22,[1,[28,["d",[15,"l"],"ads_customer_data_terms"]],[28,["d",[15,"l"],"ga_customer_data_terms"]]],[46,[6]]],[41,"m"],[3,"m",[15,"i"]],[22,[1,[20,[2,[15,"l"],"indexOf",[7,"G-"]],0],[28,[16,[15,"b"],"enableEuidAutoMode"]]],[46,[53,[52,"p",[8,"enable_code",true,"selectors",[16,[15,"i"],"selectors"]]],[3,"m",[15,"p"]]]]],["f",[15,"l"],"user_data_settings",[15,"m"]],[22,[28,[16,[15,"b"],"enableCcdUserData"]],[46,[6]]],[52,"n",[16,[15,"m"],"auto_detect"]],[22,[28,[15,"n"]],[46,[6]]],[52,"o",[51,"",[7,"p"],[52,"q",[2,[15,"p"],"getMetadata",[7,"user_data_from_automatic"]]],[22,[15,"q"],[46,[36,[15,"q"]]]],[52,"r",["e",[8,"excludeElementSelectors",[16,[15,"n"],"exclude_element_selectors"],"fieldFilters",[8,"email",[16,[15,"n"],"email"],"phone",[16,[15,"n"],"phone"],"address",[16,[15,"n"],"address"]]]]],[52,"s",[1,[15,"r"],[16,[15,"r"],"elements"]]],[52,"t",[8]],[22,[1,[15,"s"],[18,[17,[15,"s"],"length"],0]],[46,[53,[41,"u"],[3,"u",0],[63,[7,"u"],[23,[15,"u"],[17,[15,"s"],"length"]],[33,[15,"u"],[3,"u",[0,[15,"u"],1]]],[46,[53,[52,"v",[16,[15,"s"],[15,"u"]]],[22,[20,[16,[15,"v"],"type"],"email"],[46,[43,[15,"t"],"email",[16,[15,"v"],"userData"]],[4]]]]]]]]],[2,[15,"p"],"setMetadata",[7,"user_data_from_automatic",[15,"t"]]],[36,[15,"t"]]]],["g",[15,"l"],[51,"",[7,"p"],[2,[15,"p"],"setMetadata",[7,"user_data_from_automatic_getter",[15,"o"]]]]]]]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__ogt_google_signals",[46,"a"],[52,"b",["require","internal.setProductSettingsParameter"]],[52,"c",["require","getContainerVersion"]],[52,"d",[13,[41,"$0"],[3,"$0",["require","internal.getFlags"]],["$0"]]],[52,"e",[30,[17,[15,"a"],"instanceDestinationId"],[17,["c"],"containerId"]]],["b",[15,"e"],"google_signals",[20,[17,[15,"a"],"serverMacroResult"],1]],[22,[17,[15,"d"],"enableGa4OnoRemarketing"],[46,["b",[15,"e"],"google_ono",[20,[17,[15,"a"],"serverMacroResult"],2]]]],[2,[15,"a"],"gtmOnSuccess",[7]]],[50,"__set_product_settings",[46,"a"],[52,"b",["require","internal.setProductSettingsParameter"]],[52,"c",["require","getContainerVersion"]],[52,"d",[30,[17,[15,"a"],"instanceDestinationId"],[17,["c"],"containerId"]]],["b",[15,"d"],"google_tld",[17,[15,"a"],"foreignTldMacroResult"]],["b",[15,"d"],"ga_restrict_domain",[20,[17,[15,"a"],"isChinaVipRegionMacroResult"],1]],[2,[15,"a"],"gtmOnSuccess",[7]]]]
,"permissions":{"__ccd_conversion_marking":{"read_container_data":{}},"__ccd_em_download":{"listen_data_layer":{"accessType":"specific","allowedEvents":["gtm.linkClick"]},"process_dom_events":{"targets":[{"targetType":"document","eventName":"click"},{"targetType":"document","eventName":"auxclick"}]},"access_template_storage":{}},"__ccd_em_form":{"access_template_storage":{}},"__ccd_em_outbound_click":{"get_url":{"urlParts":"any","queriesAllowed":"any"},"listen_data_layer":{"accessType":"specific","allowedEvents":["gtm.linkClick"]},"process_dom_events":{"targets":[{"targetType":"document","eventName":"click"},{"targetType":"document","eventName":"auxclick"}]},"access_template_storage":{}},"__ccd_em_page_view":{"listen_data_layer":{"accessType":"specific","allowedEvents":["gtm.historyChange-v2"]},"process_dom_events":{"targets":[{"targetType":"window","eventName":"pushstate"},{"targetType":"window","eventName":"popstate"}]},"access_template_storage":{}},"__ccd_em_scroll":{"listen_data_layer":{"accessType":"specific","allowedEvents":["gtm.scrollDepth"]},"process_dom_events":{"targets":[{"targetType":"window","eventName":"resize"},{"targetType":"window","eventName":"scroll"}]},"access_template_storage":{}},"__ccd_em_site_search":{"get_url":{"urlParts":"any","queriesAllowed":"any"},"read_container_data":{}},"__ccd_em_video":{"listen_data_layer":{"accessType":"specific","allowedEvents":["gtm.video"]},"process_dom_events":{"targets":[{"targetType":"element","eventName":"onStateChange"},{"targetType":"element","eventName":"onPlaybackRateChange"}]},"access_template_storage":{}},"__ccd_ga_first":{},"__ccd_ga_last":{},"__ccd_ga_regscope":{"read_container_data":{}},"__ogt_1p_data_v2":{"read_dom_elements":{"selectors":[{"type":"css","value":"*"}]},"access_dom_element_property":{"properties":[{"property":"textContent","read":true,"write":false},{"property":"value","read":true,"write":false},{"property":"tagName","read":true,"write":false},{"property":"children","read":true,"write":false},{"property":"childElementCount","read":true,"write":false}]}},"__ogt_google_signals":{"read_container_data":{}},"__set_product_settings":{"read_container_data":{}}}
,"security_groups":{
"google":["__ccd_conversion_marking","__ccd_em_download","__ccd_em_form","__ccd_em_outbound_click","__ccd_em_page_view","__ccd_em_scroll","__ccd_em_site_search","__ccd_em_video","__ccd_ga_first","__ccd_ga_last","__ccd_ga_regscope","__ogt_1p_data_v2","__ogt_google_signals","__set_product_settings"]}
,"infra":["__ccd_conversion_marking","__ccd_em_download","__ccd_em_form","__ccd_em_outbound_click","__ccd_em_page_view","__ccd_em_scroll","__ccd_em_site_search","__ccd_em_video","__ccd_ga_first","__ccd_ga_last","__ccd_ga_regscope","__ogt_1p_data_v2","__ogt_google_signals","__set_product_settings"]
};
/*
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var ba,da=function(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:{done:!0}}},ea=function(a){return a.raw=a},fa="function"==typeof Object.create?Object.create:function(a){var b=function(){};b.prototype=a;return new b},ha;
if("function"==typeof Object.setPrototypeOf)ha=Object.setPrototypeOf;else{var ia;a:{var ja={a:!0},la={};try{la.__proto__=ja;ia=la.a;break a}catch(a){}ia=!1}ha=ia?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null}
var ma=ha,na=function(a,b){a.prototype=fa(b.prototype);a.prototype.constructor=a;if(ma)ma(a,b);else for(var c in b)if("prototype"!=c)if(Object.defineProperties){var d=Object.getOwnPropertyDescriptor(b,c);d&&Object.defineProperty(a,c,d)}else a[c]=b[c];a.Ml=b.prototype},pa=this||self,qa=function(a){return a};var ra=function(a,b){this.h=a;this.B=b};var sa=function(a){return"number"===typeof a&&0<=a&&isFinite(a)&&0===a%1||"string"===typeof a&&"-"!==a[0]&&a===""+parseInt(a,10)},ta=function(){this.D={};this.F=!1;this.N={}},ua=function(a,b){var c=[],d;for(d in a.D)if(a.D.hasOwnProperty(d))switch(d=d.substr(5),b){case 1:c.push(d);break;case 2:c.push(a.get(d));break;case 3:c.push([d,a.get(d)])}return c};ta.prototype.get=function(a){return this.D["dust."+a]};ta.prototype.set=function(a,b){this.F||(a="dust."+a,this.N.hasOwnProperty(a)||(this.D[a]=b))};
ta.prototype.has=function(a){return this.D.hasOwnProperty("dust."+a)};var va=function(a,b){b="dust."+b;a.F||a.N.hasOwnProperty(b)||delete a.D[b]};ta.prototype.Ob=function(){this.F=!0};ta.prototype.He=function(){return this.F};var wa=function(a){this.B=new ta;this.h=[];this.D=!1;a=a||[];for(var b in a)a.hasOwnProperty(b)&&(sa(b)?this.h[Number(b)]=a[Number(b)]:this.B.set(b,a[b]))};ba=wa.prototype;ba.toString=function(a){if(a&&0<=a.indexOf(this))return"";for(var b=[],c=0;c<this.h.length;c++){var d=this.h[c];null===d||void 0===d?b.push(""):d instanceof wa?(a=a||[],a.push(this),b.push(d.toString(a)),a.pop()):b.push(d.toString())}return b.join(",")};
ba.set=function(a,b){if(!this.D)if("length"===a){if(!sa(b))throw Error("RangeError: Length property must be a valid integer.");this.h.length=Number(b)}else sa(a)?this.h[Number(a)]=b:this.B.set(a,b)};ba.get=function(a){return"length"===a?this.length():sa(a)?this.h[Number(a)]:this.B.get(a)};ba.length=function(){return this.h.length};ba.Nb=function(){for(var a=ua(this.B,1),b=0;b<this.h.length;b++)a.push(b+"");return new wa(a)};var xa=function(a,b){sa(b)?delete a.h[Number(b)]:va(a.B,b)};ba=wa.prototype;
ba.pop=function(){return this.h.pop()};ba.push=function(a){return this.h.push.apply(this.h,Array.prototype.slice.call(arguments))};ba.shift=function(){return this.h.shift()};ba.splice=function(a,b,c){return new wa(this.h.splice.apply(this.h,arguments))};ba.unshift=function(a){return this.h.unshift.apply(this.h,Array.prototype.slice.call(arguments))};ba.has=function(a){return sa(a)&&this.h.hasOwnProperty(a)||this.B.has(a)};ba.Ob=function(){this.D=!0;Object.freeze(this.h);this.B.Ob()};ba.He=function(){return this.D};var ya=function(){this.quota={}};ya.prototype.reset=function(){this.quota={}};var za=function(a,b){this.U=a;this.N=function(c,d,e){return c.apply(d,e)};this.D=b;this.B=new ta;this.h=this.F=void 0};za.prototype.add=function(a,b){Aa(this,a,b,!1)};var Aa=function(a,b,c,d){if(!a.B.He())if(d){var e=a.B;e.set(b,c);e.N["dust."+b]=!0}else a.B.set(b,c)};za.prototype.set=function(a,b){this.B.He()||(!this.B.has(a)&&this.D&&this.D.has(a)?this.D.set(a,b):this.B.set(a,b))};za.prototype.get=function(a){return this.B.has(a)?this.B.get(a):this.D?this.D.get(a):void 0};
za.prototype.has=function(a){return!!this.B.has(a)||!(!this.D||!this.D.has(a))};var Ba=function(a){var b=new za(a.U,a);a.F&&(b.F=a.F);b.N=a.N;b.h=a.h;return b};var Ca=function(){},Da=function(a){return"function"===typeof a},k=function(a){return"string"===typeof a},Ea=function(a){return"number"===typeof a&&!isNaN(a)},Ga=Array.isArray,Ia=function(a,b){if(a&&Ga(a))for(var c=0;c<a.length;c++)if(a[c]&&b(a[c]))return a[c]},Ka=function(a,b){if(!Ea(a)||!Ea(b)||a>b)a=0,b=2147483647;return Math.floor(Math.random()*(b-a+1)+a)},Ma=function(a,b){for(var c=new La,d=0;d<a.length;d++)c.set(a[d],!0);for(var e=0;e<b.length;e++)if(c.get(b[e]))return!0;return!1},m=function(a,
b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b(c,a[c])},Na=function(a){return!!a&&("[object Arguments]"===Object.prototype.toString.call(a)||Object.prototype.hasOwnProperty.call(a,"callee"))},Oa=function(a){return Math.round(Number(a))||0},Pa=function(a){return"false"===String(a).toLowerCase()?!1:!!a},Qa=function(a){var b=[];if(Ga(a))for(var c=0;c<a.length;c++)b.push(String(a[c]));return b},Ra=function(a){return a?a.replace(/^\s+|\s+$/g,""):""},Sa=function(){return new Date(Date.now())},
Ta=function(){return Sa().getTime()},La=function(){this.prefix="gtm.";this.values={}};La.prototype.set=function(a,b){this.values[this.prefix+a]=b};La.prototype.get=function(a){return this.values[this.prefix+a]};
var Ua=function(a,b,c){return a&&a.hasOwnProperty(b)?a[b]:c},Wa=function(a){var b=a;return function(){if(b){var c=b;b=void 0;try{c()}catch(d){}}}},Xa=function(a,b){for(var c in b)b.hasOwnProperty(c)&&(a[c]=b[c])},Ya=function(a){for(var b in a)if(a.hasOwnProperty(b))return!0;return!1},Za=function(a,b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]),c.push.apply(c,b[a[d]]||[]);return c},ab=function(a,b){var c=z;b=b||[];for(var d=c,e=0;e<a.length-1;e++){if(!d.hasOwnProperty(a[e]))return;d=d[a[e]];if(0<=
b.indexOf(d))return}return d},bb=function(a,b){for(var c={},d=c,e=a.split("."),f=0;f<e.length-1;f++)d=d[e[f]]={};d[e[e.length-1]]=b;return c},cb=/^\w{1,9}$/,db=function(a,b){a=a||{};b=b||",";var c=[];m(a,function(d,e){cb.test(d)&&e&&c.push(d)});return c.join(b)},eb=function(a,b){function c(){++d===b&&(e(),e=null,c.done=!0)}var d=0,e=a;c.done=!1;return c};var fb=function(a,b){ta.call(this);this.U=a;this.fb=b};na(fb,ta);fb.prototype.toString=function(){return this.U};fb.prototype.Nb=function(){return new wa(ua(this,1))};fb.prototype.h=function(a,b){return this.fb.apply(new gb(this,a),Array.prototype.slice.call(arguments,1))};fb.prototype.B=function(a,b){try{return this.h.apply(this,Array.prototype.slice.call(arguments,0))}catch(c){}};
var ib=function(a,b){for(var c,d=0;d<b.length&&!(c=hb(a,b[d]),c instanceof ra);d++);return c},hb=function(a,b){try{var c=a.get(String(b[0]));if(!(c&&c instanceof fb))throw Error("Attempting to execute non-function "+b[0]+".");return c.h.apply(c,[a].concat(b.slice(1)))}catch(e){var d=a.F;d&&d(e,b.context?{id:b[0],line:b.context.line}:null);throw e;}},gb=function(a,b){this.B=a;this.h=b},E=function(a,b){return Ga(b)?hb(a.h,b):b},F=function(a){return a.B.U};var jb=function(){ta.call(this)};na(jb,ta);jb.prototype.Nb=function(){return new wa(ua(this,1))};var kb={map:function(a){for(var b=new jb,c=0;c<arguments.length-1;c+=2){var d=E(this,arguments[c])+"",e=E(this,arguments[c+1]);b.set(d,e)}return b},list:function(a){for(var b=new wa,c=0;c<arguments.length;c++){var d=E(this,arguments[c]);b.push(d)}return b},fn:function(a,b,c){var d=this.h,e=E(this,b);if(!(e instanceof wa))throw Error("Error: non-List value given for Fn argument names.");var f=Array.prototype.slice.call(arguments,2);return new fb(a,function(){return function(g){var h=Ba(d);void 0===
h.h&&(h.h=this.h.h);for(var l=Array.prototype.slice.call(arguments,0),n=0;n<l.length;n++)if(l[n]=E(this,l[n]),l[n]instanceof ra)return l[n];for(var p=e.get("length"),q=0;q<p;q++)q<l.length?h.add(e.get(q),l[q]):h.add(e.get(q),void 0);h.add("arguments",new wa(l));var r=ib(h,f);if(r instanceof ra)return"return"===r.h?r.B:r}}())},control:function(a,b){return new ra(a,E(this,b))},undefined:function(){}};var lb=function(){this.D=new ya;this.h=new za(this.D)},mb=function(a,b,c){var d=new fb(b,c);d.Ob();a.h.set(b,d)},nb=function(a,b,c){kb.hasOwnProperty(b)&&mb(a,c||b,kb[b])};lb.prototype.execute=function(a,b){var c=Array.prototype.slice.call(arguments,0);return this.B(c)};lb.prototype.B=function(a){for(var b,c=0;c<arguments.length;c++)b=hb(this.h,arguments[c]);return b};lb.prototype.F=function(a,b){var c=Ba(this.h);c.h=a;for(var d,e=1;e<arguments.length;e++)d=d=hb(c,arguments[e]);return d};function ob(){for(var a=pb,b={},c=0;c<a.length;++c)b[a[c]]=c;return b}function qb(){var a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";a+=a.toLowerCase()+"0123456789-_";return a+"."}var pb,rb;function sb(a){pb=pb||qb();rb=rb||ob();for(var b=[],c=0;c<a.length;c+=3){var d=c+1<a.length,e=c+2<a.length,f=a.charCodeAt(c),g=d?a.charCodeAt(c+1):0,h=e?a.charCodeAt(c+2):0,l=f>>2,n=(f&3)<<4|g>>4,p=(g&15)<<2|h>>6,q=h&63;e||(q=64,d||(p=64));b.push(pb[l],pb[n],pb[p],pb[q])}return b.join("")}
function tb(a){function b(l){for(;d<a.length;){var n=a.charAt(d++),p=rb[n];if(null!=p)return p;if(!/^[\s\xa0]*$/.test(n))throw Error("Unknown base64 encoding at char: "+n);}return l}pb=pb||qb();rb=rb||ob();for(var c="",d=0;;){var e=b(-1),f=b(0),g=b(64),h=b(64);if(64===h&&-1===e)return c;c+=String.fromCharCode(e<<2|f>>4);64!=g&&(c+=String.fromCharCode(f<<4&240|g>>2),64!=h&&(c+=String.fromCharCode(g<<6&192|h)))}};var ub={},vb=function(a,b){ub[a]=ub[a]||[];ub[a][b]=!0},wb=function(){delete ub.GA4_EVENT},xb=function(a){var b=ub[a];if(!b||0===b.length)return"";for(var c=[],d=0,e=0;e<b.length;e++)0===e%8&&0<e&&(c.push(String.fromCharCode(d)),d=0),b[e]&&(d|=1<<e%8);0<d&&c.push(String.fromCharCode(d));return sb(c.join("")).replace(/\.+$/,"")};var yb=Array.prototype.indexOf?function(a,b){return Array.prototype.indexOf.call(a,b,void 0)}:function(a,b){if("string"===typeof a)return"string"!==typeof b||1!=b.length?-1:a.indexOf(b,0);for(var c=0;c<a.length;c++)if(c in a&&a[c]===b)return c;return-1};var zb,Ab=function(){if(void 0===zb){var a=null,b=pa.trustedTypes;if(b&&b.createPolicy){try{a=b.createPolicy("goog#html",{createHTML:qa,createScript:qa,createScriptURL:qa})}catch(c){pa.console&&pa.console.error(c.message)}zb=a}else zb=a}return zb};var Cb=function(a,b){this.h=b===Bb?a:""};Cb.prototype.toString=function(){return this.h+""};var Db=function(a){return a instanceof Cb&&a.constructor===Cb?a.h:"type_error:TrustedResourceUrl"},Bb={},Eb=function(a){var b=a,c=Ab(),d=c?c.createScriptURL(b):b;return new Cb(d,Bb)};var Fb=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;function Gb(){var a=pa.navigator;if(a){var b=a.userAgent;if(b)return b}return""}function Hb(a){return-1!=Gb().indexOf(a)};function Ib(){return Hb("Firefox")||Hb("FxiOS")}function Jb(){return(Hb("Chrome")||Hb("CriOS"))&&!Hb("Edge")||Hb("Silk")};var Kb={},Lb=function(a,b){this.h=b===Kb?a:""};Lb.prototype.toString=function(){return this.h.toString()};var Mb=function(a){return a instanceof Lb&&a.constructor===Lb?a.h:"type_error:SafeHtml"},Nb=function(a){var b=a,c=Ab(),d=c?c.createHTML(b):b;return new Lb(d,Kb)};/*
 SPDX-License-Identifier: Apache-2.0
*/
var Ob={};var Pb=function(){},Qb=function(a){this.h=a};na(Qb,Pb);Qb.prototype.toString=function(){return this.h};function Rb(a,b){var c=[new Qb(Sb[0].toLowerCase(),Ob)];if(0===c.length)throw Error("");var d=c.map(function(f){var g;if(f instanceof Qb)g=f.h;else throw Error("");return g}),e=b.toLowerCase();if(d.every(function(f){return 0!==e.indexOf(f)}))throw Error('Attribute "'+b+'" does not match any of the allowed prefixes.');a.setAttribute(b,"true")}function Tb(a){if("script"===a.tagName.toLowerCase())throw Error("");if("style"===a.tagName.toLowerCase())throw Error("");};var z=window,I=document,Ub=navigator,Vb=I.currentScript&&I.currentScript.src,Wb=function(a,b){var c=z[a];z[a]=void 0===c?b:c;return z[a]},Xb=function(a,b){b&&(a.addEventListener?a.onload=b:a.onreadystatechange=function(){a.readyState in{loaded:1,complete:1}&&(a.onreadystatechange=null,b())})},Yb={async:1,nonce:1,onerror:1,onload:1,src:1,type:1},Zb={onload:1,src:1,width:1,height:1,style:1};function $b(a,b,c){b&&m(b,function(d,e){d=d.toLowerCase();c.hasOwnProperty(d)||a.setAttribute(d,e)})}
var ac=function(a,b,c,d,e){var f=I.createElement("script");$b(f,d,Yb);f.type="text/javascript";f.async=!0;var g=Eb(a);f.src=Db(g);var h,l,n,p=null==(n=(l=(f.ownerDocument&&f.ownerDocument.defaultView||window).document).querySelector)?void 0:n.call(l,"script[nonce]");(h=p?p.nonce||p.getAttribute("nonce")||"":"")&&f.setAttribute("nonce",h);Xb(f,b);c&&(f.onerror=c);if(e)e.appendChild(f);else{var q=I.getElementsByTagName("script")[0]||I.body||I.head;q.parentNode.insertBefore(f,q)}return f},bc=function(){if(Vb){var a=
Vb.toLowerCase();if(0===a.indexOf("https://"))return 2;if(0===a.indexOf("http://"))return 3}return 1},cc=function(a,b,c,d,e){var f;f=void 0===f?!0:f;var g=e,h=!1;g||(g=I.createElement("iframe"),h=!0);$b(g,c,Zb);d&&m(d,function(n,p){g.dataset[n]=p});f&&(g.height="0",g.width="0",g.style.display="none",g.style.visibility="hidden");if(h){var l=I.body&&I.body.lastChild||I.body||I.head;l.parentNode.insertBefore(g,l)}Xb(g,b);void 0!==a&&(g.src=a);return g},dc=function(a,b,c){var d=new Image(1,1);d.onload=
function(){d.onload=null;b&&b()};d.onerror=function(){d.onerror=null;c&&c()};d.src=a},ec=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,!!d):a.attachEvent&&a.attachEvent("on"+b,c)},fc=function(a,b,c){a.removeEventListener?a.removeEventListener(b,c,!1):a.detachEvent&&a.detachEvent("on"+b,c)},J=function(a){z.setTimeout(a,0)},gc=function(a,b){return a&&b&&a.attributes&&a.attributes[b]?a.attributes[b].value:null},hc=function(a){var b=a.innerText||a.textContent||"";b&&" "!=b&&(b=b.replace(/^[\s\xa0]+|[\s\xa0]+$/g,
""));b&&(b=b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g," "));return b},ic=function(a){var b=I.createElement("div"),c=b,d=Nb("A<div>"+a+"</div>");void 0!==c.tagName&&Tb(c);c.innerHTML=Mb(d);b=b.lastChild;for(var e=[];b.firstChild;)e.push(b.removeChild(b.firstChild));return e},jc=function(a,b,c){c=c||100;for(var d={},e=0;e<b.length;e++)d[b[e]]=!0;for(var f=a,g=0;f&&g<=c;g++){if(d[String(f.tagName).toLowerCase()])return f;f=f.parentElement}return null},kc=function(a){var b;try{b=Ub.sendBeacon&&Ub.sendBeacon(a)}catch(c){vb("TAGGING",
15)}b||dc(a)},lc=function(a,b){var c=a[b];c&&"string"===typeof c.animVal&&(c=c.animVal);return c},mc=function(){var a=z.performance;if(a&&Da(a.now))return a.now()},nc=function(){return z.performance||void 0};var oc=function(a,b){return E(this,a)&&E(this,b)},pc=function(a,b){return E(this,a)===E(this,b)},qc=function(a,b){return E(this,a)||E(this,b)},rc=function(a,b){a=E(this,a);b=E(this,b);return-1<String(a).indexOf(String(b))},sc=function(a,b){a=String(E(this,a));b=String(E(this,b));return a.substring(0,b.length)===b},tc=function(a,b){a=E(this,a);b=E(this,b);switch(a){case "pageLocation":var c=z.location.href;b instanceof jb&&b.get("stripProtocol")&&(c=c.replace(/^https?:\/\//,""));return c}};var vc=function(){this.h=new lb;uc(this)};vc.prototype.execute=function(a){return this.h.B(a)};var uc=function(a){nb(a.h,"map");var b=function(c,d){mb(a.h,c,d)};b("and",oc);b("contains",rc);b("equals",pc);b("or",qc);b("startsWith",sc);b("variable",tc)};var wc=function(a){if(a instanceof wc)return a;this.Qa=a};wc.prototype.toString=function(){return String(this.Qa)};var zc=function(a){ta.call(this);this.h=a;this.set("then",yc(this));this.set("catch",yc(this,!0));this.set("finally",yc(this,!1,!0))};na(zc,jb);var yc=function(a,b,c){b=void 0===b?!1:b;c=void 0===c?!1:c;return new fb("",function(d,e){b&&(e=d,d=void 0);c&&(e=d);d instanceof fb||(d=void 0);e instanceof fb||(e=void 0);var f=Ba(this.h),g=function(l){return function(n){return c?(l.h(f),a.h):l.h(f,n)}},h=a.h.then(d&&g(d),e&&g(e));return new zc(h)})};/*
 jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
var Ac=/\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,Bc=function(a){if(null==a)return String(a);var b=Ac.exec(Object.prototype.toString.call(Object(a)));return b?b[1].toLowerCase():"object"},Cc=function(a,b){return Object.prototype.hasOwnProperty.call(Object(a),b)},Dc=function(a){if(!a||"object"!=Bc(a)||a.nodeType||a==a.window)return!1;try{if(a.constructor&&!Cc(a,"constructor")&&!Cc(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}for(var b in a);return void 0===
b||Cc(a,b)},K=function(a,b){var c=b||("array"==Bc(a)?[]:{}),d;for(d in a)if(Cc(a,d)){var e=a[d];"array"==Bc(e)?("array"!=Bc(c[d])&&(c[d]=[]),c[d]=K(e,c[d])):Dc(e)?(Dc(c[d])||(c[d]={}),c[d]=K(e,c[d])):c[d]=e}return c};var Fc=function(a,b,c){var d=[],e=[],f=function(h,l){for(var n=ua(h,1),p=0;p<n.length;p++)l[n[p]]=g(h.get(n[p]))},g=function(h){var l=d.indexOf(h);if(-1<l)return e[l];if(h instanceof wa){var n=[];d.push(h);e.push(n);for(var p=h.Nb(),q=0;q<p.length();q++)n[p.get(q)]=g(h.get(p.get(q)));return n}if(h instanceof zc)return h.h;if(h instanceof jb){var r={};d.push(h);e.push(r);f(h,r);return r}if(h instanceof fb){var u=function(){for(var v=Array.prototype.slice.call(arguments,0),w=0;w<v.length;w++)v[w]=Ec(v[w],
b,c);var x=new za(b?b.U:new ya);b&&(x.h=b.h);return g(h.h.apply(h,[x].concat(v)))};d.push(h);e.push(u);f(h,u);return u}var t=!1;switch(c){case 1:t=!0;break;case 2:t=!1;break;case 3:t=!1;break;default:}if(h instanceof wc&&t)return h.Qa;switch(typeof h){case "boolean":case "number":case "string":case "undefined":return h;case "object":if(null===h)return null}};return g(a)},Ec=function(a,
b,c){var d=[],e=[],f=function(h,l){for(var n in h)h.hasOwnProperty(n)&&l.set(n,g(h[n]))},g=function(h){var l=d.indexOf(h);if(-1<l)return e[l];if(Ga(h)||Na(h)){var n=new wa([]);d.push(h);e.push(n);for(var p in h)h.hasOwnProperty(p)&&n.set(p,g(h[p]));return n}if(Dc(h)){var q=new jb;d.push(h);e.push(q);f(h,q);return q}if("function"===typeof h){var r=new fb("",function(y){for(var A=Array.prototype.slice.call(arguments,0),B=0;B<A.length;B++)A[B]=Fc(E(this,A[B]),b,c);return g((0,this.h.N)(h,h,A))});d.push(h);
e.push(r);f(h,r);return r}var w=typeof h;if(null===h||"string"===w||"number"===w||"boolean"===w)return h;var x=!1;switch(c){case 1:x=
!0;break;case 2:x=!1;break;default:}if(void 0!==h&&x)return new wc(h)};return g(a)};var Gc=function(a){for(var b=[],c=0;c<a.length();c++)a.has(c)&&(b[c]=a.get(c));return b},Hc=function(a){if(void 0===a||Ga(a)||Dc(a))return!0;switch(typeof a){case "boolean":case "number":case "string":case "function":return!0}return!1};var Ic={supportedMethods:"concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(" "),concat:function(a,b){for(var c=[],d=0;d<this.length();d++)c.push(this.get(d));for(var e=1;e<arguments.length;e++)if(arguments[e]instanceof wa)for(var f=arguments[e],g=0;g<f.length();g++)c.push(f.get(g));else c.push(arguments[e]);return new wa(c)},every:function(a,b){for(var c=this.length(),d=0;d<this.length()&&
d<c;d++)if(this.has(d)&&!b.h(a,this.get(d),d,this))return!1;return!0},filter:function(a,b){for(var c=this.length(),d=[],e=0;e<this.length()&&e<c;e++)this.has(e)&&b.h(a,this.get(e),e,this)&&d.push(this.get(e));return new wa(d)},forEach:function(a,b){for(var c=this.length(),d=0;d<this.length()&&d<c;d++)this.has(d)&&b.h(a,this.get(d),d,this)},hasOwnProperty:function(a,b){return this.has(b)},indexOf:function(a,b,c){var d=this.length(),e=void 0===c?0:Number(c);0>e&&(e=Math.max(d+e,0));for(var f=e;f<d;f++)if(this.has(f)&&
this.get(f)===b)return f;return-1},join:function(a,b){for(var c=[],d=0;d<this.length();d++)c.push(this.get(d));return c.join(b)},lastIndexOf:function(a,b,c){var d=this.length(),e=d-1;void 0!==c&&(e=0>c?d+c:Math.min(c,e));for(var f=e;0<=f;f--)if(this.has(f)&&this.get(f)===b)return f;return-1},map:function(a,b){for(var c=this.length(),d=[],e=0;e<this.length()&&e<c;e++)this.has(e)&&(d[e]=b.h(a,this.get(e),e,this));return new wa(d)},pop:function(){return this.pop()},push:function(a,b){return this.push.apply(this,
Array.prototype.slice.call(arguments,1))},reduce:function(a,b,c){var d=this.length(),e,f=0;if(void 0!==c)e=c;else{if(0===d)throw Error("TypeError: Reduce on List with no elements.");for(var g=0;g<d;g++)if(this.has(g)){e=this.get(g);f=g+1;break}if(g===d)throw Error("TypeError: Reduce on List with no elements.");}for(var h=f;h<d;h++)this.has(h)&&(e=b.h(a,e,this.get(h),h,this));return e},reduceRight:function(a,b,c){var d=this.length(),e,f=d-1;if(void 0!==c)e=c;else{if(0===d)throw Error("TypeError: ReduceRight on List with no elements.");
for(var g=1;g<=d;g++)if(this.has(d-g)){e=this.get(d-g);f=d-(g+1);break}if(g>d)throw Error("TypeError: ReduceRight on List with no elements.");}for(var h=f;0<=h;h--)this.has(h)&&(e=b.h(a,e,this.get(h),h,this));return e},reverse:function(){for(var a=Gc(this),b=a.length-1,c=0;0<=b;b--,c++)a.hasOwnProperty(b)?this.set(c,a[b]):xa(this,c);return this},shift:function(){return this.shift()},slice:function(a,b,c){var d=this.length();void 0===b&&(b=0);b=0>b?Math.max(d+b,0):Math.min(b,d);c=void 0===c?d:0>c?
Math.max(d+c,0):Math.min(c,d);c=Math.max(b,c);for(var e=[],f=b;f<c;f++)e.push(this.get(f));return new wa(e)},some:function(a,b){for(var c=this.length(),d=0;d<this.length()&&d<c;d++)if(this.has(d)&&b.h(a,this.get(d),d,this))return!0;return!1},sort:function(a,b){var c=Gc(this);void 0===b?c.sort():c.sort(function(e,f){return Number(b.h(a,e,f))});for(var d=0;d<c.length;d++)c.hasOwnProperty(d)?this.set(d,c[d]):xa(this,d);return this},splice:function(a,b,c,d){return this.splice.apply(this,Array.prototype.splice.call(arguments,
1,arguments.length-1))},toString:function(){return this.toString()},unshift:function(a,b){return this.unshift.apply(this,Array.prototype.slice.call(arguments,1))}};var Jc="charAt concat indexOf lastIndexOf match replace search slice split substring toLowerCase toLocaleLowerCase toString toUpperCase toLocaleUpperCase trim".split(" "),Kc=new ra("break"),Lc=new ra("continue"),Mc=function(a,b){return E(this,a)+E(this,b)},Nc=function(a,b){return E(this,a)&&E(this,b)},Oc=function(a,b,c){a=E(this,a);b=E(this,b);c=E(this,c);if(!(c instanceof wa))throw Error("Error: Non-List argument given to Apply instruction.");if(null===a||void 0===a)throw Error("TypeError: Can't read property "+
b+" of "+a+".");var d="number"===typeof a;if("boolean"===typeof a||d){if("toString"===b){if(d&&c.length()){var e=Fc(c.get(0));try{return a.toString(e)}catch(q){}}return a.toString()}throw Error("TypeError: "+a+"."+b+" is not a function.");}if("string"===typeof a){if(0<=Jc.indexOf(b)){var f=Fc(c);return Ec(a[b].apply(a,f),this.h)}throw Error("TypeError: "+b+" is not a function");}if(a instanceof wa){if(a.has(b)){var g=a.get(b);if(g instanceof fb){var h=Gc(c);h.unshift(this.h);return g.h.apply(g,h)}throw Error("TypeError: "+
b+" is not a function");}if(0<=Ic.supportedMethods.indexOf(b)){var l=Gc(c);l.unshift(this.h);return Ic[b].apply(a,l)}}if(a instanceof fb||a instanceof jb){if(a.has(b)){var n=a.get(b);if(n instanceof fb){var p=Gc(c);p.unshift(this.h);return n.h.apply(n,p)}throw Error("TypeError: "+b+" is not a function");}if("toString"===b)return a instanceof fb?a.U:a.toString();if("hasOwnProperty"===b)return a.has.apply(a,Gc(c))}if(a instanceof wc&&"toString"===b)return a.toString();throw Error("TypeError: Object has no '"+
b+"' property.");},Pc=function(a,b){a=E(this,a);if("string"!==typeof a)throw Error("Invalid key name given for assignment.");var c=this.h;if(!c.has(a))throw Error("Attempting to assign to undefined value "+b);var d=E(this,b);c.set(a,d);return d},Qc=function(a){var b=Ba(this.h),c=ib(b,Array.prototype.slice.apply(arguments));if(c instanceof ra)return c},Rc=function(){return Kc},Sc=function(a){for(var b=E(this,a),c=0;c<b.length;c++){var d=E(this,b[c]);if(d instanceof ra)return d}},Tc=function(a){for(var b=
this.h,c=0;c<arguments.length-1;c+=2){var d=arguments[c];if("string"===typeof d){var e=E(this,arguments[c+1]);Aa(b,d,e,!0)}}},Uc=function(){return Lc},Vc=function(a,b,c){var d=new wa;b=E(this,b);for(var e=0;e<b.length;e++)d.push(b[e]);var f=[51,a,d].concat(Array.prototype.splice.call(arguments,2,arguments.length-2));this.h.add(a,E(this,f))},Wc=function(a,b){return E(this,a)/E(this,b)},Xc=function(a,b){a=E(this,a);b=E(this,b);var c=a instanceof wc,d=b instanceof wc;return c||d?c&&d?a.Qa==b.Qa:!1:a==
b},Yc=function(a){for(var b,c=0;c<arguments.length;c++)b=E(this,arguments[c]);return b};function Zc(a,b,c,d){for(var e=0;e<b();e++){var f=a(c(e)),g=ib(f,d);if(g instanceof ra){if("break"===g.h)break;if("return"===g.h)return g}}}function $c(a,b,c){if("string"===typeof b)return Zc(a,function(){return b.length},function(f){return f},c);if(b instanceof jb||b instanceof wa||b instanceof fb){var d=b.Nb(),e=d.length();return Zc(a,function(){return e},function(f){return d.get(f)},c)}}
var ad=function(a,b,c){a=E(this,a);b=E(this,b);c=E(this,c);var d=this.h;return $c(function(e){d.set(a,e);return d},b,c)},bd=function(a,b,c){a=E(this,a);b=E(this,b);c=E(this,c);var d=this.h;return $c(function(e){var f=Ba(d);Aa(f,a,e,!0);return f},b,c)},cd=function(a,b,c){a=E(this,a);b=E(this,b);c=E(this,c);var d=this.h;return $c(function(e){var f=Ba(d);f.add(a,e);return f},b,c)},ed=function(a,b,c){a=E(this,a);b=E(this,b);c=E(this,c);var d=this.h;return dd(function(e){d.set(a,e);return d},b,c)},fd=
function(a,b,c){a=E(this,a);b=E(this,b);c=E(this,c);var d=this.h;return dd(function(e){var f=Ba(d);Aa(f,a,e,!0);return f},b,c)},gd=function(a,b,c){a=E(this,a);b=E(this,b);c=E(this,c);var d=this.h;return dd(function(e){var f=Ba(d);f.add(a,e);return f},b,c)};
function dd(a,b,c){if("string"===typeof b)return Zc(a,function(){return b.length},function(d){return b[d]},c);if(b instanceof wa)return Zc(a,function(){return b.length()},function(d){return b.get(d)},c);throw new TypeError("The value is not iterable.");}
var hd=function(a,b,c,d){function e(p,q){for(var r=0;r<f.length();r++){var u=f.get(r);q.add(u,p.get(u))}}var f=E(this,a);if(!(f instanceof wa))throw Error("TypeError: Non-List argument given to ForLet instruction.");var g=this.h;d=E(this,d);var h=Ba(g);for(e(g,h);hb(h,b);){var l=ib(h,d);if(l instanceof ra){if("break"===l.h)break;if("return"===l.h)return l}var n=Ba(g);e(h,n);hb(n,c);h=n}},id=function(a){a=E(this,a);var b=this.h,c=!1;if(c&&!b.has(a))throw new ReferenceError(a+" is not defined.");return b.get(a)},jd=function(a,b){var c;a=E(this,a);b=E(this,b);if(void 0===a||null===a)throw Error("TypeError: cannot access property of "+a+".");if(a instanceof jb||a instanceof wa||a instanceof fb)c=a.get(b);else if("string"===typeof a)"length"===b?c=a.length:sa(b)&&(c=a[b]);else if(a instanceof wc)return;return c},kd=function(a,b){return E(this,a)>E(this,
b)},ld=function(a,b){return E(this,a)>=E(this,b)},md=function(a,b){a=E(this,a);b=E(this,b);a instanceof wc&&(a=a.Qa);b instanceof wc&&(b=b.Qa);return a===b},nd=function(a,b){return!md.call(this,a,b)},od=function(a,b,c){var d=[];E(this,a)?d=E(this,b):c&&(d=E(this,c));var e=ib(this.h,d);if(e instanceof ra)return e},pd=function(a,b){return E(this,a)<E(this,b)},qd=function(a,b){return E(this,a)<=E(this,b)},rd=function(a,b){return E(this,a)%E(this,b)},sd=function(a,b){return E(this,a)*E(this,b)},td=function(a){return-E(this,
a)},ud=function(a){return!E(this,a)},vd=function(a,b){return!Xc.call(this,a,b)},wd=function(){return null},xd=function(a,b){return E(this,a)||E(this,b)},yd=function(a,b){var c=E(this,a);E(this,b);return c},zd=function(a){return E(this,a)},Ad=function(a){return Array.prototype.slice.apply(arguments)},Bd=function(a){return new ra("return",E(this,a))},Cd=function(a,b,c){a=E(this,a);b=E(this,b);c=E(this,c);if(null===a||void 0===a)throw Error("TypeError: Can't set property "+b+" of "+a+".");(a instanceof
fb||a instanceof wa||a instanceof jb)&&a.set(b,c);return c},Dd=function(a,b){return E(this,a)-E(this,b)},Ed=function(a,b,c){a=E(this,a);var d=E(this,b),e=E(this,c);if(!Ga(d)||!Ga(e))throw Error("Error: Malformed switch instruction.");for(var f,g=!1,h=0;h<d.length;h++)if(g||a===E(this,d[h]))if(f=E(this,e[h]),f instanceof ra){var l=f.h;if("break"===l)return;if("return"===l||"continue"===l)return f}else g=!0;if(e.length===d.length+1&&(f=E(this,e[e.length-1]),f instanceof ra&&("return"===f.h||"continue"===
f.h)))return f},Fd=function(a,b,c){return E(this,a)?E(this,b):E(this,c)},Gd=function(a){a=E(this,a);return a instanceof fb?"function":typeof a},Hd=function(a){for(var b=this.h,c=0;c<arguments.length;c++){var d=arguments[c];"string"!==typeof d||b.add(d,void 0)}},Id=function(a,b,c,d){var e=E(this,d);if(E(this,c)){var f=ib(this.h,e);if(f instanceof ra){if("break"===f.h)return;if("return"===f.h)return f}}for(;E(this,a);){var g=ib(this.h,e);if(g instanceof ra){if("break"===g.h)break;if("return"===g.h)return g}E(this,
b)}},Md=function(a){return~Number(E(this,a))},Nd=function(a,b){return Number(E(this,a))<<Number(E(this,b))},Od=function(a,b){return Number(E(this,a))>>Number(E(this,b))},Pd=function(a,b){return Number(E(this,a))>>>Number(E(this,b))},Qd=function(a,b){return Number(E(this,a))&Number(E(this,b))},Rd=function(a,b){return Number(E(this,a))^Number(E(this,b))},Sd=function(a,b){return Number(E(this,a))|Number(E(this,b))};var Ud=function(){this.h=new lb;Td(this)};Ud.prototype.execute=function(a){return Vd(this.h.B(a))};
var Wd=function(a,b,c){return Vd(a.h.F(b,c))},Td=function(a){var b=function(d,e){nb(a.h,d,String(e))};b("control",49);b("fn",51);b("list",7);b("map",8);b("undefined",44);var c=function(d,e){mb(a.h,String(d),e)};c(0,Mc);c(1,Nc);c(2,Oc);c(3,Pc);c(53,Qc);c(4,Rc);c(5,Sc);c(52,Tc);c(6,Uc);c(9,Sc);c(50,Vc);c(10,Wc);c(12,Xc);c(13,Yc);c(47,ad);c(54,bd);c(55,cd);c(63,hd);c(64,ed);c(65,fd);c(66,gd);c(15,id);c(16,jd);c(17,jd);c(18,kd);c(19,ld);c(20,md);c(21,nd);c(22,od);c(23,pd);c(24,qd);c(25,rd);c(26,sd);c(27,
td);c(28,ud);c(29,vd);c(45,wd);c(30,xd);c(32,yd);c(33,yd);c(34,zd);c(35,zd);c(46,Ad);c(36,Bd);c(43,Cd);c(37,Dd);c(38,Ed);c(39,Fd);c(40,Gd);c(41,Hd);c(42,Id);c(58,Md);c(57,Nd);c(60,Od);c(61,Pd);c(56,Qd);c(62,Rd);c(59,Sd)};function Vd(a){if(a instanceof ra||a instanceof fb||a instanceof wa||a instanceof jb||a instanceof wc||null===a||void 0===a||"string"===typeof a||"number"===typeof a||"boolean"===typeof a)return a};var Xd=function(){var a=function(b){return{toString:function(){return b}}};return{Mi:a("consent"),Eg:a("convert_case_to"),Fg:a("convert_false_to"),Gg:a("convert_null_to"),Hg:a("convert_true_to"),Ig:a("convert_undefined_to"),zl:a("debug_mode_metadata"),Wa:a("function"),Bf:a("instance_name"),Bj:a("live_only"),Cj:a("malware_disabled"),Dj:a("metadata"),Gj:a("original_activity_id"),Dl:a("original_vendor_template_id"),Cl:a("once_on_load"),Fj:a("once_per_event"),Ih:a("once_per_load"),El:a("priority_override"),
Fl:a("respected_consent_types"),Mh:a("setup_tags"),Ab:a("tag_id"),Rh:a("teardown_tags")}}();var se;
var te=[],ue=[],ve=[],we=[],xe=[],ye={},ze,Ae,Ce=function(){var a=Be;Ae=Ae||a},De,Fe=function(a,b){var c={};c["function"]="__"+a;for(var d in b)b.hasOwnProperty(d)&&(c["vtp_"+d]=b[d]);return c},Ge=function(a,b){var c=a["function"],d=b&&b.event;if(!c)throw Error("Error: No function name given for function call.");var e=ye[c],f={},g;for(g in a)a.hasOwnProperty(g)&&0===g.indexOf("vtp_")&&(e&&d&&d.Wh&&d.Wh(a[g]),f[void 0!==e?g:g.substr(4)]=a[g]);e&&d&&d.Vh&&(f.vtp_gtmCachedValues=d.Vh);if(b){if(null==
b.name){var h;a:{var l=b.index;if(null==l)h="";else{var n;switch(b.type){case 2:n=te[l];break;case 1:n=we[l];break;default:h="";break a}var p=n&&n[Xd.Bf];h=p?String(p):""}}b.name=h}e&&(f.vtp_gtmEntityIndex=b.index,f.vtp_gtmEntityName=b.name)}return void 0!==e?e(f):se(c,f,b)},Ie=function(a,b,c){c=c||[];var d={},e;for(e in a)a.hasOwnProperty(e)&&(d[e]=He(a[e],b,c));return d},He=function(a,b,c){if(Ga(a)){var d;switch(a[0]){case "function_id":return a[1];case "list":d=[];for(var e=1;e<a.length;e++)d.push(He(a[e],
b,c));return d;case "macro":var f=a[1];if(c[f])return;var g=te[f];if(!g||b.Yf(g))return;c[f]=!0;var h=String(g[Xd.Bf]);try{var l=Ie(g,b,c);l.vtp_gtmEventId=b.id;b.priorityId&&(l.vtp_gtmPriorityId=b.priorityId);d=Ge(l,{event:b,index:f,type:2,name:h});De&&(d=De.Tj(d,l))}catch(y){b.ii&&b.ii(y,Number(f),h),d=!1}c[f]=!1;return d;case "map":d={};for(var n=1;n<a.length;n+=2)d[He(a[n],b,c)]=He(a[n+1],b,c);return d;case "template":d=[];for(var p=!1,q=1;q<a.length;q++){var r=He(a[q],b,c);Ae&&(p=p||r===Ae.oe);
d.push(r)}return Ae&&p?Ae.Vj(d):d.join("");case "escape":d=He(a[1],b,c);if(Ae&&Ga(a[1])&&"macro"===a[1][0]&&Ae.xk(a))return Ae.Qk(d);d=String(d);for(var u=2;u<a.length;u++)Yd[a[u]]&&(d=Yd[a[u]](d));return d;case "tag":var t=a[1];if(!we[t])throw Error("Unable to resolve tag reference "+t+".");return d={bi:a[2],index:t};case "zb":var v={arg0:a[2],arg1:a[3],ignore_case:a[5]};v["function"]=a[1];var w=Je(v,b,c),x=!!a[4];return x||2!==w?x!==(1===w):null;default:throw Error("Attempting to expand unknown Value type: "+
a[0]+".");}}return a},Je=function(a,b,c){try{return ze(Ie(a,b,c))}catch(d){JSON.stringify(a)}return 2};var Ke=function(a,b,c){var d;d=Error.call(this);this.message=d.message;"stack"in d&&(this.stack=d.stack);this.B=a;this.h=c};na(Ke,Error);function Le(a,b){if(Ga(a)){Object.defineProperty(a,"context",{value:{line:b[0]}});for(var c=1;c<a.length;c++)Le(a[c],b[c])}};var Me=function(a,b){var c;c=Error.call(this);this.message=c.message;"stack"in c&&(this.stack=c.stack);this.Mk=a;this.B=b;this.h=[]};na(Me,Error);var Oe=function(){return function(a,b){a instanceof Me||(a=new Me(a,Ne));b&&a.h.push(b);throw a;}};function Ne(a){if(!a.length)return a;a.push({id:"main",line:0});for(var b=a.length-1;0<b;b--)Ea(a[b].id)&&a.splice(b++,1);for(var c=a.length-1;0<c;c--)a[c].line=a[c-1].line;a.splice(0,1);return a};var Re=function(a){function b(r){for(var u=0;u<r.length;u++)d[r[u]]=!0}for(var c=[],d=[],e=Pe(a),f=0;f<ue.length;f++){var g=ue[f],h=Qe(g,e);if(h){for(var l=g.add||[],n=0;n<l.length;n++)c[l[n]]=!0;b(g.block||[])}else null===h&&b(g.block||[]);}for(var p=[],q=0;q<we.length;q++)c[q]&&!d[q]&&(p[q]=!0);return p},Qe=function(a,b){for(var c=a["if"]||[],d=0;d<c.length;d++){var e=b(c[d]);if(0===e)return!1;if(2===e)return null}for(var f=
a.unless||[],g=0;g<f.length;g++){var h=b(f[g]);if(2===h)return null;if(1===h)return!1}return!0},Pe=function(a){var b=[];return function(c){void 0===b[c]&&(b[c]=Je(ve[c],a));return b[c]}};var Se={Tj:function(a,b){b[Xd.Eg]&&"string"===typeof a&&(a=1==b[Xd.Eg]?a.toLowerCase():a.toUpperCase());b.hasOwnProperty(Xd.Gg)&&null===a&&(a=b[Xd.Gg]);b.hasOwnProperty(Xd.Ig)&&void 0===a&&(a=b[Xd.Ig]);b.hasOwnProperty(Xd.Hg)&&!0===a&&(a=b[Xd.Hg]);b.hasOwnProperty(Xd.Fg)&&!1===a&&(a=b[Xd.Fg]);return a}};var Te=function(){this.h={}};function Ue(a,b,c,d){if(a)for(var e=0;e<a.length;e++){var f=void 0,g="A policy function denied the permission request";try{f=a[e].call(void 0,b,c,d),g+="."}catch(h){g="string"===typeof h?g+(": "+h):h instanceof Error?g+(": "+h.message):g+"."}if(!f)throw new Ke(c,d,g);}}function Ve(a,b,c){return function(){var d=arguments[0];if(d){var e=a.h[d],f=a.h.all;if(e||f){var g=c.apply(void 0,Array.prototype.slice.call(arguments,0));Ue(e,b,d,g);Ue(f,b,d,g)}}}};var Ze=function(){var a=data.permissions||{},b=We.H,c=this;this.B=new Te;this.h={};var d={},e=Ve(this.B,b,function(){var f=arguments[0];return f&&d[f]?d[f].apply(void 0,Array.prototype.slice.call(arguments,0)):{}});m(a,function(f,g){var h={};m(g,function(l,n){var p=Xe(l,n);h[l]=p.assert;d[l]||(d[l]=p.ba)});c.h[f]=function(l,n){var p=h[l];if(!p)throw Ye(l,{},"The requested permission "+l+" is not configured.");var q=Array.prototype.slice.call(arguments,0);p.apply(void 0,q);e.apply(void 0,q)}})},af=
function(a){return $e.h[a]||function(){}};function Xe(a,b){var c=Fe(a,b);c.vtp_permissionName=a;c.vtp_createPermissionError=Ye;try{return Ge(c)}catch(d){return{assert:function(e){throw new Ke(e,{},"Permission "+e+" is unknown.");},ba:function(){for(var e={},f=0;f<arguments.length;++f)e["arg"+(f+1)]=arguments[f];return e}}}}function Ye(a,b,c){return new Ke(a,b,c)};var bf=!1;var cf={};cf.xl=Pa('');cf.Yj=Pa('');var df=bf,ef=cf.Yj,ff=cf.xl;var gf=function(a,b){var c=String(a);return c};
var nf=function(a){var b={},c=0,d=hf?27:10;m(a,function(f,g){if(void 0!==g)if(g=gf(g,100),jf.hasOwnProperty(f))b[jf[f]]=kf(g);else if(lf.hasOwnProperty(f)){var h=lf[f],l=kf(g);b.hasOwnProperty(h)||(b[h]=l)}else if("category"===f)for(var n=kf(g).split("/",5),p=0;p<n.length;p++){var q=mf[p],r=n[p];b.hasOwnProperty(q)||(b[q]=r)}else if(c<d){var u=10>c?""+c:String.fromCharCode(65+c-10);b["k"+u]=kf(gf(f,40));b["v"+u]=kf(g);c++}});var e=[];m(b,function(f,g){e.push(""+f+g)});return e.join("~")},kf=function(a){return(""+
a).replace(/~/g,function(){return"~~"})},hf=!1;hf=!0;var jf={item_id:"id",item_name:"nm",item_brand:"br",item_category:"ca",item_category2:"c2",item_category3:"c3",item_category4:"c4",item_category5:"c5",item_variant:"va",price:"pr",quantity:"qt",coupon:"cp",item_list_name:"ln",index:"lp",item_list_id:"li",discount:"ds",affiliation:"af",promotion_id:"pi",
promotion_name:"pn",creative_name:"cn",creative_slot:"cs",location_id:"lo"},lf={id:"id",name:"nm",brand:"br",variant:"va",list_name:"ln",list_position:"lp",list:"ln",position:"lp",creative:"cn"},mf=["ca","c2","c3","c4","c5"];var of=function(a){var b=[];m(a,function(c,d){null!=d&&b.push(encodeURIComponent(c)+"="+encodeURIComponent(String(d)))});return b.join("&")},pf=function(a,b,c,d){this.Ba=a.Ba;this.Sb=a.Sb;this.Rf=a.Rf;this.h=b;this.F=c;this.D=of(a.Ba);this.B=of(a.Rf);this.N=this.B.length;if(d&&16384<this.N)throw Error("EVENT_TOO_LARGE");};var qf=function(){this.events=[];this.h=this.Ba="";this.D=0;this.B=!1};qf.prototype.add=function(a){return this.F(a)?(this.events.push(a),this.Ba=a.D,this.h=a.h,this.D+=a.N,this.B=a.F,!0):!1};qf.prototype.F=function(a){var b=20>this.events.length&&16384>a.N+this.D,c=this.Ba===a.D&&this.h===a.h&&this.B===a.F;return 0==this.events.length||b&&c};
var rf=function(a,b){m(a,function(c,d){null!=d&&b.push(encodeURIComponent(c)+"="+encodeURIComponent(d))})},sf=function(a,b){var c=[];a.D&&c.push(a.D);b&&c.push("_s="+b);rf(a.Sb,c);var d=!1;a.B&&(c.push(a.B),d=!0);var e=c.join("&"),f="",g=e.length+a.h.length+1;d&&2048<g&&(f=c.pop(),e=c.join("&"));return{lg:e,body:f}},tf=function(a,b){var c=a.events;if(1==c.length)return sf(c[0],b);var d=[];a.Ba&&d.push(a.Ba);for(var e={},f=0;f<c.length;f++)m(c[f].Sb,function(u,t){null!=t&&(e[u]=e[u]||{},e[u][String(t)]=
e[u][String(t)]+1||1)});var g={};m(e,function(u,t){var v,w=-1,x=0;m(t,function(y,A){x+=A;var B=(y.length+u.length+2)*(A-1);B>w&&(v=y,w=B)});x==c.length&&(g[u]=v)});rf(g,d);b&&d.push("_s="+b);for(var h=d.join("&"),l=[],n={},p=0;p<c.length;n={Gd:n.Gd},p++){var q=[];n.Gd={};m(c[p].Sb,function(u){return function(t,v){g[t]!=""+v&&(u.Gd[t]=v)}}(n));c[p].B&&q.push(c[p].B);rf(n.Gd,q);l.push(q.join("&"))}var r=l.join("\r\n");return{lg:h,body:r}};var Df=/^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;function Ef(a,b){return"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[a<<2|b]};var Ff=/^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|DustMap|List|OpaqueValue)$/i,Gf={Fn:"function",DustMap:"Object",List:"Array"},L=function(a,b,c){for(var d=0;d<b.length;d++){var e=Ff.exec(b[d]);if(!e)throw Error("Internal Error in "+a);var f=e[1],g="!"===e[2],h=e[3],l=c[d];if(null==l){if(g)throw Error("Error in "+a+". Required argument "+f+" not supplied.");}else if("*"!==h){var n=typeof l;l instanceof fb?n="Fn":l instanceof wa?n="List":l instanceof jb?n="DustMap":l instanceof wc&&(n="OpaqueValue");
if(n!=h)throw Error("Error in "+a+". Argument "+f+" has type "+(Gf[n]||n)+", which does not match required type "+(Gf[h]||h)+".");}}};function Hf(a){return""+a}
function If(a,b){var c=[];return c};var Jf=function(a,b){var c=new fb(a,function(){for(var d=Array.prototype.slice.call(arguments,0),e=0;e<d.length;e++)d[e]=E(this,d[e]);return b.apply(this,d)});c.Ob();return c},Kf=function(a,b){var c=new jb,d;for(d in b)if(b.hasOwnProperty(d)){var e=b[d];Da(e)?c.set(d,Jf(a+"_"+d,e)):(Ea(e)||k(e)||"boolean"===typeof e)&&c.set(d,e)}c.Ob();return c};var Nf=function(a,b){L(F(this),["apiName:!string","message:?string"],arguments);var c={},d=new jb;return d=Kf("AssertApiSubject",c)};var Of=function(a,b){L(F(this),["actual:?*","message:?string"],arguments);if(a instanceof zc)throw Error("Argument actual cannot have type Promise. Assertions on asynchronous code aren't supported.");var c={},d=new jb;return d=Kf("AssertThatSubject",c)};function Pf(a){return function(){for(var b=[],c=this.h,d=0;d<arguments.length;++d)b.push(Fc(arguments[d],c));return Ec(a.apply(null,b))}}var Rf=function(){for(var a=Math,b=Qf,c={},d=0;d<b.length;d++){var e=b[d];a.hasOwnProperty(e)&&(c[e]=Pf(a[e].bind(a)))}return c};var Sf=function(a){var b;return b};var Tf=function(a){var b;return b};var Uf=function(a){return encodeURI(a)};var Vf=function(a){return encodeURIComponent(a)};var Wf=function(a){L(F(this),["message:?string"],arguments);};var Xf=function(a,b){L(F(this),["min:!number","max:!number"],arguments);return Ka(a,b)};var M=function(a,b,c){var d=a.h.h;if(!d)throw Error("Missing program state.");d.Rj.apply(null,Array.prototype.slice.call(arguments,1))};var Yf=function(){M(this,"read_container_data");var a=new jb;a.set("containerId",'G-P81QF1533Q');a.set("version",'1');a.set("environmentName",'');a.set("debugMode",df);a.set("previewMode",ff);a.set("environmentMode",ef);a.Ob();return a};var Zf=function(){return(new Date).getTime()};var $f=function(a){if(null===a)return"null";if(a instanceof wa)return"array";if(a instanceof fb)return"function";if(a instanceof wc){a=a.Qa;if(void 0===a.constructor||void 0===a.constructor.name){var b=String(a);return b.substring(8,b.length-1)}return String(a.constructor.name)}return typeof a};var ag=function(a){function b(c){return function(d){try{return c(d)}catch(e){(df||ff)&&a.call(this,e.message)}}}return{parse:b(function(c){return Ec(JSON.parse(c))}),stringify:b(function(c){return JSON.stringify(Fc(c))})}};var bg=function(a){return Oa(Fc(a,this.h))};var cg=function(a){return Number(Fc(a,this.h))};var dg=function(a){return null===a?"null":void 0===a?"undefined":a.toString()};var eg=function(a,b,c){var d=null,e=!1;return e?d:null};var Qf="floor ceil round max min abs pow sqrt".split(" ");var fg=function(){var a={};return{kk:function(b){return a.hasOwnProperty(b)?a[b]:void 0},nl:function(b,c){a[b]=c},reset:function(){a={}}}},gg=function(a,b){return function(){var c=Array.prototype.slice.call(arguments,0);c.unshift(b);return fb.prototype.h.apply(a,c)}},hg=function(a,b){L(F(this),["apiName:!string","mock:?*"],arguments);};var ig={};
ig.keys=function(a){return new wa};
ig.values=function(a){return new wa};
ig.entries=function(a){return new wa};
ig.freeze=function(a){return a};ig.delete=function(a,b){return!1};var kg=function(){this.h={};this.B={};};kg.prototype.get=function(a,b){var c=this.h.hasOwnProperty(a)?this.h[a]:void 0;return c};
kg.prototype.add=function(a,b,c){if(this.h.hasOwnProperty(a))throw"Attempting to add a function which already exists: "+a+".";if(this.B.hasOwnProperty(a))throw"Attempting to add an API with an existing private API name: "+a+".";this.h[a]=c?void 0:Da(b)?Jf(a,b):Kf(a,b)};function lg(a,b){var c=void 0;return c};function mg(){var a={};return a};var og=function(a){return ng?I.querySelectorAll(a):null},pg=function(a,b){if(!ng)return null;if(Element.prototype.closest)try{return a.closest(b)}catch(e){return null}var c=Element.prototype.matches||Element.prototype.webkitMatchesSelector||Element.prototype.mozMatchesSelector||Element.prototype.msMatchesSelector||Element.prototype.oMatchesSelector,d=a;if(!I.documentElement.contains(d))return null;do{try{if(c.call(d,b))return d}catch(e){break}d=d.parentElement||d.parentNode}while(null!==d&&1===d.nodeType);
return null},qg=!1;if(I.querySelectorAll)try{var rg=I.querySelectorAll(":root");rg&&1==rg.length&&rg[0]==I.documentElement&&(qg=!0)}catch(a){}var ng=qg;var O=function(a){vb("GTM",a)};
var sg=function(a){return null==a?"":k(a)?Ra(String(a)):"e0"},ug=function(a){return a.replace(tg,"")},wg=function(a){return vg(a.replace(/\s/g,""))},vg=function(a){return Ra(a.replace(xg,"").toLowerCase())},zg=function(a){a=a.replace(/[\s-()/.]/g,"");"+"!==a.charAt(0)&&(a="+"+a);return yg.test(a)?a:"e0"},Bg=function(a){var b=a.toLowerCase().split("@");if(2==b.length){var c=b[0];/^(gmail|googlemail)\./.test(b[1])&&(c=c.replace(/\./g,""));c=c+"@"+b[1];if(Ag.test(c))return c}return"e0"},Eg=function(a,
b){window.Promise||b([]);Promise.all(a.map(function(c){return c.value&&-1!==Cg.indexOf(c.name)?Dg(c.value).then(function(d){c.value=d}):Promise.resolve()})).then(function(){b(a)}).catch(function(){b([])})},Dg=function(a){if(""===a||"e0"===a)return Promise.resolve(a);if(z.crypto&&z.crypto.subtle){if(Fg.test(a))return Promise.resolve(a);try{var b=Gg(a);return z.crypto.subtle.digest("SHA-256",b).then(function(c){var d=Array.from(new Uint8Array(c)).map(function(e){return String.fromCharCode(e)}).join("");
return z.btoa(d).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}).catch(function(){return"e2"})}catch(c){return Promise.resolve("e2")}}else return Promise.resolve("e1")},Gg=function(a){var b;if(z.TextEncoder)b=(new TextEncoder("utf-8")).encode(a);else{for(var c=[],d=0;d<a.length;d++){var e=a.charCodeAt(d);128>e?c.push(e):2048>e?c.push(192|e>>6,128|e&63):55296>e||57344<=e?c.push(224|e>>12,128|e>>6&63,128|e&63):(e=65536+((e&1023)<<10|a.charCodeAt(++d)&1023),c.push(240|e>>18,128|e>>12&63,128|
e>>6&63,128|e&63))}b=new Uint8Array(c)}return b},xg=/[0-9`~!@#$%^&*()_\-+=:;<>,.?|/\\[\]]/g,Ag=/^\S+@\S+\.\S+$/,yg=/^\+\d{10,15}$/,tg=/[.~]/g,Hg=/^[0-9A-Za-z_-]{43}$/,Fg=/^[0-9A-Fa-f]{64}$/,Ig={},Jg=(Ig.email="em",Ig.phone_number="pn",Ig.first_name="fn",Ig.last_name="ln",Ig.street="sa",Ig.city="ct",Ig.region="rg",Ig.country="co",Ig.postal_code="pc",Ig.error_code="ec",Ig),Kg={},Lg=(Kg.email="sha256_email_address",Kg.phone_number="sha256_phone_number",Kg.first_name="sha256_first_name",Kg.last_name=
"sha256_last_name",Kg.street="sha256_street",Kg),Mg=function(a,b){function c(u,t,v,w){var x=sg(u);""!==x&&(Fg.test(x)?l.push({name:t,value:x,index:w}):l.push({name:t,value:v(x),index:w}))}function d(u,t){var v=u;if(k(v)||Ga(v)){v=Ga(u)?u:[u];for(var w=0;w<v.length;++w){var x=sg(v[w]),y=Fg.test(x);t&&!y&&O(89);!t&&y&&O(88)}}}function e(u,t){var v=u[t];d(v,!1);var w=Lg[t];u.hasOwnProperty(w)&&(u.hasOwnProperty(t)&&O(90),v=u[w],d(v,!0));return v}function f(u,t,v){var w=e(u,t);w=Ga(w)?w:[w];for(var x=
0;x<w.length;++x)c(w[x],t,v)}function g(u,t,v,w){var x=e(u,t);c(x,t,v,w)}function h(u){return function(t){O(64);return u(t)}}var l=[];if("https:"===z.location.protocol){f(a,"email",Bg);f(a,"phone_number",zg);f(a,"first_name",h(wg));f(a,"last_name",h(wg));var n=a.home_address||{};f(n,"street",h(vg));f(n,"city",h(vg));f(n,"postal_code",h(ug));f(n,"region",h(vg));f(n,"country",h(ug));var p=a.address||{};p=Ga(p)?p:[p];for(var q=0;q<p.length;q++){var r=p[q];g(r,"first_name",wg,q);g(r,"last_name",wg,q);
g(r,"street",vg,q);g(r,"city",vg,q);g(r,"postal_code",ug,q);g(r,"region",vg,q);g(r,"country",ug,q)}Eg(l,b)}else l.push({name:"error_code",value:"e3",index:void 0}),b(l)},Ng=function(a,b){Mg(a,function(c){for(var d=["tv.1"],e=0,f=0;f<c.length;++f){var g=c[f].name,h=c[f].value,l=c[f].index,n=Jg[g];n&&h&&(-1===Cg.indexOf(g)||/^e\d+$/.test(h)||Hg.test(h)||Fg.test(h))&&(void 0!==l&&(n+=l),d.push(n+"."+h),e++)}1===c.length&&"error_code"===c[0].name&&(e=0);b(encodeURIComponent(d.join("~")),e)})},Og=function(a){if(z.Promise)try{return new Promise(function(b){Ng(a,
function(c,d){b({kg:c,Pk:d})})})}catch(b){}},Cg=Object.freeze(["email","phone_number","first_name","last_name","street"]);var S={g:{K:"ad_storage",W:"analytics_storage",Qe:"region",Ag:"consent_updated",Re:"wait_for_update",Qi:"app_remove",Ri:"app_store_refund",Si:"app_store_subscription_cancel",Ti:"app_store_subscription_convert",Ui:"app_store_subscription_renew",Jg:"add_payment_info",Kg:"add_shipping_info",Fc:"add_to_cart",Gc:"remove_from_cart",Lg:"view_cart",Wb:"begin_checkout",Hc:"select_item",Eb:"view_item_list",Xb:"select_promotion",Fb:"view_promotion",Ha:"purchase",Ic:"refund",Ia:"view_item",Mg:"add_to_wishlist",
Vi:"first_open",Wi:"first_visit",Da:"gtag.config",Ja:"gtag.get",Xi:"in_app_purchase",Jc:"page_view",Yi:"session_start",Ue:"user_engagement",Yb:"gclid",na:"ads_data_redaction",da:"allow_ad_personalization_signals",Ve:"allow_custom_scripts",Zi:"allow_display_features",Kd:"allow_enhanced_conversions",Gb:"allow_google_signals",Ea:"allow_interest_groups",Ld:"auid",aj:"auto_detection_enabled",Hb:"aw_remarketing",We:"aw_remarketing_only",Md:"discount",Nd:"aw_feed_country",Od:"aw_feed_language",ia:"items",
Pd:"aw_merchant_id",Ng:"aw_basket_type",Qd:"campaign_content",Rd:"campaign_id",Sd:"campaign_medium",Td:"campaign_name",Kc:"campaign",Ud:"campaign_source",Vd:"campaign_term",ub:"client_id",bj:"content_group",cj:"content_type",Ka:"conversion_cookie_prefix",Lc:"conversion_id",hb:"conversion_label",xa:"conversion_linker",Xe:"conversion_api",vb:"cookie_domain",Ra:"cookie_expires",wb:"cookie_flags",Mc:"cookie_name",Ye:"cookie_path",ib:"cookie_prefix",Zb:"cookie_update",Nc:"country",va:"currency",Wd:"customer_lifetime_value",
Oc:"custom_map",dj:"debug_mode",fa:"developer_id",ej:"disable_merchant_reported_purchases",fj:"dc_custom_params",gj:"dc_natural_search",Ze:"dynamic_event_settings",ij:"affiliation",Og:"checkout_option",Pg:"checkout_step",jj:"coupon",af:"item_list_name",bf:"list_name",kj:"promotions",Xd:"shipping",Qg:"tax",Yd:"engagement_time_msec",Pc:"enhanced_client_id",Qc:"enhanced_conversions",Rg:"enhanced_conversions_automatic_settings",Zd:"estimated_delivery_date",cf:"euid_logged_in_state",ac:"event_callback",
bc:"event_developer_id_string",Sg:"event",ae:"event_settings",be:"event_timeout",lj:"experiments",df:"firebase_id",ce:"first_party_collection",de:"_x_20",Ib:"_x_19",Tg:"fledge",Ug:"flight_error_code",Vg:"flight_error_message",Wg:"gac_gclid",ee:"gac_wbraid",Xg:"gac_wbraid_multiple_conversions",ef:"ga_restrict_domain",ff:"ga_temp_client_id",Yg:"gdpr_applies",Zg:"geo_granularity",xb:"value_callback",jb:"value_key",cc:"global_developer_id_string",Al:"google_ono",kb:"google_signals",Rc:"google_tld",fe:"groups",
ah:"gsa_experiment_id",bh:"iframe_state",he:"ignore_referrer",hf:"internal_traffic_results",ie:"is_legacy_loaded",dh:"is_passthrough",Sa:"language",jf:"legacy_developer_id_string",ya:"linker",fc:"accept_incoming",Jb:"decorate_forms",V:"domains",hc:"url_position",eh:"method",Sc:"new_customer",fh:"non_interaction",mj:"optimize_id",Ta:"page_location",kf:"page_path",Ua:"page_referrer",ic:"page_title",gh:"passengers",hh:"phone_conversion_callback",nj:"phone_conversion_country_code",ih:"phone_conversion_css_class",
oj:"phone_conversion_ids",jh:"phone_conversion_number",kh:"phone_conversion_options",lh:"quantity",Tc:"redact_device_info",lf:"redact_enhanced_user_id",pj:"redact_ga_client_id",qj:"redact_user_id",je:"referral_exclusion_definition",Kb:"restricted_data_processing",rj:"retoken",mh:"screen_name",Lb:"screen_resolution",sj:"search_term",La:"send_page_view",Mb:"send_to",Uc:"session_duration",ke:"session_engaged",nf:"session_engaged_time",yb:"session_id",me:"session_number",Vc:"delivery_postal_code",nh:"tc_privacy_string",
oh:"temporary_client_id",tj:"tracking_id",pf:"traffic_type",Va:"transaction_id",za:"transport_url",ph:"trip_type",Wc:"update",zb:"url_passthrough",qf:"_user_agent_architecture",rf:"_user_agent_bitness",sf:"_user_agent_full_version_list",tf:"_user_agent_mobile",uf:"_user_agent_model",vf:"_user_agent_platform",wf:"_user_agent_platform_version",qh:"_user_agent_wait",xf:"_user_agent_wow64",oa:"user_data",rh:"user_data_auto_latency",sh:"user_data_auto_meta",th:"user_data_auto_multi",uh:"user_data_auto_selectors",
vh:"user_data_auto_status",wh:"user_data_mode",yf:"user_data_settings",Aa:"user_id",Ma:"user_properties",xh:"us_privacy_string",ra:"value",ne:"wbraid",yh:"wbraid_multiple_conversions",Eh:"_host_name",Fh:"_in_page_command",Cf:"_is_linker_valid",Gh:"_is_passthrough_cid",Hh:"non_personalized_ads",bd:"_sst_parameters"}},Pg={},Qg=Object.freeze((Pg[S.g.da]=1,Pg[S.g.Kd]=1,Pg[S.g.Gb]=1,Pg[S.g.ia]=1,Pg[S.g.vb]=1,Pg[S.g.Ra]=1,Pg[S.g.wb]=1,Pg[S.g.Mc]=1,Pg[S.g.Ye]=1,Pg[S.g.ib]=1,Pg[S.g.Zb]=1,Pg[S.g.Oc]=1,Pg[S.g.fa]=
1,Pg[S.g.Ze]=1,Pg[S.g.ac]=1,Pg[S.g.ae]=1,Pg[S.g.be]=1,Pg[S.g.ce]=1,Pg[S.g.ef]=1,Pg[S.g.kb]=1,Pg[S.g.Rc]=1,Pg[S.g.fe]=1,Pg[S.g.hf]=1,Pg[S.g.ie]=1,Pg[S.g.ya]=1,Pg[S.g.lf]=1,Pg[S.g.je]=1,Pg[S.g.Kb]=1,Pg[S.g.La]=1,Pg[S.g.Mb]=1,Pg[S.g.Uc]=1,Pg[S.g.nf]=1,Pg[S.g.Vc]=1,Pg[S.g.za]=1,Pg[S.g.Wc]=1,Pg[S.g.yf]=1,Pg[S.g.Ma]=1,Pg[S.g.bd]=1,Pg));Object.freeze([S.g.Ta,S.g.Ua,S.g.ic,S.g.Sa,S.g.mh,S.g.Aa,S.g.df,S.g.bj]);
var Rg={},Sg=Object.freeze((Rg[S.g.Qi]=1,Rg[S.g.Ri]=1,Rg[S.g.Si]=1,Rg[S.g.Ti]=1,Rg[S.g.Ui]=1,Rg[S.g.Vi]=1,Rg[S.g.Wi]=1,Rg[S.g.Xi]=1,Rg[S.g.Yi]=1,Rg[S.g.Ue]=1,Rg)),Tg={},Ug=Object.freeze((Tg[S.g.Jg]=1,Tg[S.g.Kg]=1,Tg[S.g.Fc]=1,Tg[S.g.Gc]=1,Tg[S.g.Lg]=1,Tg[S.g.Wb]=1,Tg[S.g.Hc]=1,Tg[S.g.Eb]=1,Tg[S.g.Xb]=1,Tg[S.g.Fb]=1,Tg[S.g.Ha]=1,Tg[S.g.Ic]=1,Tg[S.g.Ia]=1,Tg[S.g.Mg]=1,Tg)),Vg=Object.freeze([S.g.da,S.g.Gb,S.g.Zb]),Wg=Object.freeze([].concat(Vg)),Xg=Object.freeze([S.g.Ra,S.g.be,S.g.Uc,S.g.nf,S.g.Yd]),
Yg=Object.freeze([].concat(Xg)),Zg={},$g=(Zg[S.g.K]="1",Zg[S.g.W]="2",Zg),ah={},bh=Object.freeze((ah[S.g.da]=1,ah[S.g.Kd]=1,ah[S.g.Ea]=1,ah[S.g.Hb]=1,ah[S.g.We]=1,ah[S.g.Md]=1,ah[S.g.Nd]=1,ah[S.g.Od]=1,ah[S.g.ia]=1,ah[S.g.Pd]=1,ah[S.g.Ka]=1,ah[S.g.xa]=1,ah[S.g.vb]=1,ah[S.g.Ra]=1,ah[S.g.wb]=1,ah[S.g.ib]=1,ah[S.g.va]=1,ah[S.g.Wd]=1,ah[S.g.fa]=1,ah[S.g.ej]=1,ah[S.g.Qc]=1,ah[S.g.Zd]=1,ah[S.g.df]=1,ah[S.g.ce]=1,ah[S.g.ie]=1,ah[S.g.Sa]=1,ah[S.g.Sc]=1,ah[S.g.Ta]=1,ah[S.g.Ua]=1,ah[S.g.hh]=1,ah[S.g.ih]=1,
ah[S.g.jh]=1,ah[S.g.kh]=1,ah[S.g.Kb]=1,ah[S.g.La]=1,ah[S.g.Mb]=1,ah[S.g.Vc]=1,ah[S.g.Va]=1,ah[S.g.za]=1,ah[S.g.Wc]=1,ah[S.g.zb]=1,ah[S.g.oa]=1,ah[S.g.Aa]=1,ah[S.g.ra]=1,ah));Object.freeze(S.g);var ch={},dh=z.google_tag_manager=z.google_tag_manager||{},eh=Math.random();ch.kc="31i0";ch.ad=Number("0")||0;ch.ka="dataLayer";ch.Oi="ChAIgP24ngYQydHIwZfAxOAtEiUAWQfhkyLRhLxa4zKr4OcSefjGQTU5mpe/CJI102Bhxp9UOtg/GgJD7w\x3d\x3d";var fh={__cl:!0,__ecl:!0,__ehl:!0,__evl:!0,__fal:!0,__fil:!0,__fsl:!0,__hl:!0,__jel:!0,__lcl:!0,__sdl:!0,__tl:!0,__ytl:!0},gh={__paused:!0,__tg:!0},hh;for(hh in fh)fh.hasOwnProperty(hh)&&(gh[hh]=!0);var ih=Pa("true"),jh,kh=!1;kh=!0;
jh=kh;var lh,mh=!1;lh=mh;var nh,oh=!1;nh=oh;var ph,qh=!1;ph=qh;ch.Jd="www.googletagmanager.com";
var rh=""+ch.Jd+(jh?"/gtag/js":"/gtm.js"),sh=null,th=null,uh={},vh={},wh={},xh=function(){var a=dh.sequence||1;dh.sequence=a+1;return a};ch.Ni="true";var yh="";ch.ue=yh;var zh=new La,Ah={},Bh={},Eh={name:ch.ka,set:function(a,b){K(bb(a,b),Ah);Ch()},get:function(a){return Dh(a,2)},reset:function(){zh=new La;Ah={};Ch()}},Dh=function(a,b){return 2!=b?zh.get(a):Fh(a)},Fh=function(a,b){var c=a.split(".");b=b||[];for(var d=Ah,e=0;e<c.length;e++){if(null===d)return!1;if(void 0===d)break;d=d[c[e]];if(-1!==b.indexOf(d))return}return d},Nh=function(a,b){Bh.hasOwnProperty(a)||(zh.set(a,b),K(bb(a,b),Ah),Ch())},Oh=function(){for(var a=["gtm.allowlist","gtm.blocklist","gtm.whitelist",
"gtm.blacklist","tagTypeBlacklist"],b=0;b<a.length;b++){var c=a[b],d=Dh(c,1);if(Ga(d)||Dc(d))d=K(d);Bh[c]=d}},Ch=function(a){m(Bh,function(b,c){zh.set(b,c);K(bb(b),Ah);K(bb(b,c),Ah);a&&delete Bh[b]})},Ph=function(a,b){var c,d=1!==(void 0===b?2:b)?Fh(a):zh.get(a);"array"===Bc(d)||"object"===Bc(d)?c=K(d):c=d;return c};var Qh,Rh=!1;function Sh(){Rh=!0;Qh=Qh||{}}var Th=function(a){Rh||Sh();return Qh[a]};var Uh=function(){var a=z.screen;return{width:a?a.width:0,height:a?a.height:0}},Vh=function(a){if(I.hidden)return!0;var b=a.getBoundingClientRect();if(b.top==b.bottom||b.left==b.right||!z.getComputedStyle)return!0;var c=z.getComputedStyle(a,null);if("hidden"===c.visibility)return!0;for(var d=a,e=c;d;){if("none"===e.display)return!0;var f=e.opacity,g=e.filter;if(g){var h=g.indexOf("opacity(");0<=h&&(g=g.substring(h+8,g.indexOf(")",h)),"%"==g.charAt(g.length-1)&&(g=g.substring(0,g.length-1)),f=Math.min(g,
f))}if(void 0!==f&&0>=f)return!0;(d=d.parentElement)&&(e=z.getComputedStyle(d,null))}return!1};
var Wh=function(){var a=I.body,b=I.documentElement||a&&a.parentElement,c,d;if(I.compatMode&&"BackCompat"!==I.compatMode)c=b?b.clientHeight:0,d=b?b.clientWidth:0;else{var e=function(f,g){return f&&g?Math.min(f,g):Math.max(f,g)};c=e(b?b.clientHeight:0,a?a.clientHeight:0);d=e(b?b.clientWidth:0,a?a.clientWidth:0)}return{width:d,height:c}},Xh=function(a){var b=Wh(),c=b.height,d=b.width,e=a.getBoundingClientRect(),f=e.bottom-e.top,g=e.right-e.left;return f&&g?(1-Math.min((Math.max(0-e.left,0)+Math.max(e.right-
d,0))/g,1))*(1-Math.min((Math.max(0-e.top,0)+Math.max(e.bottom-c,0))/f,1)):0};var Yh=[],Zh=!(!z.IntersectionObserver||!z.IntersectionObserverEntry),$h=function(a,b,c){for(var d=new z.IntersectionObserver(a,{threshold:c}),e=0;e<b.length;e++)d.observe(b[e]);for(var f=0;f<Yh.length;f++)if(!Yh[f])return Yh[f]=d,f;return Yh.push(d)-1},ai=function(a,b,c){function d(h,l){var n={top:0,bottom:0,right:0,left:0,width:0,height:0},p={boundingClientRect:h.getBoundingClientRect(),
intersectionRatio:l,intersectionRect:n,isIntersecting:0<l,rootBounds:n,target:h,time:Ta()};J(function(){return a(p)})}for(var e=[],f=[],g=0;g<b.length;g++)e.push(0),f.push(-1);c.sort(function(h,l){return h-l});return function(){for(var h=0;h<b.length;h++){var l=Xh(b[h]);if(l>e[h])for(;f[h]<c.length-1&&l>=c[f[h]+1];)d(b[h],l),f[h]++;else if(l<e[h])for(;0<=f[h]&&l<=c[f[h]];)d(b[h],l),f[h]--;e[h]=l}}},bi=function(a,b,c){for(var d=0;d<c.length;d++)1<c[d]?c[d]=1:0>c[d]&&(c[d]=0);if(Zh){var e=!1;J(function(){e||
ai(a,b,c)()});return $h(function(f){e=!0;for(var g={zc:0};g.zc<f.length;g={zc:g.zc},g.zc++)J(function(h){return function(){return a(f[h.zc])}}(g))},b,c)}return z.setInterval(ai(a,b,c),1E3)},ci=function(a){Zh?0<=a&&a<Yh.length&&Yh[a]&&(Yh[a].disconnect(),Yh[a]=void 0):z.clearInterval(a)};var di=/:[0-9]+$/,ei=/^\d+\.fls\.doubleclick\.net$/,fi=function(a,b,c,d){for(var e=[],f=a.split("&"),g=0;g<f.length;g++){var h=f[g].split("=");if(decodeURIComponent(h[0]).replace(/\+/g," ")===b){var l=h.slice(1).join("=");if(!c)return d?l:decodeURIComponent(l).replace(/\+/g," ");e.push(d?l:decodeURIComponent(l).replace(/\+/g," "))}}return c?e:void 0},ii=function(a,b,c,d,e){b&&(b=String(b).toLowerCase());if("protocol"===b||"port"===b)a.protocol=gi(a.protocol)||gi(z.location.protocol);"port"===b?a.port=
String(Number(a.hostname?a.port:z.location.port)||("http"===a.protocol?80:"https"===a.protocol?443:"")):"host"===b&&(a.hostname=(a.hostname||z.location.hostname).replace(di,"").toLowerCase());return hi(a,b,c,d,e)},hi=function(a,b,c,d,e){var f,g=gi(a.protocol);b&&(b=String(b).toLowerCase());switch(b){case "url_no_fragment":f=ji(a);break;case "protocol":f=g;break;case "host":f=a.hostname.replace(di,"").toLowerCase();if(c){var h=/^www\d*\./.exec(f);h&&h[0]&&(f=f.substr(h[0].length))}break;case "port":f=
String(Number(a.port)||("http"===g?80:"https"===g?443:""));break;case "path":a.pathname||a.hostname||vb("TAGGING",1);f="/"===a.pathname.substr(0,1)?a.pathname:"/"+a.pathname;var l=f.split("/");0<=(d||[]).indexOf(l[l.length-1])&&(l[l.length-1]="");f=l.join("/");break;case "query":f=a.search.replace("?","");e&&(f=fi(f,e,!1));break;case "extension":var n=a.pathname.split(".");f=1<n.length?n[n.length-1]:"";f=f.split("/")[0];break;case "fragment":f=a.hash.replace("#","");break;default:f=a&&a.href}return f},
gi=function(a){return a?a.replace(":","").toLowerCase():""},ji=function(a){var b="";if(a&&a.href){var c=a.href.indexOf("#");b=0>c?a.href:a.href.substr(0,c)}return b},ki=function(a){var b=I.createElement("a");a&&(b.href=a);var c=b.pathname;"/"!==c[0]&&(a||vb("TAGGING",1),c="/"+c);var d=b.hostname.replace(di,"");return{href:b.href,protocol:b.protocol,host:b.host,hostname:d,pathname:c,search:b.search,hash:b.hash,port:b.port}},li=function(a){function b(n){var p=n.split("=")[0];return 0>d.indexOf(p)?n:
p+"=0"}function c(n){return n.split("&").map(b).filter(function(p){return void 0!==p}).join("&")}var d="gclid dclid gbraid wbraid gclaw gcldc gclha gclgf gclgb _gl".split(" "),e=ki(a),f=a.split(/[?#]/)[0],g=e.search,h=e.hash;"?"===g[0]&&(g=g.substring(1));"#"===h[0]&&(h=h.substring(1));g=c(g);h=c(h);""!==g&&(g="?"+g);""!==h&&(h="#"+h);var l=""+f+g+h;"/"===l[l.length-1]&&(l=l.substring(0,l.length-1));return l},mi=function(a){var b=ki(z.location.href),c=ii(b,"host",!1);if(c&&c.match(ei)){var d=ii(b,
"path").split(a+"=");if(1<d.length)return d[1].split(";")[0].split("?")[0]}};var ni={};
var pi=function(a,b,c){if(a){var d=a.element,e={eb:a.eb,tagName:d.tagName,type:1};b&&(e.querySelector=oi(d));c&&(e.isVisible=!Vh(d));return e}},si=function(a){if(0!=a.length){var b;b=qi(a,function(c){return!ri.test(c.eb)});b=qi(b,function(c){return"INPUT"===c.element.tagName.toUpperCase()});b=qi(b,function(c){return!Vh(c.element)});return b[0]}},qi=function(a,b){if(1>=a.length)return a;var c=a.filter(b);return 0==c.length?a:c},oi=function(a){var b;if(a===I.body)b="body";else{var c;if(a.id)c="#"+a.id;
else{var d;if(a.parentElement){var e;a:{var f=a.parentElement;if(f){for(var g=0;g<f.childElementCount;g++)if(f.children[g]===a){e=g+1;break a}e=-1}else e=1}d=oi(a.parentElement)+">:nth-child("+e+")"}else d="";c=d}b=c}return b},ti=!0,ui=!1;ni.Ki="true";
var vi=/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i,wi=/@(gmail|googlemail)\./i,ri=/support|noreply/i,xi="SCRIPT STYLE IMG SVG PATH BR NOSCRIPT TEXTAREA".split(" "),yi=["BR"],zi={},Ai=function(a){a=a||{uc:!0,vc:!0};a.lb=a.lb||{email:!0,phone:!0,address:!0};var b,c=a,d=!!c.uc+"."+!!c.vc;c&&c.gd&&c.gd.length&&(d+="."+c.gd.join("."));c&&c.lb&&(d+="."+c.lb.email+"."+c.lb.phone+"."+c.lb.address);b=d;var e=zi[b];if(e&&200>Ta()-e.timestamp)return e.result;var f;var g=[],h=I.body;if(h){for(var l=h.querySelectorAll("*"),
n=0;n<l.length&&1E4>n;n++){var p=l[n];if(!(0<=xi.indexOf(p.tagName.toUpperCase()))&&p.children instanceof HTMLCollection){for(var q=!1,r=0;r<p.childElementCount&&1E4>r;r++)if(!(0<=yi.indexOf(p.children[r].tagName.toUpperCase()))){q=!0;break}q||g.push(p)}}f={elements:g,status:1E4<l.length?"2":"1"}}else f={elements:g,status:"4"};var u=f,t=u.status,v=[],w;if(a.lb&&a.lb.email){for(var x=u.elements,y=[],A=0;A<x.length;A++){var B=x[A],C=B.textContent;"INPUT"===B.tagName.toUpperCase()&&B.value&&(C=B.value);
if(C){var D=C.match(vi);if(D){var H=D[0],G;if(z.location){var N=hi(z.location,"host",!0);G=0<=H.toLowerCase().indexOf(N)}else G=!1;G||y.push({element:B,eb:H})}}}var Q=a&&a.gd;if(Q&&0!==Q.length){for(var Z=[],oa=0;oa<y.length;oa++){for(var P=!0,R=0;R<Q.length;R++){var ka=Q[R];if(ka&&pg(y[oa].element,ka)){P=!1;break}}P&&Z.push(y[oa])}v=Z}else v=y;w=si(v);10<y.length&&(t="3")}var ca=[];!a.xi&&w&&(v=[w]);for(var aa=0;aa<v.length;aa++)ca.push(pi(v[aa],a.uc,a.vc));var Fa={elements:ca.slice(0,10),ng:pi(w,
a.uc,a.vc),status:t};zi[b]={timestamp:Ta(),result:Fa};return Fa},Bi=function(a){return a.tagName+":"+a.isVisible+":"+a.eb.length+":"+wi.test(a.eb)};
var Ci=function(a,b,c){if(!c)return!1;var d=c.selector_type,e=String(c.value),f;if("js_variable"===d){e=e.replace(/\["?'?/g,".").replace(/"?'?\]/g,"");for(var g=e.split(","),h=0;h<g.length;h++){var l=g[h].trim();if(l){if(0===l.indexOf("dataLayer."))f=Dh(l.substring(10));else{var n=l.split(".");f=z[n.shift()];for(var p=0;p<n.length;p++)f=f&&f[n[p]]}if(void 0!==f)break}}}else if("css_selector"===d&&ng){var q=og(e);if(q&&0<q.length){f=[];for(var r=0;r<q.length&&r<("email"===b||"phone_number"===b?5:1);r++)f.push(hc(q[r])||
Ra(q[r].value));f=1===f.length?f[0]:f}}return f?(a[b]=f,!0):!1},Di=function(a){if(a){var b={},c=!1;c=Ci(b,"email",a.email)||c;c=Ci(b,"phone_number",a.phone)||c;b.address=[];for(var d=a.name_and_address||[],e=0;e<d.length;e++){var f={};c=Ci(f,"first_name",d[e].first_name)||c;c=Ci(f,"last_name",d[e].last_name)||c;c=Ci(f,"street",d[e].street)||c;c=Ci(f,"city",d[e].city)||c;c=Ci(f,"region",d[e].region)||c;c=Ci(f,"country",d[e].country)||c;c=Ci(f,"postal_code",d[e].postal_code)||c;b.address.push(f)}return c?
b:void 0}},Ei=function(a){return a.D[S.g.yf]},Fi=function(a){var b=T(a,S.g.Qc)||{},c=!1;m(b,function(d,e){var f=e.enhanced_conversions_mode;if("automatic"===f||"manual"===f)c=!0});return c},Gi=function(a){if(!Dc(a))return!1;var b=a.mode;return"auto_detect"===b||"selectors"===b||"code"===b||!!a.enable_code},Hi=function(a){if(a){if("selectors"===a.mode||Dc(a.selectors))return Di(a.selectors);if("auto_detect"===a.mode||Dc(a.auto_detect)){var b;var c=a.auto_detect;if(c){var d=Ai({uc:!1,vc:!1,gd:c.exclude_element_selectors,
lb:{email:!!c.email,phone:!!c.phone,address:!!c.address}}).elements,e={};if(0<d.length)for(var f=0;f<d.length;f++){var g=d[f];if(1===g.type){e.email=g.eb;break}}b=e}else b=void 0;return b}}};var Mi={Ae:"US",si:"US-NC"};var Ni=new function(a,b){this.h=a;this.defaultValue=void 0===b?!1:b}(1933);var Oi=function(a){Oi[" "](a);return a};Oi[" "]=function(){};var Qi=function(){var a=Pi,b="Wf";if(a.Wf&&a.hasOwnProperty(b))return a.Wf;var c=new a;return a.Wf=c};var Pi=function(){var a={};this.h=function(){var b=Ni.h,c=Ni.defaultValue;return null!=a[b]?a[b]:c};this.B=function(){a[Ni.h]=!0}};var Ri=[];function Si(){var a=Wb("google_tag_data",{});a.ics||(a.ics={entries:{},set:Ti,update:Ui,addListener:Vi,notifyListeners:Wi,active:!1,usedDefault:!1,usedUpdate:!1,accessedDefault:!1,accessedAny:!1,wasSetLate:!1});return a.ics}
function Ti(a,b,c,d,e,f){var g=Si();g.usedDefault||!g.accessedDefault&&!g.accessedAny||(g.wasSetLate=!0);g.active=!0;g.usedDefault=!0;if(void 0!=b){var h=g.entries,l=h[a]||{},n=l.region,p=c&&k(c)?c.toUpperCase():void 0;d=d.toUpperCase();e=e.toUpperCase();if(""===d||p===e||(p===d?n!==e:!p&&!n)){var q=!!(f&&0<f&&void 0===l.update),r={region:p,initial:"granted"===b,update:l.update,quiet:q};if(""!==d||!1!==l.initial)h[a]=r;q&&z.setTimeout(function(){h[a]===r&&r.quiet&&(r.quiet=!1,Xi(a),Wi(),vb("TAGGING",
2))},f)}}}function Ui(a,b){var c=Si();c.usedDefault||c.usedUpdate||!c.accessedAny||(c.wasSetLate=!0);c.active=!0;c.usedUpdate=!0;if(void 0!=b){var d=Yi(c,a),e=c.entries,f=e[a]=e[a]||{};f.update="granted"===b;var g=Yi(c,a);f.quiet?(f.quiet=!1,Xi(a)):g!==d&&Xi(a)}}function Vi(a,b){Ri.push({Lf:a,ek:b})}function Xi(a){for(var b=0;b<Ri.length;++b){var c=Ri[b];Ga(c.Lf)&&-1!==c.Lf.indexOf(a)&&(c.ni=!0)}}
function Wi(a,b){for(var c=0;c<Ri.length;++c){var d=Ri[c];if(d.ni){d.ni=!1;try{d.ek({consentEventId:a,consentPriorityId:b})}catch(e){}}}}function Yi(a,b){var c=a.entries[b]||{};return void 0!==c.update?c.update:c.initial}
var Zi=function(a){var b=Si();b.accessedAny=!0;return Yi(b,a)},$i=function(a){var b=Si();b.accessedDefault=!0;return(b.entries[a]||{}).initial},aj=function(a){var b=Si();b.accessedAny=!0;return!(b.entries[a]||{}).quiet},bj=function(){if(!Qi().h())return!1;var a=Si();a.accessedAny=!0;return a.active},cj=function(){var a=Si();a.accessedDefault=!0;return a.usedDefault},dj=function(a,b){Si().addListener(a,b)},ej=function(a,b){Si().notifyListeners(a,b)},fj=function(a,b){function c(){for(var e=0;e<b.length;e++)if(!aj(b[e]))return!0;
return!1}if(c()){var d=!1;dj(b,function(e){d||c()||(d=!0,a(e))})}else a({})},gj=function(a,b){function c(){for(var f=[],g=0;g<d.length;g++){var h=d[g];!1===Zi(h)||e[h]||(f.push(h),e[h]=!0)}return f}var d=k(b)?[b]:b,e={};c().length!==d.length&&dj(d,function(f){var g=c();0<g.length&&(f.Lf=g,a(f))})};function hj(){}function ij(){};function jj(a){for(var b=[],c=0;c<kj.length;c++){var d=a(kj[c]);b[c]=!0===d?"1":!1===d?"0":"-"}return b.join("")}
var kj=[S.g.K,S.g.W],lj=function(a){var b=a[S.g.Qe];b&&O(40);var c=a[S.g.Re];c&&O(41);for(var d=Ga(b)?b:[b],e={Ac:0};e.Ac<d.length;e={Ac:e.Ac},++e.Ac)m(a,function(f){return function(g,h){if(g!==S.g.Qe&&g!==S.g.Re){var l=d[f.Ac],n=Mi.Ae,p=Mi.si;Si().set(g,h,l,n,p,c)}}}(e))},mj=function(a,b){m(a,function(c,d){Si().update(c,d)});ej(b.eventId,b.priorityId)},nj=function(a){var b=Zi(a);return void 0!=b?b:!0},oj=function(){return"G1"+jj(Zi)},pj=function(a,b){dj(a,b)},qj=function(a,b){gj(a,b)},rj=function(a,
b){fj(a,b)};var sj=function(a){var b=1,c,d,e;if(a)for(b=0,d=a.length-1;0<=d;d--)e=a.charCodeAt(d),b=(b<<6&268435455)+e+(e<<14),c=b&266338304,b=0!==c?b^c>>21:b;return b};var tj=function(a,b,c){for(var d=[],e=b.split(";"),f=0;f<e.length;f++){var g=e[f].split("="),h=g[0].replace(/^\s*|\s*$/g,"");if(h&&h==a){var l=g.slice(1).join("=").replace(/^\s*|\s*$/g,"");l&&c&&(l=decodeURIComponent(l));d.push(l)}}return d};var uj=function(a,b){var c=function(){};c.prototype=a.prototype;var d=new c;a.apply(d,Array.prototype.slice.call(arguments,1));return d},vj=function(a){var b=a;return function(){if(b){var c=b;b=null;c()}}};function wj(a){return"null"!==a.origin};var zj=function(a,b,c,d){return xj(d)?tj(a,String(b||yj()),c):[]},Cj=function(a,b,c,d,e){if(xj(e)){var f=Aj(a,d,e);if(1===f.length)return f[0].id;if(0!==f.length){f=Bj(f,function(g){return g.Be},b);if(1===f.length)return f[0].id;f=Bj(f,function(g){return g.ud},c);return f[0]?f[0].id:void 0}}};function Dj(a,b,c,d){var e=yj(),f=window;wj(f)&&(f.document.cookie=a);var g=yj();return e!=g||void 0!=c&&0<=zj(b,g,!1,d).indexOf(c)}
var Hj=function(a,b,c,d){function e(w,x,y){if(null==y)return delete h[x],w;h[x]=y;return w+"; "+x+"="+y}function f(w,x){if(null==x)return delete h[x],w;h[x]=!0;return w+"; "+x}if(!xj(c.pb))return 2;var g;void 0==b?g=a+"=deleted; expires="+(new Date(0)).toUTCString():(c.encode&&(b=encodeURIComponent(b)),b=Ej(b),g=a+"="+b);var h={};g=e(g,"path",c.path);var l;c.expires instanceof Date?l=c.expires.toUTCString():null!=c.expires&&(l=""+c.expires);g=e(g,"expires",l);g=e(g,"max-age",c.Ik);g=e(g,"samesite",
c.al);c.fl&&(g=f(g,"secure"));var n=c.domain;if(n&&"auto"===n.toLowerCase()){for(var p=Fj(),q=void 0,r=!1,u=0;u<p.length;++u){var t="none"!==p[u]?p[u]:void 0,v=e(g,"domain",t);v=f(v,c.flags);try{d&&d(a,h)}catch(w){q=w;continue}r=!0;if(!Gj(t,c.path)&&Dj(v,a,b,c.pb))return 0}if(q&&!r)throw q;return 1}n&&"none"!==n.toLowerCase()&&(g=e(g,"domain",n));g=f(g,c.flags);d&&d(a,h);return Gj(n,c.path)?1:Dj(g,a,b,c.pb)?0:1},Ij=function(a,b,c){null==c.path&&(c.path="/");c.domain||(c.domain="auto");return Hj(a,
b,c)};function Bj(a,b,c){for(var d=[],e=[],f,g=0;g<a.length;g++){var h=a[g],l=b(h);l===c?d.push(h):void 0===f||l<f?(e=[h],f=l):l===f&&e.push(h)}return 0<d.length?d:e}function Aj(a,b,c){for(var d=[],e=zj(a,void 0,void 0,c),f=0;f<e.length;f++){var g=e[f].split("."),h=g.shift();if(!b||-1!==b.indexOf(h)){var l=g.shift();l&&(l=l.split("-"),d.push({id:g.join("."),Be:1*l[0]||1,ud:1*l[1]||1}))}}return d}
var Ej=function(a){a&&1200<a.length&&(a=a.substring(0,1200));return a},Jj=/^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,Kj=/(^|\.)doubleclick\.net$/i,Gj=function(a,b){return Kj.test(window.document.location.hostname)||"/"===b&&Jj.test(a)},yj=function(){return wj(window)?window.document.cookie:""},Fj=function(){var a=[],b=window.document.location.hostname.split(".");if(4===b.length){var c=b[b.length-1];if(parseInt(c,10).toString()===c)return["none"]}for(var d=b.length-2;0<=d;d--)a.push(b.slice(d).join("."));
var e=window.document.location.hostname;Kj.test(e)||Jj.test(e)||a.push("none");return a},xj=function(a){if(!Qi().h()||!a||!bj())return!0;if(!aj(a))return!1;var b=Zi(a);return null==b?!0:!!b};var Lj=function(a){var b=Math.round(2147483647*Math.random());return a?String(b^sj(a)&2147483647):String(b)},Mj=function(a){return[Lj(a),Math.round(Ta()/1E3)].join(".")},Pj=function(a,b,c,d,e){var f=Nj(b);return Cj(a,f,Oj(c),d,e)},Qj=function(a,b,c,d){var e=""+Nj(c),f=Oj(d);1<f&&(e+="-"+f);return[b,e,a].join(".")},Nj=function(a){if(!a)return 1;a=0===a.indexOf(".")?a.substr(1):a;return a.split(".").length},Oj=function(a){if(!a||"/"===a)return 1;"/"!==a[0]&&(a="/"+a);"/"!==a[a.length-1]&&(a+="/");return a.split("/").length-
1};function Rj(a,b,c,d){var e,f=Number(null!=a.Cb?a.Cb:void 0);0!==f&&(e=new Date((b||Ta())+1E3*(f||7776E3)));return{path:a.path,domain:a.domain,flags:a.flags,encode:!!c,expires:e,pb:d}};var Sj;var Wj=function(){var a=Tj,b=Uj,c=Vj(),d=function(g){a(g.target||g.srcElement||{})},e=function(g){b(g.target||g.srcElement||{})};if(!c.init){ec(I,"mousedown",d);ec(I,"keyup",d);ec(I,"submit",e);var f=HTMLFormElement.prototype.submit;HTMLFormElement.prototype.submit=function(){b(this);f.call(this)};c.init=!0}},Xj=function(a,b,c,d,e){var f={callback:a,domains:b,fragment:2===c,placement:c,forms:d,sameHost:e};Vj().decorators.push(f)},Yj=function(a,b,c){for(var d=Vj().decorators,e={},f=0;f<d.length;++f){var g=
d[f],h;if(h=!c||g.forms)a:{var l=g.domains,n=a,p=!!g.sameHost;if(l&&(p||n!==I.location.hostname))for(var q=0;q<l.length;q++)if(l[q]instanceof RegExp){if(l[q].test(n)){h=!0;break a}}else if(0<=n.indexOf(l[q])||p&&0<=l[q].indexOf(n)){h=!0;break a}h=!1}if(h){var r=g.placement;void 0==r&&(r=g.fragment?2:1);r===b&&Xa(e,g.callback())}}return e};function Vj(){var a=Wb("google_tag_data",{}),b=a.gl;b&&b.decorators||(b={decorators:[]},a.gl=b);return b};var Zj=/(.*?)\*(.*?)\*(.*)/,ak=/^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,bk=/^(?:www\.|m\.|amp\.)+/,ck=/([^?#]+)(\?[^#]*)?(#.*)?/;function dk(a){return new RegExp("(.*?)(^|&)"+a+"=([^&]*)&?(.*)")}var fk=function(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];void 0!==d&&d===d&&null!==d&&"[object Object]"!==d.toString()&&(b.push(c),b.push(sb(String(d))))}var e=b.join("*");return["1",ek(e),e].join("*")};
function ek(a,b){var c=[Ub.userAgent,(new Date).getTimezoneOffset(),Ub.userLanguage||Ub.language,Math.floor(Ta()/60/1E3)-(void 0===b?0:b),a].join("*"),d;if(!(d=Sj)){for(var e=Array(256),f=0;256>f;f++){for(var g=f,h=0;8>h;h++)g=g&1?g>>>1^3988292384:g>>>1;e[f]=g}d=e}Sj=d;for(var l=4294967295,n=0;n<c.length;n++)l=l>>>8^Sj[(l^c.charCodeAt(n))&255];return((l^-1)>>>0).toString(36)}
function gk(){return function(a){var b=ki(z.location.href),c=b.search.replace("?",""),d=fi(c,"_gl",!1,!0)||"";a.query=hk(d)||{};var e=ii(b,"fragment").match(dk("_gl"));a.fragment=hk(e&&e[3]||"")||{}}}function ik(a,b){var c=dk(a).exec(b),d=b;if(c){var e=c[2],f=c[4];d=c[1];f&&(d=d+e+f)}return d}
var jk=function(a,b){b||(b="_gl");var c=ck.exec(a);if(!c)return"";var d=c[1],e=ik(b,(c[2]||"").slice(1)),f=ik(b,(c[3]||"").slice(1));e.length&&(e="?"+e);f.length&&(f="#"+f);return""+d+e+f},kk=function(a){var b=gk(),c=Vj();c.data||(c.data={query:{},fragment:{}},b(c.data));var d={},e=c.data;e&&(Xa(d,e.query),a&&Xa(d,e.fragment));return d},hk=function(a){try{var b=lk(a,3);if(void 0!==b){for(var c={},d=b?b.split("*"):[],e=0;e+1<d.length;e+=2){var f=d[e],g=tb(d[e+1]);c[f]=g}vb("TAGGING",6);return c}}catch(h){vb("TAGGING",
8)}};function lk(a,b){if(a){var c;a:{for(var d=a,e=0;3>e;++e){var f=Zj.exec(d);if(f){c=f;break a}d=decodeURIComponent(d)}c=void 0}var g=c;if(g&&"1"===g[1]){var h=g[3],l;a:{for(var n=g[2],p=0;p<b;++p)if(n===ek(h,p)){l=!0;break a}l=!1}if(l)return h;vb("TAGGING",7)}}}
function mk(a,b,c,d){function e(p){p=ik(a,p);var q=p.charAt(p.length-1);p&&"&"!==q&&(p+="&");return p+n}d=void 0===d?!1:d;var f=ck.exec(c);if(!f)return"";var g=f[1],h=f[2]||"",l=f[3]||"",n=a+"="+b;d?l="#"+e(l.substring(1)):h="?"+e(h.substring(1));return""+g+h+l}
function nk(a,b){var c="FORM"===(a.tagName||"").toUpperCase(),d=Yj(b,1,c),e=Yj(b,2,c),f=Yj(b,3,c);if(Ya(d)){var g=fk(d);c?ok("_gl",g,a):pk("_gl",g,a,!1)}if(!c&&Ya(e)){var h=fk(e);pk("_gl",h,a,!0)}for(var l in f)if(f.hasOwnProperty(l))a:{var n=l,p=f[l],q=a;if(q.tagName){if("a"===q.tagName.toLowerCase()){pk(n,p,q);break a}if("form"===q.tagName.toLowerCase()){ok(n,p,q);break a}}"string"==typeof q&&mk(n,p,q)}}
function pk(a,b,c,d){if(c.href){var e=mk(a,b,c.href,void 0===d?!1:d);Fb.test(e)&&(c.href=e)}}
function ok(a,b,c){if(c&&c.action){var d=(c.method||"").toLowerCase();if("get"===d){for(var e=c.childNodes||[],f=!1,g=0;g<e.length;g++){var h=e[g];if(h.name===a){h.setAttribute("value",b);f=!0;break}}if(!f){var l=I.createElement("input");l.setAttribute("type","hidden");l.setAttribute("name",a);l.setAttribute("value",b);c.appendChild(l)}}else if("post"===d){var n=mk(a,b,c.action);Fb.test(n)&&(c.action=n)}}}
function Tj(a){try{var b;a:{for(var c=a,d=100;c&&0<d;){if(c.href&&c.nodeName.match(/^a(?:rea)?$/i)){b=c;break a}c=c.parentNode;d--}b=null}var e=b;if(e){var f=e.protocol;"http:"!==f&&"https:"!==f||nk(e,e.hostname)}}catch(g){}}function Uj(a){try{if(a.action){var b=ii(ki(a.action),"host");nk(a,b)}}catch(c){}}
var qk=function(a,b,c,d){Wj();Xj(a,b,"fragment"===c?2:1,!!d,!1)},rk=function(a,b){Wj();Xj(a,[hi(z.location,"host",!0)],b,!0,!0)},sk=function(){var a=I.location.hostname,b=ak.exec(I.referrer);if(!b)return!1;var c=b[2],d=b[1],e="";if(c){var f=c.split("/"),g=f[1];e="s"===g?decodeURIComponent(f[2]):decodeURIComponent(g)}else if(d){if(0===d.indexOf("xn--"))return!1;e=d.replace(/-/g,".").replace(/\.\./g,"-")}var h=a.replace(bk,""),l=e.replace(bk,""),n;if(!(n=h===l)){var p="."+l;n=h.substring(h.length-p.length,
h.length)===p}return n},tk=function(a,b){return!1===a?!1:a||b||sk()};var uk={};var vk=["1"],wk={},xk={},Bk=function(a,b){b=void 0===b?!0:b;var c=yk(a.prefix);if(!wk[c]&&!zk(c,a.path,a.domain)){if(void 0==uk.enable_auid_fl_iframe?0:uk.enable_auid_fl_iframe){var d=mi("auiddc");if(d){vb("TAGGING",17);wk[c]=d;return}}if(b){var e=yk(a.prefix),f=Mj();if(0===Ak(e,f,a)){var g=Wb("google_tag_data",{});g._gcl_au||(g._gcl_au=f)}zk(c,a.path,a.domain)}}};function Ak(a,b,c,d){var e=Qj(b,"1",c.domain,c.path),f=Rj(c,d);f.pb="ad_storage";return Ij(a,e,f)}
function zk(a,b,c){var d=Pj(a,b,c,vk,"ad_storage");if(!d)return!1;Ck(a,d);return!0}function Ck(a,b){var c=b.split(".");5===c.length?(wk[a]=c.slice(0,2).join("."),xk[a]={id:c.slice(2,4).join("."),gi:Number(c[4])||0}):3===c.length?xk[a]={id:c.slice(0,2).join("."),gi:Number(c[2])||0}:wk[a]=b}function yk(a){return(a||"_gcl")+"_au"}function Dk(a){bj()||a();fj(function(){Zi("ad_storage")&&a();gj(a,"ad_storage")},["ad_storage"])}
function Ek(a){var b=kk(!0),c=yk(a.prefix);Dk(function(){var d=b[c];if(d){Ck(c,d);var e=1E3*Number(wk[c].split(".")[1]);if(e){vb("TAGGING",16);var f=Rj(a,e);f.pb="ad_storage";var g=Qj(d,"1",a.domain,a.path);Ij(c,g,f)}}})}function Fk(a,b,c,d){d=d||{};var e=function(){var f=yk(d.prefix),g={},h=Pj(f,d.path,d.domain,vk,"ad_storage");if(!h)return g;g[f]=h;return g};Dk(function(){qk(e,a,b,c)})};var Gk=[];Gk[7]=!0;Gk[9]=!0;Gk[27]=!0;
Gk[10]=!0;Gk[11]=!0;Gk[13]=!0;
Gk[15]=!0;Gk[23]=!0;
Gk[35]=!0;Gk[36]=!0;
Gk[38]=!0;
Gk[43]=!0;a:{for(var Hk,Ik,Jk=0;Hk===Ik;)if(Hk=Math.floor(2*Math.random()),Ik=Math.floor(2*Math.random()),Jk++,20<Jk)break a;Hk?Gk[46]=!0:Gk[47]=!0}Gk[54]=!0;Gk[57]=!0;Gk[60]=!0;Gk[63]=!0;
Gk[68]=!0;
var U=function(a){return!!Gk[a]};var Kk=function(){dh.dedupe_gclid||(dh.dedupe_gclid=""+Mj());return dh.dedupe_gclid};var Lk=function(){var a=!1;return a};var We={H:"G-P81QF1533Q",tb:"100655040"},Mk={li:"G-P81QF1533Q|GT-KTBWB7T",mi:"G-P81QF1533Q"};We.Df=Pa("");
var Nk=function(){return Mk.li?Mk.li.split("|"):[We.H]},Ok=function(){return Mk.mi?Mk.mi.split("|"):[]},Pk=function(){this.container={};this.destination={};this.canonical={}},Rk=function(){for(var a=Qk(),b=Nk(),c=0;c<b.length;c++){var d=a.container[b[c]];!d||Ea(d)?a.container[b[c]]={state:2}:d.state=2}for(var e=Ok(),f=0;f<e.length;f++){var g=a.destination[e[f]];g&&0===g.state&&O(93);g?g.state=2:a.destination[e[f]]={state:2}}a.canonical[We.tb]=2},Sk=function(a){return!!Qk().container[a]},Tk=function(){var a=
Qk().container,b;for(b in a)if(a.hasOwnProperty(b)){var c=a[b];if(Ea(c)){if(1===c)return!0}else if(1===c.state)return!0}return!1},Uk=function(){var a={};m(Qk().destination,function(b,c){0===c.state&&(a[b]=c)});return a};function Qk(){var a=dh.tidr;a||(a=new Pk,dh.tidr=a);return a}var Vk={"":"n",UA:"u",AW:"a",DC:"d",G:"e",GF:"f",GT:"t",HA:"h",MC:"m",GTM:"g",OPT:"o"},Wk={UA:1,AW:2,DC:3,G:4,GF:5,GT:12,GTM:14,HA:6,MC:7},Xk=function(a){var b=We.H.split("-"),c=b[0].toUpperCase();if(U(45)){var d={};d.Wj=We.H;d.Xk=ch.ad;d.Zk=ch.kc;d.Gk=We.Df?2:1;jh?(d.Me=Wk[c],d.Me||(d.Me=0)):d.Me=ph?13:10;nh?d.fg=1:Lk()?d.fg=2:d.fg=3;var e;var f=d.Me,g=d.fg;void 0===f?e="":(g||(g=0),e=""+Ef(1,1)+"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[f<<2|g]);var h=d.Gl,l=4+e+(h?""+Ef(2,
1)+"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[h]:""),n,p=d.Zk;n=p&&Df.test(p)?""+Ef(3,2)+p:"";var q,r=d.Xk;q=r?""+Ef(4,1)+"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[r]:"";var u;var t=d.Wj;if(t&&a){var v=t.split("-"),w=v[0].toUpperCase();if("GTM"!==w&&"OPT"!==w)u="";else{var x=v[1];u=""+Ef(5,3)+"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[1+x.length]+(d.Gk||0)+x}}else u="";return l+n+q+u}var y=Vk[c]||"i",A=a&&"GTM"===c?b[1]:"OPT"===
c?b[1]:"",B="w";jh&&(B=Lk()?"s":"o");lh?("w"===B&&(B="x"),"o"===B&&(B="q")):nh?("w"===B&&(B="y"),"o"===B&&(B="r")):ph&&(B="z");return"2"+B+y+(4===ch.kc.length?ch.kc.slice(1):ch.kc)+A};function Yk(a,b){if(""===a)return b;var c=Number(a);return isNaN(c)?b:c};var Zk=function(a,b,c){a.addEventListener&&a.addEventListener(b,c,!1)};function $k(){return Hb("iPhone")&&!Hb("iPod")&&!Hb("iPad")}function al(){$k()||Hb("iPad")||Hb("iPod")};Hb("Opera");Hb("Trident")||Hb("MSIE");Hb("Edge");!Hb("Gecko")||-1!=Gb().toLowerCase().indexOf("webkit")&&!Hb("Edge")||Hb("Trident")||Hb("MSIE")||Hb("Edge");-1!=Gb().toLowerCase().indexOf("webkit")&&!Hb("Edge")&&Hb("Mobile");Hb("Macintosh");Hb("Windows");Hb("Linux")||Hb("CrOS");var bl=pa.navigator||null;bl&&(bl.appVersion||"").indexOf("X11");Hb("Android");$k();Hb("iPad");Hb("iPod");al();Gb().toLowerCase().indexOf("kaios");var cl=function(a,b,c,d){for(var e=b,f=c.length;0<=(e=a.indexOf(c,e))&&e<d;){var g=a.charCodeAt(e-1);if(38==g||63==g){var h=a.charCodeAt(e+f);if(!h||61==h||38==h||35==h)return e}e+=f+1}return-1},dl=/#|$/,el=function(a,b){var c=a.search(dl),d=cl(a,0,b,c);if(0>d)return null;var e=a.indexOf("&",d);if(0>e||e>c)e=c;d+=b.length+1;return decodeURIComponent(a.slice(d,-1!==e?e:0).replace(/\+/g," "))},fl=/[?&]($|#)/,gl=function(a,b,c){for(var d,e=a.search(dl),f=0,g,h=[];0<=(g=cl(a,f,b,e));)h.push(a.substring(f,
g)),f=Math.min(a.indexOf("&",g)+1||e,e);h.push(a.slice(f));d=h.join("").replace(fl,"$1");var l,n=null!=c?"="+encodeURIComponent(String(c)):"";var p=b+n;if(p){var q,r=d.indexOf("#");0>r&&(r=d.length);var u=d.indexOf("?"),t;0>u||u>r?(u=r,t=""):t=d.substring(u+1,r);q=[d.slice(0,u),t,d.slice(r)];var v=q[1];q[1]=p?v?v+"&"+p:p:v;l=q[0]+(q[1]?"?"+q[1]:"")+q[2]}else l=d;return l};var hl=function(a,b){if(a)for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b(a[c],c,a)};function il(a){if(!a||!I.head)return null;var b=jl("META");I.head.appendChild(b);b.httpEquiv="origin-trial";b.content=a;return b}
var Al=function(){if(z.top==z)return 0;var a=z.location.ancestorOrigins;if(a)return a[a.length-1]==z.location.origin?1:2;var b;var c=z.top;try{var d;if(d=!!c&&null!=c.location.href)b:{try{Oi(c.foo);d=!0;break b}catch(e){}d=!1}b=d}catch(e){b=!1}return b?1:2},jl=function(a,b){b=void 0===b?document:b;return b.createElement(String(a).toLowerCase())};function Bl(a,b,c,d){d=void 0===d?!1:d;a.google_image_requests||(a.google_image_requests=[]);var e=jl("IMG",a.document);if(c){var f=function(){if(c){var g=a.google_image_requests,h=yb(g,e);0<=h&&Array.prototype.splice.call(g,h,1)}e.removeEventListener&&e.removeEventListener("load",f,!1);e.removeEventListener&&e.removeEventListener("error",f,!1)};Zk(e,"load",f);Zk(e,"error",f)}d&&(e.attributionsrc="");e.src=b;a.google_image_requests.push(e)}
var Dl=function(a){var b;b=void 0===b?!1:b;var c="https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";hl(a,function(d,e){d&&(c+="&"+e+"="+encodeURIComponent(d))});Cl(c,b)},Cl=function(a,b){var c=window,d;b=void 0===b?!1:b;d=void 0===d?!1:d;if(c.fetch){var e={keepalive:!0,credentials:"include",redirect:"follow",method:"get",mode:"no-cors"};d&&(e.mode="cors",e.headers={"Attribution-Reporting-Eligible":"event-source"});c.fetch(a,e)}else Bl(c,a,void 0===b?!1:b,void 0===d?!1:d)};var El=function(){};var Fl=function(a){void 0!==a.addtlConsent&&"string"!==typeof a.addtlConsent&&(a.addtlConsent=void 0);void 0!==a.gdprApplies&&"boolean"!==typeof a.gdprApplies&&(a.gdprApplies=void 0);return void 0!==a.tcString&&"string"!==typeof a.tcString||void 0!==a.listenerId&&"number"!==typeof a.listenerId?2:a.cmpStatus&&"error"!==a.cmpStatus?0:3},Gl=function(a,b){b=void 0===b?{}:b;this.B=a;this.h=null;this.N={};this.fb=0;var c;this.U=null!=(c=b.rl)?c:500;var d;this.F=null!=(d=b.Hl)?d:!1;this.D=null};na(Gl,El);
Gl.prototype.addEventListener=function(a){var b=this,c={internalBlockOnErrors:this.F},d=vj(function(){return a(c)}),e=0;-1!==this.U&&(e=setTimeout(function(){c.tcString="tcunavailable";c.internalErrorState=1;d()},this.U));var f=function(g,h){clearTimeout(e);g?(c=g,c.internalErrorState=Fl(c),c.internalBlockOnErrors=b.F,h&&0===c.internalErrorState||(c.tcString="tcunavailable",h||(c.internalErrorState=3))):(c.tcString="tcunavailable",c.internalErrorState=3);a(c)};try{Hl(this,"addEventListener",f)}catch(g){c.tcString=
"tcunavailable",c.internalErrorState=3,e&&(clearTimeout(e),e=0),d()}};Gl.prototype.removeEventListener=function(a){a&&a.listenerId&&Hl(this,"removeEventListener",null,a.listenerId)};
var Jl=function(a,b,c){var d;d=void 0===d?"755":d;var e;a:{if(a.publisher&&a.publisher.restrictions){var f=a.publisher.restrictions[b];if(void 0!==f){e=f[void 0===d?"755":d];break a}}e=void 0}var g=e;if(0===g)return!1;var h=c;2===c?(h=0,2===g&&(h=1)):3===c&&(h=1,1===g&&(h=0));var l;if(0===h)if(a.purpose&&a.vendor){var n=Il(a.vendor.consents,void 0===d?"755":d);l=n&&"1"===b&&a.purposeOneTreatment&&"CH"===a.publisherCC?!0:n&&Il(a.purpose.consents,b)}else l=!0;else l=1===h?a.purpose&&a.vendor?Il(a.purpose.legitimateInterests,
b)&&Il(a.vendor.legitimateInterests,void 0===d?"755":d):!0:!0;return l},Il=function(a,b){return!(!a||!a[b])},Hl=function(a,b,c,d){c||(c=function(){});if("function"===typeof a.B.__tcfapi){var e=a.B.__tcfapi;e(b,2,c,d)}else if(Kl(a)){Ll(a);var f=++a.fb;a.N[f]=c;if(a.h){var g={};a.h.postMessage((g.__tcfapiCall={command:b,version:2,callId:f,parameter:d},g),"*")}}else c({},!1)},Kl=function(a){if(a.h)return a.h;var b;a:{for(var c=a.B,d=0;50>d;++d){var e;try{e=!(!c.frames||!c.frames.__tcfapiLocator)}catch(h){e=
!1}if(e){b=c;break a}var f;b:{try{var g=c.parent;if(g&&g!=c){f=g;break b}}catch(h){}f=null}if(!(c=f))break}b=null}a.h=b;return a.h},Ll=function(a){a.D||(a.D=function(b){try{var c;c=("string"===typeof b.data?JSON.parse(b.data):b.data).__tcfapiReturn;a.N[c.callId](c.returnValue,c.success)}catch(d){}},Zk(a.B,"message",a.D))},Ml=function(a){if(!1===a.gdprApplies)return!0;void 0===a.internalErrorState&&(a.internalErrorState=Fl(a));return"error"===a.cmpStatus||0!==a.internalErrorState?a.internalBlockOnErrors?
(Dl({e:String(a.internalErrorState)}),!1):!0:"loaded"!==a.cmpStatus||"tcloaded"!==a.eventStatus&&"useractioncomplete"!==a.eventStatus?!1:!0};var Nl={1:0,3:0,4:0,7:3,9:3,10:3},Ol=Yk('',500);function Pl(){var a=dh.tcf||{};return dh.tcf=a}
var Tl=function(){var a=Pl(),b=new Gl(z,{rl:-1});if(!0===z.gtag_enable_tcf_support&&!a.active&&("function"===typeof z.__tcfapi||"function"===typeof b.B.__tcfapi||null!=Kl(b))){a.active=!0;a.Ie={};Ql();a.tcString="tcunavailable";try{b.addEventListener(function(c){if(0!==c.internalErrorState)Rl(a),Sl(a);else{var d;a.gdprApplies=c.gdprApplies;if(!1===c.gdprApplies){var e={},f;for(f in Nl)Nl.hasOwnProperty(f)&&(e[f]=!0);d=e;b.removeEventListener(c)}else if("tcloaded"===c.eventStatus||"useractioncomplete"===
c.eventStatus||"cmpuishown"===c.eventStatus){var g={},h;for(h in Nl)if(Nl.hasOwnProperty(h))if("1"===h){var l,n=c,p=!0;p=void 0===p?!1:p;l=Ml(n)?!1===n.gdprApplies||"tcunavailable"===n.tcString||void 0===n.gdprApplies&&!p||"string"!==typeof n.tcString||!n.tcString.length?!0:Jl(n,"1",0):!1;g["1"]=l}else g[h]=Jl(c,h,Nl[h]);d=g}d&&(a.tcString=c.tcString||"tcempty",a.Ie=d,Sl(a))}})}catch(c){Rl(a),Sl(a)}}};function Rl(a){a.type="e";a.tcString="tcunavailable"}
function Ql(){var a={},b=(a.ad_storage="denied",a.wait_for_update=Ol,a);lj(b)}function Sl(a){var b={},c=(b.ad_storage=a.Ie["1"]?"granted":"denied",b);mj(c,{eventId:0},{gdprApplies:a?a.gdprApplies:void 0,tcString:Ul()})}var Ul=function(){var a=Pl();return a.active?a.tcString||"":""},Vl=function(){var a=Pl();return a.active&&void 0!==a.gdprApplies?a.gdprApplies?"1":"0":""},Wl=function(a){if(!Nl.hasOwnProperty(String(a)))return!0;var b=Pl();return b.active&&b.Ie?!!b.Ie[String(a)]:!0};var Xl=function(a){var b=String(a[Xd.Wa]||"").replace(/_/g,"");0===b.indexOf("cvt")&&(b="cvt");return b};var Yl=["L","S","Y"],Zl=["S","E"],$l={sampleRate:"0.005000",Ii:"",Hi:Number("5"),Gi:Number("")},am=0<=I.location.search.indexOf("?gtm_latency=")||0<=I.location.search.indexOf("&gtm_latency="),bm;
if(!(bm=am)){var cm=Math.random(),dm=$l.sampleRate;bm=cm<dm}var em=bm,fm="https://www.googletagmanager.com/a?id="+We.H+"&cv=1",gm={label:We.H+" Container",children:[{label:"Initialization",children:[]}]};function hm(){return[fm,"&v=3&t=t","&pid="+Ka(),"&rv="+ch.kc].join("")}var im=hm();function jm(){im=hm()}
var km={},lm="",mm="",nm="",om="",pm=[],qm="",rm={},sm=!1,tm={},um={},vm={},wm="",xm=void 0,ym={},zm={},Am=void 0,Bm=5;0<$l.Hi&&(Bm=$l.Hi);var Cm=function(a,b){for(var c=0,d=[],e=0;e<a;++e)d.push(0);return{yk:function(){return c<a?!1:Ta()-d[c%a]<b},Uk:function(){var f=c++%a;d[f]=Ta()}}}(Bm,1E3),Dm=1E3,Em="";
function Fm(a){var b=xm;if(void 0===b)return"";var c=xb("GTM"),d=xb("TAGGING"),e=xb("HEALTH"),f=im,g=km[b]?"":"&es=1",h=ym[b],l=Gm(b),n=Hm(),p=lm,q=mm,r=wm,u=Im(a),t=nm,v=om,w;return[f,g,h,l,c?"&u="+c:"",d?"&ut="+d:"",e?"&h="+e:"",n,p,q,r,u,t,v,w,qm?"&dl="+encodeURIComponent(qm):"",0<pm.length?"&tdp="+pm.join("."):"",ch.ad?
"&x="+ch.ad:"","&z=0"].join("")}function Km(){Am&&(z.clearTimeout(Am),Am=void 0);if(void 0!==xm&&(!km[xm]||lm||mm))if(zm[xm]||Cm.yk()||0>=Dm--)O(1),zm[xm]=!0;else{Cm.Uk();var a=Fm(!0);dc(a);if(om||qm&&0<pm.length){var b=a.replace("/a?","/td?");dc(b)}km[xm]=!0;qm=om=nm=wm=mm=lm="";pm=[]}}function Lm(){Am||(Am=z.setTimeout(Km,500))}function Mm(a){return a.match(/^(gtm|gtag)\./)?encodeURIComponent(a):"*"}function Nm(){2022<=Fm().length&&Km()}
function Hm(){return"&tc="+we.filter(function(a){return a}).length}
var Pm=function(a,b){if(em&&!zm[a]&&xm!==a){Km();xm=a;nm=lm="";ym[a]="&e="+Mm(b)+"&eid="+a;Lm();}},Qm=function(a,b,c,d){if(em&&b){var e=Xl(b),f=c+e;if(!zm[a]){a!==xm&&(Km(),xm=a);lm=lm?lm+"."+f:"&tr="+f;var g=b["function"];if(!g)throw Error("Error: No function name given for function call.");var h=(ye[g]?"1":"2")+e;nm=nm?nm+"."+h:"&ti="+h;Lm();Nm()}}},Rm=function(a,b,c){if(em&&a&&a[Xd.Ab]){var d=b+"."+a[Xd.Ab];
vm[d]=c;"html"==Xl(a)&&Em==d&&(lm+=":"+Math.floor(c))}};
function Im(a){}
function Gm(a){}
var Ym=function(a,b,c){if(em&&void 0!==a&&!zm[a]){a!==xm&&(Km(),xm=a);var d=c+b;mm=mm?mm+"."+d:"&epr="+d;Lm();Nm()}},Zm=function(a,b,c){},Jm=void 0;var $m=function(a){for(var b=[],c=0,d=0;d<a.length;d++){var e=a.charCodeAt(d);128>e?b[c++]=e:(2048>e?b[c++]=e>>6|192:(55296==(e&64512)&&d+1<a.length&&56320==(a.charCodeAt(d+1)&64512)?(e=65536+((e&1023)<<10)+(a.charCodeAt(++d)&1023),b[c++]=e>>18|240,b[c++]=e>>12&63|128):b[c++]=e>>12|224,b[c++]=e>>6&63|128),b[c++]=e&63|128)}return b};Ib();$k()||Hb("iPod");Hb("iPad");!Hb("Android")||Jb()||Ib()||Hb("Opera")||Hb("Silk");Jb();!Hb("Safari")||Jb()||Hb("Coast")||Hb("Opera")||Hb("Edge")||Hb("Edg/")||Hb("OPR")||Ib()||Hb("Silk")||Hb("Android")||al();var an={},bn=null,cn=function(a){for(var b=[],c=0,d=0;d<a.length;d++){var e=a.charCodeAt(d);255<e&&(b[c++]=e&255,e>>=8);b[c++]=e}var f=4;void 0===f&&(f=0);if(!bn){bn={};for(var g="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),h=["+/=","+/","-_=","-_.","-_"],l=0;5>l;l++){var n=g.concat(h[l].split(""));an[l]=n;for(var p=0;p<n.length;p++){var q=n[p];void 0===bn[q]&&(bn[q]=p)}}}for(var r=an[f],u=Array(Math.floor(b.length/3)),t=r[64]||"",v=0,w=0;v<b.length-2;v+=3){var x=b[v],
y=b[v+1],A=b[v+2],B=r[x>>2],C=r[(x&3)<<4|y>>4],D=r[(y&15)<<2|A>>6],H=r[A&63];u[w++]=""+B+C+D+H}var G=0,N=t;switch(b.length-v){case 2:G=b[v+1],N=r[(G&15)<<2]||t;case 1:var Q=b[v];u[w]=""+r[Q>>2]+r[(Q&3)<<4|G>>4]+N+t}return u.join("")};var dn="platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");function en(a){var b;return null!=(b=a.google_tag_data)?b:a.google_tag_data={}}function fn(){var a=z.google_tag_data,b;if(null!=a&&a.uach){var c=a.uach,d=Object.assign({},c);c.fullVersionList&&(d.fullVersionList=c.fullVersionList.slice(0));b=d}else b=null;return b}function gn(){var a,b;return null!=(b=null==(a=z.google_tag_data)?void 0:a.uach_promise)?b:null}
function hn(a){var b,c;return"function"===typeof(null==(b=a.navigator)?void 0:null==(c=b.userAgentData)?void 0:c.getHighEntropyValues)}function jn(){var a=z;if(!hn(a))return null;var b=en(a);if(b.uach_promise)return b.uach_promise;var c=a.navigator.userAgentData.getHighEntropyValues(dn).then(function(d){null!=b.uach||(b.uach=d);return d});return b.uach_promise=c};
var kn,ln=function(){if(hn(z)&&(kn=Ta(),!gn())){var a=jn();a&&(a.then(function(){O(95);}),a.catch(function(){O(96)}))}},nn=function(a){var b=mn.wl,c=function(g,h){try{a(g,h)}catch(l){}},d=fn();if(d)c(d);else{var e=gn();if(e){b=
Math.min(Math.max(isFinite(b)?b:0,0),1E3);var f=z.setTimeout(function(){c.pd||(c.pd=!0,O(106),c(null,Error("Timeout")))},b);e.then(function(g){c.pd||(c.pd=!0,O(104),z.clearTimeout(f),c(g))}).catch(function(g){c.pd||(c.pd=!0,O(105),z.clearTimeout(f),c(null,g))})}else c(null)}},on=function(a,b){a&&(b.C[S.g.qf]=a.architecture,b.C[S.g.rf]=a.bitness,a.fullVersionList&&(b.C[S.g.sf]=a.fullVersionList.map(function(c){return encodeURIComponent(c.brand||"")+";"+encodeURIComponent(c.version||"")}).join("|")),
b.C[S.g.tf]=a.mobile?"1":"0",b.C[S.g.uf]=a.model,b.C[S.g.vf]=a.platform,b.C[S.g.wf]=a.platformVersion,b.C[S.g.xf]=a.wow64?"1":"0")};var pn=function(a){for(var b=[],c=I.cookie.split(";"),d=new RegExp("^\\s*"+(a||"_gac")+"_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"),e=0;e<c.length;e++){var f=c[e].match(d);f&&b.push({xg:f[1],value:f[2],timestamp:Number(f[2].split(".")[1])||0})}b.sort(function(g,h){return h.timestamp-g.timestamp});return b};
function qn(a,b){var c=pn(a),d={};if(!c||!c.length)return d;for(var e=0;e<c.length;e++){var f=c[e].value.split(".");if(!("1"!==f[0]||b&&3>f.length||!b&&3!==f.length)&&Number(f[1])){d[c[e].xg]||(d[c[e].xg]=[]);var g={version:f[0],timestamp:1E3*Number(f[1]),ja:f[2]};b&&3<f.length&&(g.labels=f.slice(3));d[c[e].xg].push(g)}}return d};var rn=/^\w+$/,sn=/^[\w-]+$/,tn={aw:"_aw",dc:"_dc",gf:"_gf",ha:"_ha",gp:"_gp",gb:"_gb"},un=function(){if(!Qi().h()||!bj())return!0;var a=Zi("ad_storage");return null==a?!0:!!a},vn=function(a,b){aj("ad_storage")?un()?a():gj(a,"ad_storage"):b?vb("TAGGING",3):fj(function(){vn(a,!0)},["ad_storage"])},xn=function(a){return wn(a).map(function(b){return b.ja})},wn=function(a){var b=[];if(!wj(z)||!I.cookie)return b;var c=zj(a,I.cookie,void 0,"ad_storage");if(!c||0==c.length)return b;for(var d={},e=0;e<c.length;d=
{Ed:d.Ed},e++){var f=yn(c[e]);if(null!=f){var g=f,h=g.version;d.Ed=g.ja;var l=g.timestamp,n=g.labels,p=Ia(b,function(q){return function(r){return r.ja===q.Ed}}(d));p?(p.timestamp=Math.max(p.timestamp,l),p.labels=zn(p.labels,n||[])):b.push({version:h,ja:d.Ed,timestamp:l,labels:n})}}b.sort(function(q,r){return r.timestamp-q.timestamp});return An(b)};function zn(a,b){for(var c={},d=[],e=0;e<a.length;e++)c[a[e]]=!0,d.push(a[e]);for(var f=0;f<b.length;f++)c[b[f]]||d.push(b[f]);return d}
function Bn(a){return a&&"string"==typeof a&&a.match(rn)?a:"_gcl"}
var Dn=function(){var a=ki(z.location.href),b=ii(a,"query",!1,void 0,"gclid"),c=ii(a,"query",!1,void 0,"gclsrc"),d=ii(a,"query",!1,void 0,"wbraid"),e=ii(a,"query",!1,void 0,"dclid");if(!b||!c||!d){var f=a.hash.replace("#","");b=b||fi(f,"gclid",!1);c=c||fi(f,"gclsrc",!1);d=d||fi(f,"wbraid",!1)}return Cn(b,c,e,d)},Cn=function(a,b,c,d){var e={},f=function(g,h){e[h]||(e[h]=[]);e[h].push(g)};e.gclid=a;e.gclsrc=b;e.dclid=c;void 0!==d&&sn.test(d)&&(e.gbraid=d,f(d,"gb"));if(void 0!==a&&a.match(sn))switch(b){case void 0:f(a,
"aw");break;case "aw.ds":f(a,"aw");f(a,"dc");break;case "ds":f(a,"dc");break;case "3p.ds":f(a,"dc");break;case "gf":f(a,"gf");break;case "ha":f(a,"ha")}c&&f(c,"dc");return e},Fn=function(a){var b=Dn();vn(function(){En(b,!1,a)})};
function En(a,b,c,d,e){function f(w,x){var y=Gn(w,g);y&&(Ij(y,x,h),l=!0)}c=c||{};e=e||[];var g=Bn(c.prefix);d=d||Ta();var h=Rj(c,d,!0);h.pb="ad_storage";var l=!1,n=Math.round(d/1E3),p=function(w){var x=["GCL",n,w];0<e.length&&x.push(e.join("."));return x.join(".")};a.aw&&f("aw",p(a.aw[0]));a.dc&&f("dc",p(a.dc[0]));a.gf&&f("gf",p(a.gf[0]));a.ha&&f("ha",p(a.ha[0]));a.gp&&f("gp",p(a.gp[0]));if(!l&&a.gb){var q=a.gb[0],r=Gn("gb",g),u=!1;if(!b)for(var t=wn(r),v=0;v<t.length;v++)t[v].ja===q&&t[v].labels&&
0<t[v].labels.length&&(u=!0);u||f("gb",p(q))}}
var In=function(a,b){var c=kk(!0);vn(function(){for(var d=Bn(b.prefix),e=0;e<a.length;++e){var f=a[e];if(void 0!==tn[f]){var g=Gn(f,d),h=c[g];if(h){var l=Math.min(Hn(h),Ta()),n;b:{var p=l;if(wj(z))for(var q=zj(g,I.cookie,void 0,"ad_storage"),r=0;r<q.length;++r)if(Hn(q[r])>p){n=!0;break b}n=!1}if(!n){var u=Rj(b,l,!0);u.pb="ad_storage";Ij(g,h,u)}}}}En(Cn(c.gclid,c.gclsrc),!1,b)})},Gn=function(a,b){var c=tn[a];if(void 0!==c)return b+c},Hn=function(a){return 0!==Jn(a.split(".")).length?1E3*(Number(a.split(".")[1])||
0):0};function yn(a){var b=Jn(a.split("."));return 0===b.length?null:{version:b[0],ja:b[2],timestamp:1E3*(Number(b[1])||0),labels:b.slice(3)}}function Jn(a){return 3>a.length||"GCL"!==a[0]&&"1"!==a[0]||!/^\d+$/.test(a[1])||!sn.test(a[2])?[]:a}
var Kn=function(a,b,c,d,e){if(Ga(b)&&wj(z)){var f=Bn(e),g=function(){for(var h={},l=0;l<a.length;++l){var n=Gn(a[l],f);if(n){var p=zj(n,I.cookie,void 0,"ad_storage");p.length&&(h[n]=p.sort()[p.length-1])}}return h};vn(function(){qk(g,b,c,d)})}},An=function(a){return a.filter(function(b){return sn.test(b.ja)})},Ln=function(a,b){if(wj(z)){for(var c=Bn(b.prefix),d={},e=0;e<a.length;e++)tn[a[e]]&&(d[a[e]]=tn[a[e]]);vn(function(){m(d,function(f,g){var h=zj(c+g,I.cookie,void 0,"ad_storage");h.sort(function(u,
t){return Hn(t)-Hn(u)});if(h.length){var l=h[0],n=Hn(l),p=0!==Jn(l.split(".")).length?l.split(".").slice(3):[],q={},r;r=0!==Jn(l.split(".")).length?l.split(".")[2]:void 0;q[f]=[r];En(q,!0,b,n,p)}})})}};function Mn(a,b){for(var c=0;c<b.length;++c)if(a[b[c]])return!0;return!1}
var Nn=function(a){function b(e,f,g){g&&(e[f]=g)}if(bj()){var c=Dn();if(Mn(c,a)){var d={};b(d,"gclid",c.gclid);b(d,"dclid",c.dclid);b(d,"gclsrc",c.gclsrc);b(d,"wbraid",c.gbraid);rk(function(){return d},3);rk(function(){var e={};return e._up="1",e},1)}}},On=function(a,b,c,d){var e=[];c=c||{};if(!un())return e;var f=wn(a);if(!f.length)return e;for(var g=0;g<f.length;g++)-1===(f[g].labels||[]).indexOf(b)?e.push(0):e.push(1);if(d)return e;if(1!==e[0]){var h=f[0],l=f[0].timestamp,n=[h.version,Math.round(l/
1E3),h.ja].concat(h.labels||[],[b]).join("."),p=Rj(c,l,!0);p.pb="ad_storage";Ij(a,n,p)}return e};function Pn(a,b){var c=Bn(b),d=Gn(a,c);if(!d)return 0;for(var e=wn(d),f=0,g=0;g<e.length;g++)f=Math.max(f,e[g].timestamp);return f}function Qn(a){var b=0,c;for(c in a)for(var d=a[c],e=0;e<d.length;e++)b=Math.max(b,Number(d[e].timestamp));return b}var Rn=function(a){var b=Math.max(Pn("aw",a),Qn(un()?qn():{}));return Math.max(Pn("gb",a),Qn(un()?qn("_gac_gb",!0):{}))>b};var Wn=/[A-Z]+/,Xn=/\s/,Yn=function(a){if(k(a)){a=Ra(a);var b=a.indexOf("-");if(!(0>b)){var c=a.substring(0,b);if(Wn.test(c)){for(var d=a.substring(b+1).split("/"),e=0;e<d.length;e++)if(!d[e]||Xn.test(d[e])&&("AW"!==c||1!==e))return;return{id:a,prefix:c,X:c+"-"+d[0],O:d}}}}},$n=function(a){for(var b={},c=0;c<a.length;++c){var d=Yn(a[c]);d&&(b[d.id]=d)}Zn(b);var e=[];m(b,function(f,g){e.push(g)});return e};
function Zn(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];"AW"===d.prefix&&d.O[1]&&b.push(d.X)}for(var e=0;e<b.length;++e)delete a[b[e]]};var ao=function(a,b,c,d){var e=bc(),f;if(1===e)a:{var g=rh;g=g.toLowerCase();for(var h="https://"+g,l="http://"+g,n=1,p=I.getElementsByTagName("script"),q=0;q<p.length&&100>q;q++){var r=p[q].src;if(r){r=r.toLowerCase();if(0===r.indexOf(l)){f=3;break a}1===n&&0===r.indexOf(h)&&(n=2)}}f=n}else f=e;return(2===f||d||"http:"!=z.location.protocol?a:b)+c};var no=function(a,b,c){this.target=a;this.eventName=b;this.s=c;this.C={};this.metadata=K(c.eventMetadata||{});this.M=!1},oo=function(a,b,c){var d=T(a.s,b);void 0!==d?a.C[b]=d:void 0!==c&&(a.C[b]=c)},po=function(a,b,c){var d=Th(a.target.X);return d&&d.hasOwnProperty(b)?d[b]:c};function qo(a){return{getDestinationId:function(){return a.target.X},getEventName:function(){return a.eventName},setEventName:function(b){return void(a.eventName=b)},getHitData:function(b){return a.C[b]},setHitData:function(b,c){return void(a.C[b]=c)},setHitDataIfNotDefined:function(b,c){void 0===a.C[b]&&(a.C[b]=c)},copyToHitData:function(b,c){oo(a,b,c)},getMetadata:function(b){return a.metadata[b]},setMetadata:function(b,c){return void(a.metadata[b]=c)},abort:function(){return void(a.M=!0)},getProcessedEvent:function(){return a},
getFromEventContext:function(b){return T(a.s,b)}}};var so=function(a){var b=ro[a.target.X];if(!a.M&&b)for(var c=qo(a),d=0;d<b.length;++d){try{b[d](c)}catch(e){a.M=!0}if(a.M)break}},to=function(a,b){var c=ro[a];c||(c=ro[a]=[]);c.push(b)},ro={};var Io=function(a,b,c,d,e,f,g,h,l,n,p,q){this.eventId=a;this.priorityId=b;this.h=c;this.N=d;this.B=e;this.F=f;this.U=g;this.D=h;this.eventMetadata=l;this.aa=n;this.Z=p;this.J=q},T=function(a,b,c){if(void 0!==a.h[b])return a.h[b];if(void 0!==a.N[b])return a.N[b];if(void 0!==a.B[b])return a.B[b];em&&Jo(a,a.F[b],a.U[b])&&(O(71),O(79));return void 0!==a.F[b]?a.F[b]:void 0!==a.D[b]?a.D[b]:c},Ko=function(a){function b(g){for(var h=Object.keys(g),l=0;l<h.length;++l)c[h[l]]=1}var c={};b(a.h);b(a.N);b(a.B);
b(a.F);if(em)for(var d=Object.keys(a.U),e=0;e<d.length;e++){var f=d[e];if("event"!==f&&"gtm"!==f&&"tagTypeBlacklist"!==f&&!c.hasOwnProperty(f)){O(71);O(80);break}}return Object.keys(c)},Lo=function(a,b,c){function d(l){Dc(l)&&m(l,function(n,p){f=!0;e[n]=p})}var e={},f=!1;c&&1!==c||(d(a.D[b]),d(a.F[b]),d(a.B[b]),d(a.N[b]));c&&2!==c||d(a.h[b]);if(em){var g=f,h=e;e={};f=!1;c&&1!==c||(d(a.D[b]),d(a.U[b]),d(a.B[b]),d(a.N[b]));c&&2!==c||d(a.h[b]);if(f!==g||Jo(a,e,h))O(71),O(81);f=g;e=h}return f?e:void 0},
Mo=function(a){var b=[S.g.Kc,S.g.Qd,S.g.Rd,S.g.Sd,S.g.Td,S.g.Ud,S.g.Vd],c={},d=!1,e=function(h){for(var l=0;l<b.length;l++)void 0!==h[b[l]]&&(c[b[l]]=h[b[l]],d=!0);return d};if(e(a.h)||e(a.N)||e(a.B))return c;e(a.F);if(em){var f=c,g=d;c={};d=!1;e(a.U);Jo(a,c,f)&&(O(71),O(82));c=f;d=g}if(d)return c;e(a.D);return c},Jo=function(a,b,c){if(!em)return!1;try{if(b===c)return!1;var d=Bc(b);if(d!==Bc(c)||!(Dc(b)&&Dc(c)||"array"===d))return!0;if("array"===d){if(b.length!==c.length)return!0;for(var e=0;e<b.length;e++)if(Jo(a,
b[e],c[e]))return!0}else{for(var f in c)if(!b.hasOwnProperty(f))return!0;for(var g in b)if(!c.hasOwnProperty(g)||Jo(a,b[g],c[g]))return!0}}catch(h){O(72)}return!1},No=function(a,b){this.wj=a;this.xj=b;this.F={};this.Ch={};this.h={};this.N={};this.B={};this.Yc={};this.D={};this.Ec=function(){};this.fb=function(){};this.U=!1},Oo=function(a,b){a.F=b;return a},Po=function(a,b){a.Ch=b;return a},Qo=function(a,b){a.h=b;return a},Ro=function(a,b){a.N=b;return a},So=function(a,b){a.B=b;return a},To=function(a,
b){a.Yc=b;return a},Uo=function(a,b){a.D=b||{};return a},Vo=function(a,b){a.Ec=b;return a},Wo=function(a,b){a.fb=b;return a},Xo=function(a){a.U=!0;return a},Yo=function(a){return new Io(a.wj,a.xj,a.F,a.Ch,a.h,a.N,a.B,a.Yc,a.D,a.Ec,a.fb,a.U)};function bp(){return"attribution-reporting"}function cp(a){var b;b=void 0===b?document:b;var c;return!(null==(c=b.featurePolicy)||!c.allowedFeatures().includes(a))};var dp=!1;function ep(){if(cp("join-ad-interest-group")&&Da(Ub.joinAdInterestGroup))return!0;dp||(il('A751Xsk4ZW3DVQ8WZng2Dk5s3YzAyqncTzgv+VaE6wavgTY0QHkDvUTET1o7HanhuJO8lgv1Vvc88Ij78W1FIAAAAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjgwNjUyNzk5LCJpc1RoaXJkUGFydHkiOnRydWV9'),dp=!0);return cp("join-ad-interest-group")&&Da(Ub.joinAdInterestGroup)}
function fp(a,b){var c=void 0;try{c=I.querySelector('iframe[data-tagging-id="'+b+'"]')}catch(e){}if(c){var d=Number(c.dataset.loadTime);if(d&&6E4>Ta()-d){vb("TAGGING",9);return}}else try{if(50<=I.querySelectorAll('iframe[allow="join-ad-interest-group"][data-tagging-id*="-"]').length){vb("TAGGING",10);return}}catch(e){}cc(a,void 0,{allow:"join-ad-interest-group"},{taggingId:b,loadTime:Ta()},c)}function gp(){return U(60)?"https://td.doubleclick.net":"https://googleads.g.doubleclick.net"};var hp=RegExp("^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"),ip=/^~?[\w-]+(?:\.~?[\w-]+)*$/,jp=/^\d+\.fls\.doubleclick\.net$/,kp=/;gac=([^;?]+)/,lp=/;gacgb=([^;?]+)/,mp=/;gclaw=([^;?]+)/,np=/;gclgb=([^;?]+)/;
function op(a,b){if(jp.test(I.location.host)){var c=I.location.href.match(b);return c&&2==c.length&&c[1].match(hp)?decodeURIComponent(c[1]):""}var d=[],e;for(e in a){for(var f=[],g=a[e],h=0;h<g.length;h++)f.push(g[h].ja);d.push(e+":"+f.join(","))}return 0<d.length?d.join(";"):""}
var pp=function(a,b,c){var d=un()?qn("_gac_gb",!0):{},e=[],f=!1,g;for(g in d){var h=On("_gac_gb_"+g,a,b,c);f=f||0!==h.length&&h.some(function(l){return 1===l});e.push(g+":"+h.join(","))}return{hk:f?e.join(";"):"",gk:op(d,lp)}};function qp(a,b,c){if(jp.test(I.location.host)){var d=I.location.href.match(c);if(d&&2==d.length&&d[1].match(ip))return[{ja:d[1]}]}else return wn((a||"_gcl")+b);return[]}
var rp=function(a){return qp(a,"_aw",mp).map(function(b){return b.ja}).join(".")},sp=function(a){return qp(a,"_gb",np).map(function(b){return b.ja}).join(".")},tp=function(a,b){var c=On((b&&b.prefix||"_gcl")+"_gb",a,b);return 0===c.length||c.every(function(d){return 0===d})?"":c.join(".")};var up=function(){if(Da(z.__uspapi)){var a="";try{z.__uspapi("getUSPData",1,function(b,c){if(c&&b){var d=b.uspString;d&&RegExp("^[\\da-zA-Z-]{1,20}$").test(d)&&(a=d)}})}catch(b){}return a}};var dq={I:{zg:"ads_conversion_hit",yl:"container_execute_start",Cg:"container_setup_end",Dc:"container_setup_start",Bg:"container_execute_end",Dg:"container_yield_end",Se:"container_yield_start",zh:"event_execute_end",Ah:"event_setup_end",Xc:"event_setup_start",Bh:"ga4_conversion_hit",pe:"page_load",Xa:"snippet_load",Nh:"tag_callback_error",Oh:"tag_callback_failure",Ph:"tag_callback_success",Qh:"tag_execute_end",mc:"tag_execute_start"}};var eq="L S Y E TC HTC".split(" "),fq=["S","E"],gq=["TS","TE"];
var Dq=function(a,b,c,d,e,f){var g={};return g},Eq=function(a){var b=!1;return b},Fq=function(a,b){},Gq=function(){var a={};return a},wq=function(){var a={};
return a},Hq=function(){},Iq=function(a,b,c){},Jq=function(){function a(d){return!Ea(d)||0>d?0:d}if(!dh._li&&nc()&&nc().timing){var b=nc().timing.navigationStart,c=Ea(Eh.get("gtm.start"))?Eh.get("gtm.start"):0;dh._li={cst:a(c-b),cbt:a(th-b)}}},Kq=function(a){nc()&&nc().mark(We.H+"_"+a+"_start")},Lq=function(a){if(nc()){var b=nc(),c=We.H+"_"+a+"_start",d=We.H+"_"+a+
"_duration";b.measure(d,c);var e=nc().getEntriesByName(d)[0];b.clearMarks(c);b.clearMeasures(d);var f=dh._p||{};void 0===f[a]&&(f[a]=e.duration,dh._p=f);return e.duration}},Mq=function(){var a=mc();if(void 0!==a){var b=dh._p||{};b.PAGEVIEW=a;dh._p=b}};var Nq=function(a,b){var c=z,d,e=c.GooglebQhCsO;e||(e={},c.GooglebQhCsO=e);d=e;if(d[a])return!1;d[a]=[];d[a][0]=b;return!0};var Oq=function(a,b){var c=el(a,"fmt");if(b){var d=el(a,"random"),e=el(a,"label")||"";if(!d)return!1;var f=cn(decodeURIComponent(e.replace(/\+/g," "))+":"+decodeURIComponent(d.replace(/\+/g," ")));if(!Nq(f,b))return!1}c&&4!=c&&(a=gl(a,"rfmt",c));var g=gl(a,"fmt",4);ac(g,function(){z.google_noFurtherRedirects&&b&&b.call&&(z.google_noFurtherRedirects=null,b())},void 0,void 0,I.getElementsByTagName("script")[0].parentElement||void 0);return!0};var dr=function(){this.h={}},er=function(a,b,c){null!=c&&(a.h[b]=c)},fr=function(a){return Object.keys(a.h).map(function(b){return encodeURIComponent(b)+"="+encodeURIComponent(a.h[b])}).join("&")},hr=function(a,b,c,d){};function jr(a,b){if(a){var c=""+a;0!==c.indexOf("http://")&&0!==c.indexOf("https://")&&(c="https://"+c);"/"===c[c.length-1]&&(c=c.substring(0,c.length-1));return ki(""+c+b).href}}function kr(){return!!ch.ue&&"SGTM_TOKEN"!==ch.ue.split("@@").join("")};var mr=function(a,b,c,d){if(!lr()&&!Sk(a)){var e=c?"/gtag/js":"/gtm.js",f="?id="+encodeURIComponent(a)+"&l="+ch.ka,g=0===a.indexOf("GTM-");g||(f+="&cx=c");var h=kr();h&&(f+="&sign="+ch.ue);var l=lh||nh?jr(b,e+f):void 0;if(!l){var n=ch.Jd+e;h&&Vb&&g&&(n=Vb.replace(/^(?:https?:\/\/)?/i,"").split(/[?#]/)[0]);l=ao("https://","http://",n+f)}Qk().container[a]={state:1,context:d};ac(l)}},nr=function(a,b,c){var d;if(d=!lr()){var e=Qk().destination[a];d=!(e&&e.state)}if(d)if(Tk())Qk().destination[a]={state:0,
transportUrl:b,context:c},O(91);else{var f="/gtag/destination?id="+encodeURIComponent(a)+"&l="+ch.ka+"&cx=c";kr()&&(f+="&sign="+ch.ue);var g=lh||nh?jr(b,f):void 0;g||(g=ao("https://","http://",ch.Jd+f));Qk().destination[a]={state:1,context:c};ac(g)}};function lr(){if(Lk()){return!0}return!1};var or=new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),pr={cl:["ecl"],customPixels:["nonGooglePixels"],ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],customScripts:["html","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],nonGooglePixels:[],nonGoogleScripts:["nonGooglePixels"],nonGoogleIframes:["nonGooglePixels"]},qr={cl:["ecl"],customPixels:["customScripts","html"],
ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts"],customScripts:["html"],nonGooglePixels:["customPixels","customScripts","html","nonGoogleScripts","nonGoogleIframes"],nonGoogleScripts:["customScripts","html"],nonGoogleIframes:["customScripts","html","nonGoogleScripts"]},rr="google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" "),ur=function(a){var b=Dh("gtm.allowlist")||Dh("gtm.whitelist");b&&O(9);jh&&(b=["google","gtagfl","lcl","zone"]);sr()&&(jh?
O(116):O(117),tr&&(b=[],window.console&&window.console.log&&window.console.log("GTM blocked. See go/13687728.")));var c=b&&Za(Qa(b),pr),d=Dh("gtm.blocklist")||Dh("gtm.blacklist");d||(d=Dh("tagTypeBlacklist"))&&O(3);d?O(8):d=[];sr()&&(d=Qa(d),d.push("nonGooglePixels","nonGoogleScripts","sandboxedScripts"));0<=Qa(d).indexOf("google")&&O(2);var e=d&&Za(Qa(d),qr),f={};return function(g){var h=g&&g[Xd.Wa];if(!h||"string"!=typeof h)return!0;h=h.replace(/^_*/,"");if(void 0!==f[h])return f[h];var l=vh[h]||
[],n=a(h,l);if(b){var p;if(p=n)a:{if(0>c.indexOf(h))if(l&&0<l.length)for(var q=0;q<l.length;q++){if(0>c.indexOf(l[q])){O(11);p=!1;break a}}else{p=!1;break a}p=!0}n=p}var r=!1;if(d){var u=0<=e.indexOf(h);if(u)r=u;else{var t=Ma(e,l||[]);t&&O(10);r=t}}var v=!n||r;v||!(0<=l.indexOf("sandboxedScripts"))||c&&-1!==c.indexOf("sandboxedScripts")||(v=Ma(e,rr));return f[h]=v}},tr=!1;
var sr=function(){return or.test(z.location&&z.location.hostname)};var vr={initialized:11,complete:12,interactive:13},wr={},xr=Object.freeze((wr[S.g.La]=!0,wr)),yr=0<=I.location.search.indexOf("?gtm_diagnostics=")||0<=I.location.search.indexOf("&gtm_diagnostics="),Ar=function(a,b,c){if(em&&"config"===a&&!(1<Yn(b).O.length)){var d,e=Wb("google_tag_data",{});e.td||(e.td={});d=e.td;var f=K(c.F);K(c.h,f);var g=[],h;for(h in d){var l=zr(d[h],f);l.length&&(yr&&console.log(l),g.push(h))}if(g.length){if(g.length){var n=b+"*"+g.join(".");om=om?om+"!"+n:"&tdc="+n}vb("TAGGING",
vr[I.readyState]||14)}d[b]=f}};function Br(a,b){var c={},d;for(d in b)b.hasOwnProperty(d)&&(c[d]=!0);for(var e in a)a.hasOwnProperty(e)&&(c[e]=!0);return c}function zr(a,b,c,d){c=void 0===c?{}:c;d=void 0===d?"":d;if(a===b)return[];var e=function(q,r){var u=r[q];return void 0===u?xr[q]:u},f;for(f in Br(a,b)){var g=(d?d+".":"")+f,h=e(f,a),l=e(f,b),n="object"===Bc(h)||"array"===Bc(h),p="object"===Bc(l)||"array"===Bc(l);if(n&&p)zr(h,l,c,g);else if(n||p||h!==l)c[g]=!0}return Object.keys(c)};var Cr=!1,Dr=0,Er=[];function Fr(a){if(!Cr){var b=I.createEventObject,c="complete"==I.readyState,d="interactive"==I.readyState;if(!a||"readystatechange"!=a.type||c||!b&&d){Cr=!0;for(var e=0;e<Er.length;e++)J(Er[e])}Er.push=function(){for(var f=0;f<arguments.length;f++)J(arguments[f]);return 0}}}function Gr(){if(!Cr&&140>Dr){Dr++;try{I.documentElement.doScroll("left"),Fr()}catch(a){z.setTimeout(Gr,50)}}}var Hr=function(a){Cr?a():Er.push(a)};var Ir=function(){this.N=0;this.h={}};Ir.prototype.B=function(a,b,c){var d=++this.N;this.h[a]=this.h[a]||{};this.h[a][String(d)]={listener:b,ab:c};return d};Ir.prototype.D=function(a,b){var c=this.h[a],d=String(b);if(!c||!c[d])return!1;delete c[d];return!0};Ir.prototype.F=function(a,b){var c=[];m(this.h[a],function(d,e){0>c.indexOf(e.listener)&&(void 0===e.ab||0<=b.indexOf(e.ab))&&c.push(e.listener)});return c};var Jr=function(a,b,c){return{entityType:a,indexInOriginContainer:b,nameInOriginContainer:c,originContainerId:We.H}};var Lr=function(a,b){this.h=!1;this.F=[];this.N={tags:[]};this.U=!1;this.B=this.D=0;Kr(this,a,b)},Mr=function(a,b,c,d){if(gh.hasOwnProperty(b)||"__zone"===b)return-1;var e={};Dc(d)&&(e=K(d,e));e.id=c;e.status="timeout";return a.N.tags.push(e)-1},Nr=function(a,b,c,d){var e=a.N.tags[b];e&&(e.status=c,e.executionTime=d)},Or=function(a){if(!a.h){for(var b=a.F,c=0;c<b.length;c++)b[c]();a.h=!0;a.F.length=0}},Kr=function(a,b,c){void 0!==b&&a.we(b);c&&z.setTimeout(function(){return Or(a)},Number(c))};
Lr.prototype.we=function(a){var b=this,c=Wa(function(){return J(function(){a(We.H,b.N)})});this.h?c():this.F.push(c)};var Pr=function(a){a.D++;return Wa(function(){a.B++;a.U&&a.B>=a.D&&Or(a)})},Qr=function(a){a.U=!0;a.B>=a.D&&Or(a)};var Rr={},Sr=function(){return z.GoogleAnalyticsObject&&z[z.GoogleAnalyticsObject]},Tr=!1;
function Wr(){return z.GoogleAnalyticsObject||"ga"}
var Xr=function(a){},Yr=function(a,b){return function(){var c=Sr(),d=c&&c.getByName&&c.getByName(a);if(d){var e=d.get("sendHitTask");d.set("sendHitTask",function(f){var g=f.get("hitPayload"),h=f.get("hitCallback"),l=0>g.indexOf("&tid="+b);l&&(f.set("hitPayload",g.replace(/&tid=UA-[0-9]+-[0-9]+/,"&tid="+b),!0),f.set("hitCallback",void 0,!0));e(f);l&&(f.set("hitPayload",
g,!0),f.set("hitCallback",h,!0),f.set("_x_19",void 0,!0),e(f))})}}};function cs(a,b,c,d){var e=we[a],f=ds(a,b,c,d);if(!f)return null;var g=He(e[Xd.Mh],c,[]);if(g&&g.length){var h=g[0];f=cs(h.index,{aa:f,Z:1===h.bi?b.terminate:f,terminate:b.terminate},c,d)}return f}
function ds(a,b,c,d){function e(){if(f[Xd.Cj])h();else{var w=Ie(f,c,[]),x=w[Xd.Mi];if(null!=x)for(var y=0;y<x.length;y++)if(!nj(x[y])){h();return}var A=Mr(c.Bb,String(f[Xd.Wa]),Number(f[Xd.Ab]),w[Xd.Dj]),B=!1;w.vtp_gtmOnSuccess=function(){if(!B){B=!0;var G=Ta()-H;Qm(c.id,we[a],"5",G);Nr(c.Bb,A,"success",G);U(70)&&Iq(c,f,dq.I.Ph);g()}};w.vtp_gtmOnFailure=function(){if(!B){B=!0;var G=Ta()-H;Qm(c.id,we[a],"6",G);Nr(c.Bb,A,"failure",G);U(70)&&Iq(c,f,dq.I.Oh);h()}};w.vtp_gtmTagId=f.tag_id;w.vtp_gtmEventId=
c.id;c.priorityId&&(w.vtp_gtmPriorityId=c.priorityId);Qm(c.id,f,"1");var C=function(){var G=Ta()-H;Qm(c.id,f,"7",G);Nr(c.Bb,A,"exception",G);U(70)&&Iq(c,f,dq.I.Nh);B||(B=!0,h())};if(U(70)){var D=Dq(dq.I.mc,We.H,c.id,Number(f[Xd.Ab]),c.name,Xl(f));Eq(D)}var H=Ta();try{Ge(w,{event:c,index:a,type:1})}catch(G){C(G)}U(70)&&Iq(c,f,dq.I.Qh)}}var f=we[a],g=b.aa,h=b.Z,l=b.terminate;if(c.Yf(f))return null;var n=He(f[Xd.Rh],c,[]);if(n&&n.length){var p=n[0],q=cs(p.index,{aa:g,Z:h,terminate:l},c,d);if(!q)return null;g=q;h=2===p.bi?l:q}if(f[Xd.Ih]||f[Xd.Fj]){var r=f[Xd.Ih]?xe:c.ol,u=g,t=h;if(!r[a]){e=Wa(e);var v=es(a,r,e);g=
v.aa;h=v.Z}return function(){r[a](u,t)}}return e}function es(a,b,c){var d=[],e=[];b[a]=fs(d,e,c);return{aa:function(){b[a]=gs;for(var f=0;f<d.length;f++)d[f]()},Z:function(){b[a]=hs;for(var f=0;f<e.length;f++)e[f]()}}}function fs(a,b,c){return function(d,e){a.push(d);b.push(e);c()}}function gs(a){a()}function hs(a,b){b()};var js=function(a,b){return 1===arguments.length?is("set",a):is("set",a,b)},ks=function(a,b){return 1===arguments.length?is("config",a):is("config",a,b)},ls=function(a,b,c){c=c||{};c[S.g.Mb]=a;return is("event",b,c)};function is(a){return arguments}var ms=function(){this.h=[];this.B=[]};ms.prototype.enqueue=function(a,b,c){var d=this.h.length+1;a["gtm.uniqueEventId"]=b;a["gtm.priorityId"]=d;c.eventId=b;c.fromContainerExecution=!0;c.priorityId=d;var e={message:a,notBeforeEventId:b,priorityId:d,messageContext:c};this.h.push(e);for(var f=0;f<this.B.length;f++)try{this.B[f](e)}catch(g){}};ms.prototype.listen=function(a){this.B.push(a)};
ms.prototype.get=function(){for(var a={},b=0;b<this.h.length;b++){var c=this.h[b],d=a[c.notBeforeEventId];d||(d=[],a[c.notBeforeEventId]=d);d.push(c)}return a};ms.prototype.prune=function(a){for(var b=[],c=[],d=0;d<this.h.length;d++){var e=this.h[d];e.notBeforeEventId===a?b.push(e):c.push(e)}this.h=c;return b};var os=function(a,b,c){ns().enqueue(a,b,c)},qs=function(){var a=ps;ns().listen(a)};function ns(){var a=dh.mb;a||(a=new ms,dh.mb=a);return a}var ys=function(a){var b=dh.zones;return b?b.getIsAllowedFn(Nk(),a):function(){return!0}},zs=function(a){var b=dh.zones;return b?b.isActive(Nk(),a):!0};var Cs=function(a,b){for(var c=[],d=0;d<we.length;d++)if(a[d]){var e=we[d];var f=Pr(b.Bb);try{var g=cs(d,{aa:f,Z:f,terminate:f},b,d);if(g){var h=c,l=h.push,n=d,p=e["function"];if(!p)throw"Error: No function name given for function call.";var q=ye[p];l.call(h,{Ai:n,oi:q?q.priorityOverride||0:0,execute:g})}else As(d,b),f()}catch(u){f()}}c.sort(Bs);for(var r=0;r<c.length;r++)c[r].execute();return 0<c.length};
var Es=function(a,b){if(!Ds)return!1;var c=a["gtm.triggers"]&&String(a["gtm.triggers"]),d=Ds.F(a.event,c?String(c).split(","):[]);if(!d.length)return!1;for(var e=0;e<d.length;++e){var f=Pr(b);try{d[e](a,f)}catch(g){f()}}return!0};function Bs(a,b){var c,d=b.oi,e=a.oi;c=d>e?1:d<e?-1:0;var f;if(0!==c)f=c;else{var g=a.Ai,h=b.Ai;f=g>h?1:g<h?-1:0}return f}
function As(a,b){if(em){var c=function(d){var e=b.Yf(we[d])?"3":"4",f=He(we[d][Xd.Mh],b,[]);f&&f.length&&c(f[0].index);Qm(b.id,we[d],e);var g=He(we[d][Xd.Rh],b,[]);g&&g.length&&c(g[0].index)};c(a)}}var Fs=!1,Ds;var Gs=function(){Ds||(Ds=new Ir);return Ds};
var Ls=function(a){var b=Ta(),c=a["gtm.uniqueEventId"],d=a["gtm.priorityId"],e=a.event;if(U(70)){var f=Dq(dq.I.Xc,We.H,c,void 0,e);Eq(f)}if("gtm.js"===e){if(Fs)return!1;Fs=!0;}var l,n=!1;if(zs(c))l=ys(c);else{if("gtm.js"!==e&&"gtm.init"!==e&&"gtm.init_consent"!==e)return!1;n=!0;l=ys(Number.MAX_SAFE_INTEGER)}Pm(c,
e);var p=a.eventCallback,q=a.eventTimeout,r={id:c,priorityId:d,name:e,Yf:ur(l),ol:[],ii:function(){O(6);vb("HEALTH",0)},Vh:Hs(),Wh:Is(c),Bb:new Lr(function(){if(U(70)){var y=Dq(dq.I.Xc,We.H,c,void 0,e),A=Dq(dq.I.zh,We.H,c,void 0,e);Eq(A);Fq(A,y);if("gtm.load"===e){var B=Dq(dq.I.Dc,We.H),C=Dq(dq.I.Bg,We.H);Eq(C);Fq(C,B);Hq();}}p&&p.apply(p,[].slice.call(arguments,0))},q)},u=Re(r);n&&(u=Js(u));if(U(70)){var t=Dq(dq.I.Xc,We.H,c,void 0,e),v=Dq(dq.I.Ah,We.H,c,void 0,e);Eq(v);Fq(v,t)}var w=Cs(u,r),x=!1;
x=Es(a,r.Bb);Qr(r.Bb);"gtm.js"!==e&&"gtm.sync"!==e||Xr(We.H);return Ks(u,w)||x};function Is(a){return function(b){em&&(Hc(b)||Zm(a,"input",b))}}function Hs(){var a={};a.event=Ph("event",1);a.ecommerce=Ph("ecommerce",1);a.gtm=Ph("gtm");a.eventModel=Ph("eventModel");return a}
function Js(a){for(var b=[],c=0;c<a.length;c++)if(a[c]){var d=String(we[c][Xd.Wa]);if(fh[d]||void 0!==we[c][Xd.Gj]||wh[d])b[c]=!0;U(58)||0!==we[c][Xd.Wa].indexOf("__ccd")&&0!==we[c][Xd.Wa].indexOf("__ogt")&&"__set_product_settings"!==we[c][Xd.Wa]||(b[c]=!0)}return b}function Ks(a,b){if(!b)return b;for(var c=0;c<a.length;c++)if(a[c]&&we[c]&&!gh[String(we[c][Xd.Wa])])return!0;return!1}var Ns=function(a,b,c,d){Ms.push("event",[b,a],c,d)},Os=function(a,b,c,d){Ms.push("get",[a,b],c,d)},Ps=function(){this.status=1;this.N={};this.h={};this.B={};this.U=null;this.F={};this.D=!1},Qs=function(a,b,c,d){var e=Ta();this.type=a;this.B=e;this.ca=b||"";this.h=c;this.messageContext=d},Rs=function(){this.B={};this.D={};this.h=[]},Ss=function(a,b){var c=Yn(b);return a.B[c.X]=a.B[c.X]||new Ps},Ts=function(a,b,c,d){if(d.ca){var e=Ss(a,d.ca),f=e.U;if(f){var g=K(c),h=K(e.N[d.ca]),l=K(e.F),n=K(e.h),
p=K(a.D),q={};if(em)try{q=K(Ah)}catch(v){O(72)}var r=Yn(d.ca).prefix,u=function(v){Ym(d.messageContext.eventId,r,v);var w=g[S.g.ac];w&&J(w)},t=Yo(Wo(Vo(Uo(So(Ro(To(Qo(Po(Oo(new No(d.messageContext.eventId,d.messageContext.priorityId),g),h),l),n),p),q),d.messageContext.eventMetadata),function(){if(u){var v=u;u=void 0;v("2")}}),function(){if(u){var v=u;u=void 0;v("3")}}));try{Ym(d.messageContext.eventId,r,"1"),Ar(d.type,d.ca,t),f(d.ca,b,d.B,t)}catch(v){Ym(d.messageContext.eventId,r,"4")}}}};
Rs.prototype.register=function(a,b,c){var d=Ss(this,a);3!==d.status&&(d.U=b,d.status=3,c&&(K(d.h,c),d.h=c),this.flush())};Rs.prototype.push=function(a,b,c,d){if(void 0!==c){if(!Yn(c))return;if(c){var e=Yn(c);e&&1===Ss(this,c).status&&(Ss(this,c).status=2,this.push("require",[{}],e.X,{}))}Ss(this,c).D&&(d.deferrable=!1)}this.h.push(new Qs(a,c,b,d));d.deferrable||this.flush()};
Rs.prototype.flush=function(a){for(var b=this,c=[],d=!1,e={};this.h.length;){var f=this.h[0];if(f.messageContext.deferrable)!f.ca||Ss(this,f.ca).D?(f.messageContext.deferrable=!1,this.h.push(f)):c.push(f),this.h.shift();else{var g=void 0;switch(f.type){case "require":g=Ss(this,f.ca);if(3!==g.status&&!a){this.h.push.apply(this.h,c);return}break;case "set":m(f.h[0],function(r,u){K(bb(r,u),b.D)});break;case "config":g=Ss(this,f.ca);e.qb={};m(f.h[0],function(r){return function(u,t){K(bb(u,t),r.qb)}}(e));
var h=!!e.qb[S.g.Wc];delete e.qb[S.g.Wc];var l=Yn(f.ca),n=l.X===l.id;h||(n?g.F={}:g.N[f.ca]={});g.D&&h||Ts(this,S.g.Da,e.qb,f);g.D=!0;n?K(e.qb,g.F):(K(e.qb,g.N[f.ca]),O(70));d=!0;break;case "event":g=Ss(this,f.ca);e.Dd={};m(f.h[0],function(r){return function(u,t){K(bb(u,t),r.Dd)}}(e));Ts(this,f.h[1],e.Dd,f);break;case "get":g=Ss(this,f.ca);var p={},q=(p[S.g.jb]=f.h[0],p[S.g.xb]=f.h[1],p);Ts(this,S.g.Ja,q,f)}this.h.shift();Us(this,f)}e={qb:e.qb,Dd:e.Dd}}this.h.push.apply(this.h,c);d&&this.flush()};
var Us=function(a,b){if("require"!==b.type)if(b.ca)for(var c=Ss(a,b.ca).B[b.type]||[],d=0;d<c.length;d++)c[d]();else for(var e in a.B)if(a.B.hasOwnProperty(e)){var f=a.B[e];if(f&&f.B)for(var g=f.B[b.type]||[],h=0;h<g.length;h++)g[h]()}},Vs=function(a,b){var c=Ms,d=K(b);K(Ss(c,a).h,d);Ss(c,a).h=d},Ms=new Rs;var $e;var Ws={},zt={},At=function(a){for(var b=[],c=[],d={},e=0;e<a.length;d={Id:d.Id,Fd:d.Fd},e++){var f=a[e];if(0<=f.indexOf("-"))d.Id=Yn(f),d.Id&&(Ia(Ok(),function(p){return function(q){return p.Id.X===q}}(d))?b.push(f):c.push(f));else{var g=Ws[f]||[];d.Fd={};g.forEach(function(p){return function(q){return p.Fd[q]=!0}}(d));for(var h=Nk(),l=0;l<h.length;l++)if(d.Fd[h[l]]){b=b.concat(Ok());break}var n=zt[f]||[];n.length&&(b=b.concat(n))}}return{Hk:b,Kk:c}},Bt=function(a){m(Ws,function(b,c){var d=c.indexOf(a);
0<=d&&c.splice(d,1)})},Ct=function(a){m(zt,function(b,c){var d=c.indexOf(a);0<=d&&c.splice(d,1)})};var Dt="HA GF G UA AW DC MC".split(" "),Et=!1,Ft=!1;function Gt(a,b){a.hasOwnProperty("gtm.uniqueEventId")||Object.defineProperty(a,"gtm.uniqueEventId",{value:xh()});b.eventId=a["gtm.uniqueEventId"];b.priorityId=a["gtm.priorityId"];return{eventId:b.eventId,priorityId:b.priorityId}}
var Ht={config:function(a,b){var c=Gt(a,b);if(!(2>a.length)&&k(a[1])){var d={};if(2<a.length){if(void 0!=a[2]&&!Dc(a[2])||3<a.length)return;d=a[2]}var e=Yn(a[1]);if(e){Pm(c.eventId,"gtag.config");var f=e.X,g=e.id!==f;if(g?-1===Ok().indexOf(f):-1===Nk().indexOf(f)){if(!U(61)||!d[S.g.ie]){var h=d[S.g.za]||Ms.D[S.g.za];g?nr(f,h,{source:2,fromContainerExecution:b.fromContainerExecution}):mr(f,h,!0,{source:2,fromContainerExecution:b.fromContainerExecution})}}else{if(ih&&!g&&!d[S.g.Wc]){var l=Ft;Ft=!0;
if(l)return}Et||O(43);if(!b.noTargetGroup)if(g){Ct(e.id);var n=e.id,p=d[S.g.fe]||"default";p=String(p).split(",");for(var q=0;q<p.length;q++){var r=zt[p[q]]||[];zt[p[q]]=r;0>r.indexOf(n)&&r.push(n)}}else{Bt(e.id);var u=e.id,t=d[S.g.fe]||"default";t=t.toString().split(",");for(var v=0;v<t.length;v++){var w=Ws[t[v]]||[];Ws[t[v]]=w;0>w.indexOf(u)&&w.push(u)}}delete d[S.g.fe];var x=b.eventMetadata||{};x.hasOwnProperty("is_external_event")||(x.is_external_event=!b.fromContainerExecution);b.eventMetadata=
x;delete d[S.g.ac];for(var y=g?[e.id]:Ok(),A=0;A<y.length;A++){var B=K(b);Ms.push("config",[d],y[A],B)}}}}},consent:function(a,b){if(3===a.length){O(39);var c=Gt(a,b),d=a[1];"default"===d?lj(a[2]):"update"===d&&mj(a[2],c)}},event:function(a,b){var c=a[1];if(!(2>a.length)&&k(c)){var d;if(2<a.length){if(!Dc(a[2])&&void 0!=a[2]||3<a.length)return;d=a[2]}var e=d,f={},g=(f.event=c,f);e&&(g.eventModel=K(e),e[S.g.ac]&&(g.eventCallback=e[S.g.ac]),e[S.g.be]&&(g.eventTimeout=e[S.g.be]));var h=Gt(a,b),l=h.eventId,
n=h.priorityId;g["gtm.uniqueEventId"]=l;n&&(g["gtm.priorityId"]=n);if("optimize.callback"===c)return g.eventModel=g.eventModel||{},g;var p;var q=d,r=q&&q[S.g.Mb];void 0===r&&(r=Dh(S.g.Mb,2),void 0===r&&(r="default"));if(k(r)||Ga(r)){var u=r.toString().replace(/\s+/g,"").split(","),t=At(u),v=t.Hk,w=t.Kk;if(w.length)for(var x=q&&q[S.g.za]||Ms.D[S.g.za],y=0;y<w.length;y++){var A=Yn(w[y]);A&&nr(A.X,x,{source:3,fromContainerExecution:b.fromContainerExecution})}p=$n(v)}else p=void 0;var B=p;if(B){Pm(l,
c);for(var C=[],D=0;D<B.length;D++){var H=B[D],G=K(b);if(-1!==Dt.indexOf(H.prefix)){var N=K(d),Q=G.eventMetadata||{};Q.hasOwnProperty("is_external_event")||(Q.is_external_event=!G.fromContainerExecution);G.eventMetadata=Q;delete N[S.g.ac];Ns(c,N,H.id,G)}C.push(H.id)}g.eventModel=g.eventModel||{};0<B.length?g.eventModel[S.g.Mb]=C.join():delete g.eventModel[S.g.Mb];Et||O(43);return b.noGtmEvent?void 0:g}}},get:function(a,b){O(53);if(4===a.length&&k(a[1])&&k(a[2])&&Da(a[3])){var c=Yn(a[1]),d=String(a[2]),
e=a[3];if(c){Et||O(43);var f=Ms.D[S.g.za];if(!Ia(Ok(),function(h){return c.X===h}))nr(c.X,f,{source:4,fromContainerExecution:b.fromContainerExecution});else if(-1!==Dt.indexOf(c.prefix)){Gt(a,b);var g={};hj(K((g[S.g.jb]=d,g[S.g.xb]=e,g)));Os(d,function(h){J(function(){return e(h)})},c.id,b)}}}},js:function(a,b){if(2==a.length&&a[1].getTime){Et=!0;var c=Gt(a,b),d=c.eventId,e=c.priorityId,f={};return f.event="gtm.js",f["gtm.start"]=a[1].getTime(),f["gtm.uniqueEventId"]=d,f["gtm.priorityId"]=e,f}},policy:function(a){if(3===
a.length&&k(a[1])&&Da(a[2])){var b=a[1],c=a[2],d=$e.B;d.h[b]?d.h[b].push(c):d.h[b]=[c];if(O(74),"all"===a[1]){O(75);var e=!1;try{e=a[2](We.H,"unknown",{})}catch(f){}e||O(76)}}else{O(73);}},set:function(a,b){var c;2==a.length&&Dc(a[1])?c=K(a[1]):3==a.length&&k(a[1])&&
(c={},Dc(a[2])||Ga(a[2])?c[a[1]]=K(a[2]):c[a[1]]=a[2]);if(c){var d=Gt(a,b),e=d.eventId,f=d.priorityId;K(c);var g=K(c);Ms.push("set",[g],void 0,b);c["gtm.uniqueEventId"]=e;f&&(c["gtm.priorityId"]=f);U(30)&&delete c.event;b.overwriteModelFields=!0;return c}}},It={policy:!0};var Jt=function(a){var b=z[ch.ka].hide;if(b&&void 0!==b[a]&&b.end){b[a]=!1;var c=!0,d;for(d in b)if(b.hasOwnProperty(d)&&!0===b[d]){c=!1;break}c&&(b.end(),b.end=null)}},Kt=function(a){var b=z[ch.ka],c=b&&b.hide;c&&c.end&&(c[a]=!0)};var Lt=!1,Mt=[];function Nt(){if(!Lt){Lt=!0;for(var a=0;a<Mt.length;a++)J(Mt[a])}}var Ot=function(a){Lt?J(a):Mt.push(a)};var eu=function(a){if(du(a))return a;this.Qa=a};eu.prototype.getUntrustedMessageValue=function(){return this.Qa};var du=function(a){return!a||"object"!==Bc(a)||Dc(a)?!1:"getUntrustedMessageValue"in a};eu.prototype.getUntrustedMessageValue=eu.prototype.getUntrustedMessageValue;var fu=0,gu={},hu=[],iu=[],ju=!1,ku=!1;function lu(a,b){return a.messageContext.eventId-b.messageContext.eventId||a.messageContext.priorityId-b.messageContext.priorityId}var mu=function(a){return z[ch.ka].push(a)},nu=function(a,b,c){a.eventCallback=b;c&&(a.eventTimeout=c);return mu(a)},ou=function(a,b){var c=dh[ch.ka],d=c?c.subscribers:1,e=0,f=!1,g=void 0;b&&(g=z.setTimeout(function(){f||(f=!0,a());g=void 0},b));return function(){++e===d&&(g&&(z.clearTimeout(g),g=void 0),f||(a(),f=!0))}};
function pu(a,b){var c=a._clear||b.overwriteModelFields;m(a,function(e,f){"_clear"!==e&&(c&&Nh(e),Nh(e,f))});sh||(sh=a["gtm.start"]);var d=a["gtm.uniqueEventId"];if(!a.event)return!1;"number"!==typeof d&&(d=xh(),a["gtm.uniqueEventId"]=d,Nh("gtm.uniqueEventId",d));return Ls(a)}
function qu(a){if(null==a||"object"!==typeof a)return!1;if(a.event)return!0;if(Na(a)){var b=a[0];if("config"===b||"event"===b||"js"===b||"get"===b)return!0}return!1}
function ru(){var a;if(iu.length)a=iu.shift();else if(hu.length)a=hu.shift();else return;var b;var c=a;if(ju||!qu(c.message))b=c;else{ju=!0;var d=c.message["gtm.uniqueEventId"];"number"!==typeof d&&(d=c.message["gtm.uniqueEventId"]=xh());var e={},f={message:(e.event="gtm.init_consent",e["gtm.uniqueEventId"]=d-2,e),messageContext:{eventId:d-2}},g={},h={message:(g.event="gtm.init",g["gtm.uniqueEventId"]=d-1,g),messageContext:{eventId:d-1}};hu.unshift(h,c);if(em&&We.H){var l;if(We.Df){var n=We.H,p=Qk().destination[n];
l=p&&p.context}else{var q=We.H,r=Qk().container[q];l=r&&r.context}var u=l,t,v=ki(z.location.href);t=v.hostname+v.pathname;var w=u&&u.fromContainerExecution,x=u&&u.source,y=We.H,A=We.tb,B=We.Df;qm||(qm=t);pm.push(y+";"+A+";"+(w?1:0)+";"+(x||0)+";"+(B?1:0))}b=f}return b}
function su(){for(var a=!1,b;!ku&&(b=ru());){ku=!0;delete Ah.eventModel;Ch();var c=b,d=c.message,e=c.messageContext;if(null==d)ku=!1;else{e.fromContainerExecution&&Oh();try{if(Da(d))try{d.call(Eh)}catch(x){}else if(Ga(d)){var f=d;if(k(f[0])){var g=f[0].split("."),h=g.pop(),l=f.slice(1),n=Dh(g.join("."),2);if(null!=n)try{n[h].apply(n,l)}catch(x){}}}else{var p=void 0,q=!1;if(Na(d)){a:{if(d.length&&
k(d[0])){var r=Ht[d[0]];if(r&&(!e.fromContainerExecution||!It[d[0]])){p=r(d,e);break a}}p=void 0}(q=p&&"set"===d[0]&&!!p.event)&&O(101)}else p=d;if(p){var u=pu(p,e);a=u||a;q&&u&&O(113)}}}finally{e.fromContainerExecution&&Ch(!0);var t=d["gtm.uniqueEventId"];if("number"===typeof t){for(var v=gu[String(t)]||[],w=0;w<v.length;w++)iu.push(tu(v[w]));v.length&&iu.sort(lu);delete gu[String(t)];t>fu&&(fu=t)}ku=!1}}}
return!a}function uu(){if(U(70)&&vu()){var b=Dq(dq.I.Se,We.H),c=Dq(dq.I.Dg,We.H);Eq(c)&&Fq(c,b)}var d=su();try{Jt(We.H)}catch(e){}return d}function ps(a){if(fu<a.notBeforeEventId){var b=String(a.notBeforeEventId);gu[b]=gu[b]||[];gu[b].push(a)}else iu.push(tu(a)),iu.sort(lu),J(function(){ku||su()})}
function tu(a){return{message:a.message,messageContext:a.messageContext}}
var wu=function(){function a(g){var h={};if(du(g)){var l=g;g=du(l)?l.getUntrustedMessageValue():void 0;h.fromContainerExecution=!0}return{message:g,messageContext:h}}var b=Wb(ch.ka,[]),c=dh[ch.ka]=dh[ch.ka]||{};!0===c.pruned&&O(83);gu=ns().get();qs();Hr(function(){if(!c.gtmDom){c.gtmDom=!0;var g={};b.push((g.event="gtm.dom",g))}});Ot(function(){if(!c.gtmLoad){c.gtmLoad=!0;var g={};b.push((g.event="gtm.load",g))}});c.subscribers=(c.subscribers||0)+1;var d=b.push;b.push=function(){var g;if(0<dh.SANDBOXED_JS_SEMAPHORE){g=
[];for(var h=0;h<arguments.length;h++)g[h]=new eu(arguments[h])}else g=[].slice.call(arguments,0);var l=g.map(function(r){return a(r)});hu.push.apply(hu,l);var n=d.apply(b,g),p=Math.max(100,Number("1000")||300);if(this.length>p)for(O(4),c.pruned=!0;this.length>p;)this.shift();var q="boolean"!==typeof n||n;return su()&&q};var e=b.slice(0).map(function(g){return a(g)});hu.push.apply(hu,e);if(vu()){if(U(70)){var f=Dq(dq.I.Se,We.H);Eq(f)}J(uu)}},vu=function(){var a=!0;return a};function xu(a){if(null==a||0===a.length)return!1;var b=Number(a),c=Ta();return b<c+3E5&&b>c-9E5}function yu(a){return a&&0===a.indexOf("pending:")?xu(a.substr(8)):!1};var Be={};Be.oe=new String("undefined");
var Bu=function(a,b,c){var d={event:b,"gtm.element":a,"gtm.elementClasses":lc(a,"className"),"gtm.elementId":a["for"]||gc(a,"id")||"","gtm.elementTarget":a.formTarget||lc(a,"target")||""};c&&(d["gtm.triggers"]=c.join(","));d["gtm.elementUrl"]=(a.attributes&&a.attributes.formaction?a.formAction:"")||a.action||lc(a,"href")||a.src||a.code||a.codebase||"";return d},Cu=function(a){dh.hasOwnProperty("autoEventsSettings")||(dh.autoEventsSettings={});var b=dh.autoEventsSettings;b.hasOwnProperty(a)||(b[a]=
{});return b[a]},Du=function(a,b,c){Cu(a)[b]=c},Eu=function(a,b,c,d){var e=Cu(a),f=Ua(e,b,d);e[b]=c(f)},Fu=function(a,b,c){var d=Cu(a);return Ua(d,b,c)},Gu=function(a){return"string"===typeof a?a:String(xh())};
var Hu=["input","select","textarea"],Iu=["button","hidden","image","reset","submit"],Ju=function(a){var b=a.tagName.toLowerCase();return 0>Hu.indexOf(b)||"input"===b&&0<=Iu.indexOf(a.type.toLowerCase())?!1:!0},Ku=function(a){return a.form?a.form.tagName?a.form:I.getElementById(a.form):jc(a,["form"],100)},Lu=function(a,b,c){if(!a.elements)return 0;for(var d=b.dataset[c],e=0,f=1;e<a.elements.length;e++){var g=a.elements[e];if(Ju(g)){if(g.dataset[c]===d)return f;f++}}return 0};var Mu=!!z.MutationObserver,Nu=void 0,Ou=function(a){if(!Nu){var b=function(){var c=I.body;if(c)if(Mu)(new MutationObserver(function(){for(var e=0;e<Nu.length;e++)J(Nu[e])})).observe(c,{childList:!0,subtree:!0});else{var d=!1;ec(c,"DOMNodeInserted",function(){d||(d=!0,J(function(){d=!1;for(var e=0;e<Nu.length;e++)J(Nu[e])}))})}};Nu=[];I.body?b():J(b)}Nu.push(a)};
var Zu=function(a,b,c){function d(){var g=a();f+=e?(Ta()-e)*g.playbackRate/1E3:0;e=Ta()}var e=0,f=0;return{createEvent:function(g,h,l){var n=a(),p=n.Pf,q=void 0!==l?Math.round(l):void 0!==h?Math.round(n.Pf*h):Math.round(n.Zh),r=void 0!==h?Math.round(100*h):0>=p?0:Math.round(q/p*100),u=I.hidden?!1:.5<=Xh(c);d();var t=void 0;void 0!==b&&(t=[b]);var v=Bu(c,"gtm.video",t);v["gtm.videoProvider"]="youtube";v["gtm.videoStatus"]=g;v["gtm.videoUrl"]=n.url;v["gtm.videoTitle"]=n.title;v["gtm.videoDuration"]=
Math.round(p);v["gtm.videoCurrentTime"]=Math.round(q);v["gtm.videoElapsedTime"]=Math.round(f);v["gtm.videoPercent"]=r;v["gtm.videoVisible"]=u;return v},wi:function(){e=Ta()},nc:function(){d()}}};var $u=z.clearTimeout,av=z.setTimeout,V=function(a,b,c,d){if(Lk()){b&&J(b)}else return ac(a,b,c,d)},bv=function(){return new Date},cv=function(){return z.location.href},dv=function(a){return ii(ki(a),"fragment")},ev=function(a){return ji(ki(a))},fv=function(a,b){return Dh(a,b||2)},gv=function(a,b,c){return b?nu(a,b,c):mu(a)},hv=function(a,b){z[a]=b},W=function(a,b,c){b&&(void 0===z[a]||c&&!z[a])&&(z[a]=b);return z[a]},
iv=function(a,b,c){return zj(a,b,void 0===c?!0:!!c)},jv=function(a,b,c){return 0===Ij(a,b,c)},kv=function(a,b){if(Lk()){b&&J(b)}else cc(a,b)},lv=function(a){return!!Fu(a,"init",!1)},mv=function(a){Du(a,"init",!0)},nv=function(a,b,c){em&&(Hc(a)||Zm(c,b,a))};var Lv=["matches","webkitMatchesSelector","mozMatchesSelector","msMatchesSelector","oMatchesSelector"];function Mv(a,b){a=String(a);b=String(b);var c=a.length-b.length;return 0<=c&&a.indexOf(b,c)===c}var Nv=new La;function Ov(a,b,c){var d=c?"i":void 0;try{var e=String(b)+d,f=Nv.get(e);f||(f=new RegExp(b,d),Nv.set(e,f));return f.test(a)}catch(g){return!1}}
function Pv(a,b){function c(g){var h=ki(g),l=ii(h,"protocol"),n=ii(h,"host",!0),p=ii(h,"port"),q=ii(h,"path").toLowerCase().replace(/\/$/,"");if(void 0===l||"http"===l&&"80"===p||"https"===l&&"443"===p)l="web",p="default";return[l,n,p,q]}for(var d=c(String(a)),e=c(String(b)),f=0;f<d.length;f++)if(d[f]!==e[f])return!1;return!0}function Qv(a,b){return 0<=String(a).indexOf(String(b))}function Rv(a,b){return String(a)===String(b)}function Sv(a,b){return Number(a)>=Number(b)}
function Tv(a,b){return Number(a)<=Number(b)}function Uv(a,b){return Number(a)>Number(b)}function Vv(a,b){return Number(a)<Number(b)}function Wv(a,b){return 0===String(a).indexOf(String(b))}function Xv(a){return Yv(a)?1:0}
function Yv(a){var b=a.arg0,c=a.arg1;if(a.any_of&&Array.isArray(c)){for(var d=0;d<c.length;d++){var e=K(a,{});K({arg1:c[d],any_of:void 0},e);if(Xv(e))return!0}return!1}switch(a["function"]){case "_cn":return Qv(b,c);case "_css":var f;a:{if(b)try{for(var g=0;g<Lv.length;g++){var h=Lv[g];if(b[h]){f=b[h](c);break a}}}catch(l){}f=!1}return f;case "_ew":return Mv(b,c);case "_eq":return Rv(b,c);case "_ge":return Sv(b,c);case "_gt":return Uv(b,c);case "_lc":return 0<=String(b).split(",").indexOf(String(c));
case "_le":return Tv(b,c);case "_lt":return Vv(b,c);case "_re":return Ov(b,c,a.ignore_case);case "_sw":return Wv(b,c);case "_um":return Pv(b,c)}return!1};function Zv(a,b){var c=this;}Zv.R="addConsentListener";var $v;var aw=function(a){for(var b=0;b<a.length;++b)if($v)try{a[b]()}catch(c){O(77)}else a[b]()};function bw(a,b,c){var d=this,e;L(F(this),["eventName:!string","callback:!Fn","triggerId:?string"],arguments),aw([function(){return M(d,"listen_data_layer",a)}]),e=Gs().B(a,Fc(b),c);return e}bw.P="internal.addDataLayerEventListener";function cw(a,b,c){}cw.R="addDocumentEventListener";function dw(a,b,c,d){}dw.R="addElementEventListener";function ew(a){}ew.R="addEventCallback";
function iw(a){}iw.P="internal.addFormAbandonmentListener";var jw={},kw=[],lw={},mw=0,nw=0;
var pw=function(){ec(I,"change",function(a){for(var b=0;b<kw.length;b++)kw[b](a)});ec(z,"pagehide",function(){ow()})},ow=function(){m(lw,function(a,b){var c=jw[a];c&&m(b,function(d,e){qw(e,c)})})},tw=function(a,b){var c=""+a;if(jw[c])jw[c].push(b);else{var d=[b];jw[c]=d;var e=lw[c];e||(e={},lw[c]=e);kw.push(function(f){var g=f.target;if(g){var h=Ku(g);if(h){var l=rw(h,"gtmFormInteractId",function(){return mw++}),n=rw(g,"gtmFormInteractFieldId",function(){return nw++}),p=e[l];p?(p.wa&&(z.clearTimeout(p.wa),
p.ma.dataset.gtmFormInteractFieldId!==n&&qw(p,d)),p.ma=g,sw(p,d,a)):(e[l]={form:h,ma:g,Db:0,wa:null},sw(e[l],d,a))}}})}},qw=function(a,b){var c=a.form,d=a.ma,e=Bu(c,"gtm.formInteract"),f=c.action;f&&f.tagName&&(f=c.cloneNode(!1).action);e["gtm.elementUrl"]=f;e["gtm.interactedFormName"]=c.getAttribute("name");e["gtm.interactedFormLength"]=c.length;e["gtm.interactedFormField"]=d;e["gtm.interactedFormFieldPosition"]=Lu(c,d,"gtmFormInteractFieldId");e["gtm.interactSequenceNumber"]=a.Db;e["gtm.interactedFormFieldId"]=
d.id;e["gtm.interactedFormFieldName"]=d.getAttribute("name");e["gtm.interactedFormFieldType"]=d.getAttribute("type");for(var g=0;g<b.length;g++)b[g](e);a.Db++;a.wa=null},sw=function(a,b,c){c?a.wa=z.setTimeout(function(){qw(a,b)},c):qw(a,b)},rw=function(a,b,c){var d=a.dataset[b];if(d)return d;d=String(c());return a.dataset[b]=d};
function uw(a,b){L(F(this),["callback:!Fn","options:?*"],arguments);var c=Fc(b)||{},d=Number(c.interval);if(!d||0>d)d=0;var e=Fc(a),f;Fu("pix.fil","init")?f=Fu("pix.fil","reg"):(pw(),f=tw,Du("pix.fil","reg",tw),Du("pix.fil","init",!0));f(d,e);}uw.P="internal.addFormInteractionListener";
var ww=function(a,b,c){var d=Bu(a,"gtm.formSubmit");d["gtm.interactedFormName"]=a.getAttribute("name");d["gtm.interactedFormLength"]=a.length;d["gtm.willOpenInCurrentWindow"]=!b&&vw(a);c&&c.value&&(d["gtm.formSubmitButtonText"]=c.value);var e=a.action;e&&e.tagName&&(e=a.cloneNode(!1).action);d["gtm.elementUrl"]=e;return d},xw=function(a,b){var c=Fu("pix.fsl",a?"nv.mwt":"mwt",0);z.setTimeout(b,c)},yw=function(a,b,c,d,e){var f=Fu("pix.fsl",c?"nv.mwt":"mwt",0),g=Fu("pix.fsl",c?"runIfCanceled":"runIfUncanceled",
[]);if(!g.length)return!0;var h=ww(a,c,e);if(d&&f){for(var l=eb(b,g.length),n=0;n<g.length;++n)g[n](h,l);return l.done}for(var p=0;p<g.length;++p)g[p](h,function(){});return!0},zw=function(){var a=[],b=function(c){return Ia(a,function(d){return d.form===c})};return{store:function(c,d){var e=b(c);e?e.button=d:a.push({form:c,button:d})},get:function(c){var d=b(c);return d?d.button:null}}},vw=function(a){var b=lc(a,"target");return b&&"_self"!==b&&"_parent"!==b&&"_top"!==b?!1:!0},Aw=function(){var a=
zw(),b=HTMLFormElement.prototype.submit;ec(I,"click",function(c){var d=c.target;if(d&&(d=jc(d,["button","input"],100))&&("submit"==d.type||"image"==d.type)&&d.name&&gc(d,"value")){var e=Ku(d);e&&a.store(e,d)}},!1);ec(I,"submit",function(c){var d=c.target;if(!d)return c.returnValue;var e=c.defaultPrevented||!1===c.returnValue,f=vw(d)&&!e,g=a.get(d),h=!0,l=function(){if(h){var n;g&&(n=I.createElement("input"),n.type="hidden",n.name=g.name,n.value=g.value,d.appendChild(n));b.call(d);n&&d.removeChild(n)}};
if(yw(d,l,e,f,g))return h=!1,c.returnValue;xw(e,l);e||(c.preventDefault&&c.preventDefault(),c.returnValue=!1);return!1},!1);HTMLFormElement.prototype.submit=function(){var c=this,d=!0,e=function(){d&&b.call(c)};yw(c,e,!1,vw(c))?(b.call(c),d=!1):xw(!1,e)}};
function Bw(a,b){L(F(this),["callback:!Fn","options:?DustMap"],arguments);var c=Fc(b)||{},d=c.waitForCallbacks,e=c.waitForCallbacksTimeout,f=c.checkValidation;e=e&&0<e?e:2E3;var g=Fc(a);if(d){var h=function(n){return Math.max(e,n)};Eu("pix.fsl","mwt",h,0);f||Eu("pix.fsl","nv.mwt",h,0)}var l=function(n){n.push(g);return n};Eu("pix.fsl","runIfUncanceled",l,[]);f||Eu("pix.fsl","runIfCanceled",l,[]);Fu("pix.fsl","init")||(Aw(),Du("pix.fsl",
"init",!0));}Bw.P="internal.addFormSubmitListener";
function Gw(a){}Gw.P="internal.addGaSendListener";var Hw={},Iw=[];
var Pw=function(a,b){};
Pw.P="internal.addHistoryChangeListener";function Qw(a,b,c){}Qw.R="addWindowEventListener";function Rw(a,b){return!0}Rw.R="aliasInWindow";function Sw(a,b,c){}Sw.P="internal.appendRemoteConfigParameter";function Tw(){var a=2;return a};function Uw(a,b){var c;return c}Uw.R="callInWindow";function Vw(a){}Vw.R="callLater";function Ww(a){}Ww.P="callOnDomReady";function Xw(a){}Xw.P="callOnWindowLoad";function Yw(a){var b;return b}Yw.P="internal.computeGtmParameter";function Zw(a,b){var c;var d=Ec(c,this.h,Tw());void 0===d&&void 0!==c&&O(45);return d}Zw.R="copyFromDataLayer";function $w(a){var b;return b}$w.R="copyFromWindow";function ax(a,b){var c;L(F(this),["preHit:!DustMap","dustOptions:?DustMap"],arguments);var d=Fc(b)||{},e=Fc(a,this.h,1).getProcessedEvent(),f=new no(e.target,e.eventName,e.s);d.omitHitData||K(e.C,f.C);d.omitMetadata?f.metadata={}:K(e.metadata,f.metadata);f.M=e.M;c=Ec(qo(f),this.h,1);return c}ax.P="internal.copyPreHit";function bx(a,b){var c=null,d=Tw();return Ec(c,this.h,d)}bx.R="createArgumentsQueue";function cx(a){var b;return Ec(b,this.h,
Tw())}cx.R="createQueue";var dx={},ex=[],fx={},gx=0,hx=0;
function nx(a,b){var c=this;return b}nx.P="internal.enableAutoEventOnFormInteraction";
function sx(a,b){var c=this;return b}sx.P="internal.enableAutoEventOnFormSubmit";
function xx(){var a=this;}xx.P="internal.enableAutoEventOnGaSend";var yx={},zx=[];
var Bx=function(a,b){var c=""+b;if(yx[c])yx[c].push(a);else{var d=[a];yx[c]=d;var e=Ax(),f=-1;zx.push(function(g){0<=f&&z.clearTimeout(f);b?f=z.setTimeout(function(){e(g,d);f=-1},b):e(g,d)})}},Ax=function(){var a=z.location.href,b={source:null,state:z.history.state||null,url:ji(ki(a)),T:ii(ki(a),"fragment")};return function(c,d){var e=b,f={};f[e.source]=!0;f[c.source]=!0;if(!f.popstate||!f.hashchange||e.T!=c.T){var g={},h=(g.event="gtm.historyChange-v2",g["gtm.historyChangeSource"]=c.source,g["gtm.oldUrlFragment"]=
b.T,g["gtm.newUrlFragment"]=c.T,g["gtm.oldHistoryState"]=b.state,g["gtm.newHistoryState"]=c.state,g["gtm.oldUrl"]=b.url,g["gtm.newUrl"]=c.url,g["gtm.triggers"]=d.join(","),g);b=c;mu(h)}}},Cx=function(a,b){var c=z.history,d=c[a];if(Da(d))try{c[a]=function(e,f,g){d.apply(c,[].slice.call(arguments,0));var h=z.location.href;b({source:a,state:e,url:ji(ki(h)),T:ii(ki(h),"fragment")})}}catch(e){}},Ex=function(a){z.addEventListener("popstate",function(b){var c=Dx(b);a({source:"popstate",state:b.state,url:ji(ki(c)),
T:ii(ki(c),"fragment")})})},Fx=function(a){z.addEventListener("hashchange",function(b){var c=Dx(b);a({source:"hashchange",state:null,url:ji(ki(c)),T:ii(ki(c),"fragment")})})},Dx=function(a){return a.target&&a.target.location&&a.target.location.href?a.target.location.href:z.location.href};
function Gx(a,b){var c=this;L(F(this),["options:?DustMap","triggerId:?*"],arguments);aw([function(){return M(c,"process_dom_events","window","popstate")},function(){return M(c,"process_dom_events","window","pushstate")}]);b=Gu(b);var d=Number(a&&a.get("interval"));0<d&&isFinite(d)||(d=0);if(Fu("ehl","init",!1)){var e=Fu("ehl","reg");e&&e(b,d)}else{var f=function(g){for(var h=0;h<zx.length;h++)zx[h](g)};Fx(f);Ex(f);Cx("pushState",
f);Cx("replaceState",f);Bx(b,d);Du("ehl","reg",Bx);Du("ehl","init",!0)}return b}Gx.P="internal.enableAutoEventOnHistoryChange";
var Hx=function(a,b){if(2===a.which||a.ctrlKey||a.shiftKey||a.altKey||a.metaKey)return!1;var c=lc(b,"href"),d=c.indexOf("#"),e=lc(b,"target");if(e&&"_self"!==e&&"_parent"!==e&&"_top"!==e||0===d)return!1;if(0<d){var f=ji(ki(c)),g=ji(ki(z.location.href));return f!==g}return!0},Ix=function(a,b){for(var c=ii(ki((b.attributes&&b.attributes.formaction?b.formAction:"")||b.action||lc(b,"href")||b.src||b.code||b.codebase||""),"host"),d=0;d<a.length;d++)try{if((new RegExp(a[d])).test(c))return!1}catch(e){}return!0},
Jx=function(){var a=0,b=function(c){var d=c.target;if(d&&3!==c.which&&!(c.Zf||c.timeStamp&&c.timeStamp===a)){a=c.timeStamp;d=jc(d,["a","area"],100);if(!d)return c.returnValue;var e=c.defaultPrevented||!1===c.returnValue,f=Fu("aelc",e?"nv.mwt":"mwt",0),g;g=e?Fu("aelc","nv.ids",[]):Fu("aelc","ids",[]);for(var h=[],l=0;l<g.length;l++){var n=g[l],p=Fu("aelc","aff.map",{})[n];p&&!Ix(p,d)||h.push(n)}if(h.length){var q=Hx(c,d),r=Bu(d,"gtm.linkClick",h);r["gtm.elementText"]=hc(d);r["gtm.willOpenInNewWindow"]=
!q;if(q&&!e&&f&&d.href){var u=!!Ia(String(lc(d,"rel")||"").split(" "),function(x){return"noreferrer"===x.toLowerCase()}),t=z[(lc(d,"target")||"_self").substring(1)],v=!0,w=ou(function(){var x;if(x=v&&t){var y;a:if(u){var A;try{A=new MouseEvent(c.type,{bubbles:!0})}catch(B){if(!I.createEvent){y=!1;break a}A=I.createEvent("MouseEvents");A.initEvent(c.type,!0,!0)}A.Zf=!0;c.target.dispatchEvent(A);y=!0}else y=!1;x=!y}x&&(t.location.href=lc(d,"href"))},f);if(nu(r,w,f))v=!1;else return c.preventDefault&&
c.preventDefault(),c.returnValue=!1}else nu(r,function(){},f||2E3);return!0}}};ec(I,"click",b,!1);ec(I,"auxclick",b,!1)};
function Kx(a,b){var c=this;L(F(this),["dustOptions:?DustMap","triggerId:?*"],arguments);aw([function(){return M(c,"process_dom_events","document","click")},function(){return M(c,"process_dom_events","document","auxclick")}]);var d=Fc(a),e=d&&!!d.waitForTags,f=d&&!!d.checkValidation,g=d?d.affiliateDomains:void 0;b=Gu(b);if(e){var h=Number(d.waitForTagsTimeout);0<h&&isFinite(h)||(h=2E3);var l=function(p){return Math.max(h,p)};
Eu("aelc","mwt",l,0);f||Eu("aelc","nv.mwt",l,0)}var n=function(p){p.push(b);return p};Eu("aelc","ids",n,[]);f||Eu("aelc","nv.ids",n,[]);g&&Eu("aelc","aff.map",function(p){p[b]=g;return p},{});Fu("aelc","init",!1)||(Jx(),Du("aelc","init",!0));return b}Kx.P="internal.enableAutoEventOnLinkClick";var Lx,Mx;
var Nx=function(a){return Fu("sdl",a,{})},Ox=function(a,b,c){b&&(Array.isArray(a)||(a=[a]),Eu("sdl",c,function(d){for(var e=0;e<a.length;e++){var f=String(a[e]);d.hasOwnProperty(f)||(d[f]=[]);d[f].push(b)}return d},{}))},Rx=function(){var a=250,b=!1;I.scrollingElement&&I.documentElement&&z.addEventListener&&(a=50,b=!0);var c=0,d=!1,e=function(){d?c=z.setTimeout(e,a):(c=0,Px(),Fu("sdl","init",!1)&&!Qx()&&(fc(z,"scroll",f),fc(z,"resize",f),Du("sdl","init",!1)));d=!1},f=function(){b&&Lx();c?d=!0:(c=
z.setTimeout(e,a),Du("sdl","pending",!0))};return f},Px=function(){var a=Lx(),b=a.Nf,c=a.Of,d=b/Mx.scrollWidth*100,e=c/Mx.scrollHeight*100;Sx(b,"horiz.pix","PIXELS","horizontal");Sx(d,"horiz.pct","PERCENT","horizontal");Sx(c,"vert.pix","PIXELS","vertical");Sx(e,"vert.pct","PERCENT","vertical");Du("sdl","pending",!1)},Sx=function(a,b,c,d){var e=Nx(b),f={},g;for(g in e){f.Ub=g;if(e.hasOwnProperty(f.Ub)){var h=Number(f.Ub);if(!(a<h)){var l={};mu((l.event="gtm.scrollDepth",l["gtm.scrollThreshold"]=h,
l["gtm.scrollUnits"]=c.toLowerCase(),l["gtm.scrollDirection"]=d,l["gtm.triggers"]=e[f.Ub].join(","),l));Eu("sdl",b,function(n){return function(p){delete p[n.Ub];return p}}(f),{})}}f={Ub:f.Ub}}},Ux=function(){Eu("sdl","scr",function(a){a||(a=I.scrollingElement||I.body&&I.body.parentNode);return Mx=a},!1);Eu("sdl","depth",function(a){a||(a=Tx());return Lx=a},!1)},Tx=function(){var a=0,b=0;return function(){var c=Wh(),d=c.height;a=Math.max(Mx.scrollLeft+c.width,a);b=Math.max(Mx.scrollTop+d,b);return{Nf:a,
Of:b}}},Qx=function(){return!!(Object.keys(Nx("horiz.pix")).length||Object.keys(Nx("horiz.pct")).length||Object.keys(Nx("vert.pix")).length||Object.keys(Nx("vert.pct")).length)};
function Vx(a,b){var c=this;L(F(this),["options:!DustMap","triggerId:?*"],arguments);aw([function(){return M(c,"process_dom_events","window","resize")},function(){return M(c,"process_dom_events","window","scroll")}]);Ux();if(!Mx)return;b=Gu(b);var d=Fc(a);switch(d.horizontalThresholdUnits){case "PIXELS":Ox(d.horizontalThresholds,b,"horiz.pix");break;case "PERCENT":Ox(d.horizontalThresholds,b,"horiz.pct")}switch(d.verticalThresholdUnits){case "PIXELS":Ox(d.verticalThresholds,
b,"vert.pix");break;case "PERCENT":Ox(d.verticalThresholds,b,"vert.pct")}Fu("sdl","init",!1)?Fu("sdl","pending",!1)||J(function(){return Px()}):(Du("sdl","init",!0),Du("sdl","pending",!0),J(function(){Px();if(Qx()){var e=Rx();ec(z,"scroll",e);ec(z,"resize",e)}else Du("sdl","init",!1)}));return b}Vx.P="internal.enableAutoEventOnScroll";var Sb=ea(["data-gtm-yt-inspected-"]),Wx=["www.youtube.com","www.youtube-nocookie.com"],Xx,Yx=!1;
var Zx=function(a,b,c){var d=a.map(function(g){return{sa:g,xd:g,vd:void 0}});if(!b.length)return d;var e=b.map(function(g){return{sa:g*c,xd:void 0,vd:g}});if(!d.length)return e;var f=d.concat(e);f.sort(function(g,h){return g.sa-h.sa});return f},$x=function(a){a=void 0===a?[]:a;for(var b=[],c=0;c<a.length;c++)0>a[c]||b.push(a[c]);b.sort(function(d,e){return d-e});return b},ay=function(a){a=void 0===a?[]:a;for(var b=[],c=0;c<a.length;c++)100<a[c]||0>a[c]||(b[c]=a[c]/100);b.sort(function(d,e){return d-
e});return b},by=function(a,b){var c,d;function e(){u=Zu(function(){return{url:w,title:x,Pf:v,Zh:a.getCurrentTime(),playbackRate:y}},b.ab,a.getIframe());v=0;x=w="";y=1;return f}function f(D){switch(D){case 1:v=Math.round(a.getDuration());w=a.getVideoUrl();if(a.getVideoData){var H=a.getVideoData();x=H?H.title:""}y=a.getPlaybackRate();b.Jf?mu(u.createEvent("start")):u.nc();t=Zx(b.pg,b.og,a.getDuration());return g(D);default:return f}}function g(){A=a.getCurrentTime();B=Sa().getTime();u.wi();r();return h}
function h(D){var H;switch(D){case 0:return n(D);case 2:H="pause";case 3:var G=a.getCurrentTime()-A;H=1<Math.abs((Sa().getTime()-B)/1E3*y-G)?"seek":H||"buffering";a.getCurrentTime()&&(b.If?mu(u.createEvent(H)):u.nc());q();return l;case -1:return e(D);default:return h}}function l(D){switch(D){case 0:return n(D);case 1:return g(D);case -1:return e(D);default:return l}}function n(){for(;d;){var D=c;z.clearTimeout(d);D()}b.Hf&&mu(u.createEvent("complete",1));return e(-1)}function p(){}function q(){d&&
(z.clearTimeout(d),d=0,c=p)}function r(){if(t.length&&0!==y){var D=-1,H;do{H=t[0];if(H.sa>a.getDuration())return;D=(H.sa-a.getCurrentTime())/y;if(0>D&&(t.shift(),0===t.length))return}while(0>D);c=function(){d=0;c=p;0<t.length&&t[0].sa===H.sa&&(t.shift(),mu(u.createEvent("progress",H.vd,H.xd)));r()};d=z.setTimeout(c,1E3*D)}}var u,t=[],v,w,x,y,A,B,C=e(-1);d=0;c=p;return{onStateChange:function(D){C=C(D)},onPlaybackRateChange:function(D){A=a.getCurrentTime();B=Sa().getTime();u.nc();y=D;q();r()}}},dy=
function(a){J(function(){function b(){for(var d=c.getElementsByTagName("iframe"),e=d.length,f=0;f<e;f++)cy(d[f],a)}var c=I;b();Ou(b)})},cy=function(a,b){if(!a.getAttribute("data-gtm-yt-inspected-"+b.ab)&&(Rb(a,"data-gtm-yt-inspected-"+b.ab),ey(a,b.kd))){a.id||(a.id=fy());var c=z.YT,d=c.get(a.id);d||(d=new c.Player(a.id));var e=by(d,b),f={},g;for(g in e)f.Bc=g,e.hasOwnProperty(f.Bc)&&d.addEventListener(f.Bc,function(h){return function(l){return e[h.Bc](l.data)}}(f)),f={Bc:f.Bc}}},ey=function(a,b){var c=
a.getAttribute("src");if(gy(c,"embed/")){if(0<c.indexOf("enablejsapi=1"))return!0;if(b){var d;var e=-1!==c.indexOf("?")?"&":"?";-1<c.indexOf("origin=")?d=c+e+"enablejsapi=1":(Xx||(Xx=I.location.protocol+"//"+I.location.hostname,I.location.port&&(Xx+=":"+I.location.port)),d=c+e+"enablejsapi=1&origin="+encodeURIComponent(Xx));var f;f=Eb(d);a.src=Db(f).toString();return!0}}return!1},gy=function(a,b){if(!a)return!1;for(var c=0;c<Wx.length;c++)if(0<=a.indexOf("//"+Wx[c]+"/"+b))return!0;return!1},fy=function(){var a=
Math.round(1E9*Math.random())+"";return I.getElementById(a)?fy():a};
function hy(a,b){var c=this;L(F(this),["dustOptions:!DustMap","triggerId:?*"],arguments);aw([function(){return M(c,"process_dom_events","element","onStateChange")},function(){return M(c,"process_dom_events","element","onPlaybackRateChange")}]);b=Gu(b);var d=!!a.get("captureStart"),e=!!a.get("captureComplete"),f=!!a.get("capturePause"),g=ay(Fc(a.get("progressThresholdsPercent"))),h=$x(Fc(a.get("progressThresholdsTimeInSeconds"))),
l=!!a.get("fixMissingApi");if(!(d||e||f||g.length||h.length))return;var n={Jf:d,Hf:e,If:f,og:g,pg:h,kd:l,ab:b},p=z.YT,q=function(){dy(n)};if(p)return p.ready&&p.ready(q),b;var r=z.onYouTubeIframeAPIReady;z.onYouTubeIframeAPIReady=function(){r&&r();q()};J(function(){for(var u=I.getElementsByTagName("script"),t=u.length,v=0;v<t;v++){var w=u[v].getAttribute("src");if(gy(w,"iframe_api")||gy(w,"player_api"))return b}for(var x=I.getElementsByTagName("iframe"),y=x.length,A=0;A<y;A++)if(!Yx&&ey(x[A],n.kd))return ac("https://www.youtube.com/iframe_api"),
Yx=!0,b});return b}hy.P="internal.enableAutoEventOnYouTubeActivity";function iy(a,b){var c=!1;L(F(this),["booleanExpression:!string","context:?DustMap"],arguments);var d=JSON.parse(a);if(!d)throw Error("Invalid boolean expression string was given.");var e=b?Fc(b):{};c=jy(d,e);return c}
var ky=function(a,b){for(var c=0;c<b.length;c++){if(void 0===a)return;a=a[b[c]]}return a},ly=function(a,b){if(1===a.namespaceType){var c=b.preHit;if(!c)return;var d=a.keyParts;if(!d||0===d.length)return;var e=d[0];switch(e){case "hitData":return 2>d.length?void 0:ky(c.getHitData(d[1]),d.slice(2));case "metadata":return 2>d.length?void 0:ky(c.getMetadata(d[1]),d.slice(2));case "eventName":return c.getEventName();case "destinationId":return c.getDestinationId();default:throw Error(e+" is not a valid field that can be accessed\n                        from PreHit data.");
}}throw Error("Unknown Namespace Type used:\n                      "+a.namespaceType);},my=function(a,b){if(a){if(void 0!==a.contextValue)return ly(a.contextValue,b);if(void 0!==a.booleanExpressionValue)return jy(a.booleanExpressionValue,b);if(void 0!==a.booleanValue)return!!a.booleanValue;if(void 0!==a.stringValue)return String(a.stringValue);if(void 0!==a.integerValue)return Number(a.integerValue);if(void 0!==a.doubleValue)return Number(a.doubleValue);throw Error("Unknown field used for variable of type ExpressionValue:"+
a);}},jy=function(a,b){var c=a.args;if(!Ga(c)||0===c.length)throw Error('Invalid boolean expression format. Expected "args":'+c+" property to\n         be non-empty array.");var d=function(g){return my(g,b)};switch(a.type){case 1:for(var e=0;e<c.length;e++)if(d(c[e]))return!0;return!1;case 2:for(var f=0;f<c.length;f++)if(!d(c[f]))return!1;return 0<c.length;case 3:return!d(c[0]);case 4:return Ov(d(c[0]),d(c[1]),!1);case 5:return Rv(d(c[0]),d(c[1]));case 6:return Wv(d(c[0]),d(c[1]));case 7:return Mv(d(c[0]),
d(c[1]));case 8:return Qv(d(c[0]),d(c[1]));case 9:return Vv(d(c[0]),d(c[1]));case 10:return Tv(d(c[0]),d(c[1]));case 11:return Uv(d(c[0]),d(c[1]));case 12:return Sv(d(c[0]),d(c[1]));default:throw Error('Invalid boolean expression format. Expected "type" property tobe a positive integer which is less than 13.');}};iy.P="internal.evaluateBooleanExpression";var ny;function oy(a){var b=!1;return b}oy.P="internal.evaluateMatchingRules";
var qy=function(a,b,c){if(c)switch(c.type){case "event_name":return a;case "const":return c.const_value;case "event_param":var d=c.event_param.param_name;if(d===S.g.kf)return py(b);return b[d]}},uy=function(a,b,c,d){ry=!1;if(c&&!sy(a,b,c))return!1;if(!d||0===d.length)return!0;for(var e=0;e<d.length;e++)if(ty(a,b,d[e].predicates||[]))return!0;return!1},ty=function(a,b,c){for(var d=0;d<c.length;d++)if(!sy(a,
b,c[d]))return!1;return!0},sy=function(a,b,c){var d=c.values||[],e=qy(a,b,d[0]),f=qy(a,b,d[1]),g=c.type;if("eqi"===g||"swi"===g||"ewi"===g||"cni"===g)k(e)&&(e=e.toLowerCase()),k(f)&&(f=f.toLowerCase());var h=!1;switch(g){case "eq":case "eqi":h=Rv(e,f);break;case "sw":case "swi":h=Wv(e,f);break;case "ew":case "ewi":h=Mv(e,f);break;case "cn":case "cni":h=Qv(e,f);break;case "lt":h=Vv(e,f);break;case "le":h=Tv(e,f);break;case "gt":h=Uv(e,f);break;case "ge":h=Sv(e,f);break;case "re":case "rei":h=Ov(e,
f,"rei"===g)}return!!c.negate!==h},ry=!1;var py=function(a){var b=a[S.g.kf];if(b)return b;ry=!0;var c=a[S.g.Ta];if(k(c)){var d=U(57);if(Da(URL))try{var e=new URL(c);return e.pathname+vy(d?e.search:"")}catch(h){return}var f=ki(c);if(f.hostname){var g=d?ii(f,"query"):"";g&&(g="?"+g);return ii(f,"path")+vy(g)}}},vy=function(a){if(!U(72)||!a)return a;var b=a.split("&"),c=[];b[0]=b[0].substring(1);for(var d=0;d<b.length;d++){var e=b[d],f=e.indexOf("=");
wy[0<=f?e.substring(0,f):e]||c.push(b[d])}return c.length?"?"+c.join("&"):""},wy=Object.freeze({__utma:1,__utmb:1,__utmc:1,__utmk:1,__utmv:1,__utmx:1,__utmz:1,__ga:1,_gac:1,_gl:1,dclid:1,gbraid:1,gclid:1,gclsrc:1,utm_campaign:1,utm_content:1,utm_expid:1,utm_id:1,utm_medium:1,utm_nooverride:1,utm_referrer:1,utm_source:1,utm_term:1,wbraid:1});function xy(a,b){var c=!1;return c}xy.P="internal.evaluatePredicates";var yy=function(a){var b;return b};function zy(a,b){b=void 0===b?!0:b;var c;return c}zy.R="getCookieValues";function Ay(){return Mi.Ae}Ay.P="internal.getCountryCode";function By(){var a=[];a=Ok();return Ec(a)}By.P="internal.getDestinationIds";function Cy(a){var b=null;return b}Cy.R="getElementById";var Dy={};Dy.enableAdsHistoryChangeEvents=U(36);Dy.enableAlwaysSendFormStart=U(38);Dy.enableCcdEnhancedMeasurement=U(41);Dy.enableCcdEventBlocking=U(40);Dy.enableCcdEventEditingAndCreation=U(26);Dy.enableCcdGaConversions=U(39);Dy.enableCcdPreAutoPiiDetection=U(49);Dy.enableCcdUserData=U(16);Dy.enableEesPagePath=U(43);Dy.enableEmFormCcd=U(35);Dy.enableEuidAutoMode=U(37);Dy.enableFileDownloadExtensionRegexFullMatch=U(63);Dy.enableGa4OnoRemarketing=U(34);Dy.enableGaGamWindowSet=U(67);
Dy.autoPiiEligible=!0;function Ey(){return Ec(Dy)}Ey.P="internal.getFlags";function Fy(a,b){var c;L(F(this),["targetId:!string","name:!string"],arguments);var d=Th(a)||{};c=Ec(d[b],this.h);return c}Fy.P="internal.getProductSettingsParameter";function Gy(a,b){var c;L(F(this),["queryKey:!string","retrieveAll:?boolean"],arguments);M(this,"get_url","query",a);var d=ii(ki(z.location.href),"query"),e=fi(d,a,b);c=Ec(e,this.h);return c}Gy.R="getQueryParameters";function Hy(a,b){var c;return c}Hy.R="getReferrerQueryParameters";function Iy(a){var b="";return b}Iy.R="getReferrerUrl";function Jy(){return Mi.si}Jy.P="internal.getRegionCode";function Ky(a,b){var c;L(F(this),["targetId:!string","name:!string"],arguments);var d=Ss(Ms,a).h;c=Ec(d[b],this.h);return c}Ky.P="internal.getRemoteConfigParameter";function Ly(a){var b="";L(F(this),["component:?string"],arguments),M(this,"get_url",a),b=ii(ki(z.location.href),a);return b}Ly.R="getUrl";function My(){M(this,"get_user_agent");return Ub.userAgent}My.R="getUserAgent";function Ny(a){if(!a)return{};var b=a.dk;return Jr(b.type,b.index,b.name)}function Oy(a){return a?{originatingEntity:Ny(a)}:{}};
function Qy(a,b){}Qy.R="gtagSet";function Ry(a,b){}Ry.R="injectHiddenIframe";var Sy={};
function Uy(a,b,c,d){}var Vy=Object.freeze({dl:1,id:1}),Wy={};
function Xy(a,b,c,d){}Uy.R="injectScript";Xy.P="internal.injectScript";function Yy(a){var b=!0;return b}Yy.R="isConsentGranted";var Zy=function(){var a=ag(function(b){this.h.h.log("error",b)});a.R="JSON";return a};var $y=function(){return!1},az={getItem:function(a){var b=null;return b},setItem:function(a,
b){return!1},removeItem:function(a){}};var bz=["textContent","value","tagName","children","childElementCount"];
function cz(a){var b;M(this,"read_dom_elements","css","*");for(var c=0;c<bz.length;c++)M(this,"access_dom_element_property",I.body,"read",bz[c]);var d=Fc(a)||{},e=Ai({uc:!!d.includeSelector,vc:!!d.includeVisibility,gd:d.excludeElementSelectors,lb:d.fieldFilters,xi:!!d.selectMultipleElements});b=new jb;var f=new wa;b.set("elements",f);for(var g=e.elements,h=0;h<g.length;h++)f.push(dz(g[h]));void 0!==e.ng&&b.set("preferredEmailElement",
dz(e.ng));b.set("status",e.status);return b}var dz=function(a){var b=new jb;b.set("userData",a.eb);b.set("tagName",a.tagName);void 0!==a.querySelector&&b.set("querySelector",a.querySelector);void 0!==a.isVisible&&b.set("isVisible",a.isVisible);switch(a.type){case 1:b.set("type","email")}return b};cz.P="internal.locateUserData";function ez(){}ez.R="logToConsole";function fz(a){var b=void 0;if("function"===typeof URL){var c;a:{var d;try{d=new URL(a)}catch(w){c=void 0;break a}for(var e={},f=Array.from(d.searchParams),g=0;g<f.length;g++){var h=f[g][0],l=f[g][1];e.hasOwnProperty(h)?"string"===typeof e[h]?e[h]=[e[h],l]:e[h].push(l):e[h]=l}c=Ec({href:d.href,origin:d.origin,protocol:d.protocol,username:d.username,password:d.password,host:d.host,hostname:d.hostname,port:d.port,pathname:d.pathname,search:d.search,searchParams:e,
hash:d.hash})}return c}var n;try{n=ki(a)}catch(w){return}if(!n.protocol||!n.host)return;var p={};if(n.search)for(var q=n.search.replace("?","").split("&"),r=0;r<q.length;r++){var u=q[r].split("="),t=u[0],v=decodeURIComponent(u.splice(1).join("="));p.hasOwnProperty(t)?"string"===typeof p[t]?p[t]=[p[t],v]:p[t].push(v):p[t]=v}n.searchParams=p;n.origin=n.protocol+"//"+n.host;n.username="";n.password="";b=Ec(n);return b}fz.R="parseUrl";function gz(a){}gz.P="internal.processAsNewEvent";function hz(a,b){var c=!1;return c}hz.R="queryPermission";function iz(){var a="";return a}iz.R="readCharacterSet";function jz(){var a="";return a}jz.R="readTitle";function kz(a,b){var c=this;L(F(this),["destinationId:!string","callback:!Fn"],arguments),to(a,function(d){b.h(c.h,Ec(d,c.h,1))});}kz.P="internal.registerCcdCallback";var lz=Object.freeze(["config","event","get","set"]);function mz(a,b,c){}mz.P="internal.registerGtagCommandListener";function nz(a,b){var c=!1;return c}nz.P="internal.removeDataLayerEventListener";function oz(){}oz.R="resetDataLayer";
var pz=function(a){var b=!1;return b},qz=function(a){return po(a,S.g.ef,!1)},rz=function(a){if(a.metadata.is_merchant_center)return!1;var b=T(a.s,S.g.ce);return!(!0!==b&&"true"!==b||!T(a.s,S.g.za))},sz=function(a){var b=a.metadata.user_data;if(Dc(b))return b},tz=function(a,b){var c=po(a,S.g.ae,a.s.D[S.g.ae]);if(c&&void 0!==c[b||a.eventName])return c[b||a.eventName]},
uz=function(a,b,c){a.C[S.g.bd]||(a.C[S.g.bd]={});a.C[S.g.bd][b]=c};var vz=!1,wz=function(a){var b=a.eventName===S.g.Jc&&bj()&&rz(a),c=a.metadata.batch_on_navigation,d=a.metadata.is_conversion,e=a.metadata.is_session_start,f=a.metadata.create_dc_join,g=a.metadata.create_google_join,h=a.metadata.euid_mode_enabled&&!!sz(a);return!(!Ub.sendBeacon||d||h||e||f||g||b||!c&&vz)};var xz=function(a){vb("GA4_EVENT",a)};var zz=function(a){return!a||yz.test(a)||Sg.hasOwnProperty(a)},Az=function(a,b,c){for(var d=c.event_param_ops||[],e=0;e<d.length;e++){var f=d[e];if(f.edit_param){var g=f.edit_param.param_name,h=qy(a,b,f.edit_param.param_value),l;if(h){var n=Number(h);l=isNaN(n)?h:n}else l=h;b[g]=l}else f.delete_param&&delete b[f.delete_param.param_name]}},yz=/^(_|ga_|google_|gtag\.|firebase_).*$/;
var Bz=function(a){var b=0,c=0;return{start:function(){b=Ta()},stop:function(){c=this.get()},get:function(){var d=0;a.cg()&&(d=Ta()-b);return d+c}}},Cz=function(){this.h=void 0;this.B=0;this.isActive=this.isVisible=this.D=!1;this.N=this.F=void 0};ba=Cz.prototype;ba.yj=function(a){var b=this;if(!this.h){this.D=I.hasFocus();this.isVisible=!I.hidden;this.isActive=!0;var c=function(d,e,f){ec(d,e,function(g){b.h.stop();f(g);b.cg()&&b.h.start()})};c(z,"focus",function(){b.D=!0});c(z,"blur",function(){b.D=
!1});c(z,"pageshow",function(d){b.isActive=!0;d.persisted&&O(56);b.N&&b.N()});c(z,"pagehide",function(){b.isActive=!1;b.F&&b.F()});c(I,"visibilitychange",function(){b.isVisible=!I.hidden});rz(a)&&-1===(Ub.userAgent||"").indexOf("Firefox")&&-1===(Ub.userAgent||"").indexOf("FxiOS")&&c(z,"beforeunload",function(){vz=!0});this.rg();this.B=0}};ba.rg=function(){this.B+=this.Ee();this.h=Bz(this);this.cg()&&this.h.start()};ba.sl=function(a){var b=this.Ee();0<b&&(a.C[S.g.Yd]=b)};ba.rk=function(a){a.C[S.g.Yd]=
void 0;this.rg();this.B=0};ba.cg=function(){return this.D&&this.isVisible&&this.isActive};ba.nk=function(){return this.B+this.Ee()};ba.Ee=function(){return this.h&&this.h.get()||0};ba.Wk=function(a){this.F=a};ba.ui=function(a){this.N=a};function Dz(){return z.gaGlobal=z.gaGlobal||{}}var Ez=function(){var a=Dz();a.hid=a.hid||Ka();return a.hid},Fz=function(a,b){var c=Dz();if(void 0==c.vid||b&&!c.from_cookie)c.vid=a,c.from_cookie=b};
var Gz=function(a,b,c){var d=a.metadata.client_id_source;if(void 0===d||c<=d)a.C[S.g.ub]=b,a.metadata.client_id_source=c},Jz=function(a,b){var c;var d=b.metadata.cookie_options,e=d.prefix+"_ga",f=Rj(d,void 0,void 0,S.g.W);if(!1===T(b.s,S.g.Zb)&&Hz(b)===a)c=!0;else{var g=Qj(a,Iz[0],d.domain,d.path);c=1!==Ij(e,g,f)}return c},Hz=function(a){var b=a.metadata.cookie_options,c=b.prefix+"_ga",d=Pj(c,b.domain,b.path,Iz,S.g.W);if(!d){var e=String(T(a.s,S.g.Mc,""));e&&e!=c&&(d=Pj(e,b.domain,b.path,Iz,S.g.W))}return d},
Iz=["GA1"],Kz=function(a,b){var c=a.C[S.g.ub];if(b&&c===b)return c;if(c){c=""+c;if(!Jz(c,a))return O(31),a.M=!0,"";Fz(c,nj(S.g.W));return c}O(32);a.M=!0;return""};
var Nz=function(a,b,c){if(!b)return a;if(!a)return b;var d=Lz(a);if(!d)return b;var e,f=Oa(null!=(e=T(c.s,S.g.Uc))?e:30);if(!(Math.floor(c.metadata.event_start_timestamp_ms/1E3)>d.rd+60*f))return a;var g=Lz(b);if(!g)return a;g.Rb=d.Rb+1;var h;return null!=(h=Mz(g.sessionId,g.Rb,g.xc,g.rd,g.dg,g.Pb,g.fd))?h:b},Qz=function(a,b){var c=b.metadata.cookie_options,d=Oz(b,c),e=Qj(a,Pz[0],c.domain,c.path),f={pb:S.g.W,domain:c.domain,path:c.path,expires:c.Cb?new Date(Ta()+1E3*c.Cb):void 0,flags:c.flags};U(52)&&
Ij(d,void 0,f);return 1!==Ij(d,e,f)},Rz=function(a){var b=a.metadata.cookie_options,c=Oz(a,b),d=Pj(c,b.domain,b.path,Pz,S.g.W);if(!d||!em&&!U(52))return d;var e=zj(c,void 0,void 0,S.g.W);if(d&&1<e.length){O(114);for(var f=void 0,g=void 0,h=0;h<e.length;h++){var l=e[h].split(".");if(!(7>l.length)){var n=Number(l[5]);n&&(!g||n>g)&&(g=n,f=e[h])}}f&&!f.endsWith(d)&&(O(115),U(52)&&(d=f.split(".").slice(2).join(".")))}return d},Mz=function(a,b,c,d,e,f,g){if(a&&b){var h=[a,b,Oa(c),d,e];h.push(f?"1":"0");
h.push(g||"0");return h.join(".")}},Pz=["GS1"],Oz=function(a,b){return b.prefix+"_ga_"+a.target.O[0]},Lz=function(a){if(a){var b=a.split(".");if(!(5>b.length||7<b.length))return 7>b.length&&O(67),{sessionId:b[0],Rb:Number(b[1]),xc:!!Number(b[2]),rd:Number(b[3]),dg:Number(b[4]||0),Pb:"1"===b[5],fd:"0"!==b[6]?b[6]:void 0}}},Sz=function(a){return Mz(a.C[S.g.yb],a.C[S.g.me],a.C[S.g.ke],Math.floor(a.metadata.event_start_timestamp_ms/1E3),a.metadata.join_timer_sec||0,!!a.metadata[S.g.cf],a.C[S.g.Pc])};
var Tz=function(a){var b=T(a.s,S.g.ya),c=a.s.D[S.g.ya];if(c===b)return c;var d=K(b);c&&c[S.g.V]&&(d[S.g.V]=(d[S.g.V]||[]).concat(c[S.g.V]));return d},Uz=function(a,b){var c=kk(!0);return"1"!==c._up?{}:{clientId:c[a],yi:c[b]}},Vz=function(a,b,c){var d=kk(!0),e=d[b];e&&(Gz(a,e,2),Jz(e,a));var f=d[c];f&&Qz(f,a);return!(!e||!f)},Wz=!1,Xz=function(a){var b=Tz(a)||{},c=a.metadata.cookie_options,d=c.prefix+"_ga",e=Oz(a,c);tk(b[S.g.fc],!!b[S.g.V])&&Vz(a,d,e)&&(Wz=!0);b[S.g.V]&&qk(function(){var f={},g=Hz(a);
g&&(f[d]=g);var h=Rz(a);h&&(f[e]=h);var l=zj("FPLC",void 0,void 0,S.g.W);l.length&&(f._fplc=l[0]);return f},b[S.g.V],b[S.g.hc],!!b[S.g.Jb])},Zz=function(a){if(!T(a.s,S.g.zb))return{};var b=a.metadata.cookie_options,c=b.prefix+"_ga",d=Oz(a,b);rk(function(){var e;if(nj("analytics_storage"))e={};else{var f={};e=(f._up="1",f[c]=a.C[S.g.ub],f[d]=Sz(a),f)}return e},1);return!nj("analytics_storage")&&Yz()?Uz(c,d):{}},Yz=function(){var a=hi(z.location,"host"),b=hi(ki(I.referrer),"host");return a&&b?a===b||
0<=a.indexOf("."+b)||0<=b.indexOf("."+a)?!0:!1:!1},$z=function(a){if(!a)return a;var b=String(a);b=jk(b);return b=jk(b,"_ga")};var aA=function(){var a=!0;Wl(7)&&Wl(9)&&Wl(10)||(a=!1);return a},bA=function(){var a=!0;Wl(3)&&Wl(4)||(a=!1);return a};
var cA=function(a,b){if(!U(65)&&rz(b)){var c=up();c&&(a.us_privacy=c);var d=Vl();d&&(a.gdpr=d);var e=Ul();e&&(a.gdpr_consent=e)}},dA=function(a,b){if(bj()){a.gcs=oj();var c=b.metadata.is_consent_update;c&&(a.gcu="1");if(!U(65)&&rz(b)){cj()&&(a.gcd="G1"+jj($i));var d=T(b.s,S.g.na);a.adr=void 0!==d&&!1!==d?"1":"0";c&&(a.gcut=$g[b.metadata.consent_update_type||""])}}},eA=function(a,b,c){void 0===c&&(c={});if("object"===typeof b)for(var d in b)eA(a+"."+d,b[d],c);else c[a]=b;return c},hA=function(a){if(a.metadata.is_merchant_center)return"https://www.merchant-center-analytics.goog/mc/collect";
var b=jr(T(a.s,S.g.za),"/g/collect");if(b)return b;var c=po(a,S.g.kb,T(a.s,S.g.kb));var d=T(a.s,S.g.Gb);return c&&!qz(a)&&!1!==d&&aA()&&nj(S.g.K)&&nj(S.g.W)?fA():gA()},iA="",jA=!1;jA=!0;var kA={};kA[S.g.tj]="tid";kA[S.g.ub]=
"cid";kA[S.g.Sa]="ul";kA[S.g.df]="_fid";kA[S.g.pf]="tt";kA[S.g.he]="ir";kA[S.g.Lb]="sr";kA[S.g.cc]="gdid";kA[S.g.Tc]="_rdi";kA[S.g.Zg]="_geo";kA[S.g.Gh]="gtm_up";kA[S.g.Cf]="_glv";kA[S.g.qf]="uaa",kA[S.g.rf]=
"uab",kA[S.g.sf]="uafvl",kA[S.g.tf]="uamb",kA[S.g.uf]="uam",kA[S.g.vf]="uap",kA[S.g.wf]="uapv",kA[S.g.qh]="uaW",kA[S.g.xf]="uaw";var lA={};lA[S.g.yb]="sid";lA[S.g.me]="sct";lA[S.g.ke]="seg";lA[S.g.Ta]="dl";lA[S.g.Ua]="dr";lA[S.g.ic]="dt";lA[S.g.va]="cu";lA[S.g.Aa]="uid";lA[S.g.Qd]="cc";lA[S.g.Rd]="ci";lA[S.g.Sd]="cm";lA[S.g.Td]="cn";lA[S.g.Ud]="cs";lA[S.g.Vd]="ck";var mA={};mA[S.g.Yd]="_et";mA[S.g.bc]="edid";var nA={};nA[S.g.Qd]="cc";nA[S.g.Rd]="ci";nA[S.g.Sd]=
"cm";nA[S.g.Td]="cn";nA[S.g.Ud]="cs";nA[S.g.Vd]="ck";var oA={},pA=Object.freeze((oA[S.g.oa]=!0,oA)),gA=function(){var a="www";jA&&iA&&(a=iA);return"https://"+a+".google-analytics.com/g/collect"},fA=function(){var a;jA&&iA&&(a=iA);return"https://"+(a?a+".":"")+"analytics.google.com/g/collect"},qA=function(a,b,c){var d={},e={},f={};d.v="2";d.tid=a.target.X;d.gtm=
Xk();d._p=Ez();c&&(d.em=c);a.metadata.create_google_join&&(d._gaz=1);dA(d,a);cA(d,a);var g=a.C[S.g.cc];g&&(d.gdid=g);e.en=gf(a.eventName,40);a.metadata.is_first_visit&&(e._fv=a.metadata.is_first_visit_conversion?2:1);a.metadata.is_new_to_site&&(e._nsi=1);a.metadata.is_session_start&&(e._ss=a.metadata.is_session_start_conversion?
2:1);a.metadata.is_conversion&&(e._c=1);a.metadata.is_external_event&&(e._ee=1);if(a.metadata.is_ecommerce){var h=a.C[S.g.ia]||T(a.s,S.g.ia);if(Ga(h))for(var l=0;l<h.length&&200>l;l++)e["pr"+(l+1)]=nf(h[l])}var n=a.C[S.g.bc];n&&(e.edid=n);var p=function(v,w){if(!U(23)||"object"!==typeof w||!pA[v]){v=gf(v,40);var x="ep."+v,y="epn."+v;v=Ea(w)?y:x;var A=Ea(w)?x:y;e.hasOwnProperty(A)&&delete e[A];e[v]=gf(w,100)}},q=function(v,w){if(U(23))return!1;var x=v.split(".");if(v===S.g.oa&&"object"!==typeof w)return p(v,
w),!0;if(x[0]===S.g.oa){if((1<x.length||"object"===typeof w)&&rz(a)){var y=eA(v,w);m(y,function(A,B){return void p(A,B)})}return!0}return!1},r=function(v){rz(a)&&"object"===typeof v&&m(v||{},function(w,x){"object"!==typeof x&&(d["sst."+w]=gf(x,420))})};m(a.C,function(v,w){if(void 0!==w&&!Qg.hasOwnProperty(v)){null===w&&(w="");var x;v!==S.g.Pc?x=!1:a.metadata.euid_mode_enabled?(d.ecid=w,x=!0):x=void 0;if(!x&&v!==S.g.cf){var y=w;!0===w&&(y="1");!1===w&&(y="0");var A;if(kA[v])A=kA[v],U(65)&&v===S.g.Cf||
(d[A]=gf(y,420));else if(lA[v])A=lA[v],f[A]=gf(y,420);else if(mA[v])A=mA[v],e[A]=gf(y,420);else if("_"===v.charAt(0))d[v]=gf(y,420);else{var B;(B=q(v,w))||(nA[v]?B=!0:v!==S.g.Kc?B=!1:("object"!==typeof w&&p(v,w),B=!0));B||p(v,w)}}}});U(65)&&r(a.C[S.g.bd]);a.metadata.user_data&&q("user_data",a.metadata.user_data);var u=a.C[S.g.Ma]||{};!1!==T(a.s,S.g.da)&&bA()||(u._npa="1");U(28)&&!1===T(a.s,S.g.Gb)&&(d.ngs="1");m(u,function(v,w){if(void 0!==w)if(null===w&&(w=""),v===S.g.Aa&&!f.uid)f.uid=gf(w,36);else if(b[v]!==
w){var x=(Ea(w)?"upn.":"up.")+gf(v,24);e[x]=gf(w,36);b[v]=w}});var t=!1;return pf.call(this,{Ba:d,Sb:f,Rf:e},hA(a),rz(a),t)||this};na(qA,pf);var rA=function(){var a=Ta(),b=a+864E5,c=20,d=5E3;return function(){var e=Ta();e>=b&&(b=e+864E5,d=5E3);if(1>d)return!1;c=Math.min(c+(e-a)/1E3*5,20);a=e;if(1>c)return!1;d--;c--;return!0}};
var sA=function(a,b){return a.replace(/\$\{([^\}]+)\}/g,function(c,d){return b[d]||c})},tA=function(a){var b=a.search;return a.protocol+"//"+a.hostname+a.pathname+(b?b+"&richsstsse":"?richsstsse")},uA=function(a){var b={},c="",d=a.pathname.indexOf("/g/collect");0<=d&&(c=a.pathname.substring(0,d));b.transport_url=a.protocol+"//"+a.hostname+c;return b},vA=function(a,b){var c=new z.XMLHttpRequest;c.withCredentials=!0;var d=b?"POST":"GET",e="",f=0,g=ki(a),h=uA(g),l=tA(g);c.onprogress=function(n){if(200===
c.status){e+=c.responseText.substring(f);f=n.loaded;for(var p=sA(e,h),q=p.indexOf("\n\n");-1!==q;){var r;a:{var u,t=p.substring(0,q).split("\n"),v="undefined"!=typeof Symbol&&Symbol.iterator&&t[Symbol.iterator];u=v?v.call(t):{next:da(t)};var w=u.next().value,x=u.next().value;if(w.startsWith("event: message")&&x.startsWith("data: "))try{r=JSON.parse(x.substring(x.indexOf(":")+1));break a}catch(H){}r=void 0}var y=r;if(y){var A=y.send_pixel||[];if(Array.isArray(A))for(var B=0;B<A.length;B++)dc(A[B]);
if(U(66)){var C=y.send_beacon||[];if(Array.isArray(C))for(var D=0;D<C.length;D++)kc(C[D])}}p=p.substring(q+2);q=p.indexOf("\n\n")}e=p}};c.open(d,l);c.send(b)};
var yA=function(a,b,c,d){var e=a+"?"+b;wA&&(d=!(0===e.indexOf(gA())||0===e.indexOf(fA())));d&&!vz?vA(e,c):xA(a,b,c)},zA=function(a){},
AA=function(a,b){function c(u){q.push(u+"="+encodeURIComponent(""+a.Ba[u]))}var d=b.il,e=b.jl,f=b.qk,g=b.Oj,h=b.Nj,l=b.wk,n=b.kl,p=b.vk;if(d||e||n){var q=[];c("tid");c("cid");c("gtm");q.push("aip=1");a.Sb.uid&&!p&&q.push("uid="+encodeURIComponent(""+a.Sb.uid));d&&(xA("https://stats.g.doubleclick.net/g/collect","v=2&"+q.join("&")),ij("https://stats.g.doubleclick.net/g/collect?v=2&"+
q.join("&")));if(e){q.push("z="+Ka());if(!l){var r=f&&0===f.indexOf("google.")&&"google.com"!=f?"https://www.%/ads/ga-audiences?v=1&t=sr&slf_rd=1&_r=4&".replace("%",f):void 0;r&&dc(r+q.join("&"))}U(28)&&g&&h&&ep()&&function(){var u=gp()+"/td/ga/rul?";q=[];c("tid");q.push("gacid="+encodeURIComponent(String(a.Ba.cid)));c("gtm");q.push("aip=1");q.push("fledge=1");q.push("z="+Ka());fp(u+q.join("&"),a.Ba.tid)}()}n&&zA(a)}},wA=!1;var BA=function(){this.F=1;this.N={};this.h=new qf;this.B=-1};BA.prototype.D=function(a,b){var c=this,d;d=new qA(a,this.N,b);var e=wz(a);e&&this.h.F(d)||this.flush();if(e&&this.h.add(d)){if(0>this.B){var f=z.setTimeout,g;rz(a)?CA?(CA=!1,g=DA):g=EA:g=5E3;this.B=f.call(z,function(){return c.flush()},g)}}else{var h=sf(d,this.F++);yA(d.h,h.lg,h.body,d.F);var l=a.metadata.create_dc_join,n=a.metadata.create_google_join,p=!1!==T(a.s,S.g.Ea),
q=!1!==T(a.s,S.g.da),r={eventId:a.s.eventId,priorityId:a.s.priorityId},u={il:l,jl:n,qk:String(po(a,S.g.Rc,T(a.s,S.g.Rc))),Oj:p,Nj:q,wk:qz(a),vk:a.metadata.euid_mode_enabled,Kl:r};AA(d,u)}if(U(70)){var t=Dq(dq.I.Bh,We.tb,a.s.eventId,void 0,a.eventName);Eq(t)&&Fq(t)}};BA.prototype.add=function(a){a.metadata.euid_mode_enabled&&!vz?this.U(a):
this.D(a)};BA.prototype.flush=function(){if(this.h.events.length){var a=tf(this.h,this.F++);yA(this.h.h,a.lg,a.body,this.h.B);this.h=new qf;0<=this.B&&(z.clearTimeout(this.B),this.B=-1)}};BA.prototype.U=function(a){var b=this,c=sz(a);c?Ng(c,function(d){b.D(a,1===d.split("~").length?void 0:d)}):this.D(a)};var xA=function(a,b,c){var d=a+"?"+b;if(c)try{Ub.sendBeacon&&Ub.sendBeacon(d,c)}catch(e){vb("TAGGING",15)}else kc(d)},DA=Yk('',500),EA=Yk('',
5E3),CA=!0;var FA=window,GA=document,HA=function(a){var b=FA._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a&&!0===FA["ga-disable-"+a])return!0;try{var c=FA.external;if(c&&c._gaUserPrefs&&"oo"==c._gaUserPrefs)return!0}catch(f){}for(var d=tj("AMP_TOKEN",String(GA.cookie),!0),e=0;e<d.length;e++)if("$OPT_OUT"==d[e])return!0;return GA.getElementById("__gaOptOutExtension")?!0:!1};
var IA=function(a,b,c){c||(c=function(){});void 0!==a.C[b]&&(a.C[b]=c(a.C[b]))},JA=function(a,b){var c=S.g.K;nj(c)||qj(function(){b.metadata.is_consent_update=!0;b.metadata.consent_update_type=c;if(U(65)){var d=$g[c||""];d&&uz(b,"gcut",d)}a.Th(b)},c)},KA=function(a,b,c){void 0===c&&(c={});if("object"===typeof b)for(var d in b)KA(a+"."+d,b[d],c);else c[a]=b;return c},LA=!1;var mn={bk:"",wl:Number("")},MA={},NA=(MA[S.g.Qd]=!0,MA[S.g.Rd]=!0,MA[S.g.Sd]=!0,MA[S.g.Td]=!0,MA[S.g.Ud]=!0,MA[S.g.Vd]=!0,MA),OA=function(a){this.U=a;this.fb=new BA;this.h=void 0;this.F=new Cz;this.B=this.D=void 0;this.N=!1;this.Yc=void 0;this.Ec=!1};ba=OA.prototype;ba.Rk=function(a,b,c){var d=this,e=Yn(this.U);
if(e)if(c.eventMetadata.is_external_event&&"_"===a.charAt(0))c.Z();else{a!==S.g.Da&&a!==S.g.Ja&&zz(a)&&O(58);PA(c.h);var f=new no(e,a,c);f.metadata.event_start_timestamp_ms=b;var g=[S.g.W];(po(f,S.g.kb,T(f.s,S.g.kb))||rz(f))&&g.push(S.g.K);var h=function(){rj(function(){d.Sk(f)},g)};U(11)&&U(25)?nn(h):h()}else c.Z()};ba.Sk=function(a){this.B=a;try{HA(a.target.X)&&(O(28),a.M=!0);if(0<=mn.bk.replace(/\s+/g,"").split(",").indexOf(a.eventName))a.M=!0;else{var b=tz(a);b&&b.blacklisted&&(a.M=!0)}var c=
I.location.protocol;"http:"!=c&&"https:"!=c&&(O(29),a.M=!0);Ub&&"preview"==Ub.loadPurpose&&(O(30),a.M=!0);var d=dh.grl;d||(d=rA(),dh.grl=d);d()||(O(35),a.M=!0);if(a.M){a.s.Z();wb();return}var e={prefix:String(T(a.s,S.g.ib,"")),path:String(T(a.s,S.g.Ye,"/")),flags:String(T(a.s,S.g.wb,"")),domain:String(T(a.s,S.g.vb,"auto")),Cb:Number(T(a.s,S.g.Ra,63072E3))};a.metadata.cookie_options=e;QA(a);this.zj(a);this.F.sl(a);a.metadata.is_merchant_center||T(a.s,S.g.lf)?a.metadata.euid_mode_enabled=!1:a.metadata.euid_mode_enabled=
Gi(Ei(a.s));if(a.metadata.euid_mode_enabled){var f=Ei(a.s);if(Gi(f)){var g=T(a.s,S.g.oa);if(void 0!==g)a.metadata.user_data=g,a.C._udm="c";else{var h=Hi(f);a.metadata.user_data=h;if("selectors"===f.mode||Dc(f.selectors))a.C._udm="s";else if("auto_detect"===f.mode||Dc(f.auto_detect))a.C._udm="a"}}}var l=this.ri,n;T(a.s,S.g.zb)&&(nj(S.g.W)||T(a.s,S.g.ub)||(a.C[S.g.Gh]=!0));var p;var q;q=void 0===q?3:q;var r=z.location.href;if(r){var u=ki(r).search.replace("?",""),t=fi(u,"_gl",!1,!0)||"";p=t?void 0!==
lk(t,q):!1}else p=!1;p&&rz(a)&&(U(65)?uz(a,"glv",1):a.C[S.g.Cf]=!0);a.eventName===S.g.Da?(T(a.s,S.g.zb)&&Nn(["aw","dc"]),Xz(a),n=Zz(a)):n={};l.call(this,n);a.eventName==S.g.Da&&(T(a.s,S.g.La,!0)?(a.s.h[S.g.fa]&&(a.s.B[S.g.fa]=a.s.h[S.g.fa],a.s.h[S.g.fa]=void 0,a.C[S.g.fa]=void 0),a.eventName=S.g.Jc):a.M=!0);var v=db(Lo(a.s,S.g.fa,1),".");v&&(a.C[S.g.cc]=v);var w=db(Lo(a.s,S.g.fa,2),".");w&&(a.C[S.g.bc]=w);var x=this.D,y=this.F,A=!this.Ec,B=this.h,C=T(a.s,S.g.ub),D=C?1:8;a.metadata.is_new_to_site=
!1;C||(C=Hz(a),D=3);C||(C=B,D=5);if(!C){var H=nj(S.g.W),G=Dz();C=!G.from_cookie||H?G.vid:void 0;D=6}C?C=""+C:(C=Mj(),D=7,a.metadata.is_first_visit=a.metadata.is_new_to_site=!0);Gz(a,C,D);var N=Math.floor(a.metadata.event_start_timestamp_ms/1E3),Q=void 0;a.metadata.is_new_to_site||(Q=Rz(a)||x);var Z=Oa(T(a.s,S.g.Uc,30));Z=Math.min(475,Z);Z=Math.max(5,Z);var oa=Oa(T(a.s,S.g.nf,1E4)),P=Lz(Q);a.metadata.is_first_visit=!1;a.metadata.is_session_start=!1;a.metadata.join_timer_sec=0;P&&P.dg&&(a.metadata.join_timer_sec=
Math.max(0,P.dg-Math.max(0,N-P.rd)));var R=!1;P||(R=a.metadata.is_first_visit=!0,P={sessionId:String(N),Rb:1,xc:!1,rd:N,Pb:!1,fd:void 0});N>P.rd+60*Z&&(R=!0,P.sessionId=String(N),P.Rb++,P.xc=!1,P.fd=void 0);if(R)a.metadata.is_session_start=!0,y.rk(a);else if(y.nk()>oa||a.eventName==S.g.Jc)P.xc=!0;a.metadata.euid_mode_enabled?T(a.s,S.g.Aa)?P.Pb=!0:(P.Pb&&(P.fd=void 0),P.Pb=!1):P.Pb=!1;var ka=P.fd;if(a.metadata.euid_mode_enabled){var ca=T(a.s,S.g.Pc),aa=ca?1:8;ca||(ca=ka,aa=4);ca||(ca=Lj(),aa=7);var Fa=
aa,Va=a.metadata.enhanced_client_id_source;if(void 0===Va||Fa<=Va)a.C[S.g.Pc]=ca.toString(),a.metadata.enhanced_client_id_source=Fa}A?(oo(a,S.g.yb,P.sessionId),oo(a,S.g.me,P.Rb),oo(a,S.g.ke,P.xc?1:0)):(a.C[S.g.yb]=P.sessionId,a.C[S.g.me]=P.Rb,a.C[S.g.ke]=P.xc?1:0);a.metadata[S.g.cf]=P.Pb?1:0;RA(a);var Ha="",Ja=I.location;if(Ja){var $a=Ja.pathname||"";"/"!=$a.charAt(0)&&($a="/"+$a);Ha=Ja.protocol+"//"+Ja.hostname+$a+Ja.search}oo(a,S.g.Ta,Ha);var Jd=S.g.Ua,xc;a:{var Ee=zj("_opt_expid",void 0,void 0,
S.g.W)[0];if(Ee){var Xs=decodeURIComponent(Ee).split("$");if(3===Xs.length){xc=Xs[2];break a}}if(void 0!==dh.ga4_referrer_override)xc=dh.ga4_referrer_override;else{var Ys=Dh("gtm.gtagReferrer."+a.target.X);xc=Ys?""+Ys:I.referrer}}oo(a,Jd,xc||void 0);oo(a,S.g.ic,I.title);oo(a,S.g.Sa,(Ub.language||"").toLowerCase());var Zs=Uh();oo(a,S.g.Lb,Zs.width+"x"+Zs.height);a.metadata.create_dc_join=!1;a.metadata.create_google_join=!1;if(!(U(66)&&rz(a)||a.metadata.is_merchant_center||!1===T(a.s,S.g.Gb))&&aA()&&
nj(S.g.K)){var Gh=po(a,S.g.kb,T(a.s,S.g.kb));if(a.metadata.is_session_start||T(a.s,S.g.ff)){a.metadata.create_dc_join=!!Gh;}var $s;$s=a.metadata.join_timer_sec;Gh&&0===($s||0)&&(a.metadata.join_timer_sec=
60,a.metadata.create_google_join=!0)}SA(a);Ug.hasOwnProperty(a.eventName)&&(a.metadata.is_ecommerce=!0,oo(a,S.g.ia),oo(a,S.g.va));oo(a,S.g.pf);for(var at=T(a.s,S.g.hf)||[],kl=0;kl<at.length;kl++){var bt=at[kl];if(bt.rule_result){oo(a,S.g.pf,bt.traffic_type);xz(3);break}}if(!a.metadata.is_merchant_center&&T(a.s,S.g.za)){var ct=Tz(a)||{},kD=(tk(ct[S.g.fc],!!ct[S.g.V])?kk(!0)._fplc:void 0)||(0<zj("FPLC",void 0,void 0,S.g.W).length?void 0:"0");a.C._fplc=kD}if(void 0!==T(a.s,S.g.he))oo(a,S.g.he);else{var dt=
T(a.s,S.g.je),ll,Hh;a:{if(Wz){var ml=Tz(a)||{};if(ml&&ml[S.g.V])for(var et=ii(ki(a.C[S.g.Ua]),"host",!0),Ih=ml[S.g.V],Lf=0;Lf<Ih.length;Lf++)if(Ih[Lf]instanceof RegExp){if(Ih[Lf].test(et)){Hh=!0;break a}}else if(0<=et.indexOf(Ih[Lf])){Hh=!0;break a}}Hh=!1}if(!(ll=Hh)){var Jh;if(Jh=dt)a:{for(var ft=dt.include_conditions||[],lD=ii(ki(a.C[S.g.Ua]),"host",!0),nl=0;nl<ft.length;nl++)if(ft[nl].test(lD)){Jh=!0;break a}Jh=!1}ll=Jh}ll&&(a.C[S.g.he]="1",xz(4))}rz(a)&&(kr()||(U(65)?uz(a,"uc",Mi.Ae):a.C._uc=
Mi.Ae),bj()&&(U(65)?uz(a,"rnd",Kk()):a.C._rnd=Kk()));if(U(66)&&U(65)&&rz(a)){po(a,S.g.kb,!1)&&uz(a,"gse",1);!1===T(a.s,S.g.Gb)&&uz(a,"ngs",1);qz(a)&&uz(a,"ga_rd",1);aA()||uz(a,"ngst",1);var gt=po(a,S.g.Rc);gt&&uz(a,"etld",gt);var ht=jA?iA:"";ht&&uz(a,"gcsub",ht)}U(65)&&rz(a)&&bj()&&(cj()&&uz(a,"gcd","G1"+jj($i)),T(a.s,S.g.na)&&uz(a,"adr",1));if(U(65)&&rz(a)){var it=up();it&&uz(a,"us_privacy",it);var jt=Vl();jt&&uz(a,"gdpr",jt);var kt=Ul();kt&&uz(a,"gdpr_consent",kt)}a:if(U(11))if(U(25)&&(a.C[S.g.qh]=
"1"),!hn(z))O(87);else if(void 0!==kn){O(85);var lt=fn();if(lt){if(U(59)){if(T(a.s,S.g.Tc)&&!rz(a))break a}else if(T(a.s,S.g.Tc))break a;on(lt,a)}else O(86)}U(61)&&T(a.s,S.g.ie)&&xz(12);if(a.eventName==S.g.Ja){var mt=T(a.s,S.g.jb),mD=T(a.s,S.g.xb),nt=void 0;nt=a.C[mt];mD(nt||T(a.s,mt));a.M=!0}if(!U(26)&&!a.s.eventMetadata.syn_or_mod){var ol=T(a.s,S.g.Ze);if(ol){var Kd=K(a.s.h);K(a.C,Kd);for(var ot=ol.edit_rules||[],pt=!1,pl=0;pl<ot.length;pl++){var Kh;a:{var Lh=a,Ld=ot[pl];if(uy(Lh.eventName,Kd,Ld.event_name_predicate,
Ld.conditions||[])){if(Ld.new_event_name){var qt=k(Ld.new_event_name)?String(Ld.new_event_name):qy(Lh.eventName,Kd,Ld.new_event_name);if(zz(qt)){Kh=!1;break a}Lh.eventName=String(qt)}Az(Lh.eventName,Kd,Ld);xz(2);Kh=!0}else Kh=!1}Kh&&(pt=!0)}for(var rt=ol.synthesis_rules||[],ql=0;ql<rt.length;ql++){var rl=a,Mf=rt[ql];if(uy(rl.eventName,Kd,Mf.event_name_predicate,Mf.conditions||[])){var sl=Mf.new_event_name;if(!zz(sl)){var st=Mf.merge_source_event_params?K(Kd):{};Az(sl,st,Mf);var tt={},tl={eventMetadata:(tt.syn_or_mod=
!0,tt)};tl.eventMetadata.event_usage=[11];ry&&tl.eventMetadata.event_usage.push(10);var nD=ls(rl.target.X,sl,st);os(nD,rl.s.eventId,tl);xz(1)}}}if(pt){for(var ul={},ut={eventMetadata:(ul.syn_or_mod=!0,ul.is_external_event=!!a.s.eventMetadata.is_external_event,ul)},vt,vl=[],wt=ub.GA4_EVENT||[],Mh=0;Mh<wt.length;Mh++)wt[Mh]&&vl.push(Mh);(vt=0<vl.length?vl:void 0)&&(ut.eventMetadata.event_usage=vt);var oD=ls(a.target.X,a.eventName,Kd);os(oD,a.s.eventId,ut);a.M=!0}}}so(a);TA(a);var wl=a.metadata.event_usage;
if(Ga(wl))for(var xl=0;xl<wl.length;xl++)xz(wl[xl]);var xt=xb("GA4_EVENT");xt&&(a.C._eu=xt);oo(a,S.g.Aa);oo(a,S.g.Ma);if(a.metadata.speculative||a.M){a.s.Z();wb();return}var qD=this.ri,yt,rD=this.h,yl;a:{var zl=Sz(a);if(zl){if(Qz(zl,a)){yl=zl;break a}O(25);a.M=!0}yl=void 0}var sD=yl;yt={clientId:Kz(a,rD),yi:sD};qD.call(this,yt);this.Ec=!0;this.pl(a);if(rz(a)){var tD=a.metadata.is_conversion;("page_view"===a.eventName||tD)&&JA(this,a)}this.F.rg();this.Yc=UA(a,this.Yc);T(a.s,S.g.Tc)&&(a.C[S.g.Tc]=!0,
IA(a,S.g.Lb));oo(a,S.g.Zg);if(a.M){a.s.Z();wb();return}this.Th(a);a.s.aa()}catch(pE){a.s.Z()}wb()};ba.Th=function(a){this.fb.add(a)};ba.ri=function(a){var b=a.clientId,c=a.yi;b&&c&&(this.h=b,this.D=c)};ba.flush=function(){this.fb.flush()};ba.pl=function(a){var b=this;if(!this.N){var c=nj(S.g.W);pj([S.g.W],function(){var d=nj(S.g.W);if(c^d&&b.B&&b.D&&b.h){var e=b.h;if(d){var f=Hz(b.B);if(f){b.h=f;var g=Rz(b.B);g&&(b.D=Nz(g,b.D,b.B))}else Jz(b.h,b.B),Fz(b.h,!0);Qz(b.D,b.B);
var h={};h[S.g.ff]=e;var l=ls(b.U,S.g.Ue,h);os(l,a.s.eventId,{});}else{b.D=void 0;b.h=void 0;z.gaGlobal={};}c=d}});this.N=!0}};ba.zj=function(a){a.eventName!==S.g.Ja&&this.F.yj(a)};var TA=function(a){if(U(23)&&rz(a)){var b=function(d){var e=KA(S.g.oa,d);m(e,function(f,g){a.C[f]=g})},c=T(a.s,S.g.oa);void 0!==c?b(c):b(a.metadata.user_data);a.metadata.user_data=
void 0}},QA=function(a){function b(c,d){Qg[c]||void 0===d||(a.C[c]=d)}m(a.s.B,b);m(a.s.h,b)},RA=function(a){var b=Mo(a.s),c=function(d,e){NA[d]&&(a.C[d]=e)};Dc(b[S.g.Kc])?m(b[S.g.Kc],function(d,e){c((S.g.Kc+"_"+d).toLowerCase(),e)}):m(b,c)},SA=function(a){var b=function(c){return!!c&&c.conversion};a.metadata.is_conversion=b(tz(a));a.metadata.is_first_visit&&(a.metadata.is_first_visit_conversion=b(tz(a,"first_visit")));a.metadata.is_session_start&&(a.metadata.is_session_start_conversion=b(tz(a,"session_start")))},
UA=function(a,b){var c=void 0;return c};
function PA(a){m(a,function(c){"_"===c.charAt(0)&&delete a[c]});var b=a[S.g.Ma]||{};m(b,function(c){"_"===c.charAt(0)&&delete b[c]})};var VA=function(a){if("prerender"==I.visibilityState)return!1;a();return!0},WA=function(a){if(!VA(a)){var b=!1,c=function(){!b&&VA(a)&&(b=!0,fc(I,"visibilitychange",c),O(55))};ec(I,"visibilitychange",c);O(54)}};var YA=function(a,b){WA(function(){var c=Yn(a);if(c){var d=XA(c,b);Ms.register(a,d)}});};function XA(a,b){var c=function(){};var d=new OA(a.id),e="MC"===a.prefix;c=function(f,g,h,l){e&&(l.eventMetadata.is_merchant_center=!0);d.Rk(g,h,l)};ZA(a,d,b);return c}
function ZA(a,b,c){var d=b.F,e={},f={eventId:c,eventMetadata:(e.batch_on_navigation=!0,e)};d.Wk(function(){vz=!0;Ms.flush();1E3<=d.Ee()&&Ub.sendBeacon&&Ns(S.g.Ue,{},a.id,f);b.flush();d.ui(function(){vz=!1;d.ui()})});};var wC=XA;function yC(a,b,c,d){L(F(this),["destinationIds:!*","eventName:!*","eventParameters:?DustMap","messageContext:?DustMap"],arguments);var e=c?Fc(c):{},f=Fc(a);Array.isArray(f)||(f=[f]);b=String(b);var g=d?Fc(d):{},h=this.h.h;g.originatingEntity=Ny(h);for(var l=0;l<f.length;l++){var n=f[l];if("string"===typeof n){var p=K(e),
q=K(g),r=ls(n,b,p);os(r,g.eventId||h.eventId,q)}}}yC.P="internal.sendGtagEvent";function zC(a,b,c){}zC.R="sendPixel";function AC(a,b,c,d){var e=this;d=void 0===d?!0:d;var f=!1;return f}AC.R="setCookie";function BC(a){L(F(this),["consentSettings:!DustMap"],arguments);for(var b=a.Nb(),c=b.length(),d=0;d<c;d++){var e=b.get(d);e===S.g.Qe||U(17)&&e===S.g.Re||M(this,"access_consent",e,"write")}var f=this.h.h,g=f.eventId,h=Oy(f),l=is("consent","default",Fc(a));os(l,g,h)}BC.R="setDefaultConsentState";function CC(a,b,c){return!1}CC.R="setInWindow";function DC(a,b,c){L(F(this),["targetId:!string","name:!string","value:!*"],arguments);var d=Th(a)||{};d[b]=Fc(c,this.h);var e=a;Rh||Sh();Qh[e]=d;}DC.P="internal.setProductSettingsParameter";function EC(a,b,c){L(F(this),["targetId:!string","name:!string","value:!*"],arguments);for(var d=b.split("."),e=Ss(Ms,a).h,f=0;f<d.length-1;f++){if(void 0===e[d[f]])e[d[f]]={};else if(!Dc(e[d[f]]))throw Error("setRemoteConfigParameter failed, path contains a non-object type: "+d[f]);e=e[d[f]]}e[d[f]]=Fc(c,this.h);}EC.P="internal.setRemoteConfigParameter";function FC(a,b,c,d){var e=this;}FC.R="sha256";function GC(a,b,c){}
GC.P="internal.sortRemoteConfigParameters";var HC={},IC={};HC.R="templateStorage";HC.getItem=function(a){var b=null;M(this,"access_template_storage");var c=this.h.h;if(!c)throw Error("invalid program state");var d=c.ld();IC[d]&&(b=IC[d].hasOwnProperty("gtm."+a)?IC[d]["gtm."+a]:null);return b};
HC.setItem=function(a,b){M(this,"access_template_storage");var c=this.h.h;if(!c)throw Error("invalid program state");var d=c.ld();IC[d]=IC[d]||{};IC[d]["gtm."+a]=b;};
HC.removeItem=function(a){M(this,"access_template_storage");var b=this.h.h;if(!b)throw Error("invalid program state");var c=b.ld();if(!IC[c]||!IC[c].hasOwnProperty("gtm."+a))return;delete IC[c]["gtm."+a];};HC.clear=function(){M(this,"access_template_storage");var a=this.h.h;if(!a)throw Error("invalid program state");delete IC[a.ld()];};var JC=function(a){var b;return b};function KC(a){L(F(this),["consentSettings:!DustMap"],arguments);var b=Fc(a),c;for(c in b)b.hasOwnProperty(c)&&M(this,"access_consent",c,"write");var d=this.h.h;os(is("consent","update",b),d.eventId,Oy(d))}KC.R="updateConsentState";var LC=function(){var a=new kg,b=function(d){var e=d.P;if(a.B.hasOwnProperty(e))throw"Attempting to add a private function which already exists: "+e+".";if(a.h.hasOwnProperty(e))throw"Attempting to add a private function with an existing API name: "+e+".";a.B[e]=Da(d)?Jf(e,d):Kf(e,d)},c=function(d){return a.add(d.R,d)};c(Zv);c(ew);c(Rw);c(Uw);c(Vw);c(Zw);c($w);c(bx);c(Zy());c(cx);c(zy);c(Gy);c(Hy);c(Iy);c(Ly);c(Qy);c(Ry);c(Uy);c(Yy);c(ez);c(fz);c(hz);c(iz);c(jz);c(zC);c(AC);c(BC);c(CC);c(FC);c(HC);
c(KC);a.add("Math",Rf());a.add("Object",ig);a.add("TestHelper",mg());a.add("assertApi",Nf);a.add("assertThat",Of);a.add("decodeUri",Sf);a.add("decodeUriComponent",Tf);a.add("encodeUri",Uf);a.add("encodeUriComponent",Vf);a.add("fail",Wf);a.add("generateRandom",Xf);a.add("getContainerVersion",Yf);a.add("getTimestamp",Zf);a.add("getTimestampMillis",Zf);a.add("getType",$f);a.add("makeInteger",bg);a.add("makeNumber",cg);a.add("makeString",dg);a.add("makeTableMap",eg);a.add("mock",hg);a.add("fromBase64",
yy,!("atob"in z));a.add("localStorage",az,!$y());a.add("toBase64",JC,!("btoa"in z));b(bw);b(uw);b(Bw);b(Gw);b(Pw);b(Sw);b(Xw);b(ax);b(nx);b(sx);b(xx);b(Gx);b(Kx);b(Vx);b(hy);b(iy);b(oy);b(Ay);b(By);b(Ey);b(Fy);b(Jy);b(Ky);b(Xy);b(cz);b(gz);b(kz);b(mz);b(nz);b(yC);b(DC);b(EC);b(GC);
return function(d){var e;if(a.h.hasOwnProperty(d))e=a.get(d,this);else{var f;if(f=a.B.hasOwnProperty(d)){var g=!1,h=this.h.h;if(h){var l=h.ld();if(l){0!==l.indexOf("__cvt_")&&(g=!0);}}f=
g}if(f){var n=a.B.hasOwnProperty(d)?a.B[d]:void 0;e=n}else throw Error(d+" is not a valid API name.");}return e}};var MC=function(){return!1},NC=function(){var a={};return function(b,c,d){}};var OC;
function PC(){var a=OC;return function(b,c,d){var e=d&&d.event;QC(c);var f=new jb;m(c,function(q,r){var u=Ec(r);void 0===u&&void 0!==r&&O(44);f.set(q,u)});a.h.h.F=Oe();var g={Rj:af(b),eventId:void 0!==e?e.id:void 0,priorityId:void 0!==e?e.priorityId:void 0,we:void 0!==e?function(q){return e.Bb.we(q)}:void 0,ld:function(){return b},log:function(){},dk:{index:d&&d.index,type:d&&d.type,name:d&&d.name}};if(MC()){var h=NC(),l=void 0,n=void 0;g.Pa={wg:[],cd:{},Za:function(q,r,u){1===r&&(l=q);7===r&&(n=
u);h(q,r,u)},gg:fg()};g.log=function(q,r){if(l){var u=Array.prototype.slice.call(arguments,1);h(l,4,{level:q,source:n,message:u})}}}var p=Wd(a,g,[b,f]);a.h.h.F=void 0;p instanceof ra&&"return"===p.h&&(p=p.B);return Fc(p)}}function QC(a){var b=a.gtmOnSuccess,c=a.gtmOnFailure;Da(b)&&(a.gtmOnSuccess=function(){J(b)});Da(c)&&(a.gtmOnFailure=function(){J(c)})}
function RC(){OC.h.h.N=function(a,b,c){dh.SANDBOXED_JS_SEMAPHORE=dh.SANDBOXED_JS_SEMAPHORE||0;dh.SANDBOXED_JS_SEMAPHORE++;try{return a.apply(b,c)}finally{dh.SANDBOXED_JS_SEMAPHORE--}}}function SC(a){void 0!==a&&m(a,function(b,c){for(var d=0;d<c.length;d++){var e=c[d].replace(/^_*/,"");vh[e]=vh[e]||[];vh[e].push(b)}})};var TC=encodeURI,X=encodeURIComponent,UC=function(a,b,c){dc(a,b,c)},VC=function(a,b){if(!a)return!1;var c=ii(ki(a),"host");if(!c)return!1;for(var d=0;b&&d<b.length;d++){var e=b[d]&&b[d].toLowerCase();if(e){var f=c.length-e.length;0<f&&"."!=e.charAt(0)&&(f--,e="."+e);if(0<=f&&c.indexOf(e,f)==f)return!0}}return!1},WC=function(a,b,c){for(var d={},e=!1,f=0;a&&f<a.length;f++)a[f]&&a[f].hasOwnProperty(b)&&
a[f].hasOwnProperty(c)&&(d[a[f][b]]=a[f][c],e=!0);return e?d:null};var Y={m:{}};Y.m.access_template_storage=["google"],function(){(function(a){Y.__access_template_storage=a;Y.__access_template_storage.o="access_template_storage";Y.__access_template_storage.isVendorTemplate=!0;Y.__access_template_storage.priorityOverride=0;Y.__access_template_storage.isInfrastructure=!1})(function(){return{assert:function(){},ba:function(){return{}}}})}();
Y.m.c=["google"],function(){(function(a){Y.__c=a;Y.__c.o="c";Y.__c.isVendorTemplate=!0;Y.__c.priorityOverride=0;Y.__c.isInfrastructure=!1})(function(a){nv(a.vtp_value,"c",a.vtp_gtmEventId);return a.vtp_value})}();
Y.m.e=["google"],function(){(function(a){Y.__e=a;Y.__e.o="e";Y.__e.isVendorTemplate=!0;Y.__e.priorityOverride=0;Y.__e.isInfrastructure=!1})(function(a){return String(a.vtp_gtmCachedValues.event)})}();
Y.m.v=["google"],function(){(function(a){Y.__v=a;Y.__v.o="v";Y.__v.isVendorTemplate=!0;Y.__v.priorityOverride=0;Y.__v.isInfrastructure=!1})(function(a){var b=a.vtp_name;if(!b||!b.replace)return!1;var c=fv(b.replace(/\\\./g,"."),a.vtp_dataLayerVersion||1),d=void 0!==c?c:a.vtp_defaultValue;nv(d,"v",a.vtp_gtmEventId);return d})}();
Y.m.process_dom_events=["google"],function(){function a(b,c,d){return{targetType:c,eventName:d}}(function(b){Y.__process_dom_events=b;Y.__process_dom_events.o="process_dom_events";Y.__process_dom_events.isVendorTemplate=!0;Y.__process_dom_events.priorityOverride=0;Y.__process_dom_events.isInfrastructure=!1})(function(b){for(var c=b.vtp_targets||[],d=b.vtp_createPermissionError,e={},f=0;f<c.length;f++){var g=c[f];e[g.targetType]=e[g.targetType]||[];e[g.targetType].push(g.eventName)}return{assert:function(h,
l,n){if(!e[l])throw d(h,{},"Prohibited event target "+l+".");if(-1===e[l].indexOf(n))throw d(h,{},"Prohibited listener registration for DOM event "+n+".");},ba:a}})}();
Y.m.read_container_data=["google"],function(){(function(a){Y.__read_container_data=a;Y.__read_container_data.o="read_container_data";Y.__read_container_data.isVendorTemplate=!0;Y.__read_container_data.priorityOverride=0;Y.__read_container_data.isInfrastructure=!1})(function(){return{assert:function(){},ba:function(){return{}}}})}();
Y.m.listen_data_layer=["google"],function(){function a(b,c){return{eventName:c}}(function(b){Y.__listen_data_layer=b;Y.__listen_data_layer.o="listen_data_layer";Y.__listen_data_layer.isVendorTemplate=!0;Y.__listen_data_layer.priorityOverride=0;Y.__listen_data_layer.isInfrastructure=!1})(function(b){var c=b.vtp_accessType,d=b.vtp_allowedEvents||[],e=b.vtp_createPermissionError;return{assert:function(f,g){if(!k(g))throw e(f,{eventName:g},"Event name must be a string.");if(!("any"===c||"specific"===
c&&0<=d.indexOf(g)))throw e(f,{eventName:g},"Prohibited listen on data layer event.");},ba:a}})}();
Y.m.get_url=["google"],function(){function a(b,c,d){return{component:c,queryKey:d}}(function(b){Y.__get_url=b;Y.__get_url.o="get_url";Y.__get_url.isVendorTemplate=!0;Y.__get_url.priorityOverride=0;Y.__get_url.isInfrastructure=!1})(function(b){var c="any"===b.vtp_urlParts?null:[];c&&(b.vtp_protocol&&c.push("protocol"),b.vtp_host&&c.push("host"),b.vtp_port&&c.push("port"),b.vtp_path&&c.push("path"),b.vtp_extension&&c.push("extension"),b.vtp_query&&c.push("query"),b.vtp_fragment&&c.push("fragment"));
var d=c&&"any"!==b.vtp_queriesAllowed?b.vtp_queryKeys||[]:null,e=b.vtp_createPermissionError;return{assert:function(f,g,h){if(g){if(!k(g))throw e(f,{},"URL component must be a string.");if(c&&0>c.indexOf(g))throw e(f,{},"Prohibited URL component: "+g);if("query"===g&&d){if(!h)throw e(f,{},"Prohibited from getting entire URL query when query keys are specified.");if(!k(h))throw e(f,{},"Query key must be a string.");if(0>d.indexOf(h))throw e(f,{},"Prohibited query key: "+h);}}else if(c)throw e(f,{},
"Prohibited from getting entire URL when components are specified.");},ba:a}})}();
Y.m.read_dom_elements=["google"],function(){function a(b,c,d){return{type:c,value:d}}(function(b){Y.__read_dom_elements=b;Y.__read_dom_elements.o="read_dom_elements";Y.__read_dom_elements.isVendorTemplate=!0;Y.__read_dom_elements.priorityOverride=0;Y.__read_dom_elements.isInfrastructure=!1})(function(b){for(var c=b.vtp_selectors||[],d=b.vtp_createPermissionError,e=[],f=[],g=0;g<c.length;g++){var h=c[g];switch(h.type){case "id":e.push(h.value);break;case "css":f.push(h.value)}}return{assert:function(l,
n,p){switch(n){case "id":if(-1<e.indexOf(p))return;break;case "css":if(-1<f.indexOf(p))return;break;default:throw d(l,{},"Unknown selector type "+n+".");}throw d(l,{},"Prohibited selector value "+p+" for selector type "+n+".");},ba:a}})}();
Y.m.gct=["google"],function(){function a(d){for(var e=[],f=0;f<d.length;f++)try{e.push(new RegExp(d[f]))}catch(g){}return e}function b(d){return d.replace(/[.*+\-?^${}()|[\]\\]/g,"\\$&")}function c(d){for(var e=[],f=0;f<d.length;f++){var g=d[f].matchValue,h;switch(d[f].matchType){case "BEGINS_WITH":h="^"+b(g);break;case "ENDS_WITH":h=b(g)+"$";break;case "EQUALS":h="^"+b(g)+"$";break;case "REGEX":h=g;break;default:h=b(g)}e.push(h)}return e}(function(d){Y.__gct=d;Y.__gct.o="gct";Y.__gct.isVendorTemplate=
!0;Y.__gct.priorityOverride=0;Y.__gct.isInfrastructure=!1})(function(d){var e={},f=d.vtp_sessionDuration;0<f&&(e[S.g.Uc]=f);e[S.g.ae]=d.vtp_eventSettings;e[S.g.Ze]=d.vtp_dynamicEventSettings;e[S.g.kb]=1===d.vtp_googleSignals;e[S.g.Rc]=d.vtp_foreignTld;e[S.g.ef]=1===d.vtp_restrictDomain;e[S.g.hf]=d.vtp_internalTrafficResults;var g=S.g.ya,h=d.vtp_linker;h&&h[S.g.V]&&(h[S.g.V]=a(h[S.g.V]));e[g]=h;var l=S.g.je,n=d.vtp_referralExclusionDefinition;n&&n.include_conditions&&(n.include_conditions=a(n.include_conditions));
e[l]=n;var p=d.vtp_trackingId,q=Ss(Ms,p).h,r=q.referral_exclusion_conditions;r&&(r.length&&"object"===typeof r[0]&&(r=c(r)),e[S.g.je]={include_conditions:a(r)});var u=q.cross_domain_conditions;if(u){u.length&&"object"===typeof u[0]&&(u=c(u));var t={};e[S.g.ya]=(t[S.g.V]=a(u),t[S.g.Jb]=!0,t[S.g.fc]=!0,t[S.g.hc]="query",t)}Vs(p,e);YA(p,d.vtp_gtmEventId);J(d.vtp_gtmOnSuccess)})}();
Y.m.get=["google"],function(){(function(a){Y.__get=a;Y.__get.o="get";Y.__get.isVendorTemplate=!0;Y.__get.priorityOverride=0;Y.__get.isInfrastructure=!1})(function(a){var b=a.vtp_settings,c=b.eventParameters||{},d=String(a.vtp_eventName),e={};e.eventId=a.vtp_gtmEventId;e.priorityId=a.vtp_gtmPriorityId;a.vtp_deferrable&&(e.deferrable=!0);var f=ls(String(b.streamId),d,c);os(f,e.eventId,e);a.vtp_gtmOnSuccess()})}();
Y.m.access_dom_element_property=["google"],function(){function a(b,c,d,e){var f={property:e,read:!1,write:!1};switch(d){case "read":f.read=!0;break;case "write":f.write=!0;break;default:throw Error("Invalid "+b+" operation "+d);}return f}(function(b){Y.__access_dom_element_property=b;Y.__access_dom_element_property.o="access_dom_element_property";Y.__access_dom_element_property.isVendorTemplate=!0;Y.__access_dom_element_property.priorityOverride=0;Y.__access_dom_element_property.isInfrastructure=
!1})(function(b){for(var c=b.vtp_properties||[],d=b.vtp_createPermissionError,e=[],f=[],g=0;g<c.length;g++){var h=c[g],l=h.property;h.read&&e.push(l);h.write&&f.push(l)}return{assert:function(n,p,q,r){if(!k(r))throw d(n,{},"Property must be a string.");if("read"===q){if(-1<e.indexOf(r))return}else if("write"===q){if(-1<f.indexOf(r))return}else throw d(n,{},"Operation must be either 'read' or 'write', was "+q);throw d(n,{},"Prohibited "+q+" on "+p.tagName+" property "+r+".");},ba:a}})}();
var nE={};nE.dataLayer=Eh;nE.callback=function(a){uh.hasOwnProperty(a)&&Da(uh[a])&&uh[a]();delete uh[a]};nE.bootstrap=0;nE._spx=!1;
function oE(){dh[We.H]=dh[We.H]||nE;We.tb&&(dh["ctid_"+We.tb]=nE);Rk();Tk()||m(Uk(),function(a,b){nr(a,b.transportUrl,b.context);O(92)});Xa(vh,Y.m);De=Se}
(function(a){function b(){l=I.documentElement.getAttribute("data-tag-assistant-present");xu(l)&&(h=g.uj)}if(!z["__TAGGY_INSTALLED"]){var c=!1;if(I.referrer){var d=ki(I.referrer);c="cct.google"===hi(d,"host")}if(!c){var e=zj("googTaggyReferrer");c=e.length&&e[0].length}c&&(z["__TAGGY_INSTALLED"]=!0,ac("https://cct.google/taggy/agent.js"))}if(ph)a();else{var f=function(t){var v="GTM",w="GTM";jh?(v="OGT",w="GTAG"):ph&&(w=v="OPT");var x=z["google.tagmanager.debugui2.queue"];x||(x=[],
z["google.tagmanager.debugui2.queue"]=x,ac("https://"+ch.Jd+"/debug/bootstrap?id="+We.H+"&src="+w+"&cond="+t+"&gtm="+Xk()));var y={messageType:"CONTAINER_STARTING",data:{scriptSource:Vb,containerProduct:v,debug:!1,id:We.H,isGte:ih}};y.data.resume=function(){a()};ch.Ni&&(y.data.initialPublish=!0);x.push(y)},g={Bl:1,vj:2,Hj:3,Pi:4,uj:5},h=void 0,l=void 0,n=ii(z.location,"query",!1,void 0,"gtm_debug");xu(n)&&(h=g.vj);if(!h&&I.referrer){var p=ki(I.referrer);"tagassistant.google.com"===hi(p,"host")&&(h=g.Hj)}if(!h){var q=
zj("__TAG_ASSISTANT");q.length&&q[0].length&&(h=g.Pi)}h||b();if(!h&&U(54)&&yu(l)){var r=function(){if(u)return!0;u=!0;b();h&&Vb?f(h):a()},u=!1;ec(I,"TADebugSignal",function(){r()},!1);z.setTimeout(function(){r()},200)}else h&&Vb?f(h):a()}})(function(){var a=!1;a&&Kq("INIT");
if(U(70)){var b=Dq(dq.I.Dc,We.H);Eq(b)}Qi().B();Tl();if(We.tb?dh["ctid_"+We.tb]:dh[We.H]){var c=dh.zones;c&&c.unregisterChild(Nk());}else{(U(11)||U(13)||U(55)||U(48))&&ln();for(var d=data.resource||{},e=d.macros||[],f=0;f<e.length;f++)te.push(e[f]);for(var g=d.tags||[],h=0;h<g.length;h++)we.push(g[h]);for(var l=d.predicates||
[],n=0;n<l.length;n++)ve.push(l[n]);for(var p=d.rules||[],q=0;q<p.length;q++){for(var r=p[q],u={},t=0;t<r.length;t++)u[r[t][0]]=Array.prototype.slice.call(r[t],1);ue.push(u)}ye=Y;ze=Xv;$e=new Ze;var v=data.sandboxed_scripts,w=data.security_groups,x=data.infra,y=data.runtime||[],A=data.runtime_lines;OC=new Ud;RC();se=PC();var B=OC,C=LC();mb(B.h,"require",C);for(var D=0;D<y.length;D++){var H=y[D];if(!Ga(H)||3>H.length){if(0===H.length)continue;break}A&&A[D]&&A[D].length&&Le(H,A[D]);OC.execute(H)}if(void 0!==
v)for(var G=["sandboxedScripts"],N=0;N<v.length;N++){var Q=v[N].replace(/^_*/,"");vh[Q]=G}SC(w);if(void 0!==x)for(var Z=0;Z<x.length;Z++)wh[x[Z]]=!0;oE();wu();Cr=!1;Dr=0;if("interactive"==I.readyState&&!I.createEventObject||"complete"==I.readyState)Fr();else{ec(I,"DOMContentLoaded",Fr);ec(I,"readystatechange",Fr);if(I.createEventObject&&I.documentElement.doScroll){var oa=!0;try{oa=!z.frameElement}catch(Va){}oa&&Gr()}ec(z,"load",Fr)}Lt=!1;"complete"===I.readyState?Nt():ec(z,"load",Nt);em&&z.setInterval(jm,864E5);U(46)&&(O(111),vb("HEALTH",1));U(47)&&(O(112),vb("HEALTH",2));th=
Ta();nE.bootstrap=th;if(a){var ca=Lq("INIT");}if(U(70)){var aa=Dq(dq.I.Cg,We.H);if(Eq(aa)){var Fa=Dq(dq.I.Dc,We.H);Fq(aa,Fa)}}}});
})();
/////////////////////////////
//GA calls for this site
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-P81QF1533Q');
/////////////////////////////
//end Google Analytics
/////////////////////////////