var AOI = ee.Geometry.Polygon([[[-69.684054437432, -9.632661764537458],[-69.684054437432, -22.907257849590575],
[-57.423312249931996, -22.907257849590575],[-57.423312249931996, -9.632661764537458]]], null, false);
var generalZoom = 6;
var currentZoom = 16;
function runApp() {
Map.drawingTools().setShown(false);                     //  oculta las geometrias
Map.setOptions('ROADMAP').setControlVisibility(false);  // ROADMAP SATELLITE HYBRID TERRAIN
var Moderado =  60; var Alto =      80;
var Muy_Alto =  90; var Extremo =   97;
var expSCALE = 463.31271652791656;
var scaleReduce = expSCALE*2
var palette = ['2c7bb6','abd9e9','ffffbf','fdae61','d7191c']
var hora = 14;    var foreDays = 4;   var timeZone= 'America/La_Paz';
var timeZoneDiff = ee.Date(Date.now()).difference(ee.Date(Date.now()).format({timeZone: timeZone}), 'hour').round().int();
var GFS = ee.ImageCollection("NOAA/GFS0P25").filter(ee.Filter.calendarRange(0, 0,'hour'))
var last = GFS.filterDate(ee.Date(Date.now()).advance(-2,'day'),ee.Date(Date.now())).filter(ee.Filter.calendarRange(0, 0,	'hour'))
.filter(ee.Filter.gte('forecast_hours', timeZoneDiff)).sort('system:time_start',false).first();
var start = last.date(); 
// var start = ee.Date('2024-10-25');   print('Datos mas recientes disponibles:', start);
var end = start.advance(foreDays,'day');
var inicio = start.format('dd-MM').getInfo(); var fin = end.format('dd-MM').getInfo();
var inis = start.format('dd-MM-YYYY').getInfo();
GFS = GFS.filterDate(start,end)
GFS = GFS.filter(ee.Filter.eq('forecast_hours', timeZoneDiff.add(24*0).add(hora)))
.merge(GFS.filter(ee.Filter.eq('forecast_hours', timeZoneDiff.add(24*1).add(hora))))
.merge(GFS.filter(ee.Filter.eq('forecast_hours', timeZoneDiff.add(24*2).add(hora))))
.merge(GFS.filter(ee.Filter.eq('forecast_hours', timeZoneDiff.add(24*3).add(hora))))
.merge(GFS.filter(ee.Filter.eq('forecast_hours', timeZoneDiff.add(24*4).add(hora))))
// .merge(GFS.filter(ee.Filter.eq('forecast_hours', timeZoneDiff.add(24*5).add(hora))))
// .merge(GFS.filter(ee.Filter.eq('forecast_hours', timeZoneDiff.add(24*6).add(hora))))
// .merge(GFS.filter(ee.Filter.eq('forecast_hours', timeZoneDiff.add(24*7).add(hora))))
// .merge(GFS.filter(ee.Filter.eq('forecast_hours', timeZoneDiff.add(24*8).add(hora))))
// .merge(GFS.filter(ee.Filter.eq('forecast_hours', timeZoneDiff.add(24*9).add(hora))))
var projection = last.select('temperature_2m_above_ground').projection()//.aside(print); 
var scale = 27799.73086213645//ee.Number(projection.nominalScale()); 
var expCRS = 'EPSG:4326'  //  'SR-ORG:6974';//ee.ImageCollection("MODIS/061/MCD64A1").select('BurnDate').first().projection();
var pais = ee.FeatureCollection('users/anmarkos/CLIM_D/Bolivia').select(['mun','prov','dep']);
Map.centerObject(pais);
var HDWI_HD_P = ee.Image('users/anmarkos/CLIM_D/HDWI_HD_P');
var ETo_air_HD_P = ee.Image('users/anmarkos/CLIM_D/ETo_air_HD_P');
// ETo_air_HD_P.select(0).projection().aside(print).nominalScale().aside(print)
var buffer = AOI.buffer(80000);
var maskAll = ee.Image(1).clip(buffer);     
var centroid = ee.Geometry.Point([-64.31523040831942,-16.128361473795064])
var maskIt = ee.Image('projects/mapbiomas-public/assets/bolivia/collection2/mapbiomas_bolivia_collection2_integration_v1').select('classification_2023').lt(22).selfMask();
var elevation = ee.ImageCollection("projects/sat-io/open-datasets/FABDEM").filterBounds(buffer).mosaic()//.projection().nominalScale()/*
.rename("elv").setDefaultProjection('EPSG:4326', null, 30.922080775909304).clip(buffer);
var coord = ee.Image.pixelLonLat().updateMask(elevation);
var ELE = elevation.reproject({crs:projection, scale:scale}).int(); var LAT = coord.select('latitude').reproject({crs:projection, scale:scale}).int(); var LON = coord.select('longitude').reproject({crs:projection, scale:scale}).int();
elevation = elevation.reproject({crs:expCRS, scale:expSCALE}).int().updateMask(maskIt);
coord = coord.reproject({crs:expCRS, scale:expSCALE});
var D = ee.Terrain.products(elevation);
var ELE_T = ELE.multiply(-0.004121948463699250);        var LAT_T = LAT.multiply(0.170558629354687000);                       var LON_T = LON.multiply(0.079010547342446000);
var ele_T = elevation.multiply(-0.004121948463699250);  var lat_T = coord.select('latitude').multiply(0.170558629354687000);  var lon_T = coord.select('longitude').multiply(0.079010547342446000);
var ELE_RH = ELE.multiply(-0.003862590889267020);       var LAT_RH = LAT.multiply(1.514125924952950000);
var ele_RH = elevation.multiply(-0.003862590889267020); var lat_RH = coord.select('latitude').multiply(1.514125924952950000);
var ELE_VV = ELE.multiply(0.000876855606877356);        var LAT_VV = LAT.multiply(-0.150969744192659000);                     var LON_VV = LON.multiply(0.074259811031676600);
var ele_VV = elevation.multiply(0.000876855606877356);  var lat_VV = coord.select('latitude').multiply(-0.15096974419265900); var lon_VV = coord.select('longitude').multiply(0.074259811031676600);
var ELE_S = ELE.multiply(0.010818178405197400);         var LAT_S = LAT.multiply(-2.284080380129950000);                      var LON_S = LON.multiply(0.244353077487023000);
var ele_S = elevation.multiply(0.010818178405197400);   var lat_S = coord.select('latitude').multiply(-2.284080380129950000); var lon_S = coord.select('longitude').multiply(0.244353077487023000);
var albedo = ee.Image(0.77).multiply(0.0036);
var slope = ee.Terrain.slope(elevation);
var aspect = ee.Terrain.aspect(elevation);
var Slope_Ratio = ((slope.multiply(Math.PI).divide(180)).tan());
var SpeedUp = Slope_Ratio.lte(0.2).add(Slope_Ratio.gt(0.2).multiply(Slope_Ratio.multiply(0.75).add(0.851667)));
var focalMax = elevation.focalMax({radius: 1000, kernelType: 'circle', units: 'meters'});
var focalMin = elevation.focalMin({radius: 1000, kernelType: 'circle', units: 'meters'});
var UD = ee.Image(1).clip(AOI).subtract(focalMax.subtract(elevation).divide(focalMax.subtract(focalMin)));
var upDown = ee.Image(0.5).add(UD.multiply(0.65));
var downUp = ee.Image(0.383).add(UD.multiply(0.767));
//////////////////////////////////    Functions    //////////////////////////////////
function addSunToImage(position,date){
var coordinates=position.coordinates();
var M=ee.Number.parse(date.format('MM'));
var Y=ee.Number.parse(date.format('YYYY'));
var DoY=ee.Number.parse(date.format('D'));
var hour=ee.Number.parse(date.format('H')).add(0.5);
var minutes=ee.Number.parse(date.format('m'));
var longitude=ee.Number(coordinates.get(0));
var lon=ee.Number(coordinates.get(0)).multiply(Math.PI/180);
var lat=ee.Number(coordinates.get(1)).multiply(Math.PI/180);
var y = ee.Number(2*Math.PI/365.25).multiply(DoY.subtract(1));
var E = ee.Number(229.18).multiply(ee.Number(0.000075)
.add(ee.Number(0.001868).multiply(y.cos()))
.subtract(ee.Number(0.032077).multiply(y.sin()))
.subtract(ee.Number(0.014615).multiply(y.multiply(2).cos()))
.subtract(ee.Number(0.040849).multiply(y.multiply(2).sin())));
var SolarTime=hour.multiply(60).add(minutes).add(longitude.multiply(4)).add(E);
var declin = ee.Number(0.006918)
.subtract(ee.Number(0.399912).multiply(y.cos()))
.add(ee.Number(0.070257).multiply(y.sin()))
.subtract(ee.Number(0.006758).multiply(y.multiply(2).cos()))
.add(ee.Number(0.000907).multiply(y.multiply(2).sin()))
.subtract(ee.Number(0.002697).multiply(y.multiply(3).cos()))
.add(ee.Number(0.00148).multiply(y.multiply(3).cos()));
var w = SolarTime.divide(4).subtract(180).multiply(Math.PI/180);
var Phi= (lat.sin().multiply(declin.sin())
.add(lat.cos().multiply(declin.cos()).multiply(w.cos()))).acos();
var Theta = (lat.sin().multiply(Phi.cos()).subtract(declin.sin()))
.divide(lat.cos().multiply(Phi.sin())).multiply(-1).acos().add(Math.PI*2).mod(Math.PI*2);
var noon = hour.gt(ee.Number(12).add(timeZoneDiff)).multiply(360);
Theta = (noon.subtract(Theta.multiply(180/Math.PI))).abs();
return ee.Algorithms.Dictionary(['Azimuth',Theta,'Zenith',Phi.multiply(180/Math.PI),
'declin',declin,'Phi',Phi,'w',w,'Theta',Theta,'year',Y,'month',M,'hour',hour])}
function addBands(x){
var air_temp = x.select('temperature_2m_above_ground').updateMask(maskAll).reproject({crs: projection, scale: scale}).rename('air_temp');
air_temp = air_temp.subtract(ELE_T).subtract(LAT_T).subtract(LON_T).updateMask(maskIt);
air_temp = air_temp.resample('bicubic').add(ele_T).add(lat_T).add(lon_T);
var Te = air_temp.subtract(ele_T) // Temperatura a nivel del mar
var G = ((Te.subtract(elevation.multiply(0.0065))).divide(Te)).pow(5.26).multiply(101.3).multiply(0.000665).rename('G');
var rel_hum = x.select('relative_humidity_2m_above_ground').updateMask(maskAll).reproject({crs: projection, scale: scale}).rename('rel_hum');
rel_hum = rel_hum.subtract(ELE_RH).subtract(LAT_RH).updateMask(maskIt);
rel_hum = rel_hum.resample('bicubic').add(ele_RH).add(lat_RH);
var u = x.select('u_component_of_wind_10m_above_ground').updateMask(maskAll).reproject({crs: projection, scale: scale}).rename('u');
var v = x.select('v_component_of_wind_10m_above_ground').updateMask(maskAll).reproject({crs: projection, scale: scale}).rename('v');
var WIND = ((u.pow(2).add(v.pow(2))).sqrt()).multiply(3.6).multiply(0.7944).rename('Wind_Speed_2m');
WIND = WIND.subtract(ELE_VV).subtract(LAT_VV).subtract(LON_VV).updateMask(maskIt);
WIND = WIND.resample('bicubic').add(ele_VV).add(lat_VV).add(lon_VV);
var sun = x.select('downward_shortwave_radiation_flux').updateMask(maskAll).reproject({crs: projection, scale: scale}).rename('sun');
sun = sun.subtract(ELE_S).subtract(LAT_S).subtract(LON_S).updateMask(maskIt);
sun = sun.resample('bicubic').add(ele_S).add(lat_S).add(lon_S);
sun = ee.Terrain.hillshade(elevation, x.get('Azimuth'), ee.Number(90).subtract(x.get('Zenith'))).divide(255).multiply(sun).rename('Incident_Radiation');
// doi:10.3390/s20051391
var Wind_Dir = ((v.atan2(u)).multiply(57.29577951)).add(180).resample('bicubic').updateMask(maskIt).rename('Wind_Dir');
var delta1 = (Wind_Dir.subtract(aspect)).abs().rename('Wind_Match');
var delta2 = ee.Image(360).subtract(delta1).rename('Wind_Match');
var diff = ee.Image(1).rename('Wind_Match').subtract(ee.ImageCollection([delta1, delta2]).min().divide(180));
var	Windward_Speed = WIND.multiply(upDown.updateMask(diff.gt(0.5))).add(WIND.multiply(SpeedUp.updateMask(diff.gt(0.5))));
var	Lee_Side_Speed = WIND.multiply(downUp.updateMask(diff.lte(0.5)));
var Wind_Speed = ee.ImageCollection([Windward_Speed,Lee_Side_Speed]).mosaic();
var U = Wind_Speed.multiply(0.621371192);
///////////////////////////////////////////////////   VPD air    ////////////////////////////////////////////////////////////////
var es = x.expression('0.61078*exp(17.27*T/(T+237.3))', {T: air_temp}).rename('es');
var ea = es.multiply(rel_hum.divide(100));
var VPD_air = (es.subtract(ea)).rename('VPD_air');
///////////////////////////////////////////////////   HDWI    ////////////////////////////////////////////////////////////////
// m/s for wind speed and hPa for VPD.
var vv = Wind_Speed.divide(3.6)
var HDWI = VPD_air.divide(10).multiply(vv).rename('HDWI');
///////////////////////////////////////////////////   ETo air    ////////////////////////////////////////////////////////////////
var Rn = sun.multiply(albedo).rename('Rn'); // Convert W to MJ
var D = (es.divide((air_temp.add(237.3)).pow(2))).multiply(4098).rename('D');
var AT = (ee.Image(37.5).divide(air_temp.add(273.15))).multiply(U.pow(2)).multiply(VPD_air).rename('AT');   //    (900/24)
var ETo_air = x.expression('((0.408*D*Rn)+(G*AT))/(D+G*(1+(0.34*U*U)))',
{AT: AT, D: D, G: G, Rn: Rn, T: air_temp, U: Wind_Speed}).rename('ETo_air');
return HDWI.addBands(ETo_air).set('system:time_start', x.get('forecast_time'))       //    Consume mucha memoria! Esto permite visualizar los datos horarios correctamente en un grafico
}
function classification(x){
var HDWI = // x.select('HDWI').gt(HDWI_HD_P.select('HDWI_p60')).add(x.select('HDWI').gt(HDWI_HD_P.select('HDWI_p80'))).add(x.select('HDWI').gt(HDWI_HD_P.select('HDWI_p90'))).add(x.select('HDWI').gt(HDWI_HD_P.select('HDWI_p97'))).rename('HDWI_P');
x.select('HDWI').gt(HDWI_HD_P.select(0)).add(x.select('HDWI').gt(HDWI_HD_P.select(1))).add(x.select('HDWI').gt(HDWI_HD_P.select(2))).add(x.select('HDWI').gt(HDWI_HD_P.select(3))).add(x.select('HDWI').gt(HDWI_HD_P.select(4))).add(x.select('HDWI').gt(HDWI_HD_P.select(5))).add(x.select('HDWI').gt(HDWI_HD_P.select(6))).add(x.select('HDWI').gt(HDWI_HD_P.select(7))).add(x.select('HDWI').gt(HDWI_HD_P.select(8))).add(x.select('HDWI').gt(HDWI_HD_P.select(9))).add(x.select('HDWI').gt(HDWI_HD_P.select(10)))
.add(x.select('HDWI').gt(HDWI_HD_P.select(11))).add(x.select('HDWI').gt(HDWI_HD_P.select(12))).add(x.select('HDWI').gt(HDWI_HD_P.select(13))).add(x.select('HDWI').gt(HDWI_HD_P.select(14))).add(x.select('HDWI').gt(HDWI_HD_P.select(15))).add(x.select('HDWI').gt(HDWI_HD_P.select(16))).add(x.select('HDWI').gt(HDWI_HD_P.select(17))).add(x.select('HDWI').gt(HDWI_HD_P.select(18))).add(x.select('HDWI').gt(HDWI_HD_P.select(19))).add(x.select('HDWI').gt(HDWI_HD_P.select(20)))
.add(x.select('HDWI').gt(HDWI_HD_P.select(21))).add(x.select('HDWI').gt(HDWI_HD_P.select(22))).add(x.select('HDWI').gt(HDWI_HD_P.select(23))).add(x.select('HDWI').gt(HDWI_HD_P.select(24))).add(x.select('HDWI').gt(HDWI_HD_P.select(25))).add(x.select('HDWI').gt(HDWI_HD_P.select(26))).add(x.select('HDWI').gt(HDWI_HD_P.select(27))).add(x.select('HDWI').gt(HDWI_HD_P.select(28))).add(x.select('HDWI').gt(HDWI_HD_P.select(29))).add(x.select('HDWI').gt(HDWI_HD_P.select(30)))
.add(x.select('HDWI').gt(HDWI_HD_P.select(31))).add(x.select('HDWI').gt(HDWI_HD_P.select(32))).add(x.select('HDWI').gt(HDWI_HD_P.select(33))).add(x.select('HDWI').gt(HDWI_HD_P.select(34))).add(x.select('HDWI').gt(HDWI_HD_P.select(35))).add(x.select('HDWI').gt(HDWI_HD_P.select(36))).add(x.select('HDWI').gt(HDWI_HD_P.select(37))).add(x.select('HDWI').gt(HDWI_HD_P.select(38))).add(x.select('HDWI').gt(HDWI_HD_P.select(39))).add(x.select('HDWI').gt(HDWI_HD_P.select(40)))
.add(x.select('HDWI').gt(HDWI_HD_P.select(41))).add(x.select('HDWI').gt(HDWI_HD_P.select(42))).add(x.select('HDWI').gt(HDWI_HD_P.select(43))).add(x.select('HDWI').gt(HDWI_HD_P.select(44))).add(x.select('HDWI').gt(HDWI_HD_P.select(45))).add(x.select('HDWI').gt(HDWI_HD_P.select(46))).add(x.select('HDWI').gt(HDWI_HD_P.select(47))).add(x.select('HDWI').gt(HDWI_HD_P.select(48))).add(x.select('HDWI').gt(HDWI_HD_P.select(49))).add(x.select('HDWI').gt(HDWI_HD_P.select(50)))
.add(x.select('HDWI').gt(HDWI_HD_P.select(51))).add(x.select('HDWI').gt(HDWI_HD_P.select(52))).add(x.select('HDWI').gt(HDWI_HD_P.select(53))).add(x.select('HDWI').gt(HDWI_HD_P.select(54))).add(x.select('HDWI').gt(HDWI_HD_P.select(55))).add(x.select('HDWI').gt(HDWI_HD_P.select(56))).add(x.select('HDWI').gt(HDWI_HD_P.select(57))).add(x.select('HDWI').gt(HDWI_HD_P.select(58))).add(x.select('HDWI').gt(HDWI_HD_P.select(59))).add(x.select('HDWI').gt(HDWI_HD_P.select(60)))
.add(x.select('HDWI').gt(HDWI_HD_P.select(61))).add(x.select('HDWI').gt(HDWI_HD_P.select(62))).add(x.select('HDWI').gt(HDWI_HD_P.select(63))).add(x.select('HDWI').gt(HDWI_HD_P.select(64))).add(x.select('HDWI').gt(HDWI_HD_P.select(65))).add(x.select('HDWI').gt(HDWI_HD_P.select(66))).add(x.select('HDWI').gt(HDWI_HD_P.select(67))).add(x.select('HDWI').gt(HDWI_HD_P.select(68))).add(x.select('HDWI').gt(HDWI_HD_P.select(69))).add(x.select('HDWI').gt(HDWI_HD_P.select(70)))
.add(x.select('HDWI').gt(HDWI_HD_P.select(71))).add(x.select('HDWI').gt(HDWI_HD_P.select(72))).add(x.select('HDWI').gt(HDWI_HD_P.select(73))).add(x.select('HDWI').gt(HDWI_HD_P.select(74))).add(x.select('HDWI').gt(HDWI_HD_P.select(75))).add(x.select('HDWI').gt(HDWI_HD_P.select(76))).add(x.select('HDWI').gt(HDWI_HD_P.select(77))).add(x.select('HDWI').gt(HDWI_HD_P.select(78))).add(x.select('HDWI').gt(HDWI_HD_P.select(79))).add(x.select('HDWI').gt(HDWI_HD_P.select(80)))
.add(x.select('HDWI').gt(HDWI_HD_P.select(81))).add(x.select('HDWI').gt(HDWI_HD_P.select(82))).add(x.select('HDWI').gt(HDWI_HD_P.select(83))).add(x.select('HDWI').gt(HDWI_HD_P.select(84))).add(x.select('HDWI').gt(HDWI_HD_P.select(85))).add(x.select('HDWI').gt(HDWI_HD_P.select(86))).add(x.select('HDWI').gt(HDWI_HD_P.select(87))).add(x.select('HDWI').gt(HDWI_HD_P.select(88))).add(x.select('HDWI').gt(HDWI_HD_P.select(89))).add(x.select('HDWI').gt(HDWI_HD_P.select(90)))
.add(x.select('HDWI').gt(HDWI_HD_P.select(91))).add(x.select('HDWI').gt(HDWI_HD_P.select(92))).add(x.select('HDWI').gt(HDWI_HD_P.select(93))).add(x.select('HDWI').gt(HDWI_HD_P.select(94))).add(x.select('HDWI').gt(HDWI_HD_P.select(95))).add(x.select('HDWI').gt(HDWI_HD_P.select(96))).add(x.select('HDWI').gt(HDWI_HD_P.select(97))).add(x.select('HDWI').gt(HDWI_HD_P.select(98))).add(x.select('HDWI').gt(HDWI_HD_P.select(99))).add(x.select('HDWI').gt(HDWI_HD_P.select(100)))
var ETo_air = //  x.select('ETo_air').gt(ETo_air_HD_P.select('ETo_air_p60')).add(x.select('ETo_air').gt(ETo_air_HD_P.select('ETo_air_p80'))).add(x.select('ETo_air').gt(ETo_air_HD_P.select('ETo_air_p90'))).add(x.select('ETo_air').gt(ETo_air_HD_P.select('ETo_air_p97'))).rename('ETo_air_P');
x.select('ETo_air').gt(ETo_air_HD_P.select(0)).add(x.select('ETo_air').gt(ETo_air_HD_P.select(1))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(2))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(3))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(4))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(5))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(6))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(7))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(8))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(9))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(10)))
.add(x.select('ETo_air').gt(ETo_air_HD_P.select(11))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(12))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(13))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(14))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(15))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(16))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(17))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(18))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(19))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(20)))
.add(x.select('ETo_air').gt(ETo_air_HD_P.select(21))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(22))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(23))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(24))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(25))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(26))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(27))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(28))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(29))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(30)))
.add(x.select('ETo_air').gt(ETo_air_HD_P.select(31))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(32))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(33))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(34))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(35))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(36))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(37))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(38))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(39))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(40)))
.add(x.select('ETo_air').gt(ETo_air_HD_P.select(41))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(42))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(43))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(44))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(45))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(46))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(47))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(48))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(49))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(50)))
.add(x.select('ETo_air').gt(ETo_air_HD_P.select(51))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(52))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(53))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(54))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(55))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(56))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(57))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(58))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(59))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(60)))
.add(x.select('ETo_air').gt(ETo_air_HD_P.select(61))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(62))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(63))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(64))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(65))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(66))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(67))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(68))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(69))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(70)))
.add(x.select('ETo_air').gt(ETo_air_HD_P.select(71))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(72))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(73))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(74))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(75))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(76))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(77))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(78))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(79))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(80)))
.add(x.select('ETo_air').gt(ETo_air_HD_P.select(81))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(82))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(83))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(84))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(85))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(86))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(87))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(88))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(89))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(90)))
.add(x.select('ETo_air').gt(ETo_air_HD_P.select(91))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(92))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(93))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(94))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(95))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(96))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(97))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(98))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(99))).add(x.select('ETo_air').gt(ETo_air_HD_P.select(100)))
var P = ee.ImageCollection([HDWI.rename('Clase_Peligro'),ETo_air.rename('Clase_Peligro')]).max().float()
return x.addBands(P).copyProperties(x, ['system:time_start'])
}
// Función para centrar el mapa en una ubicación
function centerMapToLocation(location, zoom) {Map.centerObject(location, zoom);
Closebut_ubicacion.style().set('shown', true); button_ubicacion.style().set('shown', true)}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var GFS_daily = GFS.map(function(x){return x.set('system:time_start', x.get('forecast_time'))})
.map(function(x){return x.set(addSunToImage(centroid, ee.Date(x.get('system:time_start'))))}).map(addBands).map(classification)
// .map(function(x){return x.set('system:time_start', start.millis())});   
var q = GFS_daily.select('Clase_Peligro').first().reduceRegions({collection: pais, reducer: ee.Reducer.mean(), crs:expCRS, scale: scaleReduce});   
var Dpt = q.reduceToImage({properties: ['mean'], reducer: ee.Reducer.mean()}).round().int().rename('Clase_Peligro');
Dpt = Dpt.gt(Moderado).add(Dpt.gt(Alto)).add(Dpt.gt(Muy_Alto)).add(Dpt.gt(Extremo));
Map.addLayer(Dpt,{min:0,max: 4,palette:palette,opacity:0.75},'Pronóstico');
Map.addLayer(ee.Image().byte().paint({featureCollection: pais, color: 1, width: 1}), {palette: 'black'}, 'Límites admnistrativos');
var Peligro = GFS_daily.select('Clase_Peligro').map(function(x){return x.addBands(ee.Image.constant(x.date().get('year')).uint16().rename('Anho'))
.addBands(ee.Image.constant(x.date().getRelative('month','year')).add(1).uint16().rename('Mes'))
.addBands(ee.Image.constant(x.date().getRelative('day','month')).add(1).uint16().rename('Dia')).select(['Anho','Mes','Dia','Clase_Peligro'])})
var Santa_Cruz = Peligro.map(function(x){return x.reduceRegions({collection: pais.filter(ee.Filter.eq('dep','Santa Cruz')),
reducer: ee.Reducer.mean(), crs:expCRS, scale: scaleReduce})}).flatten().sort('mun').select(['mun','Anho','Mes','Dia','Clase_Peligro']);
var Beni = Peligro.map(function(x){return x.reduceRegions({collection: pais.filter(ee.Filter.eq('dep','Beni')),
reducer: ee.Reducer.mean(), crs:expCRS, scale: scaleReduce})}).flatten().sort('mun').select(['mun','Anho','Mes','Dia','Clase_Peligro']);
var Pando = Peligro.map(function(x){return x.reduceRegions({collection: pais.filter(ee.Filter.eq('dep','Pando')),
reducer: ee.Reducer.mean(), crs:expCRS, scale: scaleReduce})}).flatten().sort('mun').select(['mun','Anho','Mes','Dia','Clase_Peligro']);
// Export.table.toDrive({collection: Peligro.reduceRegions({collection: pais, reducer: ee.Reducer.mean(), crs:expCRS, scale: scaleReduce})}).flatten()
// .sort('mun').sort('prov').sort('dep').select(['dep','prov','mun','Anho','Mes','Dia','Clase_Peligro']), description: 'Peligro_'+inicio+'_'+fin, 
// selectors: ['dep','prov','mun','Anho','Mes','Dia','Clase_Peligro'], folder: 'Prónostico de Peligro Bolivia', fileFormat: 'CSV'});
////////////    Leyenda
var backgroundColor = '#FFEFD5';
// Map.add(ui.Label({value: 'Peligro de Incendio '+ inis, style: {position: 'top-center', fontSize: '20px', color: '000000', backgroundColor: backgroundColor, fontWeight: 'bold', border: '1px solid #000000'}}));
var fecha = ui.Label({value: inis, style: {fontWeight: 'bold', fontSize: '28px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
var titulopanel1 = ui.Label({value: 'Peligro de Incendio', style: {fontWeight: 'bold', fontSize: '19px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
// Botón para centrar en la vista general
var BUTTON_WIDTH = '90px';
var Closebut_ubicacion = ui.Button({label: 'Vista general',
style: {position: 'top-right',color: 'black',backgroundColor: backgroundColor,margin: '0px',padding: '0px',width: BUTTON_WIDTH},
onClick: function() {centerMapToLocation(pais)}});
// Botón para centrar en la ubicación actual
var button_ubicacion = ui.Button({label: 'Su ubicación 📍',
style: {position: 'top-right',color: 'black',backgroundColor: backgroundColor,margin: '0px',padding: '0px',width: BUTTON_WIDTH},
onClick: function() {ui.util.getCurrentPosition(current_position, 1);
function current_position(point) {Map.centerObject(point, currentZoom);
var layer_100 = ui.Map.Layer(point, {}, 'Ubicación actual', true);
Map.layers().set(100, layer_100);                // Agrega la capa de ubicación actual en la posición 8
Closebut_ubicacion.style().set('shown', true);  button_ubicacion.style().set('shown', true)}}});
var contact = ui.Label({value: 'La ciencia detrás de la app', style: {fontWeight: 'bold', fontSize: '14px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}, targetUrl: 'https://www.linkedin.com/posts/andrea-markos-9604359_con-mi-aporte-sobre-pronostico-del-peligro-activity-7386741502875631617-WJgT?utm_source=social_share_send&utm_medium=member_desktop_web&rcm=ACoAAAGqWhgBjYO-gkokS6Cj_NCrrHG52c8vEHw'
// targetUrl: 'https://www.linkedin.com/in/andrea-markos-9604359/'
});
var tituloGrafico = ui.Label({value: 'Cliquear en un Municipio', style: {fontWeight: 'bold', fontSize: '15px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
// var descargaDatos1 = ui.Label(inicio+' / '+fin+' S. Cruz', {backgroundColor: backgroundColor}, Santa_Cruz.getDownloadURL({format:'CSV'}))
// var descargaDatos2 = ui.Label(inicio+' / '+fin+' Beni', {backgroundColor: backgroundColor}, Beni.getDownloadURL({format:'CSV'}))
// var descargaDatos3 = ui.Label(inicio+' / '+fin+' Pando', {backgroundColor: backgroundColor}, Pando.getDownloadURL({format:'CSV'}))
var panel1 = ui.Panel({style: {width: '200px', position: 'bottom-right',padding: '8px 15px', backgroundColor: backgroundColor}});
panel1=panel1.add(fecha).add(titulopanel1)
var names = ['0 Bajo','1 Moderado','2 Alto','3 Muy Alto','4 Extremo'].reverse()
var palette = ['2c7bb6','abd9e9','ffffbf','fdae61','d7191c'].reverse()
var makeRow = function(color, name) {
var colorBox = ui.Label({style: {backgroundColor: '#' + color,padding: '15px',margin: '0 0 4px 0'}});
var description = ui.Label({value: name,style: {margin: '0 0 4px 6px', fontSize: '17px', backgroundColor: backgroundColor}});
return ui.Panel({widgets: [colorBox, description], style: {backgroundColor: backgroundColor}, layout: ui.Panel.Layout.Flow('horizontal')})};
for (var i = 0; i < 5; i++) {panel1.add(makeRow(palette[i], names[i]));} 
Map.add(panel1.add(button_ubicacion)//.add(Closebut_ubicacion)
// .add(descargaDatos1).add(descargaDatos2).add(descargaDatos3)
.add(contact).add(tituloGrafico))
Map.onClick(function(coords) {
var location = 'lon: ' + coords.lon.toFixed(2) + ' ' + 'lat: ' + coords.lat.toFixed(2);
var point = pais.select('mun').filterBounds(ee.Geometry.Point(coords.lon, coords.lat))
Map.centerObject(point)
var mask = ee.Image(1).clip(point)
Map.layers().set(2, ui.Map.Layer(ee.Image().byte().paint({featureCollection: point, color: 1, width: 1.5}), {palette: 'magenta'}, 'Municipio'));
var chart1 = ui.Chart.image.series(GFS_daily.map(function(x){
var q = x.select('Clase_Peligro').updateMask(mask)
.reduceRegions({collection: point, reducer: ee.Reducer.mean(), crs:expCRS, scale: scaleReduce});   
var Dpt = q.reduceToImage({properties: ['mean'], reducer: ee.Reducer.mean()}).round().int().rename('Clase_Peligro');
Dpt = Dpt.gt(Moderado).add(Dpt.gt(Alto)).add(Dpt.gt(Muy_Alto)).add(Dpt.gt(Extremo))
return Dpt.copyProperties(x, ['system:time_start'])}), 
point.geometry().bounds(), ee.Reducer.mean(), scaleReduce, 'system:time_start').setChartType('ColumnChart','AreaChart')
.setOptions({vAxis: {title: 'Clase Peligro 0-4', viewWindow: {min: 0, max: 4}} , hAxis: {title: ' del '+inicio+' al '+fin, format: 'dd-MM-YYYY'} , series: {0: {color: 'red'}}});
// var chart2 = ui.Chart.image.series(GFS_daily.map(function(x){return x.select('Clase_Peligro').updateMask(mask).rename('Peligro')
// }), point.geometry().bounds(), ee.Reducer.mean(), scaleReduce, 'system:time_start').setChartType('ColumnChart')
// .setOptions({vAxis: {title: 'Peligro 0-100', viewWindow: {min: 0, max: 100}} , hAxis: {title: ' del '+inicio+' al '+fin, format: 'dd-MM-YYYY'} , series: {0: {color: 'red'}}});
panel1.widgets()
.set(10, chart1)//.set(10, chart2)
});
}
runApp();
/**/