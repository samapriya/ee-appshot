// https://www.agraria.unirc.it/documentazione/materiale_didattico/1462_2016_412_24509.pdf 
Map.setOptions('HYBRID').setControlVisibility(false);            // ROADMAP SATELLITE HYBRID TERRAIN
var aoi =  ee.FeatureCollection('users/anmarkos/Andre_Sorio/2023/ALFREDO_PIRACICABA/ALFREDO_PIRACICABA');    
var Piquetes = ee.Image().byte().paint({featureCollection: aoi, color: 1, width: 1}).visualize({palette:'white'});  
var buffer = aoi.geometry().buffer(80000);
var maskAll = ee.Image(1).clip(buffer);
var maskIt = ee.Image('users/anmarkos/Andre_Sorio/2023/ALFREDO_PIRACICABA/ALFREDO_PIRACICABA_pasto').clip(aoi);
var centroid = maskIt.geometry().centroid();
var exp_Proj = 'EPSG:4326';             var exp_Scale = 30;
Map.centerObject(maskIt)
var foreDays = 0;
var timeZone= 'America/Buenos_Aires';
var timeZoneDiff = ee.Date(Date.now()).difference(ee.Date(Date.now()).format({timeZone: timeZone}), 'hour').round().int();
var NDWI_t = -0.37;
var NDVI_t = 0;
var cloud_t = 0.2;
var fin = ee.Date(Date.now());
var ini = fin.advance(-6, 'month');  
var MA = ee.FeatureCollection('users/anmarkos/Andre_Sorio/2023/ALFREDO_PIRACICABA/ALFREDO_PIRACICABA').aside(print).filter(ee.Filter.lte('Name', 'MA_P28'))//.aside(Map.addLayer)
var MB = ee.FeatureCollection('users/anmarkos/Andre_Sorio/2023/ALFREDO_PIRACICABA/ALFREDO_PIRACICABA').aside(print).filter(ee.Filter.gt('Name', 'MA_P28'))//.aside(Map.addLayer)
function NDVI(x){var x = x.updateMask(maskIt)
var NDWI = x.expression("((GREEN+RED)-(NIR+SWIR))/((GREEN+RED)+(NIR+SWIR))",
{GREEN: x.select("B3"), RED: x.select("B4"), NIR: x.select("B8"), SWIR: x.select("B11")}).rename('NDWI');
var nocloud = x.select(['B8A','B4']).updateMask(NDWI.select("NDWI").lt(NDWI_t)); 
var cloud = ee.Image(ee.Number(NDWI.select("NDWI").gt(NDWI_t).reduceRegion(ee.Reducer.mean(), aoi, 10).get('NDWI'))).rename('cloud');
var NDVI = x.expression("(NIR-RED)/(NIR+RED)",{RED: nocloud.select("B4"), NIR: nocloud.select("B8A")}).rename('NDVI');
NDVI = NDVI.updateMask(NDVI.gt(NDVI_t)).updateMask(NDVI.lt(0.9)).updateMask(cloud.gt(cloud_t));
var cloud = ee.Image(ee.Number(NDWI.select("NDWI").gt(NDWI_t).reduceRegion(ee.Reducer.mean(), aoi, 10).get('NDWI'))).rename('cloud')
var kc_pasture = NDVI.multiply(0.89).add(0.12).rename('kc_pasture');
return NDVI.addBands(cloud).addBands(kc_pasture)
//.addBands(NDVI.multiply(1.44).subtract(0.12).rename('kc_soy'))
.copyProperties(x, ['system:time_start'])}
var S2 = ee.ImageCollection('COPERNICUS/S2_HARMONIZED').filterBounds(aoi).filterDate(ini,fin).map(NDVI);
function NDVI_L(x){var x = x.select(['B3','B4','B5','B6']).updateMask(maskIt)
var NDWI = x.expression("((GREEN+RED)-(NIR+SWIR))/((GREEN+RED)+(NIR+SWIR))",
{GREEN: x.select("B3"), RED: x.select("B4"), NIR: x.select("B5"), SWIR: x.select("B6")}).rename('NDWI');
var nocloud = x.select(['B5','B4']).updateMask(NDWI.select("NDWI").lt(NDWI_t)); 
var cloud = ee.Image(ee.Number(NDWI.select("NDWI").gt(NDWI_t).reduceRegion(ee.Reducer.mean(), aoi, 30).get('NDWI'))).rename('cloud');
var NDVI = x.expression("(NIR-RED)/(NIR+RED)",{RED: nocloud.select("B4"), NIR: nocloud.select("B5")});
NDVI = NDVI.updateMask(NDVI.gt(NDVI_t)).updateMask(NDVI.lt(0.9)).updateMask(cloud.gt(cloud_t));
var kc_pasture = NDVI.multiply(0.89).add(0.12).rename('kc_pasture');
return NDVI.rename('NDVI').addBands(kc_pasture)
//.addBands(NDVI.multiply(1.44).subtract(0.12).rename('kc_soy'))
.copyProperties(x, ['system:time_start'])}
var L = ee.ImageCollection("LANDSAT/LC08/C02/T1_RT_TOA").filterBounds(aoi).filterDate(ini,fin).map(NDVI_L)
.merge(ee.ImageCollection("LANDSAT/LC09/C02/T1_TOA").filterBounds(aoi).filterDate(ini,fin).map(NDVI_L));
var combined = S2.merge(L).select('kc_pasture')
.map(function(x){var q = x.reduceRegions({collection: aoi, reducer: ee.Reducer.median(), scale: 30}); 
return x.addBands(q.reduceToImage({properties: ['median'], reducer: ee.Reducer.median()}).rename('kc_median'))});
var recent = combined.sort('system:time_start',false).limit(8).sort('system:time_start');
var first = recent.first().date();
recent = recent.merge(ee.Image().rename('kc_median').set('system:time_start',ee.Date(Date.now()).millis()))
.map(function timeBand(x) {return x.addBands(ee.Image(x.date().difference(ee.Date(first), 'second')).float())});
var sensSlope = recent.select(['constant','kc_median']).reduce(ee.Reducer.sensSlope());
var now = recent.map(function trendS(x) {var trend = x.expression("((constant*slope)+offset)", 
{constant: x.select("constant"), slope: sensSlope.select("slope"), offset: sensSlope.select("offset")});
return x.addBands(trend.rename('kc_now'))});
// print('Area (ha): ', combined.select('kc_pasture').mosaic().neq(0).multiply(ee.Image.pixelArea()).divide(10000)
// .reduceRegion({reducer: ee.Reducer.sum(), geometry: aoi, scale: 10, maxPixels: 1e13, tileScale: 16}));
//////////////////////////////////    Inputs    //////////////////////////////////
var GFS = ee.ImageCollection("NOAA/GFS0P25")
.filter(ee.Filter.calendarRange(0, 0,'hour'))
.filter(ee.Filter.gte('forecast_hours', timeZoneDiff.add(24*foreDays)))
.filter(ee.Filter.lt('forecast_hours', timeZoneDiff.add(24*foreDays).add(24)))
var mostRecent = GFS.filterDate(ee.Date(Date.now()).advance(-3,'day'),ee.Date(Date.now())).sort('system:time_start',false).first();
var projection = mostRecent.select('temperature_2m_above_ground').projection().aside(print)
var scale = ee.Number(projection.nominalScale()).aside(print);
var start = mostRecent.date(); print('Latest Data Available:', start);  
var end = start.advance(1,'day');
var days = 1//ee.Number(end.difference(start,'day').int()).subtract(1).aside(print); 
var GFS_hourly = GFS.filterDate(start, end)
.map(function(x){return x.set('system:time_start', x.get('forecast_time'))}).aside(print);
  // Constants
var elv = ee.ImageCollection("projects/sat-io/open-datasets/FABDEM").filterBounds(aoi).mosaic().clip(aoi)
.rename("elv").setDefaultProjection(exp_Proj, null, exp_Scale).int();
var mostRecent = ee.ImageCollection("NOAA/GFS0P25").filterDate(ee.Date(Date.now()).advance(-2,'day'),ee.Date(Date.now())).sort('system:time_start',false).first();
var projection = mostRecent.select('temperature_2m_above_ground').projection(); 
var scale = ee.Number(projection.nominalScale()); 
var elevation = ee.Terrain.fillMinima(ee.Image("USGS/SRTMGL1_003").select('elevation').clip(buffer));
elevation = elevation.updateMask(elevation.gt(0));
var latitude = ee.Image.pixelLonLat().select('latitude');
var lat = latitude.reproject({scale:scale, crs:projection});
var ele = elevation.reproject({scale:scale, crs:projection});
var latEx = latitude.reproject({scale:exp_Scale, crs:exp_Proj}).clip(aoi);   var PHI = latEx.multiply(0.01745);
var elevEx = elevation.reproject({scale:exp_Scale, crs:exp_Proj}).clip(aoi);
var aspect = ee.Terrain.aspect(elevEx);
var β = ee.Terrain.slope(elevEx).select('slope').multiply(Math.PI/180).float();
var γ = aspect.select('aspect').multiply(Math.PI/180).float();
var Slope_Ratio = β.tan();
var SpeedUp = Slope_Ratio.lte(0.2).add(Slope_Ratio.gt(0.2).multiply(Slope_Ratio.multiply(0.75).add(0.851667)));
var focalMax = elevEx.focalMax({radius: 500, kernelType: 'circle', units: 'meters'});
var focalMin = elevEx.focalMin({radius: 500, kernelType: 'circle', units: 'meters'});
var UD = ee.Image(1).clip(aoi).subtract(focalMax.subtract(elevEx).divide(focalMax.subtract(focalMin)));
var upDown = ee.Image(0.5).add(UD.multiply(0.65));
var downUp = ee.Image(0.383).add(UD.multiply(0.767));
// var MB = ee.Image('projects/mapbiomas-public/assets/peru/collection2/mapbiomas_peru_collection2_integration_v1').aside(print).select('classification_2022').clip(aoi)  // https://peru.mapbiomas.org/wp-content/uploads/sites/14/2024/02/Leyenda_website_Coleccion_20.pdf
var albedo = ee.Image(0.77)//ee.Image(1).subtract(MB.gt(6).updateMask(MB.lt(22)).add(1).multiply(0.12));
var eleRH = (elevEx.pow(2)).multiply(-0.000002571307).add(elevEx.multiply(0.009107416881)).multiply(0.574599540634743);
var latRH = (latEx.pow(2)).multiply(-0.059632388318).add(latEx.multiply(0.175854248331)).multiply(0.906513375583237);
var eleT = (elevEx.pow(3)).multiply(-0.000000000132732).add((elevEx.pow(2)).multiply(0.000001020722689)).add(elevEx.multiply(-0.006756412303233)).multiply(1.01022169695525);
var latT = lat.multiply(-0.185058870633863)
var latTEx = latEx.multiply(-0.185058870633863)
var eleRHX = (ele.pow(2)).multiply(-0.000002571307).add(ele.multiply(0.009107416881)).multiply(0.574599540634743);
var latRHX = (lat.pow(2)).multiply(-0.059632388318).add(lat.multiply(0.175854248331)).multiply(0.906513375583237);
var eleTX = (ele.pow(3)).multiply(-0.000000000132732).add((ele.pow(2)).multiply(0.000001020722689)).add(ele.multiply(-0.006756412303233)).multiply(1.01022169695525);
var ele_rs = elevEx.multiply(0.005014123);   var lat_rs = latEx.multiply(-1.818659631);
var ele_RS = ele.multiply(0.005014123);      var lat_RS = lat.multiply(-1.818659631);         
var ele_vv =  elevEx.multiply(0.000295877010).exp().multiply(1.229175952077).multiply(1.01028862);  var lat_vv = latEx.multiply(-0.094268465191).multiply(0.667333609);
var ele_VV =  ele.multiply(0.000295877010).exp().multiply(1.229175952077).multiply(1.01028862);     var lat_VV = lat.multiply(-0.094268465191).multiply(0.667333609);
//////////////////////////////////    Functions    //////////////////////////////////
function reProDWSC(x){//  calibrado para o Sergipe com GSOD
var air_temp = x.select('temperature_2m_above_ground').updateMask(maskAll).multiply(1.120652242)
.add(x.select('ventilation_rate').updateMask(maskAll).multiply(-0.000150453)).rename('air_temp');   
// var air_temp = x.select('temperature_2m_above_ground').updateMask(maskAll);
var rel_hum = x.select('relative_humidity_2m_above_ground').updateMask(maskAll);
var u = x.select('u_component_of_wind_10m_above_ground').updateMask(maskAll);
var v = x.select('v_component_of_wind_10m_above_ground').updateMask(maskAll);
var pp = x.select('precipitation_rate').updateMask(maskAll).rename('pp');
///////////////////////////////////////////////////    AIR TEMP    ////////////////////////////////////////////////////////////////
var T = (air_temp.subtract(eleTX).subtract(latT)).rename('air_temp');
var air_temp_DWSC = T.resample('bicubic').updateMask(maskIt).add(eleT).add(latTEx).rename('air_temp_DWSC');
var Te = air_temp_DWSC.subtract(eleT) // Temperatura a nivel del mar
var G = ((Te.subtract(elevEx.multiply(0.0065))).divide(Te)).pow(5.26).multiply(101.3).multiply(0.000665).rename('G');
///////////////////////////////////////////////////    REL HUM    ////////////////////////////////////////////////////////////////
var RH = (rel_hum.subtract(eleRHX).subtract(latRHX)).rename('rel_hum');
var rel_hum_DWSC = (RH.resample('bicubic').updateMask(maskIt).add(eleRH).add(latRH)).divide(100);
var rel_hum_DWSC = ee.ImageCollection([rel_hum_DWSC.updateMask(rel_hum_DWSC.lte(1)), rel_hum_DWSC.gt(1).selfMask()]).mosaic().rename('rel_hum_DWSC');
///////////////////////////////////////////////////   VPD air    ////////////////////////////////////////////////////////////////
var es = x.expression('0.61078*exp(17.27*T/(T+237.3))', {T: air_temp_DWSC}).rename('es');
var ea = es.multiply(rel_hum_DWSC);
var VPD_air = (es.subtract(ea)).rename('VPD_air');
///////////////////////////////////////////////////   Rn    ////////////////////////////////////////////////////////////////
var ds = x.select('downward_shortwave_radiation_flux').updateMask(maskAll);
var Rs = ds.subtract(ele_RS).subtract(lat_RS)
Rs = Rs.resample('bicubic').updateMask(maskIt).add(ele_rs).add(lat_rs);
var Rn = Rs.multiply(0.0036).multiply(albedo).rename('Rn'); // Convert W to MJ
///////////////////////////////////////////////////   U    ////////////////////////////////////////////////////////////////
var WIND = ((u.pow(2).add(v.pow(2))).sqrt()).multiply(0.79441473210435);  //  .multiply(3.6)   keep m/s
var W = (WIND.subtract(ele_VV).subtract(lat_VV));
var WIND_DWSC = W.resample('bicubic').updateMask(maskIt).add(ele_vv).add(lat_vv);
u = u.resample('bicubic').updateMask(maskIt);    v = v.resample('bicubic').updateMask(maskIt);
var Wind_Dir = ((v.atan2(u)).multiply(57.29577951)).add(180).rename('Wind_Dir');
var delta1 = (Wind_Dir.subtract(aspect)).abs().rename('Wind_Match');
var delta2 = ee.Image(360).subtract(delta1).rename('Wind_Match');
var diff = ee.Image(1).rename('Wind_Match').subtract(ee.ImageCollection([delta1, delta2]).min().divide(180));
var	Windward_Speed = WIND_DWSC.multiply(upDown.updateMask(diff.gt(0.5))).add(WIND.multiply(SpeedUp.updateMask(diff.gt(0.5))));
var	Lee_Side_Speed = WIND_DWSC.multiply(downUp.updateMask(diff.lte(0.5)));
var U = ee.ImageCollection([Windward_Speed,Lee_Side_Speed]).mosaic().rename('U');
///////////////////////////////////////////////////   ETo air    ////////////////////////////////////////////////////////////////
var D = (es.divide((air_temp.add(237.3)).pow(2))).multiply(4098).rename('D');
var AT = (ee.Image(37.5).divide(air_temp_DWSC.add(273.15))).multiply(U.pow(2)).multiply(VPD_air).rename('AT');   //    (900/24)
var ETo_air = x.expression('((0.408*D*Rn)+(G*AT))/(D+G*(1+(0.34*U*U)))',
{AT: AT, D: D, G: G, Rn: Rn, T: air_temp_DWSC, U: U}).rename('ETo_air');
///////////////////////////////////////////////////   ETo leaf    ////////////////////////////////////////////////////////////////
var leaf_temp = x.select('total_cloud_cover_entire_atmosphere').multiply(-0.023040433)
.add(x.select('v_component_of_wind_10m_above_ground').multiply(0.602394559))
.add(VPD_air.multiply(4.80173369)).add(17.70388653).rename('leaf_temp');
var es = x.expression('0.61078*exp(17.27*T/(T+237.3))', {T: leaf_temp}).rename('es');
var ea = es.multiply(rel_hum_DWSC);
var VPD_leaf = (es.subtract(ea)).rename('VPD_leaf');
var D = (es.divide((air_temp_DWSC.add(237.3)).pow(2))).multiply(4098).rename('D');
var AT = (ee.Image(37.5).divide(air_temp_DWSC.add(273.15))).multiply(U.pow(2)).multiply(VPD_leaf).rename('AT');   //    (900/24)
var ETo_leaf = x.expression('((0.408*D*Rn)+(G*AT))/(D+G*(1+(0.34*U*U)))',
{AT: AT, D: D, G: G, Rn: Rn, T: air_temp_DWSC, U: U}).rename('ETo_leaf');
return ETo_air.addBands(ETo_leaf).addBands(pp).addBands(air_temp_DWSC).addBands(leaf_temp).copyProperties(x, ['system:time_start'])}
GFS_hourly = GFS_hourly.map(reProDWSC);
var ETo = ee.ImageCollection(GFS_hourly).select(['ETo_air','ETo_leaf']).sum();
var kc_now = now.select('kc_now').sort('system:time_start',false).first()
var ETc_air = ETo.select('ETo_air').multiply(kc_now).rename('ETc_air');
var ETc_leaf = ETo.select('ETo_leaf').multiply(kc_now).rename('ETc_leaf');
// Maximum amount of water the soil can hold that is accessible to plants (TAW)
var TAW = ee.ImageCollection("projects/sat-io/open-datasets/HiHydroSoilv2_0/wcavail").mosaic().resample('bicubic').updateMask(maskAll).divide(10000).multiply(30).rename('Total Available Water mm/30cm');
// Management Allowed Depletion (MAD). The TAW% that can be depleted before irrigation becomes necessary. 30-50% depending on crop sensitivity to water stress.
var MAD = 0.3
// Net Irrigation Requirement (NIR) = ETc_air – Rainfall – MAD
var NIR_air = ETc_air .subtract(TAW.multiply(MAD)).rename('NIR_air').multiply(1.2);     //  20% increase for semi-arid conditions and irrigation system's inefficiencies
NIR_air = NIR_air.updateMask(NIR_air.gt(0))
var NIR_leaf = ETc_leaf .subtract(TAW.multiply(MAD)).rename('NIR_leaf').multiply(1.2);  //  20% increase for semi-arid conditions and irrigation system's inefficiencies
NIR_leaf = NIR_leaf.updateMask(NIR_leaf.gt(0))
// var NIR = ee.ImageCollection([NIR_air.rename('NIR'),NIR_leaf.rename('NIR')]).max()
var q_MA = ee.Image(ee.Number(kc_now.clip(MA).reduceRegion({reducer:ee.Reducer.mean(),geometry: MA, scale:30, bestEffort:true, maxPixels:1e13, tileScale:16}).get('kc_now'))).clip(MA)
var q_MB = ee.Image(ee.Number(kc_now.clip(MB).reduceRegion({reducer:ee.Reducer.mean(),geometry: MB, scale:30, bestEffort:true, maxPixels:1e13, tileScale:16}).get('kc_now'))).clip(MB)
var q = ee.ImageCollection([q_MA.float(),q_MB.float()]).mosaic()
Map.addLayer(ee.Image(q).visualize({min:0,max:1,palette:['white','lightblue','blue','darkblue']}).blend(Piquetes),{},'kc')
// Map.addLayer(kc_now.visualize({min:0,max:1,palette:['white','lightblue','blue','darkblue']}).blend(Piquetes),{},'kc');
// Saturated Hydraulic Conductivity indicates how quickly water moves through soil at saturation, Exceeding this rate would likely result in surface runoff rather than infiltration. (Ksat, 0.9 per stare in sicurezza)
var Ksat = ee.ImageCollection("projects/sat-io/open-datasets/HiHydroSoilv2_0/ksat").mosaic().resample('bicubic').updateMask(maskIt).divide(10000).divide(2.4).multiply(0.9).rename('mm/hour')//;
// var isric_clay = ee.Image("projects/soilgrids-isric/clay_mean").select([0,1,2]).divide(10).resample('bicubic').updateMask(maskAll);
// isric_clay=(isric_clay.select('clay_0-5cm_mean').multiply(5).add(isric_clay.select('clay_5-15cm_mean').multiply(10)).add(isric_clay.select('clay_15-30cm_mean').multiply(15))).divide(30).rename('clay');
// var isric_sand = ee.Image("projects/soilgrids-isric/sand_mean").select([0,1,2]).divide(10).resample('bicubic').updateMask(maskAll);
// isric_sand=(isric_sand.select('sand_0-5cm_mean').multiply(5).add(isric_sand.select('sand_5-15cm_mean').multiply(10)).add(isric_sand.select('sand_15-30cm_mean').multiply(15))).divide(30).rename('sand');
// print('Clay % in the top 30cm: ', ee.Number(isric_clay.reduceRegion({reducer:ee.Reducer.mean(), geometry:aoi, scale: 200, bestEffort: true}).get('clay')).multiply(100).round().int().divide(100));
// print('Sand % in the top 30cm: ', ee.Number(isric_sand.reduceRegion({reducer:ee.Reducer.mean(), geometry:aoi, scale: 200, bestEffort: true}).get('sand')).multiply(100).round().int().divide(100));
// print('Total Available Water mm/30cm: ', ee.Number(TAW.reduceRegion({reducer:ee.Reducer.mean(), geometry:aoi, scale: 200, bestEffort: true}).get('Total Available Water mm/30cm')).multiply(100).round().int().divide(100));
// print('leaf_temp: ', ee.Number(GFS_hourly.select('leaf_temp').mean().reduceRegion({reducer:ee.Reducer.mean(),geometry: aoi, scale:30, bestEffort:true, maxPixels:1e13, tileScale:16}).get('leaf_temp')).multiply(100).round().int().divide(100));
// print('air_temp: ', ee.Number(GFS_hourly.select('air_temp_DWSC').mean().reduceRegion({reducer:ee.Reducer.mean(),geometry: aoi, scale:30, bestEffort:true, maxPixels:1e13, tileScale:16}).get('air_temp_DWSC')).multiply(100).round().int().divide(100));
// print(ui.Chart.image.series(combined.select('kc_median').map(function(x){return x.clip(MA).rename('Modulo A')})
// .merge(kc_now.clip(MA).rename('kc now A')).merge(kc_now.clip(MB).rename('kc now B'))
// .merge(combined.select('kc_median').map(function(x){return x.clip(MB).rename('Modulo B')})), 
// aoi, ee.Reducer.mean(), 30,'system:time_start').setChartType('LineChart'));
var backgroundColor = 'FFEFD5';
var panel = ui.Panel({style: {width: '130px', position: 'bottom-right',padding: '8px 15px', backgroundColor: backgroundColor}});
var titulopanel = ui.Label({value: 'Necessidade hídrica dia:', style: {fontWeight: 'bold', fontSize: '18px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
var data = ui.Label({value: ee.Date(Date.now()).format({timeZone: timeZone, format: 'dd-MM-yyyy'}).getInfo(), style: {fontWeight: 'bold', fontSize: '18px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
var sol_1 = ui.Label({value: '--- Módulo A ---', style: {fontWeight: 'bold', fontSize: '13px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
var Modulo_A_leaf_max = ui.Label({value: 'máximo: '+ ee.Number(NIR_leaf.clip(MA).reduceRegion({reducer:ee.Reducer.percentile([95]),geometry: aoi, scale:30, bestEffort:true, maxPixels:1e13, tileScale:16}).get('NIR_leaf')).add(0.51).round().int().getInfo()+' mm', style: {fontWeight: 'bold', fontSize: '13px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
var Modulo_A_leaf_min = ui.Label({value: 'mínimo:  '+ ee.Number(NIR_leaf.clip(MA).reduceRegion({reducer:ee.Reducer.percentile([5]),geometry: aoi, scale:30, bestEffort:true, maxPixels:1e13, tileScale:16}).get('NIR_leaf')).add(0.51).round().int().getInfo()+' mm', style: {fontWeight: 'bold', fontSize: '13px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
var sol_2 = ui.Label({value: '--- Módulo B ---', style: {fontWeight: 'bold', fontSize: '13px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
var Modulo_B_leaf_max = ui.Label({value: 'máximo: '+ ee.Number(NIR_leaf.clip(MB).reduceRegion({reducer:ee.Reducer.percentile([95]),geometry: aoi, scale:30, bestEffort:true, maxPixels:1e13, tileScale:16}).get('NIR_leaf')).add(0.51).round().int().getInfo()+' mm', style: {fontWeight: 'bold', fontSize: '13px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
var Modulo_B_leaf_min = ui.Label({value: 'mínimo:  '+ ee.Number(NIR_leaf.clip(MB).reduceRegion({reducer:ee.Reducer.percentile([5]),geometry: aoi, scale:30, bestEffort:true, maxPixels:1e13, tileScale:16}).get('NIR_leaf')).add(0.51).round().int().getInfo()+' mm', style: {fontWeight: 'bold', fontSize: '13px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
var Chuva = ui.Label({value: 'Chuva pr.: '+ ee.Number(GFS_hourly.select('pp').sum().reduceRegion({reducer:ee.Reducer.mean(),geometry: aoi, scale:30, bestEffort:true, maxPixels:1e13, tileScale:16}).get('pp')).multiply(0.7).multiply(10).round().int().divide(10).getInfo()+' mm', style: {fontWeight: 'bold', fontSize: '13px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});//  0.7 os effectove rainfall
var Aplicacao = ui.Label({value: 'Máx. mm/h: '+ ee.Number(Ksat.reduceRegion({reducer:ee.Reducer.mean(),geometry: aoi, scale:30, bestEffort:true, maxPixels:1e13, tileScale:16}).get('mm/hour')).multiply(10).round().int().divide(10).getInfo(), style: {fontWeight: 'bold', fontSize: '13px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
panel.add(titulopanel).add(data).add(Chuva).add(Aplicacao).add(sol_1).add(Modulo_A_leaf_max).add(Modulo_A_leaf_min).add(sol_2).add(Modulo_B_leaf_max).add(Modulo_B_leaf_min);
Map.add(panel);
/**/
// var vis = {min: '0%', max: '100%', palette: ['white','lightblue','blue','darkblue']};
// function makeColorBarParams(palette) {return {bbox: [0, 0, 1, 0.1],dimensions: '100x10',format: 'png',min: 0,max: 1,palette: palette}}
// var colorBar = ui.Thumbnail({image: ee.Image.pixelLonLat().select(0),params: makeColorBarParams(vis.palette),
// style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},});
// var legendLabels = ui.Panel({widgets: [ui.Label(vis.min, {margin: '4px 8px'}),              
// ui.Label('50%',{margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),  
// ui.Label(vis.max, {margin: '4px 8px'})],layout: ui.Panel.Layout.flow('horizontal')});      
// var legendTitle = ui.Label({value: 'Coeficiente de cultura',style: {fontWeight: 'bold'}});
// var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
// Map.add(legendPanel);