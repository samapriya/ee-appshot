var scaleBar = ui.import && ui.import("scaleBar", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -82.6282647843627,
            -7.4804005166672
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([-82.6282647843627, -7.4804005166672]),
    Center = ui.import && ui.import("Center", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -83.50166613563576,
            -1.6427343352869335
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([-83.50166613563576, -1.6427343352869335]),
    AOI = ui.import && ui.import("AOI", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -91.7578823338417,
                1.6079370933020163
              ],
              [
                -91.7578823338417,
                -5.16341304772096
              ],
              [
                -75.0696499119667,
                -5.16341304772096
              ],
              [
                -75.0696499119667,
                1.6079370933020163
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-91.7578823338417, 1.6079370933020163],
          [-91.7578823338417, -5.16341304772096],
          [-75.0696499119667, -5.16341304772096],
          [-75.0696499119667, 1.6079370933020163]]], null, false);
Map.drawingTools().setShown(false);  //  oculta las geometrias
Map.setOptions('HYBRID');            // ROADMAP SATELLITE HYBRID TERRAIN
var states = ee.FeatureCollection('users/anmarkos/FIRE/ECUADOR/adm1_INEC_2019');
var aoi = AOI;  Map.centerObject(aoi, 6.4);
var zones = ee.Image('users/anmarkos/FIRE/ECUADOR/Ecuador_Zoning').select('constant').updateMask(ee.Image('users/anmarkos/FIRE/ECUADOR/WorldCover_2021')).add(1);
// // // EXPORT ZONING SHAPEFILE
// var Z = ee.Image('users/anmarkos/FIRE/ECUADOR/Ecuador_Zoning').select('constant')
// var shape = Z.addBands(Z).reduceToVectors({reducer: ee.Reducer.first(), geometry: Z.geometry(), scale:1000, crs: 'EPSG:32717', tileScale: 16})
// Export.table.toDrive(shape, 'shape', 'Ecuador', 'Ecuador_Zoning', 'SHP')
function area(x){return x.addBands(x.select('BurnDate').updateMask(zones).gte(0).multiply(ee.Image.pixelArea()).divide(10000).rename('Hectáreas Quemadas'))}
var Burned = ee.ImageCollection("MODIS/061/MCD64A1").filterDate('2016-01-01',ee.Date(Date.now())).select('BurnDate').select('BurnDate').map(area).select('Hectáreas Quemadas');
var titulo = ui.Label({value: 'Ecuador: Estacionalidad de los Índices de Peligro de Incendio por Zona.', style: {position: 'top-center', fontSize: '20px', fontWeight: 'bold', fontFamily:'Roboto Slab', color:'FFCB00', backgroundColor:'007432'}});
Map.add(titulo);
var title1 = ui.Label({value: 'Seleccione la zona de interés para visualizar la estacionalidad de los índices de peligro de incendio.', style: {position: 'top-center', fontSize: '20px', fontWeight: 'bold', fontFamily:'Dinot', color:'FFCB00', backgroundColor:'007432'}});
var title2 = ui.Label({value: 'ctrl + desplazamiento para ampliar los gráficos o el mapa.', style: {position: 'top-center', fontSize: '20px', fontWeight: 'bold', fontFamily:'Dinot', color:'FFCB00', backgroundColor:'007432'}});
var source = ui.Label({value: 'fuentes: CFSv2, ERA 5 Land Reanalysis.', style: {position: 'top-center', fontSize: '18px', fontWeight: 'bold', fontFamily:'Dinot', color:'FFCB00', backgroundColor:'007432'}});
var panel = ui.Panel({style:{width: '600px',position:'middle-right', backgroundColor:'007432'}});
var panelChart = ui.Panel({style: {width: '650px', position: 'bottom-left', backgroundColor:'007432'}});    //    .style().set({width: '500px', position: 'bottom-right'});
var WorldCover1 = ee.ImageCollection('ESA/WorldCover/v100').filterBounds(aoi).mosaic().updateMask(zones);
var WorldCover2 = ee.ImageCollection('ESA/WorldCover/v200').filterBounds(aoi).mosaic().updateMask(zones);
var cover = WorldCover1.updateMask(WorldCover1.neq(40)).updateMask(WorldCover1.neq(50)).updateMask(WorldCover1.lte(60)).updateMask(WorldCover1.lte(70)).updateMask(WorldCover1.lte(80))
.updateMask(WorldCover2.neq(40)).updateMask(WorldCover2.neq(50)).updateMask(WorldCover2.lte(60)).updateMask(WorldCover2.lte(70)).updateMask(WorldCover2.lte(80));
function maskS2(x){return x.updateMask(x.neq(1)).updateMask(x.neq(7)).updateMask(x.neq(8)).updateMask(x.neq(9)).neq(0).selfMask()}
var ESRI_Global = ee.ImageCollection('projects/sat-io/open-datasets/landcover/ESRI_Global-LULC_10m_TS').filterBounds(aoi).map(maskS2).sum().gte(6).selfMask().updateMask(zones).rename('ESRI_Global');
function maskProba(x){return x.updateMask(x.neq(0)).updateMask(x.neq(40)).updateMask(x.neq(50)).updateMask(x.neq(70)).updateMask(x.neq(80)).updateMask(x.neq(200)).neq(0)} 
var COPERNICUS_LC = ee.ImageCollection("COPERNICUS/Landcover/100m/Proba-V-C3/Global").select('discrete_classification').map(maskProba).sum().eq(5).selfMask().updateMask(zones).rename('COPERNICUS_LC'); 
var burnable = ESRI_Global.gt(0).selfMask().updateMask(cover.gt(0)).updateMask(COPERNICUS_LC).rename('burnable');
var nonBurnable = ee.ImageCollection([zones.neq(0).rename('burnable'), burnable.neq(1)]).mosaic().eq(1).selfMask();
function addBands(x){var x = x.updateMask(zones);// https://www.weather.gov/media/epz/wxcalc/vaporPressure.pdf
var air_temp = x.select('Maximum_temperature_height_above_ground_6_Hour_Interval').updateMask(zones).subtract(273.15).rename('Temperatura Máxima C');
var specific_humidity = x.select('Minimum_specific_humidity_at_2m_height_above_ground_6_Hour_Interval').updateMask(zones).multiply(1000);
var saturation_point = ee.Image.constant(10).pow((air_temp.multiply(7.5)).divide(air_temp.add(237.3))).multiply(6.11);
var Relative_Humidity_min = specific_humidity.divide(saturation_point).multiply(100).rename('Humedad Relativa Mínima %');
var u = x.select('u-component_of_wind_height_above_ground').updateMask(zones);	
var v = x.select('v-component_of_wind_height_above_ground').updateMask(zones);
var WIND = ((u.pow(2).add(v.pow(2))).sqrt()).multiply(3.6).rename('Velocidad Viento km/h promedio 6h');
// https://a.atmos.washington.edu/wrfrt/descript/definitions/fosbergindex.html
var T = air_temp.multiply(9/5).add(32);     var h = Relative_Humidity_min;    var U = WIND.multiply(0.621371192);
var m1 = (h.multiply(0.281073).subtract(h.multiply(0.000578).multiply(T)).add(0.03229)).updateMask(Relative_Humidity_min.lt(10));
var m2 = (h.multiply(0.160107).subtract(T.multiply(0.01478)).add(2.22749)).updateMask(Relative_Humidity_min.gte(10)).updateMask(Relative_Humidity_min.lt(50));
var m3 = ((h.pow(2).multiply(0.005565)).subtract(h.multiply(T).multiply(0.00035)).subtract(h.multiply(0.483199)).add(21.0606)).updateMask(Relative_Humidity_min.gte(50));
var m = ee.ImageCollection([m1,m2,m3]).mosaic().rename('equilibrium_mositure_content');
m = m.divide(30);
var n = ee.Image(1).subtract(m.multiply(2)).add(m.pow(2).multiply(1.5)).subtract(m.pow(3).multiply(0.5)).rename('moisture_damping_coefficient');
var FFWI_max = n.multiply((U.pow(2).add(1)).pow(0.5)).divide(0.3002).rename('ffwi');
return x.addBands(FFWI_max).select('ffwi');}
var CFSV2 = ee.ImageCollection("NOAA/CFSV2/FOR6H").filterDate('2016-01-01', ee.Date(Date.now())).filterDate(ee.Date(Date.now()).advance(-13, 'year'), ee.Date(Date.now())).filter(ee.Filter.calendarRange(12, 12,	'hour'))
.select('Minimum_specific_humidity_at_2m_height_above_ground_6_Hour_Interval','Maximum_temperature_height_above_ground_6_Hour_Interval','u-component_of_wind_height_above_ground','v-component_of_wind_height_above_ground').map(addBands);
var crs = 'EPSG:4326'; var scale = 22738.360990364246; var crsTransform = [0.20454520376789903, 0, -180.10227260188395, 0, -0.20442210122586923, 90];
var fwi_2000 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2000');  var fwi_2001 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2001');  var fwi_2002 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2002');  var fwi_2003 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2003');var fwi_2004 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2004');  var fwi_2005 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2005');  var fwi_2006 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2006');  var fwi_2007 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2007');var fwi_2008 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2008');  var fwi_2009 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2009');  var fwi_2010 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2010');  var fwi_2011 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2011');var fwi_2012 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2012');  var fwi_2013 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2013');  var fwi_2014 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2014');  var fwi_2015 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2015');var fwi_2016 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2016');  var fwi_2017 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2017');  var fwi_2018 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2018');  var fwi_2019 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2019');  var fwi_2020 = ee.Image('users/andreinomarcolino/era5-land-SAR-fwi-2020');
var fwi_2000_2020 = ee.ImageCollection.fromImages([fwi_2008, fwi_2009, fwi_2010, fwi_2011, fwi_2012, fwi_2013, fwi_2014, fwi_2015, fwi_2016, fwi_2017, fwi_2018, fwi_2019, fwi_2020]).toBands();
var bandList = fwi_2000_2020.bandNames();
var datedCollection1 = ee.ImageCollection(bandList.map(
function(name) {var img = fwi_2000_2020.select([name]);
var year = ee.Number.parse(ee.String(name).split('_').get(0));
var julday = ee.Number.parse(ee.String(name).split('_b').get(1)).subtract(1);
var date = ee.Date.fromYMD(2000, 1, 1).advance(year, 'year').advance(julday, 'day');
return img.set('system:time_start', date.millis(), 'human_readable_date', date)}));
function rename1(x) {return x.updateMask(x.gte(0)).rename('fwi')}	  
var fwi = datedCollection1.map(rename1);
var bi_2000 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2000');  var bi_2001 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2001');  var bi_2002 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2002');  var bi_2003 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2003');var bi_2004 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2004');  var bi_2005 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2005');  var bi_2006 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2006');  var bi_2007 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2007');var bi_2008 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2008');  var bi_2009 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2009');  var bi_2010 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2010');  var bi_2011 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2011');var bi_2012 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2012');  var bi_2013 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2013');  var bi_2014 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2014');  var bi_2015 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2015');var bi_2016 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2016');  var bi_2017 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2017');  var bi_2018 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2018');  var bi_2019 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2019');  var bi_2020 = ee.Image('users/andreinomarcolino/era5-land-SAR-bi-2020');
var bi_2000_2020 = ee.ImageCollection.fromImages([bi_2008, bi_2009, bi_2010, bi_2011, bi_2012, bi_2013, bi_2014, bi_2015, bi_2016, bi_2017, bi_2018, bi_2019, bi_2020]).toBands();
var bandList = bi_2000_2020.bandNames();
var datedCollection2 = ee.ImageCollection(bandList.map(
function(name) {var img = bi_2000_2020.select([name]);
var year = ee.Number.parse(ee.String(name).split('_').get(0));
var julday = ee.Number.parse(ee.String(name).split('_b').get(1)).subtract(1);
var date = ee.Date.fromYMD(2000, 1, 1).advance(year, 'year').advance(julday, 'day');
return img.set('system:time_start', date.millis(), 'human_readable_date', date)}));
function rename2(x) {return x.updateMask(x.gte(0)).rename('bi')}	  
var bi = datedCollection2.map(rename2);
var erc_2000 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2000');  var erc_2001 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2001');  var erc_2002 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2002');  var erc_2003 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2003');var erc_2004 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2004');  var erc_2005 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2005');  var erc_2006 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2006');  var erc_2007 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2007');var erc_2008 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2008');  var erc_2009 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2009');  var erc_2010 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2010');  var erc_2011 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2011');var erc_2012 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2012');  var erc_2013 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2013');  var erc_2014 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2014');  var erc_2015 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2015');var erc_2016 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2016');  var erc_2017 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2017');  var erc_2018 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2018');  var erc_2019 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2019');  var erc_2020 = ee.Image('users/andreinomarcolino/era5-land-SAR-erc-2020');
var erc_2000_2020 = ee.ImageCollection.fromImages([erc_2008, erc_2009, erc_2010, erc_2011, erc_2012, erc_2013, erc_2014, erc_2015, erc_2016, erc_2017, erc_2018, erc_2019, erc_2020]).toBands();
var bandList = erc_2000_2020.bandNames();
var datedCollection3 = ee.ImageCollection(bandList.map(
function(name) {var img = erc_2000_2020.select([name]);
var year = ee.Number.parse(ee.String(name).split('_').get(0));
var julday = ee.Number.parse(ee.String(name).split('_b').get(1)).subtract(1);
var date = ee.Date.fromYMD(2000, 1, 1).advance(year, 'year').advance(julday, 'day');
return img.set('system:time_start', date.millis(), 'human_readable_date', date)}));
function rename3(x) {return x.updateMask(x.gte(0)).rename('erc')}	  
var erc = datedCollection3.map(rename3);
var kbdi_2000 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2000');  var kbdi_2001 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2001');  var kbdi_2002 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2002');  var kbdi_2003 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2003');var kbdi_2004 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2004');  var kbdi_2005 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2005');  var kbdi_2006 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2006');  var kbdi_2007 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2007');var kbdi_2008 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2008');  var kbdi_2009 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2009');  var kbdi_2010 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2010');  var kbdi_2011 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2011');var kbdi_2012 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2012');  var kbdi_2013 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2013');  var kbdi_2014 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2014');  var kbdi_2015 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2015');var kbdi_2016 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2016');  var kbdi_2017 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2017');  var kbdi_2018 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2018');  var kbdi_2019 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2019');  var kbdi_2020 = ee.Image('users/andreinomarcolino/era5-land-SAR-kbdi-2020');
var kbdi_2000_2020 = ee.ImageCollection.fromImages([kbdi_2008, kbdi_2009, kbdi_2010, kbdi_2011, kbdi_2012, kbdi_2013, kbdi_2014, kbdi_2015, kbdi_2016, kbdi_2017, kbdi_2018, kbdi_2019, kbdi_2020]).toBands();
var bandList = kbdi_2000_2020.bandNames();
var datedCollection4 = ee.ImageCollection(bandList.map(
function(name) {var img = kbdi_2000_2020.select([name]);
var year = ee.Number.parse(ee.String(name).split('_').get(0));
var julday = ee.Number.parse(ee.String(name).split('_b').get(1)).subtract(1);
var date = ee.Date.fromYMD(2000, 1, 1).advance(year, 'year').advance(julday, 'day');
return img.set('system:time_start', date.millis(), 'human_readable_date', date)}));
function rename4(x) {return x.updateMask(x.gte(0)).rename('kbdi')}	  
var kbdi = datedCollection4.map(rename4);
var sc_2000 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2000');  var sc_2001 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2001');  var sc_2002 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2002');  var sc_2003 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2003');var sc_2004 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2004');  var sc_2005 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2005');  var sc_2006 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2006');  var sc_2007 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2007');var sc_2008 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2008');  var sc_2009 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2009');  var sc_2010 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2010');  var sc_2011 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2011');var sc_2012 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2012');  var sc_2013 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2013');  var sc_2014 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2014');  var sc_2015 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2015');var sc_2016 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2016');  var sc_2017 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2017');  var sc_2018 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2018');  var sc_2019 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2019');  var sc_2020 = ee.Image('users/andreinomarcolino/era5-land-SAR-sc-2020');
var sc_2000_2020 = ee.ImageCollection.fromImages([sc_2000, sc_2001, sc_2002, sc_2003, sc_2004, sc_2005, sc_2006, sc_2007, sc_2008, sc_2009, sc_2010, sc_2011, sc_2012, sc_2013, sc_2014, sc_2015, sc_2016, sc_2017, sc_2018, sc_2019, sc_2020]).toBands();
var bandList = sc_2000_2020.bandNames();
function SC(x){return x.addBands(x.select('bi').divide(3.01).pow(1/0.46).divide(x.select('erc')).rename('sc'))}
var innerJoin = ee.Join.inner();  var filterTimeEq = ee.Filter.equals({leftField: 'system:time_start',rightField: 'system:time_start'});
var innerJoined = innerJoin.apply(fwi, erc, filterTimeEq);             var COLLECTION = ee.ImageCollection(innerJoined.map(function(feature) {return ee.Image.cat(feature.get('primary'), feature.get('secondary'));})); 
var innerJoined = innerJoin.apply(COLLECTION, bi, filterTimeEq);       var COLLECTION = ee.ImageCollection(innerJoined.map(function(feature) {return ee.Image.cat(feature.get('primary'), feature.get('secondary'));})); 
var innerJoined = innerJoin.apply(COLLECTION, fwi, filterTimeEq);      var COLLECTION = ee.ImageCollection(innerJoined.map(function(feature) {return ee.Image.cat(feature.get('primary'), feature.get('secondary'));})); 
var innerJoined = innerJoin.apply(COLLECTION, kbdi, filterTimeEq);     var COLLECTION = ee.ImageCollection(innerJoined.map(function(feature) {return ee.Image.cat(feature.get('primary'), feature.get('secondary'));})); 
COLLECTION = ee.ImageCollection(COLLECTION).filterDate('2009-01-01', '2021-01-01').map(SC);
Map.onClick(function(coords) {
var point = ee.Geometry.Point(coords.lon, coords.lat);    
var value = ee.Number(zones.clip(point).reduceRegion({reducer: ee.Reducer.mean(),geometry: point,  bestEffort:true}).get('constant'));
var zone = zones.eq(value).selfMask().reduceToVectors(ee.Reducer.countEvery(), aoi, 1000, 'polygon');
var aoi = zone.geometry().bounds();
Map.layers().set(2, ui.Map.Layer(ee.Image().byte().paint({'featureCollection': zone, 'color': 1, 'width': 2}).visualize({'palette': 'black'}),{},'Zona siendo analizada'));
// Map.layers().set(4, ui.Map.Layer(MODIS.count(),{min:1, max: 8, palette:['yellow','orange','red','darkred']},'Área Quemada desde 2016 (MCD64A1)'));
function maskZone(x){return x.updateMask(zones.eq(value).selfMask())}
var chart0 = ui.Chart.image.doySeries(COLLECTION.select('erc').map(maskZone), aoi, ee.Reducer.mean(), scale).setChartType('AreaChart').setOptions({hAxis: {title: 'Día del Año'}, vAxis: {title: 'Energy Release Component'}, height: '300px'});
var chart1 = ui.Chart.image.doySeries(COLLECTION.select('sc').map(maskZone), aoi, ee.Reducer.mean(), scale).setChartType('AreaChart').setOptions({position: 'top-left', hAxis: {title: 'Día del Año'}, vAxis: {title: 'Spread Component'}, height: '300px'});
var chart2 = ui.Chart.image.doySeries(COLLECTION.select('bi').map(maskZone), aoi, ee.Reducer.mean(), scale).setChartType('AreaChart').setOptions({hAxis: {title: 'Día del Año'}, vAxis: {title: 'Burn Index'}, height: '300px'});
var chart3 = ui.Chart.image.doySeries(COLLECTION.select('fwi').map(maskZone), aoi, ee.Reducer.mean(), scale).setChartType('AreaChart').setOptions({hAxis: {title: 'Día del Año'}, vAxis: {title: 'Fire Weather Index'}, height: '300px'});
var chart4 = ui.Chart.image.doySeries(COLLECTION.select('kbdi').map(maskZone), aoi, ee.Reducer.mean(), scale).setChartType('AreaChart').setOptions({hAxis: {title: 'Día del Año'}, vAxis: {title: 'Keetch-Byram Drought Index'}, height: '300px'});
var chart5 = ui.Chart.image.doySeries(CFSV2.map(maskZone), aoi, ee.Reducer.mean(), CFSV2.first().projection().nominalScale()).setChartType('AreaChart').setOptions({hAxis: {title: 'Día del Año'}, vAxis: {title: 'Fosberg Fire Weather Index'}, height: '300px'});
function maskZoneburnable(x){return x.updateMask(zones.eq(value).selfMask()).updateMask(burnable)}
var chart6 = ui.Chart.image.doySeriesByYear({imageCollection: Burned.map(maskZoneburnable), bandName: 'Hectáreas Quemadas', region:aoi, regionReducer:ee.Reducer.sum(), scale:ee.ImageCollection("MODIS/061/MCD64A1").select('BurnDate').first().projection().nominalScale(), startDay:0, endDay:365})
.setOptions({title: 'Área Non-Agrícola Quemada Mensual (fuente: MCD64A1)',hAxis: {max: 365, title: 'Día del Año'},vAxis: {title: 'Hectáreas Quemadas'}, height: '300px'}).setChartType('ScatterChart');
function maskZonenonBurnable(x){return x.updateMask(zones.eq(value).selfMask()).updateMask(nonBurnable)}
var chart7 = ui.Chart.image.doySeriesByYear({imageCollection: Burned.map(maskZonenonBurnable), bandName: 'Hectáreas Quemadas', region:aoi, regionReducer:ee.Reducer.sum(), scale:ee.ImageCollection("MODIS/061/MCD64A1").select('BurnDate').first().projection().nominalScale(), startDay:0, endDay:365})
.setOptions({title: 'Área Agrícola Quemada Mensual (fuente: MCD64A1)',hAxis: {max: 365, title: 'Día del Año'},vAxis: {title: 'Hectáreas Quemadas'}, height: '300px'}).setChartType('ScatterChart');
panelChart.widgets().set(0, chart0).set(1, chart1).set(2, chart2).set(3, chart3).set(4, chart4).set(5, chart5).set(6, chart6).set(7, chart7);
}); 
ui.root.insert(0,panel);
panel.add(title1).add(title2).add(source).add(panelChart);
//    Legend2
var dict1 = {"names": ['Costa Manglares','Costa Sur','Costa Centro','Cordillera Norte','Cordillera Centro','Amazonia Sur/Norte','Costa Norte','Bosque Andino Seco Sur','Galapagos'],
"colors": ['#191970','#00FFFF','#8B0000','#D27D2D','#DFFF00','#F4BB44','#93C572','#BF40BF','#DC143C']};
var legend = ui.Panel({style: {width: '210px', position: 'bottom-left',padding: '8px 15px'}});
function addCategoricalLegend2(panel, dict1, title) {
var legendTitle = ui.Label({value: title,style: {fontWeight: 'bold',fontSize: '14px',margin: '0 0 4px 0',padding: '0', fontFamily:'Dinot'}});
panel.add(legendTitle);
var makeRow = function(color, name) {var colorBox = ui.Label({style: {backgroundColor: color,padding: '8px',margin: '0 0 4px 0', fontFamily:'Dinot',fontSize: '14px'}});
var description = ui.Label({value: name,style: {margin: '0 0 4px 6px', fontFamily:'Dinot',fontSize: '14px'}});
return ui.Panel({widgets: [colorBox, description],layout: ui.Panel.Layout.Flow('horizontal')});};
var palette = dict1.colors;
var names = dict1.names;
for (var i = 0; i < names.length; i++) {panel.add(makeRow(palette[i], names[i]));}
Map.add(panel);}
addCategoricalLegend2(legend, dict1, 'Zonificación Ecuador');
Map.addLayer(zones, {min:1,max:9, palette: ['#191970','#00FFFF','#8B0000','#D27D2D','#DFFF00','#F4BB44','#93C572','#BF40BF','#DC143C']},'Zonificación');
var oeel=require('users/OEEL/lib:loadAll');
Map.addLayer(oeel.Map.scaleLayer({mapScale:Map.getScale(),point: scaleBar, direction:'left'}),{},'Scale Bar');
var widget=oeel.Map.symbol({symbol:'compass', fontWeight: 'bold', colorFont:'FFCB00', colorSymbol1:'007432', colorSymbol2:'FFCB00'});
widget.style().set({position:'top-left'});
Map.add(widget);
/**/