var Beni = ui.import && ui.import("Beni", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -68.0036626595184,
                -9.992779092521596
              ],
              [
                -68.0036626595184,
                -16.743652580160006
              ],
              [
                -60.90649469076839,
                -16.743652580160006
              ],
              [
                -60.90649469076839,
                -9.992779092521596
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-68.0036626595184, -9.992779092521596],
          [-68.0036626595184, -16.743652580160006],
          [-60.90649469076839, -16.743652580160006],
          [-60.90649469076839, -9.992779092521596]]], null, false),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -81.08576943765924,
                1.5638449275507478
              ],
              [
                -81.08576943765924,
                -5.108865063214546
              ],
              [
                -75.04328896890924,
                -5.108865063214546
              ],
              [
                -75.04328896890924,
                1.5638449275507478
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-81.08576943765924, 1.5638449275507478],
          [-81.08576943765924, -5.108865063214546],
          [-75.04328896890924, -5.108865063214546],
          [-75.04328896890924, 1.5638449275507478]]], null, false);
Map.setOptions('HYBRID');
Map.setControlVisibility({zoomControl: false, mapTypeControl: false, drawingToolsControl: false})
var generalZoom = 6;
var currentZoom = 16;
var timeZone = 'America/La_Paz';
var BUTTON_WIDTH = '90px';
var backgroundColor = 'rgba(255, 255, 255, 0)';
// var AOI = ee.FeatureCollection('users/anmarkos/LIMITES/SCZ_Municipios');
// var AOI = ee.FeatureCollection('users/anmarkos/FIRE/ECUADOR/adm1_INEC_2019').select('admin2Name').filterBounds(geometry);
// var AOI = ee.FeatureCollection('users/anmarkos/FIRE/PERU/OLLANTAYTAMBO/dir_8_13_93_shape').select('system:index');
var AOI = ee.FeatureCollection('users/anmarkos/CLIM_D/Bolivia').filter(ee.Filter.neq('mun','NA'))
// var AOI = ee.FeatureCollection("WM/geoLab/geoBoundaries/600/ADM2").filter(ee.Filter.eq('shapeGroup','ITA'))
var borders = ee.Image().byte().paint({featureCollection: AOI, color: 1, width: 2})//.clip(Beni);
var roi = AOI.union(10)//.filter(ee.Filter.eq('dep','Beni')).merge(AOI.filter(ee.Filter.eq('dep','Pando')))
// .merge(AOI.filter(ee.Filter.eq('dep','Santa Cruz'))).merge(AOI.filter(ee.Filter.eq('dep','Cochabamba'))).merge(AOI.filter(ee.Filter.eq('dep','Tarija'))).union(10)
var mask = ee.Image(1).clip(AOI);
var CONTACTO = ui.Label({value: 'contacto', style: {fontStyle:'bold', position: "top-right"}, 
targetUrl: 'https://www.linkedin.com/in/andrea-markos-9604359/'});
// Función para centrar el mapa en una ubicación
function centerMapToLocation(location, zoom) {Map.centerObject(location, zoom);
Closebut_ubicacion.style().set('shown', true); button_ubicacion.style().set('shown', true)}
// Botón para centrar en la vista general
var Closebut_ubicacion = ui.Button({label: 'Vista general',
style: {position: 'top-right',color: 'black',backgroundColor: backgroundColor,margin: '0px',padding: '0px',width: BUTTON_WIDTH},
onClick: function() {centerMapToLocation(roi, generalZoom)}});
// Botón para centrar en la ubicación actual
var button_ubicacion = ui.Button({label: 'Su ubicación 📍',
style: {position: 'top-right',color: 'black',backgroundColor: backgroundColor,margin: '0px',padding: '0px',width: BUTTON_WIDTH},
onClick: function() {ui.util.getCurrentPosition(current_position, 1);
function current_position(point) {Map.centerObject(point, currentZoom);
var layer_100 = ui.Map.Layer(point, {}, 'Ubicación actual', true);
Map.layers().set(100, layer_100);                // Agrega la capa de ubicación actual en la posición 8
Closebut_ubicacion.style().set('shown', true);  button_ubicacion.style().set('shown', true)}}});
var GOES = ee.ImageCollection("NOAA/GOES/19/FDCF").filterDate(ee.Date(Date.now()).advance(-24,'hour'),ee.Date(Date.now()))
var last = GOES.sort('system:time_start',false).first().date().aside(print)
var imgGOES = GOES.filterDate(last.advance(-48,'hour'), last)
.map(function(x){return x.select('Power').updateMask(mask).updateMask(x.select('Power').gt(0))}).sum()
.visualize({min:0,max:40000,palette:['orange','red','darkred'],opacity:0.8});
var imgVIIRS = ee.ImageCollection("NASA/LANCE/NOAA20_VIIRS/C2")
.merge(ee.ImageCollection("NASA/LANCE/SNPP_VIIRS/C2")).select('frp')
.merge(ee.ImageCollection("NASA/VIIRS/002/VNP14A1").select('MaxFRP'))
.filterDate(last.advance(-48,'hour'), last)
.map(function(x){return x.updateMask(mask).updateMask(x.gt(0))}).sum()
.visualize({min:0,max:4000,palette:['orange','red','darkred'],opacity:0.8});
var imgMODIS = ee.ImageCollection("FIRMS").select('T21')
.filterDate(last.advance(-48,'hour'), last)
.map(function(x){return x.updateMask(mask).updateMask(x.gt(0))}).sum()
.visualize({min:0,max:4000,palette:['orange','red','darkred'],opacity:0.8});
var CLOUD_t = 100;         
var inicio = ee.Date(Date.now()).advance(-6,'day');   var fin =  ee.Date(Date.now());
function addNFI(x){var NFI = x.expression("B12/B8", {B12: x.select("B12"), B8: x.select("B8")}).rename('NFI');  return x.addBands(NFI)}
// function addNFI(x){var NFI = x.normalizedDifference(['B12','B8']).rename('NFI');  return x.addBands(NFI)}
function sel_S2(x) {return x.select(['B12', 'B11', 'B8', 'B4', 'B3']).updateMask(mask).float().set('system:time_start', x.get('system:time_start'))}
function ren_L9(x) {return x.select(['B7', 'B6', 'B5', 'B4', 'B3']).rename(['B12', 'B11', 'B8', 'B4', 'B3']).updateMask(mask).float().multiply(15000).set('system:time_start', x.get('system:time_start'))}
function ren_L8(x) {return x.select(['B7', 'B6', 'B5', 'B4', 'B3']).rename(['B12', 'B11', 'B8', 'B4', 'B3']).updateMask(mask).float().multiply(15000).set('system:time_start', x.get('system:time_start'))}
function ren_L7(x) {return x.select(['B7', 'B5', 'B4', 'B3', 'B2']).rename(['B12', 'B11', 'B8', 'B4', 'B3']).updateMask(mask).float().set('system:time_start', x.get('system:time_start'))}
var S2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED').filterBounds(roi).filterDate(inicio, fin).filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", CLOUD_t)).map(sel_S2);
var L9 = ee.ImageCollection("LANDSAT/LC09/C02/T1_TOA").filterBounds(roi).filterDate(inicio, fin).filterMetadata('CLOUD_COVER', 'less_than', CLOUD_t).map(ren_L9);
var L8 = ee.ImageCollection("LANDSAT/LC08/C02/T1_TOA").filterBounds(roi).filterDate(inicio, fin).filterMetadata('CLOUD_COVER', 'less_than', CLOUD_t).map(ren_L8);
var L7 = ee.ImageCollection("LANDSAT/LE07/C02/T1_TOA").filterBounds(roi).filterDate(inicio, fin).filterMetadata('CLOUD_COVER', 'less_than', CLOUD_t).map(ren_L7);
var crs = S2.first().select('B8').projection();  var scale = crs.nominalScale();
var col = (S2.merge(L7).merge(L8).merge(L9)).sort('system:time_start').map(addNFI);
var qualityMosaic = col.select(['B12','B8','B4','NFI']).qualityMosaic('NFI').select(['B12','B8','B4']);
var viz = {bands:['B12','B8','B4'], min:500,max:6500, opacity:0.9};
Map.centerObject(roi, generalZoom);
Map.addLayer(qualityMosaic,viz,'Mosaico 6 días');
Map.addLayer(imgVIIRS,{},'48h VIIRS');
Map.addLayer(imgGOES,{},'48h GOES-19');
Map.addLayer(borders,{palette: 'magenta'},'Límites Administrativos');
Map.add(button_ubicacion);  Map.add(Closebut_ubicacion); Map.add(CONTACTO);
var vis = {min: '0 MW', max: '50k MW', palette: ['orange','red','darkred']};
function makeColorBarParams(palette) {return {bbox: [0, 0, 1, 0.1],dimensions: '100x10',format: 'png',min: 0,max: 1,palette: palette}}
var colorBar = ui.Thumbnail({image: ee.Image.pixelLonLat().select(0),params: makeColorBarParams(vis.palette),
style: {stretch: 'horizontal', margin: '0px 0px', maxHeight: '20px'}});
var legendLabels = ui.Panel({widgets: [
// ui.Label(vis.min, {margin: '0px 0px'}),              
// ui.Label('25k MW',{margin: '0px 0px', textAlign: 'center', stretch: 'horizontal'}),  
// ui.Label(vis.max, {margin: '0px 0px'})
],layout: ui.Panel.Layout.flow('horizontal')});      
var legendTitle = ui.Label('Intensidad Incendios últimas 48h hasta las '+ last.format({timeZone: timeZone, format: 'HH:mm'}).getInfo(), {color: 'black',backgroundColor: backgroundColor,margin: '0px',padding: '0px'})
var legendPanel = ui.Panel({ style: { position: "bottom-center" } });
Map.add(legendPanel.add(legendTitle).add(colorBar));// contact
Map.addLayer(imgMODIS,{},'48h MODIS');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuenca_San_Javier'), color: 1, width: 2}),{palette: 'cyan'},'Cuenca_San_Javier');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuenca_S_Rafael'), color: 1, width: 2}),{palette: 'cyan'},'Cuenca_S_Rafael');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuenca_Marfil'), color: 1, width: 2}),{palette: 'cyan'},'Cuenca_Marfil');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuenca_RG_SUB_A'), color: 1, width: 2}),{palette: 'cyan'},'Cuenca_RG_SUB_A');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuenca_Zapoco'), color: 1, width: 2}),{palette: 'cyan'},'Cuenca_Zapoco');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuencas_Robore'), color: 1, width: 2}),{palette: 'cyan'},'Cuencas_Robore');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuenca_San_Ramon'), color: 1, width: 2}),{palette: 'cyan'},'Cuenca_San_Ramon');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuenca_San_Miguel'), color: 1, width: 2}),{palette: 'cyan'},'Cuenca_San_Miguel');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuenca_San_Jose'), color: 1, width: 2}),{palette: 'cyan'},'Cuenca_San_Jose');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuenca_Concepcion'), color: 1, width: 2}),{palette: 'cyan'},'Cuenca_Concepcion');
// Map.addLayer(ee.Image().byte().paint({featureCollection:ee.FeatureCollection('users/anmarkos/CUENCAS/Cuenca_San_Ignacio'), color: 1, width: 2}),{palette: 'cyan'},'Cuenca_San_Ignacio');
/**/