var PLUS = ee.FeatureCollection('projects/ee-tomichita1/assets/MOXOS/PLUS_Beni').union(10);
var image1 = ee.Image('users/anmarkos/MOXOS/LC_2050_L')
var image2 = ee.Image('users/anmarkos/MOXOS/LC_2050_CC_L')
// var image3 = ee.Image('users/anmarkos/MOXOS/LC_2050_CC_L_X')
var image3 = ee.Image('users/anmarkos/MOXOS/LCLU_2050_CC').updateMask(image2.neq(-99))
var LCLU_2024 = ee.Image('users/anmarkos/MOXOS/LCLU_2024').rename('classification').updateMask(image2.neq(-99))
// var visCaminos = {palette:'black'}
var backgroundColor = '#FFEFD5';
var palette1= ['0000FF','00FFFF','006400','008B8B','FFFF00','9ACD32','FFC0CB','FF0000','000000','696969']
var visParams1 = {min:0,max:9, palette:palette1};
var names1 = ['0 Agua','1 Vegetación flotante','2 Bosque','3 Bosque Inundable','4 Pastizal, Uso Ganadero Extensivo','5 Pastizal Inundable, Ganadero Ext','6 Pastizal Manejado, Gan Semi-Int','7 Agrícola Intensivo','8 Urbano, infraestructura','9 Minería'];
var panel1 = ui.Panel({style: {width: '340px', position: 'bottom-right',padding: '8px 15px', backgroundColor: backgroundColor}});
var titulopanel1 = ui.Label({value: 'Cobertura y Uso del Suelo', style: {fontWeight: 'bold', fontSize: '26px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
panel1=panel1.add(titulopanel1)
var makeRow1 = function(color, name) {
var colorBox = ui.Label({style: {backgroundColor: '#' + color,padding: '15px',margin: '0 0 4px 0'}});
var description = ui.Label({value: name,style: {margin: '0 0 4px 6px', fontSize: '17px', backgroundColor: backgroundColor}});
return ui.Panel({widgets: [colorBox, description], style: {backgroundColor: backgroundColor}, layout: ui.Panel.Layout.Flow('horizontal')})};
for (var i = 0; i < 10; i++) {panel1.add(makeRow1(palette1[i], names1[i]));} 
// var palette2 = ['FF0000','FFA500','FFFFFF','008000','006400']
// var visParams2 = {min:0,max:5, palette:palette2};
// var names2 = ['Degradando significativamente','Potencialmente degradando','Sin cambio significativo','Potencialmente mejorando','Mejorando significativamente'];
// var panel2 = ui.Panel({style: {width: '340px', position: 'bottom-right',padding: '8px 15px', backgroundColor: backgroundColor}});
// var titulopanel2 = ui.Label({value: 'Tendencia PPN y ET (2014-24)', style: {fontWeight: 'bold', fontSize: '22px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
// panel2=panel2.add(titulopanel2)
// var makeRow2 = function(color, name) {
// var colorBox = ui.Label({style: {backgroundColor: '#' + color,padding: '15px',margin: '0 0 4px 0'}});
// var description = ui.Label({value: name,style: {margin: '0 0 4px 6px', fontSize: '17px', backgroundColor: backgroundColor}});
// return ui.Panel({widgets: [colorBox, description], style: {backgroundColor: backgroundColor}, layout: ui.Panel.Layout.Flow('horizontal')})};
// for (var i = 0; i < 5; i++) {panel2.add(makeRow2(palette2[i], names2[i]));} 
// Create map widgets for each image
var map1 = ui.Map()
.setOptions('HYBRID').setControlVisibility({all: false, layerList: true});
map1.addLayer(LCLU_2024, visParams1, 'Cobertura y Uso 2024')
map1.setCenter(-64.5580032336299,-13.796525157186803, 7)
map1.add(ui.Label('Año 2024', {position: "top-left"}))
var map2 = ui.Map()
.setOptions('HYBRID').setControlVisibility({all: false, layerList: true});
map2.addLayer(image2, visParams1, '2050 por cambio clímático y drivers geográficos')
map2.addLayer(image1, visParams1, '2050 por drivers geográficos')
map2.addLayer(image3, visParams1, '2050 por cambio clímático')
map2.setCenter(-64.5580032336299,-13.796525157186803, 7)
map2.add(panel1)//.add(panel2)
map2.add(ui.Label('Año 2050: drivers Geográficos y Clímáticos', {position: "top-right"}))
// Link the maps for synchronized zooming and panning
ui.Map.Linker([map1, map2]);
// Create a split panel to display both maps side by side
var splitPanel = ui.SplitPanel({firstPanel: map1, secondPanel: map2, orientation: 'horizontal', wipe: true});
// Clear the default UI and add the split panel
ui.root.clear();
ui.root.add(splitPanel);
/**/