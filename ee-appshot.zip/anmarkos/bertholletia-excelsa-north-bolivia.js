var scaleBar = ui.import && ui.import("scaleBar", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.8853448624877,
            -13.782872182072344
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([-64.8853448624877, -13.782872182072344]);
Map.setOptions('HYBRID');
var palette= ['#00FFFF','#FF1493'];
var Castaña1 = ee.Image('users/anmarkos/CASTANHA/Castanha_995_2024_06_03');
var Castaña2 = ee.Image('users/anmarkos/CASTANHA/Castanha_99_2024_06_03');
var Dis_Pot = ee.Image(1).clip(ee.FeatureCollection('users/anmarkos/CASTANHA/Dis_pot_castanha'));
Map.centerObject(Castaña1, 7.5);
Map.addLayer(Dis_Pot,{palette: 'white', opacity: 0.6},'Distribución Potencial');
Map.addLayer(Castaña1, {min:1,max:2, palette: palette},'Castaña, Prob. > 99,5%');
Map.addLayer(Castaña2, {min:1,max:2, palette: palette},'Castaña, Prob. > 99%');
Map.add(ui.Label({value: 'Bertholletia Excelsa (Brazil Nut) - Detección de Árboles de Castaña en el Norte de Bolivia.', style: {position: 'top-center', fontSize: '18x', fontWeight: 'bold', color:'black', backgroundColor:'white'}}));
//    Legend2
var dict1 = {"names": ['Árboles Pequeños','Árboles Grandes'], "colors": palette};
var legend = ui.Panel({style: {width: '225px', position: 'bottom-left',padding: '8px 15px'}});
function addCategoricalLegend2(panel, dict1, title) {
var legendTitle = ui.Label({value: title,style: {fontWeight: 'bold',fontSize: '18px',margin: '0 0 4px 0',padding: '0'}});
panel.add(legendTitle);
var makeRow = function(color, name) {var colorBox = ui.Label({style: {backgroundColor: color,padding: '12px',margin: '0 0 4px 0',fontSize: '18px'}});
var description = ui.Label({value: name,style: {margin: '0 0 4px 6px',fontSize: '18px'}});
return ui.Panel({widgets: [colorBox, description],layout: ui.Panel.Layout.Flow('horizontal')});};
var palette = dict1.colors;
var names = dict1.names;
for (var i = 0; i < names.length; i++) {panel.add(makeRow(palette[i], names[i]));}
Map.add(panel);}
addCategoricalLegend2(legend, dict1, 'Arboles de Castaña');
var oeel=require('users/OEEL/lib:loadAll');
Map.addLayer(oeel.Map.scaleLayer({mapScale:Map.getScale(),point: scaleBar, direction:'left'}),{},'Scale Bar');
var widget=oeel.Map.symbol({symbol:'compass', fontWeight: 'bold', colorFont:'FFFFFF', colorSymbol1:'000000', colorSymbol2:'FFFFFF'});
widget.style().set({position:'top-right'});
Map.add(widget);