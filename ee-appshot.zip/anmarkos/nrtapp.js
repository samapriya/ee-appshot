var table = ui.import && ui.import("table", "table", {
      "id": "users/anmarkos/MOXOS/AP_TIOC"
    }) || ee.FeatureCollection("users/anmarkos/MOXOS/AP_TIOC");
var lineaBase = ee.Image('users/anmarkos/MOXOS/rh98_01_2023');
var actual = ee.Image('users/anmarkos/MOXOS/rh98_06_2025');
Map.centerObject(actual);
Map.setOptions('HYBRID');
Map.setControlVisibility({zoomControl: false, mapTypeControl: false, drawingToolsControl: false});
var palette = ['ce7e45', 'df923d', 'f1b555', 'fcd163', '99b718', '74a901','66a000', '529400', '3e8601', '207401', '056201', '004c00', '023b01','012e01', '011d01', '011301'];
//  Add Color Bar
var vis = {min: '0m', max: '≥30m', palette: palette};
function makeColorBarParams(palette) {return {bbox: [0, 0, 1, 0.1],dimensions: '100x10',format: 'png',min: 0,max: 1,palette: palette,};}
var colorBar = ui.Thumbnail({image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(vis.palette),style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},});
var legendLabels = ui.Panel({widgets: [ui.Label(vis.min, {margin: '4px 8px'}),
    ui.Label(('15m'),{margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),ui.Label(vis.max, {margin: '4px 8px'})],
  layout: ui.Panel.Layout.flow('horizontal')});
var legendTitle = ui.Label({value: 'Altura del dosel de la vegetación a partir de datos satelitales con latencia de seis meses',style: {fontWeight: 'bold'}});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
var RAMSAR = ee.FeatureCollection('users/anmarkos/MOXOS/Sitios_Ramsar_Beni');
var ramsar1 = RAMSAR.filter(ee.Filter.eq('AREA_HA',2376572.19));
var ramsar2 = RAMSAR.filter(ee.Filter.eq('AREA_HA',1730437.97));
var ramsar3 = RAMSAR.filter(ee.Filter.eq('AREA_HA',2813215.39));
var MUN = ee.FeatureCollection('users/anmarkos/MOXOS/municipios339').filter(ee.Filter.eq('departamen','Beni'));
var Trinidad = MUN.filter(ee.Filter.eq('municipio','Trinidad'));
var San_Javier = MUN.filter(ee.Filter.eq('municipio','San Javier'));
var Riberalta = MUN.filter(ee.Filter.eq('municipio','Riberalta'));
var Guayaramerin = MUN.filter(ee.Filter.eq('municipio','Guayaramerín'));
var Reyes = MUN.filter(ee.Filter.eq('municipio','Reyes'));
var San_Borja = MUN.filter(ee.Filter.eq('municipio','San Borja'));
var Santa_Rosa = MUN.filter(ee.Filter.eq('municipio','Santa Rosa'));
var Puerto_Menor_de_Rurrenabaque = MUN.filter(ee.Filter.eq('municipio','Puerto Menor de Rurrenabaque'));
var Santa_Ana = MUN.filter(ee.Filter.eq('municipio','Santa Ana'));
var Exaltacion = MUN.filter(ee.Filter.eq('municipio','Exaltación'));
var Loreto = MUN.filter(ee.Filter.eq('municipio','Loreto'));
var San_Ignacio = MUN.filter(ee.Filter.eq('municipio','San Ignacio'));
var San_Andres = MUN.filter(ee.Filter.eq('municipio','San Andrés'));
var San_Joaquin = MUN.filter(ee.Filter.eq('municipio','San Joaquín'));
var San_Ramon = MUN.filter(ee.Filter.eq('municipio','San Ramón'));
var Puerto_Siles = MUN.filter(ee.Filter.eq('municipio','Puerto Siles'));
var Magdalena = MUN.filter(ee.Filter.eq('municipio','Magdalena'));
var Baures = MUN.filter(ee.Filter.eq('municipio','Baures'));
var Huacaraje = MUN.filter(ee.Filter.eq('municipio','Huacaraje'));
var APs = ee.FeatureCollection('users/anmarkos/MOXOS/Areas_protegidas_Beni');
var ANMI_Arroyo_Guarichona = APs.filter(ee.Filter.eq('nombre','ANMI Arroyo Guarichona'));
var ANMI_Pampas_del_Yacuma = APs.filter(ee.Filter.eq('nombre','ANMI Pampas del Yacuma'));
var APM_Ibare_Mamore = APs.filter(ee.Filter.eq('nombre','APM Ibare Mamore'));
var APM_Gran_Mojos = APs.filter(ee.Filter.eq('nombre','APM Gran Mojos'));
var APM_Grandes_Lagos_Tectónicos_de_Exaltación_Sin_gestión = APs.filter(ee.Filter.eq('nombre','APM Grandes Lagos Tectónicos de Exaltación'));
var APM_Rhukanrhuka = APs.filter(ee.Filter.eq('nombre','APM Rhukanrhuka'));
var APM_TCO_Tsimane_Río_Maniqui_Sin_gestión = APs.filter(ee.Filter.eq('nombre','APM-TCO Tsimane Río Maniqui'));
var Estación_Biológica_del_Beni = APs.filter(ee.Filter.eq('nombre','Estación Biológica del Beni'));
var Eva_Eva_Mosetenes_Sin_gestión = APs.filter(ee.Filter.eq('nombre','Eva Eva Mosetenes'));
var PDANMI_Iténez = APs.filter(ee.Filter.eq('nombre','PDANMI Iténez'));
var Lago_San_José = APs.filter(ee.Filter.eq('nombre','Lago San José'));
var Lago_Tumichucua = APs.filter(ee.Filter.eq('nombre','Lago Tumichucua'));
var Parque_Regional_Yacuma_Sin_gestión = APs.filter(ee.Filter.eq('nombre','Parque Regional Yacuma'));
var Parque_Regional_Pedro_Ignacio_Muiba_Sin_gestión = APs.filter(ee.Filter.eq('nombre','Parque Regional Pedro Ignacio Muiba'));
var PN_TCO_Isiboro_Sécure_TIPNIS = APs.filter(ee.Filter.eq('nombre','PN-TCO Isiboro Sécure (TIPNIS)'));
var RCEA_Kenneth_Lee = APs.filter(ee.Filter.eq('nombre','RCEA Kenneth Lee'));
var Reserva_de_la_Biosfera_y_TCO_Pilón_Lajas = APs.filter(ee.Filter.eq('nombre','Reserva de la Biosfera y TCO Pilón Lajas'));
var Reserva_Laney_Rickman_Armonia_Privada = APs.filter(ee.Filter.eq('nombre','Reserva Laney Rickman (Armonia)'));
var Reserva_Natural_de_Inmovilizacion_Yata_Sin_gestión = APs.filter(ee.Filter.eq('nombre','Reserva Natural de Inmovilizacion Yata'));
var RVS_Chuchini_Privada = APs.filter(ee.Filter.eq('nombre','RVS Chuchini'));
var RVS_Estancias_Elsner_Espiritu_Privada = APs.filter(ee.Filter.eq('nombre','RVS Estancias Elsner Espiritu'));
var RVS_San_Rafael_de_Monasterio_Privada = APs.filter(ee.Filter.eq('nombre','RVS San Rafael de Monasterio'));
var APM_GLTE_Propuesta = ee.FeatureCollection('users/anmarkos/MOXOS/0_APM_GLTE_Propuesta')
var Loma_Santa = ee.FeatureCollection('users/anmarkos/MOXOS/0_Loma_Santa')
var TIOCs = ee.FeatureCollection('users/anmarkos/MOXOS/TIOCs_Beni-Unif').select('TIOC').aside(print)
var TCO_Baure = TIOCs.filter(ee.Filter.eq('TIOC','TCO Baure'));
var TCO_Canichana = TIOCs.filter(ee.Filter.eq('TIOC','TCO Canichana'))
var TIOC_Cavineno = TIOCs.filter(ee.Filter.eq('TIOC','Territorio Indígena Cavineño'));
var TCO_Cayubaba = TIOCs.filter(ee.Filter.eq('TIOC','TCO Cayubaba')).merge(ee.FeatureCollection('users/anmarkos/MOXOS/0_Nuevos_titulos_Cybba'));
var TIOC_Chimane = TIOCs.filter(ee.Filter.eq('TIOC','Gran Concejo Chimane'));
var TIOC_PLajas = TIOCs.filter(ee.Filter.eq('TIOC','Consejo Regional T´simane Mosetenes (CRTM)-PLajas'));
var TCO_Itonama = TIOCs.filter(ee.Filter.eq('TIOC','TCO Itonama'));
var TCO_Joaquiniano = TIOCs.filter(ee.Filter.eq('TIOC','TCO Joaquiniano'));
var TCO_More = TIOCs.filter(ee.Filter.eq('TIOC','TCO Moré'));
var TCO_Movima = TIOCs.filter(ee.Filter.eq('TIOC','TCO Movima'));
var TCO_Movima_II = TIOCs.filter(ee.Filter.eq('TIOC','TCO Movima II'));
var Multiétnico_II = TIOCs.filter(ee.Filter.eq('TIOC','TCO Multiétnico II')).union(100)//.filter(ee.Filter.eq('ClaseTitul','Colectivo'));
// var Multiétnico = TIOCs.filter(ee.Filter.eq('TIOC','TCO Multiétnico II')).filter(ee.Filter.eq('ClaseTitul','Copropiedad'));
var TCO_Pacahuara = TIOCs.filter(ee.Filter.eq('TIOC','TCO Chácobo Pacahuara'));
var TIOC_Siriono = TIOCs.filter(ee.Filter.eq('TIOC','TCO SIrionó'));
var Tacana = TIOCs.filter(ee.Filter.eq('TIOC','TCO Tacana Cavineño'));
var Tacana_III = TIOCs.filter(ee.Filter.eq('TIOC','TCO Tacana III'));
var TIM = TIOCs.filter(ee.Filter.eq('TIOC','Territorio Indígena Multiétnico (TIM)'));
var TIMI = TIOCs.filter(ee.Filter.eq('TIOC','Territorio Indígena Moxeño Ignaciano (TIMI)'));
var TIPNIS = TIOCs.filter(ee.Filter.eq('TIOC','TIPNIS'));
var TIM_LY1497 = ee.FeatureCollection('users/anmarkos/MOXOS/0_TIM_LY1497')
var places = {
  'RAMSAR Río Blanco': ramsar1,
  'RAMSAR Río Matos': ramsar2,
  'RAMSAR Río Yata': ramsar3,
  'MUN Trinidad': Trinidad,
  'MUN San Javier': San_Javier,
  'MUN Riberalta': Riberalta,
  'MUN Guayaramerín': Guayaramerin,
  'MUN Reyes': Reyes,
  'MUN San Borja': San_Borja,
  'MUN Santa Rosa': Santa_Rosa,
  'MUN Rurrenabaque': Puerto_Menor_de_Rurrenabaque,
  'MUN Santa Ana': Santa_Ana,
  'MUN Exaltación': Exaltacion,
  'MUN Loreto': Loreto,
  'MUN San Ignacio': San_Ignacio,
  'MUN San Andrés': San_Andres,
  'MUN San Joaquín': San_Joaquin,
  'MUN San Ramón': San_Ramon,
  'MUN Puerto Siles': Puerto_Siles,
  'MUN Magdalena': Magdalena,
  'MUN Baures': Baures,
  'MUN Huacaraje': Huacaraje,
  'Área Protegida Indígena Loma Santa': Loma_Santa,
  'ANMI Arroyo Guarichona': ANMI_Arroyo_Guarichona,
  'ANMI Pampas del Yacuma': ANMI_Pampas_del_Yacuma,
  'APM Ibare Mamoré': APM_Ibare_Mamore,
  'APM Grandes Lagos Tectón. de Exaltación – Sin gestión': APM_Grandes_Lagos_Tectónicos_de_Exaltación_Sin_gestión,
  'APM Grandes Lagos Tectón. de Exaltación – Propuesta': APM_GLTE_Propuesta,
  'APM Gran Mojos': APM_Gran_Mojos,
  'APM Rhukanrhuka': APM_Rhukanrhuka,
  'APM TIOC Tsimane Río Maniqui – Sin gestión': APM_TCO_Tsimane_Río_Maniqui_Sin_gestión,
  'Estación Biológica del Beni': Estación_Biológica_del_Beni,
  'ZPCH Eva Eva Mosetenes (ANMI) – Sin gestión': Eva_Eva_Mosetenes_Sin_gestión,
  'PDANMI Iténez': PDANMI_Iténez,
  'AP Lago San José': Lago_San_José,
  'AP Lago Tumichucua': Lago_Tumichucua,
  'Parque Regional Yacuma – Sin gestión': Parque_Regional_Yacuma_Sin_gestión,
  'Parque Regional Pedro Ignacio Muiba – Sin gestión': Parque_Regional_Pedro_Ignacio_Muiba_Sin_gestión,
  // 'PN TIOC Isiboro Sécure TIPNIS': PN_TCO_Isiboro_Sécure_TIPNIS,
  'RCEA Kenneth Lee': RCEA_Kenneth_Lee,
  'Reserva de la Biosfera y TIOC Pilón Lajas': Reserva_de_la_Biosfera_y_TCO_Pilón_Lajas,
  'RVS Estancias Elsner Espíritu – Privada': Reserva_Laney_Rickman_Armonia_Privada,
  'Reserva Natural de Inmovilizacion Yata – Sin gestión': Reserva_Natural_de_Inmovilizacion_Yata_Sin_gestión,
  'RVS Chuchini – Privada': RVS_Chuchini_Privada,
  'RVS Estancias Elsner Espiritu – Privada': RVS_Estancias_Elsner_Espiritu_Privada,
  'RVS San Rafael de Monasterio – Privada': RVS_San_Rafael_de_Monasterio_Privada,
  'TIOC Baure': TCO_Baure,
  'TIOC Canichana': TCO_Canichana,
  'TIOC Cavineno': TIOC_Cavineno,
  'TIOC Cayubaba': TCO_Cayubaba,
  'TIOC Chimane': TIOC_Chimane,
  // 'TIOC P.Lajas': TIOC_PLajas,
  'TIOC Itonama': TCO_Itonama,
  'TIOC Joaquiniano': TCO_Joaquiniano,
  'TIOC Moré': TCO_More,
  'TIOC Movima': TCO_Movima,
  'TIOC Movima II': TCO_Movima_II,
  'TIOC Multiétnico II': Multiétnico_II,
  // 'Multiétnico': Multiétnico,
  'TIOC Pacahuara': TCO_Pacahuara,
  'TIOC Sirionó': TIOC_Siriono,
  'TIOC Tacana': Tacana,
  'TIOC Tacana III': Tacana_III,
  // 'TIM': TIM,
  'Territorio Indígena Multiétnico (TIM)':TIM_LY1497,
  'Territorio Indígena Mojeño Ignaciano (TIMI)': TIMI,
  'Territorio Indígena Parque Nacional Isiboro-Sécure (TIPNIS)': TIPNIS,
};
var backgroundColor = '#FFEFD5';
var palette1= ['FF0000','00FFFF','FFFFFF','000000'];
var visParams1 = {min:0,max:9, palette:palette1};
var names1 = ['Pérdida (quema, desmonte)','Ganancia (sucesión, etc.)','Bosque, sin cambio','No Bosque, sin cambio'];
var panel1 = ui.Panel({style: {width: '300px', position: 'bottom-left',padding: '8px 15px', backgroundColor: backgroundColor}});
var titulopanel1 = ui.Label({value: 'Cambios en el Dosel', style: {fontWeight: 'bold', fontSize: '26px', margin: '0 0 4px 0', padding: '0', backgroundColor: backgroundColor}});
panel1=panel1.add(titulopanel1);
var makeRow1 = function(color, name) {
var colorBox = ui.Label({style: {backgroundColor: '#' + color,padding: '15px',margin: '0 0 4px 0'}});
var description = ui.Label({value: name,style: {margin: '0 0 4px 6px', fontSize: '17px', backgroundColor: backgroundColor}});
return ui.Panel({widgets: [colorBox, description], style: {backgroundColor: backgroundColor}, layout: ui.Panel.Layout.Flow('horizontal')});
};
for (var i = 0; i < 4; i++) {panel1.add(makeRow1(palette1[i], names1[i]));}
var header1 = ui.Label('Click para ver hístorico', {fontSize: '28px', fontWeight: 'bold', color: '000000'});
var panel = ui.Panel({widgets:[legendPanel, panel1], style:{width: '320px',position:'middle-right'}});
var intro = ui.Panel([ui.Label({value:'HAGA CLIC EN EL MAPA PARA EL HÍSTORICO. Analice el histograma más actualizado de la distribución de la altura del dosel de cada área de interés desde el menú:', style: {fontSize: '14px', fontWeight: 'bold'}})]);
ui.root.insert(1,panel);
// Placeholder for the dynamically generated chart
var chartPanel = ui.Panel();
panel.add(intro).add(chartPanel); // Add the placeholder panel for charts
var select = ui.Select({
  items: Object.keys(places),
  onChange: function(key) {
    var selectedFeatureCollection = places[key];
    Map.centerObject(selectedFeatureCollection); // Center on the selected feature collection
Map.addLayer(selectedFeatureCollection.style({fillColor:"FF000000", color:"yellow",width: 2}),{}, key);
    // Clear previous chart
    chartPanel.clear();
    // Dynamically create the chart for the selected region
    var chart = ui.Chart.image.histogram({
        image: actual.clip(selectedFeatureCollection), // Image is already clipped to exact features
        region: selectedFeatureCollection.geometry().bounds(), // Use the bounding box for efficient region definition
        scale: 30,
        maxBuckets: 60,
        minBucketWidth: 0.5,
        maxRaw: 100,
        maxPixels: 1e9
    }).setChartType(['BarChart']).setOptions({
        title: key, // Use the key as the title
        vAxis: {title: 'Altura del dosel (m)'},
        hAxis: {title: 'Recuento pixeles 30*30m'}
    });
    chartPanel.add(chart);
  }
});
select.setPlaceholder('Seleccione aquí su área de interés:');
panel.insert(3, select); // Insert the select widget after the intro label
Map.addLayer(lineaBase.addBands(actual).addBands(actual), {min:0, max:30}, "Cambio 2023-2025");
Map.addLayer(lineaBase,{min:0, max:30, palette:palette},'01-2023', false);
Map.addLayer(ee.Image('users/anmarkos/MOXOS/rh98_06_2023'),{min:0, max:30, palette:palette},'06-2023', false);
Map.addLayer(ee.Image('users/anmarkos/MOXOS/rh98_01_2024'),{min:0, max:30, palette:palette},'01-2024', false);
Map.addLayer(ee.Image('users/anmarkos/MOXOS/rh98_06_2024'),{min:0, max:30, palette:palette},'06-2024', false);
Map.addLayer(ee.Image('users/anmarkos/MOXOS/rh98_01_2025'),{min:0, max:30, palette:palette},'01-2025', false);
Map.addLayer(actual,{min:0, max:30, palette:palette},'06-2025', false);
// Map.addLayer(MUN.style({fillColor:"FF000000", color:"magenta",width:1.5}),{},"MUNICIPIOS", false);
// Map.addLayer(RAMSAR.style({fillColor:"FF000000", color:"cyan",width:1.5}),{},"SITIOS RAMSAR", false);
// Map.addLayer(APs.style({fillColor:"FF000000", color:"red",width:1.5}),{},"ÁREAS PROTEGIDAS", false);
// Map.addLayer(TIOCs.style({fillColor:"FF000000", color:"blue",width:1.5}),{},"TIOCs", false);
var collection = ee.ImageCollection([
lineaBase.set('system:time_start', ee.Date('2023-01-01')).rename('Altura_Dosel'),
ee.Image('users/anmarkos/MOXOS/rh98_06_2023').set('system:time_start', ee.Date('2023-06-01')).rename('Altura_Dosel'),
ee.Image('users/anmarkos/MOXOS/rh98_01_2024').set('system:time_start', ee.Date('2024-01-01')).rename('Altura_Dosel'),
ee.Image('users/anmarkos/MOXOS/rh98_06_2024').set('system:time_start', ee.Date('2024-06-01')).rename('Altura_Dosel'),
ee.Image('users/anmarkos/MOXOS/rh98_01_2025').set('system:time_start', ee.Date('2025-01-01')).rename('Altura_Dosel'),
actual.set('system:time_start', ee.Date('2025-06-01')).rename('Altura_Dosel'),
]);
var popupTextContent = 'Límites administrativos de los Municipios de Bolivia:\n' +
'Viceministerio de Autonomías – Ministerio de la Presidencia – Gestión 2015 (VA, 2015)\n' +
'Límites municipales de carácter referencial.\n' +
'https://geo.gob.bo/catalogue/#/dataset/1493\n' +
'\n' +
'Límite administrativo del Departamento del Beni:\n' +
'Gobierno Autónomo Departamental del Beni (GAD Beni, 2019). Plan de Uso de Suelos.\n' +
'IDRISI – SRL., Documento Final PLUS-Beni, Trinidad (Bolivia).\n' +
'\n' +
'Sitios Ramsar de Bolivia:\n' +
'Ministerio de Medio Ambiente y Agua (MMAyA / DGBAP 2018), Sitios RAMSAR.\n' +
'Estrategia para la gestión integral de los humedales y sitios RAMSAR en Bolivia. \n' +
'https://geo.gob.bo/catalogue/#/dataset/2869\n' +
'\n' +
'Áreas Protegidas de Bolivia: \n' +
'Ministerio de Medio Ambiente y Agua – Gestión 2024 (MMAyA, 2024).\n' +
'Atlas de las Áreas Protegidas Municipales de Bolivia.\n' +
'https://geo.gob.bo/catalogue/#/dataset/2868\n' +
'[Complementación y actualización 2025 con normas de creación de cada área protegida].\n' +
'\n' +
'Tierras Comunitarias de Origen y Territorios Indígenas Originarios Campesinos (TIOCs):\n' +
'Instituto Nacional de Reforma Agraria – Gestión 2018 (INRA, 2018). \n' +
'https://geo.gob.bo/catalogue/#/dataset/2466\n' +
'[Complementación y actualización 2024 con titulares TIOCs].';
// Create the label, ensuring whiteSpace is set to 'pre' to respect \n.
var multiLineLabel = ui.Label({value: popupTextContent,style: {whiteSpace: 'pre', fontSize: '13px',color: '#333333'}});
// A button to close the pop-up.// Hides the panel when clicked.
var closeButton = ui.Button({label: 'Cerrar ventana emergente', onClick: function() {
    popupPanel.style().set('shown', false); },style: {stretch: 'horizontal',margin: '10px 0 0 0'}});
// Create the panel container for the label and close button.
var popupPanel = ui.Panel({widgets: [multiLineLabel, closeButton], style: {position: 'top-right', width: '550px', padding: '15px',border: '2px solid #5d5d5d',backgroundColor: '#f9f9f9', shown: false}});
// Function to show the pop-up when the button is clicked.
var showPopupFunction = function() {popupPanel.style().set('shown', true);};
// Create the button that the user will click.
var showPopupButton = ui.Button({label: 'Visualizar las fuentes de los límites administrativos', onClick: showPopupFunction,
style: {padding: '10px',margin: '5px',backgroundColor: '#00FFFF',color: 'black',fontWeight: 'bold'}});
panel.add(showPopupButton);
Map.add(popupPanel);
var panelChart = ui.Panel({style: {width: '320px'}});
Map.onClick(function(coords) {
// var location = 'lon: ' + coords.lon.toFixed(11) + '; ' +'lat: ' + coords.lat.toFixed(11);
var locationX = coords.lat.toFixed(13) + ', ' +coords.lon.toFixed(13);
// var locationXX = 'lat: ' + coords.lat.toFixed(11) + '; ' +'lon: ' + coords.lon.toFixed(11);
panelChart.widgets().set(0, ui.Label(locationX));
var point = ee.Geometry.Point(coords.lon, coords.lat);
Map.layers().set(999, ui.Map.Layer(point, {color: '00FFFF'}, locationX));
var chart = ui.Chart.image.series(collection, point, ee.Reducer.first(), 30)
.setOptions({title: 'Altura del dosel promedio (30x30m)', vAxis: {title: 'm'}, lineWidth: 1, pointSize: 3, 
trendlines: {0: {type: 'linear', showR2: true, color: 'red', pointSize: 0}}}).setChartType('LineChart')
panelChart.widgets().set(1, chart);});
panelChart.style().set({position: 'bottom-left'});
Map.add(panelChart);
/**/