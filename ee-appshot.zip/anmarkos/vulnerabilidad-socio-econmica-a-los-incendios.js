var AOI = ui.import && ui.import("AOI", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -74.32567615509035,
            3.8432237199341235
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -78.51076828326863,
            -1.7691157132739446
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -76.31350265826863,
            -6.501493351689862
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -56.186549533268625,
            -4.051173351532368
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.MultiPoint(
        [[-74.32567615509035, 3.8432237199341235],
         [-78.51076828326863, -1.7691157132739446],
         [-76.31350265826863, -6.501493351689862],
         [-56.186549533268625, -4.051173351532368]]),
    Download_Area = ui.import && ui.import("Download_Area", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#bcff2b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #bcff2b */
    /* shown: false */
    ee.Geometry.MultiPoint();
var aoi = ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017").filterBounds(AOI);
var table = ee.FeatureCollection('users/anmarkos/GRIDS/h3_res4').filterBounds(aoi);
var hillshade = ee.Terrain.hillshade(ee.Image("NASA/NASADEM_HGT/001").clip(aoi).geometry().bounds()).visualize({min:180,max:200});
Map.setOptions('Dark Map', {'Dark Map': darkMap()});    function darkMap() {return [{"elementType":"geometry","stylers":[{"color":"#212121"}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"elementType":"labels.text.fill","stylers":[{"color":"#757575"}]},{"elementType":"labels.text.stroke","stylers":[{"color":"#212121"}]},{"featureType":"administrative","elementType":"geometry","stylers":[{"color":"#757575"}]},{"featureType":"administrative.country","elementType":"labels.text.fill","stylers":[{"color":"#9e9e9e"}]},{"featureType":"administrative.land_parcel","stylers":[{"visibility":"off"}]},{"featureType":"administrative.locality","elementType":"labels.text.fill","stylers":[{"color":"#bdbdbd"}]},{"featureType":"poi","elementType":"labels.text.fill","stylers":[{"color":"#757575"}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#181818"}]},{"featureType":"poi.park","elementType":"labels.text.fill","stylers":[{"color":"#616161"}]},{"featureType":"poi.park","elementType":"labels.text.stroke","stylers":[{"color":"#1b1b1b"}]},{"featureType":"road","elementType":"geometry.fill","stylers":[{"color":"#2c2c2c"}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"color":"#8a8a8a"}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#373737"}]},{"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#3c3c3c"}]},{"featureType":"road.highway.controlled_access","elementType":"geometry","stylers":[{"color":"#4e4e4e"}]},{"featureType":"road.local","elementType":"labels.text.fill","stylers":[{"color":"#616161"}]},{"featureType":"transit","elementType":"labels.text.fill","stylers":[{"color":"#757575"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#000000"}]},{"featureType":"water","elementType":"labels.text.fill","stylers":[{"color":"#3d3d3d"}]}];}
Map.centerObject(aoi);
Map.setControlVisibility({zoomControl: false, mapTypeControl: false, drawingToolsControl: false});
//////////////////////  Import Image
Map.add(ui.Label({value: 'Vulnerabilidad Socio-Económica a los Incendios (2022)',style: {position: 'top-center', fontSize: '22px', color: 'FFE363', backgroundColor: '00502F', fontWeight: 'bold', border: '1px solid orange'}}));
var PC1 = ee.Image('users/anmarkos/FIRE/Vulnerability/PC1').rename('Ocupación Humana');
var PC2 = ee.Image('users/anmarkos/FIRE/Vulnerability/PC2').rename('Economía Rural de Subsistencia');
var PC3 = ee.Image('users/anmarkos/FIRE/Vulnerability/PC3').rename('Economía Rural en Desarrollo');
var PC4 = ee.Image('users/anmarkos/FIRE/Vulnerability/PC4').rename('Ganadería Extensiva');
var PC = ee.Image('users/anmarkos/FIRE/Vulnerability/Vuln_INDEX').rename('Índice de Vulnerabilidad Socio-Económica');
var S2 = ee.ImageCollection([ee.Image('users/rodrizenteno9/S2_LULC_2021/21P_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/18G_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/17M_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/19F_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/22H_20210101-20220101'),
ee.Image('users/rodrizenteno9/S2_LULC_2021/18H_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/19G_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/20F_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/20G_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/19J_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/18F_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/21H_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/19H_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/20J_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/20H_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/18L_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/18M_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/18N_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/19L_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/19M_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/19N_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/20K_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/20K_20210101-2x0220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/20L_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/21K_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/21L_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/vulnr'),ee.Image('users/rodrizenteno9/S2_LULC_2021/21F_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/20N_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/17L_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/17N_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/19K_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/18K_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/20M_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/20P_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/21N_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/21J_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/22J_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/22K_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/21M_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/25M_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/25L_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/24M_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/24L_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/24K_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/23M_20210101-20220101')
,ee.Image('users/rodrizenteno9/S2_LULC_2021/22L_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/23L_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/23K_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/23J_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/22M_20210101-20220101'),ee.Image('users/rodrizenteno9/S2_LULC_2021/22N_20210101-20220101')])
.filterBounds(table).mosaic().clip(table.geometry().buffer(20000));
var vis = {min:'min', max:'max', palette: ['2c7bb6', 'abd9e9', 'ffffbf', 'fdae61', 'd7191c']}; 
function makeColorBarParams(palette) {return {bbox: [0, 0, 1, 0.1],
dimensions: '100x10',format: 'png',min: 0,max: 1,palette: ['2c7bb6', 'abd9e9', 'ffffbf', 'fdae61', 'd7191c']}}
var colorBar = ui.Thumbnail({image: ee.Image.pixelLonLat().select(0),params: makeColorBarParams(vis.palette),
style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},});
var legendLabels = ui.Panel({widgets: [ui.Label(vis.min, {margin: '4px 8px'}),   
ui.Label(('mediana'),{margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),     
ui.Label(vis.max, {margin: '4px 8px'})],layout: ui.Panel.Layout.flow('horizontal')});      
var legendTitle = ui.Label({value: 'Vulnerabilidad Socio-Económica a los Incendios', style: {fontWeight: 'bold'}});
var color = ui.Label({value: 'Vulnerabilidad Socio-Económica Leyenda', style: {fontWeight: 'bold'}});
var space = ui.Label({value: ' '});
var spacey = ui.Label({value: ' - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -'});
var spacex = ui.Label({value: ' '});
var legendTitle2 = ui.Label({value: 'Land Cover Land Use Legend', style: {fontWeight: 'bold'}});
var checkbox1 = ui.Checkbox('Ocupación Humana', true);              checkbox1.onChange(function(checked) {Map.layers().get(1).setShown(checked)});
var checkbox2 = ui.Checkbox('Economía Rural de Subsistencia', true);     checkbox2.onChange(function(checked) {Map.layers().get(2).setShown(checked)});
var checkbox3 = ui.Checkbox('Economía Rural en Desarrollo', true);      checkbox3.onChange(function(checked) {Map.layers().get(3).setShown(checked)});
var checkbox4 = ui.Checkbox('Ganadería Extensiva', true);     checkbox4.onChange(function(checked) {Map.layers().get(4).setShown(checked)});
var checkbox5 = ui.Checkbox('Índice de Vulnerabilidad Socio-Económica', true);checkbox5.onChange(function(checked) {Map.layers().get(5).setShown(checked)});
var pale = ['419BDF', '397D49', '88B053', '7A87C6', 'FF0000','000000', 'A59B8F', 'B39FE1', 'FF000000','DFC35A']; 
// Map.addLayer(S2, {min:1, max: 11, palette: pale},'Land Cover Land Use (ESRI 2021)');
Map.addLayer(PC1, {min:0,max:1,palette: ['2c7bb6', 'abd9e9', 'ffffbf', 'fdae61', 'd7191c']}, 'Ocupación Humana');
Map.addLayer(PC2, {min:0,max:1,palette: ['2c7bb6', 'abd9e9', 'ffffbf', 'fdae61', 'd7191c']}, 'Economía Rural de Subsistencia');
Map.addLayer(PC3, {min:0,max:1,palette: ['2c7bb6', 'abd9e9', 'ffffbf', 'fdae61', 'd7191c']}, 'Economía Rural en Desarrollo');
Map.addLayer(PC4, {min:0,max:1,palette: ['2c7bb6', 'abd9e9', 'ffffbf', 'fdae61', 'd7191c']}, 'Ganadería Extensiva');
Map.addLayer(PC, {min:0,max:1,palette: ['2c7bb6', 'abd9e9', 'ffffbf', 'fdae61', 'd7191c']}, 'Índice de Vulnerabilidad Socio-Económica');
var spaceSect = ui.Label({value: ' - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -'});
var sectionTitle = ui.Label({value: 'Explore los datos para priorizar acciones', style: {fontWeight: 'bold'}});
var bandas = {'Ocupación Humana': [], 'Economía Rural de Subsistencia': [], 'Economía Rural en Desarrollo': [], 'Ganadería Extensiva': [], 'Índice de Vulnerabilidad Socio-Económica': []};
var label =  ui.Label('Defina un umbral percentil: ', {});
var slider = ui.Slider({min: 0.8, max:1, step: 0.01, onChange: function(){}});
var dicobjetos = {select:{b1: ui.Select({items: Object.keys(bandas), placeholder: 'Seleccione una dimensión de la vulnerabilidad', onChange:function(){}})}};
var panelX = ui.Panel({widgets:[label,slider], layout: ui.Panel.Layout.Flow('horizontal')});
var boton = ui.Button({label:'Mostrar', onClick:function(b){
var layer0 = ui.Map.Layer((PC1.addBands(PC2).addBands(PC3).addBands(PC4).addBands(PC)).gt(slider.getValue()), 
{bands: [dicobjetos.select.b1.getValue()], min:0, max:1, palette: ['2c7bb6', 'd7191c']}, 'Vulnerabilidad Socio-Económica con humbral');
Map.layers().set(6,layer0)}});
Map.layers().set(6,ee.Image());
Map.layers().set(7,ee.Image());
var panelV = ui.Panel({widgets:[dicobjetos.select.b1,boton], layout: ui.Panel.Layout.Flow('horizontal')});
var contact =  ui.Label({value: 'Contacto: anmarkos@gmail.com', style: {fontWeight: 'bold'}});
//////////////////////////////////////////////////////////////////////////////////    RGB
var bands = {"PC1": [], "PC2": [], "PC3": [],"PC4": [],"Vuln_INDEX": []};
var dicobjets = {select:{b1: ui.Select({items: Object.keys(bands), placeholder: 'RED', onChange:function(){}}),
b2: ui.Select({items: Object.keys(bands), placeholder: 'GREEN', onChange:function(){}}),
b3: ui.Select({items: Object.keys(bands), placeholder: 'BLUE', onChange:function(){}})}};
var panelRGB = ui.Panel({widgets:[dicobjets.select.b1,dicobjets.select.b2,dicobjets.select.b3], 
layout: ui.Panel.Layout.Flow('horizontal'), style: {backgroundColor: '00000000'}});
var layer_rgb = PC1.addBands(PC2).addBands(PC3).addBands(PC4).addBands(PC).rename(["PC1", "PC2", "PC3","PC4","Vuln_INDEX"])
var boton = ui.Button({label:'Show selected RGB composition', onClick:function(b){
var layerRGB = ui.Map.Layer(layer_rgb, {bands: [dicobjets.select.b1.getValue(),dicobjets.select.b2.getValue(),dicobjets.select.b3.getValue()],min:0,max:1}, 'RGB composition');
Map.layers().set(99,layerRGB)}});
var spaceSect = ui.Label({value: ' - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -'});
var spaceSep = ui.Label({value: ' - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -'});
var spaceSepa = ui.Label({value: ' - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -'});
// var panelRGB = ui.Panel({widgets:[spaceSect,panelRGB,boton,spacey,contact], layout: ui.Panel.Layout.Flow('vertical')});
// Map.add(panel.add(panelRGB));
// Green: #00502F   // Yellow: #FFE363
///////////////////////////////////////////////////////////////// LCLU 2021 ///////////////////////////////////////////////////////////
function downloadImg() {var downloadArgs = {name: 'Vulnerabilidad Socio-Económica to Wildfires',scale: 1000,region: Download_Area}//table.geometry().bounds() };
var url = PC1.addBands(PC2).addBands(PC3).addBands(PC4).addBands(PC).getDownloadURL(downloadArgs); urlLabel.setUrl(url);  urlLabel.style().set({shown: true})}
var downloadButton = ui.Button('Download Data (only small Download Area)', downloadImg);
var urlLabel = ui.Label('Download', {shown: false});
var panel = ui.Panel({widgets:[legendTitle,checkbox5,checkbox4,checkbox3,checkbox2,checkbox1,color,colorBar,legendLabels,spacey,sectionTitle,panelX,panelV,spaceSepa,contact], //downloadButton, urlLabel,spaceSep,panelRGB,boton,spaceSect,
layout: ui.Panel.Layout.Flow('vertical')});
panel.style().set({position: 'top-right'});//,width: '300px',height: '180px'
Map.add(panel);
// Map.add(ui.Label({value: 'PAPER & DATA: https://drive.google.com/drive/folders/16j1ruwVUKbUdce_M5k34IV_92LUQlcVr?usp=sharing',style: {position: 'bottom-right', fontSize: '12px', color: 'FFE363', backgroundColor: '00502F', fontWeight: 'bold', border: '1px solid orange'}}));
// Map.add(ui.Label({value: 'English version: https://anmarkos.users.earthengine.app/view/socio-economic-vulnerability-to-wildfires',style: {position: 'bottom-right', fontSize: '12px', color: 'FFE363', backgroundColor: '00502F', fontWeight: 'bold', border: '1px solid orange'}}));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// var checkbox0 = ui.Checkbox('LCLU 2021 (ESRI)', true);  checkbox0.onChange(function(checked) {Map.layers().get(0).setShown(checked)});
// var panel2 = ui.Panel({widgets:[legendTitle2], layout: ui.Panel.Layout.Flow('vertical')});
// var makeRow = function(color,name){
// var colorBox = ui.Label({style: {backgroundColor: '#' + color, padding: '8px', margin: '0 0 8px 0' }});
// var description = ui.Label({value: name, style: {margin: '0 0 4px 6px'}});                       
// return ui.Panel({widgets: [colorBox, description], layout: ui.Panel.Layout.Flow('horizontal')})};  
// var names = ['Water','Trees','Grass','Flooded vegetation','Crops','Built Area','Bare ground','Snow/Ice','Clouds (NoData)','Rangeland'];
// for (var i = 0; i < 10; i++) {panel2.add(makeRow(pale[i], names[i]));}   
// panel2.style().set({position: 'bottom-left'});//,width: '300px',height: '180px'   style: {backgroundColor: '00005555'}
// Map.add(panel2.add(checkbox0));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var dimensions = 300;
var framesPerSecond = 1.5;
var states = aoi;   
var text = require('users/anmarkos/FireSpread:text');
function mosaic(x){return x.addBands(ee.ImageCollection([x.select('BurnDate').gt(0), x.select('BurnDate_1').gt(0).rename('BurnDate')]).mosaic().multiply(ee.Image.pixelArea()).divide(10000).rename('Hectáreas'))}
var states_outline = (ee.Image().byte() .paint({'featureCollection': states, 'color': 1, 'width': 1}).visualize({'palette': 'white'}));
var foco_params = {'palette': ['red']};
var innerJoin = ee.Join.inner();  var filterTimeEq = ee.Filter.equals({leftField: 'system:time_start',rightField: 'system:time_start'});
var innerJoined = innerJoin.apply(ee.ImageCollection("MODIS/061/MCD64A1").select('BurnDate'), ee.ImageCollection("ESA/CCI/FireCCI/5_1").select('BurnDate'), filterTimeEq); 
var dataset = ee.ImageCollection(innerJoined.map(function(feature) {return ee.Image.cat(feature.get('primary'), feature.get('secondary'));})); 
// var dataset = ee.ImageCollection("ESA/CCI/FireCCI/5_1").select('BurnDate')
var crs = PC1.projection();
function visImg(img) {var pt = text.getLocation(aoi.geometry().bounds(), 'right', '2%', '35%');
var textVis = {fontSize: 32, textColor: 'ffffff', outlineColor: '000000', outlineWidth: 2.5, outlineOpacity: 1 };
var labeltxt = text.draw(img.get('system:index'), pt, 23000, textVis);
return (states_outline).blend(img.select('BurnDate').gt(0).visualize(foco_params)).blend(img.select('BurnDate_1').gt(0).visualize(foco_params)).blend(labeltxt)}   //
// hillshade.blend
var datasetVideo = ee.ImageCollection.fromImages(dataset.toList(dataset.size()).slice(0, dataset.size(), 1)).map(visImg);
var filmstrip_params = {dimensions: dimensions,region: aoi.geometry().bounds(),crs: crs,'framesPerSecond': framesPerSecond,'maxPixels': 1e13};
var thumb = ui.Thumbnail(datasetVideo, filmstrip_params);
thumb.style().set({position: 'top-left'});
Map.add(ui.Label({value: 'Área quemada combinada MODIS-ESA',style: {position: 'top-left', fontSize: '19px', color: 'FFE363', backgroundColor: '00502F', fontWeight: 'bold', border: '1px solid orange'}}));
Map.add(thumb);
dataset =dataset.map(mosaic).select('Hectáreas');
Map.add(ui.Label({value: 'Click en el mapa para serie temporal de área quemada MODIS-ESA 2001-ahora', style: {position: 'bottom-left', fontSize: '12px', color: 'FFE363', backgroundColor: '00502F', fontWeight: 'bold', border: '1px solid orange'}}));
var panelChart = ui.Panel({style: {width: '400px'}});
Map.onClick(function(coords) {
var location = 'lon: ' + coords.lon.toFixed(8) + ' ' +'lat: ' + coords.lat.toFixed(8);
panelChart.widgets().set(1, ui.Label(location));
var point = ee.Geometry.Point(coords.lon, coords.lat);
var hex = table.filterBounds(point);
var heX = table.filterBounds(hex.geometry().buffer(1000));
var ring = table.filterBounds(ee.ImageCollection([ee.Image(2).clip(hex.geometry().buffer(2000)).byte(), ee.Image(1).clip(hex.geometry().buffer(1000)).byte()]).mosaic().eq(2).selfMask()
.reduceToVectors(ee.Reducer.countEvery(), heX, 1000, 'polygon')).aside(print);
Map.layers().set(7, ui.Map.Layer(ring.select(['1']), {opacity:0.4, color: 'cyan'}, 'buffer H3'));
Map.layers().set(8, ui.Map.Layer(hex, {opacity:0.4, color:'magenta'}, 'selected H3'));
Map.layers().set(9, ui.Map.Layer(dataset.mosaic().clip(heX).gt(0), {min:0, color: 'black'}, 'Área quemada 2001-ahora'));
var chart = ui.Chart.image.series(dataset, hex, ee.Reducer.sum(), ee.ImageCollection("MODIS/061/MCD64A1").select('BurnDate').first().projection().nominalScale())
.setOptions({title: 'Área quemada mensual H3 (incluye quemas agric.)',vAxis: {title: 'Hectáreas quemadas'}}).setChartType('AreaChart');
var charT = ui.Chart.image.series(dataset, heX, ee.Reducer.sum(), ee.ImageCollection("MODIS/061/MCD64A1").select('BurnDate').first().projection().nominalScale())
.setOptions({title: 'Área quemada mensual buffer (incluye quemas agric.)',vAxis: {title: 'Hectáreas quemadas'}}).setChartType('AreaChart');
panelChart.widgets().set(1, chart).set(2, charT);});
panelChart.style().set({position: 'bottom-left'});
Map.add(panelChart);
var aoi_outline = ui.Map.Layer((ee.Image().byte().paint({'featureCollection': table, 'color': 1, 'width': .5}).visualize({'palette': 'grey'})), {}, 'H3 grilla');
Map.layers().set(10,aoi_outline);
var outline = ui.Map.Layer((ee.Image().byte() .paint({'featureCollection': aoi, 'color': 1, 'width': 1.5}).visualize({'palette': 'black'})), {}, 'Paises');
Map.layers().set(11,outline);
// '9400D3','4B0082','0000FF','00FF00','FFFF00','FF7F00','FF0000'