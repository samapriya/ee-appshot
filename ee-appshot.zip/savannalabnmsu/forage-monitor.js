var modis_nbar = ui.import && ui.import("modis_nbar", "imageCollection", {
      "id": "MODIS/006/MCD43A4"
    }) || ee.ImageCollection("MODIS/006/MCD43A4"),
    modis_lu = ui.import && ui.import("modis_lu", "image", {
      "id": "MODIS/006/MCD12Q1/2017_01_01"
    }) || ee.Image("MODIS/006/MCD12Q1/2017_01_01"),
    treeCov = ui.import && ui.import("treeCov", "image", {
      "id": "users/savannalabnmsu/treecover_data/cover_biomass"
    }) || ee.Image("users/savannalabnmsu/treecover_data/cover_biomass"),
    longterm = ui.import && ui.import("longterm", "imageCollection", {
      "id": "users/savannalabnmsu/PV_NPV_lterm"
    }) || ee.ImageCollection("users/savannalabnmsu/PV_NPV_lterm"),
    modis_fire = ui.import && ui.import("modis_fire", "imageCollection", {
      "id": "MODIS/006/MOD14A1"
    }) || ee.ImageCollection("MODIS/006/MOD14A1"),
    countries = ui.import && ui.import("countries", "table", {
      "id": "USDOS/LSIB_SIMPLE/2017"
    }) || ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017");
/*MAIN APPLICATION*/
var sen = countries.filterMetadata('country_na','equals','Senegal')//.geometry().dissolve(ee.ErrorMargin(1))
var BF = countries.filterMetadata('country_na','equals','Burkina Faso')//.geometry().dissolve(ee.ErrorMargin(1))
var Ma = countries.filterMetadata('country_na','equals','Mali')//.geometry().dissolve(ee.ErrorMargin(1))
var Ng = countries.filterMetadata('country_na','equals','Niger')//.geometry().dissolve(ee.ErrorMargin(1))
var selected = sen.merge(BF).merge(Ma).merge(Ng)
var aoi = selected
//create urban and water mask using MODIS global land cover
var lu = modis_lu.select('LC_Type1').clip(aoi);
var lu_mask = lu.neq(13).and(lu.neq(17));
/*
create range of selectable dates for the application.
*/
//Retrieve date from most recent available image in MODIS NBAR collection in GEE.
var mostrecent = modis_nbar.sort('system:time_start', false).limit(1).first();
var latest = ee.Date(mostrecent.get('system:time_start'));// latest date
var latest_doy= ee.Number.parse(latest.format('D'));//latest doy of year
var startDate = latest.advance(-18,'month')//18 months is used to provide 6-month buffer in case earlier dates are selected
var endDate = latest
// Create list of dates bounded by start and end dates
var n_days = endDate.difference(startDate,'day').round();
var date_index_list = ee.List.sequence(0,n_days.subtract(1),1);
var make_datelist = function(n) {
  return startDate.advance(n,'day').format('Y-MM-dd');
};
var datelist = date_index_list.map(make_datelist).getInfo();
//convert date list to day_of_year list
var doyList = datelist.map(function(date){
  return ee.Number.parse(ee.Date(date).format('D'))
})
/*
Create weekly datelist for the select menu by using  day_of_year corresp. to midweek dates.
i.e, '10-04=YYYY' (doy = 277, middle of week 40: Oct1 - Oct7),'10-11-YYYY, '10-18-YYYY',...latest midweek date
These will be used to center weekly composites
and also retrieve already stored 10-year weekly mean and stddev images for computing anomalies
*/
//intersect annual midweek day_of_year list with previously defined datelist.
//returns all midweek dates found within the period of interest to be used in select menu
var midweekList = ee.List.sequence(4,365,7);
var subset = function(el){
  return ee.Algorithms.If(ee.List(doyList).contains(el),el)
  }
var sublist = midweekList.map(subset,true)
//create select menu items using only midweek dates
var itemlist = datelist.map(function(date){
  var year = ee.Date(date).format('YYYY')
  var doy = ee.Number.parse(ee.Date(date).format('D'))
  return ee.Algorithms.If(sublist.contains(doy),date, 'null')
},true)
var dates = ee.List(itemlist).removeAll(['null']).getInfo();
var dates_menu = ee.List(itemlist).removeAll(['null']).slice(26,-1).getInfo()//remove first 6 months to retain only 12 months of dates;
//function to run after selecting a specific midweek date
var selectDay = ui.Select({
  items: dates_menu,
  placeholder:'choose a date...',
  //value:'2020-12-26',
  onChange: function(value) {
    //reset map layer opacity
    opacitySlider.setValue(1);
    //clear all chart panels
    chart_pan.clear();
    //chart_pan2.clear();
    // new sub list of dates based on selected date
    //limit to a ~ 6 month (26 week) period
    var newEnd = ee.List(dates).indexOf(value)
    //print(newEnd)
    var newList =  ee.List(ee.Algorithms.If(newEnd.lte(25), ee.List(dates).slice(0,newEnd.add(1)),ee.List(dates).slice(newEnd.subtract(25),newEnd.add(1))))
    //print(newList)
    // fire  mask(pixels with atleast one normal confidence fire in new period)
    var firemask = modis_fire.filterDate(ee.Date(value).advance(-6,'month'), ee.Date(value).advance(1,'day'))
                        .select('FireMask')
                        .map(function(image){
                           return image.clip(aoi).updateMask(image.gte(7))
                        })
                        .count()
                        .gte(1)
                        .select([0],['firemask'])
    var bands = [
      "Nadir_Reflectance_Band1",
      "Nadir_Reflectance_Band2",
      "Nadir_Reflectance_Band4",
      "Nadir_Reflectance_Band6",
      "Nadir_Reflectance_Band7"
      ];
    //function to run for each selected date. Will create weekly results.
    var weekly =  function(d){
      var year = ee.Date(d).format('YYYY')
      var doy = ee.Number.parse(ee.Date(d).format('D'))//day of year
      var woy = doy.subtract(4).divide(7).add(1).toInt().format('%02d')// week of year
      // retrieve long-term means and std.dev for the same week
      var long = longterm.filterMetadata('week_of_year','equals',woy).first().updateMask(lu_mask)
      //weekly modis data.  NDVI and SWIR band ratio (SWIR3/SWIR2)                   
      var weeklymos = modis_nbar.filterDate(ee.Date(d).advance(-3,'day'),ee.Date(d).advance(4,'day'))
                     .select(bands,["red","nir","gr_band","swir2","swir3"])
                     .map(function(img){
                        var modis_img = img.clip(aoi)//.reproject({crs:"EPSG:4326",scale:500}).toFloat();
                        var ndwi = modis_img.normalizedDifference(["gr_band","swir2"]);// water index to mask out wetlands and riparian areas
                        var ndvi = modis_img.normalizedDifference(["nir","red"]).select([0],["ndvi"]);
                        var swir = modis_img.select("swir3").divide(modis_img.select("swir2")).select([0],["swir32"])
                        return modis_img.addBands(ndvi).addBands(swir)
                                        .updateMask(ndwi.lte(-0.4))
                     })
                     .qualityMosaic('ndvi');//maximum ndvi composite for the week
      //endmembers for unmixing weekly composites of NDVI and SWIR band ratio (SWIR3/SWIR2) into green, non-green and bare fraction.
      //Derived independently by inverting random forest models validated with high resolution image data
      var gr = [0.703, 0.421];
      var ng = [0.206, 0.769];
      var b = [0.134, 0.907];
      //unmix weekly data with sumToOne contrainst set to false
      var unmixed = weeklymos.select(['ndvi','swir32'])
                     .unmix([gr,ng,b],false,true)
                     .select([0,1,2],['green','non-green','bare'])
      var green = unmixed.select('green').where(unmixed.select('green').gt(0.99),ee.Image.constant(0.99))
      var bare= unmixed.select('bare').where(unmixed.select('bare').gt(0.99),ee.Image.constant(0.99))
      var nongreen = unmixed.select('non-green')
      //given that non-green predicitons is less accurate (based on prior models),compute new non-green fraction by subtracting green+bare from 1.
      var g_b = green.add(bare)
      var new_ng = ee.Image.constant(1).subtract(green).subtract(bare).select([0],['non-green']).where(g_b.gt(1),ee.Image.constant(0))
      //return fractional cover bands
      return green//green veg. fraction
              .addBands(new_ng)//updated non-green vegetation
              .addBands(bare)//bare soil fraction
              .addBands(long)//long-term mean and std.dev bands for the same week
                     .toFloat()
                     .set('week',woy)
                     .set('year',year)
                     .set('week_of_year', year.cat('_').cat(woy))
                     .set('date',d)
    }
    var TC = treeCov.select(0).divide(100).select([0],['tree_cover'])
    var weekly_means = ee.ImageCollection.fromImages(newList.map(weekly))
                          .map(function(image){
                            var woy = ee.Number.parse(image.get('week'))
                            return ee.Algorithms.If(woy.gt(24).and(woy.lt(37)),image.updateMask(image.lt(0)),image)
                          });
   // print(weekly_means);
    var weekly_anoms = weekly_means.map(function(image){
        var green_anom = image.select(0).subtract(image.select(3)).divide(image.select(6)).select([0],['green'])
        var ng_anom = image.select(1).subtract(image.select(4)).divide(image.select(7)).select([0],['non-green'])
        var bare_anom = image.select(2).subtract(image.select(5)).divide(image.select(8)).select([0],['bare'])
        return green_anom.addBands(ng_anom).addBands(bare_anom).copyProperties(image)
        })
   // print(weekly_anoms)
    //compute weekly forage index by assigned different weights to cover types and constraining by woody cover
    //(green*1+ (dry*(1-treecover)*0.5)+bare*0) 
    var weeklyIndex = weekly_means.map(function(image){
      var tc_inv  = ee.Image.constant(1).subtract(TC)
      var green_fr = image.select('green').multiply(1)
      var ng_fr = image.select('non-green').multiply(0.5).multiply(tc_inv)
      var bare_fr = image.select('bare').multiply(0)
      return green_fr.add(ng_fr).add(bare_fr).select([0],['forage-index']).copyProperties(image)
    })
    // get image for selected date and display
    var selected_mean = 
        weekly_means.sort('date',false).first();
    var selected_anom = 
        weekly_anoms.sort('date',false).first();
    var selected_index = 
        weeklyIndex.sort('date',false).first();
        /*
  //export custome set
    var ExportCol = function(col, scale, region, maxPixels) {
      var colList = col.toList(ee.Number(col.size()).getInfo());
      var n = colList.size().getInfo();
      for (var i = 0; i < n; i++) {
          var img = ee.Image(colList.get(i));
          var id = ee.String('img_').cat(img.get('date')).cat(ee.String('_')).getInfo();
        Export.image.toDrive({
        image:img,
        description: id,
        fileNamePrefix:id,
        folder:'fcover_images',
        scale: scale,
        region: region,
        maxPixels: maxPixels});
         }
        };
    ExportCol(weekly_means.select([0,1,2]), 500, aoi, 1e13);
*/
  var visParams_rfi = {min: 0.2, max: 0.8, palette:['saddlebrown','#D1BE9D','#3B727C']}
  mapPanel.clear();
  click_label.widgets().set(0,ui.Label('Click on map to view aggregate data for each 25km grid cell',{fontSize: '12px', fontWeight: 'bold', backgroundColor:'black',color:'white'}));
  mapPanel.layers().set(0,ui.Map.Layer(selected_mean, {bands: ['bare', 'green', 'non-green'],  min: 0, max: 1},'fractional cover'));
  mapPanel.layers().set(1,ui.Map.Layer(selected_index,visParams_rfi,'relative forage index'));
  mapPanel.layers().set(2,ui.Map.Layer(firemask,{bands: ['firemask'],  min: 0, max: 1, palette:['yellow']},'fire mask'));
  var checkbox = ui.Checkbox('Show SRTM layer', true);
  var grid = makeGrid.setGrid(mapPanel,aoi.geometry().bounds(),50000,'white')
  mapPanel.add(legendPanel);
  //mapPanel.setOptions('baseChange', {'baseChange': baseChange});
  mapPanel.setOptions('hybrid')
  mapPanel.setControlVisibility({all:false, zoomControl: true, layerList: false,scaleControl:true});
  mapPanel.style().set('cursor', 'crosshair');
 //function to display location charts on click
  mapPanel.onClick(function(coords) {
    chart_pan.clear();
    //select polygon grid cell intersecting with clicked point 
    var point = ee.Geometry.Point(coords.lon, coords.lat);
    var selected_box = ee.FeatureCollection(grid).filterBounds(point)
    //var name2 = selected_box.first().get('admin2Name').getInfo()//name of division
    //var name0 = selected_box.first().get('admin0Name').getInfo()//name of country
    //click_label.clear();
    //click_label.style().set('shown', true);
    //click_label.widgets().set(0,ui.Label("Selected: "+name2+" division in "+name0, {color: 'black',fontSize: '20px', fontWeight: 'bold'}));
    // highlight selected zone
    mapPanel.layers().set(3, ui.Map.Layer(selected_box.draw({color: 'white'}),{},'selected zone'));
    //center and zoom into selected grid cell
    mapPanel.centerObject(selected_box,9);
    //create charts for selected cell
    var chart0 = ui.Chart.image.series(weekly_means.select([0,1,2]), selected_box, ee.Reducer.median(), 500, 'date')
                              .setChartType('AreaChart')
                              .setOptions({
                              colors:['red','green','blue'],
                              hAxis: {title: 'Date', textStyle: {fontSize:8}},
                              vAxis: {title: 'fractional cover', viewWindow: {min: 0, max: 1}, textStyle: {fontSize:10}},
                              height:'90%',
                              width: '50%',
                              title: "average weekly fractional cover",
                              //stretch:'horizontal',
                               padding:'0px'
                              });
    var chart1 = ui.Chart.image.byRegion(selected_mean.select([0,1,2],['green','non-green','bare']),selected_box, ee.Reducer.median(), 500)
                              .setChartType('BarChart')
                              .setOptions({
                              colors:['red','green','blue'],
                              vAxis: {textColor:"#ffffff"},
                              hAxis: {title: 'fractional cover', viewWindow: {min: -2, max: 2}, textStyle: {fontSize:10}, ticks:[0,0.5,1]},
                              height:'90%',
                              width: '20%',
                              title: "average fractional cover (week of "+value+")",
                              //stretch:'horizontal',
                              padding:'0px'
                              });
                              /*
    var chart2 = ui.Chart.image.byRegion(selected_mean.select([3,4,5],['green','non-green','bare']),selected_box, ee.Reducer.median(), 500)
                              .setChartType('BarChart')
                              .setOptions({
                              colors:['red','green','blue'],
                              vAxis: {textColor:"#ffffff"},
                              hAxis: {title: 'Fractional cover', viewWindow: {min: -2, max: 2}, textStyle: {fontSize:12}, ticks:[0,0.5,1]},
                              height:'95%',
                              width: '20%',
                              title: "10-yr average fractional cover",
                              stretch:'horizontal',
                              padding:'0px'
                              //chartArea: {height: '40%'}
                              //legend: {position: 'none'},
                              });
                              */
    var chart3 = ui.Chart.image.byRegion(selected_anom.select([0,1,2],['green','non-green','bare']),selected_box, ee.Reducer.median(), 500)
                              .setChartType('BarChart')
                              .setOptions({
                              colors:['red','green','blue'],
                              vAxis: {textColor:"#ffffff"},
                              hAxis: {title: 'Standard deviation', viewWindow: {min: -2, max: 2}, textStyle: {fontSize:10}, ticks:[-2,-1,0,1,2]},
                              height:'90%',
                              width: '20%',
                              title: "Anomalies (week of "+value+")",
                              //stretch:'horizontal',
                              padding:'0px'
                              });
    chart_pan.add(chart0);
    chart_pan.add(chart1);
    chart_pan.add(chart3);
    var toDownload = selected_mean.select(0,1,2).addBands(selected_index).addBands(firemask).clip(selected_box)
    var id = ee.Feature(selected_box.first()).id().getInfo()
    var params = {
    region: selected_box.geometry().bounds(),
    filePerBand: true,
    scale:500,
    name: 'zone_'+id+'_'+value
    }
    legendPanel.widgets()
          .set(8,
          ui.Label(
            'Click to download selected zone data as geotiff',
            {fontSize: '12px', fontWeight: 'bold', backgroundColor:'white',color:'blue'},
            toDownload.getDownloadURL(params)
            )
            );
});
}
});
/*DESIGN UI ELEMENTS*/
var mapPanel = ui.Map();
var makeGrid = require('users/savannalabnmsu/misc:makeGrid.js');
var grid = makeGrid.setGrid(mapPanel,aoi.geometry().bounds(),50000,'white')
//print(grid)
// Center the map
mapPanel.centerObject(sen, 6.5);
// Add these to the interface.
ui.root.setLayout(ui.Panel.Layout.flow('vertical'));
ui.root.widgets().reset([mapPanel]);
var baseChange = [
  {
    featureType: 'all', 
    stylers: [{invert_lightness: true}]
  },
  {
    featureType: 'all', 
    elementType:'labels',
    stylers: [{visibility: 'off'}]
  },
  {
    featureType: 'all',
    elementType: 'geometry.stroke',
    stylers: [{visibility: 'off'}]
  },
   {
    featureType: 'all',
    elementType: 'geometry.fill',
    stylers: [{color: '#555555'}]
  },
  {
    featureType: 'water',
    stylers: [{color: '#B0E0E6'}]
  },
  {
    featureType: 'administrative',
    elementType: 'labels',
    stylers: [{visibility:'on',color: '#ffffff'}]
  },
  {
    featureType: 'administrative.country',
    elementType: 'geometry.stroke',
    stylers: [{visibility:'on',color: '#555555'}]
  },
];
//mapPanel.setOptions('baseChange', {'baseChange':baseChange});
mapPanel.setOptions('hybrid')
mapPanel.setControlVisibility(
    {all: false, zoomControl: true,layerList:true, scaleControl:true}
    );
// Add a title and some explanatory text to a tool panel
var header = ui.Label('Dry Season Vegetation Monitoring in West African Savannas', {fontSize: '16px', fontWeight: 'bold', color: 'yellow', backgroundColor:'black'});
var toolPanel = ui.Panel([], ui.Panel.Layout.Flow('horizontal'), {height:'40%'});
ui.root.widgets().add(toolPanel);
//create panel to hold body of info and add to toolPanel
var body = ui.Panel(
    [header], 'flow', {width: '15%', backgroundColor:'black'});
toolPanel.add(body);
//create panel to hold chart and add to toolPanel
var chart_pan = ui.Panel([],ui.Panel.Layout.flow('horizontal'));
chart_pan.style().set({
width: '85%',
height:'100%'
});
toolPanel.add(chart_pan);
//create panel for select date menu and add to body
var select_panel = ui.Panel(
  [
    ui.Label( 'Select a date to display weekly data',{fontSize: '13px', fontWeight:'bold', color:'white', backgroundColor:'black'}),
    ui.Label(
      '*Each date represents the mid-point of the week used to composite satellite data.\n'
      +'Data from mid-June to mid-September (core wet months)  are exluded.',
      {fontSize: '11px', color:'white', backgroundColor:'black'}),
    selectDay
    ],
    'flow',{backgroundColor:'black'});
body.add(select_panel);
//create click label  
var click_label
  = ui.Panel([],'flow', {backgroundColor:'black'});
body.add(click_label);
//click label panel to add to map
//body.add(click_label)// = ui.Panel({style: {position:'bottom-left'}});
//design legend and layer visibility options
//check boxes to show hide map layers
var cb_0 = ui.Checkbox({label:"Fractional Cover (3-band RGB)", value:true, style:{fontSize:'14px', fontWeight:'bold'}})
var cb_1 = ui.Checkbox({label:"Relative Forage Index (0-1) [Senegal Only]", value:true, style:{fontSize:'14px', fontWeight:'bold'}})
var cb_2 = ui.Checkbox({label:"Fire Mask", value:true, style:{fontSize:'14px', fontWeight:'bold'}})
cb_0.onChange(function(checked) {
  mapPanel.layers().get(0).setShown(checked);
});
cb_1.onChange(function(checked) {
  mapPanel.layers().get(1).setShown(checked);
});
cb_2.onChange(function(checked) {
  mapPanel.layers().get(2).setShown(checked);
});
// Create legend Panel to contain everything
var legendPanel = ui.Panel({
  style: {
    padding: '0px 0px',
    backgroundColor:'white',
    position: 'bottom-right',
    width: '325px',
  }
});
//add items to legend panel using pre-made functions, checkbox labels will also act as layer headings
var makeLegend = require('users/savannalabnmsu/misc:makeLegend_alt.js')//simple classified: function(names,palette)
var makeLegend2 = require('users/savannalabnmsu/misc:colorbar_alt.js')//simple colorbar: function(visparams,width, height)
var visParams_rfi = {min: 0.2, max: 0.8, palette:['saddlebrown','#D1BE9D','#3B727C']}
var legend_0 = makeLegend.createLegend(['bare soil','green vegetation','non-green vegetation'],['FF0000', '22ff00', '1500ff'])
var legend_1 = makeLegend2.makeColorBar(visParams_rfi,'300px','50px')
var legend_2 = makeLegend.createLegend(['≥ 1 active fire in the last 6 months'],['yellow'])
legendPanel.add(ui.Label('Map Key and Layer Controls',{fontSize:'16px', fontWeight:'bold'}))
legendPanel.add(cb_0)
legendPanel.add(legend_0)
legendPanel.add(cb_1)
legendPanel.add(legend_1)
legendPanel.add(cb_2)
legendPanel.add(legend_2) 
//Create an opacity slider for layers
var opacitySlider = ui.Slider({
  min: 0,
  max: 1,
  value: 1,
  step: 0.01,
  style:{width:'250px', stretch:'horizontal'}
});
opacitySlider.onSlide(function(value) {
  mapPanel.layers().forEach(function(element, index) {
    element.setOpacity(value);
  });
});
var sliderpanel = ui.Panel(
  [
    ui.Label('Adjust Layer Transparency',{fontSize: '16px', color:'black', backgroundColor:'white'}),
    opacitySlider
    ],
    'flow', {width:'275px',backgroundColor:'white'});
// add to legendPanel
legendPanel.add(sliderpanel);
print(grid)