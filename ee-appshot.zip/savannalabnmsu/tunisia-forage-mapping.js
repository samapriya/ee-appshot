var modis_lai = ui.import && ui.import("modis_lai", "imageCollection", {
      "id": "MODIS/006/MCD15A3H"
    }) || ee.ImageCollection("MODIS/006/MCD15A3H"),
    countries = ui.import && ui.import("countries", "table", {
      "id": "USDOS/LSIB/2013"
    }) || ee.FeatureCollection("USDOS/LSIB/2013"),
    geometryGradientBar = ui.import && ui.import("geometryGradientBar", "geometry", {
      "geometries": [
        {
          "type": "LineString",
          "coordinates": [
            [
              38.09028921775424,
              -0.016976405314431845
            ],
            [
              38.35396109275424,
              0.008429478195858106
            ]
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.LineString(
        [[38.09028921775424, -0.016976405314431845],
         [38.35396109275424, 0.008429478195858106]]),
    wcc = ui.import && ui.import("wcc", "image", {
      "id": "users/savannalabnmsu/wdc_tunisia_1"
    }) || ee.Image("users/savannalabnmsu/wdc_tunisia_1"),
    aoi = ui.import && ui.import("aoi", "table", {
      "id": "users/savannalabnmsu/tunisia_aoi"
    }) || ee.FeatureCollection("users/savannalabnmsu/tunisia_aoi");
/////////////////////////////////////////////////////////////////////////////////////////UI INTERFACE//////////////////////////////////////////////////////////////////////////////////
var map1 = ui.Map().setControlVisibility(false,false,true,true)
var map2 = ui.Map().setControlVisibility(false,false,true,true)
var map3 = ui.Map().setControlVisibility(false,false,true,true)
var map4 = ui.Map().setOptions('hybrid')
var changeBaseMap = require('users/savannalabnmsu/misc:removeMapIcons.js')
changeBaseMap.removeIcons(map1)
changeBaseMap.removeIcons(map2)
changeBaseMap.removeIcons(map3)
var topPanel = ui.Panel(
  [map1,map2],
  ui.Panel.Layout.flow('horizontal'),
  {width:'100%', height:'50%', backgroundColor:'#ffffff'}
  );
var bottomPanel = ui.Panel(
  [map3,map4],
  ui.Panel.Layout.flow('horizontal'),
  {width:'100%', height:'50%', backgroundColor:'#ffffff'}
  );
var mapPanel = ui.Panel(
  [topPanel,bottomPanel],
  ui.Panel.Layout.flow('vertical'),
  {width:'75%', height:'100%', backgroundColor:'#ffffff'}
  );
var linker = ui.Map.Linker([map1,map2,map3,map4]);
var sidePanel = ui.Panel(
  [
    ui.Label(
      'Monitoring forage conditions in Tunisia using Leaf Area Index ',
      { fontSize:'20px', fontWeight:'bold', width:'95%'}
      ),
    ui.Label(
    'A tool for monitoring Leaf Area Index (LAI) in North Western Tunisia. \n'
    +'MODIS derived LAI is disaggregated into woody and herbaceous components for each 500m pixel.\n'
    +'LAI is defined as total leaf surface area per unit ground area, \n'
    +'and is used here as a proxy for crop/forage conditions at a given location.',
    { fontSize:'18px', width:'95%'}),
    ui.Label('See Kahiu and Hanan (2018) for more details on methods.',
    { fontSize:'12px', width:'95%'},
    'https://agupubs.onlinelibrary.wiley.com/doi/full/10.1002/2017JG004105'
    ),
     ui.Label(
    'Resolution: 500m',
    { fontSize:'13px', width:'95%'}),
     ui.Label(
    'Choose a date',
    { fontSize:'14px', fontWeight:'bold', width:'95%'})
    ],
  ui.Panel.Layout.flow('vertical'),
  {width:'25%', height:'100%', backgroundColor:'#ffffff'}
  );
ui.root.setLayout(ui.Panel.Layout.flow('horizontal'));
ui.root.widgets().reset([mapPanel,sidePanel]);  
var labelPosition = ee.Geometry.Point([9,35.8]);
//create legend
var visLAI = {min:0,max:5,palette:['grey','yellow','green','blue']}
var visWCC = {min:0,max:1,palette:["b45133","e29c32","b9f347","22c02e"]}
var createLegend = require('users/savannalabnmsu/misc:colorbar.js')
var legend1 = createLegend.makeColorBar(visLAI, 'Leaf Area Index','85%','15%','bottom-left',14);
var legend2 = createLegend.makeColorBar(visWCC, 'Woody Canopy Cover','85%','15%','bottom-left',14);
var label1 = ui.Panel([ui.Label('Aggregate LAI',{backgroundColor:'ffffff',fontSize:'17px', fontWeight:'bold'})],'',{position:'top-center',backgroundColor:'ffffff'});
var label2 = ui.Panel([ui.Label('Woody LAI',{backgroundColor:'ffffff',fontSize:'17px', fontWeight:'bold'})],'',{position:'top-center',backgroundColor:'ffffff'});
var label3 = ui.Panel([ui.Label('Herbaceous LAI',{backgroundColor:'ffffff',fontSize:'17px', fontWeight:'bold'})],'',{position:'top-center',backgroundColor:'ffffff'});
var label4 = ui.Panel([ui.Label('Woody Cover Fraction',{backgroundColor:'ffffff',fontSize:'17px', fontWeight:'bold'})],'',{position:'top-center',backgroundColor:'ffffff'});
map1.add(label1)
map2.add(label2)
map3.add(label3)
map4.add(label4)
////////////////////////////////////////////////////////////////////////////////////MAIN ALGORITHM///////////////////////////////////////////////////////////////////////////////////////////
var cntry = countries.filterMetadata("name","equals","Tunisia");
//var col = modis_lf.filterDate('2019-01-01',Date.now())
var prj = modis_lai.first().projection()
print(prj)
/*
var MeanAP = chirps2.filterDate('1981-01-01','2020-01-01')
                    .map(function(image){return image.resample('bilinear')
                    .clip(cntry.geometry().bounds())})
                    .sum()
                    .divide(39)
                    .reproject(prj)
                    .select([0],['MAP'])
//Export.image.toAsset({image:MeanAP,region:cntry.geometry().bounds(),scale:463.312716528,maxPixels:1e13})
*/
var wcc5 = wcc.resample('bilinear').reproject(prj).select([0],['wcc'])
                     .unitScale(5,75)
var wcc500 = wcc5.where(wcc5.lte(0),0).where(wcc5.gte(1),1)
map4.addLayer(wcc500,visWCC,'woody canopy cover')
map4.addLayer(aoi.style({color:'black',fillColor:'00000000'}),{},'Selected Districts')
//Map.addLayer(MeanAP,wiz_map,'MAP')
//Map.addLayer(wcc500,viz_wcc,'tree cover')
//Map.centerObject(cntry,7)
//apply quality filter and cloud mask to modis lai. Bit 0(good quality = 0) and bits 3-4(clear clouds = 0 or 3)
var qualmask = ee.Number(2).pow(0).int()//bit 0
var cloudmask1 = ee.Number(2).pow(3).int()//bit 3
var cloudmask2 = ee.Number(2).pow(4).int()//bit 4
function qualityMask(image) {
  var qb = image.select('FparLai_QC');
  var mask = qb.bitwiseAnd(qualmask).eq(0)//goood qlty
  return image.updateMask(mask).clipToCollection(aoi);//clip cloud-masked image to area of interest
}
//var masked = col.map(qualityMask);
// Use a DateSlider to create composites for selected weekly intervals.
// Use Jan 1 2017to date of most recent image to bound the slider.
var start = ee.Date('2017-01-01')
var latest = modis_lai.sort('system:time_start',false).first().get('system:time_start')
var end = ee.Date(latest)
//computes LAI metrics for a given date using maximum value composite of a 16 day window (+/- 8 days)
//this guarantees at least 4-5 images per pixel for gap-filled composites (MODIS LAI product has 4 days interval)
var n_days = end.difference(start,'day').round();
var date_index_list = ee.List.sequence(0,n_days.subtract(1),8);
var make_datelist = function(n) {
  return start.advance(n,'day').format('Y-MM-dd');
};
var datelist = date_index_list.map(make_datelist);
print(datelist)
var compute_lai = function(d){
  var date = ee.Date(d) 
//create a 16 day maximum LAI composite around given date
  var composite = modis_lai.filterDate(date.advance(-8,'day'), date.advance(9,'day'))
                .map(qualityMask)
                .qualityMosaic('Lai')
                .select('Lai')
                .multiply(0.1)
  //commpute maximum dry LAI for the given year as peak woody LAI
  var year  = ee.Number.parse(ee.Date(date).format('YYYY')) 
  var maxLAI =  modis_lai.filter(ee.Filter.calendarRange(year,year,'year')) 
                         .filter(ee.Filter.calendarRange(6,8,'month')) 
                         .map(qualityMask)
                         .qualityMosaic('Lai')
                         .multiply(0.1)
                         .select('Lai')
  //peak woody in-canopy LAI to landscape using woody cover fraction
  var LAIwp = maxLAI.multiply(wcc500)
  //retrive aggregate lai
  var LAIagg = composite.select([0],['Lai_agg'])
  //woody lai
  var LAIw = ee.Image(LAIwp.where(LAIwp.gt(LAIagg),LAIagg)).select([0],['Lai_w'])
// herbaceous lai
  var LAIh = LAIagg.subtract(LAIw).where(wcc500.gte(1),0).select([0],['Lai_h'])
  return LAIagg.addBands(LAIw).addBands(LAIh).set('system:time_start',date.millis())
}
var processed = ee.ImageCollection.fromImages(datelist.map(compute_lai))
print(processed)
//creat gif animations for each band
var text = require('users/gena/packages:text') ;
var data1 = processed.map(function(image){
  var date = ee.Date(image.get('system:time_start')).format('YYYY-MM-dd');
  var label = text.draw(date, labelPosition, 1500, { 
      fontSize: 18, textColor: '000000', fontType: 'Consolas',
      outlineColor: 'ffffff', outlineWidth: 2.5, outlineOpacity: 0.6
  });
  return image.select('Lai_agg').visualize(visLAI).blend(label);
});
var data2 = processed.map(function(image){
  var date = ee.Date(image.get('system:time_start')).format('YYYY-MM-dd');
  var label = text.draw(date, labelPosition, 1500, { 
      fontSize: 18, textColor: '000000', fontType: 'Consolas',
      outlineColor: 'ffffff', outlineWidth: 2.5, outlineOpacity: 0.6
  });
  return image.select('Lai_w').visualize(visLAI).blend(label);
});
var data3= processed.map(function(image){
  var date = ee.Date(image.get('system:time_start')).format('YYYY-MM-dd');
  var label = text.draw(date, labelPosition, 1500, { 
      fontSize: 18, textColor: '000000', fontType: 'Consolas',
      outlineColor: 'ffffff', outlineWidth: 2.5, outlineOpacity: 0.6
  });
  return image.select('Lai_h').visualize(visLAI).blend(label);
});
//var gif1 = ui.Thumbnail(data1,{framesPerSecond:5,region:aoi.geometry().bounds()},{},{height:'200px',width:'200px',position:'bottom-left', backgroundColor:'black'});
//var gif2 = ui.Thumbnail(data2,{framesPerSecond:5,region:aoi.geometry().bounds()},{},{height:'200px',width:'200px',position:'bottom-left', backgroundColor:'black'});
//var gif3 = ui.Thumbnail(data3,{framesPerSecond:5,region:aoi.geometry().bounds()},{},{height:'200px',width:'200px',position:'bottom-left', backgroundColor:'black'});
data1.evaluate(function(collection){
  map1.add(ui.Thumbnail(data1,{framesPerSecond:5,region:aoi.geometry().bounds()},{},{height:'200px',width:'200px',position:'bottom-left', backgroundColor:'black'}));
})
data2.evaluate(function(collection){
 map2.add(ui.Thumbnail(data1,{framesPerSecond:5,region:aoi.geometry().bounds()},{},{height:'200px',width:'200px',position:'bottom-left', backgroundColor:'black'}));
})
data3.evaluate(function(collection){
  map3.add(ui.Thumbnail(data1,{framesPerSecond:5,region:aoi.geometry().bounds()},{},{height:'200px',width:'200px',position:'bottom-left', backgroundColor:'black'}));
})
//map1.add(gif1);
//map2.add(gif2);
//map3.add(gif3);
//function display specific image
// Run this function on change of the dateSlider.
var display_lai = function(range) {
  var image = processed.filterDate(range.start().advance(-8,'day'),range.start().advance(9,'day')).first()
  print(image)
  // Asynchronously compute diferent layers and display
  range.start().format('YYYY-MM-dd').evaluate(function(name) {
    //Map.addLayer(LAIWpinc,viz3,'inc LAIw')
    var layer1 = ui.Map.Layer(image.select('Lai_agg'), visLAI, name + ' aggregate LAI');
    var layer2 = ui.Map.Layer(image.select('Lai_w'), visLAI, name + ' woody LAI');
    var layer3 = ui.Map.Layer(image.select('Lai_h'), visLAI, name + ' herbaceous LAI');
    map1.layers().set(0, layer1);
    map2.layers().set(0, layer2);
    map3.layers().set(0, layer3);
    map1.centerObject(aoi,7);
  });
};
// Asynchronously compute the date range function and show the slider.
var dateRange = ee.DateRange(start, end).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: 9,
    onChange: display_lai,
    style:{width:'95%',height:'100px'}
  });
 sidePanel.add(dateSlider.setValue(ee.Date(latest).format('YYYY-MM-dd').getInfo())); 
 sidePanel.add(legend1)
sidePanel.add(legend2)
 // Add the panel to the UI
 sidePanel.add(inspector);
});
/*
var style = require('users/gena/packages:style')
//var minMax = dem.reduceRegion(ee.Reducer.percentile([1, 99]), Map.getBounds(true), Map.getScale()).values()
//var min = ee.Number(minMax.get(0))
//var max = ee.Number(minMax.get(1))
var palette = ['e47b31','ffd716','ffff00','40d61a','2e9127']
var min = ee.Number(0)
var max = ee.Number(5)
var textProperties = { fontSize:16, textColor: '000000', outlineColor: 'ffffff', outlineWidth: 2, outlineOpacity: 0.6 }
var labels = ee.List.sequence(min, max, max.subtract(min).divide(5))
var legend = style.GradientBar.draw(
      geometryGradientBar,
      {min: min, max: max, palette: palette, labels: labels, format: '%.0f', text: textProperties}
      )
*/    
//print(map1.layers())
///////////////////////////////INSPECTOR PANEL////////////////////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {width:'65%'},
});
// add sub panels for point labels
var inspector0 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  //style: {width:'60%'},
});
var inspector1 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  //style: {width:'60%'},
});
var inspector2 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  //style: {width:'60%'},
});
var inspector3 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  //style: {width:'60%'},
});
inspector.add(ui.Label('Click on map to inspect value',{fontSize:'18px',fontWeight:'bold'}));
inspector.add(inspector0);
inspector.add(inspector1);
inspector.add(inspector2);
inspector.add(inspector3);
map1.style().set('cursor', 'crosshair');
map2.style().set('cursor', 'crosshair');
map3.style().set('cursor', 'crosshair');
map4.style().set('cursor', 'crosshair');
// Register a callback on the map to be invoked when the map is clicked.
function reportVal(mp){
  mp.onClick(function(coords) {
  //Clear the panel and show a loading message.
  inspector0.clear();
  inspector0.style().set('shown', true);
  inspector0.add(ui.Label('Loading...', {color: 'gray'}));
  inspector1.clear();
  inspector1.style().set('shown', true);
  inspector1.add(ui.Label('Loading...', {color: 'gray'}));
  inspector2.clear();
  inspector2.style().set('shown', true);
  inspector2.add(ui.Label('Loading...', {color: 'gray'}));
  inspector3.clear();
  inspector3.style().set('shown', true);
  inspector3.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the LAI value at clicked location
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var agg = ee.Image(map1.layers().get(0).getEeObject())
  var woody = ee.Image(map2.layers().get(0).getEeObject())
  var herb = ee.Image(map3.layers().get(0).getEeObject())
  var sampledPoint1 = agg.reduceRegion(ee.Reducer.mean(), point, 500);
  var sampledPoint2 = woody.reduceRegion(ee.Reducer.mean(), point, 500);
  var sampledPoint3 = herb.reduceRegion(ee.Reducer.mean(), point, 500);
  var aggValue = ee.Algorithms.If(point.intersects(cntry.geometry()),sampledPoint1.get('Lai'),'Null');
  var woodyValue = ee.Algorithms.If(point.intersects(cntry.geometry()),sampledPoint2.get('Lai'),'Null');
  var herbValue = ee.Algorithms.If(point.intersects(cntry.geometry()),sampledPoint3.get('Lai'),'Null');
  //var covValue = sampledPoint.get('predicted_RF');
  //var bmValue = sampledPoint.get('bm_RF');
 //display coordinates at selected point 
    inspector0.clear();
    inspector0.add(ui.Label({
     value: 'lat/lon: ' + coords.lat.toFixed(2) +', '+ coords.lon.toFixed(2),
      style: {stretch: 'vertical'}
    }));
  //});
  // Request the corresp. aggregate lai value from the server and add as label to inspector panels
   aggValue.evaluate(function(result) {
    inspector1.clear();
    inspector1.add(ui.Label({
      value: 'Aggregate LAI: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
  });
  // do same for woody and herbaceous LAI
   woodyValue.evaluate(function(result) {
    inspector2.clear();
    inspector2.add(ui.Label({
      value: 'Woody LAI: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
   });
   herbValue.evaluate(function(result) {
    inspector3.clear();
    inspector3.add(ui.Label({
      value: 'Herbaceous LAI: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
   });
});
}
reportVal(map1);
reportVal(map2);
reportVal(map3);
reportVal(map4);