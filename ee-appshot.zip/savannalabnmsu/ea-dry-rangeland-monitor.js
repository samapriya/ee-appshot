var counties = ui.import && ui.import("counties", "table", {
      "id": "FAO/GAUL/2015/level2"
    }) || ee.FeatureCollection("FAO/GAUL/2015/level2"),
    chirps = ui.import && ui.import("chirps", "imageCollection", {
      "id": "UCSB-CHG/CHIRPS/DAILY"
    }) || ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY"),
    lewa = ui.import && ui.import("lewa", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            37.41405024006693,
            0.22152958809732265
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Point([37.41405024006693, 0.22152958809732265]),
    wcc = ui.import && ui.import("wcc", "image", {
      "id": "users/savannalabnmsu/treecover_kenya/wcc_ke_eth_2020"
    }) || ee.Image("users/savannalabnmsu/treecover_kenya/wcc_ke_eth_2020"),
    samples = ui.import && ui.import("samples", "table", {
      "id": "users/savannalabnmsu/ke_dry_modis"
    }) || ee.FeatureCollection("users/savannalabnmsu/ke_dry_modis"),
    nbar = ui.import && ui.import("nbar", "imageCollection", {
      "id": "MODIS/006/MCD43A4"
    }) || ee.ImageCollection("MODIS/006/MCD43A4"),
    aoi = ui.import && ui.import("aoi", "table", {
      "id": "users/savannalabnmsu/kenya_north"
    }) || ee.FeatureCollection("users/savannalabnmsu/kenya_north");
var chartpan = ui.Panel([],'flow',{height:'100%',width:'80%'});
var sidePanel = ui.Panel(
  [
    ui.Label(
      'Monitoring Dry Season Land Conditions in Northern Kenyan Rangelands',
      { fontSize:'16px', fontWeight:'bold', width:'95%',backgroundColor:'grey',color:'#000000'}),
    ui.Label('Lignin/Cellose Absorption Index (LCAI)):',{ fontSize:'12px', fontWeight:'bold', width:'95%',backgroundColor:'grey',color:'#000000'}),
    ui.Label(
      'LCAI  highlights the relatively higher lignin/cellulose absorption feature in non-photosynthetic plant material.\n'
      +'Calculated as 2*SWIR_2205nm - SWIR_2165nm - SWIR_2330nm (See Daughtry et. al 2005, Serbin et. al 2009).\n'
   +'In this application, LCAI is predicted from MODIS VNIR/SWIR bands using boosted regression \n'
   +'models trained/evaluated with LCAI measurements derived  directly from Worldview-3 SWIR images.',
   {fontSize:'12px',backgroundColor:'grey',color:'black'}),
    ui.Label('LCAI and EVI-2 anomalies:',{ fontSize:'12px', fontWeight:'bold', width:'95%',backgroundColor:'grey',color:'#000000'}),  
    ui.Label(
   'Tracks relative non-active/active vegetation conditions across space and time.',
   {fontSize:'12px',backgroundColor:'grey',color:'black'}),
   ui.Label('click on any map to display timeseries chart'),
    ui.Label(
      'choose a date',
      { fontSize:'16px', fontWeight:'bold', width:'95%',backgroundColor:'grey',color:'#000000'}
      )],
      ui.Panel.Layout.flow('vertical'),
  {width:'20%', height:'100%', backgroundColor:'grey'}
  );
var rgb = {bands:['red','green','blue'], min:100,max:2000}  ;
var viz_dry = { min:0.4,max:0.7,palette:['saddlebrown','white','yellow']};
var viz_ndvi = { min:0.1,max:0.5,palette:['saddlebrown','white','green']};
var createLegend = require('users/savannalabnmsu/misc:colorbar.js');
var legend1 = createLegend.makeColorBar(viz_dry, 'Lignin/Cellulose Absorption Index','400px','100px','bottom-left','16px');
var legend2 = createLegend.makeColorBar(viz_ndvi, 'Greenness (EVI2)','400px','100px','bottom-left','16px');  
var toolPanel = ui.Panel([sidePanel,chartpan],ui.Panel.Layout.flow('horizontal'),{height:'50%',width:'100%'}) ;
var map1 = ui.Map().setControlVisibility('all',true, false, true).setOptions('terrain');
var map2 = ui.Map().setControlVisibility('all',true, false, true).setOptions('satellite').add(legend1);
var map3 = ui.Map().setControlVisibility('all',true, false, true).setOptions('satellite').add(legend2);
var maps = [map1,map2,map3];
ui.Map.Linker(maps,'change-center');
ui.Map.Linker([map2,map3]);
var mapPanel = ui.Panel([map1,map2,map3],ui.Panel.Layout.flow('horizontal'),{height:'50%',width:'100%'});
ui.root.setLayout(ui.Panel.Layout.flow('vertical'));
ui.root.widgets().reset([mapPanel,toolPanel]);
var area = aoi;
var labelPosition = ee.Geometry.Point([36.5,-0.5]);
map1.centerObject(area,6);
map2.centerObject(ee.Geometry.Point([36.5,1.5]),7);
map3.centerObject(ee.Geometry.Point([36.5,1.5]),7);
///Model/////
var xvars = [
    'blue','green','red','nir',
    'swir12','swirND','swir1','swir2',
    'ndvi','msavi'
    ];
var GBTmodel = function(data,yvar,xvars){
 var classifier =  
   ee.Classifier.smileGradientTreeBoost({
                        numberOfTrees:500, 
                        shrinkage:0.01,
                        loss:'Huber',
                        samplingRate:0.9,
                        maxNodes:ee.Number(2).pow(5)
                        })
                        .setOutputMode('REGRESSION') ;
  return classifier.train(data,yvar,xvars);
};
var model_lca = GBTmodel(samples,'lca',xvars);
var oldNames = ['Nadir_Reflectance_Band3','Nadir_Reflectance_Band4',
                   'Nadir_Reflectance_Band1','Nadir_Reflectance_Band2',
                     'Nadir_Reflectance_Band6','Nadir_Reflectance_Band7'];
var newNames = ['blue','green','red','nir','swir1','swir2'];
var start = ee.Date('2016-01-01');
var end = ee.Date('2020-12-31')
           //ee.Date(nbar.sort('system:time_start',false).first().get('system:time_start'));
var n_days = end.difference(start,'day').round();
print(n_days);
var date_index_list = ee.List.sequence(0,n_days.subtract(1),7);
var date_index_list_2 = ee.List.sequence(0,n_days.subtract(1),28);
var make_datelist = function(n) {
  return start.advance(n,'day').format('Y-MM-dd');
};
var dates = date_index_list.map(make_datelist);//.getInfo();
var dates2 = date_index_list_2.map(make_datelist).getInfo();
print(dates,dates2);
function addVegIndices(image){
  var ndvi = image.normalizedDifference(['nir', 'red'])
                   .select([0],['ndvi']);
  var msavi = image.expression(
                           '(2 * NIR + 1 - sqrt(pow((2 * NIR + 1), 2) - 8 * (NIR - RED)) ) / 2', 
                           {
                             'NIR': image.select('nir').divide(10000), 
                             'RED': image.select('red').divide(10000)
                             })
                             .select([0],['msavi']);
  var evi2 =  image.expression(
    '2.5*((n-r)/(n+2.4*r+1))',
    {
      'n':image.select('nir').divide(10000),
      'r':image.select('red').divide(10000)
    })
    .select([0],['evi2']);
  var swir12 = image.select('swir1').divide(image.select('swir2')).select([0],['swir12']);
  var swirND = image.normalizedDifference(['swir1','swir2']).select([0],['swirND']);
  var ndsi = image.normalizedDifference(['swir1','nir']).select([0],['ndsi']);
  return image.addBands(ndvi).addBands(msavi).addBands(evi2).addBands(swir12).addBands(swirND).addBands(ndsi);
}
var compute = function(d){
  var date = ee.Date(d);
  var label =  date.format('YYYY-MM-dd');
  var criteria = ee.Filter.and(
  ee.Filter.bounds(area),
  ee.Filter.date(date.advance(-8,'day'), date.advance(8,'day'))
  );
  var modis = nbar.filter(criteria);
  var mosaic = modis
                .select(oldNames,newNames)//rename old band names with new ones
                .map(function(image){return image.clip(area)})
                .map(addVegIndices)
                .qualityMosaic('evi2');
  var ppt = chirps.filterDate(date.advance(-16,'day'), date)
                  .sum()
                  .clip(area)
                  .select([0],['ppt'])
  var lca = mosaic.classify(model_lca,'lca')
                   .multiply(10)
  var lca_scaled = lca.unitScale(0.4,0.7)
  lca_scaled = lca_scaled.where(lca_scaled.lt(0),0).where(lca_scaled.gt(1),1)
  var ndvi = mosaic.select('ndvi')
  var ndvi_scaled = ndvi.unitScale(0.2,0.8)
  ndvi_scaled = ndvi_scaled.where(ndvi_scaled.lt(0),0).where(ndvi_scaled.gt(1),1)
  var ndsi = mosaic.select('ndsi')
  var ndsi_scaled = ndsi.unitScale(-0.3,0.3)
  ndsi_scaled = ndsi_scaled.where(ndsi_scaled.lt(0),0).where(ndsi_scaled.gt(1),1)
  var relD = lca_scaled.addBands(ndvi_scaled).normalizedDifference(['lca','ndvi']).select([0],['relD'])
  //var relD2 = lca.addBands(ndsi_scaled).normalizedDifference(['lca','ndsi']).select([0],['relD'])
  //var relD = ee.ImageCollection([relD1,relD2]).max().select([0],['relD'])
  /*
     lca_images.filter(criteria)
                .qualityMosaic('msavi')
                //.median()
                .addBands(wcc.select(0).divide(100).clip(area).select([0],['woody cover']))
                .clip(area)
                .addBands(ppt)
                .map(function(image){ 
                  var lca =  image.clip(area.geometry().bounds()).classify(model_lca,'lca')
                      //.unitScale(0.03,0.07)
                      .multiply(10)
                  var lca_scaled = lca//.where(lca.lt(0),0).where(lca.gt(1),1)
                  var msavi = image.clip(area.geometry().bounds()).select('msavi')//.unitScale(0.3,0.8)
                                          //.multiply(100)
                  var msavi_scaled = msavi//.where(ndvi.lt(0),0).where(ndvi.gt(1),1)
                  var relD = lca_scaled.addBands(msavi_scaled)
                                        .normalizedDifference(['lca','msavi'])
                                        .select([0],['rDry'])
                  //var ndsi = image.select('ndsi')//.unitScale(-0.3,0.3)
                  //var ndsi_scaled = ndsi//.where(ndsi.lt(0),0).where(ndsi.gt(1),1)
                  return image.addBands(lca_scaled).addBands(msavi_scaled).addBands(relD)//.addBands(ndsi_scaled)
                  .copyProperties(image,['system:time_start'])
                })
    */            
  return mosaic.select('blue','green','red','evi2').addBands(lca).addBands(ppt).addBands(relD)
      .addBands(ndsi_scaled)
      .addBands(wcc.select([0],['wcc']))
      .clip(area).set('system:time_start',date.millis())
  }
var result = ee.ImageCollection.fromImages(dates.map(compute))
print('results',result)
var pkg_smooth = require('users/savannalabnmsu/misc:linear_smooth.js');
var lca = pkg_smooth.linearInterp(result.select('lca'), 32, 3.4028237e38)
var relD = pkg_smooth.linearInterp(result.select('relD'), 32, 3.4028237e38)
var ndvi = pkg_smooth.linearInterp(result.select('evi2'), 32, 3.4028237e38)
var ndsi = pkg_smooth.linearInterp(result.select('ndsi'), 32, 3.4028237e38)
var blue = pkg_smooth.linearInterp(result.select('blue'), 32, 9999)
var green = pkg_smooth.linearInterp(result.select('green'), 32, 9999)
var red = pkg_smooth.linearInterp(result.select('red'), 32, 9999)
var ppt = result.select('ppt')
var cov = result.select('wcc')
///Combine image collections
var filter = ee.Filter.equals({
  leftField: 'system:time_start',
  rightField: 'system:time_start'
});
// Create the join.
var simpleJoin = ee.Join.inner();
// Inner join
var innerJoin = ee.ImageCollection(simpleJoin.apply(blue, green, filter))
var joined = innerJoin.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
})
var innerJoin = ee.ImageCollection(simpleJoin.apply(joined, red, filter))
var joined = innerJoin.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
})
var innerJoin = ee.ImageCollection(simpleJoin.apply(joined, lca, filter))
var joined = innerJoin.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
})
var innerJoin = ee.ImageCollection(simpleJoin.apply(joined, relD, filter))
var joined = innerJoin.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
})
var innerJoin = ee.ImageCollection(simpleJoin.apply(joined, ndvi, filter))
var joined = innerJoin.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
})
var innerJoin = ee.ImageCollection(simpleJoin.apply(joined, ndsi, filter));
var joined = innerJoin.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
})
var innerJoin = ee.ImageCollection(simpleJoin.apply(joined, ppt, filter));
var joined = innerJoin.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
});
var innerJoin = ee.ImageCollection(simpleJoin.apply(joined, cov, filter));
var joined = innerJoin.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
});
print('Joined', joined);
//compute anomalies
var collection =  joined.select('evi2','lca','ppt','wcc');
var mean_img = collection.select('evi2','lca','ppt').median();
var sD_img = collection.select('evi2','lca','ppt').reduce(ee.Reducer.stdDev());
print(mean_img,sD_img)
/*
var min_max = result.first().reduceRegion({
                        reducer:ee.Reducer.percentile([5,95]),
                        geometry:area,
                        scale:100,
                        maxPixels:1e12,
                        tileScale:16
                        })
print(min_max)
  var lca = mosaic.select('lca').unitScale(min_max.get('lca_p5'),min_max.get('lca_p95'))
  var ndvi = mosaic.select('ndvi').unitScale(min_max.get('ndvi_p5'),min_max.get('ndvi_p95'))
*/
var text = require('users/gena/packages:text') ;
var data1 = joined.map(function(image){
  var date = ee.Date(image.get('system:time_start')).format('YYYY-MM-dd');
  //image = image.changeProj(ee.Projection('EPSG:5070').atScale(1), ee.Projection('EPSG:3857').scale(1.3, 1.3).translate(-8000000, 1800000)) 
  var label = text.draw(date, labelPosition, 4500, { 
      fontSize: 18, textColor: '000000', fontType: 'Consolas',
      outlineColor: 'ffffff', outlineWidth: 2.5, outlineOpacity: 0.6
  });
  return image.visualize(rgb).blend(label);
});
var data2 = joined.map(function(image){
  var date = ee.Date(image.get('system:time_start')).format('YYYY-MM-dd');
  //image = image.changeProj(ee.Projection('EPSG:5070').atScale(1), ee.Projection('EPSG:3857').scale(1.3, 1.3).translate(-8000000, 1800000)) 
  var label = text.draw(date, labelPosition, 4500, { 
      fontSize: 18, textColor: '000000', fontType: 'Consolas',
      outlineColor: 'ffffff', outlineWidth: 2.5, outlineOpacity: 0.6
  });
  return image.select('lca').visualize(viz_dry).blend(label);
});
var data3 = joined.map(function(image){
  var date = ee.Date(image.get('system:time_start')).format('YYYY-MM-dd');
  //image = image.changeProj(ee.Projection('EPSG:5070').atScale(1), ee.Projection('EPSG:3857').scale(1.3, 1.3).translate(-8000000, 1800000)) 
 var label = text.draw(date, labelPosition, 4500, { 
      fontSize: 18, textColor: '000000', fontType: 'Consolas',
      outlineColor: 'ffffff', outlineWidth: 2.5, outlineOpacity: 0.6
  });
  return image.select('evi2').visualize(viz_ndvi).blend(label);
});
var gif1 = ui.Thumbnail(data1,{framesPerSecond:2,region:area.geometry().bounds()},{},{height:'250px',width:'250px',position:'top-left'});
var gif2 = ui.Thumbnail(data2,{framesPerSecond:2,region:area.geometry().bounds()},{},{height:'250px',width:'250px',position:'top-left'});
var gif3 = ui.Thumbnail(data3,{framesPerSecond:2,region:area.geometry().bounds()},{},{height:'250px',width:'250px',position:'top-left'});
//map1.add(gif1);
map2.add(gif2);
map3.add(gif3);
//print(data2.getVideoThumbURL({framesPerSecond:2,region:area.geometry().bounds(),dimensions:500}));
// Use a DateSlider to create composites for selected weekly intervals.
var start = ee.Date('2020-01-01').format();
var latest = joined.sort('system:time_start',false).first().get('system:time_start');
var end = ee.Date(latest).format();
var addLayer = function(range) {
  var image = joined.filterDate(range.start().advance(-7,'day'), range.start().advance(1,'day')).sort('system:time_start',false).first();
  // Asynchronously add layers and display
  range.start().format('YYYY-MM-dd').evaluate(function(name) {
    //map1.setZoom(6);
    map1.layers().set(0,ui.Map.Layer(image,rgb,'RGB'));
    map1.layers().set(1,ui.Map.Layer(area.style({color:'black',fillColor:'00000000'}),{},'AOI'));
    map2.layers().set(0,ui.Map.Layer(image.select('lca'),viz_dry,name+' LCAI'));
    map3.layers().set(0,ui.Map.Layer(image.select('evi2'),viz_ndvi,name+' EVI2'));
  });
};
// Asynchronously compute the date range function and show the slider.
var dateRange = ee.DateRange(start, end).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: 1,
    onChange: addLayer,
    style:{width:'95%',backgroundColor:'grey',color:'black'}
  });
 sidePanel.add(dateSlider.setValue(ee.Date(latest).format('YYYY-MM-dd').getInfo())); 
});
var smooth = require('users/savannalabnmsu/misc:savitzy_smooth');
maps.map(function(map){
 map.onClick(function(coordinates) {
    // get coordinates for clicked point 
    var point = ee.Geometry.Point(coordinates.lon, coordinates.lat);
    var zone = ee.FeatureCollection([point]);
    //center and further zoom into selected point
    map1.layers().set(2,ui.Map.Layer(zone.style({color:'blue',pointSize:10}),{},'zone'));
    map2.layers().set(1,ui.Map.Layer(zone.style({color:'blue',pointSize:10}),{},'zone'));
    map3.layers().set(1,ui.Map.Layer(zone.style({color:'blue',pointSize:10}),{},'zone'));
    map2.centerObject(point,15);
    map1.centerObject(point,10);
    var anomalies = collection.filterDate('2020-01-01','2020-12-31').map(function(image){
      var img  = image.select('evi2','lca','ppt')//.clip(point.buffer(100,1));
      var wc = image.select('wcc')
      var mean = mean_img//.clip(point.buffer(100,1));
      var sd = sD_img//.clip(point.buffer(100,1));
      return img.subtract(mean).divide(sd).addBands(wc).copyProperties(image,['system:time_start']);
    });
    var filtered = anomalies
                    .map(function(img){
                          var ts = ee.Date(img.get('system:time_start')).format('YYYY-MM-dd');
                          return ee.Image(img)//.copyProperties(img,['system:time_start']))
                                .sample({region:point, scale: 500,factor:1})
                                .map(function(f){return f.set('date',ts)});
                         })
                         .flatten()
    print('point data',filtered);                
    var y1 = smooth.smooth(
      filtered.aggregate_array('lca'),15);
    var y2 = smooth.smooth(
      filtered.aggregate_array('evi2'),15);
   // var y3 = smooth.smooth(filtered.aggregate_array('ndsi'),15);
    var y3 = smooth.smooth(
      filtered.aggregate_array('ppt'),15);
    var y4 = smooth.smooth(
      filtered.aggregate_array('wcc'),15);
    var yValues = ee.List([y1,y2,y3,y4]);
    print('yvals',yValues);
    var xLabels = filtered.aggregate_array('date');
    print('xvals',xLabels);
    var chart = ui.Chart.array.values(yValues, 1, xLabels)
       .setSeriesNames([
       'LCAI',
       'raw',
       'EVI2',
       'raw',
       '15-day preceding rainfall',
       'raw',
       'woody canopy cover',
       'raw'
      ])
       .setOptions({
    title: 'weekly land surface conditions in 2020', 
    curveType:'function',
    hAxis: {title: 'Date', textStyle:{fontSize: 15},titleTextStyle:{fontSize: 25,bold:true},ticks:dates2}, 
    legend: null,
    series: { 
      0: { lineWidth: 3, pointSize: 0, color:'orange'},
      1: { lineWidth: 0, pointSize: 1, color:'orange', visibleInLegend: false},
      2: { lineWidth: 3, pointSize: 0, color:'green'},
      3: { lineWidth: 0, pointSize: 1, color:'green', visibleInLegend: false},
      4: { lineWidth: 3, pointSize: 0, color:'blue'},
      5: { lineWidth: 0, pointSize: 1, color:'blue', visibleInLegend: false},
      6: { lineWidth: 4, pointSize: 0, color:'saddlebrown', targetAxisIndex:1},
      7: { lineWidth: 0, pointSize: 2, color:'saddlebrown', targetAxisIndex:1, visibleInLegend:false}
    },
      vAxes: {
            0:{title: 'Anomalies (standard deviation)', textStyle:{fontSize: 15}, titleTextStyle:{fontSize: 25, bold:true},viewWindow: {min:-3, max:3}},
            1:{title: 'Canopy Cover (%)', textStyle:{fontSize: 15},titleTextStyle:{fontSize: 25,bold:true} ,viewWindow: {min:0, max:100}}
    },
      height:'95%',
      width:'100%',
  });
    /*
    var chart = ui.Chart.image.series(
      anomalies, point, ee.Reducer.median(), 100, 'system:time_start'
      )
                    .setChartType('LineChart')
                    .setSeriesNames([
                      'LCAI',
                      //'soil index ',
                      'NDVI',
                      '15-day antecedent rainfall (mm)',
                      //'relative dry plant conditions',
                      //'woody cover fraction'
                  ])
                    .setOptions({
                     curveType:'function', 
                     series:{
                       0:{color:'yellow'},
                       //1:{color:'red'},
                       1:{color:'green'},
                       2:{color:'blue'//,
                       //targetAxisIndex:1
                       },
                       //3:{color:'orange',lineWidth:4},
                       //4:{color:'maroon',lineWidth:2}
                     },
                     vAxes: {
                       0:{title: 'Land Indices', textStyle:{fontSize: 14}, viewWindow: {min:-3, max:3}},
                       //1:{title: 'Rainfall (mm)', textStyle:{fontSize: 14}, viewWindow: {min:0, max:600}}
                       },
                       height:'95%',
                       width:'100%' 
                    })
    */
    chartpan.widgets().set(0,chart);
      });
});
      //.map(function(img){return })
map1.layers().set(0,ui.Map.Layer(area.style({color:'black',fillColor:'00000000'}),{},'AOI'));