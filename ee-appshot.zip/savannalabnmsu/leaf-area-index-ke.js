var modis_lai = ui.import && ui.import("modis_lai", "imageCollection", {
      "id": "MODIS/006/MCD15A3H"
    }) || ee.ImageCollection("MODIS/006/MCD15A3H"),
    countries = ui.import && ui.import("countries", "table", {
      "id": "USDOS/LSIB/2013"
    }) || ee.FeatureCollection("USDOS/LSIB/2013"),
    map = ui.import && ui.import("map", "image", {
      "id": "users/savannalabnmsu/map_kenya"
    }) || ee.Image("users/savannalabnmsu/map_kenya"),
    viz_wcc = ui.import && ui.import("viz_wcc", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "wcc"
        ],
        "max": 0.8,
        "palette": [
          "b45133",
          "e29c32",
          "b9f347",
          "22c02e"
        ]
      }
    }) || {"opacity":1,"bands":["wcc"],"max":0.8,"palette":["b45133","e29c32","b9f347","22c02e"]},
    viz_map = ui.import && ui.import("viz_map", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "MAP"
        ],
        "min": 100,
        "max": 1000,
        "palette": [
          "ff5412",
          "ffffff",
          "0a82ff"
        ]
      }
    }) || {"opacity":1,"bands":["MAP"],"min":100,"max":1000,"palette":["ff5412","ffffff","0a82ff"]},
    global = ui.import && ui.import("global", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -130.72247384116721,
                50.80830731206831
              ],
              [
                -130.72247384116721,
                -51.328265676966396
              ],
              [
                180.76190115883287,
                -51.328265676966396
              ],
              [
                180.76190115883287,
                50.80830731206831
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#bf04c2",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #bf04c2 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-130.72247384116721, 50.80830731206831],
          [-130.72247384116721, -51.328265676966396],
          [180.76190115883287, -51.328265676966396],
          [180.76190115883287, 50.80830731206831]]], null, false),
    geometryGradientBar = ui.import && ui.import("geometryGradientBar", "geometry", {
      "geometries": [
        {
          "type": "LineString",
          "coordinates": [
            [
              38.09028921775424,
              -0.016976405314431845
            ],
            [
              38.35396109275424,
              0.008429478195858106
            ]
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.LineString(
        [[38.09028921775424, -0.016976405314431845],
         [38.35396109275424, 0.008429478195858106]]),
    wcc = ui.import && ui.import("wcc", "image", {
      "id": "users/savannalabnmsu/treecover_kenya/wcc_ke_eth_2020"
    }) || ee.Image("users/savannalabnmsu/treecover_kenya/wcc_ke_eth_2020");
/////////////////////////////////////////////////////////////////////////////////////////UI INTERFACE//////////////////////////////////////////////////////////////////////////////////
var map1 = ui.Map().setControlVisibility(false,false,true,true).setOptions('hybrid')//.style().set('cursor', 'crosshair');
var map2 = ui.Map().setControlVisibility(false,false,true,true).setOptions('hybrid')//.style().set('cursor', 'crosshair');
var map3 = ui.Map().setControlVisibility(false,false,true,true).setOptions('hybrid')//.style().set('cursor', 'crosshair');
var sidePanel = ui.Panel(
  [
    ui.Label(
      'Rangeland Monitoring Using Satellite Derived Leaf Area Index',
      { fontSize:'28px', fontWeight:'bold', width:'95%'}
      ),
    ui.Label(
    'A tool for monitoring Leaf Area Index (LAI) in Kenyan Rangelands. \n'
    +'MODIS derived LAI is disaggregated into woody and herbaceous components for each 500m pixel.\n'
    +'LAI is defined as total leaf surface area per unit ground area, \n'
    +'and is used here as a proxy for crop/forage conditions at a given location.',
    { fontSize:'18px', width:'95%'}),
    ui.Label('See Kahiu and Hanan (2018) for more details on methods.',
    { fontSize:'18px', width:'95%'},
    'https://agupubs.onlinelibrary.wiley.com/doi/full/10.1002/2017JG004105'
    ),
     ui.Label(
    'Resolution: 500m',
    { fontSize:'15px', width:'95%'}),
     ui.Label(
    'Choose a date',
    { fontSize:'18px', fontWeight:'bold', width:'95%'})
    ],
  ui.Panel.Layout.flow('vertical'),
  {width:'25%', height:'100%', backgroundColor:'#ffffff'}
  );
ui.root.setLayout(ui.Panel.Layout.flow('horizontal'));
var maps = [map1,map2,map3]
var mapPanel = ui.Panel(maps, ui.Panel.Layout.Flow('horizontal'), {width:'75%', height:'100%'});
ui.root.widgets().reset([mapPanel,sidePanel]);  
var linker = ui.Map.Linker(maps);
var label1 = ui.Panel([ui.Label('Aggregate LAI',{backgroundColor:'ffffff00',fontSize:'28px', fontWeight:'bold'})],'',{position:'top-center',backgroundColor:'ffffff00'});
var label2 = ui.Panel([ui.Label('Woody LAI',{backgroundColor:'ffffff00',fontSize:'28px', fontWeight:'bold'})],'',{position:'top-center',backgroundColor:'ffffff00'});
var label3 = ui.Panel([ui.Label('Herbaceous LAI',{backgroundColor:'ffffff00',fontSize:'28px', fontWeight:'bold'})],'',{position:'top-center',backgroundColor:'ffffff00'});
//map1.add(label1)
//map2.add(label2)
//map3.add(label3)
//transparency slider for each map
function addTransparencySlider(selected_map,name){
  var checkbox = ui.Checkbox({// visibility checkbox and an opacity slider.
    label: name,
    value: true,
    style: {fontSize: '120%', color: '000000', backgroundColor:'ffffff', fontWeight:'bold', height:'50%', width:'90%', margin:'0px 0px 0px 0px'},
    onChange: function(checked) {
    selected_map.layers().get(0).setShown(checked);
      }
  });
  var opacitySlider = ui.Slider({
    min: 0,
    max: 1,
    value: 1,
    step: 0.01,
    style:{width:'90%', height: '45%',backgroundColor:'ffffff',margin:'0px 0px 0px 0px'}
  });
  opacitySlider.onSlide(function(value) {
    selected_map.layers().get(0).setOpacity(value);
  });
  selected_map.add(ui.Panel([checkbox,opacitySlider],'flow',{position:'bottom-right', backgroundColor:'ffffff',width:'13vw', height: '6vw', margin:'0px 0px 0px 0px'}))
}
addTransparencySlider(map1,'Aggregate LAI')
addTransparencySlider(map2,'Woody LAI')
addTransparencySlider(map3,'Herbaceous LAI')
//create legend
var visParams = {min:0,max:5,palette:['e47b31','ffd716','ffff00','40d61a','2e9127'], opacity:1}
var createLegend = require('users/savannalabnmsu/misc:colorbar.js')
var legend = createLegend.makeColorBar(visParams, 'Leaf Area Index','85%','15%');
////////////////////////////////////////////////////////////////////////////////////MAIN ALGORITHM///////////////////////////////////////////////////////////////////////////////////////////
var cntry = countries.filterMetadata("name","equals","KENYA");
//var col = modis_lf.filterDate('2019-01-01',Date.now())
var prj = modis_lai.first().projection()
print(prj)
/*
var MeanAP = chirps2.filterDate('1981-01-01','2020-01-01')
                    .map(function(image){return image.resample('bilinear')
                    .clip(cntry.geometry().bounds())})
                    .sum()
                    .divide(39)
                    .reproject(prj)
                    .select([0],['MAP'])
//Export.image.toAsset({image:MeanAP,region:cntry.geometry().bounds(),scale:463.312716528,maxPixels:1e13})
*/
var MeanAP = map//.clipToCollection(cntry)
var wcc500 = wcc.resample('bilinear').divide(100).reproject(prj).select([0],['wcc'])
//Map.addLayer(MeanAP,wiz_map,'MAP')
//Map.addLayer(wcc500,viz_wcc,'tree cover')
//Map.centerObject(cntry,7)
//apply quality filter and cloud mask to modis lai. Bit 0(good quality = 0) and bits 3-4(clear clouds = 0 or 3)
var qualmask = ee.Number(2).pow(0).int()//bit 0
var cloudmask1 = ee.Number(2).pow(3).int()//bit 3
var cloudmask2 = ee.Number(2).pow(4).int()//bit 4
function qualityMask(image) {
  var qb = image.select('FparLai_QC');
  var mask = qb.bitwiseAnd(cloudmask1).eq(0)//clear cloud conditions
        .or(qb.bitwiseAnd(cloudmask1).eq(3))//clear cloud conditions
        .or(qb.bitwiseAnd(cloudmask2).eq(0))//clear cloud conditions
        .or(qb.bitwiseAnd(cloudmask2).eq(3))//clear cloud conditions
        //.and(qb.bitwiseAnd(qualmask).eq(0));//use only good quality (main algo, no back up)
  return image.updateMask(mask).clipToCollection(cntry);//clip cloud-masked image to area of interest
}
//var masked = col.map(qualityMask);
// Use a DateSlider to create composites for selected weekly intervals.
// Use Jan 1 2019 to date of most recent image to bound the slider.
var start = ee.Date('2019-01-01').format();
var latest = modis_lai.sort('system:time_start',false).first().get('system:time_start')
var end = ee.Date(latest).format()
// Run this function on change of the dateSlider.
//computes LAI metrics for a given date using maximum value composite of a 16 day window (+/- 8 days)
//this guarantees at least 4-5 images per pixel for gap-filled composites (MODIS LAI product has 4 days interval)
var compute_lai = function(range) {
  //create a 16 day maximum LAI composite around chosen date
  var composite = modis_lai.filterDate(range.start().advance(-8,'day'), range.start().advance(9,'day'))
                .map(qualityMask)
                .qualityMosaic('Lai')
                //.clipToCollection(cntry)
                .select('Lai')
  //compute peak woody in camopy lai using lai-MAP allometry
  //see Kahiu and Hanan 2018, https://agupubs.onlinelibrary.wiley.com/doi/full/10.1002/2017JG004105
  var LAIwinc1 = ee.Image(MeanAP.multiply(0.0021).subtract(MeanAP.subtract(1650).multiply(0.0020)).add(2.5219))//where MAP>=1650mm
  var LAIwinc2 = ee.Image(MeanAP.multiply(0.0021).add(2.5219))//where MAP < 1650mm
 /*
 alternative using math expression
 var LAIWpinc = composite.expression('2.5219 + 0.0021 * MAP - 0.0020 * (MAP - 1650)',{'MAP':composite.select('MAP').toFloat()}) 
 */
 //merge for peak woody in-canopy LAI, scaled to landscape using woody cover fraction
 var LAIwpinc = LAIwinc1.where(MeanAP.lt(1650), LAIwinc2).multiply(wcc500)
 //apply scale factor of 0.1 to MODIS aggregate lai
  var lai = composite.select('Lai').multiply(0.1)
  /*
  woody lai = peak in canopy woody lai estimated from allometry when less than modis aggregate lai,
  but otherwise it is equal to aggregate lai.
  It is also zero when MAP <= 100mm
  */
  var LAIw = ee.Image(LAIwpinc.where(LAIwpinc.gt(lai),lai)).where(MeanAP.lte(100),0).select([0],['Lai'])
                              .updateMask(lai.unmask(11).lte(10))//ensure same nodata masks
/*
herbaceous lai is the difference between aggregate and woody lai
and is zero when woody cover > 80% (canopy closure) and when aggregate lai falls below woody lai
*/
  var LAIh = lai.subtract(LAIw).where(wcc500.gte(0.8),0).select([0],['Lai'])
  // Asynchronously compute diferent layers and display
  range.start().format('YYYY-MM-dd').evaluate(function(name) {
    //Map.addLayer(LAIWpinc,viz3,'inc LAIw')
    var layer1 = ui.Map.Layer(lai, visParams, name + ' aggregate LAI');
    var layer2 = ui.Map.Layer(LAIw, visParams, name + ' woody LAI');
    var layer3 = ui.Map.Layer(LAIh, visParams, name + ' herbaceous LAI');
    map1.layers().set(0, layer1);
    map2.layers().set(0, layer2);
    map3.layers().set(0, layer3);
    map1.centerObject(cntry,7);
  });
};
// Asynchronously compute the date range function and show the slider.
var dateRange = ee.DateRange(start, end).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: 1,
    onChange: compute_lai,
    style:{width:'95%',height:'100px'}
  });
 sidePanel.add(dateSlider.setValue(ee.Date(latest).format('YYYY-MM-dd').getInfo())); 
 sidePanel.add(legend)
 // Add the panel to the UI
 sidePanel.add(inspector);
});
/*
var style = require('users/gena/packages:style')
//var minMax = dem.reduceRegion(ee.Reducer.percentile([1, 99]), Map.getBounds(true), Map.getScale()).values()
//var min = ee.Number(minMax.get(0))
//var max = ee.Number(minMax.get(1))
var palette = ['e47b31','ffd716','ffff00','40d61a','2e9127']
var min = ee.Number(0)
var max = ee.Number(5)
var textProperties = { fontSize:16, textColor: '000000', outlineColor: 'ffffff', outlineWidth: 2, outlineOpacity: 0.6 }
var labels = ee.List.sequence(min, max, max.subtract(min).divide(5))
var legend = style.GradientBar.draw(
      geometryGradientBar,
      {min: min, max: max, palette: palette, labels: labels, format: '%.0f', text: textProperties}
      )
*/    
//print(map1.layers())
///////////////////////////////INSPECTOR PANEL////////////////////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {width:'65%'},
});
// add sub panels for point labels
var inspector0 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  //style: {width:'60%'},
});
var inspector1 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  //style: {width:'60%'},
});
var inspector2 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  //style: {width:'60%'},
});
var inspector3 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  //style: {width:'60%'},
});
inspector.add(ui.Label('Click on map to inspect value',{fontSize:'18px',fontWeight:'bold'}));
inspector.add(inspector0);
inspector.add(inspector1);
inspector.add(inspector2);
inspector.add(inspector3);
map1.style().set('cursor', 'crosshair');
map2.style().set('cursor', 'crosshair');
map3.style().set('cursor', 'crosshair');
// Register a callback on the map to be invoked when the map is clicked.
function reportVal(mp){
  mp.onClick(function(coords) {
  //Clear the panel and show a loading message.
  inspector0.clear();
  inspector0.style().set('shown', true);
  inspector0.add(ui.Label('Loading...', {color: 'gray'}));
  inspector1.clear();
  inspector1.style().set('shown', true);
  inspector1.add(ui.Label('Loading...', {color: 'gray'}));
  inspector2.clear();
  inspector2.style().set('shown', true);
  inspector2.add(ui.Label('Loading...', {color: 'gray'}));
  inspector3.clear();
  inspector3.style().set('shown', true);
  inspector3.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the LAI value at clicked location
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var agg = ee.Image(map1.layers().get(0).getEeObject())
  var woody = ee.Image(map2.layers().get(0).getEeObject())
  var herb = ee.Image(map3.layers().get(0).getEeObject())
  var sampledPoint1 = agg.reduceRegion(ee.Reducer.mean(), point, 500);
  var sampledPoint2 = woody.reduceRegion(ee.Reducer.mean(), point, 500);
  var sampledPoint3 = herb.reduceRegion(ee.Reducer.mean(), point, 500);
  var aggValue = ee.Algorithms.If(point.intersects(cntry.geometry()),sampledPoint1.get('Lai'),'Null');
  var woodyValue = ee.Algorithms.If(point.intersects(cntry.geometry()),sampledPoint2.get('Lai'),'Null');
  var herbValue = ee.Algorithms.If(point.intersects(cntry.geometry()),sampledPoint3.get('Lai'),'Null');
  //var covValue = sampledPoint.get('predicted_RF');
  //var bmValue = sampledPoint.get('bm_RF');
 //display coordinates at selected point 
    inspector0.clear();
    inspector0.add(ui.Label({
     value: 'lat/lon: ' + coords.lat.toFixed(2) +', '+ coords.lon.toFixed(2),
      style: {stretch: 'vertical'}
    }));
  //});
  // Request the corresp. aggregate lai value from the server and add as label to inspector panels
   aggValue.evaluate(function(result) {
    inspector1.clear();
    inspector1.add(ui.Label({
      value: 'Aggregate LAI: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
  });
  // do same for woody and herbaceous LAI
   woodyValue.evaluate(function(result) {
    inspector2.clear();
    inspector2.add(ui.Label({
      value: 'Woody LAI: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
   });
   herbValue.evaluate(function(result) {
    inspector3.clear();
    inspector3.add(ui.Label({
      value: 'Herbaceous LAI: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
   });
});
}
reportVal(map1);
reportVal(map2);
reportVal(map3);