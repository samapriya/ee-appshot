var countries = ui.import && ui.import("countries", "table", {
      "id": "USDOS/LSIB_SIMPLE/2017"
    }) || ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017"),
    tree_cov = ui.import && ui.import("tree_cov", "image", {
      "id": "users/savannalabnmsu/treecover_kenya/wcc_ke_eth_2020"
    }) || ee.Image("users/savannalabnmsu/treecover_kenya/wcc_ke_eth_2020");
var aoi = countries.filter(ee.Filter.or(ee.Filter.eq('country_na','Kenya'),ee.Filter.eq('country_na','Ethiopia')))
var tc = tree_cov.where(tree_cov.lte(0),0).where(tree_cov.gte(100),100).clip(aoi).select([0],['cover'])
//create viz parameters
var visParams = {min:0,max:100,palette: ['saddlebrown','orange','yellow','green']};
//create legend
var createLegend = require('users/savannalabnmsu/misc:colorbar.js')
var legend = createLegend.makeColorBar(visParams, '% Woody Canopy Cover','400px','100px','bottom-left',14);
//print(legend)
///////////////////////////////////////////////UI INTERFACE///////////////////////////////////////////////////////////////////////////////
var changeBaseMap = require('users/savannalabnmsu/misc:removeMapIcons.js')
var map1 = ui.Map().setControlVisibility(false)
var map2 = ui.Map().setControlVisibility(false).setOptions('hybrid');
changeBaseMap.removeIcons(map1)
var text = ui.Panel(
  [],
  ui.Panel.Layout.flow('vertical'),
  {width:'250px', height:'150px', backgroundColor:'#ffffff', position:'top-left'}
  );
var label = ui.Label('basemap/VHR',{position:'bottom-right', fontWeight:'bold'});
var splitPanel = ui.SplitPanel({
  firstPanel: map1,
  secondPanel: map2,
  wipe: true,
  //style: {stretch: 'both'}
});
var linker = ui.Map.Linker([map1, map2]);
ui.root.setLayout(ui.Panel.Layout.flow('horizontal'))
ui.root.widgets().reset([]);
ui.root.widgets().add(splitPanel);
//ui.root.widgets().add(chartPanel);
var linker = ui.Map.Linker([map1,map2]);
map1.setCenter(38,2,7)
map1.layers().set(0, ui.Map.Layer(tc,visParams,'tree cover ke_eth'))
map2.layers().set(0, ui.Map.Layer(aoi.style({color:'ff0000',fillColor:'ffffff00'}),{},'AOI'))
//map1.add(legend)
map1.add(text)
//map2.add(label)
//map2.addLayer(tree_cov.updateMask(map.lte(1000)),visParams,'tree cover kenya')
//map2.addLayer({eeObject: fdp, name: 'field sites'});
///////////////////////////////////////INSPECTOR PANEL////////////////////////////////////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {width:'100%'},
});
// add sub panels for point labels
var inspector0 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  //style: {width:'60%'},
});
var inspector1 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  //style: {width:'60%'},
});
inspector.add(ui.Label('Click on the map to inspect point value. Swipe to compare with basemap imagery.',{fontSize: '12px'}));
inspector.add(inspector0);
inspector.add(inspector1);
// Add the panel to the UI
text.add(inspector);
// Set the map cursor to a "crosshair".
map1.style().set('cursor', 'crosshair');
map2.style().set('cursor', 'crosshair');
function reportVal(mp){
  mp.onClick(function(coords) {
  //Clear the panel and show a loading message.
  inspector0.clear();
  inspector0.style().set('shown', true);
  inspector0.add(ui.Label('Loading...', {color: 'gray'}));
  inspector1.clear();
  inspector1.style().set('shown', true);
  inspector1.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the woody cover
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  map1.centerObject(point, 16)
  var pointF = ee.FeatureCollection([point])
  map1.layers().set(1, ui.Map.Layer(pointF.style({color:'blue',pointSize:5}),{}, 'clicked point'))
  map2.layers().set(1, ui.Map.Layer(pointF.style({color:'blue',pointSize:5}),{}, 'clicked point'))
  var sampledPoint1 = tc.reduceRegion(ee.Reducer.mean(), point, 40);
  var covValue = ee.Algorithms.If(point.intersects(aoi.geometry()),sampledPoint1.get('cover'),'Null');
   //display coordinates at selected point 
    inspector0.clear();
    inspector0.add(ui.Label({
     value: 'lat/lon: ' + coords.lat.toFixed(2) +', '+ coords.lon.toFixed(2),
      style: {stretch: 'vertical', fontSize: '12px'}
    }));
  //});
  // Request the corresp. woody cover value from the server and add as label to inspector panels
   covValue.evaluate(function(result) {
    inspector1.clear();
    inspector1.add(ui.Label({
      value: 'Canopy Cover (%): ' + result.toFixed(2),
      style: {stretch: 'vertical', fontSize: '12px'}
    }));
  });
});
}
reportVal(map1);
reportVal(map2);