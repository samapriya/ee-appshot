var xvars_80 = ui.import && ui.import("xvars_80", "image", {
      "id": "users/savannalabnmsu/treecover_kenya/xvars_80m_new"
    }) || ee.Image("users/savannalabnmsu/treecover_kenya/xvars_80m_new"),
    ceo_80 = ui.import && ui.import("ceo_80", "table", {
      "id": "users/savannalabnmsu/treecover_kenya/ceo_80_new"
    }) || ee.FeatureCollection("users/savannalabnmsu/treecover_kenya/ceo_80_new"),
    wv_80 = ui.import && ui.import("wv_80", "table", {
      "id": "users/savannalabnmsu/treecover_kenya/wv_80_new"
    }) || ee.FeatureCollection("users/savannalabnmsu/treecover_kenya/wv_80_new"),
    wv_20 = ui.import && ui.import("wv_20", "table", {
      "id": "users/savannalabnmsu/treecover_kenya/wv_20_new"
    }) || ee.FeatureCollection("users/savannalabnmsu/treecover_kenya/wv_20_new"),
    dem = ui.import && ui.import("dem", "image", {
      "id": "MERIT/DEM/v1_0_3"
    }) || ee.Image("MERIT/DEM/v1_0_3"),
    cntries = ui.import && ui.import("cntries", "table", {
      "id": "USDOS/LSIB_SIMPLE/2017"
    }) || ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017"),
    exclude = ui.import && ui.import("exclude", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                37.87627663400343,
                2.3090444920644875
              ],
              [
                37.87627663400343,
                2.2563862709835356
              ],
              [
                37.912668845917494,
                2.2563862709835356
              ],
              [
                37.912668845917494,
                2.3090444920644875
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Polygon(
        [[[37.87627663400343, 2.3090444920644875],
          [37.87627663400343, 2.2563862709835356],
          [37.912668845917494, 2.2563862709835356],
          [37.912668845917494, 2.3090444920644875]]], null, false),
    table = ui.import && ui.import("table", "table", {
      "id": "users/savannalabnmsu/treecover_kenya/wv_20_new"
    }) || ee.FeatureCollection("users/savannalabnmsu/treecover_kenya/wv_20_new"),
    map = ui.import && ui.import("map", "image", {
      "id": "users/savannalabnmsu/treecover_kenya/map_ke_eth"
    }) || ee.Image("users/savannalabnmsu/treecover_kenya/map_ke_eth"),
    regions = ui.import && ui.import("regions", "table", {
      "id": "users/savannalabnmsu/dissolved_regions"
    }) || ee.FeatureCollection("users/savannalabnmsu/dissolved_regions");
var ke = cntries.filterMetadata('country_na','equals','Kenya')
var eth = cntries.filterMetadata('country_na','equals','Ethiopia')
var area = ke.merge(eth)
var ppt = map//.resample('bicubic')
             .reproject(xvars_80.select(0).projection())
             .gte(600).select([0],['mapclass'])                     
var stack = xvars_80
  .select(
    ['VV', 'VH', 'ndvi', 'swir21', 'ndwi', 'ndre', 'blue', 'green',
    //'nd_med_1', 
    'nd_med_2', 
    //'nd_med_3', 
    'nd_med_4', 'nd_amp', 'leafD'],
    ['VV', 'VH', 'ndvi', 'swir21', 'ndwi', 'ndre', 'blue', 'green',
    //'ndvi_feb',
    'ndvi_apr_may',
    //'ndvi_jun_jul',
    'ndvi_aug_sep', 'nd_amp', 'leafD']
    )
    //.addBands(ppt)
var zone = regions.filterMetadata('cluster_na','equals','EA_dry')//.geometry()
var sample1 = ceo_80.filterBounds(zone)
var sample2 = wv_20
           .filter(ee.Filter.bounds(exclude, 1).not())//exclude samples from problematic area
           .filterMetadata('source','not_equals','may23')
           .filterMetadata('source','not_equals','sep02')
           //.filterMetadata('source','not_equals','sep21')
           //.filterMetadata('source','not_equals','jan18')
           .filterBounds(zone)
           .randomColumn().sort('random').limit(5000)
var sample3 = sample1.merge(sample2)
//print(samples)
//print(ui.Chart.feature.histogram(samples1, 'TreeCover'))
////////////////////////////basic UI///////////////////////////////
//create viz parameters
//var visParams = {min:0,max:100,palette: 'ce7e45,df923d,f1b555,fcd163,fff705,efff00,91ff00,1bfb00,0abe00,066400'};
var palette = ['saddlebrown','orange','yellow','lightgreen','green']
var visparams = {min:0, max:100,palette:palette}
var classes = ['0-20','20-40','40-60','60-80','80-100']
var pptPalette = [
'#d53e4f',
'#fc8d59',
'#fee08b',
'#e6f598',
'#99d594',
'#3288bd'
]
var pptClasses = ['<200','200-400','400-600','600-800','800-1000','>1000']
//create legend
var createLegend = require('users/savannalabnmsu/misc:makeLegend_alt.js')
//var legendPanel = ui.Panel([ui.Label('% Woody Canopy Cover'),legend],'flow',{position:'bottom-right'})
var map1 = ui.Map().setControlVisibility(false,false,false, true).setOptions('hybrid');
var map2 = ui.Map().setControlVisibility(false,false, false, true).setOptions('hybrid');
var map3 = ui.Map().setControlVisibility(false).setOptions('hybrid');
var map4 = ui.Map().setControlVisibility(false).setOptions('hybrid');
var infoPanel = ui.Panel(
  [
    //legend,
    ui.Label('Woody Canopy Cover in East African Rangelands',{fontSize:'16px',fontWeight:'bold'}),
    ui.Label(
    'Evaluation of % woody canopy cover estimates for East Africa (Kenya and Ethiopia) @ 80m pixel resolution\n'
    +'using sentinel 1 & 2 derived metrics. Random Forest models are calibrated and evaluated with plot data derived using \n'
    +'the Collect Earth Online tool (CEO, https://collect.earth) as well as  0.3 meter  Maxar\'s worldview-3 (WV-3) classified image samples.',
    { fontSize:'12px', width:'95%'}),
    ui.Label('Scroll down for model information and charts',{fontSize:'16px',fontWeight:'bold'})
    ],
  ui.Panel.Layout.flow('vertical'),
  {width:'30%', height:'100%', backgroundColor:'#ffffff'}
  );
var topPanel = ui.Panel(
  [map1,map2],
  ui.Panel.Layout.flow('horizontal'),
  {width:'100%', height:'50%', backgroundColor:'#ffffff'}
  );
var bottomPanel = ui.Panel(
  [map3,map4],
  ui.Panel.Layout.flow('horizontal'),
  {width:'100%', height:'50%', backgroundColor:'#ffffff'}
  );
var mapPanel = ui.Panel(
  [topPanel,bottomPanel],
  ui.Panel.Layout.flow('vertical'),
  {width:'70%', height:'100%', backgroundColor:'#ffffff'}
  );
/*  
var splitPanel = ui.SplitPanel({
  firstPanel: map1,
  secondPanel: map2,
  wipe: true,
  //style: {stretch: 'both'}
});
*/
//var linker = ui.Map.Linker([map1, map2]);
ui.root.setLayout(ui.Panel.Layout.flow('horizontal'))
ui.root.widgets().reset([mapPanel,infoPanel]);
//ui.root.widgets().add(splitPanel);
//ui.root.widgets().add(infoPanel);
var linker = ui.Map.Linker([map1,map2,map3,map4]);
/////////////////test models///////////////////////////////////
//topography as base layer
var exaggeration = 20;
var hillshade = ee.Terrain.hillshade(dem.multiply(exaggeration));
function testModel(sample,source,map_instance){
  //subset data for zone
  var input = sample//.filterBounds(zone)
  //add bivariate charts to info panel
 infoPanel.add( ui.Chart.feature.byFeature(
    input, 'TreeCover',['ndvi','swir21']
    )
  .setChartType('ScatterChart')
  .setOptions({
    title: source+' derived Tree Cover by NDVI and SWIR2/SWIR1 ratio'
  })
  )
 infoPanel.add(ui.Chart.feature.byFeature(
    input, 'TreeCover',['VV','VH']
    )
  .setChartType('ScatterChart')
  .setOptions({
    title: source+" derived Tree Cover by VV and VH backscatter"
  })
 )
 //create binary variable form MAP (</> 1000mm)
 var samples = input
  //define model input variables (predictors) from input feature property list
  var xvars = samples.first().propertyNames().remove('TreeCover').remove('system:index').remove('source').remove('random')
                                           .remove('leafD').remove('MAP').remove('mapclass')
                                           .remove('ndvi_feb').remove('ndvi_jun_jul')
  print('xvars from '+source, xvars)
  // filter null values from input table
  var inputtedFeatureCollection = samples.filter(ee.Filter.notNull(xvars));
// number of k folds
  var k = 10;
// define classifier parameters
  var classifierOfChoice = ee.Classifier.smileRandomForest(50,ee.Number(xvars.size()).sqrt().round(),1,1).setOutputMode('REGRESSION');
  var propertyToPredictAsString = 'TreeCover';
// ———————————————————————————————————————————————————————————————
// train classifier with k-fold crossval
// 
  var sorted = inputtedFeatureCollection.randomColumn('random').sort('random')
  var size = sorted.size().divide(k)
  var folds = ee.List.sequence(0, k).iterate(function(n, list) {
  n = ee.Number(n)
  var start = size.multiply(n).floor()
  var count = size.multiply(n.add(1)).floor().subtract(start)
  var partition = ee.FeatureCollection(sorted.toList(count, start)).map(function(f) {
    return f.set('fold', n)
  })
  return ee.List(list).add(partition)
  }, [])
  var collection = ee.FeatureCollection(ee.List(folds)).flatten()
// Get the folds as a feature collection.
// We don't care about anything in these features except the fold number.
  var folds1 = collection.distinct('fold').select('fold')
// Add the data in the fold as validation and out of the fold as training.
  var filter = ee.Filter.equals({leftField: 'fold', rightField:'fold'})
  folds1 = ee.Join.saveAll('training').apply(folds1, collection, filter.not())
  folds1 = ee.Join.saveAll('validation').apply(folds1, collection, filter)
// ———————————————————————————————————————————————————————————————
// Train the data and retrieve the values at the sample points
// Classify points based on the training folds
  var classifiedSites = folds1.map(function(fold) {
    var trainingFold = ee.FeatureCollection(ee.List(fold.get('training')))
    var trainedClassifier = classifierOfChoice.train({
      features: trainingFold,
      inputProperties: xvars,
      classProperty: propertyToPredictAsString
    });
   var TestFold = ee.FeatureCollection(ee.List(fold.get('validation')))
   var classifiedSites = TestFold.classify(trainedClassifier, 
        ee.String(propertyToPredictAsString).cat('_Classification'));
	return classifiedSites;
  });
  ///flatten collection of classified folds
  var test = classifiedSites.flatten()
  //calculate RMSE and add to info Panel
  function calcRMSE(table,observed,predicted){
   return ee.Number(
    ee.FeatureCollection(table).map(function(feat){
              return feat
              .set('res_sq', ee.Number(feat.get(predicted)).subtract(ee.Number(feat.get(observed))).pow(2))
      })
         .reduceColumns(ee.Reducer.mean(), ['res_sq'])
         .get('mean'))
         .sqrt()
         .format('%.2f').getInfo()
 }
  var RMSE = calcRMSE(test, 'TreeCover','TreeCover_Classification')
  infoPanel.add(ui.Label([source+' crossvalidated RMSE: '+RMSE]))
  //plot crossvalidated errors
  function chart1(col,xvar,yvar,group){
    return ui.Chart.feature.groups(col, xvar, yvar, group)
    .setChartType('ScatterChart')
    .setOptions({
      title: '10-fold crossvalidation using '+source+' derived cal/val data (RMSE='+RMSE+', n='+samples.size().getInfo()+')',
      hAxis: { title: "out of sample observations", viewWindow: {min:0, max:80}},
      vAxis: { title: 'out of sample predictions', viewWindow: {min:0, max:80}},
      //height: '50%',
      width: '95%',
      padding:'0px',
      colors:['#af4b4b','#af7d4b','#af964b','#96af4b','#4baf4b','#4baf96','#4b96af','#4b4baf','#7d4baf','#af4baf'],
      //stretch:'horizontal',
      legend: {position:'right',
                maxLines:10,
                orientation:'vertical'
              },
      annotations: {
        alwaysOutside: true,
        textStyle: {
            auraColor: 'none'
        }
      },
      trendlines: { 0: {
                        showR2:true,
                        visibleInLegend:true,
                        labelInLegend:''
                        },
                    1: {
                        showR2:true,
                        visibleInLegend:true,
                        labelInLegend:''
                        },
                    2: {
                        showR2:true,
                        visibleInLegend:true,
                        labelInLegend:''
                        },
                    3: {
                        showR2:true,
                        visibleInLegend:true,
                        labelInLegend:''
                        },
                    4: {
                        showR2:true,
                        visibleInLegend:true,
                        labelInLegend:''
                        },
                    5: {
                        showR2:true,
                        visibleInLegend:true,
                        labelInLegend:''
                        },
                    6: {
                        showR2:true,
                        visibleInLegend:true,
                        labelInLegend:''
                        },
                    7: {
                        showR2:true,
                        visibleInLegend:true,
                        labelInLegend:''
                        },
                    8: {
                        showR2:true,
                        visibleInLegend:true,
                        labelInLegend:''
                        },
                    9: {
                        showR2:true,
                        visibleInLegend:true,
                        labelInLegend:''
                        },
                  },
      })
  }
  infoPanel.add(chart1(test,'TreeCover','TreeCover_Classification','fold'))
  var fulltrainedClassifier = classifierOfChoice.train({
    features: samples,
    inputProperties: xvars,
    classProperty: propertyToPredictAsString
  });
  var classifiedImage = stack.clip(zone).classify(fulltrainedClassifier,'TreeCover')//
  //print(classifiedImage)
  var layer0  = ui.Map.Layer(hillshade, {},'Topography')
  var layer1  = ui.Map.Layer(classifiedImage, visparams,source+' predicted tree cover')
  map_instance.centerObject(zone,8)
  map_instance.layers().set(0, layer0);
  map_instance.layers().set(1, layer1);
  var cb1 = ui.Checkbox(
      'show/hide layer',
      true,
      function(checked){
        map_instance.layers().get(1).setShown(checked)
      },
      false
      )
  var label = ui.Label(source+' predicted tree cover (%)')
  var legend = createLegend.createLegend(classes, palette);
  map_instance.add(ui.Panel([label,legend,cb1],'flow',{position: 'top-right'}))
  //Map.addLayer(dem.clip(image.geometry()))
Export.image.toAsset({
  image:classifiedImage,
  description:'export_'+source,
  assetId:'export'+source,
  region:classifiedImage.geometry().bounds(),
  scale:20,
  maxPixels:1e13
})
}
infoPanel.add(ui.Label('Cal/val using CEO data (sample size='+sample1.size().getInfo()+'):',{fontSize:'16px',fontWeight:'bold'}))
testModel(sample1,'CEO based',map1)
infoPanel.add(ui.Label('Cal/val using WV-3 data (sample size='+sample2.size().getInfo()+'):',{fontSize:'16px',fontWeight:'bold'}))
testModel(sample2,'WV-3 based',map2)
infoPanel.add(ui.Label('Cal/val using combined data (sample size='+sample2.size().getInfo()+'):',{fontSize:'16px',fontWeight:'bold'}))
testModel(sample3,'CEO + WV-3',map3)
//map4.addLayer(ceo_80.style('blue',4),{},'CEO sample points')
//map4.addLayer(samples2.style('red',4),{},'WV-3 sample points')
//Map.addLayer(image, {min:0, max:100,palette:['saddlebrown','orange','yellow','lightgreen','green']},'old predicted tree cover from CEO')
//map3.centerObject(samples,5)
//map4.add(legendPanel)
//create slider to sample random locations in kenya
var points = ee.FeatureCollection.randomPoints(zone.geometry(), 100, 0, 1).toList(100)
// Make inset map to show location of given random
var inset = ui.Map()
              .setControlVisibility(false)
              .setOptions('hybrid');
var createInset = function() {
  var bounds = ke.geometry().bounds();
  inset.centerObject(bounds,4.5);
};
createInset()
var slider_fn = function(val){
  var pt = ee.FeatureCollection([points.get(val)])
  map1.centerObject(pt,18)
  map2.centerObject(pt,18)
  map3.centerObject(pt,18)
  map4.centerObject(pt,18)
  inset.layers().set(0,ui.Map.Layer(pt.draw('red')));
}
var slider =
ui.Slider(
        0,
        99,
        0,
        1,
        slider_fn,
        'horizontal',
        false,
        {width:'230px'}
        )
var insetPanel  = 
ui.Panel(
    [
      ui.Label('Use slider to sample 100 random locations for visual comparisons'),
      ui.Label('(Tip: Click on slider and use <-/-> arrows for easy scrolling)'),
      slider
      ],
    'flow',
    {position:'top-right', width:'250px'}
    )
insetPanel.widgets().set(3,ui.Label('Map Locator:'))    
insetPanel.widgets().set(4,inset)
map4.add(insetPanel)