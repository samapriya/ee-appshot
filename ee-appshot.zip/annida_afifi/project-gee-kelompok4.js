var ndbiParams = ui.import && ui.import("ndbiParams", "imageVisParam", {
      "params": {
        "min": -1,
        "max": 1,
        "palette": [
          "red",
          "yellow",
          "green"
        ]
      }
    }) || {"min":-1,"max":1,"palette":["red","yellow","green"]},
    roi = ui.import && ui.import("roi", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            112.7521,
            -7.2575
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([112.7521, -7.2575]);
// Membuat link layer NDBI
var view1 = ui.Map();
var view2 = ui.Map();
// untuk layer LST
var view3 = ui.Map();
var view4 = ui.Map();
ui.root.clear();
//untuk menampilkan layer NDBI
ui.root.add(view1);
ui.root.add(view2);
//untuk menampilkan layer LST
ui.root.add(view3);
ui.root.add(view4);
ui.Map.Linker([view1,view2, view3, view4],'change-bounds');
//Siapkan shapefile batas administrasi kajian
var admin = ee.FeatureCollection("FAO/GAUL/2015/level2");
var filter = ee.Filter.inList('ADM2_NAME', ['Kota Surabaya']);  
var surabaya = admin.filter(filter);
//Load image
var landsat1 = ee.Image('LANDSAT/LC08/C01/T1_SR/LC08_118065_20131101');
var landsat2 = ee.Image('LANDSAT/LC08/C01/T1_SR/LC08_118065_20191118');
//Masukkan koordinasi wilayah untuk set tampilan 
view1.setCenter(112.7521, -7.2575, 10);
view2.setCenter(112.7521, -7.2575, 10);
view3.setCenter(112.7521, -7.2575, 10);
view4.setCenter(112.7521, -7.2575, 10);
// =============================================================== (NDBI)
  // Membuat batas nilai indeks NDBI dan membedakannya dengan pallete warna
  var ndbParams1 = {min: -0.20409956574440002, max: 0.5577235817909241, palette: ['#b46193', '#f7f487','green']};  
  var ndbParams2 = {min: -0.20409956574440002, max: 0.5577235817909241, palette: ['#b46193', '#f7f487', 'green']};
  //Memasukkan band 5 dan band 6 sebagai persamaan menghitung NDBI
  var ndbi1 = landsat1.normalizedDifference(['B5', 'B6'])
                      .rename('NDBI 2013');
  var ndbi2 = landsat2.normalizedDifference(["B5", "B6"])
                        .rename('NDBI 2019');
  //Melakukan Clip wilayah kajian khusus Surabaya
  var ndbi1_sby = ndbi1.clip(surabaya);
  var ndbi2_sby = ndbi2.clip(surabaya);
  //Menampilkan hasil NDBI pada layar 
  var layer1 = ui.Map.Layer(ndbi1_sby, ndbParams1, 'NDBI 2013');
  var layer2 = ui.Map.Layer(ndbi2_sby, ndbParams2, 'NDBI 2019');
// =============================================================== (LST)
//Masukkan parameter untuk perhitungan NDVI 
var ndviParams = {
bands: ['B5', 'B6', 'B4'],
min: 0,
max: 4000,
gamma: [1, 0.9, 1.1]
};
// Menghitung median NDVI 
{
var ndvi1 = landsat1.normalizedDifference(['B5', 'B4']).rename('NDVI_2013');
var ndvi2 = landsat2.normalizedDifference(['B5', 'B4']).rename('NDVI_2019')
}
// Membuat batas nilai indeks NDVI dan membedakannya dengan pallete warna
{
var ndviParams = {min: -1, max: 1, palette: ['blue', 'white', 'green']}
var ndviParams = {min: -1, max: 1, palette: ['blue', 'white', 'green']};
}
// Melakukan Clip pada hasil NDVI
  var ndvi1_sby = ndvi1.clip(surabaya);
  var ndvi2_sby = ndvi2.clip(surabaya);
////////Memilih thermal band 10 (select thermal brightness tempereature) dan meberikan batas min, max 
//Tahun 2013
var thermal1= landsat1.select('B10').multiply(0.1);
var b10Params = {min: 291.918, max: 302.382, palette: ['blue', 'white', 'green']};
//Tahun 2019
var thermal2= landsat2.select('B10').multiply(0.1);
var b10Params = {min: 291.918, max: 302.382, palette: ['blue', 'white', 'green']};
//////// Mencari nilai min-max NDVI pada citra
//Tahun 2013
{
var min = ee.Number(ndvi1.reduceRegion({
reducer: ee.Reducer.min(),
scale: 30,
maxPixels: 1e9
}).values().get(0));
var max = ee.Number(ndvi1.reduceRegion({
reducer: ee.Reducer.max(),
scale: 30,
maxPixels: 1e9
}).values().get(0));
}
//Tahun 2019
{
var min = ee.Number(ndvi2.reduceRegion({
reducer: ee.Reducer.min(),
scale: 30,
maxPixels: 1e9
}).values().get(0));
var max = ee.Number(ndvi2.reduceRegion({
reducer: ee.Reducer.max(),
scale: 30,
maxPixels: 1e9
}).values().get(0));
}
/////// Melakukan perhitungan pada pecahan NDVI untuk mencari Proportion of Vegetation (Pv)
//Tahun 2013
var fv_2013 =(ndvi1.subtract(min).divide(max.subtract(min))).pow(ee.Number(2)).rename('FV_2013'); 
//Tahun 2019
var fv_2019 =(ndvi2.subtract(min).divide(max.subtract(min))).pow(ee.Number(2)).rename('FV_2019');
///////Mencari nilai Emissivitas
//Tahun 2013
var a= ee.Number(0.004);
var b= ee.Number(0.986);
var EM_2013 = fv_2013.multiply(a).add(b).rename('EMM_2013');
var imageVisParam3 = {min: 0.9865619146722164, max:0.989699971371314};
//Tahun 2019
var a= ee.Number(0.004);
var b= ee.Number(0.986);
var EM_2019 = fv_2019.multiply(a).add(b).rename('EMM_2019');
var imageVisParam3 = {min: 0.9865619146722164, max:0.989699971371314};
///////Menghitung persamaan LST (Land Surface Temperature)
///////NB: Dalam celcius -273,15
//Tahun 2013
var lst_2013 = thermal1.expression(
'(Tb/(1 + (0.00115* (Tb / 1.438))*log(Ep)))-273.15', {
 'Tb': thermal1.select('B10'),
'Ep': EM_2013.select('EMM_2013')
}).rename('LST_2013');
//Tahun 2019
var lst_2019 = thermal2.expression(
'(Tb/(1 + (0.00115* (Tb / 1.438))*log(Ep)))-273.15', {
 'Tb': thermal2.select('B10'),
'Ep': EM_2019.select('EMM_2019')
}).rename('LST_2019');
//Clip LST Kota Surabaya
var lst_sby_2013 = lst_2013.clip(surabaya);
var lst_sby_2019 = lst_2019.clip(surabaya);
// Membuat batas nilai indeks LST dan membedakannya dengan pallete warna
var lst1Params = {min: 20, max: 40, palette: ['green', '#10bdff', 'yellow', 'red']};
var lst2Params ={min: 20, max: 40, palette: ['green', '#10bdff', 'yellow', 'red']};
  //Menampilkan hasil LST untuk ditampilkan dalam map
 var layer3 = ui.Map.Layer(lst_sby_2013, lst1Params, 'LST November 2013');
 var layer4 = ui.Map.Layer(lst_sby_2019, lst2Params, 'LST November 2019');
//menampilkan layer di layar
  view1.layers().set(0, layer1);
  view2.layers().set(0, layer2);
  view3.layers().set(0, layer3);
  view4.layers().set(0, layer4);
// Menyesuaikan posisi panel
var resultsPanel = ui.Panel({style: {position: 'bottom-left'}});
Map.add(resultsPanel);
// ============================================================================================================================================================================================================
// Membhuat panel pada map (memunculkan panel deskripsi)
var mapPanel = ui.Map();
Map.style().set({cursor: 'crosshair'});
// Memberikan judul dan beberapa teks dalam panel
var header = ui.Label('Analisis Hubungan antara Perubahan Suhu Permukaan Tanah dengan Indeks Kawasan Terbangun Menggunakan Citra Landsat 8 OLI/TIRS', {fontSize: '20px', color: 'black',fontWeight: 'bold' });
// Menambahkan header untuk ditangkap pada panel
var toolPanel = ui.Panel([header], 'flow', {width: '400px'});   
//Menambahkan text deskripsi pada panel
var textu = ui.Label(
    '(Studi Kasus: Kota Surabaya)',
    {fontWeight: 'bold', fontSize: '14px', margin: '4px 4px 4px 4px', padding: '1'});
    toolPanel.add(textu);
//Masukkan teks 1
var text = ui.Label(
    'Surabaya adalah kota metropolitan terbesar kedua dengan luas wilayah ± 52.087 Ha.'
    + ' Pertumbuhan penduduk di perkotaan yang bertambah secara eksponensial baik secara alami maupun'
    +' akibat arus urbanisasi menyebabkan perubahan penggunaan lahan , sehingga menimbulkan  permasalahan'
    +' seperti perubahan suhu permukaan (Sasky et al. 2017).',
    {fontSize: '12px'});
//Masukkan teks 2
var text2 = ui.Label(
              'Project ini menggunakan Normalized Difference Built-up Index (NDBI) dan Land Surface Temperature (LST) yang bertujuan melihat '
              + 'hubungan perubahan suhu permukaan tanah dengan indeks kawasan terbangun di Kota Surabaya. ', {fontSize:'12px'});
//Memasukkan teks kedalam panel 
var toolPanel = ui.Panel([header,textu, text, text2], 'flow', {width: '300px'});
ui.root.widgets().add(toolPanel);
///// Membuat title pada map
//Menambahkan header NDBI dan menampilkannya pada map
var header = ui.Label('NDBI November 2013', {position : 'top-left', fontSize: '14px', color: 'black', fontWeight: 'bold'});
view1.add(header);
var header1 = ui.Label('NDBI November 2019', {position : 'top-left', fontSize: '14px', color: 'black', fontWeight: 'bold'});
view2.add(header1);
//Menambahkan header LST dan menampilkannya pada map
var header2 = ui.Label('LST November 2013', {position : 'top-left', fontSize: '14px', color: 'black', fontWeight: 'bold'});
view3.add(header2);
var header3 = ui.Label('LST November 2019', {position : 'top-left', fontSize: '14px', color: 'black', fontWeight: 'bold'});
view4.add(header3);
//==================================================== Membuat Legenda
// Membuat variabel dengan beberapa kategori di legenda
var LEGEND = {
  '-0.2 - 0.05: Non Pemukiman':'green',
  '0.05 - 0.3: Pemukiman Jarang ': '#f7f487',
  '0.3 - 0.55: Pemukiman Padat': '#b46193',
};
//Mengunci variabel untuk ditambahkan pada legenda
var lcPalette = Object.keys(LEGEND).map(function(key){
  return LEGEND[key]
});
// Membuata legenda dan menampilkannya pada map
var legend1 = makeLegend1(LEGEND);
view1.add(legend1);
var legend1 = makeLegend1(LEGEND);
view2.add(legend1);
// Fungsi untuk membuat label legenda 
function makeLegendEntry1(color, label) {
  label = ui.Label(label, {
    margin: '0 0 4px 6px',    
  });
  return makeRow([makeColorBox(color), label]);
}
// Fungsi membuat warna pada box label
function makeColorBox(color) {
  return ui.Label('', {
    backgroundColor: color,  
    padding: '5px',
    margin: '0 0 4px 0',
  })
}
// Fungsi membuat baris pada panel
function makeRow(widgets){
  return ui.Panel({
    widgets: widgets,
    layout: ui.Panel.Layout.flow('horizontal'),
    style: {
      padding: '0px 5px',
    }
  })
}
// Fungsi untuk memasukkan teks legenda 
function makeLegend1(data) {
  // ui.Panel:
  var legend1 = ui.Panel({
    style: {
      width: '250px',
      position: 'bottom-right'
    }
  });
// Membuat judul pada Legenda
  legend1.add(ui.Label("Klasifikasi NDBI", {
    fontWeight: 'bold', 
    fontSize: '14px'
  }));
//Mengkunci variabel terhadap fungsi label 
  Object.keys(data).map(function(label){
    legend1.add(makeLegendEntry1(data[label], label));
  });
  return legend1;
}
// Fungsi untuk membuat label legenda 2
function makeLegendEntry2(color, label) {
  label = ui.Label(label, {
    margin: '0 0 4px 6px',    //'aut{palette:['FF0000']}, 'oil palm'o 0',
    //fontWeight: '100',
    //color: '#555'
  });
  return makeRow([makeColorBox(color), label]);
}
// Fungsi membuat warna pada box label legenda 2
function makeColorBox(color) {
  return ui.Label('', {
    backgroundColor: color,  
    padding: '8px',
    margin: '0 0 4px 0',
    //border: '1px solid gray',
  })
}
//Fungsi membuat baris pada legenda 2
function makeRow(widgets){
  return ui.Panel({
    widgets: widgets,
    layout: ui.Panel.Layout.flow('horizontal'),
    style: {
      padding: '0px 5px',
    }
  })
}
//Fungsi membuat legenda pada tampilan map
function makeLegend2(data) {
  // ui.Panel:
  var legend2 = ui.Panel({
    style: {
      width: '250px',
      position: 'bottom-right',
    }
  });
// Membuat judul pada Legenda
  legend2.add(ui.Label("Suhu Permukaan", {
    fontWeight: 'bold', 
    fontSize: '14px'
  }));
//Mengkunci variabel terhadap fungsi label legenda 2
  Object.keys(data).map(function(label){
    legend2.add(makeLegendEntry2(data[label], label));
  });
  return legend2;
}
//Menulis teks pada legenda 2
var legend2 = {
  '20°C - 25°C':'green',
  '25°C - 30°C':'#10bdff',
  '30°C - 35°C':'yellow',
  '35°C - 40°C':'red',
};
// Memasukkan variabel pada legenda 2 dan memunculkannya pada map 
var legend_2 = makeLegend2(legend2);
view3.add(legend_2);
var legend_2 = makeLegend2(legend2);
view4.add(legend_2);
//Mengkunci variabel terhadap fungsi label legenda 2
var lcPalette2 = Object.keys(legend2).map(function(key){
  return legend_2[key]
});