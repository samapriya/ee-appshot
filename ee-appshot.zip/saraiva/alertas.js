// https://javascriptobfuscator.com/Javascript-Obfuscator.aspx
// Imports
var ARDLib = require('users/saraiva/public:ARDLib_v2.js');
var SARLib = require('users/saraiva/public:SARLib.js');
var layersLib = require("users/saraiva/apps:layers.js");
// End Inports
// Global Variables
var currentPoint = null;
var selectedAlerts = null;
var satellites = ['LT05', 'LE07', 'LC08', 'LC09', 'S1', 'S2'];
var satellitesDict = {
  'LT05': {'label': 'Landsat 5 TM', 'value': 'LT05', 'checked': true},
  'LE07': {'label': 'Landsat 7 ETM+', 'value': 'LE07', 'checked': true},
  'LC08': {'label': 'Landsat 8 OLI', 'value': 'LC08', 'checked': true},
  'LC09': {'label': 'Landsat 9 OLI', 'value': 'LC09', 'checked': true},
  'S1'  : {'label': 'Sentinel 1 SAR', 'value': 'S1', 'checked': false},
  'S2'  : {'label': 'Sentinel 2 MSI', 'value': 'S2', 'checked': true},
};
var MODULES = {
  IMAGES: 1,
  TIME_SERIES: 2
}
var COLLECTIONS = {
  S1: {
    "PATHS": ['COPERNICUS/S1_GRD'], 
    "ID_FIELD": "system:index",
  },
  S2: {
    "SATELLITE": 'SENTINEL_2',
    "ID_FIELD": "PRODUCT_ID",
  },
  LT05: {
    "SATELLITE": 'LANDSAT_5',
    "ID_FIELD": "LANDSAT_PRODUCT_ID",
  },
  LE07: {
    "SATELLITE": 'LANDSAT_7',
    "ID_FIELD": "LANDSAT_PRODUCT_ID",
  },
  LC08: {
    "SATELLITE": 'LANDSAT_8',
    "ID_FIELD": "LANDSAT_PRODUCT_ID",
  },
  LC09: {
    "SATELLITE": 'LANDSAT_9',
    "ID_FIELD": "LANDSAT_PRODUCT_ID",
  }
}
var VISUALIZATIONS = {
  // https://code.earthengine.google.com/bdeb122d459a10893fe0df3ce3372c33
  RGB: {
    "MULTIBAND": true,
    "BANDS": ["RED", "GREEN", "BLUE"],
    "VIS": {
      "bands": ["RED", "GREEN", "BLUE"],
    }
  },
  NSR: {
    "MULTIBAND": true,
    "BANDS": ["NIR", "SWIR1", "RED"],
    "MIN": [0.037, 0.002, 0.015],
    "MAX": [0.638, 0.313, 0.225],
    "VIS": {
      "bands": ["NIR", "SWIR1", "RED"]
    }
  },
  NRG: {
    "MULTIBAND": true,
    "BANDS": ["NIR", "RED", "GREEN"],
    "MIN": [0.037, 0.015, 0.015],
    "MAX": [0.638, 0.225, 0.225],
    "VIS": {
      "bands": ["NIR", "RED", "GREEN"]
    }
  },
  NDVI: {
    "MULTIBAND": false,
    "EXPRESSION": "(b('NIR') - b('RED'))/(b('NIR') + b('RED'))",
    "RENAME": "NDVI",
    "VIS": {
      "min": 0, 
      "max": 0.9,
      "bands": ["NDVI"],
      "palette": "ff1e07,ffa275,f7ff81,b8ff48,1b7006",
    },
  },
  EVI2: {
    "MULTIBAND": false,
    "EXPRESSION": "2.4 *  ( ((b('NIR')-b('RED'))/10000) / ((b('NIR')/10000) + (2.4 * (b('RED')/10000) ) + 1) )",
    "RENAME": "EVI2",
    "VIS": {
      "min": 0, 
      "max": 0.8,
      "bands": ["EVI2"],
      "palette": "ff1e07,ffa275,f7ff81,b8ff48,1b7006",
    },
  },
  NBR: {
    "MULTIBAND": false,
    "EXPRESSION": "(b('NIR') - b('SWIR1'))/(b('NIR') + b('SWIR1'))",
    "RENAME": "NBR",
    "VIS": {
      "min": -0.8, 
      "max": 0.8,
      "bands": ["NBR"],
      "palette": "ff1e07,ffa275,f7ff81,b8ff48,1b7006",
      "gamma": 0.85,
    },
  }
}
var TIMESERIES_COLLECTIONS = {
  EVI2_8_days: {bandName: "EVI2", min: 0, max: 1},
  NDVI_8_days: {bandName: "NDVI", min: 0, max: 1},
  NDVI: {bandName: "NDVI",min: 0, max: 1},
  EVI2: {bandName: "EVI2",min: 0, max: 1},
  NBR: {bandName: "NBR",min: -0.5, max: 1},
  LST: {bandName: "LST", min: 290, max: 320},
  ET: {bandName: "ET", min: 0, max: 8},
  P: {bandName: "P", min: 0, max: 40}
};
// End Global Variables
// Map
var map = ui.Map(); 
map.setOptions('satellite');
map.setControlVisibility({
  "all": true,
  "layerList": true,
  "zoomControl": false,
  "scaleControl": false,
  "mapTypeControl": true, 
  "fullscreenControl": false,
});
map.style()
  .set('cursor', 'crosshair')
  .set("height", "calc(100vh - 70px - 350px)");
map.centerObject(ee.Geometry.Point([-49.447, -14.233]), 5);
// End Map
// Layers
var layersPanel = layersLib.getLayerPanel(map, updateImages);
layersPanel.style().set("position", 'top-left');
layersPanel.style().set("maxHeight", "calc(100%)");
// End Layers
// Sidebar
var logo = ee.Image("users/saraiva/alertas");
logo = logo.updateMask(logo.select(3).eq(255));
var headerPanel = ui.Panel({
  widgets: [
    ui.Panel({
      widgets:[
        ui.Thumbnail({
          image: logo, 
          params: {
            format: 'PNG',
            bands: 'b1,b2,b3',
            dimensions: '200x200'
          }, 
          style: {
            width: '50px'
          }
        }),
        ui.Label("A", {"color": "#3D88ED", 'margin': '10px 3px 0px 3px', 'fontWeight': 'bold'}), 
        ui.Label("L", {"color": "#F0403B", 'margin': '10px 3px 0px 3px', 'fontWeight': 'bold'}),
        ui.Label("E", {"color": "#FDBB41", 'margin': '10px 3px 0px 3px', 'fontWeight': 'bold'}),
        ui.Label("R", {"color": "#3D88ED", 'margin': '10px 3px 0px 3px', 'fontWeight': 'bold'}),
        ui.Label("T", {"color": "#21A85E", 'margin': '10px 3px 0px 3px', 'fontWeight': 'bold'}),
        ui.Label("A", {"color": "#F0403B", 'margin': '10px 3px 0px 3px', 'fontWeight': 'bold'}),
        ui.Label("S", {"color": "#FDBB41", 'margin': '10px 3px 0px 3px', 'fontWeight': 'bold'}),
      ],
      layout: ui.Panel.Layout.flow("horizontal"),
    }),
  ],  
  style: {
    position: 'top-center',
    textAlign: 'center',
    fontSize: '35px',
    margin: '0px 0px 0px 0px'
  }
})
var moduleSelect = ui.Select({
  items: [
    {label: "Imagens", value: MODULES.IMAGES},
    {label: "Séries Temporais", value: MODULES.TIME_SERIES},
  ],
  value: MODULES.IMAGES,
});
var startDateImages = ui.Textbox({
  value: "2024-10-01",
  style: {
    "width": "100px",
  }
}) 
var endDateImages = ui.Textbox({
  value: new Date().toISOString().slice(0, 10),
  style: {
    "width": "100px",
  }
});
var monthlySelect = ui.Select({
  items: [
    {label: "janeiro", value: 1},
    {label: "Fevereiro", value: 2},
    {label: "Março", value: 3},
    {label: "Abril", value: 4},
    {label: "Maio", value: 5},
    {label: "Junho", value: 6},
    {label: "Julho", value: 7},
    {label: "Agosto", value: 8},
    {label: "Setembro", value: 9},
    {label: "Outubro", value: 10},
    {label: "Novembro", value: 11},
    {label: "Dezembro", value: 12},
  ]
});
var useFirstImage = ui.Checkbox({
  label: 'Apenas 1 imagem'
});
var cloudCover = ui.Slider(0, 100, 100, 1);
var satellitesChecks = [];
satellites.forEach(function(satKey){
  var satellite = satellitesDict[satKey];
  var checkBox = ui.Checkbox({
    label: satellite.label,
    value: satellite.checked,
    onChange: function(value){
      satellitesDict[satKey].checked = value;
    }
  });
  satellitesChecks.push(checkBox);
});
var visSelect = ui.Select({
  items: [
    {label: "Cor Natural (RED, GREEN, BLUE)", value: 'RGB'},
    {label: "Falsa Cor 1 (NIR, SWIR1, RED)", value: 'NSR'},
    {label: "Falsa Cor 2 (NIR, RED, GREEN)", value: 'NRG'},
    {label: "Normalized Difference Vegetation Index (NDVI)", value: 'NDVI'},
    {label: "Two-band Enhanced Vegetation Index (EVI2)", value: 'EVI2'},
    {label: "Difference Normalized Burn Index (NBR)", value: 'NBR'},
  ],
  value: 'NSR'
});
var roiInput = ui.Textbox({
  placeholder: '{ "type": "MultiPolygon", "coordinates": [ [ [ [ -54.75700539981581, -13.247125256661093 ], [ -54.753205422793748, -13.245951011761701 ], [ -54.753084788602571, -13.246538134919538 ], [ -54.746268956801096, -13.244894186508741 ], [ -54.744218175551104, -13.240373271136209 ], [ -54.714662798712865, -13.230978892890235 ], [ -54.711646943933452, -13.241841110005774 ], [ -54.708570772058458, -13.240608125949946 ], [ -54.715929457720215, -13.252878974766443 ], [ -54.751516544117273, -13.265207912406524 ], [ -54.75712603400698, -13.247594953034573 ], [ -54.75700539981581, -13.247125256661093 ] ] ] ] }',
  style: {
    width: '95%'
  }
});
var submitROI = ui.Button({
  label: 'Enviar geometria',
  onClick: function(){
    var text = roiInput.getValue();
    var roi = geojson2geometry(text);
    map.addLayer(roi);
    map.centerObject(roi);
    updateImages(roi);
  },
});
var startDateSeries = ui.Textbox({
  value: "2010-08-01",
  style: {
    "width": "100px",
  }
});
var endDateSeries = ui.Textbox({
  value: new Date().toISOString().slice(0, 10),
  style: {
    "width": "100px",
  }
});
var serieIndex = ui.Select({
  items: [
    {label: "EVI2 (8 dias)", value: "EVI2_8_days"},
    {label: "NDVI (8 dias)", value: "NDVI_8_days"},
    {label: "EVI2 (16 dias)", value: 'EVI2'},
    {label: "NDVI (16 dias)", value: 'NDVI'},
    {label: "NBR (16 dias)", value: 'NBR'},
    {label: "LST (ºK)", value: 'LST'},
    {label: "ET (mm/day)", value: 'ET'},
    {label: "P (mm/day)", value: 'P'},
  ],
  value: 'EVI2_8_days',
});
var savitzkyGolay = ui.Select({
  items: [
    {label: "Sem suavisação", value: 0},
    {label: "1", value: 1},
    {label: "2", value: 2},
    {label: "3", value: 3},
    {label: "4", value: 4},
    {label: "5", value: 5},
    {label: "6", value: 6},
  ],
  value: 1,
});
var imageModulePanel = ui.Panel({
  widgets: [
    ui.Panel({
      widgets: [ui.Label("Módulo: Imagens", {backgroundColor: "#337ab7", color: "#ffffff",  position:'top-center', textAlign: 'center'})],
      style: {backgroundColor: "#337ab7", position:'top-center'},
      layout: ui.Panel.Layout.flow("horizontal"),
    }),
    ui.Label("Perído para obtenção das imagens:"),
    ui.Panel({
      widgets: [startDateImages, endDateImages],
      layout: ui.Panel.Layout.flow("horizontal"),  
    }),
    ui.Panel({
      widgets: [
          ui.Label("Mês:"),
          monthlySelect,  
          useFirstImage,
      ],
      layout: ui.Panel.Layout.flow("horizontal"),  
    }),
    ui.Label("Máxima cobertura de nuvens:"),
    cloudCover,
    ui.Label("Satélites:"),
    ui.Panel({
      widgets: satellitesChecks,
      layout:  ui.Panel.Layout.flow("horizontal", true),
      style: {
        width: '100%',
      }
    }),
    ui.Label("Visualização:"),
    visSelect,
    ui.Label("Minha geometria:"),
    ui.Label("Formato (GeoJSON, EPSG: 4326)"),
    roiInput,
    submitROI,
  ],
  layout: ui.Panel.Layout.flow("vertical")
});
var timeSeriesModulePanel = ui.Panel({
  widgets: [
    ui.Panel({
      widgets: [ui.Label("Módulo: Séries Temporais", {backgroundColor: "#337ab7", color: "#ffffff",  position:'top-center', textAlign: 'center'})],
      style: {backgroundColor: "#337ab7", position:'top-center'},
      layout: ui.Panel.Layout.flow("horizontal"),
    }),
    ui.Label("Período para as séries temporais:"),
    ui.Panel({
      widgets: [startDateSeries, endDateSeries],
      layout: ui.Panel.Layout.flow("horizontal"),  
    }),
    ui.Label("Índice vegetativo:"),
    serieIndex,
    ui.Label("Suavisação Savitzky–Golay:"),
    savitzkyGolay,
  ],
  layout: ui.Panel.Layout.flow("vertical")
});
var menuPanel = ui.Panel({
  widgets: [
    headerPanel,
    ui.Panel({
      widgets: [ui.Label("Módulo", {backgroundColor: "#337ab7", color: "#ffffff",  position:'top-center', textAlign: 'center'})],
      style: {backgroundColor: "#337ab7", position:'top-center'},
      layout: ui.Panel.Layout.flow("horizontal"),
    }),
    moduleSelect,
    imageModulePanel,
  ],
  layout: ui.Panel.Layout.flow("vertical"),
  style: {
    width: '350px',
    position: 'top-left',
    border: '0.5px solid #000000',
    padding: '10px',
  }
});
moduleSelect.onChange(function(text){
  if(moduleSelect.getValue() === MODULES.IMAGES){
    menuPanel.add(imageModulePanel);
    menuPanel.remove(timeSeriesModulePanel);
  }else{
    menuPanel.remove(imageModulePanel);
    menuPanel.add(timeSeriesModulePanel);
  }
});
// End Sidebar
// Coordinates Panel
var coordinatesSelect = ui.Select({
  items: [
    { label:"Lat,Lon", value: 'LATLON' },
    { label:"Lon,Lat", value: 'LONLAT' },
  ],
  value: 'LONLAT'
});
var coordinatesPanel = ui.Panel({
  widgets: [
    ui.Panel({
      widgets: [
        coordinatesSelect,
        ui.Textbox({
          onChange: function(text){
            var coordinates = text.split(',').map(function(item){return parseFloat(item)});
            var currentPoint = null;
            if(coordinatesSelect.getValue() === "LATLON"){
              currentPoint = ee.Geometry.Point([coordinates[1], coordinates[0]])
            }else if(coordinatesSelect.getValue() === "LONLAT"){
              currentPoint = ee.Geometry.Point(coordinates)
            }
            map.centerObject(currentPoint, 15)
            map.addLayer(currentPoint,  {color: 'FF0000'}, "Point");
          },
          style: {
            width: '100px'
          }
        })
      ],
      layout: ui.Panel.Layout.flow("horizontal"),  
    }),  
  ],
  style: {
    position: 'top-right',
    border: '0.1px solid #000000',
    padding: '0px',
    margin: '0px',
  }
})
// End Coordinates Panel
map.add(coordinatesPanel);
// End Coordinates Panel
// Tools Panel
var panelTools = ui.Panel({
  widgets: [
    ui.Button("Aplicar contraste", function(){
      ARDLib.contrastService.updateContrast(map);
    }, false, {
      padding: '0px',
      margin: '0px',
    }),
    ui.Button("Limpar a tela", function(){
      map.layers().reset();
    }, false, {
      padding: '0px',
      margin: '0px',
    }),
  ],
  layout: ui.Panel.Layout.flow("horizontal"),
  style: {
    position: 'top-right',
    border: '0.1px solid #000000',
    padding: '0px',
    margin: '0px',
  }
})
map.add(panelTools);
// End Tools Panel
// Panel Time Series
var panelTimeSeries = ui.Panel({
  widgets: [],
  layout: ui.Panel.Layout.flow("horizontal"),
  style: {
    "width": "100%",
    "minHeight": "349px",
    "maxHeight": "349px",
    "border": '0.5px solid #000000',
  }
})
var timeSeries = ui.Label("", {fontSize: '25px'});
panelTimeSeries.add(timeSeries);
// End Panel Time Series
var mapPanel = ui.Panel({
  widgets: [
    map,
    panelTimeSeries
  ],
  layout: ui.Panel.Layout.flow("vertical"),
  style: {
    "position": 'top-center',
    "border": '0.5px solid #000000',
    'width': 'calc(100% - 350px - 300px)'
  }
})
ui.root.clear();
ui.root.setLayout(ui.Panel.Layout.flow("horizontal"));
ui.root.add(menuPanel);
ui.root.add(mapPanel);
ui.root.add(layersPanel);
map.onClick(function(latlon){
  var coordinates = 'Cooordenadas: ' + latlon.lon + ' , ' + latlon.lat + '. ';
  var roi = ee.Geometry.Point([latlon.lon, latlon.lat]);
  update(coordinates, roi);
});
// Update Functions 
function update(coordinates, roi){
  if(moduleSelect.getValue() === MODULES.IMAGES){
    selectedAlerts = ee.FeatureCollection([]);
    var clickedLayers = Object.keys(layersLib.currentFeatureCollection());
    var clickedFeatures = ee.FeatureCollection([]);
    clickedLayers.forEach(function(clickedLayer){
      var clickedLayerPath = layersLib.currentFeatureCollection()[clickedLayer];
      var clickedLayerFc = ee.FeatureCollection(clickedLayerPath)
        .filterBounds(roi);
      clickedFeatures = clickedFeatures.merge(clickedLayerFc);
    });
    var clickedFeatureData = clickedFeatures.getInfo();
    if(clickedFeatureData !== undefined && clickedFeatureData !== null){
      if(clickedFeatureData.features.length > 1){
        alert('Mais de uma geometria foi encontrada para o ponto clicado. No painel que se abriu, procure pelo botão "Ver imagens de satélite" para ver as imagens de satélite para a geometria que você deseja.');
      }else if(clickedFeatureData.features.length === 1){
        var featureGeometry = ee.Geometry(clickedFeatureData.features[0].geometry); 
        updateImages(featureGeometry); 
      }else{
        alert("Ative uma camada no painel de camadas e clique em qualquer feição no mapa para visualizar as imagens de satélite disponíveis para a feição clicada. Se você deseja visualizar uma série temporal para o ponto clicado, altere o módulo para 'Séries Temporais'.");  
      }
    }else{
      alert("Ative uma camada no painel de camadas e clique em qualquer feição no mapa para visualizar as imagens de satélite disponíveis para a feição clicada. Se você deseja visualizar uma série temporal para o ponto clicado, altere o módulo para 'Séries Temporais'.");
    }
  }else{
    updateTimeSeriesModis(coordinates, roi);    
  }
}
function updateImages(roi){
  var selectedSatellites = getSelectedSatellites(satellites);
  var allImages = ee.ImageCollection(getSelectedCollection(
    selectedSatellites, 
    startDateImages.getValue(), 
    endDateImages.getValue(), roi, 
    monthlySelect.getValue()));
  allImages = allImages
    .filterMetadata("CLOUD_OR_NODATA_PERCETAGE", "less_than", cloudCover.getValue() + 0.00001);
  var filter = ee.Filter.equals({
    leftField: 'DATE_AND_SATELLITE',
    rightField: 'DATE_AND_SATELLITE'
  });
  // Define the join.
  var saveAllJoin = ee.Join.saveAll({
    matchesKey: 'images',
    ordering: 'system:time_start',
    ascending: true
  });
  // Apply the join.
  var combinedImages = saveAllJoin.apply(allImages, allImages, filter)
    .distinct('DATE_AND_SATELLITE');
  var loading = ui.Label('Buscando imagens... Por favor, aguarde.');
  map.add(loading);
  var evaluatedAllImages = false;
  combinedImages.toList(1000).evaluate(function(images){
    if(evaluatedAllImages){
      return;
    }else{
      evaluatedAllImages = true;
    }
    if(images === undefined || images === null){
      alert('Não encontramos imagens para sua busca. Tente aumentar o período de busca ou a máxima cobertura de nuvens no painel esquerdo.');
      map.remove(loading);
      return;
    }
    map.remove(loading);
    panelTimeSeries.clear();
    var timeSeries = ui.Panel({
      layout: ui.Panel.Layout.flow("horizontal")
    });
    panelTimeSeries.add(timeSeries);
    images.forEach(function(imageData){
      var date = imageData.properties.DATE;
      var satellite = imageData.properties.SATELLITE;
      var dateAndSatellite = imageData.properties.DATE_AND_SATELLITE;
      var image = ee.Image(combinedImages
        .filterMetadata("DATE_AND_SATELLITE", "equals", dateAndSatellite)
        .first());
      var region = roi.centroid(ee.ErrorMargin(1)).buffer(roi.bounds().perimeter(ee.ErrorMargin(1)).divide(4), ee.ErrorMargin(1));
      var newImageVis = null;
      if(satellite.toUpperCase() === 'SENTINEL-1'){
        var mosaic = ee.ImageCollection
          .fromImages(ee.List(image.get('images')).filter(ee.Filter.eq('SPACECRAFT', 'Sentinel-1')))
          .median();
      }else{
        var mosaic = ee.ImageCollection.fromImages(image.get('images')).median();
      }
      var imageID = imageData.properties['system:index'];
      var imageIDParts = null;
      if(satellite.indexOf('Sentinel-2') !== -1){
        imageIDParts = imageData.properties['PRODUCT_ID'].split("_");
        imageID = imageIDParts[2].slice(0, 8) + "_" +imageIDParts[5].slice(1, 6)+ "_" +imageIDParts[0];
      }else if(satellite.indexOf("LANDSAT") !== -1){
        imageIDParts = imageData.properties['ID'].split("_");
        imageID =  imageIDParts[3] + '_' + imageIDParts[2] + '_L' +  imageIDParts[0].slice(3,4);
      }else if(satellite.indexOf('Sentinel-1') !== -1){
        imageIDParts = imageData.properties['ID'].split("_");
        imageID = imageIDParts[4].slice(0, 8) + "_" +imageIDParts[6] + "_" +imageIDParts[0];
      }
      var visualization = VISUALIZATIONS[visSelect.getValue()];  
      var imageTitle = date + ' | ' + imageID;
      var thumbnail = makeThumbnail(imageTitle, imageID, mosaic.select(visualization.BANDS), roi, region);
      timeSeries.add(thumbnail);
    });
  });
}
function updateTimeSeriesModis(coordinates, roi){
  map.addLayer(roi,  {color: 'FF0000'}, "Point");
  var collection = ee.ImageCollection([]);
  var index = TIMESERIES_COLLECTIONS[serieIndex.getValue()];
  if(['NDVI', 'EVI2', 'NBR'].indexOf(serieIndex.getValue()) !== -1 ){
    var mod13q1Collection = ee.ImageCollection(Manager().getMOD13Q1Collection(
      startDateSeries.getValue(), 
      endDateSeries.getValue(),
      roi
    ));
    collection = collection.merge(mod13q1Collection);
  }else if(['NDVI_8_days', 'EVI2_8_days'].indexOf(serieIndex.getValue()) !== -1 ){
    var mod09Q1Collection = ee.ImageCollection(Manager().getMOD09Q1Collection(
      startDateSeries.getValue(), 
      endDateSeries.getValue(),
      roi
    ));
    mod09Q1Collection = mod09Q1Collection
    collection = collection.merge(mod09Q1Collection);
  }else if(index.bandName === 'LST'){
    var mod11a2Collection = ee.ImageCollection(Manager().getMOD11A2Collection(
      startDateSeries.getValue(), 
      endDateSeries.getValue(),
      roi
    ));
    collection = collection.merge(mod11a2Collection);
  }else if(index.bandName === 'ET'){
    var mod16a2Collection = ee.ImageCollection(Manager().getMOD16A2Collection(
      startDateSeries.getValue(), 
      endDateSeries.getValue(),
      roi
    ));
    collection = collection.merge(mod16a2Collection);
  }else if(index.bandName === 'P'){
    var chirpsCollection = ee.ImageCollection(Manager().getCHIRPSCollection(
      startDateSeries.getValue(), 
      endDateSeries.getValue(),
      roi
    ));
    collection = collection.merge(chirpsCollection);
  }
  var series = collection
    .select(index.bandName)
    .getRegion({
      geometry: roi, 
      scale: 30,
    })
    .slice(1)
    .map(function(list){
      return ee.Algorithms.If(
        ee.Algorithms.IsEqual(ee.List(list).get(-1), null),
        0,
        ee.List(list)
      );
    });
  var validSeries = ee.List(series).removeAll([0]);
  var yValues = validSeries.map(function(item){
    return ee.List(item).get(-1);
  });
  var xValues = validSeries.map(function(item){
    return ee.List(item).get(-2);
  });
  if(savitzkyGolay.getValue() !== 0){
    var smooth = savitzkyGolaySmooth(yValues, 8-savitzkyGolay.getValue());
  }
  var options = {
    title: ''
  };
  var finalXValues = xValues;
  var finalYValue = finalXValues.map(function(value){
    var mask = -100;
    var values = ee.List([]);
    var index = xValues.indexOf(value);
    values = ee.List(ee.Algorithms.If(index.gte(0), values.add(yValues.get(index)), values.add(mask)));
    if(savitzkyGolay.getValue() !== 0){
      values = ee.List(ee.Algorithms.If(index.gte(0), values.add(smooth.get(index)), values.add(mask)));
    }
    values = values.map(function(value){
      value = ee.Number(value);
      return ee.Algorithms.If(value.eq(mask), null, value);
    });
    return values;
  });
  timeSeries = ui.Chart.array.values({
      array: finalYValue,
      axis: 0, 
      xLabels: finalXValues,
    })
    .setChartType('LineChart')
  if(savitzkyGolay.getValue() !== 0){
    timeSeries.setSeriesNames([index.bandName, 'SG' ])
    options["series"] = {
        0: {targetAxisIndex:0, lineWidth: 0, pointSize: 5, interpolateNulls: true, color: "#0e5e12"},
        1: {targetAxisIndex:0, lineWidth: 3, pointSize: 0 }
    };
  }else{
    timeSeries.setSeriesNames([index.bandName]);
    options["series"] = {
        0: {targetAxisIndex:0, lineWidth: 1, pointSize: 5, interpolateNulls: true, color: "#0e5e12"},
        1: {targetAxisIndex:0, lineWidth: 1, pointSize: 5}
    };
  }
  options["vAxes"] = {
      0: {
        viewWindowMode:'explicit',
        viewWindow: {
          min:index.min,
          max:index.max
        },
        minValue: index.max, 
        maxValue: index.min,
      },
    };
  options["interpolateNulls"] = true;
  timeSeries
    .setOptions(options)
    .style()
    .set({'width': '99%', 'height': '90%', 'padding': '0px', 'margin': '0px'});
  panelTimeSeries.clear();
  panelTimeSeries.setLayout(ui.Panel.Layout.flow("vertical"));
  panelTimeSeries.add(ui.Label(coordinates + "Clique em qualquer ponto da série temporal MODIS para visualizar a imagem mais próxima do ponto clicado. "));
  panelTimeSeries.add(timeSeries);
  // When the chart is clicked, update the map and label.
  timeSeries.onClick(function(xValue, yValue, seriesName) {
    if (!xValue) return;  // ScurrentPointelection was cleared.
    // Show the image for the clicked date.
    var clickedDate = ee.Date(xValue);
    var date_next = ee.Date(xValue).advance(8, "day");
    var date_previous = ee.Date(xValue).advance(-8, "day");
    var selectedSatellites = getSelectedSatellites(satellites);
    var collection = ee.ImageCollection(getSelectedCollection(selectedSatellites,  date_previous, date_next, roi))
      .map(function(image){
        image = ee.Image(image);
        return image.set("DISTANCE", clickedDate.millis().subtract(image.date().millis()).abs());
      });
    var image = ee.Image(collection
      .limit(1, 'CLOUD_OR_NODATA_PERCETAGE')
      .first()
    );
    var visualization = VISUALIZATIONS[visSelect.getValue()];  
    try{
      image.get("ID").evaluate(function(filename){
        ARDLib.contrastService.addLayer(map, image.select(visualization.BANDS), null, image.geometry(), {}, filename);
      });
    }catch(err){
      print(err);
    }
  });  
}
// End Update Functions 
function makeThumbnail(title, link, image, geometry, region) {
  var thumbnailContainer = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical'),
    style: {
      backgroundColor: '#11ffee00',
      border: '4px solid rgba(97, 97, 97, 0.5)',
      margin: '0px',
      width: '300px',
      height: '330px',
    },
  });
  var geometryVis = ee.FeatureCollection(geometry)
    .style({color: "fffb09", fillColor: "00000000", width: 3});
  var imageVis = ARDLib.visualizeImage(image, region);
  var thumbnail = ui.Thumbnail({
    image: geometryVis.unmask(imageVis).set("system:footprint", region).reproject("EPSG:3857", null, 10),
    params: {
      dimensions: "290", 
      format: 'jpg'
    },
    style: {
        maxWidth: '290px',
        maxHeight: '290px',
        margin: '0px',
        padding: '0px',
        backgroundColor: '#11ffee00',
    },
    onClick: function(){
      ARDLib.contrastService.addLayer(map, image, geometryVis, geometry, {}, title);
    }
  });
  thumbnailContainer.add(ui.Label({value: title}));
  thumbnailContainer.add(thumbnail);
  return thumbnailContainer;
}
function getSelectedSatellites(satellites){
  var selectedSatellites = [];
  satellites.forEach(function(satelliteKey){
    var satellite = satellitesDict[satelliteKey];
    if(satellite.checked === true){
      selectedSatellites.push(satellite.value);
    }
  })
  return selectedSatellites;
};
function getSelectedCollection(satellites, startDate, endDate, roi, selectedMonth){
  var useFirstImageValue = useFirstImage.getValue();
  var allImages = ee.ImageCollection([]);
  var filteredCollection = null;
  satellites.forEach(function(satellite){
    var collectionData = COLLECTIONS[satellite];
    var collection = null;
    if(satellite === 'S1'){
      collection = SARLib.getCollection(startDate, endDate, roi).map(function(image){
        return image.set('SPACECRAFT', 'Sentinel-1');
      });
    }else{
      collection = ee.ImageCollection(ARDLib.getCollection(
        collectionData.SATELLITE, 
        roi,
        startDate, 
        endDate,
        100, 
        function(image){
          return  ARDLib.bandPassAjustment(ARDLib.padronizeBandNames(ARDLib.padronizeProperties(image)));
        }
      ))
      if(selectedMonth){
        collection = collection
          .map(function(image){
            return image
              .set("MONTH", image.date().get('month'))
              .set("YEAR", image.date().get('year'))
          })
          .filterMetadata('MONTH', 'equals', selectedMonth);
      }
      collection = collection.map(function(image){
        var stats = calcCloudProperties(image, roi);
        return image.setMulti(stats);
      });
    }
    var filteredCollection = collection
      .map(function(image){
        var date = image.date().format("dd/MM/yyyy");
        var satellite = ee.String(image.get('SPACECRAFT'));
        return ee.Image(image
          .float()
          .copyProperties(image, ["system:time_start", "system:index", "system:footprint", "CLOUD_OR_NODATA_PERCETAGE"]))
          .set("DATE", date)
          .set("YEAR", image.date().get('year'))
          .set("SATELLITE", satellite)
          .set("DATE_AND_SATELLITE", date.cat('_').cat(satellite))
          .set("ID", image.get(collectionData.ID_FIELD));
      });
    allImages = allImages.merge(filteredCollection);
  });
  if(useFirstImageValue){
    var allYears = allImages.aggregate_array('YEAR').distinct().sort();
    allImages = ee.ImageCollection(allYears.iterate(function(year, images){
      images = ee.ImageCollection(images);
      var selectedImages = allImages.filterMetadata('YEAR', 'equals', year);
      return ee.List(
        ee.Algorithms.If(ee.Algorithms.IsEqual(selectedImages.size(), 0), 
          images, 
          images.merge(ee.ImageCollection([ee.Image(selectedImages.first())]))
        )
      );
    }, ee.ImageCollection([])));
  }
  return allImages.sort("system:time_start");
}
function Manager(){
  return new function(){
    this.MOD13Q1 = "MODIS/061/MOD13Q1";
    this.MOD09Q1 = "MODIS/061/MOD09Q1";
    this.MOD16A2 = "MODIS/061/MOD16A2";
    this.MOD11A2 = "MODIS/061/MOD11A2";
    this.GPM     = "NASA/GPM_L3/IMERG_V05";
    this.CHIRPS  = "UCSB-CHG/CHIRPS/DAILY";
    this.getMOD13Q1Collection = function(start, end, roi){
      var modisCollection = ee.ImageCollection(this.MOD13Q1)
        .filterDate(start, end)
        .map(function(image){
          //var cloudMask = ARDLib.getcloudMaskByQA(
          //image.select(['DetailedQA'], ['BQA']).set('SPACECRAFT', 'MOD13Q1'));
          //image = image.updateMask(cloudMask.unmask().not());
          var ndvi = image.select("NDVI").multiply(0.0001);
          var evi2 = image.expression("2.4 *  ( (N-R) / (N + (2.4 * R) + 1) )", {
            "N": image.select('sur_refl_b02').divide(10000),
            "R": image.select('sur_refl_b01').divide(10000),
          }).rename("EVI2")
           var nbr = image.expression("((NIR-SWIR)/(NIR+SWIR))", {
            "NIR": image.select('sur_refl_b02').divide(10000),
            "SWIR": image.select('sur_refl_b07').divide(10000),
          }).rename("NBR");
          return ee.Image(image.addBands(ndvi, ["NDVI"], true)
            .addBands(evi2)
            .addBands(nbr)
            .copyProperties(image));
        })
        .select(["NDVI", "EVI2", "NBR", "DayOfYear"], ["NDVI", "EVI2",  "NBR", "DOY"]);
      return modisCollection;
    };
    this.getMOD09Q1Collection = function(start, end, roi){
      var modisCollection = ee.ImageCollection(this.MOD09Q1)
        .filterDate(start, end)
        .map(function(image){
          var cloudMask = ARDLib.getcloudMaskByQA(
            image.select(['State'], ['BQA']).set('SPACECRAFT', 'MOD09Q1'));
          image = image.updateMask(cloudMask.unmask().not());
          var ndvi = image.normalizedDifference(['sur_refl_b02', 'sur_refl_b01'])
            .rename("NDVI");
          var evi2 = image.expression("2.4 *  ( (N-R) / (N + (2.4 * R) + 1) )", {
            "N": image.select('sur_refl_b02').divide(10000),
            "R": image.select('sur_refl_b01').divide(10000),
          }).rename("EVI2");
          return ee.Image(image.addBands(ndvi).addBands(evi2).copyProperties(image));
        })
        .select(["NDVI", "EVI2"], ["NDVI", "EVI2"]);
      return modisCollection;
    };
    this.getMOD16A2Collection = function(start, end, roi){
      var modisCollection = ee.ImageCollection(this.MOD16A2)
        .filterDate(start, end)
        .map(function(image){
          var clippedIMage = image.select("ET").clip(roi).set("system:footprint", roi);
          var et = clippedIMage.select("ET")
            .multiply(0.1) // reescale
            //.multiply(86400) // Kg/M²/8 Days -> mm/M²/8 Days
            .divide(8); // mm/M²/8 Days -> mm/M²/Day
          return ee.Image(et.copyProperties(image, ["system:time_start"]));
        })
      return modisCollection
    };
    this.getMOD11A2Collection = function(start, end, roi){
      var modisCollection = ee.ImageCollection(this.MOD11A2)
        .filterDate(start, end)
        .map(function(image){
          var clippedImage = image.select(["LST_Day_1km", "Day_view_time"]).clip(roi).set("system:footprint", roi);
          var lst = clippedImage.select("LST_Day_1km").multiply(0.02).rename("LST");
          return clippedImage.select(["Day_view_time"], ["DOY"]).addBands(lst).copyProperties(image, ["system:time_start"])
        });
      return modisCollection
    };
    this.getCHIRPSCollection = function(start, end, roi){
      var chirpsCollection = ee.ImageCollection(this.CHIRPS)
        .filterDate(start, end)
        .map(function(image){
          return ee.Image(image).clip(roi).set("system:footprint", roi);
        })
        .select(["precipitation"], ["P"]);
      return chirpsCollection;
    };
    return this;
  }
}
function getCollection(paths, startDate, endDate, roi){
  var collection = ee.ImageCollection([]);
  paths.forEach(function(path){
     var newCollection = ee.ImageCollection(path)
      .filterDate(startDate, endDate)
      .filterBounds(roi)
      .map(ARDLib.padronizeProperties)
      .map(ARDLib.padronizeBandNames)
      .map(ARDLib.bandPassAjustment)
      .map(function(image){
        var stats = calcCloudProperties(image, roi);
        return image.setMulti(stats);
      });
    collection = collection.merge(newCollection);
  });
  return collection;
}
function savitzkyGolaySmooth(y, order){
  var window_size = 11
  var half_window = (window_size - 1)/2
  var deriv = 0
  var order_range = ee.List.sequence(0, order)
  var k_range = ee.List.sequence(-half_window, half_window)
  //b = np.mat([[k**i for i in order_range] for k in range(-half_window, half_window+1)])
  var b = ee.Array(k_range.map(function (k) { return order_range.map(function(o) { return ee.Number(k).pow(o)})}))
  // m = np.linalg.pinv(b).A[deriv] 
  var mPI = ee.Array(b.matrixPseudoInverse())
  var impulse_response = (mPI.slice({axis: 0, start: deriv, end: deriv+1})).project([1])
  //firstvals = y[0] - np.abs( y[1:half_window+1][::-1] - y[0] )
  var y0 = y.get(0)
  var firstvals = y.slice(1, half_window+1).reverse().map(
    function(e) { return ee.Number(e).subtract(y0).abs().multiply(-1).add(y0) }
  )
  //lastvals = y[-1] + np.abs(y[-half_window-1:-1][::-1] - y[-1])
  var yend = y.get(-1)
  var lastvals = y.slice(-half_window-1,-1).reverse().map(
    function(e) { return ee.Number(e).subtract(yend).abs().add(yend) }
  )
  // y = np.concatenate((firstvals, y, lastvals))
  var y_ext = firstvals.cat(y).cat(lastvals)
  // np.convolve( m, y, mode='valid')
  var runLength = ee.List.sequence(0, y_ext.length().subtract(window_size))
  var smooth = runLength.map(function(i) {
    return ee.Array(y_ext.slice(ee.Number(i), ee.Number(i).add(window_size))).multiply(impulse_response).reduce("sum", [0]).get([0])
  })
  return smooth
}
function geojson2geometry(geojson){
  var obj = JSON.parse(geojson);
  if(obj["type"] === 'FeatureCollection'){
    var features = [];
    obj.features.forEach(function(geom){
      var geometry = ee.Geometry({
        geoJson: geom["geometry"],
        evenOdd: true, 
      });
      var feature = ee.Feature(geometry);
      features.push(feature);
    });
    var featureCollection = ee.FeatureCollection(features);
    return featureCollection.geometry();    
  }else{
    var geometry = ee.Geometry({
      geoJson: obj,
      evenOdd: true, 
    });
    return geometry;
  }
}
// Welcome 
var panel_intro = ui.Panel();
panel_intro.style().set({ width: '700px',height: '90%', position: 'top-center',color: '#4874ba', fontWeight: 'bold'});
// Add a button to hide the Panel.
panel_intro.add(ui.Button({label: 'Fechar', style: {color: 'black'},
  onClick: function() {
    panel_intro.style().set('shown', false);}
}));
// Add the title text
var title = ui.Panel({
  widgets: [
    ui.Label('Seja bem vindo ao', {"fontSize": '25px', "fontWeight": 'bold', "textAlign": 'center', "color":'black', "margin": '0px 3px 0px 3px'}),
    ui.Thumbnail({
      image: logo, 
      params: {
        format: 'PNG',
        bands: 'b1,b2,b3',
        dimensions: '100x100'
      }, 
      style: {
        'width': '30px',
        'margin': '0px 5px 0px 0px', 
        'padding': '0px'
      }
    }),
    ui.Label("A", {"color": "#3D88ED", 'margin': '3px', 'fontSize': '25px', 'fontWeight': 'bold', 'textAlign': 'center'}), 
    ui.Label("L", {"color": "#F0403B", 'margin': '3px', 'fontSize': '25px', 'fontWeight': 'bold', 'textAlign': 'center'}),
    ui.Label("E", {"color": "#FDBB41", 'margin': '3px', 'fontSize': '25px', 'fontWeight': 'bold', 'textAlign': 'center'}),
    ui.Label("R", {"color": "#3D88ED", 'margin': '3px', 'fontSize': '25px', 'fontWeight': 'bold', 'textAlign': 'center'}),
    ui.Label("T", {"color": "#21A85E", 'margin': '3px', 'fontSize': '25px', 'fontWeight': 'bold', 'textAlign': 'center'}),
    ui.Label("A", {"color": "#F0403B", 'margin': '3px', 'fontSize': '25px', 'fontWeight': 'bold', 'textAlign': 'center'}),
    ui.Label("S", {"color": "#FDBB41", 'margin': '3px', 'fontSize': '25px', 'fontWeight': 'bold', 'textAlign': 'center'}),
  ], 
  layout: ui.Panel.Layout.flow("horizontal")
});
panel_intro.add(title);
var intro = ui.Panel([ui.Label({value: 'Antes de começar a explorar a ferramenta, aqui estão algumas dicas e truques. Leia com atenção :)',
    style: {color: 'black',fontWeight: 'normal',}})]);
panel_intro.add(intro);
var intro2 = ui.Panel([ui.Label({value: 'No lado direito da tela existe um painel com a lista de todas as camadas disponíveis no sistema. Para facilidade de uso, algumas camadas têm a opção de filtrar dados por data. Algumas camadas, como alertas de desmatamento, permitem que você, ao clicar em qualquer feição do mapa de camadas, visualize todas as imagens de satélite obtidas para aquela feição.',
    style: {color: 'black',fontWeight: 'normal',}})]);
panel_intro.add(intro2);
var intro3 = ui.Panel([ui.Label({value: 'Para definir o período em que o sistema buscará as imagens, o limite máximo permitido de cobertura de nuvens, a composição da visualização e até mesmo quais sensores serão utilizados, você pode utilizar o painel de configurações no canto esquerdo do sistema.',
    style: {color: 'black',fontWeight: 'normal',}})]);
panel_intro.add(intro3);
var intro4 = ui.Panel([ui.Label({value: 'Se desejar, você também pode enviar sua própria geometria, no formato GeoJSON e projeção EPSG: 4326. Para gerar sua geometria, basta acessar um GIS como QGIS ou ArcGIS e ir até a opção "Exportar como" e selecionar o formato GeoJSON. Depois de salvar o arquivo, basta abri-lo com um editor de texto e copiá-lo e colá-lo na caixa de texto do painel lateral.',
    style: {color: 'black',fontWeight: 'normal',}})]);
panel_intro.add(intro4);
var intro5 = ui.Panel([ui.Label({value: 'Se você tiver alguma dúvida, entre em contato: saraiva.ufc@gmail.com.',
    style: {color: 'black',fontWeight: 'normal',}})]);
panel_intro.add(intro5);
var intro6 = ui.Panel([ui.Label({value: 'Licença: CC BY-SA 4.0',
    style: {color: 'black',fontWeight: 'normal',}})]);
panel_intro.add(intro6);
var end = ui.Panel([ui.Label({value: 'Pressione o botão "Fechar" para começar a explorar a ferramenta. Enjoy!',
    style: {color: 'black', fontWeight: 'bold'}})]);
panel_intro.add(end);
map.add(panel_intro);
/*  CLOUD COVER FUNCTIONS */
function calcCloudProperties(image, roi){
  var maskedImage = ARDLib.maskImage(image);
  var validPixels = ee.Image(0).clip(roi)
    .blend(maskedImage.select(1).mask().unmask());
  var roiNodata = validPixels
    .rename('mask')
    .reduceRegion({
      reducer: ee.Reducer.sum().combine(ee.Reducer.count(), null, true),
      geometry: roi, 
      scale: 30
    });
  var validPercentage = roiNodata.getNumber('mask_sum').divide(roiNodata.getNumber('mask_count')).multiply(100);
  var invalidPercentage = ee.Number(100).subtract(validPercentage);
  var stats = ee.Dictionary({
    'CLOUD_OR_NODATA_PERCETAGE': invalidPercentage,
  });
  return stats;
}