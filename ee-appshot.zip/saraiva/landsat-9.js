// Display a grid of linked maps, each with a different visualization.
/*
 * Image setup
 */
// Create an initial mosiac, which we'll visualize in a few different ways.
var image_true_color = ee.Image('users/saraiva/layers/landsat_9/true_color/LC09_L1TP_226069_20220122_20220122_02_T1_TRUE_COLOR');
var image_true_color_15m = ee.Image('users/saraiva/layers/landsat_9/true_color_15m/LC09_L1TP_226069_20220122_20220122_02_T1_TRUE_COLOR_15M');
var image_false_color = ee.Image('users/saraiva/layers/landsat_9/false_color/LC09_L1TP_226069_20220122_20220122_02_T1_FALSE_COLOR');
var image_vi = image_false_color.normalizedDifference(['b1', 'b3']).rename('NDVI');
// Each map has a name and some visualization parameters .
var MAP_PARAMS = {
  'Cor Natural (B4/B3/B2) - 30 metros': {
    'image': image_true_color,
    'min': [6691, 7864, 8558],
    'max': [13112, 11298, 10914]
  },
  'Falsa Cor (B5/B6/B4)':  {
    'image': image_false_color,
    'min': [13813, 10518, 6586],
    'max': [27884, 23294, 11855]
  },
  'Cor Natural (B4/B3/B2) - 15 metros':  {
    'image': image_true_color_15m,
    'min': [6691, 7864, 8558],
    'max': [13112, 11298, 10914]
  },
  'Índice de Vegetação (NDVI)':  {
    'image': image_vi,
    'min': 0,
    'max': 0.6,
    'palette': 'ff0000,ff8f06,fcff00,92ff00,0ade19'
  },
};
/*
 * Configure maps, link them in a grid
 */
// Create a map for each visualization option.
var maps = [];
Object.keys(MAP_PARAMS).forEach(function(name) {
  var params = MAP_PARAMS[name];
  var map = ui.Map();
  map.add(ui.Label(name));
  map.addLayer(params['image'], {min: params['min'], max: params['max'], palette: params['palette']}, name);
  map.setControlVisibility(false);
  maps.push(map);
});
var linker = ui.Map.Linker(maps);
// Enable zooming on the top-left map.
maps[0].setControlVisibility({zoomControl: true});
// Show the scale (e.g. '500m') on the bottom-right map.
maps[3].setControlVisibility({scaleControl: true});
// Create a grid of maps.
var mapGrid = ui.Panel(
    [
      ui.Panel([maps[0], maps[1]], null, {stretch: 'both'}),
      ui.Panel([maps[2], maps[3]], null, {stretch: 'both'})
    ],
    ui.Panel.Layout.Flow('horizontal'), {stretch: 'both'});
// Center the map at an interesting spot in Greece. All
// other maps will align themselves to this parent map.
maps[0].setCenter(-55.25499, -12.35603, 14);
/*
 * Add a title and initialize
 */
// Create a title.
var title = ui.Label('LANDSAT 9 - 22/01/2022', {
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight: 'bold',
  fontSize: '24px'
});
// Add the maps and title to the ui.root.
ui.root.widgets().reset([title, mapGrid]);
ui.root.setLayout(ui.Panel.Layout.Flow('vertical'));