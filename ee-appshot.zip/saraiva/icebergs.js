var imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "COPERNICUS/S1_GRD"
    }) || ee.ImageCollection("COPERNICUS/S1_GRD"),
    A74 = ui.import && ui.import("A74", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -25.26339322891007,
            -75.13929275905933
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Point([-25.26339322891007, -75.13929275905933]),
    D28 = ui.import && ui.import("D28", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            72.28905009795506,
            -68.60275190689849
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #98ff00 */ee.Geometry.Point([72.28905009795506, -68.60275190689849]),
    A68 = ui.import && ui.import("A68", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -60.95553710251998,
            -67.85353790899767
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #0b4a8b */ee.Geometry.Point([-60.95553710251998, -67.85353790899767]);
// var col = imageCollection
//   .filterDate('2017-07-01', '2017-07-29')
//   .select('HH')
//   .filterBounds(Map.getCenter())
//   .sort('system:time_start');
var a68Col = imageCollection
  .filterDate('2017-07-01', '2017-09-30')
  .select('HH')
  .filterBounds(A68)
  .sort('system:time_start');
var d28Col = imageCollection
  .filterDate('2019-09-01', '2019-10-30')
  .select('HH')
  .filterBounds(D28)
  .sort('system:time_start');
var a74Col = imageCollection
  .filterDate('2021-02-01', '2021-03-17')
  .select('HH')
  .filterBounds(A74)
  .sort('system:time_start');
var a68Bbox = A68.buffer(90000).bounds();
var d28Bbox = D28.buffer(90000).bounds();
var a74Bbox = A74.buffer(90000).bounds();
// col.evaluate(function(col){
//   col.features.forEach(function(imageData){
//     var image = ee.Image(imageData.id).select('HH');
//     Map.addLayer(image, 
//       {min: -26.52, max: 0.31}, 
//       new Date(imageData.properties['system:time_end']).toString(), false)
//   })
// })
function create_panel(col, bbox, name, area, period){
  var args = {
    crs: 'EPSG:3857',
    dimensions: '700',
    region: bbox,
    min: -26.52,
    max: 0.31,
    framesPerSecond: 1,
  };
  var panelStyle = {fontSize: '20px'};
  var panel = ui.Panel({
    widgets: [
      ui.Label('Iceberg name: ' + name, panelStyle),
      ui.Label('Area: ' + area, panelStyle),
      ui.Label('Images: Sentinel-1 SAR (' + period + ')', panelStyle),
    ]
  });
  var thumb = ui.Thumbnail({
    image: col,
    params: args,
    style: {
      position: 'top-center',
      width: '600px'
  }});
  panel.add(thumb);
  return panel
}
var a68Panel = create_panel(a68Col, a68Bbox, 'A68', '5,800 km²', '2017-07-01 - 2017-09-30');
var d28Panel = create_panel(d28Col, d28Bbox, 'D28', '1,636 km²', '2019-09-01 - 2019-10-30');
var a74Panel = create_panel(a74Col, a74Bbox, 'A74', '1,290 km²', '2021-02-01 - 2021-03-17');
var fullPanel = ui.Panel({
  widgets: [a68Panel, d28Panel, a74Panel],
  style: {
    position: 'top-center',
    width: '95%'
  },
  layout: ui.Panel.Layout.flow('horizontal')
});
ui.root.clear();
var map = ui.Map();
map.setControlVisibility(false);
map.add(fullPanel)
ui.root.add(map);