var ned = ee.Image("USGS/3DEP/10m");
var vis_params = {
  'min': 0, 
  'max': 4000, 
  'palette': ["006633", "E5FFCC", "662A00", "D8D8D8", "F5F5F5"]
};
var hillshade = ee.Terrain.hillshade(ned);
Map.addLayer(hillshade, {}, 'Hillshade');
Map.addLayer(ned, vis_params, 'NED (10m)', true, 0.7);
var dataset = ee.Image('JRC/GSW1_3/GlobalSurfaceWater');
var visualization = {
  bands: ['occurrence'],
  min: 0.0,
  max: 100.0,
  palette: ['ffffff', 'ffbbbb', '0000ff']
};
Map.setCenter(-100, 40, 4);
Map.addLayer(dataset, visualization, 'Occurrence');
var dep = ee.FeatureCollection("users/giswqs/MRB/NED_10m_sinks_v2");
Map.addLayer(dep, {}, 'depressions');
var nhd = ee.FeatureCollection('users/giswqs/MRB/NWI_HU8');
Map.addLayer(nhd.style({"fillColor": "00000000", 'color': '0000ff'}), {}, "NHD-HUC08");