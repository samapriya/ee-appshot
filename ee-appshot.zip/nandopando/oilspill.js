var Nautilus_point = ui.import && ui.import("Nautilus_point", "table", {
      "id": "users/nandopando/seep_methane_nautilus-point"
    }) || ee.FeatureCollection("users/nandopando/seep_methane_nautilus-point"),
    confetti_Plume = ui.import && ui.import("confetti_Plume", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -90.61653455257107,
                27.41262031756101
              ],
              [
                -90.61653455257107,
                27.30071227112142
              ],
              [
                -90.47302564143826,
                27.30071227112142
              ],
              [
                -90.47302564143826,
                27.41262031756101
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-90.61653455257107, 27.41262031756101],
          [-90.61653455257107, 27.30071227112142],
          [-90.47302564143826, 27.30071227112142],
          [-90.47302564143826, 27.41262031756101]]], null, false),
    Sleeping_Dragon = ui.import && ui.import("Sleeping_Dragon", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -88.5001866625821,
                28.85900058865152
              ],
              [
                -88.5001866625821,
                28.8443411350962
              ],
              [
                -88.48190472593659,
                28.8443411350962
              ],
              [
                -88.48190472593659,
                28.85900058865152
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ffc82d",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-88.5001866625821, 28.85900058865152],
          [-88.5001866625821, 28.8443411350962],
          [-88.48190472593659, 28.8443411350962],
          [-88.48190472593659, 28.85900058865152]]], null, false),
    kwaitt = ui.import && ui.import("kwaitt", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                48.514769185360485,
                28.711866392897576
              ],
              [
                48.43923817950111,
                28.707650766780887
              ],
              [
                48.435118306454235,
                28.683257024381444
              ],
              [
                48.424131978329235,
                28.63626047295089
              ],
              [
                48.421385396297985,
                28.59888921666866
              ],
              [
                48.45846425371986,
                28.565123106750182
              ],
              [
                48.46395741778236,
                28.55064859877527
              ],
              [
                48.523008931454235,
                28.53496563631304
              ],
              [
                48.57931386309486,
                28.521090300421548
              ],
              [
                48.61707936602455,
                28.52320188240367
              ],
              [
                48.6429983262483,
                28.524406833346646
              ],
              [
                48.61673604327064,
                28.60732904985972
              ],
              [
                48.57931386309486,
                28.68084745744286
              ],
              [
                48.562491048153454,
                28.71156528238033
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#00ffff",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[48.514769185360485, 28.711866392897576],
          [48.43923817950111, 28.707650766780887],
          [48.435118306454235, 28.683257024381444],
          [48.424131978329235, 28.63626047295089],
          [48.421385396297985, 28.59888921666866],
          [48.45846425371986, 28.565123106750182],
          [48.46395741778236, 28.55064859877527],
          [48.523008931454235, 28.53496563631304],
          [48.57931386309486, 28.521090300421548],
          [48.61707936602455, 28.52320188240367],
          [48.6429983262483, 28.524406833346646],
          [48.61673604327064, 28.60732904985972],
          [48.57931386309486, 28.68084745744286],
          [48.562491048153454, 28.71156528238033]]]),
    Morrosquillo = ui.import && ui.import("Morrosquillo", "table", {
      "id": "users/nandopando/Area_estudio"
    }) || ee.FeatureCollection("users/nandopando/Area_estudio"),
    Estado_Valencia = ui.import && ui.import("Estado_Valencia", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -68.18755258782112,
                10.525949052351796
              ],
              [
                -68.16523660881721,
                10.503332680969738
              ],
              [
                -68.1594001220008,
                10.501644825646393
              ],
              [
                -68.15425028069221,
                10.502319968881844
              ],
              [
                -68.14189066155159,
                10.493542991819549
              ],
              [
                -68.13639749748909,
                10.490167165087055
              ],
              [
                -68.13056101067268,
                10.487466477183418
              ],
              [
                -68.1264411376258,
                10.492867829419932
              ],
              [
                -68.11991800530159,
                10.491179916974387
              ],
              [
                -68.10755838616096,
                10.483077809083
              ],
              [
                -68.09210886223518,
                10.493542991819549
              ],
              [
                -68.08077921135627,
                10.501644825646393
              ],
              [
                -68.06635965569221,
                10.497931511493428
              ],
              [
                -68.04198374016487,
                10.54113822162286
              ],
              [
                -68.15768350823127,
                10.624159076417872
              ],
              [
                -68.21330179436409,
                10.553964047779557
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-68.18755258782112, 10.525949052351796],
          [-68.16523660881721, 10.503332680969738],
          [-68.1594001220008, 10.501644825646393],
          [-68.15425028069221, 10.502319968881844],
          [-68.14189066155159, 10.493542991819549],
          [-68.13639749748909, 10.490167165087055],
          [-68.13056101067268, 10.487466477183418],
          [-68.1264411376258, 10.492867829419932],
          [-68.11991800530159, 10.491179916974387],
          [-68.10755838616096, 10.483077809083],
          [-68.09210886223518, 10.493542991819549],
          [-68.08077921135627, 10.501644825646393],
          [-68.06635965569221, 10.497931511493428],
          [-68.04198374016487, 10.54113822162286],
          [-68.15768350823127, 10.624159076417872],
          [-68.21330179436409, 10.553964047779557]]]),
    studio1 = ui.import && ui.import("studio1", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #98ff00 */ee.Geometry.MultiPoint();
//Map.addLayer(Nautilus_point)
var zonaestudio = {
  'Oil Spill Pipeline Damage Kuwaitt (2017-08-09)' : kwaitt,
  'Oil Spill Refinery El Palito Venezuela (2020-07-06)' : Estado_Valencia,
  'Seep Methane Confetti Plume, Mexico Gulf (2019-02-26)':confetti_Plume,
  'Seep Methane Sleeping Dragon':Sleeping_Dragon,
  'Morrosquillo exploration block ': Morrosquillo,
  'Draw your study area': studio1,
};
var YEARS = {'2017': 2017, '2018': 2018, '2019': 2019,'2020':2020};
var DIA = {'1': 1, '2': 2, '3': 3,'4': 4, '5': 5, '6': 6,
'7': 7, '8': 8, '9': 9,'10': 10, '11': 11, '12': 12,
'13': 13, '14': 14, '15': 15,'16': 17, '18': 18, '19': 19};
var MES = {'1': 1, '2': 2, '3': 3,'4': 4, '5': 5, '6': 6,
'7': 7, '8': 8, '9': 9,'10': 10, '11': 11, '12': 12};
/* Create UI Panels */
var panel = ui.Panel({style: {width:'300px',position: 'top-right',
      border: '0.5px solid #000000CC',
      backgroundColor: 'F7F8E0' }});
ui.root.insert(0,panel);
var table = ui.Chart(
    [
      ['<img src=https://www.upb.edu.co/es/imagenes/logo-upb-kitprensa-imagen-institucional-1464096760882.png width=150px>','<img src=https://image.freepik.com/vector-gratis/escena-oceano-burbujas-agua_1639-1509.jpg width=100px>']
    ],
    'Table', {allowHtml: true});
//https://seaflowerfoundation.org/images/ARB.jpg
var titlePanel = ui.Panel([table], 'flow', {width: '300x', padding: '8px'});
panel.add(titlePanel);
//intro
var intro = ui.Label('Oil Spill and Seep Methane Detect v.1', 
{fontWeight: 'bold', fontSize: '18px', textAlign: 'center', backgroundColor: '#A3CCFF00'  }
);
var intro2 = ui.Label('Historical oil spills and Seep Methane Monitoring App ', 
{fontWeight: 'bold', fontSize: '14px', textAlign: 'center', backgroundColor: '#A3CCFF00'  }
);
var subtitle = ui.Label('ESA PROTOCOL: OIL SPILL MAPPING WITH SENTINEL-1, 2018',
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '12px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(intro).add(intro2).add(subtitle);
//select study area
var selectArea = ui.Select({
  items: Object.keys(zonaestudio),
});
selectArea.setPlaceholder('Select an area...');
panel.add(ui.Label('1. Study area or Event',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(selectArea); 
panel.add(ui.Label('2. Date of evaluation',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' }));
var subtitle2 = ui.Label('Fecha Year-Month-Day',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' });
var fecha_1= ui.Textbox('YYYY-MM-DD', '2017-08-09');
panel.add(subtitle2).add(fecha_1)
/////////////////////////////////////////////////////////////////////////////////
// Create Land Use Map
var mapbutton = ui.Label('4.Generate Radar images',
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '15px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(mapbutton);
panel.add(ui.Button("Resulting Thresholds images",landMap));
var additional_directions = ui.Label
  ('Display products in Layers ,', 
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '12px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(additional_directions);
var outputPanel = ui.Panel();
print(outputPanel);
function landMap(){
Map.clear()
var selectedStudy_name = selectArea.getValue();
var studyArea = zonaestudio[selectedStudy_name];
//Map.centerObject(studyArea,9);
Map.centerObject(studyArea,13);
var date_1 = fecha_1.getValue();
var date_2 = ee.Date(date_1).advance(+5,'day');
//Creating the variable as collection to store the filtered scenes:
var sentinel1 = ee.ImageCollection('COPERNICUS/S1_GRD')
    .filter(ee.Filter.eq('instrumentMode', 'IW'))
    //.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'))
    .filter(ee.Filter.eq('resolution_meters', 10))
     .filterBounds(studyArea)
    .filterDate(date_1,date_2)
  .map(function(image) {
      return image.clip(studyArea);
    });
//print(sentinel1, 'Sentinel-1 in dB');
//Changing fisical values from dB to linear power:
var SAR_linear_VV = sentinel1.map(function toNatural(sentinel1) {
  return ee.Image(10.0).pow(sentinel1.select('VV').divide(10.0)).copyProperties(sentinel1);
})
var SAR_linear_VH = sentinel1.map(function toNatural(sentinel1) {
  return ee.Image(10.0).pow(sentinel1.select('VH').divide(10.0)).copyProperties(sentinel1);
})
//Showing in the console the encountered products:
//print(SAR_linear_VV, 'Sentinel-1 VV em intensidade')
//print(SAR_linear_VH, 'Sentinel-1 VH em intensidade')
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Despeckle filtering by Refined Lee filter (Guido Lemoine):
//First to VV band:
var LeeFiltered_VV = function(SAR_linear_VV) {
  // img must be in natural units, i.e. not in dB!
  // Set up 3x3 kernels 
  var weights3 = ee.List.repeat(ee.List.repeat(1,3),3);
  var kernel3 = ee.Kernel.fixed(3,3, weights3, 1, 1, false);
  var mean3 = SAR_linear_VV.reduceNeighborhood(ee.Reducer.mean(), kernel3);
  var variance3 = SAR_linear_VV.reduceNeighborhood(ee.Reducer.variance(), kernel3);
  // Use a sample of the 3x3 windows inside a 7x7 windows to determine gradients and directions
  var sample_weights = ee.List([[0,0,0,0,0,0,0], [0,1,0,1,0,1,0],[0,0,0,0,0,0,0], [0,1,0,1,0,1,0], [0,0,0,0,0,0,0], [0,1,0,1,0,1,0],[0,0,0,0,0,0,0]]);
  var sample_kernel = ee.Kernel.fixed(7,7, sample_weights, 3,3, false);
  // Calculate mean and variance for the sampled windows and store as 9 bands
  var sample_mean = mean3.neighborhoodToBands(sample_kernel); 
  var sample_var = variance3.neighborhoodToBands(sample_kernel);
  // Determine the 4 gradients for the sampled windows
  var gradients = sample_mean.select(1).subtract(sample_mean.select(7)).abs();
  gradients = gradients.addBands(sample_mean.select(6).subtract(sample_mean.select(2)).abs());
  gradients = gradients.addBands(sample_mean.select(3).subtract(sample_mean.select(5)).abs());
  gradients = gradients.addBands(sample_mean.select(0).subtract(sample_mean.select(8)).abs());
  // And find the maximum gradient amongst gradient bands
  var max_gradient = gradients.reduce(ee.Reducer.max());
  // Create a mask for band pixels that are the maximum gradient
  var gradmask = gradients.eq(max_gradient);
  // duplicate gradmask bands: each gradient represents 2 directions
  gradmask = gradmask.addBands(gradmask);
  // Determine the 8 directions
  var directions = sample_mean.select(1).subtract(sample_mean.select(4)).gt(sample_mean.select(4).subtract(sample_mean.select(7))).multiply(1);
  directions = directions.addBands(sample_mean.select(6).subtract(sample_mean.select(4)).gt(sample_mean.select(4).subtract(sample_mean.select(2))).multiply(2));
  directions = directions.addBands(sample_mean.select(3).subtract(sample_mean.select(4)).gt(sample_mean.select(4).subtract(sample_mean.select(5))).multiply(3));
  directions = directions.addBands(sample_mean.select(0).subtract(sample_mean.select(4)).gt(sample_mean.select(4).subtract(sample_mean.select(8))).multiply(4));
  // The next 4 are the not() of the previous 4
  directions = directions.addBands(directions.select(0).not().multiply(5));
  directions = directions.addBands(directions.select(1).not().multiply(6));
  directions = directions.addBands(directions.select(2).not().multiply(7));
  directions = directions.addBands(directions.select(3).not().multiply(8));
  // Mask all values that are not 1-8
  directions = directions.updateMask(gradmask);
  // "collapse" the stack into a singe band image (due to masking, each pixel has just one value (1-8) in it's directional band, and is otherwise masked)
  directions = directions.reduce(ee.Reducer.sum());  
  //var pal = ['ffffff','ff0000','ffff00', '00ff00', '00ffff', '0000ff', 'ff00ff', '000000'];
  //Map.addLayer(directions.reduce(ee.Reducer.sum()), {min:1, max:8, palette: pal}, 'Directions', false);
  var sample_stats = sample_var.divide(sample_mean.multiply(sample_mean));
  // Calculate localNoiseVariance
  var sigmaV = sample_stats.toArray().arraySort().arraySlice(0,0,5).arrayReduce(ee.Reducer.mean(), [0]);
  // Set up the 7*7 kernels for directional statistics
  var rect_weights = ee.List.repeat(ee.List.repeat(0,7),3).cat(ee.List.repeat(ee.List.repeat(1,7),4));
  var diag_weights = ee.List([[1,0,0,0,0,0,0], [1,1,0,0,0,0,0], [1,1,1,0,0,0,0], 
    [1,1,1,1,0,0,0], [1,1,1,1,1,0,0], [1,1,1,1,1,1,0], [1,1,1,1,1,1,1]]);
  var rect_kernel = ee.Kernel.fixed(7,7, rect_weights, 3, 3, false);
  var diag_kernel = ee.Kernel.fixed(7,7, diag_weights, 3, 3, false);
  // Create stacks for mean and variance using the original kernels. Mask with relevant direction.
  var dir_mean = SAR_linear_VV.reduceNeighborhood(ee.Reducer.mean(), rect_kernel).updateMask(directions.eq(1));
  var dir_var = SAR_linear_VV.reduceNeighborhood(ee.Reducer.variance(), rect_kernel).updateMask(directions.eq(1));
  dir_mean = dir_mean.addBands(SAR_linear_VV.reduceNeighborhood(ee.Reducer.mean(), diag_kernel).updateMask(directions.eq(2)));
  dir_var = dir_var.addBands(SAR_linear_VV.reduceNeighborhood(ee.Reducer.variance(), diag_kernel).updateMask(directions.eq(2)));
  // and add the bands for rotated kernels
  for (var i=1; i<4; i++) {
    dir_mean = dir_mean.addBands(SAR_linear_VV.reduceNeighborhood(ee.Reducer.mean(), rect_kernel.rotate(i)).updateMask(directions.eq(2*i+1)));
    dir_var = dir_var.addBands(SAR_linear_VV.reduceNeighborhood(ee.Reducer.variance(), rect_kernel.rotate(i)).updateMask(directions.eq(2*i+1)));
    dir_mean = dir_mean.addBands(SAR_linear_VV.reduceNeighborhood(ee.Reducer.mean(), diag_kernel.rotate(i)).updateMask(directions.eq(2*i+2)));
    dir_var = dir_var.addBands(SAR_linear_VV.reduceNeighborhood(ee.Reducer.variance(), diag_kernel.rotate(i)).updateMask(directions.eq(2*i+2)));
  }
  // "collapse" the stack into a single band image (due to masking, each pixel has just one value in it's directional band, and is otherwise masked)
  dir_mean = dir_mean.reduce(ee.Reducer.sum());
  dir_var = dir_var.reduce(ee.Reducer.sum());
  // A finally generate the filtered value
  var varX = dir_var.subtract(dir_mean.multiply(dir_mean).multiply(sigmaV)).divide(sigmaV.add(1.0));
  var b = varX.divide(dir_var);
  var result = dir_mean.add(b.multiply(SAR_linear_VV.subtract(dir_mean))).rename(['VV_RLee']);
  return SAR_linear_VV.addBands(result.arrayFlatten([['Sigma0_VV']]))
}
//After to VH band:
var LeeFiltered_VH = function(SAR_linear_VH) {
  // img must be in natural units, i.e. not in dB!
  // Set up 3x3 kernels 
  var weights3 = ee.List.repeat(ee.List.repeat(1,3),3);
  var kernel3 = ee.Kernel.fixed(3,3, weights3, 1, 1, false);
  var mean3 = SAR_linear_VH.reduceNeighborhood(ee.Reducer.mean(), kernel3);
  var variance3 = SAR_linear_VH.reduceNeighborhood(ee.Reducer.variance(), kernel3);
  // Use a sample of the 3x3 windows inside a 7x7 windows to determine gradients and directions
  var sample_weights = ee.List([[0,0,0,0,0,0,0], [0,1,0,1,0,1,0],[0,0,0,0,0,0,0], [0,1,0,1,0,1,0], [0,0,0,0,0,0,0], [0,1,0,1,0,1,0],[0,0,0,0,0,0,0]]);
  var sample_kernel = ee.Kernel.fixed(7,7, sample_weights, 3,3, false);
  // Calculate mean and variance for the sampled windows and store as 9 bands
  var sample_mean = mean3.neighborhoodToBands(sample_kernel); 
  var sample_var = variance3.neighborhoodToBands(sample_kernel);
  // Determine the 4 gradients for the sampled windows
  var gradients = sample_mean.select(1).subtract(sample_mean.select(7)).abs();
  gradients = gradients.addBands(sample_mean.select(6).subtract(sample_mean.select(2)).abs());
  gradients = gradients.addBands(sample_mean.select(3).subtract(sample_mean.select(5)).abs());
  gradients = gradients.addBands(sample_mean.select(0).subtract(sample_mean.select(8)).abs());
  // And find the maximum gradient amongst gradient bands
  var max_gradient = gradients.reduce(ee.Reducer.max());
  // Create a mask for band pixels that are the maximum gradient
  var gradmask = gradients.eq(max_gradient);
  // duplicate gradmask bands: each gradient represents 2 directions
  gradmask = gradmask.addBands(gradmask);
  // Determine the 8 directions
  var directions = sample_mean.select(1).subtract(sample_mean.select(4)).gt(sample_mean.select(4).subtract(sample_mean.select(7))).multiply(1);
  directions = directions.addBands(sample_mean.select(6).subtract(sample_mean.select(4)).gt(sample_mean.select(4).subtract(sample_mean.select(2))).multiply(2));
  directions = directions.addBands(sample_mean.select(3).subtract(sample_mean.select(4)).gt(sample_mean.select(4).subtract(sample_mean.select(5))).multiply(3));
  directions = directions.addBands(sample_mean.select(0).subtract(sample_mean.select(4)).gt(sample_mean.select(4).subtract(sample_mean.select(8))).multiply(4));
  // The next 4 are the not() of the previous 4
  directions = directions.addBands(directions.select(0).not().multiply(5));
  directions = directions.addBands(directions.select(1).not().multiply(6));
  directions = directions.addBands(directions.select(2).not().multiply(7));
  directions = directions.addBands(directions.select(3).not().multiply(8));
  // Mask all values that are not 1-8
  directions = directions.updateMask(gradmask);
  // "collapse" the stack into a singe band image (due to masking, each pixel has just one value (1-8) in it's directional band, and is otherwise masked)
  directions = directions.reduce(ee.Reducer.sum());  
  //var pal = ['ffffff','ff0000','ffff00', '00ff00', '00ffff', '0000ff', 'ff00ff', '000000'];
  //Map.addLayer(directions.reduce(ee.Reducer.sum()), {min:1, max:8, palette: pal}, 'Directions', false);
  var sample_stats = sample_var.divide(sample_mean.multiply(sample_mean));
  // Calculate localNoiseVariance
  var sigmaV = sample_stats.toArray().arraySort().arraySlice(0,0,5).arrayReduce(ee.Reducer.mean(), [0]);
  // Set up the 7*7 kernels for directional statistics
  var rect_weights = ee.List.repeat(ee.List.repeat(0,7),3).cat(ee.List.repeat(ee.List.repeat(1,7),4));
  var diag_weights = ee.List([[1,0,0,0,0,0,0], [1,1,0,0,0,0,0], [1,1,1,0,0,0,0], 
    [1,1,1,1,0,0,0], [1,1,1,1,1,0,0], [1,1,1,1,1,1,0], [1,1,1,1,1,1,1]]);
  var rect_kernel = ee.Kernel.fixed(7,7, rect_weights, 3, 3, false);
  var diag_kernel = ee.Kernel.fixed(7,7, diag_weights, 3, 3, false);
  // Create stacks for mean and variance using the original kernels. Mask with relevant direction.
  var dir_mean = SAR_linear_VH.reduceNeighborhood(ee.Reducer.mean(), rect_kernel).updateMask(directions.eq(1));
  var dir_var = SAR_linear_VH.reduceNeighborhood(ee.Reducer.variance(), rect_kernel).updateMask(directions.eq(1));
  dir_mean = dir_mean.addBands(SAR_linear_VH.reduceNeighborhood(ee.Reducer.mean(), diag_kernel).updateMask(directions.eq(2)));
  dir_var = dir_var.addBands(SAR_linear_VH.reduceNeighborhood(ee.Reducer.variance(), diag_kernel).updateMask(directions.eq(2)));
  // and add the bands for rotated kernels
  for (var i=1; i<4; i++) {
    dir_mean = dir_mean.addBands(SAR_linear_VH.reduceNeighborhood(ee.Reducer.mean(), rect_kernel.rotate(i)).updateMask(directions.eq(2*i+1)));
    dir_var = dir_var.addBands(SAR_linear_VH.reduceNeighborhood(ee.Reducer.variance(), rect_kernel.rotate(i)).updateMask(directions.eq(2*i+1)));
    dir_mean = dir_mean.addBands(SAR_linear_VH.reduceNeighborhood(ee.Reducer.mean(), diag_kernel.rotate(i)).updateMask(directions.eq(2*i+2)));
    dir_var = dir_var.addBands(SAR_linear_VH.reduceNeighborhood(ee.Reducer.variance(), diag_kernel.rotate(i)).updateMask(directions.eq(2*i+2)));
  }
  // "collapse" the stack into a single band image (due to masking, each pixel has just one value in it's directional band, and is otherwise masked)
  dir_mean = dir_mean.reduce(ee.Reducer.sum());
  dir_var = dir_var.reduce(ee.Reducer.sum());
  // A finally generate the filtered value
  var varX = dir_var.subtract(dir_mean.multiply(dir_mean).multiply(sigmaV)).divide(sigmaV.add(1.0));
  var b = varX.divide(dir_var);
  var result = dir_mean.add(b.multiply(SAR_linear_VH.subtract(dir_mean))).rename(['VH_RLee']);
  return SAR_linear_VH.addBands(result.arrayFlatten([['Sigma0_VH']]));
}
//Applying the functions to remove speckle noise:
var SentinelUm_Lee_VV = SAR_linear_VV.map(LeeFiltered_VV)
var SentinelUm_Lee_VH = SAR_linear_VH.map(LeeFiltered_VH)
//print(SentinelUm_Lee_VV,"Sentinel-1 VV em intensidade: Lee refinado");
//print(SentinelUm_Lee_VH,"Sentinel-1 VH em intensidade: Lee refinado");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
print(SentinelUm_Lee_VV, "Sentinel-1 Lee");
var VVSentinel_Lee = SentinelUm_Lee_VV.select('Sigma0_VV')
Map.addLayer(SentinelUm_Lee_VV,{ min: 0.001, max: 0.02},'Filtro Lee')
//print (VVSentinel_Leem,'vvmean')
//Apply Thresholds based on < stdvx1.5 to create a vegetation regrowth mask 
var OIL_THRESHOLD = 0.006;
var OIL_thresholded = VVSentinel_Lee.map(function(image) {
      return image.gt(OIL_THRESHOLD);
    });
//Map.addLayer(OIL_thresholded,{},'Oil Spill',false);
//Map.addLayer(AZUL_thresholded,{},'AZULT');
print(OIL_thresholded ,'UMBRAL')
var OIL_band = OIL_thresholded.mean()
var classified_img_kernel = OIL_band.reduceNeighborhood({
    reducer: ee.Reducer.mode(),
    kernel: ee.Kernel.square(2),
  });
Map.addLayer(classified_img_kernel,{},'Oil Spill');
///////
var classes = ee.List([0])
  .map(function(n) {
    var classImage = classified_img_kernel .eq(ee.Number(n));
    var vectors = classImage.updateMask(classImage)
      .reduceToVectors({
        reducer: ee.Reducer.countEvery(), 
       geometry: studyArea, 
        scale: 20,
        maxPixels: 1e10})
      .geometry();
    return ee.Feature(vectors, {"class": n,"size":vectors.area(1)});
  });
var result = ee.FeatureCollection(classes);
Map.addLayer(result,{},'vectores 1');
///////////////////////////////DESCARGA////////////////////////
      var URLDownload = result.getDownloadURL({
        format: 'KMZ',     
        filename: 'Vectores'});
      //print ('Link_to_download', URLDownload); 
      var descarga = ui.Panel({
          style: {
            position: 'top-right',
            padding: '8px 15px'
          }
        });
        var descargaurl = ui.Label({
          value: 'Download the affected area (kmz file):', // Descarga
        style:{
            margin: '4px 0 -1px 4px',
            fontSize: '13px',
            color: '3792cb'}  
      }); // TamaÃ±o de fuente
      descarga.add(descargaurl.setUrl(URLDownload));
      Map.add(descarga);
////////////////////////////////////AREA////////////////
var area_clases_alta = classified_img_kernel.eq([0]).multiply(ee.Image.pixelArea()).divide(10000);
var reducerBuffer_alta = area_clases_alta.reduceRegion({
  reducer: ee.Reducer.sum(),
  maxPixels: 500000000,
  scale: 10,
  geometry: result
});
print ('Total Area derrame', reducerBuffer_alta);
var area = ee.Number(reducerBuffer_alta.get("Sigma0_VV_mode")).format('%.2f').getInfo();
var validation = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var areabosque = ui.Label({
    value: 'Area: '+  area + ' (Hectare)', // Titulo del mapa
    style: {//position: 'bottom-left', // Posicion
    fontWeight: 'bold', // Negrita
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }}); // TamaÃ±o de fuente
 validation.add(areabosque);
  Map.add(validation);   
}