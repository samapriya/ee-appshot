var cinagagsm = ui.import && ui.import("cinagagsm", "table", {
      "id": "projects/ee-nandopando/assets/AlcanceGeografico_MaNglares_CGSM"
    }) || ee.FeatureCollection("projects/ee-nandopando/assets/AlcanceGeografico_MaNglares_CGSM"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.MultiPoint(),
    cober_2020i = ui.import && ui.import("cober_2020i", "table", {
      "id": "projects/gee-alpha-testing-327717/assets/cober_2020_3g"
    }) || ee.FeatureCollection("projects/gee-alpha-testing-327717/assets/cober_2020_3g"),
    cober_2021i = ui.import && ui.import("cober_2021i", "table", {
      "id": "projects/gee-alpha-testing-327717/assets/cober_2021_3g"
    }) || ee.FeatureCollection("projects/gee-alpha-testing-327717/assets/cober_2021_3g"),
    recorte = ui.import && ui.import("recorte", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#00d68c",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #00d68c */ee.Geometry.MultiPoint(),
    cober_2020 = ui.import && ui.import("cober_2020", "table", {
      "id": "users/nandopando/cober_2020_rev"
    }) || ee.FeatureCollection("users/nandopando/cober_2020_rev"),
    cober_2021 = ui.import && ui.import("cober_2021", "table", {
      "id": "users/nandopando/cober_2021_rev"
    }) || ee.FeatureCollection("users/nandopando/cober_2021_rev"),
    ptoscampo = ui.import && ui.import("ptoscampo", "table", {
      "id": "users/nandopando/PuntosFormato"
    }) || ee.FeatureCollection("users/nandopando/PuntosFormato"),
    Laguna1_1 = ui.import && ui.import("Laguna1_1", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -74.65792543481139,
            10.94011310146619
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65736753533629,
            10.939986695225949
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65839750359801,
            10.940070966058768
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65685255120543,
            10.940281643035995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.6560371596649,
            10.940281643035995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65535051415709,
            10.940281643035995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.6545780379608,
            10.939986695225949
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65363390038756,
            10.939228256652475
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65741045068053,
            10.942304134398226
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64655286858824,
            10.944073803017838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64779741357115,
            10.944326611957894
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65341932366637,
            10.93299213260125
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65286142419127,
            10.9346354482865
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.6540201384857,
            10.934888265276067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65346223901061,
            10.935393898608611
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66685182641295,
            10.932865723325257
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66444856713561,
            10.935098945936058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.63578111718444,
            10.944242342335174
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64483625481871,
            10.939143985580095
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.644707508786,
            10.940155236867634
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.644707508786,
            10.939649611655085
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.644707508786,
            10.939270392179688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64479333947448,
            10.938933307794297
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64745409081725,
            10.936910793433235
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.6481836516693,
            10.937753509427077
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64882738183287,
            10.939354663216154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64522249291686,
            10.9352674903563
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65496427605895,
            10.931517354362773
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65590841363219,
            10.930801030858627
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65642339776305,
            10.930758894128044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.655693836911,
            10.930421800067977
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66221696923522,
            10.936278754866
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.6637619216278,
            10.94108221418383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66715223382262,
            10.93981815348844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66162793195213,
            10.946687431873944
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66214291608298,
            10.947277313861198
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66128460919822,
            10.948372805863825
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66823689496482,
            10.950479509864852
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66913811719382,
            10.949973902271356
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.6677648261782,
            10.950521643792007
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66699234998191,
            10.95119578581121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66836564099754,
            10.950100304250661
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66471783673728,
            10.954355806065733
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66403119122947,
            10.955114205907723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66900937116111,
            10.954187272503663
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66939560925925,
            10.953976605416118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66986767804588,
            10.953555270791284
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.67025391614402,
            10.953260336197108
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65664975202048,
            10.948204268896362
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65617768323386,
            10.947698657418618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65579144513572,
            10.947614388755076
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65664975202048,
            10.947614388755076
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65729348218406,
            10.948077866107848
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65682141339744,
            10.947530120067578
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65596310651267,
            10.947319448243908
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64866749799216,
            10.947740791741394
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64862458264793,
            10.947445851356086
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65137116467918,
            10.94988963425517
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65141408002341,
            10.953091802011368
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64647881543601,
            10.946645297401338
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64652173078025,
            10.946476759450967
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.62742440259422,
            10.954103005686623
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.67835732458232,
            10.958874438857482
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.67775650976299,
            10.958705907868508
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.6773273563206,
            10.958579509563775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.66046162603496,
            10.967005944999684
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64544909258332,
            10.926210244126333
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.6524872090384,
            10.925241082815964
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.65321676989045,
            10.926505205636145
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64132921953644,
            10.922038614244826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -74.64636501610427,
            10.923310428993117
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "classvalue": 2
      },
      "color": "#0b32d6",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b32d6 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-74.65792543481139, 10.94011310146619]),
            {
              "classvalue": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65736753533629, 10.939986695225949]),
            {
              "classvalue": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65839750359801, 10.940070966058768]),
            {
              "classvalue": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65685255120543, 10.940281643035995]),
            {
              "classvalue": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.6560371596649, 10.940281643035995]),
            {
              "classvalue": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65535051415709, 10.940281643035995]),
            {
              "classvalue": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.6545780379608, 10.939986695225949]),
            {
              "classvalue": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65363390038756, 10.939228256652475]),
            {
              "classvalue": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65741045068053, 10.942304134398226]),
            {
              "classvalue": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64655286858824, 10.944073803017838]),
            {
              "classvalue": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64779741357115, 10.944326611957894]),
            {
              "classvalue": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65341932366637, 10.93299213260125]),
            {
              "classvalue": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65286142419127, 10.9346354482865]),
            {
              "classvalue": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.6540201384857, 10.934888265276067]),
            {
              "classvalue": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65346223901061, 10.935393898608611]),
            {
              "classvalue": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66685182641295, 10.932865723325257]),
            {
              "classvalue": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66444856713561, 10.935098945936058]),
            {
              "classvalue": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.63578111718444, 10.944242342335174]),
            {
              "classvalue": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64483625481871, 10.939143985580095]),
            {
              "classvalue": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.644707508786, 10.940155236867634]),
            {
              "classvalue": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.644707508786, 10.939649611655085]),
            {
              "classvalue": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.644707508786, 10.939270392179688]),
            {
              "classvalue": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64479333947448, 10.938933307794297]),
            {
              "classvalue": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64745409081725, 10.936910793433235]),
            {
              "classvalue": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.6481836516693, 10.937753509427077]),
            {
              "classvalue": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64882738183287, 10.939354663216154]),
            {
              "classvalue": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64522249291686, 10.9352674903563]),
            {
              "classvalue": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65496427605895, 10.931517354362773]),
            {
              "classvalue": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65590841363219, 10.930801030858627]),
            {
              "classvalue": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65642339776305, 10.930758894128044]),
            {
              "classvalue": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.655693836911, 10.930421800067977]),
            {
              "classvalue": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66221696923522, 10.936278754866]),
            {
              "classvalue": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.6637619216278, 10.94108221418383]),
            {
              "classvalue": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66715223382262, 10.93981815348844]),
            {
              "classvalue": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66162793195213, 10.946687431873944]),
            {
              "classvalue": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66214291608298, 10.947277313861198]),
            {
              "classvalue": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66128460919822, 10.948372805863825]),
            {
              "classvalue": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66823689496482, 10.950479509864852]),
            {
              "classvalue": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66913811719382, 10.949973902271356]),
            {
              "classvalue": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.6677648261782, 10.950521643792007]),
            {
              "classvalue": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66699234998191, 10.95119578581121]),
            {
              "classvalue": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66836564099754, 10.950100304250661]),
            {
              "classvalue": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66471783673728, 10.954355806065733]),
            {
              "classvalue": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66403119122947, 10.955114205907723]),
            {
              "classvalue": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66900937116111, 10.954187272503663]),
            {
              "classvalue": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66939560925925, 10.953976605416118]),
            {
              "classvalue": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66986767804588, 10.953555270791284]),
            {
              "classvalue": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.67025391614402, 10.953260336197108]),
            {
              "classvalue": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65664975202048, 10.948204268896362]),
            {
              "classvalue": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65617768323386, 10.947698657418618]),
            {
              "classvalue": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65579144513572, 10.947614388755076]),
            {
              "classvalue": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65664975202048, 10.947614388755076]),
            {
              "classvalue": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65729348218406, 10.948077866107848]),
            {
              "classvalue": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65682141339744, 10.947530120067578]),
            {
              "classvalue": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65596310651267, 10.947319448243908]),
            {
              "classvalue": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64866749799216, 10.947740791741394]),
            {
              "classvalue": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64862458264793, 10.947445851356086]),
            {
              "classvalue": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65137116467918, 10.94988963425517]),
            {
              "classvalue": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65141408002341, 10.953091802011368]),
            {
              "classvalue": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64647881543601, 10.946645297401338]),
            {
              "classvalue": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64652173078025, 10.946476759450967]),
            {
              "classvalue": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.62742440259422, 10.954103005686623]),
            {
              "classvalue": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.67835732458232, 10.958874438857482]),
            {
              "classvalue": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.67775650976299, 10.958705907868508]),
            {
              "classvalue": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.6773273563206, 10.958579509563775]),
            {
              "classvalue": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.66046162603496, 10.967005944999684]),
            {
              "classvalue": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64544909258332, 10.926210244126333]),
            {
              "classvalue": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.6524872090384, 10.925241082815964]),
            {
              "classvalue": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.65321676989045, 10.926505205636145]),
            {
              "classvalue": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64132921953644, 10.922038614244826]),
            {
              "classvalue": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.64636501610427, 10.923310428993117]),
            {
              "classvalue": 2,
              "system:index": "70"
            })]),
    Manglar_ref = ui.import && ui.import("Manglar_ref", "table", {
      "id": "projects/gee-alpha-testing-327717/assets/Manglar_Ref_2020"
    }) || ee.FeatureCollection("projects/gee-alpha-testing-327717/assets/Manglar_Ref_2020");
//
var help_text = ui.Label({
  value: 'Siga los pasos del panel izquiero y espere unos segundos o minutos (dependiendo de la velocidad de su internet) por los resultados  de la clasificación supervisada por fecha y las zonas de cambio. En paneles a su izquiera encontrara el resultado de la exactitud temática para el manglar y descargue los vectores resultantes en formato kmz.',
  style: {position: 'bottom-center', width: '250px', whiteSpace: 'pre-wrap'},
});
var help_cross = ui.Button({
  label: 'X',
  style: {position: 'top-right'},
});
var help_panel = ui.Panel({
  layout: ui.Panel.Layout.absolute(),
  widgets: [help_cross, help_text],
  style: {width: '400px', height: '200px'},
});
Map.add(help_panel);
help_cross.onClick( function() {help_panel.style().set('shown', false); });
function show_help_panel(text) {
  help_panel.style().set('shown', true);
  help_text.setValue(text);
}
var Manglar1 = cober_2020i.filter(ee.Filter.eq('classvalue', 1));
var Mangalr1_1 = ptoscampo.filter(ee.Filter.eq('classvalue', 1)) 
var Laguna1 = cober_2020i.filter(ee.Filter.eq('classvalue', 2));
var Vegetacion_secundaria1 = cober_2020i.filter(ee.Filter.eq('classvalue', 3));
var Manglar2 = cober_2021i.filter(ee.Filter.eq('classvalue', 1));
var Manglar2_2 = ptoscampo.filter(ee.Filter.eq('classvalue', 1));
var Laguna2 = cober_2021i.filter(ee.Filter.eq('classvalue', 2));
var Vegetacion_secundaria2 = cober_2021i.filter(ee.Filter.eq('classvalue', 3));
//Map.addLayer(Manglar,{},'Manglar')
//Map.addLayer(Laguna,{},'Manglar')
//Map.addLayer(Vegetacion_secundaria,{},'Manglar')
///////
/**
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */
function maskS2clouds(image) {
  var qa = image.select('QA60')
  //** Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  //** Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0))
  //** Return the masked and scaled data, without the QA bands.
  return image.updateMask(mask).divide(10000)
      .select("B.*")
      .copyProperties(image, ["system:time_start"])
}
var zonaestudio = {
  'Ciénaga Grande de Santa Marta': cinagagsm,
};
var muestras = {
'Datos INVEMAR Manglar 2020':(Manglar1).merge(Mangalr1_1).merge(Laguna1).merge(Laguna1_1).merge(Vegetacion_secundaria1),
'Datos INVEMAR Manglar 2021':(Manglar2).merge(Mangalr1_1).merge(Laguna2).merge(Laguna1_1).merge(Vegetacion_secundaria2),
  };
print(muestras,'muestras');
/* Create UI Panels */
var panel = ui.Panel({style: {width:'300px',position: 'top-right',
      border: '0.5px solid #000000CC',
      backgroundColor: 'F7F8E0' }});
ui.root.insert(0,panel);
//intro
var intro = ui.Label(' Cambios en la cobertura del manglar de La Cienaga Grande de Santa Marta V.5 ', 
{fontWeight: 'bold', fontSize: '18px', textAlign: 'center', backgroundColor: '#A3CCFF00'  }
);
var intro2 = ui.Label('Instituto de Investigaciones Marinas y Costeras "José Benito Vives de Andréis"-INVEMAR.', 
{fontWeight: 'bold', fontSize: '14px', textAlign: 'center', backgroundColor: '#A3CCFF00'  }
);
var subtitle = ui.Label('Clasificación supervisada de imágenes SENTINEL 2, SENTINEL 1 y SRTM 30 m con Algoritmo -Random Fores-',
  {fontWeight: 'bold',margin: '12px 0 0 12px',fontSize: '12px',color: 'black',backgroundColor: '#A3CCFF00' });
panel.add(intro).add(intro2).add(subtitle);
//var selectArea = ui.Select({
//  items: Object.keys(zonaestudio),
//});
//select area
var selectArea = ui.Select({
items: Object.keys(zonaestudio),
  onChange: function(key) {
    Map.clear();
    //Map.drawingTools().setShown(false);
    //var visOption = app.VIS_OPTIONS[app.vis.select.getValue()];
    Map.addLayer(zonaestudio[key],{},'Area de Estudio '+key);
    Map.centerObject(zonaestudio[key]);
  }
});
selectArea.setPlaceholder('Seleccione un área...');
panel.add(ui.Label('1. Area de Estudio',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(selectArea); 
panel.add(ui.Label('2. Seleccione el periodo de evaluación',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' }));
var subtitle2 = ui.Label('Fecha inicial' ,
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray', backgroundColor: '#A3CCFF00'});
var fecha_1= ui.Textbox('YYYY-MM-DD', '2020-01-01');
var subtitle3 = ui.Label('Fecha final',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray',backgroundColor: '#A3CCFF00'});
var fecha_2= ui.Textbox('YYYY-MM-DD', '2021-01-01');
/////////////////////////////////////////////////////////////
panel.add(subtitle2).add(fecha_1).add(subtitle3).add(fecha_2);
//////////////////////////////////////////////////////////////////
//select samples
//var selectsample = ui.Select({
//  items: Object.keys(muestras),
//});
var SelectMuetras1 = ui.Select({
items: Object.keys(muestras),
  onChange: function(key) {
    Map.addLayer(muestras[key],{},'Muestras Fecha 1 '+key);
  }
});
SelectMuetras1.setPlaceholder('Muestras Fecha Incial...');
panel.add(ui.Label('3. Zonas de entrenamiento Fecha Inicial',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(SelectMuetras1); 
var SelectMuetras2 = ui.Select({
  items: Object.keys(muestras),
onChange: function(key) {
    Map.addLayer(muestras[key],{palette:'red'},'Muestras Fecha 2 '+key);
  }
});
SelectMuetras2.setPlaceholder('Muestras Fecha Final...');
panel.add(ui.Label('4. Zonas de entrenamiento Fecha Final',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(SelectMuetras2 ); 
/////////////////////////////////////////////////////////////////////////////////
// Create Land Use Map
var mapbutton = ui.Label('5.Genere los mapas de cobertura de manglar',
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(mapbutton);
panel.add(ui.Button("Coberturas de manglar",landMap));
var additional_directions = ui.Label
  (' Elaborado por: Msc. Hernando Hernández', 
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '12px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(additional_directions);
var outputPanel = ui.Panel();
print(outputPanel);
function landMap(){
Map.clear();
Map.addLayer(Manglar_ref,{},'Cartografia referencia 2020',false);
//Map.centerObject(studyArea,9);
var selectedStudy_name = selectArea.getValue();
var studyArea = zonaestudio[selectedStudy_name];
Map.centerObject(studyArea,12);
//Map.centerObject(studyArea,18);
///////////////////////////////////PROCESAMIENTO DE IMAGENES SENTINEL PARA MAPEO DE CORALES///////////
///////////////////////////////////////IMAGENES SENTINEL 2//////////////////////////////////////////////
////////////////////////////////////////AREA DE PILOTO SERRANA PARQUE SEFLOWER ////////////////////////
///
/////////////////////////////////////////////////////////////
var date_1 = fecha_1.getValue();
var date_2 = ee.Date(date_1).advance(+365,'day');
var date_3 = fecha_2.getValue();
var date_4 = ee.Date(date_3).advance(+350,'day');
//////////////////////////////////SELECCION DE INDICES////////////////////////////////////////////
var addIndicesS2 = function(img) {
  //** ---NDVI---
  //var ndvi = img.normalizedDifference(['B8','B4']).rename('NDVI');
  //** ---NDMI---
  var ndmi = img.normalizedDifference(['B12','B3']).rename('NDMI');
  //** ---MNDWI---
  var mndwi = img.normalizedDifference(['B3','B11']).rename('MNDWI');
  //** ---NIR/SWIR---
  //var sr = img.select('B8').divide(img.select('B4')).rename('SR');
  //** Band Ratio SWIR/NIR
  var ratio54 = img.select('B11').divide(img.select('B8')).rename('R11/8');
  //** ---Band Ratio RED/SWIR---
  var ratio35 = img.select('B4').divide(img.select('B11')).rename('R4/11');
  //** ---GCVI---
  var gcvi = img.expression('(NIR/GREEN)-1',{
    'NIR':img.select('B8'),
    'GREEN':img.select('B3')
  }).rename('GCVI');
  //** ---EVI---
  var evi = img.expression(
    '(2.5 * ((NIR - RED) / (NIR + 6 * RED- 7.5 * BLUE + 1)))', {
      'NIR': img.select('B8'),
      'RED': img.select('B3'),
      'BLUE': img.select('B2')
  }).rename ('EVI');
  return img
    //.addBands(ndvi)
    .addBands(ndmi)
    .addBands(mndwi)
    //.addBands(sr)
    .addBands(ratio54)
    .addBands(ratio35)
    .addBands(gcvi)
    .addBands (evi);
};
///////////////////////////////IMAGENENES DE RADAR FECHA 1
var collectionVV = ee.ImageCollection('COPERNICUS/S1_GRD')
                      .filter(ee.Filter.eq('instrumentMode', 'IW'))
                      .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
                      .filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'))
                      .filterMetadata('resolution_meters', 'equals' , 10)
                      .filterBounds(studyArea)
                      .select('VV');
                    // print(collectionVV, 'Collection VV'); 
//** Load Sentinel-1 C-band SAR Ground Range collection (log scale, VH, descending)
var collectionVH = ee.ImageCollection('COPERNICUS/S1_GRD')
                      .filter(ee.Filter.eq('instrumentMode', 'IW'))
                      .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
                      .filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'))
                      .filterMetadata('resolution_meters', 'equals' , 10)
                      .filterBounds(studyArea)
                      .select('VH');
                      //print(collectionVH, 'Collection VH');
//** Filter by date SAR Sentinel 1
var SARVV = collectionVV.filterDate(date_1,date_2).mosaic();
var SARVH = collectionVH.filterDate(date_1,date_2).mosaic();
//** Apply filter to reduce speckle
var SMOOTHING_RADIUS = 50;
var SARVV_filtered = SARVV.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters');
var SARVH_filtered = SARVH.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters');
//** clip SAR Image 
var SARVV_filtered_clip = SARVV_filtered.clip (studyArea);
var SARVH_filtered_clip = SARVH_filtered.clip (studyArea);
//** Threshold for SAR Sentinel 1
var sarVV_masking = SARVV_filtered_clip.select ('VV').gt (-10.3);
var sarVH_masking = SARVV_filtered_clip.select ('VV').gt (-10.3); 
//** Import dataset NASA SRTM Digital Elevation 30m
var srtm = ee.Image("USGS/SRTMGL1_003")
              .clip (studyArea);
//** Defining threshold for SRTM less 30m
var Elevmask = srtm.lt (85);
/////////////////////////CLOUD MASK NEW METHOD FOR CLOUD PROBABILITY
var s2Clouds = ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY');
var s2Clouds1 = s2Clouds.filter(ee.Filter.and(
    ee.Filter.bounds(studyArea), ee.Filter.date(date_1, date_2)));
var s2Clouds2 = s2Clouds.filter(ee.Filter.and(
    ee.Filter.bounds(studyArea), ee.Filter.date(date_3, date_4)));
var MAX_CLOUD_PROBABILITY = 65;
function maskClouds(img) {
  var clouds = ee.Image(img.get('cloud_mask')).select('probability');
  var isNotCloud = clouds.lt(MAX_CLOUD_PROBABILITY);
  return img.updateMask(isNotCloud);
}
function maskEdges(s2_img) {
  return s2_img.updateMask(
      s2_img.select('B8A').mask().updateMask(s2_img.select('B9').mask()));
}
//** Load Sentinel-2 reflectance data.
var collec1 = ee.ImageCollection('COPERNICUS/S2_SR')
       .filterBounds(studyArea)
      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5))
       .filterDate(date_1, date_2)
       .map(maskEdges)
       .select(['B2', 'B3', 'B4', 'B8', 'B11', 'B12'])
       .map(addIndicesS2)
       .map(function(image) {
          return image
       .clip(studyArea) });
// Join S2 SR with cloud probability dataset to add cloud mask.fecha 1
var collect1WCloudMask = ee.Join.saveFirst('cloud_mask').apply({
  primary: collec1,
  secondary: s2Clouds,
  condition:
      ee.Filter.equals({leftField: 'system:index', rightField: 'system:index'})
});
var collection_ini =
    ee.ImageCollection(collect1WCloudMask).map(maskClouds).median();
var rgbVis = {min: 0, max: 3000, bands: ['B8', 'B11', 'B12']};
print(collection_ini,'colleccion inicial');
Map.addLayer(
    collection_ini, rgbVis, 'Mosaico 2020 ' + MAX_CLOUD_PROBABILITY + '%',
    true);
var collec2 = ee.ImageCollection('COPERNICUS/S2_SR')
      .filterBounds(studyArea)
      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5))
      .filterDate(date_3,date_4)
      .map(maskEdges)
      .select(['B2', 'B3', 'B4', 'B8', 'B11', 'B12'])
      .map(addIndicesS2)
      .map(function(image) {
          return image
      .clip(studyArea) }); 
// Join S2 SR with cloud probability dataset to add cloud mask.
var collect2WCloudMask = ee.Join.saveFirst('cloud_mask').apply({
  primary: collec2,
  secondary: s2Clouds2,
  condition:
      ee.Filter.equals({leftField: 'system:index', rightField: 'system:index'})
});
var collection_fin =
    ee.ImageCollection(collect2WCloudMask ).map(maskClouds).median();
print(collection_fin,'colleccion Final');
Map.addLayer(
    collection_fin, rgbVis, 'Mosaico 2021 ' + MAX_CLOUD_PROBABILITY + '%',
    true);
Export.image.toDrive({
  image: collection_ini,
  description: 'Imagen Fecha Inicial',
  fileNamePrefix: 'Inicial',
  scale: 10,
  region: studyArea
});
Export.image.toDrive({
  image: collection_fin,
  description: 'Imagen Fecha Final',
  fileNamePrefix: 'Final',
  scale: 10,
  region: studyArea
});
var clipped_ini = collection_ini.clip(studyArea)
var clipped_fin = collection_fin.clip(studyArea)
//** Define Threshold using NDVI,
var NDWImask_ini = clipped_ini.select ('MNDWI').gt (-0.5);
var NDWImask_fin = clipped_fin.select ('MNDWI').gt (-0.5);
//** Define Threshold for SAR Images
var sarVV_mask = SARVV_filtered_clip//.updateMask(sarVV_masking)
var sarVH_mask = SARVH_filtered_clip//.updateMask(sarVH_masking)
Map.addLayer(sarVV_mask, {min:-15,max:0}, 'SAR VV_2018', false);
Map.addLayer(sarVH_mask, {min:-25,max:0}, 'SAR VH_2018', false);
// ** Masking the image using bands masks
var composite_mask_ini = clipped_ini
                              .updateMask (NDWImask_ini)
                              //.updateMask (sarVV_masking)
var composite_mask_fin = clipped_fin
                              .updateMask (NDWImask_fin)
                              //.updateMask (sarVV_masking)                                  
    //** NDVI
//var ndvi = clipped_img2018.normalizedDifference(['B8','B4']).rename('NDVI_2017');
//Map.addLayer (ndvi,{min:0,max:1},'NDVI_2017',false)
    //** MNDWI
//var mndwi = clipped_img2018.normalizedDifference(['B3','B11']).rename('MNDWI_2017');
//Map.addLayer (mndwi,{min:-1,max:1},'MNDWI_2017',false)
/////////////////////////////////////////////////////STACK////////////////////////////////////////
//** Stacking Optic and SAR
var img_stack_ini = ee.Image.cat (collection_ini, sarVV_mask, sarVH_mask)
var img_stack_fin = ee.Image.cat (collection_fin, sarVV_mask, sarVH_mask)
/////////////////////////////////////CLASIFICACION RANDOM///////////////////
var palette1 = [
  "5D8C29", // Coral  // amarillo
  "4DA7F2", // Arena  // verde claro
  "66F141", //  Macroalgas // verde esmeralda
 ]; 
//zonas de entrenamiento
//var newfc = Acropora.merge(Macroalgas).merge(Montastrea).merge(Algasescombros).merge(Coralmixtos).merge(Arena).merge(Costrascoral)
var selectsample_name = SelectMuetras1.getValue();
var newfc = muestras[selectsample_name];
var selectsample_name2 = SelectMuetras2.getValue();
var newfc2 = muestras[selectsample_name2];
print (newfc,"newfc");
var classes = [
  {'classvalue':1,'description':'Manglar'},
  {'classvalue':2,'description':'Laguna'},
  {'classvalue':3,'description':'Vegetacion Secundaria'},
];
////////////////////////////////////////////////////////// Fusionar los valores de cada pixel con los valores asignados de la geometria (agua, urbano o vegetacion)
///////////////////////////////////////////////////////// Crear una colección de puntos. Habrá los mismos puntos que pixeles dentro de las tres regiones
//////////////////////////////////////////////////////// Cada punto contendrá 7 propiedades (6 valores de reflectancia -uno para cada banda en ese pixel- y el valor de la propiedad asignada -agua, water o vegetacion-)
var aleatorios = newfc.randomColumn('random',2);
var aleatorios2 = newfc2.randomColumn('random',2);
print('aleatorios',aleatorios);
var samples20 = img_stack_ini.sampleRegions({
  collection: aleatorios, 
  properties:["classvalue","random"],
  scale:20,
  });
var samples21 = img_stack_fin.sampleRegions({
  collection: aleatorios2, 
  properties:["classvalue","random"],
  scale:20,
  });
var training20 = samples20.filterMetadata('random', 'less_than',0.7);
var testing20 = samples20.filterMetadata('random', 'not_less_than',0.3);
var training21 = samples21.filterMetadata('random', 'less_than',0.7);
var testing21 = samples21.filterMetadata('random', 'not_less_than',0.3);
print(training21.limit(10), "training feature collection");
////////////////////////////////////////////// SUPERVISED CLASSIFICATION /////////////////////////////////
var trained_random21 =ee.Classifier.smileRandomForest(50).train(training21, "classvalue");
var trained_random20 =ee.Classifier.smileRandomForest(50).train(training20, "classvalue");
//////////////////////////////////////////////////////////////////////////////////////////////
var classified_random_ini = img_stack_ini.classify(trained_random20);
var classified_random_fin = img_stack_fin.classify(trained_random21);
////////////////////////////////FILTRO KERNEL////////////////
//var resolucion = classified_random20.projection().nominalScale();
  //FILTRO DE MODA
 // var classified_img_kernel20 = classified_random20.reduceNeighborhood({
 //   reducer: ee.Reducer.mode(),
 //   kernel: ee.Kernel.square(2),
 // });
 // var classified_img_kernel21 = classified_random21.reduceNeighborhood({
 //   reducer: ee.Reducer.mode(),
 //   kernel: ee.Kernel.square(2),
 // });
////////////////////////////////////////////////////////////////////////////////////////////////////////////
Map.addLayer(classified_random_ini .clip(studyArea),{min:1, max:3, palette:["5D8C29","4DA7F2","66F141"]}, "Random fecha inicial",false );
Map.addLayer(classified_random_fin.clip(studyArea),{min:1, max:3, palette:["5D8C29","4DA7F2","66F141"]}, "Random fecha final",false );
Export.image.toDrive({
  image: classified_random_ini,
  description: 'Random_inicial',
  fileNamePrefix: 'Random_inicial',
  scale: 10,
  region: studyArea
});
Export.image.toDrive({
  image: classified_random_fin,
  description: 'Random_final',
  fileNamePrefix: 'Random_final',
  scale: 10,
  region: studyArea
});
//////////////////////////VECTORIZACION 
//RASTER TO VECTOR
var classes20 = ee.List([1])
  .map(function(n) {
    var classImage = classified_random_ini.eq(ee.Number(n));
    var vectors = classImage.updateMask(classImage)
      .reduceToVectors({
        reducer: ee.Reducer.countEvery(), 
       geometry: studyArea, 
        scale: 20,
        maxPixels: 1e10})
      .geometry();
    return ee.Feature(vectors, {"class": n,"size":vectors.area(1)});
  });
var result20 = ee.FeatureCollection(classes20);
Map.addLayer(result20,{},'Vectores de manglar fecha inicial');
var classes21 = ee.List([1])
  .map(function(n) {
    var classImage = classified_random_fin.eq(ee.Number(n));
    var vectors = classImage.updateMask(classImage)
      .reduceToVectors({
        reducer: ee.Reducer.countEvery(), 
       geometry: studyArea, 
        scale: 20,
        maxPixels: 1e10})
      .geometry();
    return ee.Feature(vectors, {"class": n,"size":vectors.area(1)});
  });
var result21 = ee.FeatureCollection(classes21);
Map.addLayer(result21,{},'vectores de manglar fecha final');
/////////////////////////////////DESCARGA //////////////////////////////////////////////////
 //DESCARGA FECHA INICIAL
      var URLDownload20 = result20.getDownloadURL({
        format: 'KMZ',     
        filename: 'Manglar_fecha_ini'});
      //print ('Link_to_download', URLDownload); 
      var descarga20 = ui.Panel({
          style: {
            position: 'top-right',
            padding: '8px 15px'
          }
        });
        var descargaurl20 = ui.Label({
          value: 'Decargar vectores (urlDownload) Fecha inicial:', // Descarga
        style:{
            margin: '4px 0 -1px 4px',
            fontSize: '13px',
            color: '3792cb'}  
      }); // TamaÃ±o de fuente
      descarga20.add(descargaurl20.setUrl(URLDownload20));
      Map.add(descarga20);
//DESCARGA FECHA FINAL
      var URLDownload21 = result21.getDownloadURL({
        format: 'KMZ',     
        filename: 'Manglar_fecha_fin'});
      //print ('Link_to_download', URLDownload); 
      var descarga21 = ui.Panel({
          style: {
            position: 'top-right',
            padding: '8px 15px'
          }
        });
        var descargaurl21 = ui.Label({
          value: 'Decargar vectores (urlDownload) Fecha final:', // Descarga
        style:{
            margin: '4px 0 -1px 4px',
            fontSize: '13px',
            color: '3792cb'}  
      }); // TamaÃ±o de fuente
      descarga21.add(descargaurl21.setUrl(URLDownload21));
      Map.add(descarga21);
/////////////////////////////////////////////////////////GAIN AND DIFERENCE/////////////////////////////////////////////////////////
var classified_random21r = classified_random_fin.clip(result21);
var classified_random20r = classified_random_ini.clip(result20);
Map.addLayer(classified_random21r,{palette:["green"]}, "Manglar fecha final",false);
Map.addLayer(classified_random20r,{palette:["green"]}, "Manglar inicial inicial",false);
Export.image.toDrive({
  image: classified_random_fin,
  description: 'Manglar Fecha Inicial',
  fileNamePrefix: 'Inicial',
  scale: 10,
  region: studyArea
});
Export.image.toDrive({
  image: classified_random_ini,
  description: 'Manglar Fecha Inicial',
  fileNamePrefix: 'Inicial',
  scale: 10,
  region: studyArea
});
var Perdida = classified_random_ini.updateMask(classified_random_fin.mask().not());
var Ganancia = classified_random_fin.updateMask(classified_random_ini.mask().not()); 
var Mantiene = classified_random_ini.updateMask(classified_random_fin.mask());
Map.addLayer(Mantiene,{palette:["green"]}, "Mantiene"); 
Map.addLayer(Ganancia, {palette:["Blue"]}, "Ganancia");
Map.addLayer(Perdida,{palette:["Red"]}, "Perdida");
//var Diff20_21 = classified_random21r.accum(classified_random20r)
//var difcol = ee.ImageCollection([classified_random21r, classified_random21r]);
//print('difcol: ', difcol);
//var Diff20_21 = difcol.sum();
//print(Diff20_21);
//Map.addLayer(Diff20_21,{min:1, max:2, palette:['orange',"green"]}, "Diferencia 20-21",false);
var confusion_matrix_random21 = trained_random21.confusionMatrix();
print(confusion_matrix_random21, "confusion matrix_Random");
var confusion_matrix_random20 = trained_random20.confusionMatrix();
print(confusion_matrix_random20, "confusion matrix_Random");
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var kappa_matrix_random21 = confusion_matrix_random21.kappa();
print(kappa_matrix_random21, "indice kappa Random");
////////////////////////////////////////////////////////AREA COBERTURA/////////////////////////////////////////////////////////////////////
var get_area = function(image, type, subarea){
  var subset_class = image.eq(type);
  var areaImage = subset_class.multiply(ee.Image.pixelArea()).divide(10000);
  var stats = areaImage.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: studyArea,
    maxPixels: 5e10,
    scale: 10
  });
  return(stats.get('classification'));
};
///////////////////////////////////////////////////////////////////////AREA FECHA 1/////////////////////////////////////////
var area_manglar20 = get_area(classified_random_ini, 1, studyArea);
var area_Laguna20 = get_area(classified_random_ini, 2, studyArea);
var area_vegetacion_secundaria20 = get_area(classified_random_ini, 3, studyArea);
print('area_manglar: ', area_manglar20, ' Hectareas');
print('area_Laguna: ', area_Laguna20, ' Hectareas');
print('area_vegetacion: ', area_vegetacion_secundaria20, ' Hectareas');
  var area_manglarx20 = ee.Number(area_manglar20).format('%.2f').getInfo();
  var area_Lagunax20 = ee.Number(area_Laguna20).format('%.2f').getInfo();
  var area_vegetacion_secundariax20 = ee.Number(area_vegetacion_secundaria20).format('%.2f').getInfo();
  //Panel de resultados
  var arearesultados20 = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var valTitle = ui.Label({
    value: 'Area de las coberturas Fecha 1',
    style: {
      fontWeight: 'bold',
      fontSize: '12px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  var mangalrarea20 = ui.Label({
        value: 'Area del Manglar (He): '+ area_manglarx20,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  var Lagunaarea20 = ui.Label({
        value: 'Area del Cuerpo Lagunar (He): '+ area_Lagunax20,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
 var vegetacionsecundariaarea20 = ui.Label({
        value: 'Area vegetación No Manglar (He): '+ area_vegetacion_secundariax20,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  arearesultados20.add(valTitle);
  arearesultados20.add(mangalrarea20);
  arearesultados20.add(Lagunaarea20);
  arearesultados20.add(vegetacionsecundariaarea20);  
Map.add(arearesultados20);
///////////////////////////////////////////////////////////////////////AREA FECHA 2/////////////////////////////////////////
var area_manglar21 = get_area(classified_random_fin, 1, studyArea);
var area_Laguna21 = get_area(classified_random_fin, 2, studyArea);
var area_vegetacion_secundaria21 = get_area(classified_random_fin, 3, studyArea);
print('area_manglar: ', area_manglar21, ' Hectareas');
print('area_Laguna: ', area_Laguna21, ' Hectareas');
print('area_vegetacion: ', area_vegetacion_secundaria21, ' Hectareas');
  var area_manglarx21 = ee.Number(area_manglar21).format('%.2f').getInfo();
  var area_Lagunax21 = ee.Number(area_Laguna21).format('%.2f').getInfo();
  var area_vegetacion_secundariax21 = ee.Number(area_vegetacion_secundaria21).format('%.2f').getInfo();
  //Panel de resultados
  var arearesultados21 = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var valTitle = ui.Label({
    value: 'Area de las coberturas Fecha 2',
    style: {
      fontWeight: 'bold',
      fontSize: '12px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  var mangalrarea21 = ui.Label({
        value: 'Area del Manglar (He): '+ area_manglarx21,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  var Lagunaarea21 = ui.Label({
        value: 'Area del Cuerpo Lagunar (He): '+ area_Lagunax21,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
 var vegetacionsecundariaarea21 = ui.Label({
        value: 'Area vegetación No Manglar (He): '+ area_vegetacion_secundariax21,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  arearesultados21.add(valTitle);
  arearesultados21.add(mangalrarea21);
  arearesultados21.add(Lagunaarea21);
  arearesultados21.add(vegetacionsecundariaarea21);  
Map.add(arearesultados21);
///////////////////////////////////////AREA DE CAMBIO/////////////////////
//var area_ganancia = get_area(Diff20_21, -1, studyArea);
//var area_mantiene = get_area(Diff20_21, 0, studyArea);
//var area_perdida = get_area(Diff20_21, 1, studyArea);
//Panel de resultados
  var arearesultadosc = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var valTitle = ui.Label({
    value: 'Areas de cambio',
    style: {
      fontWeight: 'bold',
      fontSize: '12px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
 var manglarganado = ui.Label({
        value: 'Manglar gandado (He): '+ area_ganancia,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  var manglarmantenido = ui.Label({
        value: 'Manglar que se mantiene (He): '+ area_mantiene,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
 var manglarperdido = ui.Label({
        value: 'Manglar perdido (He): '+ area_perdida,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
 //arearesultadosc.add(valTitle);
 // arearesultadosc.add(manglarganado);
 // arearesultadosc.add(manglarmantenido);
 // arearesultadosc.add(manglarperdido);  
//Map.add(arearesultadosc);
///////////////////////////////////////////EVALUACION EXACTITUD FECHA 2////////////////////////////////////
var validation_random21 = testing21.classify(classified_random_fin);                                     
  var errorMatrix_random21 = validation_random21.errorMatrix('landcover', 'classification');           
  //print('Error Matrix:', errorMatrix_random);
  //print('Overall Accuracy:', errorMatrix_random.accuracy());
  //print('Kappa Coefficient: ', errorMatrix_random.kappa());
  var ikappa21 = ee.Number(confusion_matrix_random21.kappa()).format('%.2f').getInfo();
  var egeneral21 = ee.Number(confusion_matrix_random21.accuracy()).format('%.2f').getInfo();
  //print(ikappa, egeneral);
  //Panel de resultados
  var validation = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var valTitle = ui.Label({
    value: 'Evaluación de exactitud Fecha 2',
    style: {
      fontWeight: 'bold',
      fontSize: '15px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  var kappa21 = ui.Label({
        value: 'Indice Kappa: '+ ikappa21,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  var exgen21 = ui.Label({
        value: 'Exactitud General: '+ egeneral21,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  validation.add(valTitle);
  validation.add(exgen21);
  validation.add(kappa21);
  Map.add(validation);
///////////////////////////////////////////EVALUACION EXACTITUD FECHA 1////////////////////////////////////
var validation_random20 = testing20.classify(classified_random_ini);                                     
  var errorMatrix_random20 = validation_random20.errorMatrix('landcover', 'classification');           
  //print('Error Matrix:', errorMatrix_random);
  //print('Overall Accuracy:', errorMatrix_random.accuracy());
  //print('Kappa Coefficient: ', errorMatrix_random.kappa());
  var ikappa20 = ee.Number(confusion_matrix_random20.kappa()).format('%.2f').getInfo();
  var egeneral20 = ee.Number(confusion_matrix_random20.accuracy()).format('%.2f').getInfo();
  //print(ikappa, egeneral);
  //Panel de resultados
  var validation = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var valTitle = ui.Label({
    value: 'Evaluación de exactitud Fecha 1',
    style: {
      fontWeight: 'bold',
      fontSize: '18px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  var kappa20 = ui.Label({
        value: 'Indice Kappa: '+ ikappa20,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  var exgen20 = ui.Label({
        value: 'Exactitud General: '+ egeneral20,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  validation.add(valTitle);
  validation.add(exgen20);
  validation.add(kappa20);
  Map.add(validation);
/////////////////////////////////// CREAR LEYENDA////////////////////////////////
// Create the panel for the legend items.
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create and add the legend title.
var legendTitle = ui.Label({
  value: 'Clasificación de coberturas',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
  }
});
legend.add(legendTitle);
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0 0 4px 0'
    }
  });
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'}
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
// Get the list of palette colors and class names from the image.
classified_random_ini.toDictionary().evaluate(function(result) {
  var names1 = ['Manglar', 'Laguna',  'Vegetación secundaria'];
  for (var i = 0; i < names1.length; i++) {
    legend.add(makeRow(palette1[i], names1[i]));
  }
});
// Add the legend to the map.
Map.add(legend);
//////////////////////////////////////////
// help box
//REINICIAR//
var reiniciar = ui.Button({
  label: "Reiniciar",
  onClick: function() {
    Map.clear();
   Map.drawingTools().clear();
  }
});
panel.add(reiniciar);
}
//Map.addLayer(cober_2020);