var guajira = ui.import && ui.import("guajira", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -85.153853609375,
                16.663370224550583
              ],
              [
                -85.153853609375,
                0.31401064969657094
              ],
              [
                -70.190474703125,
                0.31401064969657094
              ],
              [
                -70.190474703125,
                16.663370224550583
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#efeb5e",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #efeb5e */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-85.153853609375, 16.663370224550583],
          [-85.153853609375, 0.31401064969657094],
          [-70.190474703125, 0.31401064969657094],
          [-70.190474703125, 16.663370224550583]]], null, false),
    colombia = ui.import && ui.import("colombia", "table", {
      "id": "users/nandopando/depto"
    }) || ee.FeatureCollection("users/nandopando/depto");
var datasetw = ee.ImageCollection('MODIS/006/MOD44W')
                  .filter(ee.Filter.date('2015-01-01', '2015-05-01'))
  .select('water_mask')
  .map(function(img) {
      return img.clip(guajira);
    });
var waterMaskVis = {
  min: 0.0,
  max: 1.0,
  palette: ['bcba99', '2d0491'],
};
Map.addLayer(datasetw, waterMaskVis, 'Mascara Tierra')
//Hernando Hernandez Hamon 2019. 
var visParams = {
  palette : ['D50000','FD2D04', 'FD6C11', 'FDB223', 'FCFC35', '85FF36', '00FF52',
               '24F1FF', '2A74FC', '2B00FB', '3D00C9', '62009C', '8A0073'],
};
var visParams2 = {
  palette : ['D50000','FD2D04', 'FD6C11', 'FDB223', 'FCFC35', '85FF36', '00FF52',
               '24F1FF', '2A74FC', '2B00FB', '3D00C9', '62009C', '8A0073'],
};
// averaging MODIS Aqua data for a given time period.
var modisOceanColor = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI');
var chla =
    modisOceanColor.select(['chlor_a']).filterDate('2016-01-01', '2018-10-01')
var sst =
    modisOceanColor.select(['sst']).filterDate('2016-01-01', '2018-10-01')
var composite = chla.mean().visualize(visParams).clip(guajira);
var composite2 = sst.mean().visualize(visParams).clip(guajira);
var compositeLayer = ui.Map.Layer(composite).setName('Chl-a Composite')
var compositeLayer2 = ui.Map.Layer(composite).setName('sst')
/* Create UI Panels */
var panel = ui.Panel({style: {width:'300px',position: 'top-right',
      border: '0.5px solid #000000CC',
      backgroundColor: '#A3CCFFA0' }});
ui.root.insert(0,panel);
var table = ui.Chart(
    [
      ['<img src=https://conflictos-ambientales.net/oca_bd/img/IGAC.jpg width=80px>']
    ],
    'Table', {allowHtml: true});
var titlePanel = ui.Panel([table], 'flow', {width: '300x', padding: '8px'});
panel.add(titlePanel);
//intro
var intro = ui.Label('Productividad del Mar Caribe y Pacífico Colombiano. Imágenes color del Oceano MODIS-Aqua/L3SMI. Concentración de "Clorofila a" y Temperatura superfial del Mar',
{fontWeight: 'bold', fontSize: '18px', textAlign: 'center', backgroundColor: '#A3CCFF00'  }
);
var subtitle = ui.Label('Promedios Mensuales de Clorofila "a" mg/m3 y Temperatura ºC',
  {margin: '0 0 0 12px',fontSize: '12px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(intro).add(subtitle);
Map.setCenter(-77.549180,  8.057068, 6.8); 
var YEARS = {'2013': 2013, '2014': 2014, '2015': 2015, '2016': 2016, '2017': 2017, '2018': 2018,'2019': 2019, '2020': 2020};
var MES = {'1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6,'7': 7, '8': 8, '9': 9, '10': 10, '11': 11, '12': 12};
//Seleccione el año
var selectYear = ui.Select({
  items: Object.keys(YEARS),
});
selectYear.setPlaceholder('Año...');
panel.add(ui.Label('1. Seleccione un año...',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '18px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(selectYear); 
var selectMes = ui.Select({
  items: Object.keys(MES),
});
selectMes.setPlaceholder('Mes...',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '18px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(ui.Label('2. Seleccione el mes....',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '18px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(selectMes); 
//landMap
//Cree el mapa
var mapbutton = ui.Label('3. Despliegue los productos Mensuales',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '18px',color: 'gray',backgroundColor: '#A3CCFF00' });
//var mapbutton2 = ui.Label('4.Cree el Mapa Mensual de Temperaturas ºC')
panel.add(mapbutton);
//panel.add(mapbutton1);
panel.add(ui.Button(" Genere los mapas",landMap));
//panel.add(ui.Button("Genere Temperatura",landMap))
var additional_directions = ui.Label
  ('Dar un Click sobre la imágen para obtener la serie de tiempo - abajo la coordenada geográfica.', 
  {margin: '0 0 0 12px',fontSize: '12px',color: 'gray'});
panel.add(additional_directions);
//
var visParams = {
  palette : ['D50000','FD2D04', 'FD6C11', 'FDB223', 'FCFC35', '85FF36', '00FF52',
               '24F1FF', '2A74FC', '2B00FB', '3D00C9', '62009C', '8A0073'],
};
function landMap(){
Map.clear()
/////////////////////////////////////////////MASCARA DE TIERRA///////////////
var datasetw = ee.ImageCollection('MODIS/006/MOD44W')
                  .filter(ee.Filter.date('2015-01-01', '2015-05-01'))
  .select('water_mask')
  .map(function(img) {
      return img.clip(guajira);
    });
var waterMaskVis = {
  min: 0.0,
  max: 1.0,
  palette: ['bcba99', '2d0491'],
};
Map.addLayer(datasetw, waterMaskVis, 'Mascara Tierra')
/////////////////////////////////////////////////////////////////////////
 var yearNum = (ee.Number.parse(selectYear.getValue()));
 var MesNum = (ee.Number.parse(selectMes.getValue()));
 var startDate = ee.Date.fromYMD(yearNum,MesNum,1);
 var endDate = ee.Date.fromYMD(yearNum,MesNum,28);
//ee.ImageCollection(modisOceanColor)
var modisOceanColor = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI')
.filterBounds(guajira)
.filterDate(startDate,endDate)
.select('chlor_a')
.map(function(image) {
      return image.clip(guajira);
    });
print(modisOceanColor)
var mediaocenacolor = modisOceanColor.median()
var modistemperatura = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI')
.filterBounds(guajira)
.filterDate(startDate,endDate)
.select('sst')
.map(function(image) {
      return image.clip(guajira);
    });
print(modistemperatura)
var mediamodistemperatura = modistemperatura.median()
Map.addLayer(mediaocenacolor, 
     visParams, 'Año Clorofila');
var vis = {min: 0, max: 3, palette: ['D50000','FD2D04', 'FD6C11', 'FDB223', 'FCFC35', '85FF36', '00FF52',
               '24F1FF', '2A74FC', '2B00FB', '3D00C9', '62009C', '8A0073'],};
var vist = {min: 10, max: 34, palette: ['8A0073','62009C','3D00C9','2B00FB','2A74FC',
'24F1FF','00FF52','85FF36','FCFC35','FDB223','FD6C11','FD2D04','D50000'],};
Map.addLayer(mediamodistemperatura, 
     vist, 'Año Temperatura');
//Map.addLayer(colombia,{},'colombia',1)
////////////////////////////////////////////////////////////////////////
var elevationdata = ee.Image('NOAA/NGDC/ETOPO1').clip(guajira);
var elevation = elevationdata.select('bedrock');
var elevationVis = {
  min: -2500.0,
  max: 20.0,
  palette: ['011de2', 'afafaf', '3603ff', 'fff477', 'b42109'],
};
var min = -300;
var max = 100;
var step = 10;
var map_color_saturation = 0.2; // how colorful the colors are (>0 up to 1)
//=== contours
// source: https://groups.google.com/d/msg/google-earth-engine-developers/RhqK4cGI6pA/i4K95oGFAwAJ
var levels = ee.List.sequence(min, max, step);
var contours = levels.map(function(level) {
  var contour = elevation
    .resample('bicubic')
    .convolve(ee.Kernel.gaussian(5, 3))
    .subtract(ee.Image.constant(level)).zeroCrossing() // line contours
    // .gt(ee.Image.constatn(level)) // area
    .multiply(ee.Image.constant(level)).toFloat();
  return contour.mask(contour);
});
contours = ee.ImageCollection(contours).mosaic();
//=== together
var Cont = (contours.visualize({ opacity: 0.6, palette: ['000000'] }));
Map.addLayer(elevation, {min:-5000,max:0}, 'Bathymetry',false)
///////////////////////////////////////////////////////////////////
////////////////////////////////////////////////VIENTO//////////////////////////////////////////////////
// Daily mean 10m u-component of wind
var era5_u_wind_10m = ee.ImageCollection('ECMWF/ERA5/DAILY')
                          .select('u_component_of_wind_10m')
                          .filter(ee.Filter.date(startDate,endDate))
.map(function(image) {
      return image.clip(guajira);
    });
// Visualization palette for u- and v-component of 10m wind
var visWind = {
  min: -20,
  max: 30,
  palette: ['#FFFFFF', '#FFFF71', '#DEFF00', '#9EFF00', '#77B038', '#007E55', '#005F51',
    '#004B51', '#013A7B', '#023AAD']
};
var palette = ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
               '74A901', '66A000', '529400', '3E8601', '207401', '056201',
               '004C00', '023B01', '012E01', '011D01', '011301'];
Map.addLayer(
    era5_u_wind_10m.filter(ee.Filter.date('2019-07-15')), visWind,
    'Daily mean 10m u-component of wind',false);
//////////////////////////////////////////////////////////////
//compositeLayer = ui.Map.Layer(mediaocenacolor).setName('Mapa Mensual').visualize(vis)
var compositeLayer = ui.Map.Layer(mediaocenacolor,vis,'Clorofila a mg/l')
var compositeLayer2 = ui.Map.Layer(mediamodistemperatura,vist,'TemperaturaºC',false)
var compositeLayer3 = ui.Map.Layer(datasetw, waterMaskVis, 'Mascara Tierra')
var compositeLayer4 = ui.Map.Layer(elevation,  {min:-5000,max:0}, 'Bathymetry',false)
var compositeLayer5 = ui.Map.Layer(era5_u_wind_10m, visWind, 'Daily mean 10m u-component of wind',false)
// * Chart setup
// Generates a new time series chart of chl-a for the given coordinates.
var generateChart = function (coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2));
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  // Add a dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'ffff00'}, 'clicked location');
  // Add the dot as the second layer, so it shows up on top of the composite.
  mapPanel.layers().set(7, dot);
  // Make a chart from the time series.
  var chlaChart = ui.Chart.image.series(chla, point, ee.Reducer.mean(), 500);
  // Customize the chart.
  chlaChart.setOptions({
    title: 'Clorofila a: serie de tiempo',
    vAxis: {title: 'Concentración mg/L'},
    hAxis: {title: 'Date', format: 'MM-yy', gridlines: {count: 7}},
    series: {
      0: {
        color: 'green',
        lineWidth: 0,
        pointsVisible: true,
        pointSize: 2,
      },
    },
    legend: {position: 'right'},
  });
  // Add the chart at a fixed position, so that new charts overwrite older ones.
  panel.widgets().set(8, chlaChart);
  };
//var inspectorPanel = ui.Panel({style: {width: '30%'}});
//compositeLayer
// Create the main map and set the chl-a layer.
//var mapPanel1 = ui.Map();
//var layers = mapPanel.layers();
//layers.add(mediaocenacolor, 'Composite2')
var mapPanel = ui.Map();
var layers = mapPanel.layers();
layers.add(compositeLayer4,visParams,'con5');
layers.add(compositeLayer5,visParams,'con6');
layers.add(compositeLayer3,visParams,'con4');
layers.add(compositeLayer2,visParams,'con3');
layers.add(compositeLayer,visParams,'con2');
//layers.add(colombia,{},'Colombia',0.1);
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// Add placeholders for the chart and legend.
panel.add(ui.Label('[Chart]'));
panel.add(ui.Label('[Legend]'));
// * Chart setup
// Generates a new time series chart of chl-a for the given coordinates.
var generateChart = function (coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2));
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  // Add a dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'ffff00'}, 'clicked location');
  // Add the dot as the second layer, so it shows up on top of the composite.
  mapPanel.layers().set(9, dot);
  // Make a chart from the time series.
  var chlaChart = ui.Chart.image.series(chla, point, ee.Reducer.mean(), 500);
  // Customize the chart.
  chlaChart.setOptions({
    title: 'Chl-a: time series',
    vAxis: {title: 'chl-a level'},
    hAxis: {title: 'Date', format: 'MM-yy', gridlines: {count: 7}},
    series: {
      0: {
        color: 'green',
        lineWidth: 0,
        pointsVisible: true,
        pointSize: 2,
      },
    },
    legend: {position: 'right'},
  });
  // Add the chart at a fixed position, so that new charts overwrite older ones.
  panel.widgets().set(10, chlaChart);
};
/*
 * Legend setup
 */
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(vis.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a scale panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(vis.min, {margin: '4px 8px'}),
    ui.Label(
        (vis.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(vis.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Leyenda: Clorofia "a" media mg/L',
  style: {fontWeight: 'bold'}
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
panel.widgets().set(11, legendPanel);
//////////////////////////////////////////////
// Register a callback on the default map to be invoked when the map is clicked.
mapPanel.onClick(generateChart);
// Configure the map.
mapPanel.style().set('cursor', 'crosshair');
// Initialize with a test point.
var initialPoint = ee.Geometry.Point(-72.367355, 12.082469);
mapPanel.centerObject(guajira, 8);
// Replace the root with a SplitPanel that contains the inspector and map.
ui.root.clear();
ui.root.add(ui.SplitPanel(panel,mapPanel));
//ui.root.add(ui.SplitPanel(panel,mapPanel));
generateChart({
  lon: initialPoint.coordinates().get(0).getInfo(),
  lat: initialPoint.coordinates().get(1).getInfo()
});
}