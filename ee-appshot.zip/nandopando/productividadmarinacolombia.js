var guajira = ui.import && ui.import("guajira", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -78.21336810341525,
                14.406365105157914
              ],
              [
                -78.21336810341525,
                8.09554745620036
              ],
              [
                -70.58885638466525,
                8.09554745620036
              ],
              [
                -70.58885638466525,
                14.406365105157914
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#efeb5e",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #efeb5e */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-78.21336810341525, 14.406365105157914],
          [-78.21336810341525, 8.09554745620036],
          [-70.58885638466525, 8.09554745620036],
          [-70.58885638466525, 14.406365105157914]]], null, false),
    colombia = ui.import && ui.import("colombia", "table", {
      "id": "users/nandopando/depto"
    }) || ee.FeatureCollection("users/nandopando/depto");
//Hernando Hernandez Hamon 2019. 
var visParams = {
  palette : ['D50000','FD2D04', 'FD6C11', 'FDB223', 'FCFC35', '85FF36', '00FF52',
               '24F1FF', '2A74FC', '2B00FB', '3D00C9', '62009C', '8A0073'],
};
var visParams2 = {
  palette : ['D50000','FD2D04', 'FD6C11', 'FDB223', 'FCFC35', '85FF36', '00FF52',
               '24F1FF', '2A74FC', '2B00FB', '3D00C9', '62009C', '8A0073'],
};
// averaging MODIS Aqua data for a given time period.
var modisOceanColor = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI');
var chla =
    modisOceanColor.select(['chlor_a']).filterDate('2016-01-01', '2018-10-01')
var sst =
    modisOceanColor.select(['sst']).filterDate('2016-01-01', '2018-10-01')
var composite = chla.mean().visualize(visParams).clip(guajira);
var composite2 = sst.mean().visualize(visParams).clip(guajira);
var compositeLayer = ui.Map.Layer(composite).setName('Chl-a Composite')
var compositeLayer2 = ui.Map.Layer(composite).setName('sst')
/* Create UI Panels */
var panel = ui.Panel({style: {width:'300px'}});
ui.root.insert(0,panel);
//intro
var intro = ui.Label('Mapa mensual de procuctividad fitoplanctónica marina "Clorofila a" y Temperatura superfial ºC:  ZONAS DE SURGENCIA DEL CARIBE COLOMBIANO. PRODUCTO MODIS-Aqua/L3SMI', 
{fontWeight: 'bold', fontSize: '15px', margin: '10px 5px'}
);
var subtitle = ui.Label('Promedios Mensuales de Clorofila "a" mg/l y Temperatura ºC',
  {margin: '0 0 0 12px',fontSize: '12px',color: 'gray'});
panel.add(intro).add(subtitle);
Map.setCenter(-74.486129, 10.159041, 7.1); 
var YEARS = {'2013': 2013, '2014': 2014, '2015': 2015, '2016': 2016, '2017': 2017, '2018': 2018,'2019': 2019, '2020': 2020};
var MES = {'1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6,'7': 7, '8': 8, '9': 9, '10': 10, '11': 11, '12': 12};
//Seleccione el año
var selectYear = ui.Select({
  items: Object.keys(YEARS),
});
selectYear.setPlaceholder('Seleccione un año...');
panel.add(ui.Label('1. Seleccione un año...')).add(selectYear); 
var selectMes = ui.Select({
  items: Object.keys(MES),
});
selectMes.setPlaceholder('Seleccione el mes...');
panel.add(ui.Label('2. Seleccione el mes....')).add(selectMes); 
//landMap
//Cree el mapa
var mapbutton = ui.Label('3. Mapa mensual de clorofilas mg/lt y temperatura ºC (SST)');
//var mapbutton2 = ui.Label('4.Cree el Mapa Mensual de Temperaturas ºC')
panel.add(mapbutton);
//panel.add(mapbutton1);
panel.add(ui.Button("Genere Mapa de Clorofila y Temperatura Mensual",landMap));
//panel.add(ui.Button("Genere Temperatura",landMap))
var additional_directions = ui.Label
  ('Dar un Click sobre la imágen para obtener la serie de tiempo - abajo la coordenada geográfica.', 
  {margin: '0 0 0 12px',fontSize: '12px',color: 'gray'});
panel.add(additional_directions);
//
var visParams = {
  palette : ['D50000','FD2D04', 'FD6C11', 'FDB223', 'FCFC35', '85FF36', '00FF52',
               '24F1FF', '2A74FC', '2B00FB', '3D00C9', '62009C', '8A0073'],
};
function landMap(){
 var yearNum = (ee.Number.parse(selectYear.getValue()));
 var MesNum = (ee.Number.parse(selectMes.getValue()));
 var startDate = ee.Date.fromYMD(yearNum,MesNum,1);
 var endDate = ee.Date.fromYMD(yearNum,MesNum,28);
//ee.ImageCollection(modisOceanColor)
var modisOceanColor = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI')
.filterBounds(guajira)
.filterDate(startDate,endDate)
.select('chlor_a')
.map(function(image) {
      return image.clip(guajira);
    });
print(modisOceanColor)
var mediaocenacolor = modisOceanColor.median()
var modistemperatura = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI')
.filterBounds(guajira)
.filterDate(startDate,endDate)
.select('sst')
.map(function(image) {
      return image.clip(guajira);
    });
print(modistemperatura)
var mediamodistemperatura = modistemperatura.median()
Map.addLayer(mediaocenacolor, 
     visParams, 'Año Clorofila');
var vis = {min: 0, max: 3, palette: ['D50000','FD2D04', 'FD6C11', 'FDB223', 'FCFC35', '85FF36', '00FF52',
               '24F1FF', '2A74FC', '2B00FB', '3D00C9', '62009C', '8A0073'],};
var vist = {min: 10, max: 34, palette: ['8A0073','62009C','3D00C9','2B00FB','2A74FC',
'24F1FF','00FF52','85FF36','FCFC35','FDB223','FD6C11','FD2D04','D50000'],};
Map.addLayer(mediamodistemperatura, 
     vist, 'Año Temperatura');
Map.addLayer(colombia,{},'colombia',1)
//compositeLayer = ui.Map.Layer(mediaocenacolor).setName('Mapa Mensual').visualize(vis)
compositeLayer = ui.Map.Layer(mediaocenacolor,vis,'Clorofila a mg/l')
compositeLayer2 = ui.Map.Layer(mediamodistemperatura,vist,'TemperaturaºC')
// * Chart setup
// Generates a new time series chart of chl-a for the given coordinates.
var generateChart = function (coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2));
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  // Add a dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'ffff00'}, 'clicked location');
  // Add the dot as the second layer, so it shows up on top of the composite.
  mapPanel.layers().set(7, dot);
  // Make a chart from the time series.
  var chlaChart = ui.Chart.image.series(chla, point, ee.Reducer.mean(), 500);
  // Customize the chart.
  chlaChart.setOptions({
    title: 'Clorofila a: serie de tiempo',
    vAxis: {title: 'Concentración mg/L'},
    hAxis: {title: 'Date', format: 'MM-yy', gridlines: {count: 7}},
    series: {
      0: {
        color: 'green',
        lineWidth: 0,
        pointsVisible: true,
        pointSize: 2,
      },
    },
    legend: {position: 'right'},
  });
  // Add the chart at a fixed position, so that new charts overwrite older ones.
  panel.widgets().set(8, chlaChart);
  };
//var inspectorPanel = ui.Panel({style: {width: '30%'}});
//compositeLayer
// Create the main map and set the chl-a layer.
//var mapPanel1 = ui.Map();
//var layers = mapPanel.layers();
//layers.add(mediaocenacolor, 'Composite2')
var mapPanel = ui.Map();
var layers = mapPanel.layers();
layers.add(compositeLayer2,visParams,'con3');
layers.add(compositeLayer,visParams,'con2');
layers.add(colombia,{},'Colombia',0.1);
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// Add placeholders for the chart and legend.
panel.add(ui.Label('[Chart]'));
panel.add(ui.Label('[Legend]'));
// * Chart setup
// Generates a new time series chart of chl-a for the given coordinates.
var generateChart = function (coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2));
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  // Add a dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'ffff00'}, 'clicked location');
  // Add the dot as the second layer, so it shows up on top of the composite.
  mapPanel.layers().set(9, dot);
  // Make a chart from the time series.
  var chlaChart = ui.Chart.image.series(chla, point, ee.Reducer.mean(), 500);
  // Customize the chart.
  chlaChart.setOptions({
    title: 'Chl-a: time series',
    vAxis: {title: 'chl-a level'},
    hAxis: {title: 'Date', format: 'MM-yy', gridlines: {count: 7}},
    series: {
      0: {
        color: 'green',
        lineWidth: 0,
        pointsVisible: true,
        pointSize: 2,
      },
    },
    legend: {position: 'right'},
  });
  // Add the chart at a fixed position, so that new charts overwrite older ones.
  panel.widgets().set(10, chlaChart);
};
/*
 * Legend setup
 */
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(vis.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a scale panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(vis.min, {margin: '4px 8px'}),
    ui.Label(
        (vis.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(vis.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Leyenda: Clorofia "a" media mg/L',
  style: {fontWeight: 'bold'}
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
panel.widgets().set(11, legendPanel);
//////////////////////////////////////////////
// Register a callback on the default map to be invoked when the map is clicked.
mapPanel.onClick(generateChart);
// Configure the map.
mapPanel.style().set('cursor', 'crosshair');
// Initialize with a test point.
var initialPoint = ee.Geometry.Point(-72.367355, 12.082469);
mapPanel.centerObject(guajira, 8);
// Replace the root with a SplitPanel that contains the inspector and map.
ui.root.clear();
ui.root.add(ui.SplitPanel(panel,mapPanel));
//ui.root.add(ui.SplitPanel(panel,mapPanel));
generateChart({
  lon: initialPoint.coordinates().get(0).getInfo(),
  lat: initialPoint.coordinates().get(1).getInfo()
});
}