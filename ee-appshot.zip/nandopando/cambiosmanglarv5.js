var cinagagsm = ui.import && ui.import("cinagagsm", "table", {
      "id": "projects/ee-nandopando/assets/AlcanceGeografico_MaNglares_CGSM"
    }) || ee.FeatureCollection("projects/ee-nandopando/assets/AlcanceGeografico_MaNglares_CGSM"),
    cober_2020 = ui.import && ui.import("cober_2020", "table", {
      "id": "projects/ee-nandopando/assets/cober_2020_3g"
    }) || ee.FeatureCollection("projects/ee-nandopando/assets/cober_2020_3g"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -74.53648622761824,
                10.847443840552414
              ],
              [
                -74.53648622761824,
                10.781010405424063
              ],
              [
                -74.46026857625105,
                10.781010405424063
              ],
              [
                -74.46026857625105,
                10.847443840552414
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-74.53648622761824, 10.847443840552414],
          [-74.53648622761824, 10.781010405424063],
          [-74.46026857625105, 10.781010405424063],
          [-74.46026857625105, 10.847443840552414]]], null, false);
var help_text = ui.Label({
  value: 'Siga los pasos del panel izquiero y espere unos segundos o minutos (dependiendo de la velocidad de su internet) por los resultados  de la clasificación supervisada por fecha y las zonas de cambio. En paneles a su derecha encontrara el resultado de la exactitud temática para el manglar y descargue los vectores resultantes en formato kmz.',
  style: {position: 'bottom-center', width: '250px', whiteSpace: 'pre-wrap'},
});
var help_cross = ui.Button({
  label: 'X',
  style: {position: 'top-right'},
});
var help_panel = ui.Panel({
  layout: ui.Panel.Layout.absolute(),
  widgets: [help_cross, help_text],
  style: {width: '400px', height: '200px'},
});
Map.add(help_panel);
help_cross.onClick( function() {help_panel.style().set('shown', false); });
function show_help_panel(text) {
  help_panel.style().set('shown', true);
  help_text.setValue(text);
}
var Manglar = cober_2020.filter(ee.Filter.eq('classvalue', 1));
var Laguna = cober_2020.filter(ee.Filter.eq('classvalue', 2));
var Vegetacion_secundaria = cober_2020.filter(ee.Filter.eq('classvalue', 3));
//Map.addLayer(Manglar,{},'Manglar')
//Map.addLayer(Laguna,{},'Manglar')
//Map.addLayer(Vegetacion_secundaria,{},'Manglar')
///////
/**
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */
function maskS2clouds(image) {
  var qa = image.select('B2');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1800 << 5000;
 // var cirrusBitMask = 1500 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0);
 //     .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask)//.divide(10000);
}
var zonaestudio = {
  'Ciénaga Grande de Santa Marta': cinagagsm,
};
var muestras = {
'Muestras de entrenamiento Datos INVEMAR 2020':Manglar.merge(Laguna).merge(Vegetacion_secundaria)
};
print(muestras,'muestras')
/* Create UI Panels */
var panel = ui.Panel({style: {width:'300px',position: 'top-right',
      border: '0.5px solid #000000CC',
      backgroundColor: 'F7F8E0' }});
ui.root.insert(0,panel);
//intro
var intro = ui.Label(' Cambios en la cobertura del manglar de La Cienaga Grande de Santa Marta V.5 ', 
{fontWeight: 'bold', fontSize: '18px', textAlign: 'center', backgroundColor: '#A3CCFF00'  }
);
var intro2 = ui.Label('Instituto de Investigaciones Marinas y Costeras "José Benito Vives de Andréis"-INVEMAR.', 
{fontWeight: 'bold', fontSize: '14px', textAlign: 'center', backgroundColor: '#A3CCFF00'  }
);
var subtitle = ui.Label('Clasificación supervisada de imágenes SENTINEL 2, SENTINEL 1 y SRTM 30 m con Algoritmo -Random Fores-',
  {fontWeight: 'bold',margin: '12px 0 0 12px',fontSize: '12px',color: 'black',backgroundColor: '#A3CCFF00' });
panel.add(intro).add(intro2).add(subtitle);
var selectArea = ui.Select({
  items: Object.keys(zonaestudio),
});
selectArea.setPlaceholder('Seleccione un área...');
panel.add(ui.Label('1. Area de Estudio',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(selectArea); 
//select samples
var selectsample = ui.Select({
  items: Object.keys(muestras),
});
selectsample.setPlaceholder('Muestras...');
panel.add(ui.Label('2. Seleccione las áreas para el entrenamiento del Algoritmo',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(selectsample); 
////////////////////////////////////////////////////////////
panel.add(ui.Label('3. Seleccione el periodo de evaluación',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' }));
var subtitle2 = ui.Label('Fecha inicial' ,
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray', backgroundColor: '#A3CCFF00'});
var fecha_1= ui.Textbox('YYYY-MM-DD', '2020-12-21');
var subtitle3 = ui.Label('Fecha final',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray',backgroundColor: '#A3CCFF00'});
var fecha_2= ui.Textbox('YYYY-MM-DD', '2021-07-31');
panel.add(subtitle2).add(fecha_1).add(subtitle3).add(fecha_2)
/////////////////////////////////////////////////////////////////////////////////
// Create Land Use Map
var mapbutton = ui.Label('4.Genere los mapas de cobertura de manglar',
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(mapbutton);
panel.add(ui.Button("Coberturas de manglar",landMap));
var additional_directions = ui.Label
  (' Elaborado por: Msc. Hernando Hernández y Leonardo Hernández Noviembre de 2021', 
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '12px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(additional_directions);
var outputPanel = ui.Panel();
print(outputPanel);
function landMap(){
Map.clear()
//Map.centerObject(studyArea,9);
var selectedStudy_name = selectArea.getValue();
var studyArea = zonaestudio[selectedStudy_name];
Map.centerObject(studyArea,12)
//Map.centerObject(studyArea,18);
///////////////////////////////////PROCESAMIENTO DE IMAGENES SENTINEL PARA MAPEO DE CORALES///////////
///////////////////////////////////////IMAGENES SENTINEL 2//////////////////////////////////////////////
////////////////////////////////////////AREA DE PILOTO SERRANA PARQUE SEFLOWER ////////////////////////
///
/////////////////////////////////////////////////////////////
var date_1 = fecha_1.getValue();
var date_2 = ee.Date(date_1).advance(+5,'day')
var date_3 = fecha_2.getValue();
var date_4 = ee.Date(date_3).advance(+2,'day');
  var colleccion = ee.ImageCollection('COPERNICUS/S2_SR')
        .filterBounds(studyArea)
       .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 60))
       .filterDate(date_1, date_2)
       .map(maskS2clouds)
       .map(function(image) {
          return image
            .select(['B2', 'B3', 'B4', 'B8', 'B11', 'B12'])
            .rename(['B', 'G', 'R', 'NIR', 'SWIR1', 'SWIR2'])
            .clip(studyArea) }); 
  var colleccion2 = ee.ImageCollection('COPERNICUS/S2_SR')
      .filterBounds(studyArea)
      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 60))
      .filterDate(date_3, date_4)
      .map(maskS2clouds)
      .map(function(image) {
          return image
            .select(['B2', 'B3', 'B4', 'B8', 'B11', 'B12'])
            .rename(['B', 'G', 'R', 'NIR', 'SWIR1', 'SWIR2'])
            .clip(studyArea) }); 
  //S2.set('size', S2.size())
  //S2=S2.filter(ee.Filter.gt('size', 0));
var imS = colleccion.mean();
var imS2 = colleccion2.mean();
print(colleccion)
print(colleccion2) 
Map.addLayer(imS2,{'bands':["R","G","B"],'min':100,'max':1000},'Imágenes ópticas Sentinel fecha final');
Map.addLayer(imS,{'bands':["R","G","B"],'min':100,'max':1000},'Imágenes ópticas Sentinel fecha inicial');
//////////////////////////////DTM///////////////////////////////////////////////////////////////
var SRTM30 = ee.Image("USGS/SRTMGL1_003");
var regionBound = ee.FeatureCollection(cinagagsm);
regionBound = regionBound.toList(regionBound.size());
regionBound = ee.Feature(regionBound.get(0));
var SRTM30_Regional = SRTM30.clip(ee.Geometry(regionBound.geometry()));
var elevation = SRTM30_Regional.select('elevation');
var slope = ee.Terrain.slope(elevation);
Map.addLayer(slope, {min: 0, max: 60, gamma:2.5}, 'DTM',false);
///////////////////////////////IMAGENENES DE RADAR 
// Load Sentinel-1 C-band SAR Ground Range collection (log scale, VH, descending)
var collectionVV = ee.ImageCollection('COPERNICUS/S1_GRD')
.filterDate(date_1,date_2)
.filter(ee.Filter.eq('instrumentMode', 'IW')) 
.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH')) 
.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING')) 
.filterMetadata('resolution_meters', 'equals' , 10)
.filterBounds(studyArea)
.map (function(image) {
      return image.clip(studyArea);
    })
.select('VV')
.mosaic();
var SMOOTHING_RADIUS = 50;
var Fecha2VV_filtered = collectionVV.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters'); 
Map.addLayer(Fecha2VV_filtered, {min:-27,max:0}, 'Filtrada fecha 2',0); 
/////////////////////////////////////////////////////STACK////////////////////////////////////////
var imSstack = imS.addBands(slope).addBands(Fecha2VV_filtered)
var imS2stack = imS2.addBands(slope).addBands(Fecha2VV_filtered)
print(imSstack,'imSstack')
print(imS2stack,'imS2stack')
/////////////////////////////////////CLASIFICACION RANDOM///////////////////
var palette1 = [
  "5D8C29", // Coral  // amarillo
  "4DA7F2", // Arena  // verde claro
  "66F141", //  Macroalgas // verde esmeralda
 ]; 
//zonas de entrenamiento
//var newfc = Acropora.merge(Macroalgas).merge(Montastrea).merge(Algasescombros).merge(Coralmixtos).merge(Arena).merge(Costrascoral)
var selectsample_name = selectsample.getValue();
var newfc = muestras[selectsample_name];
print (newfc,"newfc")
var classes = [
  {'classvalue':1,'description':'Manglar'},
  {'classvalue':2,'description':'Laguna'},
  {'classvalue':3,'description':'Vegetacion Secundaria'},
];
////////////////////////////////////////////////////////// Fusionar los valores de cada pixel con los valores asignados de la geometria (agua, urbano o vegetacion)
///////////////////////////////////////////////////////// Crear una colección de puntos. Habrá los mismos puntos que pixeles dentro de las tres regiones
//////////////////////////////////////////////////////// Cada punto contendrá 7 propiedades (6 valores de reflectancia -uno para cada banda en ese pixel- y el valor de la propiedad asignada -agua, water o vegetacion-)
var aleatorios = newfc.randomColumn('random',2);
print('aleatorios',aleatorios);
var samples21 = imS2stack.sampleRegions({
  collection: aleatorios, 
  properties:["classvalue","random"],
  scale:10,
  });
var samples20 = imSstack.sampleRegions({
  collection: aleatorios, 
  properties:["classvalue","random"],
  scale:10,
  });
var training21 = samples21.filterMetadata('random', 'less_than',0.9);
var testing21 = samples21.filterMetadata('random', 'not_less_than',0.9);
var training20 = samples20.filterMetadata('random', 'less_than',0.9);
var testing20 = samples20.filterMetadata('random', 'not_less_than',0.9);
print(training21.limit(10), "training feature collection")
////////////////////////////////////////////// SUPERVISED CLASSIFICATION /////////////////////////////////
var trained_random21 =ee.Classifier.smileRandomForest(50).train(training21, "classvalue")
var trained_random20 =ee.Classifier.smileRandomForest(50).train(training20, "classvalue")
//////////////////////////////////////////////////////////////////////////////////////////////
var classified_random21 = imS2stack.classify(trained_random21)
var classified_random20 = imSstack.classify(trained_random20)
////////////////////////////////FILTRO KERNEL////////////////
var resolucion = classified_random20.projection().nominalScale();
  //FILTRO DE MODA
  var classified_img_kernel20 = classified_random20.reduceNeighborhood({
    reducer: ee.Reducer.mode(),
    kernel: ee.Kernel.square(2),
  });
  var classified_img_kernel21 = classified_random21.reduceNeighborhood({
    reducer: ee.Reducer.mode(),
    kernel: ee.Kernel.square(2),
  });
////////////////////////////////////////////////////////////////////////////////////////////////////////////
Map.addLayer(classified_img_kernel21.clip(studyArea),{min:1, max:3, palette:["5D8C29","4DA7F2","66F141"]}, "Random fecha final",false )
Map.addLayer(classified_img_kernel20 .clip(studyArea),{min:1, max:3, palette:["5D8C29","4DA7F2","66F141"]}, "Random fecha inicial",false )
//////////////////////////VECTORIZACION 
//RASTER TO VECTOR
var classes20 = ee.List([1])
  .map(function(n) {
    var classImage = classified_img_kernel20  .eq(ee.Number(n));
    var vectors = classImage.updateMask(classImage)
      .reduceToVectors({
        reducer: ee.Reducer.countEvery(), 
       geometry: studyArea, 
        scale: 10,
        maxPixels: 1e10})
      .geometry();
    return ee.Feature(vectors, {"class": n,"size":vectors.area(1)});
  });
var result20 = ee.FeatureCollection(classes20);
Map.addLayer(result20,{},'Vectores de manglar fecha inicial');
var classes21 = ee.List([1])
  .map(function(n) {
    var classImage = classified_img_kernel21  .eq(ee.Number(n));
    var vectors = classImage.updateMask(classImage)
      .reduceToVectors({
        reducer: ee.Reducer.countEvery(), 
       geometry: studyArea, 
        scale: 10,
        maxPixels: 1e10})
      .geometry();
    return ee.Feature(vectors, {"class": n,"size":vectors.area(1)});
  });
var result21 = ee.FeatureCollection(classes21);
Map.addLayer(result21,{},'vectores de manglar fecha final');
/////////////////////////////////DESCARGA //////////////////////////////////////////////////
 //DESCARGA FECHA INICIAL
      var URLDownload20 = result20.getDownloadURL({
        format: 'KMZ',     
        filename: 'Manglar_fecha_ini'});
      //print ('Link_to_download', URLDownload); 
      var descarga20 = ui.Panel({
          style: {
            position: 'top-right',
            padding: '8px 15px'
          }
        });
        var descargaurl20 = ui.Label({
          value: 'Decargar vectores (urlDownload) Fecha inicial:', // Descarga
        style:{
            margin: '4px 0 -1px 4px',
            fontSize: '13px',
            color: '3792cb'}  
      }); // TamaÃ±o de fuente
      descarga20.add(descargaurl20.setUrl(URLDownload20));
      Map.add(descarga20);
//DESCARGA FECHA FINAL
      var URLDownload21 = result21.getDownloadURL({
        format: 'KMZ',     
        filename: 'Manglar_fecha_fin'});
      //print ('Link_to_download', URLDownload); 
      var descarga21 = ui.Panel({
          style: {
            position: 'top-right',
            padding: '8px 15px'
          }
        });
        var descargaurl21 = ui.Label({
          value: 'Decargar vectores (urlDownload) Fecha final:', // Descarga
        style:{
            margin: '4px 0 -1px 4px',
            fontSize: '13px',
            color: '3792cb'}  
      }); // TamaÃ±o de fuente
      descarga21.add(descargaurl21.setUrl(URLDownload21));
      Map.add(descarga21);
/////////////////////////////////////////////////////////GAIN AND DIFERENCE/////////////////////////////////////////////////////////
var classified_random21r = classified_random21.clip(result21)
var classified_random20r = classified_random20.clip(result20)
Map.addLayer(classified_random21r,{palette:["green"]}, "Manglar fecha final",false)
Map.addLayer(classified_random20r,{palette:["green"]}, "Manglar inicial inicial",false)
//var Diff20_21 = classified_random21r.accum(classified_random20r)
var difcol = ee.ImageCollection([classified_random21r, classified_random21r]);
print('difcol: ', difcol);
var Diff20_21 = difcol.sum()
print(Diff20_21)
Map.addLayer(Diff20_21,{min:1, max:2, palette:['orange',"green"]}, "Diferencia 20-21",false)
var confusion_matrix_random21 = trained_random21.confusionMatrix()
print(confusion_matrix_random21, "confusion matrix_Random")
var confusion_matrix_random20 = trained_random20.confusionMatrix()
print(confusion_matrix_random20, "confusion matrix_Random")
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var kappa_matrix_random21 = confusion_matrix_random21.kappa()
print(kappa_matrix_random21, "indice kappa Random")
////////////////////////////////////////////////////////AREA COBERTURA/////////////////////////////////////////////////////////////////////
var get_area = function(image, type, subarea){
  var subset_class = image.eq(type);
  var areaImage = subset_class.multiply(ee.Image.pixelArea()).divide(10000);
  var stats = areaImage.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: studyArea,
    maxPixels: 5e10,
    scale: 10
  });
  return(stats.get('classification'));
};
///////////////////////////////////////////////////////////////////////AREA FECHA 1/////////////////////////////////////////
var area_manglar20 = get_area(classified_random20, 1, studyArea);
var area_Laguna20 = get_area(classified_random20, 2, studyArea);
var area_vegetacion_secundaria20 = get_area(classified_random20, 3, studyArea);
print('area_manglar: ', area_manglar20, ' Hectareas');
print('area_Laguna: ', area_Laguna20, ' Hectareas');
print('area_vegetacion: ', area_vegetacion_secundaria20, ' Hectareas');
  var area_manglarx20 = ee.Number(area_manglar20).format('%.2f').getInfo();
  var area_Lagunax20 = ee.Number(area_Laguna20).format('%.2f').getInfo();
  var area_vegetacion_secundariax20 = ee.Number(area_vegetacion_secundaria20).format('%.2f').getInfo();
  //Panel de resultados
  var arearesultados20 = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var valTitle = ui.Label({
    value: 'Area de las coberturas Fecha 1',
    style: {
      fontWeight: 'bold',
      fontSize: '12px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  var mangalrarea20 = ui.Label({
        value: 'Area del Manglar (He): '+ area_manglarx20,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  var Lagunaarea20 = ui.Label({
        value: 'Area del Cuerpo Lagunar (He): '+ area_Lagunax20,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
 var vegetacionsecundariaarea20 = ui.Label({
        value: 'Area vegetación No Manglar (He): '+ area_vegetacion_secundariax20,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  arearesultados20.add(valTitle);
  arearesultados20.add(mangalrarea20);
  arearesultados20.add(Lagunaarea20);
  arearesultados20.add(vegetacionsecundariaarea20);  
Map.add(arearesultados20);
///////////////////////////////////////////////////////////////////////AREA FECHA 2/////////////////////////////////////////
var area_manglar21 = get_area(classified_random21, 1, studyArea);
var area_Laguna21 = get_area(classified_random21, 2, studyArea);
var area_vegetacion_secundaria21 = get_area(classified_random21, 3, studyArea);
print('area_manglar: ', area_manglar21, ' Hectareas');
print('area_Laguna: ', area_Laguna21, ' Hectareas');
print('area_vegetacion: ', area_vegetacion_secundaria21, ' Hectareas');
  var area_manglarx21 = ee.Number(area_manglar21).format('%.2f').getInfo();
  var area_Lagunax21 = ee.Number(area_Laguna21).format('%.2f').getInfo();
  var area_vegetacion_secundariax21 = ee.Number(area_vegetacion_secundaria21).format('%.2f').getInfo();
  //Panel de resultados
  var arearesultados21 = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var valTitle = ui.Label({
    value: 'Area de las coberturas Fecha 2',
    style: {
      fontWeight: 'bold',
      fontSize: '12px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  var mangalrarea21 = ui.Label({
        value: 'Area del Manglar (He): '+ area_manglarx21,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  var Lagunaarea21 = ui.Label({
        value: 'Area del Cuerpo Lagunar (He): '+ area_Lagunax21,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
 var vegetacionsecundariaarea21 = ui.Label({
        value: 'Area vegetación No Manglar (He): '+ area_vegetacion_secundariax21,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  arearesultados21.add(valTitle);
  arearesultados21.add(mangalrarea21);
  arearesultados21.add(Lagunaarea21);
  arearesultados21.add(vegetacionsecundariaarea21);  
Map.add(arearesultados21);
///////////////////////////////////////AREA DE CAMBIO/////////////////////
var area_ganancia = get_area(Diff20_21, -1, studyArea);
var area_mantiene = get_area(Diff20_21, 0, studyArea);
var area_perdida = get_area(Diff20_21, 1, studyArea);
//Panel de resultados
  var arearesultadosc = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var valTitle = ui.Label({
    value: 'Areas de cambio',
    style: {
      fontWeight: 'bold',
      fontSize: '12px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
 var manglarganado = ui.Label({
        value: 'Manglar gandado (He): '+ area_ganancia,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  var manglarmantenido = ui.Label({
        value: 'Manglar que se mantiene (He): '+ area_mantiene,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
 var manglarperdido = ui.Label({
        value: 'Manglar perdido (He): '+ area_perdida,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
 //arearesultadosc.add(valTitle);
 // arearesultadosc.add(manglarganado);
 // arearesultadosc.add(manglarmantenido);
 // arearesultadosc.add(manglarperdido);  
//Map.add(arearesultadosc);
///////////////////////////////////////////EVALUACION EXACTITUD FECHA 2////////////////////////////////////
var validation_random21 = testing21.classify(classified_random21);                                     
  var errorMatrix_random21 = validation_random21.errorMatrix('landcover', 'classification');           
  //print('Error Matrix:', errorMatrix_random);
  //print('Overall Accuracy:', errorMatrix_random.accuracy());
  //print('Kappa Coefficient: ', errorMatrix_random.kappa());
  var ikappa21 = ee.Number(confusion_matrix_random21.kappa()).format('%.2f').getInfo();
  var egeneral21 = ee.Number(confusion_matrix_random21.accuracy()).format('%.2f').getInfo();
  //print(ikappa, egeneral);
  //Panel de resultados
  var validation = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var valTitle = ui.Label({
    value: 'Evaluación de exactitud Fecha 2',
    style: {
      fontWeight: 'bold',
      fontSize: '15px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  var kappa21 = ui.Label({
        value: 'Indice Kappa: '+ ikappa21,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  var exgen21 = ui.Label({
        value: 'Exactitud General: '+ egeneral21,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  validation.add(valTitle);
  validation.add(exgen21);
  validation.add(kappa21);
  Map.add(validation);
///////////////////////////////////////////EVALUACION EXACTITUD FECHA 1////////////////////////////////////
var validation_random20 = testing20.classify(classified_random21);                                     
  var errorMatrix_random20 = validation_random20.errorMatrix('landcover', 'classification');           
  //print('Error Matrix:', errorMatrix_random);
  //print('Overall Accuracy:', errorMatrix_random.accuracy());
  //print('Kappa Coefficient: ', errorMatrix_random.kappa());
  var ikappa20 = ee.Number(confusion_matrix_random20.kappa()).format('%.2f').getInfo();
  var egeneral20 = ee.Number(confusion_matrix_random20.accuracy()).format('%.2f').getInfo();
  //print(ikappa, egeneral);
  //Panel de resultados
  var validation = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var valTitle = ui.Label({
    value: 'Evaluación de exactitud Fecha 1',
    style: {
      fontWeight: 'bold',
      fontSize: '18px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  var kappa20 = ui.Label({
        value: 'Indice Kappa: '+ ikappa20,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  var exgen20 = ui.Label({
        value: 'Exactitud General: '+ egeneral20,
        style: {
          // Use padding to give the box height and width.
          padding: '3px',
          margin: '0 0 4px 0'
        }
      });
  validation.add(valTitle);
  validation.add(exgen20);
  validation.add(kappa20);
  Map.add(validation);
/////////////////////////////////// CREAR LEYENDA////////////////////////////////
// Create the panel for the legend items.
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create and add the legend title.
var legendTitle = ui.Label({
  value: 'Clasificación de coberturas',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
  }
});
legend.add(legendTitle);
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0 0 4px 0'
    }
  });
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'}
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
// Get the list of palette colors and class names from the image.
classified_random21.toDictionary().evaluate(function(result) {
  var names1 = ['Manglar', 'Laguna',  'Vegetación secundaria'];
  for (var i = 0; i < names1.length; i++) {
    legend.add(makeRow(palette1[i], names1[i]));
  }
});
// Add the legend to the map.
Map.add(legend);
//////////////////////////////////////////
// help box
//REINICIAR//
var reiniciar = ui.Button({
  label: "Reiniciar",
  onClick: function() {
    Map.clear();
   Map.drawingTools().clear();
  }
});
panel.add(reiniciar);
}