var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "LinearRing",
          "coordinates": [
            [
              -76.36833238136487,
              9.501925489289215
            ],
            [
              -76.34554597002308,
              9.55853585378198
            ],
            [
              -76.33307911240428,
              9.582403522418943
            ],
            [
              -76.32056580344756,
              9.596269088291264
            ],
            [
              -76.08794800982398,
              9.597072249754927
            ],
            [
              -76.08746591545335,
              9.5030121040008
            ],
            [
              -76.36833238136487,
              9.501925489289215
            ]
          ],
          "geodesic": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.LinearRing(
        [[-76.36833238136487, 9.501925489289215],
         [-76.34554597002308, 9.55853585378198],
         [-76.33307911240428, 9.582403522418943],
         [-76.32056580344756, 9.596269088291264],
         [-76.08794800982398, 9.597072249754927],
         [-76.08746591545335, 9.5030121040008],
         [-76.36833238136487, 9.501925489289215]]),
    AOI = ui.import && ui.import("AOI", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -76.47504572668716,
                9.699862749438422
              ],
              [
                -76.47504572668716,
                9.315206148368251
              ],
              [
                -75.89414362707778,
                9.315206148368251
              ],
              [
                -75.89414362707778,
                9.699862749438422
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-76.47504572668716, 9.699862749438422],
          [-76.47504572668716, 9.315206148368251],
          [-75.89414362707778, 9.315206148368251],
          [-75.89414362707778, 9.699862749438422]]], null, false);
var zonaestudio = {
  'Bloque de exploracion Morrosquillo': AOI,
};
var YEARS = {'2017': 2017, '2018': 2018, '2019': 2019,'2020':2020};
var DIA = {'1': 1, '2': 2, '3': 3,'4': 4, '5': 5, '6': 6,
'7': 7, '8': 8, '9': 9,'10': 10, '11': 11, '12': 12,
'13': 13, '14': 14, '15': 15,'16': 17, '18': 18, '19': 19};
var MES = {'1': 1, '2': 2, '3': 3,'4': 4, '5': 5, '6': 6,
'7': 7, '8': 8, '9': 9,'10': 10, '11': 11, '12': 12};
/* Create UI Panels */
var panel = ui.Panel({style: {width:'300px',position: 'top-right',
      border: '0.5px solid #000000CC',
      backgroundColor: 'F7F8E0' }});
ui.root.insert(0,panel);
var table = ui.Chart(
    [
      ['<img src=https://www.upb.edu.co/es/imagenes/logo-upb-kitprensa-imagen-institucional-1464096760882.png width=150px>','<img src=https://image.freepik.com/vector-gratis/escena-oceano-burbujas-agua_1639-1509.jpg width=100px>']
    ],
    'Table', {allowHtml: true});
//https://seaflowerfoundation.org/images/ARB.jpg
var titlePanel = ui.Panel([table], 'flow', {width: '300x', padding: '8px'});
panel.add(titlePanel);
//intro
var intro = ui.Label(' App Monitoreo de Sumideros de Metano', 
{fontWeight: 'bold', fontSize: '18px', textAlign: 'center', backgroundColor: '#A3CCFF00'  }
);
var intro2 = ui.Label('Bloque de exploración Golfo de Morrosquillo', 
{fontWeight: 'bold', fontSize: '14px', textAlign: 'center', backgroundColor: '#A3CCFF00'  }
);
var subtitle = ui.Label('Imágenes de Radar Sentinel 1 e imágenes Ópticas Sentinel 2',
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '12px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(intro).add(intro2).add(subtitle);
//select study area
var selectArea = ui.Select({
  items: Object.keys(zonaestudio),
});
selectArea.setPlaceholder('Seleccione un área...');
panel.add(ui.Label('1. Área de estudio',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(selectArea); 
panel.add(ui.Label('3. Seleccione la fecha de evaluación',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' }));
var subtitle2 = ui.Label('Fecha Año-Mes-Día',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' });
var fecha_1= ui.Textbox('YYYY-MM-DD', '2019-01-28');
panel.add(subtitle2).add(fecha_1)
/////////////////////////////////////////////////////////////////////////////////
// Create Land Use Map
var mapbutton = ui.Label('4.Génere imágenes Radar y Ópticas',
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '15px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(mapbutton);
panel.add(ui.Button("Imagen resultante",landMap));
var additional_directions = ui.Label
  ('Despliegue los productos en Layers ,', 
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '12px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(additional_directions);
var outputPanel = ui.Panel();
print(outputPanel);
function landMap(){
Map.clear()
var selectedStudy_name = selectArea.getValue();
var studyArea = zonaestudio[selectedStudy_name];
//Map.centerObject(studyArea,9);
Map.centerObject(studyArea,11);
var date_1 = fecha_1.getValue();
var date_2 = ee.Date(date_1).advance(+5,'day');
function create_norm_diff(image) {
    var ang = image.select(['angle']);
    var corr1 = image;//.updateMask(ang.gt(20.63993)).updateMask(ang.lt(60.53993));
    var vh = corr1.select('VH').subtract(corr1.select('angle').multiply(Math.PI/180.0).cos().log10().multiply(10.0));
    var vhcorr = vh.addBands(image.select('VV').subtract(image.select('angle').multiply(Math.PI/180.0).cos().log10().multiply(10.0)));
  return image.addBands(ee.Image(vhcorr.expression('(VH - VV) / (VH + VV)', {'VH': vhcorr.select(['VH']),'VV': vhcorr.select(['VV'])})));
  }
var S1 = ee.ImageCollection('COPERNICUS/S1_GRD')
    .filterDate(date_1,date_2)
    .filterMetadata('transmitterReceiverPolarisation', 'equals', ['VV', 'VH'])
    .filter(ee.Filter.eq('instrumentMode', 'IW'))
    .filterBounds(AOI)
    .map(create_norm_diff)
    .map(function(image) {
      return image.clip(studyArea);
    });
  //Map.addLayer(S1,{},'S1')
  var im = S1.mean()
//////////////////////GET SENT-2 LIST FOR ALL PERIOD//////////////////////////////////////
  var collection = ee.ImageCollection('COPERNICUS/S2_SR')
  var S2 = collection
    .filterDate(date_1,date_2)
    .filterMetadata('CLOUDY_PIXEL_PERCENTAGE','less_than', 95)
    .filterBounds(AOI)
    .map(function(image) {
      return image.clip(studyArea);
    });
  //S2.set('size', S2.size())
  //S2=S2.filter(ee.Filter.gt('size', 0));
  var imS2 = S2.median();
Map.addLayer(im.select('VH_1'),{min:0,max:0.5,"opacity":0.9},'Imágenes de Radar Sentinel 1');
Map.addLayer(imS2,{'bands':["B12","B8","B4"],'min':10,'max':400},'Imágenes ópticas Sentinel 2');
}