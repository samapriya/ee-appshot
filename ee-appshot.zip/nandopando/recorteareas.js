var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -74.79006922883768,
                10.463884920600153
              ],
              [
                -74.7639766995408,
                10.450380100696362
              ],
              [
                -74.68569911165018,
                10.493593454106831
              ],
              [
                -74.67745936555643,
                10.523299134665153
              ],
              [
                -74.65274012727518,
                10.559752195697715
              ],
              [
                -74.62939418000956,
                10.600250526084022
              ],
              [
                -74.61978114290018,
                10.628596171386805
              ],
              [
                -74.6211544339158,
                10.67718258047876
              ],
              [
                -74.60055506868143,
                10.73385690573139
              ],
              [
                -74.5827022854783,
                10.782426444282388
              ],
              [
                -74.56896937532206,
                10.820197333735821
              ],
              [
                -74.56896937532206,
                10.843127338971989
              ],
              [
                -74.66647303743143,
                10.866055586637431
              ],
              [
                -74.68569911165018,
                10.86470691490235
              ],
              [
                -74.70217860383768,
                10.832336966992756
              ],
              [
                -74.71041834993143,
                10.801312482813785
              ],
              [
                -74.7145382229783,
                10.775681143084185
              ],
              [
                -74.74063075227518,
                10.741952371818549
              ],
              [
                -74.74475062532206,
                10.714966641884812
              ],
              [
                -74.7639766995408,
                10.6839300793481
              ],
              [
                -74.77908290071268,
                10.647491806785801
              ],
              [
                -74.78457606477518,
                10.616448359506226
              ],
              [
                -74.79830897493143,
                10.58000202923562
              ],
              [
                -74.78869593782206,
                10.54760165497955
              ],
              [
                -74.77633631868143,
                10.516548094546463
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-74.79006922883768, 10.463884920600153],
          [-74.7639766995408, 10.450380100696362],
          [-74.68569911165018, 10.493593454106831],
          [-74.67745936555643, 10.523299134665153],
          [-74.65274012727518, 10.559752195697715],
          [-74.62939418000956, 10.600250526084022],
          [-74.61978114290018, 10.628596171386805],
          [-74.6211544339158, 10.67718258047876],
          [-74.60055506868143, 10.73385690573139],
          [-74.5827022854783, 10.782426444282388],
          [-74.56896937532206, 10.820197333735821],
          [-74.56896937532206, 10.843127338971989],
          [-74.66647303743143, 10.866055586637431],
          [-74.68569911165018, 10.86470691490235],
          [-74.70217860383768, 10.832336966992756],
          [-74.71041834993143, 10.801312482813785],
          [-74.7145382229783, 10.775681143084185],
          [-74.74063075227518, 10.741952371818549],
          [-74.74475062532206, 10.714966641884812],
          [-74.7639766995408, 10.6839300793481],
          [-74.77908290071268, 10.647491806785801],
          [-74.78457606477518, 10.616448359506226],
          [-74.79830897493143, 10.58000202923562],
          [-74.78869593782206, 10.54760165497955],
          [-74.77633631868143, 10.516548094546463]]]),
    Runap = ui.import && ui.import("Runap", "table", {
      "id": "users/nandopando/Runap_humboldt"
    }) || ee.FeatureCollection("users/nandopando/Runap_humboldt");
// "I need covering grid for an external partner and this is what I'm doing with it"
print(Runap)
Map.setCenter(-73.107486, 3.452082, 6);  
var Flamencos = Runap.filter(ee.Filter.eq('nombre', 'Los Flamencos'));
var Perija = Runap.filter(ee.Filter.eq('nombre', 'Serrania de Perija'));
var Oca = Runap.filter(ee.Filter.eq('nombre', 'Montes de  Oca'));
var Rancheria = Runap.filter(ee.Filter.eq('nombre', 'Delta del Rio Rancheria'));
var Sierra = Runap.filter(ee.Filter.eq('nombre', 'Sierra Nevada de Santa Marta'));
var Camarones = Runap.filter(ee.Filter.eq('nombre', 'Banaderos  Cuenca Alta del Rio Camarones'));
var localidades = {
  'Serrania de Perija': Perija,
  'Montes de Oca': Oca,
  'Delta del Río Rancheria': Rancheria,
  'Sierra Nevada de Santa Marta': Sierra,
   'Flamencos': Flamencos, 
   'Banaderos Cuenca Alta del Rio Camarones': Camarones, 
};
/* Crear los UI Panels */ 
var panel = ui.Panel({style: {width:'320px',position: 'top-right',
      border: '0.5px solid #000000CC',
      backgroundColor: 'E7E4CE' }});
ui.root.insert(0,panel);
var table = ui.Chart(
    [
      ['<img src=https://www.santamartacomovamos.org/images/socios/logo-03.png width=100px>']
    ],
    'Table', {allowHtml: true});
var titlePanel = ui.Panel([table], 'flow', {width: '300x', padding: '8px'});
panel.add(titlePanel);
//introducción
var intro = ui.Label('Proyecto Humboltd, Aplicativo para la selección de imágenes Sentinel 2 en las áreas de estudio',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'green',backgroundColor: '#A3CCFF00' } 
);
var subtitle = ui.Label('Imágenes Sentinel 2. NIVEL 2A',
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '12px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(intro).add(subtitle);
//select study area
var selectArea = ui.Select({
  items: Object.keys(localidades),
});
selectArea.setPlaceholder('Areas...');
panel.add(ui.Label('1. Seleccione un área',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(selectArea); 
panel.add(ui.Label('2. Seleccione de escenas por fecha',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' }));
var subtitle2 = ui.Label('Fecha inicial' ,
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray', backgroundColor: '#A3CCFF00'});
var fecha_1= ui.Textbox('YYYY-MM-DD', '2020-01-01');
var subtitle3 = ui.Label('Fecha final',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray',backgroundColor: '#A3CCFF00'});
var fecha_2= ui.Textbox('YYYY-MM-DD', '2020-01-08');
panel.add(subtitle2).add(fecha_1).add(subtitle3).add(fecha_2)
/// Create Land Use Map
var mapbutton = ui.Label('5.Génere imagenes recortadas en una grilla de 10 km',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(mapbutton);
panel.add(ui.Button("Crear mapas",landMap));
/////////////////////////////////////////////////////////////////////FUNCION PRINCIPAL///////////////////////////////
function landMap(tipo){
Map.clear();
var selectedStudy_name = selectArea.getValue();
var studyArea = localidades[selectedStudy_name];
var poi = studyArea.map (function (feature) {
  return feature.buffer (6500);
});
Map.addLayer(studyArea,{},'buffer')
Map.centerObject(studyArea,12);
////////////
var date_1 = fecha_1.getValue();
var date_2 = fecha_2.getValue();
var colleccion = ee.ImageCollection('COPERNICUS/S2_SR')
        .filterBounds(studyArea)
       .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
        .filterDate(date_1, date_2)
//        .map(mask_s2)
        .map(function(image) {
          return image
            .select(['B2', 'B3', 'B4', 'B8', 'B11', 'B12'])
            .rename(['B', 'G', 'R', 'NIR', 'SWIR1', 'SWIR2'])
            .clip(studyArea)
        });
//Map.addLayer(ndvi.clip(studyArea), {min: 0, max: 1, palette: ndvipalette}, 'NDVI',false);
var colleccionf = colleccion.mean()
Map.addLayer(colleccionf,{
  bands :["R","G","B"],
  min:500,
  max:2300,
  gamma:2.1,
},"Imagen");
// ReduceToVectors way:
//var pixels = ee.Image.random().multiply(10000000).toInt32()
//    .reduceToVectors({
//      reducer: ee.Reducer.countEvery(),
//      geometry: geometry,
//      geometryType: 'polygon' ,
//      eightConnected: false,
//      scale: 10000,
//      crs: 'EPSG:3116'
//    });
var pixels2 = ee.Image.random().multiply(10000000).toInt32()
    .reduceToVectors({
      reducer: ee.Reducer.countEvery(),
      geometry: poi,
      geometryType: 'bb' ,
      eightConnected: false,
      scale: 10000,
      crs: 'EPSG:3116'
    });
print(pixels2)
//Map.addLayer(pixels.style({color:"FF0000", fillColor:"FF000000"}), {}, 'pixels');
Map.addLayer(pixels2.style({color:"00FF00", fillColor:"FF000000"}), {}, 'pixels2');
//Map.addLayer(ee.FeatureCollection(geometry).style({color:"00FFFF", fillColor:"FF000000"}), {}, 'geometry');
print(colleccion)
var count = pixels2.size();
var pixelsc = pixels2.toList(count)
print('tolist',pixelsc)
///
for (var i = 0; i<= 7; i++){
  //Carga la imagen de la coleccion
  var recortegrilla = (ee.Feature(pixelsc.get(i)));
  Map.addLayer(recortegrilla);
var recortadaimage =colleccionf.clip(recortegrilla);
  // Crea una nueva capa con la nueva imagen
 Map.addLayer(recortadaimage,{
  bands :["R","G","B"],
  min:500,
  max:2300,
  gamma:2.1,
},"Imagen recortada"+i,false);
// Export through URL
//var URLDownload = recortadaimage.getDownloadURL({
//'scale': 10,
//"region":recortadaimage.geometry(),
// maxPixels: 33491829976
//});
//print('Link download',URLDownload);
//var descarga = ui.Panel({
//    style: {
//      position: 'top-right',
//      padding: '8px 15px'
//    }
//  });
//  var descargaurl = ui.Label({
//    value: 'Decargar grilla (urlDownload):', // Descarga
//  style:{
//      margin: '4px 0 -1px 4px',
//      fontSize: '13px',
//      color: '3792cb'}  
//}); // TamaÃ±o de fuente
//descarga.add(descargaurl.setUrl(URLDownload));
//Map.add(descarga);  
Export.image.toDrive({
  image: recortadaimage,
  description: 'Camarones'+i,
  fileNamePrefix: 'Camarones'+i,
  scale: 10,
  region: recortegrilla,
  maxPixels: 33491829976
});
}
}