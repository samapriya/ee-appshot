var Sierra = ui.import && ui.import("Sierra", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -73.80417612963036,
                10.905009954604475
              ],
              [
                -73.80417612963036,
                10.722908061250834
              ],
              [
                -73.49655894213036,
                10.722908061250834
              ],
              [
                -73.49655894213036,
                10.905009954604475
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-73.80417612963036, 10.905009954604475],
          [-73.80417612963036, 10.722908061250834],
          [-73.49655894213036, 10.722908061250834],
          [-73.49655894213036, 10.905009954604475]]], null, false),
    area = ui.import && ui.import("area", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -87.30814797476482,
                14.367549862906635
              ],
              [
                -87.30814797476482,
                -57.458594870614554
              ],
              [
                -31.05814797476483,
                -57.458594870614554
              ],
              [
                -31.05814797476483,
                14.367549862906635
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-87.30814797476482, 14.367549862906635],
          [-87.30814797476482, -57.458594870614554],
          [-31.05814797476483, -57.458594870614554],
          [-31.05814797476483, 14.367549862906635]]], null, false),
    Ruiz = ui.import && ui.import("Ruiz", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -75.37827137182634,
                4.9351933100181915
              ],
              [
                -75.37827137182634,
                4.843859731152572
              ],
              [
                -75.26840809057634,
                4.843859731152572
              ],
              [
                -75.26840809057634,
                4.9351933100181915
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ffc82d",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-75.37827137182634, 4.9351933100181915],
          [-75.37827137182634, 4.843859731152572],
          [-75.26840809057634, 4.843859731152572],
          [-75.26840809057634, 4.9351933100181915]]], null, false),
    Los_Nevados_Merida_Venezuela = ui.import && ui.import("Los_Nevados_Merida_Venezuela", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -71.1349249113505,
                8.596701929726484
              ],
              [
                -71.1349249113505,
                8.477870458106352
              ],
              [
                -70.95193388351846,
                8.477870458106352
              ],
              [
                -70.95193388351846,
                8.596701929726484
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#00ffff",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-71.1349249113505, 8.596701929726484],
          [-71.1349249113505, 8.477870458106352],
          [-70.95193388351846, 8.477870458106352],
          [-70.95193388351846, 8.596701929726484]]], null, false),
    Chimborazo = ui.import && ui.import("Chimborazo", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -78.967133328077,
                -1.3102071905313946
              ],
              [
                -78.967133328077,
                -1.5676178432217325
              ],
              [
                -78.65608291303793,
                -1.5676178432217325
              ],
              [
                -78.65608291303793,
                -1.3102071905313946
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-78.967133328077, -1.3102071905313946],
          [-78.967133328077, -1.5676178432217325],
          [-78.65608291303793, -1.5676178432217325],
          [-78.65608291303793, -1.3102071905313946]]], null, false),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #98ff00 */ee.Geometry.MultiPoint();
var palette3 = ['FFFFFF', '00F5FF', '00ECFF', '00E4FF', '00D9FF', '00CDFF',
               '00C5FF', '00C5FF', '00BBFF', '00AFFF', '00A1FF', '0086FF',
               '#FF0000', '#FF0000', '#FF0000', '#FF0000', '#FF0000'];
///
var Glaciares = {
  'Sierra Nevada de Santa Marta-Colombia': Sierra,
};
//DEM
var srtm = ee.Image("USGS/SRTMGL1_003");
var dem = ee.Algorithms.Terrain(srtm);
var elevation = dem.select("elevation");
var slope = dem.select("slope");
//Color palette
var visParams = {
  min: 4000,
  max: 6700,
  palette: [
    '030d81', '0519ff', '05e8ff', '11ff01', 'fbff01', 'ff9901', 'ff0000',
    'ad0000'
  ],
};
var slope_masked = ee.Image(elevation) //Mask slope range from 0 to 90 meters
  .updateMask(elevation.lt(6700).and(elevation.gt(4500))).clip(area)
//Map.addLayer(slope_masked, visParams, 'Slope',true);
/////////////////////////////////////////////////////////////////////////////////////////////
/*possible years for study, you can add future years once the imagery exists and is hosted in Google Earth Engine*/
var YEARS = {'2016': 2016, '2017': 2017, '2018': 2018, '2019': 2019,'2020': 2020 };
/* Create UI Panels */
var panel = ui.Panel({style: {width:'250px'}});
ui.root.insert(0,panel);
var table = ui.Chart(
    [
      ['<img src=https://ecomapp.co/wp-content/uploads/2020/07/cropped-ecomap-solutions-386x128.png width=200px>']
    ],
    'Table', {allowHtml: true});
var titlePanel = ui.Panel([table], 'flow', {width: '300x', padding: '8px'});
panel.add(titlePanel)
//intro
var intro = ui.Label('App para monitoreo de Glaciares- EcomApp.co Vers. 1.0', 
{fontWeight: 'bold', fontSize: '15px', margin: '10px 5px'}
);
var subtitle = ui.Label('Producto derivado del Catálogo Sentinel 2 TOA, Índices NDSI, Bandas Visible y SWIR1',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
panel.add(intro).add(subtitle);
//select study area
var selectArea = ui.Select({
  items: Object.keys(Glaciares),
});
selectArea.setPlaceholder('Seleccione un Glaciar...');
panel.add(ui.Label('1. Seleccione un Glaciar')).add(selectArea); 
panel.add(ui.Label('2. Seleccione El periodo de evaluación'));
var subtitle2 = ui.Label('Fecha inicial',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var fecha_1= ui.Textbox('YYYY-MM-DD', '2017-01-01');
var subtitle3 = ui.Label('Fecha final',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var fecha_2= ui.Textbox('YYYY-MM-DD', '2020-01-01');
panel.add(subtitle2).add(fecha_1).add(subtitle3).add(fecha_2)
///////////////////////////////////////////////////
panel.add(ui.Label('2. Seleccione alturas mínimas y máximas: Ejemplo picos nevados entre 4500 y 7000 m'));
var subtitle5 = ui.Label('Altura Mínima (m)',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var maxima = ui.Textbox('4500','4500');
var subtitle6 = ui.Label('Altura Máxima (m)',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var minima= ui.Textbox('7000','7000');
panel.add(subtitle5).add(maxima).add(subtitle6).add(minima)
/// Create Land Use Map
var mapbutton = ui.Label('3.Compare el deshielo entreí la fecha inicial y final');
panel.add(mapbutton);
panel.add(ui.Button("Cree el mapa inicial vs final",landMap));
var additional_directions = ui.Label
  ('Capa de hielo de color azul', 
  {margin: '0 0 0 12px',fontSize: '12px',color: 'gray'});
panel.add(additional_directions);
var outputPanel = ui.Panel();
print(outputPanel);
////////////////////////////////////////////////////////////////////////////////////////////////
function mask_s2(image) {
  var QABand = image.select('QA60')
  var B1Band = image.select('B1')
  var mask = QABand.bitwiseAnd(ee.Number(2).pow(10).int())
    .or(QABand.bitwiseAnd(ee.Number(2).pow(11).int()))
    .or(B1Band.gt(1500));
  var masked = image.updateMask(mask.eq(0));
  return masked;
}
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
function landMap(){
var selectedStudy_name = selectArea.getValue();
var studyArea = Glaciares[selectedStudy_name];
Map.centerObject(studyArea,12);
///////////////////////////////////////////////////////DTM//////////////////////////////////
var maximav = maxima.getValue();
var minimav = minima.getValue();
var maximus = ee.Number.parse(maximav);
var minimus = ee.Number.parse(minimav);
var srtm = ee.Image("USGS/SRTMGL1_003");
var dem = ee.Algorithms.Terrain(srtm);
var elevation = dem.select("elevation");
var slope = dem.select("slope");
//Color palette
var visParams = {
  min: 2500,
  max: 6000,
  palette: [
    '030d81', '0519ff', '05e8ff', '11ff01', 'fbff01', 'ff9901', 'ff0000',
    'ad0000'
  ],
};
var slope_masked = ee.Image(elevation) //Mask slope range from 0 to 90 meters
  .updateMask(elevation.lt(minimus).and(elevation.gt(maximus))).clip(area)
Map.addLayer(slope_masked, visParams, 'Slope',true);
//////////////////////////////////////////////////////////////MASCARA/////////////////////////
var vectors = slope_masked.updateMask(slope_masked)
      .reduceToVectors({
        reducer: ee.Reducer.countEvery(), 
        geometry: studyArea, 
        scale: 30,
        maxPixels: 1e15
      });
//Map.addLayer(vectors,{},'Mascara de estudio',false);
//var yearNum = (ee.Number.parse(selectYear.getValue()));
//var date_1 = ee.Date.fromYMD(yearNum,1,1);
//var date_2 = ee.Date.fromYMD(yearNum,1,31);
//////////////////////////////////////////////////////////////
var date_1 = fecha_1.getValue();
var date_2 = ee.Date(date_1).advance(+30,'day');
var date_3 = fecha_2.getValue();
var date_4 = ee.Date(date_3).advance(+30,'day');
//var date_2 = fecha_1.getValue();
var collectionyear1 = ee.ImageCollection('COPERNICUS/S2')
 .filterDate(date_1, date_2)
 .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
 //.map(mask_s2)
 .map(function(image) {
      return image
 .select(['B2', 'B3', 'B4','B7', 'B8A', 'B11', 'B12'])
 .rename(['B', 'G', 'R','R2', 'NIR', 'SWIR1', 'SWIR2'])
 .clip(Sierra);
    });
var collectionyear2 = ee.ImageCollection('COPERNICUS/S2')
 .filterDate(date_3, date_4)
 .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
 //.map(mask_s2)
 .map(function(image) {
      return image
 .select(['B2', 'B3', 'B4','B7', 'B8A', 'B11', 'B12'])
 .rename(['B', 'G', 'R','R2', 'NIR', 'SWIR1', 'SWIR2'])
 .clip(Sierra);
    });
var procimage1 = collectionyear1 
      .map(function(image) {
        var ndsi = image.normalizedDifference(['SWIR1', 'G']);
        var ndvi = image.normalizedDifference(['NIR', 'R']);
        return image.addBands([ndsi.rename(['NDSI']), ndvi.rename(['NDVI'])]);
      });
var procimage2 = collectionyear2 
      .map(function(image) {
        var ndsi = image.normalizedDifference(['SWIR1', 'G']);
        var ndvi = image.normalizedDifference(['NIR', 'R']);
        return image.addBands([ndsi.rename(['NDSI']), ndvi.rename(['NDVI'])]);
      });
var imagequality1 = procimage1.qualityMosaic('NDSI');
var imagequality2 = procimage2.qualityMosaic('NDSI');
Map.addLayer(imagequality1.clip(vectors),{
  bands :['SWIR1','G','B'],
  min:400,
  max:3000,
  gamma:2.7,
  scale:10
},"Fecha 1",false);
Map.addLayer(imagequality2.clip(vectors),{
  bands :['SWIR1','G','B'],
  min:400,
  max:3000,
  gamma:2.7,
  scale:10
},"Fecha2",false);
/////////////////////////////////////////////////////////////////////////////////////////////
var centroid = studyArea.centroid(1);
var geometries = centroid.geometries();
print('geometries',geometries);
var lat = geometries.get(0);
print('lat',lat);
var center = {lon: -73.65, lat: 10.81, zoom: 13};
// Create two maps.
var leftMap = ui.Map(center);
var rightMap = ui.Map(center);
// Remove UI controls from both maps, but leave zoom control on the left map.
leftMap.setControlVisibility(false);
rightMap.setControlVisibility(false);
leftMap.setControlVisibility({zoomControl: true});
// Link them together.
//var linker = new ui.Map.Linker([leftMap, rightMap]);
var linker = new ui.Map.Linker([leftMap,rightMap]);
// Create a split panel with the two maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe: true
});
/////////////////////////////////////////////////////////////////////////////////
leftMap.addLayer(imagequality1.clip(vectors),{
  bands :['SWIR1','G','B'],
  min:400,
  max:3000,
  gamma:2.7,
  scale:10
},"Fecha 1")
//rightMap.addLayer(ndsi2018,  {min: 0, max: 1, palette: palette3}, 'NDSI HIELO 2018')
rightMap.addLayer(imagequality2.clip(vectors),{
  bands :['SWIR1','G','B'],
  min:400,
  max:3000,
  gamma:2.7,
  scale:10
},"Fecha2")
ui.root.clear(panel);
ui.root.add(splitPanel);
ui.root.add(panel)
}