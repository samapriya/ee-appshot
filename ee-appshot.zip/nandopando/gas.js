///
// The GHSL global population density dataset for 2015.
var ghslPop = ee.Image('JRC/GHSL/P2016/POP_GPW_GLOBE_V1/2015');
// Country boundary data with associated precomputed population totals.
// These are USDOS LSIB boundaries simplified somewhat for visualization.
var countries = ee.FeatureCollection(
    'projects/google/examples/population-explorer/LSIB_SIMPLE-with-GHSL_POP');
/*
 * Visualization and styling
 */
// Constants used to visualize the data on the map.
var POPULATION_STYLE = {
  min: 0,
  max: 1,
  palette: ['lightyellow', 'steelblue', 'darkblue']
};
var NO2_STYLE= {
  min: 0,
  max: 0.0003,
   palette: ["white","yellow", "red"]
};
var POPULATION_VIS_MAX_VALUE = 1200;
var POPULATION_VIS_NONLINEARITY = 4;
// Constants used to visualize the data on the map.
var COUNTRIES_STYLE = {color: '26458d', fillColor: '00000000'};
var HIGHLIGHT_STYLE = {color: '8856a7', fillColor: '8856a7C0'};
// Apply a non-linear stretch to the population data for visualization.
function colorStretch(image) {
  return image.divide(POPULATION_VIS_MAX_VALUE)
      .pow(1 / POPULATION_VIS_NONLINEARITY);
}
function undoColorStretch(val) {
  return Math.pow(val, POPULATION_VIS_NONLINEARITY) * POPULATION_VIS_MAX_VALUE;
}
/* Create UI Panels */
var panel = ui.Panel({style: {width:'250px'}});
ui.root.insert(0,panel);
var table = ui.Chart(
    [
      ['<img src=https://ecomapp.co/wp-content/uploads/2020/07/cropped-ecomap-solutions-386x128.png width=200px>']
    ],
    'Table', {allowHtml: true});
var titlePanel = ui.Panel([table], 'flow', {width: '300x', padding: '8px'});
panel.add(titlePanel)
//intr
var intro = ui.Label('Contaminación atmosférica a escala global. Promedio de imágenes satelitales diarias de Sentinel 5 desde Febrero de 2018. EcomApp Vers. 1.2 ', 
{fontWeight: 'bold', fontSize: '16px', margin: '10px 5px'}
);
var subtitle = ui.Label('MAPAS DE DENSIDAD (mol/m^2) DE DIÓXIDO DE NITROGENO (NO2), MONÓXIDO DE CARBONO (CO), OZONO (O3), DIÓXIDO DE AZUFRE (SO2) y FORMALDEHIDO (CH2O)',
  {margin: '0 0 0 12px',fontSize: '12px',color: 'gray'});
panel.add(intro).add(subtitle);
panel.add(ui.Label('1. Seleccione el periodo de evaluación'));
var subtitle2 = ui.Label('Fecha inicial',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var fecha_1= ui.Textbox('YYYY-MM-DD', '2018-09-01');
var subtitle3 = ui.Label('Fecha final',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var fecha_2= ui.Textbox('YYYY-MM-DD', '2019-01-01');
panel.add(subtitle2).add(fecha_1).add(subtitle3).add(fecha_2)
/// Create Land Use Map
var mapbutton = ui.Label('2. Genere los mapas de calidad del aire: NO2,CO, O3,SO2 Y CH2O');
panel.add(mapbutton);
panel.add(ui.Button("Cree los mapas",landMap));
var additional_directions = ui.Label
  ('DESARROLLO EN GOOGLE EARTH ENGINE DE LIBRE USO PARA CIENCIA CIUDADANA', 
  {margin: '0 0 0 12px',fontSize: '12px',color: 'gray'});
panel.add(additional_directions);
var outputPanel = ui.Panel();
print(outputPanel);
panel.add(ui.Label('3. Despliegue los mapas en layers'));
var subtitle3 = ui.Label('Layers se encuentra en la esquina superior derecha del mapa',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
panel.add(subtitle3)
//////////////////////////////////////////////////////////
var help_text = ui.Label({
  value: 'Esta aplicación permite realizar un seguimiento a la densidad de gases de efecto invernadero en la atmósfera, su efecto en la capa de ozono y compara los resultados sobre un mapa de población mundial - Administre la visualiazación de los mapas en "Layers"',
  style: {position: 'bottom-center', width: '200px', whiteSpace: 'pre-wrap',fontSize: '10px'},
});
var help_cross = ui.Button({
  label: 'X',
  style: {position: 'top-right'},
});
var help_panel = ui.Panel({
  layout: ui.Panel.Layout.absolute(),
  widgets: [help_cross, help_text],
  style: {position: 'bottom-center',width: '200px', height: '200px'},
});
Map.add(help_panel);
help_cross.onClick( function() {help_panel.style().set('shown', false); });
function show_help_panel(text) {
  help_panel.style().set('shown', true);
  help_text.setValue(text);
}
/////////////////////////////////////////////////////////////////
function landMap(){
Map.clear()
// Add layers to the map: global population density and countries and NO2 levels
Map.addLayer(colorStretch(ghslPop.unmask(0).updateMask(1)), POPULATION_STYLE,'Densidad de Población',false);
Map.addLayer(countries.style(COUNTRIES_STYLE),{},'Límite de Paises',false);
var start = fecha_1.getValue();
var end = fecha_2.getValue();
var collectionHCHO = ee.ImageCollection('COPERNICUS/S5P/NRTI/L3_HCHO')
  .select('tropospheric_HCHO_column_number_density')
  .filterDate(start,end);
var HCHO_min = 0.0;
var HCHO_max = 0.0003;
var HCHO_viz = {
  min: HCHO_min,
  max: HCHO_max,
  opacity: 0.5,
  palette: ["black", "blue", "purple", "cyan", "green", "yellow", "red"]
};
var collectionNO2 = ee.ImageCollection('COPERNICUS/S5P/NRTI/L3_NO2')
  .select('NO2_column_number_density')
  .filterDate(start,end);
//var NO2_max = 0.0002;
var NO2_max = 0.0001;
var NO2_min = 0;
var NO2_viz = {
  min: NO2_min,
  max: NO2_max,
  opacity: 0.5,
  palette: ["black", "blue", "purple", "cyan", "green", "yellow", "red"]
};
var collectionSO2 = ee.ImageCollection('COPERNICUS/S5P/NRTI/L3_SO2')
  .select('SO2_column_number_density')
  .filterDate(start,end);
var SO2_min = 0.0;
var SO2_max = 0.0005;
var SO2_viz = {
  min: SO2_min,
  max: SO2_max,
  opacity: 0.5,
  palette: ["black", "blue", "purple", "cyan", "green", "yellow", "red"]
};
var collectionO3 = ee.ImageCollection('COPERNICUS/S5P/NRTI/L3_O3')
  .select('O3_column_number_density')
  .filterDate(start,end);
var O3_max = .15;
var O3_min = .12;
var O3_viz = {
  min: O3_min,
  max: O3_max,
  opacity: 0.5,
  palette: ["black", "blue", "purple", "cyan", "green", "yellow", "red"]
};
var collectionCO = ee.ImageCollection("COPERNICUS/S5P/NRTI/L3_CO")
  .select('CO_column_number_density')
  .filterDate(start,end);
var CO_max = 0.05;
var CO_min = 0;
var CO_viz = {
  min: CO_min,
  max: CO_max,
  opacity: 0.5,
  palette: ["black", "blue", "purple", "cyan", "green", "yellow", "red"]
};
Map.addLayer(collectionNO2.mean(), NO2_viz, 'DIOXIDO DE NITROGENO (NO2)');
Map.addLayer(collectionCO.mean(), CO_viz, 'MONOXIDO DE CARBONO (CO)',false);
Map.addLayer(collectionO3.mean(), O3_viz, 'OZONO (O3)',false);
Map.addLayer(collectionSO2.mean(), SO2_viz, 'DIÓXIDO DE AZUFRE SO2',false);
Map.addLayer(collectionHCHO.mean(), HCHO_viz, 'FORMALDEHÍDO ',false);
Map.setCenter(30, 20, 3);
///////////////////////////////////////////////////////////////////
// A color bar widget for population. Makes a horizontal color bar to display the given
// color palette.
function ColorBar(palette) {
  return ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 1, 0.1],
      dimensions: '100x10',
      format: 'png',
      min: 0,
      max: 1,
      palette: palette
    },
    style: {stretch: 'horizontal', margin: '0px 8px'},
  });
}
function ColorBarNO2(palette) {
  return ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 1, 0.1],
      dimensions: '100x10',
      format: 'png',
      min: 0,
      max: 1,
       palette: ["white","yellow", "red"]
    },
    style: {stretch: 'horizontal', margin: '0px 8px'},
  });
}
function makeLegend() {
  var labelPanel = ui.Panel(
      [
        ui.Label(Math.round(undoColorStretch(0)), {margin: '4px 8px'}),
        ui.Label(
            Math.round(undoColorStretch(0.5)),
            {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
        ui.Label(Math.round(undoColorStretch(1)), {margin: '4px 8px'})
      ],
      ui.Panel.Layout.flow('horizontal'));
  return ui.Panel([ColorBar(POPULATION_STYLE.palette), labelPanel]);
}
// Returns our labeled legend, with a color bar and three labels representing
// the minimum, middle, and maximum values.
function makeLegend2() {
  var labelPanel = ui.Panel(
      [
        ui.Label(0, {margin: '4px 8px'}),
        ui.Label(0.00015, {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
        ui.Label(0.0003, {margin: '4px 8px'})
      ],
      ui.Panel.Layout.flow('horizontal'));
  return ui.Panel([ColorBarNO2(NO2_STYLE.palette), labelPanel]);
}
// Styling for the legend title.
var LEGEND_TITLE_STYLE = {
  fontSize: '15px',
  fontWeight: 'bold',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '4px',
};
// Styling for the legend footnotes.
var LEGEND_FOOTNOTE_STYLE = {
  fontSize: '10px',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '4px',
};
// Assemble the legend panel.
Map.add(ui.Panel(
    [
    //  ui.Label('Population Density', LEGEND_TITLE_STYLE), makeLegend(),
    //  ui.Label(
    //      '(thousands of people per square kilometer)', LEGEND_FOOTNOTE_STYLE),
    //  ui.Label(
    //      'Source: Global Human Settlement Layer (JRC)', LEGEND_FOOTNOTE_STYLE),
    //  ui.Label('Country boundaries source: USDOS LSIB', LEGEND_FOOTNOTE_STYLE)
      ui.Label('Concentración de NO2', LEGEND_TITLE_STYLE), 
      makeLegend2(),
      ui.Label( '(Densidad de NO2 mol/m^2)', LEGEND_FOOTNOTE_STYLE),
      ui.Label('Población', LEGEND_TITLE_STYLE), 
      makeLegend(),
      ui.Label('(Miles de personas por kilometro cuadrado)', LEGEND_FOOTNOTE_STYLE),   
      ui.Label('Fuerte: Global Human Settlement Layer (JRC)', LEGEND_FOOTNOTE_STYLE),
      ui.Label('Fuente datos NO2 : Promedios imágenes Sentinel 5p', LEGEND_FOOTNOTE_STYLE),
      ui.Label('Fuente limite de los paises: USDOS LSIB', LEGEND_FOOTNOTE_STYLE)
    ],
    ui.Panel.Layout.flow('vertical'),
    {width: '300px', position: 'bottom-right'}));
////////////////////////////////////////////////////////////////////////////////////////
//compositeLayer = ui.Map.Layer(mediaocenacolor).setName('Mapa Mensual').visualize(vis)
var compositeLayer = ui.Map.Layer(collectionO3,O3_viz,'Densidad de N02 a mol/m2')
var compositeLayer2 = ui.Map.Layer(collectionNO2,NO2_viz,'Densidad de N02 a mol/m2')
// Generates a new time series chart of chl-a for the given coordinates.
//compositeLayer2 = ui.Map.Layer(mediamodistemperatura,vist,'TemperaturaºC')
// * Chart setup
// Generates a new time series chart of chl-a for the given coordinates.
var generateChart = function (coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2));
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  // Add a dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'ffff00'}, 'clicked location');
  // Add the dot as the second layer, so it shows up on top of the composite.
  mapPanel.layers().set(10, dot);
  // Make a chart from the time series.
  var chlaChart = ui.Chart.image.series(collectionO3, point, ee.Reducer.mean(), 500);
  // Customize the chart.
  chlaChart.setOptions({
    title: 'Clorofila a: serie de tiempo',
    vAxis: {title: 'Densidad mol/m2'},
    hAxis: {title: 'Date', format: 'MM-yy', gridlines: {count: 7}},
    series: {
      0: {
        color: 'green',
        lineWidth: 0,
        pointsVisible: true,
        pointSize: 2,
      },
    },
    legend: {position: 'right'},
  });
  // Add the chart at a fixed position, so that new charts overwrite older ones.
  panel.widgets().set(11, chlaChart);
  };
var mapPanel = ui.Map();
var layers = mapPanel.layers();
//layers.add(compositeLayer2,visParams,'con3');
layers.add(compositeLayer,O3_viz,'con2');
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// Add placeholders for the chart and legend.
panel.add(ui.Label('[Chart]'));
//////////////////////////////////////////////
// Register a callback on the default map to be invoked when the map is clicked.
mapPanel.onClick(generateChart);
// Configure the map.
mapPanel.style().set('cursor', 'crosshair');
// Initialize with a test point.
var initialPoint = ee.Geometry.Point(117.300926,  26.572294);
//mapPanel.centerObject(guajira, 8);
// Replace the root with a SplitPanel that contains the inspector and map.
ui.root.clear();
//ui.root.add(ui.SplitPanel(panel,mapPanel));
ui.root.add(ui.SplitPanel(panel,mapPanel));
generateChart({
  lon: initialPoint.coordinates().get(0).getInfo(),
  lat: initialPoint.coordinates().get(1).getInfo()
});
}