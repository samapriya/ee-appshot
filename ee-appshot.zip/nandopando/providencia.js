var area_providencia = ui.import && ui.import("area_providencia", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -81.45802492237056,
                13.555533091957358
              ],
              [
                -81.45802492237056,
                13.290715798793881
              ],
              [
                -81.28911012744868,
                13.290715798793881
              ],
              [
                -81.28911012744868,
                13.555533091957358
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Polygon(
        [[[-81.45802492237056, 13.555533091957358],
          [-81.45802492237056, 13.290715798793881],
          [-81.28911012744868, 13.290715798793881],
          [-81.28911012744868, 13.555533091957358]]], null, false),
    area_sanandres = ui.import && ui.import("area_sanandres", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -81.86816378991651,
                12.73528365204092
              ],
              [
                -81.86816378991651,
                12.418964509275483
              ],
              [
                -81.57153293054151,
                12.418964509275483
              ],
              [
                -81.57153293054151,
                12.73528365204092
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #98ff00 */ee.Geometry.Polygon(
        [[[-81.86816378991651, 12.73528365204092],
          [-81.86816378991651, 12.418964509275483],
          [-81.57153293054151, 12.418964509275483],
          [-81.57153293054151, 12.73528365204092]]], null, false),
    area_cayonuevo = ui.import && ui.import("area_cayonuevo", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #0b4a8b */ee.Geometry.MultiPoint();
var zonaestudio = {
//  'Cayo Serrana': area_serrana,
  'Isla de Providencia': area_providencia,
  'Isla de San Andres': area_sanandres,
  'Cayo Nuevo': area_cayonuevo,
// 'San Andres': area_sanandres, 
// 'Cayo roncador': area_roncador, 
//'Banco Quitasueño': area_quitasueno,  
};
///////////////////////////////////////
/* Create UI Panels */
var panel = ui.Panel({style: {width:'300px',position: 'top-right',
      border: '0.5px solid #000000CC',
      backgroundColor: 'F7F8E0' }});
ui.root.insert(0,panel);
var table = ui.Chart(
    [
      ['<img src=https://d1yjjnpx0p53s8.cloudfront.net/styles/logo-thumbnail/s3/122012/logo_upb.png?itok=c9oTlH7S width=150px>']
    ],
    'Table', {allowHtml: true});
var titlePanel = ui.Panel([table], 'flow', {width: '300x', padding: '8px'});
panel.add(titlePanel);
//intro
var intro = ui.Label('Explorador de Imágenes Satelitales Sentinel 2 para La Reserva Seaflower, Caribe colombiano', 
{fontWeight: 'bold', fontSize: '18px', textAlign: 'center', backgroundColor: '#A3CCFF00'  }
);
var subtitle = ui.Label('Imágenes Nivel 2A Corregidas atmosféricamente',
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '12px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(intro).add(subtitle);
////////////////////////////////////////////
//select study area
var selectArea = ui.Select({
  items: Object.keys(zonaestudio),
});
selectArea.setPlaceholder('área...');
panel.add(ui.Label('1. Defina el área',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(selectArea); 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
// Create Land Use Map
var mapbutton = ui.Label('2.Seleccione escenas disponibles por fecha',
  {fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '15px',color: 'gray',backgroundColor: '#A3CCFF00' });
panel.add(mapbutton);
panel.add(ui.Button("Imágenes disponible",landMap));
var additional_directions = ui.Label
  ('Imágenes multiespectrales de 10 m de resolución espacial', 
  {margin: '0 0 0 12px',fontSize: '12px',color: 'gray'});
panel.add(additional_directions)
//////////////////////////////////////////////////////////////////////////
function landMap(){
Map.clear()
var selectedStudy_name = selectArea.getValue();
var studyArea = zonaestudio[selectedStudy_name];
Map.centerObject(studyArea,12);
/// Demonstrates before/after imagery comparison with a variety of dates.
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
/*
 * Configure the imagery
 */
// These Sentinel-1 images track the major flooding in Kerala during the 2018
// monsoon season: https://en.wikipedia.org/wiki/2018_Kerala_floods
var images = {
  '2020-04-12 antes del huracán': getWeeklySentinelComposite('2020-04-12'),
  '2020-10-09 antes del huracán': getWeeklySentinelComposite('2020-10-09'),
  '2020-11-01 antes del huracán': getWeeklySentinelComposite('2020-11-01'),
  '2020-11-08 antes del huracán': getWeeklySentinelComposite('2020-11-08'),
  '2020-11-11 antes del huracán': getWeeklySentinelComposite('2020-11-11'),  
  '2020-11-20 después del huracán': getWeeklySentinelComposite('2020-11-20'),  
  '2020-11-28 después del huracán': getWeeklySentinelComposite('2020-11-28'),
  '2020-12-13 después del huracán': getWeeklySentinelComposite('2020-12-13'),
  '2020-12-23 después del huracán': getWeeklySentinelComposite('2020-12-23'),
};
// Composite the Sentinel-1 ImageCollection for 7 days (inclusive) after the
// given date.
function getWeeklySentinelComposite(date) {
  var date = ee.Date(date);
  var sentinel2 = ee.ImageCollection('COPERNICUS/S2_SR')
                      .filterDate(date, date.advance(1, 'week'))
 .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 30))
 .filterBounds(studyArea)
 .map(maskS2clouds)
 .mean()
 .clip(studyArea);
  return sentinel2.visualize({min: 0,max: 1,gamma: 2.1,bands: ['B4', 'B3', 'B2'],});
}
/*
 * Set up the maps and control widgets
 */
// Create the left map, and have it display layer 0.
var leftMap = ui.Map();
leftMap.setControlVisibility(false);
var leftSelector = addLayerSelector(leftMap, 0, 'top-left');
// Create the right map, and have it display layer 1.
var rightMap = ui.Map();
rightMap.setControlVisibility(false);
var rightSelector = addLayerSelector(rightMap, 1, 'top-right');
// Adds a layer selection widget to the given map, to allow users to change
// which image is displayed in the associated map.
function addLayerSelector(mapToChange, defaultValue, position) {
  var label = ui.Label('Seleccione una imágen para visualizar');
  // This function changes the given map to show the selected image.
  function updateMap(selection) {
    mapToChange.layers().set(0, ui.Map.Layer(images[selection]));
  }
  // Configure a selection dropdown to allow the user to choose between images,
  // and set the map to update when a user makes a selection.
  var select = ui.Select({items: Object.keys(images), onChange: updateMap});
  select.setValue(Object.keys(images)[defaultValue], true);
  var controlPanel =
      ui.Panel({widgets: [label, select], style: {position: position}});
  mapToChange.add(controlPanel);
}
/*
 * Tie everything together
 */
// Create a SplitPanel to hold the adjacent, linked maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in the UI root.
ui.root.widgets().reset([splitPanel]);
ui.root.insert(0,panel);
var linker = ui.Map.Linker([leftMap, rightMap]);
leftMap.setCenter(-81.33602, 13.44235, 9);
}
//.setCenter(-81.33602, 13.44235, 12)