var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -174.49253937499998,
                35.88626652474758
              ],
              [
                -174.49253937499998,
                -43.071397670374225
              ],
              [
                165.819960625,
                -43.071397670374225
              ],
              [
                165.819960625,
                35.88626652474758
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-174.49253937499998, 35.88626652474758],
          [-174.49253937499998, -43.071397670374225],
          [165.819960625, -43.071397670374225],
          [165.819960625, 35.88626652474758]]], null, false);
var baseChange = [{featureType: 'all', stylers: [{invert_lightness: true}]}];
Map.setOptions('HYBRID', {'baseChange': baseChange});
///ECONOMIC ZONE
var eez = ee.FeatureCollection('users/iglushko/eez');
var bufferd=200000;
var Countries =ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017');
var selEez= eez.filter(ee.Filter.eq('country', 'Brazil'));
var features = ee.FeatureCollection(eez).sort('country').getInfo()['features'];
  var items=[];
  for (var i = 0; i < features.length; i++) {
      items.push({
        label: features[i]['properties']['country'],
        value: features[i]['properties']['country']
      });
  }
///////////////////////////////////////////////////////COLECTIONS//////////////////////////
//////////////////////////////////////////////////////BATHYMETRY/////////////////////////
var elevationdata = ee.Image('NOAA/NGDC/ETOPO1')
var elevation = elevationdata.select('bedrock');
var elevationVis = {
  min: -2500.0,
  max: 20.0,
  palette: ['011de2', 'afafaf', '3603ff', 'fff477', 'b42109'],
};
var palettes = require('users/gena/packages:palettes');
var palette7 = palettes.colorbrewer.OrRd[9];//.reverse();
var palette8 = palettes.colorbrewer.YlOrBr[9].reverse();
var palette9 = palettes.colorbrewer.Paired[7];
var palettepreci = palettes.colorbrewer.RdYlBu[9];
var palette = ['CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
               '74A901', '66A000', '529400', '3E8601', '207401', '056201',
               '004C00', '023B01', '012E01', '011D01', '011301'];
////////////////////////////////////////////////////////AREA COBERTURA/////////////////////////////////////////////////////////////////////
/* Create UI Panels */
var panel = ui.Panel({style: {width:'300px',position: 'top-right',
      border: '0.5px solid #000000CC',
      backgroundColor: 'white' }});
ui.root.insert(0,panel);
//intro PANEL
var intro = ui.Label('Global Ocean Termal Energy Zones',
{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: 'white' }
);
var subtitle = ui.Label('Herrera, J., Hernández-Hamon H and Ardila, N. 2022. Global Ocean Termal Proyect Zones Assement Based in Cloud Google Earth Engine Processing ',
  {margin: '0 0 0 12px',fontSize: '12px',color: 'gray',backgroundColor: 'white' });
panel.add(intro).add(subtitle);
Map.setCenter(-77.549180,  8.057068, 3); 
/////////////////////////////////////////////////SELECT AREA/
//OPCIONES CARGA//
var defaoi = {'Select by Country': 'SelectCountry',
  'Select by AOI': 'SelectAOI',
};
//SELECCIONAR ÁREA DE ESTUDIO//
var typeArea = ui.Select({
  items: Object.keys(defaoi),
  onChange: function(key) {
    if(defaoi[key] == 'SelectCountry'){
      selectArea.style().set('shown', true);
      selectArea2.style().set('shown', false);
    //  labeltxm.style().set('shown', false);
    }else{
      selectArea2.style().set('shown', true);
      selectArea.style().set('shown', false);
    }
  }
});
typeArea.setPlaceholder('Select...');
panel.add(ui.Label('2. Select a area',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' })).add(typeArea); 
var selectArea = ui.Select({
items:items, 
      style: {shown: false},
      onChange: function(value) {
        print(value)
        var selected_country = eez.filter(ee.Filter.eq('country', value)).geometry();
        Map.clear();
        Map.addLayer(selected_country, {color:'red'}, value);
        Map.centerObject(selected_country);
        var SelectedCountry = value;
              },
      //style:{width:'90px'},
      placeholder:'Name'
    })
selectArea.setPlaceholder('Seleccione un pais...');
//panel.add(ui.Label('1. Select a country',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: 'white' })).add(selectArea); 
panel.add(selectArea); 
//////////////////////////////////////////////////////////////////////
var selectArea2 = ui.Button({
  label:'Drawing AOI in the Map',
  style: {shown: false},
  onClick: function() {
    Map.drawingTools().clear();
    Map.drawingTools().setLinked(false);
    Map.drawingTools().setDrawModes(['rectangle']);
    Map.drawingTools().addLayer([]);
    Map.drawingTools().setShape('rectangle');
    Map.drawingTools().draw();
    var getcoord = ui.util.debounce(function() {
      var points = Map.drawingTools().layers().get(0).toGeometry();
      Map.centerObject(points);
    }, 100);
    Map.drawingTools().onDraw(getcoord);
  }
});
panel.add(selectArea2);
///////////////////////////////////////SELECT MONTH)
var dateVal = new Date();
dateVal.setDate(dateVal.getDate() - 11);
var targetDateSlider = ui.DateSlider({
  start: '2017-03-28',
  end: new Date(),
  value: dateVal,
  period: 365,
//  onChange:landMap,
  style: {stretch: 'horizontal', shown: true}
});
panel.add(ui.Label('2. Select a month....',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: 'white' })).add(targetDateSlider)
///////////////////////////////////////////////////DIFF TEMPERATURE 0 -1000 m//////////////////////////////////////
panel.add(ui.Label('3. Weight of Factors ',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: 'white' }));
var subtitle5 = ui.Label('Diff Temperature Surface/Bottom °C',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var gradi= ui.Textbox('0.4', '0.4');
var subtitle6 = ui.Label('Bathymetry (m)',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var bati = ui.Textbox('0.2', '0.2');
var subtitle7 = ui.Label('Surface Water Velocity  (m/s)',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var velis= ui.Textbox('0.1', '0.1');
var subtitle8 = ui.Label('Bottom Water Velocity (m/s)',
  {margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var velif= ui.Textbox('0.1', '0.1');
var subtitle9 = ui.Label('Population distance (m) ',
{margin: '0 0 0 12px',fontSize: '14px',color: 'gray'});
var pobli= ui.Textbox('0.2', '0.2');
panel.add(subtitle5).add(gradi).add(subtitle6).add(bati).add(subtitle7).add(velis).add(subtitle8).add(velif).add(subtitle9).add(pobli)
//landMap
var mapbutton = ui.Label('4. Results Monthly OTEC maps',{fontWeight: 'bold',margin: '10px 0 0 12px',fontSize: '16px',color: 'gray',backgroundColor: '#A3CCFF00' });
//var mapbutton2 = ui.Label('4.Cree el Mapa Mensual de Temperaturas ºC')
panel.add(mapbutton);
//panel.add(mapbutton1);
panel.add(ui.Button(" Generate maps",landMap));
//panel.add(ui.Button("Genere Temperatura",landMap))
var additional_directions = ui.Label
  ('Visualize maps in layers.', 
  {margin: '0 0 0 12px',fontSize: '12px',color: 'gray'});
panel.add(additional_directions);
//
var visParams = {
  palette : ['D50000','FD2D04', 'FD6C11', 'FDB223', 'FCFC35', '85FF36', '00FF52',
               '24F1FF', '2A74FC', '2B00FB', '3D00C9', '62009C', '8A0073'],
};
function landMap(){
Map.clear();
var baseChange = [{featureType: 'all', stylers: [{invert_lightness: true}]}];
Map.setOptions('HYBRID', {'baseChange': baseChange});
var Typeareaselect = typeArea.getValue()
var tiarea = defaoi[Typeareaselect]
if(tiarea == 'SelectCountry'){
var selectedStudy_name = selectArea.getValue();
var studyArea = ee.FeatureCollection(eez.filter(ee.Filter.eq('country', selectedStudy_name)).geometry());
print('Hello');
}else{
var studyArea = Map.drawingTools().layers().get(0).toGeometry();
print('Hello2');
  }
//var studyArea = Map.drawingTools().layers().get(0).toGeometry();
Map.centerObject(studyArea,5);
var opacity = 0.4;
var shown = true; // true or false, 1 or 0 
Map.addLayer(studyArea,{},'selectArea',shown, opacity);  
/////////////////////////////////////////////DATE///////////////
/////////////////////////////////////////////////////////////////////////
var endDate = ee.Date(ee.List(targetDateSlider.getValue()).get(1));
var  startDate = ee.Date(ee.List(targetDateSlider.getValue()).get(0));
//////////////////////////////////////////////////////////////BATHYMETRY RECLASS///////////////////////////////////////////////////////////
print(elevation,'Batimetria')
var Baticlass = ee.Image(1)
          .where(elevation.gt(-12000).and(elevation.lte(-2000)), 0)
          .where(elevation.gt(-700).and(elevation.lte(-200)), 5)
          .where(elevation.gt(-1000).and(elevation.lte(-700)), 4)
          .where(elevation.gt(-1200).and(elevation.lte(-1000)), 3)
          .where(elevation.gt(-1500).and(elevation.lte(-1200)), 2)
          .where(elevation.gt(-2000).and(elevation.lte(-1500)), 1)
          .where(elevation.gt(-199).and(elevation.lte(8500)), 0);
var minmaxbati = Baticlass.reduce(ee.Reducer.minMax());
print(minmaxbati,'minmaxsumaPclass');
var max2 = 5;
var min2 = 0;
var resta2 = (max2)-(min2);
print(resta2);
var Baticlass_normalizada = ((Baticlass.subtract(min2))).divide(resta2);
var UPPER_THRESHOLD = 0;
var Baticlass_normalizada_mask = Baticlass_normalizada.gt(UPPER_THRESHOLD );
var Baticlass_normalizada_updateMask = Baticlass_normalizada.updateMask(Baticlass_normalizada_mask);
var Baticlass_normalizada_clip = Baticlass_normalizada.multiply(Baticlass_normalizada_updateMask);
//Map.addLayer(Baticlass_normalizada,{palette:['white','white','yellow','orange','green']},'Batimetria Normalizada',false)
//Map.addLayer(Baticlass_normalizada_updateMask,{palette:"0000FF"},'Batimetria Normalizada Mascara',false);
Map.addLayer(Baticlass_normalizada_clip.clip(studyArea),{palette:['yellow','orange','green']},'Bathymetry',false);
'Optimal', 'Good', 'Acceptable', 'Bad', 'Limitant'
var Baticlass_Optimal = Baticlass.eq([5]).multiply(ee.Image.pixelArea()).divide(1000000);
var Baticlass_Good = Baticlass.eq([4]).multiply(ee.Image.pixelArea()).divide(1000000);
var Baticlass_Acceptable = Baticlass.eq([3]).multiply(ee.Image.pixelArea()).divide(1000000);
var Baticlass_Bad = Baticlass.eq([2]).multiply(ee.Image.pixelArea()).divide(1000000);
var Baticlass_Limitant = Baticlass.eq([1]).multiply(ee.Image.pixelArea()).divide(1000000);
var reducerbaticlass_optimal = Baticlass_Optimal.reduceRegion({
  reducer: ee.Reducer.sum(),
  maxPixels: 50000000,
  scale: 2000,
  geometry: studyArea
});
print ('Total Area BATHYMETRY OPTIMAL(ha) ', reducerbaticlass_optimal);
var reducerbaticlass_Good = Baticlass_Good.reduceRegion({
  reducer: ee.Reducer.sum(),
  maxPixels: 50000000,
  scale: 2000,
  geometry: studyArea
});
print ('Total Area BATHYMETRY GOOD (ha) ', reducerbaticlass_Good);
var reducerbaticlass_Acceptable = Baticlass_Acceptable.reduceRegion({
  reducer: ee.Reducer.sum(),
  maxPixels: 50000000,
  scale: 2000,
  geometry: studyArea
});
print ('Total Area BATHYMETRY BAD(ha) ', reducerbaticlass_Acceptable);
var reducerbaticlass_Bad = Baticlass_Bad.reduceRegion({
  reducer: ee.Reducer.sum(),
  maxPixels: 50000000,
  scale: 2000,
  geometry: studyArea
});
print ('Total Area BATHYMETRY LIMITANT (ha)  ', reducerbaticlass_Bad);
var reducerbaticlass_Limitant = Baticlass_Limitant.reduceRegion({
  reducer: ee.Reducer.sum(),
  maxPixels: 50000000,
  scale: 2000,
  geometry: studyArea
});
print ('Total Area (ha) ', reducerbaticlass_Limitant);
/////////////////////////////////////////////////DIFF TEMPERATURE/////////////////////////////////////////////////////////
var dataset = ee.ImageCollection('HYCOM/sea_temp_salinity')
         .filterDate(startDate,endDate);
// Select water temperature at 0 meters and scale to degrees C.
var seaWaterTemperature0 = dataset.select('water_temp_0')
    .map(function scaleAndOffset(image) {
      return ee.Image(image).multiply(0.001).add(20);
    });
print(seaWaterTemperature0,'Imagenes temperaratura 0 m')
var seaWaterTemperature0m = seaWaterTemperature0.mean();
var seaWaterTemperature1000 = dataset.select('water_temp_1000')
    .map(function scaleAndOffset(image) {
      return ee.Image(image).multiply(0.001).add(20);
    });
print(seaWaterTemperature1000,'Imagenes temperaratura 1000 m')
var seaWaterTemperature1000m = seaWaterTemperature1000.mean();
var seawatergrad0_1000 = seaWaterTemperature0m.subtract(seaWaterTemperature1000m);
// Define visualization parameters.
var visParams = {
  min: -2.0,  // Degrees C
  max: 34.0,
  palette: ['000000', '005aff', '43c8c8', 'fff700', 'ff0000'],
};
Map.addLayer(seawatergrad0_1000, visParams, 'Diferencial temperatura promedio superficie mediagua y fondo 0-1000 m',false)
var Mediatclass = ee.Image(1)
          .where(seawatergrad0_1000.gt(1).and(seawatergrad0_1000.lte(5)), 0)
          .where(seawatergrad0_1000.gt(5).and(seawatergrad0_1000.lte(14)), 1)
          .where(seawatergrad0_1000.gt(14).and(seawatergrad0_1000.lte(19)), 2)
          .where(seawatergrad0_1000.gt(19).and(seawatergrad0_1000.lte(20)), 3)
          .where(seawatergrad0_1000.gt(20).and(seawatergrad0_1000.lte(22)), 4)
          .where(seawatergrad0_1000.gt(22).and(seawatergrad0_1000.lte(25)), 5);
var minmaxtemp = Mediatclass.reduce(ee.Reducer.minMax());
print(minmaxtemp,'minmaxtemp');
var max = 5;
var min = 1;
var resta = (max)-(min);
print(resta);
var Mediatclass_normalizada = ((Mediatclass.subtract(min))).divide(resta);
///////////////////////////////////////////////////////////////////////////////////////////LEYENDA//////////////////////////////////////////
var palette1 = ['008000', //Optimal
               'b89b00', //Good
               'ffbe00', //Acceptable
               'ffe200', //Bad
               'fff800', //Limitant
              ];
//Map.addLayer(Mediatclass_normalizada,{palette:['white','white','yellow', 'orange','green']},'Diferencial temperatura Normalizada',false)
Map.addLayer(Mediatclass.clip(studyArea),{palette:['fff800','ffe200','ffbe00', 'b89b00','008000','white',]},'Diff Temperature Class',false);
Map.addLayer(Mediatclass_normalizada.clip(studyArea),{palette:['fff800','ffe200','ffbe00', 'b89b00','008000','white',]},'Diff Temperature',false);
/////////////////////////////////////////////////LEYENDA/////////////////////////////////////
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: ['000000', '005aff', '43c8c8', 'fff700', 'ff0000'],
  };
}
var vis = {min: 17, max: 23, palette: ['000000', '005aff', '43c8c8', 'fff700', 'ff0000'].reverse(),};
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(vis.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a scale panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(vis.min, {margin: '4px 8px'}),
    ui.Label(
        (vis.max / 0),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(vis.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Diff temperature °C ',
  style: {fontWeight: 'bold'}
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
panel.widgets().set(11, legendPanel);
///////////////////////////////////////////////WATER VELOCITY////////////////////////////////////
var velociagua = ee.ImageCollection('HYCOM/sea_water_velocity')
 .filterDate(startDate,endDate);
// Select water temperature at 0 meters and scale to degrees C.
var Velociagua0 = velociagua .select('velocity_u_0');
//var Velociagua500 = velociagua .select('velocity_u_100').mean();
//var Velociagua700 = velociagua .select('velocity_u_700').mean();
var Velociagua1000 = velociagua .select('velocity_u_1000').mean();
//var Velociagua500_1000 = (Velociagua500.add(Velociagua700).add(Velociagua1000)).divide(3)
var visParams2 = {
  min: -1000,  // Degrees C
  max: 4000,
  palette: ['000000', '005aff', '43c8c8', 'fff700', 'ff0000'],
};
var mediavelociagua  = Velociagua0.median();
Map.addLayer(mediavelociagua, visParams2, 'Water Velocity 0 m');
Map.addLayer(Velociagua1000, visParams2, 'Water Velocity 500-1000 m');
print(mediavelociagua,'Imagenes Velocidad Superficie 0m')
print(Velociagua1000,'Imagenes Velocidad Fondo 1000 m')
//Map.addLayer(Velociagua700, visParams2, 'Water Velocity 700');
//Map.addLayer(Velociagua1000, visParams2, 'Water Velocity 1000');
var Mediavalass = ee.Image(1)
          .where(mediavelociagua .gt(800).and(mediavelociagua .lte(2500)), 0)
          .where(mediavelociagua .gt(800).and(mediavelociagua .lte(1000)), 1)
          .where(mediavelociagua .gt(500).and(mediavelociagua .lte(800)), 2)
          .where(mediavelociagua .gt(200).and(mediavelociagua .lte(500)), 3)
          .where(mediavelociagua .gt(100).and(mediavelociagua .lte(200)), 4)
          .where(mediavelociagua .gt(-100).and(mediavelociagua .lte(100)), 5)
var Mediavalassf = ee.Image(1)
          .where(Velociagua1000 .gt(400).and(Velociagua1000 .lte(2500)), 0)
          .where(Velociagua1000 .gt(300).and(Velociagua1000 .lte(400)), 1)
          .where(Velociagua1000 .gt(100).and(Velociagua1000 .lte(300)), 2)
          .where(Velociagua1000 .gt(50).and(Velociagua1000 .lte(100)), 3)
          .where(Velociagua1000 .gt(20).and(Velociagua1000 .lte(50)), 4)
          .where(Velociagua1000 .gt(0).and(Velociagua1000 .lte(20)), 5)
var minmaxveloc = Mediavalass.reduce(ee.Reducer.minMax())
print(minmaxveloc,'minmaxveloc')
var max = 5
var min = 1
var resta = (max)-(min)
print(resta)
var Mediavalass_normalizada = ((Mediavalass.subtract(min))).divide(resta)
var Mediavalass_normalizadaf = ((Mediavalassf.subtract(min))).divide(resta)
Map.addLayer(Mediavalass_normalizada.clip(studyArea),{palette:['white','white','yellow','orange','green']},'Surface Water Velocity 0 m',false)
Map.addLayer(Mediavalass_normalizadaf.clip(studyArea),{palette:['white','white','yellow','orange','green']},'Bottom Water Velicity 500-1000 m',false)
////////////////////////////////////////////////////POPULATION///////////////////////////////////////////
var ghslPop = ee.Image('JRC/GHSL/P2016/POP_GPW_GLOBE_V1/2015');
ghslPop = ghslPop
print(ghslPop,'Poblacion')
// Constants used to visualize the data on the map.
var POPULATION_STYLE = {
  min: 0,
  max: 1,
  palette: ['white', 'brown', 'red']
};
 var pal2 = ['FF0040', //rojo
           'FFFFFF']; //blanco
//Map.addLayer(ghslPop,POPULATION_STYLE,'Poblacion');
// Define the sources. Mask the sources.
var sources = ee.Image().toByte().paint(ghslPop.geometry(), 1);
sources = sources.updateMask(ghslPop);
// Define what is necesarry for you as low as possible to decrease computational time
var maxDist = 50000;
// cost image.
var dist = ghslPop.cumulativeCost({
  source: sources, 
  maxDistance: maxDist,  
});
//Map.addLayer(dist.clip(studyArea),{min: 0, max: maxDist,palette: ['white','brown','red']}, 'Population distance',false);
var Mediadistance = ee.Image(1)
          .where(dist .gt(1000).and(dist .lte(10000)), 0)
          .where(dist .gt(500).and(dist .lte(1000)), 1)
          .where(dist .gt(50).and(dist .lte(100)), 2)
          .where(dist .gt(10).and(dist .lte(50)), 3)
          .where(dist .gt(1).and(dist .lte(10)), 4)
          .where(dist .gt(0).and(dist .lte(1)), 5)
var minmaxdistance = Mediadistance.reduce(ee.Reducer.minMax())
print(minmaxdistance,'minmaxdistance')
var max = 5
var min = 1
var resta = (max)-(min)
print(resta)
var Mediadistance_normalizada = ((Mediadistance.subtract(min))).divide(resta)
Map.addLayer(Mediadistance_normalizada.clip(studyArea),{palette:['white','white','yellow','orange','green']},'Population distance',false)
//////////////////////////////////////////////////////////////OCTEC MENSUAL//////////////////
var bativ = bati.getValue();
var gradiv = gradi.getValue();
var velivs = velis.getValue();
var velivf = velif.getValue();
var pobliv = pobli.getValue();
var bativn = ee.Number.parse(bativ);
var gradivn = ee.Number.parse(gradiv);
var velivsn = ee.Number.parse(velivs);
var velivfn = ee.Number.parse(velivf);
var poblivn = ee.Number.parse(pobliv);
var OTEC = (Mediatclass_normalizada.multiply(gradivn))
.add((Baticlass_normalizada.multiply(bativn)))
.add(Mediadistance_normalizada.multiply(poblivn))
.add((Mediavalass_normalizada.multiply(velivsn))
.add(Mediavalass_normalizadaf.multiply(velivfn).multiply(Baticlass_normalizada_updateMask)));
var OTEC_mask = OTEC.gt(UPPER_THRESHOLD);
var OTEC_updateMask = OTEC.updateMask(OTEC_mask);
var OTEC_clip = OTEC.multiply(OTEC_updateMask);
var OTEC_clip_recorte = OTEC_clip.clip(studyArea)
//Map.addLayer(OTEC,{palette: ['white','white','yellow','orange','green']},'OTEC',false);
Map.addLayer(OTEC_clip_recorte,{palette: ['yellow','orange','green']},'OTEC ANNUAL');
///////////////////////////////////////////////////////////////////////////////////////////LEYENDA//////////////////////////////////////////
var palette1 = ['008000', //Optimal
               'b89b00', //Good
               'ffbe00', //Acceptable
               'ffe200', //Bad
               'fff800', //Limitant
              ];
// Create the panel for the legend items.
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create and add the legend title.
var legendTitle = ui.Label({
  value: 'Factor Class',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
  }
});
legend.add(legendTitle);
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0 0 4px 0'
    }
  });
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'}
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
// Get the list of palette colors and class names from the image.
OTEC_clip.toDictionary().evaluate(function(result) {
  var names1 = ['Optimal', 'Good', 'Acceptable', 'Bad', 'Limitant'];
  for (var i = 0; i < names1.length; i++) {
    legend.add(makeRow(palette1[i], names1[i]));
  }
});
// Add the legend to the map.
Map.add(legend);
////////////////////////////EXPORTAR IMAGENES////////////////////////
// Export through URL
var URLDownload = OTEC_clip_recorte.getDownloadURL({
'scale': 20000,
//"region": studyAreat,
// "format" :png,
  });
//print('Link download',URLDownload);
var descarga = ui.Panel({
    style: {
      position: 'top-right',
      padding: '8px 15px'
    }
  });
  var descargaurl = ui.Label({
    value: 'Decargar imagen OTEC:', // Descarga
//    style: {//position: 'bottom-left', // Posicion
//    fontWeight: 'bold', // Negrita
//    fontSize: '8px',
//    margin: '0 0 4px 0',
//    padding: '0'}
  style:{
      margin: '4px 0 -1px 4px',
      fontSize: '13px',
      color: '3792cb'}  
}); // TamaÃ±o de fuente
  //Incorporar el titulo en el visor
//var ExportingLinks=ui.Label(classified_img.getName()).setUrl(URLDownload); //This creates a hyper link.
//dercarga.add(ExportingLinks);
descarga.add(descargaurl.setUrl(URLDownload));
Map.add(descarga);
}