var CHIRPS_pentad = ui.import && ui.import("CHIRPS_pentad", "imageCollection", {
      "id": "UCSB-CHG/CHIRPS/PENTAD"
    }) || ee.ImageCollection("UCSB-CHG/CHIRPS/PENTAD"),
    CHIRPS_daily = ui.import && ui.import("CHIRPS_daily", "imageCollection", {
      "id": "UCSB-CHG/CHIRPS/DAILY"
    }) || ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY");
// ****************************************************************************************************************** //
// DESCRIPTION
// ****************************************************************************************************************** //
//Main script for water accounting app (Gujarat and Kerala)
// ****************************************************************************************************************** //
// PARAMETERS
// ****************************************************************************************************************** //
var hy_first_year = 2017; // first hydrological year available for selection (starting in July of the previous calendar year)
// Import external dependencies
var gee_codes = require('users/hydrosolutions/public_functions:SedimentBalance_T1L2');
var palettes = require('users/gena/packages:palettes');
var functions4cropmapper = require('users/hydrosolutions/public_functions:functions4cropmapper');
//Project root path:
var root='projects/ee-india-reservoirs/assets/';
//Sediment Balance:
var sedZone_path = root + 'SedZones_';//root name of the image collections for sediment balance assets
var sedZone_collection = 'SedZones_1st_Iteration';//name of the image collection containing the sediment balance assets used here
var sedZone_name= 'SedZone_00to22_'; //first part of the file name of each sediment balance asset (each image name is composed of the sedZone_name, the ID of the water body, and the name of the iteration)
var sedZone_iteration_name = '1st_iteration'; //last part of the file name of each sediment balance asset (each image name is composed of the sedZone_name, the ID of the water body, and the name of the iteration)
var pvalue_thresh=0.05;//sediment balance significance threshold (p-value)
//Administrative level boundaries:
var adm_1=ee.FeatureCollection("FAO/GAUL/2015/level1");
var adm1_fieldname='ADM1_NAME';//property name providing the name of the level-1 units
//Irrigation systems:
var command_areas_folder = 'CommandAreas';
var cmd_areas_root_name = 'all_schemes_'; //root name of each command area asset (example: all_schemes_Gujarat --> root name is 'all_schemes_')
//States:
var state1='Gujarat'; //currently: state for which all data are available
var state2='Kerala'; //currently: state for which DEMs are mostly not available
//Water bodies
var name_shp_waterbodies = 'all_WaterBodies_v3'; //Name of shapefile of all water bodies (should be placed into the root project folder)
var wb_name = 'WBNAME';//name of attribute holding the water body names of name_shp_waterbodies
var wb_id = 'OBJECTID';//name of attribute holding the IDs of name_shp_waterbodies
var attributes_with_levels_st1='Feature_summaries_Gujarat_h_v2';//State1: attribute table of water bodies with water levels (should be placed into the root project folder)
var attributes_wo_levels_st1='Feature_summaries_Gujarat_only_area';//State1: attribute table of water bodies without water levels (only areas; should be placed into the root project folder)
var attributes_with_levels_st2='Feature_summaries_Kerala2';//State2: attribute table of water bodies without water levels (should be placed into the root project folder)
var buffer_width=500;//buffer in meters to be drawn around shapes of water bodies to include all areas that might get flooded
//Bathymetries
var ic_dems_st1 = 'DEMs_Gujarat';//State1: image collection with DEMs (should be placed into the root project folder)
var ic_dems_st2 = 'DEMs_Kerala';//State2: image collection with DEMs (should be placed into the root project folder)
var dem_name_root = 'DEMfrom_SurfWaterFreq_S2_17to22_'; //filename root of bathymetry images
//Time-Series:
var ts_root_st1 = 'Gujarat_TimeSeries';//State1: root folder containing the time series folders (should be placed into the root project folder)
var ts_root_st2 = 'Kerala_TimeSeries';//State2: root folder containing the time series folders (should be placed into the root project folder)
var ts1_folder_Landsat = 'Landsat_new';//folder containing the Landsat based time series assets (should be placed into ts_root_st1 and ts_root_st2, respectively)
var ts1_folder_S2 = 'Sentinel2_new';//folder containing the Sentinel-2 based time series assets (should be placed into ts_root_st1 and ts_root_st2, respectively)
var ts2_folder_Landsat = 'Landsat_only_areas';//folder containing the Landsat based time series assets (only areas, no levels) (should be placed into ts_root_st1 and ts_root_st2, respectively)
var ts2_folder_S2 = 'Sentinel2_only_areas';//folder containing the Sentinel-2 based time series assets (only areas, no levels) (should be placed into ts_root_st1 and ts_root_st2, respectively)
var ts_root_name = 'TS_00to22_ID_';//root name of each time series asset (example: TS_00to22_ID_10031 --> root name is 'TS_00to22_ID_')
var ts_first_year = 2015; // year of first pre-processed data point
var ts_last_year = 2022; //year of last pre-processed data point
//Surface water occurence probability (SWOP) maps:
var SurfFreq_root_name = 'SurfFreqMaps_'; //root name of each SWOP folder (example: SurfFreqMaps_Gujarat --> root name is 'SurfFreqMaps_') (should be placed into the root project folder)
var ic_SurfFreq_reservoirs = 'imgs_17to22_Otsu'; //image collection name of SWOP maps for reservoirs
var ic_SurfFreq_lakes = 'imgs_17to22_Otsu_Lakes'; //image collection name of SWOP maps for lakes
//Vegetation periods:
var crop_veg_ic = 'crop_veg_period_v2'; //image collection with cropping period maps (should be placed into the root project folder)
var crop_veg_root_name = 'crop_veg_period_'; // root name of each crop vegetation period asset (example: crop_veg_period_Gujarat_2017 --> root name is 'crop_veg_period_')
//LULC maps:
var lulc_folder = 'LULC_2018'; //folder with LULC maps
var lulc_root_name = '_lulc'; //root name of each LULC map (example: Gujarat_lulc --> root name is '_lulc')
//Optical imagery parameters
var cc_thresh = 20; //maximum value for cloud cover per optical remote sensing image (in %)
var cc_pix=50; //maximum value for CLOUDY_PIXEL_PERCENTAGE per optical remote sensing image (in %)
var nodata_thresh = 20; //percent of pixels with no data over AOI
///Crop Classes of vegetation periods
var cropland_class_names_b=['User Input...',
  'Kharif Crop',
  'Rabi Crop',
  'Zaid Crop',
  'Double Crop Kharif/Rabi',
  'Double Crop Kharif/Zaid',
  'Double Crop Rabi/Zaid',
  'Triple Crop',
  'Permanent Crops'
];
///Crop Classes of LULC maps
var cropland_class_names=['User Input...',
  'Built Up',
  'Kharif Crop',
  'Rabi Crop',
  'Zaid Crop',
  'Double / Triple Crop',
  'Current Fallow',
  'Plantation',
  'Evergreen Forest',
  'Deciduous Forest',
  'Degraded / Scrub Forest',
  'Littoral Swamp',
  'Grassland',
  'Wasteland',
  'Rann',
  'Waterbodies Max',
  'Waterbodies Min',
];
var max_crop_id = 5 ; //last id denominating crop area in LULC map
//Evapotranspiration dataset:
var ETA_monthly_maps = ee.ImageCollection('projects/ee-hsol/assets/ETa_global/USGS_SSEBop_monthly');
//Biomass production maps (annual):
var MODIS_npp=ee.ImageCollection("MODIS/061/MOD17A3HGF");
//Projection:
var utm_zone='EPSG:7755';
// ****************************************************************************************************************** //
// END OF USER INPUT //
// ****************************************************************************************************************** //
var systems1=ee.FeatureCollection(root + command_areas_folder + '/' +  cmd_areas_root_name + state1);
var systems2=ee.FeatureCollection(root + command_areas_folder + '/' + cmd_areas_root_name + state2);
var all_schemes=ee.FeatureCollection([systems1,systems2]).flatten();
var MODIS_npp=MODIS_npp.filterBounds(all_schemes.geometry().bounds(1000)).filter(ee.Filter.calendarRange(hy_first_year,2022, 'year'));
var state_summaries=ee.FeatureCollection(root + attributes_with_levels_st1)
  .map(function(ft){return ee.Feature(ft).set('STATE',state1).set('h_av',1)});
/*var duplicate_ids=ee.FeatureCollection('projects/ee-india-reservoirs/assets/Feature_summaries_Gujarat_only_area')//update this list, it contains duplicates of the other list above!
  .filter(ee.Filter.inList('OBJECTID', state_summaries.aggregate_array('OBJECTID'))).aggregate_array('OBJECTID');
*/
var only_area=  ee.FeatureCollection(root + attributes_wo_levels_st1)
  .map(function(ft){return ee.Feature(ft).set('STATE',state1).set('h_av',0)});
/*only_area=ee.FeatureCollection(duplicate_ids.iterate(function(x,previous){
  return ee.FeatureCollection(previous).filter(ee.Filter.notEquals('OBJECTID',ee.Number(x)));
},only_area));*/
state_summaries=ee.FeatureCollection([state_summaries, only_area]).flatten();
state_summaries=ee.FeatureCollection([state_summaries,
    ee.FeatureCollection(ee.data.listAssets(root + attributes_with_levels_st2).assets.map(function(ic){ 
      return ee.FeatureCollection(ic.id);
    })).flatten().map(function(ft){return ee.Feature(ft).set('STATE',state2).set('h_av',1)})]).flatten()
    .map(function(feat){
      var name=ee.String(ee.Feature(feat).get(wb_name));
      return ee.Feature(feat).set('Name',ee.Algorithms.If(name.length().gt(0),name.cat(' (').cat(ee.String('ID_').cat(ee.Number.parse(feat.get(wb_id)))).cat(')'),
        ee.String('ID_').cat(ee.Number.parse(feat.get(wb_id)))))});
// print('state_summaries',state_summaries);
var all_WaterBodies=ee.FeatureCollection(root + name_shp_waterbodies);
// print(all_WaterBodies.filter(ee.Filter.eq('OBJECTID',1026258)))
var Table = ee.data.listAssets(root + ic_dems_st1);
var l =Table.assets.length;
var allids=[];
for (var i=0; i<l; i++) {//l
  allids.push(Table.assets[i].id.split(dem_name_root)[1]);
}
var Table = ee.data.listAssets(root + ic_dems_st2);
var l2 =Table.assets.length;
for (var i=0; i<l2; i++) {//l
  allids.push(Table.assets[i].id.split(dem_name_root)[1]);
}
// print('IDs with DEMs',allids);
/*var path_ts=root + 'Gujarat_TimeSeries/Landsat_new';
var path_ts_S2=root + 'Gujarat_TimeSeries/Sentinel2_new';*/
var path_ts=root + ts_root_st1 + '/' + ts1_folder_Landsat;
var path_ts_S2=root + ts_root_st1 + '/' + ts1_folder_S2;
var state_TS=ee.FeatureCollection(ee.data.listAssets(path_ts).assets.map(function(ic){ 
      var id= ee.String(ic.id.split(ts_root_name)[1]);
      var satellite= 'Landsat';
      return ee.FeatureCollection(ic.id).set('ID',id).set('satellite',satellite);
    }));
state_TS=ee.FeatureCollection([state_TS.filter(ee.Filter.eq('satellite', 'Landsat')),
  ee.FeatureCollection(ee.data.listAssets(path_ts_S2).assets.map(function(ic){ 
  var id= ee.String(ic.id.split(ts_root_name)[1]);
  var satellite= 'Sentinel-2';
  return ee.FeatureCollection(ic.id).set('ID',id).set('satellite',satellite);
}))]).flatten();
/*var path_ts=root + 'Gujarat_TimeSeries/Landsat_only_areas';
var path_ts_S2=root + 'Gujarat_TimeSeries/Sentinel2_only_areas';*/
var path_ts=root + ts_root_st1 + '/' + ts2_folder_Landsat;
var path_ts_S2=root + ts_root_st1 + '/' + ts2_folder_S2;
var area_TS=ee.FeatureCollection(ee.data.listAssets(path_ts).assets.map(function(ic){ 
      var id= ee.String(ic.id.split(ts_root_name)[1]);
      var satellite= 'Landsat';
      return ee.FeatureCollection(ic.id).set('ID',id).set('satellite',satellite);
    }));
area_TS=ee.FeatureCollection([area_TS.filter(ee.Filter.eq('satellite', 'Landsat')),
  ee.FeatureCollection(ee.data.listAssets(path_ts_S2).assets.map(function(ic){ 
  var id= ee.String(ic.id.split(ts_root_name)[1]);
  var satellite= 'Sentinel-2';
  return ee.FeatureCollection(ic.id).set('ID',id).set('satellite',satellite);
}))]).flatten();
state_TS=ee.FeatureCollection([state_TS,area_TS]).flatten();
/*var path_ts=root + 'Kerala_TimeSeries/Landsat';
var path_ts_S2=root + 'Kerala_TimeSeries/Sentinel2';*/
var path_ts=root + ts_root_st2 + '/Landsat';// + ts1_folder_Landsat;
var path_ts_S2=root + ts_root_st2 + '/Sentinel2';// + ts1_folder_S2;
state_TS=ee.FeatureCollection([state_TS,
  ee.FeatureCollection(ee.data.listAssets(path_ts).assets.map(function(ic){ 
      var id= ee.String(ic.id.split(ts_root_name)[1]);
      var satellite= 'Landsat';
      return ee.FeatureCollection(ic.id).set('ID',id).set('satellite',satellite);
    })),
  ee.FeatureCollection(ee.data.listAssets(path_ts_S2).assets.map(function(ic){ 
      var id= ee.String(ic.id.split(ts_root_name)[1]);
      var satellite= 'Sentinel-2';
      return ee.FeatureCollection(ic.id).set('ID',id).set('satellite',satellite);
}))]).flatten();
//Background settings
var middleMap = ui.Map();
middleMap.setOptions("HYBRID");
middleMap.setControlVisibility(false);
middleMap.setControlVisibility({layerList: true});
middleMap.setControlVisibility({scaleControl: true});
middleMap.setControlVisibility({zoomControl: true});
middleMap.setControlVisibility({fullscreenControl: true});
middleMap.style().set('cursor', 'crosshair');
var satelliteMap = ui.Map();
satelliteMap.setControlVisibility(false);
satelliteMap.style().set('cursor', 'hand');
satelliteMap.setControlVisibility({layerList: true});
var hydrosolutions = ui.Label({ value : "hydrosolutions.ch", style : { shown:true ,color:'blue', fontWeight: '600', fontSize: '11px',margin: '4px 1px 2px 0px'}, targetUrl : "https://www.hydrosolutions.ch/projects/reservoir-bathymetry-and-water-accounting-in-irrigated-systems-using-earth-observation-technology"  } );
//var manual = ui.Label({ value : "APP MANUAL", style : { shown:true ,fontFamily:"arial",color:'black', fontWeight: '500', fontSize: '11px',margin: '4px 1px 2px 1px',height:'12px'}, targetUrl : "https://30867c33-1fc0-4c0a-9951-79ede3db345a.filesusr.com/ugd/858ea7_5a2de1ca6e7c42e785c57068b90dbdc5.pdf"  } );
//var hydrosolutions_manual=ui.Panel({widgets: [hydrosolutions],layout: ui.Panel.Layout.flow('horizontal'),style: {position: 'top-center',height: '22px',padding:"2px"}});
//LIST OF COUNTRIES
//state shapes
var state_list=[state1,state2];
var Table_assets;
var get_dem_from_asset = function(ic){ 
  var id= ee.String(ic.id.split(dem_name_root)[1]);
  return ee.Image(ic.id).set(wb_id,id);
};
var ETProjection = ETA_monthly_maps.first().projection();
var path;
var selectedState;
var dem_collection;
var collection_ids;
var dem;
var Lakes_with_Stats;
var lakes_fc;
var IDs;
var point;
var feat_area_s2;
var feat_elev_s2;
var area_of_interest;
var img_list_s2;
var s2Projection;
var withbands_s2;
var s2_cc;
var iteration_id=0;
var debug = false;
var cannyThreshold = 0.7;
var cannySigma = 0.7;
var minValue = -0.3;
var newfeature=1;
var dem_thislake; var dem_reservoir; var FreqMap;
var ts_thislake_s2;
var long_term_areas; var bimonthly_areas;
var long_term_average; var bimonthly_average;
var elev_range;
var selectedLake; var csv2export;
var name_id;
var name_id_client;
var area_of_interest;
var lake_area;
var drawingMode;
var good_ids;
var state_summary;
var sedzone;
var sedzone_stack;
var sedclick;
var sensor_data_4plotting;
var aoiisnew=1;
var leftmapclick;
var leftmapclick_trigger;
var rightmapclick;
var rightmapclick_trigger=function() {};
var point2;
var greenest_1to12;
var result_cmd=0;
var name_thislake;
var cluster_map;
var date_of_max_level; var date_of_min_level;
var month_of_max_level; var month_of_min_level;
var h_av; var key2; var nb_datapoints0;
var title_multi_annual;var title_multi_annual_tmp;
var command_areas; var name_cmd; var name_cmd_tmp;
var rRscale; var rRtileScale; var init_res; var attempt_no;
var command_area;
var gridsize=10;
var newdownloadname;
var downloadselectionmode=false;
var click2download=function(){};
var downloadregion;
var stateGrid; 
var area_full;
//var pixelArea0;
var prefix;
var annual_average_S2;//var pvalue; var sensslope; 
var monthly_anomalies; var season=0;
//var river_fc;
var panel_outputs = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical'),
    style: {width: '400px',border: '1px solid black'},
    widgets: []
});
var center_again =ui.util.debounce( function(){
    panel_outputs.style().set('maxWidth', '50%');
    middleMap.remove(title2);
    title2.setValue('PLEASE WAIT...');
    middleMap.centerObject(centeronthis);
},200);
var center_again2 =ui.util.debounce( function(){
    middleMap.centerObject(centeronthis/*,5*/);
},200);
var unit_name=ui.Label({style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada', margin: '7px 1px 1px 9px'}});
var unit_download=ui.Label({ value : "Download Outputs in Table Format", style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada', margin: '7px 1px 1px 9px'}});
var unit_cmd=ui.Label({style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada', margin: '7px 1px 1px 9px'}});
var unit_name_panel=ui.Panel([unit_name,unit_download,unit_cmd],ui.Panel.Layout.Flow('vertical'),{width: '370x',backgroundColor : '#dadada', margin: '3px 1px 7px 0px'});
var unit_area=ui.Label({value: "", style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada'}});
var unit_name_and_area=ui.Panel({widgets:[
  ui.Panel([ui.Label('OUTPUTS', {fontSize: '24px', fontWeight: 'bold', margin: '7px 1px 1px 10px',backgroundColor : '#dadada'}),
    unit_name_panel, unit_area], 
    ui.Panel.Layout.Flow('vertical'),
    {width: '370x',backgroundColor : '#dadada'})], 
  layout: ui.Panel.Layout.Flow('horizontal'),
  style: {backgroundColor : '#dadada'}});
var header_capacity=ui.Label('Reservoir Capacity:',{fontWeight: 'bold',fontSize: '16px',margin: '1px 10px 1px 5px',backgroundColor : '#dadada',padding: '0'});
var unit_capacity=ui.Label({style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada', margin: '7px 1px 1px 5px'}});
var sedBalance_label2=ui.Label({style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada', margin: '7px 1px 1px 5px'}});
var capacity_panel=ui.Panel({widgets:[header_capacity,unit_capacity,sedBalance_label2],layout: ui.Panel.Layout.Flow('vertical'),style: {maxWidth: "490px", margin: '15px 1px 1px 3px', backgroundColor : '#dadada'}});
//var download_fc= ui.Label({ value : "(Download Command Area as Shapefile)", style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada', margin: '1px 1px 1px 10px'}});
var header_cropanalysis=ui.Label('Crop Analysis:',{fontWeight: 'bold',fontSize: '16px',margin: '1px 10px 1px 5px',backgroundColor : '#dadada',padding: '0'});
var TotalCommandAreaLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total command area (ha):  ");
var TotalCropAreaLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total cropped area (ha):  ");
var CroppingIntensityLabel= ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Average cropping intensity:  ");
var TotalKharifAreaLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total Kharif area (ha):  ");
var TotalRabiAreaLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total Rabi area (ha):  ");
var TotalZaidAreaLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total Zaid area (ha):  ");
var total_panel=ui.Panel({widgets:[header_cropanalysis,TotalCommandAreaLabel,TotalCropAreaLabel,CroppingIntensityLabel,TotalKharifAreaLabel,TotalRabiAreaLabel,TotalZaidAreaLabel],
  layout: ui.Panel.Layout.Flow('vertical'),style: {maxWidth: "490px",margin: '15px 1px 1px 3px',backgroundColor : '#dadada'}});
var header_volchange=ui.Label('Rabi Season Water Balance:',{fontWeight: 'bold',fontSize: '16px',margin: '1px 10px 1px 5px',backgroundColor : '#dadada',padding: '0'});
var TotalVolChangeLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total reservoir water used (M m³):  ");
var TotalPLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total rainfall over cropped areas (M m³):  ");
var TotalETLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total ET over cropped areas (M m³):  ");
var TotalETfallowLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total ETgreen over cropped areas (M m³):  ");
var VolChange_panel=ui.Panel({widgets:[header_volchange,TotalVolChangeLabel],layout: ui.Panel.Layout.Flow('vertical'),style: {maxWidth: "490px", margin: '15px 1px 1px 3px', backgroundColor : '#dadada'}});
var header_avolchange=ui.Label('Annual Water Balance:',{fontWeight: 'bold',fontSize: '16px',margin: '1px 10px 1px 5px',backgroundColor : '#dadada',padding: '0'});
var max_storage=ui.Label({style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada', margin: '7px 1px 1px 5px'}});
var min_storage=ui.Label({style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada', margin: '7px 1px 1px 5px'}});
var unit_used=ui.Label({style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada', margin: '7px 1px 1px 5px'}});
var aPLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total rainfall over command area (M m³):  ");
var aETLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total ET over command area (M m³):  ");
var TotalPosVolChangeLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total Increment in the Storage (M m³):  ");
var TotalNegVolChangeLabel = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Total Water Used from Reservoir (M m³):  ");
var aVolChange_panel=ui.Panel({widgets:[header_avolchange,max_storage,min_storage,unit_used,TotalPosVolChangeLabel,TotalNegVolChangeLabel,aPLabel,aETLabel],layout: ui.Panel.Layout.Flow('vertical'),style: {maxWidth: "490px", margin: '15px 1px 1px 3px', backgroundColor : '#dadada'}});
unit_name_panel.add(capacity_panel);
unit_name_panel.add(aVolChange_panel);
unit_name_panel.add(VolChange_panel);
var header_sedBalance=ui.Label('Annual Sediment Balance:',{fontWeight: 'bold',fontSize: '16px',margin: '1px 10px 1px 5px',backgroundColor : '#dadada',padding: '0'});
var sedBalance_label1=ui.Label({style: {fontWeight: '450', fontSize: '12px',backgroundColor : '#dadada', margin: '7px 1px 1px 5px'}}).setValue("Sediment balance (mm/year):  ");
var zones_erosion = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Erosion Zones (\u0394 h < -1cm/year):  ");
var zones_deposition = ui.Label({},{fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'}).setValue( "Deposition Zones (\u0394 h < -1cm/year):  ");
var sedBalance_panel=ui.Panel({widgets:[header_sedBalance,sedBalance_label1,zones_erosion,zones_deposition],layout: ui.Panel.Layout.Flow('vertical'),style: {maxWidth: "490px", margin: '15px 1px 1px 3px', backgroundColor : '#dadada'}});
var panel_thisyear=ui.Panel({
      layout: ui.Panel.Layout.flow('vertical'),
      style: {/*maxWidth: '600px',*/border: '1px solid black',  position: 'bottom-right'},
  });
var panel_sedzone=ui.Panel({
      layout: ui.Panel.Layout.flow('vertical'),
      style: {/*maxWidth: '600px',*/},
  });
var panel_trend=ui.Panel({
      layout: ui.Panel.Layout.flow('vertical'),
//      style: {/*maxWidth: '600px',*/border: '1px solid black',  position: 'bottom-right'},
  });
panel_outputs.add(unit_name_and_area);
panel_outputs.add(panel_sedzone);
panel_outputs.add(panel_thisyear);
panel_outputs.add(panel_trend);
///OPACITY SLIDER AND LEGEND
// create vizualization parameters
var viz = {min: -1, max: 1, palette: ["red","white","#0ce9ff"]};
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'top-left',
    padding: '1px 1px',
    //maxWidth: '80px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '16px',
    margin: '1px 1px 4px 1px',
    padding: '0',
    //maxWidth: '75px'
    }
});
// Add the title to the panel
legend.add(legendTitle);
var thumbnail_erosion = ui.Thumbnail({
  image: ee.Image(1).visualize({min: 1, max: 1, palette: ['blue']}),
  params: {bbox:'0,0,10,100', dimensions:'16x16'},
  style: {padding: '0px', margin: '1px 3px 1px 0px'}
});
//thumbnail_erosion.setImage(ee.Image(1).visualize({min: 1, max: 1, palette: ["blue"]}));
var erosion_panel=ui.Panel([ui.Label('Erosion Area', {fontSize: '14px', margin: '1px 10px 1px 1px'})
  ,thumbnail_erosion], ui.Panel.Layout.Flow('horizontal'));
legend.add(erosion_panel);
//
var thumbnail_sed = ui.Thumbnail({
  image: ee.Image(1).visualize({min: 1, max: 1, palette: ['red']}),
  params: {bbox:'0,0,10,100', dimensions:'16x16'},
  style: {padding: '0px', margin: '1px 3px 1px 0px'}
});
//thumbnail_sed.setImage(ee.Image(1).visualize({min: 1, max: 1, palette: ["red"]}));
var sed_panel=ui.Panel([ui.Label('Deposition Area', { fontSize: '14px', margin: '1px 10px 1px 1px'})
  ,thumbnail_sed], ui.Panel.Layout.Flow('horizontal'));
legend.add(sed_panel);
//function to calculate volume change between two datapoints
var func_ts_analysis=function(x,th_thislake_list){
  th_thislake_list=ee.List(th_thislake_list);
          var ftm1=ee.Feature(th_thislake_list.get(ee.Number(x).subtract(1)));
          var ft0=ee.Feature(th_thislake_list.get(x));
          var ft1=ee.Feature(th_thislake_list.get(ee.Number(x).add(1)));
          var hm1=ee.Number(ftm1.get('dem_elev'));
          var h0=ee.Number(ft0.get('dem_elev'));
          var h1=ee.Number(ft1.get('dem_elev'));
          var am1=ee.Number(ftm1.get('area_water'));
          var a0=ee.Number(ft0.get('area_water'));
          var a1=ee.Number(ft1.get('area_water'));
          var tm1=ee.Date(ftm1.get('system:time_start'));
          var t0=ee.Date(ft0.get('system:time_start'));
          var t1=ee.Date(ft1.get('system:time_start'));
          var d0=t0.difference(tm1,'day');
          var d1=t1.difference(t0,'day');
          var m0=t0.difference(tm1,'month').floor();
          var m1=t1.difference(t0,'month').floor();
          var volchange0=ee.Number(ee.Algorithms.If(m0.gt(0),-99,h0.subtract(hm1).multiply((a0.add(am1).divide(2).multiply(10000))).divide(d0)));
          var volchange1=ee.Number(ee.Algorithms.If(m1.gt(0),-99,h1.subtract(h0).multiply((a0.add(a1).divide(2).multiply(10000))).divide(d1)));
          var volchange0abs=ee.Number(ee.Algorithms.If(m0.gt(0),-99,h0.subtract(hm1).multiply((a0.add(am1).divide(2).multiply(10000))).divide(d0).abs()));
          var volchange1abs=ee.Number(ee.Algorithms.If(m1.gt(0),-99,h1.subtract(h0).multiply((a0.add(a1).divide(2).multiply(10000))).divide(d1).abs()));
          var dh0abs=ee.Number(ee.Algorithms.If(m0.gt(0),-99,h0.subtract(hm1).divide(d0).abs()));
          var dh1abs=ee.Number(ee.Algorithms.If(m1.gt(0),-99,h1.subtract(h0).divide(d1).abs()));
          return ft0.set('volchange1',volchange1).set('volchange0',volchange0)
            .set('dh0abs',dh0abs).set('dh1abs',dh1abs)
            .set('volchange1abs',volchange1abs).set('volchange0abs',volchange0abs);
        };
///function to convert stack of annual edge anomalies to sedzone image
function stacktoimage(aoi,img){
  aoi=ee.Geometry(aoi);
  var bands=ee.Image(img).bandNames();
  var annual_deltah=//ee.List.sequence(0,bands.length().subtract(1))
    bands.map(function(str){
    var x=ee.Number.parse(ee.String(str).slice(1));
    return ee.Image(img).select(ee.String('t').cat(x.int())).rename('sed_diff')
    .addBands(ee.Image(x).clip(area_of_interest).rename('t').float())
    .set('system:time_start',ee.Date.fromYMD(x.add(2000), 1, 1));
  });
  var correlation = ee.ImageCollection(annual_deltah).select('t', 'sed_diff').reduce(ee.Reducer.pearsonsCorrelation());
  var reducerSensSlope=ee.Reducer.sensSlope();
  var im_reduced_sens=ee.ImageCollection(annual_deltah).select('t', 'sed_diff').reduce(reducerSensSlope)//8
    .addBands(ee.ImageCollection(annual_deltah).select('sed_diff').count().rename('count'))
    .addBands(correlation.select('p-value'))
        .clip(area_of_interest);
  var slope=im_reduced_sens.select('slope');
  var count=im_reduced_sens.select('count');
  var sed_zone_collection=ee.ImageCollection(ee.Image(img).bandNames().map(function(b){
    var nr=ee.Number.parse(ee.String(b).slice(1));
    return ee.Image(img).select(ee.String(b)).rename('b1').set('t',nr);
  }));
  //number of values from 2000 to 2010
  var count2=sed_zone_collection.filter(ee.Filter.lte('t', 10)).count().rename('count');
  //how about 2011-2020? find those pixels with relevant slope that were not representing water edge before 2011!!
  var count3=sed_zone_collection.filter(ee.Filter.gt('t', 10)).count().rename('count');
  count3=count3.where(count2.gte(2),0);
  slope=slope.updateMask(count.gte(5)).updateMask(count2.gt(1));
  var slope11to20=im_reduced_sens.select('slope').updateMask(count3.gte(5));
  var sedzones_tmp=slope.where(im_reduced_sens.select('p-value').gt(pvalue_thresh),0);
  var sedzones_tmp11to20=slope11to20.where(im_reduced_sens.select('p-value').gt(pvalue_thresh),0);//.updateMask(sedzones_tmp.neq(0)) ;   
  sedzones_tmp=sedzones_tmp11to20.blend(sedzones_tmp);
  var sedzone_filled=sedzones_tmp;//.focal_mean({radius: 1, kernelType :'circle',units: 'pixels',iterations: 1}).blend(sedzones_tmp);
  count=count.focal_mode({radius: 2, kernelType :'circle',units: 'pixels',iterations: 1}).blend(count)
    .reproject({crs: utm_zone, scale:10});
  var slope_final=im_reduced_sens.select('slope').updateMask(count.gte(6))
    .focal_mean({radius: 2, kernelType :'circle',units: 'pixels',iterations: 1})
    .blend(im_reduced_sens.select('slope').updateMask(count.gte(6))
    .focal_mean({radius: 1, kernelType :'circle',units: 'pixels',iterations: 1}).updateMask(count.gte(6)))
    .reproject({crs: utm_zone, scale:10});
  //var ndvi_wetseason=ee.Image(1).where(merged_landsat.mean().select('NDVI').gte(0.5),0);//.reproject({crs: utm_zone, scale:10})
  slope_final=slope_final
    //.updateMask(ndvi_wetseason.focal_min({radius: 10,kernelType:'square', units: 'meters'}))
    .updateMask(count.gte(1))
    .reproject({crs: utm_zone, scale:10});
  var sed_thislake=sedzone_filled.focal_mean({radius: 2, kernelType :'circle',units: 'pixels',iterations: 1})
    .blend(sedzone_filled)
    .updateMask(count.gte(3))
    .reproject({crs: utm_zone, scale:10})
    .rename('sedzone_filled');
  var mean_movement21=ee.Number(slope_final
    .reduceRegion(ee.Reducer.mean(),aoi).get('slope')).multiply(1000).round();
  var erosion_area=ee.Number(slope_final.updateMask(slope_final.gte(0.01)).updateMask(sed_thislake.select('sedzone_filled').neq(0)).updateMask(count.gte(3))
    .reduceRegion(ee.Reducer.count(),aoi).get('slope'))
    .divide(ee.Number(slope_final.updateMask(count.gte(3)).reduceRegion(ee.Reducer.count(),aoi).get('slope')))
    .multiply(100);
  var deposition_area=ee.Number(slope_final.updateMask(slope_final.lte(-0.01)).updateMask(sed_thislake.select('sedzone_filled').neq(0)).updateMask(count.gte(3))
    .reduceRegion(ee.Reducer.count(),aoi).get('slope'))
    .divide(ee.Number(slope_final.updateMask(count.gte(3)).reduceRegion(ee.Reducer.count(),aoi).get('slope')))
    .multiply(100);
  var neutral_area=ee.Number(slope_final.updateMask(slope_final.abs().lt(0.01)).updateMask(sed_thislake.select('sedzone_filled').neq(0)).updateMask(count.gte(3))
    .reduceRegion(ee.Reducer.count(),aoi).get('slope')) 
    .divide(ee.Number(slope_final.updateMask(count.gte(3)).reduceRegion(ee.Reducer.count(),aoi).get('slope')))
    .multiply(100); 
  sedzone_filled=sedzone_filled.where(sedzone_filled.abs().lte(0.01),0).rename('sedzone_filled');//.updateMask(sedzone_filled.abs().gt(0.01))
  //.reproject({crs: sedzone_filled.projection().crs(), scale:10});
  return im_reduced_sens.addBands(sedzone_filled).clip(area_of_interest)
    //.set('sedfrac',sedfrac)
    //.set('sedfrac_1m',sedfrac2)
    //.set('mean_movement',mean_movement)
    .set('mean_movement21',mean_movement21)
    .set('erosion_area',erosion_area.multiply(100).round().divide(100))
    .set('deposition_area',deposition_area.multiply(100).round().divide(100))
    .set('neutral_area',neutral_area.multiply(100).round().divide(100));
}
var slider1 = ui.Slider({direction: 'horizontal',style: {width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 0px 1px 1px'}}).setValue(1);
//var slider = ui.Slider({style: {stretch: 'both',width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 1px 1px 1px'}}).setValue(1);
slider1.onSlide(function(value) {
  middleMap.layers().get(8).setShown(true);
  middleMap.layers().get(8).setOpacity(value);
});
var slider2 = ui.Slider({direction: 'horizontal',style: {width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 0px 1px 1px'}}).setValue(1);
//var slider2 = ui.Slider({style: {stretch: 'both',width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 1px 1px 1px'}}).setValue(1);
slider2.onSlide(function(value) {
  middleMap.layers().get(7).setShown(true);
  middleMap.layers().get(7).setOpacity(value);
  //middleMap.style().set('cursor', 'crosshair');
});
var slider3 = ui.Slider({style: {stretch: 'both',width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 1px 1px 1px'}}).setValue(1);
slider3.onSlide(function(value) {
  middleMap.layers().get(6).setShown(true);
  middleMap.layers().get(6).setOpacity(value);
});
var slider4 = ui.Slider({style: {stretch: 'both',width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 1px 1px 1px'}}).setValue(1);
slider4.onSlide(function(value) {
  middleMap.layers().get(4).setShown(true);
  middleMap.layers().get(4).setOpacity(value);
});
var slider5 = ui.Slider({style: {stretch: 'both',width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 1px 1px 1px'}}).setValue(1);
slider5.onSlide(function(value) {
  middleMap.layers().get(4).setShown(true);
  middleMap.layers().get(4).setOpacity(value);
});
var slider6 = ui.Slider({style: {stretch: 'both',width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 1px 1px 1px'}}).setValue(0);
slider6.onSlide(function(value) {
  middleMap.layers().get(2).setShown(true);
  middleMap.layers().get(2).setOpacity(value);
});
var slider7 = ui.Slider({style: {stretch: 'both',width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 1px 1px 1px'}}).setValue(0);
slider7.onSlide(function(value) {
  //middleMap.remove(legend);
  //middleMap.add(legend);
  middleMap.layers().get(1).setShown(true);
  middleMap.layers().get(1).setOpacity(value);
});
var slider8 = ui.Slider({style: {stretch: 'both',width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 1px 1px 1px'}}).setValue(0);
slider8.onSlide(function(value) {
  middleMap.layers().get(0).setShown(true);
  middleMap.layers().get(0).setOpacity(value);
});
var sliderPanel = ui.Panel({style :{position : "top-left",maxWidth: "200px"}});//
var sliderPanel_base = ui.Panel({style :{}});//
var thumbnail_s2 = ui.Thumbnail({
  image: ee.Image(1).visualize({min: 1, max: 1, palette: ['#008000']}),
  params: {bbox:'0,0,10,100', dimensions:'16x16'},
  style: {padding: '0px', margin: '1px 1px 1px 0px'}
});
var thumbnail_IS = ui.Thumbnail({
  image: ee.Image(1).visualize({min: 1, max: 1, palette: ['00FF00']}),
  params: {bbox:'0,0,10,100', dimensions:'16x16'},
  style: {padding: '0px', margin: '1px 1px 1px 0px'}
});
var slider1_panel=ui.Panel([slider1,thumbnail_s2], ui.Panel.Layout.Flow('horizontal'));
var slider2_panel=ui.Panel([slider2,thumbnail_IS], ui.Panel.Layout.Flow('horizontal'));
sliderPanel_base.widgets().set(0,ui.Label('Irrigation Systems', {fontWeight: '450', fontSize: '10px', margin: '1px 1px 1px 1px'}));
sliderPanel_base.widgets().set(1,slider2_panel);
sliderPanel_base.widgets().set(2,ui.Label('Crop Map', {fontWeight: '450', fontSize: '10px', margin: '1px 1px 1px 1px'}));
sliderPanel_base.widgets().set(3,slider5);
sliderPanel_base.widgets().set(4,ui.Label('Surface Water Probability', {fontWeight: '450', fontSize: '10px', margin: '1px 1px 1px 1px'}));
sliderPanel_base.widgets().set(5,slider6);
sliderPanel_base.widgets().set(6,ui.Label('Deposition/Erosion', {fontWeight: '450', fontSize: '10px', margin: '1px 1px 1px 1px'}));
sliderPanel_base.widgets().set(7,slider7);
sliderPanel_base.widgets().set(8,ui.Label('Bathymetry', {fontWeight: '450', fontSize: '10px', margin: '1px 1px 1px 1px'}));
sliderPanel_base.widgets().set(9,slider8);
sliderPanel.widgets().set(0,ui.Label('Opacity', {fontWeight: '450', fontSize: '14px', margin: '1px 1px 1px 1px'}));
sliderPanel.widgets().set(1,sliderPanel_base);
var header = ui.Label({value: 'Select a State and a Lake', style : {color:'black', fontWeight: '600', fontSize: '12px',margin: '1px 1px 1px 7px'}});
var header_first = ui.Label({value: 'Select a State', style : {color:'black', fontWeight: '600', fontSize: '12px',margin: '1px 1px 1px 7px'}});
var thisyear;
//starting from September the last year will switch to the current calendar year
//Comment: attention, app not yet fully operational
if (new Date().getMonth()>=8){//September
  thisyear=2022;//new Date().getFullYear();
} else {
  thisyear=2022;//(new Date().getFullYear()) - 1;
}
//
var year_list=ee.List.sequence(hy_first_year,ee.Number(thisyear)).map(function(nb){
        return {label: ee.String(ee.Number(nb).int()), value: nb};
  });
// print('year_list',year_list);
///PANEL ON THE LEFT SIDE  
//select_year = ui.Select({items:[{label: '2020', value: 2020}]}).setValue(2020,false); 
var select_year = ui.Select({items:[{label: thisyear, value: thisyear}],
  style:{fontWeight: '450', fontSize: '12px',width: '115px',height: '29px',margin: '10px 1px 1px 10px'}}).setValue(thisyear,false); 
var years_select_panel=ui.Panel({widgets: [ui.Label('Select a Year',{fontWeight: '450', fontSize: '12px',width: '90px',height: '29px',margin: '10px 1px 5px 10px'})
  ,select_year],layout: ui.Panel.Layout.flow('horizontal'),style: {fontWeight: '450', fontSize: '12px'}});
var label_label=ui.Label('CROP MAP LEGEND', {fontSize: '24px', fontWeight: 'bold', margin: '15px 1px 10px 10px'});
var label_download=ui.Label('MAP EXPORT', {fontSize: '24px', fontWeight: 'bold', margin: '15px 1px 10px 10px'});
var nicebar=ui.Label({style: {backgroundColor: 'black',padding: '1px',width: '240px',height: '2px',margin: '1px 1px 1px 10px'}});
var nicebar0=ui.Label({style: {backgroundColor: 'black',padding: '1px',width: '240px',height: '2px',margin: '10px 1px 1px 10px'}});
var nicebar2=ui.Label({style: {backgroundColor: 'black',padding: '1px',width: '240px',height: '2px',margin: '15px 1px 1px 10px'}});
var label_label2=ui.Label('YEAR', {fontSize: '24px', fontWeight: 'bold', margin: '15px 1px 10px 10px'});
var centeronthis=all_WaterBodies;
//go back to main menu after selection of adm1: not in use currently
/*var adm1_select=ui.Select({style:{fontWeight: '450', fontSize: '12px',width: '115px',height: '29px',margin: '10px 1px 1px 10px'}, 
  items: state_list,
  onChange: function(key){
    //select_adm1.setPlaceholder('Select ID ...');
    selectPanel.remove(select_adm1);
    splitPanel1.getFirstPanel().style().set('width','100%');
    mapChartSplitPanel.getFirstPanel().style().set('width','100%');
    middleMap.remove(title2);
    middleMap.add(title2);
    centeronthis=all_WaterBodies.filter(ee.Filter.eq('STATE', key));
    middleMap.unlisten(click_state);
    var gotomain=ui.util.debounce( function(){
      ui.root.clear();
      reselect();
      redraw(key);
    },100);
    gotomain();  
  }
}).setPlaceholder('Select a State ...'); */
//selection of water bodies in main manu
var select_adm1 = ui.Select({items: [],
    onChange: function(key){
      if (key == '...'){
        /*middleMap.centerObject(all_WaterBodies,5);
        selectPanel.remove(select_adm1);
        select_adm0b.setValue(null, false);
        select_adm0b.setPlaceholder('Select a State ...');*/
        reselect();
      } else {
          title2.setValue('PLEASE WAIT...');
          middleMap.remove(sliderPanel);middleMap.remove(trend_panel);
          middleMap.remove(title2);
          middleMap.add(title2);
          middleMap.centerObject(ee.Feature(all_WaterBodies.filter(ee.Filter.eq('Name', key)).first()).geometry());
          var gotosecond=ui.util.debounce( function(){
              root4redraw2();
              redraw2(key);
          },800);
          gotosecond();
    }}
    }).setPlaceholder('Select ID ...'); 
select_adm1.style().set({color: 'red',fontWeight: '450',border: '1px solid black',margin: '1px 1px 1px 7px'}); 
var wb4sel=ui.Select({style:{fontWeight: '450', fontSize: '12px',width: '115px',height: '29px',margin: '10px 1px 1px 10px'}, 
  items: [],
  onChange: function(key){
      if (key!=='...') {
        start_redraw=1;
        redraw2(key);
      }
    }
}).setPlaceholder('Select a Water Body ...');
var irrg4sel=ui.Select({style:{fontWeight: '450', fontSize: '12px',width: '115px',height: '29px',margin: '10px 1px 1px 10px'}, 
  items: ['...'],
  onChange: function(key){
    name_cmd=key;
    closewindow();
    if (key == '...'){
      unit_name_panel.remove(total_panel);
      unit_cmd.setValue("");
      VolChange_panel.remove(TotalPLabel);
      VolChange_panel.remove(TotalETLabel);
      VolChange_panel.remove(TotalETfallowLabel);
      aVolChange_panel.remove(aPLabel);
      aVolChange_panel.remove(aETLabel);
      middleMap.layers().set(4, ui.Map.Layer(dl,null,'Placeholder for Crop Map',false));
      dd = ee.Image().paint(selectedLake.geometry(), 0, 2);
      middleMap.layers().set(9, ui.Map.Layer(dd,null, "area_of_interest"));
      middleMap.centerObject(selectedLake);
      slider2.setValue(1);
      dataSelector.setValue('-');
    } else {
      checkbox_download.setDisabled(false);
      //var cmd_area=command_areas.filter(ee.Filter.eq('CNAME',key)).first();
      result_cmd=0;attempt_no=1;
      task2a(name_cmd,rRscale,rRtileScale);
      task2(name_cmd,rRscale,rRtileScale,year,month_of_max_level,month_of_min_level);
      task2b(name_cmd,rRscale,rRtileScale);
      unit_download.setUrl(csv2export.sort('1_Type').getDownloadURL({format:'csv',filename:'OUTPUT_'+ name_thislake.replace(/ /g,'').replace(/\./g, '').replace(/'/g,'') + '_Year' + year}));
      var_select_multi.items().reset(items_var_select_multi1prefix.concat(items_var_select_multi2).concat(items_var_select_multi3));
      if (name_cmd_tmp!==name_cmd){
        var_select_multi.setValue(0);
      }
      dataSelector.setValue(null,false);
      if (right_selected==1){
        var data_selected_tmp=data_selected;
//        dataSelector.setValue('-');
        dataSelector.setValue(null,false);
        dataSelector.setValue(data_selected_tmp);
      }
    }
  }
}).setPlaceholder('...');
var back2Main_button = ui.Button({label : "Back to Main Menu", style : {color:'red', fontWeight: '450', fontSize: '12px',height: '29px', margin: '10px 1px 1px 7px'}, 
  onClick: function(){
    splitPanel1.getFirstPanel().style().set('width','100%');
    mapChartSplitPanel.getFirstPanel().style().set('width','100%');
    middleMap.add(title2);
    centeronthis=all_WaterBodies;
    select_adm1.setValue(null,false);
    wb4sel.setValue(null,false);
    select_adm1.setPlaceholder('Select ID ...');
    var gotomain=ui.util.debounce( function(){
      ui.root.clear();
      reselect();
    },100);
    gotomain();
  }, disabled: false});
var panel = ui.Panel({
  // Create a panel with vertical flow layout.
    layout: ui.Panel.Layout.flow('vertical'),
    style: {width: '270px',border: '1px solid black'},
    widgets: [
      ui.Label('USER INPUT', {fontSize: '24px', fontWeight: 'bold', margin: '7px 1px 1px 10px'}),
      back2Main_button,
      /*ui.Panel([ui.Label('Select a State', {fontWeight: '450', fontSize: '12px',width: '90px',height: '29px',margin: '10px 1px 1px 10px'}),
        adm1_select], ui.Panel.Layout.Flow('horizontal')),*/
     /* ui.Panel([ui.Label('Select a Rayon', {fontWeight: '450', fontSize: '12px',width: '70px',height: '29px',margin: '5px 1px 15px 10px'}),
        adm2_select], ui.Panel.Layout.Flow('horizontal')),*/
      ui.Panel([ui.Label('Water Bodies', {fontWeight: '450', fontSize: '12px',width: '90px',height: '29px',margin: '10px 1px 5px 10px'}),
        wb4sel], ui.Panel.Layout.Flow('horizontal')),        
      ui.Panel([ui.Label('Command Areas', {fontWeight: '450', fontSize: '12px',width: '90px',height: '29px',margin: '10px 1px 5px 10px'}),
        irrg4sel], ui.Panel.Layout.Flow('horizontal')),
      years_select_panel,
      nicebar,
      label_label
    ]
});
var selectionPanel2 = ui.Panel({style :{position : "middle-right",maxWidth: "180px"}});//
selectionPanel2.widgets().set(0,ui.Label('Map for Comparison', {fontWeight: 'bold', fontSize: '20px', margin: '1px 1px 1px 1px'}));
var data_selected= '-';
var VIselect='NDVI';
var VARselect='Precipitation';
var mapVARselect;
var mapVAR_list=["Irrigation_months",	"Evapotranspiration",'Precipitation','TBP','NDVI'];
var var_title_monthly=['Crop ID','mm/month','mm/month','kgDM/ha/year','NDVI [-]'];
var var_comparison=['-','Annual Precipitation','Annual Evapotranspiration'/*,'Total Biomass Production'*/,'Annual Max. NDVI'];
var rigthmapclick_on=0;var leftmapclick_on=0;
var checkbox_download = ui.Checkbox('Open Crop Map Download Panel',false,null,null,{maxWidth: "230px"});
var checkbox_download_panel=ui.Panel([], ui.Panel.Layout.Flow('horizontal')).add(checkbox_download);
var checkbox_panel=ui.Panel([], ui.Panel.Layout.Flow('horizontal'));
var checkbox_ET = ui.Checkbox('Create Evapotranspiration Map Download Link',false,null,null,{maxWidth: "230px"});
var checkbox_P = ui.Checkbox('Create Precipitation Map Download Link',false,null,null,{maxWidth: "230px"});
checkbox_download.onChange(function(checked) {
  bottomPanel1.remove(title_bottomPanel1);
  middleMap.centerObject(command_area);
  //middleMap.layers().get(7).setShown(false);
  //reset_zoom();
  newdownloadname=ee.String('CropMap_').cat(ee.String(name_thislake))
  .cat('_').cat(ee.String(ee.Number(year).toShort())).cat('_')
  .cat(ee.String(ee.Number(gridsize).round().toShort())).cat('m');
  // print('newdownloadname',newdownloadname);
  downloaddata();
});
var notificationPanel = ui.Panel({ widgets : [],  layout: ui.Panel.Layout.flow('vertical'),
  style : {position : "top-center",maxWidth: "500px",maxHeight: "600px"}});
var MapType='Crop Type Map';
var message = ui.Label({ value :'', style : {color:'red'}  });
notificationPanel.add(message);
var handleClickOnMap= function(coords) {
  if (downloadselectionmode){
    message.setValue('Please wait. Download link is being generated...');
    var pointd = ee.Geometry.Point(coords.lon, coords.lat);
    downloadregion=ee.Feature(stateGrid.filterBounds(pointd).first());
    // print('downloadregion',downloadregion);
    var dl = ee.Image().paint(ee.FeatureCollection([]), 0, 2);
    middleMap.layers().set(6, ui.Map.Layer(dl,null, '',false));
    middleMap.addLayer(downloadregion, {color:'222200'}, 'grid selected');
    var region = functions4cropmapper.getRegion(downloadregion.geometry());
    ee.String(ee.Number(downloadregion.get('id')).toShort()).evaluate(function(tileNo) {
      newdownloadname.evaluate(function(result) {
        var download_tif_label = ui.Label({ value : "Download Crop Map as TIF, Tile " + tileNo, style : { shown:true },targetUrl : cluster_map.int8().getDownloadURL({scale: gridsize, region: region, name :result + '_Year' + year + '_tile' + tileNo})} );
        notificationPanel.add(download_tif_label);
        message.setValue('Click on the map to download more tiles');
        middleMap.layers().set(11, ui.Map.Layer(stateGrid, {color:'222200'}, 'grid'));
      });
    });
  }
};
var closewindow = function(){
    downloadselectionmode=false;
    notificationPanel.clear();
    message.setValue('');
    notificationPanel.add(message);
    middleMap.remove(notificationPanel);
    var zIndex = middleMap.layers().length();
    for (var i=zIndex-1; i>10; i--) {
      middleMap.remove(middleMap.layers().get(i));
    }
    checkbox_download.setDisabled(false).setValue(false,false);
    //middleMap.layers().get(10).setShown(false);
    click_state=middleMap.onClick(todo_when_click);
    if (right_selected==1){
      //satelliteMap.layers().get(1).setShown(true);
      rightmapclick= satelliteMap.onClick(function(coords) {
        rightmapclick_trigger(ee.FeatureCollection(ee.Geometry.Point(coords.lon, coords.lat)));
      });
    }
    select_year.setDisabled(false);
    bottomPanel1.remove(title_bottomPanel1);
    bottomPanel1.add(title_bottomPanel1);
    middleMap.unlisten(click2download); 
};
var close_point = function(){
  if (rigthmapclick_on==1){
    satelliteMap.remove(satelliteMap.layers().get(3));
  }
  rigthmapclick_on=0;leftmapclick_on=0;
  bottomPanel1.clear();
  middleMap.layers().get(10).setShown(false);
  bottomPanel1.add(title_bottomPanel1);  
};
var downloaddata=function(){ 
  middleMap.remove(notificationPanel);
  notificationPanel.style().set('position', 'top-center').set('width', "");
  checkbox_download.setDisabled(true);
  message.setValue('Click on the Scheme to select a tile for download');
  middleMap.add(notificationPanel);
  var cancelButton=ui.Button({label : "Close", style : {}, onClick:function(){
    closewindow();
  }});  
  var toohighres_label=ui.Label({ value : 'Spatial resolutions higher than 30 m are not permitted.'});
  var enter_res=ui.Textbox({
    style: {width: '48px',margin: '1px 1px 5px 1px'},
    onChange: function(text) {
      notificationPanel.remove(toohighres_label);
      if (parseInt(text,0)>=10){
        gridsize=Number(text); 
        var tilesize=ee.Number(10000).multiply(ee.Number(gridsize)).divide(111000).multiply(0.4);///0.55 safety factor, bcs Total request size must be less than or equal to 33554432 bytes
        stateGrid = ee.FeatureCollection(functions4cropmapper.coverByGrid(command_area.geometry(),tilesize, tilesize));//0.89° ~=100'000 m ~= 10000x10000 pixels (10m)
        middleMap.layers().set(11, ui.Map.Layer(stateGrid, {color:'222200'}, 'grid'));
        newdownloadname=ee.String(newdownloadname.split(ee.String(ee.Number(year).toShort()).cat('_')).get(0)).cat(ee.String(ee.Number(gridsize).toShort())).cat('m');
      } else {
         notificationPanel.widgets().set(3,toohighres_label);
      }
    }
  }).setValue(gridsize.toString());
  notificationPanel.widgets().set(1,cancelButton);
  notificationPanel.widgets().set(2, ui.Panel([ui.Label('Spatial resolution download map', {maxWidth: "200px", fontWeight: '450', fontSize: '12px', margin: '7px 7px 5px 10px'}),
        enter_res,ui.Label('m', {fontWeight: '350', fontSize: '12px', margin: '7px 1px 5px 1px'})],ui.Panel.Layout.Flow('horizontal')));
  enter_res.setDisabled(true);//reducing the resolution with the mode aggregator leads to "User memory limit exceeded.". Using NN not required, therefore it is better to disable this option.
  select_year.setDisabled(true);
  if (rigthmapclick_on==1 ||leftmapclick_on==1){
    close_point();
  }
  downloadselectionmode=true;
  middleMap.unlisten(click_state);
  //middleMap.unlisten(leftmapclick);
  satelliteMap.unlisten(rightmapclick);
  click2download=middleMap.onClick(handleClickOnMap);
};
////Slider Panel for satelliteMap:
var slider1b = ui.Slider({style: {stretch: 'both',width:'80px',fontWeight: '450', fontSize: '12px', margin: '1px 1px 1px 1px'}}).setValue(0);
slider1b.onSlide(function(value) {
  satelliteMap.layers().get(1).setOpacity(value);
});
var sliderPanel2 = ui.Panel({style :{maxWidth: "120px"}});//
sliderPanel2.widgets().set(0,ui.Label('Opacity Slider', {fontWeight: '450', fontSize: '10px', margin: '1px 1px 1px 1px'}));
sliderPanel2.widgets().set(1,slider1b);
var selectionPanel2 = ui.Panel({style :{position : "middle-right",maxWidth: "180px"}});//
selectionPanel2.widgets().set(0,ui.Label('Map for Comparison', {fontWeight: 'bold', fontSize: '20px', margin: '1px 1px 1px 1px'}));
selectionPanel2.widgets().set(1,sliderPanel2);
satelliteMap.add(selectionPanel2);
//legends for right side map
// set position of panel
var legend2 = ui.Panel({
  style: {
    position: 'top-right',
    padding: '1px 1px'
  }
});
// Create legend2 title
var legend2title = ui.Label({
  value: 'Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '16px',
    margin: '0 0 1px 0',
    padding: '0',
    maxWidth: '75px'
    }
});
legend2.add(legend2title);
// create the legend2 image
var lon = ee.Image.pixelLonLat().select('latitude');
// create vizualization parameters
var legend_palette = palettes.misc.jet[7];
var viz = {min: 0, max: 100, palette: ['white'].concat(legend_palette)};
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legend2Image = gradient.visualize(viz);
// create text on top of legend2
var legend2_max = ui.Label(viz.max + ' ', {fontWeight: '450', fontSize: '15px', margin: '0px 1px 1px 1px'});
legend2.add(legend2_max);
// create thumbnail from the image
var thumbnail = ui.Thumbnail({
image: legend2Image,
params: {bbox:'0,0,10,100', dimensions:'20x50'},
style: {padding: '0px', position: 'bottom-center'}
});
// add the thumbnail to the legend2
legend2.add(thumbnail);
// create text on top of legend2
var legend2_min = ui.Label(viz.min, {fontWeight: '450', fontSize: '15px', margin: '0px 1px 1px 1px'});
legend2.add(legend2_min);
var right_selected=0;//none selected on starting screen
//click on right map: display time series of currently displayed variable
var click2_function_monthly=function(imgcol) {
  if (dataSelector.getValue()=='Annual Max. NDVI'){
    // print('loading NDVI image collection');
    imgcol=sensor_data4NDVI(point2).select('NDVI');
  // print('imgcol',imgcol);
  }
  imgcol=ee.ImageCollection(imgcol);
  var mapTS_chart2 = ui.Chart.image.series(imgcol, point2, ee.Reducer.first(), 30,'system:time_start');
  mapTS_chart2.setOptions({title: 'Point of Interest',
    height: 200,
    lineWidth: 1, 
    pointSize: 3,
    interpolateNulls: false,
    curveType: 'function',
    explorer: {axis: 'vertical'},
    pointsVisible: true,
    legend: {position: 'right'},
    hAxis: {gridlines: {color: 'FFF'},titleTextStyle: {italic: false, fontSize: 14, bold: true},viewWindow: {min:new Date(hy_first_year - 1 + "-07-01").getTime()},maxValue:new Date(thisyear + "-07-01").getTime()},
    vAxis: {gridlines: {color: 'FFF'},titleTextStyle: {italic: false, fontSize: 14, bold: true}, title: var_title_monthly[mapVAR_list.indexOf(mapVARselect)],minValue:0},
    colors: new_palette.slice(1),
  });
  var options4chart=mapTS_chart2.getOptions();
  if (dataSelector.getValue()=='Annual Max. NDVI'){
    options4chart.lineWidth= 0;
    options4chart.color= 'FFF';
    mapTS_chart2.setOptions(options4chart);
  }
  bottomPanel1.clear();
  rigthmapclick_on=1;
  bottomPanel1.widgets().set(0,mapTS_chart2);
};
var task_click2=function(imgcol) {
  rightmapclick= satelliteMap.onClick(function(coords) {
    rightmapclick_trigger(ee.FeatureCollection(ee.Geometry.Point(coords.lon, coords.lat)));
  });
  rightmapclick_trigger=function(point){
    point2=ee.FeatureCollection(point);
    var poi_map_layer=ui.Map.Layer(point2.style({pointShape: 'triangle',pointSize:10,color:'black',fillColor : 'white'}), {},"Point of Interest");
    satelliteMap.layers().set(3, poi_map_layer);
    poi_map_layer=ui.Map.Layer(point2.style({pointShape: 'triangle',pointSize:10,color:'black',fillColor : 'white'}), {},"Point of Interest");
    middleMap.layers().set(10, poi_map_layer);
    click2_function_monthly(imgcol);
  }; 
};
//ET map
var ET_maps4display; var ET_maps4chart;var ET_monthly_imgs;
var get_ET_maps4display=function(key){
  var get_ET_maps_per_month=function(yr){
       var et_img_sel=ETA_monthly_maps;
       ET_monthly_imgs=ee.List.sequence(1,12).map(function(m){
          var et_tmp0= et_img_sel.filter(ee.Filter.and(ee.Filter.calendarRange(yr, yr, 'year'),ee.Filter.calendarRange(m, m, 'month')));
          var et_tmp1= et_img_sel.filter(ee.Filter.and(ee.Filter.calendarRange(ee.Number(yr).subtract(1), ee.Number(yr).subtract(1), 'year'),ee.Filter.calendarRange(m, m, 'month')));
          var et_tmp=ee.ImageCollection(ee.Algorithms.If(ee.Number(m).gte(7),et_tmp1,et_tmp0));//agricultural year from July to June
          return ee.Image(ee.Algorithms.If(ee.Number(et_tmp.size()).eq(0),ee.Image().short(),et_tmp.first()))
            .set('Month',m)
            .rename('b1');
      });
  };
  var get_ET_maps_per_year=function(yr){
    get_ET_maps_per_month(yr);
    var ET_annual_img=ee.ImageCollection(ET_monthly_imgs).sum();
    return ET_annual_img.set('Year',yr).rename('ET');
  };
  var get_ETmaps4chart=function(yr){
    get_ET_maps_per_month(yr);
    return ET_monthly_imgs.map(function(img){
      var m=ee.Number(ee.Image(img).get('Month'));
      var yr0=ee.Number(ee.Algorithms.If(m.gte(7),ee.Number(yr).subtract(1),yr));
      return ee.Image(img).set('system:time_start',ee.Date.fromYMD(yr0,m,1).millis()).rename('ET')});
    };  
  ET_maps4chart=ee.ImageCollection(ee.List.sequence(hy_first_year,thisyear).map(get_ETmaps4chart).flatten());  
  ET_maps4display=ee.List.sequence(hy_first_year,thisyear).map(get_ET_maps_per_year);
};
var min_et_client=0; var max_et_client=1500;
get_ET_maps4display();
var cb1b=ui.Checkbox({value: false,style:{height: '31px',margin: '1px 1px 1px 1px'},onChange: function(key){
  cb2b.setValue(false,false); cb3b.setValue(false,false); cb8b.setValue(false,false);
  slider1b.setValue(1,false).setDisabled(false);
  mapVARselect='Evapotranspiration';
  task_click2(ET_maps4chart);
  satelliteMap.layers().set(1,ui.Map.Layer(ee.Image(ET_maps4display.get(ee.Number(year).subtract(hy_first_year))).clip(centeronthis.geometry().bounds(100)), {bands: ['ET'],min: min_et_client, max:max_et_client, palette: ["white","green"]},"Annual ET, Year " + year).setOpacity(1));    
  if (newfeature==1){
        //Legend parameters
        viz.palette=["white","green"];
        viz.max=max_et_client;
        viz.min=min_et_client;
        gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
        legend2Image = gradient.visualize(viz);
        legend2_max.setValue(viz.max + ' mm');
        thumbnail.setImage(legend2Image);
        if (right_selected===0){
          satelliteMap.remove(legend2);satelliteMap.add(legend2); 
        }
  right_selected=1;  satelliteMap.style().set('cursor', 'crosshair');
  if (rigthmapclick_on==1 && newfeature==1){
    click2_function_monthly(ET_maps4chart);
  }}
}});
var P_maps4display;var Pmaps4chart;  var P_monthly_imgs;
var get_Pmaps4display=function(){
  var get_P_maps_per_month=function(yr){
       P_monthly_imgs=ee.List.sequence(1,12).map(function(m){
          var P_tmp0= CHIRPS_pentad.filter(ee.Filter.and(ee.Filter.calendarRange(yr, yr, 'year'),ee.Filter.calendarRange(m, m, 'month'))).sum();
          var P_tmp1= CHIRPS_pentad.filter(ee.Filter.and(ee.Filter.calendarRange(ee.Number(yr).subtract(1), ee.Number(yr).subtract(1), 'year'),ee.Filter.calendarRange(m, m, 'month'))).sum();
          var P_tmp=ee.Image(ee.Algorithms.If(ee.Number(m).gte(7),P_tmp1,P_tmp0));//agricultural year from July to June
          return P_tmp.set('Month',m).rename('b1');
      });
  };
  var get_P_maps_per_year=function(yr){
    get_P_maps_per_month(yr);
    var P_annual_img=ee.ImageCollection(P_monthly_imgs).sum();
    return P_annual_img.set('Year',yr).rename('Precipitation');
  };
  var get_Pmaps4chart=function(yr){
    get_P_maps_per_month(yr);
    return P_monthly_imgs.map(function(img){
      var m=ee.Number(ee.Image(img).get('Month'));
      var yr0=ee.Number(ee.Algorithms.If(m.gte(7),ee.Number(yr).subtract(1),yr));
      return ee.Image(img).set('system:time_start',ee.Date.fromYMD(yr0,m,1).millis()).rename('Precipitation')});
    };  
  Pmaps4chart=ee.ImageCollection(ee.List.sequence(hy_first_year,thisyear).map(get_Pmaps4chart).flatten());  
  P_maps4display=ee.List.sequence(hy_first_year,thisyear).map(get_P_maps_per_year);
};
get_Pmaps4display();
var cb2b=ui.Checkbox({value: false,style:{height: '31px',margin: '1px 1px 1px 1px'},onChange: function(key){
  cb1b.setValue(false,false); cb3b.setValue(false,false); cb8b.setValue(false,false);
  slider1b.setValue(1,false).setDisabled(false);
  mapVARselect='Precipitation';
  task_click2(Pmaps4chart);  
  satelliteMap.layers().set(1,ui.Map.Layer(ee.Image(P_maps4display.get(ee.Number(year).subtract(hy_first_year))).clip(centeronthis.geometry().bounds(100)), {bands: ['Precipitation'],min: 0, max:1500, palette: ["white","blue"]},"Annual Precipitation, Year " + year).setOpacity(1));
  if (newfeature==1){
        //Legend parameters
        viz.palette=["white","blue"];
        viz.max=1500;
        viz.min=0;
        gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
        legend2Image = gradient.visualize(viz);
        legend2_max.setValue(viz.max + ' mm');
        thumbnail.setImage(legend2Image);
        if (right_selected===0){
          satelliteMap.remove(legend2);satelliteMap.add(legend2);
        }
  right_selected=1;
  satelliteMap.style().set('cursor', 'crosshair');
  if (rigthmapclick_on==1 && newfeature==1){
    click2_function_monthly(Pmaps4chart);
  }}
}});
//it is sufficient to generate the TBP maps only once
var get_TBP_maps_per_year=function(yr){
  var TBPcol=MODIS_npp.filter(ee.Filter.calendarRange(yr, yr, 'year'));
  var TBP=ee.Image(ee.Algorithms.If(TBPcol.size().gt(0),MODIS_npp.filter(ee.Filter.calendarRange(yr, yr, 'year')).first().select('Npp').multiply(0.0001).multiply(1000).multiply(22.2222).rename('b1'),
    ee.Image().double().rename('TBP')))
    .setDefaultProjection('EPSG:4326',null,MODIS_npp.first().projection().nominalScale());
  //var TBP=MODIS_npp.filter(ee.Filter.calendarRange(yr, yr, 'year')).first().select('Npp').multiply(0.0001).multiply(1000).multiply(22.2222).rename('b1');
  return TBP.set('Year',yr).set('system:time_start',ee.Date.fromYMD(yr,7,1).millis()).rename('Total_Biomass_Production');
};
var TBP4display=ee.List.sequence(hy_first_year,thisyear).map(get_TBP_maps_per_year);
var cb3b=ui.Checkbox({value: false,style:{height: '31px',margin: '1px 1px 1px 1px'},onChange: function(key){
  cb1b.setValue(false,false); cb2b.setValue(false,false); cb8b.setValue(false,false);
  slider1b.setValue(1,false).setDisabled(false);
  mapVARselect='Precipitation';
  task_click2(TBP4display); 
  satelliteMap.layers().set(1,ui.Map.Layer(ee.Image(TBP4display.get(ee.Number(year).subtract(hy_first_year))).clip(centeronthis.geometry().bounds(100)), {bands: ['Total_Biomass_Production'],min: 0, max:12000, palette:  ['white'].concat(legend_palette)},"Total_Biomass_Production, Year " + year).setOpacity(1));
  if (newfeature==1){
        //Legend parameters
        viz.palette=['white'].concat(legend_palette);
        viz.max=12000;
        viz.min=0;
        gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
        legend2Image = gradient.visualize(viz);
        legend2_max.setValue(viz.max + ' kgDM/ha/year');
        thumbnail.setImage(legend2Image);
        if (right_selected===0){
          satelliteMap.remove(legend2);satelliteMap.add(legend2);
        }
  right_selected=1;
  satelliteMap.style().set('cursor', 'crosshair');
  if (rigthmapclick_on==1 && newfeature==1){
    click2_function_monthly(TBP4display);
  }}
}});
///NDVI
var cc_threshold=30;
var sensor_data4NDVI=function(point){
    //Load the SENTINEL2 data   
    var all_s2 = ee.ImageCollection('COPERNICUS/S2_HARMONIZED').filterBounds(point)
      .filterDate(ee.Date.fromYMD(hy_first_year - 1,7,1), ee.Date.fromYMD(thisyear,7,1))
      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cc_threshold))
      .filter(ee.Filter.neq('GENERAL_QUALITY','FAILED'))
      .map(rename_sensing_time);
    //one image per day is enough 
  //var img_names_s2=all_s2.sort('system:time_start').aggregate_array('SENSING_TIME').distinct();
  //all_s2=ee.ImageCollection(img_names_s2.map(function(str){return all_s2.filter(ee.Filter.eq('SENSING_TIME',str)).first()}));
    return all_s2.map(gee_codes.addVariables_s2);
};
var cb8b=ui.Checkbox({value: false,style:{height: '31px',margin: '1px 1px 1px 1px'},onChange: function(key){
  cb1b.setValue(false,false); cb2b.setValue(false,false);
  slider1b.setValue(1,false).setDisabled(false);
  task_click2();
  mapVARselect='NDVI';
  satelliteMap.layers().set(1,ui.Map.Layer(ee.Image(greenest_1to12.get(ee.Number(year).subtract(hy_first_year))).clip(centeronthis.geometry()), {bands: ['NDVI'],min: 0, max:1, palette: ["white","green"]},"Annual max. NDVI, Year " + year).setOpacity(1));
  if (newfeature==1){
        //Legend parameters
        viz.palette=["white","green"];
        viz.max=1;
        viz.min=0;
        gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
        legend2Image = gradient.visualize(viz);
        legend2_max.setValue(viz.max);
        thumbnail.setImage(legend2Image);
        if (right_selected===0){
          satelliteMap.remove(legend2);satelliteMap.add(legend2); 
        }
  right_selected=1;  satelliteMap.style().set('cursor', 'crosshair');
  if (rigthmapclick_on==1 && newfeature==1){
    click2_function_monthly();
  }}
}});
var dataSelector = ui.Select({
  items: var_comparison,
  style: {minWidth: '80px'},
  onChange: function(key){
    checkbox_panel.clear();
    WBpanel.remove(checkbox_panel);
    WBpanel.widgets().set(4, checkbox_panel); 
    data_selected=key;
    //aoiisnew=1;//do as if a new aoi is selected, so that legends do not need to be removed and added again?
    bottomPanel1.remove(title_bottomPanel1);
    title_bottomPanel1.setValue(bottom_panel_notes);
    if (leftmapclick_on===0 && rigthmapclick_on===0){
      bottomPanel1.add(title_bottomPanel1);
    }
    if (key == 'Annual Evapotranspiration'){
      cb1b.setValue(true);
      //checkbox_panel.add(checkbox_ET.setValue(false,false));
      selectionPanel2.widgets().set(0,ui.Label('Annual ET', {fontWeight: 'bold', fontSize: '20px', margin: '1px 1px 1px 1px'}));
    } else if (key == 'Annual Precipitation'){
      cb2b.setValue(true);
      //checkbox_panel.add(checkbox_P.setValue(false,false));
      selectionPanel2.widgets().set(0,ui.Label('Annual Precipitation', {fontWeight: 'bold', fontSize: '20px', margin: '1px 1px 1px 1px'}));
    } else if (key == 'Total Biomass Production'){
      cb3b.setValue(true);
      //checkbox_panel.add(checkbox_P.setValue(false,false));
      selectionPanel2.widgets().set(0,ui.Label('Total Biomass Production', {fontWeight: 'bold', fontSize: '20px', margin: '1px 1px 1px 1px'}));
    } else if (key =='Annual Max. NDVI'){
      cb8b.setValue(true);
      selectionPanel2.widgets().set(0,ui.Label('Annual Max. NDVI', {fontWeight: 'bold', fontSize: '20px', margin: '1px 1px 1px 1px'}));
    }
    else {
      cb1b.setValue(false,false); cb2b.setValue(false,false); cb3b.setValue(false,false); cb8b.setValue(false,false);
      //cb1b.setValue(false,false); cb2b.setValue(false,false); cb3b.setValue(false,false); cb4b.setValue(false,false); cb5b.setValue(false,false); cb6b.setValue(false,false);
      //cb7b.setValue(false,false); cb8b.setValue(false,false); cb9b.setValue(false,false); cb10b.setValue(false,false); cb11b.setValue(false,false);
      slider1b.setDisabled(true);
      selectionPanel2.widgets().set(0,ui.Label('Map for Comparison', {fontWeight: 'bold', fontSize: '20px', margin: '1px 1px 1px 1px'}));
      right_selected=0;satelliteMap.remove(legend2);
      if (rigthmapclick_on==1 && newfeature==1){
        close_point();
      }
      // print('key dataSelector',key);
      satelliteMap.layers().get(1).setShown(false);
      satelliteMap.style().set('cursor', 'hand');
      satelliteMap.unlisten(rightmapclick);
    }
  },
});//.setPlaceholder('Please wait...').setDisabled(true);//uncomment when layers become available
// Create a SplitPanel which holds the linked maps side-by-side.
var splitPanel1 = ui.SplitPanel({
  secondPanel: satelliteMap,//panel4splitPanel3,
  wipe: true,
});
var panel4splitPanel1=ui.Panel(splitPanel1);
var bottom_panel_notes='Click on the map on the left side:'+
    '\n - Reservoirs: inspect terrain height changes at point of interest'+
    '\n - Irrigation Systems: select an irrigation system for water balance analysis'+
    '\n'+
    '\nClick on the map on the right side:'+
    '\n - Display time-series of selected dataset at point of interest (choose a map for comparison first)';
var title_bottomPanel1 = ui.Label({value: bottom_panel_notes, style : {whiteSpace: 'pre'}});
var bottomPanel1 = ui.Panel({ widgets : [title_bottomPanel1],  layout: ui.Panel.Layout.flow('vertical'),
  //style : {maxWidth: "1500px",height: "100px"},});
  style : {maxWidth: "1500px",maxHeight: "200px"},});
var splitPanel2 = ui.SplitPanel({
  firstPanel: panel4splitPanel1,
  secondPanel: bottomPanel1,//panel4splitPanel3,
  orientation: 'vertical', 
  wipe: false,
});
splitPanel2.getFirstPanel().style().set('height','85%');//set the initial height of the bottom panel: 15%
var middleMapPanel=ui.Panel();
//var mapChartSplitPanel = ui.SplitPanel(middleMapPanel, panel_outputs);
var mapChartSplitPanel = ui.SplitPanel(ui.Panel(splitPanel2), panel_outputs);
var linker = ui.Map.Linker([satelliteMap, middleMap]);
var click_state;
var todo_when_click=function(coords) {
  middleMap.style().set('cursor', 'hand');
  middleMap.unlisten(click_state);
  title_bottomPanel1.setValue('Please wait...');
  command_areas.filterBounds(ee.Geometry.Point(coords.lon, coords.lat)).evaluate(function(result){
    click_state=middleMap.onClick(todo_when_click);
    title_bottomPanel1.setValue(bottom_panel_notes);
    middleMap.style().set('cursor', 'crosshair');
    if (result.features.length===0){
      //click_state=middleMap.onClick(todo_when_click);
    } else {
      // print(result.features[0].properties.CNAME);
      irrg4sel.setValue(result.features[0].properties.CNAME);
      name_cmd_tmp=result.features[0].properties.CNAME;
    }
  });
};
var swipeStatus = true;
var swipeButtonLabel = 'Show swipe display';
if(swipeStatus) {
  swipeButtonLabel = 'Show side-by-side display';
}
var swipeButton = ui.Button(swipeButtonLabel, switchSwipe, null, {position: 'top-left', border: '1px solid black' });
function switchSwipe() {
  if(swipeStatus) {
    splitPanel1.setWipe(false);
    swipeButton.setLabel('Show swipe display');
    swipeStatus = false;
  } else {
    splitPanel1.setWipe(true);
    swipeButton.setLabel('Show side-by-side display');
    swipeStatus = true;
  }
}
var img_select_S2mosaic = ui.Select({
          items: [],
          style: {maxWidth: "240px"},
      }).setPlaceholder('Please wait...');
var mapComparison = ui.Panel([
  ui.Label({style: {backgroundColor: 'black',padding: '1px',width: '240px',height: '2px',margin: '15px 1px 1px 10px'}}),//nicebar
  ui.Label({
    value: 'MAP COMPARISON',
    style: {fontSize: '24px', fontWeight: 'bold',  margin: '15px 1px 10px 10px'}
  }),
  ui.Label({value: 'Select a dataset:'}),
  dataSelector,
  ui.Label({value: 'Select a satellite image:'}),
  img_select_S2mosaic,
  swipeButton,
]);
var comps = [];
comps.push( mapComparison);
comps.push( nicebar2);
comps.push( label_download);
comps.push( checkbox_download_panel);
var WBpanel = ui.Panel({ widgets : comps, style :  {position : "top-left",maxWidth: "260px"}});
var new_palette = ['white'].concat(palettes.colorbrewer.Paired[12]).concat(['#1fff26','cyan','magenta','grey','yellow','#4b69bc','#b69fbc','cyan']);
new_palette[4]=new_palette[7];
new_palette[7]='#33a02c';//green
//panel.add(wait_for_cropno);
var panel_tmp=ui.Panel({style: {maxWidth: "250px"}});
//Labels currently used for states without crop vegetation maps:
for (var i=1; i<=4; i++) {
  var j = i - 1;
  panel_tmp.add(ui.Panel([
      ui.Label({style: {backgroundColor: new_palette[i + 1],padding: '12px',width: '80px',height: '29px',margin: '7px 1px 1px 10px'}}).setValue( 'Class ' + (i + 1)),
    ], ui.Panel.Layout.Flow('horizontal')));
  panel_tmp.widgets().get(j).widgets().set(1,ui.Panel([
          ui.Label({style: {backgroundColor: '#f5f5f5',padding: '12px',width: '140px',height: '29px',margin: '7px 1px 1px 10px'}}).setValue( cropland_class_names[i + 1] ),
        ], ui.Panel.Layout.Flow('horizontal')));    
}
var panel_tmp_b=ui.Panel({style: {maxWidth: "250px"}});
//Labels currently used for Gujarat state:
for (var i=1; i<=8; i++) {
  var j = i - 1;
  panel_tmp_b.add(ui.Panel([
      ui.Label({style: {backgroundColor: new_palette[i],padding: '12px',width: '80px',height: '29px',margin: '7px 1px 1px 10px'}}).setValue( 'Class ' + (i)),
    ], ui.Panel.Layout.Flow('horizontal')));
  panel_tmp_b.widgets().get(j).widgets().set(1,ui.Panel([
          ui.Label({style: {backgroundColor: '#f5f5f5',padding: '12px',width: '140px',height: '29px',margin: '7px 1px 1px 10px'}}).setValue( cropland_class_names_b[i] ),
        ], ui.Panel.Layout.Flow('horizontal')));    
}
panel.add(panel_tmp);
panel.add(WBpanel);
///Plot RGB mosaic
var rename_sensing_time = function(image){
  return image.set({'SENSING_TIME': ee.Date(image.get('system:time_start')).format('YYYY-MM-dd')});
};
//load satellite data
var loadnewdata=function(year){  
  //Load the SENTINEL2 data   
  var all_s2 = ee.ImageCollection('COPERNICUS/S2_HARMONIZED').filterBounds(centeronthis.geometry())
    .filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),7,1), ee.Date.fromYMD(ee.Number(year),7,1))
    .map(rename_sensing_time);
   return all_s2.map(gee_codes.addVariables_s2).map(function(img){return ee.Image(img).set('Year',year)}).set('sensor_id',0);
};
var bands_s2 = ['Red', 'Green', 'Blue','NDVI'];//Sentinel-2 bands required for image vizualization
//time intervals for mosaics used for vizualization
var AGG_INTERVAL_S2 = 30; // Number of days to use to create the temporal composite (for display purposes)
var allyears_client_a = [];
for(var i = hy_first_year - 1; i <= thisyear; i++) {allyears_client_a.push(i)}
var allyears_client;//=allyears_client_a;
var allyears_client_b = allyears_client_a.slice(1);
var time_intervals_all=gee_codes.extract_time_ranges(allyears_client_a, AGG_INTERVAL_S2).iterate(function(list, previous){return ee.List(previous).cat(ee.List(list))},ee.List([]));
// print('time_intervals_all',time_intervals_all);
var plotsatelliteimage=function(){  
  var imgcol_composite_func = function(time_interval){
    var start_date = ee.List(time_interval).get(0);
    var end_date = ee.List(time_interval).get(1);
   // composites
    var ps_composite = sensor_data_4plotting.select(bands_s2)
    // requires checking if either time_end or time_start is contained in the date range
    .filter(ee.Filter.or(ee.Filter.dateRangeContains({leftValue: ee.DateRange(start_date, end_date), 
                                                      rightField: 'system:time_end'}),
                         ee.Filter.dateRangeContains({leftValue: ee.DateRange(start_date, end_date), 
                                                      rightField: 'system:time_start'})))
    .select(bands_s2)
    .qualityMosaic('NDVI')
    .rename(bands_s2);
    return ps_composite.set({'system:time_start': ee.Date(start_date).millis(), 'system:time_end': ee.Date(end_date).millis()})
      .set('BandN',ps_composite.bandNames().length());
  };
  var image_select =  ee.ImageCollection(ee.List(time_intervals_all).map(imgcol_composite_func)).sort('system:time_start').map(rename_sensing_time)
    .filterDate(ee.Date.fromYMD(hy_first_year - 1,7,1),ee.Date.fromYMD(thisyear,9,30));
  // print('image_select',image_select);
  //remove images with no bands (the collection only covers part of the year depending on season)
  image_select=image_select.filter(ee.Filter.neq('BandN',0));
  //looks for the most recent image
  var s2_initial=ee.Image(image_select.sort('system:time_start',false).toList(999).get(4));//.first();
  // print('s2_initial',s2_initial);
  var image_select_and_name=image_select.map(function(img){
    return ee.Image(img).set('Name',ee.String('Sentinel-2').cat(ee.String(" RGB, YEAR ")).cat(ee.Date(ee.Image(img).get('system:time_start')).format('YYYY')).cat(ee.String(", DOY "))
      .cat((ee.String('00').cat(ee.Date(ee.Image(img).get('system:time_start')).format('D'))).slice(-3))
      .cat(ee.String(' (')).cat(ee.Date(ee.Image(img).get('system:time_start')).format('d MMMM'))
      .cat(ee.String(')')));
  });
  //ui.select item for Sentinel-2 images
  var img_names=ee.ImageCollection(image_select_and_name).aggregate_array('Name');
  var img_list=ee.List(time_intervals_all).iterate(function(time_interval,prev){
    var start_date = ee.Date(ee.List(time_interval).get(0));
    var sensing_time=start_date.format('YYYY-MM-dd');
    var imgs=image_select.filter(ee.Filter.eq('SENSING_TIME',sensing_time));
    var imgname=ee.String('Sentinel-2').cat(ee.String(" RGB, YEAR ")).cat(start_date.format('YYYY')).cat(ee.String(", DOY "))
      .cat((ee.String('00').cat(start_date.format('D'))).slice(-3))
      .cat(ee.String(' (')).cat(start_date.format('d MMMM'))
      .cat(ee.String(')'));
    return ee.Algorithms.If(imgs.size().gt(0),ee.List(prev).add(imgname),ee.List(prev));
  },ee.List([]));
  //print('img_list',img_list);
  var label_part2=' RGB, May ' + thisyear;
    var label_leftmap=  ui.Label('Sentinel-2' + label_part2);
    img_list.evaluate(function(result2){
      // print('label_leftmap',label_leftmap);
      img_select_S2mosaic.items().reset(result2);
      img_select_S2mosaic.onChange(function(key){
          var img1 = ee.Image(image_select_and_name.filter(ee.Filter.eq('Name', key)).first());//
          // print('selected image',ee.Image(image_select_and_name.filter(ee.Filter.eq('Name', key)).first()));
          satelliteMap.layers().set(0,ui.Map.Layer(img1.select(bands_s2),{bands: ['Red', 'Green', 'Blue'],min:0,max:2200},"Sentinel-2 image"));
      });
      img_select_S2mosaic.setPlaceholder('Sentinel-2' + label_part2);
    });
  //});
  var showRS= ui.util.debounce( function() {//debounce, to make sure it gets plotted after the crop map
    satelliteMap.layers().set(0,ui.Map.Layer(s2_initial.select(bands_s2),{bands: ['Red', 'Green', 'Blue'],min:0,max:2200},"Sentinel-2 image"));
    satelliteMap.layers().set(2,ui.Map.Layer(dd,null,'Area of Interest'));
    img_select_S2mosaic.setValue(null,false);
  },200);
    showRS();
};
///TRENDLINE SCATTERPLOTS  
var set_options_trend1=function(){
  var options_trend={
      hAxis: {titleTextStyle:{fontSize: 10},viewWindowMode: 'maximized',textStyle:{fontSize: 10},format:'####',ticks: allyears_client},
      trendlines: {
          0: {color: '00FF00',labelInLegend: 'Trendline',
                        showR2: true,
                        lineWidth: 4,
                        opacity: 0.2,
                        visibleInLegend: true}
        },
      lineWidth: 1,
      pointSize: 2,
      legend: {position:"top",textStyle:{fontSize: 10}},
      fontSize: 22,
      series: {0: {color: '00FF00',pointShape: 'diamond',labelInLegend: 'Annual Values'}}, 
      vAxes: {0: {title: title_multi_annual,titleTextStyle:{fontSize: 12},textStyle:{fontSize: 10}}},
      vAxis: {gridlines: { count: 0 }}
    };
  return options_trend;
};
var set_options_trend2=function(){
  var options_trend={
      hAxis: {titleTextStyle:{fontSize: 10},viewWindowMode: 'maximized',textStyle:{fontSize: 10},format:'####',ticks: allyears_client_b},
      legend: {position:"top",textStyle:{fontSize: 10}},
      fontSize: 22,
      vAxes: {0: {title: title_multi_annual,titleTextStyle:{fontSize: 12},textStyle:{fontSize: 10}}},
      vAxis: {gridlines: { count: 0 }}
    };
  return options_trend;
};
  //WEEKLY AVERAGES
var getweeklyLevels=function(daily_levels){  
    var annual_levels=ee.List.sequence(ts_first_year, ts_last_year).map(function(year) {
      var weekly_levels0=ee.List.sequence(1,53).map(function(weeks) {
        var date0=ee.Date.fromYMD(ee.Number(year),1,1);
        var collection_Levels=daily_levels.filter(ee.Filter.calendarRange(ee.Number(year),ee.Number(year), 'year'))
              .filterDate(date0.advance(ee.Number(weeks).subtract(1),'week'), date0.advance(ee.Number(weeks),'week'))      ;
        var col_mean= ee.Feature(null,{'hweekly':collection_Levels.reduceColumns(ee.Reducer.mean()).get('mean'),'system:time_start': date0.advance(ee.Number(weeks).subtract(1),'week')});    
        var col_empty=ee.Feature(null).set('hweekly',-99).set('system:time_start',date0.advance(ee.Number(weeks).subtract(1),'week'));    
        return ee.Feature(ee.Algorithms.If(collection_Levels.size().eq(0),col_empty,col_mean));
      });
      return weekly_levels0;
    });
    return annual_levels.flatten();
};  
  //MONTHLY LONG-TERM AVERAGE AREAS
var getmonthlyAreas=function(daily_areas){  
    var annual_areas=ee.List.sequence(ts_first_year, ts_last_year).map(function(year) {
      var monthly_areas0=ee.List.sequence(1,12).map(function(month) { //4,10
        var collection_Areas=daily_areas.filter(ee.Filter.calendarRange(ee.Number(year),ee.Number(year), 'year'))
        .filter(ee.Filter.calendarRange(ee.Number(month),ee.Number(month), 'month'));
        var col_mean= ee.Feature(null,{'amonthly':collection_Areas.reduceColumns(ee.Reducer.median(),['area_water']).get('median'),'system:time_start': ee.Date.fromYMD(ee.Number(year), ee.Number(month), 15),'month':ee.Number(month)});    
        var col_empty=ee.Feature(null).set('system:time_start',ee.Date.fromYMD(ee.Number(year), ee.Number(month), 1)).set('month',ee.Number(month));    
        return ee.Feature(ee.Algorithms.If(collection_Areas.size().eq(0),col_empty,col_mean));
      });
      return monthly_areas0;
    });
    var monthly_area=ee.List.sequence(1,12).map(function(month) {
      var col=ee.FeatureCollection(annual_areas.flatten()).filter(ee.Filter.eq('month',ee.Number(month)));
      var yr=ee.Algorithms.If(ee.Number(month).gte(7),ee.Number(year).subtract(1),year);
      var col_median= ee.Feature(null,{'amonthly':col.reduceColumns(ee.Reducer.mean(),['amonthly']).get('mean'),
        'system:time_start': ee.Date.fromYMD(ee.Number(yr), ee.Number(month), 15),'month':ee.Number(month)});    
      return col_median;
    });
    return monthly_area;
};
var getbimonthlyAreas=function(daily_areas){  
  var monthly_areas0=ee.List(gee_codes.extract_time_ranges(ee.List.sequence(2015, 2022), 10).iterate(function(list, previous){return ee.List(previous).cat(ee.List(list))},ee.List([])))
  .map(function(time_range) { //4,10
    time_range=ee.List(time_range);
      var start_date = ee.Date(time_range.get(0));
      var end_date = ee.Date(time_range.get(1));
    var collection_Areas=daily_areas.filterDate(start_date, end_date);
    var col_mean= ee.Feature(null,{'amonthly':collection_Areas.reduceColumns(ee.Reducer.mean(),['area_water']).get('mean'),'system:time_start': start_date});    
    var col_empty=ee.Feature(null).set('system:time_start',start_date);    
    return ee.Feature(ee.Algorithms.If(collection_Areas.size().eq(0),col_empty,col_mean));
  });
  return monthly_areas0;
};
  //MONTHLY LONG-TERM AVERAGE LEVELS
var getmonthlyLevels=function(daily_levels){  
    var annual_levels=ee.List.sequence(ts_first_year, ts_last_year).map(function(year) {
      var monthly_levels0=ee.List.sequence(1,12).map(function(month) { //4,10
        var collection_Levels=daily_levels.filter(ee.Filter.calendarRange(ee.Number(year),ee.Number(year), 'year'))
        .filter(ee.Filter.calendarRange(ee.Number(month),ee.Number(month), 'month'));
        var level=ee.Number(collection_Levels.reduceColumns(ee.Reducer.median(),['dem_elev']).get('median'));
        level=ee.Number(ee.Algorithms.If(ee.Algorithms.IsEqual(level,null),-99,level));
        var outofbounds=ee.Number(ee.Algorithms.If(level.lt(ee.Number(dem_thislake.get('min_elev_perc_fit'))),1,0));            
        var col_mean= ee.Feature(null,{'hmonthly':level,'system:time_start': ee.Date.fromYMD(ee.Number(year), ee.Number(month), 15)
          ,'month':ee.Number(month),'year':ee.Number(year),'outofbounds':outofbounds});    
        var col_empty=ee.Feature(null).set('system:time_start',ee.Date.fromYMD(ee.Number(year), ee.Number(month), 1)).set('month',ee.Number(month)).set('year',ee.Number(year));    
        return ee.Feature(ee.Algorithms.If(collection_Levels.size().eq(0),col_empty,col_mean));
      });
      return monthly_levels0;
    });
    var monthly_level=ee.List.sequence(1,12).map(function(month) {
      var col=ee.FeatureCollection(annual_levels.flatten()).filter(ee.Filter.eq('month',ee.Number(month)));
      var outofbounds_sum=ee.Number(col.aggregate_array('outofbounds').reduce(ee.Reducer.sum()));
      var yr=ee.Algorithms.If(ee.Number(month).gte(7),ee.Number(year).subtract(1),year);
      var col_median= ee.Feature(null,{'hmonthly':col.reduceColumns(ee.Reducer.mean(),['hmonthly']).get('mean'),'outofbounds_sum':outofbounds_sum,
        'system:time_start': ee.Date.fromYMD(ee.Number(yr), ee.Number(month), 15),'month':ee.Number(month)});    
      return col_median;
    });
    return monthly_level;
};  
var getbimonthlyLevels=function(daily_levels){  
  var monthly_levels0=ee.List(gee_codes.extract_time_ranges(ee.List.sequence(2015, 2022), 10).iterate(function(list, previous){return ee.List(previous).cat(ee.List(list))},ee.List([])))
  .map(function(time_range) { //4,10
    time_range=ee.List(time_range);
      var start_date = ee.Date(time_range.get(0));
      var end_date = ee.Date(time_range.get(1));
    var collection_Areas=daily_levels.filterDate(start_date, end_date);
    var col_mean= ee.Feature(null,{'hmonthly':collection_Areas.reduceColumns(ee.Reducer.mean(),['dem_elev']).get('mean'),'system:time_start': start_date});    
    var col_empty=ee.Feature(null).set('system:time_start',start_date);    
    return ee.Feature(ee.Algorithms.If(collection_Areas.size().eq(0),col_empty,col_mean));
  });
  return monthly_levels0;
};
//MONTHLY MEDIAN WATER LEVELS
var getmonthlyAnomalies=function(daily_levels){   
    var annual_levels=ee.List.sequence(ts_first_year, ts_last_year).map(function(year) {
      var monthly_levels0=ee.List.sequence(1,12).map(function(months) {
        var date0=ee.Date.fromYMD(ee.Number(year),1,1);
        var collection_Levels=daily_levels.filter(ee.Filter.calendarRange(ee.Number(year),ee.Number(year), 'year'))
              .filterDate(date0.advance(ee.Number(months).subtract(1),'month'), date0.advance(ee.Number(months),'month'));
        var level=collection_Levels.reduceColumns(ee.Reducer.median(),ee.List(['dem_elev']));
        level=ee.Number(ee.Algorithms.If(ee.Algorithms.IsEqual(level,null),-99,level.get('median')));
        /*var outofbounds=ee.Number(ee.Algorithms.If(level.gt(ee.Number(dem_thislake.get('max_elev_perc_fit'))),1,
          ee.Number(ee.Algorithms.If(level.lt(ee.Number(dem_thislake.get('min_elev_perc_fit'))),1,0))));*/
        var outofbounds=ee.Number(ee.Algorithms.If(level.lt(ee.Number(dem_thislake.get('min_elev_perc_fit'))),1,0));
        var outofbounds_sum=ee.Number(long_term_average.filter(ee.Filter.eq('month',ee.Number(months))).first().get('outofbounds_sum'));
        //outofbounds=ee.Number(ee.Algorithms.If(outofbounds.gt(0),1,0));
        var col_mean= ee.Feature(null,{'year':year,'month':months,
//        'hmonthly':level.subtract(ee.Number(long_term_average.filter(ee.Filter.eq('month',ee.Number(months))).first().get('hmonthly'))),
        'hmonthly':level,
        'system:time_start': date0.advance(ee.Number(months).subtract(1),'month')})
        .set('outofbounds_sum',outofbounds_sum)
        .set('outofbounds',outofbounds);    
        var col_empty=ee.Feature(null).set('year',year).set('hmonthly',-99).set('month',months)
          .set('system:time_start',date0.advance(ee.Number(months).subtract(1),'month'));    
        return ee.Feature(ee.Algorithms.If(collection_Levels.size().eq(0),col_empty,col_mean));
      });
      return monthly_levels0;
    });
    return annual_levels.flatten();
};
//MONTHLY MEDIAN WATER AREAS
var getmonthlyAnomalies2=function(daily_areas){   
    var annual_areas=ee.List.sequence(ts_first_year, ts_last_year).map(function(year) {
      var monthly_areas0=ee.List.sequence(1,12).map(function(months) {
        var date0=ee.Date.fromYMD(ee.Number(year),1,1);
        var collection_areas=daily_areas.filter(ee.Filter.calendarRange(ee.Number(year),ee.Number(year), 'year'))
              .filterDate(date0.advance(ee.Number(months).subtract(1),'month'), date0.advance(ee.Number(months),'month'));
        var area=collection_areas.reduceColumns(ee.Reducer.median(),ee.List(['area_water']));
        area=ee.Number(ee.Algorithms.If(ee.Algorithms.IsEqual(area,null),-99,area.get('median')));
        var col_mean= ee.Feature(null,{'year':year,'month':months,
        'hmonthly':area,
        'system:time_start': date0.advance(ee.Number(months).subtract(1),'month')})
        .set('outofbounds_sum',0)
        .set('outofbounds',0); 
        var col_empty=ee.Feature(null).set('year',year).set('hmonthly',-99).set('month',months)
          .set('system:time_start',date0.advance(ee.Number(months).subtract(1),'month'));    
        return ee.Feature(ee.Algorithms.If(collection_areas.size().eq(0),col_empty,col_mean));
      });
      return monthly_areas0;
    });
    return annual_areas.flatten();
};  
//Oct to May, not excluding months which are out of bounds
var getannualLevels1=function(monthly_levels){  
    var annual_levels=ee.List.sequence(ts_first_year, ts_last_year).map(function(year) {
        var date0=ee.Date.fromYMD(ee.Number(year),1,1);
        var collection_Levels1=monthly_levels.filter(ee.Filter.calendarRange(ee.Number(year),ee.Number(year), 'year'))
          .filter(ee.Filter.lte('month', 5))//dry season ends in May?
          .filter(ee.Filter.gt('hmonthly', -99));
        var collection_Levels2=monthly_levels.filter(ee.Filter.calendarRange(ee.Number(year).subtract(1),ee.Number(year).subtract(1), 'year'))
          .filter(ee.Filter.gte('month', 11))//dry season starts in Nov
          .filter(ee.Filter.gt('hmonthly', -99));
        var collection_Levels=ee.FeatureCollection([collection_Levels1,collection_Levels2]).flatten();
        var col_mean= ee.Feature(null,{'year':year,'value':collection_Levels.reduceColumns(ee.Reducer.mean(),['hmonthly']).get('mean'),'system:time_start': date0});    
        var col_empty=ee.Feature(null).set('year',year).set('value',-99).set('year',year).set('system:time_start',date0);    
        return ee.Feature(ee.Algorithms.If(collection_Levels.size().eq(0),col_empty,col_mean));
      });
    return annual_levels.flatten();
};  
//Per Trimester
var getSeasonalLevels=function(monthly_levels,x){  
    var annual_levels=ee.List.sequence(ts_first_year, ts_last_year).map(function(year) {
        var month_start=(ee.Number(x).subtract(1)).multiply(3).add(1);
        var month_end=(ee.Number(x).subtract(1)).multiply(3).add(3);
        var date0=ee.Date.fromYMD(ee.Number(year),1,1);
        var collection_Levels1=monthly_levels.filter(ee.Filter.calendarRange(ee.Number(year),ee.Number(year), 'year'))
          .filter(ee.Filter.rangeContains('month',month_start,month_end))
          .filter(ee.Filter.gt('hmonthly', -99));
        var collection_Levels=collection_Levels1;
        var col_mean= ee.Feature(null,{'year':year,'value':collection_Levels.reduceColumns(ee.Reducer.mean(),['hmonthly']).get('mean'),'system:time_start': date0});    
        var col_empty=ee.Feature(null).set('year',year).set('value',-99).set('year',year).set('system:time_start',date0);    
        return ee.Feature(ee.Algorithms.If(collection_Levels.size().eq(0),col_empty,col_mean));
      });
    return annual_levels.flatten();
};
var listofvariables0=['value','value','value','value','value','cropping intensity','Annual Rainfall','Annual ET','Seasonal Rainfall','Seasonal ET',['Kharif Crop Area','Rabi Crop Area','Zaid Crop Area']
  ,'Crop Area','Annual Storage Change','Seasonal Storage Change','Annual Biomass Production'];
var get_multiannual_values=function(x){  
    var dictwithvalues=ee.List([]);
    allyears_client=allyears_client_b;
    for (var year=hy_first_year; year<=ts_last_year; year++) {
      var listwithvalues;
      if (x < 12){
        task2(name_cmd,rRscale,rRtileScale,year,11,5);//always consider Nov-May
      } else {
        task_storage(ee.Date.fromYMD(year - 1,11,1),ee.Date.fromYMD(year,6,1),year);
      }
      //alternatively compute all variables together whenever a new command area is selected
      title_multi_annual='[M m³]';
      if (x==5){
        title_multi_annual='[%]';
        listwithvalues=ee.List([{'cropping intensity':avg_cropping_intensity}]);
      } else if (x==6){
       listwithvalues=ee.List([{'Annual Rainfall':vol_p_annual.divide(1000000)}]);
      } else if (x==7){
        listwithvalues=ee.List([{'Annual ET':vol_et_annual.divide(1000000)}]);
      } else if (x==8){
        listwithvalues=ee.List([{'Seasonal Rainfall':vol_p.divide(1000000)}]);
      } else if (x==14){
        title_multi_annual='Dry Tonnes per year';
        listwithvalues=ee.List([{'Annual Biomass Production':tot_tbp.divide(1000)}]);
      } else if (x==9){
        listwithvalues=ee.List([{'Seasonal ET':vol_et.divide(1000000)}]);
      } else if (x==10){
        title_multi_annual='[ha]';
        listwithvalues=ee.List([{            
          'Kharif Crop Area':total_Kharif_area,
          'Rabi Crop Area': total_Rabi_area,
          'Zaid Crop Area':total_Zaid_area}]);
      } else if (x==11){
        title_multi_annual='[ha]';
        listwithvalues=ee.List([{'Crop Area':total_crop_area}]);
      } else if (x==12){
        listwithvalues=ee.List([{'Annual Storage Change':volchange_annual.multiply(-1).divide(1000000)}]);
      } else if (x==13){
        listwithvalues=ee.List([{'Seasonal Storage Change':volchange_seasonal.divide(1000000)}]);
      }
      dictwithvalues=dictwithvalues.add(listwithvalues);
      //print('value2add',ee.Number(listofvariables.get(x)));
    }
    // print('dictwithvalues',dictwithvalues);
    /*var collection_levels=ee.Number(ee.Feature(null,ee.List(dictwithvalues.get(0)).flatten().get(0)).get(listofvariables0[x]));
    print('collection_levels',collection_levels);
    var col_mean= ee.Feature(null,{'year':year}).set(listofvariables0[x],collection_levels);    
    print('col_mean',col_mean);*/
    // print(ee.Feature(ee.List([listofvariables0[x]]).flatten().iterate(
    //   function(x,previous){return ee.Feature(previous).set(ee.String(x),ee.Feature(null,ee.List(dictwithvalues.get(0)).flatten().get(0)).get(ee.String(x)))},
    //   ee.Feature(null))));//three values
      var annual_levels=ee.List.sequence(hy_first_year, ts_last_year).map(function(year) {
        var date0=ee.Date.fromYMD(ee.Number(year),1,1);
        var col_mean=ee.Feature(ee.List([listofvariables0[x]]).flatten().iterate(
          function(x1,previous){return ee.Feature(previous).set(ee.String(x1),ee.Feature(null,ee.List(dictwithvalues.get(ee.Number(year).subtract(hy_first_year))).flatten().get(0)).get(ee.String(x1)))},
          ee.Feature(null,{'year':year,'system:time_start': date0})));
        //var col_mean= ee.Feature(null,{'year':year,/*'value':collection_Levels,*/'system:time_start': date0}).set(listofvariables0[x],collection_levels);    
        return col_mean;
      });
    // print('annual_levels',annual_levels);
    return annual_levels/*.flatten()*/;
};
function print_and_plot_trend(input_ts,x,plot,aoi){
  var monthly_anomalies=ee.FeatureCollection(input_ts);
  var reducerSensSlope=ee.Reducer.sensSlope();
  title_multi_annual=title_multi_annual_tmp;
  allyears_client=allyears_client_a;
  if (x===0){
    annual_average_S2=ee.FeatureCollection(getannualLevels1(monthly_anomalies)).filter(ee.Filter.gt('value', -99));
  } else if (x<=4) {
    annual_average_S2=ee.FeatureCollection(getSeasonalLevels(monthly_anomalies,x))
      .filter(ee.Filter.gt('value', -99));
  } else {
    annual_average_S2=ee.FeatureCollection(get_multiannual_values(x));
  }
  /*var coll=ee.ImageCollection(annual_average_S2.map(function(feat){
    //Mann-Kendall algorithm has problems with ties. Therefore add a random number with the year as a seed.
    return ee.Image(ee.Number(ee.Feature(feat).get('value')).multiply(100000)).round().add(ee.Image.random(ee.Number(ee.Feature(feat).get('year'))).multiply(ee.Image(100)).round()).clip(area_of_interest)
    .set('system:time_start',ee.Date(ee.Feature(feat).get('system:time_start')).millis());
  }));*/
  //sensslope = annual_average_S2.reduceColumns(reducerSensSlope, ['year','value']).get('slope');
  //pvalue = annual_average_S2.reduceColumns(ee.Reducer.pearsonsCorrelation(), ['year','value']).get('p-value');
  //pvalue = ee.Number(ee.Image(morefunctions.kendallpvalue(coll)).reduceRegion(ee.Reducer.mean(),aoi,100).get('constant'));
  if (plot){
    //print('annual_average_S2',annual_average_S2.aggregate_array('value'));  
    //print('Levels Trimester',x,'Sensslope:',sensslope,'pvalue',pvalue);
    var plot_multiannual = ui.Chart.feature.byFeature(annual_average_S2, 'year',[].concat.apply([], [listofvariables0[x]]))
    //[/*'value'*/listofvariables0[x]])//
        .setChartType('ScatterChart')
        .setOptions(set_options_trend1());
    if (x==10){
      plot_multiannual = ui.Chart.feature.byFeature(annual_average_S2, 'year',[].concat.apply([], [listofvariables0[x]]))
        .setChartType('ColumnChart')
        .setOptions(set_options_trend2());
    }
    //print(plot_multiannual);      
    panel_trend.widgets().set(2,plot_multiannual); 
  }
}
var feat_centroids; var feat_all_centroids;
var feat_missing_centroids;
var plot_centroids=function(x){
  middleMap.layers().set(8, ui.Map.Layer(feat_centroids.filter(ee.Filter.and(ee.Filter.eq('Type','Reservoir'),ee.Filter.lte('AREA_HA',1000))),{color: 'red',pointShape:'star6',pointSize:5,fillColor : 'white'}, "Reservoirs small").setShown(true));
  middleMap.layers().set(7, ui.Map.Layer(feat_missing_centroids.filter(ee.Filter.and(ee.Filter.eq('Type','Reservoir'),ee.Filter.lte('AREA_HA',1000))),{color: '#ffa5a5',pointShape:'star6',pointSize:5,fillColor : 'white'}, "Reservoirs small, wo. level data").setShown(true));
  middleMap.layers().set(6, ui.Map.Layer(feat_centroids.filter(ee.Filter.and(ee.Filter.eq('Type','Lake'),ee.Filter.lte('AREA_HA',1000))),{color: 'blue',pointShape:'star6',pointSize:5,fillColor : 'white'}, "Lakes small").setShown(true));
  middleMap.layers().set(5, ui.Map.Layer(feat_missing_centroids.filter(ee.Filter.and(ee.Filter.eq('Type','Lake'),ee.Filter.lte('AREA_HA',1000))),{color: 'cyan',pointShape:'star6',pointSize:5,fillColor : 'white'}, "Lakes small, wo. level data").setShown(true));
  middleMap.layers().set(3, ui.Map.Layer(feat_centroids.filter(ee.Filter.and(ee.Filter.eq('Type','Reservoir'),ee.Filter.gt('AREA_HA',1000))).style({color: 'red',pointSize:10}),{}, "Reservoirs large").setShown(true));
  middleMap.layers().set(1, ui.Map.Layer(feat_missing_centroids.filter(ee.Filter.and(ee.Filter.eq('Type','Reservoir'),ee.Filter.gt('AREA_HA',1000))).style({color: '#ffa5a5',pointSize:10}),{}, "Reservoirs large, wo. level data").setShown(true));
  middleMap.layers().set(2, ui.Map.Layer(feat_centroids.filter(ee.Filter.and(ee.Filter.eq('Type','Lake'),ee.Filter.gt('AREA_HA',1000))).style({color: 'blue',pointSize:10}),{}, "Lakes large").setShown(true));
  middleMap.layers().set(0, ui.Map.Layer(feat_missing_centroids.filter(ee.Filter.and(ee.Filter.eq('Type','Lake'),ee.Filter.gt('AREA_HA',1000))).style({color: 'cyan',pointSize:10}),{}, "Lakes large, wo. level data").setShown(true));
};
var plot_centroids0=function(x){
  var pvalue_select='pvalue' + x;
  var trend_select='trend' + x;
  var feat_centroids_neg=feat_centroids.filter(ee.Filter.and(ee.Filter.lte(pvalue_select, 0.1),ee.Filter.lt(trend_select, 0)));
  var feat_centroids_pos=feat_centroids.filter(ee.Filter.and(ee.Filter.lte(pvalue_select, 0.1),ee.Filter.gt(trend_select, 0)));
  var feat_centroids_neutral=feat_centroids.filter(ee.Filter.gt(pvalue_select, 0.1));
  var centroids_neutral=ee.Geometry.MultiPoint(ee.List.sequence(0,feat_centroids_neutral.size().subtract(1)).map(function(x){return ee.Feature(feat_centroids_neutral.toList(999).get(ee.Number(x))).geometry()}));
  var centroids_pos=ee.Geometry.MultiPoint(ee.List.sequence(0,feat_centroids_pos.size().subtract(1)).map(function(x){return ee.Feature(feat_centroids_pos.toList(999).get(ee.Number(x))).geometry()}));
  var centroids_neg=ee.Geometry.MultiPoint(ee.List.sequence(0,feat_centroids_neg.size().subtract(1)).map(function(x){return ee.Feature(feat_centroids_neg.toList(999).get(ee.Number(x))).geometry()}));
  middleMap.layers().set(4, ui.Map.Layer(centroids_neg,{color: 'red',pointShape:'star6',pointSize:5,fillColor : 'white'}, "Negative1").setShown(true));
  middleMap.layers().set(2, ui.Map.Layer(centroids_pos,{color: 'blue',pointShape:'star6',pointSize:5,fillColor : 'white'}, "Positive1").setShown(true));
  middleMap.layers().set(0, ui.Map.Layer(centroids_neutral,{color: 'black',pointShape:'star6',pointSize:5,fillColor : 'white'}, "Neutral Centroids").setShown(true));
};
var season_labels=['Dry Season (Nov-May)','January-March','April-June','July-September','October-December'];
var season_overall;
var select_season = ui.Panel([
  ui.Label('○', {color:'black', fontWeight: '1000',fontSize: '18px', margin: '12px 3px 0px 1px'}),
  ui.Label('Size ≤ 1000 ha', {fontSize: '14px', margin: '16px 3px 0px 1px'}),
  ui.Label('○', {color:'black', fontWeight: '600',fontSize: '40px', margin: '0px 3px 0px 1px'}),
  ui.Label('Size > 1000 ha', {fontSize: '14px', margin: '16px 1px 0px 1px'})
  ],ui.Panel.Layout.Flow('horizontal'));
var trend_panel = ui.Panel([ui.Label('Water Bodies available for Selection:', {fontSize: '14px',fontWeight: '600', margin: '1px 10px 1px 1px'})], ui.Panel.Layout.Flow('vertical'));
var trend_neg_panel=ui.Panel([
  ui.Label('●', {color:'red', fontWeight: '600',fontSize: '18px', margin: '0px 3px 0px 1px'}),
  ui.Label('Reservoirs  (', {fontSize: '14px', margin: '4px 3px 0px 1px'}),
  ui.Label('●', {color:'#ffa5a5', fontWeight: '600',fontSize: '18px', margin: '0px 3px 0px 1px'}),
  ui.Label('water levels not available) ', {fontSize: '14px', margin: '4px 1px 0px 1px'})
  ], ui.Panel.Layout.Flow('horizontal'));
trend_panel.add(trend_neg_panel);
//
var trend_pos_panel=ui.Panel([
  ui.Label('●', {color:'blue', fontWeight: '600',fontSize: '18px', margin: '0px 3px 0px 1px'}),
  ui.Label('Lakes  (', { fontSize: '14px', margin: '4px 7px 0px 1px'}),
  ui.Label('●', {color:'cyan', fontWeight: '600',fontSize: '18px', margin: '0px 3px 0px 1px'}),
  ui.Label('water levels not available) ', {fontSize: '14px', margin: '4px 1px 0px 1px'})
  ], ui.Panel.Layout.Flow('horizontal'));
trend_panel.add(trend_pos_panel);
trend_panel.add(select_season);
var trend_neutral_panel=ui.Panel([ui.Label('●', {color:'black', fontWeight: '600',fontSize: '18px', margin: '0px 3px 0px 1px'}),
  ui.Label('No significant Trend', { fontSize: '14px', margin: '4px 1px 0px 1px'})
  ], ui.Panel.Layout.Flow('horizontal'));
/////////////////////////////////////////////////////////  
var year=thisyear;
//selection of States in Main Menu
var select_adm0 = ui.Select({items: state_list}).setPlaceholder('Select a State ...'); 
var comps= ui.Panel();
var state_name;
//USER INPUT: YEAR FOR STARTING SCREEN (attention, further modifications in code required)
var start_date = ee.Date.fromYMD(thisyear - 1,7,1);
var end_date = ee.Date.fromYMD(thisyear, 7,1);
//USER INPUT:cloud and nodata thresholds
//comps.add(select_year);
comps.add(header);
var comps_first= ui.Panel();
comps_first.add(header_first);
comps.add(select_adm0);
var selectPanel = ui.Panel({ widgets : [comps],layout: ui.Panel.Layout.flow('vertical'), style :{position : "top-left",maxWidth: "250px"}});
var Logo_HydroSolutions= ee.Image("projects/ee-hsol/assets/logo_hsol_projected").resample('bicubic').resample('bicubic');
var Logo2= ee.Image("projects/ee-hsol/assets/SaWeL_logo_projected").resample('bicubic').resample('bicubic');
var logo_hsol=ui.Thumbnail({
  image:Logo_HydroSolutions,//,
  params:{bands:['b1','b2','b3'],
  min:0,max:255},
  style:{width:'90px',height:'auto', margin: 'auto'}});
var Logos_PANEL=ui.Panel({
    style: {
    width: '110px',
    height: 'auto',
    padding: '10px',
    position: 'bottom-right'
    },
    widgets:[logo_hsol,hydrosolutions]
  });
//middleMap.add(sliderPanel);
year_list.evaluate(function(years) {
      select_year.items().reset(years); 
});
var start_redraw=0;
function select_another_date(keyD){
  csv2export=csv2export.filter(ee.Filter.and(ee.Filter.neq('1_Type','Annual Water Balance'),
    ee.Filter.neq('1_Type','Crop Analysis'),ee.Filter.neq('1_Type','Rabi Season Water Balance')
    ));
  year=keyD;
  middleMap.remove(img_select_s2);
  //middleMap.remove(legend);
  if (year >= hy_first_year && start_redraw!==1){
    middleMap.add(img_select_s2);
  }
  start_date = ee.Date.fromYMD(keyD - 1,7,1);
  end_date = ee.Date.fromYMD(keyD, 7,1);
  if (start_redraw!==1){//start_redraw==1 --> means selecting another year before selecting a water body. not possible in current app
    newfeature=0;
    iteration_id=iteration_id + 1;
    get_new_s2();
    panel_thisyear.clear();
    get_annual_ts();
    /*sliderPanel.clear();
    sliderPanel.widgets().set(0,ui.Label('Opacity', {fontWeight: '450', fontSize: '14px', margin: '1px 1px 1px 1px'}));
    sliderPanel.add(sliderPanel_base); */
    //start_l8=0;
    start_s2=0;
    for (var i=4; i<9; i++) {
      middleMap.layers().get(i).setShown(false);
    }
    slider2.setValue(0,false); slider1.setValue(0,false); slider3.setValue(0,false);slider4.setValue(1,false);
    middleMap.layers().set(9, ui.Map.Layer(dd,null, "area_of_interest"));
    //update the map for comparison
    aoiisnew=0;
    cb1b.setValue(false,false); cb2b.setValue(false,false); cb3b.setValue(false,false); cb8b.setValue(false,false);
    dataSelector.setValue(null,false);
    dataSelector.setValue(data_selected);
    //if (h_av==1){
      task_storage_a();task_storage(date_of_max_level,date_of_min_level,year);task_storage_b();
    //}
    if (name_cmd !== '...'){
      // print('name_cmd',name_cmd);
      irrg4sel.setValue(null,false);
      irrg4sel.setValue(name_cmd);//bcs task2 is executed over irrg4sel
    }
    newfeature=1;
  }
}
select_year.onChange(select_another_date);
var title = ui.Label({value:'Select an ID in the drop-down menu above or click on a point on the map',style : {color:'red', fontWeight: '400'}});
var title_first = ui.Label({value:'Select a State in the drop-down menu above or click on a point on the map',style : {color:'red', fontWeight: '400'}});
var title2 = ui.Label({value:'PLEASE WAIT...',style : {color:'red', fontWeight: '800', fontSize: '20px'}});
title2.style().set('position', 'bottom-center');
var func0=function(names,key){
  selectPanel.clear();
  selectPanel.add(comps);
  selectPanel.widgets().set(1,select_adm1);
  // Display the bands of the selected image.
  select_adm1.items().reset(names);
  wb4sel.items().reset(names);
  select_adm0.setValue(null, false);
  select_adm0.setPlaceholder(key); 
};
function redraw(key){
  // get the selected state
  middleMap.remove(selectPanel_first);
  middleMap.remove(selectPanel);
  middleMap.add(selectPanel);
  middleMap.remove(Logos_PANEL);
  middleMap.add(Logos_PANEL);
  middleMap.remove(sliderPanel);
  middleMap.add(sliderPanel);
  start_redraw=1;
  season=0;
  middleMap.remove(legend);
  middleMap.remove(trend_panel);
  panel_thisyear.clear();
  panel_sedzone.clear();
  panel_trend.clear();
  selectedState = ee.Feature(adm_1.filter(ee.Filter.eq(adm1_fieldname, key)).first());
  state_name = key;
  var stats_thisstate=ee.FeatureCollection(state_summaries.filter(ee.Filter.eq('STATE', state_name)));
  Lakes_with_Stats = stats_thisstate;
  lakes_fc=Lakes_with_Stats.filter(ee.Filter.eq('STATE', state_name));
  // print('stats_thisstate',stats_thisstate.sort(wb_id));
  state_summary=Lakes_with_Stats
    /*.filter(ee.Filter.lt('bias', 0.3))*/
    //.filter(ee.Filter.lt('bias_rel', 10))
    .filter(ee.Filter.gte('p_remaining', 50))
    //.filter(ee.Filter.lt('rmse_rel', 20))
    .filter(ee.Filter.gt('correlation', 0.8));
    //.filter(ee.Filter.or(ee.Filter.lt('bias_rel_fitted', 10),ee.Filter.lt('rmse_rel_fitted', 20)));//??
    //.filter(ee.Filter.or(ee.Filter.lt('rmse', 0.5),ee.Filter.lt('bias', 0.25)))//??
  /*var missing_lakes=ee.FeatureCollection(state_summary.aggregate_array(wb_id).iterate(function(x,prev){
    return ee.FeatureCollection(prev).filter(ee.Filter.neq(wb_id,x));
  },all_WaterBodies.filter(ee.Filter.gte('AREA_HA',100)).filter(ee.Filter.eq('STATE', state_name))));
  */  
  middleMap.remove(img_select_s2);
  //middleMap.remove(img_select_l8);
  //adm1_select.setPlaceholder(key); 
  selectPanel.widgets().set(1,ui.Select({style: {color: 'red',fontWeight: '450',border: '1px solid black',margin: '1px 1px 1px 7px'}}).setPlaceholder('Please Wait...'));
  //middleMap.remove(title);
  //FIRST OPTION: CLICK ON LAKE TO SELECT IT
  middleMap.style().set('cursor', 'crosshair');
  title.style().set('position', 'bottom-center');
  //middleMap.add(title);
  feat_centroids=ee.FeatureCollection(state_summary.map(function(feat){return ee.Feature(feat).centroid()}));
  //feat_missing_centroids=ee.FeatureCollection(missing_lakes.map(function(feat){return ee.Feature(feat).set('h_av',0).centroid()}));//.set('Name',)
  //feat_all_centroids=feat_missing_centroids.merge(feat_centroids);
  feat_all_centroids=feat_centroids;//.flatten();
  feat_missing_centroids=feat_centroids.filter(ee.Filter.eq('h_av',0));
  feat_centroids=feat_centroids.filter(ee.Filter.eq('h_av',1));  
  good_ids= feat_all_centroids.sort(wb_id).sort('Name').aggregate_array('Name').distinct();
  good_ids= all_WaterBodies.filter(ee.Filter.inList('Name', good_ids)).sort(wb_id).sort('Name').aggregate_array('Name').distinct();
  // print('good_ids',good_ids);
  // print('good_ids with h av',feat_centroids.sort(wb_id).sort('Name').aggregate_array('Name'));
  // print('feat_all_centroids',feat_all_centroids);
  // print('feat_centroids',feat_centroids);
  // print('permanent_area',feat_centroids.aggregate_array('permanent_area'));
  // print('min_area_meas',feat_centroids.aggregate_array('min_area_meas'));
  middleMap.add(trend_panel);
  drawingMode=true;
  middleMap.unlisten(sedclick);
  middleMap.unlisten(pointclick);
  //selecect lakes by clicking on map - after selection of state
  Lakes_with_Stats = all_WaterBodies.filter(ee.Filter.inList('Name', good_ids));
  pointclick_instate=middleMap.onClick(function(coords) {
      if(drawingMode){
        //point = ee.Geometry.Point(coords.lon, coords.lat);
        point = ee.Geometry.Point(coords.lon, coords.lat).buffer(1500,500);
        //get the name of selected lake
        var feat=ee.Feature(Lakes_with_Stats.filterBounds(point).first());
        var name=ee.String(feat.get(wb_name));
        var lake_name=ee.Algorithms.If(name.length().gt(0),name.cat(' (').cat(ee.String('ID_').cat(ee.Number.parse(feat.get(wb_id)))).cat(')'),
            ee.String('ID_').cat(ee.Number.parse(feat.get(wb_id))));
        middleMap.style().set('cursor', 'hand');
        drawingMode=false;
        middleMap.remove(title2);    
        middleMap.add(title2);    
        ee.Number(feat_all_centroids.filterBounds(point).size()).evaluate(function(result){
          if (result===0){
            middleMap.style().set('cursor', 'crosshair');
            drawingMode=true;
            title2.setValue('SELECTION UNSUCCESSFUL, PLEASE ZOOM IN FIRST');
            var task2debounce= ui.util.debounce( function() {
              middleMap.remove(title2);
              title2.setValue('PLEASE WAIT...');
            },5000);
            task2debounce();
          } else {
            middleMap.remove(sliderPanel);middleMap.remove(trend_panel);
            middleMap.centerObject(point,11);
            // print('lake_name',lake_name);
            // print('lake_area',ee.Feature(Lakes_with_Stats.filterBounds(point).first()).get('AREA_HA'));
            title2.setValue('SELECTION SUCCESSFUL, PLEASE WAIT...');
            ee.String(lake_name).evaluate(function(xx) {
              middleMap.style().set('cursor', 'crosshair');
              root4redraw2();
              redraw2(xx);
            });
          }
        });
      }  
    });
  sliderPanel.clear();
  sliderPanel.add(title);
  //start_l8=0;
  start_s2=0;
  //switch off other layers
  for (var i=0; i<=10; i++) {
    middleMap.layers().get(i).setShown(false);
  }
  middleMap.centerObject(lakes_fc,7);
  plot_centroids(season_overall);
  /*if (key=='Gujarat'){
    var names=['...'].concat(gee_codes.Gujarat_names());//precomputed names: much faster
    func0(names,key);
  } else {*/
    good_ids.evaluate(function(names) {
      // print('names',names);
      func0(['...'].concat(names),key);
    });
  //}
}
select_adm0.onChange(redraw);
var statistics_thislake;
function root4redraw2(){
  ui.root.clear();
  middleMapPanel.remove(middleMap);
  //middleMapPanel=ui.Panel(middleMap);
  //mapChartSplitPanel.setFirstPanel(middleMapPanel);
  splitPanel1.setFirstPanel(middleMap);
  /*splitPanel1.setSecondPanel(satelliteMap)
  splitPanel1.setWipe(true)*/
  splitPanel1.getFirstPanel().style().set('width','90%');
  panel_outputs.style().set('maxWidth', '400px');
  //ui.root.widgets().reset([mapChartSplitPanel]);  
  ui.root.widgets().reset([panel,mapChartSplitPanel]);
}
var plz_wait2=ui.Label('Please wait...', {color: 'red', fontWeight: '450', fontSize: '12px', margin: '7px 1px 1px 5px',backgroundColor : '#dadada'});
function task_filter_outliers(){
    //now calculate the volume change between datapoints
  var min_level=ee.Number(ts_thislake_s2.aggregate_array('dem_elev').reduce(ee.Reducer.min()));
  var dh_std_max=ee.Number(ts_thislake_s2.aggregate_array('dh_std').reduce(ee.Reducer.max()));
  var dh_std_med=ee.Number(ts_thislake_s2.aggregate_array('dh_std').reduce(ee.Reducer.median()));
  // print('min_level',min_level,'dh_std_max',dh_std_max,'dh_std_med',dh_std_med);
  //DEM not defined (eq to min_level) when h < (Freq==1):
  var ts_thislake_s20=ts_thislake_s2.filter(ee.Filter.and(ee.Filter.eq('dem_elev',min_level),ee.Filter.gt('area_water',0)))
    .map(function(ft){return ee.Feature(ft).set('dem_elev',null)});
  //DEM not defined (eq to min_level) when h < (Freq==1): REMOVE
  ts_thislake_s2=ts_thislake_s2.filter(ee.Filter.or(ee.Filter.neq('dem_elev',min_level),ee.Filter.eq('area_water',0)));
  var th_thislake_list=ts_thislake_s2.filter(ee.Filter.notNull(['dem_elev']))
    .merge(ts_thislake_s2.filter(ee.Filter.eq('area_water',0)).map(function(ft){return ee.Feature(ft).set('dem_elev',min_level)}))
    .sort('system:time_start')
    .toList(9999);
  var th_thislake_all=ee.FeatureCollection(ee.List.sequence(1,th_thislake_list.length().subtract(2)).map(function(x){return func_ts_analysis(x,th_thislake_list)}));
  //standard deviation of volume changes
  var std_vol0=ee.Number(th_thislake_all.filter(ee.Filter.neq('volchange0abs',-99))
    .filter(ee.Filter.or(ee.Filter.neq('dh1abs',0),ee.Filter.neq('dh0abs',0)))
    .aggregate_array('volchange0abs').reduce(ee.Reducer.stdDev()));
  var std_vol1=ee.Number(th_thislake_all.filter(ee.Filter.neq('volchange1abs',-99))
      .filter(ee.Filter.or(ee.Filter.neq('dh1abs',0),ee.Filter.neq('dh0abs',0)))
    .aggregate_array('volchange1abs').reduce(ee.Reducer.stdDev()));
  //median of volume changes
  var median_vol0=ee.Number(th_thislake_all.filter(ee.Filter.neq('volchange0abs',-99))
      .filter(ee.Filter.or(ee.Filter.neq('dh1abs',0),ee.Filter.neq('dh0abs',0)))
      .aggregate_array('volchange0abs').reduce(ee.Reducer.median()));
  var median_vol1=ee.Number(th_thislake_all.filter(ee.Filter.neq('volchange1abs',-99))
      .filter(ee.Filter.or(ee.Filter.neq('dh1abs',0),ee.Filter.neq('dh0abs',0)))
      .aggregate_array('volchange1abs').reduce(ee.Reducer.median()));
  //standard deviation of height changes
  var std_dh0=ee.Number(th_thislake_all.filter(ee.Filter.neq('dh0abs',-99)).aggregate_array('dh0abs').reduce(ee.Reducer.stdDev()));
  var std_dh1=ee.Number(th_thislake_all.filter(ee.Filter.neq('dh1abs',-99)).aggregate_array('dh1abs').reduce(ee.Reducer.stdDev()));
  //median of height changes
  var median_dh0=ee.Number(th_thislake_all.filter(ee.Filter.neq('dh0abs',-99)).aggregate_array('dh0abs').reduce(ee.Reducer.median()));
  var median_dh1=ee.Number(th_thislake_all.filter(ee.Filter.neq('dh1abs',-99)).aggregate_array('dh1abs').reduce(ee.Reducer.median()));
  //now remove all data points where the volume change to t-1 and t+1 exceeds 1.645*std (90% confidence interval)
  // print('th_thislake_all',th_thislake_all);
  ts_thislake_s2=th_thislake_all
    .filter(ee.Filter.or(ee.Filter.lte('volchange0abs',median_vol0.add(ee.Number(1.645).multiply(std_vol0))),
    ee.Filter.lte('volchange1abs',median_vol1.add(ee.Number(1.645).multiply(std_vol1)))))
    .filter(ee.Filter.or(ee.Filter.lte('volchange0abs',median_vol0.add(ee.Number(1.96).multiply(std_vol0))),
    ee.Filter.neq('volchange1abs',-99)))
    .filter(ee.Filter.or(ee.Filter.lte('volchange1abs',median_vol1.add(ee.Number(1.96).multiply(std_vol1))),
    ee.Filter.neq('volchange0abs',-99)))
    .filter(ee.Filter.or(ee.Filter.lte('dh0abs',median_dh0.add(ee.Number(1.645).multiply(std_dh0))),
    ee.Filter.lte('dh1abs',median_dh1.add(ee.Number(1.645).multiply(std_dh1)))))
    .filter(ee.Filter.and(/*ee.Filter.lte('dem_elev',maxDEM),ee.Filter.gte('inside_aoi',0.5),*/ee.Filter.neq('otsu_th', -0.3)))
    .merge(ts_thislake_s20).sort('system:time_start');
  var nb_datapoints2=ts_thislake_s2.size();
  // print('% remaining',nb_datapoints2.divide(nb_datapoints0).multiply(100));
  // print('volchange0abs',median_vol0.add(ee.Number(1.645).multiply(std_vol0)),'volchange1abs',median_vol1.add(ee.Number(1.645).multiply(std_vol1)));
  // print('dh0abs',median_dh0.add(ee.Number(1.645).multiply(std_dh0)),'dh1abs',median_dh1.add(ee.Number(1.645).multiply(std_dh1)));
  // print('ts_thislake_s2',ts_thislake_s2);
}
function task_dem(){
  path=root + 'DEMs_' +state_name.replace(' ','');
  dem_thislake= ee.Image(ee.data.getAsset(path + '/' + dem_name_root + key2).id).set(wb_id,key2);
  var minDEM=ee.Number(dem_thislake.get('min_elev_perc_fit'));
  var maxDEM=ee.Number(dem_thislake.get('max_elev_perc_fit'));
  var dem_orig=dem_thislake;
  var dem_defined=dem_thislake.updateMask(dem_thislake.lte(maxDEM)).updateMask(dem_thislake.gte(minDEM));
  var slope_occ=(ee.Number(dem_thislake.get('max_elev_perc_fit')).subtract(ee.Number(dem_thislake.get('min_elev_perc_fit')))).divide(
    ee.Number(100).multiply(ee.Number(dem_thislake.get('max_occ')).subtract(ee.Number(dem_thislake.get('min_occ')))));
  var dem_delta = FreqMap.subtract(ee.Image(ee.Number(dem_thislake.get('max_occ')))).multiply(100).multiply(slope_occ).clip(area_of_interest.buffer(buffer_width));
  dem_reservoir=dem_orig.where(dem_delta.gt(0),ee.Image(ee.Number(dem_thislake.get('min_elev_perc_fit'))).subtract(dem_delta));
  dem_thislake=dem_reservoir;
  // print('dem_thislake',dem_thislake);
}
function sedzoneanalysis(){
  middleMap.style().set('cursor', 'crosshair');
  slider7.setDisabled(false);
  panel_outputs.widgets().set(1,ui.Label());
  panel_outputs.remove(panel_sedzone);
  panel_outputs.widgets().set(1,panel_sedzone);
  //panel_outputs.add(panel_sedzone);
  sedzone=ee.Image(stacktoimage(area_of_interest,sedzone_stack));
  unit_name_panel.remove(sedBalance_panel);
  unit_name_panel.add(sedBalance_panel);
  /*
  path= 'users/magosilvain/SedZones/' + state_name.replace(' ','') + '/SedZone_L8_00to20_' + key2;
  sedzone=ee.Image(ee.data.getAsset(path).id).set(wb_id,key2);*/
  // print('sedzone thislake',sedzone);
  panel_sedzone.widgets().set(0,ui.Label('Deposition/Erosion',{fontWeight: 'bold',fontSize: '16px',margin: '1px 10px 1px 1px',padding: '0'}));
  //panel_sedzone.widgets().set(1,ui.Label('Sediment balance: ', {fontSize: '10px', margin: '1px 1px 1px 1px'}));
  sedBalance_label1.setValue("Sediment balance (mm/year):  ");
  var balance=ee.Number(0).subtract(ee.Number(sedzone.get('mean_movement21')));
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
        .set('1_Type','Annual Sediment Balance')
        .set('2_Variable','Sediment balance')
        .set('3_TimePeriod','1999-2022')
        .set('4_Unit','mm/year')
        .set('5_Value',balance)));     
  balance.evaluate(function(result){
    // print('Sediment balance',result);
    sedBalance_label1.setValue("Sediment balance:  " + (result<0?"":"+") + result +' mm/year' );
    //panel_sedzone.widgets().set(1,ui.Label('Sediment balance: ' + (result<0?"":"+") + result +' mm/year', {fontSize: '10px', margin: '1px 1px 1px 1px'}));
  });
//  var volchange=balance.divide(1000).multiply(ee.Number(selectedLake.get('AREA_HA')).multiply(10000));
  var volchange=balance.divide(1000).multiply(area_full);
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
        .set('1_Type','Reservoir Capacity')
        .set('2_Variable','Storage Volume Change')
        .set('3_TimePeriod','1999-2022')
        .set('4_Unit','M m3 per Year')
        .set('5_Value',volchange.divide(-1000000)))); 
  sedBalance_label2.setValue("Storage volume lost/gained per year ( M m³):  ");
  volchange.evaluate(function(result){
    result=result/1000000;
    if (result>0){
      sedBalance_label2.setValue("Storage volume lost per year (M m³):  " +  result.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:3}));
    } else {
      result=-result;
      sedBalance_label2.setValue("Storage volume gained per year (M m³):  " +  result.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:3}));
    }
  });
  var erosion_area=ee.Number(sedzone.get('erosion_area'));
  var deposition_area=ee.Number(sedzone.get('deposition_area'));
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
        .set('1_Type','Annual Sediment Balance')
        .set('2_Variable','Erosion Zones (delta h < -1cm/year)')
        .set('3_TimePeriod','1999-2022')
        .set('4_Unit','%')
        .set('5_Value',erosion_area)));  
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
        .set('1_Type','Annual Sediment Balance')
        .set('2_Variable','Deposition Zones (delta h < -1cm/year)')
        .set('3_TimePeriod','1999-2022')
        .set('4_Unit','%')
        .set('5_Value',deposition_area)));
  zones_erosion.setValue("Erosion Zones (\u0394 h < -1cm/year):  ");
  erosion_area.evaluate(function(result){
    zones_erosion.setValue("Erosion Zones (\u0394 h < -1cm/year):  " + result + '%' );
  });
  zones_deposition.setValue("Deposition Zones (\u0394 h < -1cm/year):  ");
  deposition_area.evaluate(function(result){
    zones_deposition.setValue("Deposition Zones (\u0394 h < -1cm/year):  " + result + '%' );
  });  
  /*panel_sedzone.widgets().set(2,ui.Label('Erosion Zones (\u0394 h < -1cm/year): ', {fontSize: '10px', margin: '1px 1px 1px 1px'}));
  erosion_area.evaluate(function(result){
      panel_sedzone.widgets().set(2,ui.Label('Erosion Zones (\u0394 h < -1cm/year): ' + result + '%', {fontSize: '10px', margin: '1px 1px 1px 1px'}));
  });    
  panel_sedzone.widgets().set(3,ui.Label('Deposition Zones (\u0394 h > +1cm/year): ', {fontSize: '10px', margin: '1px 1px 1px 1px'}));
  deposition_area.evaluate(function(result){
      panel_sedzone.widgets().set(3,ui.Label('Deposition Zones (\u0394 h > +1cm/year): ' + result + '%', {fontSize: '10px', margin: '1px 1px 1px 1px'}));
  });*/
  panel_sedzone.widgets().set(1,ui.Label({value:'Click on the reservoir to inspect local terrain height changes',style :{color: 'red',}})); 
  var bands=sedzone_stack.bandNames().size();
  var new_sed_zone_col=ee.ImageCollection(ee.List.sequence(0,bands.subtract(1)).map(function(band){
    var bandname=ee.String(sedzone_stack.bandNames().get(ee.Number(band)));
    var nr=ee.Number.parse(bandname.slice(1));
    return sedzone_stack.select(bandname).rename('delta')
      .multiply(ee.Image(-1))
      .set('t',nr.add(2000)).set('Name',bandname);
  }));
  middleMap.layers().set(1, ui.Map.Layer(sedzone.updateMask(sedzone.select('sedzone_filled').neq(0)), {bands: ['sedzone_filled'], palette:['red', 'white','blue'],min: -0.04, max: 0.04}, "sedzone_filled",true));
  sedclick=middleMap.onClick(function(coords) {
    middleMap.style().set('cursor', 'hand');
    all_WaterBodies.filterBounds(ee.Geometry.Point(coords.lon, coords.lat)).evaluate(function(result){
      middleMap.style().set('cursor', 'crosshair');
      if (result.features.length===0){
      } else {
        var point = ee.Geometry.Point(coords.lon, coords.lat);
        middleMap.layers().set(10, ui.Map.Layer(ee.FeatureCollection(point).style({color: 'black',pointShape:'star6',pointSize:5,fillColor : 'white'}), {},'point'));
                       var chart=ui.Chart.image.series(new_sed_zone_col.select('delta'), point, null, 10,'t')
                      .setChartType('ScatterChart')
                      .setOptions({
                          instruct: 'delta per year and linear trendline',
                          trendlines: {0: { 
                            color: 'CC0000',
                            lineWidth: 1, 
                            labelInLegend: 'Trendline',
                            showR2: true,
                            visibleInLegend: true
                          }},
                          lineWidth: 1, 
                          pointSize: 3,
                          series: {
                            0: {lineWidth:0,labelInLegend: 'delta h',},
                          },                          
                          //legend: {position:"none"},
                          vAxis: {minValue:-0.5,maxValue:0.5/*,ticks: [-1.5, -1, -0.5, 0, 0.5,1,1.5]*/,title: '\u0394 h [m]'},
                          hAxis: {title:'Year',ticks: [2000,2005,2010,2015,2020],viewWindowMode: 'maximized'}
                        }); 
      panel_sedzone.widgets().set(1,chart);
    //print('chart',chart);
      }
    });
  });
}
function task_posvolchange(area,levels){
  var list2return=ee.List.sequence(0,ee.Number(area.length()).subtract(2)).map(function(x){
      x=ee.Number(x);
      var h0=ee.Number(levels.get(x));
      var h1=ee.Number(levels.get(x.add(1)));
      var a0=ee.Number(area.get(x));
      var a1=ee.Number(area.get(x.add(1)));
      var posh=h1.subtract(h0).max(ee.Number(0));
      var posa=a1.add(a0).divide(2).multiply(10000);
    var vol0=ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(h0)).mask()
      .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
      .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1'))
      .multiply(ee.Number(ee.Image(h0).rename('b1').subtract(dem_reservoir).updateMask(dem_reservoir.lte(h0))
      .reduceRegion({'reducer': ee.Reducer.mean(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')));  
    var vol1=ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(h1)).mask()
      .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
      .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1'))
      .multiply(ee.Number(ee.Image(h1).rename('b1').subtract(dem_reservoir).updateMask(dem_reservoir.lte(h1))
      .reduceRegion({'reducer': ee.Reducer.mean(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')));  
      //return posa.multiply(posh);
    return vol1.subtract(vol0).max(0);
    });
  return list2return.reduce(ee.Reducer.sum());
}
function task_negvolchange(area,levels){
  var list2return=ee.List.sequence(0,ee.Number(area.length()).subtract(2)).map(function(x){
      x=ee.Number(x);
      var h0=ee.Number(levels.get(x));
      var h1=ee.Number(levels.get(x.add(1)));
      var a0=ee.Number(area.get(x));
      var a1=ee.Number(area.get(x.add(1)));
      var posh=h0.subtract(h1).max(ee.Number(0));
      var posa=a1.add(a0).divide(2).multiply(10000);
    var vol0=ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(h0)).mask()
      .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
      .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1'))
      .multiply(ee.Number(ee.Image(h0).rename('b1').subtract(dem_reservoir).updateMask(dem_reservoir.lte(h0))
      .reduceRegion({'reducer': ee.Reducer.mean(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')));  
    var vol1=ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(h1)).mask()
      .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
      .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1'))
      .multiply(ee.Number(ee.Image(h1).rename('b1').subtract(dem_reservoir).updateMask(dem_reservoir.lte(h1))
      .reduceRegion({'reducer': ee.Reducer.mean(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')));  
      //return posa.multiply(posh);
    return vol0.subtract(vol1).max(0);    });
  return list2return.reduce(ee.Reducer.sum());
}
function task_volchange(ft0,ft1){
    var h0=ee.Number(ft0.get('dem_elev'));
    var h1=ee.Number(ft1.get('dem_elev'));
    var vol0=ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(h0)).mask()
      .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
      .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1'))
      .multiply(ee.Number(ee.Image(h0).rename('b1').subtract(dem_reservoir).updateMask(dem_reservoir.lte(h0))
      .reduceRegion({'reducer': ee.Reducer.mean(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')));  
    var vol1=ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(h1)).mask()
      .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
      .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1'))
      .multiply(ee.Number(ee.Image(h1).rename('b1').subtract(dem_reservoir).updateMask(dem_reservoir.lte(h1))
      .reduceRegion({'reducer': ee.Reducer.mean(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')));  
    //print('vol1-vol0',vol0.subtract(vol1));
    return vol0.subtract(vol1);
}
//calculate storage volume change between maximum level and minimum level
var volchange_annual; var max_vol; var min_vol; var volchange_seasonal;var prop;
var negvolchange_seasonal; var posvolchange_seasonal;
function task_storage_a(){
  if (h_av==1){
    prop='dem_elev';
  } else {
    prop='area_water';
  }
  //unit_name_panel.remove(VolChange_panel);
  //unit_name_panel.add(VolChange_panel);
  //find the date of the maximum level with cloud cover < 10%, search between November and April.
  //Consider only max within the defined range??
  var max_level=ee.Number(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),11, 1), ee.Date.fromYMD(year,5, 1))
    .filter(ee.Filter.lte('cloud_cover',10)).aggregate_array(prop).reduce(ee.Reducer.max()));
  var ft0=ee.Feature(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),11, 1), ee.Date.fromYMD(year,11, 1))
    .filter(ee.Filter.lte('cloud_cover',10)).filter(ee.Filter.eq(prop,max_level)).first());
  date_of_max_level=ee.Date(ft0.get('system:time_start'));
  month_of_max_level=ee.Number(date_of_max_level.get('month'));
  // print('date_of_max_level',date_of_max_level.format('YYYY-MM-dd'));
  //find the date of the minimum level with cloud cover < 10%, search between date_of_max_level and not later than June
  var min_level=ee.Number(ts_thislake_s2.filterDate(date_of_max_level, ee.Date.fromYMD(year,7, 1))
    .filter(ee.Filter.lte('cloud_cover',10)).aggregate_array(prop).reduce(ee.Reducer.min()));
  var ft1=ee.Feature(ts_thislake_s2.filterDate(date_of_max_level, ee.Date.fromYMD(year,7, 1))
    .filter(ee.Filter.lte('cloud_cover',10)).filter(ee.Filter.eq(prop,min_level)).first());
  date_of_min_level=ee.Date(ft1.get('system:time_start'));
  /*if (year == 2022){//ET maps not available after April 2022
    date_of_min_level=ee.Date(ee.List([date_of_min_level,ee.Date.fromYMD(2022,4,30)]).sort().get(0));
    min_level=ee.Number(ts_thislake_s2.filterDate(date_of_max_level, date_of_min_level)
    .filter(ee.Filter.lte('cloud_cover',10)).aggregate_array(prop).reduce(ee.Reducer.min()));
    ft1=ee.Feature(ts_thislake_s2.filterDate(date_of_max_level, date_of_min_level)
    .filter(ee.Filter.lte('cloud_cover',10)).filter(ee.Filter.eq(prop,min_level)).first());
  }*/
  date_of_min_level=ee.Date(ft1.get('system:time_start'));
  month_of_min_level=ee.Number(date_of_min_level.get('month'));
  // print('date_of_min_level',date_of_min_level.format('YYYY-MM-dd'));
}
function task_storage(date_of_max_level,date_of_min_level,year){
  //TODO: RETURN NAN VALUE IF NO DATES ARE AVAILABLE IN A GIVEN YEAR
  var max_level=ee.Number(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),11, 1), ee.Date.fromYMD(year,5, 1))
    .filter(ee.Filter.lte('cloud_cover',10)).aggregate_array(prop).reduce(ee.Reducer.max()));
  var max_level_tot=ee.Feature(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),7, 1), ee.Date.fromYMD(year,5, 1))
    .filter(ee.Filter.lte('cloud_cover',10)).aggregate_array(prop).reduce(ee.Reducer.max()));
  var max_level_abs=ee.Feature(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),7, 1), ee.Date.fromYMD(year,5, 1))
    .aggregate_array(prop).reduce(ee.Reducer.max()));       
  var ft0=ee.Feature(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),11, 1), ee.Date.fromYMD(year,11, 1))
    .filter(ee.Filter.lte('cloud_cover',10)).filter(ee.Filter.eq(prop,max_level)).first());
  var min_level=ee.Number(ts_thislake_s2.filterDate(date_of_max_level, date_of_min_level)
    .filter(ee.Filter.lte('cloud_cover',10)).aggregate_array(prop).reduce(ee.Reducer.min()));
  var ft1=ee.Feature(ts_thislake_s2.filterDate(date_of_max_level, date_of_min_level)
    .filter(ee.Filter.lte('cloud_cover',10)).filter(ee.Filter.eq(prop,min_level)).first());
  var ft_max=ee.Feature(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),7, 1), ee.Date.fromYMD(year,5, 1))
    .filter(ee.Filter.eq(prop,max_level_abs)).first());
  //calculate volume change  //USE MORE ACCURATE CALCULATIONS BASED ON THE BATHYMETRY, NOT BASED ON AVERAGE LAKE AREA
  var a0=ee.Number(ft0.get('area_water'));var v0; var h0;
  var a1=ee.Number(ft1.get('area_water'));var v1; var h1; var v_max;
  var a_max=ee.Number(ee.Feature(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),7, 1), ee.Date.fromYMD(year,5, 1))
    .filter(ee.Filter.lte('cloud_cover',10)).filter(ee.Filter.eq(prop,max_level_tot)).first()).get('area_water'));
  var line2add=ee.Feature(null)
        .set('1_Type','Annual Water Balance')
        .set('2_Variable','Minimum Active Water Storage')
        .set('3_TimePeriod',year)
        .set('4_Unit','M m3');
  var line2add2=ee.Feature(null)
        .set('1_Type','Annual Water Balance')
        .set('2_Variable','Maximum Active Water Storage')
        .set('3_TimePeriod',year)
        .set('4_Unit','M m3');          
  if (h_av==1){
    /*var pixelArea0 = ee.Number(ee.Image(1).multiply(ee.Image.pixelArea())
      .reproject({crs: dem_reservoir.projection().crs(), scale:10})
      .reduceRegion({'reducer': ee.Reducer.first(),'geometry': area_of_interest.buffer(500),'scale':10}).get('constant'));*/
    volchange_seasonal=ee.Number(task_volchange(ft0,ft1));
    // print('test area',  ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(180)).mask()
    //   .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
    //   .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')));
    // print('bimonthly_average areas',bimonthly_areas.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),11, 1), ee.Date.fromYMD(year,5, 1)).aggregate_array('amonthly'));
    // print('bimonthly_average levels',bimonthly_average.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),11, 1), ee.Date.fromYMD(year,5, 1)).aggregate_array('hmonthly'));
    posvolchange_seasonal=ee.Number(task_posvolchange(
      bimonthly_areas.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),9, 1), ee.Date.fromYMD(year,6, 1)).aggregate_array('amonthly'),
      bimonthly_average.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),9, 1), ee.Date.fromYMD(year,6, 1)).aggregate_array('hmonthly')
    ));
    negvolchange_seasonal=ee.Number(task_negvolchange(
      bimonthly_areas.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),9, 1), ee.Date.fromYMD(year,6, 1)).aggregate_array('amonthly'),
      bimonthly_average.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),9, 1), ee.Date.fromYMD(year,6, 1)).aggregate_array('hmonthly')
    ));
    // print('posvolchange_seasonal',posvolchange_seasonal);
    //negvolchange_seasonal=volchange_seasonal.add(posvolchange_seasonal);
    volchange_seasonal=posvolchange_seasonal.subtract(negvolchange_seasonal);//this is more accurate for the net changes
    //volchange=h1.subtract(h0).multiply((a0.add(a1).divide(2).multiply(10000)))/*.divide(1000000000)*/.multiply(-1);//.divide(d1)
    h0=ee.Number(ft_max.get('dem_elev'));
    h1=ee.Number(ft1.get('dem_elev'));
    v_max=ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(h0)).mask()
      .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
      .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1'))
      .multiply(ee.Number(ee.Image(h0).rename('b1').subtract(dem_reservoir).updateMask(dem_reservoir.lte(h0))
      .reduceRegion({'reducer': ee.Reducer.mean(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')));  
    v1=ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(h1)).mask()
      .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
      .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1'))
      .multiply(ee.Number(ee.Image(h1).rename('b1').subtract(dem_reservoir).updateMask(dem_reservoir.lte(h1))
      .reduceRegion({'reducer': ee.Reducer.mean(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')));  
    //print('vol1-vol0',vol0.subtract(vol1));
  } else {
    //V-A scaling: 0.0000028554*C2^1.383852053*1000000000
    v1=ee.Number(0.0000028554).multiply(a1.pow(1.383852053)).multiply(1000000000);
    v0=ee.Number(0.0000028554).multiply(a0.pow(1.383852053)).multiply(1000000000);
    volchange_seasonal=v0.subtract(v1);
    v_max=ee.Number(0.0000028554).multiply(a_max.pow(1.383852053)).multiply(1000000000);
    line2add=line2add.set('2_Variable','Minimum Water Storage');
    line2add2=line2add2.set('2_Variable','Maximum Water Storage');
  }
  // print('volchange_seasonal',volchange_seasonal);
  min_vol=v1;
  line2add=line2add.set('5_Value',v1.divide(1000000));
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(line2add));
  max_vol=v_max;
  line2add2=line2add2.set('5_Value',v_max.divide(1000000));
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(line2add2)); 
  //minimum level in June/July, previous year
  var first_level=ee.Number(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),5, 1), ee.Date.fromYMD(ee.Number(year).subtract(1),7, 31))
    .filter(ee.Filter.lte('cloud_cover',10)).aggregate_array(prop).reduce(ee.Reducer.min()));
  //print('first_level',first_level);
  ft0=ee.Feature(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),5, 1), ee.Date.fromYMD(ee.Number(year).subtract(1),7, 31))
    .filter(ee.Filter.lte('cloud_cover',10)).filter(ee.Filter.eq(prop,first_level)).first());
      //minimum level in June/July, this year
  var this_level=ee.Number(ts_thislake_s2.filterDate(ee.Date.fromYMD(ee.Number(year),5, 1), ee.Date.fromYMD(ee.Number(year),7, 31))
    .filter(ee.Filter.lte('cloud_cover',10)).aggregate_array(prop).reduce(ee.Reducer.min()));
  //print('this_level',this_level);
  ft1=ee.Feature(ts_thislake_s2.filterDate(date_of_max_level, ee.Date.fromYMD(year,7, 31))
    .filter(ee.Filter.lte('cloud_cover',10)).filter(ee.Filter.eq(prop,this_level)).first());  
  a0=ee.Number(ft0.get('area_water'));
  a1=ee.Number(ft1.get('area_water'));
  if (h_av==1){
    volchange_annual=ee.Number(task_volchange(ft0,ft1));
    //print('volchange_annual',volchange_annual);
  } else {
    //V-A scaling: 
    v1=ee.Number(0.0000028554).multiply(a1.pow(1.383852053)).multiply(1000000000);
    v0=ee.Number(0.0000028554).multiply(a0.pow(1.383852053)).multiply(1000000000);
    volchange_annual=v0.subtract(v1);
    }
  // print('volchange_annual',volchange_annual);
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
        .set('1_Type','Annual Water Balance')
        .set('2_Variable','Net Water Balance')
        .set('3_TimePeriod',year)
        .set('4_Unit','M m3')
        .set('5_Value',volchange_annual.divide(-1000000))));   
}
function task_storage_b(){
  //display the results
  TotalVolChangeLabel.setValue("Total Water Use (M m³):  ");//or, Total reservoir storage used...
  //
  TotalPosVolChangeLabel.setValue("Total Increment in the Storage (M m³): ");
  TotalNegVolChangeLabel.setValue("Total Water Used from Reservoir (M m³): ");
  var iteration_id_tmp = iteration_id;
  var month_last=date_of_min_level.format('MMM');var month_last_client="";
  var month_first=date_of_max_level.format('MMM'); var month_first_client="";
  month_first.evaluate(function(result1) {
    month_first_client=result1;
    month_last.evaluate(function(result2) {
      month_last_client=result2;
        header_volchange.setValue("Rabi Season Water Balance ("+ month_first_client + "-"+ month_last_client + "):");
    });
  });
  header_volchange.setValue("Rabi Season Water Balance:");
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
      .set('1_Type','Annual Water Balance')
      .set('2_Variable','Total Increment in the Storage')
      .set('3_TimePeriod',year)
      .set('4_Unit','M m3')
      .set('5_Value',posvolchange_seasonal.divide(1000000))));  
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
      .set('1_Type','Annual Water Balance')
      .set('2_Variable','Total Water Used from Reservoir')
      .set('3_TimePeriod',year)
      .set('4_Unit','M m3')
      .set('5_Value',negvolchange_seasonal.divide(1000000))));
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
      .set('1_Type','Rabi Season Water Balance')
      .set('2_Variable','Total Water Use')
      .set('3_TimePeriod',date_of_max_level.format('MMM').cat(ee.String('-').cat(date_of_min_level.format('MMM')).cat(ee.String(' ').cat(ee.String(ee.Number(year))))))
      .set('4_Unit','M m3')
      .set('5_Value',volchange_seasonal.divide(1000000))));
  volchange_seasonal.evaluate(function(result0) {
    if (iteration_id == iteration_id_tmp){
      result0=result0/1000000;
      TotalVolChangeLabel.setValue("Total Water Use (M m³):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
    }      
  });
  aVolChange_panel.remove(TotalPosVolChangeLabel);
  aVolChange_panel.remove(TotalNegVolChangeLabel);
  if (h_av==1){
    aVolChange_panel.add(TotalPosVolChangeLabel);
    aVolChange_panel.add(TotalNegVolChangeLabel);
    posvolchange_seasonal.evaluate(function(result0) {
      if (iteration_id == iteration_id_tmp){
        result0=result0/1000000;
        TotalPosVolChangeLabel.setValue("Total Increment in the Storage (M m³):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }      
    });
    negvolchange_seasonal.evaluate(function(result0) {
      if (iteration_id == iteration_id_tmp){
        result0=result0/1000000;
        TotalNegVolChangeLabel.setValue("Total Water Used from Reservoir (M m³):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }      
    });  
  }
    //following is calculated under task2, if command areas available
  TotalCommandAreaLabel.setValue( "Total command area (ha):  ");
  TotalCropAreaLabel.setValue( "Total cropped area (ha):  ");
  max_storage.setValue("Maximum Storage (M m³): ");
  max_vol.evaluate(function(result0) {
    if (iteration_id == iteration_id_tmp){
      result0=result0/1000000;
      if (h_av===0){
        max_storage.setValue("Maximum Storage (M m³): " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      } else {
        max_storage.setValue("Maximum Active Storage (M m³): " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }}      
  });
  min_storage.setValue("Minimum Storage (M m³): ");
  min_vol.evaluate(function(result0) {
    if (iteration_id == iteration_id_tmp){
      result0=result0/1000000;
      if (h_av===0){
        min_storage.setValue("Minimum Storage (M m³): " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      } else {
        min_storage.setValue("Minimum Active Storage (M m³): " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }}      
  });
  unit_used.setValue("Net Water Balance (M m³): ");
  volchange_annual.evaluate(function(result0) {
    if (iteration_id == iteration_id_tmp){
      result0=-result0/1000000;
      unit_used.setValue("Net Water Balance (M m³): " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      /*if (result0>0){
        unit_used.setValue("Total reservoir water used (M m³): " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      } else {
        result0=-result0;
        unit_used.setValue("Total reservoir water gained (M m³): " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }*/}      
  });
}
//all tasks related to crop and irrigated area processing
function task2a(name,rRscale,rRtileScale){
  unit_cmd.setValue("Selected Command Area: " + name);
  slider5.setDisabled(false);//slider for crop map
  slider2.setValue(0);//slider for command areas
  command_area=command_areas.filter(ee.Filter.eq('CNAME',name));
  if (result_cmd===0 && newfeature==1){//this is the case when the command area isnt identified automatically, but through manual selection
    var lake_and_cmd=ee.Feature(ee.FeatureCollection(ee.List([selectedLake, ee.Feature(command_area.union(100).first())])).union(100).first());
    dd = ee.Image().paint(lake_and_cmd.geometry(), 0, 2);
    middleMap.layers().set(9, ui.Map.Layer(dd,null, "area_of_interest"));
    middleMap.centerObject(lake_and_cmd);
    satelliteMap.layers().set(2,ui.Map.Layer(dd,null,'Area of Interest'));
    centeronthis=lake_and_cmd;
  }
}
function task2(name,rRscale,rRtileScale,yearx,month_of_max_level,month_of_min_level){
  var lulc_map=ee.Image(root + lulc_folder + '/' + state_name +lulc_root_name)/*.clip(command_area.geometry().buffer(5000,500))*/.rename('clusters');
  lulc_map=lulc_map.where(lulc_map.gt(max_crop_id),0);
  if (state_name==state1){
    var cropVegPeriod=ee.Image(root + crop_veg_ic + '/' + crop_veg_root_name + state_name +'_'+ yearx)/*.clip(command_area.geometry().buffer(5000,500))*/;
    var fittedGreenFirstMonth=cropVegPeriod.select('first');
    var fittedGreenLastMonth=cropVegPeriod.select('last');
    var fittedGreenFirstMonth2=cropVegPeriod.select('first2');
    var fittedGreenLastMonth2=cropVegPeriod.select('last2');
    //var fittedGreenFirstMonth0=cropVegPeriod.select('first0');
    fittedGreenFirstMonth=ee.Image(2).updateMask(fittedGreenLastMonth.gt(0)).where(fittedGreenFirstMonth.gt(0),fittedGreenFirstMonth);//2-->10 after conversion to calendar year
    var fittedGreenLength=fittedGreenLastMonth.subtract(fittedGreenFirstMonth).add(1);    
    /*print('month_of_max_level',month_of_max_level);
    print('month_of_min_level',month_of_min_level);*/
    var fGFM=fittedGreenFirstMonth;
    var fGLM=fittedGreenLastMonth;
    var fGFM2=fittedGreenFirstMonth2;
    var fGLM2=fittedGreenLastMonth2;
    var getETandETgreen = function(init_res){
      // print('init_res',init_res);
      et_sum=ee.ImageCollection(ee.List.sequence(1,12).map(function(m){
        m=ee.Number(m).int();
        var m0=ee.Number(ee.Algorithms.If(m.subtract(4).lte(0),m.subtract(4).add(12),m.subtract(4)));
        var year0=ee.Number(ee.Algorithms.If(m0.gte(8),ee.Number(yearx).subtract(1),yearx));
        var et_month= ETA_monthly_maps.filter(ee.Filter.and(
          ee.Filter.calendarRange(year0, year0, 'year'),
          ee.Filter.calendarRange(m0, m0, 'month')))
        .filter(ee.Filter.calendarRange(month_of_max_level, month_of_min_level, 'month'));
        var multiply=ee.Image(1).where(fGFM.lte(m).and(fGLM.gte(m))
            .or(ee.Image(0).blend(fGFM2.lte(m).and(fGLM2.gte(m)))).not().eq(1),0)
            .rename('multiply').setDefaultProjection({crs: utm_zone, scale:init_res}).reduceResolution({
              reducer: ee.Reducer.mode().unweighted(),
              maxPixels: 16384
            }).reproject(ETProjection);
        var mean_ET_img=ee.Image(ee.Algorithms.If(et_month.size().gt(0),ee.Image(et_month.first()),ee.Image(0)))
          .multiply(multiply);      
          mean_ET_img=mean_ET_img.updateMask(mean_ET_img.gt(0));  
        var mean_ET=mean_ET_img
          .reduceRegion({
            reducer: ee.Reducer.mean(),
            geometry: command_area.geometry().buffer(2000,500),//add a 2km buffer around command area to make sure we'll find some fallow area...
            crs: ETProjection, //scale: res_sel_ET,
          });
        var ET=mean_ET.values().get(0);
        ET=ee.Algorithms.If(ee.Algorithms.IsEqual(ET,null),0,ET);
        var ETimg=ee.Image(ee.Number(ET)).toShort();   
        return ETimg
          .multiply(fGFM.lte(m).and(fGLM.gte(m))
          .or(ee.Image(0).blend(fGFM2.lte(m).and(fGLM2.gte(m)))))
          .rename('b1');
      })).sum().rename('b1');
      et_fallow=ee.ImageCollection(ee.List.sequence(1,12).map(function(m){
        m=ee.Number(m).int();
        var m0=ee.Number(ee.Algorithms.If(m.subtract(4).lte(0),m.subtract(4).add(12),m.subtract(4)));
        var year0=ee.Number(ee.Algorithms.If(m0.gte(8),ee.Number(yearx).subtract(1),yearx));
        var et_month= ETA_monthly_maps.filter(ee.Filter.and(
            ee.Filter.calendarRange(year0, year0, 'year'),
            ee.Filter.calendarRange(m0, m0, 'month')))
          .filter(ee.Filter.calendarRange(month_of_max_level, month_of_min_level, 'month'));
        var multiply=ee.Image(1).where(fGFM.lte(m).and(fGLM.gte(m))
            .or(ee.Image(0).blend(fGFM2.lte(m).and(fGLM2.gte(m)))).eq(1),0)
            .rename('multiply').where(lulc_map.eq(0),0).setDefaultProjection({crs: utm_zone, scale:init_res}).reduceResolution({
              reducer: ee.Reducer.mode().unweighted(),
              maxPixels: 16384
            }).reproject(ETProjection);
        var mean_ETgreen_img=ee.Image(ee.Algorithms.If(et_month.size().gt(0),ee.Image(et_month.first()),ee.Image(0)))
          .multiply(multiply);
        mean_ETgreen_img=mean_ETgreen_img.updateMask(mean_ETgreen_img.gt(0));  
        var mean_ETgreen=mean_ETgreen_img
          .reduceRegion({
            reducer: ee.Reducer.mean(),
            geometry: command_area.geometry().buffer(2000,500),//add a 2km buffer around command area to make sure we'll find some fallow area...
            crs: ETProjection, //scale: res_sel_ET,
          });
        var ETgreen=mean_ETgreen.values().get(0);
        ETgreen=ee.Algorithms.If(ee.Algorithms.IsEqual(ETgreen,null),0,ETgreen);
        var ETgreenimg=ee.Image(ee.Number(ETgreen)).toShort();        
        return ETgreenimg
          .multiply(fGFM.lte(m).and(fGLM.gte(m))
          .or(ee.Image(0).blend(fGFM2.lte(m).and(fGLM2.gte(m)))))
          .rename('b1');
      })).sum().rename('b1');
      //print('et_fallow',et_fallow);
    };
    getETandETgreen(init_res);
    //calculate total P over cropped area and vegetation period
    p_sum=ee.ImageCollection(ee.List.sequence(1,12).map(function(m){
      m=ee.Number(m).int();
      var m0=ee.Number(ee.Algorithms.If(m.subtract(4).lte(0),m.subtract(4).add(12),m.subtract(4)));
      var year0=ee.Number(ee.Algorithms.If(m0.gte(8),ee.Number(yearx).subtract(1),yearx));
      var p_month= ee.ImageCollection("UCSB-CHG/CHIRPS/PENTAD").filter(ee.Filter.and(
        ee.Filter.calendarRange(year0, year0, 'year'),
        ee.Filter.calendarRange(m0, m0, 'month')))
      .filter(ee.Filter.calendarRange(month_of_max_level, month_of_min_level, 'month'));
      return ee.Image(ee.Algorithms.If(p_month.size().gt(0),ee.Image(p_month.sum())
      .multiply(fittedGreenFirstMonth.lte(m).and(fittedGreenLastMonth.gte(m))
      .or(ee.Image(0).blend(fittedGreenFirstMonth2.lte(m).and(fittedGreenLastMonth2.gte(m))))),
        ee.Image(0).float())).rename('b1');
    })).sum().rename('b1');
    //the hydrological year starts in October --> convert into calendar year
    fittedGreenFirstMonth=fittedGreenFirstMonth.subtract(4);
    fittedGreenFirstMonth=fittedGreenFirstMonth.where(fittedGreenFirstMonth.lte(0),fittedGreenFirstMonth.add(12));
    fittedGreenLastMonth=fittedGreenLastMonth.subtract(4);
    fittedGreenLastMonth=fittedGreenLastMonth.where(fittedGreenLastMonth.lte(0),fittedGreenLastMonth.add(12));
    fittedGreenFirstMonth2=fittedGreenFirstMonth2.subtract(4);
    fittedGreenFirstMonth2=fittedGreenFirstMonth2.where(fittedGreenFirstMonth2.lte(0),fittedGreenFirstMonth2.add(12));
    fittedGreenLastMonth2=fittedGreenLastMonth2.subtract(4);
    fittedGreenLastMonth2=fittedGreenLastMonth2.where(fittedGreenLastMonth2.lte(0),fittedGreenLastMonth2.add(12));
    //Permanent crops
    //Definition: at least 6 months of vegetation period
    var permanent=ee.Image(0).where(fittedGreenLength.gte(6),1)
      .where(fittedGreenLastMonth2.gte(10).subtract(fittedGreenFirstMonth2).add(1).gte(6),1);
    //Rabi (winter)
    //Definition: vegetation period starts between November and January
    var rabi=ee.Image(0).rename('Rabi').where(fittedGreenFirstMonth.lt(2).or(fittedGreenFirstMonth.gt(10)),1);
    rabi=rabi.where(permanent.eq(1),0);
    //Zaid (spring)
    //Definition: vegetation period starts between February and May
    var zaid=ee.Image(0).rename('Zaid').where(fittedGreenFirstMonth2.gte(2).and(fittedGreenFirstMonth2.lt(6)),1)
      .where(fittedGreenFirstMonth.gte(2).and(fittedGreenFirstMonth.lt(6)),1);
    zaid=zaid.where(permanent.eq(1),0);
    var fittedGreenFirstMonth1=fittedGreenFirstMonth;//keep this for later
    //Agricultural year starts in July, which is in the previous hydrological year (by which I have extracted the data)
    cropVegPeriod=ee.Image(root + crop_veg_ic + '/' + crop_veg_root_name + state_name +'_'+ (yearx - 1));
    var fittedGreenFirstMonth0=cropVegPeriod.select('first0');
    var fittedGreenLastMonth0=cropVegPeriod.select('last0');
    fittedGreenFirstMonth=cropVegPeriod.select('first');
    fittedGreenLastMonth=cropVegPeriod.select('last');
    fittedGreenFirstMonth2=cropVegPeriod.select('first2');
    fittedGreenLastMonth2=cropVegPeriod.select('last2');
    //I considered hydrological years starting in October --> now convert into calendar year
    fittedGreenFirstMonth=fittedGreenFirstMonth.subtract(4);
    fittedGreenFirstMonth=fittedGreenFirstMonth.where(fittedGreenFirstMonth.lte(0),fittedGreenFirstMonth.add(12));
    fittedGreenLastMonth=fittedGreenLastMonth.subtract(4);
    fittedGreenLastMonth=fittedGreenLastMonth.where(fittedGreenLastMonth.lte(0),fittedGreenLastMonth.add(12));
    fittedGreenFirstMonth2=fittedGreenFirstMonth2.subtract(4);
    fittedGreenFirstMonth2=fittedGreenFirstMonth2.where(fittedGreenFirstMonth2.lte(0),fittedGreenFirstMonth2.add(12));
    fittedGreenLastMonth2=fittedGreenLastMonth2.subtract(4);
    fittedGreenLastMonth2=fittedGreenLastMonth2.where(fittedGreenLastMonth2.lte(0),fittedGreenLastMonth2.add(12));
    //Kharif (summer)
    //Definition: Vegetation period starts between June and September
    var kharif=ee.Image(0).rename('Kharif').where(fittedGreenFirstMonth0.gt(0),1)
      //Kharif ending in October and Rabi starting in October - it is the same crop - should be treated as Rabi (or Rabi should be relabeled as Kharif?)
      .where(fittedGreenLastMonth0.eq(10).and(fittedGreenFirstMonth1.eq(10)),0)
      .where(fittedGreenFirstMonth.gte(6).and(fittedGreenFirstMonth.lte(9)),1)
      .where(fittedGreenFirstMonth2.gte(6).and(fittedGreenFirstMonth2.lte(9)),1)
      .where(permanent.eq(1),0);
    var cropping_intensity=kharif.add(rabi).add(zaid).where(permanent.eq(1),4).rename('ci');
    cluster_map=ee.Image(0).updateMask(cropping_intensity.gt(0)).rename('clusters')
      .where(kharif.gt(0),1).where(rabi.gt(0),2).where(zaid.gt(0),3)
      .where(kharif.gt(0).and(rabi.gt(0)),4).where(kharif.gt(0).and(zaid.gt(0)),5).where(rabi.gt(0).and(zaid.gt(0)),6)
      .where(cropping_intensity.eq(3),7).where(permanent.eq(1),8)
      //MASK BUILT-UP AREAS AND WATER!
      .updateMask(lulc_map.gt(0));
    total_Kharif_area = ee.Number(kharif.updateMask(cluster_map.gt(0)).multiply(ee.Image.pixelArea()).multiply(1e-6).multiply(100).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: command_area.geometry(),
      scale: rRscale,
      maxPixels: 1e13,
      tileScale: rRtileScale
    }).get('Kharif')); 
    //print('Kharif Crop Area',total_Kharif_area);
    total_Rabi_area = ee.Number(rabi.updateMask(cluster_map.gt(0)).multiply(ee.Image.pixelArea()).multiply(1e-6).multiply(100).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: command_area.geometry(),
      scale: rRscale,
      maxPixels: 1e13,
      tileScale: rRtileScale
    }).get('Rabi'));
    //print('Rabi Crop Area',total_Rabi_area);
    total_Zaid_area = ee.Number(zaid.updateMask(cluster_map.gt(0)).multiply(ee.Image.pixelArea()).multiply(1e-6).multiply(100).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: command_area.geometry(),
      scale: rRscale,
      maxPixels: 1e13,
      tileScale: rRtileScale
    }).get('Zaid'));
    //print('Zaid Crop Area',total_Zaid_area);
    avg_cropping_intensity = ee.Number(cropping_intensity.updateMask(cropping_intensity.gt(0)).updateMask(cropping_intensity.lte(3)).reduceRegion({
      reducer: ee.Reducer.mean(),
      geometry: command_area.geometry(),
      scale: rRscale,
      maxPixels: 1e13,
      tileScale: rRtileScale
    }).get('ci')).multiply(100);        
  } else {
    //for other states than Gujarat: use the LULC maps instead of the vegetation period maps
    cluster_map=lulc_map.updateMask(lulc_map.gt(0));
  }
  //print('cluster_map',cluster_map);
  var new_crop_ids=ee.List([1,2,3,4,5,6,7,8]);
  var calculate_area=function(x,cluster_map) {
    var image1=ee.Image(1).updateMask(ee.Image(cluster_map).select('clusters').eq(ee.Number(x))).multiply(ee.Image.pixelArea()).multiply(1e-6).multiply(100);
    //var image2=ee.Image(1).updateMask(ee.Image(cluster_map).select('clusters').eq(ee.Number(x))).multiply(ee.Image.pixelArea()).multiply(1e-6).multiply(100)//.updateMask(irrg_map.eq(1));
    return ee.Image(cluster_map)
      .addBands(image1.rename(ee.String("a").cat(ee.String('00').cat(ee.String(ee.Number(x).int())).slice(-2))));
      //.addBands(image2.rename(ee.String("b").cat(ee.String('00').cat(ee.String(ee.Number(x).int())).slice(-2))));
  };
  var area_image   = ee.Image(ee.Algorithms.If(new_crop_ids.length().eq(0),ee.Image(0),ee.Image(new_crop_ids.iterate(calculate_area, cluster_map)).slice(1)));
  var area_crops = area_image.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: command_area.geometry(),
    scale: rRscale,
    maxPixels: 1e13,
    tileScale: rRtileScale
  }); 
  total_cmd_area=ee.Number(command_area.aggregate_array('AREA_HA').reduce(ee.Reducer.sum()));
  //print('total_cmd_area',total_cmd_area);
  total_crop_area=ee.Number(area_crops.select(['a.*']).values().reduce(ee.Reducer.sum()));
  //print('total_crop_area',total_crop_area);
  //more simple case for states without vegetation period maps
  if (state_name !==state1){
    et_sum=ETA_monthly_maps.filterDate(date_of_max_level.advance(-30,'day'), date_of_min_level.advance(30,'day'))
      .filter(ee.Filter.calendarRange(month_of_max_level, month_of_min_level, 'month'))
      .sum().rename('b1');
    //calculate total P over command area
    p_sum=CHIRPS_daily.filterDate(date_of_max_level, date_of_min_level).sum().rename('b1');      
  }
  //satelliteMap.addLayer(p_sum.updateMask(cluster_map.gt(0)), {bands: ['b1'],min: 0, max: 25, palette: ['white','red']},"p sum " + year)
  //satelliteMap.addLayer(p_sum.setDefaultProjection({crs: utm_zone, scale:10}).updateMask(cluster_map.gt(0)), {bands: ['b1'],min: 0, max: 25, palette: ['white','red']},"p sum " + year)
  vol_p = ee.Number(p_sum/*.reproject(cluster_map.projection())*/.updateMask(cluster_map.gt(0))
    .divide(1000)//mm to m
    .multiply(ee.Image.pixelArea())//pixel area in m2
    //.divide(1000000000)//m³
    .reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: command_area.geometry(),
    scale: rRscale,
    maxPixels: 1e13,
    tileScale: rRtileScale
  }).get('b1'));
  //print('vol_p',vol_p);
  vol_p_annual = ee.Number(CHIRPS_daily.filterDate(ee.Date.fromYMD(ee.Number(yearx).subtract(1),7,1), ee.Date.fromYMD(yearx,7,1)).sum().rename('b1')
  //var vol_p_annual = ee.Number(ee.ImageCollection("UCSB-CHG/CHIRPS/PENTAD").filterDate(ee.Date.fromYMD(ee.Number(year).subtract(1),7,1), ee.Date.fromYMD(year,7,1)).sum().rename('b1')
  /*.reproject(cluster_map.projection())*///.updateMask(cluster_map.gt(0))
    .divide(1000)//mm to m
    .multiply(ee.Image.pixelArea())//pixel area in m2
    //.divide(1000000000)//m³
    .reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: command_area.geometry(),
    scale: rRscale,
    maxPixels: 1e13,
    tileScale: rRtileScale
  }).get('b1'));
  //print('vol_p_annual',vol_p_annual.divide(1000000));
  vol_et_annual = ee.Number(ETA_monthly_maps.filterDate(ee.Date.fromYMD(ee.Number(yearx).subtract(1),7,1), ee.Date.fromYMD(yearx,7,1).advance(-1,'day')).sum().rename('b1')
    .divide(1000)//mm to m
    .multiply(ee.Image.pixelArea())//pixel area in m2
    //.divide(1000000000)//m³
    .reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: command_area.geometry(),
    scale: rRscale,
    maxPixels: 1e13,
    tileScale: rRtileScale
  }).get('b1'));
  tot_tbp = ee.Number(ee.Image(TBP4display.get(ee.Number(yearx).subtract(hy_first_year)))
    .rename('b1')
        .reduceRegion({
        reducer: ee.Reducer.mean(),
        geometry: command_area.geometry(),
        scale: 1000,
        maxPixels: 1e13,
        tileScale: 2
      }).get('b1')).multiply(total_crop_area);
  //print('vol_et_annual',vol_et_annual.divide(1000000));
  vol_et = ee.Number(et_sum/*.reproject(cluster_map.projection())*/.updateMask(cluster_map.gt(0))
    .divide(1000)//mm to m
    .multiply(ee.Image.pixelArea())//pixel area in m2
    //.divide(1000000000)//m³
    .reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: command_area.geometry(),
    scale: rRscale,
    maxPixels: 1e13,
    tileScale: rRtileScale
  }).get('b1'));
}
var total_cmd_area;
var total_crop_area;
var et_sum; var p_sum; var et_fallow;
var total_Kharif_area; var total_Rabi_area; var total_Zaid_area; var avg_cropping_intensity;
var vol_p_annual; var vol_et_annual; var vol_p; var vol_et; var tot_tbp;
function task2b(name,rRscale,rRtileScale){
  middleMap.layers().set(4, ui.Map.Layer(cluster_map.clip(command_area.geometry()), {bands: ['clusters'],min: 0, max: 20, palette: new_palette},"Crop Map " + year).setShown(true));
  unit_name_panel.remove(total_panel);
  unit_name_panel.add(total_panel);
  total_panel.remove(plz_wait2);
  var iteration_id_tmp = iteration_id;
  TotalCommandAreaLabel.setValue( "Total command area (ha):  ");
  TotalCropAreaLabel.setValue( "Total cropped area (ha):  ");
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
        .set('1_Type','Crop Analysis')
        .set('2_Variable','Total Command Area')
        .set('3_TimePeriod','')
        .set('4_Unit','ha')
        .set('5_Value',total_cmd_area)));  
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
        .set('1_Type','Crop Analysis')
        .set('2_Variable','Total Cropped Area')
        .set('3_TimePeriod',year)
        .set('4_Unit','ha')
        .set('5_Value',total_crop_area)));
  total_cmd_area.evaluate(function(result0) {
    total_crop_area.evaluate(function(result) { 
      if (iteration_id == iteration_id_tmp){
        if (isNaN(result)){
          TotalCommandAreaLabel.setValue( "Total command area (ha):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:0}));
          rRscale = rRscale + 20; //print('rRscale',rRscale);
          rRtileScale = 8;
          attempt_no=attempt_no + 1;
          iteration_id=iteration_id + 1;
          plz_wait2.setValue('Please wait... This may still take some time.');
          task2a(name_cmd,rRscale,rRtileScale);
          task2(name_cmd,rRscale,rRtileScale,year,month_of_max_level,month_of_min_level);
          task2b(name_cmd,rRscale,rRtileScale);
        } else {
          TotalCommandAreaLabel.setValue( "Total command area (ha):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:0}));
          TotalCropAreaLabel.setValue( "Total cropped area (ha):  " + result.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:0}));
          total_panel.remove(plz_wait2);
          plz_wait2.setValue('Please wait...');
        }
      }
    });
  });
  total_panel.remove(CroppingIntensityLabel);total_panel.remove(TotalKharifAreaLabel);total_panel.remove(TotalRabiAreaLabel);total_panel.remove(TotalZaidAreaLabel);
  if (state_name==state1){
    total_panel.add(CroppingIntensityLabel);total_panel.add(TotalKharifAreaLabel);total_panel.add(TotalRabiAreaLabel);total_panel.add(TotalZaidAreaLabel);
    total_panel.add(plz_wait2);
    csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
      .set('1_Type','Crop Analysis')
      .set('2_Variable','Average Cropping Intensity')
      .set('3_TimePeriod',year)
      .set('4_Unit','%')
      .set('5_Value',avg_cropping_intensity)));
    csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
      .set('1_Type','Crop Analysis')
      .set('2_Variable','Total Kharif Area')
      .set('3_TimePeriod',year)
      .set('4_Unit','ha')
      .set('5_Value',total_Kharif_area)));
    csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
      .set('1_Type','Crop Analysis')
      .set('2_Variable','Total Rabi Area')
      .set('3_TimePeriod',year)
      .set('4_Unit','ha')
      .set('5_Value',total_Rabi_area)));
    csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
      .set('1_Type','Crop Analysis')
      .set('2_Variable','Total Zaid Area')
      .set('3_TimePeriod',year)
      .set('4_Unit','ha')
      .set('5_Value',total_Zaid_area)));      
    TotalKharifAreaLabel.setValue( "Total Kharif area (ha):  ");
    TotalRabiAreaLabel.setValue( "Total Rabi area (ha):  ");
    TotalZaidAreaLabel.setValue( "Total Zaid area (ha):  ");
    CroppingIntensityLabel.setValue( "Average cropping intensity:  ");
    total_Kharif_area.evaluate(function(result0) {
      if (iteration_id == iteration_id_tmp){
        TotalKharifAreaLabel.setValue( "Total Kharif area (ha):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:0}));
      }
    });
    total_Rabi_area.evaluate(function(result0) {
      if (iteration_id == iteration_id_tmp){
        TotalRabiAreaLabel.setValue( "Total Rabi area (ha):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:0}));
      }
    });
    total_Zaid_area.evaluate(function(result0) {
      if (iteration_id == iteration_id_tmp){
        TotalZaidAreaLabel.setValue( "Total Zaid area (ha):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:0}));
      }
    });
    avg_cropping_intensity.evaluate(function(result0) {
      if (iteration_id == iteration_id_tmp){
        CroppingIntensityLabel.setValue( "Average cropping intensity: " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:0}) + '%');
      }
    });    
  } else {
      total_panel.add(plz_wait2);
  }
  //calculate total ET over cropped area in this period
  TotalPLabel.setValue("Total rainfall over cropped areas (M m³):  ");
  TotalETLabel.setValue("Total ET over cropped areas (M m³):  ");  
  TotalETfallowLabel.setValue("Total ETgreen over cropped areas (M m³):  ");  
  aPLabel.setValue("Total rainfall over command area (M m³):  ");
  aETLabel.setValue("Total ET over command area (M m³):  ");
  VolChange_panel.remove(TotalPLabel);
  VolChange_panel.remove(TotalETLabel);
  VolChange_panel.remove(TotalETfallowLabel);
  aVolChange_panel.remove(aPLabel);
  aVolChange_panel.remove(aETLabel);
  VolChange_panel.add(TotalPLabel).add(TotalETLabel);
  aVolChange_panel.add(aPLabel).add(aETLabel);
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
    .set('1_Type','Rabi Season Water Balance')
    .set('2_Variable','Total rainfall over cropped areas')
    .set('3_TimePeriod',date_of_max_level.format('MMM').cat(ee.String('-').cat(date_of_min_level.format('MMM')).cat(ee.String(' ').cat(ee.String(ee.Number(year))))))
    .set('4_Unit','M m3')
    .set('5_Value',vol_p.divide(1000000)))); 
  vol_p.evaluate(function(result0) { 
    if (iteration_id == iteration_id_tmp){
      if (isNaN(result0)){
          rRscale = rRscale + 20; //print('rRscale',rRscale);
          rRtileScale = 8;
          iteration_id=iteration_id + 1;
          attempt_no=attempt_no + 1;
          plz_wait2.setValue('Please wait... This may still take some time.');
          task2a(name_cmd,rRscale,rRtileScale);
          task2(name_cmd,rRscale,rRtileScale,year,month_of_max_level,month_of_min_level);
          task2b(name_cmd,rRscale,rRtileScale);          
      } else {
        result0=result0/1000000;
      TotalPLabel.setValue("Total rainfall over cropped areas (M m³):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
    }}
  });
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
      .set('1_Type','Annual Water Balance')
      .set('2_Variable','Total rainfall over command area')
      .set('3_TimePeriod',year)
      .set('4_Unit','M m3')
      .set('5_Value',vol_p_annual.divide(1000000))));  
  vol_p_annual.evaluate(function(result0) { 
    if (iteration_id == iteration_id_tmp){
        result0=result0/1000000;
      aPLabel.setValue("Total rainfall over command area (M m³):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
    }
  });
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
      .set('1_Type','Annual Water Balance')
      .set('2_Variable','Total ET over command area')
      .set('3_TimePeriod',year)
      .set('4_Unit','M m3')
      .set('5_Value',vol_et_annual.divide(1000000))));   
  vol_et_annual.evaluate(function(result0) { 
    if (iteration_id == iteration_id_tmp){
        result0=result0/1000000;
      aETLabel.setValue("Total ET over command area (M m³):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
    }
  });  
  //print('et_sum',et_sum);
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
      .set('1_Type','Rabi Season Water Balance')
      .set('2_Variable','Total ET over cropped areas')
      .set('3_TimePeriod',date_of_max_level.format('MMM').cat(ee.String('-').cat(date_of_min_level.format('MMM')).cat(ee.String(' ').cat(ee.String(ee.Number(year))))))
      .set('4_Unit','M m3')
      .set('5_Value',vol_et.divide(1000000)))); 
  // print('vol_et',vol_et);
  vol_et.evaluate(function(result0) {
    if (iteration_id == iteration_id_tmp){
      if (isNaN(result0)){
        } else {
          result0=result0/1000000;
          TotalETLabel.setValue("Total ET over cropped areas (M m³):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }}
  });
  /*if (state_name ==state1){
    VolChange_panel.add(TotalETfallowLabel);
    var vol_et_fallow = ee.Number(et_fallow.updateMask(cluster_map.gt(0))
      .divide(1000)//mm to m
      .multiply(ee.Image.pixelArea())//pixel area in m2
      .reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: command_area.geometry(),
      scale: rRscale,
      maxPixels: 1e13,
      tileScale: rRtileScale
    }).get('b1'));
    vol_et_fallow.evaluate(function(result0) { 
      if (iteration_id == iteration_id_tmp){
        if (isNaN(result0)){
          attempt_no=attempt_no + 1;
          init_res=init_res + 10;
          taskETagain(init_res);
          plz_wait2.setValue('Please wait... Still working on it (attempt: ' + attempt_no + ').');
        } else {
          result0=result0/1000000;
          TotalETfallowLabel.setValue("Total ETgreen over cropped areas (M m³):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }}
    }); 
  }
  var taskETagain = function(init_res){
    getETandETgreen(init_res);
    var vol_et = ee.Number(et_sum.updateMask(cluster_map.gt(0))
      .divide(1000)//mm to m
      .multiply(ee.Image.pixelArea())//pixel area in m2
      .reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: command_area.geometry(),
      scale: rRscale,
      maxPixels: 1e13,
      tileScale: rRtileScale
    }).get('b1'));
    print('vol_et',vol_et);
    vol_et.evaluate(function(result0) { 
      if (iteration_id == iteration_id_tmp){
        if (isNaN(result0)){
        } else {
          result0=result0/1000000;
          TotalETLabel.setValue("Total ET over cropped areas (M m³):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }}
    });
    var vol_et_fallow = ee.Number(et_fallow.updateMask(cluster_map.gt(0))
      .divide(1000)//mm to m
      .multiply(ee.Image.pixelArea())//pixel area in m2
      .reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: command_area.geometry(),
      scale: rRscale,
      maxPixels: 1e13,
      tileScale: rRtileScale
    }).get('b1'));
    print('vol_et_fallow',vol_et_fallow);
    vol_et_fallow.evaluate(function(result0) { 
      if (iteration_id == iteration_id_tmp){
        if (isNaN(result0)){
          attempt_no=attempt_no + 1;
          init_res=init_res + 20;
          taskETagain(init_res);
          plz_wait2.setValue('Please wait... Still working on it (attempt: ' + attempt_no + ').');
          total_panel.remove(plz_wait2);
          total_panel.add(plz_wait2);
        } else {
          total_panel.remove(plz_wait2);
          result0=result0/1000000;
          TotalETfallowLabel.setValue("Total ETgreen over cropped areas (M m³):  " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }}
    });   
  };*/
}
function redraw2(name){//executed whenever a new water body is selected
  csv2export=ee.FeatureCollection([]);
  name_thislake=name;
  key2=name.split('ID_')[1].split(')')[0];
  // print('key2',key2);
  unit_name.setValue("Selected Unit: " + name);
  unit_cmd.setValue("");
  var thisname=key2;
  middleMap.setControlVisibility(true);
  middleMap.remove(selectPanel_first);
  middleMap.remove(selectPanel);
  //middleMap.add(selectPanel);
  middleMap.remove(Logos_PANEL);
  middleMap.add(Logos_PANEL);
  iteration_id=iteration_id + 1;
  var iteration_id_tmp = iteration_id;
  drawingMode=false;
  newfeature=1;
  dataSelector.setValue('-');
  middleMap.remove(legend);
  //middleMap.style().set('cursor', 'hand');
  // get the selected Water Body
  //selectedLake = ee.Feature(Lakes_with_Stats.filter(ee.Filter.eq('Name', name)).first());
  selectedLake = ee.Feature(all_WaterBodies.filter(ee.Filter.eq('Name', name)).first());
  csv2export = ee.FeatureCollection(ee.Feature(selectedLake.centroid().geometry()).copyProperties(selectedLake,null,['Area','Shape_Area','Shape_Leng','WBCODE','WBQULITY','WBRSCODE','h_av'])
    .propertyNames().map(function(x){
      //return ee.Feature(selectedLake.centroid().geometry())
      return ee.Feature(null)
        .set('1_Type','GENERAL')
        .set('2_Variable',ee.String(x))
        .set('3_TimePeriod','')
        .set('4_Unit','')
        .set('5_Value',selectedLake.get(ee.String(x)));
    }));
  csv2export=csv2export.filter(ee.Filter.neq('1_Variable','AREA_HA'));
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(ee.Feature(null)
        .set('1_Type','GENERAL')
        .set('2_Variable','Design Area')
        .set('3_TimePeriod','')
        .set('4_Unit','ha')
        .set('5_Value',selectedLake.get('AREA_HA'))));    
  //unit_download.setUrl(csv2export.sort('1_Type').getDownloadURL({format:'csv',filename:'OUTPUT_'+ name_thislake.replace(/ /g,'').replace(/\./g, '').replace(/'/g,'') + '_Year' + year}));
  //h_av=ee.Number(ee.Feature(feat_all_centroids.filter(ee.Filter.eq('Name', name)).first()).get('h_av')).getInfo();
  h_av=ee.Number(selectedLake.get('h_av')).getInfo();
  // print('h_av',h_av);
  command_area=ee.FeatureCollection(all_schemes.filter(ee.Filter.eq('CNAME',ee.String(selectedLake.get(wb_name)))));
  command_area=ee.Feature(ee.Algorithms.If(ee.Number(command_area.size()).gt(0),
    ee.Feature(command_area.union(100).first()).set('withCmdArea',1),
    ee.Feature(null).set('withCmdArea',0)));
  var sel_withCmd=ee.Feature(ee.FeatureCollection(ee.List([selectedLake,command_area])).union(100).first()).copyProperties(selectedLake).copyProperties(command_area,['withCmdArea']);
    //ee.Feature(all_withCmd.filter(ee.Filter.eq(wb_id, ee.Number.parse(ee.String(key2)))).first());
  // print('sel_withCmd',sel_withCmd);
  centeronthis=sel_withCmd;
  center_again();//it is necessary to give ui.root.widgets().reset some time
  // print('centeronthis',centeronthis);
  //now find out if command area is available for given Reservoir
  var cmd01=ee.Number(sel_withCmd.get('withCmdArea'));
  // print('cmd01',cmd01);
  //selection of other command areas:
  click_state=middleMap.onClick(todo_when_click);
  slider5.setDisabled(true);//slider for crop map
  //unit_name_panel.remove(download_fc);
  unit_name_panel.remove(total_panel);
  aoiisnew=1;
  area_of_interest=selectedLake.geometry();
  //print('selectedLake',selectedLake);
  name_id= ee.String(key2);
  name_id_client=key2;
  lake_area=area_of_interest.area().divide(1000).divide(1000);
  // print('lake_area',lake_area);
  statistics_thislake=feat_all_centroids.filter(ee.Filter.eq(wb_id,ee.Number.parse(ee.String(key2)))).first();
  // print('stats thislake',statistics_thislake);
  //command areas, if available
  path=root + command_areas_folder + '/' +  cmd_areas_root_name +state_name.replace(' ','');
  var irrigation_system= ee.FeatureCollection(path).filter(ee.Filter.eq('CNAME',statistics_thislake.get(wb_name)));
  irrigation_system=ee.Feature(ee.Algorithms.If(irrigation_system.size().gt(0),irrigation_system.first(),ee.Feature(null)));
  // print('irrigation_system',irrigation_system);
  middleMap.centerObject(centeronthis);
  sensor_data_4plotting=ee.ImageCollection(ee.List.sequence(hy_first_year,thisyear).map(function(yr){
    return ee.ImageCollection(loadnewdata(yr))}).iterate(function(ic, previous){return ee.ImageCollection(ic).merge(ee.ImageCollection(previous))},ee.ImageCollection([])))
      .filter(ee.Filter.neq('GENERAL_QUALITY','FAILED'));
  greenest_1to12=ee.List.sequence(hy_first_year,thisyear).map(function(yr){
    return sensor_data_4plotting.filter(ee.Filter.eq('Year', yr)).filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cc_threshold)).qualityMosaic('NDVI').select('NDVI');
  });
  dd = ee.Image().paint(centeronthis.geometry(), 0, 2);
  plotsatelliteimage();
  cb1b.setValue(false,false); cb2b.setValue(false,false); cb8b.setValue(false,false);
  dataSelector.setValue(null,false);
  if (right_selected==1){
    dataSelector.setValue(data_selected);
  }
  //river_fc=ee.FeatureCollection(root + state_name + '_river');
  var FreqMap_res=ee.ImageCollection(root + SurfFreq_root_name + state_name + '/' + ic_SurfFreq_reservoirs);
  var FreqMap_lakes=ee.ImageCollection(root + SurfFreq_root_name + state_name +'/' + ic_SurfFreq_lakes);
  var FreqMapCollection=ee.ImageCollection(ee.List([FreqMap_res.toList(9999),FreqMap_lakes.toList(9999)]).flatten()).map(function(img){
      return ee.Image(img).set('ID',ee.String(ee.String(img.get('system:index')).split('SurfWaterFreq_S2_17to22_').get(1)));
    });
  FreqMap=FreqMapCollection.filter(ee.Filter.eq('ID',thisname)).first();
  FreqMap=FreqMap.multiply(100).round().divide(100);
  /*ts_thislake_l8=ee.FeatureCollection(state_TS.filter(ee.Filter.eq('ID', thisname)).filter(ee.Filter.eq('satellite', 'Landsat')).first())
    .map(function(ft){return ee.Feature(ft).copyProperties(ee.Feature(ft), ['otsu_th','system:time_start','SENSING_TIME', 'SATELLITE','cloud_cover',wb_id,'nodata_cover'])
      .set('dem_elev_Landsat',ee.Feature(ft).get('dem_elev'))}).sort('system:time_start');*/
  ts_thislake_s2=ee.FeatureCollection(state_TS.filter(ee.Filter.eq('ID', thisname)).filter(ee.Filter.eq('satellite', 'Sentinel-2')).first())
    .sort('system:time_start');
  // print('state_TS',ts_thislake_s2);
  if (h_av==1){
    //round hs values to three digits after the comma. This allows identifying all timesteps with level below the defined DEM.
    ts_thislake_s2=ts_thislake_s2.filter(ee.Filter.notNull(['dem_elev'])).map(function(ft){return ee.Feature(ft).set('dem_elev', ee.Number(ee.Feature(ft).get('dem_elev')).multiply(1000).round().divide(1000))})
      .merge(ts_thislake_s2.filter(ee.Filter.eq('dem_elev',null))).sort('system:time_start');
  }
  nb_datapoints0=ts_thislake_s2.size();
  // print('ts_thislake_s2',ts_thislake_s2);
  if (h_av==1){
    task_dem();
    task_filter_outliers();
    path= sedZone_path + state_name + '/' + sedZone_collection + '/';
    thisname=key2;
    sedzone_stack=ee.Image(path +  sedZone_name + thisname + '_' + sedZone_iteration_name).set(wb_id,key2);
  }
  //Storage calculations
  var minFreq=ee.Number(FreqMap.updateMask(FreqMap.gt(0)).updateMask(FreqMap.lte(0.05)).rename('b1').reduceRegion(ee.Reducer.max(),area_of_interest.buffer(500),10).get('b1'));
  var freqFull=minFreq;//usually, 0.05
  area_full=ee.Number(FreqMap.gte(freqFull).multiply(ee.Image.pixelArea())
      .reduceRegion({'reducer':ee.Reducer.sum(),'geometry':area_of_interest.buffer(500),'scale':10,'tileScale':2}).values().get(0));//
  // print('area_full',area_full);
  //Reservoir capacity: difference between maximum and minimum volume of entire time period
  var volchange;
  var maxFreq=ee.Number(FreqMap.rename('b1').reduceRegion(ee.Reducer.max(),area_of_interest,10).get('b1'));
  // print('maxFreq',maxFreq);
  var area_empty=ee.Number(FreqMap.gte(maxFreq).multiply(ee.Image.pixelArea())
      .reduceRegion({'reducer':ee.Reducer.sum(),'geometry':area_of_interest.buffer(500),'scale':10,'tileScale':2}).values().get(0));//
  // print('area_empty',area_empty);
  var empty_frac=maxFreq.eq(1).multiply(area_empty.divide(area_full));
  // print('empty_frac',empty_frac);
  var line2add=ee.Feature(null)
        .set('1_Type','Reservoir Capacity')
        .set('2_Variable','Present Active Storage Capacity')
        .set('3_TimePeriod','2016-2022')
        .set('4_Unit','M m3');
  if (h_av==1){
    //var freqFull=0.05;
    var h0=ee.Number(dem_reservoir.updateMask(FreqMap.eq(freqFull))
      .reduceRegion({'reducer':ee.Reducer.median(),'geometry':area_of_interest.buffer(500),'scale':10,'tileScale':2}).values().get(0));//
    /*var ft0=ee.Feature(null,{'dem_elev':thislevel});
    thislevel=ee.Number(dem_reservoir.updateMask(FreqMap.eq(maxFreq))
      .reduceRegion({'reducer':ee.Reducer.median(),'geometry':area_of_interest.buffer(500),'scale':10,'tileScale':2}).values().get(0));//
    var ft1=ee.Feature(null,{'dem_elev':thislevel});
    volchange=ee.Number(task_volchange(ft0,ft1));*/
    //print('ft0,ft1',ft0,ft1);
    var vol0=ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(h0)).mask()
      .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
      .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1'))
      .multiply(ee.Number(ee.Image(h0).rename('b1').subtract(dem_reservoir).updateMask(dem_reservoir.lte(h0))
      .reduceRegion({'reducer': ee.Reducer.mean(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')));      
    volchange=vol0;
  } else {
    //area "empty"
    /*var a0=ee.Number(FreqMap.gte(maxFreq).multiply(pixelArea0)
      .reduceRegion({'reducer':ee.Reducer.sum(),'geometry':area_of_interest.buffer(500),'scale':10,'tileScale':2}).values().get(0));//
    var v0=ee.Number(0.0000028554).multiply(a0.pow(1.383852053)).multiply(1000000000);*/
    //V-A scaling: 
    var v1=ee.Number(0.0000028554).multiply(area_full.divide(10000).pow(1.383852053)).multiply(1000000000);
    volchange=v1;//.subtract(v0);
    line2add=line2add.set('2_Variable','Present Storage Capacity');
  }
  unit_capacity.setValue("Present Reservoir Capacity (M m³): ");
  line2add=line2add.set('5_Value',volchange.divide(1000000));
  csv2export=ee.FeatureCollection(csv2export.toList(999).add(line2add));   
  // print('reservoir capacity', volchange.divide(1000000));
  empty_frac.evaluate(function(result1) {
    volchange.evaluate(function(result0) {
      result0=result0/1000000;
      /*if (result1>0.1){
        unit_capacity.setValue("Reservoir capacity (M m³): >" + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      } else {
        unit_capacity.setValue("Reservoir capacity (M m³): " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }*/
      if (h_av==1){
        unit_capacity.setValue("Present Active Storage Capacity (2016-2022, M m³): " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      } else {
        unit_capacity.setValue("Present Storage Capacity (M m³): " + result0.toLocaleString('en', {minimumIntegerDigits:1,maximumFractionDigits:2}));
      }
      });
  });
  panel.remove(panel_tmp);
  panel.remove(panel_tmp_b);
  panel.remove(WBpanel);
  if (state_name==state1){
    panel.add(panel_tmp_b);
    panel.add(WBpanel);
  } else {
    panel.add(panel_tmp);
    panel.add(WBpanel);
  }
  name_cmd='...';
  name_cmd_tmp=name_cmd;  
  irrg4sel.setValue(name_cmd);
  //irrg4sel
  //if (start_redraw!==1){
    //var st_key=ee.String(statistics_thislake.get('STATE'));
    //st_key.evaluate(function(state) {
      command_areas=ee.FeatureCollection(root + command_areas_folder + '/' +  cmd_areas_root_name + state_name);
      var cmd_names=command_areas.aggregate_array('CNAME').distinct();
      cmd_names.evaluate(function(names_cmd) {
        irrg4sel.items().reset(["..."].concat(names_cmd).sort());
        irrg4sel.setPlaceholder(name_cmd); 
      });
      if (start_redraw!==1){
        /*if (state_name==state1){
          var names=['...'].concat(gee_codes.Gujarat_names());//precomputed names: much faster
          func0(names,state_name);
        } else {*/
          good_ids.evaluate(function(names) {
            // print('names',names);
            func0(['...'].concat(names),state_name);
          });
        //}
      }
    //});
  //}
  rRtileScale=4;  rRscale=10; init_res=10; checkbox_download.setDisabled(true);
  cmd01.evaluate(function(result) {
    //print('check',result,iteration_id,iteration_id_tmp,aoiisnew);
    if (iteration_id == iteration_id_tmp || aoiisnew===0){//if just another date is selected still select cmd area
    result_cmd=result;
      if (result_cmd==1){
        middleMap.centerObject(centeronthis);
        middleMap.remove(title2);
        title2.setValue('Command Area Identified');
        middleMap.add(title2);
        //var name_common=ee.String(ee.Feature(Lakes_with_Stats.filter(ee.Filter.eq('Name', name_thislake)).first()).get(wb_name));
        name_cmd=name.replace(" (","").split("ID")[0];
        //name_common.evaluate(function(result1) {
        irrg4sel.setValue(null,false);
        //irrg4sel.setPlaceholder(result1);
        irrg4sel.setValue(name_cmd);
        name_cmd_tmp=name_cmd;  
        // print('name_common',name_cmd);
        var task2debounce= ui.util.debounce( function() {
          middleMap.remove(title2);
          title2.setValue('PLEASE WAIT...');
        },5000);
        task2debounce();           
      }
    }});
  var water_level_ts_S2_long=ts_thislake_s2;
  slider8.setDisabled(true);
  long_term_areas=ee.FeatureCollection(getmonthlyAreas(water_level_ts_S2_long)).sort('system:time_start');
  bimonthly_areas=ee.FeatureCollection(getbimonthlyAreas(water_level_ts_S2_long)).sort('system:time_start');
  elev_range=long_term_areas.map(function(feat){return ee.Feature(null)
    .set('month',ee.Feature(feat).get('month'))
    .set('system:time_start',ee.Feature(feat).get('system:time_start'))});
  if (h_av==1){
    //get the bottom elevation of the lake - use it for the long-term average
    var min_level=ee.Number(water_level_ts_S2_long.aggregate_array('dem_elev').reduce(ee.Reducer.min()));
    // print('min_level S2',min_level);//this is assumed to be the level when the lake is empty    
    water_level_ts_S2_long=water_level_ts_S2_long.filter(ee.Filter.neq('area_water', 0))
      .filter(ee.Filter.neq('dem_elev', null))
      .merge(water_level_ts_S2_long.filter(ee.Filter.eq('area_water', 0))
        .map(function(img){return ee.Image(img).set('dem_elev',min_level)}))
        .sort('system:time_start');
    long_term_average=ee.FeatureCollection(getmonthlyLevels(water_level_ts_S2_long)).sort('system:time_start');
    bimonthly_average=ee.FeatureCollection(getbimonthlyLevels(water_level_ts_S2_long)).sort('system:time_start');
    // print('long_term_average',long_term_average);
    // print('water_level_ts_S2_long',water_level_ts_S2_long);
    monthly_anomalies=ee.FeatureCollection(getmonthlyAnomalies(water_level_ts_S2_long));
  //var mind=ee.Number(dem_thislake.get('min_elev_perc_fit'));
    var maxd=ee.Number(dem_thislake.get('max_elev_perc_fit'));
    min_level.evaluate(function(minDEM){
      maxd.evaluate(function(maxDEM){
        if (iteration_id == iteration_id_tmp){
        middleMap.layers().set(0, ui.Map.Layer(dem_thislake.updateMask(FreqMap.lt(1)), {min:minDEM,max:maxDEM,palette:'white,black'},'DEM',false));
        slider8.setDisabled(false);
        }
      });
    });
    // print('outofbounds_sum',long_term_average.aggregate_array('outofbounds_sum'));
    var outofbounds_list=long_term_average.aggregate_array('outofbounds_sum');
    var dryseason_outofbounds=outofbounds_list.slice(0,5).cat(outofbounds_list.slice(9));
    dryseason_outofbounds=dryseason_outofbounds.removeAll(ee.List([0,1]));
    var months_outofbounds=dryseason_outofbounds.length();
    // print('months_outofbounds',months_outofbounds);
    title_multi_annual_tmp='Level [m asl]';
    prefix='Water Levels ';
  } else {
    monthly_anomalies=ee.FeatureCollection(getmonthlyAnomalies2(water_level_ts_S2_long));    
    title_multi_annual_tmp='Water Surface [ha]';
    var zIndex = panel_thisyear.widgets().length();
    if (zIndex==3){
      panel_thisyear.remove(panel_thisyear.widgets().get(2));
    }    
    prefix='Water Surface ';
  }
  task_storage_a();task_storage(date_of_max_level,date_of_min_level,year);task_storage_b();
  unit_download.setUrl(csv2export.sort('1_Type').getDownloadURL({format:'csv',filename:'OUTPUT_'+ name_thislake.replace(/ /g,'').replace(/\./g, '').replace(/'/g,'') + '_Year' + year}));
  var items_var_select_multi1_tmp=items_var_select_multi1;
  items_var_select_multi1prefix=items_var_select_multi1_tmp.map(function(x){
      var label=x.label;
      var y = {label: prefix + label,value: x.value};
      return y;
  });
  //list should be dependent on result_cmd!
  var_select_multi.items().reset(items_var_select_multi1prefix.concat(items_var_select_multi2));    
  // print('monthly anomalies',monthly_anomalies); 
  //middleMap.layers().set(4, ui.Map.Layer(occ_map, {min:0,max:1,palette:'white,blue'}, 'OccMapAsset',false).setOpacity(1));
  wb4sel.setPlaceholder(name);
  select_adm1.setValue(null, false);
  select_adm1.setPlaceholder(name);
  //img_select_l8.items().reset();
  img_select_s2.items().reset();
  //img_select_l8.setPlaceholder('Please wait...');
  img_select_s2.setPlaceholder('Please wait...');
  middleMap.remove(img_select_s2);
  middleMap.add(img_select_s2);
  /*middleMap.remove(img_select_l8);
  middleMap.add(img_select_l8);*/
  //slider3.setValue(0,false);
  //slider4.setValue(0,false);
  slider5.setValue(1,false);
  slider6.setValue(0,false);
  slider8.setValue(0,false);
  middleMap.remove(sliderPanel);
  middleMap.add(sliderPanel);
  sliderPanel.clear();
  sliderPanel.widgets().set(0,ui.Label('Opacity', {fontWeight: '450', fontSize: '14px', margin: '1px 1px 1px 1px'}));
  sliderPanel.add(sliderPanel_base);
  //start_l8=0;
  start_s2=0;
  //var key_number=ee.Number.parse(ee.String(key2).splice(3));
  //print('key_number',key_number);
  //this is really only necessary for after October 2022. For the other years we just need a list of Images.
  get_new_s2();
  var water_surface_probability = FreqMap;
  middleMap.layers().set(2, ui.Map.Layer(water_surface_probability, {min:0,max:1,palette:'white,blue'}, 'water surface probability S2',false).setOpacity(0));
  get_annual_ts();
  get_trend_panel();
  for (var i=0; i<=10; i++) {
    middleMap.layers().get(i).setShown(false);
  }
  var schemes=ee.FeatureCollection(root + command_areas_folder + '/' +  cmd_areas_root_name + state_name);
  // print('schemes',schemes);
  var layerGeometry3 = ui.Map.Layer(schemes.geometry(),{color: '00FF00'},'Irrigation Systems',true);
  middleMap.layers().set(7,layerGeometry3);
  slider2.setValue(1);
  if (h_av==1){
    middleMap.remove(legend);
    slider7.setValue(1);
    middleMap.add(legend);
    sedzoneanalysis();
  } else {
    middleMap.remove(legend);
    slider7.setDisabled(true);
    panel_outputs.widgets().set(1,ui.Label());
    panel_outputs.remove(panel_sedzone);
    sedBalance_label2.setValue("");//bcs this is now under Reservoir Capacity
  }
  middleMap.layers().set(9, ui.Map.Layer(dd,null, "area_of_interest"));
  middleMap.layers().set(5, ui.Map.Layer(dl,{color: 'blue'}, "Lakes",false).setOpacity(0.2));
  //middleMap.layers().set(4, ui.Map.Layer(lakes_fc,{color: 'blue'}, "Lakes").setShown(true));
  //end drawing mode
  start_redraw=0;
}
function getEdge10m(mask) {
  //get a buffer around edge +- 10m
  return mask.focal_max({radius: 10, units: 'meters'}).subtract(mask.focal_min({radius: 10, units: 'meters'}));
}
var img2feat_area=function(image){
    return ee.Feature(null).copyProperties(image, ['area_water','otsu_th','system:time_start','SENSING_TIME', 'SATELLITE','cloud_cover','OBJECTID','nodata_cover']);
};
var img2feat_elev=function(image){
    return ee.Feature(null).copyProperties(image, ['otsu_th','system:time_start','SENSING_TIME', 'SATELLITE','cloud_cover','OBJECTID','nodata_cover','dem_elev']);
};
var cc_feat=function(image){
  return ee.Feature(null).copyProperties(image,['cloud_cover','system:time_start','SENSING_TIME']);
};
  ///////////////
var img_select_s2 = ui.Select({
    items: [],
    style: {position:'top-center',padding:'1px', fontWeight:'bold', backgroundColor: 'red'},
});
img_select_s2.setDisabled(true); 
middleMap.add(img_select_s2);
  img_select_s2.setPlaceholder('Please wait...');
var func4edgeOtsu = function(img){return gee_codes.edgeOtsu_optical(img,dem_reservoir,
          {cannyThreshold: 0.7,
            cannySigma: 0.7,
            minimumValue: -0.3,
            maximumValue: 0.3,
            scale: 30,
            th_veg: 0.5,
            withDEM: true,
            keepMNDWI:true,
          })};
function get_new_s2(){ 
  var iteration_id_tmp = iteration_id;
  withbands_s2 = ee.ImageCollection(gee_codes.get_s2_images(area_of_interest.buffer(buffer_width),start_date,end_date,
    {nodata_thresh: nodata_thresh,
    cc_thresh: cc_thresh,
    cc_pix: cc_pix,
    }));
  var img_names_s2=withbands_s2.sort('system:time_start').aggregate_array('SENSING_TIME');
  img_list_s2=ee.Dictionary.fromLists(img_names_s2.distinct(), img_names_s2.distinct()).keys();
  //print('img_list_s2',img_list_s2);  
  //uncomment in operational mode!
  /*
  var edge_imgs_s2 = ee.ImageCollection(withbands_s2.map(func4edgeOtsu));
  var aoi_img=ee.Image(0).clip(area_of_interest.buffer(buffer_width)).blend(ee.Image(1).clip(area_of_interest)).float();
  var edge_img4DEM = ee.ImageCollection(gee_codes.get_corrected_elevation_DEM(edge_imgs_s2, null, {//sed_thislake
    filter_outliers: false, //optional: filter out the noisiest shorelines (dh_std >= two standard deviations of the entire ensemble)
    pvalues: true, //optional: consider only pixels with p-values <0.1
    additional_exports: true, //calculate also the water surface area and additional properties
    },aoi_img));
  feat_area_s2 = ee.FeatureCollection(edge_img4DEM.map(img2feat_area));
  print('feat_area_s2',feat_area_s2);
  feat_elev_s2 = ee.FeatureCollection(edge_img4DEM.map(img2feat_elev));
  print('feat_elev_s2',feat_elev_s2);*/
  img_select_s2.items().reset();
  img_select_s2.setDisabled(true);  
  img_select_s2.setPlaceholder('Please wait...');
  img_list_s2.evaluate(function(result1b){
        if (iteration_id == iteration_id_tmp){
    img_select_s2.items().reset(result1b);
    img_select_s2.setPlaceholder('Select Sentinel-2 Scene');
    img_select_s2.setDisabled(false);
    img_select_s2.onChange(draw_s2);
        }
  });  
}
//////////////////////
var start_s2=0;
//var start_l8=0;
//-----------------------------------------------------------------------------------------
//VISUALIZATION
//-----------------------------------------------------------------------------------------
var draw_s2 = function(key){
  if (start_s2===0){
    start_s2=1;
    sliderPanel.clear();
      sliderPanel.widgets().set(0,ui.Label('Opacity', {fontWeight: '450', fontSize: '14px', margin: '1px 1px 1px 1px'}));
      sliderPanel.widgets().set(1,ui.Label('Waterline', {fontWeight: '450', fontSize: '10px', margin: '1px 1px 1px 1px'}));
      sliderPanel.widgets().set(2,slider1_panel);
      sliderPanel.widgets().set(3,ui.Label('Sentinel-2 RGB', {fontWeight: '450', fontSize: '10px', margin: '1px 1px 1px 1px'}));
      sliderPanel.widgets().set(4,slider3);
      sliderPanel.add(sliderPanel_base);
  }
    var start_date0=ee.Date(key);
    var end_date0=ee.Date(key).advance(1,'day');
    withbands_s2 = ee.ImageCollection(gee_codes.get_s2_images(area_of_interest.buffer(buffer_width),start_date0,end_date0,
      {nodata_thresh: nodata_thresh,
      cc_thresh: cc_thresh,
      cc_pix: cc_pix,
      }));
    var edge_imgs_s2 = ee.ImageCollection(withbands_s2
        //returns the DEM clipped to the shorelines for each scene
         .map(func4edgeOtsu));
    var aoi_img=ee.Image(0).clip(area_of_interest.buffer(buffer_width)).blend(ee.Image(1).clip(area_of_interest)).float();
    var edge_img4DEM = ee.ImageCollection(gee_codes.get_corrected_elevation_DEM(edge_imgs_s2, null, {//sed_thislake
      filter_outliers: false, //optional: filter out the noisiest shorelines (dh_std >= two standard deviations of the entire ensemble)
      pvalues: true, //optional: consider only pixels with p-values <0.1
      additional_exports: true, //calculate also the water surface area and additional properties
      },aoi_img));
    //print('edge_img4DEM',edge_img4DEM);
    feat_area_s2 = ee.FeatureCollection(edge_img4DEM.map(img2feat_area));
    // print('feat_area_s2',feat_area_s2);
    feat_elev_s2 = ee.FeatureCollection(edge_img4DEM.map(img2feat_elev));
    // print('feat_elev_s2',feat_elev_s2);
    var img1 = ee.Image(withbands_s2.filter(ee.Filter.eq('SENSING_TIME', key)).mosaic())
      .addBands(ee.Image(withbands_s2.filter(ee.Filter.eq('SENSING_TIME', key)).first()).select(['cloud']));
    var feature4 = ee.Feature(feat_elev_s2.filter(ee.Filter.eq('SENSING_TIME', key)).first());
    middleMap.layers().set(6, ui.Map.Layer(img1, {bands: (['R', 'G', 'B']), min: 0, max: 3000}, 's2 RGB'));
    slider3.setValue(1);
    slider1.setValue(1);
    // print('Lake shore scene: ', feature4);
    img_select_s2.setValue(null,false);
    img_select_s2.setPlaceholder('Sen-2: ' + key);
  // compute threshold using Otsu thresholding
  var image=img1;
  var bounds=area_of_interest;
  var mndwi = image.select('MNDWI');
  var imgcloud = image.select('cloud');
  var maxValue=0.3;
  mndwi=mndwi.where(mndwi.gt(maxValue),maxValue);//bcs we do not want to detect edges between free water and vegetation overgrown water
  //OTSU THRESHOLD
  var scale=ee.Number(30);
  var th = gee_codes.computeThresholdUsingOtsu(mndwi.updateMask(imgcloud.lt(100)), scale, bounds.buffer(buffer_width), cannyThreshold, cannySigma, minValue, debug);
  var th_veg = 0.5;
  var veg_edge=ee.Image(1).updateMask(
    img1.select('NDVI').gt(th_veg).focal_max({radius: 30, units: 'meters'}).subtract(img1.select('NDVI').gt(th_veg).focal_min({radius: 30, units: 'meters'}))
    );
  veg_edge=ee.Image(0).where(veg_edge.eq(1),1);  
  var dem_edge=ee.Image(1).mask(getEdge10m(mndwi.gt(th))).updateMask(imgcloud.lt(100));//.updateMask(veg_edge.neq(1))
  middleMap.layers().set(8, ui.Map.Layer(dem_edge, {palette:'#008000'}, 'Edge S2'));//.difference(sedimentation_zone)
};
//-----------------------------------------------------------------------------------------
//VISUALIZATION
//-----------------------------------------------------------------------------------------
/////////CHARTS//////
var options_dic={
        hAxis: {/*title:'Year',*/titleTextStyle:{fontSize: 12},viewWindowMode: 'maximized',textStyle:{fontSize: 10},gridlines: { count: 12 }},//
        lineWidth: 1,
        pointSize: 2,
        legend: {position:"top",textStyle:{fontSize: 10}},
        fontSize: 22,
        series: {
          0: {color: '#008000',labelInLegend: 'Sentinel-2'}, // 
          1: {color: 'red',labelInLegend: 'Average ' + (hy_first_year - 1) + '-' + thisyear,lineWidth: 2,opacity: 0.2,}, // 
        },
    vAxis: {title: 'Water Surface [ha]',titleTextStyle:{fontSize: 12},gridlines: { count: 0 },minValue: 0,textStyle:{fontSize: 10} }
};  
var options_dic2={
        hAxis: {/*title:'Year',*/titleTextStyle:{fontSize: 10},viewWindowMode: 'maximized',textStyle:{fontSize: 10},gridlines: { count: 12 }},//
        lineWidth: 1,
        pointSize: 2,
        legend: {position:"top",textStyle:{fontSize: 10}},
        fontSize: 22,
        series: {
          3: {color: '#008000',labelInLegend: 'Sentinel-2'}, // 
          2: {color: 'red',labelInLegend: 'Average ' + (hy_first_year - 1) + '-' + thisyear,lineWidth: 2,opacity: 0.2,}, 
          0: {color: 'grey',labelInLegend: 'Fitted Range',lineWidth: 1,visibleInLegend : true,pointsVisible: false},
          1: {color: 'grey',labelInLegend: 'Fitted Range',lineWidth: 1,visibleInLegend : false,pointsVisible: false},          
        },
        vAxes: {
          0: {title: 'Level [m asl]',titleTextStyle:{fontSize: 12},textStyle:{fontSize: 10}}, //00FF00
        },
        vAxis: {gridlines: { count: 0 } },//title: 'Dust Storm [no:0, yes:1]',gridlines: { count: 0 }
};
var options_dic3={
        hAxis: {/*title:'Year',*/titleTextStyle:{fontSize: 12},viewWindowMode: 'maximized',textStyle:{fontSize: 10},gridlines: { count: 12 }},//
        lineWidth: 1,
        pointSize: 2,
        legend: {position:"top",textStyle:{fontSize: 10}},
        fontSize: 22,
        series: {
          0: {color: '#008000',labelInLegend: 'Reservoir Storage Volume'}, // 
        },
    vAxis: {title: 'Storage Volume [M m³]',titleTextStyle:{fontSize: 12},gridlines: { count: 0 },minValue: 0,textStyle:{fontSize: 10} }
};  
var var_select_single = ui.Select({items: [ 
      {label:  'Water Levels', value: 0},
      {label:  'Water Areas', value: 1},
      {label:  'Storage Volumes', value: 2},
     ],
    onChange: function(key){
      panel_thisyear.remove(plot_waterarea);
      panel_thisyear.remove(plot_waterlevel);
      panel_thisyear.remove(plot_watervol);
        if (key===0){
        if (h_av==1){
          panel_thisyear.add(plot_waterlevel);
        } else {
          panel_thisyear.widgets().set(2,ui.Label({value:'Water levels are not available for this water body',style :{color: 'red',}})); 
        }
      } else if (key==1) {
        panel_thisyear.add(plot_waterarea);
      } else {
        panel_thisyear.add(plot_watervol);
        if (h_av==1){
          var_select_single.setValue(null,false);
          var_select_single.setPlaceholder('Active Storage Volume');
        }
      }
    }});
var plot_waterlevel=ui.Label();//actually, Chart(), but leads to error with empty brackets in App
var plot_waterarea=ui.Label();//actually, Chart(), but leads to error with empty brackets in App
var plot_watervol=ui.Label();//actually, Chart(), but leads to error with empty brackets in App
var panel_single=ui.Panel([ui.Label('Select a variable:', {fontSize: '14px', margin: '15px 10px 1px 1px'})
  ,var_select_single], ui.Panel.Layout.Flow('horizontal'));
var get_vol_from_level = function(ft){
  var h1=ee.Number(ee.Feature(ft).get('dem_elev'));
  return ee.Feature(ft).set('vol_water',ee.Number(dem_reservoir.updateMask(dem_reservoir.lte(h1)).mask()
      .multiply(ee.Image.pixelArea())//surface, multiplied by depth:
      .reduceRegion({'reducer': ee.Reducer.sum(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1'))
      .multiply(ee.Number(ee.Image(h1).rename('b1').subtract(dem_reservoir).updateMask(dem_reservoir.lte(h1))
      .reduceRegion({'reducer': ee.Reducer.mean(),'geometry': area_of_interest.buffer(500),'scale':10}).get('b1')))
      .divide(1000000));
};
var get_vol_from_area = function(ft){
  var a1=ee.Number(ee.Feature(ft).get('area_water'));
  return ee.Feature(ft).set('vol_water',ee.Number(0.0000028554).multiply(a1.pow(1.383852053)).multiply(1000000000)
    .divide(1000000));
};
function get_annual_ts(){
  panel_thisyear.clear();
  panel_thisyear.widgets().set(0,ui.Label('Annual time-series:',{fontWeight: 'bold',fontSize: '16px',margin: '1px 10px 1px 1px',padding: '0'}));
  panel_thisyear.widgets().set(1,panel_single);
    var water_area_ts_S2; var water_vol_s;
    long_term_areas=long_term_areas.map(function(feat){
      var month=ee.Number(ee.Feature(feat).get('month'));
      var yr=ee.Algorithms.If(month.gte(7),ee.Number(year).subtract(1),year);
      return ee.Feature(feat).set('system:time_start', ee.Date.fromYMD(ee.Number(yr), month, 15));
    });
    if (h_av==1){
      long_term_average=long_term_average.map(function(feat){
        var month=ee.Number(ee.Feature(feat).get('month'));
        var yr=ee.Algorithms.If(month.gte(7),ee.Number(year).subtract(1),year);
        return ee.Feature(feat).set('system:time_start', ee.Date.fromYMD(ee.Number(yr), month, 15));
      });
    }
    elev_range=elev_range.map(function(feat){
      var month=ee.Number(ee.Feature(feat).get('month'));
      var yr=ee.Algorithms.If(month.gte(7),ee.Number(year).subtract(1),year);
      return ee.Feature(feat).set('system:time_start', ee.Date.fromYMD(ee.Number(yr), month, 15));
    });
    if (year <= ts_last_year){
      water_area_ts_S2=ee.FeatureCollection(ee.Algorithms.If(ee.Algorithms.IsEqual(ts_thislake_s2,null),feat_area_s2,ts_thislake_s2));  
      water_area_ts_S2=water_area_ts_S2.filterDate(start_date, end_date).sort('system:time_start')
        .filter(ee.Filter.gt('otsu_th', -0.3))
        .filter(ee.Filter.lt('nodata_cover', 10))
        .merge(water_area_ts_S2.filter(ee.Filter.gte('nodata_cover', 10)).map(function(img){return ee.Image(img).set('area_water',null)}))
        .sort('system:time_start');
      // print('water_area_ts_S2',water_area_ts_S2);
    } else {
      water_area_ts_S2=feat_area_s2.filter(ee.Filter.gt('otsu_th', -0.3));
    }
    var water_areas_s=ee.FeatureCollection([water_area_ts_S2,long_term_areas]).flatten();
    // print('Lake area plot',water_areas_s);
    plot_waterarea = ui.Chart.feature.byFeature(water_areas_s, 'system:time_start',['area_water','amonthly'])//
      //.setDataTable(ee.FeatureCollection(feat_area_s2))
      .setChartType('ScatterChart')
      .setOptions(options_dic);
    //panel_thisyear.widgets().set(1,plot_waterarea);
    //now the water level plot
    var water_level_ts_S2;
    if (year <= ts_last_year){
    // print('name_id_client',name_id_client);
      water_level_ts_S2=ee.FeatureCollection(ee.Algorithms.If(ee.Algorithms.IsEqual(ts_thislake_s2,null),feat_elev_s2,ts_thislake_s2))
        .filterDate(start_date, end_date)
        .filter(ee.Filter.gt('otsu_th', -0.3))
        .filter(ee.Filter.neq('otsu_th', 99));
      water_level_ts_S2=water_level_ts_S2
        .sort('system:time_start');
      // print('water_level_ts_S2',water_level_ts_S2);
  } else {
      water_level_ts_S2=feat_elev_s2        
        .filter(ee.Filter.gt('otsu_th', -0.3));
  }
  //ATTENTION: null VALUES CREATE PROBLEMS IF THEY APPEAR FIRST IN THE LIST OF FEATURES
  // it leads to the error “All series on a given axis must be of the same data type”
  // API is somehow assuming that the data type of that column is null...
  var water_level_ts_S2_2plot=water_level_ts_S2.sort('system:time_start');
  function plotelevation(){
    elev_range=elev_range.map(function(feat){return ee.Feature(feat)
      .set('min_bound',dem_thislake.get('min_elev_perc_fit'))
      .set('max_bound',dem_thislake.get('max_elev_perc_fit'))});
    var prop_s2=ee.FeatureCollection([water_level_ts_S2_2plot,long_term_average,elev_range]).flatten();//.filter(ee.Filter.gt('dem_elev', -10))
      // print('Lake elevation plot',prop_s2);
      plot_waterlevel = ui.Chart.feature.byFeature(prop_s2, 'system:time_start',['min_bound','max_bound','hmonthly','dem_elev'])
        .setChartType('ScatterChart')
        .setOptions(options_dic2);
     // panel_thisyear.widgets().set(2,plot_waterlevel); 
  }
  var_select_single.setValue(null,false);
  if (h_av==1){
    plotelevation();
    var_select_single.setValue(0);
    water_vol_s=water_level_ts_S2_2plot.filter(ee.Filter.gte('dem_elev',0)).map(get_vol_from_level);
  } else {
    var_select_single.setValue(1);
    water_vol_s=water_area_ts_S2.filter(ee.Filter.gte('area_water',0)).map(get_vol_from_area);
  }
  // print('water_vol_s',water_vol_s);
  // print('area-vol scaling',water_area_ts_S2.filter(ee.Filter.gte('area_water',0)).map(get_vol_from_area));
  plot_watervol = ui.Chart.feature.byFeature(water_vol_s, 'system:time_start',['vol_water'])//
    .setChartType('ScatterChart')
    .setOptions(options_dic3);
}
//if h_av==1 --> levels in Label, otherwise area
var items_var_select_multi1=[ 
      {label:  'Dry Season (Nov-May)', value: 0},
      {label:  'Jan-March', value: 1},
      {label:  'Apr-June', value: 2},
      {label:  'July-Sep', value: 3},
      {label:  'Oct-Dec', value: 4}
     ];
var items_var_select_multi1prefix;
var items_var_select_multi2=[ 
      {label:  'Annual Storage Change', value: 12},
      {label:  'Seasonal Storage Change', value: 13},
     ];
var items_var_select_multi3=[ 
      {label:  'Cropping Intensity', value: 5},
      {label:  'Annual Rainfall', value: 6},
      {label:  'Annual ET', value: 7},
      {label:  'Annual Biomass Production', value: 14},
      {label:  'Seasonal Rainfall (Nov-May)', value: 8},
      {label:  'Seasonal ET (Nov-May)', value: 9},
      {label:  'Kharif/Rabi/Zaid Crop Areas', value: 10},
      {label:  'Total Area under Crops', value: 11},//total_crop_area      
     ];
var var_select_multi = ui.Select({items: items_var_select_multi1.concat(items_var_select_multi2),
    onChange: function(key){
      season=key;
      if (season <= 4){
        print_and_plot_trend(monthly_anomalies,season,true,area_of_interest);
      } else{
        print_and_plot_trend([],key,true,area_of_interest);
      }
    }}).setPlaceholder(season_labels[season]);
var panel_multi=ui.Panel([ui.Label('Select a variable:', {fontSize: '14px', margin: '15px 10px 1px 1px'})
  ,var_select_multi], ui.Panel.Layout.Flow('horizontal'));
function get_trend_panel(){
  panel_trend.clear();
  panel_trend.widgets().set(0,ui.Label('Multi-Annual Analysis:',{fontWeight: 'bold',fontSize: '16px',margin: '1px 10px 1px 1px',padding: '0'}));
  panel_trend.widgets().set(1, panel_multi); 
  print_and_plot_trend(monthly_anomalies,0,true,area_of_interest);  
}
//panel_outputs.add(panel_thisyear);
//print('panel_thisyear',panel_thisyear.widgets().get(0).getOptions());
var dl = ee.Image().paint(ee.FeatureCollection([]), 0, 2);
var dd=dl;
middleMap.addLayer(dl,null,'dummy layer',false);
middleMap.addLayer(dl,null,'dummy layer',false);
middleMap.addLayer(dl,null,'dummy layer',false);
middleMap.addLayer(dl,null,'dummy layer',false);
middleMap.addLayer(dl,null,'dummy layer',false);
middleMap.addLayer(dl,null,'dummy layer',false);
middleMap.addLayer(dl,null,'dummy layer',false);
middleMap.addLayer(dl,null,'dummy layer',false);
middleMap.addLayer(dl,null,'dummy layer',false);
middleMap.addLayer(dl,null,'dummy layer',false);
middleMap.addLayer(dl,null,'dummy layer',false);
satelliteMap.addLayer(dl,null,'dummy layer',false);
satelliteMap.addLayer(dl,null,'dummy layer',false);
var pointclick;
var pointclick_instate;
var select_adm0b = ui.Select({items: state_list,onChange:function(key) {
    redraw(key);
    select_adm0b.setValue(null, false);
    select_adm0b.setPlaceholder('Select a State ...');
    select_adm0.setPlaceholder(key);
}}).setPlaceholder('Select a State ...'); 
var select_adm0_first = ui.Panel([select_adm0b], ui.Panel.Layout.Flow('horizontal'));
comps_first.add(select_adm0_first);
var selectPanel_first = ui.Panel({widgets : [/*hydrosolutions_manual,*/comps_first],layout: ui.Panel.Layout.flow('vertical'), style :{position : "top-left",maxWidth: "250px"}});
function reselect(){
  //middleMapPanel.remove(middleMap);
  splitPanel1.getFirstPanel().remove(middleMap);
  //middleMapPanel.add(middleMap);
  ui.root.widgets().reset([middleMap]);
  //ui.root.widgets().reset([middleMapPanel]);
    middleMap.remove(title2);
    title2.setValue('PLEASE WAIT...');  
  center_again2;
  middleMap.add(selectPanel_first);
  middleMap.remove(selectPanel);
  middleMap.remove(sliderPanel);
  middleMap.add(sliderPanel);
  middleMap.remove(Logos_PANEL);
  middleMap.add(Logos_PANEL);
  season=0;
  middleMap.remove(legend);
  middleMap.remove(trend_panel);
  panel_thisyear.clear();
  panel_sedzone.clear();
  panel_trend.clear();
  middleMap.centerObject(all_WaterBodies,5);
  middleMap.remove(img_select_s2);
  //middleMap.remove(img_select_l8);
  middleMap.add(trend_panel);
  middleMap.unlisten(sedclick);
  middleMap.unlisten(pointclick_instate);
  middleMap.style().set('cursor', 'crosshair');
  middleMap.setControlVisibility(false);
  middleMap.setControlVisibility({zoomControl: true, layerList: true});
  sliderPanel.clear();
  sliderPanel.add(title_first);
  feat_centroids=state_list.map(function(x){
    var state_name= x;
    var stats_thisstate=ee.FeatureCollection(state_summaries.filter(ee.Filter.eq('STATE', state_name.replace(' ',''))));
    var state_summary=stats_thisstate
    //.filter(ee.Filter.lt('bias_rel', 10))
    .filter(ee.Filter.gte('p_remaining', 50))
      //.filter(ee.Filter.lt('rmse_rel', 20))
      .filter(ee.Filter.gt('correlation', 0.8));
      //.filter(ee.Filter.or(ee.Filter.lt('bias_rel_fitted', 10),ee.Filter.lt('rmse_rel_fitted', 20)));//??
    var centroids_thisstate=ee.FeatureCollection(state_summary.map(function(feat){return ee.Feature(feat).centroid()}));
    return centroids_thisstate;
  });
  // print('feat_centroids',feat_centroids);
  feat_centroids=ee.FeatureCollection(feat_centroids).flatten();
  //print('Water bodies with command area',feat_centroids.filter(ee.Filter.eq('withCmdArea',1)));
  feat_all_centroids=feat_centroids;//.flatten();
  feat_missing_centroids=feat_centroids.filter(ee.Filter.eq('h_av',0));
  feat_centroids=feat_centroids.filter(ee.Filter.eq('h_av',1));
  // print('feat_all_centroids',feat_all_centroids);
  // print('total number of features',feat_centroids.size());
  collection_ids=feat_centroids.aggregate_array(wb_id);
  Lakes_with_Stats = all_WaterBodies.filter(ee.Filter.inList(wb_id, collection_ids));
  good_ids= Lakes_with_Stats.sort(wb_id).sort('Name').aggregate_array('Name').distinct();
  good_ids= all_WaterBodies.filter(ee.Filter.inList('Name', good_ids)).sort(wb_id).sort('Name').aggregate_array('Name').distinct();
  drawingMode=true;
  season_overall=0;
  plot_centroids(season_overall);
  //selecect lakes by clicking on map - before selection of state
  pointclick=middleMap.onClick(function(coords) {
    if(drawingMode){
      //point = ee.Geometry.Point(coords.lon, coords.lat);
      point = ee.Geometry.Point(coords.lon, coords.lat).buffer(1500,500);
      //get the name of selected lake
      //WAIT A SECOND - NOT ALL WATER BODIES! ONLY THOSE IN SELECTION!
      var feat=ee.Feature(Lakes_with_Stats.filterBounds(point).first());
      var name=ee.String(feat.get(wb_name));
      var lake_name=ee.Algorithms.If(name.length().gt(0),name.cat(' (').cat(ee.String('ID_').cat(ee.Number.parse(feat.get(wb_id)))).cat(')'),
          ee.String('ID_').cat(ee.Number.parse(feat.get(wb_id))));
      middleMap.style().set('cursor', 'hand');
      drawingMode=false;
      middleMap.remove(title2);    
      middleMap.add(title2);    
      ee.Number(feat_all_centroids.filterBounds(point).size()).evaluate(function(result){
        if (result===0){
          middleMap.style().set('cursor', 'crosshair');
          drawingMode=true;
          title2.setValue('SELECTION UNSUCCESSFUL, PLEASE ZOOM IN FIRST');
          var task2debounce= ui.util.debounce( function() {
            middleMap.remove(title2);
            title2.setValue('PLEASE WAIT...');
          },5000);
          task2debounce();
        } else {
          middleMap.remove(sliderPanel);middleMap.remove(trend_panel);
          selectedState = ee.Feature(adm_1.filterBounds(point).first());
          state_name = selectedState.get(adm1_fieldname);
          // print('state_name',state_name); 
          middleMap.centerObject(point,11);
          // print('lake_name',lake_name);
          // print('lake_area',ee.Feature(Lakes_with_Stats.filterBounds(point).first()).get('AREA_HA'));
          title2.setValue('SELECTION SUCCESSFUL, PLEASE WAIT');
          ee.String(lake_name).evaluate(function(xx) {
            ee.String(state_name).evaluate(function(yy) {
              state_name=yy;
              middleMap.style().set('cursor', 'crosshair');
              root4redraw2();
              redraw2(xx);
            });
          });
        }
      });
    }  
  });
}
reselect();