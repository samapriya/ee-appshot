// Load the NLCD Land Cover Image Collection
var nlcd_landcover = ee.ImageCollection("projects/sat-io/open-datasets/USGS/ANNUAL_NLCD/LANDCOVER");
// Define class values, remapped values, color palette, and simplified class names
var originalClasses = [11, 12, 21, 22, 23, 24, 31, 41, 42, 43, 52, 71, 81, 82, 90, 95];
var remappedClasses = ee.List.sequence(1, originalClasses.length);
var palette = [
  '#466b9f', '#d1def8', '#dec5c5', '#d99282', '#eb0000', '#ab0000',
  '#b3ac9f', '#68ab5f', '#1c5f2c', '#b5c58f', '#ccb879', '#dfdfc2', 
  '#dcd939', '#ab6c28', '#b8d9eb', '#6c9fb8'
];
var classNames = [
  "Open Water", "Perennial Ice/Snow", "Developed, Open Space", "Developed, Low Intensity", 
  "Developed, Medium Intensity", "Developed, High Intensity", "Barren Land", 
  "Deciduous Forest", "Evergreen Forest", "Mixed Forest", "Shrub/Scrub", 
  "Grassland/Herbaceous", "Pasture/Hay", "Cultivated Crops", "Woody Wetlands", 
  "Emergent Herbaceous Wetlands"
];
// Remap each image's land cover classes and retain the year property
function remapImage(image) {
  var remapped = image.remap(originalClasses, remappedClasses, null);
  return remapped.copyProperties(image, ['year']).set('system:time_start', image.get('system:time_start'));
}
var remappedCollection = nlcd_landcover.map(remapImage);
// Visualization parameters
var landCoverVis = {
  min: 1,
  max: remappedClasses.length().getInfo(),
  palette: palette
};
// Function to get the image for a given year
function getImageByYear(year) {
  return remappedCollection.filter(ee.Filter.eq('year', year)).first();
}
// Define a list of years from 1985 to 2023 (client-side)
var yearList = ee.List.sequence(1985, 2024).getInfo().map(String); // Get years as client-side strings
// Create map instances
var map1 = ui.Map();
var map2 = ui.Map();
// Set initial center for both maps
map1.setCenter(-115.1393, 36.1408, 10);
map2.setCenter(-115.1393, 36.1408, 10);
// Link the maps for synchronized zooming and panning
var linker = ui.Map.Linker([map1, map2]);
// Create the split panel with linked maps
var splitPanel = ui.SplitPanel({
  firstPanel: linker.get(0),
  secondPanel: linker.get(1),
  orientation: 'horizontal',
  wipe: true,
});
ui.root.widgets().reset([splitPanel]);
// Create year selectors for each map, positioned in the middle-left and middle-right
var yearSelect1 = ui.Select({
  items: yearList,
  value: yearList[0],
  onChange: function(value) {
    updateMap1(value);
  },
  style: {position: 'middle-left', width: '150px', padding: '8px'}
});
var yearSelect2 = ui.Select({
  items: yearList,
  value: yearList[yearList.length - 1],
  onChange: function(value) {
    updateMap2(value);
  },
  style: {position: 'middle-right', width: '150px', padding: '8px'}
});
map1.add(ui.Panel([ui.Label('Select Year 1'), yearSelect1], ui.Panel.Layout.Flow('vertical'), {position: 'middle-left'}));
map2.add(ui.Panel([ui.Label('Select Year 2'), yearSelect2], ui.Panel.Layout.Flow('vertical'), {position: 'middle-right'}));
// Function to update map1 based on selected year
function updateMap1(year) {
  var image = getImageByYear(parseInt(year)).visualize(landCoverVis);
  map1.layers().set(0, ui.Map.Layer(image, {}, 'Year: ' + year));
}
// Function to update map2 based on selected year
function updateMap2(year) {
  var image = getImageByYear(parseInt(year)).visualize(landCoverVis);
  map2.layers().set(0, ui.Map.Layer(image, {}, 'Year: ' + year));
}
// Initialize the maps with default years
updateMap1(yearSelect1.getValue());
updateMap2(yearSelect2.getValue());
// Create a legend for land cover classes with multiple columns
function createLegend() {
  var legend = ui.Panel({
    style: {
      position: 'bottom-left',
      padding: '8px 15px'
    }
  });
  legend.add(ui.Label({
    value: 'Land Cover Legend',
    style: {
      fontWeight: 'bold',
      fontSize: '16px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  }));
  var numColumns = 4;
  var columns = [];
  for (var i = 0; i < numColumns; i++) {
    columns.push(ui.Panel({
      layout: ui.Panel.Layout.Flow('vertical'),
      style: {margin: '0 10px 0 0'}
    }));
  }
  for (var i = 0; i < classNames.length; i++) {
    var colorBox = ui.Label({
      style: {
        backgroundColor: palette[i],
        padding: '8px',
        margin: '0 0 4px 0'
      }
    });
    var description = ui.Label({
      value: classNames[i],
      style: { margin: '0 0 4px 6px' }
    });
    var row = ui.Panel({
      widgets: [colorBox, description],
      layout: ui.Panel.Layout.Flow('horizontal')
    });
    columns[i % numColumns].add(row);
  }
  var legendRow = ui.Panel({
    widgets: columns,
    layout: ui.Panel.Layout.Flow('horizontal')
  });
  legend.add(legendRow);
  // Add the legend to the first map
  map1.add(legend);
}
// Call function to create the legend initially
createLegend();
// Create a styled data panel with attribution, similar to the reference image
var dataPanel = ui.Panel({
  widgets: [
    ui.Label({
      value: 'Annual NLCD Landcover Datasets',
      style: {
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '0 0 8px 0',
        color: '#333'
      }
    }),
    ui.Label({
      value: 'Provided by: United States Geological Survey (USGS) & Multi-Resolution Land Characteristics (MRLC) Consortium',
      style: {
        fontSize: '12px',
        margin: '0 0 8px 0',
        color: '#666'
      }
    }),
    ui.Label({
      value: 'Data provided under Creative Commons Zero license',
      style: {
        fontSize: '12px',
        margin: '0 0 8px 0',
        color: '#666'
      }
    }),
    ui.Label({
      value: 'Link to Community Catalog page',
      style: {
        fontSize: '12px',
        color: '#1a73e8',
        textDecoration: 'underline'
      },
      targetUrl: 'https://gee-community-catalog.org/projects/annual_nlcd/'
    })
  ],
  style: {
    position: 'bottom-right',
    padding: '8px',
    width: '250px',
    backgroundColor: '#ffffff',  // Set to opaque white
    border: '1px solid #ccc'
  }
});
map2.add(dataPanel);