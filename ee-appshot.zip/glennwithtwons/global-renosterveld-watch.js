var geometry = 
    /* color: #d63000 */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[18.639906129366985, -33.15824276406912],
          [18.639906129366985, -34.95123716342574],
          [22.325819215304485, -34.95123716342574],
          [22.325819215304485, -33.15824276406912]]], null, false);
var poi = /* color: #d63000 */ee.Geometry.Point([19.851898808263627, -34.40280888387663]);
var logo = ee.Image('projects/ee-vegetation-gee4geo/assets/gorw4')
var thumb = ui.Thumbnail({image:logo,params:{bands:['b1','b2','b3'],min:0,max:255,dimensions: '754x1220',format:'png'},style:{width:'250px'}});
var ic = ee.ImageCollection("projects/ee-vegetation-gee4geo/assets/reno_predict")
.cast({
  'RenoProb':'double',
  'prediction':'int8',
  'TransProb':'double'
},['RenoProb','prediction','TransProb']);
//natural + degraded
var fc_o = ee.FeatureCollection("projects/ee-vegetation-gee4geo/assets/overberg_renosterveld")
var fc=fc_o.map(function(feature){return(feature.set('class', ee.Number(1)))});
fc=fc.reduceToImage(['class'],ee.Reducer.first());
//natural only
var mask = ee.Image("projects/ee-vegetation-gee4geo/assets/reno_mask");
var ic = ic
.map(function(image){return image.updateMask(mask)})
var first = ic.first().get('system:time_start')
var firstdate = ee.Date(first)
var last = ic.limit(1, 'system:time_start', false).first().get('system:time_start')
var lastdate = ee.Date(last).advance(1,'day')
//view only the predicted probability of renosterveld loss
//Map.setCenter(20.05,-34.31,10)
//Map.addLayer(ic2,imageVisParam,'all lost');
//Map.addLayer(ic_new,imageVisParam,'newly lost');
//Map.addLayer(recent,imageVisParam,'raw data');
//Map.addLayer(lost_vec);
var now = lastdate;
var mapPanel = ui.Map();
var showMosaic = function(range) {
  var ic_view = ic.filterDate(firstdate,range.end())
  var lost = ic_view.select('prediction').sum().gte(1)
  var lost_one = ic_view.select('prediction').sum().eq(1)
  var recent=ic_view.limit(1, 'system:time_start', false).first();
  var lost_new = recent.select('prediction').multiply(lost_one)
  var lost_zero = lost.unmask(0)
  var lost_zero_new = lost_new.unmask(0)
  var con = lost_zero.focal_mean(20, "circle","meters").gt(0.9)
  var con_new = lost_zero_new.focal_mean(20, "circle","meters").gt(0.9)
  lost = lost.updateMask(lost).updateMask(con)
  lost_new = lost_new.updateMask(lost_new).updateMask(con_new)
  //var lost_vec = lost.reduceToVectors({
  //  scale: 10,
  //  geometry: fc_o.geometry(),
  //  geometryType: 'polygon',
  //  labelProperty: 'zone',
  //  bestEffort: true
  //})
  //lost_vec = lost_vec.map(function(feature){return(feature.buffer(20))})
  var ic2 = ic_view
  .sum()
  .select('TransProb')
  .updateMask(lost)
  var ic_new = recent.updateMask(lost_new)
  var imageVisParam = {"opacity":1,"bands":["TransProb"],"palette":["1aff36","1e25ff","ff1a3a"]};
  var layer0 = ui.Map.Layer(ic2,imageVisParam,'all lost');
  var layer1 = ui.Map.Layer(ic_new,imageVisParam,'newly lost');
  var layer2 = ui.Map.Layer(recent,imageVisParam,'raw data');
  mapPanel.layers().set(0, layer0);
  mapPanel.layers().set(1, layer1);
  mapPanel.layers().set(2, layer2);
}
// Asynchronously compute the date range and show the slider.
var dateRange = ee.DateRange(firstdate, lastdate).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: 1,
    onChange: showMosaic
  });
  mapPanel.add(dateSlider.setValue(now));
});
// Create a panel to hold title, intro text, chart and legend components.
var inspectorPanel = ui.Panel({style: {width: '30%'}});
var titlePanel = ui.Panel(thumb, 'flow', {width: '300px'});
inspectorPanel.insert(0, titlePanel);
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label('An application for monitoring the loss of the critically endangered Renosterveld shrubland',{fontSize:'18px'}),
  ui.Label('New data is added every 10 days',{fontSize:'16px'}),
  ui.Label(''),
  ui.Label('Select from the available layers:',{fontWeight:'bold'}),
  ui.Label('raw data: probablility of loss'),
  ui.Label('newly lost: lost vegetaion within the last 10 days'),
  ui.Label('all lost: all lost vegetation'),
  ui.Label(''),
  ui.Label('Click a location on the map to see its history below',{fontWeight:'bold'})
]);
inspectorPanel.add(intro);
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
inspectorPanel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
/*
 * Chart setup
 */
// Generates a new time series chart of ndvi for the given coordinates.
var generateChart = function (coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2));
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  // Add a dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  // Make a chart from the time series.
  var ndviChart = ui.Chart.image.series(ic.select(['TransProb'],['probablity']), point, ee.Reducer.mean(), 10);
  // Customize the chart.
  ndviChart.setOptions({
    title: '',
    vAxis: {title: 'Probability transformed',viewWindow: {min: 0}},
    hAxis: {title: 'Date', format: 'dd-MM-yy', gridlines: {count: 7}},
    series: {
      0: {
        color: 'gray',
        lineWidth: 3,
        visibleInLegend: false
      }
    },
    legend: {position: 'none'},
  });
  // Add the chart at a fixed position, so that new charts overwrite older ones.
  inspectorPanel.widgets().set(2, ndviChart);
};
// Register a callback on the default map to be invoked when the map is clicked.
mapPanel.onClick(generateChart);
// Configure the map.
mapPanel.style().set('cursor', 'crosshair');
// Initialize with a test point.
var initialPoint = ee.Geometry.Point(20.05,-34.31);
mapPanel.centerObject(initialPoint, 10);
/*
 * Initialize the app
 */
// Replace the root with a SplitPanel that contains the inspector and map.
ui.root.clear();
ui.root.add(ui.SplitPanel(inspectorPanel, mapPanel));
generateChart({
  lon: initialPoint.coordinates().get(0).getInfo(),
  lat: initialPoint.coordinates().get(1).getInfo()
});