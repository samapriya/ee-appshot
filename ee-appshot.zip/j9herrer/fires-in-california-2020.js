var States = ui.import && ui.import("States", "table", {
      "id": "TIGER/2018/States"
    }) || ee.FeatureCollection("TIGER/2018/States"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -122.88372846679688,
            38.65422330650005
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([-122.88372846679688, 38.65422330650005]);
//Map.addLayer(Outline_image,[],'Outline, Image');
var California = States.filterBounds(geometry); // get California
var MCD64A1 = ee.ImageCollection('FIRMS').filterDate('2019-08-01', '2019-09-08');
MCD64A1 = MCD64A1.select('T21');
var MCD64A1_ = ee.ImageCollection('FIRMS').filterDate('2020-08-01', '2020-09-08');
MCD64A1_ = MCD64A1_.select('T21');
print(MCD64A1);
var firesVis = {
  min: 296, max: 500, opacity: 0.6,
  palette: ['red', 'orange', 'yellow'],
};
var firesVis_ = {
  min: 304.29998779296875, max: 504, opacity: 0.6,
  palette: ["002bff","5ae8ff","85ff89"],
};
Map.setCenter(-122.3663, 38.0288,9);
Map.addLayer(MCD64A1.max().clip(California), firesVis, 'Fires2019');
Map.addLayer(MCD64A1_.max().clip(California), firesVis_, 'Fires2020');
var Outline_image=MCD64A1.count().gt(0); 
//creating an image that has 1 wherever there has been a fire, 0 else
var Outline_image_=MCD64A1_.count().gt(0); 
//creating an image that has 1 wherever there has been a fire, 0 else
var Outline_feature = Outline_image.reduceToVectors({geometry: California, scale: 1000});
var Outline_feature_ = Outline_image_.reduceToVectors({geometry: California, scale: 1000});
// create a ee.FeatureCollection for all fires within California in a scale of 500 m
var city_outline = ee.Image().byte().paint({
  featureCollection: Outline_feature,
  width: 2
});
var city_outline_ = ee.Image().byte().paint({
  featureCollection: Outline_feature_,
  width: 2
});
//Map.addLayer(city_outline,[],'Outline, Feature');
//Map.addLayer(city_outline_,[],'Outline, Feature');
print(Outline_feature);
print(Outline_feature_);
// PREPARE PANELS
var mypanel=ui.Panel({
style: {
position: 'bottom-left',
width: '450px'}});
var intro = ui.Panel([
  ui.Label({
    value: 'Fires in California, Comparison Aug-Sept 2019 Vs. 2020',
    style: {fontSize: '22px', fontWeight: 'bold'}
  }),
  ui.Label('Visualization created by @herrerajuans - Juan Sebastian Herrera. University of California, San Diego'),
  ui.Label('Activate or hide layers by clicking "Layers Button"')
]);
mypanel.add(intro);
Map.add(mypanel);
var Dark = [
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#212121"
      }
    ]
  },
  {
    "elementType": "labels.icon",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#212121"
      }
    ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "administrative.country",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#9e9e9e"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "administrative.locality",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#bdbdbd"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "poi.business",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#181818"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#616161"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#1b1b1b"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#2c2c2c"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.icon",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#8a8a8a"
      }
    ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#373737"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#3c3c3c"
      }
    ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#4e4e4e"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#616161"
      }
    ]
  },
  {
    "featureType": "transit",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "transit",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#000000"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#3d3d3d"
      }
    ]
  }
];
Map.setOptions('Dark', {Dark: Dark});