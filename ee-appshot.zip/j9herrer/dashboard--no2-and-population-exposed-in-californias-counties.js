var States = ui.import && ui.import("States", "table", {
      "id": "TIGER/2018/States"
    }) || ee.FeatureCollection("TIGER/2018/States"),
    image2 = ui.import && ui.import("image2", "imageCollection", {
      "id": "COPERNICUS/S5P/OFFL/L3_NO2"
    }) || ee.ImageCollection("COPERNICUS/S5P/OFFL/L3_NO2"),
    pretty = ui.import && ui.import("pretty", "imageVisParam", {
      "params": {
        "opacity": 0.6,
        "bands": [
          "tropospheric_NO2_column_number_density"
        ],
        "min": 10,
        "max": 140,
        "palette": [
          "1000ff",
          "00c4ff",
          "ffa502",
          "ff0000"
        ]
      }
    }) || {"opacity":0.6,"bands":["tropospheric_NO2_column_number_density"],"min":10,"max":140,"palette":["1000ff","00c4ff","ffa502","ff0000"]},
    Counties = ui.import && ui.import("Counties", "table", {
      "id": "TIGER/2018/Counties"
    }) || ee.FeatureCollection("TIGER/2018/Counties");
// Assignment info
print ('GPGN494 - Remote Sensing and Data Analytics', 'Juan Sebastian Herrera - A53289098','Coding Assignment #4');
//----------------------------------DATA----------------------------------------------------
var myfunction1 = function(x)
{var img = image2.filter(ee.Filter.calendarRange(x,null,'day_of_week'));
 img = img.mean().clip(Ca).multiply(1000000);
return img.set('mypoperty',x);  
};
 var mystyle = {
  series: {0: {color: '4285F4', labelInLegend: 'Population/km²'}}, 
  title: 'Weekly Average Population Exposed to No2', 
  vAxis: {title: 'Population Density/km²'},
  hAxis: {title: 'No2 Particles/km²'},
          };
 var mystyle01 = {
  series: {0: {color: '4285F4', labelInLegend: 'Population/km²'}}, 
  title: 'Population Exposed by No2 level on Monday', 
  vAxis: {title: 'Population Density/km²'},
  hAxis: {title: 'No2 Particles/km²'},
          };
 var mystyle02 = {
  series: {0: {color: '4285F4', labelInLegend: 'Population/km²'}}, 
  title: 'Population Exposed by No2 level on Tuesday', 
  vAxis: {title: 'Population Density/km²'},
  hAxis: {title: 'No2 Particles/km²'},
          };
 var mystyle03 = {
  series: {0: {color: '4285F4', labelInLegend: 'Population/km²'}}, 
  title: 'Population Exposed by No2 level on Wednesday', 
  vAxis: {title: 'Population Density/km²'},
  hAxis: {title: 'No2 Particles/km²'},
          };
 var mystyle04 = {
  series: {0: {color: '4285F4', labelInLegend: 'Population/km²'}}, 
  title: 'Population Exposed by No2 level on Thursday', 
  vAxis: {title: 'Population Density/km²'},
  hAxis: {title: 'No2 Particles/km²'},
          };
 var mystyle05 = {
  series: {0: {color: '4285F4', labelInLegend: 'Population/km²'}}, 
  title: 'Population Exposed by No2 level on Friday', 
  vAxis: {title: 'Population Density/km²'},
  hAxis: {title: 'No2 Particles/km²'},
          };
 var mystyle06 = {
  series: {0: {color: '4285F4', labelInLegend: 'Population/km²'}}, 
  title: 'Population Exposed by No2 level on Saturday', 
  vAxis: {title: 'Population Density/km²'},
  hAxis: {title: 'No2 Particles/km²'},
          };
 var mystyle07 = {
  series: {0: {color: '4285F4', labelInLegend: 'Population/km²'}}, 
  title: 'Population Exposed by No2 level on Sunday', 
  vAxis: {title: 'Population Density/km²'},
  hAxis: {title: 'No2 Particles/km²'},
          };
 var mystyle2 = {
   series: {0: {color: 'FFC107', labelInLegend: 'No2'}},
   title: 'Average No2 Levels by day of the week', 
  vAxis: {title: 'Mean No2/km²',},
  hAxis: {title: 'Day of the Week'},
          };
// PREPARING DATA
var Ca= States.filterBounds(ee.Geometry.Point([-118, 36]));
var LocA=Counties.filterBounds(ee.Geometry.Point([-121.4513, 38.5707]));
var LocB=Counties.filterBounds(ee.Geometry.Point([-122.4345, 37.7706]));
var LocC=Counties.filterBounds(ee.Geometry.Point([-121.7397, 37.2817]));
var LocD=Counties.filterBounds(ee.Geometry.Point([-118.3117, 34.0183]));
var LocE=Counties.filterBounds(ee.Geometry.Point([-117.1361, 32.7617]));
var image = ee.Image('CIESIN/GPWv411/GPW_UNWPP-Adjusted_Population_Density/gpw_v4_population_density_adjusted_to_2015_unwpp_country_totals_rev11_2020_30_sec');
image2=image2.filterDate('2019-1-1','2019-12-1').select('tropospheric_NO2_column_number_density');
var mylist = ee.List.sequence(1,7);
var IC = mylist.map(myfunction1);
//print(IC);
image2 = image2.mean().clip(Ca).multiply(1000000);
//print(image2);
var mylimits=ee.List.sequence(15,135,10);
var geometry = ee.Geometry.Point([-121.4513, 38.5707]);
var county=Counties.filterBounds(geometry);
//---------------------------------- VISUALIZATION----------------------------------------------------
// PREPARE DEFAULT OPTIONS FOR MAP AND CHART
Map.centerObject(Ca,5);
Map.setControlVisibility(false);
Map.addLayer(ee.Image(IC.get(0)),pretty,null,false);
Map.addLayer(ee.Image(IC.get(1)),pretty,null,false);
Map.addLayer(ee.Image(IC.get(2)),pretty,null,false);
Map.addLayer(ee.Image(IC.get(3)),pretty,null,false);
Map.addLayer(ee.Image(IC.get(4)),pretty,null,false);
Map.addLayer(ee.Image(IC.get(5)),pretty,null,false);
Map.addLayer(ee.Image(IC.get(6)),pretty,null,false);
Map.addLayer(image2,pretty);
 var outline = ee.Image().byte().paint({
  featureCollection: LocD,
  width: 2
 });
 Map.addLayer(outline);
//FUNCTIONS and Variables NEEDED FOR USER INTERACTION WITH WIDGETS OR MAP
var myoptions = {
  'Sacramento County': LocA,
  'San Francisco County': LocB,
  'Santa Clara County': LocC,
  'Los Angeles County': LocD,
  'San Diego County': LocE,
};
var mydata = {'myimage': image2};
//print (mydata);
var myfunction = function(x){
  var key = mychoice.getValue();
  var region=myoptions[key];
  var img = mydata['myimage'];
  var mymask = img.gt(ee.Number(x).subtract(5)).and(img.lte(ee.Number(x).add(5)));
  var results = image.mask(mymask).multiply(ee.Image.pixelArea()).divide(1000000);
  results = results.reduceRegion(ee.Reducer.sum(),region,1000);
  results = ee.Dictionary(results).get('unwpp-adjusted_population_density');
  return results;
};
var makemyChart = function(){
var myresults = mylimits.map(myfunction);
//print(myresults);
var myChart = ui.Chart.array.values(myresults, 0, mylimits).setChartType('ColumnChart');
return myChart.setOptions(mystyle);
};
var makemyChart2 = function(region){
var myChart = ui.Chart.image.series(ee.ImageCollection(IC),region,null,1000,'mypoperty').setChartType('ColumnChart');
return myChart.setOptions(mystyle2);
};
var handelcb = function(i){
 if (i!=1){checkbox1.setValue(false);}
 if (i!=2){checkbox2.setValue(false);}
 if (i!=3){checkbox3.setValue(false);}
 if (i!=4){checkbox4.setValue(false);}
 if (i!=5){checkbox5.setValue(false);}
 if (i!=6){checkbox6.setValue(false);}
 if (i!=7){checkbox7.setValue(false);}
 if (i!=8){checkbox8.setValue(false);}
};
// PREPARE PANELS
var mypanel=ui.Panel({
style: {
position: 'top-right',
width: '760px',
}});
var mypanel2=ui.Panel({
layout: ui.Panel.Layout.flow('horizontal')});
var mypanel11=ui.Panel({
layout: ui.Panel.Layout.flow('horizontal')});
var mychoice = ui.Select({items: Object.keys(myoptions),
                          value: 'Los Angeles County',
});
// PREPARE WIDGETS
var myLabel = ui.Label({
              value: 'Dashboard – No2 and Population Exposed in Los Angeles County in 2019',
              style: {fontWeight: 'bold', fontSize: '18px'}});
  var subTextVis1 = {
  'margin':'16px 0px 0px 0px',
  'fontSize':'12px',
  'color':'red'
  };
var myLabel2 = ui.Label('Please select the county of interest from the menu',subTextVis1);
var myLabel3 = ui.Label({
              value: 'Subset Analysis and Map No2 by Day of the Week',
              style: {fontWeight: 'bold', fontSize: '14px'}});
var myLabel5 = ui.Label({
              value: '',
              style: {fontWeight: 'normal', fontSize: '12px'}});
var subTextVis = {
  'margin':'0px 10px 10px 10px',
  'fontSize':'12px',
  'color':'grey'
  };
var myLabel6 = ui.Label('Note: This dashboard compares Nitrogen Dioxide –No2 and population exposed for five regions in California in the year 2019. The first chart shows total population exposed to different No2 levels per Km2 for every day of the week. The chart at the bottom summarizes No2 emissions per day of the week for the region selected in the dropdown menu.',subTextVis);
mychoice.onChange(function(key){
  var myChart = makemyChart();
  mypanel.widgets().set(1, myChart.setOptions(mystyle));
  var x = myoptions[key];
  myChart = makemyChart2(x);
  mypanel.widgets().set(3, myChart.setOptions(mystyle2)); 
  var countynname = x.first().get('NAME');
  myLabel.setValue('Dashboard – No2 and Population Exposed in ' + countynname.getInfo()+' County in 2019');
  var outline = ee.Image().byte().paint({
  featureCollection: x,
  width: 2
   });
  Map.layers().set(8, ui.Map.Layer(outline));
  Map.centerObject(x,8);
});
var myChart1 = makemyChart();   
var myChart2 = makemyChart2(LocD);  
var checkbox1 = ui.Checkbox('Monday', false);
checkbox1.onChange(function(checked) {
  Map.layers().get(0).setShown(checked);
  if (checked){
    handelcb(1);
    mydata['myimage'] = ee.Image(IC.get(0));
    var myChart = makemyChart();
    mypanel.widgets().set(1, myChart.setOptions(mystyle01));
  }
});
var checkbox2 = ui.Checkbox('Tuesday', false);
checkbox2.onChange(function(checked) {
  Map.layers().get(1).setShown(checked);
  if (checked){
    handelcb(2);
    mydata['myimage'] = ee.Image(IC.get(1));
    var myChart = makemyChart();
    mypanel.widgets().set(1, myChart.setOptions(mystyle02));
  }
});
var checkbox3 = ui.Checkbox('Wednesday', false);
checkbox3.onChange(function(checked) {
  Map.layers().get(2).setShown(checked);
  if (checked){
    handelcb(3);
    mydata['myimage'] = ee.Image(IC.get(2));
    var myChart = makemyChart();
    mypanel.widgets().set(1, myChart.setOptions(mystyle03));
  }
});
var checkbox4 = ui.Checkbox('Thursday', false);
checkbox4.onChange(function(checked) {
  Map.layers().get(3).setShown(checked);
  if (checked){
    handelcb(4);
    mydata['myimage'] = ee.Image(IC.get(3));
    var myChart = makemyChart();
    mypanel.widgets().set(1, myChart.setOptions(mystyle04));
  }
});
var checkbox5 = ui.Checkbox('Friday', false);
checkbox5.onChange(function(checked) {
  Map.layers().get(4).setShown(checked);
  if (checked){
    handelcb(5);
    mydata['myimage'] = ee.Image(IC.get(4));
    var myChart = makemyChart();
    mypanel.widgets().set(1, myChart.setOptions(mystyle05));
  }
});
var checkbox6 = ui.Checkbox('Saturday', false);
checkbox6.onChange(function(checked) {
  Map.layers().get(5).setShown(checked);
  if (checked){
    handelcb(6);
    mydata['myimage'] = ee.Image(IC.get(5));
    var myChart = makemyChart();
    mypanel.widgets().set(1, myChart.setOptions(mystyle06));
  }
});
var checkbox7 = ui.Checkbox('Sunday', false);
checkbox7.onChange(function(checked) {
  Map.layers().get(6).setShown(checked);
    if (checked){
    handelcb(7);
    mydata['myimage'] = ee.Image(IC.get(6));
    var myChart = makemyChart();
    mypanel.widgets().set(1, myChart.setOptions(mystyle07));
  }
});
var checkbox8 = ui.Checkbox('Weekly Mean', true);
checkbox8.onChange(function(checked) {
  Map.layers().get(7).setShown(checked);
    if (checked){
    handelcb(8);
    mydata['myimage'] = image2;
    var myChart = makemyChart();
    mypanel.widgets().set(1, myChart.setOptions(mystyle));
  }
});
//ADD WIDGETS TO PANEL AND PANELS TO THE MAP 
mypanel2.add(checkbox8);
mypanel2.add(checkbox1).add(checkbox2).add(checkbox3).add(checkbox4).add(checkbox5).add(checkbox6).add(checkbox7);
mypanel11.add(mychoice).add(myLabel2)
mypanel.add(myLabel);
mypanel.add(myChart1);
mypanel.add(mypanel11);
mypanel.add(myChart2);
mypanel.add(myLabel3);
mypanel.add(mypanel2);
mypanel.add(myLabel5);
mypanel.add(myLabel6);
ui.root.add(mypanel);