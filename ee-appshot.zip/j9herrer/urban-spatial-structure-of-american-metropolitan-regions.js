var point = ui.import && ui.import("point", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -73.935242,
            40.7306
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([-73.935242, 40.7306]),
    table = ui.import && ui.import("table", "table", {
      "id": "users/j9herrer/USA_Boundary"
    }) || ee.FeatureCollection("users/j9herrer/USA_Boundary"),
    usastates = ui.import && ui.import("usastates", "table", {
      "id": "users/j9herrer/usstates"
    }) || ee.FeatureCollection("users/j9herrer/usstates");
var point = 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([-73.935242, 40.7306]),
    table = ee.FeatureCollection("users/j9herrer/USA_Boundary"),
    usastates = ee.FeatureCollection("users/j9herrer/usstates");
////////////////------------------------------------------------ CITY AND TOWNS SHAPEFILES
var usa_outline = ee.Image().byte().paint({
  featureCollection: usastates,
  width: 2
});
var cities = ee.FeatureCollection("users/j9herrer/USACities2");
var mycity = cities.filterBounds(point);
//var la = ee.Geometry.Point([-118.243683, 34.052235]);
mycity = mycity.filterBounds(point);
var city_outline = ee.Image().byte().paint({
  featureCollection: mycity,
  width: 2
});
var mycurrentcity = {'city':mycity};
////////////////----------------------------------------------- TRANSECT 
var geom_city = mycity.geometry();
var boundingbox=geom_city.bounds();
var coords = boundingbox.coordinates().get(0); 
//for whatever reason .coordinates returns a list with one element which is the list we want, hence .get(0)
coords = ee.List(coords);
var NW = coords.get(1);
var SE = coords.get(3);
var mydiagonal = ee.Geometry.LineString([NW,SE]);
//print (mydiagonal, "Transect");
// Coordinates
var latLon = ee.Image.pixelLonLat().select('longitude');
////////////////------------------------------------------------ VIIRS DATA
var VIIRS = ee.ImageCollection("NOAA/VIIRS/DNB/MONTHLY_V1/VCMSLCFG");
VIIRS = VIIRS.select('avg_rad');
var VIIRS2014 = VIIRS.filterDate('2014-1-1','2015-1-1').mean();
print(VIIRS2014);
var VIIRS2019 = VIIRS.filterDate('2020-1-1','2021-1-1').mean().addBands(latLon);
VIIRS2019 = VIIRS2019.addBands(VIIRS2014);
var VIIR2014List = VIIRS2014.reduceRegion({
  reducer: ee.Reducer.toList(),
  geometry: mydiagonal,
  scale: 1000,
  maxPixels: 1e9
});
print(VIIR2014List);
//print (VIIR2014List, "Lists 2014"); /// 2014
var VIIR2019List = VIIRS2019.reduceRegion({
  reducer: ee.Reducer.toList(),
  geometry: mydiagonal,
  scale: 1000,
  maxPixels: 1e9
});
print(VIIR2019List);
//print (VIIR2019List, "Lists 2019"); /// 2019
// subset the lists
var lon_2019 = ee.List(VIIR2019List.get('longitude'));
var avgRad_2019 = ee.List(VIIR2019List.get('avg_rad'));
var avgRad_2014 = ee.List(VIIR2019List.get('avg_rad_1'));
// Chart
var chart_options = { 
  series: { 0: {labelInLegend: 'VIIRS 2020',color: '30678d'},
            1: {labelInLegend: 'VIIRS 2019',color: '#FF6347', lineDashStyle:[1,1],lineWidth: 2 }
  },
  height: '280px',
  title: '',
  vAxis: {title: 'Avg Rad - nanoWatts/cm²'},
  hAxis: {
    title: 'Longitude',
    //viewWindow: {
    //    min: -75,
    //   max: -73
    },
    //ticks: [0, 25, 50, 75, 100] // display labels every 25
};
//};
//var mychart = ui.Chart.array.values(avgRad,0,lon).setChartType('ColumnChart');
//print(mychart.setOptions(chart_options));
//---------------------------------- VISUALIZATION----------------------------------------------------
Map.centerObject(mycity,8);
Map.setControlVisibility(false);
Map.style().set('cursor', 'crosshair');
var imageVisParam = {"opacity":0.8,"bands":["avg_rad"],"max":150,"palette":["440154","433982","30678d","218f8b","36b677","8ed542","fde725"]};
// Display avg_rad with defined palette stretched between selected min and max
var vis2019 = VIIRS2019.select('avg_rad');
Map.addLayer(vis2019.clip(usastates), imageVisParam, 'avg_rad');
Map.addLayer(city_outline,{},'My City');
Map.addLayer(mydiagonal,{color: 'FF6347'},'Transect');
/// Line Chart
var fc = ee.FeatureCollection(ee.List.sequence(0, lon_2019.size().subtract(1)).map(function(index) {
  return ee.Feature(null, { avgRad_2019: avgRad_2019.get(index), lon_2019: lon_2019.get(index)});
}));
var linechart = ui.Chart.feature.byFeature(fc.sort('lon_2019'), 'lon_2019', ['avgRad_2019']);
/// Line Chart Both
var fcboth = ee.FeatureCollection(ee.List.sequence(0, lon_2019.size().subtract(1)).map(function(index) {
  return ee.Feature(null, { avgRad_2019: avgRad_2019.get(index),avgRad_2014: avgRad_2014.get(index), lon_2019: lon_2019.get(index)});
}));
var linechartboth = ui.Chart.feature.byFeature(fcboth.sort('lon_2019'), 'lon_2019', ['avgRad_2019','avgRad_2014']);
//FUNCTIONS NEEDED FOR USER INTERACTION WITH WIDGETS OR MAP
/*
var makemyChart = function(mycity){
mycity = mycurrentcity['city'];
var geom_city = mycity.geometry();
var boundingbox=geom_city.bounds();
var coords = boundingbox.coordinates().get(0); 
//for whatever reason .coordinates returns a list with one element which is the list we want, hence .get(0)
coords = ee.List(coords);
var NW = coords.get(1);
var SE = coords.get(3);
var mydiagonal = ee.Geometry.LineString([NW,SE]);
//Map.addLayer(mydiagonal,{color: 'FF6347'},'Transect');
Map.layers().set(2, ui.Map.Layer(mydiagonal,{color: 'FF6347'},'Transect'));
var VIIR2019List = VIIRS2019.reduceRegion({
  reducer: ee.Reducer.toList(),
  geometry: mydiagonal,
  scale: 1000,
  maxPixels: 1e9
});
var lon_2019 = ee.List(VIIR2019List.get('longitude'));
var avgRad_2019 = ee.List(VIIR2019List.get('avg_rad'));
var avgRad_2014 = ee.List(VIIR2019List.get('avg_rad_1'));
var fc = ee.FeatureCollection(ee.List.sequence(0, lon_2019.size().subtract(1)).map(function(index) {
  return ee.Feature(null, { avgRad_2019: avgRad_2019.get(index), lon_2019: lon_2019.get(index)});
}));
var fcboth = ee.FeatureCollection(ee.List.sequence(0, lon_2019.size().subtract(1)).map(function(index) {
  return ee.Feature(null, { avgRad_2019: avgRad_2019.get(index),avgRad_2014: avgRad_2014.get(index), lon_2019: lon_2019.get(index)});
}));
var linechart = ui.Chart.feature.byFeature(fc.sort('lon_2019'), 'lon_2019', ['avgRad_2019']);
  return linechart.setOptions(chart_options);
};
*/ 
var myband = ee.List(['avgRad_2019','avgRad_2014']);
var makemyChart = function(){
  mycity = mycurrentcity['city'];
  var geom_city = mycity.geometry();
var boundingbox=geom_city.bounds();
var coords = boundingbox.coordinates().get(0); 
//for whatever reason .coordinates returns a list with one element which is the list we want, hence .get(0)
coords = ee.List(coords);
var NW = coords.get(1);
var SE = coords.get(3);
var mydiagonal = ee.Geometry.LineString([NW,SE]);
//Map.addLayer(mydiagonal,{color: 'FF6347'},'Transect');
Map.layers().set(2, ui.Map.Layer(mydiagonal,{color: 'FF6347'},'Transect'));
var VIIR2019List = VIIRS2019.reduceRegion({
  reducer: ee.Reducer.toList(),
  geometry: mydiagonal,
  scale: 1000,
  maxPixels: 1e9
});
var lon_2019 = ee.List(VIIR2019List.get('longitude'));
var avgRad_2019 = ee.List(VIIR2019List.get('avg_rad'));
var avgRad_2014 = ee.List(VIIR2019List.get('avg_rad_1'));
var fc = ee.FeatureCollection(ee.List.sequence(0, lon_2019.size().subtract(1)).map(function(index) {
  return ee.Feature(null, { avgRad_2019: avgRad_2019.get(index), lon_2019: lon_2019.get(index)});
}));
var fcboth = ee.FeatureCollection(ee.List.sequence(0, lon_2019.size().subtract(1)).map(function(index) {
  return ee.Feature(null, {avgRad_2019: avgRad_2019.get(index),avgRad_2014: avgRad_2014.get(index), lon_2019: lon_2019.get(index)});
}));
  var myband = ee.List([]);
  if (mycheckbox2.getValue()){myband = myband.add('avgRad_2014');}
  if (myband.length().getInfo()>0){
  var myChart = ui.Chart.feature.byFeature(fcboth.sort('lon_2019'), 'lon_2019', ['avgRad_2019','avgRad_2014']);
  }
  else {
  myChart = ui.Chart.feature.byFeature(fc.sort('lon_2019'), 'lon_2019', ['avgRad_2019']);}
  return myChart.setOptions(chart_options);
};
/////// SCATTER
var makemyscatter = function(mycity){
var geom_city = mycity.geometry();
var boundingbox=geom_city.bounds();
var coords = boundingbox.coordinates().get(0); 
//for whatever reason .coordinates returns a list with one element which is the list we want, hence .get(0)
coords = ee.List(coords);
var NW = coords.get(1);
var SE = coords.get(3);
var mydiagonal = ee.Geometry.LineString([NW,SE]);
//Map.addLayer(mydiagonal,{color: 'FF6347'},'Transect');
Map.layers().set(2, ui.Map.Layer(mydiagonal,{color: 'FF6347'},'Transect'));
// VIIRS DATA
var VIIRS = ee.ImageCollection("NOAA/VIIRS/DNB/MONTHLY_V1/VCMCFG");
VIIRS = VIIRS.select('avg_rad');
var ICpop = ee.ImageCollection("JRC/GHSL/P2016/POP_GPW_GLOBE_V1");
ICpop = ICpop.max();
var VIIRS2019 = VIIRS.filterDate('2019-1-1','2020-1-1').mean();
var VIIR2019Listscatter = VIIRS2019.reduceRegion({
  reducer: ee.Reducer.toList(),
  geometry: mydiagonal,
  scale: 500,
  maxPixels: 1e9
});
var popListscatter = ICpop.reduceRegion({
  reducer: ee.Reducer.toList(),
  geometry: mydiagonal,
  scale: 500,
  maxPixels: 1e9
});
var population_scatter = ee.List(popListscatter.get('population_count'));
var avgRad_scatter = ee.List(VIIR2019Listscatter.get('avg_rad'));
// Make a line chart.
var scatterChart = ui.Chart.array.values(avgRad_scatter, 0, population_scatter);
return scatterChart.setOptions({
    height: '280px',
    title: 'Linear Fit, Nighttime Data and Population Density',
    legend: {position: 'none'},
    hAxis: {'title': 'Population Density/km²',format: '0'},
    vAxis: {'title': 'Avg Rad - nanoWatts/cm²'},
    series: {
      0: {
        pointSize: 3.5,
        dataOpacity: 0.6,
        color: 'FF6347',
      }}, 
      trendlines: {0: {
        color: '30678d',
      }}})};
///// Function Click My Map
/*
var clickmyMap = function(coord){
 var point = ee.Geometry.Point(coord.lon, coord.lat);
 var mycity=cities.filterBounds(point);
 var myChart = makemyChart(mycity);
 mypanel.widgets().set(3, myChart); 
 var myscatter = makemyscatter(mycity);
 mypanel.widgets().set(5, myscatter);
 var city_outline = ee.Image().byte().paint({
  featureCollection: mycity,
  width: 2
 });
 Map.layers().set(1, ui.Map.Layer(city_outline,{},'My City'));
 var citynamename = mycity.first().get('NAME10');
 myLabel.setValue('Metropolitan Area: ' + citynamename.getInfo());
 Map.centerObject(mycity,8);
 };
 */
var clickmyMap = function(coord){
 var point = ee.Geometry.Point(coord.lon, coord.lat);
 var mycity=cities.filterBounds(point); 
 if (mycity.first().getInfo()){
 mycurrentcity['city'] = mycity;
 var myChart = makemyChart(); 
 mypanel.widgets().set(3, myChart);
var myscatter = makemyscatter(mycity);
 mypanel.widgets().set(5, myscatter);
 var city_outline = ee.Image().byte().paint({
  featureCollection: mycity,
  width: 2
 });
Map.centerObject(mycity,8);
 Map.layers().set(1, ui.Map.Layer(city_outline,{},'My City'));
 var cityname = mycity.first().get('NAME10');
 myLabel.setValue('Metropolitan Area: ' + cityname.getInfo());
 myInstructions.setValue('Click the map to select a metropolitan region in the United States');
 }
 else{ 
    myInstructions.setValue('Please click WITHIN the contiguous United States')}
};
/// CHECKBOX
 var checkmybox = function(checked) {
  var myChart = makemyChart(); 
  mypanel.widgets().set(3, myChart); 
 };
var mycheckbox2 = ui.Checkbox('Compare to 2019 - Prepandemic', false,checkmybox);
mycheckbox2.onChange(checkmybox);
// PREPARE PANELS
var mypanel=ui.Panel({
style: {
position: 'top-right',
width: '650px'}});
var mypanel1=ui.Panel({
style: {
position: 'top-left',
width: ''}});
var intro = ui.Panel([
  ui.Label({
    value: 'Urban Spatial Structure of American Metropolitan Regions',
    style: {fontSize: '22px', fontWeight: 'bold'}
  }),
  ui.Label('A tool to identify cities’ functional pattern from nighttime data.')
]);
// PREPARE WIDGETS
var myInstructions = ui.Label({
              value: 'Click the map to select a metropolitan region in the United States', style: {color: 'FF6347'}});
mypanel.add(intro);
var panelBreak25 = ui.Panel(null, null, {stretch: 'horizontal', height: '1px', backgroundColor: '000', margin: '8px 0px 8px 0px'});
mypanel.add(panelBreak25);
var myLabel = ui.Label({
              value: 'Metropolitan Area: New York--Newark, NY--NJ--CT',
              style: {fontWeight: 'bold', fontSize: '16px'}});
mypanel.add(myLabel);
//mypanel.add(myInstructions);
var myChart = makemyChart(mycity);  
mypanel.add(myChart);
mypanel.add(mycheckbox2);
var myscatter = makemyscatter(mycity);    
mypanel.add(myscatter);
mypanel.add(myInstructions)
////
/**
 * @license
 * Copyright 2020 Google LLC.
 * SPDX-License-Identifier: Apache-2.0
 * 
 * @description
 * Earth Engine App collapsible note code snippet from:
 *   https://showcase.earthengine.app/view/jrc-global-surface-water-animation
 */
// Function to handle showing and hiding the notes panel.
var notesShow = false;
function notesButtonHandler() {
  if(notesShow){
    notesShow = false;
    notesPanel.style().set('shown', false);
    notesPanel.style().set('width', '83px');
    notesButton.setLabel('See notes');
  } else {
    notesShow = true;
    notesPanel.style().set('shown', true);
    notesPanel.style().set('width', '290px');
    notesButton.setLabel('Hide notes');
  }
}
// Note style.
var noteStyle = {backgroundColor: 'rgba(1, 1, 1, 0.0)', fontSize: '11px', fontWeight: '400', margin: '3px 8px 1px 22px'};
var titles = {backgroundColor: 'rgba(1, 1, 1, 0.0)', fontSize: '12px', fontWeight: 'bold', margin: '8px 8px 1px 8px'};
var credit = {backgroundColor: 'rgba(1, 1, 1, 0.0)', fontSize: '11px', fontWeight: '400', margin: '3px 8px 10px 22px'};
// Show/hide note button.
var notesButton = ui.Button({label: 'See notes', onClick: notesButtonHandler, style: {margin: '0px'}});
// Notes panel.
var notesPanel = ui.Panel({
  widgets: [
    ui.Label({value: 'Line Chart notes:', style: titles}),
    ui.Label({value: '• The chart represents the light intensity recorded in 2019 and 2014 along a transect path for the metropolitan region of interest. Note the longitude in the horizontal axis.', style: noteStyle}),
    ui.Label({value: '• This method offers a novel alternative to identify the urban spatial structure of cities and metropolitan regions using remote sensing applications.', style: noteStyle}),
    ui.Label({value: '• To learn more: 2004, Author: Bertaud, Alain',
        style: {backgroundColor: 'rgba(0, 0, 0, 0.0)', fontSize: '11px', fontWeight: '400', margin: '3px 8px 8px 22px'},
        targetUrl: 'https://escholarship.org/uc/item/5vb4w9wb'}),
    ui.Label({value: 'Scatterplot notes:', style: titles}),
    ui.Label({value: '• This scatter allows us to evaluate how well does light intensity proxy for population density. To confirm whether nightlights are a good fit to identify urban centralities, we should be able to see an upward slope.', style: noteStyle}),
    ui.Label({value: '• The data points plotted also correspond to the transect path shown on the map and are based on data for the year 2019.', style: noteStyle}),
    ui.Label({value: 'Note to researchers:', style: titles}),
    ui.Label({value: '• To export the data for each city to CSV, click the magnify button located at the top-right of each chart.', style: noteStyle}),
    ui.Label({value: 'Credits:', style: titles}),
    ui.Label({value: '• VIIRS Nighttime Dataset',
        style: {backgroundColor: 'rgba(0, 0, 0, 0.0)', fontSize: '11px', fontWeight: '400', margin: '3px 8px 0px 22px'},
        targetUrl: 'https://developers.google.com/earth-engine/datasets/catalog/NOAA_VIIRS_DNB_MONTHLY_V1_VCMSLCFG'}),
    ui.Label({value: '• Population Density Dataset',
        style: {backgroundColor: 'rgba(0, 0, 0, 0.0)', fontSize: '11px', fontWeight: '400', margin: '3px 8px 0px 22px'},
        targetUrl: 'https://developers.google.com/earth-engine/datasets/catalog/JRC_GHSL_P2016_POP_GPW_GLOBE_V1'}),
    ui.Label({value: 'Elaborated by:', style: titles}),
    ui.Label({value: '• Juan Sebastian Herrera - University of California, San Diego. @herrerajuans', style: credit}),
  ],
  style: {shown: false, backgroundColor: 'rgba(255, 255, 255, 1)', fontSize: '11px', fontWeight: '500'}
});
// Notes panel container.
var notesContainer = ui.Panel({widgets: [notesButton, notesPanel],
  style: {position: 'bottom-left', padding: '8px',
    backgroundColor: 'rgba(0, 0, 0, 0.5)'}});
/////
var maplabel = ui.Label({
  value: 'Map for 2019',
  style: {fontSize: '12px', margin: '1px 8px 1px 8px',fontWeight: 'bold'},
});
//mypanel1.add(maplabel);
//mypanel1.add(notesButton);
//mypanel1.add(panelBreak26);
//mypanel1.add(notesPanel);
////
Map.add(mypanel);
//Map.add(mypanel1);
Map.onClick(clickmyMap);
Map.add(notesContainer);
var Dark = [
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#212121"
      }
    ]
  },
  {
    "elementType": "labels.icon",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#212121"
      }
    ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "administrative.country",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#9e9e9e"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "administrative.locality",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#bdbdbd"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "poi.business",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#181818"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#616161"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#1b1b1b"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#2c2c2c"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.icon",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#8a8a8a"
      }
    ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#373737"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#3c3c3c"
      }
    ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#4e4e4e"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#616161"
      }
    ]
  },
  {
    "featureType": "transit",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "transit",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#000000"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#3d3d3d"
      }
    ]
  }
];
Map.setOptions('Dark', {Dark: Dark});