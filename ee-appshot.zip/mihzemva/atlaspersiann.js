var PERSIANN = ee.ImageCollection("NOAA/PERSIANN-CDR"),
    geo = 
    /* color: #d63000 */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-42.088428841246355, 47.90802063748186],
          [-42.088428841246355, 16.855752344668904],
          [44.923289908753645, 16.855752344668904],
          [44.923289908753645, 47.90802063748186]]], null, false),
    imageVisParam = {"opacity":0.81,"bands":["Precipitation"],"min":20,"max":200,"palette":["fffeed","0415ff","0d0000"]};
var Data = PERSIANN.filterDate('2017-01-01', '2018-01-01');
                   //Q13.filterBounds(table)
                   //.filter.bounds(geo);
 var Init = ee.Image.constant(0)
 .rename('Precipitation')
 .cast({'Precipitation':'long'});
 function CalcDryDays(current,previous){
   var Mask = current.remap([0], [1], 0);
   var LastImage = ee.Image(ee.List(previous).get(-1));
   var Updated = LastImage.add(Mask).multiply(Mask);
   return ee.List(previous).add(Updated);
 }
 var result = ee.List(Data.iterate(CalcDryDays, ee.List([Init])));
 var ResultCollection = ee.ImageCollection(result);
 var ResultImage = ResultCollection.max().clip(geo);
 Map.addLayer(ResultImage,imageVisParam);
 Map.centerObject(geo, 5);