var table = ee.FeatureCollection("users/mihzemva/Slovenia_shape_simpl_nosea"),
    Q13 = ee.ImageCollection("MODIS/006/MOD13Q1");
Map.setOptions('satellite');
Map.centerObject(table, 12);
var StartDate = '2013-01-01';
var EndDate = '2016-12-31';
var collectionModNDVI = Q13.filterBounds(table)
    .filterDate(StartDate,EndDate)
    .select('NDVI');
    print(collectionModNDVI);
var collectionModEvi = Q13.filterBounds(table)
 .filterDate(StartDate,EndDate)
 .select('EVI');
var palette1 = [
  'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
  '74A901', '66A000', '529400', '3E8601', '207401', '056201',
  '004C00', '023B01', '012E01', '011D01', '011301'];
var seeEVI = Q13
    .first()
    .select('EVI')
        .clip(table);
Map.addLayer(seeEVI, {min:-10, max: 5000, palette: palette1, opacity:(0.6)}, 'EVI');
var panel = ui.Panel();
panel.style().set('width', '350px');
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: 'Vege_dyna chart 2013-2016',
    style: {fontSize: '18px', fontWeight: 'bold'}
  }),
  ui.Label('Click on a map')
]);
panel.add(intro);
// panels to hold lon/lat values
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// Register a callback on the default map to be invoked when the map is clicked
Map.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(4)),
  lat.setValue('lat: ' + coords.lat.toFixed(4));
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var eviChart = ui.Chart.image.series(collectionModEvi, point, ee.Reducer.mean(), 250);
  eviChart.setOptions({
    title: 'MOD13Q1 EVI',
    vAxis: {maxValue: 9000, minValue: -1000},
    hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
  });
  panel.widgets().set(2, eviChart);
  var ndviChart = ui.Chart.image.series(collectionModNDVI, point, ee.Reducer.mean(), 250);
  ndviChart.setOptions({
    title: 'MOD13Q1 NDVI',
    vAxis: { maxValue: 9000, minValue: -1000},
    hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
  });
  panel.widgets().set(3, ndviChart);
});
Map.style().set('cursor', 'crosshair');
// Add the panel to the ui.root
ui.root.insert(0, panel);