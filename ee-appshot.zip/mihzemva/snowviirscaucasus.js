var title = ui.Label('15. and 16.oct 2019  (500m GA-resolution)');
title.style().set('position', 'top-center');
Map.add(title);
 var title2 = ui.Label('Snow on Caucasus mountains from VIIRS instrument(NASA)');
title.style().set('position', 'top-center');
Map.add(title2);
 // var MOD10A1=ee.ImageCollection('MODIS/006/MOD10A1')
   //           .filterDate('2018-10-14', '2018-10-15');
    var VIIRS09 = ee.ImageCollection('NOAA/VIIRS/001/VNP09GA')
                 .filter(ee.Filter.date('2019-10-15'));
    var VIIRS09a = ee.ImageCollection('NOAA/VIIRS/001/VNP09GA')
                 .filter(ee.Filter.date('2019-10-16'));
 var roi =  ee.Geometry.Polygon(
        [[39.4, 44.44],
          [39.4, 40.8],
          [49.2, 40.8],
          [49.2, 44.44]], null, false);
 var bounded = ee.Geometry.Polygon(
        [[39.86654185290081, 44.17817333952024],
          [39.77041148180706, 44.061841609223606],
          [39.93795298571331, 43.83839739258955],
          [40.22909068102581, 43.67175301388538],
          [40.37740611071331, 43.52257128989341],
          [40.61361216540081, 43.46877533502391],
          [40.77566050524456, 43.41293631973923],
          [41.16842173571331, 43.18105434148932],
          [41.53371714586956, 43.068794885958276],
          [41.98964976305706, 42.80941355798846],
          [42.01986216540081, 42.90605518180768],
          [42.07479380602581, 42.90404335741884],
          [42.20388316149456, 42.67830364107385],
          [42.65981577868206, 42.53882208520136],
          [42.828730573603934, 42.64497777086494],
          [44.03036021227581, 42.38685752547985],
          [45.26357554430706, 42.36859699405054],
          [46.15621470446331, 41.99818952344363],
          [47.23836802477581, 41.32723083622804],
          [47.65584849352581, 41.095816233905424],
          [48.38094614977581, 40.90511359713127],
          [48.46334361071331, 41.22402189534999],
          [47.83712290758831, 41.46321669210041],
          [47.36196421618206, 41.87764677797189],
          [46.97469614977581, 42.036959865133255],
          [46.31551646227581, 42.623761098731826],
          [45.33498667711956, 42.97039889429968],
          [43.88753794665081, 43.04270519496379],
          [43.30800913805706, 43.436873636723554],
          [42.90975474352581, 43.584277911928766],
          [41.50899790758831, 43.67572613003772],
          [40.76742075915081, 43.97098339532748],
          [40.46804331774456, 44.122993618070275]], null, false);
 // var Modis10a1 = ee.Image(MOD10A1.select(['NDSI_Snow_Cover']).first().clip(roi));
//  var snowMask = Modis10a1.neq(0);
//  var snowMask2 = Modis10a1.lte(100);
//  var maskedSnowx = Modis10a1.updateMask(snowMask);
//  var maskedSnow = maskedSnowx.updateMask(snowMask2);
  var clipped=VIIRS09.map(function(image) { return image.clip(roi); });
    var clippeda=VIIRS09a.map(function(image) { return image.clip(roi); });
  var bandi = ['I1','I2', 'I3'];
  var rgbi = clipped.select(['I3', 'I2', 'I1']);
    var rgbia = clippeda.select(['I3', 'I2', 'I1']);
  var rgbVis = {min: 0.0, max: 9000.0,};
  var imag = ee.Image(VIIRS09.first())
                              .select(bandi)
                              .clip(roi);
  var ndci = imag.normalizedDifference(['I1', 'I3']);
  var ndciMasked = ndci.updateMask(ndci.gte(0.08).clip(bounded));
    var imag16 = ee.Image(VIIRS09a.first())
                              .select(bandi)
                              .clip(roi);
  var ndcia = imag16.normalizedDifference(['I1', 'I3']);
  var ndciMaskeda = ndcia.updateMask(ndci.gte(0.1).clip(bounded));
  Map.setCenter(43.2, 43, 8);
//Map.addLayer(maskedSnow, {min: 0, max: 80, palette: ['yellow', 'white']}, 'MODIS 10A1');
  Map.addLayer(rgbi, rgbVis, 'VIIRS_15.oct 2019 (I-bands)');
    Map.addLayer(rgbia, rgbVis, 'VIIRS_16.oct 2019 (I-bands)');
     var diff = ndciMasked.subtract(ndcia);
       var diffM = diff.updateMask(diff.gte(0.16));
//  Map.addLayer(diffM, {min: 0, max: 0.6, palette: ['white', 'red']}, 'Diff (15.oct minus 16.oct)');
  Map.addLayer(ndciMasked, {min: 0.1, max: 1, palette: ['blue', 'white']}, '15.oct 2019 (VNP09_Rho snow)'); 
  Map.addLayer(ndciMaskeda, {min: 0.1, max: 1, palette: ['blue', 'white']}, '16.oct 2019 (VNP09_Rho snow)');
//  Map.addLayer(ndciMaskedb, {min: 0.1, max: 1, palette: ['blue', 'white']}, '16.oct 2019 (VNP_Rho snow)');
//  Map.addLayer(bounded);
Map.addLayer(diffM, {min: 0.05, max: 0.6, palette: ['white', 'red']}, 'High melt and humidity');
//var collectionFromImages = ee.ImageCollection.fromImages(
//  [ee.Image(3), ee.Image(4)]);
//print('collectionFromImages: ', collectionFromImages);
//var collectionFromConstructor = ee.ImageCollection([ndciMasked, ndciMaskeda]);
//print('collectionFromConstructor: ', collectionFromConstructor);