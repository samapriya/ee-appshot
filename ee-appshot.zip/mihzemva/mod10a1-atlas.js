var damsbounded = ee.Geometry.Polygon(
        [[-5.0254638671874545, 32.19224077584831],
          [-4.5393188476562045, 32.505484419402],
          [-4.5695312499999545, 32.59808876127707],
          [-5.1408203124999545, 32.60734393909137],
          [-4.9897583007812045, 33.25511882532697],
          [-3.7675292968749545, 33.5234299195208],
          [-3.7730224609374545, 33.77036525766938],
          [-4.2701538085937045, 33.80460576693427],
          [-5.3111083984374545, 33.13560395956072],
          [-5.2781494140624545, 32.5355913093359],
          [-5.5912597656249545, 32.31070471936209],
          [-5.4978759765624545, 32.23406922542386],
          [-5.5583007812499545, 32.180618348239754],
          [-5.6983764648437045, 32.15969423971448],
          [-5.8357055664062045, 32.24800776562451],
          [-6.6349609374999545, 31.793913178094403],
          [-6.6486938476562045, 31.6937719063158],
          [-8.024731445312455, 31.142665375670962],
          [-8.881665039062455, 31.0885826999557],
          [-8.889904785156205, 30.7705209927324],
          [-7.7061279296874545, 30.947352566683875],
          [-5.8137329101562045, 31.574214374287237]]);
 var roi =  ee.Geometry.Polygon(
          [[-9.2, 34], [-9.2, 30.5],[-3.2, 30.5],[-3.2, 34]], null, false);
var chartstyle = {title: 'Atlas mountains Snow Cover 2017/18',
                  hAxis: {title: 'Date'},
                  vAxis: {title: 'sum_NDSI gt(0)'},
              lineWidth: 0.5, pointSize: 2, };
 var title = ui.Label('Atlas mountains snow cover 2017/18  from MODIS(c NASA, GEE)');
 var title2 = ui.Label('21.jan 2018');title2.style().set('position', 'top-left');
                  Map.add(title); Map.add(title2);
var MOD10A1coll = ee.ImageCollection('MODIS/006/MOD10A1')
                                  .filterDate('2017-12-01','2018-07-01');
var datelist17 = ee.List(['2017-12-02','2017-12-04','2017-12-05','2017-12-06','2017-12-07',
                         '2017-12-10','2017-12-14','2017-12-22','2017-12-23','2017-12-24',
                         '2017-12-26','2017-12-29','2018-01-01','2018-01-02','2018-01-03',
                         '2018-01-04','2018-01-05','2018-01-09','2018-01-11','2018-01-12',
                         '2018-01-16','2018-01-17','2018-01-20','2018-01-21','2018-01-24',
                         '2018-02-01','2018-02-04','2018-02-09','2018-02-11','2018-02-12',
                         '2018-02-14','2018-02-23','2018-02-27','2018-03-09','2018-03-23',
                         '2018-03-26','2018-03-27','2018-03-31','2018-04-01','2018-04-12',
                         '2018-04-15','2018-05-23','2018-06-07','2018-06-19','2018-06-22',
                         '2018-06-24','2018-06-25','2018-06-28','2018-06-29','2018-06-30'])
                  .map(function(date){return ee.Date(date).millis()});
var RhoCollectMODIS = MOD10A1coll.filter(ee.Filter.inList("system:time_start", datelist17));
//print(RhoCollectVIIRS);
 var MODndsiSnowBounded = RhoCollectMODIS.map(function(image) 
                                {return image.clip(damsbounded).select('NDSI_Snow_Cover');});
 var MODndsiBounded     = RhoCollectMODIS.map(function(image) 
                                {return image.clip(damsbounded).select('NDSI');});
 var MODndsiUpThreshold = function(image){return image.addBands(image.where(image.lte(0), 0));};
var  MODndsiBoundUpzero = ee.ImageCollection(MODndsiBounded.map(MODndsiUpThreshold).select(['NDSI_1']));
//print(MODndsiBoundUpzero);
var NDSIup0chart = ui.Chart.image.series(MODndsiBoundUpzero, damsbounded, ee.Reducer.sum(), 464).setOptions(chartstyle); 
//print(ui.Chart.image.series(MODndsiSnowBounded, damsbounded, ee.Reducer.sum(),464 ).setOptions(chartstyle));
//var dataset = ee.Image('USGS/GMTED2010');
//      var elevation = dataset.select('be75').clip(roi);
//      var elevationVis = {min: -50.0, max: 400.0};
//      var hill = ee.Terrain.hillshade(elevation, 260).clip(roi);
                  Map.setOptions('terrain');Map.setCenter(-5.8, 32, 7);
//                  Map.addLayer(hill, elevationVis, 'Elevation', false);
                  var sunnyday = '2018-01-21';
var MOD09GQcoll = ee.ImageCollection('MODIS/006/MOD09GQ')
                                  .filter(ee.Filter.date(sunnyday));
      var addNDVI = function(image) 
              {return image.addBands(image.normalizedDifference(['sur_refl_b02', 'sur_refl_b01'])
                                          .rename('NDVI').clip(roi))};
      var  GQndvi = ee.ImageCollection(MOD09GQcoll.map(addNDVI).select(['NDVI']));
      var ndviSet = {min: 0, max: 0.8, palette: ['white', 'green'],opacity:0.92};
                  Map.addLayer(GQndvi, ndviSet, 'NDVI_GQ', false);
var MOD09GAcoll = ee.ImageCollection('MODIS/006/MOD09GA').filter(ee.Filter.date(sunnyday));
      var  ModisRGB = ee.ImageCollection(MOD09GAcoll.select(['sur_refl_b01', 'sur_refl_b04', 'sur_refl_b03'])); 
      var    rgbVis = {min: 0, max: 6800};
                  Map.addLayer(ModisRGB, rgbVis, 'MOD09GA_21.jan 2018 ~500m/px');
var Mndsi = ee.ImageCollection('MODIS/006/MOD10A1').filter(ee.Filter.date(sunnyday)).select('NDSI');
      var imag = ee.Image(Mndsi.first().clip(damsbounded));
      var ndsiMasked = imag.updateMask(imag.gte(0));
                  Map.addLayer(ndsiMasked, {min: 0, max: 8400, palette: ['blue', 'white']}, 'MOD10A1 NDSI');
var SC10 = ee.ImageCollection('MODIS/006/MOD10A1').filter(ee.Filter.date(sunnyday)).select('NDSI_Snow_Cover');
                  Map.addLayer(SC10, {min: 0, max: 90, palette: ['00FFFF', '0000FF']}, 'Snow MOD10A1 v.6', false);
Map.style().set('cursor', 'crosshair');
var panel = ui.Panel(); panel.style().set('width', '400px');
var intro = ui.Panel([ui.Label({ value: 'Snow_dyna chart 2017-2018',
                                 style: {fontSize: '18px', fontWeight: 'bold'}}),
  ui.Label({ value: 'Click on a map for px_dyna',
                                 style: {fontSize: '10px'}})]);
panel.add(intro);
panel.add(NDSIup0chart);
var lon = ui.Label(); var lat = ui.Label();
//panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
Map.onClick(function(coords) { lon.setValue('lon: ' + coords.lon.toFixed(4)),   //*****
                               lat.setValue('lat: ' + coords.lat.toFixed(4));
            var point = ee.Geometry.Point(coords.lon, coords.lat);
        var ndsiChart = ui.Chart.image.series(MODndsiBoundUpzero, point, ee.Reducer.mean(), 464);
    ndsiChart.setOptions({
      title: 'NDSI   (*10e3)__MOD10A1 px_dyna',
      vAxis: {title : coords.lat, minValue: 0, maxValue: 10000},
      hAxis: {title: coords.lon},//, format: 'MM-yy'},
      lineWidth: 0.5, pointSize: 2, color:'red', gridlines: {count: 2},});
      Map.addLayer(point, {color: 'FF0000'});
panel.widgets().set(2, ndsiChart);});                                           //*****
ui.root.insert(1, panel);
//Export.video.toDrive({ collection: MODndsiSnowBounded , description: 'AtlasTimelapse', dimensions: 720, framesPerSecond: 3, region: roi});
 //var dataset = ee.Image('WWF/HydroSHEDS/03DIR');
//  palette: [
//    '000000', '023858', '006837', '1a9850', '66bd63', 'a6d96a', 'd9ef8b',
//    'ffffbf', 'fee08b', 'fdae61', 'f46d43', 'd73027'],};
//Map.addLayer(drainageDirection, drainageDirectionVis, 'Drainage Direction');
//Map.addLayer(image, {bands: ['B5', 'B4', 'B3'], min: 0, max: 0.5});