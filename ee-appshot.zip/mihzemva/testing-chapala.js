// This script processes a single Landsat 8 image of interest.
 var title = ui.Label('This spring the algae Oscillatoria rubescens red colored spread(Landsat 8, 30 m/px)');
title.style().set('position', 'top-center');
Map.add(title);
 var title2 = ui.Label('VAMO Julio ya :)');
title.style().set('position', 'bottom-center');
Map.add(title2);
        var iniDate = '2021-12-01';
        var endDate = '2022-04-30';
        var l8 = ee.Image('LANDSAT/LC08/C01/T1/LC08_029046_20211225');
var Chapalapoint = ee.Geometry.Point([-103.25,20.24]);
var Chapalaarea =     ee.Geometry.Polygon(
        [[-103.54946723751699,19.777893178841246],
          [-102.02236762814199,19.777893178841246],
          [-102.02236762814199,20.63363056211918],
          [-103.54946723751699,20.63363056211918],
         [-103.54946723751699,19.777893178841246]], null, false);
var Chapalalago =     ee.Geometry.Polygon(
[[-103.37910914400231,20.290904068451997],
 [-103.39284205415856,20.28575170253256],
 [-103.4113814828695,20.28446358429101],
 [-103.41309809663903,20.278022832541232],
 [-103.41824793794763,20.255800185906086],
 [-103.41790461519372,20.23679568950082],
 [-103.40726160982263,20.23260794555628],
 [-103.36331629732263,20.23099724476731],
 [-103.3561065194906,20.2216548511423],
 [-103.33859705904138,20.218111037786656],
 [-103.32074427583825,20.211023168907836],
 [-103.3011748788656,20.20167957581542],
 [-103.28057551363122,20.199746348612106],
 [-103.26134943941247,20.197490886542077],
 [-103.23491358736169,20.182023981170282],
 [-103.22530055025231,20.185246379728124],
 [-103.21774744966638,20.18363518877694],
 [-103.21465754488122,20.178479265813937],
 [-103.20950770357263,20.17719025842869],
[-103.19783472993981,20.174934469862286],
 [-103.18684840181481,20.162688191166996],
 [-103.17860865572106,20.158820745546922],
 [-103.17174220064294,20.151407873575458],
 [-103.15732264497888,20.15688698679683],
[-103.15457606294763,20.16075448033762],
 [-103.13740992525231,20.168489179868327],
 [-103.12161707857263,20.169455990347135],
 [-103.11131739595544,20.163977318407166],
 [-103.10445094087731,20.165266434996436],
 [-103.09586787202966,20.166555540934272],
 [-103.09174799898278,20.162688191166996],
 [-103.08419489839685,20.162043623553032],
 [-103.07698512056481,20.173645433172595],
 [-103.06908869722497,20.19040207883454],
 [-103.05157923677575,20.192657643550294],
 [-103.0378463266195,20.188468711659773],
 [-103.02926325777185,20.1817017376504],
 [-103.02274012544763,20.1678446362201],
 [-103.00935053804528,20.17042279483347],
 [-102.99733424165856,20.176223495896316],
 [-102.9389693734945,20.17332317233529],
 [-102.90292048433435,20.169455990347135],
 [-102.86584162691247,20.164621878033195],
 [-102.8507354257406,20.149796333091402],
 [-102.84146571138513,20.13077889960902],
 [-102.83803248384606,20.120785761326164],
 [-102.82292628267419,20.110147202741945],
 [-102.81399989107263,20.108535236818827],
 [-102.8071334359945,20.11627252180161],
 [-102.80576014497888,20.123687060818025],
[-102.80953669527185,20.13142359627329],
 [-102.81331324556481,20.13335767031093],
 [-102.82567286470544,20.126910663785086],
 [-102.83322596529138,20.13658107385207],
 [-102.82841944673669,20.146895518307485],
 [-102.78756403902185,20.148507088728856],
 [-102.78687739351403,20.14141605448671],
 [-102.7738311288656,20.14592856807204],
 [-102.76181483247888,20.153664002308766],
 [-102.75597834566247,20.162043623553032],
 [-102.73915553072106,20.174289952849367],
 [-102.71477961519372,20.17332317233529],
 [-102.70894312837731,20.171711858159888],
 [-102.70310664156091,20.17590124038681],
 [-102.69315028169763,20.172678648662878],
 [-102.68800044038903,20.176868004917274],
 [-102.68731379488122,20.2023239795496],
 [-102.68937373140466,20.211345351769832],
 [-102.6969268319906,20.211345351769832],
 [-102.69898676851403,20.20329058015036],
 [-102.70516657808435,20.202646180416604],
 [-102.7079131601156,20.206834731011224],
 [-102.71752619722497,20.210700985378875],
 [-102.75357508638513,20.205223763349288],
 [-102.76971125581872,20.204257174750353],
 [-102.76627802827966,20.214889319229368],
 [-102.7573516366781,20.219077540344617],
 [-102.74155878999841,20.225520737266553],
 [-102.74773859956872,20.229064381792643],
 [-102.74430537202966,20.246137173198115],
 [-102.73057246187341,20.251935052974012],
 [-102.70139002779138,20.252901345226725],
 [-102.70173335054528,20.25837688773962],
 [-102.69658350923669,20.261597704887777],
 [-102.702763318807,20.278988962359556],
 [-102.70688319185388,20.282209351613034],
 [-102.71683955171716,20.280599165347127],
 [-102.71683955171716,20.273514147138503],
 [-102.7192428109945,20.271903870588645],
 [-102.72507929781091,20.279311004294737],
 [-102.7353789804281,20.28510764474959],
 [-102.75323176363122,20.28639575763916],
 [-102.76765131929528,20.292514147673092],
 [-102.77829432466638,20.298632296128872],
 [-102.78172755220544,20.307004107692276],
 [-102.79271388033044,20.30990193701217],
 [-102.80198359468591,20.308614019566274],
 [-102.82773280122888,20.301852277210358],
[-102.84352564790856,20.303462242647413],
 [-102.8510787484945,20.29992029659427],
 [-102.8620650766195,20.302818258481],
 [-102.87099146822106,20.303462242647413],
 [-102.90429377534997,20.303462242647413],
 [-102.93038630464685,20.308292038530674],
 [-102.95853877046716,20.31054589171713],
 [-102.9660918710531,20.31762921666026],
 [-102.99149775484216,20.33276068817064],
 [-102.999394178182,20.331151027523212],
 [-103.02239680269372,20.328897474466785],
 [-103.03097987154138,20.33276068817064],
 [-103.05054926851403,20.326965831424033],
 [-103.07698512056481,20.32921941262833],
 [-103.09689784029138,20.31827313921583],
 [-103.11715388277185,20.31827313921583],
 [-103.12676691988122,20.31054589171713],
 [-103.14118647554528,20.302818258480976],
 [-103.17071223238122,20.29992029659424],
 [-103.17501191237059,20.293849576332274],
 [-103.1834233198413,20.285316039382543],
 [-103.18788651564208,20.282900802111655],
 [-103.19921616652098,20.288214274434385],
 [-103.20882920363036,20.291112455291206],
 [-103.21209076979247,20.288214274434385],
 [-103.22153214552489,20.286765163682443],
 [-103.22445038893309,20.28885831930854],
 [-103.22719697096434,20.289663371637573],
 [-103.2302868757495,20.28692617665726],
 [-103.23406342604247,20.285155024735186],
 [-103.24367646315184,20.285960096299476],
 [-103.24693802931395,20.287248202105122],
 [-103.24831132032958,20.29062942891223],
 [-103.26719407179442,20.29578163266191],
 [-103.26994065382567,20.296586649021606],
 [-103.27320221998778,20.294976612119214],
 [-103.27697877028075,20.293688570550607],
 [-103.28796509840575,20.291595480164606],
 [-103.29723481276122,20.287409214578165],
 [-103.3020413313159,20.286604150540363],
 [-103.31680420973387,20.286765163682443],
 [-103.32470063307372,20.285155024735186],
 [-103.33328370192137,20.280968585203127],
 [-103.33843354322997,20.280968585203127],
 [-103.34409836866942,20.28354486906316],
 [-103.34701661207762,20.28708718946482],
 [-103.36452607252684,20.289019330108893],
 [-103.37910914400231,20.290904068451997]], null, false);
// Citations: 
// Page, B.P. and Mishra, D.R., 2018. A modified atmospheric correction when coupling sentinel-2 and landsat-8 for inland water quality monitoring, In Review
/////https://github.com/SERVIR/water-quality-gee/blob/master/javascript/Ls8_single_image.js///////////////////
// Import Collections //
// landsat 8 raw dn
var OLI_DN = ee.ImageCollection('LANDSAT/LC08/C01/T1');
// toms / omi
var ozone = ee.ImageCollection('TOMS/MERGED');
// Filtering Collection and Masking //
var pi = ee.Image(3.141592);
// filter landsat 8 collection
var FC_OLI = OLI_DN.filterDate(iniDate, endDate).filterBounds(Chapalapoint);
print(FC_OLI, 'Available Imagery');
print(l8, 'l8 image info');
// oli image date
var oliDate = l8.date();
print(oliDate, 'l8 Date');
var footprint = l8.geometry();
// single OLI image ATMOSPHERIC CORRECTION // 
// dem
var DEM_OLI = ee.Image('USGS/SRTMGL1_003').clip(footprint);
// ozone
var DU_OLI = ee.Image(ozone.filterDate(iniDate,endDate).filterBounds(footprint).mean());
//Julian Day
var imgDate_OLI = ee.Date(l8.get('system:time_start'));
var FOY_OLI = ee.Date.fromYMD(imgDate_OLI.get('year'),1,1);
var JD_OLI = imgDate_OLI.difference(FOY_OLI,'day').int().add(1); 
// Earth-Sun distance
var d_OLI = ee.Image.constant(l8.get('EARTH_SUN_DISTANCE'));
//Sun elevation
var SunEl_OLI = ee.Image.constant(l8.get('SUN_ELEVATION'));
//Sun azimuth
var SunAz_OLI = ee.Image.constant(l8.get('SUN_AZIMUTH'));
//Satellite zenith
var SatZe_OLI = ee.Image(0.0);
var cosdSatZe_OLI = (SatZe_OLI).multiply(pi.divide(ee.Image(180))).cos();
var sindSatZe_OLI = (SatZe_OLI).multiply(pi.divide(ee.Image(180))).sin();
//Satellite azimuth
var SatAz_OLI = ee.Image(0.0);
//Sun zenith________in degrees
var SunZe_OLI = ee.Image(90).subtract(SunEl_OLI);
var cosdSunZe_OLI = SunZe_OLI.multiply(pi.divide(ee.Image.constant(180))).cos();
var sindSunZe_OLI = SunZe_OLI.multiply(pi.divide(ee.Image(180))).sin(); 
//Relative azimuth
var RelAz_OLI = ee.Image(SunAz_OLI);
var cosdRelAz_OLI = RelAz_OLI.multiply(pi.divide(ee.Image(180))).cos();
//Pressure calculation
var P_OLI = ee.Image(101325).multiply(ee.Image(1).subtract(ee.Image(0.0000225577).multiply(DEM_OLI)).pow(5.25588)).multiply(0.01);
var Po_OLI = ee.Image(1013.25);
// Radiometric Calibration //
//select bands to be converted to radiance
var bands_OLI = ['B1','B2','B3','B4','B5','B6','B7'];
// radiance_mult_bands
var rad_mult_OLI = ee.Image(ee.Array([ee.Image(l8.get('RADIANCE_MULT_BAND_1')),
                        ee.Image(l8.get('RADIANCE_MULT_BAND_2')),
                        ee.Image(l8.get('RADIANCE_MULT_BAND_3')),
                        ee.Image(l8.get('RADIANCE_MULT_BAND_4')),
                        ee.Image(l8.get('RADIANCE_MULT_BAND_5')),
                        ee.Image(l8.get('RADIANCE_MULT_BAND_6')),
                        ee.Image(l8.get('RADIANCE_MULT_BAND_7'))]
                        )).toArray(1);
// radiance add band                         
var rad_add_OLI = ee.Image(ee.Array([ee.Image(l8.get('RADIANCE_ADD_BAND_1')),
                        ee.Image(l8.get('RADIANCE_ADD_BAND_2')),
                        ee.Image(l8.get('RADIANCE_ADD_BAND_3')),
                        ee.Image(l8.get('RADIANCE_ADD_BAND_4')),
                        ee.Image(l8.get('RADIANCE_ADD_BAND_5')),
                        ee.Image(l8.get('RADIANCE_ADD_BAND_6')),
                        ee.Image(l8.get('RADIANCE_ADD_BAND_7'))]
                        )).toArray(1);
//create an empty image to save new radiance bands to
var imgArr_OLI = l8.select(bands_OLI).toArray().toArray(1);
var Ltoa_OLI = imgArr_OLI.multiply(rad_mult_OLI).add(rad_add_OLI)
// esun
var ESUN_OLI = ee.Image.constant(197.24790954589844)
                .addBands(ee.Image.constant(201.98426818847656))
                .addBands(ee.Image.constant(186.12677001953125))
                .addBands(ee.Image.constant(156.95257568359375))
                .addBands(ee.Image.constant(96.04714965820312))
                .addBands(ee.Image.constant(23.8833221450863))
                .addBands(ee.Image.constant(8.04995873449635)).toArray().toArray(1);
ESUN_OLI = ESUN_OLI.multiply(ee.Image(1));
var ESUNImg_OLI = ESUN_OLI.arrayProject([0]).arrayFlatten([bands_OLI]);
// Ozone Correction //
// Ozone coefficients
var koz_OLI = ee.Image.constant(0.0039).addBands(ee.Image.constant(0.0218))
                          .addBands(ee.Image.constant(0.1078))
                          .addBands(ee.Image.constant(0.0608))
                          .addBands(ee.Image.constant(0.0019))
                          .addBands(ee.Image.constant(0))
                          .addBands(ee.Image.constant(0))
                          .toArray().toArray(1);
// Calculate ozone optical thickness
var Toz_OLI = koz_OLI.multiply(DU_OLI).divide(ee.Image.constant(1000));
// Calculate TOA radiance in the absense of ozone
var Lt_OLI = Ltoa_OLI.multiply(((Toz_OLI)).multiply((ee.Image.constant(1).divide(cosdSunZe_OLI)).add(ee.Image.constant(1).divide(cosdSatZe_OLI))).exp());
// Rayleigh optical thickness
var bandCenter_OLI = ee.Image(443).divide(1000).addBands(ee.Image(483).divide(1000))
                                          .addBands(ee.Image(561).divide(1000))
                                          .addBands(ee.Image(655).divide(1000))
                                          .addBands(ee.Image(865).divide(1000))
                                          .addBands(ee.Image(1609).divide(1000))
                                          .addBands(ee.Number(2201).divide(1000))
                                          .toArray().toArray(1);
// create an empty image to save new Tr values to
var Tr_OLI = (P_OLI.divide(Po_OLI)).multiply(ee.Image(0.008569).multiply(bandCenter_OLI.pow(-4))).multiply((ee.Image(1).add(ee.Image(0.0113).multiply(bandCenter_OLI.pow(-2))).add(ee.Image(0.00013).multiply(bandCenter_OLI.pow(-4)))));
// Fresnel Reflection //
// Specular reflection (s- and p- polarization states)
var theta_V_OLI = ee.Image(0.0000000001);
var sin_theta_j_OLI = sindSunZe_OLI.divide(ee.Image(1.333));
var theta_j_OLI = sin_theta_j_OLI.asin().multiply(ee.Image(180).divide(pi));
var theta_SZ_OLI = SunZe_OLI;
var R_theta_SZ_s_OLI = (((theta_SZ_OLI.multiply(pi.divide(ee.Image(180)))).subtract(theta_j_OLI.multiply(pi.divide(ee.Image(180))))).sin().pow(2)).divide((((theta_SZ_OLI.multiply(pi.divide(ee.Image(180)))).add(theta_j_OLI.multiply(pi.divide(ee.Image(180))))).sin().pow(2)));
var R_theta_V_s_OLI = ee.Image(0.0000000001);
var R_theta_SZ_p_OLI = (((theta_SZ_OLI.multiply(pi.divide(180))).subtract(theta_j_OLI.multiply(pi.divide(180)))).tan().pow(2)).divide((((theta_SZ_OLI.multiply(pi.divide(180))).add(theta_j_OLI.multiply(pi.divide(180)))).tan().pow(2)));
var R_theta_V_p_OLI = ee.Image(0.0000000001);
var R_theta_SZ_OLI = ee.Image(0.5).multiply(R_theta_SZ_s_OLI.add(R_theta_SZ_p_OLI));
var R_theta_V_OLI = ee.Image(0.5).multiply(R_theta_V_s_OLI.add(R_theta_V_p_OLI));
// Rayleigh scattering phase function //
// Sun-sensor geometry
var theta_neg_OLI = ((cosdSunZe_OLI.multiply(ee.Image(-1))).multiply(cosdSatZe_OLI)).subtract((sindSunZe_OLI).multiply(sindSatZe_OLI).multiply(cosdRelAz_OLI));
var theta_neg_inv_OLI = theta_neg_OLI.acos().multiply(ee.Image(180).divide(pi));
var theta_pos_OLI = (cosdSunZe_OLI.multiply(cosdSatZe_OLI)).subtract(sindSunZe_OLI.multiply(sindSatZe_OLI).multiply(cosdRelAz_OLI));
var theta_pos_inv_OLI = theta_pos_OLI.acos().multiply(ee.Image(180).divide(pi));
var cosd_tni_OLI = theta_neg_inv_OLI.multiply(pi.divide(180)).cos(); // in degrees
var cosd_tpi_OLI = theta_pos_inv_OLI.multiply(pi.divide(180)).cos(); // in degrees
var Pr_neg_OLI = ee.Image(0.75).multiply((ee.Image(1).add(cosd_tni_OLI.pow(2))));
var Pr_pos_OLI = ee.Image(0.75).multiply((ee.Image(1).add(cosd_tpi_OLI.pow(2))));
// Rayleigh scattering phase function
var Pr_OLI = Pr_neg_OLI.add((R_theta_SZ_OLI.add(R_theta_V_OLI)).multiply(Pr_pos_OLI));
// Calulate Lr,
var denom_OLI = ee.Image(4).multiply(pi).multiply(cosdSatZe_OLI);
var Lr_OLI = (ESUN_OLI.multiply(Tr_OLI)).multiply(Pr_OLI.divide(denom_OLI));
// Rayleigh corrected radiance
var Lrc_OLI = (Lt_OLI.divide(ee.Image(10))).subtract(Lr_OLI);
var LrcImg_OLI = Lrc_OLI.arrayProject([0]).arrayFlatten([bands_OLI]);
// Rayleigh corrected reflectance
var prc_OLI = Lrc_OLI.multiply(pi).multiply(d_OLI.pow(2)).divide(ESUN_OLI.multiply(cosdSunZe_OLI));
var prcImg_OLI = prc_OLI.arrayProject([0]).arrayFlatten([bands_OLI]);
// Aerosol Correction // 
// Bands in nm
var bands_nm_OLI = ee.Image(443).addBands(ee.Image(483))
                            .addBands(ee.Image(561))
                            .addBands(ee.Image(655))
                            .addBands(ee.Image(865))
                            .addBands(ee.Image(0))
                            .addBands(ee.Image(0))
                            .toArray().toArray(1);
// Lam in SWIR bands
var Lam_6_OLI = LrcImg_OLI.select('B6');
var Lam_7_OLI = LrcImg_OLI.select('B7');
// Calculate aerosol type
var eps_OLI = (((((Lam_7_OLI).divide(ESUNImg_OLI.select('B7'))).log()).subtract(((Lam_6_OLI).divide(ESUNImg_OLI.select('B6'))).log())).divide(ee.Image(2201).subtract(ee.Image(1609))));
// Calculate multiple scattering of aerosols for each band
var Lam_OLI = (Lam_7_OLI).multiply(((ESUN_OLI).divide(ESUNImg_OLI.select('B7')))).multiply((eps_OLI.multiply(ee.Image(-1))).multiply((bands_nm_OLI.divide(ee.Image(2201)))).exp());
// diffuse transmittance
var trans_OLI = Tr_OLI.multiply(ee.Image(-1)).divide(ee.Image(2)).multiply(ee.Image(1).divide(cosdSatZe_OLI)).exp();
// Compute water-leaving radiance
var Lw_OLI = Lrc_OLI.subtract(Lam_OLI).divide(trans_OLI);
// water-leaving reflectance
var pw_OLI = (Lw_OLI.multiply(pi).multiply(d_OLI.pow(2)).divide(ESUN_OLI.multiply(cosdSunZe_OLI)));
var pwImg_OLI = pw_OLI.arrayProject([0]).arrayFlatten([bands_OLI]);
// Rrs
var Rrs = (pw_OLI.divide(pi).arrayProject([0]).arrayFlatten([bands_OLI]).slice(0,5));
// Models //
// Surface water temperature  
var TIRS_1 = l8.select('B10');
var b10_add_band = ee.Number(TIRS_1.get('RADIANCE_ADD_BAND_10'));
var b10_mult_band = ee.Number(TIRS_1.get('RADIANCE_MULT_BAND_10'));
var Oi = ee.Number(0.29);
var TIRS_cal = (TIRS_1.multiply(b10_mult_band).add(b10_add_band).subtract(Oi)); //.multiply(lakes);
var K1_b10 = ee.Number(TIRS_1.get('K1_CONSTANT_BAND_10'));
var K2_b10 = ee.Number(TIRS_1.get('K2_CONSTANT_BAND_10'));
var LST = ((ee.Image(K2_b10).divide(((ee.Image(K1_b10).divide(ee.Image(TIRS_cal))).add(ee.Image(1))).log())).subtract(ee.Image(273))); // Celsius
LST = (ee.Image(0.7745).multiply(LST)).add(ee.Image(9.6502)); // calibration R2 = 0.8599
// chlor_a
// Chlorophyll-a OC3
var a0 = ee.Image(0.2412);
var a1 = ee.Image(-2.0546);
var a2 = ee.Image(1.1776);
var a3 = ee.Image(-0.5538);
var a4 = ee.Image(-0.4570);
var log_BG = (Rrs.select('B1').divide(Rrs.select('B3'))).log10();
var a1a = a1.multiply(log_BG.pow(1));
var a2a = a2.multiply(log_BG.pow(2));
var a3a = a3.multiply(log_BG.pow(3));
var a4a = a4.multiply(log_BG.pow(4));
var sum = a1a.add(a2a).add(a3a).add(a4a);
var log10_chlor_a = a0.add(sum);
var chlor_a = ee.Image(10).pow(log10_chlor_a);
var chlor_a_cal = ee.Image(4.0752).multiply(chlor_a).subtract(ee.Image(3.9617));
// SD
var ln_BlueRed = (Rrs.select('B2').divide(Rrs.select('B4'))).log();
var lnMOSD = (ee.Image(1.4856).multiply(ln_BlueRed)).add(ee.Image(0.2734)); // R2 = 0.8748 with in-situ
var MOSD = ee.Image(10).pow(lnMOSD); // log space to (m)
var SD = (ee.Image(0.1777).multiply(MOSD)).add(ee.Image(1.0813));
// tsi
var TSI_c = ee.Image(30.6).add(ee.Image(9.81)).multiply(chlor_a_cal.log());
var TSI_s = ee.Image(60.0).subtract(ee.Image(14.41)).multiply(SD.log());
var TSI = (TSI_c.add(TSI_s)).divide(ee.Image(2));
// Reclassify TSI 
  // Create conditions
  var mask1 = TSI.lt(30); // (1)
  var mask2 = TSI.gte(30).and(TSI.lt(40));// (2)
  var mask3 = TSI.gte(40).and(TSI.lt(50)); // (3)
  var mask4 = TSI.gte(50).and(TSI.lt(60)); // (4)
  var mask5 = TSI.gte(60).and(TSI.lt(70)); // (5)
  var mask6 = TSI.gte(70).and(TSI.lt(80)); // (6)
  var mask7 = TSI.gte(80); // (7)
  // Reclassify conditions into new values
  var img1 = TSI.where(mask1.eq(1), 1).mask(mask1);
  var img2 = TSI.where(mask2.eq(1), 2).mask(mask2);
  var img3 = TSI.where(mask3.eq(1), 3).mask(mask3);
  var img4 = TSI.where(mask4.eq(1), 4).mask(mask4);
  var img5 = TSI.where(mask5.eq(1), 5).mask(mask5);
  var img6 = TSI.where(mask6.eq(1), 6).mask(mask6);
  var img7 = TSI.where(mask7.eq(1), 7).mask(mask7);
// Ouput of reclassified image
var TSI_R = img1.unmask(img2).unmask(img3).unmask(img4).unmask(img5).unmask(img6).unmask(img7);
// Create a panel to hold the chart.
var panel = ui.Panel();
panel.style().set({
  width: '200px',
  position: 'bottom-right'});
Map.add(panel);
// Register a function to draw a chart when a user clicks on the map.
Map.onClick(function(coords) {
  panel.clear();
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chart = ui.Chart.image.regions(SD, point, null, 30);
  chart.setOptions({
    title: null,  
    vAxis: {title: 'Secchi depth (m)'},  
    hAxis: {title: 'Lake px' }, // , minValue: 0},
    legend: 'none', pointSize: 4});
  panel.add(chart);   });
var panel2 = ui.Panel();
panel.style().set({
  width: '200px',
  position: 'bottom-left' });
Map.add(panel2);
Map.onClick(function(coords) {
  panel2.clear();
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chart = ui.Chart.image.regions(LST, point, null, 30);
  chart.setOptions({
    title: null,  
    vAxis: {title: 'Temperature (C)'},  
    hAxis: {title: 'Lake px' }, // , minValue: 0},
    legend: 'none', pointSize: 4});
  panel2.add(chart); });
Map.addLayer(DEM_OLI, {min: 600, max: 2600, palette: ['green', 'yellow', 'orange' , 'red','darkred','white']}, 'DEM of tile');
Map.addLayer(l8.clip(Chapalaarea), {bands: ['B4', 'B3', 'B2'], min: 1000, max: 12000, gamma :0.6}, 'RGB 25.dec 2021'); 
Map.addLayer(LST.clip(Chapalalago), {min: 18, max: 24, palette: ['darkblue', 'blue', 'white', 'red']}, 'Land surface temperature 25.dec 2021');
Map.addLayer(chlor_a_cal.clip(Chapalalago), {min: 8, max: 32, palette: ['blue', 'cyan', 'yellow', 'orange' , 'red']}, 'Chlorophyll a 25.dec 2021', false);
Map.addLayer(SD.clip(Chapalalago), {min: 0, max: 3, palette: ['darkred', 'orange', 'yellow', 'limegreen', 'cyan', 'blue']}, 'Secchi depth 25.dec 2021');
//Map.addLayer(TSI.clip(Chapalalago), {min: 30, max: 70, palette: ['blue', 'cyan', 'limegreen', 'yellow', 'orange' , 'darkred']}, 'Trophic state index 17.mar 2020', false)
//Map.addLayer(TSI_R.clip(Chapalalago), {min: 1, max: 7, palette: ['purple', 'blue', 'limegreen', 'yellow', 'orange', 'orangered', 'darkred']}, 'TSI_R', true)
Map.centerObject(Chapalaarea, 10);