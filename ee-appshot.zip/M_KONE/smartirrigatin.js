var s2 = ee.ImageCollection("COPERNICUS/S2_SR");
var urban = ee.FeatureCollection("users/M_KONE/ROI");
var AREA = ee.FeatureCollection("users/M_KONE/AREA");
var filtered = AREA.filter(ee.Filter.eq('system:index', '00000000000000000000'))
var geometry = filtered.geometry()
var startDate= '2021-04-01';
var endDate= ee.Date(Date.now());
Map.setCenter(-5.29049726,33.41723983174487,17)
var filtered = s2.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 30))
  .filter(ee.Filter.date(startDate, endDate))
  .filter(ee.Filter.bounds(geometry))
var image = filtered.median(); 
// Calculate  Normalized Difference Vegetation Index (NDVI)
// 'NIR' (B8) and 'RED' (B4)
var NDVI = image.normalizedDifference(['B8', 'B4']).rename(['NDVI']);
function addNDVI(image) {
  var NDVI = image.normalizedDifference(['B8', 'B4']).rename('NDVI');
  return image.addBands(NDVI);
}
function addDWSI(image) {
 var DWSI= image.expression(
 '(NIR - GREEN)/(SWIR1 + RED)', {
      'NIR': image.select('B8').multiply(0.0001),
      'RED': image.select('B4').multiply(0.0001),
      'SWIR1': image.select('B11').multiply(0.0001),
       'GREEN': image.select('B3').multiply(0.0001),
}).rename('DWSI');
  return image.addBands(DWSI);
}
function addNDWI(image) {
var NDWI= image.expression(
 '(NIR - SWIR1)/(SWIR1 + NIR)', {
      'NIR': image.select('B8').multiply(0.0001),
      'SWIR1': image.select('B11').multiply(0.0001),
}).rename('NDWI');
return image.addBands(NDWI);
}
function addEVI(image) {
var EVI = image.expression(
 '2.5 * ((NIR - RED) / ((NIR + 6.0 * RED - 7.5 * BLUE) + 1.0))', {
      'NIR': image.select('B8').multiply(0.0001),
      'RED': image.select('B4').multiply(0.0001),
      'BLUE': image.select('B4').multiply(0.0001),
}).rename('EVI');
return image.addBands(EVI);
}
function addSAVI(image) {
var SAVI = image.expression(
    '1.5 * ((NIR - RED) / (NIR + RED + 0.5))', {
      'NIR': image.select('B8').multiply(0.0001),
      'RED': image.select('B4').multiply(0.0001),
      'BLUE': image.select('B4').multiply(0.0001),
}).rename('SAVI');
return image.addBands(SAVI);
}
// Map the function over the collection
var withNdvi = filtered.map(addNDVI);
var withDWSI = withNdvi.map(addDWSI);
var withNDWI = withDWSI.map(addNDWI);
var withEVI = withNDWI.map(addEVI);
var withSAVI = withEVI.map(addSAVI);
// Calculate Enhanced Vegetation Index
var EVI = image.expression(
 '2.5 * ((NIR - RED) / ((NIR + 6.0 * RED - 7.5 * BLUE) + 1.0))', {
      'NIR': image.select('B8').multiply(0.0001),
      'RED': image.select('B4').multiply(0.0001),
      'BLUE': image.select('B4').multiply(0.0001),
}).rename('EVI');
// Calculated Disease Water Stress Index 
var DWSI= image.expression(
 '(NIR - GREEN)/(SWIR1 + RED)', {
      'NIR': image.select('B8').multiply(0.0001),
      'RED': image.select('B4').multiply(0.0001),
      'SWIR1': image.select('B11').multiply(0.0001),
       'GREEN': image.select('B3').multiply(0.0001),
}).rename('DWSI');
// Calculated Differencied  Normalized Difference Water Index 
var NDWI= image.expression(
 '(NIR - SWIR1)/(SWIR1 + NIR)', {
      'NIR': image.select('B8').multiply(0.0001),
      'SWIR1': image.select('B11').multiply(0.0001),
}).rename('NDWI');
var savi = image.expression(
    '1.5 * ((NIR - RED) / (NIR + RED + 0.5))', {
      'NIR': image.select('B8').multiply(0.0001),
      'RED': image.select('B4').multiply(0.0001),
      'BLUE': image.select('B4').multiply(0.0001),
}).rename('savi');
var palette = [
  '#d7191c','#fdae61','#ffffbf','#a6d96a','#1a9641'];
var rgbVis = {min: 0.0, max: 3000, bands: ['B4', 'B3', 'B2']};
var ndviVis = {min:0, max:1, palette: palette}
var ndwiVis = {min:0, max:0.5, palette: ['white', 'blue']}
var dswiVis= {min:0, max:1, palette: ['#fdfdfd', '#c9caed','#5156d0','#001fff']}
var saviVis = {min:0, max:0.5, palette: palette}
var eviVis = {min:0, max:0.75, palette:palette}
Map.addLayer(image.clip(geometry), rgbVis, 'Image');
// Map.addLayer(savi.clip(geometry), saviVis, 'savi') 
// Map.addLayer(NDVI.clip(geometry), ndviVis, 'NDVI')
// Map.addLayer(EVI.clip(geometry), eviVis, 'EVI')
// Map.addLayer(DWSI.clip(geometry), dswiVis, 'DWSI')
// Map.addLayer(NDWI.clip(geometry), dswiVis, 'NDWI')
function createColorBar(titleText, palette, min, max) {
  // Legend Title
  var title = ui.Label({
    value: titleText, 
    style: {fontWeight: 'bold', textAlign: 'center', stretch: 'horizontal'}});
  // Colorbar
  var legend = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 1, 0.1],
      dimensions: '200x20',
      format: 'png', 
      min: 0, max: 1,
      palette: palette},
    style: {stretch: 'horizontal', margin: '8px 8px', maxHeight: '40px'},
  });
  // Legend Labels
  var labels = ui.Panel({
    widgets: [
      ui.Label(min, {margin: '4px 10px',textAlign: 'left', stretch: 'horizontal'}),
      ui.Label((min+max)/2, {margin: '4px 20px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(max, {margin: '4px 10px',textAlign: 'right', stretch: 'horizontal'})],
    layout: ui.Panel.Layout.flow('horizontal')});
  // Create a panel with all 3 widgets
  var legendPanel = ui.Panel({
    widgets: [title, legend, labels],
    style: {position: 'bottom-center', padding: '8px 15px'}
  })
  return legendPanel
}
// Create a panel to hold our widgets.
var panel = ui.Panel({
  style: {
    width: '600px',
    backgroundColor: 'white',
    textAlign : 'center',
    // border:'3px solid red'
  }
});
var title = ui.Label({
  value: 'Crop Spatial Monitoring',
  style: {
    fontSize: '36px',
    textAlign: 'center',
    fontWeight:'bold'
  }
});
// You can add widgets to the panel
panel.add(title)
var index = ui.Panel([
 ui.Label({
    value: "Spatial variability index ( Click button to load index)",
    style:{
      textAlign: 'center',
      fontSize: '14px',
      color:'green',
      fontWeight:'bold'
    }
    })
]);
panel.add(index);
// You can even add panels to other panels
var dropdownPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
});
panel.add(dropdownPanel);
var buttonNDVI = ui.Button('NDVI')
var buttonDWSI = ui.Button('DWSI')
var buttonEVI = ui.Button('EVI')
var buttonSAVI = ui.Button('SAVI')
var buttonGNDVI = ui.Button('GNDVI')
// var buttonCVI = ui.Button('CVI')
dropdownPanel.add(buttonNDVI)
dropdownPanel.add(buttonDWSI)
dropdownPanel.add(buttonEVI)
dropdownPanel.add(buttonSAVI)
dropdownPanel.add(buttonGNDVI)
// dropdownPanel.add(buttonCVI)
// DSWI LOAD
var loadComposite = function() {
  var DWSI= image.expression(
 '(NIR - GREEN)/(SWIR1 + RED)', {
      'NIR': image.select('B8').multiply(0.0001),
      'RED': image.select('B4').multiply(0.0001),
      'SWIR1': image.select('B11').multiply(0.0001),
       'GREEN': image.select('B3').multiply(0.0001),
}).rename('DWSI');
var dswiVis= {min:0, max:1, palette: ['#fdfdfd', '#c9caed','#5156d0','#001fff']}
Map.addLayer(DWSI.clip(geometry), dswiVis, 'DWSI')
}
buttonDWSI.onClick(loadComposite)
// NDVI LOAD
var loadNDVI = function() {
var NDVI = image.normalizedDifference(['B8', 'B4']).rename(['NDVI']);
var palettendvi = ['f9fffb','bcffc1','0eff15','00c006'];
var ndviVis = {min:0, max:0.6, palette: palettendvi}
Map.addLayer(NDVI.clip(geometry), ndviVis, 'NDVI')
var colorBar = createColorBar('NDVI Values', palettendvi, 0, 0.6)
Map.add(colorBar)
}
buttonNDVI.onClick(loadNDVI)
// LOAD EVI
var loadEVI = function() {
 var EVI = image.expression(
 '2.5 * ((NIR - RED) / ((NIR + 6.0 * RED - 7.5 * BLUE) + 1.0))', {
      'NIR': image.select('B8').multiply(0.0001),
      'RED': image.select('B4').multiply(0.0001),
      'BLUE': image.select('B4').multiply(0.0001),
}).rename('EVI');
var eviVis = {min:0, max:0.75, palette:palette}
var palettevi = ['f9fffb','bcffc1','0eff15','00c006'];
var eviVis = {min:0, max:0.6, palette: palettevi}
var colorBar = createColorBar('EVI Values', palettevi, 0, 0.6)
Map.add(colorBar)
Map.addLayer(EVI.clip(geometry), eviVis, 'EVI')
}
buttonEVI.onClick(loadEVI)
// LOAD SAVI
var loadSAVI = function() {
  var savi = image.expression(
    '1.5 * ((NIR - RED) / (NIR + RED + 0.5))', {
      'NIR': image.select('B8').multiply(0.0001),
      'RED': image.select('B4').multiply(0.0001),
      'BLUE': image.select('B4').multiply(0.0001),
}).rename('savi');
var saviVis = {min:0, max:0.5, palette: palettesavi}
var colorBar = createColorBar('EVI Values', palettesavi, 0, 0.6)
Map.add(colorBar)
Map.addLayer(savi.clip(geometry), saviVis, 'savi')
}
buttonSAVI.onClick(loadSAVI)
// LOAD GNDVI
var loadGNDVI = function() {
var GNDVI = image.expression(
    '((NIR - GREEN) / (NIR + GREEN))', {
      'NIR': image.select('B8').multiply(0.0001),
      'GREEN': image.select('B3').multiply(0.0001),
}).rename('GNDVI');
var ndviVis = {min:0, max:1, palette: palette}
Map.addLayer(GNDVI.clip(geometry), ndviVis, 'GNDVI')
}
buttonGNDVI.onClick(loadGNDVI)
// LOAD CVI
// var loadCVI = function() {
// var CVI = image.expression(
//     '((NIR*RED) / (GREEN*GREEN))', {
//       'NIR': image.select('B8').multiply(0.0001),
//       'GREEN': image.select('B3').multiply(0.0001),
//       'RED': image.select('B4').multiply(0.0001),
// }).rename('CVI');
// var ndviVis = {min:0, max:1, palette: palette}
// Map.addLayer(CVI.clip(geometry), ndviVis, 'CVI')
// }
// buttonCVI.onClick(loadCVI)
// You can even add panels to other panels
var dropdownPanel1 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
});
panel.add(dropdownPanel1);
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: "Click to visualise index evolution chart",
    style:{
      textAlign: 'left',
      fontSize: '14px',
      color:'green',
      fontWeight:'bold'
    }
    })
]);
dropdownPanel1.add(intro);
// panels to hold lon/lat values
var lon = ui.Label();
var lat = ui.Label();
dropdownPanel1.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// Register a callback on the default map to be invoked when the map is clicked
Map.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2)),
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  // Create an NDVI chart.
  var ndviChart = ui.Chart.image.series({
  imageCollection: withSAVI.select(['NDVI','DWSI','EVI','SAVI']),
  region: geometry,
  reducer: ee.Reducer.mean(),
  scale: 20
})
// .setSeriesNames(['EVI', 'NDVI'])
        .setOptions({
          title: 'Average Crop Index Value by Date ',
          hAxis: {title: 'Date', titleTextStyle: {italic: false, bold: true}},
          vAxis: {
            title: 'Index value',
            titleTextStyle: {italic: false, bold: true},
             viewWindow: {min: 0, max: 1}
          },
          lineWidth: 2,
          colors: ['e37d05', '1d6b99','red','yellow'],
          curveType: 'function',
          width: 300,
         height: 300,
        });
 dropdownPanel1.widgets().set(2, ndviChart);
//   // Create an MODIS NDVI chart.
 // Create an NDVI chart.
  var DSWIChart = ui.Chart.image.series({
  imageCollection: withEVI.select(['B2','B3','B4','B8','B11']),
  region: point,
  reducer: ee.Reducer.mean(),
  scale: 20
}).setOptions({
      lineWidth: 1,
      title: 'DSWI Time Series',
      interpolateNulls: true,
      vAxis: {
        title: 'EVI',
        gridlines: {color: '#edf8fb'},
        // viewWindow: {min: 0, max: 1}
      },
      hAxis: {
        title: '', format: 'YYYY-MMM',
        gridlines: {color: '#edf8fb'},
      },
      lineWidth: 2,
          colors: ['e37d05', '1d6b99','red','yellow'],
          curveType: 'function',
      // chartArea: {backgroundColor: '#0037db'},
      width: 300,
      height: 300,
    })
  dropdownPanel1.widgets().set(3, DSWIChart);
//   var ndviChart = ui.Chart.image.series(collectionModNDVI, point, ee.Reducer.mean(), 250);
//   ndviChart.setOptions({
//     title: 'MODIS NDVI',
//     vAxis: {title: 'NDVI', maxValue: 9000},
//     hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
//   });
//   panel.widgets().set(3, ndviChart);
});
Map.style().set('cursor', 'crosshair');
// Add the panel to the ui.root.
ui.root.insert(0, panel);