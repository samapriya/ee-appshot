/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var mod16 = ee.ImageCollection("MODIS/006/MOD16A2"),
    chirps = ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY"),
    gsmap = ee.ImageCollection("JAXA/GPM_L3/GSMaP/v6/operational"),
    gpm = ee.ImageCollection("NASA/GPM_L3/IMERG_V06"),
    mod13 = ee.ImageCollection("MODIS/006/MOD13A1"),
    smap = ee.ImageCollection("NASA_USDA/HSL/SMAP10KM_soil_moisture");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// Agriculture water assessment (Experimental)
// Dhyey Bhatpuria dhyeybhatpuria@gmail.com
Map.setOptions('SATELLITE');
// User Inputs
var startDate = '2020-08-01';
var endDate = '2020-08-31';
var scale_spatial = 1000;
var chart_spatial_scale = 1000;
var w_veg = 0.4; // Vegetation criteria weight
var w_evapo = 0.2; // Evapotranspiration criteria weight
var w_soilm = 0.2; // Soil Moisture criteria weight
var w_rf = 0.2; // Precipitation criteria weight
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// external imports
var colorbrewer = require('users/gena/packages:colorbrewer');
var utils = require('users/gena/packages:utils');
var color_palette = colorbrewer.Palettes.Spectral[11].reverse();
var color_palette1 = colorbrewer.Palettes.RdYlGn[9]; //.reverse();
// Data ingestion and primary querying  ++++++++++++++++++++++++++++++++++
var countrieslayer = ee.FeatureCollection("USDOS/LSIB/2013");
var Admin_boundary_name = "TH";
var select_dist = countrieslayer.filterMetadata('cc', "equals", Admin_boundary_name);
var aoi_state = select_dist.geometry();
Map.centerObject(select_dist, 6);
var aoi = aoi_state;
var point_sampling = 5000;
// var P = chirps.select('precipitation');
var P = gsmap.select('hourlyPrecipRate');
// var P = gpm.select('HQprecipitation');
var ET = mod16.select("ET");
var NDVI = mod13.select("NDVI");
var soilmoisture = smap.select('ssm');
var ET = ET.map(function (image) {return image.unmask(0);});
var testET = ET.filterDate(startDate, endDate).sum().multiply(0.1).rename("evapotranspiration");
var testNDVI = NDVI.filterDate(startDate, endDate).mean().multiply(0.0001).rename("ndvi");
testNDVI = testNDVI.mask(testNDVI.gte(0));
var testSM = soilmoisture.filterDate(startDate, endDate).mean().rename("soilmoisture");
testSM = testSM.mask(testSM.gte(5));
var testPrcp = P.filterDate(startDate, endDate).sum().rename("precipitation");
var compiled_actual = (testNDVI.addBands(testSM).addBands(testET).addBands(testPrcp)).clip(aoi);
var compiled_actual_state = (testNDVI.addBands(testSM).addBands(testET).addBands(testPrcp)).clip(aoi_state);
Map.addLayer(compiled_actual.select("soilmoisture"), {min: 0.0, max: 28.0, palette: color_palette1}, "Soil Moisture-Actual",false);
Map.addLayer(compiled_actual.select("evapotranspiration"),{min:0.0, max:4.0, palette: color_palette1},"ET-Actual",false);
Map.addLayer(compiled_actual.select("ndvi"),{min:0.1, max:0.9, palette: color_palette1},"NDVI-Actual",false);
Map.addLayer(compiled_actual.select("precipitation"),{min: 50, max: 300, palette: color_palette1},"Precipitation_Sum-Actual",false);
// Calculate Correlation between two parameters  ++++++++++++++++++++++++++++++++++
var calc_correlation = function(imagestack, variable1, variable2){
  var image1 = imagestack.select(variable1);
  var image2 = imagestack.select(variable2);
  var correl_image = image1.addBands(image2);
  var correlation_outp = correl_image.reduceRegion({
    reducer: ee.Reducer.pearsonsCorrelation(), //ee.Reducer.spearmansCorrelation()
    geometry: aoi, 
    scale: scale_spatial
  });
  var add = ee.Dictionary({"a_parameter":variable1 + "_" + variable2});
  return correlation_outp.combine(add, false);
};
var chart_correlation = function(imagestack, variable1, variable2){
  var image1 = imagestack.select(variable1);
  var image2 = imagestack.select(variable2);
  var correl_image = image1.addBands(image2);
  var values = correl_image.sample(
    {region: aoi, scale: chart_spatial_scale, numPixels: point_sampling, geometries: true}
    ); 
  // create scatterplot  
  var chart = ui.Chart.feature.byFeature(values, variable1, [variable2])
    .setChartType('ScatterChart')
    .setOptions(
      {pointSize: 2, pointColor: 'blue', width: 200, height: 200, 
      titleX: variable1, titleY: variable2,
      trendlines: { 0: {color: 'red',lineWidth: 1.5, opacity: 0.8} 
      }, 'hAxis': {min: 0, max : 1}});
  return chart;
};
// Parameter names ::: "evapotranspiration","ndvi", "precipitation", "soilmoisture"
// var corr_1 = calc_correlation(compiled_actual, "ndvi", "evapotranspiration");
var corr_1_chart = chart_correlation(compiled_actual_state, "ndvi", "evapotranspiration");
// var corr_2 = calc_correlation(compiled_actual, "ndvi", "precipitation");
var corr_2_chart = chart_correlation(compiled_actual_state, "ndvi", "precipitation");
var corr_3_chart = chart_correlation(compiled_actual_state, "soilmoisture", "precipitation");
// var corr_4 = calc_correlation(compiled_actual, "ndvi", "soilmoisture");
var corr_4_chart = chart_correlation(compiled_actual_state, "ndvi", "soilmoisture");
// print(corr_4);
// print(corr_4_chart);
//// Classify data into classes based on mean and standard deviation ++++++++++++++++++++++++++++++++
var classifydata = function(image){
  var prop = image.bandNames();
  var variablename = prop.get(0);
  var mean = ee.Dictionary(image.reduceRegion(
    {geometry:aoi, reducer:ee.Reducer.mean(), scale:scale_spatial})).get(ee.String(variablename));
  var sd = ee.Dictionary(image.reduceRegion(
    {geometry:aoi, reducer:ee.Reducer.stdDev(), scale:scale_spatial})).get(ee.String(variablename));
  var classif_data = image.expression(  // Criteria scores
    '(b < 0) ? 0 \
          : (b <= meanminussd) ? 1 \
          : (b <= mean) ? 2.5 \
          : (b <= meanplussd) ? 7.5 \
          : (b > meanplussd) ? 10 \
          : 0',
  {'b': image.select(ee.String(variablename)),
    'meanplussd': ee.Number(mean).add(ee.Number(sd)),
    'meanminussd': ee.Number(mean).subtract(ee.Number(sd)),
    'mean': ee.Number(mean)
  });
  return classif_data.clip(aoi);
};
var colors = colorbrewer.Palettes.RdYlGn[5];
var output_ndvi = classifydata(testNDVI).rename("ndvi");
Map.addLayer(output_ndvi,{min: 1, max: 10, palette: colors},"NDVI-Classified");
var output_sm = classifydata(testSM).rename("soilmoisture");
Map.addLayer(output_sm,{min: 1, max: 10, palette: colors},"SoilMoisture-Classified");
var output_et = classifydata(testET).rename("evapotranspiration");
Map.addLayer(output_et,{min: 1, max: 10, palette: colors},"ET-Classified");
var output_prcp = classifydata(testPrcp).rename("precipitation");
Map.addLayer(output_prcp,{min: 1, max: 10, palette: colors},"Prcp-Classified");
var compiled = output_ndvi.addBands(output_sm).addBands(output_et).addBands(output_prcp);
// Weighted Overlay based on user defined weights ++++++++++++++++++++++++++++++++
var weighted_overlay_neo = function(img_inp, weights){
  // overall score = [criteria score1 X weight1] + [criteria score2 X weight2] + [criteria score3 X weight3] ...........
  var vegetation = (img_inp.select("ndvi")).multiply(ee.Number(weights.get(0)));
  var evapotranspiration = (img_inp.select("evapotranspiration")).multiply(ee.Number(weights.get(1)));
  var soil_moist = (img_inp.select("soilmoisture")).multiply(ee.Number(weights.get(2)));
  var rainf = (img_inp.select("precipitation")).multiply(ee.Number(weights.get(3)));
  return vegetation.add(evapotranspiration).add(soil_moist).add(rainf);
};
var criteria_weights = ee.List([w_veg,w_evapo, w_soilm, w_rf]);
var finalscore = weighted_overlay_neo(compiled,criteria_weights);
Map.addLayer(finalscore,{min:0, max:10, palette:colorbrewer.Palettes.Spectral[11].reverse()},"Agricultural Water Stress");
var panel = ui.Panel({style: {width: '400px'}});
var UI_panel_params = ui.Panel([
  ui.Label("Satellite based Multi-Indices Evaluation for Agriculture-Water Assessment",
  {fontSize: '20px', padding: '1px', color: 'black', fontWeight:'bold', margin: '10px 10px 0 15px'}),
  ]);
panel.add(UI_panel_params);
Map.style().set('cursor', 'crosshair');
ui.root.insert(0, panel);   // Add the panel to the ui.root.
var chartPanel = new ui.Panel();
panel.add(chartPanel);
var chartPanel1 = new ui.Panel();
panel.add(chartPanel1);
var chartPanel2 = new ui.Panel();
panel.add(chartPanel2);
var widgets = chartPanel.widgets();
widgets.reset([]);
var widgets2 = chartPanel2.widgets();
widgets2.reset([]);
var widgets1 = chartPanel1.widgets();
widgets1.reset([]);
widgets.add(corr_1_chart);
widgets1.add(corr_2_chart);
widgets2.add(corr_4_chart);