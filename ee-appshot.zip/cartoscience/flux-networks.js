var table = ee.FeatureCollection("users/cartoscience/Flux/cluster_groups_v2")
var ecoregions = ee.Image("users/cartoscience/Flux/ecoregions")
var map = ui.Map()
var rootPanel = ui.Panel({style: {width: '320px', border: '12px solid #CFD3D4'}})
ui.root.widgets().reset([rootPanel, map])
map.centerObject(table)
map.style().set('cursor', 'crosshair')
//print(table)
var igbpColors = [
  '05450a', '086a10', '54a708', '78d203', '009900', 'c6b044', 'dcd159',
  'dade48', 'fbff13', 'b6ff05', '27ff87', 'c24f44', 'a5a5a5', 'ff6d4c',
  '69fff8', 'f9ffa4', 'CFD3D4'
]
var igbpCats = [
  'Evergreen Needleleaf Forests',
  'Evergreen Broadleaf Forests',
  'Deciduous Needleleaf Forests',
  'Deciduous Broadleaf Forests',
  'Mixed Forests',
  'Closed Shrublands',
  'Open Shrublands',
  'Woody Savannas',
  'Savannas',
  'Grasslands',
  'Permanent Wetlands',
  'Croplands',
  'Urban and Built-Up Lands',
  'Cropland/Natural Veg. Mosaics',
  'Snow and Ice',
  'Barren Sparse Vegetation',
  'Water Bodies'
]
var ecoregionsColors = [
  'CFD3D4',	'6A91CA',	'9EABD6',	'91C5EA',	'3DB1BE',	'AFDEE5',	'5FBC55',	
  '45C0BD',	'BDDA8D',	'F7CD9C',	'F9DC6A',	'D2E5B7',	'DBD492',	'BDDA8D',	
  'EF8265',	'C674AF',	'B5D033',	'E3DAEB',	'D4E6F2',	'03869A',	'89CA52',	
  'BEE6C1',	'F2C960',	'FFE2CA',	'FDC9B4'
]
var ecoregionsCats = [
  'Great Lakes',	'Arctic Cordillera',	'Tundra',	'Taiga',	'Hudson Plains',	'Northern Forests',	
  'Northwestern Forested Mountains',	'Marine West Coast Forests',	'Eastern Temperate Forests',	
  'Great Plains',	'North American Deserts',	'Mediterranean California',	'Southern Semi-Arid Highlands',	
  'Temperate Sierras',	'Tropical Dry Forests',	'Tropical Humid Forests',	'Caribbean Islands',	
  'Northern Andes',	'Central Andes',	'Southern Andes',	'Amazonian-Orinocan Lowland',	
  'Eastern Highlands',	'Gran Chaco',	'Pampas',	'Monte-Patagonian',
]
var dataset = ee.ImageCollection('MODIS/061/MCD12Q1').mode()
var igbpLandCover = dataset.select('LC_Type1')
igbpLandCover = igbpLandCover.updateMask(igbpLandCover.neq(17)).updateMask(ecoregions)
var igbpLandCoverVis = {
  min: 1.0,
  max: 17.0,
  palette: igbpColors,
}
var ecoregionVis = {
  min: 0.0,
  max: 24.0,
  palette: ecoregionsColors,
}
map.addLayer(igbpLandCover, igbpLandCoverVis, 'IGBP Land Cover (MCD12Q1)', false)
map.addLayer(ecoregions, ecoregionVis, 'Ecoregions (Level 1)', false)
var igbp_labels = {
  BSV: ['Barren Sparse Vegetation'],
  CRO: ['Croplands'],
  CSH: ['Closed Shrublands'],
  CVM: ['Cropland/Natural Vegetation Mosaics'],
  DBF: ['Deciduous Broadleaf Forests'],
  DNF: ['Deciduous Needleleaf Forests'],
  EBF: ['Evergreen Broadleaf Forests'],
  ENF: ['Evergreen Needleleaf Forests'],
  GRA: ['Grasslands'],
  MF: ['Mixed Forests'],
  OSH: ['Open Shrublands'],
  SAV: ['Savannas'],
  SNO: ['Snow and Ice'],
  URB: ['Urban and Built-Up Lands'],
  WAT: ['Water Bodies'],
  WET: ['Permanent Wetlands'],
  WSA: ['Woody Savannas']
}
var cols = [
  {id: 'Group', type: 'string'},
  {id: 'Count', label: 'Count', type: 'number'},
  {id: 'Label', type: 'number', role: 'annotation'},
  {id: 'Style', type: 'string', role: 'style'}
]
var flux_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '25'}, {v: 9}, {v: 9}, {v: 'color: #E6194B'}]},
    {c: [ {v: '29'}, {v: 19}, {v: 19}, {v: 'color: #F58230'}]},
    {c: [ {v: '31'}, {v: 16}, {v: 16}, {v: 'color: #FFE119'}]},
    {c: [ {v: '33'}, {v: 6}, {v: 6}, {v: 'color: #D2F53C'}]},
    {c: [ {v: '41'}, {v: 8}, {v: 8}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '55'}, {v: 32}, {v: 32}, {v: 'color: #46F0F0'}]},
    {c: [ {v: '56'}, {v: 5}, {v: 5}, {v: 'color: #0082C8'}]},
    {c: [ {v: '59'}, {v: 70}, {v: 70}, {v: 'color: #911EB4'}]},
    {c: [ {v: '60'}, {v: 62}, {v: 62}, {v: 'color: #F032E6'}]},
    {c: [ {v: 'Other'}, {v: 86}, {v: 86}, {v: 'color: #A9A9A9'}]}
  ]
}
var h_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '3'}, {v: 17}, {v: 17}, {v: 'color: #E6194B'}]},
    {c: [ {v: '4'}, {v: 119}, {v: 119}, {v: 'color: #F58230'}]},
    {c: [ {v: '5'}, {v: 121}, {v: 121}, {v: 'color: #FFE119'}]},
    {c: [ {v: '8'}, {v: 10}, {v: 10}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '11'}, {v: 14}, {v: 14}, {v: 'color: #0082C8'}]},
    {c: [ {v: '14'}, {v: 18}, {v: 18}, {v: 'color: #911EB4'}]},
    {c: [ {v: 'Other'}, {v: 37}, {v: 37}, {v: 'color: #A9A9A9'}]}
  ]
}
var le_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '24'}, {v: 5}, {v: 5}, {v: 'color: #E6194B'}]},
    {c: [ {v: '35'}, {v: 114}, {v: 114}, {v: 'color: #D2F53C'}]},
    {c: [ {v: '36'}, {v: 110}, {v: 110}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '40'}, {v: 9}, {v: 9}, {v: 'color: #46F0F0'}]},
    {c: [ {v: '41'}, {v: 8}, {v: 8}, {v: 'color: #0082C8'}]},
    {c: [ {v: '44'}, {v: 34}, {v: 34}, {v: 'color: #911EB4'}]},
    {c: [ {v: 'Other'}, {v: 52}, {v: 52}, {v: 'color: #A9A9A9'}]}
  ]
}
var nee_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '9'}, {v: 26}, {v: 26}, {v: 'color: #E6194B'}]},
    {c: [ {v: '11'}, {v: 156}, {v: 156}, {v: 'color: #FFE119'}]},
    {c: [ {v: '13'}, {v: 28}, {v: 28}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '15'}, {v: 62}, {v: 62}, {v: 'color: #0082C8'}]},
    {c: [ {v: '26'}, {v: 5}, {v: 5}, {v: 'color: #911EB4'}]},
    {c: [ {v: 'Other'}, {v: 39}, {v: 39}, {v: 'color: #A9A9A9'}]}
  ]
}
var netrad_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '6'}, {v: 12}, {v: 12}, {v: 'color: #800000'}]},
    {c: [ {v: '11'}, {v: 7}, {v: 7}, {v: 'color: #E6194B'}]},
    {c: [ {v: '36'}, {v: 6}, {v: 6}, {v: 'color: #AA6E28'}]},
    {c: [ {v: '39'}, {v: 27}, {v: 27}, {v: 'color: #F58230'}]},
    {c: [ {v: '48'}, {v: 13}, {v: 13}, {v: 'color: #808000'}]},
    {c: [ {v: '52'}, {v: 16}, {v: 16}, {v: 'color: #FFE119'}]},
    {c: [ {v: '56'}, {v: 7}, {v: 7}, {v: 'color: #D2F53C'}]},
    {c: [ {v: '60'}, {v: 8}, {v: 8}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '62'}, {v: 24}, {v: 24}, {v: 'color: #46F0F0'}]},
    {c: [ {v: '64'}, {v: 10}, {v: 10}, {v: 'color: #0082C8'}]},
    {c: [ {v: '65'}, {v: 9}, {v: 9}, {v: 'color: #911EB4'}]},
    {c: [ {v: '66'}, {v: 35}, {v: 35}, {v: 'color: #DCBEFF'}]},
    {c: [ {v: '68'}, {v: 12}, {v: 12}, {v: 'color: #F032E6'}]},
    {c: [ {v: 'Other'}, {v: 104}, {v: 104}, {v: 'color: #A9A9A9'}]}
  ]
}
var swc_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '9'}, {v: 9}, {v: 9}, {v: 'color: #800000'}]},
    {c: [ {v: '14'}, {v: 5}, {v: 5}, {v: 'color: #E6194B'}]},
    {c: [ {v: '18'}, {v: 6}, {v: 6}, {v: 'color: #AA6E28'}]},
    {c: [ {v: '21'}, {v: 10}, {v: 10}, {v: 'color: #F58230'}]},
    {c: [ {v: '23'}, {v: 11}, {v: 11}, {v: 'color: #808000'}]},
    {c: [ {v: '24'}, {v: 7}, {v: 7}, {v: 'color: #FFE119'}]},
    {c: [ {v: '41'}, {v: 8}, {v: 8}, {v: 'color: #D2F53C'}]},
    {c: [ {v: '42'}, {v: 8}, {v: 8}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '44'}, {v: 7}, {v: 7}, {v: 'color: #46F0F0'}]},
    {c: [ {v: '45'}, {v: 6}, {v: 6}, {v: 'color: #0082C8'}]},
    {c: [ {v: '47'}, {v: 18}, {v: 18}, {v: 'color: #911EB4'}]},
    {c: [ {v: '48'}, {v: 20}, {v: 20}, {v: 'color: #DCBEFF'}]},
    {c: [ {v: '51'}, {v: 17}, {v: 17}, {v: 'color: #F032E6'}]},
    {c: [ {v: 'Other'}, {v: 91}, {v: 91}, {v: 'color: #A9A9A9'}]}
  ]
}
var ta_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '10'}, {v: 8}, {v: 8}, {v: 'color: #800000'}]},
    {c: [ {v: '17'}, {v: 10}, {v: 10}, {v: 'color: #E6194B'}]},
    {c: [ {v: '20'}, {v: 6}, {v: 6}, {v: 'color: #FABED4'}]},
    {c: [ {v: '21'}, {v: 11}, {v: 11}, {v: 'color: #AA6E28'}]},
    {c: [ {v: '33'}, {v: 13}, {v: 13}, {v: 'color: #F58230'}]},
    {c: [ {v: '37'}, {v: 5}, {v: 5}, {v: 'color: #808000'}]},
    {c: [ {v: '39'}, {v: 16}, {v: 16}, {v: 'color: #FFE119'}]},
    {c: [ {v: '40'}, {v: 12}, {v: 12}, {v: 'color: #D2F53C'}]},
    {c: [ {v: '42'}, {v: 13}, {v: 13}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '49'}, {v: 6}, {v: 6}, {v: 'color: #008080'}]},
    {c: [ {v: '56'}, {v: 20}, {v: 20}, {v: 'color: #46F0F0'}]},
    {c: [ {v: '61'}, {v: 13}, {v: 13}, {v: 'color: #000080'}]},
    {c: [ {v: '63'}, {v: 7}, {v: 7}, {v: 'color: #0082C8'}]},
    {c: [ {v: '66'}, {v: 6}, {v: 6}, {v: 'color: #911EB4'}]},
    {c: [ {v: '68'}, {v: 35}, {v: 35}, {v: 'color: #DCBEFF'}]},
    {c: [ {v: '72'}, {v: 38}, {v: 38}, {v: 'color: #F032E6'}]},
    {c: [ {v: 'Other'}, {v: 109}, {v: 109}, {v: 'color: #A9A9A9'}]}
  ]
}
var ustar_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '8'}, {v: 174}, {v: 174}, {v: 'color: #E6194B'}]},
    {c: [ {v: '10'}, {v: 48}, {v: 48}, {v: 'color: #F58230'}]},
    {c: [ {v: '11'}, {v: 31}, {v: 31}, {v: 'color: #FFE119'}]},
    {c: [ {v: '17'}, {v: 6}, {v: 6}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '21'}, {v: 16}, {v: 16}, {v: 'color: #0082C8'}]},
    {c: [ {v: '26'}, {v: 32}, {v: 32}, {v: 'color: #911EB4'}]},
    {c: [ {v: 'Other'}, {v: 31}, {v: 31}, {v: 'color: #A9A9A9'}]}
  ]
}
var vpd_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '7'}, {v: 6}, {v: 6}, {v: 'color: #E6194B'}]},
    {c: [ {v: '19'}, {v: 5}, {v: 5}, {v: 'color: #F58230'}]},
    {c: [ {v: '22'}, {v: 144}, {v: 144}, {v: 'color: #FFE119'}]},
    {c: [ {v: '23'}, {v: 73}, {v: 73}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '24'}, {v: 9}, {v: 9}, {v: 'color: #0082C8'}]},
    {c: [ {v: '25'}, {v: 22}, {v: 22}, {v: 'color: #911EB4'}]},
    {c: [ {v: '27'}, {v: 17}, {v: 17}, {v: 'color: #F032E6'}]},
    {c: [ {v: 'Other'}, {v: 50}, {v: 50}, {v: 'color: #A9A9A9'}]}
  ]
}
var reco_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '6'}, {v: 11}, {v: 11}, {v: 'color: #E6194B'}]},
    {c: [ {v: '8'}, {v: 6}, {v: 6}, {v: 'color: #F58230'}]},
    {c: [ {v: '11'}, {v: 13}, {v: 13}, {v: 'color: #FFE119'}]},
    {c: [ {v: '15'}, {v: 5}, {v: 5}, {v: 'color: #D2F53C'}]},
    {c: [ {v: '16'}, {v: 26}, {v: 26}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '46'}, {v: 27}, {v: 27}, {v: 'color: #46F0F0'}]},
    {c: [ {v: '47'}, {v: 26}, {v: 26}, {v: 'color: #0082C8'}]},
    {c: [ {v: '48'}, {v: 18}, {v: 18}, {v: 'color: #911EB4'}]},
    {c: [ {v: '99'}, {v: 53}, {v: 53}, {v: 'color: #A9A9A9'}]}
  ]
}
var gpp_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '32'}, {v: 7}, {v: 7}, {v: 'color: #E6194B'}]},
    {c: [ {v: '47'}, {v: 6}, {v: 6}, {v: 'color: #FFE119'}]},
    {c: [ {v: '50'}, {v: 53}, {v: 53}, {v: 'color: #3CB44B'}]},
    {c: [ {v: '55'}, {v: 10}, {v: 10}, {v: 'color: #0082C8'}]},
    {c: [ {v: '58'}, {v: 22}, {v: 22}, {v: 'color: #911EB4'}]},
    {c: [ {v: '99'}, {v: 87}, {v: 87}, {v: 'color: #A9A9A9'}]}
  ]
}
var hup_chart = {
  cols: cols,
  rows: [
    {c: [ {v: '0.15–0.18'}, {v: 100}, {v: 100}, {v: 'color: #F1FA22'}]},
    {c: [ {v: '0.18–0.20'}, {v: 78}, {v: 78}, {v: 'color: #F99541'}]},
    {c: [ {v: '0.20–0.24'}, {v: 96}, {v: 96}, {v: 'color: #CC4779'}]},
    {c: [ {v: '0.24–0.29'}, {v: 29}, {v: 29}, {v: 'color: #7E03A8'}]},
    {c: [ {v: '>0.29'}, {v: 10}, {v: 10}, {v: 'color: #0D0887'}]}
  ]
}
var chartOptions = {
  hAxis: {viewWindow: {min:0, max: 175}, title: 'Count'},
  vAxis: {title: 'Group'},
  legend: {position: 'none'},
  annotations: {
    alwaysOutside: true
  },
}
var basemap = {
  'Basemap': [
    {
      featureType: 'water',
      stylers: [
        { color: '#CFD3D4' }
      ]
    },
    {
      featureType: 'water',
      elementType: 'labels',
      stylers: [
        { color: '#7a7a7a' }
      ]
    },
    {
      featureType: 'landscape',
      stylers: [
        { color: '#F3F3F3' }
      ]
    },
    {
      featureType: 'administrative',
      elementType: 'geometry',
      stylers: [
        { visibility: 'on' },
        { color: '#343434'}
      ]
    },
    {
      featureType: 'administrative',
      elementType: 'labels',
      stylers: [
        { visibility: 'off' }
      ]
    },
    {
      featureType: 'administrative',
      elementType: 'labels.text.fill',
      stylers: [
        { visibility: 'off' },
        { color: '#0021A5'}
      ]
    },
    {
      featureType: 'administrative',
      elementType: 'labels.text.stroke',
      stylers: [
        { visibility: 'off' },
        { color: '#ffffff'},
        { weight: 1.5 }
      ]
    },
    {
      featureType: 'road',
      stylers: [
        { visibility: 'off' }
      ]
    },
    {
      featureType: 'poi',
      stylers: [
        { visibility: 'off' }
      ]
    },
    {
      featureType: 'transit',
      stylers: [
        { visibility: 'off' }
      ]
    }
  ]
}
map.setOptions('Basemap', basemap)
function addStyle(pt) {
  return pt.set('styleProperty', ee.Dictionary({'color': '1A1A1A', 'pointSize': 1}))
}
var styled = ee.FeatureCollection(table).map(addStyle)
map.layers().set(2, ui.Map.Layer(styled.style({styleProperty: 'styleProperty'}), {}, 'All sites', false))
map.layers().set(3, ui.Map.Layer(null, {}, 'Placeholder', false))
var variables = {
  'FLUX': [flux_chart,'NEE, LE, H, and USTAR'],
  'H': [h_chart, 'Sensible Heat Flux'],
  'LE': [le_chart, 'Latent Heat Flux'],
  'NEE': [nee_chart, 'Net Ecosystem Exchange'],
  'NETRAD': [netrad_chart, 'Net Radiation'],
  'SWC': [swc_chart, 'Soil Water Content'],
  'TA': [ta_chart, 'Air Temperature'],
  'USTAR': [ustar_chart, 'Friction Velocity'],
  'VPD': [vpd_chart, 'Vapor Pressure Deficit'],
  'RECO': [reco_chart, 'Ecosystem Respiration'],
  'GPP': [gpp_chart, 'Gross Primary Production'],
  'HUP': [hup_chart, 'Harmonic Uniqueness Parameter']
}
var title = ui.Label({
  value: 'Network of Networks',
  style: {margin: '5px 0 3px 5px', fontWeight: 'bold', fontSize: '18px'}
})
var label = ui.Label({
  value: 'Select a variable to plot',
  style: {margin: '0 0 0 5px'}
})
var connector = ui.Label({
  value: ' • ',
  style: {margin: '-1px 3px 0 3px'}
})
var cat99 = ui.Label({
  value: 'Other: Site is in group with <5 elements.',
  style: {margin: '-10px 0 5px 5px', fontSize: '11px'}
})
var igbp_disclaimer = ui.Label({
  value: 'IGBP classifications based on AmeriFlux database; map layer is for visualization only.',
  style: {margin: '0 10px 5px 5px', fontSize: '11px'}
})
var line = ui.Label({
  value: '___________________________________________________',
  style: {margin: '0 0 0 5px', fontSize: '10px'}
})
var line2 = ui.Label({
  value: '___________________________________________________',
  style: {margin: '-7px 0 5px 5px', fontSize: '10px'}
})
var ameriflux = ui.Label({
  value: 'AmeriFlux Database',
  style: {margin: '5px 5px 5px 5px', fontSize: '12px'},
  targetUrl: 'https://ameriflux.lbl.gov/'
})
var acknowledgments = ui.Label('We acknowledge the listed AmeriFlux sites for sharing their data records. AmeriFlux data were made available through the data portal maintained by the AmeriFlux Management Project, supported by the U.S. Department of Energy’s Office of Science.',
  {margin: '-2px 5px 10px 5px', fontSize: '12px'}
)
var logo = ui.Thumbnail({image:logo,params:{bands:['b1','b2','b3'],min:0,max:255},style:{width:'133px',height:'123px'}})
var igbp_link = ui.Label({
  value: 'IGBP Info',
  style: {margin: '0 0 0 0', fontSize: '11px'},
  targetUrl: 'http://www.igbp.net/'
})
var eco_link = ui.Label({
  value: 'Ecoregion Info',
  style: {margin: '0 0 0 0', fontSize: '11px'},
  targetUrl: 'http://ecologicalregions.info/htm/ecoregions.htm'
})
var joinLinks = ui.Panel({
  widgets: [igbp_link, connector, eco_link],
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {margin: '-2px 0 0 5px'}
})
var disclaim = ui.Label({
  value: 'This application is intended to accompany the manuscript by Reed et al. (in prep) cited below.',
  style: {margin: '5px 20px 5px 5px', fontWeight: '450', fontSize: '11px', color: 'E6194B'}
})
var source = ui.Label({
  value: 'Network of Networks: Time-Series Clustering of AmeriFlux Sites. 2024. Reed, Chu, Peter, Chen, et al. [in prep]. Journal TBD.',
  style: {margin: '0 15px 5px 5px', fontSize: '12px'}
})
var legend = ui.Panel({widgets: [title, label, ui.Label(), ui.Label(), ui.Label(), ui.Label(), cat99, igbp_disclaimer, joinLinks, line, disclaim, source, line2, ameriflux, acknowledgments], 
  style: {
    position: 'bottom-left', 
    width: '260px',
    margin: '10px 10px 10px 10px'
  }
})
rootPanel.add(legend)
var selector = addLayerSelector(map, legend)
function addLayerSelector(mapToChange, legendPanel) {
  function updateMap(selection) {
    function addStyle(pt) {
      var color = pt.get(selection+'_C')
      var size = ee.Algorithms.If(ee.Number(pt.get(selection+'_G')).eq(999),0,3)
      return pt.set('styleProperty', ee.Dictionary({'color': color, 'pointSize': size}))
    }
    var styled = ee.FeatureCollection(table).map(addStyle)
    mapToChange.layers().set(4, ui.Map.Layer(styled.style({styleProperty: 'styleProperty'}), {}, selection+' Groupings'))
    var chart = ui.Chart(variables[selection][0],'BarChart', chartOptions)
    var varLabel = ui.Label({
      value: selection+': '+variables[selection][1],
      style: {margin: '5px 0 0 5px', fontSize: '11px'}
    })
    legendPanel.widgets().set(3,varLabel)
    legendPanel.widgets().set(5,chart)
    legendPanel.widgets().set(4, ui.Panel({
      widgets: [
        ui.Label('Click a point to get additional information', {margin: '10px 0 -2px 5px', fontSize: '12px', color: '0082C8', fontWeight: 'bold'}),
        ui.Label('...', {margin: '5px 0 0 5px', fontSize: '12px', color: 'white'})
      ]
    }))
    map.layers().set(3, ui.Map.Layer(null, {}, '[Placeholder Layer]', false))
  }
  var select = ui.Select({items: Object.keys(variables), onChange: updateMap, style: {margin: '5px 0 0 5px'}})
  select.setValue(Object.keys(variables)[0], true)
  legendPanel.widgets().set(2,select)
}
function getProps(loc) {
  map.layers().set(3, ui.Map.Layer(null, {}, 'Placeholder', false))
  loc = ee.Dictionary(loc)
  var point = ee.Geometry.Point(loc.getNumber('lon'), loc.getNumber('lat'));
  var selected = table.filterBounds(
    point.buffer(10000)).map(function(ft) {
      return ft.set('system:click_distance', point.distance(ft.geometry()));
  }).sort('system:click_distance').first()
  var size = ee.FeatureCollection(ee.Feature(selected)).size()
  var props = selected.toDictionary()
  var sample_style = ee.Feature(selected).set('styleProperty', ee.Dictionary({'color': 'black', 'pointSize': 5}))
  var infoSet
  if (size.getInfo() === 1) {
    props.evaluate(function(props) {
      var getVar = rootPanel.widgets().get(0).widgets().get(2).get('value')
      var lon = props['LON'].toFixed(2)
      var lat = props['LAT'].toFixed(2)
      var id = props['SITE_ID']
      var igbp = props['IGBP']
      var econame = props['eco_L1_nam']
      var group = 'Group: ' + props[getVar + '_O']
      if (getVar == 'HUP') {
        group = 'Value: ' + props[getVar].toFixed(4)
      }
      var latLon = 'Lon: ' + lon + ', Lat: ' + lat
      var textString = 'IGBP: ' + igbp_labels[igbp]
      infoSet = ui.Panel({
        widgets: [
          ui.Label('Site: '+ id, {margin: '10px 0 -2px 5px', fontSize: '13px', fontWeight: 'bold', color: '0082C8'}),
          ui.Label(latLon, {margin: '5px 0 -2px 5px', fontSize: '12px', color: '0082C8'}),
          ui.Label(getVar + ' ' + group, {margin: '5px 0 -2px 5px', fontSize: '12px', color: '0082C8'}),
          ui.Label(textString, {margin: '5px 0 -2px 5px', fontSize: '12px', color: '0082C8'}),
          ui.Label('Ecoregion: ' + econame, {margin: '5px 0 -2px 5px', fontSize: '12px', color: '0082C8'}),
          ui.Label({
            value: 'ameriflux.lbl.gov/sites/siteinfo/'+id, 
            style: {margin: '5px 0 0 5px', fontSize: '12px'},
            targetUrl: 'https://ameriflux.lbl.gov/sites/siteinfo/'+id
          })
        ]
      })
      map.layers().set(3, ui.Map.Layer(ee.FeatureCollection(sample_style).style({styleProperty: 'styleProperty'}), {}, 'Site: '+id))
      //map.centerObject(selected,8)
      legend.widgets().set(4, infoSet)
    })
  } else {
      infoSet = ui.Panel({
        widgets: [
          ui.Label('No point found within 10km', {margin: '10px 0 -2px 5px', fontSize: '12px', color: 'E6194B', fontWeight: 'bold'}),
          ui.Label('...', {margin: '5px 0 0 5px', fontSize: '12px', color: 'white'})
        ]
      })
      legend.widgets().set(4, infoSet)
      map.layers().set(3, ui.Map.Layer(null, {}, 'Placeholder', false))
  }
}
map.onClick(getProps)
var legend2 = ui.Panel({
  style: {
    position: 'bottom-right',
    border: '1px solid #C9C9C9',
    margin: '0 0 0 0',
    width: '209px'
  }
})
var legendTitle2 = ui.Label({
  value: 'IGBP',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 5px 0',
    padding: '0'
  }
})
var makeRow = function(color, name) {
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      padding: '6px',
      margin: '0 0 0 0'
    }
  })
  var description = ui.Label({
    value: name,
    style: {
      margin: '-1px 0 4px 4px',
      fontSize: '11px'
    }
  })
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  })
}
legend2.add(legendTitle2)
for (var i = 0; i < 17; i++) {
  legend2.add(makeRow(igbpColors[i], igbpCats[i]));
}
var legend3 = ui.Panel({
  style: {
    position: 'bottom-right',
    border: '1px solid #C9C9C9',
    margin: '0 0 0 0',
    width: '210px'
  }
})
var legendTitle3 = ui.Label({
  value: 'Ecoregion',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 5px 0',
    padding: '0'
  }
})
var makeRow2 = function(color, name) {
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      padding: '6px',
      margin: '0 0 0 0'
    }
  })
  var description = ui.Label({
    value: name,
    style: {
      margin: '-1px 0 4px 4px',
      fontSize: '11px'
    }
  })
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  })
}
legend3.add(legendTitle3)
for (var i = 0; i < 24; i++) {
  legend3.add(makeRow2(ecoregionsColors[i], ecoregionsCats[i]));
}
var button = ui.Button('Toggle IGBP Layer/Legend', null, null, {margin: '0 0 5px 0', padding: '0', position: 'bottom-right', width: '200px'})
var ecoButton = ui.Button('Toggle Ecoregion Layer/Legend', null, null, {margin: '0 0 0 0', padding: '0', position: 'bottom-right', width: '200px'})
var buttonsPanel = ui.Panel({widgets:[button,ecoButton], style: {padding: '5px', position: 'bottom-right'}})
map.add(buttonsPanel)
function changeLayerAddLegend() {
  if (map.widgets().length() == 1 || map.widgets().get(1).get('style').get('width') == '210px') {
    map.remove(legend3)
    map.add(legend2)
    map.layers().get(0).set('shown', true)
    map.layers().get(1).set('shown', false)
  } else {
    map.remove(legend2)
    map.layers().get(0).set('shown', false)
    map.layers().get(1).set('shown', false)
  }
}
button.onClick(changeLayerAddLegend)
function changeLayerAddLegendEco() {
  if (map.widgets().length() == 1 || map.widgets().get(1).get('style').get('width') == '209px') {
    map.remove(legend2)
    map.add(legend3)
    map.layers().get(0).set('shown', false)
    map.layers().get(1).set('shown', true)
  } else {
    map.remove(legend3)
    map.layers().get(0).set('shown', false)
    map.layers().get(1).set('shown', false)
  }
}
ecoButton.onClick(changeLayerAddLegendEco)