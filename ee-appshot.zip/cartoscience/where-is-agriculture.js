var v006 = ui.import && ui.import("v006", "imageCollection", {
      "id": "MODIS/006/MCD12Q1"
    }) || ee.ImageCollection("MODIS/006/MCD12Q1"),
    gc = ui.import && ui.import("gc", "image", {
      "id": "ESA/GLOBCOVER_L4_200901_200912_V2_3"
    }) || ee.Image("ESA/GLOBCOVER_L4_200901_200912_V2_3"),
    gfsad = ui.import && ui.import("gfsad", "image", {
      "id": "USGS/GFSAD1000_V1"
    }) || ee.Image("USGS/GFSAD1000_V1");
// Where is global agriculture? How well do we know? Here's a comparison of GlobCover and MODIS land cover using Google #EarthEngine. 
var gfsad2 = gfsad.gt(0)
var v0062 = v006.mode().select('LC_Type1').eq([12,14]);
var v0063 = v0062.select('constant').add(v0062.select('constant_1')).gt(0).rename('v006_ag');
var gc2 = gc.select('landcover').lte(30).rename('gc_ag');//.reproject(v051.first().projection());
var added = gc2.add(gfsad2.remap([0,1],[0,3])).add(v0063.remap([0,1],[0,5]));
var cats = added.remap([0,1,3,4,5,6,8,9],[0,1,2,5,3,6,4,7]).rename('agriculture');
                                        //0 - none
                                        //1-1 - gc
                                        //3-2 - gfsad
                                        //4-5 - gfsad + gc
                                        //5-3 - v006
                                        //6-6 - v006 + gc
                                        //8-4 - gfsad + v006
                                        //9-7 - gfsad + v006 + gc
var catsMask = cats.updateMask(cats.neq(0));
var colors = ['01545A','017351','03C383','AAD962','A12A5E','710162','ED0345'];
var categories = ['GlobCover 2009', 'GFSAD', 'MCD12Q1 V006 (mode)', 
                  'GFSAD & V006',
                  'GFSAD & GlobCover', 'MCD12Q1 V006 & GlobCover', 
                  'GFSAD & V006 & GlobCover'];
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    backgroundColor: '202020',
    padding: '8px 15px',
    border: '5px solid #333333'
  }
});
var legendTitle = ui.Label({
  value: 'Where is global agriculture?',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '3px 0 -1px 13px',
    backgroundColor: '202020',
    color: 'dbdbdb',
    padding: '0'
  }
});
var line = ui.Label({
  value: '_________________________________________________________',
  style: {
    fontSize: '10px',
    margin: '0 0 10px 1px',
    backgroundColor: '202020',
    color: 'dbdbdb',
    padding: '0'
  }
});
legend.add(legendTitle);
legend.add(line);
var makeRow = function(color, name) {
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      padding: '8px',
      margin: '0 0 4px 0'
    }
  });
  var description = ui.Label({
    value: name,
    style: {
      margin: '0 0 4px 6px',
      backgroundColor: '202020',
      color: 'dbdbdb',
    }
  });
  return ui.Panel({
    widgets: [colorBox, description],
    style: {
      backgroundColor: '202020'
    },
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
for (var i = 0; i < categories.length; i++) {
  legend.add(makeRow(colors[i], categories[i]));
}
var site = ui.Label('cartoscience.com', {fontSize: '12px', color: 'white', stretch: 'horizontal', textAlign: 'center', margin: '0 0 0 0', backgroundColor: '202020'}, 'http://cartoscience.com');
legend.add(site);
Map.add(legend);
Map.setOptions('HYBRID');
Map.setCenter(33.77,-13.96,8);
Map.addLayer(ee.Image(0),{palette:'black', opacity: 0.87}, 'dark basemap');
Map.addLayer(catsMask, {palette: colors, min: 1, max: 7}, 'agriculture');