var pass = +prompt('Nhập mật khẩu gồm 13 chữ số: ',5738426649530)
require('users/thao226355/share:Ứng dụng xử lý ảnh Sentinel2_DEM').SD(pass);