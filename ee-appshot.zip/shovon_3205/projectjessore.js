var Landsat = ui.import && ui.import("Landsat", "imageCollection", {
      "id": "LANDSAT/LC08/C01/T1_RT"
    }) || ee.ImageCollection("LANDSAT/LC08/C01/T1_RT"),
    Home = ui.import && ui.import("Home", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            89.17974807024757,
            23.160054343396734
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#43d8ff",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #43d8ff */ee.Geometry.Point([89.17974807024757, 23.160054343396734]),
    table = ui.import && ui.import("table", "table", {
      "id": "users/shovon_3205/Jessore_New01"
    }) || ee.FeatureCollection("users/shovon_3205/Jessore_New01");
Map.centerObject(table);
//----------Task of Safa----------
// Load the image from the archive.
// Import the Landsat 8 TOA image collection.
var Home_Landsat_2021 = ee.Image(Landsat
// Filter the image. 
// Filter by date and location.
// Get the least cloudy image in 2021.
    .filterDate ('2021-01-01','2021-07-01')
    .filterBounds(Home)
// Sort by increasing cloudiness.
    .sort('CLOUD_COVER')
    .first()
    .clip(table)
    );
// Print the console.
print('Home_Landsat_2021', Home_Landsat_2021);
//----------End of Safa's Task----------
//----------Task of Tasnia----------
// Load the image.
// Load the image from the archive.
// Import the Landsat 8 TOA image collection.
var Home_Landsat_2015 = ee.Image(Landsat
// Filter the image. 
// Filter by date and location.
// Get the least cloudy image in 2015.
    .filterDate ('2015-01-01','2015-07-01')
    .filterBounds(Home)
// Sort by increasing cloudiness.
    .sort('CLOUD_COVER')
    .first()
    .clip(table)
    );
// Print the functions. 
print('Home_Landsat_2015', Home_Landsat_2015);
//----------End of Tasnia's Task----------
//----------Task of Shovon----------
// Define the visualization parameters.
var trueColor={
    bands:['B4','B3','B2'],
    min: 7587,
    max: 10725,
    gamma: [0.95, 1.1, 1]
};
// Display the image
Map.addLayer(Home_Landsat_2021, trueColor, 'Study Area 2021');
// Load two Landsat 8 images, 6 years apart.
// Compute the Normalized Difference Vegetation Index (NDVI).
var B4_Red_2021 = Home_Landsat_2021.select('B4');
var B5_NIR_2021 = Home_Landsat_2021.select('B5');
// Display the result.
var NDVI_2021= Home_Landsat_2021.expression(
// NDVI calculation.
  '(B5-B4)/(B5+B4)',{
    'B5': B5_NIR_2021,
    'B4': B4_Red_2021
  });
// Compute the Normalized Difference Vegetation Index (NDVI).
var B4_Red_2015 = Home_Landsat_2015.select('B4');
var B5_NIR_2015 = Home_Landsat_2015.select('B5');
// Display the result.
var NDVI_2015= Home_Landsat_2015.expression(
// NDVI calculation.
  '(B5-B4)/(B5+B4)',{
    'B5': B5_NIR_2015,
    'B4': B4_Red_2015
  });
//----------End of Shovon's Task----------
//----------Task of Fariha----------
// Color palettes.
var custom_palette= ['FFFFFF','CE7E45','DF923D','F1B555','FCD163','99B718','74A901',
                     '66A000','529400','3E8601','207401','056201','004C00','023B01',
                     '012E01','011D01','011301'];
// Display the image
Map.addLayer (NDVI_2021, {min:0.0, max:1.0, palette:custom_palette}, 'NDVI_2021');
// Display the image
Map.addLayer (NDVI_2015, {min:0.0, max:1.0, palette:custom_palette}, 'NDVI_2015');
// Load a landsat image and select three bands.
var landsat8=ee.Image('LANDSAT/LC08/C01/T1_RT/LC08_138044_20210204')
    .select(['B4','B3','B2']);
// Export the image, specifying scale and region.    
var study_area = Home_Landsat_2021;
Export.image.toDrive({
  image: landsat8,
  description: 'Study_area',
  scale: 30,
  region: study_area
});
//----------End of Fariha's Task----------
//----------Task of Shovon----------
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette =['B56727', '62BD69', 'FFDB58', 'FFFFFF'];
// name of the legend
var names = ['Road','Vegetation','Land','Water Body'];
// Add color and and names
for (var i = 0; i < 4; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)  
Map.add(legend);  
//----------End of Shovon's Task----------