var imageCollection = ee.ImageCollection("users/zandersamuel/Apps/rePhotoSA"),
    thumb = ee.Image("users/zandersamuel/Apps/rePhotoSA-Logo_RGB_Web_2"),
    feats = ee.FeatureCollection("ft:1juhwbbQeYS8gL-E0bzMUYTwl-_u_JfGvPgzg9NUA"),
    thumb2 = ee.Image("users/zandersamuel/Apps/ZSV_logo");
var count = feats.reduceColumns(ee.Reducer.count(),['name']).get('count');
var featList = feats.toList(8)  
// Build a dictionary of computable properties, so that we can fetch all the properties
// in a single evaluate() call.
function featureProperties(f) {
  var feat = ee.Feature(f);
  return ee.Dictionary({geometry: feat.geometry(), name: feat.get('name'), textHist: feat.get('textHist'), textRept: feat.get('textRept')})
}
featList.map(featureProperties).evaluate(function(listOfProps) {
  var geoms = listOfProps.map(function(props) {
    return ui.Map.GeometryLayer([props['geometry']], [props['name']]);
  })
  startUI(geoms);
})
var startUI = function(geoms, newFeats){
  function resetGeoms() {
    d.layers().map(function(g){
      g.set('color','#000000')
    })
  } 
  print(geoms)
  print(newFeats)
  var histTexts = feats.reduceColumns(ee.Reducer.toList(), ['textHist']);
  var reptTexts = feats.reduceColumns(ee.Reducer.toList(), ['textRept']);
  print(imageCollection, 'image collection')
  print(feats)
  ui.root.clear();
  var mapSmall = ui.Map({style:{stretch:'vertical', height:'400px', margin:'5px'}});
  mapSmall.setCenter(27.6, -28.97, 5);
  var panel = ui.Panel({style: {width: '425px'}});
  var logo = ui.Thumbnail(thumb,{dimensions: '600',min:0, max:255},null,{height:'60px',width:'150px'});
  var logo2 = ui.Thumbnail(thumb2,{dimensions: '600',min:0, max:255},null,{height:'60px',width:'150px'});
  ui.root.add(panel)
  var d = ui.Map.DrawingTools({layers:geoms, selected:geoms[5]});
  //print(d.getSelected())
  //d.setLinked(true)
  d.setShown(false);
  mapSmall.add(d)
  d.onSelect(repeatSlider)
  var style = {'Deep': [{
        featureType: 'all',
        stylers: [{ color: '#ffffff'}]
    }]
  };
  var leftMap = ui.Map({lon: 0, lat: 0, zoom: 3}).setOptions(null, style,[]);
  leftMap.setLocked(true)
  //print(leftMap.widgets(), 'map')
  var rightMap = ui.Map({lon: 200, lat: 0, zoom: 3}).setOptions(null, style,[]);
  rightMap.setLocked(true)  
  // Link them together.
  var linker = new ui.Map.Linker([leftMap, rightMap]);
  // Create a split panel with the two maps.
  var splitPanel = ui.SplitPanel({
    firstPanel: leftMap,
    secondPanel: rightMap,
    orientation: 'horizontal',
    wipe: true
  });
  ui.root.widgets().set(1, splitPanel);
  var leftPanel = ui.Panel({style: {shown: true, position: 'bottom-left'}});
  var rightPanel = ui.Panel({style: {shown: true, position: 'bottom-right'}});
  function repeatSlider(g, l, t)  {
    resetGeoms()
    zoomBox.style().set('shown', true);
    zoomBox.centerObject(g, 9);
    zoomBox.layers().reset([ui.Map.Layer(g,{color:'#ff0000'})])
    var id = l.get('name');
    //print(id, 'id')
    var ft = feats.filterMetadata('name','equals',id).first();
    //print(ft, 'ft')
    l.set('color','#ff0000')
    leftMap.setCenter({lon: 0, lat: 0, zoom: 6});
    rightMap.setCenter({lon: 0, lat: 0, zoom: 6})
    var id1 = ee.String(id + 'A')
    var id2 = ee.String(id + 'B')
    var images = imageCollection.filter(ee.Filter.or(ee.Filter.eq('system:index', id1), ee.Filter.eq('system:index',id2)))
    var leftImage = ui.Thumbnail(ee.Image(images.first()),
        {dimensions: '800',min:0, max:255},null,{height:'600px',width:'950px'});
    var rightImage = ui.Thumbnail(ee.Image(images.filterMetadata('system:index','contains','B').first()),
        {dimensions: '800',min:0, max:255},null,{height:'600px',width:'950px'});
    leftMap.widgets().set(0,leftImage)
    rightMap.widgets().set(0,rightImage);
    var rightText = ft.get('textRept')
    rightText.evaluate(function(value){
      rightPanel.widgets().reset([ui.Label(value,{fontSize: '18px', fontWeight: 'bold'})])
    })
    var leftText = ft.get('textHist')
    leftText.evaluate(function(value){
      leftPanel.widgets().reset([ui.Label(value,{fontSize: '18px', fontWeight: 'bold'})])
    })
    leftMap.widgets().set(1,leftPanel);
    rightMap.widgets().set(1,rightPanel);
  } 
  var next = ui.Button('NEXT', nextGeom);
  function nextGeom() {
    var current = d.layers().indexOf(d.getSelected())
    print(current)
    if (current == 7){
      var nextIndex = 0;
    } else {
      nextIndex =  current + 1
    }
    var nextLayer = d.layers().get(nextIndex);
    d.setSelected(nextLayer)
    repeatSlider(nextLayer.geometries().get(0),nextLayer,null)
  }
  panel.widgets().set(0,ui.Label({
      value:'Woody plant encroachment inspector',
      style: {fontSize: '20px', fontWeight: 'bold'}
    }));
  panel.widgets().set(1,ui.Label('Click a point in the map below or click the NEXT button...'));
  panel.widgets().set(2,mapSmall);
  panel.widgets().set(3,ui.Label('These images are curated by the repeat photography project of southern African landscapes. Find out more here: http://rephotosa.adu.org.za/'));
  panel.widgets().set(4,logo);
  panel.widgets().set(5,ui.Label('This app was made by ZSV consulting. Contact them for more information: http://zsv.co.za'));
  panel.widgets().set(6,logo2);
  mapSmall.widgets().add(next)
  // Create a map to be used as the zoom box.
  var zoomBox = ui.Map({style: {stretch: 'both',shown: false,position: 'bottom-right'}})
      .setControlVisibility(false);
  //mapSmall.add(zoomBox)
  nextGeom()
}