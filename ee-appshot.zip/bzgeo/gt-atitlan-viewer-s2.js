////////////////////////////////////////////////////////////////////////////////////////////////
// Exercise: Generate simple User Interface (UI) to display imagery
// Example study area: Lake Atitlan, Guatemala
// based on code from Sulong Zhou and Noel Gorelick
// modified by Kel Markert, SERVIR SCO / UAH
// Last modified: 9 Jan. 2019
////////////////////////////////////////////////////////////////////////////////////////////////
// Specify geographic domain for windows
var pt = ee.Geometry.Point([-91.1898, 14.7064]);
var lake = ee.FeatureCollection("projects/servir-amazonia/aoi/gt_atitlan_lake"),
    roi = ee.FeatureCollection("projects/servir-amazonia/aoi/gt_atitlan_ws");
var roi2_ = ee.Image().byte().paint({featureCollection:roi,color:'blue',width:2});
////////////////////////////////////////////////////////////////////////////////////////////////
var logo = ee.Image("users/servirbz/compil_imagery/_logos/logo_uah_blk");
////////////////////////////////////////////////////////////////////////////////////////////////
var t = 'system:time_start';
// Specify image collection to be used -> can be changed to another collection (e.g. Landsat-8 SR)
var collection = ee.ImageCollection("COPERNICUS/S2").filterBounds(pt)
              //.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
              //.filterDate('2018-01-01','2019-12-31')
              .sort(t, false)
              .map(function(image){var dateStr = ee.Date(image.get('system:time_start')).format();
              return image.clip(roi).set('date',dateStr);});
////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////
// Display each image in the collection
var imgLayer = null;
var aoiLayer = null;
var imgDates = ee.List(collection.aggregate_array('date'));
var imgIds = ee.List(collection.aggregate_array('system:index'));
imgIds.evaluate(function(ids) {
  var size = ids.length;
  var showTitle = ui.Label("", {fontWeight: 'bold', color: 'blue'});
  var curIndex = 0;
/////////////////////////////////////////  
// Define buttons
  var previous = ui.Button("Earlier", function() {
    curIndex += 1;
    if (curIndex >= size) {curIndex = 0;}
    showTitle.setValue(imgDates.get(curIndex).getInfo());
    showSelectRawImage(ids[curIndex]);});
  var next = ui.Button("Later", function() {
    curIndex -= 1;
    if (curIndex < 0) {curIndex = total - 1;}
    showTitle.setValue(imgDates.get(curIndex).getInfo());
    showSelectRawImage(ids[curIndex]);});
  var buttonPanel = new ui.Panel(
    [next, previous],
    ui.Panel.Layout.Flow('horizontal'));
/////////////////////////////////////////
  showTitle.setValue(imgDates.get(curIndex).getInfo());
  showSelectRawImage(ids[curIndex]);
  var insert_logo = ui.Thumbnail({image:logo,params:{bands:['b1','b2','b3'],min:0,max:255},style:{width:'223px',height:'100px'}});
/////////////////////////////////////////
  var main = ui.Panel({
    widgets: [
      ui.Label('Sentinel-2 explorer: Lake Atitlan', {fontWeight: 'bold', fontSize: '18px', color: 'mediumblue'}), // UI title
      ui.Label("date / time of image shown: ", {fontWeight: 'bold'}),
      showTitle,
      buttonPanel,
      insert_logo,
      ui.Label('credit: contains modified European Space Agency / Copernicus Sentinel data', {fontSize: '14px'})
    ],
    style: {width: '250px', padding: '8px'}
  });
  ui.root.insert(0, main);});
/////////////////////////////////////////
function showSelectRawImage(key) {
  if (imgLayer !== null) {
    Map.remove(imgLayer);
    //Map.remove(aoiLayer);
  }
  var image = ee.Image(collection.filter(ee.Filter.eq("system:index", key)).first());
  imgLayer = Map.addLayer(image, {bands: ['B4', 'B3', 'B2'], min: 226, max: 1100},key);
  //aoiLayer = Map.addLayer(roi2_, {palette: "blue"},'Lake Atitlan');
}
////////////////////////////////////////////////////////////////////////////////////////////////
Map.setOptions('TERRAIN');
Map.centerObject(pt,13);
//////////////////////////////////////////// END ///////////////////////////////////////////////