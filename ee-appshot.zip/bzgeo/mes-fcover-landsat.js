var roi_mes = ui.import && ui.import("roi_mes", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -93.00357722671643,
                18.606013471737782
              ],
              [
                -92.98160457046643,
                14.903761657603624
              ],
              [
                -91.64127253921643,
                13.818190879714503
              ],
              [
                -87.94986628921643,
                12.834678751199208
              ],
              [
                -86.12613582046643,
                11.007367001905505
              ],
              [
                -85.97232722671643,
                9.99195815675067
              ],
              [
                -84.91763972671643,
                9.168649649583603
              ],
              [
                -83.51138972671643,
                8.060704859029391
              ],
              [
                -82.03922175796643,
                7.015146725756474
              ],
              [
                -80.85269832046643,
                6.94971764312247
              ],
              [
                -77.57877253921643,
                7.145977228510395
              ],
              [
                -76.96353816421643,
                7.951912460865559
              ],
              [
                -77.35904597671643,
                8.929958955465029
              ],
              [
                -78.01822566421643,
                9.558886622487552
              ],
              [
                -79.51236628921643,
                9.883743332728564
              ],
              [
                -81.09439753921643,
                9.342142373018826
              ],
              [
                -82.74234675796643,
                10.165026845639192
              ],
              [
                -83.29166316421643,
                11.158307062986283
              ],
              [
                -83.31363582046643,
                12.126720924389572
              ],
              [
                -83.00601863296643,
                13.070228089157691
              ],
              [
                -82.94010066421643,
                15.200823873934057
              ],
              [
                -83.75308894546643,
                16.04724535139411
              ],
              [
                -85.75260066421643,
                16.805967394836888
              ],
              [
                -87.62027644546643,
                16.363739111046
              ],
              [
                -87.29068660171643,
                17.100216325037493
              ],
              [
                -87.02701472671643,
                18.20989553202233
              ],
              [
                -87.02701472671643,
                19.664683279254323
              ],
              [
                -86.43375300796643,
                20.407816913453235
              ],
              [
                -86.34586238296643,
                21.188361945685877
              ],
              [
                -86.69742488296643,
                21.80169143854806
              ],
              [
                -87.53238582046643,
                21.883272405917058
              ],
              [
                -88.80679988296643,
                21.781288927059006
              ],
              [
                -89.75162410171643,
                21.495349889411155
              ],
              [
                -90.80631160171643,
                20.83967028912287
              ],
              [
                -91.20181941421643,
                19.72674476342327
              ],
              [
                -91.72916316421643,
                19.063526125971602
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-93.00357722671643, 18.606013471737782],
          [-92.98160457046643, 14.903761657603624],
          [-91.64127253921643, 13.818190879714503],
          [-87.94986628921643, 12.834678751199208],
          [-86.12613582046643, 11.007367001905505],
          [-85.97232722671643, 9.99195815675067],
          [-84.91763972671643, 9.168649649583603],
          [-83.51138972671643, 8.060704859029391],
          [-82.03922175796643, 7.015146725756474],
          [-80.85269832046643, 6.94971764312247],
          [-77.57877253921643, 7.145977228510395],
          [-76.96353816421643, 7.951912460865559],
          [-77.35904597671643, 8.929958955465029],
          [-78.01822566421643, 9.558886622487552],
          [-79.51236628921643, 9.883743332728564],
          [-81.09439753921643, 9.342142373018826],
          [-82.74234675796643, 10.165026845639192],
          [-83.29166316421643, 11.158307062986283],
          [-83.31363582046643, 12.126720924389572],
          [-83.00601863296643, 13.070228089157691],
          [-82.94010066421643, 15.200823873934057],
          [-83.75308894546643, 16.04724535139411],
          [-85.75260066421643, 16.805967394836888],
          [-87.62027644546643, 16.363739111046],
          [-87.29068660171643, 17.100216325037493],
          [-87.02701472671643, 18.20989553202233],
          [-87.02701472671643, 19.664683279254323],
          [-86.43375300796643, 20.407816913453235],
          [-86.34586238296643, 21.188361945685877],
          [-86.69742488296643, 21.80169143854806],
          [-87.53238582046643, 21.883272405917058],
          [-88.80679988296643, 21.781288927059006],
          [-89.75162410171643, 21.495349889411155],
          [-90.80631160171643, 20.83967028912287],
          [-91.20181941421643, 19.72674476342327],
          [-91.72916316421643, 19.063526125971602]]]),
    fit70 = ui.import && ui.import("fit70", "image", {
      "id": "projects/bz-sdg/compil_imagery/optical/landsat_ft/mes_landsat_boa_fitted_r70_1984_2022_0630_100m"
    }) || ee.Image("projects/bz-sdg/compil_imagery/optical/landsat_ft/mes_landsat_boa_fitted_r70_1984_2022_0630_100m");
// Last updated: 1 July 2022
var a = require('users/bzgeo/examples:_ancillary/mes');
var b = require('users/servirbz/packages:sma_std3');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var ltStack2 = fit70.clip(a.mes_bnds);
/////
var landsat_1984 = ltStack2.select(['B1_1984','B2_1984','B3_1984','B4_1984','B5_1984','B7_1984'],['B1','B2','B3','B4','B5','B7']);
var landsat_1985 = ltStack2.select(['B1_1985','B2_1985','B3_1985','B4_1985','B5_1985','B7_1985'],['B1','B2','B3','B4','B5','B7']);
var landsat_1986 = ltStack2.select(['B1_1986','B2_1986','B3_1986','B4_1986','B5_1986','B7_1986'],['B1','B2','B3','B4','B5','B7']);
var landsat_1987 = ltStack2.select(['B1_1987','B2_1987','B3_1987','B4_1987','B5_1987','B7_1987'],['B1','B2','B3','B4','B5','B7']);
var landsat_1988 = ltStack2.select(['B1_1988','B2_1988','B3_1988','B4_1988','B5_1988','B7_1988'],['B1','B2','B3','B4','B5','B7']);
var landsat_1989 = ltStack2.select(['B1_1989','B2_1989','B3_1989','B4_1989','B5_1989','B7_1989'],['B1','B2','B3','B4','B5','B7']);
var landsat_1990 = ltStack2.select(['B1_1990','B2_1990','B3_1990','B4_1990','B5_1990','B7_1990'],['B1','B2','B3','B4','B5','B7']);
var landsat_1991 = ltStack2.select(['B1_1991','B2_1991','B3_1991','B4_1991','B5_1991','B7_1991'],['B1','B2','B3','B4','B5','B7']);
var landsat_1992 = ltStack2.select(['B1_1992','B2_1992','B3_1992','B4_1992','B5_1992','B7_1992'],['B1','B2','B3','B4','B5','B7']);
var landsat_1993 = ltStack2.select(['B1_1993','B2_1993','B3_1993','B4_1993','B5_1993','B7_1993'],['B1','B2','B3','B4','B5','B7']);
var landsat_1994 = ltStack2.select(['B1_1994','B2_1994','B3_1994','B4_1994','B5_1994','B7_1994'],['B1','B2','B3','B4','B5','B7']);
var landsat_1995 = ltStack2.select(['B1_1995','B2_1995','B3_1995','B4_1995','B5_1995','B7_1995'],['B1','B2','B3','B4','B5','B7']);
var landsat_1996 = ltStack2.select(['B1_1996','B2_1996','B3_1996','B4_1996','B5_1996','B7_1996'],['B1','B2','B3','B4','B5','B7']);
var landsat_1997 = ltStack2.select(['B1_1997','B2_1997','B3_1997','B4_1997','B5_1997','B7_1997'],['B1','B2','B3','B4','B5','B7']);
var landsat_1998 = ltStack2.select(['B1_1998','B2_1998','B3_1998','B4_1998','B5_1998','B7_1998'],['B1','B2','B3','B4','B5','B7']);
var landsat_1999 = ltStack2.select(['B1_1999','B2_1999','B3_1999','B4_1999','B5_1999','B7_1999'],['B1','B2','B3','B4','B5','B7']);
var landsat_2000 = ltStack2.select(['B1_2000','B2_2000','B3_2000','B4_2000','B5_2000','B7_2000'],['B1','B2','B3','B4','B5','B7']);
var landsat_2001 = ltStack2.select(['B1_2001','B2_2001','B3_2001','B4_2001','B5_2001','B7_2001'],['B1','B2','B3','B4','B5','B7']);
var landsat_2002 = ltStack2.select(['B1_2002','B2_2002','B3_2002','B4_2002','B5_2002','B7_2002'],['B1','B2','B3','B4','B5','B7']);
var landsat_2003 = ltStack2.select(['B1_2003','B2_2003','B3_2003','B4_2003','B5_2003','B7_2003'],['B1','B2','B3','B4','B5','B7']);
var landsat_2004 = ltStack2.select(['B1_2004','B2_2004','B3_2004','B4_2004','B5_2004','B7_2004'],['B1','B2','B3','B4','B5','B7']);
var landsat_2005 = ltStack2.select(['B1_2005','B2_2005','B3_2005','B4_2005','B5_2005','B7_2005'],['B1','B2','B3','B4','B5','B7']);
var landsat_2006 = ltStack2.select(['B1_2006','B2_2006','B3_2006','B4_2006','B5_2006','B7_2006'],['B1','B2','B3','B4','B5','B7']);
var landsat_2007 = ltStack2.select(['B1_2007','B2_2007','B3_2007','B4_2007','B5_2007','B7_2007'],['B1','B2','B3','B4','B5','B7']);
var landsat_2008 = ltStack2.select(['B1_2008','B2_2008','B3_2008','B4_2008','B5_2008','B7_2008'],['B1','B2','B3','B4','B5','B7']);
var landsat_2009 = ltStack2.select(['B1_2009','B2_2009','B3_2009','B4_2009','B5_2009','B7_2009'],['B1','B2','B3','B4','B5','B7']);
var landsat_2010 = ltStack2.select(['B1_2010','B2_2010','B3_2010','B4_2010','B5_2010','B7_2010'],['B1','B2','B3','B4','B5','B7']);
var landsat_2011 = ltStack2.select(['B1_2011','B2_2011','B3_2011','B4_2011','B5_2011','B7_2011'],['B1','B2','B3','B4','B5','B7']);
var landsat_2012 = ltStack2.select(['B1_2012','B2_2012','B3_2012','B4_2012','B5_2012','B7_2012'],['B1','B2','B3','B4','B5','B7']);
var landsat_2013 = ltStack2.select(['B1_2013','B2_2013','B3_2013','B4_2013','B5_2013','B7_2013'],['B1','B2','B3','B4','B5','B7']);
var landsat_2014 = ltStack2.select(['B1_2014','B2_2014','B3_2014','B4_2014','B5_2014','B7_2014'],['B1','B2','B3','B4','B5','B7']);
var landsat_2015 = ltStack2.select(['B1_2015','B2_2015','B3_2015','B4_2015','B5_2015','B7_2015'],['B1','B2','B3','B4','B5','B7']);
var landsat_2016 = ltStack2.select(['B1_2016','B2_2016','B3_2016','B4_2016','B5_2016','B7_2016'],['B1','B2','B3','B4','B5','B7']);
var landsat_2017 = ltStack2.select(['B1_2017','B2_2017','B3_2017','B4_2017','B5_2017','B7_2017'],['B1','B2','B3','B4','B5','B7']);
var landsat_2018 = ltStack2.select(['B1_2018','B2_2018','B3_2018','B4_2018','B5_2018','B7_2018'],['B1','B2','B3','B4','B5','B7']);
var landsat_2019 = ltStack2.select(['B1_2019','B2_2019','B3_2019','B4_2019','B5_2019','B7_2019'],['B1','B2','B3','B4','B5','B7']);
var landsat_2020 = ltStack2.select(['B1_2020','B2_2020','B3_2020','B4_2020','B5_2020','B7_2020'],['B1','B2','B3','B4','B5','B7']);
var landsat_2021 = ltStack2.select(['B1_2021','B2_2021','B3_2021','B4_2021','B5_2021','B7_2021'],['B1','B2','B3','B4','B5','B7']);
var landsat_2022 = ltStack2.select(['B1_2022','B2_2022','B3_2022','B4_2022','B5_2022','B7_2022'],['B1','B2','B3','B4','B5','B7']);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var img_raw = {
'1984': landsat_1984,
'1985': landsat_1985,
'1986': landsat_1986,
'1987': landsat_1987,
'1988': landsat_1988,
'1989': landsat_1989,
'1990': landsat_1990,
'1991': landsat_1991,
'1992': landsat_1992,
'1993': landsat_1993,
'1994': landsat_1994,
'1995': landsat_1995,
'1996': landsat_1996,
'1997': landsat_1997,
'1998': landsat_1998,
'1999': landsat_1999,
'2000': landsat_2000,
'2001': landsat_2001,
'2002': landsat_2002,
'2003': landsat_2003,
'2004': landsat_2004,
'2005': landsat_2005,
'2006': landsat_2006,
'2007': landsat_2007,
'2008': landsat_2008,
'2009': landsat_2009,
'2010': landsat_2010,
'2011': landsat_2011,
'2012': landsat_2012,
'2013': landsat_2013,
'2014': landsat_2014,
'2015': landsat_2015,
'2016': landsat_2016,
'2017': landsat_2017,
'2018': landsat_2018,
'2019': landsat_2019,
'2020': landsat_2020,
'2021': landsat_2021,
'2022': landsat_2022,
// '2023': landsat_2023,
};
var img_sma = {
'1984': b.sma_(landsat_1984),
'1985': b.sma_(landsat_1985),
'1986': b.sma_(landsat_1986),
'1987': b.sma_(landsat_1987),
'1988': b.sma_(landsat_1988),
'1989': b.sma_(landsat_1989),
'1990': b.sma_(landsat_1990),
'1991': b.sma_(landsat_1991),
'1992': b.sma_(landsat_1992),
'1993': b.sma_(landsat_1993),
'1994': b.sma_(landsat_1994),
'1995': b.sma_(landsat_1995),
'1996': b.sma_(landsat_1996),
'1997': b.sma_(landsat_1997),
'1998': b.sma_(landsat_1998),
'1999': b.sma_(landsat_1999),
'2000': b.sma_(landsat_2000),
'2001': b.sma_(landsat_2001),
'2002': b.sma_(landsat_2002),
'2003': b.sma_(landsat_2003),
'2004': b.sma_(landsat_2004),
'2005': b.sma_(landsat_2005),
'2006': b.sma_(landsat_2006),
'2007': b.sma_(landsat_2007),
'2008': b.sma_(landsat_2008),
'2009': b.sma_(landsat_2009),
'2010': b.sma_(landsat_2010),
'2011': b.sma_(landsat_2011),
'2012': b.sma_(landsat_2012),
'2013': b.sma_(landsat_2013),
'2014': b.sma_(landsat_2014),
'2015': b.sma_(landsat_2015),
'2016': b.sma_(landsat_2016),
'2017': b.sma_(landsat_2017),
'2018': b.sma_(landsat_2018),
'2019': b.sma_(landsat_2019),
'2020': b.sma_(landsat_2020),
'2021': b.sma_(landsat_2021),
'2022': b.sma_(landsat_2022),
};
var img_for = {
'1984': b.for_sma_60(b.sma_(landsat_1984)),
'1985': b.for_sma_60(b.sma_(landsat_1985)),
'1986': b.for_sma_60(b.sma_(landsat_1986)),
'1987': b.for_sma_60(b.sma_(landsat_1987)),
'1988': b.for_sma_60(b.sma_(landsat_1988)),
'1989': b.for_sma_60(b.sma_(landsat_1989)),
'1990': b.for_sma_60(b.sma_(landsat_1990)),
'1991': b.for_sma_60(b.sma_(landsat_1991)),
'1992': b.for_sma_60(b.sma_(landsat_1992)),
'1993': b.for_sma_60(b.sma_(landsat_1993)),
'1994': b.for_sma_60(b.sma_(landsat_1994)),
'1995': b.for_sma_60(b.sma_(landsat_1995)),
'1996': b.for_sma_60(b.sma_(landsat_1996)),
'1997': b.for_sma_60(b.sma_(landsat_1997)),
'1998': b.for_sma_60(b.sma_(landsat_1998)),
'1999': b.for_sma_60(b.sma_(landsat_1999)),
'2000': b.for_sma_60(b.sma_(landsat_2000)),
'2001': b.for_sma_60(b.sma_(landsat_2001)),
'2002': b.for_sma_60(b.sma_(landsat_2002)),
'2003': b.for_sma_60(b.sma_(landsat_2003)),
'2004': b.for_sma_60(b.sma_(landsat_2004)),
'2005': b.for_sma_60(b.sma_(landsat_2005)),
'2006': b.for_sma_60(b.sma_(landsat_2006)),
'2007': b.for_sma_60(b.sma_(landsat_2007)),
'2008': b.for_sma_60(b.sma_(landsat_2008)),
'2009': b.for_sma_60(b.sma_(landsat_2009)),
'2010': b.for_sma_60(b.sma_(landsat_2010)),
'2011': b.for_sma_60(b.sma_(landsat_2011)),
'2012': b.for_sma_60(b.sma_(landsat_2012)),
'2013': b.for_sma_60(b.sma_(landsat_2013)),
'2014': b.for_sma_60(b.sma_(landsat_2014)),
'2015': b.for_sma_60(b.sma_(landsat_2015)),
'2016': b.for_sma_60(b.sma_(landsat_2016)),
'2017': b.for_sma_60(b.sma_(landsat_2017)),
'2018': b.for_sma_60(b.sma_(landsat_2018)),
'2019': b.for_sma_60(b.sma_(landsat_2019)),
'2020': b.for_sma_60(b.sma_(landsat_2020)),
'2021': b.for_sma_60(b.sma_(landsat_2021)),
'2022': b.for_sma_60(b.sma_(landsat_2022)),
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PART 1: SET UP LEFT AND RIGHT PANEL WINDOWS
// CREATE LEFT 7 RIGHT MAPS
var leftMap = ui.Map();
leftMap.setOptions('TERRAIN');
leftMap.setControlVisibility(true);
var rightMap = ui.Map();
rightMap.setOptions('TERRAIN');
rightMap.setControlVisibility(true);
//
var leftSelector = addLayerSelector(leftMap, 0, 'top-left');
function addLayerSelector(mapToChange, defaultValue, position) {
  var label = ui.Label('Choose year to visualize');
  function updateMap(selection) {
    mapToChange.layers().set(0, ui.Map.Layer(img_raw[selection].visualize(b.viz_543),{},"Landsat_imagery", false));
    mapToChange.layers().set(1, ui.Map.Layer(img_sma[selection].visualize({}),{},"Landsat_SMA", true));
    mapToChange.layers().set(2, ui.Map.Layer(img_for[selection].visualize(b.pal_fc),{},"Forest_cover", false));
    mapToChange.layers().set(3, ui.Map.Layer(a.hill_mes.clip(a.mes_bnds),{},"Hillshade", false));
    mapToChange.layers().set(4, ui.Map.Layer(a.pa_mes_ln.clip(a.mes_bnds),{palette: "yellow"},"Prot. areas", true));
    mapToChange.layers().set(5, ui.Map.Layer(a.bnds_intl_ln2,{palette: "white"},"Int'l boundaries", true));
    }
var select = ui.Select({items: Object.keys(img_raw), onChange: updateMap});
  select.setValue(Object.keys(img_raw)[defaultValue], true);
var controlPanel = ui.Panel({widgets: [label, select], style: {position: position}});
  mapToChange.add(controlPanel);
}
var rightSelector = addLayerSelector2(rightMap, 38, 'top-right');
function addLayerSelector2(mapToChange, defaultValue, position) {
  var label = ui.Label('Choose year to visualize');
  function updateMap(selection) {
    mapToChange.layers().set(0, ui.Map.Layer(img_raw[selection].visualize(b.viz_543),{},"Landsat_imagery", false));
    mapToChange.layers().set(1, ui.Map.Layer(img_sma[selection].visualize({}),{},"Landsat_SMA", true));
    mapToChange.layers().set(2, ui.Map.Layer(img_for[selection].visualize(b.pal_fc),{},"Forest_cover", false));
    mapToChange.layers().set(3, ui.Map.Layer(a.hill_mes.clip(a.mes_bnds),{},"Hillshade", false));
    mapToChange.layers().set(4, ui.Map.Layer(a.pa_mes_ln.clip(a.mes_bnds),{palette: "yellow"},"Prot. areas", true));
    mapToChange.layers().set(5, ui.Map.Layer(a.bnds_intl_ln2,{palette: "white"},"Int'l boundaries", true));
    }
var select = ui.Select({items: Object.keys(img_raw), onChange: updateMap});
  select.setValue(Object.keys(img_raw)[defaultValue], true);
var controlPanel = ui.Panel({widgets: [label, select], style: {position: position}});
  mapToChange.add(controlPanel);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PART 2: INITIATE THE SPLIT PANEL
var splitPanel = ui.SplitPanel({firstPanel:leftMap, secondPanel:rightMap, wipe:true, style:{stretch: 'both'}});
var title = ui.Label("Forest cover change, 1984-2022: Mesoamerican Biological Corridor", {stretch:'horizontal',textAlign:'center',fontWeight:'bold',fontSize:'20px', color: 'green'});
var descr = ui.Label("instructions: swipe images to compare them", {stretch:'horizontal',textAlign:'center',fontSize: '13px', color: 'mediumseagreen'});
var credits = ui.Label("credits: Landsat imagery © NASA, USGS, processed with Kennedy et al. (2018)'s LandTrendr algorithm", {stretch:'horizontal',textAlign:'center',fontSize: '12px', color: 'gray'});
//ui.root.widgets().reset([title, splitPanel]);
ui.root.widgets().reset([title, descr, credits, splitPanel]);
ui.root.setLayout(ui.Panel.Layout.Flow('vertical'));
var linker = ui.Map.Linker([leftMap, rightMap]);
leftMap.setCenter(-88.7547, 17.2487,8);
//leftMap.centerObject(a.roi_mes,7);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////