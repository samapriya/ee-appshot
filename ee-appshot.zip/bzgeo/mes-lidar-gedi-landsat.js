var rh_50 = ui.import && ui.import("rh_50", "image", {
      "id": "projects/bz-sdg/x_tmp/mod_agb_gedi/mes_gedi_chm_rh_050_mod04d_030m"
    }) || ee.Image("projects/bz-sdg/x_tmp/mod_agb_gedi/mes_gedi_chm_rh_050_mod04d_030m"),
    rh_75 = ui.import && ui.import("rh_75", "image", {
      "id": "projects/bz-sdg/x_tmp/mod_agb_gedi/mes_gedi_chm_rh_075_mod04d_030m"
    }) || ee.Image("projects/bz-sdg/x_tmp/mod_agb_gedi/mes_gedi_chm_rh_075_mod04d_030m"),
    rh_98 = ui.import && ui.import("rh_98", "image", {
      "id": "projects/bz-sdg/x_tmp/mod_agb_gedi/mes_gedi_chm_rh_098_mod04d_030m"
    }) || ee.Image("projects/bz-sdg/x_tmp/mod_agb_gedi/mes_gedi_chm_rh_098_mod04d_030m"),
    lt_2024 = ui.import && ui.import("lt_2024", "image", {
      "id": "projects/bz-sdg/compil_imagery/optical/landsat_ft/mes_landsat_boa_fitted_r70_2024_0628_030m"
    }) || ee.Image("projects/bz-sdg/compil_imagery/optical/landsat_ft/mes_landsat_boa_fitted_r70_2024_0628_030m");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Visualize upscaled canopy height model (CHM) and relative height (RH) metrics from GEDI L2A product
// Orig. GEDI data: https://developers.google.com/earth-engine/datasets/catalog/LARSE_GEDI_GEDI02_A_002_MONTHLY
// Upscaling based on: https://spatialthoughts.com/2024/02/07/agb-regression-gee/
// Last modified: 06.12.2024
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Load requisite libraries
var a = require('users/bzgeo/examples:_ancillary/mes');
var b = require('users/servirbz/packages:img_list_landsat_sma_fc__mes');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Unsupervised classification
function unsuper(img, no) {
return img.cluster(ee.Clusterer.wekaKMeans(no).train(img.sample({region:a.roi_mes,scale:30,numPixels:3000})));}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Composite GEDI RH data
var rh_05_98_0 = ee.Image.cat([rh_50,rh_75,rh_98]).updateMask(a.msk_wtr);
// 3x3 low pass filter on GEDI RH data
var rh_05_98_1 = rh_05_98_0.focal_mean({kernel: ee.Kernel.square(90,'meters', false), iterations: 1}).toInt8().updateMask(a.msk_wtr);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Visualizations
var viz_chm = {"bands":["rh_098","rh_075","rh_050"],"min":[3,0,-1],"max":[23,17,13]};
var viz_rh50 = {"bands":["rh_050"],"min":[-1],"max":[13]};
var viz_rh75 = {"bands":["rh_075"],"min":[0],"max":[17]};
var viz_rh98 = {"bands":["rh_098"],"min":[3],"max":[23]};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PART 1: SET UP LEFT AND RIGHT PANEL WINDOWS
// CREATE LEFT 7 RIGHT MAPS
var leftMap = ui.Map();
leftMap.setOptions('SATELLITE');
leftMap.setControlVisibility(true);
var rightMap = ui.Map();
rightMap.setOptions('SATELLITE');
rightMap.setControlVisibility(true);
/////
leftMap.addLayer(lt_2024.visualize(b.viz_543).clip(a.mes_bnds),{},"Landsat_imagery_2024_dry_season", 1);
leftMap.addLayer(rh_50.visualize(viz_rh50), {},'GEDI heights_RH50', 0);
leftMap.addLayer(rh_75.visualize(viz_rh75), {},'GEDI heights_RH75', 0);
leftMap.addLayer(rh_98.visualize(viz_rh98), {},'GEDI heights_RH98', 0);
leftMap.addLayer(rh_05_98_0.visualize(viz_chm), {},'GEDI heights_RH50_RH75_RH98', 0);
leftMap.addLayer(rh_05_98_1.visualize(viz_chm), {},'GEDI heights_RH50_RH75_RH98_3x3', 0);
leftMap.addLayer(a.pa_mes_ln,{palette: "yellow"},"Prot. areas", 1);
leftMap.addLayer(a.cam_bnds_ln,{palette: "white"},"Int'l boundaries", 1);
/////
rightMap.addLayer(lt_2024.visualize(b.viz_543).clip(a.mes_bnds),{},"Landsat_imagery_2024_dry_season", 0);
rightMap.addLayer(rh_50.visualize(viz_rh50), {},'GEDI heights_RH50', 0);
rightMap.addLayer(rh_75.visualize(viz_rh75), {},'GEDI heights_RH75', 0);
rightMap.addLayer(rh_98.visualize(viz_rh98), {},'GEDI heights_RH98', 0);
rightMap.addLayer(rh_05_98_0.visualize(viz_chm), {},'GEDI heights_RH50_RH75_RH98', 1);
rightMap.addLayer(rh_05_98_1.visualize(viz_chm), {},'GEDI heights_RH50_RH75_RH98_3x3', 0);
rightMap.addLayer(a.pa_mes_ln,{palette: "yellow"},"Prot. areas", 1);
rightMap.addLayer(a.cam_bnds_ln,{palette: "white"},"Int'l boundaries", 1);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PART 2: INITIATE THE SPLIT PANEL
var splitPanel = ui.SplitPanel({firstPanel:leftMap, secondPanel:rightMap, wipe:true, style:{stretch: 'both'}});
var title = ui.Label("Landsat imagery and LiDAR-derived vegetation canopy height visualization: Mesoamerica", {stretch:'horizontal',textAlign:'center',fontWeight:'bold',fontSize:'20px', color: 'green'});
var descr = ui.Label("instructions: swipe to compare the derived LiDAR data and Landsat imagery; visualization is based on RH50 / RH75 / RH98 upscaled from GEDI", {stretch:'horizontal',textAlign:'center',fontSize: '13px', color: 'mediumseagreen'});
var credits = ui.Label("credits: Landsat data from NASA and the USGS, and GEDI data from NASA; upscaling analysis by the SERVIR SCO (Dec. 2024)", {stretch:'horizontal',textAlign:'center',fontSize: '12px', color: 'gray'});
ui.root.widgets().reset([title, descr, credits, splitPanel]);
ui.root.setLayout(ui.Panel.Layout.Flow('vertical'));
var linker = ui.Map.Linker([leftMap, rightMap]);
leftMap.setCenter(-86.499, 14.415,7);
rightMap.setCenter(-86.499, 14.415,7);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////