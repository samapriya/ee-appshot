var snazzy = require("users/aazuspan/snazzy:styles");
snazzy.addStyle("https://snazzymaps.com/style/38830/vector", "Dark Background");
var palettes = require('users/gena/packages:palettes');
var palette_sequential = palettes.colorbrewer.BuGn[9];
//-------------------------------------------------------------
var layerProperties = {
  'Annual mangrove maps': {
    visParams: {min: 1, max: 2, palette: ['#00ce00','green']},
    legend: [{'Mangroves (Clear observation)': '#00ce00'},{'Mangroves (Gap filled)': 'green'}],
    defaultVisibility: true
  },
  'Loss/Gain': {
    mangrove1: 'projects/mangrovedatahub/assets/AnnualMap/projected_1984',
    mangrove2:'projects/mangrovedatahub/assets/AnnualMap/projected_1985',
    visParams: {min: -1, max: 1, palette: ['#e92700','#d4d4d4', '#0978ff']},
    legend:
        [{'Loss': '#e92700'}, {'Persistent': '#d4d4d4'}, {'Gain': '#0978ff'}],
    defaultVisibility: false
  },
  'Expansion/Regeneration (2010-2023)': {
    visParams: {min: 1, max: 2, palette: ['#00ce00','#ffd966']},
    legend:
        [{'Expansion': '#00ce00'}, {'Regeneration': '#ffd966'}],
    defaultVisibility: false
  },
  'Fractional Canopy Cover': {
    visParams: {min: 10, max: 100, palette: palette_sequential},
    legend: [
      {'90-100%': palette_sequential[8]}, {'80-90%': palette_sequential[7]}, {'70-80%': palette_sequential[6]},
      {'60-70%': palette_sequential[5]}, {'50-60%': palette_sequential[4]}, {'40-50%': palette_sequential[3]},
      {'30-40%': palette_sequential[2]}, {'20-30%': palette_sequential[1]}, {'10-20%': palette_sequential[0]},
    ],
    defaultVisibility: false
  },
  'Annual Degradation and Growth': {
    visParams: {min: 1, max: 2, palette: ['red','00ce00']},
    legend: [{'Degradation': 'red'}, {'Growth': '00ce00'}],
    defaultVisibility: false
  }
};
Map.setCenter(22.61, 0.7, 3);
//----------------Introduction of the app----------------------
var header = ui.Label('Continuous Global Mangrove Dynamics', {fontSize: '20px', fontWeight: 'bold',color:'#db521a'})
var intro = ui.Label('This tool provides an interactive platform to visualize global mangrove dynamics at 30-m resolution from 1984 to 2023. "Mangrove Loss" is defined as a change from mangrove to non-mangrove state. "Mangrove Gain" is defined as the inverse of loss. "Mangrove Degradation" is defined as substantial reduction of fractional canopy cover within persistent mangroves at the annual frequency. "Mangrove Growth" is defined as the inverse of degradation',{fontSize:'13px',margin: '6px 0px 0px 6px'})
// var desc1 = ui.Panel({
//     widgets: [
//       ui.Label({value: '-Loss/Gain:', style: {fontSize:'13px',margin: '5px 0px 0px 5px',fontWeight: 'bold'}}),
//       ui.Label('Mangroves convert to/from other land-cover types, whatever naturally or artificially.',{fontSize:'13px',margin: '5px 0px 0px 2px',width: '200px'})
//     ],layout: ui.Panel.Layout.Flow('horizontal') // 让它们水平排列
//   });
// var desc2 = ui.Panel({
//     widgets: [
//       ui.Label({value: '-Degradation/Growth:', style: {fontSize:'13px',margin: '2px 0px 0px 5px',fontWeight: 'bold'}}),
//       ui.Label('Substantial decrease/increase of mangrove fractional canopy cover.',{fontSize:'13px',margin: '2px 0px 0px 2px',width: '200px'})
//     ],layout: ui.Panel.Layout.Flow('horizontal') // 让它们水平排列
//   });
// var desc3 = ui.Panel({
//     widgets: [
//       ui.Label({value: '-Expansion/Regeneration:', style: {fontSize:'13px',margin: '2px 0px 0px 5px',fontWeight: 'bold'}}),
//       ui.Label('Mangrove gain from new areas/historical areas.',{fontSize:'13px',margin: '2px 0px 0px 2px',width: '190px'})
//     ],layout: ui.Panel.Layout.Flow('horizontal') // 让它们水平排列
//   });
var link_paper = ui.Panel({
    widgets: [
      ui.Label({value: 'Research paper:', style: {fontSize:'13px',margin: '5px 0px 0px 5px'}}),
      ui.Label('https://www.themangrovelab.com/',{fontSize:'13px',margin: '5px 0px 0px 5px',width: '200px'},'https://www.themangrovelab.com/')
    ],layout: ui.Panel.Layout.Flow('horizontal') // 让它们水平排列
  });
var link_data = ui.Panel({
    widgets: [
      ui.Label({value: 'Download data:', style: {fontSize:'13px',margin: '2px 0px 0px 5px'}}),
      ui.Label('https://zenodo.org/communities/cgmd',{fontSize:'13px',margin: '2px 0px 0px 5px',width: '250px'},'https://zenodo.org/communities/cgmd')
    ],layout: ui.Panel.Layout.Flow('horizontal') // 让它们水平排列
  });
var toolPanel = ui.Panel([header,intro,link_paper,link_data], 'flow', {width: '370px'})
ui.root.widgets().add(toolPanel);
// panel.add(intro);
//-----------------The elements of the pulldown are the keys of the layerProperties dictionary-----------
var legendPanel = ui.Panel({
  style:
      {fontWeight: 'bold', fontSize: '14px', margin: '0 0 0 8px', padding: '0'}
});
var legendTitle = ui.Label(
    'Legend',
    {fontWeight: 'bold', fontSize: '14px', margin: '0 0 4px 0', padding: '0'});
legendPanel.add(legendTitle);
// Define an area for the legend key itself.
// This area will be replaced every time the layer pulldown is changed.
var keyPanel = ui.Panel();
legendPanel.add(keyPanel);
var selectItems = Object.keys(layerProperties);
var layerSelect = ui.Select({
  items: selectItems,
  value: selectItems[0],
  onChange: updatePanel
});
toolPanel.add(ui.Label('View Different Layers', {fontSize: '14px',fontWeight:'bold',color:'grey'}));
toolPanel.add(layerSelect);
function updatePanel(selected) {
  while (toolPanel.widgets().length() > 6) { 
    toolPanel.remove(toolPanel.widgets().get(6));
  }
  if (selected === selectItems[0]) {
    var yearSlider = ui.Slider({
      min: 1984,
      max: 2023,
      value: 2023,
      step: 1,
      style: {stretch: 'horizontal'}
    });
    var Layer1 = function(value) {
      var mgf_layer = ee.FeatureCollection('projects/mangrovedatahub/assets/AnnualMap/projected_' + value);
      var img1 = ee.Image(1).clip(mgf_layer.filter(ee.Filter.eq('gridcode',1)));
      var img2 = ee.Image(2).clip(mgf_layer.filter(ee.Filter.eq('gridcode',2)));
      var img = ee.ImageCollection([img1.toByte(),img2.toByte()]).mosaic();
      var yearLayer = ui.Map.Layer(img, {min:1,max:2,palette: ['#00ce00','green']}, String(value));
      Map.layers().reset([yearLayer]);
    };
    yearSlider.onSlide(Layer1);
    var label = ui.Label('Select a year');
    toolPanel.add(label);
    var panel = ui.Panel([
      ui.Panel([yearSlider], ui.Panel.Layout.Flow('horizontal'))
    ]);
    toolPanel.add(panel);
    setLegend(layerProperties[selected].legend);
    // var label = ui.Label('Earth Engine Asset',{fontWeight:'bold', fontSize:'14px',color:"grey"});
    // var codeBlock = ui.Label({
    //     value: "var mgf_1984 = ee.FeatureCollection('projects/mangrovedatahub/assets/AnnualMap/projected_1984')",
    //     style: {
    //       fontFamily: 'monospace',
    //       whiteSpace: 'pre',
    //       backgroundColor: '#f0f0f0'
    //     }
    //   });
    // toolPanel.add(label);
    // toolPanel.add(codeBlock);
    // var selectItems = Object.keys(layerProperties);
    var location_prop = {'Sundarbans':[89.2182, 21.9066,9],
                         'Everglades':[-81.0717, 25.4853,10],
                         'Bintuni Bay':[133.5511, -2.3436,10],
    }
    var layerSelect_inset = ui.Select({
      items: Object.keys(location_prop),
      onChange: ShowingExample
    });
    function ShowingExample(location_name){
      var coor_x = location_prop[location_name][0];
      var coor_y = location_prop[location_name][1];
      var zoom_level = location_prop[location_name][2];
      Map.setCenter(coor_x, coor_y, zoom_level);
    }
    toolPanel.add(ui.Label('Example Locations', {fontSize: '14px',fontWeight:'bold',color:'black'}));
    toolPanel.add(layerSelect_inset);
    Layer1(2023)
  } else if (selected === selectItems[1]) {
    var yearSliderA = ui.Slider({
      min: 1984,
      max: 2022,
      value: 1984,
      step: 1,
      style: {stretch: 'horizontal'}
    });
    var yearSliderB = ui.Slider({
      min: 1985,
      max: 2023,
      value: 2023,
      step: 1,
      style: {stretch: 'horizontal'}
    });
    var updateDiffLayer = function() {
      var yearA = yearSliderA.getValue();
      var yearB = yearSliderB.getValue();
      if (yearA === yearB) return; // In case the same year
      var imgA = ee.Image(1).clip(ee.FeatureCollection('projects/mangrovedatahub/assets/AnnualMap/projected_' + yearA));
      var imgB = ee.Image(1).clip(ee.FeatureCollection('projects/mangrovedatahub/assets/AnnualMap/projected_' + yearB));
      var diff = imgB.unmask().subtract(imgA.unmask());
      diff = diff.updateMask(imgA.unmask().gt(0).or(imgB.unmask().gt(0)))
      var diffLayer = ui.Map.Layer(diff, layerProperties[selected].visParams, yearA + ' - ' + yearB);
      Map.layers().reset([diffLayer]);
    };
    yearSliderA.onSlide(updateDiffLayer);
    yearSliderB.onSlide(updateDiffLayer);
    var labelA = ui.Label('Start Year:');
    var labelB = ui.Label('End Year:');
    var panel = ui.Panel([
      ui.Panel([labelA, yearSliderA], ui.Panel.Layout.Flow('horizontal')),
      ui.Panel([labelB, yearSliderB], ui.Panel.Layout.Flow('horizontal'))
    ]);
    toolPanel.add(panel);
    setLegend(layerProperties[selected].legend)
    var location_prop = {'Deforestation in the Irrawaddy Delta, Myanmar':[95.0882, 15.9076,10],
                         'Deforestation in the Mahakam Delta, Indonesia': [117.4, -0.7, 12],
                         'Ongoing Deforestation in Tanzania':[39.3114, -7.8153,12],
                         'Loss due to aquaculture in Ecuador':[-80.1482, -3.3685,12],
                         'Erosion in Deception Bay, Papua New Guinea': [144.2735, -8.1128,9],
                         'Gain in China':[108.5486, 21.7615,11],
                         'Expansion in west Florida, USA': [-82.6955, 28.8327,11],
                         'Expansion in Gulf of Kutch, India': [69.9581, 22.7415, 10],
                         'Erosion and Accretion in Amazon Macrotidal Mangrove Coast, Brazil': [-46.6487, -0.8744, 10]
    }
    var layerSelect_inset = ui.Select({
      items: Object.keys(location_prop),
      onChange: ShowingExample
    });
    function ShowingExample(location_name){
      var coor_x = location_prop[location_name][0];
      var coor_y = location_prop[location_name][1];
      var zoom_level = location_prop[location_name][2];
      Map.setCenter(coor_x, coor_y, zoom_level);
    }
    toolPanel.add(ui.Label('Example Locations', {fontSize: '14px',fontWeight:'bold',color:'black'}));
    toolPanel.add(layerSelect_inset);
    // 初次加载时显示一次
    updateDiffLayer();
  }
  else if (selected === selectItems[2]) {
    var expansion = ee.FeatureCollection('projects/mangrovedatahub/assets/Expansion1023');
    var regeneration = ee.FeatureCollection('projects/mangrovedatahub/assets/Regeneration1023');
    expansion = ee.Image(1).clip(expansion);
    regeneration = ee.Image(2).clip(regeneration);
    var gain = ee.ImageCollection([expansion.toInt8(),regeneration.toInt8()]).mosaic();
    var yearLayer = ui.Map.Layer(gain, {min:1,max:2,palette: ['#00ce00','#ffd966']}, 'Expansion/Regeneration');
    Map.layers().reset([yearLayer]);
    setLegend(layerProperties[selected].legend);
  }
  else if (selected === selectItems[3]) {
    var yearSlider = ui.Slider({
      min: 1984,
      max: 2023,
      value: 2023,
      step: 1,
      style: {stretch: 'horizontal'}
    });
    var Layer3 = function (value) {
      var mgf_layer = ee.FeatureCollection('projects/mangrovedatahub/assets/AnnualMap/projected_' + value);
      var fcc_NA = ee.Image('projects/mangrovedatahub/assets/FCC/NorthAmerica/FCC_'+value).clip(mgf_layer);
      var fcc_SouthAmerica = ee.Image('projects/mangrovedatahub/assets/FCC/SouthAmerica/FCC_'+value).clip(mgf_layer);
      var fcc_AUS = ee.Image('projects/mangrovedatahub/assets/FCC/Australia/FCC_'+value).clip(mgf_layer);
      var fcc_WA = ee.Image('projects/mangrovedatahub2/assets/FCC/WestAfrica/FCC_'+value).clip(mgf_layer);
      var fcc_EA = ee.Image('projects/mangrovedatahub2/assets/FCC/EastAfrica/FCC_'+value).clip(mgf_layer);
      var fcc_SAsia = ee.Image('projects/mangrovedatahub2/assets/FCC/SouthAsia/FCC_'+value).clip(mgf_layer);
      if (value < 1987) {
        var fcc_SEA = ee.Image('projects/mangrovedatahub/assets/FCC/SEA/FCC_1987').clip(mgf_layer);
      } else {
        var fcc_SEA = ee.Image('projects/mangrovedatahub/assets/FCC/SEA/FCC_'+value).clip(mgf_layer);
      }
      var fcc_yearly = ee.ImageCollection([fcc_NA.toInt8(),fcc_SouthAmerica.toInt8(),fcc_AUS.toInt8(),fcc_WA.toInt8(),
                                           fcc_EA.toInt8(),fcc_SAsia.toInt8(),fcc_SEA.toInt8()]).mosaic();
      var yearLayer = ui.Map.Layer(fcc_yearly, {min:10,max:100,palette: palette_sequential}, 'Fractional Canopy Cover'+String(value));
      Map.layers().reset([yearLayer]);
    }
    yearSlider.onSlide(Layer3);
    var label = ui.Label('Select a year');
    toolPanel.add(label);
    var panel = ui.Panel([
      ui.Panel([yearSlider], ui.Panel.Layout.Flow('horizontal'))
    ]);
    toolPanel.add(panel);
    setLegend(layerProperties[selected].legend);
    Layer3(2023);
  }
  else if (selected === selectItems[4]) {
    var yearSlider = ui.Slider({
      min: 1985,
      max: 2023,
      value: 2023,
      step: 1,
      style: {stretch: 'horizontal'}
    });
    var Layer4 = function(value) {
      var degradation_layer = ee.FeatureCollection('projects/mangrovedatahub/assets/AnnualVariation/Degradation_' + (value-1)+'-'+value);
      var degradation = ee.Image(1).clip(degradation_layer.filter(ee.Filter.eq('landcover',1)))
      var growth = ee.Image(2).clip(degradation_layer.filter(ee.Filter.eq('landcover',2)))
      var total = ee.ImageCollection([degradation.toInt8(),growth.toInt8()]).mosaic()
      var yearLayer = ui.Map.Layer(total, {min:1,max:2,palette:['red','#00ce00']}, String(value-1)+'-'+String(value));
      Map.layers().reset([yearLayer]);
    }
    yearSlider.onSlide(Layer4)
    var label = ui.Label('Select a year');
    toolPanel.add(label);
    var panel = ui.Panel([
      ui.Panel([yearSlider], ui.Panel.Layout.Flow('horizontal'))
    ]);
    toolPanel.add(panel);
    setLegend(layerProperties[selected].legend);
    var location_prop = {'Degradation in Florida due to 2017 Hurricane Irma':[-81.2129, 25.546,10,2018],
                         'Degradation in Gulf of Carpentaria, Australia, due to 2015 El Niño': [140.2753, -17.5508, 11,2016],
                         'Degradation in Southern VietNam due to logging in 1992':[104.8707, 8.6346, 12, 1992],
                         'Degradation in Niger Delta due to Oil Pollution in 2012':[6.8994, 4.5608,11, 2012]
    }
    var layerSelect_inset = ui.Select({
      items: Object.keys(location_prop),
      onChange: ShowingExample
    });
    function ShowingExample(location_name){
      var coor_x = location_prop[location_name][0];
      var coor_y = location_prop[location_name][1];
      var zoom_level = location_prop[location_name][2];
      var year = location_prop[location_name][3];
      Map.setCenter(coor_x, coor_y, zoom_level);
      Layer4(year)
    }
    toolPanel.add(ui.Label('Example Locations', {fontSize: '14px',fontWeight:'bold',color:'black'}));
    toolPanel.add(layerSelect_inset);
    Layer4(2023)
  }
}
updatePanel(selectItems[0]);
// var img = ee.Image(1).clip(ee.FeatureCollection('projects/mangrovedatahub/assets/AnnualMap/projected_' + 2023));
// Map.addLayer(img, {palette: '#00ce00'}, '2023');
// print(toolPanel.widgets().length())
function setLegend(legend) {
  // Loop through all the items in a layer's key property,
  // creates the item, and adds it to the key panel.
  keyPanel.clear();
  toolPanel.add(legendPanel);
  for (var i = 0; i < legend.length; i++) {
    var item = legend[i];
    var name = Object.keys(item)[0];
    var color = item[name];
    var colorBox = ui.Label('', {
      backgroundColor: color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0'
    });
    // Create the label with the description text.
    var description = ui.Label(name, {margin: '0 0 4px 6px'});
    keyPanel.add(
        ui.Panel([colorBox, description], ui.Panel.Layout.Flow('horizontal')));
  }
}
// var logoUrl = 'https://pbs.twimg.com/media/GMQihw7WEAAVRkS.jpg';
// // 创建 HTML 图像标签
// var logoHtml = '<img src="' + logoUrl + '" style="width:100px; height:auto;">';
// // 放入 Label（包含 HTML）
// var logoLabel = ui.Label({
//   value: logoHtml,
//   style: {
//     position: 'top-left',
//     margin: '10px',
//     fontWeight: 'normal'
//   }
// });
// // 加入 panel 后插入 ui.root
// var logoPanel = ui.Panel([logoLabel], ui.Panel.Layout.flow('vertical'), {
//   position: 'top-left'
// });
// ui.root.insert(0, logoPanel);