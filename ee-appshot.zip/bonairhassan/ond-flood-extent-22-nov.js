var table = ui.import && ui.import("table", "table", {
      "id": "users/bonairhassan/urban_clusters"
    }) || ee.FeatureCollection("users/bonairhassan/urban_clusters"),
    roi = ui.import && ui.import("roi", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                39.01167107768044,
                4.147174771771586
              ],
              [
                39.01167107768044,
                -2.651535949233773
              ],
              [
                40.88484002299294,
                -2.651535949233773
              ],
              [
                40.88484002299294,
                4.147174771771586
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[39.01167107768044, 4.147174771771586],
          [39.01167107768044, -2.651535949233773],
          [40.88484002299294, -2.651535949233773],
          [40.88484002299294, 4.147174771771586]]], null, false),
    buildings = ui.import && ui.import("buildings", "table", {
      "id": "GOOGLE/Research/open-buildings/v3/polygons"
    }) || ee.FeatureCollection("GOOGLE/Research/open-buildings/v3/polygons");
// This is the final copy and paste script from the tutorial
// Load Sentinel-1 C-band SAR Ground Range collection (log scale, VV, descending)
var collectionVV = ee.ImageCollection('COPERNICUS/S1_GRD')
.filter(ee.Filter.eq('instrumentMode', 'IW'))
.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'))
.filterMetadata('resolution_meters', 'equals' , 10)
.filterBounds(roi)
.select('VV');
//print(collectionVV, 'Collection VV');
// Load Sentinel-1 C-band SAR Ground Range collection (log scale, VH, descending)
var collectionVH = ee.ImageCollection('COPERNICUS/S1_GRD')
.filter(ee.Filter.eq('instrumentMode', 'IW'))
.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'))
.filterMetadata('resolution_meters', 'equals' , 10)
.filterBounds(roi)
.select('VH');
//print(collectionVH, 'Collection VH');
//Filter by date
var beforeVV = collectionVV.filterDate('2023-09-01', '2023-09-30').mosaic();
var afterVV = collectionVV.filterDate('2023-11-11', '2023-11-26').mosaic();
var beforeVH = collectionVH.filterDate('2023-09-01', '2023-09-30').mosaic();
var afterVH = collectionVH.filterDate('2023-11-11', '2023-11-26').mosaic();
print(beforeVV, 'Before VV');
print(beforeVH, 'Before VH');
//print(beforeVV, 'Before VV');
print(afterVV, 'After VV');
//print(beforeVH, 'Before VH');
print(afterVH, 'After VH');
// Display map
Map.centerObject(roi, 9);
//Map.addLayer(beforeVV, {min:-15,max:0}, 'Before flood VV', 0);
//Map.addLayer(afterVV, {min:-15,max:0}, 'After flood VV', 0);
//Map.addLayer(beforeVH, {min:-25,max:0}, 'Before flood VH', 0);
//Map.addLayer(afterVH, {min:-25,max:0}, 'After flood VH', 0);
Map.addLayer(beforeVH.addBands(afterVH).addBands(beforeVH), {min: -25, max: -8},'BVH/AVV/AVH composite', 0);
//Apply filter to reduce speckle
var SMOOTHING_RADIUS = 50;
var beforeVV_filtered = beforeVV.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters');
var beforeVH_filtered = beforeVH.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters');
var afterVV_filtered = afterVV.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters');
var afterVH_filtered = afterVH.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters');
//Display filtered images
Map.addLayer(beforeVV_filtered, {min:-15,max:0}, 'Before Flood VV Filtered',0);
Map.addLayer(afterVV_filtered, {min:-15,max:0}, 'After Flood VV Filtered',0);
Map.addLayer(beforeVH_filtered, {min:-25,max:0}, 'Before Flood VH Filtered',0);
Map.addLayer(afterVH_filtered, {min:-25,max:0}, 'After Flood VH Filtered',0);
// Calculate difference between before and after
var differenceVH= afterVH_filtered.divide(beforeVH_filtered);
Map.addLayer(differenceVH, {min: 0,max:2},'difference VH filtered', 0);
//Apply Threshold
var DIFF_UPPER_THRESHOLD = 1.2;
var differenceVH_thresholded = differenceVH.gt(DIFF_UPPER_THRESHOLD);
 //* Function to mask clouds using the Sentinel-2 QA band
// * @param {ee.Image} image Sentinel-2 image
 //* @return {ee.Image} cloud masked Sentinel-2 image
// */
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
var dataset = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2023-11-18', '2023-11-23').filterBounds(roi)
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',70))
                  .map(maskS2clouds);
print (dataset)
//var visualization = {
//  min: 0.0,
//  max: 0.3,
//  bands: ['B4', 'B3', 'B2'],
//};
//false color
var visualization = {
  bands: ['B5', 'B4', 'B3'],
  min: 0,
  max: 0.5,
  gamma: [0.95, 1.1, 1]
};
//Map.centerObject(dataset, 12);
//Map.addLayer(dataset.median(), visualization, 'RGB');
// Adding additional vector datasets: 1. TRC Village clusters
var clusters = ee.FeatureCollection(table)
//Map.addLayer(clusters,{},'village Clusters')
var fd= differenceVH_thresholded.updateMask(differenceVH_thresholded)
/**
var vectors = fd.reduceToVectors({
  geometry: roi, // Replace with the actual region of interest geometry
  scale: 30,
  geometryType: 'polygon', // You can also use 'line' or 'point' depending on your needs
  eightConnected: false, // Set to true for 8-connected features
  labelProperty: 'class',// Property to label the vectors, change as needed
  maxPixels: 1e8,
  //reducer: ee.Reducer.mean()
  reducer: ee.Reducer.countEvery()// You can change the reducer based on your requirements
});
'''
var vectors = ee.FeatureCollection(vectors);
Export.table.toDrive ({
  collection: vectors,
  description:'flood_extent_011',
  fileFormat: 'KML'
});
**/
// Set the export "scale" and "crs" parameters.
/**
Export.image.toDrive({
  image: fd,
  description: 'image_export',
  folder: 'flooded_areas',
  region: roi,
  scale: 30,
  crs: 'EPSG:4326',
  maxPixels: 1E10,
});
**/
//var t_gte_070 = buildings.filter('confidence >= 0.70')
//mabatini_buildings = buildings.clip(mabatini)
//var trc_buildings = t_gte_070.filterBounds(roi)
//Map.addLayer (trc_buildings,{},'open buildings')
var dataset_2 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2023-11-11', '2023-11-26').filterBounds(roi)
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',60))
                  .map(maskS2clouds);
print (dataset_2)
//var visualization = {
//  min: 0.0,
//  max: 0.3,
//  bands: ['B4', 'B3', 'B2'],
//};
//false color
var visualization = {
  bands: ['B5', 'B4', 'B3'],
  min: 0,
  max: 0.5,
  gamma: [0.95, 1.1, 1]
};
Map.centerObject(dataset, 12);
Map.addLayer(dataset_2.max(), visualization, 'False color');
Map.addLayer(fd,{palette:"0000FF"},'flooded areas - blue',1);