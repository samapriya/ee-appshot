///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////
////////// Define Styles ////////////
/////////////////////////////////////
var colors = {'transparent': '#11ffee00', 'gray': '#F8F9FA'};
var TITLE_STYLE = {
  fontSize: '32px',
  padding: '8px',
  color: '#616161',
  backgroundColor: colors.transparent,
  fontWeight:'bold',
  textAlign: 'center',
  width: '520px'
};
var SUBTITLE_STYLE = {
  fontWeight: '350',
  fontSize: '16px',
  padding: '8px',
  color: '#616161',
  textAlign: 'center',
  //maxWidth: '450px',
  backgroundColor: colors.transparent,
};
var PARAGRAPH_STYLE = {
  fontSize: '14px',
  fontWeight: '50',
  color: '#616161',
  padding: '8px',
  maxWidth: '500px',
  backgroundColor: colors.transparent,
};
var BUTTON_STYLE = {
  fontSize: '14px',
  fontWeight: '100',
  color: '#616161',
  padding: '8px',
  backgroundColor: colors.transparent,
};
var SELECT_STYLE = {
  fontSize: '14px',
  fontWeight: '50',
  color: '#616161',
  padding: '2px',
  backgroundColor: colors.transparent,
  width: '100px'
};
var TEXTBOX_STYLE = {
  fontWeight: 'bold',
  fontSize: '14px',
  color: '#3690c0',
  padding: '2px',
  backgroundColor: colors.transparent,
  width: '100px'
};
var LABEL_STYLE = {
  fontWeight: 'bold',
  textAlign: 'center',
  fontSize: '14px',
  padding: '8px',
  backgroundColor: colors.transparent,
};
var datepickerstyle = {
  stretch : 'horizontal',
  width : '250px',
  fontSize: '14px',
  padding: '10px',
  backgroundColor: colors.transparent,
};
var symbol = {
  polygon: '△',
  point: '⊕',
  rectangle: '▭'
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////
////////// Define Panels ////////////
/////////////////////////////////////
var infoPanel = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical'), 
    style: {
      stretch: 'horizontal',
      height: '100%',
      width: '550px',
      backgroundColor: colors.gray
    }
});
var mappingPanel = ui.Map();
mappingPanel.style().set('cursor', 'hand');
ui.root.clear() // This is important to do to remove the "normal" GEE map
ui.root.add(ui.SplitPanel(mappingPanel, infoPanel)); // order matters!
//ui.root.add() is where you are adding panels to the EE window 
var panelmargin = ['15px 0px 0px 0px']
var seasonPanel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), 
                            style: {backgroundColor: colors.transparent}});
var visPanel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent}}); 
var checkPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var av_datesPanel = ui.Panel({style: {backgroundColor: colors.transparent}})
var downPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var sourcedatesPanel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent,stretch:'horizontal'}}); 
var areatitlePanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent,margin:panelmargin}}); 
var NDVIsliderPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var NDWIsliderPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var NDMIsliderPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var datePanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent,margin: '30px 8px 30px 8px'}}); 
var date1labelPanel = ui.Panel({style: {backgroundColor: colors.transparent}})
var date2labelPanel = ui.Panel({style: {backgroundColor: colors.transparent}})
var date1Panel = ui.Panel({style: {backgroundColor: colors.transparent}})
var date2Panel = ui.Panel({style: {backgroundColor: colors.transparent}})
var GovPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var JsonPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent,margin:['10px 8px 10px 0px']}}); 
var CloudPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent,margin:panelmargin}}); 
var DaysPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var modePanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var downloadPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var EPSGPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var inspectPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent,margin:panelmargin}}); 
var coordPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var watershedPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent,shown:false}}); 
var streamPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent,shown:false}}); 
var inputpolygon = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}});
var descriptionPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}}); 
var downloadsnippet = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}});
var coordinatepanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent,margin:panelmargin}});
var bandspanelvert = ui.Panel({layout: ui.Panel.Layout.flow('vertical',false),style: {backgroundColor: colors.transparent,width: '550px',stretch:'vertical'}});
var bandspanelhorz = ui.Panel({layout: ui.Panel.Layout.flow('horizontal',false),style: {backgroundColor: colors.transparent,height: '265px',width: '550px'}});
var bandspanela = ui.Panel({layout: ui.Panel.Layout.flow('vertical',true),style: {backgroundColor: colors.transparent,height: '265px',width: '200px'}});
var bandspanelb = ui.Panel({layout: ui.Panel.Layout.flow('vertical',true),style: {backgroundColor: colors.transparent,height: '265px',width: '200px'}});
var bandspanelc = ui.Panel({layout: ui.Panel.Layout.flow('vertical',true),style: {backgroundColor: colors.transparent,height: '265px',width: '150px'}});
var gotogee = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent}});
var predefinedPanel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent,margin:panelmargin}});
var customPanel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent}});
var drawpolygonPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent,height:'40px'}});
var bandslabelPanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal'),style: {backgroundColor: colors.transparent,margin:panelmargin}});
var separator1 = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent,margin:['-15px 0px -15px 0px']}});
var minor_separator = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent,margin:['-15px 0px -15px 0px']}});
var separator2 = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent,margin:['-15px 0px -15px 0px']}});
var separator3 = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent,margin:['-15px 0px -15px 0px']}});
var separator4 = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent,margin:['-15px 0px -15px 0px']}});
var separator5 = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent,margin:['-15px 0px -15px 0px']}});
var separator6 = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent,margin:['-15px 0px -15px 0px']}});
var separator7 = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {backgroundColor: colors.transparent,margin:['-15px 0px -15px 0px']}});
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////
////////////// Intro ////////////////
/////////////////////////////////////
infoPanel.add(ui.Label('GEE Satellite Image Services', TITLE_STYLE));
// var version = ui.Label('GIS Department Version',PARAGRAPH_STYLE);
// version.style().set({color:'#008B8B',fontWeight:'bold',fontFamily:'Monaco',fontSize: '14px',margin:'-25px 8px 8px 318px'})
// infoPanel.add(version)
infoPanel.add(descriptionPanel)
var Author = ui.Label('By Yousif Almamalachy',PARAGRAPH_STYLE);
Author.style().set({color:'mediumvioletred',fontWeight:'bold',fontFamily:'Monaco',fontSize: '14px'})
var Help = ui.Label('Help!',PARAGRAPH_STYLE);
Help.setUrl('https://view.genial.ly/611cac2df27bad1005105a97/interactive-content-sentinel-2')
Help.style().set({margin: '8px 8px 8px 280px', fontWeight:'bold',color:'blue'})
descriptionPanel.add(Author);
descriptionPanel.add(Help)
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////
//////////// Data Entry /////////////
/////////////////////////////////////
var NDMIscale;
var NDVIscale;
var NDWIscale;
var DEMscale = 30;
var sourcedates = []
infoPanel.add(seasonPanel);
seasonPanel.add(modePanel);
var sensor_label = ui.Label('Select Dataset:', LABEL_STYLE)
var sensor_list = [
{label:'Sentinel 2 L2A', value:'s2a'},
{label:'Sentinel 2 L1C', value:'s1c'},
{label:'Landsat 8 L2', value:'l8'},
{label:'Landsat 9 L2', value:'l9'},
{label:'Landsat 5 L2', value:'l5'},
{label:'NASA DEM (30m)', value:'dem'},
{label:'Watershed Delineation', value:'ws'}
];
var sensor_selector = ui.Select({items: sensor_list, placeholder: 'Sentinel 2 L2A',
value: 's2a', style: SELECT_STYLE,onChange:function(value){
var vanishlistdem = [Cloud_selector,Cloud_label,Days_selector,Days_label,
AutoDetect,datee1,datee2,dd1,dd2,date1format,date2format,availabeldates,
av_dates_description,meantitle,areatitle,bandspanelvert,NDVIsliderPanel,
NDWIsliderPanel,NDMIsliderPanel,CloudButton,av_dates,separator2,separator7]; // items to hide when dem is selected
var vanishlistws = [predefinedPanel,customPanel,visPanel,datePanel,checkPanel,
downPanel,sourcedatesPanel,meantitle,areatitle,bandspanelvert,NDVIsliderPanel,
NDWIsliderPanel,NDMIsliderPanel,minor_separator,separator2,separator3,separator4,separator7]; // items to hide when watershed is selected
var showlistws = [watershedPanel,streamPanel,drawwatershedd]; // items to show when watershed is selected
if(value == 's2a')
{PolygonGeometry.setShown(1)
if(definedmode.getValue() == 1)
{if(Gov_selector.getValue() == 'Anbar'|| Gov_selector.getValue() == 'Muthanna' || Gov_selector.getValue() == 'Najaf' || Gov_selector.getValue() == 'Ninewa' || Gov_selector.getValue() == 'Thi-Qar')
{Days_selector.setValue('3')}
else{Days_selector.setValue('1')}
EPSG_number.setValue('32638')
utmzone.setValue('WGS84 \\ UTM Zone 38N')
CloudButton.setDisabled(0)}
else if(custommode.getValue() == 1)
{EPSG_number.setValue('')
utmzone.setValue('')
checkpolygon()}
var clientdate_current = new Date();
// clientdate_current.setDate(clientdate_current.getDate() - 10)
clientdate_current.setMonth(clientdate_current.getMonth() - 1);
var clientdate_befortendays = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_current = new Date();
var month = clientdate_current.getMonth();
clientdate_current.setMonth(clientdate_current.getMonth() - 1);
while (clientdate_current.getMonth() === month) {
    clientdate_current.setDate(clientdate_current.getDate() - 1)}
var clientdate_beforonemonth_1 = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_beforonemonth_2 = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(((clientdate_current.getMonth() + 1))) +'-'+clientdate_current.getFullYear())
var clientdate_beforonemonth_3 = String(((clientdate_current.getDate()))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_beforonemonth_4 = String(((clientdate_current.getDate()))+'-'+(((clientdate_current.getMonth() + 1))) +'-'+clientdate_current.getFullYear())
if (datee1.getValue() == clientdate_beforonemonth_1 || datee1.getValue() == clientdate_beforonemonth_2 || datee1.getValue() == clientdate_beforonemonth_3 || datee1.getValue() == clientdate_beforonemonth_4)
{datee1.setValue(clientdate_befortendays)}  
downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
blist.map(function(band){band.setDisabled(1)})
B1.setLabel('B1-Aerosols (60m)');
B2.setLabel('B2-Blue (10m)');
B3.setLabel('B3-Green (10m)');
B4.setLabel('B4-Red (10m)');
B5.setLabel('B5-Red Edge 1 (20m)');
B6.setLabel('B6-Red Edge 2 (20m)');
B7.setLabel('B7-Red Edge 3 (20m)');
B8.setLabel('B8-NIR (10m)');B8.style().set({shown:true});
B8A.setLabel('B8A-Red Edge 4 (20m)');B8A.style().set({shown:true});
B9.setLabel('B9-Water vapor (60m)');B9.style().set({shown:true});
B10.style().set({shown:false});B10.setValue(0);
B11.setLabel('B11-SWIR 1 (20m)');B11.style().set({shown:true});
B12.setLabel('B12-SWIR 2 (20m)');B12.style().set({shown:true});
NDMIband.setLabel('NDMI (20m)');
NDVIband.setLabel('NDVI (10m)');
NDWIband.setLabel('NDWI (10m)');
Trueband.setLabel('TrueColor (10m)');
vanishlistdem.map(function(item){
item.style().set({shown:true})
})
vanishlistws.map(function(item){
item.style().set({shown:true})
})
showlistws.map(function(item){
item.style().set({shown:false})
})
minNDMI.setValue(0) && maxNDMI.setValue(1) && minNDMI.setDisabled(1) && maxNDMI.setDisabled(1)
minNDVI.setValue(0) && maxNDVI.setValue(1) && minNDVI.setDisabled(1) && maxNDVI.setDisabled(1)
minNDWI.setValue(0) && maxNDWI.setValue(1) && minNDWI.setDisabled(1) && maxNDWI.setDisabled(1)
NDMIarea.setValue('') && NDMImean.setValue('')
NDVIarea.setValue('') && NDVImean.setValue('')
NDWIarea.setValue('') && NDWImean.setValue('')
var bb = ['Select a value']
av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
ProdButton.setDisabled(1)
datasetinfo.style().set({shown:1})
datasetinfo.setUrl('https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2_SR')
}
if(value == 's1c')
{PolygonGeometry.setShown(1)
if(definedmode.getValue() == 1)
{if(Gov_selector.getValue() == 'Anbar'|| Gov_selector.getValue() == 'Muthanna' || Gov_selector.getValue() == 'Najaf' || Gov_selector.getValue() == 'Ninewa' || Gov_selector.getValue() == 'Thi-Qar')
{Days_selector.setValue('3')}
else{Days_selector.setValue('1')}
EPSG_number.setValue('32638')
utmzone.setValue('WGS84 \\ UTM Zone 38N')
CloudButton.setDisabled(0)}
else if(custommode.getValue() == 1)
{EPSG_number.setValue('')
utmzone.setValue('')
checkpolygon()}
var clientdate_current = new Date();
// clientdate_current.setDate(clientdate_current.getDate() - 10)
clientdate_current.setMonth(clientdate_current.getMonth() - 1);
var clientdate_befortendays = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_current = new Date();
var month = clientdate_current.getMonth();
clientdate_current.setMonth(clientdate_current.getMonth() - 1);
while (clientdate_current.getMonth() === month) {
    clientdate_current.setDate(clientdate_current.getDate() - 1)}
var clientdate_beforonemonth_1 = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_beforonemonth_2 = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(((clientdate_current.getMonth() + 1))) +'-'+clientdate_current.getFullYear())
var clientdate_beforonemonth_3 = String(((clientdate_current.getDate()))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_beforonemonth_4 = String(((clientdate_current.getDate()))+'-'+(((clientdate_current.getMonth() + 1))) +'-'+clientdate_current.getFullYear())
if (datee1.getValue() == clientdate_beforonemonth_1 || datee1.getValue() == clientdate_beforonemonth_2 || datee1.getValue() == clientdate_beforonemonth_3 || datee1.getValue() == clientdate_beforonemonth_4)
{datee1.setValue(clientdate_befortendays)}  
downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
blist.map(function(band){band.setDisabled(1)})
B1.setLabel('B1-Aerosols (60m)');
B2.setLabel('B2-Blue (10m)');
B3.setLabel('B3-Green (10m)');
B4.setLabel('B4-Red (10m)');
B5.setLabel('B5-Red Edge 1 (20m)');
B6.setLabel('B6-Red Edge 2 (20m)');
B7.setLabel('B7-Red Edge 3 (20m)');
B8.setLabel('B8-NIR (10m)');B8.style().set({shown:true});
B8A.setLabel('B8A-Red Edge 4 (20m)');B8A.style().set({shown:true});
B9.setLabel('B9-Water vapor (60m)');B9.style().set({shown:true});
B10.style().set({shown:false});B10.setValue(0);
B11.setLabel('B11-SWIR 1 (20m)');B11.style().set({shown:true});
B12.setLabel('B12-SWIR 2 (20m)');B12.style().set({shown:true});
NDMIband.setLabel('NDMI (20m)');
NDVIband.setLabel('NDVI (10m)');
NDWIband.setLabel('NDWI (10m)');
Trueband.setLabel('TrueColor (10m)');
vanishlistdem.map(function(item){
item.style().set({shown:true})
})
vanishlistws.map(function(item){
item.style().set({shown:true})
})
showlistws.map(function(item){
item.style().set({shown:false})
})
minNDMI.setValue(0) && maxNDMI.setValue(1) && minNDMI.setDisabled(1) && maxNDMI.setDisabled(1)
minNDVI.setValue(0) && maxNDVI.setValue(1) && minNDVI.setDisabled(1) && maxNDVI.setDisabled(1)
minNDWI.setValue(0) && maxNDWI.setValue(1) && minNDWI.setDisabled(1) && maxNDWI.setDisabled(1)
NDMIarea.setValue('') && NDMImean.setValue('')
NDVIarea.setValue('') && NDVImean.setValue('')
NDWIarea.setValue('') && NDWImean.setValue('')
var bb = ['Select a value']
av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
ProdButton.setDisabled(1)
datasetinfo.style().set({shown:1})
datasetinfo.setUrl('https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2')
}
else if(value == 'l8')
{PolygonGeometry.setShown(1)
if(definedmode.getValue() == 1)
{if(Gov_selector.getValue() == 'Diyala'|| Gov_selector.getValue() == 'Erbil' || Gov_selector.getValue() == 'Kirkuk' || Gov_selector.getValue() == 'Kerbala' || Gov_selector.getValue() == 'Babil')
{Days_selector.setValue('1')}
else if(Gov_selector.getValue() == 'Anbar' || Gov_selector.getValue() == 'Ninewa')
{Days_selector.setValue('10')}
else{Days_selector.setValue('8')}
EPSG_number.setValue('32638')
utmzone.setValue('WGS84 \\ UTM Zone 38N')
CloudButton.setDisabled(0)}
else if(custommode.getValue() == 1)
{EPSG_number.setValue('')
utmzone.setValue('')
checkpolygon()}
var clientdate_current = new Date();
clientdate_current.setDate(clientdate_current.getDate() - 10)
var clientdate_befortendays_1 = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_befortendays_2 = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(((clientdate_current.getMonth() + 1))) +'-'+clientdate_current.getFullYear())
var clientdate_befortendays_3 = String(((clientdate_current.getDate()))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_befortendays_4 = String(((clientdate_current.getDate()))+'-'+(((clientdate_current.getMonth() + 1))) +'-'+clientdate_current.getFullYear())
var clientdate_current = new Date();
var month = clientdate_current.getMonth();
clientdate_current.setMonth(clientdate_current.getMonth() - 1);
while (clientdate_current.getMonth() === month) {
    clientdate_current.setDate(clientdate_current.getDate() - 1)}
var clientdate_beforonemonth = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
if (datee1.getValue() == clientdate_befortendays_1 || datee1.getValue() == clientdate_befortendays_2 || datee1.getValue() == clientdate_befortendays_3 || datee1.getValue() == clientdate_befortendays_4)
{datee1.setValue(clientdate_beforonemonth)}
downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
blist.map(function(band){band.setDisabled(1)})
B1.setLabel('B1-Ultra Blue (30m)');
B2.setLabel('B2-Blue (30m)');
B3.setLabel('B3-Green (30m)');
B4.setLabel('B4-Red (30m)');
B5.setLabel('B5-NIR (30m)');
B6.setLabel('B6-SWIR 1 (30m)');
B7.setLabel('B7-SWIR 2 (30m)');
B8.style().set({shown:false});B8.setValue(0);
B8A.style().set({shown:false});B8A.setValue(0);
B9.style().set({shown:false});B9.setValue(0);
B10.style().set({shown:true});
B11.style().set({shown:false});B11.setValue(0);
B12.style().set({shown:false});B12.setValue(0);
NDMIband.setLabel('NDMI (30m)');
NDVIband.setLabel('NDVI (30m)');
NDWIband.setLabel('NDWI (30m)');
Trueband.setLabel('TrueColor (30m)');
vanishlistdem.map(function(item){
item.style().set({shown:true})
})
vanishlistws.map(function(item){
item.style().set({shown:true})
})
showlistws.map(function(item){
item.style().set({shown:false})
})
minNDMI.setValue(0) && maxNDMI.setValue(1) && minNDMI.setDisabled(1) && maxNDMI.setDisabled(1)
minNDVI.setValue(0) && maxNDVI.setValue(1) && minNDVI.setDisabled(1) && maxNDVI.setDisabled(1)
minNDWI.setValue(0) && maxNDWI.setValue(1) && minNDWI.setDisabled(1) && maxNDWI.setDisabled(1)
NDMIarea.setValue('') && NDMImean.setValue('')
NDVIarea.setValue('') && NDVImean.setValue('')
NDWIarea.setValue('') && NDWImean.setValue('')
var bb = ['Select a value']
av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
ProdButton.setDisabled(1)
datasetinfo.style().set({shown:1})
datasetinfo.setUrl('https://developers.google.com/earth-engine/datasets/catalog/LANDSAT_LC08_C02_T1_L2')
}
else if(value == 'l9')
{PolygonGeometry.setShown(1)
if(definedmode.getValue() == 1)
{if(Gov_selector.getValue() == 'Diyala'|| Gov_selector.getValue() == 'Erbil' || Gov_selector.getValue() == 'Kirkuk' || Gov_selector.getValue() == 'Kerbala' || Gov_selector.getValue() == 'Babil')
{Days_selector.setValue('1')}
else if(Gov_selector.getValue() == 'Anbar' || Gov_selector.getValue() == 'Ninewa')
{Days_selector.setValue('10')}
else{Days_selector.setValue('8')}
EPSG_number.setValue('32638')
utmzone.setValue('WGS84 \\ UTM Zone 38N')
CloudButton.setDisabled(0)}
else if(custommode.getValue() == 1)
{EPSG_number.setValue('')
utmzone.setValue('')
checkpolygon()}
var clientdate_current = new Date();
clientdate_current.setDate(clientdate_current.getDate() - 10)
var clientdate_befortendays_1 = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_befortendays_2 = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(((clientdate_current.getMonth() + 1))) +'-'+clientdate_current.getFullYear())
var clientdate_befortendays_3 = String(((clientdate_current.getDate()))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_befortendays_4 = String(((clientdate_current.getDate()))+'-'+(((clientdate_current.getMonth() + 1))) +'-'+clientdate_current.getFullYear())
var clientdate_current = new Date();
var month = clientdate_current.getMonth();
clientdate_current.setMonth(clientdate_current.getMonth() - 1);
while (clientdate_current.getMonth() === month) {
    clientdate_current.setDate(clientdate_current.getDate() - 1)}
var clientdate_beforonemonth = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
if (datee1.getValue() == clientdate_befortendays_1 || datee1.getValue() == clientdate_befortendays_2 || datee1.getValue() == clientdate_befortendays_3 || datee1.getValue() == clientdate_befortendays_4)
{datee1.setValue(clientdate_beforonemonth)}
downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
blist.map(function(band){band.setDisabled(1)})
B1.setLabel('B1-Ultra Blue (30m)');
B2.setLabel('B2-Blue (30m)');
B3.setLabel('B3-Green (30m)');
B4.setLabel('B4-Red (30m)');
B5.setLabel('B5-NIR (30m)');
B6.setLabel('B6-SWIR 1 (30m)');
B7.setLabel('B7-SWIR 2 (30m)');
B8.style().set({shown:false});B8.setValue(0);
B8A.style().set({shown:false});B8A.setValue(0);
B9.style().set({shown:false});B9.setValue(0);
B10.style().set({shown:true});
B11.style().set({shown:false});B11.setValue(0);
B12.style().set({shown:false});B12.setValue(0);
NDMIband.setLabel('NDMI (30m)');
NDVIband.setLabel('NDVI (30m)');
NDWIband.setLabel('NDWI (30m)');
Trueband.setLabel('TrueColor (30m)');
vanishlistdem.map(function(item){
item.style().set({shown:true})
})
vanishlistws.map(function(item){
item.style().set({shown:true})
})
showlistws.map(function(item){
item.style().set({shown:false})
})
minNDMI.setValue(0) && maxNDMI.setValue(1) && minNDMI.setDisabled(1) && maxNDMI.setDisabled(1)
minNDVI.setValue(0) && maxNDVI.setValue(1) && minNDVI.setDisabled(1) && maxNDVI.setDisabled(1)
minNDWI.setValue(0) && maxNDWI.setValue(1) && minNDWI.setDisabled(1) && maxNDWI.setDisabled(1)
NDMIarea.setValue('') && NDMImean.setValue('')
NDVIarea.setValue('') && NDVImean.setValue('')
NDWIarea.setValue('') && NDWImean.setValue('')
var bb = ['Select a value']
av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
ProdButton.setDisabled(1)
datasetinfo.style().set({shown:0})
datasetinfo.setUrl()
}
else if(value == 'l5')
{PolygonGeometry.setShown(1)
if(definedmode.getValue() == 1)
{if(Gov_selector.getValue() == 'Diyala'|| Gov_selector.getValue() == 'Erbil' || Gov_selector.getValue() == 'Kirkuk' || Gov_selector.getValue() == 'Kerbala' || Gov_selector.getValue() == 'Babil')
{Days_selector.setValue('1')}
else if(Gov_selector.getValue() == 'Anbar' || Gov_selector.getValue() == 'Ninewa')
{Days_selector.setValue('10')}
else{Days_selector.setValue('8')}
EPSG_number.setValue('32638')
utmzone.setValue('WGS84 \\ UTM Zone 38N')
CloudButton.setDisabled(0)}
else if(custommode.getValue() == 1)
{EPSG_number.setValue('')
utmzone.setValue('')
checkpolygon()}
var clientdate_current = new Date();
clientdate_current.setDate(clientdate_current.getDate() - 10)
var clientdate_befortendays_1 = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_befortendays_2 = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(((clientdate_current.getMonth() + 1))) +'-'+clientdate_current.getFullYear())
var clientdate_befortendays_3 = String(((clientdate_current.getDate()))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
var clientdate_befortendays_4 = String(((clientdate_current.getDate()))+'-'+(((clientdate_current.getMonth() + 1))) +'-'+clientdate_current.getFullYear())
var clientdate_current = new Date();
var month = clientdate_current.getMonth();
clientdate_current.setMonth(clientdate_current.getMonth() - 1);
while (clientdate_current.getMonth() === month) {
    clientdate_current.setDate(clientdate_current.getDate() - 1)}
var clientdate_beforonemonth = String((("0" + clientdate_current.getDate()).slice(-2))+'-'+(("0" + (clientdate_current.getMonth() + 1)).slice(-2)) +'-'+clientdate_current.getFullYear())
if (datee1.getValue() == clientdate_befortendays_1 || datee1.getValue() == clientdate_befortendays_2 || datee1.getValue() == clientdate_befortendays_3 || datee1.getValue() == clientdate_befortendays_4)
{datee1.setValue(clientdate_beforonemonth)}
downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
blist.map(function(band){band.setDisabled(1)})
B1.setLabel('B1-Blue (30m)');
B2.setLabel('B2-Green (30m)');
B3.setLabel('B3-Red (30m)');
B4.setLabel('B4-NIR (30m)');
B5.setLabel('B5-SWIR 1 (30m)');
B6.setLabel('B6-Surface temperature (30m)');
B7.setLabel('B7-SWIR 2 (30m)');
B8.style().set({shown:false});B8.setValue(0);
B8A.style().set({shown:false});B8A.setValue(0);
B9.style().set({shown:false});B9.setValue(0);
B10.style().set({shown:false});
B11.style().set({shown:false});B11.setValue(0);
B12.style().set({shown:false});B12.setValue(0);
NDMIband.setLabel('NDMI (30m)');
NDVIband.setLabel('NDVI (30m)');
NDWIband.setLabel('NDWI (30m)');
Trueband.setLabel('TrueColor (30m)');
vanishlistdem.map(function(item){
item.style().set({shown:true})
})
vanishlistws.map(function(item){
item.style().set({shown:true})
})
showlistws.map(function(item){
item.style().set({shown:false})
})
minNDMI.setValue(0) && maxNDMI.setValue(1) && minNDMI.setDisabled(1) && maxNDMI.setDisabled(1)
minNDVI.setValue(0) && maxNDVI.setValue(1) && minNDVI.setDisabled(1) && maxNDVI.setDisabled(1)
minNDWI.setValue(0) && maxNDWI.setValue(1) && minNDWI.setDisabled(1) && maxNDWI.setDisabled(1)
NDMIarea.setValue('') && NDMImean.setValue('')
NDVIarea.setValue('') && NDVImean.setValue('')
NDWIarea.setValue('') && NDWImean.setValue('')
var bb = ['Select a value']
av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
ProdButton.setDisabled(1)
datasetinfo.style().set({shown:1})
datasetinfo.setUrl('https://developers.google.com/earth-engine/datasets/catalog/LANDSAT_LT05_C02_T1_L2#description')
}
else if(value == 'dem')
{PolygonGeometry.setShown(1)
  vanishlistws.map(function(item){
  item.style().set({shown:true})
  })
  showlistws.map(function(item){
  item.style().set({shown:false})
  })
  vanishlistdem.map(function(item){
  item.style().set({shown:false})
  })
  var bb = ['Select a value']
av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
  // ProdButton.setDisabled(0)
  downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
  blist.map(function(band){band.setValue(0)})
  datasetinfo.style().set({shown:1})
  datasetinfo.setUrl('https://developers.google.com/earth-engine/datasets/catalog/NASA_NASADEM_HGT_001')
  EPSG_number.setValue('4326')
  utmzone.setValue('WGS84')
  if (custommode.getValue() == 1)
  {checkpolygon()}
  else if(definedmode.getValue() == 1)
  {ProdButton.setDisabled(0)}
}
else if(value == 'ws')
{PolygonGeometry.setShown(0)
  vanishlistdem.map(function(item){
  item.style().set({shown:true})
  })
  vanishlistws.map(function(item){
  item.style().set({shown:false})
  })
  showlistws.map(function(item){
  item.style().set({shown:true})
  })
  var bb = ['Select a value']
av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
  // ProdButton.setDisabled(0)
  downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
  blist.map(function(band){band.setValue(0)})
  datasetinfo.style().set({shown:1})
  datasetinfo.setUrl('https://www.hydrosheds.org/')
  EPSG_number.setValue('4326')
  utmzone.setValue('WGS84')
}
suggestLabel.style().set({shown: false})
suggestLabel1.style().set({shown: false})
suggestLabel3.style().set({shown: false})
}})
sensor_selector.style().set({width:'145px'})
var datasetinfo = ui.Label('Dataset Info',PARAGRAPH_STYLE)
datasetinfo.setUrl('https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2_SR')
datasetinfo.style().set({margin: '8px 8px 8px 8px', fontWeight:'bold',color:'blue',shown:1})
modePanel.add(sensor_label).add(sensor_selector).add(datasetinfo)
///////////////////////////////////
////// Predefined Panel ///////
///////////////////////////////////
var hozline1 = ui.Label('____________________________________________________________________________________________________________________', LABEL_STYLE)
hozline1.style().set({stretch: 'horizontal',margin:['0px 0px 0px -15px']})
seasonPanel.add(separator1);
separator1.add(hozline1)
var definedmode = ui.Checkbox({label: 'PreDefined AOI',style:LABEL_STYLE,value: 1,
onChange:function(value){
  if(value == 0 && custommode.getValue() == 0)
  {definedmode.setValue(1)}
  if(value == 1)
  {
    if(sensor_selector.getValue() == 's2a')
      {if(Gov_selector.getValue() == 'Anbar'|| Gov_selector.getValue() == 'Muthanna' || Gov_selector.getValue() == 'Najaf' || Gov_selector.getValue() == 'Ninewa' || Gov_selector.getValue() == 'Thi-Qar')
      {Days_selector.setValue('3')}
      else{Days_selector.setValue('1')}}
    else if(sensor_selector.getValue() == 's1c')
      {if(Gov_selector.getValue() == 'Anbar'|| Gov_selector.getValue() == 'Muthanna' || Gov_selector.getValue() == 'Najaf' || Gov_selector.getValue() == 'Ninewa' || Gov_selector.getValue() == 'Thi-Qar')
      {Days_selector.setValue('3')}
      else{Days_selector.setValue('1')}}
    else if(sensor_selector.getValue() == 'l8')
      {if(Gov_selector.getValue() == 'Diyala'|| Gov_selector.getValue() == 'Erbil' || Gov_selector.getValue() == 'Kirkuk' || Gov_selector.getValue() == 'Kerbala' || Gov_selector.getValue() == 'Babil')
      {Days_selector.setValue('1')}
      else if(Gov_selector.getValue() == 'Anbar' || Gov_selector.getValue() == 'Ninewa')
      {Days_selector.setValue('10')}
      else{Days_selector.setValue('8')}}
    else if(sensor_selector.getValue() == 'l9')
      {if(Gov_selector.getValue() == 'Diyala'|| Gov_selector.getValue() == 'Erbil' || Gov_selector.getValue() == 'Kirkuk' || Gov_selector.getValue() == 'Kerbala' || Gov_selector.getValue() == 'Babil')
      {Days_selector.setValue('1')}
      else if(Gov_selector.getValue() == 'Anbar' || Gov_selector.getValue() == 'Ninewa' )
      {Days_selector.setValue('10')}
      else{Days_selector.setValue('8')}}
    CloudButton.setDisabled(0)
    polytextbox.setValue('')  
    suggestLabel3.style().set({shown: false})
    suggestLabel2.style().set({shown: false});polytextbox.setValue('')
    custommode.setValue(0)
    PolygonGeometry.setShown(0)
    Gov_selector.setDisabled(0)
    dataset_selector.setDisabled(0)
    Days_selector.setDisabled(1)
    drawapolygon.setDisabled(1)
    drawarectangle.setDisabled(1)
    AutoDetect.setDisabled(1)
    insertbutton.setDisabled(1)
    polytextbox.setDisabled(1)
    var bb = ['Select a value']
    av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
    if(sensor_selector.getValue() == 's2a' || sensor_selector.getValue() == 's1c' || sensor_selector.getValue() == 'l8' || sensor_selector.getValue() == 'l9')
    {ProdButton.setDisabled(1)}
    else if(sensor_selector.getValue() == 'dem')
    {ProdButton.setDisabled(0)}
    minNDMI.setValue(0) && maxNDMI.setValue(1) && minNDMI.setDisabled(1) && maxNDMI.setDisabled(1)
    minNDVI.setValue(0) && maxNDVI.setValue(1) && minNDVI.setDisabled(1) && maxNDVI.setDisabled(1)
    minNDWI.setValue(0) && maxNDWI.setValue(1) && minNDWI.setDisabled(1) && maxNDWI.setDisabled(1)
    NDMIarea.setValue('') && NDMImean.setValue('')
    NDVIarea.setValue('') && NDVImean.setValue('')
    NDWIarea.setValue('') && NDWImean.setValue('')
    downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
    blist.map(function(band){band.setDisabled(1)})
    var Hammar = ee.FeatureCollection("users/Yousif_Almamalachy/Hammar_Marsh_NDWI");
    var Huaizah = ee.FeatureCollection("users/Yousif_Almamalachy/Huaizah_Marsh_NDWI");
    var Iraq;
    if (dataset_selector.getValue() == 'GSA') {Iraq = ee.FeatureCollection("users/Yousif_Almamalachy/GSA");}
    else if (dataset_selector.getValue() == 'SWLRI') {Iraq = ee.FeatureCollection("users/Yousif_Almamalachy/SWLRI");}
    else if (dataset_selector.getValue() == 'UN') {Iraq = ee.FeatureCollection("users/Yousif_Almamalachy/UN");}
    var Governorate = Gov_selector.getValue()
    if(Governorate == 'Hammar Marsh')
    {aoi = Hammar}
    else if(Governorate == 'Huaizah Marsh')
    {aoi = Huaizah}
    else
    {aoi = Iraq.filter(ee.Filter.eq("ADM1_NAM", Governorate)).geometry()}
    EPSG_number.setValue('32638')
    utmzone.setValue('WGS84 \\ UTM Zone 38N')
    addgovernoratepolygon(aoi)
  }
}
})
definedmode.style().set({margin: '16px 8px 8px 8px',padding: '0px',backgroundColor: colors.transparent})
var Gov_label = ui.Label('Select a governorate of Iraq:', LABEL_STYLE)
Gov_label.style().set({margin: '8px 8px 8px 8px'})
var dataset_list = [
{label:'GSA', value:'GSA'},
{label:'SWLRI', value:'SWLRI'},
{label:'UN', value:'UN'}
];
var Iraq;
var dataset_selector = ui.Select({items: dataset_list, placeholder: 'UN',
value: 'UN', style: SELECT_STYLE,onChange:function(value){
if (value == 'GSA') {Iraq = ee.FeatureCollection("users/Yousif_Almamalachy/GSA");
var Governorate = Gov_selector.getValue();
aoi = Iraq.filter(ee.Filter.eq("ADM1_NAM", Governorate)).geometry();
addgovernoratepolygon(aoi);
datasetinfo2.setUrl('https://mowr.gov.iq/en/general-survey-authority/')
}
else if (value == 'SWLRI') {Iraq = ee.FeatureCollection("users/Yousif_Almamalachy/SWLRI");
var Governorate = Gov_selector.getValue();
aoi = Iraq.filter(ee.Filter.eq("ADM1_NAM", Governorate)).geometry();
addgovernoratepolygon(aoi);
datasetinfo2.setUrl('http://t-zero.it/en/portfolio/swlri-strategy-for-water-and-land-resources-in-iraq/')
}
else if (value == 'UN') {Iraq = ee.FeatureCollection("users/Yousif_Almamalachy/UN");
var Governorate = Gov_selector.getValue();
aoi = Iraq.filter(ee.Filter.eq("ADM1_NAM", Governorate)).geometry();
addgovernoratepolygon(aoi);
datasetinfo2.setUrl('https://developers.google.com/earth-engine/datasets/catalog/FAO_GAUL_2015_level1')
}
}})
dataset_selector.style().set({shown:false});
var Gov_list = [
{label:'Anbar', value:'Anbar'},
{label:'Babil', value:'Babil'},
{label:'Baghdad', value:'Baghdad'},
{label:'Basrah', value:'Basrah'},
{label:'Dahuk', value:'Dahuk'},
{label:'Diyala', value:'Diyala'},
{label:'Erbil', value:'Erbil'},
{label:'Kerbala', value:'Kerbala'},
{label:'Kirkuk', value:'Kirkuk'},
{label:'Missan', value:'Missan'},
{label:'Muthanna', value:'Muthanna'},
{label:'Najaf', value:'Najaf'},
{label:'Ninewa', value:'Ninewa'},
{label:'Qadissiya', value:'Qadissiya'},
{label:'Salah al-Din', value:'Salah al-Din'},
{label:'Sulaymaniyah', value:'Sulaymaniyah'},
{label:'Thi-Qar', value:'Thi-Qar'},
{label:'Wassit', value:'Wassit'}
];
var Gov_selector = ui.Select({items: Gov_list, placeholder: 'Wassit',
value: 'Wassit', style: SELECT_STYLE,onChange:function(value){
if(sensor_selector.getValue() == 's2a')
{if(value == 'Anbar'|| value == 'Muthanna' || value == 'Najaf' || value == 'Ninewa' || value == 'Thi-Qar' || value == 'Sulaymaniyah' || value == 'Baghdad')
{Days_selector.setValue('3')}
else{Days_selector.setValue('1')}}
else if(sensor_selector.getValue() == 's1c')
{if(value == 'Anbar'|| value == 'Muthanna' || value == 'Najaf' || value == 'Ninewa' || value == 'Thi-Qar' || value == 'Sulaymaniyah' || value == 'Baghdad')
{Days_selector.setValue('3')}
else{Days_selector.setValue('1')}}
else if(sensor_selector.getValue() == 'l8')
{if(value == 'Diyala' || value == 'Erbil' || value == 'Kirkuk' || value == 'Kerbala' || value == 'Babil')
{Days_selector.setValue('1')}
else if(value == 'Anbar' || value == 'Ninewa')
{Days_selector.setValue('10')}
else{Days_selector.setValue('8')}
}
else if(sensor_selector.getValue() == 'l9')
{if(value == 'Diyala'|| value == 'Erbil' || value == 'Kirkuk' || value == 'Kerbala' || value == 'Babil')
{Days_selector.setValue('1')}
else if(value == 'Anbar' || value == 'Ninewa')
{Days_selector.setValue('10')}
else{Days_selector.setValue('8')}
}
var bb = ['Select a value']
av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
if(sensor_selector.getValue() == 's2a' || sensor_selector.getValue() == 's1c' || sensor_selector.getValue() == 'l8' || sensor_selector.getValue() == 'l9')
{ProdButton.setDisabled(1)}
minNDMI.setValue(0) && maxNDMI.setValue(1) && minNDMI.setDisabled(1) && maxNDMI.setDisabled(1)
minNDVI.setValue(0) && maxNDVI.setValue(1) && minNDVI.setDisabled(1) && maxNDVI.setDisabled(1)
minNDWI.setValue(0) && maxNDWI.setValue(1) && minNDWI.setDisabled(1) && maxNDWI.setDisabled(1)
NDMIarea.setValue('') && NDMImean.setValue('')
NDVIarea.setValue('') && NDVImean.setValue('')
NDWIarea.setValue('') && NDWImean.setValue('')
downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
var Hammar = ee.FeatureCollection("users/Yousif_Almamalachy/Hammar_Marsh_NDWI");
var Huaizah = ee.FeatureCollection("users/Yousif_Almamalachy/Huaizah_Marsh_NDWI");
// var Iraq = ee.FeatureCollection("users/Yousif_Almamalachy/Iraq_Governorates_GAUL");
var Governorate = value
if(Governorate == 'Hammar Marsh')
{aoi = Hammar}
else if(Governorate == 'Huaizah Marsh')
{aoi = Huaizah}
else
{aoi = Iraq.filter(ee.Filter.eq("ADM1_NAM", Governorate)).geometry()}
addgovernoratepolygon(aoi)
}})
Gov_selector.style().set({width: '115px',margin: '8px 8px 8px 8px'})
var Hammar = ee.FeatureCollection("users/Yousif_Almamalachy/Hammar_Marsh_NDWI");
var Huaizah = ee.FeatureCollection("users/Yousif_Almamalachy/Huaizah_Marsh_NDWI");
var Iraq = ee.FeatureCollection("users/Yousif_Almamalachy/UN");
var aoi;
var Governorate = Gov_selector.getValue()
if(Governorate == 'Hammar Marsh')
{aoi = Hammar}
else if(Governorate == 'Huaizah Marsh')
{aoi = Huaizah}
else
{aoi = Iraq.filter(ee.Filter.eq("ADM1_NAM", Governorate)).geometry()}
var datasetinfo2 = ui.Label('Dataset Info',PARAGRAPH_STYLE)
datasetinfo2.setUrl('https://developers.google.com/earth-engine/datasets/catalog/FAO_GAUL_2015_level1')
datasetinfo2.style().set({margin: '8px 8px 8px 8px', fontWeight:'bold',color:'blue',whiteSpace:'nowrap',textAlign:'center'})
seasonPanel.add(predefinedPanel);
predefinedPanel.add(definedmode).add(GovPanel)
GovPanel.add(Gov_label).add(dataset_selector).add(Gov_selector).add(datasetinfo2)
///////////////////////////////////
////// Custom Panel ///////
///////////////////////////////////
var minor_hozline = ui.Label('_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _', LABEL_STYLE)
minor_hozline.style().set({fontWeight: '0',fontSize: '10px',stretch: 'horizontal',margin:['15px 0px 0px -15px'],height:'15px'})
seasonPanel.add(minor_separator);
minor_separator.add(minor_hozline)
var custommode = ui.Checkbox({label: 'Custom AOI',style:LABEL_STYLE,value: 0,
onChange:function(value){
  if(value == 0 && definedmode.getValue() == 0)
  {custommode.setValue(1)}
  if(value == 1)
  {
    clearPolygon()
    PolygonGeometry.setShown(0)
    suggestLabel3.style().set({shown: false})
    definedmode.setValue(0)
    Gov_selector.setDisabled(1)
    dataset_selector.setDisabled(1)
    Days_selector.setDisabled(1)
    AutoDetect.setDisabled(1)
    Days_selector.setValue('1')
    drawapolygon.setDisabled(0)
    drawarectangle.setDisabled(0)
    insertbutton.setDisabled(0)
    polytextbox.setDisabled(0)
    var bb = ['Select a value']
    av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
    if(sensor_selector.getValue() == 's2a' || sensor_selector.getValue() == 's1c' || sensor_selector.getValue() == 'l8' || sensor_selector.getValue() == 'l9')
    {ProdButton.setDisabled(1);CloudButton.setDisabled(1);checkpolygon()}
    else if(sensor_selector.getValue() == 'dem')
    {ProdButton.setDisabled(1);checkpolygon()}
    minNDMI.setValue(0) && maxNDMI.setValue(1) && minNDMI.setDisabled(1) && maxNDMI.setDisabled(1)
    minNDVI.setValue(0) && maxNDVI.setValue(1) && minNDVI.setDisabled(1) && maxNDVI.setDisabled(1)
    minNDWI.setValue(0) && maxNDWI.setValue(1) && minNDWI.setDisabled(1) && maxNDWI.setDisabled(1)
    NDMIarea.setValue('') && NDMImean.setValue('')
    NDVIarea.setValue('') && NDVImean.setValue('')
    NDWIarea.setValue('') && NDWImean.setValue('')
    downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
    blist.map(function(band){band.setDisabled(1)})
  }
}
})
custommode.style().set({margin: '16px 8px 8px 8px',padding: '0px',backgroundColor: colors.transparent})
var drawapolygon = ui.Button({
      label: symbol.polygon + ' Draw a Polygon',
      onClick: drawPolygon,
      style: {width: '115px',margin:'8px 8px 8px 15px'},
      disabled : 1
    })
var drawarectangle = ui.Button({
      label: symbol.rectangle + ' Draw a Rectangle',
      onClick: drawRectangle,
      style: {width: '115px',margin:'8px 8px 8px 15px'},
      disabled : 1
    })
var suggestLabel2 = ui.Label('Hint: GeoJSON should be in WGS84 and \n preferably contain one polygon only.', BUTTON_STYLE)
suggestLabel2.style().set({shown: false,color:'#41ab5d', whiteSpace: 'pre', 
textAlign: 'left',fontSize: '12px',fontWeight: 'bold',margin: ['10px 8px 8px 8px'],height:'28px'})
var suggestLabel4 = ui.Label('Uploading... please wait.', BUTTON_STYLE)
suggestLabel4.style().set({shown: false,color:'4daf4a', whiteSpace: 'pre', 
textAlign: 'left',fontSize: '12px',fontWeight: 'bold',margin: ['10px 8px 8px 8px'],height:'28px'})
var poly_label = ui.Label('Insert GeoJSON Text →', LABEL_STYLE)
inputpolygon.insert(1, poly_label)
var polytextbox = ui.Textbox({value: '',disabled: 1,style: TEXTBOX_STYLE})
polytextbox.style().set({width: '240px',margin:'8px 8px 8px -3px'})
inputpolygon.insert(2, polytextbox)
var insertbutton = ui.Button({
      label: 'Upload GeoJSON',
      onClick: addpoly,
      disabled: 1,
      style: {width: '100px',margin:'8px 0px 8px -3px'}
    })
drawpolygonPanel.add(drawapolygon).add(drawarectangle).add(suggestLabel2).add(suggestLabel4)
JsonPanel.add(poly_label).add(polytextbox).add(insertbutton)
customPanel.add(custommode).add(drawpolygonPanel).add(JsonPanel)
seasonPanel.add(customPanel);
////////////////////////////////////////
////// Cloud Percentage Selector ///////
////////////////////////////////////////
var hozline2 = ui.Label('____________________________________________________________________________________________________________________', LABEL_STYLE)
hozline2.style().set({stretch: 'horizontal',margin:['0px 0px 0px -15px']})
seasonPanel.add(separator2);
separator2.add(hozline2)
var Cloud_label = ui.Label('Allowed Cloud Coverage (%):', LABEL_STYLE)
Cloud_label.style().set({margin: '8px 8px 8px 8px'})
var Cloud_selector = ui.Textbox({value: "100", onChange:function(value){
if(parseFloat(value) < 0)
{Cloud_selector.setValue('0')}
if(parseFloat(value) > 100)
{Cloud_selector.setValue('100')}
if(isNaN(value))
{Cloud_selector.setValue('5')}
if(countDecimals(parseFloat(value)) > 2)
{Cloud_selector.setValue(Math.floor(parseFloat(value) * 100) / 100)}
}
,style: TEXTBOX_STYLE})
var Cloud_style = Cloud_selector.style();
Cloud_style.set({width:'50px',margin: '8px 8px 8px 8px',textAlign : 'center'}); //bottom left up right
/////////////////////////////////////
////// Coverage Days Selector ///////
/////////////////////////////////////
var Days_label = ui.Label('Coverage Days:', LABEL_STYLE)
Days_label.style().set({margin: '8px 8px 8px 8px'})
var Days_selector = ui.Textbox({value: "1", onChange:function(value){
if(parseFloat(value) < 1)
{Days_selector.setValue('1')}
if(isNaN(value))
{Days_selector.setValue('1')}
if(countDecimals(parseFloat(value)) > 0)
{Days_selector.setValue(parseInt(value))}
suggestLabel3.style().set({shown: false})
}
,style: TEXTBOX_STYLE})
var Days_style = Days_selector.style();
Days_style.set({width:'50px',margin: '8px 8px 8px 8px',textAlign : 'center'}); //bottom left up right
Days_selector.setDisabled(1)
var AutoDetect = ui.Button({label: 'Auto Detect', 
style:BUTTON_STYLE,
disabled: 1,
onClick:function() {
  if (polygonisdrawn == true)
  {AutoDetect.setDisabled(1)
  sensor_selector.setDisabled(1)
  insertbutton.setDisabled(1)
  drawapolygon.setDisabled(1)
  drawarectangle.setDisabled(1)
  custommode.setDisabled(1)
  definedmode.setDisabled(1)
  Days_selector.setDisabled(1)
  CloudButton.setDisabled(1)
  ProdButton.setDisabled(1)
  Days_selector.setValue('')
  suggestLabel3.style().set({shown: false})
  loading1.style().set({shown: true})
  var starttime = (new Date().getTime()) / 1000
  if(sensor_selector.getValue() == 's2a')
  {s2aCdaysCheck().evaluate(function(val){
    var currenttime = (new Date().getTime()) / 1000
    if (currenttime - starttime >= 300)
    { Days_selector.setValue('1')
      loading1.style().set({shown: false})
      suggestLabel3.style().set({shown: true})}
    Days_selector.setValue(val)
    AutoDetect.setDisabled(0)
    sensor_selector.setDisabled(0)
    insertbutton.setDisabled(0)
    drawapolygon.setDisabled(0)
    drawarectangle.setDisabled(0)
    Days_selector.setDisabled(0)
    CloudButton.setDisabled(0)
    custommode.setDisabled(0)
    definedmode.setDisabled(0)
    loading1.style().set({shown: false})
  })}
  else if(sensor_selector.getValue() == 's1c')
  {s1cCdaysCheck().evaluate(function(val){
    var currenttime = (new Date().getTime()) / 1000
    if (currenttime - starttime >= 300)
    { Days_selector.setValue('1')
      loading1.style().set({shown: false})
      suggestLabel3.style().set({shown: true})}
    Days_selector.setValue(val)
    AutoDetect.setDisabled(0)
    sensor_selector.setDisabled(0)
    insertbutton.setDisabled(0)
    drawapolygon.setDisabled(0)
    drawarectangle.setDisabled(0)
    Days_selector.setDisabled(0)
    CloudButton.setDisabled(0)
    custommode.setDisabled(0)
    definedmode.setDisabled(0)
    loading1.style().set({shown: false})
  })}
  else if(sensor_selector.getValue() == 'l8')
  {l8CdaysCheck().evaluate(function(val){
    var currenttime = (new Date().getTime()) / 1000
    if (currenttime - starttime >= 300)
    { Days_selector.setValue('1')
      loading1.style().set({shown: false})
      suggestLabel3.style().set({shown: true})}
    Days_selector.setValue(val)
    AutoDetect.setDisabled(0)
    sensor_selector.setDisabled(0)
    insertbutton.setDisabled(0)
    drawapolygon.setDisabled(0)
    drawarectangle.setDisabled(0)
    Days_selector.setDisabled(0)
    CloudButton.setDisabled(0)
    custommode.setDisabled(0)
    definedmode.setDisabled(0)
    loading1.style().set({shown: false})
  })}
  else if(sensor_selector.getValue() == 'l9')
  {l9CdaysCheck().evaluate(function(val){
    var currenttime = (new Date().getTime()) / 1000
    if (currenttime - starttime >= 300)
    { Days_selector.setValue('1')
      loading1.style().set({shown: false})
      suggestLabel3.style().set({shown: true})}
    Days_selector.setValue(val)
    AutoDetect.setDisabled(0)
    sensor_selector.setDisabled(0)
    insertbutton.setDisabled(0)
    drawapolygon.setDisabled(0)
    drawarectangle.setDisabled(0)
    Days_selector.setDisabled(0)
    CloudButton.setDisabled(0)
    custommode.setDisabled(0)
    definedmode.setDisabled(0)
    loading1.style().set({shown: false})
  })}
  else if(sensor_selector.getValue() == 'l5')
  {l5CdaysCheck().evaluate(function(val){
    var currenttime = (new Date().getTime()) / 1000
    if (currenttime - starttime >= 300)
    { Days_selector.setValue('1')
      loading1.style().set({shown: false})
      suggestLabel3.style().set({shown: true})}
    Days_selector.setValue(val)
    AutoDetect.setDisabled(0)
    sensor_selector.setDisabled(0)
    insertbutton.setDisabled(0)
    drawapolygon.setDisabled(0)
    drawarectangle.setDisabled(0)
    Days_selector.setDisabled(0)
    CloudButton.setDisabled(0)
    custommode.setDisabled(0)
    definedmode.setDisabled(0)
    loading1.style().set({shown: false})
  })}
  }  
}
})
AutoDetect.style().set({margin:'0px 8px 8px 8px'})
var suggestLabel3 = ui.Label('Google earth engine server limitation \n exceeded. Try reducing AOI area.', BUTTON_STYLE)
suggestLabel3.style().set({shown: false,color:'#ef3b2c', whiteSpace: 'pre', 
textAlign: 'left',fontSize: '12px',fontWeight: 'bold'})
var loading1 = ui.Label('Loading...', LABEL_STYLE)
loading1.style().set({margin:'8px 8px 8px 8px',backgroundColor: colors.transparent, color:'4daf4a'})
loading1.style().set({shown: false})
// GovPanel.add(Gov_label).add(Gov_selector)
CloudPanel.add(Cloud_label).add(Cloud_selector)
DaysPanel.add(Days_label).add(Days_selector).add(AutoDetect).add(loading1).add(suggestLabel3)
visPanel.add(CloudPanel)
visPanel.add(DaysPanel)
seasonPanel.add(visPanel)
/////////////////////////////
////// Date Selector ///////
///////////////////////////
var now = ee.Date(Date.now()).advance(-1,'month').format('dd-MM-YYYY').getInfo();
var dd1 = ui.Label('Date 1', LABEL_STYLE)
dd1.style().set({margin: '55px 8px 8px 8px'})
var date1format = ui.Label('DD-MM-YYYY', LABEL_STYLE)
date1format.style().set({margin: '25px 8px 8px 8px'})
var datee1 = ui.Textbox({value: now, onChange:function(value){
if(value.indexOf("/") !== -1)
{datee1.setValue(value.split('/').join('-'))}
if(value.indexOf("\\") !== -1)
{datee1.setValue(value.split('\\').join('-'))}
else if(value.indexOf(" ") !== -1)
{datee1.setValue(value.split(' ').join('-'))}
else if(!value.match(/^\d/) || !value.match(/\d$/) )
{datee1.setValue(now)}
else if(isNaN(Date.parse(getdate(value))))
{datee1.setValue(now)}
else if(Date.parse(getdate(value)) >= Date.parse(getdate(datee2.getValue())))
{datee1.setValue(ee.Date(getdate(datee2.getValue())).advance(-1,'day').format('dd-MM-YYYY').getInfo())}
}
,style: TEXTBOX_STYLE})
datee1.style().set({margin: '-10px 8px 8px 8px'})
var noww = ee.Date(Date.now()).format('dd-MM-YYYY').getInfo();
var dd2 = ui.Label('Date 2', LABEL_STYLE)
dd2.style().set({margin: '55px 8px 8px 100px'})
var date2format = ui.Label('DD-MM-YYYY', LABEL_STYLE)
date2format.style().set({margin: '25px 8px 8px 8px'})
var datee2 = ui.Textbox({value: noww, onChange:function(value){
if(value.indexOf("/") !== -1)
{datee2.setValue(value.split('/').join('-'))}
if(value.indexOf("\\") !== -1)
{datee2.setValue(value.split('\\').join('-'))}
else if(value.indexOf(" ") !== -1)
{datee2.setValue(value.split(' ').join('-'))}
else if(!value.match(/^\d/) || !value.match(/\d$/) )
{datee2.setValue(noww)}
else if(isNaN(Date.parse(getdate(value))))
{datee2.setValue(noww)}
else if(Date.parse(getdate(value)) <= Date.parse(getdate(datee1.getValue())))
{datee2.setValue(ee.Date(getdate(datee1.getValue())).advance(1,'day').format('dd-MM-YYYY').getInfo())}
}
,style: TEXTBOX_STYLE})
datee2.style().set({margin: '-10px 8px 8px 8px'})
date1labelPanel.add(dd1)
date1Panel.add(date1format).add(datee1)
date2labelPanel.add(dd2)
date2Panel.add(date2format).add(datee2)
datePanel.add(date1labelPanel).add(date1Panel).add(date2labelPanel).add(date2Panel)
datePanel.style().set({margin: '-10px 8px 8px 8px'})
seasonPanel.add(datePanel)
/////////////////////////////////
////// Check dates panel ///////
////////////////////////////////
var hozline3 = ui.Label('____________________________________________________________________________________________________________________', LABEL_STYLE)
hozline3.style().set({stretch: 'horizontal',margin:['0px 0px 0px -15px']})
seasonPanel.add(separator3);
separator3.add(hozline3)
var CloudButton = ui.Button({label: 'Check available dates', 
style:BUTTON_STYLE,
onClick:function() {
  var cc = ['Select a value...']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(cc) && av_dates.setValue(cc[0])
  && av_dates.setPlaceholder(cc[0]) && Gov_selector.setDisabled(1) && dataset_selector.setDisabled(1)
  && Days_selector.setDisabled(1) && Cloud_selector.setDisabled(1)
  && definedmode.setDisabled(1) && custommode.setDisabled(1)
  && datee1.setDisabled(1) && datee2.setDisabled(1) && AutoDetect.setDisabled(1)
  CloudButton.setDisabled(1)
  drawapolygon.setDisabled(1)
  drawarectangle.setDisabled(1)
  sensor_selector.setDisabled(1)
  sourcedates = []
  sourcedatesbox.setValue(sourcedates)
  var starttime = (new Date().getTime()) / 1000
  var proceed = true;
loading.style().set({shown: true})
suggestLabel.style().set({shown: false})
suggestLabel1.style().set({shown: false})
  var date1 = getdate(datee1.getValue())
  var date2 = getdate(datee2.getValue())
  var CloudC = ee.Number.parse(Cloud_selector.getValue())
  var CDays = ee.Number.parse(Days_selector.getValue())
  var aa = [];
  if(sensor_selector.getValue() == 's2a')
  {s2acloud(date1,date2,aoi,CloudC,CDays).evaluate(function(val){
  var currenttime = (new Date().getTime()) / 1000
  if (currenttime - starttime >= 300)
  {var bb = ['Time Out']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(bb) && av_dates.setValue(bb[0])
  && av_dates.setPlaceholder(bb[0]) 
  && suggestLabel1.style().set({shown: true})
  proceed = false
  }
  if (val != null)
  {val.forEach(function(i) {
    aa.push(i)})};
  if (aa.length == 0 && proceed == true)
  {
  var bb = ['Non!']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(bb) && av_dates.setValue(bb[0])
  && av_dates.setPlaceholder(bb[0]) 
  && suggestLabel.style().set({shown: true})
  }
  else if(proceed == true) {
  av_dates.setDisabled(0) && ProdButton.setDisabled(0) 
  && av_dates.items().reset(aa) 
  && av_dates.setValue(aa[aa.length - 1])&& av_dates.setPlaceholder(aa[aa.length - 1]) 
  && suggestLabel.style().set({shown: false})
  }
  loading.style().set({shown: false})
  sensor_selector.setDisabled(0)
  if(definedmode.getValue() == 1)
  {Gov_selector.setDisabled(0);dataset_selector.setDisabled(0)}
  Cloud_selector.setDisabled(0)
  definedmode.setDisabled(0) && custommode.setDisabled(0)
  && datee1.setDisabled(0) && datee2.setDisabled(0)
  CloudButton.setDisabled(0)
  if(custommode.getValue() == 1)
  {
  Days_selector.setDisabled(0)
  drawapolygon.setDisabled(0)
  drawarectangle.setDisabled(0)
  AutoDetect.setDisabled(0)
  }
  })}
  if(sensor_selector.getValue() == 's1c')
  {s1ccloud(date1,date2,aoi,CloudC,CDays).evaluate(function(val){
  var currenttime = (new Date().getTime()) / 1000
  if (currenttime - starttime >= 300)
  {var bb = ['Time Out']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(bb) && av_dates.setValue(bb[0])
  && av_dates.setPlaceholder(bb[0]) 
  && suggestLabel1.style().set({shown: true})
  proceed = false
  }
  if (val != null)
  {val.forEach(function(i) {
    aa.push(i)})};
  if (aa.length == 0 && proceed == true)
  {
  var bb = ['Non!']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(bb) && av_dates.setValue(bb[0])
  && av_dates.setPlaceholder(bb[0]) 
  && suggestLabel.style().set({shown: true})
  }
  else if(proceed == true) {
  av_dates.setDisabled(0) && ProdButton.setDisabled(0) 
  && av_dates.items().reset(aa) 
  && av_dates.setValue(aa[aa.length - 1])&& av_dates.setPlaceholder(aa[aa.length - 1]) 
  && suggestLabel.style().set({shown: false})
  }
  loading.style().set({shown: false})
  sensor_selector.setDisabled(0)
  if(definedmode.getValue() == 1)
  {Gov_selector.setDisabled(0);dataset_selector.setDisabled(0)}
  Cloud_selector.setDisabled(0)
  definedmode.setDisabled(0) && custommode.setDisabled(0)
  && datee1.setDisabled(0) && datee2.setDisabled(0)
  CloudButton.setDisabled(0)
  if(custommode.getValue() == 1)
  {
  Days_selector.setDisabled(0)
  drawapolygon.setDisabled(0)
  drawarectangle.setDisabled(0)
  AutoDetect.setDisabled(0)
  }
  })}
  else if(sensor_selector.getValue() == 'l8')
  {l8cloud(date1,date2,aoi,CloudC,CDays).evaluate(function(val){
  var currenttime = (new Date().getTime()) / 1000
  if (currenttime - starttime >= 300)
  {var bb = ['Time Out']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(bb) && av_dates.setValue(bb[0])
  && av_dates.setPlaceholder(bb[0]) 
  && suggestLabel1.style().set({shown: true})
  proceed = false
  }
  if (val != null)
  {val.forEach(function(i) {
    aa.push(i)})};
  if (aa.length == 0 && proceed == true)
  {
  var bb = ['Non!']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(bb) && av_dates.setValue(bb[0])
  && av_dates.setPlaceholder(bb[0]) 
  && suggestLabel.style().set({shown: true})
  }
  else if(proceed == true) {
  av_dates.setDisabled(0) && ProdButton.setDisabled(0) 
  && av_dates.items().reset(aa) 
  && av_dates.setValue(aa[aa.length - 1])&& av_dates.setPlaceholder(aa[aa.length - 1]) 
  && suggestLabel.style().set({shown: false})
  }
  loading.style().set({shown: false})
  sensor_selector.setDisabled(0)
  if(definedmode.getValue() == 1)
  {Gov_selector.setDisabled(0);dataset_selector.setDisabled(0)}
  Cloud_selector.setDisabled(0)
  && definedmode.setDisabled(0) && custommode.setDisabled(0)
  && datee1.setDisabled(0) && datee2.setDisabled(0)
  CloudButton.setDisabled(0)
  if(custommode.getValue() == 1)
  {
  Days_selector.setDisabled(0)
  drawapolygon.setDisabled(0)
  drawarectangle.setDisabled(0)
  AutoDetect.setDisabled(0)
  }
  })}
  else if(sensor_selector.getValue() == 'l9')
  {l9cloud(date1,date2,aoi,CloudC,CDays).evaluate(function(val){
  var currenttime = (new Date().getTime()) / 1000
  if (currenttime - starttime >= 300)
  {var bb = ['Time Out']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(bb) && av_dates.setValue(bb[0])
  && av_dates.setPlaceholder(bb[0]) 
  && suggestLabel1.style().set({shown: true})
  proceed = false
  }
  if (val != null)
  {val.forEach(function(i) {
    aa.push(i)})};
  if (aa.length == 0 && proceed == true)
  {
  var bb = ['Non!']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(bb) && av_dates.setValue(bb[0])
  && av_dates.setPlaceholder(bb[0]) 
  && suggestLabel.style().set({shown: true})
  }
  else if(proceed == true) {
  av_dates.setDisabled(0) && ProdButton.setDisabled(0) 
  && av_dates.items().reset(aa) 
  && av_dates.setValue(aa[aa.length - 1])&& av_dates.setPlaceholder(aa[aa.length - 1]) 
  && suggestLabel.style().set({shown: false})
  }
  loading.style().set({shown: false})
  sensor_selector.setDisabled(0)
  if(definedmode.getValue() == 1)
  {Gov_selector.setDisabled(0);dataset_selector.setDisabled(0)}
  Cloud_selector.setDisabled(0)
  && definedmode.setDisabled(0) && custommode.setDisabled(0)
  && datee1.setDisabled(0) && datee2.setDisabled(0)
  CloudButton.setDisabled(0)
  if(custommode.getValue() == 1)
  {
  Days_selector.setDisabled(0)
  drawapolygon.setDisabled(0)
  drawarectangle.setDisabled(0)
  AutoDetect.setDisabled(0)
  }
  })}
  else if(sensor_selector.getValue() == 'l5')
  {l5cloud(date1,date2,aoi,CloudC,CDays).evaluate(function(val){
  var currenttime = (new Date().getTime()) / 1000
  if (currenttime - starttime >= 300)
  {var bb = ['Time Out']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(bb) && av_dates.setValue(bb[0])
  && av_dates.setPlaceholder(bb[0]) 
  && suggestLabel1.style().set({shown: true})
  proceed = false
  }
  if (val != null)
  {val.forEach(function(i) {
    aa.push(i)})};
  if (aa.length == 0 && proceed == true)
  {
  var bb = ['Non!']
  av_dates.setDisabled(1) && ProdButton.setDisabled(1) 
  && av_dates.items().reset(bb) && av_dates.setValue(bb[0])
  && av_dates.setPlaceholder(bb[0]) 
  && suggestLabel.style().set({shown: true})
  }
  else if(proceed == true) {
  av_dates.setDisabled(0) && ProdButton.setDisabled(0) 
  && av_dates.items().reset(aa) 
  && av_dates.setValue(aa[aa.length - 1])&& av_dates.setPlaceholder(aa[aa.length - 1]) 
  && suggestLabel.style().set({shown: false})
  }
  loading.style().set({shown: false})
  sensor_selector.setDisabled(0)
  if(definedmode.getValue() == 1)
  {Gov_selector.setDisabled(0);dataset_selector.setDisabled(0)}
  Cloud_selector.setDisabled(0)
  && definedmode.setDisabled(0) && custommode.setDisabled(0)
  && datee1.setDisabled(0) && datee2.setDisabled(0)
  CloudButton.setDisabled(0)
  if(custommode.getValue() == 1)
  {
  Days_selector.setDisabled(0)
  drawapolygon.setDisabled(0)
  drawarectangle.setDisabled(0)
  AutoDetect.setDisabled(0)
  }
  })}
}
})
CloudButton.style().set({margin:'50px 8px 8px 8px'})
var availabeldates = ui.Label('Available Dates:', LABEL_STYLE);
availabeldates.style().set({margin:'55px 8px 8px 12px',backgroundColor: colors.transparent})
var av_dates_description = ui.Label('Date (Cloud %)', LABEL_STYLE);
av_dates_description.style().set({margin:'55px 8px 8px 23px'})
var arabic_date;
var english_date;
var av_dates = ui.Select({placeholder: "",style: SELECT_STYLE,
onChange:function(){
arabic_date = getdate(getdate(av_dates.getValue()))
english_date = getdate(av_dates.getValue())
loading.style().set({shown: false})
}});
av_dates.setDisabled(1)
av_dates.style().set({margin:'-10px 8px 8px 8px',width:'136px'})
// var arabic_date = getdate(getdate(av_dates.getValue()))
// var english_date = getdate(av_dates.getValue())
var loading = ui.Label('Loading...', LABEL_STYLE)
loading.style().set({margin:'57px 8px 8px 0px',backgroundColor: colors.transparent,color:'4daf4a'})
loading.style().set({shown: false})
checkPanel.add(CloudButton)
checkPanel.add(availabeldates)
checkPanel.add(av_datesPanel)
av_datesPanel.style().set({margin:'-30px 8px 8px -12px'})
av_datesPanel.add(av_dates_description)
av_datesPanel.add(av_dates)
checkPanel.add(loading)
seasonPanel.add(checkPanel)
////////////////////////////
////// Results Panel ///////
////////////////////////////
var vars = [];
var legendisdrawn = false;
var ProdButton = ui.Button({label: 'Show Results', 
style:BUTTON_STYLE,onClick:function() {
  clearmap()
  PolygonGeometry.setShown(0)
  inspectpoint.setDisabled(0)
  if(legendisdrawn == false)
  {
  verticalcolorbar('NDWI',NDWI_visualization)
  verticalcolorbar('NDVI',NDVI_visualization)
  verticalcolorbar('NDMI',NDMI_visualization)
  verticalcolorbar('DEM (m)',elev_visualization)
  legendisdrawn = true
  }
  if(custommode.getValue() == 1)
  {PolygonGeometry.setShown(0)}
  var date3;
  var CloudC;
  var CDays;
  if(sensor_selector.getValue() == 's2a' || sensor_selector.getValue() == 's1c' || sensor_selector.getValue() == 'l8' || sensor_selector.getValue() == 'l9' || sensor_selector.getValue() == 'l5' || sensor_selector.getValue() == 'dem'){
  date3 = ee.Date(english_date)
  CloudC = ee.Number.parse(Cloud_selector.getValue())
  CDays = ee.Number.parse(Days_selector.getValue())
  NDMIarea.setValue('') && NDMImean.setValue('')
  NDVIarea.setValue('') && NDVImean.setValue('')
  NDWIarea.setValue('') && NDWImean.setValue('')
  minNDMI.setValue(0);maxNDMI.setValue(1)
  minNDVI.setValue(0);maxNDVI.setValue(1)
  minNDWI.setValue(0);maxNDWI.setValue(1)
  minNDMI.setDisabled(0);minNDVI.setDisabled(0);minNDWI.setDisabled(0);
  maxNDMI.setDisabled(0);maxNDVI.setDisabled(0);maxNDWI.setDisabled(0);
  downtext.setDisabled(0);downtext.setValue('')
  X_coord.setDisabled(0);Y_coord.setDisabled(0);inspectbutton.setDisabled(0);
  // downloadtrue.setDisabled(0);downloadNDMI.setDisabled(0);downloadNDVI.setDisabled(0);downloadNDWI.setDisabled(0)
  // downtext.setDisabled(0);EPSG_number.setDisabled(0)
  blist.map(function(band){band.setDisabled(0);checkbandsSelection()})
  }
  if(sensor_selector.getValue() == 's2a')
  {return vars  = s2aproduction(date3,aoi,CDays,mappingPanel,minNDMI.getValue(),
  maxNDMI.getValue(),minNDVI.getValue(),maxNDVI.getValue(),
  minNDWI.getValue(),maxNDWI.getValue())}
  else if(sensor_selector.getValue() == 's1c')
  {return vars  = s1cproduction(date3,aoi,CDays,mappingPanel,minNDMI.getValue(),
  maxNDMI.getValue(),minNDVI.getValue(),maxNDVI.getValue(),
  minNDWI.getValue(),maxNDWI.getValue())}
  else if(sensor_selector.getValue() == 'l8')
  {return vars  = l8production(date3,aoi,CDays,mappingPanel,minNDMI.getValue(),
  maxNDMI.getValue(),minNDVI.getValue(),maxNDVI.getValue(),
  minNDWI.getValue(),maxNDWI.getValue())}
  else if(sensor_selector.getValue() == 'l9')
  {return vars  = l9production(date3,aoi,CDays,mappingPanel,minNDMI.getValue(),
  maxNDMI.getValue(),minNDVI.getValue(),maxNDVI.getValue(),
  minNDWI.getValue(),maxNDWI.getValue())}
  else if(sensor_selector.getValue() == 'l5')
  {return vars  = l5production(date3,aoi,CDays,mappingPanel,minNDMI.getValue(),
  maxNDMI.getValue(),minNDVI.getValue(),maxNDVI.getValue(),
  minNDWI.getValue(),maxNDWI.getValue())}
  else if(sensor_selector.getValue() == 'dem')
  {checkbandsSelection();return vars  = demproduction(aoi)}
}
})
ProdButton.setDisabled(1)
var suggestLabel = ui.Label('Try changing "Allowed Cloud Coverage (%)", Date Range \n or Coverage days (when permitted).', BUTTON_STYLE)
suggestLabel.style().set({shown: false,color:'#ef3b2c', whiteSpace: 'pre', 
textAlign: 'left',fontSize: '12px',fontWeight: 'bold'})
var suggestLabel1 = ui.Label('Google earth engine server limitation exceeded. \n Try reducing AOI or Date Range.', BUTTON_STYLE)
suggestLabel1.style().set({shown: false,color:'#ef3b2c', whiteSpace: 'pre', 
textAlign: 'left',fontSize: '12px',fontWeight: 'bold'})
var sourcedateslabel = ui.Label('Image Date:', LABEL_STYLE);
sourcedateslabel.style().set({margin:'0px 8px -8px 8px'})
var sourcedatesbox = ui.Label({value: "",style: TEXTBOX_STYLE})
sourcedatesbox.style().set({margin:'8px 8px 8px 15px',width: '500px',height:'50px',whiteSpace: 'normal',border: 'inset'})
seasonPanel.add(downPanel)
downPanel.add(ProdButton)
downPanel.add(suggestLabel)
downPanel.add(suggestLabel1)
seasonPanel.add(sourcedatesPanel)
sourcedatesPanel.add(sourcedateslabel).add(sourcedatesbox);
var hozline4 = ui.Label('____________________________________________________________________________________________________________________', LABEL_STYLE)
hozline4.style().set({stretch: 'horizontal',margin:['0px 0px 0px -15px']})
seasonPanel.add(separator4);
separator4.add(hozline4)
var Autozoom = ui.Checkbox('Auto Zoom',1)
Autozoom.style().set({margin: '8px 8px 8px 8px',padding: '0px',backgroundColor: colors.transparent})
areatitlePanel.add(Autozoom)
var meantitle = ui.Label('Mean:', LABEL_STYLE)
meantitle.style().set({margin: '8px 0px 8px 260px',padding: '0px'})
areatitlePanel.add(meantitle)
var areatitle = ui.Label('Area (KM²)', LABEL_STYLE)
areatitle.style().set({margin: '8px 0px 8px 23px',padding: '0px'})
areatitlePanel.add(areatitle)
seasonPanel.add(areatitlePanel);
///////////////////////////////////
////// Modification Section ///////
///////////////////////////////////
seasonPanel.add(NDMIsliderPanel);
NDMIsliderPanel.insert(1, ui.Label('NDMI Value:', LABEL_STYLE))
var minNDMI = ui.Textbox({value: "0", onChange:function(value){
if(parseFloat(value) < 0)
{minNDMI.setValue('0')}
if(parseFloat(value) > 1)
{minNDMI.setValue('1')}
if(isNaN(value))
{minNDMI.setValue('0')}
if(parseFloat(value) >= maxNDMI.getValue())
{minNDMI.setValue((parseFloat(value) -0.01).toString())}
if(countDecimals(parseFloat(value)) > 2)
{minNDMI.setValue(Math.floor(parseFloat(value) * 100) / 100)}
updateNDMI(parseFloat(value),parseFloat(maxNDMI.getValue()))
NDMIarea.setValue('')
NDMImean.setValue('')
updateNDMIstats()[1].evaluate(function(val){NDMImean.setValue(val)})
updateNDMIstats()[0].evaluate(function(val){NDMIarea.setValue(val)})
}
,style: TEXTBOX_STYLE})
minNDMI.setDisabled(1)
minNDMI.style().set({width:'50px',textAlign : 'center'})
var maxNDMI = ui.Textbox({value: "1", onChange:function(value){
if(parseFloat(value) < 0)
{maxNDMI.setValue('0')}
if(parseFloat(value) > 1)
{maxNDMI.setValue('1')}
if(isNaN(value))
{maxNDMI.setValue('1')}
if(parseFloat(value) <= minNDMI.getValue())
{maxNDMI.setValue((parseFloat(value) +0.01).toString())}
if(countDecimals(parseFloat(value)) > 2)
{maxNDMI.setValue(Math.floor(parseFloat(value) * 100) / 100)}
updateNDMI(parseFloat(minNDMI.getValue()),parseFloat(value))
NDMIarea.setValue('')
NDMImean.setValue('')
updateNDMIstats()[1].evaluate(function(val){NDMImean.setValue(val)})
updateNDMIstats()[0].evaluate(function(val){NDMIarea.setValue(val)})
}
,style: TEXTBOX_STYLE})
maxNDMI.setDisabled(1)
maxNDMI.style().set({width:'50px',textAlign : 'center'})
NDMIsliderPanel.insert(2, ui.Label('Min', LABEL_STYLE))
NDMIsliderPanel.insert(3, minNDMI)
NDMIsliderPanel.insert(4, ui.Label('Max', LABEL_STYLE))
NDMIsliderPanel.insert(5, maxNDMI)
var NDMIarea = ui.Label('', LABEL_STYLE)
var NDMImean = ui.Label('', LABEL_STYLE)
NDMImean.style().set({padding: '8px',width: '42px'});
NDMIsliderPanel.insert(6, NDMImean)
NDMIsliderPanel.insert(7, NDMIarea)
//////////////////////////////
//////////////////////////////
//////////////////////////////
seasonPanel.add(NDVIsliderPanel);
var ndlabel = ui.Label('NDVI Value:', LABEL_STYLE)
ndlabel.style().set({padding: '10px',textAlign:'left'})
NDVIsliderPanel.insert(1, ndlabel)
var minNDVI = ui.Textbox({value: "0", onChange:function(value){
if(parseFloat(value) < 0)
{minNDVI.setValue('0')}
if(parseFloat(value) > 1)
{minNDVI.setValue('1')}
if(isNaN(value))
{minNDVI.setValue('0')}
if(parseFloat(value) >= maxNDVI.getValue())
{minNDVI.setValue((parseFloat(value) -0.01).toString())}
if(countDecimals(parseFloat(value)) > 2)
{minNDVI.setValue(Math.floor(parseFloat(value) * 100) / 100)}
updateNDVI(parseFloat(value),parseFloat(maxNDVI.getValue()))
NDVIarea.setValue('')
NDVImean.setValue('')
updateNDVIstats()[1].evaluate(function(val){NDVImean.setValue(val)})
updateNDVIstats()[0].evaluate(function(val){NDVIarea.setValue(val)})
}
,style: TEXTBOX_STYLE})
minNDVI.setDisabled(1)
minNDVI.style().set({width:'50px',textAlign : 'center'})
var maxNDVI = ui.Textbox({value: "1", onChange:function(value){
if(parseFloat(value) < 0)
{maxNDVI.setValue('0')}
if(parseFloat(value) > 1)
{maxNDVI.setValue('1')}
if(isNaN(value))
{maxNDVI.setValue('1')}
if(parseFloat(value) <= minNDVI.getValue())
{maxNDVI.setValue((parseFloat(value) +0.01).toString())}
if(countDecimals(parseFloat(value)) > 2)
{maxNDVI.setValue(Math.floor(parseFloat(value) * 100) / 100)}
updateNDVI(parseFloat(minNDVI.getValue()),parseFloat(value))
NDVIarea.setValue('')
NDVImean.setValue('')
updateNDVIstats()[1].evaluate(function(val){NDVImean.setValue(val)})
updateNDVIstats()[0].evaluate(function(val){NDVIarea.setValue(val)})
}
,style: TEXTBOX_STYLE})
maxNDVI.setDisabled(1)
maxNDVI.style().set({width:'50px',textAlign : 'center'})
var minlabel = ui.Label('Min', LABEL_STYLE)
minlabel.style().set({padding: '8px'})
NDVIsliderPanel.insert(2, minlabel)
NDVIsliderPanel.insert(3, minNDVI)
NDVIsliderPanel.insert(4, ui.Label('Max', LABEL_STYLE))
NDVIsliderPanel.insert(5, maxNDVI)
var NDVIarea = ui.Label('', LABEL_STYLE)
var NDVImean = ui.Label('', LABEL_STYLE)
NDVImean.style().set({padding: '8px',width: '42px'});
NDVIsliderPanel.insert(6, NDVImean)
NDVIsliderPanel.insert(7, NDVIarea)
//////////////////////////////
//////////////////////////////
//////////////////////////////
seasonPanel.add(NDWIsliderPanel);
NDWIsliderPanel.insert(1, ui.Label('NDWI Value:', LABEL_STYLE))
var minNDWI = ui.Textbox({value: "0", onChange:function(value){
if(parseFloat(value) < 0)
{minNDWI.setValue('0')}
if(parseFloat(value) > 1)
{minNDWI.setValue('1')}
if(isNaN(value))
{minNDWI.setValue('0')}
if(parseFloat(value) >= maxNDWI.getValue())
{minNDWI.setValue((parseFloat(value) -0.01).toString())}
if(countDecimals(parseFloat(value)) > 2)
{minNDWI.setValue(Math.floor(parseFloat(value) * 100) / 100)}
updateNDWI(parseFloat(value),parseFloat(maxNDWI.getValue()))
NDWIarea.setValue('')
NDWImean.setValue('')
updateNDWIstats()[1].evaluate(function(val){NDWImean.setValue(val)})
updateNDWIstats()[0].evaluate(function(val){NDWIarea.setValue(val)})
}
,style: TEXTBOX_STYLE})
minNDWI.setDisabled(1)
minNDWI.style().set({width:'50px',textAlign : 'center'})
var maxNDWI = ui.Textbox({value: "1", onChange:function(value){
if(parseFloat(value) < 0)
{maxNDWI.setValue('0')}
if(parseFloat(value) > 1)
{maxNDWI.setValue('1')}
if(isNaN(value))
{maxNDWI.setValue('1')}
if(parseFloat(value) <= minNDMI.getValue())
{maxNDWI.setValue((parseFloat(value) +0.01).toString())}
if(countDecimals(parseFloat(value)) > 2)
{maxNDWI.setValue(Math.floor(parseFloat(value) * 100) / 100)}
updateNDWI(parseFloat(minNDWI.getValue()),parseFloat(value))
NDWIarea.setValue('')
NDWImean.setValue('')
updateNDWIstats()[1].evaluate(function(val){NDWImean.setValue(val)})
updateNDWIstats()[0].evaluate(function(val){NDWIarea.setValue(val)})
}
,style: TEXTBOX_STYLE})
maxNDWI.setDisabled(1)
maxNDWI.style().set({width:'50px',textAlign : 'center'})
NDWIsliderPanel.insert(2, ui.Label('Min', LABEL_STYLE))
NDWIsliderPanel.insert(3, minNDWI)
NDWIsliderPanel.insert(4, ui.Label('Max', LABEL_STYLE))
NDWIsliderPanel.insert(5, maxNDWI)
var NDWIarea = ui.Label('', LABEL_STYLE)
var NDWImean = ui.Label('', LABEL_STYLE)
NDWImean.style().set({padding: '8px',width: '44px'});
NDWIsliderPanel.insert(6, NDWImean)
NDWIsliderPanel.insert(7, NDWIarea)
//////////////////////////////
//////////////////////////////
//////////////////////////////
var hozline5 = ui.Label('____________________________________________________________________________________________________________________', LABEL_STYLE)
hozline5.style().set({stretch: 'horizontal',margin:['0px 0px 0px -15px']})
seasonPanel.add(separator5);
separator5.add(hozline5)
var inspectpoint = ui.Button({
      label: symbol.point + ' Inspect by Point',
      onClick: drawPoint,
      disabled: 0,
      style: {width: '120px'}
    })
var X = ui.Label('X/Lon', LABEL_STYLE)
var X_coord = ui.Textbox({value: '',disabled: 0,style: TEXTBOX_STYLE,
onChange:function(value){
if(isNaN(value)) {X_coord.setValue('')}
else if(value > 180) {X_coord.setValue('180')}
else if(value < -180) {X_coord.setValue('-180')}
}})
X_coord.style().set({width: '110px'})
var Y = ui.Label('Y/Lat', LABEL_STYLE)
var Y_coord = ui.Textbox({value: '',disabled: 0,style: TEXTBOX_STYLE,
onChange:function(value){
if(isNaN(value)) {Y_coord.setValue('')}
else if(value > 85) {Y_coord.setValue('85')}
else if(value < -85) {Y_coord.setValue('-85')}
}})
Y_coord.style().set({width: '110px'})
var inspectbutton = ui.Button({
      label: 'Inspect by Coordinate',
      onClick: drawPointcoords,
      disabled: 0,
      style: {width: '125px'}
    })
var watershedlabel = ui.Label('WaterShed Size:', LABEL_STYLE)
watershedlabel.style().set({margin: '8px -15px 0px 8px'})
var watersheddescription = ui.Label('Larger number → Samller watershed', LABEL_STYLE)
watersheddescription.style().set({color: 'green',fontSize:'12px', fontWeight:'0',margin:'12px 8px 8px 8px'})
var watershedlevel = ui.Slider({min:1,max:12,value:6,step:1, onChange:function(value){}, direction:'horizontal', disabled:0,style:datepickerstyle})
watershedlevel.style().set({margin: '8px -50px -10px 8px',fontWeight:'bold',width:'242px'})
var drawwatershedd = ui.Button({
      label: 'Draw Watershed',
      onClick: drawwatershed,
      disabled: 1,
      style: {width: '120px',shown:false}
    })
var streamlabel = ui.Label('Streams Detail Level:', LABEL_STYLE)
var streamdescription = ui.Label('Larger number → Less detail', LABEL_STYLE)
streamdescription.style().set({color: 'green',fontSize:'12px', fontWeight:'0',margin:'8px 8px 8px 27px'})
// var streamlevel = ui.Slider({min:1,max:9,value:5,step:1, onChange:function(value){}, direction:'horizontal', disabled:0,style:datepickerstyle})
// streamlevel.style().set({margin: '8px 8px 8px 8px',fontWeight:'bold'})
var streamlevel = ui.Textbox({value: '1000',disabled: 0,style: TEXTBOX_STYLE,
onChange:function(value){
if(isNaN(value)) {X_coord.setValue('1000')}
else if(value <= 0) {X_coord.setValue('1000')}
}})
streamlevel.style().set({width: '110px'})
seasonPanel.add(inspectPanel)
inspectPanel.add(inspectpoint)
seasonPanel.add(coordPanel)
coordPanel.add(X).add(X_coord).add(Y).add(Y_coord).add(inspectbutton)
seasonPanel.add(streamPanel)
streamPanel.add(streamlabel).add(streamlevel).add(streamdescription)
seasonPanel.add(watershedPanel)
watershedPanel.add(watershedlabel).add(watershedlevel).add(watersheddescription)
seasonPanel.add(drawwatershedd)
//////////////////////////////
//////////////////////////////
//////////////////////////////
var hozline6 = ui.Label('____________________________________________________________________________________________________________________', LABEL_STYLE)
hozline6.style().set({stretch: 'horizontal',margin:['0px 0px 0px -15px']})
seasonPanel.add(separator6);
separator6.add(hozline6)
seasonPanel.add(bandspanelvert);
var bandlabel = ui.Label('Select Band\\s to download:', LABEL_STYLE)
bandlabel.style().set({margin: '8px 8px 8px 8px'})
bandspanelvert.add(bandslabelPanel)
bandslabelPanel.add(bandlabel)
// if(sensor_selector.getValue() == 's2a')
bandspanelvert.add(bandspanelhorz)
bandspanelhorz.add(bandspanela)
var B1 = ui.Checkbox({label: 'B1-Aerosols (60m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B1.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanela.insert(1,B1)
var B2 = ui.Checkbox({label: 'B2-Blue (10m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B2.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanela.insert(2,B2)
var B3 = ui.Checkbox({label: 'B3-Green (10m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B3.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanela.insert(3,B3)
var B4 = ui.Checkbox({label: 'B4-Red (10m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B4.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanela.insert(4,B4)
var B5 = ui.Checkbox({label: 'B5-Red Edge 1 (20m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B5.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanela.insert(5,B5)
var B6 = ui.Checkbox({label: 'B6-Red Edge 2 (20m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B6.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanela.insert(6,B6)
bandspanelhorz.add(bandspanelb)
var B7 = ui.Checkbox({label: 'B7-Red Edge 3 (20m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B7.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelb.insert(7,B7)
var B8 = ui.Checkbox({label: 'B8-NIR (10m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B8.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelb.insert(8,B8)
var B8A = ui.Checkbox({label: 'B8A-Red Edge 4 (20m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B8A.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelb.insert(9,B8A)
var B9 = ui.Checkbox({label: 'B9-Water vapor (60m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B9.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelb.insert(10,B9)
var B10 = ui.Checkbox({label: 'B10-Surface temperature (30m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B10.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent,shown:false})
bandspanelb.insert(11,B10)
var B11 = ui.Checkbox({label: 'B11-SWIR 1 (20m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B11.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelb.insert(12,B11)
var B12 = ui.Checkbox({label: 'B12-SWIR 2 (20m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
B12.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelb.insert(13,B12)
bandspanelhorz.add(bandspanelc)
var NDMIband = ui.Checkbox({label: 'NDMI (20m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
NDMIband.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelc.insert(14,NDMIband)
var NDVIband = ui.Checkbox({label: 'NDVI (10m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
NDVIband.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelc.insert(15,NDVIband)
var NDWIband = ui.Checkbox({label: 'NDWI (10m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
NDWIband.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelc.insert(16,NDWIband)
var Trueband = ui.Checkbox({label: 'TrueColor (10m)',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
Trueband.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelc.insert(17,Trueband)
var AOIshp = ui.Checkbox({label: 'AOI shapefile',value: 0,disabled: 1,
onChange:function(value){checkbandsSelection()}})
AOIshp.style().set({margin: '16px 8px 8px 8px',padding: '0px',
backgroundColor: colors.transparent})
bandspanelc.insert(18,AOIshp)
var blist=[B1,B2,B3,B4,B5,B6,B7,B8,B8A,B9,B10,B11,B12,NDMIband,NDVIband,NDWIband,Trueband,AOIshp];
//////////////////////////////
//////////////////////////////
//////////////////////////////
var hozline7 = ui.Label('____________________________________________________________________________________________________________________', LABEL_STYLE)
hozline7.style().set({stretch: 'horizontal',margin:['0px 0px 0px -15px']})
seasonPanel.add(separator7);
separator7.add(hozline7)
seasonPanel.add(coordinatepanel)
var EPSG = ui.Label('EPSG:', LABEL_STYLE);
coordinatepanel.insert(1, EPSG)
var EPSG_number = ui.Textbox({value: '32638',disabled: 1,style: TEXTBOX_STYLE,
  onChange:function(){
    // if (EPSG_number !== lonlattoepsg().evaluate(function(val){val}))
    // { 
    // try{var proj = ee.Projection({crs:'EPSG:' + EPSG_number.getValue()}).getInfo()
    // utmzone.setValue('')
    // if(minNDWI.getDisabled() === 0)
    // {checkbandsSelection()}
    // }
    //   catch(err){utmzone.setValue('Invalid EPSG code')
    //   downsnippet.setDisabled(1)
    //   }
    // }
    }
})
EPSG_number.style().set({width: '100px',margin:'8px 8px 8px -3px'})
coordinatepanel.insert(2, EPSG_number)
var utmzone = ui.Label('WGS84 \\ UTM Zone 38N', LABEL_STYLE);
coordinatepanel.insert(3, utmzone)
//////////////////////////////
//////////////////////////////
//////////////////////////////
seasonPanel.add(downloadsnippet)
var downsnippet = ui.Button({
      label: 'Generate Download Snippet',
      onClick:function() {downtext.setValue('Loading snippet...Please wait')
      createsnippet().evaluate(function(t){downtext.setValue(t)})},
      disabled: 1,
      style: {stretch: 'horizontal'}
    })
downloadsnippet.insert(1, downsnippet)
var downtext = ui.Textbox({value: '',disabled: 1,style: TEXTBOX_STYLE})
downtext.style().set({width: '360px',margin:'8px 8px 8px -3px'})
downloadsnippet.insert(2, downtext)
//////////////////////////////
//////////////////////////////
//////////////////////////////
seasonPanel.add(gotogee)
var gotobutton = ui.Label('Go to Google Earth Engine',PARAGRAPH_STYLE);
gotobutton.setUrl('https://code.earthengine.google.com/')
gotobutton.style().set({margin: '8px 8px 8px 8px', fontWeight:'bold',color:'blue'})
var contactus = ui.Label('Contact Us',PARAGRAPH_STYLE);
contactus.setUrl('mailto:yousif_samir@yahoo.com')
contactus.style().set({color:'blue',fontWeight:'bold',margin: '8px 8px 8px 250px'})
gotogee.insert(1, gotobutton)
gotogee.insert(2, contactus)
//////////////////////////////
//////////////////////////////
//////////////////////////////
// var EPSG_label = ui.Label('Coordinate System', LABEL_STYLE)
// var EPSG_list = [
// {label:'Web Mercator projection', value:'EPSG:3857'},
// {label:'WGS84/UTM zone 38N', value:'EPSG:32638'}
// ];
// var EPSG_selector = ui.Select({items: EPSG_list, placeholder: 'WGS84/UTM zone 38N',
// value: 'EPSG:32638', style: SELECT_STYLE});
// EPSG_selector.style().set({width:'174px'})
// seasonPanel.add(EPSGPanel)
// EPSGPanel.add(EPSG_label)
// EPSGPanel.add(EPSG_selector)
// var ssymbol = {download: '⇩'}
// seasonPanel.add(downloadPanel);
// var downloadtrue = ui.Button({label: ssymbol.download + ' TrueColor', 
// style:BUTTON_STYLE,disabled: 1,onClick:function() {
//   var aa;
//   var layers = mappingPanel.layers()
//     layers.forEach(
//       function(x) {
//       var lay_name = x.getName()
//       if (lay_name == (Gov_selector.getValue() +' '+arabic_date + ' True Color'))
//       {aa = x.getEeObject()}})
//   Export.image.toDrive({
//   image: aa,
//   description: Gov_selector.getValue() + '-TrueColor-' +english_date,
//   fileNamePrefix: Gov_selector.getValue() + ' TrueColor ' +english_date,
//   scale: 10,
//   region: aoi,
//   maxPixels: 1e10,
//   crs: EPSG_selector.getValue(),
//   folder: "Image Production"
// })
// }})
// downloadPanel.add(downloadtrue)
// //////////////////////////////
// var downloadNDMI = ui.Button({label: ssymbol.download + ' NDMI', 
// style:BUTTON_STYLE,disabled: 1,onClick:function() {
//   var aa;
//   var layers = mappingPanel.layers()
//     layers.forEach(
//       function(x) {
//       var lay_name = x.getName()
//       if (lay_name == (Gov_selector.getValue() +' '+arabic_date + ' NDMI'))
//       {aa = x.getEeObject()}})
//   Export.image.toDrive({
//   image: aa,
//   description: Gov_selector.getValue() + '-NDMI-' +english_date,
//   fileNamePrefix: Gov_selector.getValue() + ' NDMI ' +english_date,
//   scale: 20,
//   region: aoi,
//   maxPixels: 1e10,
//   crs: EPSG_selector.getValue(),
//   folder: "Image Production"
// })
// }})
// downloadPanel.add(downloadNDMI)
// //////////////////////////////
// var downloadNDVI = ui.Button({label: ssymbol.download + ' NDVI', 
// style:BUTTON_STYLE,disabled: 1,onClick:function() {
//   var aa;
//   var layers = mappingPanel.layers()
//     layers.forEach(
//       function(x) {
//       var lay_name = x.getName()
//       if (lay_name == (Gov_selector.getValue() +' '+arabic_date + ' NDVI'))
//       {aa = x.getEeObject()}})
//   var Governorate = Gov_selector.getValue()
//   if(Governorate == 'Hammar Marsh')
//   {aoi = ee.FeatureCollection("users/Yousif_Almamalachy/Hammar_Marsh_NDVI")}
//   else if(Governorate == 'Huaizah Marsh') 
//   {aoi = ee.FeatureCollection("users/Yousif_Almamalachy/Huaizah_Marsh_NDVI")}
//   Export.image.toDrive({
//   image: aa,
//   description: Gov_selector.getValue() + '-NDVI-' +english_date,
//   fileNamePrefix: Gov_selector.getValue() + ' NDVI ' +english_date,
//   scale: 10,
//   region: aoi,
//   maxPixels: 1e10,
//   crs: EPSG_selector.getValue(),
//   folder: "Image Production"
// })
// }})
// downloadPanel.add(downloadNDVI)
// //////////////////////////////
// var downloadNDWI = ui.Button({label: ssymbol.download + ' NDWI', 
// style:BUTTON_STYLE,disabled: 1,onClick:function() {
//   var aa;
//   var layers = mappingPanel.layers()
//     layers.forEach(
//       function(x) {
//       var lay_name = x.getName()
//       if (lay_name == (Gov_selector.getValue() +' '+arabic_date + ' NDWI'))
//       {aa = x.getEeObject()}})
//   Export.image.toDrive({
//   image: aa,
//   description: Gov_selector.getValue() + '-NDWI-' +english_date,
//   fileNamePrefix: Gov_selector.getValue() + ' NDWI ' +english_date,
//   scale: 10,
//   region: aoi,
//   maxPixels: 1e10,
//   crs: EPSG_selector.getValue(),
//   folder: "Image Production"
// })
// }})
// downloadPanel.add(downloadNDWI)
///////////////////////////////////////////////////////////////////
////////////////////////// Functions Section //////////////////////
///////////////////////////////////////////////////////////////////
function s2acloud(Start_Date,End_Date,aoii,Allowed_Cloud,Coverage_Days){
  var sentinel = ee.ImageCollection("COPERNICUS/S2_SR");
  var aoi = aoii;
  var sStart_Date = Start_Date
  var eEnd_Date = End_Date
  var aAllowed_Cloud = Allowed_Cloud
  var Minimum_Areal_Coverage = 0.99
  var cCoverage_Days = Coverage_Days
  var data1 = sentinel.filterBounds(aoi).filterDate(sStart_Date,eEnd_Date)
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 100)).sort('CLOUDY_PIXEL_PERCENTAGE',false);
  var CLD_PRB_THRESH = 40
  // Import and filter s2cloudless.
  var s2_cloudless_col = (ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY')
    .filterBounds(aoi)
    .filterDate(sStart_Date, eEnd_Date))  
  // Join the filtered s2cloudless collection to the SR collection by the 'system:index' property.
  var data2 =  ee.ImageCollection(ee.Join.saveFirst('s2cloudless').apply({
    'primary': data1,
    'secondary': s2_cloudless_col,
    'condition': ee.Filter.equals({
        'leftField': 'system:index',
        'rightField': 'system:index'
    })
  }))  
  var data3 = data2.map(function(img){
    var cld_prb = ee.Image(img.get('s2cloudless')).select('probability')
    var is_cloud = cld_prb.gte(CLD_PRB_THRESH).rename('is_cloud')
    // var no_cloud = cld_prb.lt(CLD_PRB_THRESH).rename('no_cloud')
    var no_cloud = ee.Image.constant(100).subtract(cld_prb).rename('no_cloud')
    return img.addBands(ee.Image([cld_prb,is_cloud,no_cloud]))
  })
  var sscale = 10
  var polygon_area = aoi.area(1e-3).divide(1e6)
  var minimum_area = ee.Number(polygon_area).multiply(Minimum_Areal_Coverage)
    // Get the dates of filtered images with less than specified cloud percentage
  var dates = data3
      .map(function(image) {
        return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
      })
      //.distinct('date')
      .aggregate_array('date')
  // Filter Images that doesn't contain all bands
  var data3 = data3.map(function(n) {
    return n.set('Num_of_bands',n.bandNames().length());
  })
  data3 = data3.filterMetadata("Num_of_bands","equals",26);
  // Mosaic images of the same date and calculate its average cloud cover
  var data4 = ee.ImageCollection(
    ee.List(dates.distinct()).map(function (n) {
    var date = ee.Date(n)
    var filtered = data3.filterDate(date, date.advance(Coverage_Days,'day')) 
    // var cc = filtered
    //   .map(function(image) {
    //     return ee.Feature(null, {'cloud_cover': ee.Image(image)
    //     .get('CLOUDY_PIXEL_PERCENTAGE')})
    //   })
    //   .aggregate_array('cloud_cover')
    // var cloud_cover = cc.reduce({
    //   reducer: ee.Reducer.mean()
    // })
    var image = ee.Image(filtered.mosaic())
    return image.set({'date':n})
  }));
  // Filter Images that doesn't contain all bands
  var data4 = data4.map(function(n) {
    return n.set('Num_of_bands',n.bandNames().length());
  })
  data4 = data4.filterMetadata("Num_of_bands","equals",26);
  // Filter Images that doesn't cover polygon area (raster area calculation method)
  var data5 = data4.map(function(n) {
    var data = ee.Image(1).mask(n.select('B2'))
    var raster_area = data.multiply(ee.Image.pixelArea()).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: aoi,
      scale: sscale,
      maxPixels: 1E13
    }).get('constant')
    raster_area=ee.Number(raster_area).divide(1e6)
    return n.set('Area_KM2',raster_area)
  })
  data5 = data5.filterMetadata("Area_KM2","greater_than",ee.Number(minimum_area));
  // // Filter Images that doesn't match specified cloud coverage
  //   var data6 = data5.map(function(n) {
  //   var data = n.select('is_cloud')
  //   var num_of_pix = data.reduceRegion({
  //     reducer: ee.Reducer.count(),
  //     geometry: aoi,
  //     scale: sscale,
  //     maxPixels: 1E13
  //   }).get('is_cloud')
  //   return n.set('num_of_pix',num_of_pix)
  // })
  // var data7 = data6.map(function(n) {  
  //   var data = n.select('is_cloud').mask(n.select('is_cloud').eq(1))
  //   var num_of_cld_pix = data.reduceRegion({
  //   reducer: ee.Reducer.count(),
  //   geometry: aoi,
  //   scale: sscale,
  //   maxPixels: 1E13
  // }).get('is_cloud')
  // return n.set('num_of_cld_pix',num_of_cld_pix)
  // })
    var data7 = data5.map(function(n) {
    var data = ee.Image(1).mask(n.select('is_cloud').mask(n.select('is_cloud').eq(1)))
    var raster_area = data.multiply(ee.Image.pixelArea()).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: aoi,
      scale: sscale,
      maxPixels: 1E13
    }).get('constant')
    raster_area=ee.Number(raster_area).divide(1e6)
    return n.set('Cloud_area',raster_area)
  })
  var data8 = data7.map(function(n) {  
    var cloud_prec = (ee.Number(n.get('Cloud_area')).divide(ee.Number(n.get('Area_KM2')))).multiply(100)
  return n.set('cloud_prec',cloud_prec)
  })
  data8 = data8.filterMetadata("cloud_prec","less_than",ee.Number(aAllowed_Cloud));
  data8 = data8.sort('date',true)
  // // Create list of calculated Areas
  // var Area_list = data8
  //     .map(function(image) {
  //       return ee.Feature(null, {'Area_Coverage': ee.Number(ee.Image(image)
  //       .get('Area_KM2')).divide(polygon_area).multiply(100)})
  //     })
  //     .aggregate_array('Area_Coverage')
    // Create list of cloud cover
  var Cloud_Cover = data8
      .map(function(image) {
        return ee.Feature(null, {'Cloud_Cover': ee.Image(image)
        .get('cloud_prec')})
      })
      .aggregate_array('Cloud_Cover')
  //Convert cloud cover list from list of numbers to list of strings with two decimal places only
  var Cloud_Cover_String = ee.List.sequence(0, Cloud_Cover.length().subtract(1))
    .map(function (i) {
      return Cloud_Cover.getNumber(i).format('%.2f')
    });
  // Create list of available dates
  var dates = data8
      .map(function(image) {
        return ee.Feature(null, {'dates': ee.Image(image).get('date')})
      })
      .aggregate_array('dates')
  //Reverse dates format from 'yyyy-mm-dd' to 'dd-mm-yyyy'
  var dates_reversed = ee.List.sequence(0, dates.length().subtract(1))
  .map(function (i) {
    return dates.getString(i).split('-').reverse().join('-')
  });
  // Combine dates list with cloud cover dates element wise.
  var datesandcloud = ee.List.sequence(0, Cloud_Cover.length().subtract(1))
  .map(function (i) {
    return dates_reversed.getString(i).cat(' (').cat(Cloud_Cover_String.getString(i)).cat('%)')
  });
  return datesandcloud
}
///////////////////////////////////////////////
function s1ccloud(Start_Date,End_Date,aoii,Allowed_Cloud,Coverage_Days){
  var sentinel = ee.ImageCollection("COPERNICUS/S2");
  var aoi = aoii;
  var sStart_Date = Start_Date
  var eEnd_Date = End_Date
  var aAllowed_Cloud = Allowed_Cloud
  var Minimum_Areal_Coverage = 0.99
  var cCoverage_Days = Coverage_Days
  var data1 = sentinel.filterBounds(aoi).filterDate(sStart_Date,eEnd_Date)
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 100)).sort('CLOUDY_PIXEL_PERCENTAGE',false);
  var CLD_PRB_THRESH = 40
  // Import and filter s2cloudless.
  var s2_cloudless_col = (ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY')
    .filterBounds(aoi)
    .filterDate(sStart_Date, eEnd_Date))  
  // Join the filtered s2cloudless collection to the SR collection by the 'system:index' property.
  var data2 =  ee.ImageCollection(ee.Join.saveFirst('s2cloudless').apply({
    'primary': data1,
    'secondary': s2_cloudless_col,
    'condition': ee.Filter.equals({
        'leftField': 'system:index',
        'rightField': 'system:index'
    })
  }))  
  var data3 = data2.map(function(img){
    var cld_prb = ee.Image(img.get('s2cloudless')).select('probability')
    var is_cloud = cld_prb.gte(CLD_PRB_THRESH).rename('is_cloud')
    // var no_cloud = cld_prb.lt(CLD_PRB_THRESH).rename('no_cloud')
    var no_cloud = ee.Image.constant(100).subtract(cld_prb).rename('no_cloud')
    return img.addBands(ee.Image([cld_prb,is_cloud,no_cloud]))
  })
  var sscale = 10
  var polygon_area = aoi.area(1e-3).divide(1e6)
  var minimum_area = ee.Number(polygon_area).multiply(Minimum_Areal_Coverage)
    // Get the dates of filtered images with less than specified cloud percentage
  var dates = data3
      .map(function(image) {
        return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
      })
      //.distinct('date')
      .aggregate_array('date')
  // Filter Images that doesn't contain all bands
  var data3 = data3.map(function(n) {
    return n.set('Num_of_bands',n.bandNames().length());
  })
  data3 = data3.filterMetadata("Num_of_bands","equals",19);
  // Mosaic images of the same date and calculate its average cloud cover
  var data4 = ee.ImageCollection(
    ee.List(dates.distinct()).map(function (n) {
    var date = ee.Date(n)
    var filtered = data3.filterDate(date, date.advance(Coverage_Days,'day')) 
    // var cc = filtered
    //   .map(function(image) {
    //     return ee.Feature(null, {'cloud_cover': ee.Image(image)
    //     .get('CLOUDY_PIXEL_PERCENTAGE')})
    //   })
    //   .aggregate_array('cloud_cover')
    // var cloud_cover = cc.reduce({
    //   reducer: ee.Reducer.mean()
    // })
    var image = ee.Image(filtered.mosaic())
    return image.set({'date':n})
  }));
  // Filter Images that doesn't contain all bands
  var data4 = data4.map(function(n) {
    return n.set('Num_of_bands',n.bandNames().length());
  })
  data4 = data4.filterMetadata("Num_of_bands","equals",19);
  // Filter Images that doesn't cover polygon area (raster area calculation method)
  var data5 = data4.map(function(n) {
    var data = ee.Image(1).mask(n.select('B2'))
    var raster_area = data.multiply(ee.Image.pixelArea()).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: aoi,
      scale: sscale,
      maxPixels: 1E13
    }).get('constant')
    raster_area=ee.Number(raster_area).divide(1e6)
    return n.set('Area_KM2',raster_area)
  })
  data5 = data5.filterMetadata("Area_KM2","greater_than",ee.Number(minimum_area));
  // // Filter Images that doesn't match specified cloud coverage
  //   var data6 = data5.map(function(n) {
  //   var data = n.select('is_cloud')
  //   var num_of_pix = data.reduceRegion({
  //     reducer: ee.Reducer.count(),
  //     geometry: aoi,
  //     scale: sscale,
  //     maxPixels: 1E13
  //   }).get('is_cloud')
  //   return n.set('num_of_pix',num_of_pix)
  // })
  // var data7 = data6.map(function(n) {  
  //   var data = n.select('is_cloud').mask(n.select('is_cloud').eq(1))
  //   var num_of_cld_pix = data.reduceRegion({
  //   reducer: ee.Reducer.count(),
  //   geometry: aoi,
  //   scale: sscale,
  //   maxPixels: 1E13
  // }).get('is_cloud')
  // return n.set('num_of_cld_pix',num_of_cld_pix)
  // })
    var data7 = data5.map(function(n) {
    var data = ee.Image(1).mask(n.select('is_cloud').mask(n.select('is_cloud').eq(1)))
    var raster_area = data.multiply(ee.Image.pixelArea()).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: aoi,
      scale: sscale,
      maxPixels: 1E13
    }).get('constant')
    raster_area=ee.Number(raster_area).divide(1e6)
    return n.set('Cloud_area',raster_area)
  })
  var data8 = data7.map(function(n) {  
    var cloud_prec = (ee.Number(n.get('Cloud_area')).divide(ee.Number(n.get('Area_KM2')))).multiply(100)
  return n.set('cloud_prec',cloud_prec)
  })
  data8 = data8.filterMetadata("cloud_prec","less_than",ee.Number(aAllowed_Cloud));
  data8 = data8.sort('date',true)
  // // Create list of calculated Areas
  // var Area_list = data8
  //     .map(function(image) {
  //       return ee.Feature(null, {'Area_Coverage': ee.Number(ee.Image(image)
  //       .get('Area_KM2')).divide(polygon_area).multiply(100)})
  //     })
  //     .aggregate_array('Area_Coverage')
    // Create list of cloud cover
  var Cloud_Cover = data8
      .map(function(image) {
        return ee.Feature(null, {'Cloud_Cover': ee.Image(image)
        .get('cloud_prec')})
      })
      .aggregate_array('Cloud_Cover')
  //Convert cloud cover list from list of numbers to list of strings with two decimal places only
  var Cloud_Cover_String = ee.List.sequence(0, Cloud_Cover.length().subtract(1))
    .map(function (i) {
      return Cloud_Cover.getNumber(i).format('%.2f')
    });
  // Create list of available dates
  var dates = data8
      .map(function(image) {
        return ee.Feature(null, {'dates': ee.Image(image).get('date')})
      })
      .aggregate_array('dates')
  //Reverse dates format from 'yyyy-mm-dd' to 'dd-mm-yyyy'
  var dates_reversed = ee.List.sequence(0, dates.length().subtract(1))
  .map(function (i) {
    return dates.getString(i).split('-').reverse().join('-')
  });
  // Combine dates list with cloud cover dates element wise.
  var datesandcloud = ee.List.sequence(0, Cloud_Cover.length().subtract(1))
  .map(function (i) {
    return dates_reversed.getString(i).cat(' (').cat(Cloud_Cover_String.getString(i)).cat('%)')
  });
  return datesandcloud
}
///////////////////////////////////////////////
function l8cloud(Start_Date,End_Date,aoii,Allowed_Cloud,Coverage_Days){
  var landsat = ee.ImageCollection("LANDSAT/LC08/C02/T1_L2");
  var aoi = aoii;
  var sStart_Date = Start_Date
  var eEnd_Date = End_Date
  var aAllowed_Cloud = Allowed_Cloud
  var Minimum_Areal_Coverage = 0.99
  var cCoverage_Days = Coverage_Days
  var data1 = landsat.filterBounds(aoi).filterDate(sStart_Date,eEnd_Date).sort('CLOUD_COVER',false);
//   function applyScaleFactors(image) {
//   var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
//   var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
//   return image.addBands(opticalBands, null, true)
//               .addBands(thermalBands, null, true);
// }
// data1 = data1.map(applyScaleFactors);
  function calcclouds(image){
  var quality = image.select('QA_PIXEL');
  var c1 = quality.eq(22280)
  var c2 = quality.eq(24088)
  var c3 = quality.eq(24216)
  var c4 = quality.eq(24344)
  var c5 = quality.eq(24472)
  var c6 = quality.eq(55052)
  var c7 = quality.eq(56856)
  var c8 = quality.eq(56984)
  var c9 = quality.eq(57240)
  var mask = c1.or(c2).or(c3).or(c4).or(c5).or(c6).or(c7).or(c8).or(c9)
  return ee.Image(1).mask(mask).unmask(0)
}
  var data2 = data1.map(function(img){
    var geom = img.geometry()
    var is_cloud = calcclouds(img).clip(geom).rename('is_cloud')
    var no_cloud = is_cloud.not().rename('no_cloud')
    return img.addBands(ee.Image([is_cloud,no_cloud]))
  })
  var sscale = 30
  var polygon_area = aoi.area(1e-3).divide(1e6)
  var minimum_area = ee.Number(polygon_area).multiply(Minimum_Areal_Coverage)
    // Get the list of image collection dates
  var dates = data2
      .map(function(image) {
        return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
      })
      .aggregate_array('date')
  // Filter Images that doesn't contain all bands
  var data2 = data2.map(function(n) {
    return n.set('Num_of_bands',n.bandNames().length());
  })
  data2 = data2.filterMetadata("Num_of_bands","equals",21);
  // Mosaic images of the same date
  var data3 = ee.ImageCollection(
    ee.List(dates.distinct()).map(function (n) {
    var date = ee.Date(n)
    var filtered = data2.filterDate(date, date.advance(Coverage_Days,'day')) 
    var image = ee.Image(filtered.mosaic())
    return image.set({'date':n})
  }));
  // Filter Images that doesn't contain all bands
  var data3 = data3.map(function(n) {
    return n.set('Num_of_bands',n.bandNames().length());
  })
  data3 = data3.filterMetadata("Num_of_bands","equals",21);
  // caclulate raster area
  var data4 = data3.map(function(n) {
    var data = ee.Image(1).mask(n.select('SR_B2'))
    var raster_area = data.multiply(ee.Image.pixelArea()).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: aoi,
      scale: sscale,
      maxPixels: 1E13
    }).get('constant')
    raster_area=ee.Number(raster_area).divide(1e6)
    return n.set('Area_KM2',raster_area)
  })
  //Filter Images that doesn't cover polygon area
  data4 = data4.filterMetadata("Area_KM2","greater_than",ee.Number(minimum_area));
  // Calculate cloud area    
    var data5 = data4.map(function(n) {
    var data = ee.Image(1).mask(n.select('is_cloud').mask(n.select('is_cloud')))
    var cld_area = data.multiply(ee.Image.pixelArea()).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: aoi,
      scale: sscale,
      maxPixels: 1E13
    }).get('constant')
    cld_area=ee.Number(cld_area).divide(1e6)
    return n.set('Cloud_area',cld_area)
  })
  var data6 = data5.map(function(n) {  
    var cloud_prec = (ee.Number(n.get('Cloud_area')).divide(ee.Number(n.get('Area_KM2')))).multiply(100)
  return n.set('cloud_prec',cloud_prec)
  })
  // Filter images that doesn't meet the predefined minimum allowed cloud cover
  data6 = data6.filterMetadata("cloud_prec","less_than",ee.Number(aAllowed_Cloud));
  data6 = data6.sort('date',true)
  // Create list of calculated Areas
  // var Area_list = data6
  //     .map(function(image) {
  //       return ee.Feature(null, {'Area_Coverage': ee.Number(ee.Image(image)
  //       .get('Area_KM2')).divide(polygon_area).multiply(100)})
  //     })
  //     .aggregate_array('Area_Coverage')
    // Create list of cloud cover
  var Cloud_Cover = data6
      .map(function(image) {
        return ee.Feature(null, {'Cloud_Cover': ee.Image(image)
        .get('cloud_prec')})
      })
      .aggregate_array('Cloud_Cover')
  //Convert cloud cover list from list of numbers to list of strings with two decimal places only
  var Cloud_Cover_String = ee.List.sequence(0, Cloud_Cover.length().subtract(1))
    .map(function (i) {
      return Cloud_Cover.getNumber(i).format('%.2f')
    });
  // Create list of available dates
  var dates = data6
      .map(function(image) {
        return ee.Feature(null, {'dates': ee.Image(image).get('date')})
      })
      .aggregate_array('dates')
  //Reverse dates format from 'yyyy-mm-dd' to 'dd-mm-yyyy'
  var dates_reversed = ee.List.sequence(0, dates.length().subtract(1))
  .map(function (i) {
    return dates.getString(i).split('-').reverse().join('-')
  });
  // Combine dates list with cloud cover dates element wise.
  var datesandcloud = ee.List.sequence(0, Cloud_Cover.length().subtract(1))
  .map(function (i) {
    return dates_reversed.getString(i).cat(' (').cat(Cloud_Cover_String.getString(i)).cat('%)')
  });
  return datesandcloud
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function l9cloud(Start_Date,End_Date,aoii,Allowed_Cloud,Coverage_Days){
  var landsat = ee.ImageCollection('LANDSAT/LC09/C02/T1_L2');
  var aoi = aoii;
  var sStart_Date = Start_Date
  var eEnd_Date = End_Date
  var aAllowed_Cloud = Allowed_Cloud
  var Minimum_Areal_Coverage = 0.99
  var cCoverage_Days = Coverage_Days
  var data1 = landsat.filterBounds(aoi).filterDate(sStart_Date,eEnd_Date).sort('CLOUD_COVER',false);
//   function applyScaleFactors(image) {
//   var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
//   var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
//   return image.addBands(opticalBands, null, true)
//               .addBands(thermalBands, null, true);
// }
// data1 = data1.map(applyScaleFactors);
  function calcclouds(image){
  var quality = image.select('QA_PIXEL');
  var c1 = quality.eq(22280)
  var c2 = quality.eq(24088)
  var c3 = quality.eq(24216)
  var c4 = quality.eq(24344)
  var c5 = quality.eq(24472)
  var c6 = quality.eq(55052)
  var c7 = quality.eq(56856)
  var c8 = quality.eq(56984)
  var c9 = quality.eq(57240)
  var mask = c1.or(c2).or(c3).or(c4).or(c5).or(c6).or(c7).or(c8).or(c9)
  return ee.Image(1).mask(mask).unmask(0)
}
  var data2 = data1.map(function(img){
    var geom = img.geometry()
    var is_cloud = calcclouds(img).clip(geom).rename('is_cloud')
    var no_cloud = is_cloud.not().rename('no_cloud')
    return img.addBands(ee.Image([is_cloud,no_cloud]))
  })
  var sscale = 30
  var polygon_area = aoi.area(1e-3).divide(1e6)
  var minimum_area = ee.Number(polygon_area).multiply(Minimum_Areal_Coverage)
    // Get the list of image collection dates
  var dates = data2
      .map(function(image) {
        return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
      })
      .aggregate_array('date')
  // Filter Images that doesn't contain all bands
  var data2 = data2.map(function(n) {
    return n.set('Num_of_bands',n.bandNames().length());
  })
  data2 = data2.filterMetadata("Num_of_bands","equals",21);
  // Mosaic images of the same date
  var data3 = ee.ImageCollection(
    ee.List(dates.distinct()).map(function (n) {
    var date = ee.Date(n)
    var filtered = data2.filterDate(date, date.advance(Coverage_Days,'day')) 
    var image = ee.Image(filtered.mosaic())
    return image.set({'date':n})
  }));
  // Filter Images that doesn't contain all bands
  var data3 = data3.map(function(n) {
    return n.set('Num_of_bands',n.bandNames().length());
  })
  data3 = data3.filterMetadata("Num_of_bands","equals",21);
  // caclulate raster area
  var data4 = data3.map(function(n) {
    var data = ee.Image(1).mask(n.select('SR_B2'))
    var raster_area = data.multiply(ee.Image.pixelArea()).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: aoi,
      scale: sscale,
      maxPixels: 1E13
    }).get('constant')
    raster_area=ee.Number(raster_area).divide(1e6)
    return n.set('Area_KM2',raster_area)
  })
  //Filter Images that doesn't cover polygon area
  data4 = data4.filterMetadata("Area_KM2","greater_than",ee.Number(minimum_area));
  // Calculate cloud area    
    var data5 = data4.map(function(n) {
    var data = ee.Image(1).mask(n.select('is_cloud').mask(n.select('is_cloud')))
    var cld_area = data.multiply(ee.Image.pixelArea()).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: aoi,
      scale: sscale,
      maxPixels: 1E13
    }).get('constant')
    cld_area=ee.Number(cld_area).divide(1e6)
    return n.set('Cloud_area',cld_area)
  })
  var data6 = data5.map(function(n) {  
    var cloud_prec = (ee.Number(n.get('Cloud_area')).divide(ee.Number(n.get('Area_KM2')))).multiply(100)
  return n.set('cloud_prec',cloud_prec)
  })
  // Filter images that doesn't meet the predefined minimum allowed cloud cover
  data6 = data6.filterMetadata("cloud_prec","less_than",ee.Number(aAllowed_Cloud));
  data6 = data6.sort('date',true)
  // Create list of calculated Areas
  // var Area_list = data6
  //     .map(function(image) {
  //       return ee.Feature(null, {'Area_Coverage': ee.Number(ee.Image(image)
  //       .get('Area_KM2')).divide(polygon_area).multiply(100)})
  //     })
  //     .aggregate_array('Area_Coverage')
    // Create list of cloud cover
  var Cloud_Cover = data6
      .map(function(image) {
        return ee.Feature(null, {'Cloud_Cover': ee.Image(image)
        .get('cloud_prec')})
      })
      .aggregate_array('Cloud_Cover')
  //Convert cloud cover list from list of numbers to list of strings with two decimal places only
  var Cloud_Cover_String = ee.List.sequence(0, Cloud_Cover.length().subtract(1))
    .map(function (i) {
      return Cloud_Cover.getNumber(i).format('%.2f')
    });
  // Create list of available dates
  var dates = data6
      .map(function(image) {
        return ee.Feature(null, {'dates': ee.Image(image).get('date')})
      })
      .aggregate_array('dates')
  //Reverse dates format from 'yyyy-mm-dd' to 'dd-mm-yyyy'
  var dates_reversed = ee.List.sequence(0, dates.length().subtract(1))
  .map(function (i) {
    return dates.getString(i).split('-').reverse().join('-')
  });
  // Combine dates list with cloud cover dates element wise.
  var datesandcloud = ee.List.sequence(0, Cloud_Cover.length().subtract(1))
  .map(function (i) {
    return dates_reversed.getString(i).cat(' (').cat(Cloud_Cover_String.getString(i)).cat('%)')
  });
  return datesandcloud
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function l5cloud(Start_Date,End_Date,aoii,Allowed_Cloud,Coverage_Days){
  var landsat = ee.ImageCollection("LANDSAT/LT05/C02/T1_L2");
  var aoi = aoii;
  var sStart_Date = Start_Date
  var eEnd_Date = End_Date
  var aAllowed_Cloud = Allowed_Cloud
  var Minimum_Areal_Coverage = 0.99
  var cCoverage_Days = Coverage_Days
  var data1 = landsat.filterBounds(aoi).filterDate(sStart_Date,eEnd_Date).sort('CLOUD_COVER',false);
  // function applyScaleFactors(image) {
  // var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  // var thermalBand = image.select('ST_B6').multiply(0.00341802).add(149.0);
  // return image.addBands(opticalBands, null, true)
  //             .addBands(thermalBand, null, true);
  // }
  // data1 = data1.map(applyScaleFactors);
  function calcclouds(image){
  var quality = image.select('QA_PIXEL');
  var c1 = quality.bitwiseAnd(1<<3)
  var mask = c1;
  return ee.Image(1).mask(mask).unmask(0)
  }
  var data2 = data1.map(function(img){
    var geom = img.geometry()
    var is_cloud = calcclouds(img).clip(geom).rename('is_cloud')
    var no_cloud = is_cloud.not().clip(geom).rename('no_cloud')
    return img.addBands(ee.Image([is_cloud,no_cloud]))
  })
  var sscale = 30
  var polygon_area = aoi.area(1e-3).divide(1e6)
  var minimum_area = ee.Number(polygon_area).multiply(Minimum_Areal_Coverage)
    // Get the list of image collection dates
  var dates = data2
      .map(function(image) {
        return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
      })
      .aggregate_array('date')
  // Filter Images that doesn't contain all bands
  var data2 = data2.map(function(n) {
    return n.set('Num_of_bands',n.bandNames().length());
  })
  data2 = data2.filterMetadata("Num_of_bands","equals",21);
  // Mosaic images of the same date
  var data3 = ee.ImageCollection(
    ee.List(dates.distinct()).map(function (n) {
    var date = ee.Date(n)
    var filtered = data2.filterDate(date, date.advance(Coverage_Days,'day')) 
    var image = ee.Image(filtered.mosaic())
    return image.set({'date':n})
  }));
  // Filter Images that doesn't contain all bands
  var data3 = data3.map(function(n) {
    return n.set('Num_of_bands',n.bandNames().length());
  })
  data3 = data3.filterMetadata("Num_of_bands","equals",21);
  // caclulate raster area
  var data4 = data3.map(function(n) {
    var data = ee.Image(1).mask(n.select('SR_B1'))
    var raster_area = data.multiply(ee.Image.pixelArea()).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: aoi,
      scale: sscale,
      maxPixels: 1E13
    }).get('constant')
    raster_area=ee.Number(raster_area).divide(1e6)
    return n.set('Area_KM2',raster_area)
  })
  //Filter Images that doesn't cover polygon area
  data4 = data4.filterMetadata("Area_KM2","greater_than",ee.Number(minimum_area));
  // Calculate cloud area    
    var data5 = data4.map(function(n) {
    var data = ee.Image(1).mask(n.select('is_cloud').mask(n.select('is_cloud')))
    var cld_area = data.multiply(ee.Image.pixelArea()).reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: aoi,
      scale: sscale,
      maxPixels: 1E13
    }).get('constant')
    cld_area=ee.Number(cld_area).divide(1e6)
    return n.set('Cloud_area',cld_area)
  })
  var data6 = data5.map(function(n) {  
    var cloud_prec = (ee.Number(n.get('Cloud_area')).divide(ee.Number(n.get('Area_KM2')))).multiply(100)
  return n.set('cloud_prec',cloud_prec)
  })
  // Filter images that doesn't meet the predefined minimum allowed cloud cover
  data6 = data6.filterMetadata("cloud_prec","less_than",ee.Number(aAllowed_Cloud));
  data6 = data6.sort('date',true)
  // Create list of calculated Areas
  // var Area_list = data6
  //     .map(function(image) {
  //       return ee.Feature(null, {'Area_Coverage': ee.Number(ee.Image(image)
  //       .get('Area_KM2')).divide(polygon_area).multiply(100)})
  //     })
  //     .aggregate_array('Area_Coverage')
    // Create list of cloud cover
  var Cloud_Cover = data6
      .map(function(image) {
        return ee.Feature(null, {'Cloud_Cover': ee.Image(image)
        .get('cloud_prec')})
      })
      .aggregate_array('Cloud_Cover')
  //Convert cloud cover list from list of numbers to list of strings with two decimal places only
  var Cloud_Cover_String = ee.List.sequence(0, Cloud_Cover.length().subtract(1))
    .map(function (i) {
      return Cloud_Cover.getNumber(i).format('%.2f')
    });
  // Create list of available dates
  var dates = data6
      .map(function(image) {
        return ee.Feature(null, {'dates': ee.Image(image).get('date')})
      })
      .aggregate_array('dates')
  //Reverse dates format from 'yyyy-mm-dd' to 'dd-mm-yyyy'
  var dates_reversed = ee.List.sequence(0, dates.length().subtract(1))
  .map(function (i) {
    return dates.getString(i).split('-').reverse().join('-')
  });
  // Combine dates list with cloud cover dates element wise.
  var datesandcloud = ee.List.sequence(0, Cloud_Cover.length().subtract(1))
  .map(function (i) {
    return dates_reversed.getString(i).cat(' (').cat(Cloud_Cover_String.getString(i)).cat('%)')
  });
  return datesandcloud
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
  var s2aTrue_Color_visualization = {
    min: 0,
    max: 4000,
    bands: ['B4', 'B3', 'B2'],
  }
    var s1cTrue_Color_visualization = {
    min: 0,
    max: 4000,
    bands: ['B4', 'B3', 'B2'],
  }
  var l8True_Color_visualization = {
  bands: ['B4', 'B3', 'B2'],
  min: 6500,
  max: 20000,
  }
  var l9True_Color_visualization = {
  bands: ['B4', 'B3', 'B2'],
  min: 6500,
  max: 20000,
  }
  var l5True_Color_visualization = {
  bands: ['B3', 'B2', 'B1'],
  min: 6500,
  max: 20000,
  }
  var NDVI_visualization = {
  min: 0,
  max: 1,
  palette: [
    'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01', '011301'
  ],
};
  var NDWI_visualization = {
  min: 0,
  max: 1,
  palette: ['87CEFA', '00BFFF', '1E90FF', '0000FF', '00008B'],
};
  var NDMI_visualization = {
  min: 0,
  max: 1,
  palette: ['faf6ec','e7d29f','a5c9a6','040eff','5a3a9d'],
};
var elev_visualization = {
    min: 0, 
    max: 1, 
    palette: [
    '0602ff', '235cb1', '307ef3', '269db1', '30c8e2', '32d3ef', '3ae237',
    'b5e22e', 'd6e21f', 'fff705', 'ffd611', 'ffb613', 'ff8b13', 'ff6e08',
    'ff500d', 'ff0000', 'de0101', 'c21301'
  ]};
function s2aproduction(date,aoii,Coverage_Days,mapping,minndmi,
maxndmi,minndvi,maxndvi,minndwi,maxndwi){
  var sentinel = ee.ImageCollection("COPERNICUS/S2_SR");
  var aoi = aoii;
  var datee = date
  var cloud_percentage = ee.Number(100)
  var data1 = sentinel.filterBounds(aoi).filterDate(datee,datee.advance(Coverage_Days,'day'))
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloud_percentage)).sort('CLOUDY_PIXEL_PERCENTAGE',false);
  // function applyScaleFactors(image) {
  // var opticalBands = image.select('B.').multiply(0.0001);
  // return image.addBands(opticalBands, null, true);
  // }
  // data = data.map(applyScaleFactors);
  var CLD_PRB_THRESH = 40
  // Import and filter s2cloudless.
  var s2_cloudless_col = (ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY')
    .filterBounds(aoi)
    .filterDate(datee, datee.advance(Coverage_Days,'day')))  
  // Join the filtered s2cloudless collection to the SR collection by the 'system:index' property.
  var data2 =  ee.ImageCollection(ee.Join.saveFirst('s2cloudless').apply({
    'primary': data1,
    'secondary': s2_cloudless_col,
    'condition': ee.Filter.equals({
        'leftField': 'system:index',
        'rightField': 'system:index'
    })
  }))  
  var data3 = data2.map(function(img){
    var cld_prb = ee.Image(img.get('s2cloudless')).select('probability')
    var is_cloud = cld_prb.gte(CLD_PRB_THRESH).rename('is_cloud')
    // var no_cloud = cld_prb.lt(CLD_PRB_THRESH).rename('no_cloud')
    var no_cloud = ee.Image.constant(100).subtract(cld_prb).rename('no_cloud')
    return img.addBands(ee.Image([cld_prb,is_cloud,no_cloud]))
  })
   // Get the list of image collection dates
  sourcedates = data3
      .map(function(image) {
        return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
      })
      .aggregate_array('date').distinct()
  var no_of_dates = sourcedates.length().getInfo()
  var no_of_scenes = data3.size().getInfo()
  if (no_of_dates > 1 && no_of_scenes > 1)
  {sourcedateslabel.setValue('Mosaic Dates:')}
  else if (no_of_dates == 1 && no_of_scenes > 1)
  {sourcedateslabel.setValue('Mosaic Date:')}
  else if (no_of_dates == 1 && no_of_scenes == 1)
  {sourcedateslabel.setValue('Image Date:')}
  sourcedates.evaluate(function(dates){
  dates = dates.sort()
  var  datees = dates.map(function(date) { 
  var parts = date.slice(0,10).split('-')
  var mydate = '  ' + parts.reverse().join('-') + '  '
  return mydate
  })
  sourcedatesbox.setValue(datees)  
  })
  var mosaic = data3.mosaic();
  var TrueColor = (mosaic.select(['B2','B3','B4','B8'], ['B2','B3','B4','B8'])).clip(aoi);
  var NDMI = (mosaic.normalizedDifference(['B8A','B11'])).clip(aoi);
  var NDWI = (mosaic.normalizedDifference(['B3','B8'])).clip(aoi);
  var NDVI
  var Governorate = Gov_selector.getValue()
  if(Governorate == 'Hammar Marsh' || Governorate == 'Huaizah Marsh')
      {NDVI = marshNDVI(datee)}
  else
      {NDVI = (mosaic.normalizedDifference(['B8','B4'])).clip(aoi)}
  NDMIscale = 20;
  NDVIscale = 10;
  NDWIscale = 10;
  calculatearea(NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),aoi,NDMIscale).evaluate(function(val){NDMIarea.setValue(val)})
  calculatearea(NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),aoi,NDVIscale).evaluate(function(val){NDVIarea.setValue(val)})
  calculatearea(NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),aoi,NDWIscale).evaluate(function(val){NDWIarea.setValue(val)})
  calculatemean(NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),aoi,NDMIscale).evaluate(function(val){NDMImean.setValue(val)})
  calculatemean(NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),aoi,NDVIscale).evaluate(function(val){NDVImean.setValue(val)})
  calculatemean(NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),aoi,NDWIscale).evaluate(function(val){NDWImean.setValue(val)})
  if (Autozoom.getValue() == 1)
  {mappingPanel.centerObject(TrueColor)}
  var True = ui.Map.Layer({eeObject: TrueColor,visParams: s2aTrue_Color_visualization,
  name: arabic_date + ' True Color'})
  if (definedmode.getValue() == 1)
  {True.setName(Gov_selector.getValue() + ' ' +arabic_date + ' True Color')}
  mappingPanel.add(True)
  var NDWII = ui.Map.Layer({eeObject: NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),visParams: NDWI_visualization,
  name: arabic_date + ' NDWI'})
  if (definedmode.getValue() == 1)
  {NDWII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDWI')}
  mappingPanel.add(NDWII)
  var NDMII = ui.Map.Layer({eeObject: NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),visParams: NDMI_visualization,
  name: arabic_date + ' NDMI'})
  if (definedmode.getValue() == 1)
  {NDMII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDMI')}
  mappingPanel.add(NDMII)
  var NDVII
  var Governorate = Gov_selector.getValue()
  if(Governorate == 'Hammar Marsh' || Governorate == 'Huaizah Marsh')
      {NDVII = ui.Map.Layer({eeObject: NDVI,visParams:{"opacity":1,"bands":["vis-red","vis-green","vis-blue"],"min":15.26148870132132,"max":115.43211399228136,"gamma":1.999},
      name: Gov_selector.getValue() + ' ' +arabic_date + ' NDVI'})
      mappingPanel.add(NDVII)}
  else
        {NDVII = ui.Map.Layer({eeObject: NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),visParams: NDVI_visualization,
        name: arabic_date + ' NDVI'})
        if (definedmode.getValue() == 1)
        {NDVII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDVI')}
        mappingPanel.add(NDVII)}
  var demlayerscount = 0
  var layers = mappingPanel.layers()
      layers.forEach(function(x) {
      var lay_name = x.getName()
      if (lay_name.search('Elevation') !== -1)
      {demlayerscount = demlayerscount + 1}
      })
      if (demlayerscount == 0 && mappingPanel.widgets().length() > 7)
      {mappingPanel.remove(mappingPanel.widgets().get(7))}
  var variablelist = [NDMII.getEeObject(),NDVII.getEeObject(),NDWII.getEeObject()]
  return variablelist
}
///////////////////////////////////////////////
function s1cproduction(date,aoii,Coverage_Days,mapping,minndmi,
maxndmi,minndvi,maxndvi,minndwi,maxndwi){
  var sentinel = ee.ImageCollection("COPERNICUS/S2");
  var aoi = aoii;
  var datee = date
  var cloud_percentage = ee.Number(100)
  var data1 = sentinel.filterBounds(aoi).filterDate(datee,datee.advance(Coverage_Days,'day'))
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloud_percentage)).sort('CLOUDY_PIXEL_PERCENTAGE',false);
  // function applyScaleFactors(image) {
  // var opticalBands = image.select('B.').multiply(0.0001);
  // return image.addBands(opticalBands, null, true);
  // }
  // data = data.map(applyScaleFactors);
  var CLD_PRB_THRESH = 40
  // Import and filter s2cloudless.
  var s2_cloudless_col = (ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY')
    .filterBounds(aoi)
    .filterDate(datee, datee.advance(Coverage_Days,'day')))  
  // Join the filtered s2cloudless collection to the SR collection by the 'system:index' property.
  var data2 =  ee.ImageCollection(ee.Join.saveFirst('s2cloudless').apply({
    'primary': data1,
    'secondary': s2_cloudless_col,
    'condition': ee.Filter.equals({
        'leftField': 'system:index',
        'rightField': 'system:index'
    })
  }))  
  var data3 = data2.map(function(img){
    var cld_prb = ee.Image(img.get('s2cloudless')).select('probability')
    var is_cloud = cld_prb.gte(CLD_PRB_THRESH).rename('is_cloud')
    // var no_cloud = cld_prb.lt(CLD_PRB_THRESH).rename('no_cloud')
    var no_cloud = ee.Image.constant(100).subtract(cld_prb).rename('no_cloud')
    return img.addBands(ee.Image([cld_prb,is_cloud,no_cloud]))
  })
   // Get the list of image collection dates
  sourcedates = data3
      .map(function(image) {
        return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
      })
      .aggregate_array('date').distinct()
  var no_of_dates = sourcedates.length().getInfo()
  var no_of_scenes = data3.size().getInfo()
  if (no_of_dates > 1 && no_of_scenes > 1)
  {sourcedateslabel.setValue('Mosaic Dates:')}
  else if (no_of_dates == 1 && no_of_scenes > 1)
  {sourcedateslabel.setValue('Mosaic Date:')}
  else if (no_of_dates == 1 && no_of_scenes == 1)
  {sourcedateslabel.setValue('Image Date:')}
  sourcedates.evaluate(function(dates){
  dates = dates.sort()
  var  datees = dates.map(function(date) { 
  var parts = date.slice(0,10).split('-')
  var mydate = '  ' + parts.reverse().join('-') + '  '
  return mydate
  })
  sourcedatesbox.setValue(datees)  
  })
  var mosaic = data3.mosaic();
  var TrueColor = (mosaic.select(['B2','B3','B4','B8'], ['B2','B3','B4','B8'])).clip(aoi);
  var NDMI = (mosaic.normalizedDifference(['B8A','B11'])).clip(aoi);
  var NDWI = (mosaic.normalizedDifference(['B3','B8'])).clip(aoi);
  var NDVI
  var Governorate = Gov_selector.getValue()
  if(Governorate == 'Hammar Marsh' || Governorate == 'Huaizah Marsh')
      {NDVI = marshNDVI(datee)}
  else
      {NDVI = (mosaic.normalizedDifference(['B8','B4'])).clip(aoi)}
  NDMIscale = 20;
  NDVIscale = 10;
  NDWIscale = 10;
  calculatearea(NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),aoi,NDMIscale).evaluate(function(val){NDMIarea.setValue(val)})
  calculatearea(NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),aoi,NDVIscale).evaluate(function(val){NDVIarea.setValue(val)})
  calculatearea(NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),aoi,NDWIscale).evaluate(function(val){NDWIarea.setValue(val)})
  calculatemean(NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),aoi,NDMIscale).evaluate(function(val){NDMImean.setValue(val)})
  calculatemean(NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),aoi,NDVIscale).evaluate(function(val){NDVImean.setValue(val)})
  calculatemean(NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),aoi,NDWIscale).evaluate(function(val){NDWImean.setValue(val)})
  if (Autozoom.getValue() == 1)
  {mappingPanel.centerObject(TrueColor)}
  var True = ui.Map.Layer({eeObject: TrueColor,visParams: s1cTrue_Color_visualization,
  name: arabic_date + ' True Color'})
  if (definedmode.getValue() == 1)
  {True.setName(Gov_selector.getValue() + ' ' +arabic_date + ' True Color')}
  mappingPanel.add(True)
  var NDWII = ui.Map.Layer({eeObject: NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),visParams: NDWI_visualization,
  name: arabic_date + ' NDWI'})
  if (definedmode.getValue() == 1)
  {NDWII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDWI')}
  mappingPanel.add(NDWII)
  var NDMII = ui.Map.Layer({eeObject: NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),visParams: NDMI_visualization,
  name: arabic_date + ' NDMI'})
  if (definedmode.getValue() == 1)
  {NDMII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDMI')}
  mappingPanel.add(NDMII)
  var NDVII
  var Governorate = Gov_selector.getValue()
  if(Governorate == 'Hammar Marsh' || Governorate == 'Huaizah Marsh')
      {NDVII = ui.Map.Layer({eeObject: NDVI,visParams:{"opacity":1,"bands":["vis-red","vis-green","vis-blue"],"min":15.26148870132132,"max":115.43211399228136,"gamma":1.999},
      name: Gov_selector.getValue() + ' ' +arabic_date + ' NDVI'})
      mappingPanel.add(NDVII)}
  else
        {NDVII = ui.Map.Layer({eeObject: NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),visParams: NDVI_visualization,
        name: arabic_date + ' NDVI'})
        if (definedmode.getValue() == 1)
        {NDVII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDVI')}
        mappingPanel.add(NDVII)}
  var demlayerscount = 0
  var layers = mappingPanel.layers()
      layers.forEach(function(x) {
      var lay_name = x.getName()
      if (lay_name.search('Elevation') !== -1)
      {demlayerscount = demlayerscount + 1}
      })
      if (demlayerscount == 0 && mappingPanel.widgets().length() > 7)
      {mappingPanel.remove(mappingPanel.widgets().get(7))}
  var variablelist = [NDMII.getEeObject(),NDVII.getEeObject(),NDWII.getEeObject()]
  return variablelist
}
///////////////////////////////////////////////
function l8production(date,aoii,Coverage_Days,mapping,minndmi,
maxndmi,minndvi,maxndvi,minndwi,maxndwi){
  var landsat = ee.ImageCollection("LANDSAT/LC08/C02/T1_L2");
  var aoi = aoii;
  var datee = date
  var data = landsat.filterBounds(aoi).filterDate(datee,datee.advance(Coverage_Days,'day')).sort('CLOUD_COVER',false);
  // function applyScaleFactors(image) {
  // var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  // var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
  // return image.addBands(opticalBands, null, true)
  //             .addBands(thermalBands, null, true);
  // }
  // data = data.map(applyScaleFactors);
  function calcclouds(image){
  var quality = image.select('QA_PIXEL');
  var c1 = quality.eq(22280)
  var c2 = quality.eq(24088)
  var c3 = quality.eq(24216)
  var c4 = quality.eq(24344)
  var c5 = quality.eq(24472)
  var c6 = quality.eq(55052)
  var c7 = quality.eq(56856)
  var c8 = quality.eq(56984)
  var c9 = quality.eq(57240)
  var mask = c1.or(c2).or(c3).or(c4).or(c5).or(c6).or(c7).or(c8).or(c9)
  return ee.Image(1).mask(mask).unmask(0)
}
  var data2 = data.map(function(img){
    var geom = img.geometry()
    var is_cloud = calcclouds(img).clip(geom).rename('is_cloud')
    var no_cloud = is_cloud.not().rename('no_cloud')
    return img.addBands(ee.Image([is_cloud,no_cloud]))
  })
// Get the list of image collection dates
  sourcedates = data2
      .map(function(image) {
        return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
      })
      .aggregate_array('date').distinct()
  var no_of_dates = sourcedates.length().getInfo()
  var no_of_scenes = data2.size().getInfo()
  if (no_of_dates > 1 && no_of_scenes > 1)
  {sourcedateslabel.setValue('Mosaic Dates:')}
  else if (no_of_dates == 1 && no_of_scenes > 1)
  {sourcedateslabel.setValue('Mosaic Date:')}
  else if (no_of_dates == 1 && no_of_scenes == 1)
  {sourcedateslabel.setValue('Image Date:')}
  sourcedates.evaluate(function(dates){
  dates = dates.sort()
  var  datees = dates.map(function(date) { 
  var parts = date.slice(0,10).split('-')
  var mydate = '  ' + parts.reverse().join('-') + '  '
  return mydate
  })
  sourcedatesbox.setValue(datees)  
  })
  var mosaic = data2.mosaic();
  var TrueColor = (mosaic.select(['SR_B2','SR_B3','SR_B4','SR_B6'], ['B2','B3','B4','B6'])).clip(aoi);
  var NDMI = (mosaic.normalizedDifference(['SR_B5','SR_B6'])).clip(aoi);
  var NDWI = (mosaic.normalizedDifference(['SR_B3','SR_B5'])).clip(aoi);
  var NDVI
  var Governorate = Gov_selector.getValue()
  if(Governorate == 'Hammar Marsh' || Governorate == 'Huaizah Marsh')
      {NDVI = marshNDVI(datee)}
  else
      {NDVI = (mosaic.normalizedDifference(['SR_B5','SR_B4'])).clip(aoi)}
  NDMIscale = 30;
  NDVIscale = 30;
  NDWIscale = 30;
  calculatearea(NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),aoi,NDMIscale).evaluate(function(val){NDMIarea.setValue(val)})
  calculatearea(NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),aoi,NDVIscale).evaluate(function(val){NDVIarea.setValue(val)})
  calculatearea(NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),aoi,NDWIscale).evaluate(function(val){NDWIarea.setValue(val)})
  calculatemean(NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),aoi,NDMIscale).evaluate(function(val){NDMImean.setValue(val)})
  calculatemean(NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),aoi,NDVIscale).evaluate(function(val){NDVImean.setValue(val)})
  calculatemean(NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),aoi,NDWIscale).evaluate(function(val){NDWImean.setValue(val)})
  if (Autozoom.getValue() == 1)
  {mappingPanel.centerObject(TrueColor)}
  var True = ui.Map.Layer({eeObject: TrueColor,visParams: l8True_Color_visualization,
  name: arabic_date + ' True Color'})
  if (definedmode.getValue() == 1)
  {True.setName(Gov_selector.getValue() + ' ' +arabic_date + ' True Color')}
  mappingPanel.add(True)
  var NDWII = ui.Map.Layer({eeObject: NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),visParams: NDWI_visualization,
  name: arabic_date + ' NDWI'})
  if (definedmode.getValue() == 1)
  {NDWII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDWI')}
  mappingPanel.add(NDWII)
  var NDMII = ui.Map.Layer({eeObject: NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),visParams: NDMI_visualization,
  name: arabic_date + ' NDMI'})
  if (definedmode.getValue() == 1)
  {NDMII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDMI')}
  mappingPanel.add(NDMII)
  var NDVII
  var Governorate = Gov_selector.getValue()
  if(Governorate == 'Hammar Marsh' || Governorate == 'Huaizah Marsh')
      {NDVII = ui.Map.Layer({eeObject: NDVI,visParams:{"opacity":1,"bands":["vis-red","vis-green","vis-blue"],"min":15.26148870132132,"max":115.43211399228136,"gamma":1.999},
      name: Gov_selector.getValue() + ' ' +arabic_date + ' NDVI'})
      mappingPanel.add(NDVII)}
  else
        {NDVII = ui.Map.Layer({eeObject: NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),visParams: NDVI_visualization,
        name: arabic_date + ' NDVI'})
        if (definedmode.getValue() == 1)
        {NDVII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDVI')}
        mappingPanel.add(NDVII)}
      var demlayerscount = 0
  var layers = mappingPanel.layers()
      layers.forEach(function(x) {
      var lay_name = x.getName()
      if (lay_name.search('Elevation') !== -1)
      {demlayerscount = demlayerscount + 1}
      })
      if (demlayerscount == 0 && mappingPanel.widgets().length() > 7)
      {mappingPanel.remove(mappingPanel.widgets().get(7))}
  var variablelist = [NDMII.getEeObject(),NDVII.getEeObject(),NDWII.getEeObject()]
  return variablelist
}
///////////////////////////////////////////////
function l9production(date,aoii,Coverage_Days,mapping,minndmi,
maxndmi,minndvi,maxndvi,minndwi,maxndwi){
  var landsat = ee.ImageCollection('LANDSAT/LC09/C02/T1_L2');
  var aoi = aoii;
  var datee = date
  var data = landsat.filterBounds(aoi).filterDate(datee,datee.advance(Coverage_Days,'day')).sort('CLOUD_COVER',false);
  // function applyScaleFactors(image) {
  // var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  // var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
  // return image.addBands(opticalBands, null, true)
  //             .addBands(thermalBands, null, true);
  // }
  // data = data.map(applyScaleFactors);
  function calcclouds(image){
  var quality = image.select('QA_PIXEL');
  var c1 = quality.eq(22280)
  var c2 = quality.eq(24088)
  var c3 = quality.eq(24216)
  var c4 = quality.eq(24344)
  var c5 = quality.eq(24472)
  var c6 = quality.eq(55052)
  var c7 = quality.eq(56856)
  var c8 = quality.eq(56984)
  var c9 = quality.eq(57240)
  var mask = c1.or(c2).or(c3).or(c4).or(c5).or(c6).or(c7).or(c8).or(c9)
  return ee.Image(1).mask(mask).unmask(0)
}
  var data2 = data.map(function(img){
    var geom = img.geometry()
    var is_cloud = calcclouds(img).clip(geom).rename('is_cloud')
    var no_cloud = is_cloud.not().rename('no_cloud')
    return img.addBands(ee.Image([is_cloud,no_cloud]))
  })
// Get the list of image collection dates
  sourcedates = data2
      .map(function(image) {
        return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
      })
      .aggregate_array('date').distinct()
  var no_of_dates = sourcedates.length().getInfo()
  var no_of_scenes = data2.size().getInfo()
  if (no_of_dates > 1 && no_of_scenes > 1)
  {sourcedateslabel.setValue('Mosaic Dates:')}
  else if (no_of_dates == 1 && no_of_scenes > 1)
  {sourcedateslabel.setValue('Mosaic Date:')}
  else if (no_of_dates == 1 && no_of_scenes == 1)
  {sourcedateslabel.setValue('Image Date:')}
  sourcedates.evaluate(function(dates){
  dates = dates.sort()
  var  datees = dates.map(function(date) { 
  var parts = date.slice(0,10).split('-')
  var mydate = '  ' + parts.reverse().join('-') + '  '
  return mydate
  })
  sourcedatesbox.setValue(datees)  
  })
  var mosaic = data2.mosaic();
  var TrueColor = (mosaic.select(['SR_B2','SR_B3','SR_B4','SR_B6'], ['B2','B3','B4','B6'])).clip(aoi);
  var NDMI = (mosaic.normalizedDifference(['SR_B5','SR_B6'])).clip(aoi);
  var NDWI = (mosaic.normalizedDifference(['SR_B3','SR_B5'])).clip(aoi);
  var NDVI
  var Governorate = Gov_selector.getValue()
  if(Governorate == 'Hammar Marsh' || Governorate == 'Huaizah Marsh')
      {NDVI = marshNDVI(datee)}
  else
      {NDVI = (mosaic.normalizedDifference(['SR_B5','SR_B4'])).clip(aoi)}
  NDMIscale = 30;
  NDVIscale = 30;
  NDWIscale = 30;
  calculatearea(NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),aoi,NDMIscale).evaluate(function(val){NDMIarea.setValue(val)})
  calculatearea(NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),aoi,NDVIscale).evaluate(function(val){NDVIarea.setValue(val)})
  calculatearea(NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),aoi,NDWIscale).evaluate(function(val){NDWIarea.setValue(val)})
  calculatemean(NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),aoi,NDMIscale).evaluate(function(val){NDMImean.setValue(val)})
  calculatemean(NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),aoi,NDVIscale).evaluate(function(val){NDVImean.setValue(val)})
  calculatemean(NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),aoi,NDWIscale).evaluate(function(val){NDWImean.setValue(val)})
  if (Autozoom.getValue() == 1)
  {mappingPanel.centerObject(TrueColor)}
  var True = ui.Map.Layer({eeObject: TrueColor,visParams: l9True_Color_visualization,
  name: arabic_date + ' True Color'})
  if (definedmode.getValue() == 1)
  {True.setName(Gov_selector.getValue() + ' ' +arabic_date + ' True Color')}
  mappingPanel.add(True)
  var NDWII = ui.Map.Layer({eeObject: NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),visParams: NDWI_visualization,
  name: arabic_date + ' NDWI'})
  if (definedmode.getValue() == 1)
  {NDWII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDWI')}
  mappingPanel.add(NDWII)
  var NDMII = ui.Map.Layer({eeObject: NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),visParams: NDMI_visualization,
  name: arabic_date + ' NDMI'})
  if (definedmode.getValue() == 1)
  {NDMII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDMI')}
  mappingPanel.add(NDMII)
  var NDVII
  var Governorate = Gov_selector.getValue()
  if(Governorate == 'Hammar Marsh' || Governorate == 'Huaizah Marsh')
      {NDVII = ui.Map.Layer({eeObject: NDVI,visParams:{"opacity":1,"bands":["vis-red","vis-green","vis-blue"],"min":15.26148870132132,"max":115.43211399228136,"gamma":1.999},
      name: Gov_selector.getValue() + ' ' +arabic_date + ' NDVI'})
      mappingPanel.add(NDVII)}
  else
        {NDVII = ui.Map.Layer({eeObject: NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),visParams: NDVI_visualization,
        name: arabic_date + ' NDVI'})
        if (definedmode.getValue() == 1)
        {NDVII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDVI')}
        mappingPanel.add(NDVII)}
      var demlayerscount = 0
  var layers = mappingPanel.layers()
      layers.forEach(function(x) {
      var lay_name = x.getName()
      if (lay_name.search('Elevation') !== -1)
      {demlayerscount = demlayerscount + 1}
      })
      if (demlayerscount == 0 && mappingPanel.widgets().length() > 7)
      {mappingPanel.remove(mappingPanel.widgets().get(7))}
  var variablelist = [NDMII.getEeObject(),NDVII.getEeObject(),NDWII.getEeObject()]
  return variablelist
}
///////////////////////////////////////////////
function l5production(date,aoii,Coverage_Days,mapping,minndmi,
maxndmi,minndvi,maxndvi,minndwi,maxndwi){
  var landsat = ee.ImageCollection("LANDSAT/LT05/C02/T1_L2");
  var aoi = aoii;
  var datee = ee.Date(date)
  var data = landsat.filterBounds(aoi).filterDate(datee,datee.advance(Coverage_Days,'day')).sort('CLOUD_COVER',false);
  // function applyScaleFactors(image) {
  //   var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  //   var thermalBand = image.select('ST_B6').multiply(0.00341802).add(149.0);
  //   return image.addBands(opticalBands, null, true)
  //               .addBands(thermalBand, null, true);
  // }
  // data = data.map(applyScaleFactors);
    function calcclouds(image){
  var quality = image.select('QA_PIXEL');
  var c1 = quality.bitwiseAnd(1<<3)
  var mask = c1;
  return ee.Image(1).mask(mask).unmask(0)
  }
  var data2 = data.map(function(img){
    var geom = img.geometry()
    var is_cloud = calcclouds(img).clip(geom).rename('is_cloud')
    var no_cloud = is_cloud.not().clip(geom).rename('no_cloud')
    return img.addBands(ee.Image([is_cloud,no_cloud]))
  })
// Get the list of image collection dates
  sourcedates = data2
      .map(function(image) {
        return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
      })
      .aggregate_array('date').distinct()
  var no_of_dates = sourcedates.length().getInfo()
  var no_of_scenes = data2.size().getInfo()
  if (no_of_dates > 1 && no_of_scenes > 1)
  {sourcedateslabel.setValue('Mosaic Dates:')}
  else if (no_of_dates == 1 && no_of_scenes > 1)
  {sourcedateslabel.setValue('Mosaic Date:')}
  else if (no_of_dates == 1 && no_of_scenes == 1)
  {sourcedateslabel.setValue('Image Date:')}
  sourcedates.evaluate(function(dates){
  dates = dates.sort()
  var  datees = dates.map(function(date) { 
  var parts = date.slice(0,10).split('-')
  var mydate = '  ' + parts.reverse().join('-') + '  '
  return mydate
  })
  sourcedatesbox.setValue(datees)  
  })
  var mosaic = data2.mosaic();
  var TrueColor = (mosaic.select(['SR_B1','SR_B2','SR_B3','SR_B4'], ['B1','B2','B3','B4'])).clip(aoi);
  var NDMI = (mosaic.normalizedDifference(['SR_B4','SR_B5'])).clip(aoi);
  var NDWI = (mosaic.normalizedDifference(['SR_B2','SR_B4'])).clip(aoi);
  var NDVI
  var Governorate = Gov_selector.getValue()
  if(Governorate == 'Hammar Marsh' || Governorate == 'Huaizah Marsh')
      {NDVI = marshNDVI(datee)}
  else
      {NDVI = (mosaic.normalizedDifference(['SR_B4','SR_B3'])).clip(aoi)}
  NDMIscale = 30;
  NDVIscale = 30;
  NDWIscale = 30;
  calculatearea(NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),aoi,NDMIscale).evaluate(function(val){NDMIarea.setValue(val)})
  calculatearea(NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),aoi,NDVIscale).evaluate(function(val){NDVIarea.setValue(val)})
  calculatearea(NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),aoi,NDWIscale).evaluate(function(val){NDWIarea.setValue(val)})
  calculatemean(NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),aoi,NDMIscale).evaluate(function(val){NDMImean.setValue(val)})
  calculatemean(NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),aoi,NDVIscale).evaluate(function(val){NDVImean.setValue(val)})
  calculatemean(NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),aoi,NDWIscale).evaluate(function(val){NDWImean.setValue(val)})
  if (Autozoom.getValue() == 1)
  {mappingPanel.centerObject(TrueColor)}
  var True = ui.Map.Layer({eeObject: TrueColor,visParams: l5True_Color_visualization,
  name: arabic_date + ' True Color'})
  if (definedmode.getValue() == 1)
  {True.setName(Gov_selector.getValue() + ' ' +arabic_date + ' True Color')}
  mappingPanel.add(True)
  var NDWII = ui.Map.Layer({eeObject: NDWI.updateMask(NDWI.gte(parseFloat(minndwi)).and(NDWI.lte(parseFloat(maxndwi)))),visParams: NDWI_visualization,
  name: arabic_date + ' NDWI'})
  if (definedmode.getValue() == 1)
  {NDWII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDWI')}
  mappingPanel.add(NDWII)
  var NDMII = ui.Map.Layer({eeObject: NDMI.updateMask(NDMI.gte(parseFloat(minndmi)).and(NDMI.lte(parseFloat(maxndmi))).and(NDWI.lt(0))),visParams: NDMI_visualization,
  name: arabic_date + ' NDMI'})
  if (definedmode.getValue() == 1)
  {NDMII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDMI')}
  mappingPanel.add(NDMII)
  var NDVII
  var Governorate = Gov_selector.getValue()
  if(Governorate == 'Hammar Marsh' || Governorate == 'Huaizah Marsh')
      {NDVII = ui.Map.Layer({eeObject: NDVI,visParams:{"opacity":1,"bands":["vis-red","vis-green","vis-blue"],"min":15.26148870132132,"max":115.43211399228136,"gamma":1.999},
      name: Gov_selector.getValue() + ' ' +arabic_date + ' NDVI'})
      mappingPanel.add(NDVII)}
  else
        {NDVII = ui.Map.Layer({eeObject: NDVI.updateMask(NDVI.gte(parseFloat(minndvi)).and(NDVI.lte(parseFloat(maxndvi))).and(NDWI.lt(0))),visParams: NDVI_visualization,
        name: arabic_date + ' NDVI'})
        if (definedmode.getValue() == 1)
        {NDVII.setName(Gov_selector.getValue() + ' ' +arabic_date + ' NDVI')}
        mappingPanel.add(NDVII)}
      var demlayerscount = 0
  var layers = mappingPanel.layers()
      layers.forEach(function(x) {
      var lay_name = x.getName()
      if (lay_name.search('Elevation') !== -1)
      {demlayerscount = demlayerscount + 1}
      })
      if (demlayerscount == 0 && mappingPanel.widgets().length() > 7)
      {mappingPanel.remove(mappingPanel.widgets().get(7))}
  var variablelist = [NDMII.getEeObject(),NDVII.getEeObject(),NDWII.getEeObject()]
  return variablelist
}
///////////////////////////////////////////////
function demproduction(aoii){
  var dem = ee.Image("NASA/NASADEM_HGT/001");
  var aoi = aoii;
  var elevation = dem.select('elevation').clip(aoi);
  if (Autozoom.getValue() == 1)
  {mappingPanel.centerObject(elevation)}
var minmax_elev = elevation.reduceRegion({
reducer: ee.Reducer.min().combine(ee.Reducer.max(),'',true),
geometry: aoi,
scale: DEMscale,
maxPixels: 1e10
})
minmax_elev.evaluate(function (MinMaxDict) {
  var elev_visualization = {
    min: MinMaxDict['elevation_min'], 
    max: MinMaxDict['elevation_max'], 
    palette: [
    '0602ff', '235cb1', '307ef3', '269db1', '30c8e2', '32d3ef', '3ae237',
    'b5e22e', 'd6e21f', 'fff705', 'ffd611', 'ffb613', 'ff8b13', 'ff6e08',
    'ff500d', 'ff0000', 'de0101', 'c21301'
  ]};
  var elev = ui.Map.Layer({eeObject: elevation,visParams: elev_visualization,
  name: 'Elevation (m)'})
  if (definedmode.getValue() == 1)
  {elev.setName(Gov_selector.getValue() + ' Elevation (m)')}
  mappingPanel.add(elev)
     // Get the list of image collection dates
  sourcedates = ["11-2-2000 --> 21-2-2000"]
  sourcedatesbox.setValue(sourcedates)
  sourcedateslabel.setValue('Mosaic Dates:')
  var demlayerscount = 0
  var layers = mappingPanel.layers()
      layers.forEach(function(x) {
      var lay_name = x.getName()
      if (lay_name.search('Elevation') !== -1)
      {demlayerscount = demlayerscount + 1}
      })
      if (demlayerscount !== 0 && mappingPanel.widgets().length() > 7)
      {mappingPanel.remove(mappingPanel.widgets().get(7))
        verticalcolorbar('DEM (m)',elev_visualization)
      }
       else if (demlayerscount !== 0 && mappingPanel.widgets().length() <= 7 )
       {verticalcolorbar('DEM (m)',elev_visualization)}
});
var elev = ui.Map.Layer({eeObject: elevation,name: 'Elevation (m)'})
  if (definedmode.getValue() == 1)
  {elev.setName(Gov_selector.getValue() + ' Elevation (m)')}
var variablelist = [elev.getEeObject()]
return variablelist
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function verticalcolorbar(title,viz){
    // set position of panel
      var legend = ui.Panel({
      layout: ui.Panel.Layout.flow({direction: 'horizontal',wrap: 1}),
      style: {
        position: 'bottom-left',
        padding: '8px 15px',
        backgroundColor: 'rgba(255, 255, 255, 0)',
      }
    });
  // Create legend title
  var legendTitle = ui.Label({
    value: title,
    style: {
      fontWeight: 'bold',
      fontSize: '18px',
      margin: '0 0 4px 0',
      padding: '6px',
      backgroundColor: 'rgba(255, 255, 255, 0)'
      }
  });
  if(title == 'NDVI')
  {legendTitle.style().set({padding:'8px'})}
   // Add the title to the panel
  legend.add(legendTitle); 
  // create the legend image
  var lon = ee.Image.pixelLonLat().select('longitude');
  var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
  var legendImage = gradient.visualize(viz);
  // create text on top of legend
  var panel1 = ui.Panel({
      widgets: [
        ui.Label({value: viz['min'],style :{backgroundColor: 'rgba(255, 255, 255, 0)',
          padding: '4px'
        }}),
      ],style :{backgroundColor: 'rgba(255, 255, 255, 0)'}
    });
  legend.add(panel1);
  // create thumbnail from the image
  var thumbnail = ui.Thumbnail({
    image: legendImage, 
    params: {bbox:'0,0,100,10', dimensions:'100x15'},  
    style: {padding: '1px', position: 'bottom-center'}
  });
  // add the thumbnail to the legend
  legend.add(thumbnail);
  // create text on top of legend
  var panel2 = ui.Panel({
      widgets: [
        ui.Label({value: viz['max'],style :{backgroundColor: 'rgba(255, 255, 255, 0)',
          padding: '4px'
        }}),
      ],style :{backgroundColor: 'rgba(255, 255, 255, 0)'}
    });
  legend.add(panel2);
  return mappingPanel.add(legend);
  }
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function updateNDVI(minn,maxx){
  var NDVIlayer = vars[1];
  var NDVIlayername = getlayernames()[0]
  var layers = mappingPanel.layers()
    layers.forEach(function(x) {
      var lay_name = x.getName()
      if (lay_name == Gov_selector.getValue() +' '+arabic_date + ' NDVI' || lay_name == arabic_date + ' NDVI')
      {x.setEeObject(NDVIlayer.updateMask(NDVIlayer.gte(parseFloat(minn)).and(NDVIlayer.lte(parseFloat(maxx)))))}
  })
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function updateNDMI(minn,maxx){
  var NDMIlayer = vars[0];
  var layers = mappingPanel.layers()
    layers.forEach(function(x) {
      var lay_name = x.getName()
      if (lay_name == Gov_selector.getValue() +' '+arabic_date + ' NDMI' || lay_name == arabic_date + ' NDMI')
      {x.setEeObject(NDMIlayer.updateMask(NDMIlayer.gte(parseFloat(minn)).and(NDMIlayer.lte(parseFloat(maxx)))))}
  })
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function updateNDWI(minn,maxx){
  var NDWIlayer = vars[2];
  var layers = mappingPanel.layers()
    layers.forEach(function(x) {
      var lay_name = x.getName()
      if (lay_name == Gov_selector.getValue() +' '+arabic_date + ' NDWI' || lay_name == arabic_date + ' NDWI')
      {x.setEeObject(NDWIlayer.updateMask(NDWIlayer.gte(parseFloat(minn)).and(NDWIlayer.lte(parseFloat(maxx)))))}
  })
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function getdate(date){
  var parts = date.slice(0,10).split('-')
  var mydate = parts.reverse().join('-')
  return mydate
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function clearmap(){
  if (mappingPanel.layers().length() >= 5)
  {
  var layers = mappingPanel.layers()
  layers.reset()
  }
  else if(mappingPanel.layers().length() < 5)
  {
    var demlayerscount = 0;
    var layers = mappingPanel.layers()
    layers.forEach(function(x) {
      var lay_name = x.getName()
      if (lay_name.search('Elevation') !== -1)
      {demlayerscount = demlayerscount + 1}
      if (demlayerscount > 0 && sensor_selector.getValue() == 'dem')
      {layers.reset()}
      if (lay_name.search('Watershed') !== -1 || lay_name.search('Streams') !== -1)
      {layers.reset();watershedisdrawn = false}
    })
}
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function countDecimals(value) {
  if(isNaN(value) == false)
    {if (Math.floor(value) !== value)
        return value.toString().split(".")[1].length || 0;
    return 0;}
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
// Calculate area using raster method
//Create Equal-Area Projection
// var wkt = ' \
//   PROJCS["World_Behrmann",\
//     GEOGCS["GCS_WGS_1984",\
//         DATUM["WGS_1984",\
//             SPHEROID["WGS_1984",6378137,298.257223563]],\
//         PRIMEM["Greenwich",0],\
//         UNIT["Degree",0.017453292519943295]],\
//     PROJECTION["Behrmann"],\
//     PARAMETER["False_Easting",0],\
//     PARAMETER["False_Northing",0],\
//     PARAMETER["Central_Meridian",0],\
//     UNIT["Meter",1],\
//     AUTHORITY["EPSG","54017"]]'
// var World_Behrmann = ee.Projection(wkt); //Equal-Area Projection.
function calculatearea(raster,aoii,sscale){
  if (raster != undefined)
  {
  var aoi = aoii;
  var polygon_area = aoi.area(1e-3).divide(1e6)
  var data = ee.Image.pixelArea().divide(1e6).mask(raster.multiply(1e6))
  var raster_area = ee.Number(data.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: aoi,
    scale: sscale,
    maxPixels: 1E13
  }).get('area'))
  var areaPercentage = raster_area.divide(polygon_area).multiply(100).round()
  return ee.String(raster_area.round()).slice(0,-2).cat(' (').cat(ee.String(areaPercentage).slice(0,-2)).cat('%)')
  }
  else {return ee.String('')}
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
// Calculate mean of raster
function calculatemean(raster,aoii,sscale){
  if (raster != undefined)
  {
  var aoi = aoii;
  var mean = ee.Number(raster.reduceRegion({
  reducer: ee.Reducer.mean(),
  geometry: aoi,
  scale: sscale,
  maxPixels: 1e13
}).get('nd'))
return mean.format('%.2f')
}
else {return ee.String('')}
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function updateNDVIstats(){
  NDVIarea.setValue('')
  NDVImean.setValue('')
  var NDVIlayer;
  var layers = mappingPanel.layers()
    layers.forEach(
      function(x) {
      var lay_name = x.getName()
      if (lay_name == Gov_selector.getValue() +' '+arabic_date + ' NDVI' || lay_name == arabic_date + ' NDVI')
      {NDVIlayer = x.getEeObject()}
      })
  return [calculatearea(NDVIlayer,aoi,NDVIscale),calculatemean(NDVIlayer,aoi,NDVIscale)]
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function updateNDMIstats(){
  NDMIarea.setValue('')
  NDMImean.setValue('')
  var NDMIlayer;
  var layers = mappingPanel.layers()
    layers.forEach(
      function(x) {
      var lay_name = x.getName()
      if (lay_name == Gov_selector.getValue() +' '+arabic_date + ' NDMI' || lay_name == arabic_date + ' NDMI')
      {NDMIlayer = x.getEeObject()}
      })
  return [calculatearea(NDMIlayer,aoi,NDMIscale),calculatemean(NDMIlayer,aoi,NDMIscale)]
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function updateNDWIstats(){
  NDWIarea.setValue('')
  NDWImean.setValue('')
  var NDWIlayer;
  var layers = mappingPanel.layers()
    layers.forEach(
      function(x) {
      var lay_name = x.getName()
      if (lay_name == Gov_selector.getValue() +' '+arabic_date + ' NDWI' || lay_name == arabic_date + ' NDWI')
      {NDWIlayer = x.getEeObject()} 
      })
  return [calculatearea(NDWIlayer,aoi,NDWIscale),calculatemean(NDWIlayer,aoi,NDWIscale)]
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
var dm = ui.Panel([ui.Label('DEM')]);
dm.style().set({position: 'top-left'})
mappingPanel.add(dm);
var mi = ui.Panel([ui.Label('NDMI')]);
mi.style().set({position: 'top-left'})
mappingPanel.add(mi);
var vi = ui.Panel([ui.Label('NDVI')]);
vi.style().set({position: 'top-left'})
mappingPanel.add(vi);
var wi = ui.Panel([ui.Label('NDWI')]);
wi.style().set({position: 'top-left'})
mappingPanel.add(wi);
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
var drawingTools = mappingPanel.drawingTools();
drawingTools.setShown(false);
function drawPoint() {
  drawwatershedd.setDisabled(1)
  clearPoint()
  drawingTools.setSelected(PointGeometry);
  drawingTools.setShape('point');
  drawingTools.draw();
  drawingTools.onDraw(ui.util.debounce(checkpoint, 100))
}
var ppoint;
var pointisdrawn = false;
function checkpoint(){
if(PointGeometry.geometries({type:'Point'}).length() > 1)
  {
  pointisdrawn = true
  ppoint = PointGeometry.geometries({type:'Point'}).get(1);
  X_coord.setValue('');Y_coord.setValue('')
  ppoint.coordinates().get(0).evaluate(function(x){X_coord.setValue('');X_coord.setValue(x.toFixed(9))})
  ppoint.coordinates().get(1).evaluate(function(y){Y_coord.setValue('');Y_coord.setValue(y.toFixed(9))})
  if (mappingPanel.layers().length() > 0)
  {inspect()}
  clearPoint();
  drawingTools.stop();
  drawwatershedd.setDisabled(0)
  }
  else if(PointGeometry.geometries({type:'Point'}).length() > 0)
  {
  pointisdrawn = true
  ppoint = PointGeometry.geometries({type:'Point'}).get(0);
  X_coord.setValue(ppoint.coordinates().get(0).getInfo().toFixed(9))
  Y_coord.setValue(ppoint.coordinates().get(1).getInfo().toFixed(9))
  if (mappingPanel.layers().length() > 0)
  {inspect()}
  clearPoint();
  drawingTools.stop();
  drawwatershedd.setDisabled(0)
  }
  }
  ////////////////////////////////////
  function drawPointcoords() {
    drawwatershedd.setDisabled(1)
    var x = X_coord.getValue()
    var y = Y_coord.getValue()
    if (x.length !== 0){
    if(y.length !== 0){
  clearPoint()
  ppoint = ee.Geometry.Point(parseFloat(x), parseFloat(y));
  PointGeometry.fromGeometry(ppoint)
  if(PointGeometry.geometries({type:'Point'}).length() > 0)
  {drawwatershedd.setDisabled(0)
  if (Autozoom.getValue() == 1){
  mappingPanel.setCenter(parseFloat(x), parseFloat(y), 8)}
  if (mappingPanel.layers().length() > 0)
  {inspect()}}
}}}
  /////////////////////////////////////////////
  function clearPoint() {
  while (PointGeometry.geometries({type:'Point'}).length() > 1)
  {
  PointGeometry.geometries().remove(PointGeometry.geometries({type:'Point'}).get(0));
}}
function inspect(){
var TrueColorlayer;var NDMIlayer;var NDVIlayer;var NDWIlayer;var DEMlayer
var NDVIlayername = getlayernames()[0]
var NDMIlayername = getlayernames()[1]
var NDWIlayername = getlayernames()[2]
var TrueColorlayername = getlayernames()[3]
var DEMlayername = getlayernames()[4]
//////////////////////////////////////////////////////
// True Color
var layers = mappingPanel.layers()
var point = ppoint;
var layers = mappingPanel.layers()
layers.forEach(
    function(x)
    {
        var lay_name = x.getName()
///////////////////////////////////////////////
// NDMI
        if (lay_name == NDMIlayername)
        {
            NDMIlayer = x.getEeObject()
        try
        {
            // Show the loading label.
            mi.widgets().set(0, ui.Label(
            {
                value: 'Loading...',
                style:
                {
                    color: 'gray'
                }
            }));
            var NDMIvalue = NDMIlayer.sample(
            {
                region: point,
                dropNulls: false,
                scale: NDMIscale
            }).first().get('nd')
            NDMIvalue.evaluate(function(result)
            {
                if (result == null)
                {
                    mi.widgets().set(0, ui.Label(
                    {
                        value: 'NDMI: NoData',
                        style:
                        {
                            color: 'gray'
                        }
                    }))
                }
                else
                {
                    mi.widgets().set(0, ui.Label(
                    {
                        value: 'NDMI: ' + result.toFixed(2),
                    }))
                }
            })
        }
        catch (error)
        {
            mi.widgets().set(0, ui.Label(
            {
                value: 'NDMI',
                style:
                {
                    color: 'black'
                }
            }))
        }
    }
///////////////////////////////////////////////
// NDVI
      else if (lay_name == NDVIlayername)
        {
            NDVIlayer = x.getEeObject()
        try
        {
            // Show the loading label.
            vi.widgets().set(0, ui.Label(
            {
                value: 'Loading...',
                style:
                {
                    color: 'gray'
                }
            }));
            var NDVIvalue = NDVIlayer.sample(
            {
                region: point,
                dropNulls: false,
                scale: NDVIscale
            }).first().get('nd')
            NDVIvalue.evaluate(function(result)
            {
                if (result == null)
                {
                    vi.widgets().set(0, ui.Label(
                    {
                        value: 'NDVI: NoData',
                        style:
                        {
                            color: 'gray'
                        }
                    }))
                }
                else
                {
                    vi.widgets().set(0, ui.Label(
                    {
                        value: 'NDVI: ' + result.toFixed(2),
                    }))
                }
            })
        }
        catch (error)
        {
            vi.widgets().set(0, ui.Label(
            {
                value: 'NDVI',
                style:
                {
                    color: 'black'
                }
            }))
        }
      }
///////////////////////////////////////////////
// NDWI
        else if (lay_name == NDWIlayername)
        {
            NDWIlayer = x.getEeObject()
        try
        {
            // Show the loading label.
            wi.widgets().set(0, ui.Label(
            {
                value: 'Loading...',
                style:
                {
                    color: 'gray'
                }
            }));
            var NDWIvalue = NDWIlayer.sample(
            {
                region: point,
                dropNulls: false,
                scale: NDWIscale
            }).first().get('nd')
            NDWIvalue.evaluate(function(result)
            {
                if (result == null)
                {
                    wi.widgets().set(0, ui.Label(
                    {
                        value: 'NDWI: NoData',
                        style:
                        {
                            color: 'gray'
                        }
                    }))
                }
                else
                {
                    wi.widgets().set(0, ui.Label(
                    {
                        value: 'NDWI: ' + result.toFixed(2),
                    }))
                }
            })
        }
        catch (error)
        {
            wi.widgets().set(0, ui.Label(
            {
                value: 'NDWI',
                style:
                {
                    color: 'black'
                }
            }))
        }
        }
///////////////////////////////////////////////
// DEM
        else if (lay_name == DEMlayername)
        {
            DEMlayer = x.getEeObject()
        try
        {
            // Show the loading label.
            dm.widgets().set(0, ui.Label(
            {
                value: 'Loading...',
                style:
                {
                    color: 'gray'
                }
            }));
            var DEMvalue = DEMlayer.sample(
            {
                region: point,
                dropNulls: false,
                scale: DEMscale
            }).first().get('elevation')
            DEMvalue.evaluate(function(result)
            {
                if (result == null)
                {
                    dm.widgets().set(0, ui.Label(
                    {
                        value: 'DEM: NoData',
                        style:
                        {
                            color: 'gray'
                        }
                    }))
                }
                else
                {
                    dm.widgets().set(0, ui.Label(
                    {
                        value: 'DEM: ' + result.toFixed(0),
                    }))
                }
            })
        }
        catch (error)
        {
            dm.widgets().set(0, ui.Label(
            {
                value: 'DEM',
                style:
                {
                    color: 'black'
                }
            }))
        }
}
})
}
/*
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
*/
var PolygonGeometry = ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: '23cba7'});
drawingTools.layers().add(PolygonGeometry);
var PointGeometry = ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: 'd73027'});
drawingTools.layers().add(PointGeometry);
// function clearGeometry() {
//   var layers = drawingTools.layers();
//   while (drawingTools.layers().get(0).geometries().length() > 0) {
//   layers.get(0).geometries().remove(layers.get(0).geometries({type:'Polygon'}).get(0))
// }}
function clearPolygon(){
  while (PolygonGeometry.geometries({type:'Polygon'}).length() > 0)
  {
  PolygonGeometry.geometries().remove(PolygonGeometry.geometries({type:'Polygon'}).get(0));
}
polygonisdrawn = false;
// AutoDetect.setDisabled(1)
}
function drawPolygon() {
  clearPolygon();
  drawingTools.unlisten()
  var bb = ['Select a value']
  av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
  ProdButton.setDisabled(1);CloudButton.setDisabled(1);Days_selector.setDisabled(1);AutoDetect.setDisabled(1)
  minNDMI.setValue(0) && maxNDMI.setValue(1) && minNDMI.setDisabled(1) && maxNDMI.setDisabled(1)
  minNDVI.setValue(0) && maxNDVI.setValue(1) && minNDVI.setDisabled(1) && maxNDVI.setDisabled(1)
  minNDWI.setValue(0) && maxNDWI.setValue(1) && minNDWI.setDisabled(1) && maxNDWI.setDisabled(1)
  downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
  NDMIarea.setValue('') && NDMImean.setValue('')
  NDVIarea.setValue('') && NDVImean.setValue('')
  NDWIarea.setValue('') && NDWImean.setValue('')
  suggestLabel2.style().set({shown: false});polytextbox.setValue('')
  suggestLabel3.style().set({shown: false})
  drawingTools.setSelected(PolygonGeometry)
  drawingTools.setShape('polygon');
  drawingTools.draw();
  drawingTools.onDraw(ui.util.debounce(checkpolygon, 100))
}
function drawRectangle() {
  drawingTools.unlisten()
  clearPolygon();
  var bb = ['Select a value']
  av_dates.items().reset(bb) && av_dates.setValue(bb[0]) && av_dates.setPlaceholder(bb[0]) && av_dates.setDisabled(1)
  ProdButton.setDisabled(1);CloudButton.setDisabled(1);Days_selector.setDisabled(1);AutoDetect.setDisabled(1)
  minNDMI.setValue(0) && maxNDMI.setValue(1) && minNDMI.setDisabled(1) && maxNDMI.setDisabled(1)
  minNDVI.setValue(0) && maxNDVI.setValue(1) && minNDVI.setDisabled(1) && maxNDVI.setDisabled(1)
  minNDWI.setValue(0) && maxNDWI.setValue(1) && minNDWI.setDisabled(1) && maxNDWI.setDisabled(1)
  downtext.setDisabled(1);downtext.setValue('');downsnippet.setDisabled(1);EPSG_number.setDisabled(1)
  NDMIarea.setValue('') && NDMImean.setValue('')
  NDVIarea.setValue('') && NDVImean.setValue('')
  NDWIarea.setValue('') && NDWImean.setValue('')
  suggestLabel2.style().set({shown: false});polytextbox.setValue('')
  suggestLabel3.style().set({shown: false})
  drawingTools.setSelected(PolygonGeometry)
  drawingTools.setShape('rectangle');
  drawingTools.draw();
  drawingTools.onDraw(ui.util.debounce(checkpolygon, 100))
}
var polygonisdrawn = false;
function checkpolygon(){
if(PolygonGeometry.geometries({type:'Polygon'}).length() > 0)
  {
  polygonisdrawn = true
  // aoi = PolygonGeometry.geometries({type:'Polygon'}).get(0);
  aoi = PolygonGeometry.toGeometry();
  EPSG_number.setValue('')
  utmzone.setValue('')
  if(sensor_selector.getValue() == 's2a' || sensor_selector.getValue() == 's1c' || sensor_selector.getValue() == 'l8' || sensor_selector.getValue() == 'l9' || sensor_selector.getValue() == 'l5')
  {lonlattoepsg().evaluate(function(val){EPSG_number.setValue(val)})
  lonlattoutm().evaluate(function(val){utmzone.setValue(val)})}
  else if(sensor_selector.getValue() == 'dem')
  {EPSG_number.setValue('4326')
   utmzone.setValue('WGS84')}
  if (custommode.getValue() == 1)
  {ProdButton.setDisabled(0);CloudButton.setDisabled(0);Days_selector.setDisabled(0);AutoDetect.setDisabled(0)}
  drawingTools.stop();
  }
  }
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function marshNDVI(date){
var sentinel = ee.ImageCollection("COPERNICUS/S2_SR");
var ndviaoi;
var Governorate = Gov_selector.getValue()
if(Governorate == 'Hammar Marsh')
{ndviaoi = ee.FeatureCollection("users/Yousif_Almamalachy/Hammar_Marsh_NDVI")}
else if(Governorate == 'Huaizah Marsh') 
{ndviaoi = ee.FeatureCollection("users/Yousif_Almamalachy/Huaizah_Marsh_NDVI")}
var ddate = ee.Date(date)
var data = sentinel.filterBounds(ndviaoi).filterDate(ddate,ddate.advance(1,'day'))
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 100));
var mosaic = data.mosaic();
var NDVI = (mosaic.normalizedDifference(['B8','B4'])).clip(ndviaoi);
var Max_NDVI = NDVI.reduceRegion({
  reducer: ee.Reducer.max(),
  geometry: ndviaoi.geometry(),
  scale: 10,
  maxPixels: 1e10
});
var Max_NDVI=Max_NDVI.getNumber('nd');
var Min_NDVI = NDVI.reduceRegion({
  reducer: ee.Reducer.min(),
  geometry: ndviaoi.geometry(),
  scale: 10,
  maxPixels: 1e10
});
var Min_NDVI=Min_NDVI.getNumber('nd')
////////////////////////
var NDVI_1 = NDVI.updateMask(NDVI.gte(Min_NDVI).and(NDVI.lt(-1.1)));
var NDVI_1_RGB = NDVI_1.visualize({
    min: Min_NDVI, 
    max: -1.1, 
    palette: ['000000', '000000']
  });
var NDVI_2 = NDVI.updateMask(NDVI.gte(-1.1).and(NDVI.lt(-0.2)));
var NDVI_2_RGB = NDVI_2.visualize({
    min: -1.1, 
    max: -0.2, 
    palette: ['4B4B4B', '4B4B4B']
  });
var NDVI_3 = NDVI.updateMask(NDVI.gte(-0.2).and(NDVI.lt(-0.1)));
var NDVI_3_RGB = NDVI_3.visualize({
    min: -0.2, 
    max: -0.1, 
    palette: ['565656', '565656']
  });
var NDVI_4 = NDVI.updateMask(NDVI.gte(-0.1).and(NDVI.lt(0)));
var NDVI_4_RGB = NDVI_4.visualize({
    min: -0.1, 
    max: 0, 
    palette: ['646458', '646458']
  });
var NDVI_5 = NDVI.updateMask(NDVI.gte(0).and(NDVI.lt(0.025)));
var NDVI_5_RGB = NDVI_5.visualize({
    min: 0, 
    max: 0.025, 
    palette: ['646250', '646250']
  });
var NDVI_6 = NDVI.updateMask(NDVI.gte(0.025).and(NDVI.lt(0.05)));
var NDVI_6_RGB = NDVI_6.visualize({
    min: 0.025, 
    max: 0.05, 
    palette: ['5D5B47', '5D5B47']
  });
var NDVI_7 = NDVI.updateMask(NDVI.gte(0.05).and(NDVI.lt(0.075)));
var NDVI_7_RGB = NDVI_7.visualize({
    min: 0.05, 
    max: 0.075, 
    palette: ['57553D', '57553D']
  });
var NDVI_8 = NDVI.updateMask(NDVI.gte(0.075).and(NDVI.lt(0.1)));
var NDVI_8_RGB = NDVI_8.visualize({
    min: 0.075, 
    max: 0.1, 
    palette: ['504E33', '504E33']
  });
var NDVI_9 = NDVI.updateMask(NDVI.gte(0.1).and(NDVI.lt(0.125)));
var NDVI_9_RGB = NDVI_9.visualize({
    min: 0.1, 
    max: 0.125, 
    palette: ['4A482A', '4A482A']
  });
var NDVI_10 = NDVI.updateMask(NDVI.gte(0.125).and(NDVI.lt(0.15)));
var NDVI_10_RGB = NDVI_10.visualize({
    min: 0.125, 
    max: 0.15, 
    palette: ['454C26', '454C26']
  });
var NDVI_11 = NDVI.updateMask(NDVI.gte(0.15).and(NDVI.lt(0.175)));
var NDVI_11_RGB = NDVI_11.visualize({
    min: 0.15, 
    max: 0.175, 
    palette: ['405023', '405023']
  });
var NDVI_12 = NDVI.updateMask(NDVI.gte(0.175).and(NDVI.lt(0.2)));
var NDVI_12_RGB = NDVI_12.visualize({
    min: 0.175, 
    max: 0.2, 
    palette: ['394B20', '394B20']
  });
var NDVI_13 = NDVI.updateMask(NDVI.gte(0.2).and(NDVI.lt(0.25)));
var NDVI_13_RGB = NDVI_13.visualize({
    min: 0.2, 
    max: 0.25, 
    palette: ['32461C', '32461C']
  });
var NDVI_14 = NDVI.updateMask(NDVI.gte(0.25).and(NDVI.lt(0.3)));
var NDVI_14_RGB = NDVI_14.visualize({
    min: 0.25, 
    max: 0.3, 
    palette: ['2C4019', '2C4019']
  });
var NDVI_15 = NDVI.updateMask(NDVI.gte(0.3).and(NDVI.lt(0.35)));
var NDVI_15_RGB = NDVI_15.visualize({
    min: 0.3, 
    max: 0.35, 
    palette: ['263B15', '263B15']
  });
var NDVI_16 = NDVI.updateMask(NDVI.gte(0.35).and(NDVI.lt(0.4)));
var NDVI_16_RGB = NDVI_16.visualize({
    min: 0.35, 
    max: 0.4, 
    palette: ['1F3612', '1F3612']
  });
var NDVI_17 = NDVI.updateMask(NDVI.gte(0.4).and(NDVI.lt(0.45)));
var NDVI_17_RGB = NDVI_17.visualize({
    min: 0.4, 
    max: 0.45, 
    palette: ['19310E', '19310E']
  });
var NDVI_18 = NDVI.updateMask(NDVI.gte(0.45).and(NDVI.lt(0.5)));
var NDVI_18_RGB = NDVI_18.visualize({
    min: 0.45, 
    max: 0.5, 
    palette: ['132B0B', '132B0B']
  });
var NDVI_19 = NDVI.updateMask(NDVI.gte(0.5).and(NDVI.lt(0.55)));
var NDVI_19_RGB = NDVI_19.visualize({
    min: 0.5, 
    max: 0.55, 
    palette: ['0D2607', '0D2607']
  });
var NDVI_20 = NDVI.updateMask(NDVI.gte(0.55).and(NDVI.lt(0.6)));
var NDVI_20_RGB = NDVI_20.visualize({
    min: 0.55, 
    max: 0.6, 
    palette: ['062104', '062104']
  });
var NDVI_21 = NDVI.updateMask(NDVI.gte(0.6).and(NDVI.lte(Max_NDVI)));
var NDVI_21_RGB = NDVI_21.visualize({
    min: 0.6, 
    max: Max_NDVI, 
    palette: ['001B00', '001B00']
  });
////////////////////////
var NDVI_Sub_Final = ee.ImageCollection([NDVI_1_RGB, NDVI_2_RGB, NDVI_3_RGB, NDVI_4_RGB, NDVI_5_RGB, NDVI_6_RGB, NDVI_7_RGB, NDVI_8_RGB, NDVI_9_RGB, NDVI_10_RGB, NDVI_11_RGB, NDVI_12_RGB, NDVI_13_RGB, NDVI_14_RGB, NDVI_15_RGB, NDVI_16_RGB, NDVI_17_RGB, NDVI_18_RGB, NDVI_19_RGB, NDVI_20_RGB, NDVI_21_RGB]).mosaic();
var NDVI_Final = NDVI_Sub_Final
return NDVI_Final
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function s2aCdaysCheck(){
// This function calculates the minimal days required for sentinel 2 collection
// to cover at least 99% of a specific aoi (area of interest). 
// It generates a mosaic for every number of days (starting with 1 day)
// then it calculates it's aerial coverage with respect to aoi and test If it exceeds 99% or not.
// If not the number of days is incresed and the procedure is repeated. Otherwise the loop terminates.
var list = ee.List.sequence(1,4) //Iterate for 5 days.
//In each iteration if check1 function returns 0 then add 1 to the previous iteration and rerun check1
// Else if check1 returns 999 or any number other than 0 then return 999
/// 999 is used as a flag to terminate the iteration.
var addone = function(current,previous){
  previous = ee.List(previous)
  var pr = ee.Number(previous.get(-1))
  var cu = ee.Number(current)
  var cd = ee.Number(check1(pr,aoi))
  var n1 = ee.Algorithms.If(cd.eq(ee.Number(0)),pr.add(1),
           ee.Algorithms.If(cd.eq(ee.Number(999)),
           ee.Number(999),ee.Number(999)))
  return previous.add(ee.Number(n1))
}
var start = [1] //Start iteration at 1
var result = ee.List(list.iterate(addone,start))
result = ee.String(result.filter(ee.Filter.lt('item', 999)).get(-1)) 
return ee.String(result)
///////////////////////////////////////////////
function check1(i,aoii){
  // If i equals to 999 then don't go further... just return 999.
  // Else if i equals any number other than 999 or 0 then move forward with the continu function.
  return ee.Number(ee.Algorithms.If(ee.Number(i).neq(ee.Number(999)),
                   continu(ee.Number(i),aoii),ee.Number(999)))
  function continu(i,aoii){
    var aa = i
    var sentinel = ee.ImageCollection("COPERNICUS/S2_SR");
    var aoi = aoii;
    var sStart_Date = ee.Date(Date.now()).advance(-30,'day')
    var eEnd_Date =  ee.Date(Date.now()).advance(-20,'day')
    var aAllowed_Cloud = 100
    var Minimum_Areal_Coverage = 0.999
    var cCoverage_Days = aa
    var data = sentinel.filterBounds(aoi).filterDate(sStart_Date,eEnd_Date)
      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', aAllowed_Cloud));
    // var sscale=data.first().select('B1').projection().nominalScale().getInfo()
    var sscale= 10
    var polygon_area = aoi.area(1e-3).divide(1e6)
    var minimum_area = ee.Number(polygon_area).multiply(Minimum_Areal_Coverage)
    // Get the dates of filtered images with less than specified cloud percentage
    var dates = data
        .map(function(image) {
          return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
        })
        .aggregate_array('date')
    // Filter Images that doesn't contain all bands
    var data = data.map(function(n) {
      return n.set('Num_of_bands',n.bandNames().length());
    })
    data = data.filterMetadata("Num_of_bands","equals",23);
    // Mosaic images of the same date/date range and calculate the area of the mosaic
    // return the result as image collection 
    var dd = ee.ImageCollection(
      ee.List(dates.distinct()).map(function (n) {
      var date = ee.Date(n)
      var filtered = data.filterDate(date, date.advance(cCoverage_Days,'day')) 
      var image = ee.Image(filtered.mosaic())
      var data1 = ee.Image(1).mask(image.select('B2'))
      var raster_area = data1.multiply(ee.Image.pixelArea()).reduceRegion({
        reducer: ee.Reducer.sum(),
        geometry: aoi,
        scale: sscale,
        maxPixels: 1E13
      }).get('constant')
      raster_area=ee.Number(raster_area).divide(1e6)
      return image.set({'date':n,'Area_KM2':raster_area})
    }));
    // Filter Images that doesn't cover 99% of polygon area
    var data2 = dd.filterMetadata("Area_KM2","greater_than",ee.Number(minimum_area));
    var ii = ee.Number(ee.Algorithms.If(ee.Number(data2.size()).gt(0),ee.Number(i),ee.Number(0)))
    return ii //return the number of image collections that covers 99% of specified aoi (area of interest)
}
}
}
///////////////////////////////////////////////
function s1cCdaysCheck(){
// This function calculates the minimal days required for sentinel 2 collection
// to cover at least 99% of a specific aoi (area of interest). 
// It generates a mosaic for every number of days (starting with 1 day)
// then it calculates it's aerial coverage with respect to aoi and test If it exceeds 99% or not.
// If not the number of days is incresed and the procedure is repeated. Otherwise the loop terminates.
var list = ee.List.sequence(1,4) //Iterate for 5 days.
//In each iteration if check1 function returns 0 then add 1 to the previous iteration and rerun check1
// Else if check1 returns 999 or any number other than 0 then return 999
/// 999 is used as a flag to terminate the iteration.
var addone = function(current,previous){
  previous = ee.List(previous)
  var pr = ee.Number(previous.get(-1))
  var cu = ee.Number(current)
  var cd = ee.Number(check1(pr,aoi))
  var n1 = ee.Algorithms.If(cd.eq(ee.Number(0)),pr.add(1),
           ee.Algorithms.If(cd.eq(ee.Number(999)),
           ee.Number(999),ee.Number(999)))
  return previous.add(ee.Number(n1))
}
var start = [1] //Start iteration at 1
var result = ee.List(list.iterate(addone,start))
result = ee.String(result.filter(ee.Filter.lt('item', 999)).get(-1)) 
return ee.String(result)
///////////////////////////////////////////////
function check1(i,aoii){
  // If i equals to 999 then don't go further... just return 999.
  // Else if i equals any number other than 999 or 0 then move forward with the continu function.
  return ee.Number(ee.Algorithms.If(ee.Number(i).neq(ee.Number(999)),
                   continu(ee.Number(i),aoii),ee.Number(999)))
  function continu(i,aoii){
    var aa = i
    var sentinel = ee.ImageCollection("COPERNICUS/S2");
    var aoi = aoii;
    var sStart_Date = ee.Date(Date.now()).advance(-30,'day')
    var eEnd_Date =  ee.Date(Date.now()).advance(-20,'day')
    var aAllowed_Cloud = 100
    var Minimum_Areal_Coverage = 0.999
    var cCoverage_Days = aa
    var data = sentinel.filterBounds(aoi).filterDate(sStart_Date,eEnd_Date)
      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', aAllowed_Cloud));
    // var sscale=data.first().select('B1').projection().nominalScale().getInfo()
    var sscale= 10
    var polygon_area = aoi.area(1e-3).divide(1e6)
    var minimum_area = ee.Number(polygon_area).multiply(Minimum_Areal_Coverage)
    // Get the dates of filtered images with less than specified cloud percentage
    var dates = data
        .map(function(image) {
          return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
        })
        .aggregate_array('date')
    // Filter Images that doesn't contain all bands
    var data = data.map(function(n) {
      return n.set('Num_of_bands',n.bandNames().length());
    });
    data = data.filterMetadata("Num_of_bands","equals",16);
    // Mosaic images of the same date/date range and calculate the area of the mosaic
    // return the result as image collection 
    var dd = ee.ImageCollection(
      ee.List(dates.distinct()).map(function (n) {
      var date = ee.Date(n)
      var filtered = data.filterDate(date, date.advance(cCoverage_Days,'day')) 
      var image = ee.Image(filtered.mosaic())
      var data1 = ee.Image(1).mask(image.select('B2'))
      var raster_area = data1.multiply(ee.Image.pixelArea()).reduceRegion({
        reducer: ee.Reducer.sum(),
        geometry: aoi,
        scale: sscale,
        maxPixels: 1E13
      }).get('constant')
      raster_area=ee.Number(raster_area).divide(1e6)
      return image.set({'date':n,'Area_KM2':raster_area})
    }));
    // Filter Images that doesn't cover 99% of polygon area
    var data2 = dd.filterMetadata("Area_KM2","greater_than",ee.Number(minimum_area));
    var ii = ee.Number(ee.Algorithms.If(ee.Number(data2.size()).gt(0),ee.Number(i),ee.Number(0)))
    return ii //return the number of image collections that covers 99% of specified aoi (area of interest)
}
}
}
///////////////////////////////////////////////
function l8CdaysCheck(){
// This function calculates the minimal days required for sentinel 2 collection
// to cover at least 99% of a specific aoi (area of interest). 
// It generates a mosaic for every number of days (starting with 1 day)
// then it calculates it's aerial coverage with respect to aoi and test If it exceeds 99% or not.
// If not the number of days is incresed and the procedure is repeated. Otherwise the loop terminates.
var list = ee.List.sequence(1,15) //Iterate for 15 days.
//In each iteration if check1 function returns 0 then add 1 to the previous iteration and rerun check1
// Else if check1 returns 999 or any number other than 0 then return 999
/// 999 is used as a flag to terminate the iteration.
var addone = function(current,previous){
  previous = ee.List(previous)
  var pr = ee.Number(previous.get(-1))
  var cu = ee.Number(current)
  var cd = ee.Number(check1(pr,aoi))
  var n1 = ee.Algorithms.If(cd.eq(ee.Number(0)),pr.add(1),
           ee.Algorithms.If(cd.eq(ee.Number(999)),
           ee.Number(999),ee.Number(999)))
  return previous.add(ee.Number(n1))
}
var start = [1] //Start iteration at 1
var result = ee.List(list.iterate(addone,start))
result = ee.String(result.filter(ee.Filter.lt('item', 999)).get(-1)) 
return ee.String(result)
///////////////////////////////////////////////
function check1(i,aoii){
  // If i equals to 999 then don't go further... just return 999.
  // Else if i equals any number other than 999 or 0 then move forward with the continu function.
  return ee.Number(ee.Algorithms.If(ee.Number(i).neq(ee.Number(999)),
                   continu(ee.Number(i),aoii),ee.Number(999)))
  function continu(i,aoii){
    var aa = i
    var landsat = ee.ImageCollection("LANDSAT/LC08/C02/T1_L2");
    var aoi = aoii;
    var sStart_Date = ee.Date(Date.now()).advance(-2,'month')
    var eEnd_Date =  ee.Date(Date.now()).advance(-1,'month')
    var Minimum_Areal_Coverage = 0.999
    var cCoverage_Days = aa
    var data = landsat.filterBounds(aoi).filterDate(sStart_Date,eEnd_Date);
    // function applyScaleFactors(image) {
    // var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
    // var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
    // return image.addBands(opticalBands, null, true)
    //           .addBands(thermalBands, null, true);
    // }
    // data = data.map(applyScaleFactors);
    var sscale = 30
    var polygon_area = aoi.area(1e-3).divide(1e6)
    var minimum_area = ee.Number(polygon_area).multiply(Minimum_Areal_Coverage)
    // Get the dates of filtered images with less than specified cloud percentage
    var dates = data
        .map(function(image) {
          return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
        })
        .aggregate_array('date')
    // Filter Images that doesn't contain all bands
    var data = data.map(function(n) {
      return n.set('Num_of_bands',n.bandNames().length());
    })
    data = data.filterMetadata("Num_of_bands","equals",19);
    // Mosaic images of the same date/date range and calculate the area of the mosaic
    // return the result as image collection 
    var dd = ee.ImageCollection(
      ee.List(dates.distinct()).map(function (n) {
      var date = ee.Date(n)
      var filtered = data.filterDate(date, date.advance(cCoverage_Days,'day')) 
      var image = ee.Image(filtered.mosaic())
      var data1 = ee.Image(1).mask(image.select('SR_B2'))
      var raster_area = data1.multiply(ee.Image.pixelArea()).reduceRegion({
        reducer: ee.Reducer.sum(),
        geometry: aoi,
        scale: sscale,
        maxPixels: 1E13
      }).get('constant')
      raster_area=ee.Number(raster_area).divide(1e6)
      return image.set({'date':n,'Area_KM2':raster_area})
    }));
    // Filter Images that doesn't cover 99% of polygon area
    var data2 = dd.filterMetadata("Area_KM2","greater_than",ee.Number(minimum_area));
    var ii = ee.Number(ee.Algorithms.If(ee.Number(data2.size()).gt(0),ee.Number(i),ee.Number(0)))
    return ii //return the number of image collections that covers 99% of specified aoi (area of interest)
}
}
}
///////////////////////////////////////////////
function l9CdaysCheck(){
// This function calculates the minimal days required for sentinel 2 collection
// to cover at least 99% of a specific aoi (area of interest). 
// It generates a mosaic for every number of days (starting with 1 day)
// then it calculates it's aerial coverage with respect to aoi and test If it exceeds 99% or not.
// If not the number of days is incresed and the procedure is repeated. Otherwise the loop terminates.
var list = ee.List.sequence(1,15) //Iterate for 15 days.
//In each iteration if check1 function returns 0 then add 1 to the previous iteration and rerun check1
// Else if check1 returns 999 or any number other than 0 then return 999
/// 999 is used as a flag to terminate the iteration.
var addone = function(current,previous){
  previous = ee.List(previous)
  var pr = ee.Number(previous.get(-1))
  var cu = ee.Number(current)
  var cd = ee.Number(check1(pr,aoi))
  var n1 = ee.Algorithms.If(cd.eq(ee.Number(0)),pr.add(1),
           ee.Algorithms.If(cd.eq(ee.Number(999)),
           ee.Number(999),ee.Number(999)))
  return previous.add(ee.Number(n1))
}
var start = [1] //Start iteration at 1
var result = ee.List(list.iterate(addone,start))
result = ee.String(result.filter(ee.Filter.lt('item', 999)).get(-1)) 
return ee.String(result)
///////////////////////////////////////////////
function check1(i,aoii){
  // If i equals to 999 then don't go further... just return 999.
  // Else if i equals any number other than 999 or 0 then move forward with the continu function.
  return ee.Number(ee.Algorithms.If(ee.Number(i).neq(ee.Number(999)),
                   continu(ee.Number(i),aoii),ee.Number(999)))
  function continu(i,aoii){
    var aa = i
    var landsat = ee.ImageCollection('LANDSAT/LC09/C02/T1_L2');
    var aoi = aoii;
    var sStart_Date = ee.Date(Date.now()).advance(-2,'month')
    var eEnd_Date =  ee.Date(Date.now()).advance(-1,'month')
    var Minimum_Areal_Coverage = 0.999
    var cCoverage_Days = aa
    var data = landsat.filterBounds(aoi).filterDate(sStart_Date,eEnd_Date);
    // function applyScaleFactors(image) {
    // var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
    // var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
    // return image.addBands(opticalBands, null, true)
    //           .addBands(thermalBands, null, true);
    // }
    // data = data.map(applyScaleFactors);
    var sscale = 30
    var polygon_area = aoi.area(1e-3).divide(1e6)
    var minimum_area = ee.Number(polygon_area).multiply(Minimum_Areal_Coverage)
    // Get the dates of filtered images with less than specified cloud percentage
    var dates = data
        .map(function(image) {
          return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
        })
        .aggregate_array('date')
    // Filter Images that doesn't contain all bands
    var data = data.map(function(n) {
      return n.set('Num_of_bands',n.bandNames().length());
    })
    data = data.filterMetadata("Num_of_bands","equals",19);
    // Mosaic images of the same date/date range and calculate the area of the mosaic
    // return the result as image collection 
    var dd = ee.ImageCollection(
      ee.List(dates.distinct()).map(function (n) {
      var date = ee.Date(n)
      var filtered = data.filterDate(date, date.advance(cCoverage_Days,'day')) 
      var image = ee.Image(filtered.mosaic())
      var data1 = ee.Image(1).mask(image.select('SR_B2'))
      var raster_area = data1.multiply(ee.Image.pixelArea()).reduceRegion({
        reducer: ee.Reducer.sum(),
        geometry: aoi,
        scale: sscale,
        maxPixels: 1E13
      }).get('constant')
      raster_area=ee.Number(raster_area).divide(1e6)
      return image.set({'date':n,'Area_KM2':raster_area})
    }));
    // Filter Images that doesn't cover 99% of polygon area
    var data2 = dd.filterMetadata("Area_KM2","greater_than",ee.Number(minimum_area));
    var ii = ee.Number(ee.Algorithms.If(ee.Number(data2.size()).gt(0),ee.Number(i),ee.Number(0)))
    return ii //return the number of image collections that covers 99% of specified aoi (area of interest)
}
}
}
///////////////////////////////////////////////
function l5CdaysCheck(){
// This function calculates the minimal days required for sentinel 2 collection
// to cover at least 99% of a specific aoi (area of interest). 
// It generates a mosaic for every number of days (starting with 1 day)
// then it calculates it's aerial coverage with respect to aoi and test If it exceeds 99% or not.
// If not the number of days is incresed and the procedure is repeated. Otherwise the loop terminates.
var list = ee.List.sequence(1,15) //Iterate for 15 days.
//In each iteration if check1 function returns 0 then add 1 to the previous iteration and rerun check1
// Else if check1 returns 999 or any number other than 0 then return 999
/// 999 is used as a flag to terminate the iteration.
var addone = function(current,previous){
  previous = ee.List(previous)
  var pr = ee.Number(previous.get(-1))
  var cu = ee.Number(current)
  var cd = ee.Number(check1(pr,aoi))
  var n1 = ee.Algorithms.If(cd.eq(ee.Number(0)),pr.add(1),
           ee.Algorithms.If(cd.eq(ee.Number(999)),
           ee.Number(999),ee.Number(999)))
  return previous.add(ee.Number(n1))
}
var start = [1] //Start iteration at 1
var result = ee.List(list.iterate(addone,start))
result = ee.String(result.filter(ee.Filter.lt('item', 999)).get(-1)) 
return ee.String(result)
///////////////////////////////////////////////
function check1(i,aoii){
  // If i equals to 999 then don't go further... just return 999.
  // Else if i equals any number other than 999 or 0 then move forward with the continu function.
  return ee.Number(ee.Algorithms.If(ee.Number(i).neq(ee.Number(999)),
                   continu(ee.Number(i),aoii),ee.Number(999)))
  function continu(i,aoii){
    var aa = i
    var landsat = ee.ImageCollection("LANDSAT/LT05/C02/T1_L2");
    var aoi = aoii;
    var d1 = ee.Date.parse('dd-MM-YYYY', datee1.getValue()).update(1988);
    var sStart_Date = d1.advance(-1,'month')
    var eEnd_Date =  d1
    var Minimum_Areal_Coverage = 0.999
    var cCoverage_Days = aa
    var data = landsat.filterBounds(aoi).filterDate(sStart_Date,eEnd_Date);
  //   function applyScaleFactors(image) {
  //   var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  //   var thermalBand = image.select('ST_B6').multiply(0.00341802).add(149.0);
  //   return image.addBands(opticalBands, null, true)
  //               .addBands(thermalBand, null, true);
  // }
  //   data = data.map(applyScaleFactors);
    var sscale = 30
    var polygon_area = aoi.area(1e-3).divide(1e6)
    var minimum_area = ee.Number(polygon_area).multiply(Minimum_Areal_Coverage)
    // Get the dates of filtered images with less than specified cloud percentage
    var dates = data
        .map(function(image) {
          return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
        })
        .aggregate_array('date')
    // Filter Images that doesn't contain all bands
    var data = data.map(function(n) {
      return n.set('Num_of_bands',n.bandNames().length());
    })
    data = data.filterMetadata("Num_of_bands","equals",19);
    // Mosaic images of the same date/date range and calculate the area of the mosaic
    // return the result as image collection 
    var dd = ee.ImageCollection(
      ee.List(dates.distinct()).map(function (n) {
      var date = ee.Date(n)
      var filtered = data.filterDate(date, date.advance(cCoverage_Days,'day')) 
      var image = ee.Image(filtered.mosaic())
      var data1 = ee.Image(1).mask(image.select('ST_B6'))
      var raster_area = data1.multiply(ee.Image.pixelArea()).reduceRegion({
        reducer: ee.Reducer.sum(),
        geometry: aoi,
        scale: sscale,
        maxPixels: 1E13
      }).get('constant')
      raster_area=ee.Number(raster_area).divide(1e6)
      return image.set({'date':n,'Area_KM2':raster_area})
    }));
    // Filter Images that doesn't cover 99% of polygon area
    var data2 = dd.filterMetadata("Area_KM2","greater_than",ee.Number(minimum_area));
    var ii = ee.Number(ee.Algorithms.If(ee.Number(data2.size()).gt(0),ee.Number(i),ee.Number(0)))
    return ii //return the number of image collections that covers 99% of specified aoi (area of interest)
}
}
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function addpoly(){
insertbutton.setDisabled(1)
sensor_selector.setDisabled(1)
AutoDetect.setDisabled(1)
drawapolygon.setDisabled(1)
drawarectangle.setDisabled(1)
custommode.setDisabled(1)
definedmode.setDisabled(1)
Days_selector.setDisabled(1)
CloudButton.setDisabled(1)
ProdButton.setDisabled(1)
suggestLabel3.style().set({shown: false})
  try{
clearPolygon()
suggestLabel2.style().set({shown: false});
suggestLabel4.style().set({shown: true});
var poly = JSON.parse(polytextbox.getValue())
var polygon;
if (poly.type == 'Polygon') 
  {var poly2 = ee.Geometry(poly)
    poly2.evaluate(function (fc){
        polygon =  ee.Geometry(fc)
        PolygonGeometry.fromGeometry(polygon)
        PolygonGeometry.setShown(1)
        checkpolygon()
        if (Autozoom.getValue() == 1)
          {mappingPanel.centerObject(polygon)}
          suggestLabel4.style().set({shown: false});
          insertbutton.setDisabled(0)
          sensor_selector.setDisabled(0)
          AutoDetect.setDisabled(0)
          drawapolygon.setDisabled(0)
          drawarectangle.setDisabled(0)
          custommode.setDisabled(0)
          definedmode.setDisabled(0)
          Days_selector.setDisabled(0)
          CloudButton.setDisabled(0)
          ProdButton.setDisabled(0)
  })
  }
else if (poly.type == 'FeatureCollection') 
  { if (poly['features'].length == 1)
    {var poly2 = ee.Geometry(poly['features'][0].geometry)
    poly2.evaluate(function (fc){
        polygon =  ee.Geometry(fc)
        PolygonGeometry.fromGeometry(polygon)
        PolygonGeometry.setShown(1)
        checkpolygon()
        if (Autozoom.getValue() == 1)
          {mappingPanel.centerObject(polygon)}
          suggestLabel4.style().set({shown: false});
          insertbutton.setDisabled(0)
          sensor_selector.setDisabled(0)
          AutoDetect.setDisabled(0)
          drawapolygon.setDisabled(0)
          drawarectangle.setDisabled(0)
          custommode.setDisabled(0)
          definedmode.setDisabled(0)
          Days_selector.setDisabled(0)
          CloudButton.setDisabled(0)
          ProdButton.setDisabled(0)
  })
    }
    else if (poly['features'].length > 1)
    {var no_of_features = poly['features'].length;
      var properties = poly['features'][0].properties;
      var properties_keys = Object.keys(properties);
      var poly1=poly;
      for (var i = 0; i < no_of_features; i++) {
      for (var j = 0; j < properties_keys.length; j++) {
      if (typeof poly['features'][i].properties[properties_keys[j]] == 'number') {
        poly1['features'][i].properties[properties_keys[j]] = String(poly['features'][i].properties[properties_keys[j]])
      }
      if (typeof poly['features'][i].id == 'number') {
        poly1['features'][i].id = String(poly['features'][i].id)
      }
      }
    }
      var poly2 = ee.FeatureCollection(poly1)
      poly2.union(1).evaluate(function (fc){
        polygon =  ee.Geometry(fc['features'][0].geometry)
        PolygonGeometry.fromGeometry(polygon)
        PolygonGeometry.setShown(1)
        checkpolygon()
        if (Autozoom.getValue() == 1)
          {mappingPanel.centerObject(polygon)}
          suggestLabel4.style().set({shown: false});
          insertbutton.setDisabled(0)
          sensor_selector.setDisabled(0)
          AutoDetect.setDisabled(0)
          drawapolygon.setDisabled(0)
          drawarectangle.setDisabled(0)
          custommode.setDisabled(0)
          definedmode.setDisabled(0)
          Days_selector.setDisabled(0)
          CloudButton.setDisabled(0)
          ProdButton.setDisabled(0)
      })
    }
  }
}
catch (err){
  suggestLabel4.style().set({shown: false});
  insertbutton.setDisabled(0)
  sensor_selector.setDisabled(0)
  AutoDetect.setDisabled(0)
  drawapolygon.setDisabled(0)
  drawarectangle.setDisabled(0)
  custommode.setDisabled(0)
  definedmode.setDisabled(0)
  Days_selector.setDisabled(0)
  CloudButton.setDisabled(0)
  ProdButton.setDisabled(0)
  polytextbox.setValue('Invalid Input')
  suggestLabel2.style().set({shown: true})
}
}
// function addpoly(){
// suggestLabel3.style().set({shown: false})
//   try{
// clearPolygon()
// suggestLabel2.style().set({shown: false});
// var poly = JSON.parse(polytextbox.getValue())
// var polygon;
// if (poly.type == 'Polygon') 
//   {polygon = ee.Geometry(poly)}
// else if (poly.type == 'FeatureCollection') 
//   { if (poly['features'].length == 1)
//     {polygon = ee.Geometry(poly['features'][0].geometry)}
//     else if (poly['features'].length > 1)
//     {var no_of_features = poly['features'].length;
//       var properties = poly['features'][0].properties;
//       var properties_keys = Object.keys(properties);
//       var poly1=poly;
//       for (var i = 0; i < no_of_features; i++) {
//       for (var j = 0; j < properties_keys.length; j++) {
//       if (typeof poly['features'][i].properties[properties_keys[j]] == 'number') {
//         poly1['features'][i].properties[properties_keys[j]] = String(poly['features'][i].properties[properties_keys[j]])
//       }
//       if (typeof poly['features'][i].id == 'number') {
//         poly1['features'][i].id = String(poly['features'][i].id)
//       }
//       }
//     }
//       var poly2 = ee.FeatureCollection(poly1)
//       poly2 = poly2.union(1).getInfo()
//       polygon =  ee.Geometry(poly2['features'][0].geometry)
//     }
//   }
// // PolygonGeometry.geometries().add(polygon)
// PolygonGeometry.fromGeometry(polygon)
// PolygonGeometry.setShown(1)
// checkpolygon()
// if (Autozoom.getValue() == 1)
//   {mappingPanel.centerObject(polygon)}
// }
// catch (err){
//   polytextbox.setValue('Invalid Input')
//   suggestLabel2.style().set({shown: true})
// }
// }
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function createsnippet(){
var datecs = getdate(av_dates.getValue())
var aoics = JSON.stringify(aoi.getInfo())
var watershedcs
if(watershedisdrawn == true)
{watershedcs = JSON.stringify(wscenterpoint.getInfo())}
else{watershedcs = null}
var wlevel = watershedlevel.getValue()
var slevel = streamlevel.getValue()
var cdayscs = Days_selector.getValue()
var EPSG_Number = EPSG_number.getValue()
var minNDMIcs = minNDMI.getValue();var maxNDMIcs = maxNDMI.getValue();
var minNDWIcs = minNDWI.getValue();var maxNDWIcs = maxNDWI.getValue();
var minNDVIcs = minNDVI.getValue();var maxNDVIcs = maxNDVI.getValue();
var bands = '{'
  + 'B1:' + B1.getValue() + ','
  + 'B2:' + B2.getValue() + ','
  + 'B3:' + B3.getValue() + ','
  + 'B4:' + B4.getValue() + ','
  + 'B5:' + B5.getValue() + ','
  + 'B6:' + B6.getValue() + ','
  + 'B7:' + B7.getValue() + ','
  + 'B8:' + B8.getValue() + ','
  + 'B8A:' + B8A.getValue() + ','
  + 'B9:' + B9.getValue() + ','
  + 'B10:' + B10.getValue() + ','
  + 'B11:' + B11.getValue() + ','
  + 'B12:' + B12.getValue() + ','
  + 'NDMI:' + NDMIband.getValue() + ','
  + 'NDVI:' + NDVIband.getValue() + ','
  + 'NDWI:' + NDWIband.getValue() + ','
  + 'True:' + Trueband.getValue() + ','
  + 'AOI:'  + AOIshp.getValue() +
'}' 
// var text1 = 'var aoics = ' + JSON.stringify(aoi.first().geometry().getInfo())+";"
var text2 = "var prodmodule = require('users/Yousif_Almamalachy/My_Modules:ImageExport-DeptVersion')"+";"
var text3 = 'prodmodule.production('+ "'" + sensor_selector.getValue() + "'" + ',' + "'" + datecs + "'"  + ',' + aoics +','+ watershedcs +','+ wlevel +','+ slevel +','+ cdayscs + ',' + "'" +'EPSG: ' + EPSG_Number + "'" + ',' + minNDMIcs + ',' + maxNDMIcs + ',' + minNDVIcs + ',' + maxNDVIcs + ',' + minNDWIcs + ',' + maxNDWIcs + ',' + bands + ');'
var text4 = text2+'\n'+text3
return ee.String(text4)
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function lonlattoepsg(){
var aoics = aoi
var Lon = ee.Number(aoics.centroid(1e-3).coordinates().get(0))
var Lat = ee.Number(aoics.centroid(1e-3).coordinates().get(1))
var zone_number = ee.Number((Lon.add(180).divide(6))).ceil()
var EPSG_code = ee.Number(ee.Algorithms.If(Lat.lt(0),ee.Number(32600).add(zone_number).add(100),ee.Number(32600).add(zone_number)))
return EPSG_code
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function lonlattoutm(){
var aoics = aoi
var Lon = ee.Number(aoics.centroid(1e-3).coordinates().get(0))
var Lat = ee.Number(aoics.centroid(1e-3).coordinates().get(1))
var zone_number = ee.Number((Lon.add(180).divide(6))).ceil().format('%.0f')
var S_N = ee.Number(ee.Algorithms.If(Lat.lt(0),ee.String('S'),ee.String('N')))
var UTM_Zone = ee.String('WGS84 ').cat('\\').cat(' UTM Zone ').cat(zone_number).cat(S_N)
return UTM_Zone
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function checkbandsSelection(){
  if(sensor_selector.getValue() == 's2a' || sensor_selector.getValue() == 's1c' || sensor_selector.getValue() == 'l8' || sensor_selector.getValue() == 'l9' || sensor_selector.getValue() == 'l5')
  {var disabledcondition = [];var selectioncondition = [];
  blist.map(function(band){disabledcondition.push(band.getDisabled());selectioncondition.push(band.getValue())})
  if(disabledcondition.filter(Boolean).length == 0 || utmzone.getValue() == 'Invalid EPSG code')
  {if(selectioncondition.filter(Boolean).length == 0)
  {downsnippet.setDisabled(1)}
  else{downsnippet.setDisabled(0)}  
  }
  }
  else if(sensor_selector.getValue() == 'dem')
  {if(utmzone.getValue() == 'Invalid EPSG code')
  {downsnippet.setDisabled(1)}
  else{downsnippet.setDisabled(0)}}
  else if(sensor_selector.getValue() == 'ws')
  {if(utmzone.getValue() == 'Invalid EPSG code')
  {downsnippet.setDisabled(1)}
  else{downsnippet.setDisabled(0)}}
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
addgovernoratepolygon(aoi)
function addgovernoratepolygon(aoii){
aoi = aoii
clearPolygon()
drawingTools.unlisten()
aoi.evaluate(function(polygon){
PolygonGeometry.geometries().add(polygon)
})
drawingTools.stop()
if (Autozoom.getValue() == 1)
{mappingPanel.centerObject(Iraq)}
PolygonGeometry.setShown(1)
checkpolygon()
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
function getlayernames(){
var layers = mappingPanel.layers()
  var nameslist = []
  layers.forEach(
    function(x)
    {nameslist.push(x.getName())})
var PATTERN
var TrueColorlayername;var NDMIlayername;var NDVIlayername;var NDWIlayername;var DEMlayername;
  PATTERN = /NDVI/;
  var NDVIlist = nameslist.filter(function (str) { return PATTERN.test(str)});
  NDVIlayername = NDVIlist[NDVIlist.length -1]
  if (NDVIlayername == null)
  {
    vi.widgets().set(0, ui.Label(
    {
        value: 'NDVI',
        style:
        {
            color: 'black'
        }
    }))
  }
  PATTERN = /NDMI/;
  var NDMIlist = nameslist.filter(function (str) { return PATTERN.test(str)});
  NDMIlayername = NDMIlist[NDMIlist.length -1]
  if (NDMIlayername == null)
  {
    mi.widgets().set(0, ui.Label(
    {
        value: 'NDMI',
        style:
        {
            color: 'black'
        }
    }))
  }
  PATTERN = /NDWI/;
  var NDWIlist = nameslist.filter(function (str) { return PATTERN.test(str)});
  NDWIlayername = NDWIlist[NDWIlist.length -1]
  if (NDWIlayername == null)
  {
    wi.widgets().set(0, ui.Label(
    {
        value: 'NDWI',
        style:
        {
            color: 'black'
        }
    }))
  }
  PATTERN = /True Color/;
  var TrueColorlist = nameslist.filter(function (str) { return PATTERN.test(str)});
  TrueColorlayername = TrueColorlist[TrueColorlist.length -1]
  PATTERN = /Elevation/;
  var DEMlist = nameslist.filter(function (str) { return PATTERN.test(str)});
  DEMlayername = DEMlist[DEMlist.length -1]
  if (DEMlayername == null)
  {
    dm.widgets().set(0, ui.Label(
    {
        value: 'DEM',
        style:
        {
            color: 'black'
        }
    }))
  }
  var list = [NDVIlayername,NDMIlayername,NDWIlayername,TrueColorlayername,DEMlayername];
  return list
}
///////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////////////////////
var wscenterpoint
var watershedisdrawn = false
function drawwatershed(point,Basinlevel,Streamlevel){
clearmap()
var Basinlevel = watershedlevel.getValue()
var Streamlevel = streamlevel.getValue()
var point = ppoint
var Watershed = ee.FeatureCollection("WWF/HydroSHEDS/v1/Basins/hybas_" + Basinlevel.toString()).filterBounds(point)
wscenterpoint = Watershed.geometry().centroid(1e-3)
var flowaccu = ee.Image("WWF/HydroSHEDS/15ACC")
var Streams = flowaccu.updateMask(flowaccu.gte(parseInt(Streamlevel))).clip(Watershed)
// var Streams = ee.FeatureCollection("WWF/HydroSHEDS/v1/FreeFlowingRivers").filterMetadata('RIV_ORD', 'less_than', Streamlevel).filterBounds(Watershed);
var ws_styling  = {color:'red', fillColor: '00000000',width: 3}
// var st_styling  = {color:'blue',width: 1}
if (Autozoom.getValue() == 1)
{mappingPanel.centerObject(Watershed)}
mappingPanel.addLayer(Watershed.style(ws_styling), {}, "Watershed");
// mappingPanel.addLayer(Streams.style(st_styling), {}, "Streams");
mappingPanel.addLayer(Streams,{bands: ['b1'],min: 0,max: 1,palette: ['blue']},"Streams")
watershedisdrawn = true
downtext.setDisabled(0);downtext.setValue('')
checkbandsSelection()
}