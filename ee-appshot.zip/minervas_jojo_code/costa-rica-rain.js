////////
var Countries = ee.FeatureCollection('USDOS/LSIB/2017');
var WDPA = ee.FeatureCollection('WCMC/WDPA/current/polygons');
var CHIRPS = ee.ImageCollection("UCSB-CHG/CHIRPS/PENTAD");//rainfall
var MOD13Q1 = ee.ImageCollection("MODIS/006/MOD13Q1");
// Setup startDate and endDate as Date objects
var startDate = ee.Date.fromYMD(1981,1,1);
var endDate = ee.Date.fromYMD(2019,12,31);
// Create a sequence for years and months
var years = ee.List.sequence(1981, 2019);
var months = ee.List.sequence(1, 12);
var costaRica = Countries.filter(ee.Filter.inList('COUNTRY_NA', ['Costa Rica']));
// // WDPA boundaries filtered to 'Braulio Carrillo' National Park in Costa Rica
var braulio = WDPA.filter(ee.Filter.stringContains('ORIG_NAME', 'Braulio Carrillo'));
var costaRica_geo = costaRica.geometry(); // Online collection
var braulio_geo = braulio.geometry(); // Online collection
var rainAll = CHIRPS.select('precipitation')
  .filterDate(startDate, endDate)
  .filterBounds(costaRica_geo);
print('Çheck rainAll', rainAll);  
print('All CHIRPS Images: ', rainAll.size());
var rainYr_list =  years.map(function(y){
  var rain_year = rainAll.filter(ee.Filter.calendarRange(y, y, 'year')).sum().rename('rain_yr');
  return rain_year.set('year', ee.Date.fromYMD(y,1,1)); // ee.Image(ee.Date.fromYMD(y,1,1).millis()).divide(1e18).toFloat()
});
var rainYr = ee.ImageCollection.fromImages(rainYr_list);
print('Annual Mean CHIRPS Images: ', rainYr.size()); 
print('Check rainYr', rainYr);
var rainAnnual = rainYr.select('rain_yr').mean().clip(costaRica);
print('Check rainAnnual', rainAnnual);
var title = ui.Label('Costa Rica: Annual Rainfall 1981 to 2018', {
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight: 'bold',
  fontSize: '20px'
});  
var rainYvis = {
  min: 2100,
  max: 3800, 
  palette: 'ffffff, 67d9f1, 1036cb'
};  
Map.centerObject(costaRica, 8);
Map.addLayer(rainAnnual, rainYvis, 'Long-term Annual Rainfall'); 
Map.addLayer(braulio,{color: 'grey'}, 'Braulio Carrillo',true, 0.8);
Map.add(title);
var opt_chart_annualPrecip = {
  title: 'Annual Rainfall: Braulio Carrillo National Park',
  pointSize: 2, lineWidth: 1,
  hAxis: {title: 'Year'},
  vAxis: {title: 'Rainfall (mm)'},
};
var chart_annualPrecip = ui.Chart.image.series({
  imageCollection: rainYr,
  region:costaRica_geo,
  reducer: ee.Reducer.mean(),
  scale: 5000,
  xProperty: 'year'
}).setOptions(opt_chart_annualPrecip);
print(chart_annualPrecip);
// // Create a panel to hold the chart in the map
var panel = ui.Panel();
panel.style().set({
width: '350px',
position: 'bottom-left'
});
// // Add empty panel to map
// Map.add(panel);
// // Add chart to panel
// panel.add(chart_annualPrecip);