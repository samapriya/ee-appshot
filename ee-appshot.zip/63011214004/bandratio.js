var StudyArea = ui.import && ui.import("StudyArea", "table", {
      "id": "users/63011214004/SubBASIN_Yung"
    }) || ee.FeatureCollection("users/63011214004/SubBASIN_Yung"),
    StudyArea2 = ui.import && ui.import("StudyArea2", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                103.75486228832963,
                17.17162606275796
              ],
              [
                103.75486228832963,
                16.65658512875967
              ],
              [
                104.32065818676713,
                16.65658512875967
              ],
              [
                104.32065818676713,
                17.17162606275796
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#ffffff",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffffff */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[103.75486228832963, 17.17162606275796],
          [103.75486228832963, 16.65658512875967],
          [104.32065818676713, 16.65658512875967],
          [104.32065818676713, 17.17162606275796]]], null, false);
// นายปฏิพัทธ์ หายทุกข์ 63011214004
//Step 1 :: Import StudyArea ขอบเขตลุ่มน้ำสาขาลำน้ำยัง
//Step 2 :: Asset Landsat 8 Tier 1 surface Reflectance นำเข้าข้อมูลภาพถ่ายดาวเทียมเข้ามายัง Google Earth Engine Code Editor
var lc8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
                    .filterBounds(StudyArea)
                    .filterDate('2021-01-01','2021-12-31')
                    .select('B3','B4','B5','B6')
                    .filter(ee.Filter.lt('CLOUD_COVER',10));
print(lc8, 'image Collection SubBasin Yung December 2021');
Map.centerObject(StudyArea,9);
//Step 3 :: Mosaic Clip ทำการรวมและตัดขอบเขตพื้นที่ศึกษาและทำการเกลี่ยให้ภาพทั้งแต่ละภาพมีสีที่คล้ายกันที่สุดโดยใช้ median
var Lc08_median = lc8.median().clip(StudyArea);
print(Lc08_median, 'Median reduced Image SubBasin Yung December 2021');
//Step 4 :: Add image as a map layer ทำการนำเข้าภาพถ่ายที่นำเข้าให้มาโชว์เป็นแผนที่
var visParams = {
  'min':400,
  'max':[4000,3000,3000],
  'bands':'B5,B4,B3'};
var layerName = 'Landsat 8 False Color Image';
Map.addLayer(Lc08_median, visParams, layerName);
//Step 5 :: Calculate NDVI ทำการคำนวนค่าดัชนีNDVI
//Step 5.1 :: Version1 คำนวนโดยคำนวนตรง ๆ
var NIR = Lc08_median.select('B5');
var RED = Lc08_median.select('B4');
var NDVI01 = NIR.subtract(RED).divide(NIR.add(RED)).rename('NDVI');
var ndviParams = {
        min:-1,
        max:1,
        palette:['blue','white','green']};
layerName = 'NDVI V.1';
Map.addLayer(NDVI01, ndviParams, layerName);
//Step 5.2 :: Version2 คำนวนโดยใช้สูตรทางคณิตศาสตร์
var NDVI02 = Lc08_median.expression(
            '(NIR-RED)/(NIR+RED)', {
                'NIR':Lc08_median.select('B5'),
                'RED':Lc08_median.select('B4')})
            .rename('NDVI');
ndviParams = {
        min:-0.2,
        max:0.8,
        palette:['blue','white','green']};
layerName = 'NDVI v.2';
Map.addLayer(NDVI02, ndviParams, layerName);
//Step 5.3 :: Version3 คำนวนโดยใช ้API ของGoogle Earth Engine มาช่วยในการคำนวน
var NDVI03 = Lc08_median.normalizedDifference(['B5','B4'])
            .rename('NDVI');
print(NDVI03, 'NDVI Version 3');
var ndvipalette = ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
               '74A901', '66A000', '529400', '3E8601', '207401', '056201',
               '004C00', '023B01', '012E01', '011D01', '011301'];
ndviParams = {
      min: 0,
      max: 1,
      palette: ndvipalette};
layerName = 'NDVI v.3';
Map.addLayer(NDVI01,ndviParams,layerName);