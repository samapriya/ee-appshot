var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                112.86352003120992,
                -8.025653348998242
              ],
              [
                112.86352003120992,
                -8.111314240658029
              ],
              [
                112.99192274117085,
                -8.111314240658029
              ],
              [
                112.99192274117085,
                -8.025653348998242
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[112.86352003120992, -8.025653348998242],
          [112.86352003120992, -8.111314240658029],
          [112.99192274117085, -8.111314240658029],
          [112.99192274117085, -8.025653348998242]]], null, false);
// Menentukan data dan batas area TN BTS
var mod13 = ee.ImageCollection('MODIS/006/MOD13Q1');
var tn = ee.FeatureCollection("WCMC/WDPA/current/polygons");
var bts = tn.filterBounds(geometry);
// Memilah data berdasarkan periode musim
var mod13Summer = mod13.filter(ee.Filter.calendarRange(4, 8, 'month'))
  .filter(ee.Filter.calendarRange(2000, 2021, 'year'))
  .map(function(img) {
    return img.set('year', img.date().get('year'));
  });
// Menggabungkan data 
var mod13SummerAnnualJoin = ee.Join.saveAll('same_year').apply({
  primary: mod13Summer.distinct('year'),
  secondary: mod13Summer,
  condition: ee.Filter.equals({leftField: 'year', rightField: 'year'})
});
// Menggabungkan data EVI dan tahun 
var summerStats = ee.ImageCollection(mod13SummerAnnualJoin.map(function(img) {
  var year = img.get('year');
  var yearCol = ee.ImageCollection.fromImages(img.get('same_year'));
  var max = yearCol.select('EVI').max();
  var yr = ee.Image.constant(ee.Number(year)).toShort();
  return ee.Image.cat(yr, max).rename(['year', 'max']).set('year', year);
}));
// Menghitung sensSlope()
var sens = summerStats.reduce(ee.Reducer.sensSlope());
// Membuat histogram
function getHistogram(sensImg, geometry, title) {
  var hist = sensImg.select('slope').reduceRegion({
    reducer: ee.Reducer.autoHistogram(),
    geometry: geometry,
    scale: 250,
    maxPixels: 1e13,
  });
  var histArray = ee.Array(hist.get('slope'));
  var binBottom = histArray.slice(1, 0, 1);
  var nPixels = histArray.slice(1, 1, null);
  var histColumnFromArray =
    ui.Chart.array.values({array: nPixels, axis: 0, xLabels: binBottom})
      .setChartType('LineChart')
      .setOptions({
        title: title + ' tren kondisi vegetasi',
        hAxis: {title: 'Slope'},
        vAxis: {title: 'Pixel count'},
        pointSize: 0,
        lineSize: 2,
        colors: ['1b7837'],
        legend: {position: 'none'}
      });
  return histColumnFromArray;
}
// Menampilkan histogram
print(getHistogram(sens, bts, 'Bromo Tengger Semeru'));
// Membagi piksel berdasarkan kondisi green/brown
var cond = ee.Image.cat(sens.select('slope').gt(0).rename('greening'),
                        sens.select('slope').lt(0).rename('browning'));
// Menghitung luas area
var btsRes = cond.multiply(ee.Image.pixelArea())
                 .reduceRegions(bts, ee.Reducer.sum(), 250);
// Membuat tabel luasan (sq km)
btsRes = btsRes.map(function(feature) {
  var browningSqM = feature.getNumber('browning');
  var greeningSqM = feature.getNumber('greening');
  var forestSqM = feature.area();
  return feature.set({
    'Browning sq km': browningSqM.divide(1e6),
    'Browning fraction': browningSqM.divide(forestSqM),
    'Greening sq km': greeningSqM.divide(1e6),
    'Greening fraction': greeningSqM.divide(forestSqM),
  });
});
// Menampilkan tabel
print(ui.Chart.feature.byFeature(btsRes.select(['NAME', 'Browning sq km',
    'Browning fraction', 'Greening sq km', 'Greening fraction']),
    'NAME')
  .setChartType('Table'));
// Membuat parameter visualisasi
var visParams = {
  opacity: 1,
  bands: ['slope'],
  min: -55,
  max: 55,
  palette:
    ['8c510a', 'd8b365', 'f6e8c3', 'f5f5f5', 'd9f0d3', '7fbf7b', '1b7837']
};
// Menampilkan batas TN BTS
var paimg = ee.Image().byte().paint(bts, 0, 2);
Map.centerObject(bts, 11);
Map.addLayer(paimg, {palette: 'ff0000'}, 'National Parks');
Map.addLayer(sens.clipToCollection(bts), visParams, 'Sen\'s slope');
// Membuat grafis
print(ui.Chart.image
          .seriesByRegion({
            imageCollection: summerStats,
            regions: bts,
            reducer: ee.Reducer.median(),
            band: 'max',
            scale: 250,
            xProperty: 'year',
            seriesProperty: 'NAME'
          })
          .setChartType('ScatterChart')
          .setOptions({
            title: 'Tren Greening/browning di TN Bromo-Tengger-Semeru',
            vAxis: {title: 'Median EVI (musim kemarau)'},
            hAxis: {title: 'Tahun', format: '####'},
            lineWidth: 2,
            pointSize: 0,
            series: {0: {color: 'ff0000'}, 1: {color: '0000ff'}}
          }));