var allArea = ui.import && ui.import("allArea", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -86.04513213785049,
                11.352989224571683
              ],
              [
                -86.04513213785049,
                7.898244635842124
              ],
              [
                -82.43612334878799,
                7.898244635842124
              ],
              [
                -82.43612334878799,
                11.352989224571683
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-86.04513213785049, 11.352989224571683],
          [-86.04513213785049, 7.898244635842124],
          [-82.43612334878799, 7.898244635842124],
          [-82.43612334878799, 11.352989224571683]]], null, false),
    GMWR = ui.import && ui.import("GMWR", "image", {
      "id": "users/smk6598/GMW_PR_USVI"
    }) || ee.Image("users/smk6598/GMW_PR_USVI"),
    st_ThomasJohn_NCCOS_2002 = ui.import && ui.import("st_ThomasJohn_NCCOS_2002", "table", {
      "id": "users/smk6598/stThomas_John_NCCOS_2002"
    }) || ee.FeatureCollection("users/smk6598/stThomas_John_NCCOS_2002"),
    st_mang1 = ui.import && ui.import("st_mang1", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.87469654918488,
            18.307476548058297
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8733500802594,
            18.306544545708498
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87211626411255,
            18.30650380232195
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87111311794098,
            18.306595474928212
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87323206306274,
            18.3092947021392
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87245958686646,
            18.308388173919287
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87242203594025,
            18.30881597434479
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87262051940735,
            18.31097023899637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87341981769379,
            18.312253617962956
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87330716491516,
            18.314321264064247
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87481993079956,
            18.31546202375527
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 0
      },
      "color": "#5cb7d6",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #5cb7d6 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.87469654918488, 18.307476548058297]),
            {
              "class": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8733500802594, 18.306544545708498]),
            {
              "class": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87211626411255, 18.30650380232195]),
            {
              "class": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87111311794098, 18.306595474928212]),
            {
              "class": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87323206306274, 18.3092947021392]),
            {
              "class": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87245958686646, 18.308388173919287]),
            {
              "class": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87242203594025, 18.30881597434479]),
            {
              "class": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87262051940735, 18.31097023899637]),
            {
              "class": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87341981769379, 18.312253617962956]),
            {
              "class": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87330716491516, 18.314321264064247]),
            {
              "class": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87481993079956, 18.31546202375527]),
            {
              "class": 0,
              "system:index": "10"
            })]),
    st_mang2 = ui.import && ui.import("st_mang2", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.87212823657603,
            18.30728791935398
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87166689662547,
            18.307328662556042
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87438129214854,
            18.306136919935057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8720853212318,
            18.30911116826273
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87799765753141,
            18.31457602995844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8790598123013,
            18.314270468500077
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87208606886259,
            18.314586215331094
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87007977651945,
            18.317550133310036
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 0
      },
      "color": "#98ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.87212823657603, 18.30728791935398]),
            {
              "class": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87166689662547, 18.307328662556042]),
            {
              "class": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87438129214854, 18.306136919935057]),
            {
              "class": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8720853212318, 18.30911116826273]),
            {
              "class": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87799765753141, 18.31457602995844]),
            {
              "class": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8790598123013, 18.314270468500077]),
            {
              "class": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87208606886259, 18.314586215331094]),
            {
              "class": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87007977651945, 18.317550133310036]),
            {
              "class": 0,
              "system:index": "7"
            })]),
    st_mang3 = ui.import && ui.import("st_mang3", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.87250617225743,
            18.307101404590988
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8717980690775,
            18.307111590403384
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8737078018961,
            18.30856815540613
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87303188522435,
            18.308252397599478
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87164786537267,
            18.30670415744059
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8786967106638,
            18.31290722048787
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8779027767954,
            18.312723881910156
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.881831347064,
            18.31725373276567
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87083429010293,
            18.317151880581843
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87237924249551,
            18.316123170165433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87440699251077,
            18.315440754931792
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86494415910623,
            18.32013612471592
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86525529535196,
            18.319647241829617
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86628526361368,
            18.316785212223813
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86741179139993,
            18.315522237489205
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 0
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.87250617225743, 18.307101404590988]),
            {
              "class": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8717980690775, 18.307111590403384]),
            {
              "class": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8737078018961, 18.30856815540613]),
            {
              "class": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87303188522435, 18.308252397599478]),
            {
              "class": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87164786537267, 18.30670415744059]),
            {
              "class": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8786967106638, 18.31290722048787]),
            {
              "class": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8779027767954, 18.312723881910156]),
            {
              "class": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.881831347064, 18.31725373276567]),
            {
              "class": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87083429010293, 18.317151880581843]),
            {
              "class": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87237924249551, 18.316123170165433]),
            {
              "class": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87440699251077, 18.315440754931792]),
            {
              "class": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86494415910623, 18.32013612471592]),
            {
              "class": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86525529535196, 18.319647241829617]),
            {
              "class": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86628526361368, 18.316785212223813]),
            {
              "class": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86741179139993, 18.315522237489205]),
            {
              "class": 0,
              "system:index": "14"
            })]),
    st_mang4 = ui.import && ui.import("st_mang4", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.87112092204464,
            18.30625557162922
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87277852721584,
            18.30937751032463
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86200155753617,
            18.32213207696376
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 0
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.87112092204464, 18.30625557162922]),
            {
              "class": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87277852721584, 18.30937751032463]),
            {
              "class": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86200155753617, 18.32213207696376]),
            {
              "class": 0,
              "system:index": "2"
            })]),
    st_mang5 = ui.import && ui.import("st_mang5", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.99756037105796,
            18.350032798404936
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.99702392925498,
            18.35168248264537
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.9936765324044,
            18.35183523038917
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.99631582607505,
            18.352161091791164
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87984416941231,
            18.312878178085402
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88062737444466,
            18.312134636970217
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88168952921455,
            18.313041145574378
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88026259401863,
            18.312399460199305
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 0
      },
      "color": "#00ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.99756037105796, 18.350032798404936]),
            {
              "class": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.99702392925498, 18.35168248264537]),
            {
              "class": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.9936765324044, 18.35183523038917]),
            {
              "class": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.99631582607505, 18.352161091791164]),
            {
              "class": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87984416941231, 18.312878178085402]),
            {
              "class": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88062737444466, 18.312134636970217]),
            {
              "class": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88168952921455, 18.313041145574378]),
            {
              "class": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88026259401863, 18.312399460199305]),
            {
              "class": 0,
              "system:index": "7"
            })]),
    st_Mang6 = ui.import && ui.import("st_Mang6", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.95190534331506,
            18.315584659943113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.95199117400354,
            18.315406416863247
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.95237741210168,
            18.315238358934124
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.95183560588067,
            18.316022627874013
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.95191070773309,
            18.31638929784761
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.95528748131524,
            18.31300718910735
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.95535721874963,
            18.31300718910735
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.95530893898736,
            18.312946076304968
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.9415979844005,
            18.32002688476952
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.94148533162188,
            18.31993012674682
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.94145850953173,
            18.319497261246003
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.94136195000719,
            18.319497261246003
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.94097034749102,
            18.31887087748658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86857807635317,
            18.30765164899144
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86868536471377,
            18.30773822810253
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86858880518923,
            18.307493769324477
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87684939749725,
            18.311570061615683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8768386686612,
            18.311694834555986
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87695132143982,
            18.311267041243454
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87694059260376,
            18.311188103076216
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87709884293564,
            18.31207169921743
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87744216568954,
            18.312726117660112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87751190312393,
            18.31260898457976
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88232915051468,
            18.315756271975356
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88214676030167,
            18.316377574374137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87647210849043,
            18.31831410352617
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87638091338393,
            18.318232622283155
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8762682606053,
            18.318151141001774
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86578767412618,
            18.32041274410622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85363719476311,
            18.324411074235346
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85353527082054,
            18.32443144382234
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8547529937133,
            18.32287825593327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85503194345085,
            18.322959734988757
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8507886887893,
            18.323637028152294
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85089061273186,
            18.323535179725653
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.84952327349993,
            18.327523214862648
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85015091040941,
            18.326891767836436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85015091040941,
            18.326800105979743
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.84874543288561,
            18.327462107186662
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.84913703540178,
            18.329524479319648
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.89344712832781,
            18.36019745052064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.89336666205736,
            18.36019235917793
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 5
      },
      "color": "#bf04c2",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #bf04c2 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.95190534331506, 18.315584659943113]),
            {
              "class": 5,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.95199117400354, 18.315406416863247]),
            {
              "class": 5,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.95237741210168, 18.315238358934124]),
            {
              "class": 5,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.95183560588067, 18.316022627874013]),
            {
              "class": 5,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.95191070773309, 18.31638929784761]),
            {
              "class": 5,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.95528748131524, 18.31300718910735]),
            {
              "class": 5,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.95535721874963, 18.31300718910735]),
            {
              "class": 5,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.95530893898736, 18.312946076304968]),
            {
              "class": 5,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.9415979844005, 18.32002688476952]),
            {
              "class": 5,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.94148533162188, 18.31993012674682]),
            {
              "class": 5,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.94145850953173, 18.319497261246003]),
            {
              "class": 5,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.94136195000719, 18.319497261246003]),
            {
              "class": 5,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.94097034749102, 18.31887087748658]),
            {
              "class": 5,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86857807635317, 18.30765164899144]),
            {
              "class": 5,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86868536471377, 18.30773822810253]),
            {
              "class": 5,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86858880518923, 18.307493769324477]),
            {
              "class": 5,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87684939749725, 18.311570061615683]),
            {
              "class": 5,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8768386686612, 18.311694834555986]),
            {
              "class": 5,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87695132143982, 18.311267041243454]),
            {
              "class": 5,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87694059260376, 18.311188103076216]),
            {
              "class": 5,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87709884293564, 18.31207169921743]),
            {
              "class": 5,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87744216568954, 18.312726117660112]),
            {
              "class": 5,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87751190312393, 18.31260898457976]),
            {
              "class": 5,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88232915051468, 18.315756271975356]),
            {
              "class": 5,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88214676030167, 18.316377574374137]),
            {
              "class": 5,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87647210849043, 18.31831410352617]),
            {
              "class": 5,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87638091338393, 18.318232622283155]),
            {
              "class": 5,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8762682606053, 18.318151141001774]),
            {
              "class": 5,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86578767412618, 18.32041274410622]),
            {
              "class": 5,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85363719476311, 18.324411074235346]),
            {
              "class": 5,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85353527082054, 18.32443144382234]),
            {
              "class": 5,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8547529937133, 18.32287825593327]),
            {
              "class": 5,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85503194345085, 18.322959734988757]),
            {
              "class": 5,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8507886887893, 18.323637028152294]),
            {
              "class": 5,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85089061273186, 18.323535179725653]),
            {
              "class": 5,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.84952327349993, 18.327523214862648]),
            {
              "class": 5,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85015091040941, 18.326891767836436]),
            {
              "class": 5,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85015091040941, 18.326800105979743]),
            {
              "class": 5,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.84874543288561, 18.327462107186662]),
            {
              "class": 5,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.84913703540178, 18.329524479319648]),
            {
              "class": 5,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.89344712832781, 18.36019745052064]),
            {
              "class": 5,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.89336666205736, 18.36019235917793]),
            {
              "class": 5,
              "system:index": "41"
            })]),
    st_veg1 = ui.import && ui.import("st_veg1", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.87081744809946,
            18.305015378738382
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87119295736154,
            18.30529039877518
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86996450563272,
            18.30483712477756
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87348356386026,
            18.30579969398643
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87441160817941,
            18.304052805170535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87141052744998,
            18.315566456728558
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87171093485965,
            18.315189599675307
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87130323908939,
            18.3159280350219
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87057904265536,
            18.31668174509236
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.875557222587,
            18.31686507947808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8840928315768,
            18.315925697191453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88374950882289,
            18.315334949158217
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.84734509575867,
            18.322433447367466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.84781716454529,
            18.323411196014487
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.96273386169922,
            18.37020454931223
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.84919799742427,
            18.3415015511802
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85515250143733,
            18.33646050285861
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85729826864925,
            18.33669473664342
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85845698294368,
            18.338364916170086
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86670745787349,
            18.341216404895096
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 11
      },
      "color": "#ff0000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff0000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.87081744809946, 18.305015378738382]),
            {
              "class": 11,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87119295736154, 18.30529039877518]),
            {
              "class": 11,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86996450563272, 18.30483712477756]),
            {
              "class": 11,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87348356386026, 18.30579969398643]),
            {
              "class": 11,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87441160817941, 18.304052805170535]),
            {
              "class": 11,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87141052744998, 18.315566456728558]),
            {
              "class": 11,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87171093485965, 18.315189599675307]),
            {
              "class": 11,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87130323908939, 18.3159280350219]),
            {
              "class": 11,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87057904265536, 18.31668174509236]),
            {
              "class": 11,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.875557222587, 18.31686507947808]),
            {
              "class": 11,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8840928315768, 18.315925697191453]),
            {
              "class": 11,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88374950882289, 18.315334949158217]),
            {
              "class": 11,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.84734509575867, 18.322433447367466]),
            {
              "class": 11,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.84781716454529, 18.323411196014487]),
            {
              "class": 11,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.96273386169922, 18.37020454931223]),
            {
              "class": 11,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.84919799742427, 18.3415015511802]),
            {
              "class": 11,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85515250143733, 18.33646050285861]),
            {
              "class": 11,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85729826864925, 18.33669473664342]),
            {
              "class": 11,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85845698294368, 18.338364916170086]),
            {
              "class": 11,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86670745787349, 18.341216404895096]),
            {
              "class": 11,
              "system:index": "19"
            })]),
    st_veg2 = ui.import && ui.import("st_veg2", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.9056996004463,
            18.31361475726149
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.90297447608717,
            18.313054557731633
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.90066777633436,
            18.31158784492165
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.89416610168226,
            18.313115670495716
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.89475618766554,
            18.31373698237255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88858710693128,
            18.31262676777901
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.95656501220472,
            18.319705536947332
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.95450507568128,
            18.312229533305032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.96976700000249,
            18.339765424415866
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.96487465075933,
            18.338176730307357
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -65.03192901889045,
            18.356407871967164
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 12
      },
      "color": "#00ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.9056996004463, 18.31361475726149]),
            {
              "class": 12,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.90297447608717, 18.313054557731633]),
            {
              "class": 12,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.90066777633436, 18.31158784492165]),
            {
              "class": 12,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.89416610168226, 18.313115670495716]),
            {
              "class": 12,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.89475618766554, 18.31373698237255]),
            {
              "class": 12,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88858710693128, 18.31262676777901]),
            {
              "class": 12,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.95656501220472, 18.319705536947332]),
            {
              "class": 12,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.95450507568128, 18.312229533305032]),
            {
              "class": 12,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.96976700000249, 18.339765424415866]),
            {
              "class": 12,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.96487465075933, 18.338176730307357]),
            {
              "class": 12,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.03192901889045, 18.356407871967164]),
            {
              "class": 12,
              "system:index": "10"
            })]),
    st_veg3 = ui.import && ui.import("st_veg3", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.90057945559336,
            18.31227252539736
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.9034333259852,
            18.31311792053778
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.90396976778818,
            18.312323452932315
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.89371283398407,
            18.31297921269213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8883698736264,
            18.313121809170166
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87673372234337,
            18.30777866779137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85977096974716,
            18.31893342348536
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86359043538437,
            18.31840379661529
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86434145390854,
            18.340707832118802
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.92288030467573,
            18.361873825049386
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 13
      },
      "color": "#0000ff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0000ff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.90057945559336, 18.31227252539736]),
            {
              "class": 13,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.9034333259852, 18.31311792053778]),
            {
              "class": 13,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.90396976778818, 18.312323452932315]),
            {
              "class": 13,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.89371283398407, 18.31297921269213]),
            {
              "class": 13,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8883698736264, 18.313121809170166]),
            {
              "class": 13,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87673372234337, 18.30777866779137]),
            {
              "class": 13,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85977096974716, 18.31893342348536]),
            {
              "class": 13,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86359043538437, 18.31840379661529]),
            {
              "class": 13,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86434145390854, 18.340707832118802]),
            {
              "class": 13,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.92288030467573, 18.361873825049386]),
            {
              "class": 13,
              "system:index": "9"
            })]),
    st_bare1 = ui.import && ui.import("st_bare1", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.88287247500959,
            18.313367357859015
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88599456630293,
            18.315088689349068
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88659538112226,
            18.315597955739378
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87701453052107,
            18.317247968551758
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87815178714338,
            18.3177164878409
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87956799350324,
            18.317685932273744
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87197197757307,
            18.320272951184442
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.85181899263394,
            18.334324552252895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8533424873544,
            18.335424443468877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87170878685605,
            18.345605503266107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.894999816604,
            18.360901169667162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.92458667543536,
            18.36019762404467
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.92287006166583,
            18.362875649502925
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 21
      },
      "color": "#999900",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #999900 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.88287247500959, 18.313367357859015]),
            {
              "class": 21,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88599456630293, 18.315088689349068]),
            {
              "class": 21,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88659538112226, 18.315597955739378]),
            {
              "class": 21,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87701453052107, 18.317247968551758]),
            {
              "class": 21,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87815178714338, 18.3177164878409]),
            {
              "class": 21,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87956799350324, 18.317685932273744]),
            {
              "class": 21,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87197197757307, 18.320272951184442]),
            {
              "class": 21,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.85181899263394, 18.334324552252895]),
            {
              "class": 21,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8533424873544, 18.335424443468877]),
            {
              "class": 21,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87170878685605, 18.345605503266107]),
            {
              "class": 21,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.894999816604, 18.360901169667162]),
            {
              "class": 21,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.92458667543536, 18.36019762404467]),
            {
              "class": 21,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.92287006166583, 18.362875649502925]),
            {
              "class": 21,
              "system:index": "12"
            })]),
    st_veg4 = ui.import && ui.import("st_veg4", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.88456560977035,
            18.315719919830254
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88466753371291,
            18.31564353002106
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88501085646682,
            18.315704641871115
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88492502577834,
            18.315169912451534
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88486601718002,
            18.314548605717846
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88486601718002,
            18.314487493459637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88888933070236,
            18.311431853041967
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8949296654039,
            18.31183927488051
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.90841283217956,
            18.314488756763208
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.90905656234314,
            18.31447857138482
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.97872318539456,
            18.335847649275667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.97783269200161,
            18.335837465154768
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.98136247906521,
            18.335715255657153
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.9682303837283,
            18.337925197394846
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 14
      },
      "color": "#009999",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #009999 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.88456560977035, 18.315719919830254]),
            {
              "class": 14,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88466753371291, 18.31564353002106]),
            {
              "class": 14,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88501085646682, 18.315704641871115]),
            {
              "class": 14,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88492502577834, 18.315169912451534]),
            {
              "class": 14,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88486601718002, 18.314548605717846]),
            {
              "class": 14,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88486601718002, 18.314487493459637]),
            {
              "class": 14,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88888933070236, 18.311431853041967]),
            {
              "class": 14,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8949296654039, 18.31183927488051]),
            {
              "class": 14,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.90841283217956, 18.314488756763208]),
            {
              "class": 14,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.90905656234314, 18.31447857138482]),
            {
              "class": 14,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.97872318539456, 18.335847649275667]),
            {
              "class": 14,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.97783269200161, 18.335837465154768]),
            {
              "class": 14,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.98136247906521, 18.335715255657153]),
            {
              "class": 14,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.9682303837283, 18.337925197394846]),
            {
              "class": 14,
              "system:index": "13"
            })]),
    st_veg5 = ui.import && ui.import("st_veg5", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -65.02872842418654,
            18.342436131660122
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -65.0298013077925,
            18.343861848318287
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -65.0368663280751,
            18.348473875860915
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -65.04012789423722,
            18.351355747393118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -65.04043903048294,
            18.351620510564057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -65.00540445250263,
            18.345100669938926
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 15
      },
      "color": "#ff00ff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff00ff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-65.02872842418654, 18.342436131660122]),
            {
              "class": 15,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.0298013077925, 18.343861848318287]),
            {
              "class": 15,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.0368663280751, 18.348473875860915]),
            {
              "class": 15,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.04012789423722, 18.351355747393118]),
            {
              "class": 15,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.04043903048294, 18.351620510564057]),
            {
              "class": 15,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.00540445250263, 18.345100669938926]),
            {
              "class": 15,
              "system:index": "5"
            })]),
    st_water = ui.import && ui.import("st_water", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.87277700511518,
            18.3107687262768
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87357630340162,
            18.313116490457368
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87319006530348,
            18.31321325228926
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87395717708173,
            18.314547541508425
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87376942245069,
            18.314659580593112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87314673703156,
            18.317194460149082
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87239571850739,
            18.31702640395608
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87481507103882,
            18.316267602749875
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.8750081900879,
            18.316181027904168
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.86954184811555,
            18.318039831250893
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 31
      },
      "color": "#99ff99",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #99ff99 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.87277700511518, 18.3107687262768]),
            {
              "class": 31,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87357630340162, 18.313116490457368]),
            {
              "class": 31,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87319006530348, 18.31321325228926]),
            {
              "class": 31,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87395717708173, 18.314547541508425]),
            {
              "class": 31,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87376942245069, 18.314659580593112]),
            {
              "class": 31,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87314673703156, 18.317194460149082]),
            {
              "class": 31,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87239571850739, 18.31702640395608]),
            {
              "class": 31,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87481507103882, 18.316267602749875]),
            {
              "class": 31,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.8750081900879, 18.316181027904168]),
            {
              "class": 31,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.86954184811555, 18.318039831250893]),
            {
              "class": 31,
              "system:index": "9"
            })]),
    st_MangrovesORnot = ui.import && ui.import("st_MangrovesORnot", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -64.99138852770642,
            18.366085693766422
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.97515351320413,
            18.338624967696962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.97345835710672,
            18.33863515165366
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.97016460443643,
            18.33870643933365
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.97765002885504,
            18.33949943004698
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.90605745572009,
            18.31218027409159
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.90659389752307,
            18.314329404187827
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88349859364517,
            18.316102571948143
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88059107907303,
            18.311315422683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.88193218358047,
            18.313749755554767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87843548548933,
            18.316674286127647
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -64.87844084990736,
            18.316587711485372
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 1
      },
      "color": "#ff9999",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff9999 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-64.99138852770642, 18.366085693766422]),
            {
              "class": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.97515351320413, 18.338624967696962]),
            {
              "class": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.97345835710672, 18.33863515165366]),
            {
              "class": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.97016460443643, 18.33870643933365]),
            {
              "class": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.97765002885504, 18.33949943004698]),
            {
              "class": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.90605745572009, 18.31218027409159]),
            {
              "class": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.90659389752307, 18.314329404187827]),
            {
              "class": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88349859364517, 18.316102571948143]),
            {
              "class": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88059107907303, 18.311315422683]),
            {
              "class": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.88193218358047, 18.313749755554767]),
            {
              "class": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87843548548933, 18.316674286127647]),
            {
              "class": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.87844084990736, 18.316587711485372]),
            {
              "class": 1,
              "system:index": "11"
            })]),
    ExclusionAreas = ui.import && ui.import("ExclusionAreas", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.95811634679018,
                18.30942683396317
              ],
              [
                -64.96154957432924,
                18.30967129001223
              ],
              [
                -64.96086292882143,
                18.306330360803965
              ],
              [
                -64.95717220921694,
                18.30518954094639
              ],
              [
                -64.95425396580873,
                18.307308200414877
              ],
              [
                -64.95674305577455,
                18.307878604304754
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.94892594638844,
                18.326455319983083
              ],
              [
                -64.94866845432301,
                18.32751452280932
              ],
              [
                -64.95008466068288,
                18.327677476514587
              ],
              [
                -64.95441911045094,
                18.323277672590397
              ],
              [
                -64.95819566074391,
                18.320670328574348
              ],
              [
                -64.9593114596941,
                18.318062945269897
              ],
              [
                -64.95905396762868,
                18.315129592096483
              ],
              [
                -64.95785233799,
                18.314640695067677
              ],
              [
                -64.956049893532,
                18.315944417409213
              ],
              [
                -64.95579240146657,
                18.317655538079887
              ],
              [
                -64.95613572422047,
                18.319570343533655
              ],
              [
                -64.95476243320485,
                18.32152586766059
              ],
              [
                -64.95283124271413,
                18.32189252597402
              ],
              [
                -64.95407578769704,
                18.322462881806107
              ],
              [
                -64.9523591739275,
                18.32441837324184
              ],
              [
                -64.95004174533864,
                18.32392950245503
              ],
              [
                -64.94841096225758,
                18.32466280811717
              ],
              [
                -64.9488830310442,
                18.326047932553656
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.94579312625905,
                18.330284714919262
              ],
              [
                -64.94669434848805,
                18.328858886286476
              ],
              [
                -64.94613644901295,
                18.328370028049246
              ],
              [
                -64.9436044437029,
                18.329795860712277
              ],
              [
                -64.94433400455495,
                18.33040692825511
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.94287488285084,
                18.324092459537457
              ],
              [
                -64.94523522678395,
                18.321648087184723
              ],
              [
                -64.94476315799733,
                18.32038514793891
              ],
              [
                -64.94351861301442,
                18.319692564439027
              ],
              [
                -64.94343278232594,
                18.318185167239893
              ],
              [
                -64.94223115268727,
                18.31757405652681
              ],
              [
                -64.94201657596608,
                18.318918497247118
              ],
              [
                -64.94266030612965,
                18.320059226637202
              ],
              [
                -64.94381902042409,
                18.321811046415963
              ],
              [
                -64.94231698337575,
                18.323033235758004
              ],
              [
                -64.94253156009694,
                18.323603587829687
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.93475176447822,
                18.33172648772825
              ],
              [
                -64.93294932002021,
                18.334415138747747
              ],
              [
                -64.93698336237861,
                18.337674053627186
              ],
              [
                -64.94093157404853,
                18.33783699775851
              ],
              [
                -64.94316317194892,
                18.33368187443404
              ],
              [
                -64.93912912959053,
                18.331074687245977
              ],
              [
                -64.93784166926338,
                18.32602315021568
              ],
              [
                -64.93466593378974,
                18.32194922257215
              ],
              [
                -64.93209101313545,
                18.31836408689634
              ],
              [
                -64.93011690730049,
                18.31950481994102
              ],
              [
                -64.9308035528083,
                18.32374176255431
              ],
              [
                -64.92925860041572,
                18.326593492429947
              ],
              [
                -64.93063189143135,
                18.328956318712162
              ],
              [
                -64.93294932002021,
                18.33074878608354
              ],
              [
                -64.93320681208564,
                18.32854893717326
              ],
              [
                -64.93552424067451,
                18.328304507789323
              ],
              [
                -64.93621088618232,
                18.330585835272018
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.9241945897956,
                18.33323376693369
              ],
              [
                -64.92599703425361,
                18.33021919538471
              ],
              [
                -64.92402292841865,
                18.324678764698923
              ],
              [
                -64.92393709773017,
                18.319871482537007
              ],
              [
                -64.91904474848701,
                18.318567789777237
              ],
              [
                -64.90908838862373,
                18.31302698598854
              ],
              [
                -64.90471102351142,
                18.310093547475624
              ],
              [
                -64.90007616633369,
                18.309441665500948
              ],
              [
                -64.8926947271247,
                18.3109083964926
              ],
              [
                -64.88694407099678,
                18.3119676944813
              ],
              [
                -64.8828241979499,
                18.31318995333743
              ],
              [
                -64.88488413447334,
                18.314656652573586
              ],
              [
                -64.88419748896553,
                18.316286303815925
              ],
              [
                -64.88308169001533,
                18.317101123683216
              ],
              [
                -64.882480875196,
                18.318241865052727
              ],
              [
                -64.8853991186042,
                18.317671495307838
              ],
              [
                -64.89217974299385,
                18.314901101238057
              ],
              [
                -64.8978445684333,
                18.316286303815925
              ],
              [
                -64.90986086482002,
                18.31799742110652
              ],
              [
                -64.92170549982978,
                18.330952474382038
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.88140799159004,
                18.318893713887935
              ],
              [
                -64.88179422968818,
                18.317936310066028
              ],
              [
                -64.88132216090156,
                18.317406680144458
              ],
              [
                -64.88087154978706,
                18.31799742110652
              ],
              [
                -64.88076426142646,
                18.318588160052137
              ],
              [
                -64.88029219263984,
                18.319056675713103
              ],
              [
                -64.87836100214912,
                18.319321488351694
              ],
              [
                -64.87673021906807,
                18.31907704593045
              ],
              [
                -64.87602211588813,
                18.320014073336743
              ],
              [
                -64.8772237455268,
                18.321093685579175
              ],
              [
                -64.87814642542793,
                18.321093685579175
              ],
              [
                -64.88054968470527,
                18.319728891619764
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.87200953120185,
                18.31869001139069
              ],
              [
                -64.87243868464424,
                18.31869001139069
              ],
              [
                -64.87415529841377,
                18.317447420965202
              ],
              [
                -64.8755285894294,
                18.317325198474208
              ],
              [
                -64.87544275874092,
                18.3166733437312
              ],
              [
                -64.87492777461006,
                18.316877048602116
              ],
              [
                -64.87445570582344,
                18.316897419076017
              ],
              [
                -64.87432695979072,
                18.316591861715693
              ],
              [
                -64.87355448359443,
                18.316815937166016
              ],
              [
                -64.8729536687751,
                18.317365939314136
              ],
              [
                -64.87190224284126,
                18.31789556936037
              ],
              [
                -64.87166620844795,
                18.318486308653657
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.86750342005683,
                18.320360364789792
              ],
              [
                -64.87112976664497,
                18.318751122165033
              ],
              [
                -64.87117268198921,
                18.318221494737067
              ],
              [
                -64.86788965815498,
                18.319280747972122
              ],
              [
                -64.86711718195869,
                18.31979000202726
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.8578258037631,
                18.318444205949742
              ],
              [
                -64.8589416027133,
                18.318321984162694
              ],
              [
                -64.85874848366423,
                18.317914577582485
              ],
              [
                -64.85771851540251,
                18.317873836871726
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.85291199684782,
                18.319177534859296
              ],
              [
                -64.85475735665007,
                18.318851611283137
              ],
              [
                -64.85419945717497,
                18.316407164896795
              ],
              [
                -64.84544472695036,
                18.311110745962175
              ],
              [
                -64.8420114994113,
                18.314492324446647
              ],
              [
                -64.85213952065153,
                18.31925901565743
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.84926419258757,
                18.326388436932678
              ],
              [
                -64.85145287514372,
                18.326632869024312
              ],
              [
                -64.85316948891325,
                18.324758880828412
              ],
              [
                -64.85213952065153,
                18.324514446088816
              ],
              [
                -64.85020833016081,
                18.325329227211025
              ],
              [
                -64.84677510262175,
                18.325329227211025
              ],
              [
                -64.84977917671843,
                18.323292267210313
              ],
              [
                -64.8493071079318,
                18.32268117453338
              ],
              [
                -64.84797673226042,
                18.32308856989117
              ],
              [
                -64.84475808144255,
                18.324677402620246
              ],
              [
                -64.84098153114958,
                18.324229271789424
              ],
              [
                -64.83372883797331,
                18.32080714353233
              ],
              [
                -64.82939438820524,
                18.324473706931975
              ],
              [
                -64.83587460518523,
                18.327121732171356
              ],
              [
                -64.84076695442839,
                18.327243947742236
              ],
              [
                -64.8454876422946,
                18.326225482013037
              ],
              [
                -64.84780507088347,
                18.325981049345735
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.85283347599366,
                18.330897833056202
              ],
              [
                -64.84742614261964,
                18.3327717547374
              ],
              [
                -64.84875651829103,
                18.334319761678508
              ],
              [
                -64.85201808445314,
                18.333912392774536
              ],
              [
                -64.85424968235353,
                18.331631109175966
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.85249015323976,
                18.33497154992847
              ],
              [
                -64.84961482517579,
                18.335745545283846
              ],
              [
                -64.85090228550294,
                18.340104296524242
              ],
              [
                -64.86356231205323,
                18.345725701242586
              ],
              [
                -64.86751052372315,
                18.341733708015607
              ],
              [
                -64.86193152897218,
                18.337660150485657
              ],
              [
                -64.85309096805909,
                18.334686392871447
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.88868521966258,
                18.35373877850307
              ],
              [
                -64.8807458809785,
                18.354309029267966
              ],
              [
                -64.8819904259614,
                18.352842666353986
              ],
              [
                -64.88005923547068,
                18.350968962290853
              ],
              [
                -64.8772697380952,
                18.34970623721878
              ],
              [
                -64.87272071160594,
                18.349665503998267
              ],
              [
                -64.87005996026316,
                18.35129482532714
              ],
              [
                -64.8710040978364,
                18.352964863739018
              ],
              [
                -64.87551020898142,
                18.35390170748519
              ],
              [
                -64.87950133599558,
                18.355408793282717
              ],
              [
                -64.88323497094432,
                18.35650855029359
              ],
              [
                -64.88722609795848,
                18.357200986299638
              ],
              [
                -64.888942711728,
                18.36074458591946
              ],
              [
                -64.89053057946482,
                18.363392055404454
              ],
              [
                -64.89336299218455,
                18.3637993547981
              ],
              [
                -64.89615248956004,
                18.362088690886196
              ],
              [
                -64.898126595395,
                18.35980777929928
              ],
              [
                -64.89490794457713,
                18.358463656573793
              ],
              [
                -64.89422129906932,
                18.35911535374754
              ],
              [
                -64.89533709801951,
                18.360052164125072
              ],
              [
                -64.89538001336375,
                18.360988969419115
              ],
              [
                -64.89413546838084,
                18.36164065706013
              ],
              [
                -64.8926334313325,
                18.362129421176366
              ],
              [
                -64.89057349480906,
                18.359156084739222
              ],
              [
                -64.89053057946482,
                18.35618269709463
              ],
              [
                -64.89018725671092,
                18.354390493509236
              ],
              [
                -64.88941478051463,
                18.35382024301334
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.90098877136599,
                18.361313175059806
              ],
              [
                -64.89686889831911,
                18.363594066755734
              ],
              [
                -64.90734024231325,
                18.370762387277047
              ],
              [
                -64.93240280334841,
                18.383469132574582
              ],
              [
                -64.9562637347449,
                18.395197604758877
              ],
              [
                -64.97737808411013,
                18.40529648274619
              ],
              [
                -65.00278396789919,
                18.387378711983466
              ],
              [
                -65.06544037048708,
                18.385423933362443
              ],
              [
                -65.09015960876833,
                18.360661486182522
              ],
              [
                -65.08758468811403,
                18.334673388120958
              ],
              [
                -65.08603973572146,
                18.33336980691594
              ],
              [
                -65.07814331238161,
                18.33434749374111
              ],
              [
                -65.0465075651725,
                18.343341038996194
              ],
              [
                -65.03131553331215,
                18.33926751934945
              ],
              [
                -65.02444907823403,
                18.33788250079924
              ],
              [
                -64.99603912034829,
                18.345703636395694
              ],
              [
                -64.99990150132973,
                18.34920673859321
              ],
              [
                -65.00908538499672,
                18.347332995090614
              ],
              [
                -65.01904174486,
                18.346273913686748
              ],
              [
                -65.02041503587563,
                18.344237200433113
              ],
              [
                -65.02187415757973,
                18.342363403037407
              ],
              [
                -65.0259940306266,
                18.343666916420087
              ],
              [
                -65.02994224229653,
                18.34790326700363
              ],
              [
                -65.02728067928096,
                18.35604652233806
              ],
              [
                -65.01955591731807,
                18.357675783468498
              ],
              [
                -65.01886927181026,
                18.360934259607184
              ],
              [
                -65.0172384887292,
                18.36077133726089
              ],
              [
                -65.01483522945186,
                18.359793799954247
              ],
              [
                -65.00917040401241,
                18.359956723223082
              ],
              [
                -64.99955736690303,
                18.359549414762714
              ],
              [
                -64.99114595943233,
                18.3583274836161
              ],
              [
                -64.98960100703975,
                18.362482014228004
              ],
              [
                -64.99389254146358,
                18.366554986387346
              ],
              [
                -64.9897726684167,
                18.367939775025107
              ],
              [
                -64.97904383235714,
                18.369324552550044
              ],
              [
                -64.96805750423214,
                18.36671790327445
              ],
              [
                -64.96071898036739,
                18.36280785553773
              ],
              [
                -64.95222174220821,
                18.36358172618314
              ],
              [
                -64.92848955684444,
                18.355679936465148
              ],
              [
                -64.9205931335046,
                18.357797977433542
              ],
              [
                -64.92763124995967,
                18.3628485856582
              ],
              [
                -64.92265307002803,
                18.366758632472184
              ],
              [
                -64.91183840327999,
                18.361545217036348
              ],
              [
                -64.904456964071,
                18.36040476141956
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.81677587838387,
                18.363669850885138
              ],
              [
                -64.87874563546394,
                18.364973203463872
              ],
              [
                -64.87857397408699,
                18.358293417472417
              ],
              [
                -64.85333975167488,
                18.351287510606813
              ],
              [
                -64.81265600533699,
                18.353731463886252
              ],
              [
                -64.81265600533699,
                18.36008558054808
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.98990147533843,
                18.351655441699133
              ],
              [
                -64.99127476635405,
                18.349374392297715
              ],
              [
                -64.98732655468413,
                18.344893671856035
              ],
              [
                -64.98715489330718,
                18.338946354362374
              ],
              [
                -64.98552411022612,
                18.33234703654621
              ],
              [
                -65.00998585644194,
                18.303421130582223
              ],
              [
                -64.99865620556304,
                18.297064931795337
              ],
              [
                -64.98543827953765,
                18.30782143926912
              ],
              [
                -64.95883076610991,
                18.323954947661868
              ],
              [
                -64.95110600414702,
                18.331124913012225
              ],
              [
                -64.94818776073882,
                18.337479861062445
              ],
              [
                -64.9555691999478,
                18.337479861062445
              ],
              [
                -64.96586888256499,
                18.335361570999186
              ],
              [
                -64.97415154400298,
                18.337194708142704
              ],
              [
                -64.97634022655913,
                18.338172373337773
              ],
              [
                -64.97938721600005,
                18.33853899636038
              ],
              [
                -64.97874348583647,
                18.34012768713926
              ],
              [
                -64.97543900433013,
                18.34143121738487
              ],
              [
                -64.97200577679106,
                18.33947591832976
              ],
              [
                -64.96749966564605,
                18.33890561860538
              ],
              [
                -64.96638386669585,
                18.33796869354479
              ],
              [
                -64.96286480846831,
                18.338253845187783
              ],
              [
                -64.9616202634854,
                18.340290628957607
              ],
              [
                -64.9671134275479,
                18.340779453490985
              ],
              [
                -64.97578232708403,
                18.34297914678185
              ],
              [
                -64.98539536419341,
                18.349374392297715
              ],
              [
                -64.98921482983062,
                18.351573976167778
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.99884932461211,
                18.349720624949484
              ],
              [
                -64.99803393307158,
                18.35033162205384
              ],
              [
                -64.99803393307158,
                18.3510648157263
              ],
              [
                -64.99751894894072,
                18.351798006286547
              ],
              [
                -64.99728291517489,
                18.352235882516762
              ],
              [
                -64.99696104946563,
                18.352592292548042
              ],
              [
                -64.99654798927733,
                18.35280613822508
              ],
              [
                -64.9964514297528,
                18.353086173830345
              ],
              [
                -64.996325366044,
                18.353261832308615
              ],
              [
                -64.99619393768737,
                18.353493497536558
              ],
              [
                -64.99584525051543,
                18.35361060292433
              ],
              [
                -64.99549119892546,
                18.353585145238114
              ],
              [
                -64.9953020410485,
                18.3535392985875
              ],
              [
                -64.99505527781913,
                18.353447650861657
              ],
              [
                -64.9947441415734,
                18.3535189324304
              ],
              [
                -64.99421842860649,
                18.353905889004512
              ],
              [
                -64.99549516009758,
                18.354954740621647
              ],
              [
                -64.99713667201469,
                18.355148217408498
              ],
              [
                -64.99902494716117,
                18.353167615267687
              ],
              [
                -64.99997981357048,
                18.35180307449585
              ],
              [
                -64.99914296435783,
                18.350122841571743
              ],
              [
                -64.9993897275872,
                18.34972569321974
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -64.84117193740488,
                18.341207507172275
              ],
              [
                -64.84700842422129,
                18.3386004334756
              ],
              [
                -64.84469099563242,
                18.33257142495589
              ],
              [
                -64.84082861465097,
                18.32980126947456
              ],
              [
                -64.83064921061418,
                18.326509642713482
              ],
              [
                -64.83007071521054,
                18.319467692853173
              ],
              [
                -64.83573554064999,
                18.314741748847325
              ],
              [
                -64.84062788989316,
                18.30643029296579
              ],
              [
                -64.83908293750058,
                18.30007420459373
              ],
              [
                -64.85247252490292,
                18.285975894426667
              ],
              [
                -64.84835265185605,
                18.269838849338914
              ],
              [
                -64.85830901171933,
                18.29412534652424
              ],
              [
                -64.881483297608,
                18.287462999409016
              ],
              [
                -64.90791914965878,
                18.282247193762736
              ],
              [
                -64.90156767871152,
                18.27051105756124
              ],
              [
                -64.87736342456112,
                18.248340635076172
              ],
              [
                -64.7939359953619,
                18.25877412764391
              ],
              [
                -64.7877561857916,
                18.287462999409016
              ],
              [
                -64.80560896899472,
                18.30962842242958
              ],
              [
                -64.81659529711972,
                18.330487405400415
              ],
              [
                -64.82826827075253,
                18.345804119111968
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.MultiPolygon(
        [[[[-64.95811634679018, 18.30942683396317],
           [-64.96154957432924, 18.30967129001223],
           [-64.96086292882143, 18.306330360803965],
           [-64.95717220921694, 18.30518954094639],
           [-64.95425396580873, 18.307308200414877],
           [-64.95674305577455, 18.307878604304754]]],
         [[[-64.94892594638844, 18.326455319983083],
           [-64.94866845432301, 18.32751452280932],
           [-64.95008466068288, 18.327677476514587],
           [-64.95441911045094, 18.323277672590397],
           [-64.95819566074391, 18.320670328574348],
           [-64.9593114596941, 18.318062945269897],
           [-64.95905396762868, 18.315129592096483],
           [-64.95785233799, 18.314640695067677],
           [-64.956049893532, 18.315944417409213],
           [-64.95579240146657, 18.317655538079887],
           [-64.95613572422047, 18.319570343533655],
           [-64.95476243320485, 18.32152586766059],
           [-64.95283124271413, 18.32189252597402],
           [-64.95407578769704, 18.322462881806107],
           [-64.9523591739275, 18.32441837324184],
           [-64.95004174533864, 18.32392950245503],
           [-64.94841096225758, 18.32466280811717],
           [-64.9488830310442, 18.326047932553656]]],
         [[[-64.94579312625905, 18.330284714919262],
           [-64.94669434848805, 18.328858886286476],
           [-64.94613644901295, 18.328370028049246],
           [-64.9436044437029, 18.329795860712277],
           [-64.94433400455495, 18.33040692825511]]],
         [[[-64.94287488285084, 18.324092459537457],
           [-64.94523522678395, 18.321648087184723],
           [-64.94476315799733, 18.32038514793891],
           [-64.94351861301442, 18.319692564439027],
           [-64.94343278232594, 18.318185167239893],
           [-64.94223115268727, 18.31757405652681],
           [-64.94201657596608, 18.318918497247118],
           [-64.94266030612965, 18.320059226637202],
           [-64.94381902042409, 18.321811046415963],
           [-64.94231698337575, 18.323033235758004],
           [-64.94253156009694, 18.323603587829687]]],
         [[[-64.93475176447822, 18.33172648772825],
           [-64.93294932002021, 18.334415138747747],
           [-64.93698336237861, 18.337674053627186],
           [-64.94093157404853, 18.33783699775851],
           [-64.94316317194892, 18.33368187443404],
           [-64.93912912959053, 18.331074687245977],
           [-64.93784166926338, 18.32602315021568],
           [-64.93466593378974, 18.32194922257215],
           [-64.93209101313545, 18.31836408689634],
           [-64.93011690730049, 18.31950481994102],
           [-64.9308035528083, 18.32374176255431],
           [-64.92925860041572, 18.326593492429947],
           [-64.93063189143135, 18.328956318712162],
           [-64.93294932002021, 18.33074878608354],
           [-64.93320681208564, 18.32854893717326],
           [-64.93552424067451, 18.328304507789323],
           [-64.93621088618232, 18.330585835272018]]],
         [[[-64.9241945897956, 18.33323376693369],
           [-64.92599703425361, 18.33021919538471],
           [-64.92402292841865, 18.324678764698923],
           [-64.92393709773017, 18.319871482537007],
           [-64.91904474848701, 18.318567789777237],
           [-64.90908838862373, 18.31302698598854],
           [-64.90471102351142, 18.310093547475624],
           [-64.90007616633369, 18.309441665500948],
           [-64.8926947271247, 18.3109083964926],
           [-64.88694407099678, 18.3119676944813],
           [-64.8828241979499, 18.31318995333743],
           [-64.88488413447334, 18.314656652573586],
           [-64.88419748896553, 18.316286303815925],
           [-64.88308169001533, 18.317101123683216],
           [-64.882480875196, 18.318241865052727],
           [-64.8853991186042, 18.317671495307838],
           [-64.89217974299385, 18.314901101238057],
           [-64.8978445684333, 18.316286303815925],
           [-64.90986086482002, 18.31799742110652],
           [-64.92170549982978, 18.330952474382038]]],
         [[[-64.88140799159004, 18.318893713887935],
           [-64.88179422968818, 18.317936310066028],
           [-64.88132216090156, 18.317406680144458],
           [-64.88087154978706, 18.31799742110652],
           [-64.88076426142646, 18.318588160052137],
           [-64.88029219263984, 18.319056675713103],
           [-64.87836100214912, 18.319321488351694],
           [-64.87673021906807, 18.31907704593045],
           [-64.87602211588813, 18.320014073336743],
           [-64.8772237455268, 18.321093685579175],
           [-64.87814642542793, 18.321093685579175],
           [-64.88054968470527, 18.319728891619764]]],
         [[[-64.87200953120185, 18.31869001139069],
           [-64.87243868464424, 18.31869001139069],
           [-64.87415529841377, 18.317447420965202],
           [-64.8755285894294, 18.317325198474208],
           [-64.87544275874092, 18.3166733437312],
           [-64.87492777461006, 18.316877048602116],
           [-64.87445570582344, 18.316897419076017],
           [-64.87432695979072, 18.316591861715693],
           [-64.87355448359443, 18.316815937166016],
           [-64.8729536687751, 18.317365939314136],
           [-64.87190224284126, 18.31789556936037],
           [-64.87166620844795, 18.318486308653657]]],
         [[[-64.86750342005683, 18.320360364789792],
           [-64.87112976664497, 18.318751122165033],
           [-64.87117268198921, 18.318221494737067],
           [-64.86788965815498, 18.319280747972122],
           [-64.86711718195869, 18.31979000202726]]],
         [[[-64.8578258037631, 18.318444205949742],
           [-64.8589416027133, 18.318321984162694],
           [-64.85874848366423, 18.317914577582485],
           [-64.85771851540251, 18.317873836871726]]],
         [[[-64.85291199684782, 18.319177534859296],
           [-64.85475735665007, 18.318851611283137],
           [-64.85419945717497, 18.316407164896795],
           [-64.84544472695036, 18.311110745962175],
           [-64.8420114994113, 18.314492324446647],
           [-64.85213952065153, 18.31925901565743]]],
         [[[-64.84926419258757, 18.326388436932678],
           [-64.85145287514372, 18.326632869024312],
           [-64.85316948891325, 18.324758880828412],
           [-64.85213952065153, 18.324514446088816],
           [-64.85020833016081, 18.325329227211025],
           [-64.84677510262175, 18.325329227211025],
           [-64.84977917671843, 18.323292267210313],
           [-64.8493071079318, 18.32268117453338],
           [-64.84797673226042, 18.32308856989117],
           [-64.84475808144255, 18.324677402620246],
           [-64.84098153114958, 18.324229271789424],
           [-64.83372883797331, 18.32080714353233],
           [-64.82939438820524, 18.324473706931975],
           [-64.83587460518523, 18.327121732171356],
           [-64.84076695442839, 18.327243947742236],
           [-64.8454876422946, 18.326225482013037],
           [-64.84780507088347, 18.325981049345735]]],
         [[[-64.85283347599366, 18.330897833056202],
           [-64.84742614261964, 18.3327717547374],
           [-64.84875651829103, 18.334319761678508],
           [-64.85201808445314, 18.333912392774536],
           [-64.85424968235353, 18.331631109175966]]],
         [[[-64.85249015323976, 18.33497154992847],
           [-64.84961482517579, 18.335745545283846],
           [-64.85090228550294, 18.340104296524242],
           [-64.86356231205323, 18.345725701242586],
           [-64.86751052372315, 18.341733708015607],
           [-64.86193152897218, 18.337660150485657],
           [-64.85309096805909, 18.334686392871447]]],
         [[[-64.88868521966258, 18.35373877850307],
           [-64.8807458809785, 18.354309029267966],
           [-64.8819904259614, 18.352842666353986],
           [-64.88005923547068, 18.350968962290853],
           [-64.8772697380952, 18.34970623721878],
           [-64.87272071160594, 18.349665503998267],
           [-64.87005996026316, 18.35129482532714],
           [-64.8710040978364, 18.352964863739018],
           [-64.87551020898142, 18.35390170748519],
           [-64.87950133599558, 18.355408793282717],
           [-64.88323497094432, 18.35650855029359],
           [-64.88722609795848, 18.357200986299638],
           [-64.888942711728, 18.36074458591946],
           [-64.89053057946482, 18.363392055404454],
           [-64.89336299218455, 18.3637993547981],
           [-64.89615248956004, 18.362088690886196],
           [-64.898126595395, 18.35980777929928],
           [-64.89490794457713, 18.358463656573793],
           [-64.89422129906932, 18.35911535374754],
           [-64.89533709801951, 18.360052164125072],
           [-64.89538001336375, 18.360988969419115],
           [-64.89413546838084, 18.36164065706013],
           [-64.8926334313325, 18.362129421176366],
           [-64.89057349480906, 18.359156084739222],
           [-64.89053057946482, 18.35618269709463],
           [-64.89018725671092, 18.354390493509236],
           [-64.88941478051463, 18.35382024301334]]],
         [[[-64.90098877136599, 18.361313175059806],
           [-64.89686889831911, 18.363594066755734],
           [-64.90734024231325, 18.370762387277047],
           [-64.93240280334841, 18.383469132574582],
           [-64.9562637347449, 18.395197604758877],
           [-64.97737808411013, 18.40529648274619],
           [-65.00278396789919, 18.387378711983466],
           [-65.06544037048708, 18.385423933362443],
           [-65.09015960876833, 18.360661486182522],
           [-65.08758468811403, 18.334673388120958],
           [-65.08603973572146, 18.33336980691594],
           [-65.07814331238161, 18.33434749374111],
           [-65.0465075651725, 18.343341038996194],
           [-65.03131553331215, 18.33926751934945],
           [-65.02444907823403, 18.33788250079924],
           [-64.99603912034829, 18.345703636395694],
           [-64.99990150132973, 18.34920673859321],
           [-65.00908538499672, 18.347332995090614],
           [-65.01904174486, 18.346273913686748],
           [-65.02041503587563, 18.344237200433113],
           [-65.02187415757973, 18.342363403037407],
           [-65.0259940306266, 18.343666916420087],
           [-65.02994224229653, 18.34790326700363],
           [-65.02728067928096, 18.35604652233806],
           [-65.01955591731807, 18.357675783468498],
           [-65.01886927181026, 18.360934259607184],
           [-65.0172384887292, 18.36077133726089],
           [-65.01483522945186, 18.359793799954247],
           [-65.00917040401241, 18.359956723223082],
           [-64.99955736690303, 18.359549414762714],
           [-64.99114595943233, 18.3583274836161],
           [-64.98960100703975, 18.362482014228004],
           [-64.99389254146358, 18.366554986387346],
           [-64.9897726684167, 18.367939775025107],
           [-64.97904383235714, 18.369324552550044],
           [-64.96805750423214, 18.36671790327445],
           [-64.96071898036739, 18.36280785553773],
           [-64.95222174220821, 18.36358172618314],
           [-64.92848955684444, 18.355679936465148],
           [-64.9205931335046, 18.357797977433542],
           [-64.92763124995967, 18.3628485856582],
           [-64.92265307002803, 18.366758632472184],
           [-64.91183840327999, 18.361545217036348],
           [-64.904456964071, 18.36040476141956]]],
         [[[-64.81677587838387, 18.363669850885138],
           [-64.87874563546394, 18.364973203463872],
           [-64.87857397408699, 18.358293417472417],
           [-64.85333975167488, 18.351287510606813],
           [-64.81265600533699, 18.353731463886252],
           [-64.81265600533699, 18.36008558054808]]],
         [[[-64.98990147533843, 18.351655441699133],
           [-64.99127476635405, 18.349374392297715],
           [-64.98732655468413, 18.344893671856035],
           [-64.98715489330718, 18.338946354362374],
           [-64.98552411022612, 18.33234703654621],
           [-65.00998585644194, 18.303421130582223],
           [-64.99865620556304, 18.297064931795337],
           [-64.98543827953765, 18.30782143926912],
           [-64.95883076610991, 18.323954947661868],
           [-64.95110600414702, 18.331124913012225],
           [-64.94818776073882, 18.337479861062445],
           [-64.9555691999478, 18.337479861062445],
           [-64.96586888256499, 18.335361570999186],
           [-64.97415154400298, 18.337194708142704],
           [-64.97634022655913, 18.338172373337773],
           [-64.97938721600005, 18.33853899636038],
           [-64.97874348583647, 18.34012768713926],
           [-64.97543900433013, 18.34143121738487],
           [-64.97200577679106, 18.33947591832976],
           [-64.96749966564605, 18.33890561860538],
           [-64.96638386669585, 18.33796869354479],
           [-64.96286480846831, 18.338253845187783],
           [-64.9616202634854, 18.340290628957607],
           [-64.9671134275479, 18.340779453490985],
           [-64.97578232708403, 18.34297914678185],
           [-64.98539536419341, 18.349374392297715],
           [-64.98921482983062, 18.351573976167778]]],
         [[[-64.99884932461211, 18.349720624949484],
           [-64.99803393307158, 18.35033162205384],
           [-64.99803393307158, 18.3510648157263],
           [-64.99751894894072, 18.351798006286547],
           [-64.99728291517489, 18.352235882516762],
           [-64.99696104946563, 18.352592292548042],
           [-64.99654798927733, 18.35280613822508],
           [-64.9964514297528, 18.353086173830345],
           [-64.996325366044, 18.353261832308615],
           [-64.99619393768737, 18.353493497536558],
           [-64.99584525051543, 18.35361060292433],
           [-64.99549119892546, 18.353585145238114],
           [-64.9953020410485, 18.3535392985875],
           [-64.99505527781913, 18.353447650861657],
           [-64.9947441415734, 18.3535189324304],
           [-64.99421842860649, 18.353905889004512],
           [-64.99549516009758, 18.354954740621647],
           [-64.99713667201469, 18.355148217408498],
           [-64.99902494716117, 18.353167615267687],
           [-64.99997981357048, 18.35180307449585],
           [-64.99914296435783, 18.350122841571743],
           [-64.9993897275872, 18.34972569321974]]],
         [[[-64.84117193740488, 18.341207507172275],
           [-64.84700842422129, 18.3386004334756],
           [-64.84469099563242, 18.33257142495589],
           [-64.84082861465097, 18.32980126947456],
           [-64.83064921061418, 18.326509642713482],
           [-64.83007071521054, 18.319467692853173],
           [-64.83573554064999, 18.314741748847325],
           [-64.84062788989316, 18.30643029296579],
           [-64.83908293750058, 18.30007420459373],
           [-64.85247252490292, 18.285975894426667],
           [-64.84835265185605, 18.269838849338914],
           [-64.85830901171933, 18.29412534652424],
           [-64.881483297608, 18.287462999409016],
           [-64.90791914965878, 18.282247193762736],
           [-64.90156767871152, 18.27051105756124],
           [-64.87736342456112, 18.248340635076172],
           [-64.7939359953619, 18.25877412764391],
           [-64.7877561857916, 18.287462999409016],
           [-64.80560896899472, 18.30962842242958],
           [-64.81659529711972, 18.330487405400415],
           [-64.82826827075253, 18.345804119111968]]]]),
    mangroves = ui.import && ui.import("mangroves", "table", {
      "id": "projects/ee-grettelvargas/assets/Mangroves"
    }) || ee.FeatureCollection("projects/ee-grettelvargas/assets/Mangroves"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B8_median",
          "B4_median",
          "B3_median"
        ],
        "min": 0.01769999973475933,
        "max": 0.33169999718666077,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B8_median","B4_median","B3_median"],"min":0.01769999973475933,"max":0.33169999718666077,"gamma":1};
//=============================================================================================
/////////// Data Preprocessing ////////////
//=============================================================================================
//center map to area being classified
Map.setCenter(-83.945, 9.9089, 8);
//specify the extent of the area to be classified
var classificationExtent = allArea; 
//------------------------------------------------------------------
// Establish function for masking clouds from Sentinel-2 image collection
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.//
  var cloudBitMask = 1 << 10; 
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
//---------------------------------------------------------------------------------------------.
//Function to mask high elevation areas out. This helps reduce the needed to train/classify
function maskHighElevation(image) {
  // Create "elevation" layer to mask out high-elevation features
  var srtm = ee.Image('USGS/SRTMGL1_003').clip(mangroves);
  var elevation_layer = srtm.select('elevation');
  //mask image
  return image.updateMask(elevation_layer.lte(20.0));//this cutoff is place dependent
}
//---------------------------------------------------------------------------------------------     
// Establish variable for visualizing data on screen
var median_vis = {
  min: 0.0,
  max: 0.3,
  bands: ['B4_median', 'B3_median', 'B2_median'],
};
//---------------------------------------------------------------------------------------------
// Load image collection of Sentinel-2 surface reflectance data
//The following function composites imagery from a specified period of time using the median reducer to 
//obtain a single image. It calculates several indices and adds the layers as band of the main image. 
//This additional bands are also used in the training and classification of mangroves
var getImage = function(geometry) {
  var start = ee.Date('2020-01-01');
  var end = ee.Date('2020-12-31');
  var date_range = ee.DateRange(start,end);
  var sentinel_collection = ee.ImageCollection('COPERNICUS/S2_SR')
    .filterDate(date_range)
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))//Pre-filter to get less cloudy granules.
    .filterBounds(geometry)
    .map(maskS2clouds)
    .map(maskHighElevation)
    .map(function(image) { return image.clip(geometry); });
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  //Reduce collection to 1 image and mask out water areas 
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  // Reduce Sentinel image collection to single image
  var sentinel_image = sentinel_collection.reduce(ee.Reducer.median());
  // Create "NDWI" layer to mask out water features
  var ndwi_layer = sentinel_image.normalizedDifference(['B3_median', 'B8_median']);
  // Mask water out of Sentinel image using NDWI layer
  sentinel_image = sentinel_image.updateMask(ndwi_layer.lte(0.0));
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  //Create additional layers to use as bands in classification and for masking 
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  //Calculate and add NDVI (Normalized Difference Vegetation Index (NDVI))
  var ndvi = sentinel_image.normalizedDifference(['B8_median', 'B4_median']);
  var image = sentinel_image.addBands(ndvi.rename('NDVI'));
  //Calculate and add NDBI (Normalized Difference Built-up Index (NDBI))
  //SWIR(Band11)-NIR(Band8)/ SWIR(Band11)+NIR(Band8)
  var ndbi = sentinel_image.normalizedDifference(['B11_median','B8_median']);
  image = image.addBands(ndbi.rename('NDBI'));
  //Calculate and add NDBaI (Normalized Difference Bareness Index (NDBaI))
  //https://eo4sd-lab.net/sites/default/files/eo4sd_lab_s2_ndbal_guide_v1.1.pdf
  // (SWIR [B11] – Vegetation Red Edge [B8A] / (SWIR [B11] + Vegetation Red Edge [B8A])
  var ndbai = sentinel_image.normalizedDifference(['B11_median','B8A_median']);
  image = image.addBands(ndbai.rename('NDBaI'));
  //Calculate and add NDMI (Normalized Difference Moisture Index  (NDMI))
  //NIR(B8)-SWIR1(B11)/NIR(B8)+SWIR1(B11)
  var ndmi = sentinel_image.normalizedDifference(['B8_median', 'B11_median']);
  image = image.addBands(ndmi.rename('NDMI'));
  //---------------------------------------------------------------------------------------------  
  //Calculate mangroves heights from SRTM data following the method of Simard et al. mangrove height 
  //calculations. add the mangrove height layer as a band the the composite image.
  // SRTMHmax is estimated 95th percentile of mangrove height
  var SRTMHmax = ee.Image("USGS/SRTMGL1_003").multiply(1.697);  // Eq. 1 Simard et al.
  //Mask the data to match sentinel image extents
  SRTMHmax = SRTMHmax.updateMask(sentinel_image.select("B8_median"));
  var ZeroMask = SRTMHmax.eq(0);  // Make a mask for areas with zero elevation
  SRTMHmax = SRTMHmax.where(ZeroMask,0.5);  // Simard et al. replace elevations of 0 with 0.5
  var pal = ['EFC2B3','ECB176','E9BD3A','E6E600','63C600','00A600'];  // Define color ramp for height layer
  //Map.addLayer(SRTMHmax, {min:0, max:20, palette: pal}, 'Mangrove Height - 95th Percentile');
  var SRTMHba = SRTMHmax.multiply(1.0754); // Eq. 2 Simard et al.
  //Map.addLayer(SRTMHba, {min:0, max:20, palette: pal}, 'Mangrove Height - Basal Area Weighted');
  //-------------------------------------------------------
  image = image.addBands(SRTMHba.rename('MangHGT'));
  // Mask non-Mangrove vegetation using Mangrove heights. If an appropriate cutoff for Mangroves height is 
  //know for an area, it can be used to further mask out the image 
  //var image = image.updateMask(SRTMHba.lte(22)); //eliminate areas with hights greater than 22m. 
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-
  // Mask non-vegetation using NDVI: Here I use a low threshold of 0.1 in order not to exclude areas of dead mangroves.
  //If you do not need dead mangrove areas, increase the threshold to only retain green areas.
  var veg_sentinel_image = image.updateMask(ndvi.gte(0.1)).set('system:time_start',ee.Date(end).millis());
  return(veg_sentinel_image);
};
//Image to be used for training is the full extent image. I use the full extent image here because it allows me to used
//training data from any point within that extent. E.g., I can use training data for Puerto Rico to classify St. Thomas
//if the full extent image includes both of these areas.
var trainingImage = getImage(mangroves);
//Map.addLayer(trainingImage, median_vis, "sentinel image: full extent");
//=============================================================================================
/////// MANGROVE CLASSIFICATION /////////
//=============================================================================================
//Image to be classified
var classificationImage = getImage(classificationExtent);
Map.addLayer(classificationImage, imageVisParam, "sentinel image: to be classified");
//----------------------------------------------------- -
//Merge training data feature collections into one feature collection. The training data can be collected from the image
//or can be from the field. Make sure that in the attribute table of the training data, each cover class has a unique value. 
//In this code, all mangroves points have a value of 0 'zero' and the rest can have any value.  
//var training_points = st_mang1.merge(st_mang2).merge(st_mang3).merge(st_mang4).merge(st_mang5).merge(st_veg1)
//.merge(st_veg2).merge(st_veg3).merge(st_veg4).merge(st_veg5).merge(st_bare1).merge(st_water);
// Get and print the number of training points.
//var numTrnPoints= training_points.size();
//print('Number of training points:', numTrnPoints);
//----------------------------------------------------- -
//Function for performing the classification
//function classification(trainingImage,classificationImage){
  // Designate which spectral bands to include in the classification
//  var bands = ["B8_median", "B4_median", "B3_median", "B2_median", "NDVI","NDBI", "NDBaI", "NDMI", "MangHGT"];
  // Train the classifier using the training points
//  var training = trainingImage.select(bands).sampleRegions({
//    collection: training_points,
//    properties: ['class'],
//    scale: 10
//  });
  // Establish the classifier
//  var classifier = ee.Classifier.smileRandomForest(numTrnPoints)
//    .train({
//      features: training,
//      classProperty: 'class',
//      inputProperties: bands
//    });
    //classify the image
//  var classified = classificationImage.select(bands).classify(classifier);
//  return classified;
//}
//----------------------------------------------------- -
// Classify the image
//var classified_image = classification(trainingImage,classificationImage);
//Map.addLayer(classified_image.randomVisualizer(), {}, 'Initial Image Classification - multiple classes');
//=============================================================================================
/////// POST-PROCESSING /////////
//=============================================================================================
// Smooth with a mode filter. //Filter the image to romove groups of (isolated) pixels
//var SCALE=10;
//var mode = classified_image.focal_mode();
// Weighted smoothing 
// using a 3x3 window
// euclidean distance weighting from corners
//var weights = [[1,2,1],
//               [2,3,2],
//               [1,2,1]];
// create a 3x3 kernel with the weights
// kernel W and H must equal weight H and H
//var kernel = ee.Kernel.fixed(3,3,weights);
// apply mode filter on neightborhood using weights
//var Classification_mode_filtered = classified_image.reduceNeighborhood({
//  reducer: ee.Reducer.mode(),
//  kernel: kernel
//});//.reproject('EPSG:4326', null, SCALE);
//sometimes, it may be necessary to reproject the image after filter to retain the scale. 
//In that case, add the .reproject operations above. However, this operation is costly.
//.reproject('EPSG:4326', null, SCALE)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-
//Extract the Mangrove class from the filtered thematic map. Since we filtered the classification 
//that had all the classes in it, lets now extract just the mangrove class. The class has a value 
//of 0. This values is determined by the whatever value was assigned to the training data for mangroves.
//var Mangroves_filtered = Classification_mode_filtered.updateMask(Classification_mode_filtered.eq(0)); 
//Map.addLayer(Mangroves_filtered.randomVisualizer(), {}, 'Mangrove classification mode filtered');
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//The classification may further be filtered e.g. using mangroves height to futher eliminate non 
//mangrove areas. If a cutoff height is determined for Mangroves (mangroved are shorter than most trees), 
//then that can be used as follows. As of now, we do not know this cut-off and so the filter is not applied. 
//var Mangroves_filtered2 = Mangroves_filtered.updateMask(SRTMHba.lte(18.5));
//Map.addLayer(Mangroves_filtered2.randomVisualizer(), {}, 'Mangrove classification mode_height filtered');
//=============================================================================================-
/////// Manual Editing /////////
//=============================================================================================
//Manual editing to remove misclassifications
//create a feature collection (polygons) of areas that are not supposed to be Mangroves
//this is the 'ExclusionAreas' file here. The polygon can be a feature collected digitized here
//A function to clip off the unwanted areas from the classification
//var maskInside = function(image, geometry) {
//  var mask = ee.Image.constant(1).clip(geometry).mask().not();
//  return image.updateMask(mask);
//};
//var Mangroves_filtered_edited = maskInside(Mangroves_filtered, ExclusionAreas);
//Map.addLayer(Mangroves_filtered_edited.randomVisualizer(), {}, 'StThomas Mangrove map');
//=============================================================================================
/////// // Calculate mangrove area, and print to console/////////
//=============================================================================================
//Mangroves area from current map
//var MangroveClass = Mangroves_filtered.select(0).rename('mangroves');//rename the mangroves band
//var areaImage = MangroveClass.add(ee.Image.pixelArea());//assign pixel values to be pixel area
//var Mangrove_area = areaImage.reduceRegion({
//  reducer: ee.Reducer.sum(), //add up areas of all pixels
//  geometry: classificationExtent,
//  scale: 10,
//  maxPixels: 1e10
//  });
//var MangroveAreaSqKm = ee.Number(
//  Mangrove_area.get('mangroves')).divide(1e6).round();
//print('StThomas mangrove area as of 2020:', MangroveAreaSqKm, ' SqKm');
//=============================================================================================
/////// // //Display existing layers of old Mangroves and validation data for visual comparison/////////
//============================================================================================= 
//Display existing layers of old Mangroves
//Map.addLayer(GMW, {color: 'green'}, 'GMW_2016'); //Global Mangroves watch layer
//Map.addLayer(st_ThomasJohn_NCCOS_2002, {color: 'yellow'}, 'st_ThomasJohn_NCCOS_2002');
//=============================================================================================
///////// ACCURACY ASSESSMENT /////////////
//============================================================================================= 
// Convert mangrove raster to polygon, inside of which to generate random mangrove present points for validation
//var mangroves_polygon = Mangroves_filtered.toInt().reduceToVectors({
//  geometry: classificationExtent,
//  crs: Mangroves_filtered.projection(),
//  scale: 10,
//  geometryType: 'polygon',
//  eightConnected: false,
//  maxPixels: 1e9
//});
//Map.addLayer(mangroves_polygon, {color: 'yellow'}, 'mangroves polygon');
// Export the mangrove polygon to Google Drive 
//Export.table.toDrive({
//  collection: StThomas_mangroves_polygon,
//  description:'StThomas_mangroves',
//  fileFormat: 'KMZ'
//});
// Generate random points for "mangrove presence" validation, and export to Google Drive
//var presence_points = ee.FeatureCollection.randomPoints(mangroves_polygon, 1000);
//Export.table.toDrive({collection: presence_points, fileFormat: 'GeoJSON'});
//Accuracy assesssment can be done outside of GEE
//=============================================================================================
/////// END /////////
//=============================================================================================
// Paneles____________________________________________________________________________
Map.setCenter(-83.945, 9.9089, 8);
//App title
var header = ui.Label('MONITOREO DE MANGLARES COSTA RICA', {fontSize: '20px', fontWeight: 'bold', color: '4A997E'});
//App summary
var text = ui.Label(
  'Esta herramienta expone mosaicos de imágenes Sentinel-2 año 2020.',
      {fontSize: '14px'});
//3.2) Create a panel to hold text
var panel = ui.Panel({
  widgets:[header, text],//Adds header and text
  style:{width: '300px',position:'middle-right'}});
//3.3) Create variable for additional text and separators
//This creates another panel to house a line separator and instructions for the user
var intro = ui.Panel([
  ui.Label({
    value: '____________________________________________',
    style: {fontWeight: 'bold',  color: '4A997E'},
  }),
  ui.Label({
    value:'Unidad de Acción Climática, CATIE, CR',
    style: {fontSize: '15px', fontWeight: 'bold'}
  })]);
//Add this new panel to the larger panel we created 
panel.add(intro)
//3.4) Add our main panel to the root of our GUI
ui.root.insert(1,panel)