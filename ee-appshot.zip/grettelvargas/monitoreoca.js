var imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI"
        ],
        "min": -0.32028702475058113,
        "max": 0.7905862203211292,
        "palette": [
          "1916ff",
          "ff170c",
          "40ff1d"
        ]
      }
    }) || {"opacity":1,"bands":["NDVI"],"min":-0.32028702475058113,"max":0.7905862203211292,"palette":["1916ff","ff170c","40ff1d"]},
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 0.55,
        "bands": [
          "vegetation"
        ],
        "palette": [
          "a59a89"
        ]
      }
    }) || {"opacity":0.55,"bands":["vegetation"],"palette":["a59a89"]},
    dsm = ui.import && ui.import("dsm", "imageCollection", {
      "id": "JAXA/ALOS/AW3D30/V3_2"
    }) || ee.ImageCollection("JAXA/ALOS/AW3D30/V3_2"),
    CA = ui.import && ui.import("CA", "table", {
      "id": "users/grettelvargas/Cosecha_agua/Area_CA"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/Area_CA"),
    munis = ui.import && ui.import("munis", "table", {
      "id": "users/grettelvargas/curso_GEE/Municipios_CA"
    }) || ee.FeatureCollection("users/grettelvargas/curso_GEE/Municipios_CA"),
    classes = ui.import && ui.import("classes", "table", {
      "id": "users/grettelvargas/classes"
    }) || ee.FeatureCollection("users/grettelvargas/classes"),
    agua = ui.import && ui.import("agua", "table", {
      "id": "users/grettelvargas/Cosecha_agua/agua"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/agua"),
    lat_ab = ui.import && ui.import("lat_ab", "table", {
      "id": "users/grettelvargas/Cosecha_agua/b_latiabierto"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/b_latiabierto"),
    lat_ce = ui.import && ui.import("lat_ce", "table", {
      "id": "users/grettelvargas/Cosecha_agua/b_laticerrado"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/b_laticerrado"),
    bp_abi = ui.import && ui.import("bp_abi", "table", {
      "id": "users/grettelvargas/Cosecha_agua/bp_abierto"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/bp_abierto"),
    bp_cerr = ui.import && ui.import("bp_cerr", "table", {
      "id": "users/grettelvargas/Cosecha_agua/bp_cerrado"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/bp_cerrado"),
    cafe = ui.import && ui.import("cafe", "table", {
      "id": "users/grettelvargas/Cosecha_agua/cafe_sombra"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/cafe_sombra"),
    citri = ui.import && ui.import("citri", "table", {
      "id": "users/grettelvargas/Cosecha_agua/citri"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/citri"),
    forestal = ui.import && ui.import("forestal", "table", {
      "id": "users/grettelvargas/Cosecha_agua/forestal"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/forestal"),
    frijol = ui.import && ui.import("frijol", "table", {
      "id": "users/grettelvargas/Cosecha_agua/frijol"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/frijol"),
    horta = ui.import && ui.import("horta", "table", {
      "id": "users/grettelvargas/Cosecha_agua/horta"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/horta"),
    maiz = ui.import && ui.import("maiz", "table", {
      "id": "users/grettelvargas/Cosecha_agua/maiz"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/maiz"),
    mango = ui.import && ui.import("mango", "table", {
      "id": "users/grettelvargas/Cosecha_agua/mango"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/mango"),
    matorr = ui.import && ui.import("matorr", "table", {
      "id": "users/grettelvargas/Cosecha_agua/matorr"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/matorr"),
    p_malez = ui.import && ui.import("p_malez", "table", {
      "id": "users/grettelvargas/Cosecha_agua/p_maleza"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/p_maleza"),
    p_manej = ui.import && ui.import("p_manej", "table", {
      "id": "users/grettelvargas/Cosecha_agua/p_manej"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/p_manej"),
    pobla = ui.import && ui.import("pobla", "table", {
      "id": "users/grettelvargas/Cosecha_agua/poblados"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/poblados"),
    s_desn = ui.import && ui.import("s_desn", "table", {
      "id": "users/grettelvargas/Cosecha_agua/s_desn"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/s_desn"),
    sorgo = ui.import && ui.import("sorgo", "table", {
      "id": "users/grettelvargas/Cosecha_agua/sorgo"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/sorgo"),
    b_rege = ui.import && ui.import("b_rege", "table", {
      "id": "users/grettelvargas/Cosecha_agua/b_rege"
    }) || ee.FeatureCollection("users/grettelvargas/Cosecha_agua/b_rege"),
    water = ui.import && ui.import("water", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -86.72668635940552,
            13.464010325044374
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72612845993042,
            13.463655569847669
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72562420463562,
            13.463227776116932
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72521650886536,
            13.462737377484892
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7246478805542,
            13.462288714026476
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72417581176758,
            13.461933956277885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72401487922669,
            13.46154789577759
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72431528663635,
            13.46184004972702
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72450840568543,
            13.462080033061582
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72492683029175,
            13.462486960774601
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72704041099549,
            13.464239872244368
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72753393745423,
            13.464552890798636
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72773778533936,
            13.46465723022573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72637522315979,
            13.463989457106189
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72638595199585,
            13.463749475686217
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72589242553711,
            13.463561663972277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72592461204529,
            13.46337385211096
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72550618743897,
            13.463081700033745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72549545860291,
            13.462977359919742
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7250984916687,
            13.462653905277243
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7232799539566,
            13.460301020449245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72337114906311,
            13.46011842309864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72319948768616,
            13.460087120681699
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72312975025177,
            13.459920174388863
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72197103595734,
            13.460681865903734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72187984085083,
            13.460744470577993
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7219281206131,
            13.46064012944513
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72168672180176,
            13.460989672061187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72179401016236,
            13.460994889111277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68539413236067,
            13.465432780029118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68523319981978,
            13.465777098699835
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68543704770491,
            13.465140630465434
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68560870908186,
            13.464775443009238
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68567308209822,
            13.464316349416508
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68546923421309,
            13.465912739252262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68552287839339,
            13.466361395916365
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68534048818037,
            13.46956457137485
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68506153844282,
            13.47015929304213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68484696172163,
            13.470446219633558
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68520637772963,
            13.469976703213868
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68522247098372,
            13.469841064965484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6849864365904,
            13.470096690831006
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68491133473799,
            13.470352316423355
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68475576661513,
            13.470686194336615
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68454118989393,
            13.470832265777121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68472894452498,
            13.470482737538685
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68002653432237,
            13.471728591606634
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68027329755174,
            13.471671206623546
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68051469636308,
            13.471655556171227
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68071317983018,
            13.471608604808106
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68101895165788,
            13.471582520713515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68122279954301,
            13.471566870255392
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68084729028092,
            13.471650339353555
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68089557004319,
            13.471566870255392
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68222058129655,
            13.471019103575854
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68238687825547,
            13.470914766923247
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68265509915696,
            13.47084694807464
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6825531752144,
            13.47084694807464
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68271947217332,
            13.470763478696115
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.65999742245458,
            13.475841463394204
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66006179547094,
            13.475497159210802
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66020127033971,
            13.47534065714534
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66022272801183,
            13.474965051770338
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66173549389623,
            13.4733269880989
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66195007061742,
            13.473139183903674
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66290493702672,
            13.47270097354128
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66308732723974,
            13.472554903242047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67596305906362,
            13.472057384293718
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67552317678518,
            13.471994782579358
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67593087255544,
            13.4719739153376
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67461122572011,
            13.471848711848816
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6740318685729,
            13.471713074662
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6745361238677,
            13.471817410966377
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67470778524465,
            13.4717756764501
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64364897720068,
            13.507164550527037
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64369189254492,
            13.506559488876235
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64420687667578,
            13.506413439282298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64485060683936,
            13.506079611303223
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64504372588843,
            13.505683189971302
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64530121795386,
            13.505683189971302
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6349359279178,
            13.513509770306406
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63480718188508,
            13.514031360066648
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63463552050813,
            13.514636402758839
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63459260516389,
            13.514093950761188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63469989352448,
            13.513760133533738
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63500030093415,
            13.513405452217425
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6281660323642,
            13.51775547778967
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62839133792146,
            13.51775547778967
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62854154162629,
            13.517703319679917
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62844498210175,
            13.517536413651964
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62813384585603,
            13.51759900342614
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62767250590547,
            13.517724182925182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62745792918427,
            13.51785979397495
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62750084452851,
            13.517484255494262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62791926913484,
            13.51742166568996
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6282196765445,
            13.517484255494262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62762959056123,
            13.517463392227981
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62727553897126,
            13.517682456432807
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62699658923371,
            13.518026699776435
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62685711436494,
            13.518423100586451
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62673909716828,
            13.518819500737123
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62663180880769,
            13.519090721512953
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62633140139802,
            13.51934107887819
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62612755351289,
            13.519466257462174
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62579495959504,
            13.519737477501891
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62710387759431,
            13.51775547778967
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62739355616792,
            13.517463392227981
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62765104823335,
            13.51732778095266
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62811238818391,
            13.5174112340543
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62320237207618,
            13.528335290298735
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62330966043677,
            13.528168391719346
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62336330461707,
            13.527980630677723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62348132181373,
            13.527657264092367
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62357788133826,
            13.527427777862192
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62365298319068,
            13.527219153824673
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62366371202674,
            13.526958373520785
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6236744408628,
            13.526749749072081
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62368516969886,
            13.526395087089877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62365298319068,
            13.526113443374841
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62357788133826,
            13.52581093679141
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62347059297767,
            13.525654467718214
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62295560884681,
            13.528804691926098
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62265520143714,
            13.529086332458379
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.622268963339,
            13.529409697103175
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62163596201148,
            13.529743492404926
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62133555460181,
            13.52991038988033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62247281122413,
            13.529284523744373
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62191491174903,
            13.529628750322736
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62303071069923,
            13.528627362531177
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62276248979774,
            13.528950727799234
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62314872789588,
            13.528199685211895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62336330461707,
            13.527751144759154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62334184694495,
            13.52553972366586
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62337403345313,
            13.525289372814312
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62329893160071,
            13.52525807893937
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61681395715954,
            13.530192029104803
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61683541483166,
            13.530348495196664
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61647063440563,
            13.530650996016066
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61629897302868,
            13.530786599706895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61594492143871,
            13.531016082700052
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61568742937328,
            13.531235134441712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61529046243908,
            13.531527203117099
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61490422434093,
            13.531694099342175
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61456090158703,
            13.531694099342175
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61471110529186,
            13.53150634108075
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61495786852123,
            13.531349875749779
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61514025873424,
            13.531214272379765
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61539775079967,
            13.531068237894916
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61635261720897,
            13.53051161045084
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61643844789745,
            13.530396868738803
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61607366747143,
            13.530772386863482
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61592346376659,
            13.53087669734856
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6156015986848,
            13.531147904395892
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6155479545045,
            13.531012300910845
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6156552428651,
            13.530814111062995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61597710794689,
            13.530636783164562
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61617022699596,
            13.53051161045084
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61648136324169,
            13.530355144466164
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61667448229076,
            13.530292558043506
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60440069383861,
            13.538809375821778
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6043792361665,
            13.53872071486732
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6045777196336,
            13.538658130644308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60458308405163,
            13.538705068813112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60484594053509,
            13.538548608214386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60524290746929,
            13.538308701763196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60543066210033,
            13.538141810176231
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60559695905926,
            13.538042718241094
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60576325601818,
            13.537912334053035
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60584372228863,
            13.53775587293308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60568278974773,
            13.537891472576309
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60559159464123,
            13.53799577994162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60540920442821,
            13.538115733355198
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60525363630535,
            13.538230471346395
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60494786447765,
            13.538407793587586
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60507124609234,
            13.53846516251966
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60510879701854,
            13.538360855360121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60462063497783,
            13.538605977112532
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60474938101055,
            13.538538177504154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60466355032207,
            13.538694638109735
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60443824476482,
            13.538694638109735
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60450261778118,
            13.538647699938858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60463672823192,
            13.538532962148855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60479766077282,
            13.538475593233112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60422366804363,
            13.538798945122972
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60527509397747,
            13.538178317720881
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60509270376446,
            13.538345209282246
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6054789418626,
            13.538089656531291
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6058383578706,
            13.53764635008788
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59535396974687,
            13.542173917018838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5953968850911,
            13.542111333704177
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59552563112382,
            13.542137410087273
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59577239435319,
            13.542121764257761
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59585822504167,
            13.542069611485248
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59591723364,
            13.542043535094697
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59571338575486,
            13.542126979534375
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5956490127385,
            13.542116548981019
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59558463972215,
            13.542100903150121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59544516485337,
            13.542111333704177
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59532714765672,
            13.542111333704177
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59576702993516,
            13.542074826763008
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5959011403859,
            13.542027889259003
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59597087782029,
            13.54201224342229
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59599233549241,
            13.542090472595621
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26744016621008,
            13.506308415209144
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26752599689856,
            13.506162365461485
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26752599689856,
            13.507205575982947
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26761182758703,
            13.507643723041404
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26761182758703,
            13.508207053791025
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26769765827551,
            13.508749519181281
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26786931965246,
            13.509291983337683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2673543355216,
            13.505536436958693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26748308155432,
            13.50591199425745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26013118616744,
            13.492448160081743
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26037794939681,
            13.492375130978132
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26076418749496,
            13.492750708987339
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26118261210128,
            13.493053257509589
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26153666369125,
            13.493314074893513
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26183707110091,
            13.49356445931405
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26209456316634,
            13.49368965142586
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26247007242843,
            13.493919170127032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26274902216598,
            13.493960900776264
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26286703936263,
            13.493908737463583
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26247007242843,
            13.493741814786416
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2620516478221,
            13.49358532467058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26157957903548,
            13.493261911439527
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26140791765853,
            13.493011526701723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26101095072433,
            13.492844603397327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26095730654403,
            13.492782007128103
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26060325495406,
            13.492521189163025
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26054961077377,
            13.492865468816769
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26016337267562,
            13.492354265515857
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26721221796676,
            13.49621434500351
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26728731981918,
            13.496130884485504
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26702982775375,
            13.49588050275643
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.267255133311,
            13.49608915421556
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26678306452438,
            13.495755311793411
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.266536301295,
            13.495703148872778
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26682597986861,
            13.495661418528066
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34546786250229,
            13.45632978536969
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34526401461716,
            13.456580208520602
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34500652255173,
            13.456726288571035
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34494214953537,
            13.456611511396057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34502798022385,
            13.45651760275742
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34521037043686,
            13.456486299869693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34531765879746,
            13.456298482457406
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34531765879746,
            13.456288048152395
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34513526858444,
            13.45631935106604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34502798022385,
            13.456413259782417
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34584337176437,
            13.455954150152264
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34595066012497,
            13.455828938282174
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34607940615768,
            13.455672423352503
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34597211779709,
            13.455661989020216
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34580045642014,
            13.455818503956706
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34574681223984,
            13.455891544225388
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32722003711001,
            13.472572627693058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32725222361819,
            13.47266653003157
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32762773288027,
            13.472676963622458
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32775647891299,
            13.472583061288056
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32746680033938,
            13.472562194097616
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3275955463721,
            13.472583061288056
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32728441012637,
            13.472510026113579
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32701618922488,
            13.472520459711298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32746680033938,
            13.472478725317687
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32769210589663,
            13.472478725317687
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32713420642153,
            13.472499592515401
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3268767143561,
            13.472489158916767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.40883353263092,
            13.628092244279962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.40898373633576,
            13.628060963961767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4094236186142,
            13.627998403312935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41001370459747,
            13.628040110414002
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4104321292038,
            13.628029683639426
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.410829096138,
            13.628008830088898
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41109731703949,
            13.62798797653654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4109900286789,
            13.627904562308656
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41091492682648,
            13.62784200161844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41062524825287,
            13.62798797653654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41006734877777,
            13.628008830088898
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.40965965300751,
            13.62798797653654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4098742297287,
            13.627998403312935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.40904810935211,
            13.627967122982325
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.40882280379486,
            13.627998403312935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4209692814668,
            13.623321825932528
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42058304336865,
            13.623353106877904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42034700897534,
            13.623353106877904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42003587272961,
            13.623363533858758
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42045429733594,
            13.623207129097418
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42130187538464,
            13.623154994153975
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4207010605653,
            13.623113286190952
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42084053543408,
            13.623050724232598
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42040065315564,
            13.623009016251178
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42114094284375,
            13.623092432206676
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42236403015454,
            13.623154994153975
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42255714920361,
            13.623134140173386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42217091110547,
            13.623113286190952
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42149499443371,
            13.623134140173386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42184904602368,
            13.623092432206676
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42126968887646,
            13.62302987024281
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42094782379468,
            13.623009016251178
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42608693626721,
            13.62410384832507
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.426408801349,
            13.623791039678483
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4257436135133,
            13.624197690838344
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44253283827021,
            13.621377765931273
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44227534620478,
            13.621398620066794
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44246846525385,
            13.621263068153064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44253283827021,
            13.621085807840947
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44270449964716,
            13.620991964092502
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4438095697613,
            13.6210023911775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44414216367915,
            13.620991964092502
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44336968748286,
            13.620971109921106
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44295126287653,
            13.620971109921106
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4431980261059,
            13.6210023911775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44636303274348,
            13.619615584836307
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44621282903864,
            13.619719856272544
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44650250761225,
            13.619407041825898
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4467814573498,
            13.61915678997064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44709259359553,
            13.61895867373076
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44695311872675,
            13.61894824655565
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44703894941523,
            13.61879183887371
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39754887696843,
            13.62385351634529
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39777418252568,
            13.623926505047233
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3978492843781,
            13.623759673695394
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39766689416508,
            13.62366583100826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39743085977177,
            13.62366583100826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39685150262456,
            13.623582415255086
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3957249748383,
            13.62366583100826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39529582139592,
            13.623551134340065
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3953816520844,
            13.623686684941953
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39558549996953,
            13.62363455010427
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39590736505131,
            13.623582415255086
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39602538224797,
            13.623686684941953
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39626141664128,
            13.623655404040726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39655109521489,
            13.623551134340065
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.397291384903,
            13.62359284222584
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39703389283757,
            13.62361369616597
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39559622880559,
            13.62359284222584
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37605475989693,
            13.61565364574413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37596892920845,
            13.615789200873014
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37648391333931,
            13.616154156603109
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37678432074898,
            13.616550393615386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37709545699471,
            13.616904920905833
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37723493186348,
            13.617103038866112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3773100337159,
            13.617009193537182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37704181281441,
            13.616675520955061
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3769130667817,
            13.616539966334097
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3767521342408,
            13.616383557059551
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37637662497872,
            13.616039456291476
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37626933661812,
            13.615956037848074
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37593674270028,
            13.61562236378029
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37584018317574,
            13.615716209659416
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37593674270028,
            13.615611936458073
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37625860778206,
            13.615987319767793
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37662338820809,
            13.616362702481794
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37662338820809,
            13.616508684487453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3766984900605,
            13.616310566029355
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36587497154389,
            13.61088016530863
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36601444641266,
            13.611297266180118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36606809059296,
            13.611067860791783
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36607881942902,
            13.610817600114506
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36604663292084,
            13.610536056536205
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36587497154389,
            13.610525628989835
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36583205619965,
            13.610692469676614
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36578914085541,
            13.610400498397558
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36604663292084,
            13.610442208602338
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36396523872529,
            13.607751885339667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36428710380707,
            13.60782487901009
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36360045829926,
            13.607835306675463
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36314984718476,
            13.607762313008244
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36302110115204,
            13.607522476514651
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3629245416275,
            13.607428627385774
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36330005088959,
            13.607678891646735
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36341806808625,
            13.607689319318531
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36380430618439,
            13.607783168344044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36335369506989,
            13.607605897931286
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36318203369294,
            13.607564187226652
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36362191597138,
            13.607710174660744
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "label": 0
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-86.72668635940552, 13.464010325044374]),
            {
              "label": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72612845993042, 13.463655569847669]),
            {
              "label": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72562420463562, 13.463227776116932]),
            {
              "label": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72521650886536, 13.462737377484892]),
            {
              "label": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7246478805542, 13.462288714026476]),
            {
              "label": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72417581176758, 13.461933956277885]),
            {
              "label": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72401487922669, 13.46154789577759]),
            {
              "label": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72431528663635, 13.46184004972702]),
            {
              "label": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72450840568543, 13.462080033061582]),
            {
              "label": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72492683029175, 13.462486960774601]),
            {
              "label": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72704041099549, 13.464239872244368]),
            {
              "label": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72753393745423, 13.464552890798636]),
            {
              "label": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72773778533936, 13.46465723022573]),
            {
              "label": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72637522315979, 13.463989457106189]),
            {
              "label": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72638595199585, 13.463749475686217]),
            {
              "label": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72589242553711, 13.463561663972277]),
            {
              "label": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72592461204529, 13.46337385211096]),
            {
              "label": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72550618743897, 13.463081700033745]),
            {
              "label": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72549545860291, 13.462977359919742]),
            {
              "label": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7250984916687, 13.462653905277243]),
            {
              "label": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7232799539566, 13.460301020449245]),
            {
              "label": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72337114906311, 13.46011842309864]),
            {
              "label": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72319948768616, 13.460087120681699]),
            {
              "label": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72312975025177, 13.459920174388863]),
            {
              "label": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72197103595734, 13.460681865903734]),
            {
              "label": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72187984085083, 13.460744470577993]),
            {
              "label": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7219281206131, 13.46064012944513]),
            {
              "label": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72168672180176, 13.460989672061187]),
            {
              "label": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72179401016236, 13.460994889111277]),
            {
              "label": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68539413236067, 13.465432780029118]),
            {
              "label": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68523319981978, 13.465777098699835]),
            {
              "label": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68543704770491, 13.465140630465434]),
            {
              "label": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68560870908186, 13.464775443009238]),
            {
              "label": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68567308209822, 13.464316349416508]),
            {
              "label": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68546923421309, 13.465912739252262]),
            {
              "label": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68552287839339, 13.466361395916365]),
            {
              "label": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68534048818037, 13.46956457137485]),
            {
              "label": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68506153844282, 13.47015929304213]),
            {
              "label": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68484696172163, 13.470446219633558]),
            {
              "label": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68520637772963, 13.469976703213868]),
            {
              "label": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68522247098372, 13.469841064965484]),
            {
              "label": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6849864365904, 13.470096690831006]),
            {
              "label": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68491133473799, 13.470352316423355]),
            {
              "label": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68475576661513, 13.470686194336615]),
            {
              "label": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68454118989393, 13.470832265777121]),
            {
              "label": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68472894452498, 13.470482737538685]),
            {
              "label": 0,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68002653432237, 13.471728591606634]),
            {
              "label": 0,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68027329755174, 13.471671206623546]),
            {
              "label": 0,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68051469636308, 13.471655556171227]),
            {
              "label": 0,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68071317983018, 13.471608604808106]),
            {
              "label": 0,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68101895165788, 13.471582520713515]),
            {
              "label": 0,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68122279954301, 13.471566870255392]),
            {
              "label": 0,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68084729028092, 13.471650339353555]),
            {
              "label": 0,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68089557004319, 13.471566870255392]),
            {
              "label": 0,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68222058129655, 13.471019103575854]),
            {
              "label": 0,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68238687825547, 13.470914766923247]),
            {
              "label": 0,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68265509915696, 13.47084694807464]),
            {
              "label": 0,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6825531752144, 13.47084694807464]),
            {
              "label": 0,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68271947217332, 13.470763478696115]),
            {
              "label": 0,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.65999742245458, 13.475841463394204]),
            {
              "label": 0,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66006179547094, 13.475497159210802]),
            {
              "label": 0,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66020127033971, 13.47534065714534]),
            {
              "label": 0,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66022272801183, 13.474965051770338]),
            {
              "label": 0,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66173549389623, 13.4733269880989]),
            {
              "label": 0,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66195007061742, 13.473139183903674]),
            {
              "label": 0,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66290493702672, 13.47270097354128]),
            {
              "label": 0,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66308732723974, 13.472554903242047]),
            {
              "label": 0,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67596305906362, 13.472057384293718]),
            {
              "label": 0,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67552317678518, 13.471994782579358]),
            {
              "label": 0,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67593087255544, 13.4719739153376]),
            {
              "label": 0,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67461122572011, 13.471848711848816]),
            {
              "label": 0,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6740318685729, 13.471713074662]),
            {
              "label": 0,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6745361238677, 13.471817410966377]),
            {
              "label": 0,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67470778524465, 13.4717756764501]),
            {
              "label": 0,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64364897720068, 13.507164550527037]),
            {
              "label": 0,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64369189254492, 13.506559488876235]),
            {
              "label": 0,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64420687667578, 13.506413439282298]),
            {
              "label": 0,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64485060683936, 13.506079611303223]),
            {
              "label": 0,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64504372588843, 13.505683189971302]),
            {
              "label": 0,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64530121795386, 13.505683189971302]),
            {
              "label": 0,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6349359279178, 13.513509770306406]),
            {
              "label": 0,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63480718188508, 13.514031360066648]),
            {
              "label": 0,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63463552050813, 13.514636402758839]),
            {
              "label": 0,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63459260516389, 13.514093950761188]),
            {
              "label": 0,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63469989352448, 13.513760133533738]),
            {
              "label": 0,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63500030093415, 13.513405452217425]),
            {
              "label": 0,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6281660323642, 13.51775547778967]),
            {
              "label": 0,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62839133792146, 13.51775547778967]),
            {
              "label": 0,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62854154162629, 13.517703319679917]),
            {
              "label": 0,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62844498210175, 13.517536413651964]),
            {
              "label": 0,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62813384585603, 13.51759900342614]),
            {
              "label": 0,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62767250590547, 13.517724182925182]),
            {
              "label": 0,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62745792918427, 13.51785979397495]),
            {
              "label": 0,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62750084452851, 13.517484255494262]),
            {
              "label": 0,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62791926913484, 13.51742166568996]),
            {
              "label": 0,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6282196765445, 13.517484255494262]),
            {
              "label": 0,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62762959056123, 13.517463392227981]),
            {
              "label": 0,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62727553897126, 13.517682456432807]),
            {
              "label": 0,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62699658923371, 13.518026699776435]),
            {
              "label": 0,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62685711436494, 13.518423100586451]),
            {
              "label": 0,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62673909716828, 13.518819500737123]),
            {
              "label": 0,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62663180880769, 13.519090721512953]),
            {
              "label": 0,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62633140139802, 13.51934107887819]),
            {
              "label": 0,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62612755351289, 13.519466257462174]),
            {
              "label": 0,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62579495959504, 13.519737477501891]),
            {
              "label": 0,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62710387759431, 13.51775547778967]),
            {
              "label": 0,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62739355616792, 13.517463392227981]),
            {
              "label": 0,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62765104823335, 13.51732778095266]),
            {
              "label": 0,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62811238818391, 13.5174112340543]),
            {
              "label": 0,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62320237207618, 13.528335290298735]),
            {
              "label": 0,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62330966043677, 13.528168391719346]),
            {
              "label": 0,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62336330461707, 13.527980630677723]),
            {
              "label": 0,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62348132181373, 13.527657264092367]),
            {
              "label": 0,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62357788133826, 13.527427777862192]),
            {
              "label": 0,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62365298319068, 13.527219153824673]),
            {
              "label": 0,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62366371202674, 13.526958373520785]),
            {
              "label": 0,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6236744408628, 13.526749749072081]),
            {
              "label": 0,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62368516969886, 13.526395087089877]),
            {
              "label": 0,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62365298319068, 13.526113443374841]),
            {
              "label": 0,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62357788133826, 13.52581093679141]),
            {
              "label": 0,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62347059297767, 13.525654467718214]),
            {
              "label": 0,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62295560884681, 13.528804691926098]),
            {
              "label": 0,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62265520143714, 13.529086332458379]),
            {
              "label": 0,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.622268963339, 13.529409697103175]),
            {
              "label": 0,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62163596201148, 13.529743492404926]),
            {
              "label": 0,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62133555460181, 13.52991038988033]),
            {
              "label": 0,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62247281122413, 13.529284523744373]),
            {
              "label": 0,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62191491174903, 13.529628750322736]),
            {
              "label": 0,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62303071069923, 13.528627362531177]),
            {
              "label": 0,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62276248979774, 13.528950727799234]),
            {
              "label": 0,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62314872789588, 13.528199685211895]),
            {
              "label": 0,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62336330461707, 13.527751144759154]),
            {
              "label": 0,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62334184694495, 13.52553972366586]),
            {
              "label": 0,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62337403345313, 13.525289372814312]),
            {
              "label": 0,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62329893160071, 13.52525807893937]),
            {
              "label": 0,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61681395715954, 13.530192029104803]),
            {
              "label": 0,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61683541483166, 13.530348495196664]),
            {
              "label": 0,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61647063440563, 13.530650996016066]),
            {
              "label": 0,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61629897302868, 13.530786599706895]),
            {
              "label": 0,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61594492143871, 13.531016082700052]),
            {
              "label": 0,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61568742937328, 13.531235134441712]),
            {
              "label": 0,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61529046243908, 13.531527203117099]),
            {
              "label": 0,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61490422434093, 13.531694099342175]),
            {
              "label": 0,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61456090158703, 13.531694099342175]),
            {
              "label": 0,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61471110529186, 13.53150634108075]),
            {
              "label": 0,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61495786852123, 13.531349875749779]),
            {
              "label": 0,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61514025873424, 13.531214272379765]),
            {
              "label": 0,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61539775079967, 13.531068237894916]),
            {
              "label": 0,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61635261720897, 13.53051161045084]),
            {
              "label": 0,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61643844789745, 13.530396868738803]),
            {
              "label": 0,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61607366747143, 13.530772386863482]),
            {
              "label": 0,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61592346376659, 13.53087669734856]),
            {
              "label": 0,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6156015986848, 13.531147904395892]),
            {
              "label": 0,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6155479545045, 13.531012300910845]),
            {
              "label": 0,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6156552428651, 13.530814111062995]),
            {
              "label": 0,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61597710794689, 13.530636783164562]),
            {
              "label": 0,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61617022699596, 13.53051161045084]),
            {
              "label": 0,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61648136324169, 13.530355144466164]),
            {
              "label": 0,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61667448229076, 13.530292558043506]),
            {
              "label": 0,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60440069383861, 13.538809375821778]),
            {
              "label": 0,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6043792361665, 13.53872071486732]),
            {
              "label": 0,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6045777196336, 13.538658130644308]),
            {
              "label": 0,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60458308405163, 13.538705068813112]),
            {
              "label": 0,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60484594053509, 13.538548608214386]),
            {
              "label": 0,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60524290746929, 13.538308701763196]),
            {
              "label": 0,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60543066210033, 13.538141810176231]),
            {
              "label": 0,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60559695905926, 13.538042718241094]),
            {
              "label": 0,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60576325601818, 13.537912334053035]),
            {
              "label": 0,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60584372228863, 13.53775587293308]),
            {
              "label": 0,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60568278974773, 13.537891472576309]),
            {
              "label": 0,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60559159464123, 13.53799577994162]),
            {
              "label": 0,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60540920442821, 13.538115733355198]),
            {
              "label": 0,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60525363630535, 13.538230471346395]),
            {
              "label": 0,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60494786447765, 13.538407793587586]),
            {
              "label": 0,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60507124609234, 13.53846516251966]),
            {
              "label": 0,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60510879701854, 13.538360855360121]),
            {
              "label": 0,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60462063497783, 13.538605977112532]),
            {
              "label": 0,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60474938101055, 13.538538177504154]),
            {
              "label": 0,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60466355032207, 13.538694638109735]),
            {
              "label": 0,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60443824476482, 13.538694638109735]),
            {
              "label": 0,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60450261778118, 13.538647699938858]),
            {
              "label": 0,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60463672823192, 13.538532962148855]),
            {
              "label": 0,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60479766077282, 13.538475593233112]),
            {
              "label": 0,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60422366804363, 13.538798945122972]),
            {
              "label": 0,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60527509397747, 13.538178317720881]),
            {
              "label": 0,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60509270376446, 13.538345209282246]),
            {
              "label": 0,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6054789418626, 13.538089656531291]),
            {
              "label": 0,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6058383578706, 13.53764635008788]),
            {
              "label": 0,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59535396974687, 13.542173917018838]),
            {
              "label": 0,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5953968850911, 13.542111333704177]),
            {
              "label": 0,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59552563112382, 13.542137410087273]),
            {
              "label": 0,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59577239435319, 13.542121764257761]),
            {
              "label": 0,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59585822504167, 13.542069611485248]),
            {
              "label": 0,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59591723364, 13.542043535094697]),
            {
              "label": 0,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59571338575486, 13.542126979534375]),
            {
              "label": 0,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5956490127385, 13.542116548981019]),
            {
              "label": 0,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59558463972215, 13.542100903150121]),
            {
              "label": 0,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59544516485337, 13.542111333704177]),
            {
              "label": 0,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59532714765672, 13.542111333704177]),
            {
              "label": 0,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59576702993516, 13.542074826763008]),
            {
              "label": 0,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5959011403859, 13.542027889259003]),
            {
              "label": 0,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59597087782029, 13.54201224342229]),
            {
              "label": 0,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59599233549241, 13.542090472595621]),
            {
              "label": 0,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26744016621008, 13.506308415209144]),
            {
              "label": 0,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26752599689856, 13.506162365461485]),
            {
              "label": 0,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26752599689856, 13.507205575982947]),
            {
              "label": 0,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26761182758703, 13.507643723041404]),
            {
              "label": 0,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26761182758703, 13.508207053791025]),
            {
              "label": 0,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26769765827551, 13.508749519181281]),
            {
              "label": 0,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26786931965246, 13.509291983337683]),
            {
              "label": 0,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2673543355216, 13.505536436958693]),
            {
              "label": 0,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26748308155432, 13.50591199425745]),
            {
              "label": 0,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26013118616744, 13.492448160081743]),
            {
              "label": 0,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26037794939681, 13.492375130978132]),
            {
              "label": 0,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26076418749496, 13.492750708987339]),
            {
              "label": 0,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26118261210128, 13.493053257509589]),
            {
              "label": 0,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26153666369125, 13.493314074893513]),
            {
              "label": 0,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26183707110091, 13.49356445931405]),
            {
              "label": 0,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26209456316634, 13.49368965142586]),
            {
              "label": 0,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26247007242843, 13.493919170127032]),
            {
              "label": 0,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26274902216598, 13.493960900776264]),
            {
              "label": 0,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26286703936263, 13.493908737463583]),
            {
              "label": 0,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26247007242843, 13.493741814786416]),
            {
              "label": 0,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2620516478221, 13.49358532467058]),
            {
              "label": 0,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26157957903548, 13.493261911439527]),
            {
              "label": 0,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26140791765853, 13.493011526701723]),
            {
              "label": 0,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26101095072433, 13.492844603397327]),
            {
              "label": 0,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26095730654403, 13.492782007128103]),
            {
              "label": 0,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26060325495406, 13.492521189163025]),
            {
              "label": 0,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26054961077377, 13.492865468816769]),
            {
              "label": 0,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26016337267562, 13.492354265515857]),
            {
              "label": 0,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26721221796676, 13.49621434500351]),
            {
              "label": 0,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26728731981918, 13.496130884485504]),
            {
              "label": 0,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26702982775375, 13.49588050275643]),
            {
              "label": 0,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.267255133311, 13.49608915421556]),
            {
              "label": 0,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26678306452438, 13.495755311793411]),
            {
              "label": 0,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.266536301295, 13.495703148872778]),
            {
              "label": 0,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26682597986861, 13.495661418528066]),
            {
              "label": 0,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34546786250229, 13.45632978536969]),
            {
              "label": 0,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34526401461716, 13.456580208520602]),
            {
              "label": 0,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34500652255173, 13.456726288571035]),
            {
              "label": 0,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34494214953537, 13.456611511396057]),
            {
              "label": 0,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34502798022385, 13.45651760275742]),
            {
              "label": 0,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34521037043686, 13.456486299869693]),
            {
              "label": 0,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34531765879746, 13.456298482457406]),
            {
              "label": 0,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34531765879746, 13.456288048152395]),
            {
              "label": 0,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34513526858444, 13.45631935106604]),
            {
              "label": 0,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34502798022385, 13.456413259782417]),
            {
              "label": 0,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34584337176437, 13.455954150152264]),
            {
              "label": 0,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34595066012497, 13.455828938282174]),
            {
              "label": 0,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34607940615768, 13.455672423352503]),
            {
              "label": 0,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34597211779709, 13.455661989020216]),
            {
              "label": 0,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34580045642014, 13.455818503956706]),
            {
              "label": 0,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34574681223984, 13.455891544225388]),
            {
              "label": 0,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32722003711001, 13.472572627693058]),
            {
              "label": 0,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32725222361819, 13.47266653003157]),
            {
              "label": 0,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32762773288027, 13.472676963622458]),
            {
              "label": 0,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32775647891299, 13.472583061288056]),
            {
              "label": 0,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32746680033938, 13.472562194097616]),
            {
              "label": 0,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3275955463721, 13.472583061288056]),
            {
              "label": 0,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32728441012637, 13.472510026113579]),
            {
              "label": 0,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32701618922488, 13.472520459711298]),
            {
              "label": 0,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32746680033938, 13.472478725317687]),
            {
              "label": 0,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32769210589663, 13.472478725317687]),
            {
              "label": 0,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32713420642153, 13.472499592515401]),
            {
              "label": 0,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3268767143561, 13.472489158916767]),
            {
              "label": 0,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.40883353263092, 13.628092244279962]),
            {
              "label": 0,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.40898373633576, 13.628060963961767]),
            {
              "label": 0,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4094236186142, 13.627998403312935]),
            {
              "label": 0,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41001370459747, 13.628040110414002]),
            {
              "label": 0,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4104321292038, 13.628029683639426]),
            {
              "label": 0,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.410829096138, 13.628008830088898]),
            {
              "label": 0,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41109731703949, 13.62798797653654]),
            {
              "label": 0,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4109900286789, 13.627904562308656]),
            {
              "label": 0,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41091492682648, 13.62784200161844]),
            {
              "label": 0,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41062524825287, 13.62798797653654]),
            {
              "label": 0,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41006734877777, 13.628008830088898]),
            {
              "label": 0,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.40965965300751, 13.62798797653654]),
            {
              "label": 0,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4098742297287, 13.627998403312935]),
            {
              "label": 0,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.40904810935211, 13.627967122982325]),
            {
              "label": 0,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.40882280379486, 13.627998403312935]),
            {
              "label": 0,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4209692814668, 13.623321825932528]),
            {
              "label": 0,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42058304336865, 13.623353106877904]),
            {
              "label": 0,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42034700897534, 13.623353106877904]),
            {
              "label": 0,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42003587272961, 13.623363533858758]),
            {
              "label": 0,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42045429733594, 13.623207129097418]),
            {
              "label": 0,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42130187538464, 13.623154994153975]),
            {
              "label": 0,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4207010605653, 13.623113286190952]),
            {
              "label": 0,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42084053543408, 13.623050724232598]),
            {
              "label": 0,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42040065315564, 13.623009016251178]),
            {
              "label": 0,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42114094284375, 13.623092432206676]),
            {
              "label": 0,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42236403015454, 13.623154994153975]),
            {
              "label": 0,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42255714920361, 13.623134140173386]),
            {
              "label": 0,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42217091110547, 13.623113286190952]),
            {
              "label": 0,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42149499443371, 13.623134140173386]),
            {
              "label": 0,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42184904602368, 13.623092432206676]),
            {
              "label": 0,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42126968887646, 13.62302987024281]),
            {
              "label": 0,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42094782379468, 13.623009016251178]),
            {
              "label": 0,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42608693626721, 13.62410384832507]),
            {
              "label": 0,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.426408801349, 13.623791039678483]),
            {
              "label": 0,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4257436135133, 13.624197690838344]),
            {
              "label": 0,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44253283827021, 13.621377765931273]),
            {
              "label": 0,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44227534620478, 13.621398620066794]),
            {
              "label": 0,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44246846525385, 13.621263068153064]),
            {
              "label": 0,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44253283827021, 13.621085807840947]),
            {
              "label": 0,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44270449964716, 13.620991964092502]),
            {
              "label": 0,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4438095697613, 13.6210023911775]),
            {
              "label": 0,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44414216367915, 13.620991964092502]),
            {
              "label": 0,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44336968748286, 13.620971109921106]),
            {
              "label": 0,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44295126287653, 13.620971109921106]),
            {
              "label": 0,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4431980261059, 13.6210023911775]),
            {
              "label": 0,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44636303274348, 13.619615584836307]),
            {
              "label": 0,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44621282903864, 13.619719856272544]),
            {
              "label": 0,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44650250761225, 13.619407041825898]),
            {
              "label": 0,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4467814573498, 13.61915678997064]),
            {
              "label": 0,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44709259359553, 13.61895867373076]),
            {
              "label": 0,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44695311872675, 13.61894824655565]),
            {
              "label": 0,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44703894941523, 13.61879183887371]),
            {
              "label": 0,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39754887696843, 13.62385351634529]),
            {
              "label": 0,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39777418252568, 13.623926505047233]),
            {
              "label": 0,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3978492843781, 13.623759673695394]),
            {
              "label": 0,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39766689416508, 13.62366583100826]),
            {
              "label": 0,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39743085977177, 13.62366583100826]),
            {
              "label": 0,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39685150262456, 13.623582415255086]),
            {
              "label": 0,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3957249748383, 13.62366583100826]),
            {
              "label": 0,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39529582139592, 13.623551134340065]),
            {
              "label": 0,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3953816520844, 13.623686684941953]),
            {
              "label": 0,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39558549996953, 13.62363455010427]),
            {
              "label": 0,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39590736505131, 13.623582415255086]),
            {
              "label": 0,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39602538224797, 13.623686684941953]),
            {
              "label": 0,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39626141664128, 13.623655404040726]),
            {
              "label": 0,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39655109521489, 13.623551134340065]),
            {
              "label": 0,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.397291384903, 13.62359284222584]),
            {
              "label": 0,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39703389283757, 13.62361369616597]),
            {
              "label": 0,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39559622880559, 13.62359284222584]),
            {
              "label": 0,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37605475989693, 13.61565364574413]),
            {
              "label": 0,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37596892920845, 13.615789200873014]),
            {
              "label": 0,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37648391333931, 13.616154156603109]),
            {
              "label": 0,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37678432074898, 13.616550393615386]),
            {
              "label": 0,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37709545699471, 13.616904920905833]),
            {
              "label": 0,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37723493186348, 13.617103038866112]),
            {
              "label": 0,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3773100337159, 13.617009193537182]),
            {
              "label": 0,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37704181281441, 13.616675520955061]),
            {
              "label": 0,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3769130667817, 13.616539966334097]),
            {
              "label": 0,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3767521342408, 13.616383557059551]),
            {
              "label": 0,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37637662497872, 13.616039456291476]),
            {
              "label": 0,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37626933661812, 13.615956037848074]),
            {
              "label": 0,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37593674270028, 13.61562236378029]),
            {
              "label": 0,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37584018317574, 13.615716209659416]),
            {
              "label": 0,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37593674270028, 13.615611936458073]),
            {
              "label": 0,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37625860778206, 13.615987319767793]),
            {
              "label": 0,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37662338820809, 13.616362702481794]),
            {
              "label": 0,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37662338820809, 13.616508684487453]),
            {
              "label": 0,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3766984900605, 13.616310566029355]),
            {
              "label": 0,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36587497154389, 13.61088016530863]),
            {
              "label": 0,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36601444641266, 13.611297266180118]),
            {
              "label": 0,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36606809059296, 13.611067860791783]),
            {
              "label": 0,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36607881942902, 13.610817600114506]),
            {
              "label": 0,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36604663292084, 13.610536056536205]),
            {
              "label": 0,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36587497154389, 13.610525628989835]),
            {
              "label": 0,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36583205619965, 13.610692469676614]),
            {
              "label": 0,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36578914085541, 13.610400498397558]),
            {
              "label": 0,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36604663292084, 13.610442208602338]),
            {
              "label": 0,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36396523872529, 13.607751885339667]),
            {
              "label": 0,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36428710380707, 13.60782487901009]),
            {
              "label": 0,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36360045829926, 13.607835306675463]),
            {
              "label": 0,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36314984718476, 13.607762313008244]),
            {
              "label": 0,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36302110115204, 13.607522476514651]),
            {
              "label": 0,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3629245416275, 13.607428627385774]),
            {
              "label": 0,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36330005088959, 13.607678891646735]),
            {
              "label": 0,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36341806808625, 13.607689319318531]),
            {
              "label": 0,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36380430618439, 13.607783168344044]),
            {
              "label": 0,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36335369506989, 13.607605897931286]),
            {
              "label": 0,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36318203369294, 13.607564187226652]),
            {
              "label": 0,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36362191597138, 13.607710174660744]),
            {
              "label": 0,
              "system:index": "374"
            })]),
    latif_abierto = ui.import && ui.import("latif_abierto", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -86.6628625834396,
            13.472371652266666
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66318444852139,
            13.472298617027638
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66337756757046,
            13.472256882595316
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66355995778348,
            13.472194280933179
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66377453450467,
            13.472131679254657
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66404275540616,
            13.472048210324479
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66433243397977,
            13.471985608607728
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66452555302884,
            13.471964741365166
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66136054639126,
            13.473049835564002
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66155366544034,
            13.472914199058383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66009454373624,
            13.475073940430605
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.65985850934293,
            13.475220009191148
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.65969757680203,
            13.475553880308734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.65953664426114,
            13.47595035165535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72488083916433,
            13.461710694764049
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72469844895132,
            13.461554183679477
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72464480477102,
            13.461397672492556
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72450532990224,
            13.461220293023679
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72423710900075,
            13.460949006522899
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7241190918041,
            13.460771626721543
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72405471878774,
            13.460625549139387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72396888809926,
            13.460416866724515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72392597275503,
            13.460208184127728
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72405471878774,
            13.460249920661635
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72415127831228,
            13.46056294443402
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72447314339406,
            13.461084649811712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.724462414558,
            13.460959440624775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72441949921377,
            13.46078206083115
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72433366852529,
            13.460750758500986
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72223081665761,
            13.461251595292447
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72206988411672,
            13.461251595292447
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72240247803457,
            13.461199424842222
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7222093589855,
            13.461199424842222
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72697296219594,
            13.463536649855426
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72683348732717,
            13.463442743933381
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72665109711416,
            13.463234063974685
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72646870690114,
            13.463067119876715
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72620048599966,
            13.462722797306895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7260288246227,
            13.46250368268637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68586888792967,
            13.466332705428162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68589034560179,
            13.466207498986858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68581524374937,
            13.465915350369057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68597617629027,
            13.464517205617097
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68596544745421,
            13.464757186267196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68589034560179,
            13.464851091673468
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6850642252252,
            13.467616067673847
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68499985220885,
            13.468492506227152
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68282189848875,
            13.470474914919091
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68313303473448,
            13.470401879100883
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68325105193114,
            13.47027667478919
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67626657965636,
            13.471633051341628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67597690108275,
            13.471580883154926
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67556920531248,
            13.4714556794604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67516150954222,
            13.471361776646495
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67500057700133,
            13.471361776646495
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67512932303404,
            13.472165166196119
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67551556113219,
            13.472279935911489
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67579451086974,
            13.472572076756611
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.67596617224669,
            13.472582510351621
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66196085319054,
            13.47263658461131
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.66147805556785,
            13.472657451795246
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6617033611251,
            13.472500947871325
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6639349590255,
            13.472010568246484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26192114762945,
            13.49294369809278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26196406297369,
            13.492797640166325
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26295111589117,
            13.493559226944067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26333735398931,
            13.493840909109515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26324079446478,
            13.493747015091282
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2632622521369,
            13.493642688361064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2615349095313,
            13.49266201486892
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26128814630194,
            13.492495091320206
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26098773889227,
            13.492129945650579
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26056931428595,
            13.491785664936403
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26045129708929,
            13.491545711417837
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26060150079412,
            13.491410085409397
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26071951799078,
            13.491316190435356
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26437805108709,
            13.4944460030079
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26479647569342,
            13.494498166203194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26503251008673,
            13.494550329387112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26446388177557,
            13.494393839801194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26390598230047,
            13.4942895133536
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26369140557928,
            13.494185186860422
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26828436972919,
            13.508052228777688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26815562369647,
            13.507749699270038
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26804833533588,
            13.50750976180148
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26788740279498,
            13.50726982409154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26791958930316,
            13.507175935356731
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26821999671283,
            13.50889722295588
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26821999671283,
            13.509105863032836
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26827364089313,
            13.509408390820196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26834874274554,
            13.509637894402905
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2678015721065,
            13.505767599899906
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26784448745074,
            13.506330935080433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26776938559833,
            13.506612602171797
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64641857242584,
            13.505190876309657
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64618790245056,
            13.505383871386057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6460323343277,
            13.505509057298063
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64564073181153,
            13.506124553743236
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64574265575409,
            13.506213226829043
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64320221444534,
            13.507419129855913
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6430520107405,
            13.507632987257812
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64311638375686,
            13.50760690709712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63658788701461,
            13.51258036731615
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63626602193283,
            13.512872458861123
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63602998753952,
            13.51310195910972
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63571885129379,
            13.513446209068368
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63557937642501,
            13.51358703845364
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63543453713821,
            13.51388956055552
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63532724877761,
            13.514040821462501
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6351985027449,
            13.51415557105206
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63525751134323,
            13.514051253245661
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63608363171981,
            13.513060231808215
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63588514825271,
            13.513211493241386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63574030896591,
            13.513331459137381
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63611581822799,
            13.512929833943986
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62798179617867,
            13.518185028553784
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62815345755563,
            13.518174596951546
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62769211760506,
            13.518518839584292
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62788523665414,
            13.51859186068489
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6274453543757,
            13.518633587018046
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62836803427682,
            13.518263265556012
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62867380610452,
            13.51824240235792
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62896348467812,
            13.51823718655812
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62752582064614,
            13.518471897436374
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62741316786752,
            13.51855535013739
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62801398268685,
            13.518372797315974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62790669432626,
            13.51839887629902
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62756337157235,
            13.518680529134107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62745071879372,
            13.518852650147222
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62719054451928,
            13.519113439324183
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6287247680758,
            13.518370189417519
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62844581833825,
            13.518396268400844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62331817032339,
            13.525898925301815
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62331817032339,
            13.526316175507038
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62331817032339,
            13.526514369098452
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62287828804494,
            13.528193792384466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62274954201223,
            13.52842327787647
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62302849174978,
            13.526952480662658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62286755920888,
            13.527328004219076
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.62318942429067,
            13.52753662816123
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61681636702205,
            13.53087483653572
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6165910614648,
            13.53110431944383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6161404503503,
            13.5297587119651
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61596878897335,
            13.530092506777592
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61508902441646,
            13.530488887509645
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61489590536739,
            13.530645353406422
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61439165007259,
            13.531146043585176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61359771620418,
            13.53108345737041
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61310418974544,
            13.531615439671455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61390885244991,
            13.531166905653102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61390885244991,
            13.531417250325688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6146276844659,
            13.532230868693539
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61438092123653,
            13.532429057361975
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61409124266292,
            13.532575091012095
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61419853102352,
            13.532429057361975
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6143380058923,
            13.532335178539604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61441310774471,
            13.532335178539604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6155289066949,
            13.53212655880176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6156361950555,
            13.532376902465233
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61580785643245,
            13.532575091012095
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61658033262874,
            13.531594577642828
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61692365538265,
            13.531521560528242
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61708458792354,
            13.531312940077433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.61708458792354,
            13.531208629783482
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60494787848857,
            13.538811262325295
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60501761592296,
            13.538967722751304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60509808219341,
            13.538806046975989
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60524828589824,
            13.53870173996587
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60543604052928,
            13.538566140784352
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60562915957836,
            13.53842532616791
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60595638907817,
            13.538195850318136
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60614414370922,
            13.537976804982357
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60624070323375,
            13.538268865385248
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60624070323375,
            13.53836274186719
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60592956698802,
            13.538696524614155
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60597248233226,
            13.538623509678274
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60579009211925,
            13.538414895452268
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60579009211925,
            13.538602648263904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60552187121776,
            13.538592217556037
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60521073497203,
            13.53868609391041
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59646654049362,
            13.542146797978509
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59665429512467,
            13.542105075765813
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59682059208359,
            13.542021631318462
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5969117871901,
            13.542094645211504
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59693324486221,
            13.541974693803963
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59702443996872,
            13.541974693803963
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59587645451035,
            13.542355408932243
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59601056496109,
            13.542423207452822
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5961017600676,
            13.542496221222597
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44311527665283,
            13.62164809768988
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44348005707886,
            13.621616816518912
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44231061394837,
            13.621877492817099
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44203166421082,
            13.621929628042261
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44182781632568,
            13.621887919863065
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44172052796509,
            13.621731514125537
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44718150551941,
            13.618311416133576
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44778232033875,
            13.618165435240575
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.44749264176514,
            13.61833227053952
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42615567050944,
            13.624514216708052
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42597328029643,
            13.624597632132431
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42644534908305,
            13.624462082052869
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42686377368938,
            13.623972015732116
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42711053691875,
            13.623638352974957
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41999731861125,
            13.623836465293824
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4202762683488,
            13.623857319212455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42041574321757,
            13.624024150495377
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42105947338115,
            13.62396158877808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42120967708598,
            13.624128419987416
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42193923793803,
            13.622668642913895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42206798397075,
            13.622731204973354
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42293701969157,
            13.622731204973354
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42301212154399,
            13.622647788890408
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4231408675767,
            13.622543518745324
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41161809764873,
            13.628184467532824
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4114678939439,
            13.628267881661893
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41124258838664,
            13.628267881661893
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41084562145244,
            13.628309588715389
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41063104473125,
            13.628424283074551
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.40967617832194,
            13.628830926263024
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.40922556720744,
            13.628768365818042
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.40900026165019,
            13.628768365818042
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.40871058307658,
            13.628799646042602
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4104593833543,
            13.627246056552023
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41053448520671,
            13.627047947090837
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41171465717326,
            13.628142760457239
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41195069156657,
            13.628080199830073
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41142497859965,
            13.628174040764607
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.41101728282939,
            13.628340869000684
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39636169277202,
            13.623012734036012
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39649043880473,
            13.623200419891536
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39667282901775,
            13.62326298181025
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39675865970622,
            13.623179565914942
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39709125362407,
            13.623252554824955
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39720927082072,
            13.62326298181025
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39731655918132,
            13.623252554824955
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39798174701701,
            13.623200419891536
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39818559490215,
            13.62331511672989
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3981963237382,
            13.623429813512596
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39828215442668,
            13.62337767861826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3983572562791,
            13.623388105598059
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3978530009843,
            13.624493362847359
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39773498378764,
            13.624576778279092
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39526735149394,
            13.62414927388031
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3953317245103,
            13.624441228187568
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39551411472331,
            13.6245246436377
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39446268878947,
            13.623117003974144
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39449487529765,
            13.623294262763423
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.39455924831401,
            13.622971026047875
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37787546357566,
            13.616052503654846
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37776817521507,
            13.616198485851962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37745703896934,
            13.6159378032939
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37833680352622,
            13.616469595407573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37821878632957,
            13.616594722789968
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.375955001921,
            13.615051480447686
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37581552705223,
            13.614988916356591
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.37605156144554,
            13.614988916356591
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36539782723838,
            13.61138102578296
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36576260766441,
            13.611777270789597
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36565531930381,
            13.611485300849035
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36529053887779,
            13.611401880799862
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36271561822349,
            13.606813732809455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36303748330528,
            13.606813732809455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36357392510826,
            13.607126563906967
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3638528748458,
            13.607230840847599
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3638528748458,
            13.60704314232138
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36346663674766,
            13.60687629906203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36331643304283,
            13.606772021965218
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36271561822349,
            13.60660517851477
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36265124520713,
            13.606438334946699
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36376704415733,
            13.606855443646337
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34641497853073,
            13.455746095170504
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34628623249802,
            13.455913044373814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34608238461288,
            13.456184336580968
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34583562138351,
            13.456372154082795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34600728276047,
            13.455234812511305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34566396000656,
            13.455579145850786
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34548156979355,
            13.455798266809026
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34527772190842,
            13.455913044373814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34548156979355,
            13.455714792181915
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.34578197720322,
            13.455443499442818
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3457605195311,
            13.455464368125966
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32705719494176,
            13.472867585823277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32720739864659,
            13.472867585823277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3274434330399,
            13.47281541790584
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32773311161351,
            13.47281541790584
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32787258648229,
            13.472804984320986
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32809789203954,
            13.472794550735681
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32763655208898,
            13.473065823805706
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32763655208898,
            13.472919753729304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32731468700719,
            13.472919753729304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32720739864659,
            13.472982355201546
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32720739864659,
            13.473170159519936
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32701427959752,
            13.47320146022532
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32712156795812,
            13.472919753729304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32725031399083,
            13.4728571522407
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32757217907262,
            13.472763249977042
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.32743270420384,
            13.473253628058538
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "label": 1
      },
      "color": "#78d6a6",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #78d6a6 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-86.6628625834396, 13.472371652266666]),
            {
              "label": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66318444852139, 13.472298617027638]),
            {
              "label": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66337756757046, 13.472256882595316]),
            {
              "label": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66355995778348, 13.472194280933179]),
            {
              "label": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66377453450467, 13.472131679254657]),
            {
              "label": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66404275540616, 13.472048210324479]),
            {
              "label": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66433243397977, 13.471985608607728]),
            {
              "label": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66452555302884, 13.471964741365166]),
            {
              "label": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66136054639126, 13.473049835564002]),
            {
              "label": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66155366544034, 13.472914199058383]),
            {
              "label": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66009454373624, 13.475073940430605]),
            {
              "label": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.65985850934293, 13.475220009191148]),
            {
              "label": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.65969757680203, 13.475553880308734]),
            {
              "label": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.65953664426114, 13.47595035165535]),
            {
              "label": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72488083916433, 13.461710694764049]),
            {
              "label": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72469844895132, 13.461554183679477]),
            {
              "label": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72464480477102, 13.461397672492556]),
            {
              "label": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72450532990224, 13.461220293023679]),
            {
              "label": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72423710900075, 13.460949006522899]),
            {
              "label": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7241190918041, 13.460771626721543]),
            {
              "label": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72405471878774, 13.460625549139387]),
            {
              "label": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72396888809926, 13.460416866724515]),
            {
              "label": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72392597275503, 13.460208184127728]),
            {
              "label": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72405471878774, 13.460249920661635]),
            {
              "label": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72415127831228, 13.46056294443402]),
            {
              "label": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72447314339406, 13.461084649811712]),
            {
              "label": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.724462414558, 13.460959440624775]),
            {
              "label": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72441949921377, 13.46078206083115]),
            {
              "label": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72433366852529, 13.460750758500986]),
            {
              "label": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72223081665761, 13.461251595292447]),
            {
              "label": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72206988411672, 13.461251595292447]),
            {
              "label": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72240247803457, 13.461199424842222]),
            {
              "label": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7222093589855, 13.461199424842222]),
            {
              "label": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72697296219594, 13.463536649855426]),
            {
              "label": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72683348732717, 13.463442743933381]),
            {
              "label": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72665109711416, 13.463234063974685]),
            {
              "label": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72646870690114, 13.463067119876715]),
            {
              "label": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72620048599966, 13.462722797306895]),
            {
              "label": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7260288246227, 13.46250368268637]),
            {
              "label": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68586888792967, 13.466332705428162]),
            {
              "label": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68589034560179, 13.466207498986858]),
            {
              "label": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68581524374937, 13.465915350369057]),
            {
              "label": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68597617629027, 13.464517205617097]),
            {
              "label": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68596544745421, 13.464757186267196]),
            {
              "label": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68589034560179, 13.464851091673468]),
            {
              "label": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6850642252252, 13.467616067673847]),
            {
              "label": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68499985220885, 13.468492506227152]),
            {
              "label": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68282189848875, 13.470474914919091]),
            {
              "label": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68313303473448, 13.470401879100883]),
            {
              "label": 1,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68325105193114, 13.47027667478919]),
            {
              "label": 1,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67626657965636, 13.471633051341628]),
            {
              "label": 1,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67597690108275, 13.471580883154926]),
            {
              "label": 1,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67556920531248, 13.4714556794604]),
            {
              "label": 1,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67516150954222, 13.471361776646495]),
            {
              "label": 1,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67500057700133, 13.471361776646495]),
            {
              "label": 1,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67512932303404, 13.472165166196119]),
            {
              "label": 1,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67551556113219, 13.472279935911489]),
            {
              "label": 1,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67579451086974, 13.472572076756611]),
            {
              "label": 1,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.67596617224669, 13.472582510351621]),
            {
              "label": 1,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66196085319054, 13.47263658461131]),
            {
              "label": 1,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.66147805556785, 13.472657451795246]),
            {
              "label": 1,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6617033611251, 13.472500947871325]),
            {
              "label": 1,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6639349590255, 13.472010568246484]),
            {
              "label": 1,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26192114762945, 13.49294369809278]),
            {
              "label": 1,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26196406297369, 13.492797640166325]),
            {
              "label": 1,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26295111589117, 13.493559226944067]),
            {
              "label": 1,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26333735398931, 13.493840909109515]),
            {
              "label": 1,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26324079446478, 13.493747015091282]),
            {
              "label": 1,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2632622521369, 13.493642688361064]),
            {
              "label": 1,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2615349095313, 13.49266201486892]),
            {
              "label": 1,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26128814630194, 13.492495091320206]),
            {
              "label": 1,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26098773889227, 13.492129945650579]),
            {
              "label": 1,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26056931428595, 13.491785664936403]),
            {
              "label": 1,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26045129708929, 13.491545711417837]),
            {
              "label": 1,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26060150079412, 13.491410085409397]),
            {
              "label": 1,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26071951799078, 13.491316190435356]),
            {
              "label": 1,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26437805108709, 13.4944460030079]),
            {
              "label": 1,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26479647569342, 13.494498166203194]),
            {
              "label": 1,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26503251008673, 13.494550329387112]),
            {
              "label": 1,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26446388177557, 13.494393839801194]),
            {
              "label": 1,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26390598230047, 13.4942895133536]),
            {
              "label": 1,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26369140557928, 13.494185186860422]),
            {
              "label": 1,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26828436972919, 13.508052228777688]),
            {
              "label": 1,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26815562369647, 13.507749699270038]),
            {
              "label": 1,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26804833533588, 13.50750976180148]),
            {
              "label": 1,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26788740279498, 13.50726982409154]),
            {
              "label": 1,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26791958930316, 13.507175935356731]),
            {
              "label": 1,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26821999671283, 13.50889722295588]),
            {
              "label": 1,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26821999671283, 13.509105863032836]),
            {
              "label": 1,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26827364089313, 13.509408390820196]),
            {
              "label": 1,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26834874274554, 13.509637894402905]),
            {
              "label": 1,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2678015721065, 13.505767599899906]),
            {
              "label": 1,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26784448745074, 13.506330935080433]),
            {
              "label": 1,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26776938559833, 13.506612602171797]),
            {
              "label": 1,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64641857242584, 13.505190876309657]),
            {
              "label": 1,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64618790245056, 13.505383871386057]),
            {
              "label": 1,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6460323343277, 13.505509057298063]),
            {
              "label": 1,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64564073181153, 13.506124553743236]),
            {
              "label": 1,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64574265575409, 13.506213226829043]),
            {
              "label": 1,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64320221444534, 13.507419129855913]),
            {
              "label": 1,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6430520107405, 13.507632987257812]),
            {
              "label": 1,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64311638375686, 13.50760690709712]),
            {
              "label": 1,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63658788701461, 13.51258036731615]),
            {
              "label": 1,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63626602193283, 13.512872458861123]),
            {
              "label": 1,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63602998753952, 13.51310195910972]),
            {
              "label": 1,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63571885129379, 13.513446209068368]),
            {
              "label": 1,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63557937642501, 13.51358703845364]),
            {
              "label": 1,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63543453713821, 13.51388956055552]),
            {
              "label": 1,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63532724877761, 13.514040821462501]),
            {
              "label": 1,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6351985027449, 13.51415557105206]),
            {
              "label": 1,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63525751134323, 13.514051253245661]),
            {
              "label": 1,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63608363171981, 13.513060231808215]),
            {
              "label": 1,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63588514825271, 13.513211493241386]),
            {
              "label": 1,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63574030896591, 13.513331459137381]),
            {
              "label": 1,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63611581822799, 13.512929833943986]),
            {
              "label": 1,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62798179617867, 13.518185028553784]),
            {
              "label": 1,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62815345755563, 13.518174596951546]),
            {
              "label": 1,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62769211760506, 13.518518839584292]),
            {
              "label": 1,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62788523665414, 13.51859186068489]),
            {
              "label": 1,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6274453543757, 13.518633587018046]),
            {
              "label": 1,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62836803427682, 13.518263265556012]),
            {
              "label": 1,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62867380610452, 13.51824240235792]),
            {
              "label": 1,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62896348467812, 13.51823718655812]),
            {
              "label": 1,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62752582064614, 13.518471897436374]),
            {
              "label": 1,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62741316786752, 13.51855535013739]),
            {
              "label": 1,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62801398268685, 13.518372797315974]),
            {
              "label": 1,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62790669432626, 13.51839887629902]),
            {
              "label": 1,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62756337157235, 13.518680529134107]),
            {
              "label": 1,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62745071879372, 13.518852650147222]),
            {
              "label": 1,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62719054451928, 13.519113439324183]),
            {
              "label": 1,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6287247680758, 13.518370189417519]),
            {
              "label": 1,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62844581833825, 13.518396268400844]),
            {
              "label": 1,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62331817032339, 13.525898925301815]),
            {
              "label": 1,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62331817032339, 13.526316175507038]),
            {
              "label": 1,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62331817032339, 13.526514369098452]),
            {
              "label": 1,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62287828804494, 13.528193792384466]),
            {
              "label": 1,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62274954201223, 13.52842327787647]),
            {
              "label": 1,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62302849174978, 13.526952480662658]),
            {
              "label": 1,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62286755920888, 13.527328004219076]),
            {
              "label": 1,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.62318942429067, 13.52753662816123]),
            {
              "label": 1,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61681636702205, 13.53087483653572]),
            {
              "label": 1,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6165910614648, 13.53110431944383]),
            {
              "label": 1,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6161404503503, 13.5297587119651]),
            {
              "label": 1,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61596878897335, 13.530092506777592]),
            {
              "label": 1,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61508902441646, 13.530488887509645]),
            {
              "label": 1,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61489590536739, 13.530645353406422]),
            {
              "label": 1,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61439165007259, 13.531146043585176]),
            {
              "label": 1,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61359771620418, 13.53108345737041]),
            {
              "label": 1,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61310418974544, 13.531615439671455]),
            {
              "label": 1,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61390885244991, 13.531166905653102]),
            {
              "label": 1,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61390885244991, 13.531417250325688]),
            {
              "label": 1,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6146276844659, 13.532230868693539]),
            {
              "label": 1,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61438092123653, 13.532429057361975]),
            {
              "label": 1,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61409124266292, 13.532575091012095]),
            {
              "label": 1,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61419853102352, 13.532429057361975]),
            {
              "label": 1,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6143380058923, 13.532335178539604]),
            {
              "label": 1,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61441310774471, 13.532335178539604]),
            {
              "label": 1,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6155289066949, 13.53212655880176]),
            {
              "label": 1,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6156361950555, 13.532376902465233]),
            {
              "label": 1,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61580785643245, 13.532575091012095]),
            {
              "label": 1,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61658033262874, 13.531594577642828]),
            {
              "label": 1,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61692365538265, 13.531521560528242]),
            {
              "label": 1,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61708458792354, 13.531312940077433]),
            {
              "label": 1,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.61708458792354, 13.531208629783482]),
            {
              "label": 1,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60494787848857, 13.538811262325295]),
            {
              "label": 1,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60501761592296, 13.538967722751304]),
            {
              "label": 1,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60509808219341, 13.538806046975989]),
            {
              "label": 1,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60524828589824, 13.53870173996587]),
            {
              "label": 1,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60543604052928, 13.538566140784352]),
            {
              "label": 1,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60562915957836, 13.53842532616791]),
            {
              "label": 1,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60595638907817, 13.538195850318136]),
            {
              "label": 1,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60614414370922, 13.537976804982357]),
            {
              "label": 1,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60624070323375, 13.538268865385248]),
            {
              "label": 1,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60624070323375, 13.53836274186719]),
            {
              "label": 1,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60592956698802, 13.538696524614155]),
            {
              "label": 1,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60597248233226, 13.538623509678274]),
            {
              "label": 1,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60579009211925, 13.538414895452268]),
            {
              "label": 1,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60579009211925, 13.538602648263904]),
            {
              "label": 1,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60552187121776, 13.538592217556037]),
            {
              "label": 1,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60521073497203, 13.53868609391041]),
            {
              "label": 1,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59646654049362, 13.542146797978509]),
            {
              "label": 1,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59665429512467, 13.542105075765813]),
            {
              "label": 1,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59682059208359, 13.542021631318462]),
            {
              "label": 1,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5969117871901, 13.542094645211504]),
            {
              "label": 1,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59693324486221, 13.541974693803963]),
            {
              "label": 1,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59702443996872, 13.541974693803963]),
            {
              "label": 1,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59587645451035, 13.542355408932243]),
            {
              "label": 1,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59601056496109, 13.542423207452822]),
            {
              "label": 1,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5961017600676, 13.542496221222597]),
            {
              "label": 1,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44311527665283, 13.62164809768988]),
            {
              "label": 1,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44348005707886, 13.621616816518912]),
            {
              "label": 1,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44231061394837, 13.621877492817099]),
            {
              "label": 1,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44203166421082, 13.621929628042261]),
            {
              "label": 1,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44182781632568, 13.621887919863065]),
            {
              "label": 1,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44172052796509, 13.621731514125537]),
            {
              "label": 1,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44718150551941, 13.618311416133576]),
            {
              "label": 1,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44778232033875, 13.618165435240575]),
            {
              "label": 1,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.44749264176514, 13.61833227053952]),
            {
              "label": 1,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42615567050944, 13.624514216708052]),
            {
              "label": 1,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42597328029643, 13.624597632132431]),
            {
              "label": 1,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42644534908305, 13.624462082052869]),
            {
              "label": 1,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42686377368938, 13.623972015732116]),
            {
              "label": 1,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42711053691875, 13.623638352974957]),
            {
              "label": 1,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41999731861125, 13.623836465293824]),
            {
              "label": 1,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4202762683488, 13.623857319212455]),
            {
              "label": 1,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42041574321757, 13.624024150495377]),
            {
              "label": 1,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42105947338115, 13.62396158877808]),
            {
              "label": 1,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42120967708598, 13.624128419987416]),
            {
              "label": 1,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42193923793803, 13.622668642913895]),
            {
              "label": 1,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42206798397075, 13.622731204973354]),
            {
              "label": 1,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42293701969157, 13.622731204973354]),
            {
              "label": 1,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42301212154399, 13.622647788890408]),
            {
              "label": 1,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4231408675767, 13.622543518745324]),
            {
              "label": 1,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41161809764873, 13.628184467532824]),
            {
              "label": 1,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4114678939439, 13.628267881661893]),
            {
              "label": 1,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41124258838664, 13.628267881661893]),
            {
              "label": 1,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41084562145244, 13.628309588715389]),
            {
              "label": 1,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41063104473125, 13.628424283074551]),
            {
              "label": 1,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.40967617832194, 13.628830926263024]),
            {
              "label": 1,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.40922556720744, 13.628768365818042]),
            {
              "label": 1,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.40900026165019, 13.628768365818042]),
            {
              "label": 1,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.40871058307658, 13.628799646042602]),
            {
              "label": 1,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4104593833543, 13.627246056552023]),
            {
              "label": 1,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41053448520671, 13.627047947090837]),
            {
              "label": 1,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41171465717326, 13.628142760457239]),
            {
              "label": 1,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41195069156657, 13.628080199830073]),
            {
              "label": 1,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41142497859965, 13.628174040764607]),
            {
              "label": 1,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.41101728282939, 13.628340869000684]),
            {
              "label": 1,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39636169277202, 13.623012734036012]),
            {
              "label": 1,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39649043880473, 13.623200419891536]),
            {
              "label": 1,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39667282901775, 13.62326298181025]),
            {
              "label": 1,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39675865970622, 13.623179565914942]),
            {
              "label": 1,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39709125362407, 13.623252554824955]),
            {
              "label": 1,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39720927082072, 13.62326298181025]),
            {
              "label": 1,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39731655918132, 13.623252554824955]),
            {
              "label": 1,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39798174701701, 13.623200419891536]),
            {
              "label": 1,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39818559490215, 13.62331511672989]),
            {
              "label": 1,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3981963237382, 13.623429813512596]),
            {
              "label": 1,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39828215442668, 13.62337767861826]),
            {
              "label": 1,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3983572562791, 13.623388105598059]),
            {
              "label": 1,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3978530009843, 13.624493362847359]),
            {
              "label": 1,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39773498378764, 13.624576778279092]),
            {
              "label": 1,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39526735149394, 13.62414927388031]),
            {
              "label": 1,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3953317245103, 13.624441228187568]),
            {
              "label": 1,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39551411472331, 13.6245246436377]),
            {
              "label": 1,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39446268878947, 13.623117003974144]),
            {
              "label": 1,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39449487529765, 13.623294262763423]),
            {
              "label": 1,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.39455924831401, 13.622971026047875]),
            {
              "label": 1,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37787546357566, 13.616052503654846]),
            {
              "label": 1,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37776817521507, 13.616198485851962]),
            {
              "label": 1,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37745703896934, 13.6159378032939]),
            {
              "label": 1,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37833680352622, 13.616469595407573]),
            {
              "label": 1,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37821878632957, 13.616594722789968]),
            {
              "label": 1,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.375955001921, 13.615051480447686]),
            {
              "label": 1,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37581552705223, 13.614988916356591]),
            {
              "label": 1,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.37605156144554, 13.614988916356591]),
            {
              "label": 1,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36539782723838, 13.61138102578296]),
            {
              "label": 1,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36576260766441, 13.611777270789597]),
            {
              "label": 1,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36565531930381, 13.611485300849035]),
            {
              "label": 1,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36529053887779, 13.611401880799862]),
            {
              "label": 1,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36271561822349, 13.606813732809455]),
            {
              "label": 1,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36303748330528, 13.606813732809455]),
            {
              "label": 1,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36357392510826, 13.607126563906967]),
            {
              "label": 1,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3638528748458, 13.607230840847599]),
            {
              "label": 1,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3638528748458, 13.60704314232138]),
            {
              "label": 1,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36346663674766, 13.60687629906203]),
            {
              "label": 1,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36331643304283, 13.606772021965218]),
            {
              "label": 1,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36271561822349, 13.60660517851477]),
            {
              "label": 1,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36265124520713, 13.606438334946699]),
            {
              "label": 1,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36376704415733, 13.606855443646337]),
            {
              "label": 1,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34641497853073, 13.455746095170504]),
            {
              "label": 1,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34628623249802, 13.455913044373814]),
            {
              "label": 1,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34608238461288, 13.456184336580968]),
            {
              "label": 1,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34583562138351, 13.456372154082795]),
            {
              "label": 1,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34600728276047, 13.455234812511305]),
            {
              "label": 1,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34566396000656, 13.455579145850786]),
            {
              "label": 1,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34548156979355, 13.455798266809026]),
            {
              "label": 1,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34527772190842, 13.455913044373814]),
            {
              "label": 1,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34548156979355, 13.455714792181915]),
            {
              "label": 1,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.34578197720322, 13.455443499442818]),
            {
              "label": 1,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3457605195311, 13.455464368125966]),
            {
              "label": 1,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32705719494176, 13.472867585823277]),
            {
              "label": 1,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32720739864659, 13.472867585823277]),
            {
              "label": 1,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3274434330399, 13.47281541790584]),
            {
              "label": 1,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32773311161351, 13.47281541790584]),
            {
              "label": 1,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32787258648229, 13.472804984320986]),
            {
              "label": 1,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32809789203954, 13.472794550735681]),
            {
              "label": 1,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32763655208898, 13.473065823805706]),
            {
              "label": 1,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32763655208898, 13.472919753729304]),
            {
              "label": 1,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32731468700719, 13.472919753729304]),
            {
              "label": 1,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32720739864659, 13.472982355201546]),
            {
              "label": 1,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32720739864659, 13.473170159519936]),
            {
              "label": 1,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32701427959752, 13.47320146022532]),
            {
              "label": 1,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32712156795812, 13.472919753729304]),
            {
              "label": 1,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32725031399083, 13.4728571522407]),
            {
              "label": 1,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32757217907262, 13.472763249977042]),
            {
              "label": 1,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.32743270420384, 13.473253628058538]),
            {
              "label": 1,
              "system:index": "296"
            })]),
    lat_cerrado = ui.import && ui.import("lat_cerrado", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -86.73554938160366,
            13.39676282734147
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73563521229214,
            13.396627147689237
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73572104298061,
            13.396627147689237
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73584978901333,
            13.396919380691262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73586051784939,
            13.396700205973024
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73568885647244,
            13.396543652480592
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73476617657131,
            13.399194611207637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73444431148953,
            13.3992781054961
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73441212498135,
            13.399372036535977
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73471253239101,
            13.39958077204881
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7349807532925,
            13.399664266203203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73523824535793,
            13.399664266203203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73554938160366,
            13.39974776032863
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73567812763638,
            13.39964339266733
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73537772022671,
            13.399622519129627
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73515241466946,
            13.39954946173343
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73504512630886,
            13.399403346874449
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73489492260403,
            13.399205047995286
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7366544517178,
            13.398839760158316
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73690121494717,
            13.39869364486819
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73713724934048,
            13.398516219039434
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73729818188137,
            13.398557966305031
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73681538425869,
            13.398568403120299
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73681538425869,
            13.398359666728895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73645060383267,
            13.398777139330564
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73748057209438,
            13.398484908585473
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73726599537319,
            13.398443161307194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73104327045864,
            13.402022964089008
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73152606808132,
            13.40231519053497
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73180501781887,
            13.40231519053497
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73369329296536,
            13.40200209075785
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73359673344082,
            13.401678553893229
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73360746227688,
            13.401407200058198
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72713797413296,
            13.403244050808276
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72703068577236,
            13.403327543690766
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72691266857571,
            13.40321274096985
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72762077175564,
            13.403191867741985
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72857563816494,
            13.402722219635717
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.731107643475,
            13.408305754403305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73108618580288,
            13.408764955229222
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7315582545895,
            13.408911064398929
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73157971226162,
            13.40855622768985
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73132222019619,
            13.408201390456881
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.730206421246,
            13.408806700715347
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73048537098354,
            13.409349391375118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.73016350590176,
            13.409495500189518
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72669891775647,
            13.424957109587654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72655944288769,
            13.425040594924342
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72694568098584,
            13.425197129852373
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72725681723156,
            13.425311922068044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72752503813305,
            13.425291050760187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72766451300183,
            13.425144951554369
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72756795347729,
            13.42509277324503
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72756795347729,
            13.424957109587654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72752503813305,
            13.424811010178571
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7274070209364,
            13.424737960440693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72726754606762,
            13.424591860898232
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72731046141186,
            13.42524930813903
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72705296934643,
            13.425165822874936
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72693495214978,
            13.425009287926482
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72697786749401,
            13.42134634099318
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72694568098584,
            13.421586364867945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72693495214978,
            13.421847260111848
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72714952887097,
            13.421930746530027
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72734264792004,
            13.422014232919162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72726754606762,
            13.42248384331718
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72741774977246,
            13.422619508372259
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72154907644787,
            13.424827921466914
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7214096015791,
            13.425005327868151
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72158126295605,
            13.425255783740791
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72179583967724,
            13.425360140277274
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72197822989025,
            13.42539144722937
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72176365316906,
            13.425151427158955
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.7219138568739,
            13.42522447677101
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72177438200512,
            13.424900971177427
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72163490713635,
            13.42468182197921
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72136668623486,
            13.424942713859155
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72192458570996,
            13.426414138752383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72224645079174,
            13.426560237185658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72245029867688,
            13.426654157560092
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72234301031628,
            13.427280292450387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72234301031628,
            13.427582923728444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72263268888989,
            13.427468132598934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72306184233227,
            13.427040274268853
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72290090979138,
            13.426768949078928
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72275070608654,
            13.427102887730655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.72253612936535,
            13.427301163585259
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68335079876387,
            13.395925643684027
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68320059505903,
            13.396249188287255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6830503913542,
            13.396144819107942
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68307184902632,
            13.39601957603301
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68326496807539,
            13.39587345902985
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68330788341963,
            13.395612535589184
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68332934109175,
            13.3963326835981
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68372630802595,
            13.398440930592624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68352246014082,
            13.398931460659368
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6833937141081,
            13.39900451824328
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68298601833784,
            13.399161070134102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68308257786238,
            13.399213254075061
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68326496807539,
            13.39910888618181
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68356537548506,
            13.398900150259463
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6843363449997,
            13.4249769883901
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6838857338852,
            13.424956117053112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68367115716401,
            13.425164830341243
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68382136086885,
            13.425310929534975
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68397156457368,
            13.425404850398262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68414322595063,
            13.425404850398262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68421832780305,
            13.425352672145422
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6839930222458,
            13.425300493881233
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68416468362275,
            13.425133523359607
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68402520875398,
            13.425081345047774
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.68414322595063,
            13.424987424057903
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64138208994959,
            13.41042142117773
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64159666667078,
            13.410525784160102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64175759921167,
            13.41098498074409
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64170395503137,
            13.4111102160238
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64150010714624,
            13.410400548575808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.64148937831018,
            13.410233567695231
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63447579751156,
            13.419781830413443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63434168706081,
            13.419750522729831
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63427194962642,
            13.419677471452221
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63419148335598,
            13.41962007400422
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63412174592159,
            13.419505279067078
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63393935570858,
            13.419343522471591
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6339608133807,
            13.41930177881636
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63398763547085,
            13.419129586161809
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63408419499538,
            13.419072188582861
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63459917912624,
            13.419802702200226
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63465818772457,
            13.419912279051168
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63469573865078,
            13.420058381441295
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63489958653591,
            13.420063599382159
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63499078164241,
            13.42000620202647
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63484594235561,
            13.420027073793763
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63454553494594,
            13.419974894372121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63474938283107,
            13.419985330257346
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6347011030688,
            13.419839227822768
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63472792515896,
            13.419740086834391
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.63479766259334,
            13.419547022686931
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59706407739483,
            13.404770881440795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59684950067364,
            13.404843937250634
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59676366998517,
            13.404739571801205
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59653836442791,
            13.40464564285799
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59633451654278,
            13.404593460095898
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59633451654278,
            13.404447348301801
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59644180490338,
            13.404436911741675
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59665638162457,
            13.404530840766443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59673148347699,
            13.404603896649228
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60264307214581,
            13.40090932846774
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60239630891644,
            13.400836271462433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60212808801495,
            13.400846708178838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60176330758893,
            13.400930201893742
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60185986711346,
            13.400742340994432
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60237485124432,
            13.400606663586997
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60258942796551,
            13.400585790132913
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60273963167035,
            13.400617100313362
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.59977806989369,
            13.401202144342403
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5995634931725,
            13.401442188339837
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60019649450001,
            13.401536118534487
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60058273259816,
            13.401149960832983
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60038961354908,
            13.401056030487508
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60015357915577,
            13.401233454442611
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60020722333607,
            13.400941226682102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.60020722333607,
            13.400795112668689
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.6001213926476,
            13.400482010912436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56919762649142,
            13.510908235419723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56924054183565,
            13.511680196282667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56928345717989,
            13.511993152677277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5696267799338,
            13.512243517497215
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57031342544161,
            13.512681655299518
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56887576140963,
            13.51270251898431
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56855389632784,
            13.512285244941642
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5686182693442,
            13.511909697678883
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56866118468844,
            13.511680196282667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56958386458956,
            13.511721923825679
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56969115295016,
            13.512994610379632
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56992718734347,
            13.513224110510636
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56992718734347,
            13.512952883059347
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57016322173678,
            13.512598200542094
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57016322173678,
            13.512368699808604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56990572967135,
            13.51226438122035
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56971261062228,
            13.511805378889797
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56887576140963,
            13.51178451512651
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56878993072115,
            13.511513286037577
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5687255577048,
            13.511388103277094
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56840369262301,
            13.511680196282667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57956168212496,
            13.467111016021576
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57956168212496,
            13.467382295537172
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57939002074801,
            13.467862250849695
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57917544402682,
            13.467465766095465
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57885357894503,
            13.466985809987563
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57883212127291,
            13.466714530022426
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57898232497774,
            13.466631059202044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57923981704317,
            13.466923206945982
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57921835937105,
            13.467069280684182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56752392806612,
            13.46176883366984
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56778142013155,
            13.461873174310696
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56773850478731,
            13.461581020401688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56773850478731,
            13.461455811474385
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56752392806612,
            13.46153928409986
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56480953254305,
            13.458993355927902
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5649275497397,
            13.459076829412023
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5646378711661,
            13.458722066903464
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56470224418246,
            13.458732501102396
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56471297301852,
            13.45868033010318
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56768486060702,
            13.46136190473593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5675561145743,
            13.461445377394151
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56740591086947,
            13.461581020401688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56728789367281,
            13.461727097400772
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56736299552523,
            13.461967080848574
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56057164229952,
            13.548481049695031
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56039998092257,
            13.548720945886505
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56016394652926,
            13.548773097200442
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.55994936980807,
            13.548700085357712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.55958458938204,
            13.548585352416703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56007811584078,
            13.548293304680692
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56037852325045,
            13.548387177206392
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56036779441439,
            13.548543631333526
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56000301398836,
            13.548585352416703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.55977770843111,
            13.548533201061588
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.55982062377535,
            13.548428898317024
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.55991718329989,
            13.54831416524517
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5030972675284,
            13.54347446525231
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50305435218417,
            13.5438603932188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50302216567599,
            13.544246320559104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50294706382357,
            13.544538373265244
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50271102943026,
            13.544799134306965
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50285050429903,
            13.544246320559104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50282904662691,
            13.54393340654742
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50282904662691,
            13.5437143664943
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50282904662691,
            13.543568339680169
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50312945403658,
            13.543203272252596
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50322601356112,
            13.543098967170364
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50332257308565,
            13.543067675636797
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50295779265963,
            13.543328438290882
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50282904662691,
            13.543537048208329
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50321528472506,
            13.544308903312027
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50283977546297,
            13.545028603787182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50247499503695,
            13.545018173361074
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5023569778403,
            13.545299794705642
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50268957175814,
            13.54414201593429
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50283977546297,
            13.54340145178279
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51809618033968,
            13.568110015555687
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51809618033968,
            13.568589768058374
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51858970679842,
            13.568694061952419
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51897594489657,
            13.568568909274067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51852533378207,
            13.568276886101375
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51831075706087,
            13.568110015555687
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5173237041434,
            13.567525967722176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51773139991366,
            13.567755415256691
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51906177558504,
            13.568381180132858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51936218299471,
            13.568652344400292
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51936218299471,
            13.56925724818845
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51906177558504,
            13.569778715734198
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51871845283114,
            13.569945585106908
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51826784171664,
            13.570112454362306
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51884719886385,
            13.569549270155187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51848241843783,
            13.569549270155187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51788160361849,
            13.56931982435442
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51798889197909,
            13.569653563627696
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51768848456942,
            13.56884007332708
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51695892371737,
            13.56758854434449
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51695892371737,
            13.567317378862024
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51745245017611,
            13.567442532200113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51775285758578,
            13.56765112095032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51816055335604,
            13.567859709517265
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51876136817538,
            13.568193450843195
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51895448722445,
            13.568360321330218
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51798889197909,
            13.567755415256691
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51904031791292,
            13.569465835344207
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50589749373995,
            13.565419211813364
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50592968024813,
            13.56560694329654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5061227992972,
            13.565669520424615
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50639102019869,
            13.565596513773597
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50660559691988,
            13.565492218518896
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50630518951021,
            13.565325346016127
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50568291701876,
            13.56537749368585
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50566145934664,
            13.565596513773597
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50587603606783,
            13.565356634619338
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50611207046114,
            13.565314916480817
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50600478210055,
            13.56528362787211
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50641247787081,
            13.565231480181795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50679871596896,
            13.565231480181795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50680944480501,
            13.565492218518896
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5065734104117,
            13.565137614310336
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50656268157564,
            13.565325346016127
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50644466437899,
            13.565179332480014
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50621935882174,
            13.565168902938277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50611207046114,
            13.565231480181795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50600478210055,
            13.565241909720767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50591895141207,
            13.56527319833497
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5057794765433,
            13.565346205085389
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57847821807862,
            13.341617944675734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57766282653809,
            13.340281713009219
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5786927947998,
            13.338736685932835
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57950818634033,
            13.338903716363301
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57873571014404,
            13.338277351653746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57787740325928,
            13.337943289811463
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57646119689942,
            13.337901532048702
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5759891281128,
            13.337650985320655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57766282653809,
            13.337650985320655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57895028686524,
            13.337650985320655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57955110168457,
            13.338277351653746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.57774865722656,
            13.339697109331322
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56483162165719,
            13.337734462001045
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56481016398507,
            13.337985008642553
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56515348673898,
            13.338277312729327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56541097880441,
            13.338360828117754
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56586158991891,
            13.338214676169077
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5657328438862,
            13.338235555024301
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56556118250924,
            13.338277312729327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56545389414865,
            13.338193797312048
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.56521785975534,
            13.338047645262344
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5649603676899,
            13.337609188582896
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5650676560505,
            13.337713583102527
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5042995286091,
            13.334811398658536
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50434244395333,
            13.335458651445881
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50477159739572,
            13.335270739524862
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50517929316598,
            13.335145464829706
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50492180110055,
            13.334936673526814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50507200480538,
            13.334748761200032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50511492014962,
            13.334602607067078
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5045355630024,
            13.334352056919302
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50496471644479,
            13.334247660947744
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50541532755929,
            13.334247660947744
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50472868205148,
            13.335082827457779
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.504642851363,
            13.335270739524862
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51957739115792,
            13.29699630292864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5189980340107,
            13.297226009350945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51919115305978,
            13.297622774476832
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51947010279733,
            13.298082185916588
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51987779856759,
            13.297810715625594
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.52015674830514,
            13.297518362664562
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.52015674830514,
            13.296745713856076
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51979196787912,
            13.296829243575726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51925552607614,
            13.29699630292864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5192126107319,
            13.297038067748899
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51161659480172,
            13.30248831504771
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51161659480172,
            13.303031244847382
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51161659480172,
            13.303260945550258
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51138056040841,
            13.303260945550258
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51131618739205,
            13.303260945550258
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51108015299874,
            13.303052126738445
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51108015299874,
            13.302843307746686
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51118744135934,
            13.30282242583761
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51131618739205,
            13.302801543926739
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51131618739205,
            13.302905953463105
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.51144493342477,
            13.302676252423712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48694027186471,
            13.297946213582309
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48672569514352,
            13.298196801413946
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4871548485859,
            13.298635329495996
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48728359461862,
            13.298551800398679
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48732650996286,
            13.29813415448033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48713339091378,
            13.297779154883964
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48672569514352,
            13.298071507530505
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48758400202829,
            13.288548982945205
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48732650996286,
            13.288653398619317
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48713339091378,
            13.288757814248457
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48685444117623,
            13.288945762267677
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4867042374714,
            13.288862229832674
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48676861048776,
            13.288736931126227
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48696172953683,
            13.288590749220237
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48717630625802,
            13.288528099804997
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48732650996286,
            13.288528099804997
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48694027186471,
            13.288528099804997
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.48651111842233,
            13.288569866083618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4867042374714,
            13.288548982945205
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50244411193393,
            13.35312383440588
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50248702727816,
            13.353875425658277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5025299426224,
            13.354459995014313
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5025299426224,
            13.354710524304918
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50222953521273,
            13.354501749914142
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50227245055697,
            13.354209465463656
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50270160399936,
            13.354251220406828
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50295909606479,
            13.35458525969212
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50300201140902,
            13.35437648519299
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.50283035003207,
            13.353958935652953
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.5027445193436,
            13.353666650545147
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42616208755038,
            13.34700662968833
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42616208755038,
            13.347445069312004
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42596896850131,
            13.347591215676328
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42594751082919,
            13.34717365440073
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42575439178012,
            13.346964873492185
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42558273040316,
            13.347319800929322
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4256256457474,
            13.346129748052997
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42575439178012,
            13.34654731113357
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4265268679764,
            13.34725716671361
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4265268679764,
            13.34821755623592
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4265268679764,
            13.347967020207042
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4262908335831,
            13.348134044255177
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4260762568619,
            13.348426336061422
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.42659124099276,
            13.3480087762299
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.46464113853982,
            13.37317108239885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.46485571526101,
            13.373567722881699
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4649630036216,
            13.373880859643888
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.46438364647439,
            13.373734729205507
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.46412615440896,
            13.373525971282662
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.46391157768777,
            13.373525971282662
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.46373991631081,
            13.373338088997507
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.46378283165505,
            13.373233709886899
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.46399740837624,
            13.373191958230013
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.4641690697532,
            13.373296337358688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.46434073113015,
            13.373296337358688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.46449093483498,
            13.373755604987831
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3646269287925,
            13.332564171858113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36477713249734,
            13.332939999761923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36537794731667,
            13.333253189235458
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36627916954568,
            13.333733412306868
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36647228859475,
            13.333670774569049
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36602167748025,
            13.334380667980655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36565689705422,
            13.333691653816791
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36578564308694,
            13.334192755221636
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36621479652932,
            13.333670774569049
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36610750816872,
            13.333649895319489
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.3658500161033,
            13.333587257560042
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36576418541482,
            13.333336706359894
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36542086266091,
            13.333148792789363
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36539940498879,
            13.333023516994537
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36512045525124,
            13.332919120449247
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36604313515237,
            13.333023516994537
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36642937325051,
            13.333190551373203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36657957695535,
            13.333357585636476
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36692289970925,
            13.333921325422951
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36657957695535,
            13.334610338932192
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.36647228859475,
            13.334631218098792
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.25218524854253,
            13.369895243531026
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.25235690991948,
            13.370751162758754
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.25212087552617,
            13.3709181710342
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.25197067182134,
            13.370772038799519
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.25190629880498,
            13.370312765485183
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.25201358716558,
            13.370083128499886
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.25222816388677,
            13.370563278310566
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.25233545224737,
            13.370521526191077
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.25235690991948,
            13.37033364156391
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2764216892011,
            13.396928296609737
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27672209661077,
            13.397095286731032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27678646962713,
            13.397471014080105
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27644314687322,
            13.397867614534123
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27603545110296,
            13.398076351352522
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27601399343084,
            13.397825867148699
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2759710780866,
            13.397638003824646
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2759710780866,
            13.397575382684032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27612128179143,
            13.397429266625855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27618565480779,
            13.397575382684032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2759710780866,
            13.397178781748195
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27612128179143,
            13.396928296609737
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27616419713567,
            13.396844801505615
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27627148549627,
            13.396677811210441
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.276765011955,
            13.396907422836414
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.27650751988958,
            13.396844801505615
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2764216892011,
            13.397617130112929
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26607909123967,
            13.39436080890328
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26584305684636,
            13.394736540522997
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26586451451848,
            13.395049649757867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26620783727239,
            13.395049649757867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26637949864934,
            13.395028775821547
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26665844838689,
            13.395007901883412
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2665511600263,
            13.394569548764439
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26648678700994,
            13.394715666559506
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2664438716657,
            13.394506926825109
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26629366796087,
            13.394548674786481
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26620783727239,
            13.394527800806705
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26704468648504,
            13.390707832020768
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26687302510808,
            13.391000072211966
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26665844838689,
            13.391083569344264
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26650824468206,
            13.391167066447604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.2664438716657,
            13.39122968925609
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26642241399358,
            13.391062695063898
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26674427907537,
            13.390916575050689
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26687302510808,
            13.390833077860455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.26695885579656,
            13.390707832020768
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.28410353581975,
            13.404922818571714
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.28388895909856,
            13.405277660644433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.28399624745916,
            13.405590756155995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.28431811254094,
            13.405486391030784
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.28440394322942,
            13.405402898897988
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.28440394322942,
            13.405152422325624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.28429665486883,
            13.405027183941577
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.28410353581975,
            13.405528137086316
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -86.28399624745916,
            13.405173295383292
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "label": 2
      },
      "color": "#f9ff97",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #f9ff97 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-86.73554938160366, 13.39676282734147]),
            {
              "label": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73563521229214, 13.396627147689237]),
            {
              "label": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73572104298061, 13.396627147689237]),
            {
              "label": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73584978901333, 13.396919380691262]),
            {
              "label": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73586051784939, 13.396700205973024]),
            {
              "label": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73568885647244, 13.396543652480592]),
            {
              "label": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73476617657131, 13.399194611207637]),
            {
              "label": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73444431148953, 13.3992781054961]),
            {
              "label": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73441212498135, 13.399372036535977]),
            {
              "label": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73471253239101, 13.39958077204881]),
            {
              "label": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7349807532925, 13.399664266203203]),
            {
              "label": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73523824535793, 13.399664266203203]),
            {
              "label": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73554938160366, 13.39974776032863]),
            {
              "label": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73567812763638, 13.39964339266733]),
            {
              "label": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73537772022671, 13.399622519129627]),
            {
              "label": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73515241466946, 13.39954946173343]),
            {
              "label": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73504512630886, 13.399403346874449]),
            {
              "label": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73489492260403, 13.399205047995286]),
            {
              "label": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7366544517178, 13.398839760158316]),
            {
              "label": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73690121494717, 13.39869364486819]),
            {
              "label": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73713724934048, 13.398516219039434]),
            {
              "label": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73729818188137, 13.398557966305031]),
            {
              "label": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73681538425869, 13.398568403120299]),
            {
              "label": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73681538425869, 13.398359666728895]),
            {
              "label": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73645060383267, 13.398777139330564]),
            {
              "label": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73748057209438, 13.398484908585473]),
            {
              "label": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73726599537319, 13.398443161307194]),
            {
              "label": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73104327045864, 13.402022964089008]),
            {
              "label": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73152606808132, 13.40231519053497]),
            {
              "label": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73180501781887, 13.40231519053497]),
            {
              "label": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73369329296536, 13.40200209075785]),
            {
              "label": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73359673344082, 13.401678553893229]),
            {
              "label": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73360746227688, 13.401407200058198]),
            {
              "label": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72713797413296, 13.403244050808276]),
            {
              "label": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72703068577236, 13.403327543690766]),
            {
              "label": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72691266857571, 13.40321274096985]),
            {
              "label": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72762077175564, 13.403191867741985]),
            {
              "label": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72857563816494, 13.402722219635717]),
            {
              "label": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.731107643475, 13.408305754403305]),
            {
              "label": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73108618580288, 13.408764955229222]),
            {
              "label": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7315582545895, 13.408911064398929]),
            {
              "label": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73157971226162, 13.40855622768985]),
            {
              "label": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73132222019619, 13.408201390456881]),
            {
              "label": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.730206421246, 13.408806700715347]),
            {
              "label": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73048537098354, 13.409349391375118]),
            {
              "label": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.73016350590176, 13.409495500189518]),
            {
              "label": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72669891775647, 13.424957109587654]),
            {
              "label": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72655944288769, 13.425040594924342]),
            {
              "label": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72694568098584, 13.425197129852373]),
            {
              "label": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72725681723156, 13.425311922068044]),
            {
              "label": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72752503813305, 13.425291050760187]),
            {
              "label": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72766451300183, 13.425144951554369]),
            {
              "label": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72756795347729, 13.42509277324503]),
            {
              "label": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72756795347729, 13.424957109587654]),
            {
              "label": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72752503813305, 13.424811010178571]),
            {
              "label": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7274070209364, 13.424737960440693]),
            {
              "label": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72726754606762, 13.424591860898232]),
            {
              "label": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72731046141186, 13.42524930813903]),
            {
              "label": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72705296934643, 13.425165822874936]),
            {
              "label": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72693495214978, 13.425009287926482]),
            {
              "label": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72697786749401, 13.42134634099318]),
            {
              "label": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72694568098584, 13.421586364867945]),
            {
              "label": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72693495214978, 13.421847260111848]),
            {
              "label": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72714952887097, 13.421930746530027]),
            {
              "label": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72734264792004, 13.422014232919162]),
            {
              "label": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72726754606762, 13.42248384331718]),
            {
              "label": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72741774977246, 13.422619508372259]),
            {
              "label": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72154907644787, 13.424827921466914]),
            {
              "label": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7214096015791, 13.425005327868151]),
            {
              "label": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72158126295605, 13.425255783740791]),
            {
              "label": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72179583967724, 13.425360140277274]),
            {
              "label": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72197822989025, 13.42539144722937]),
            {
              "label": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72176365316906, 13.425151427158955]),
            {
              "label": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.7219138568739, 13.42522447677101]),
            {
              "label": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72177438200512, 13.424900971177427]),
            {
              "label": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72163490713635, 13.42468182197921]),
            {
              "label": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72136668623486, 13.424942713859155]),
            {
              "label": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72192458570996, 13.426414138752383]),
            {
              "label": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72224645079174, 13.426560237185658]),
            {
              "label": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72245029867688, 13.426654157560092]),
            {
              "label": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72234301031628, 13.427280292450387]),
            {
              "label": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72234301031628, 13.427582923728444]),
            {
              "label": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72263268888989, 13.427468132598934]),
            {
              "label": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72306184233227, 13.427040274268853]),
            {
              "label": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72290090979138, 13.426768949078928]),
            {
              "label": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72275070608654, 13.427102887730655]),
            {
              "label": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.72253612936535, 13.427301163585259]),
            {
              "label": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68335079876387, 13.395925643684027]),
            {
              "label": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68320059505903, 13.396249188287255]),
            {
              "label": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6830503913542, 13.396144819107942]),
            {
              "label": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68307184902632, 13.39601957603301]),
            {
              "label": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68326496807539, 13.39587345902985]),
            {
              "label": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68330788341963, 13.395612535589184]),
            {
              "label": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68332934109175, 13.3963326835981]),
            {
              "label": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68372630802595, 13.398440930592624]),
            {
              "label": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68352246014082, 13.398931460659368]),
            {
              "label": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6833937141081, 13.39900451824328]),
            {
              "label": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68298601833784, 13.399161070134102]),
            {
              "label": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68308257786238, 13.399213254075061]),
            {
              "label": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68326496807539, 13.39910888618181]),
            {
              "label": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68356537548506, 13.398900150259463]),
            {
              "label": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6843363449997, 13.4249769883901]),
            {
              "label": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6838857338852, 13.424956117053112]),
            {
              "label": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68367115716401, 13.425164830341243]),
            {
              "label": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68382136086885, 13.425310929534975]),
            {
              "label": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68397156457368, 13.425404850398262]),
            {
              "label": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68414322595063, 13.425404850398262]),
            {
              "label": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68421832780305, 13.425352672145422]),
            {
              "label": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6839930222458, 13.425300493881233]),
            {
              "label": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68416468362275, 13.425133523359607]),
            {
              "label": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68402520875398, 13.425081345047774]),
            {
              "label": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.68414322595063, 13.424987424057903]),
            {
              "label": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64138208994959, 13.41042142117773]),
            {
              "label": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64159666667078, 13.410525784160102]),
            {
              "label": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64175759921167, 13.41098498074409]),
            {
              "label": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64170395503137, 13.4111102160238]),
            {
              "label": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64150010714624, 13.410400548575808]),
            {
              "label": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.64148937831018, 13.410233567695231]),
            {
              "label": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63447579751156, 13.419781830413443]),
            {
              "label": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63434168706081, 13.419750522729831]),
            {
              "label": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63427194962642, 13.419677471452221]),
            {
              "label": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63419148335598, 13.41962007400422]),
            {
              "label": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63412174592159, 13.419505279067078]),
            {
              "label": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63393935570858, 13.419343522471591]),
            {
              "label": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6339608133807, 13.41930177881636]),
            {
              "label": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63398763547085, 13.419129586161809]),
            {
              "label": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63408419499538, 13.419072188582861]),
            {
              "label": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63459917912624, 13.419802702200226]),
            {
              "label": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63465818772457, 13.419912279051168]),
            {
              "label": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63469573865078, 13.420058381441295]),
            {
              "label": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63489958653591, 13.420063599382159]),
            {
              "label": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63499078164241, 13.42000620202647]),
            {
              "label": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63484594235561, 13.420027073793763]),
            {
              "label": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63454553494594, 13.419974894372121]),
            {
              "label": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63474938283107, 13.419985330257346]),
            {
              "label": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6347011030688, 13.419839227822768]),
            {
              "label": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63472792515896, 13.419740086834391]),
            {
              "label": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.63479766259334, 13.419547022686931]),
            {
              "label": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59706407739483, 13.404770881440795]),
            {
              "label": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59684950067364, 13.404843937250634]),
            {
              "label": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59676366998517, 13.404739571801205]),
            {
              "label": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59653836442791, 13.40464564285799]),
            {
              "label": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59633451654278, 13.404593460095898]),
            {
              "label": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59633451654278, 13.404447348301801]),
            {
              "label": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59644180490338, 13.404436911741675]),
            {
              "label": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59665638162457, 13.404530840766443]),
            {
              "label": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59673148347699, 13.404603896649228]),
            {
              "label": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60264307214581, 13.40090932846774]),
            {
              "label": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60239630891644, 13.400836271462433]),
            {
              "label": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60212808801495, 13.400846708178838]),
            {
              "label": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60176330758893, 13.400930201893742]),
            {
              "label": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60185986711346, 13.400742340994432]),
            {
              "label": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60237485124432, 13.400606663586997]),
            {
              "label": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60258942796551, 13.400585790132913]),
            {
              "label": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60273963167035, 13.400617100313362]),
            {
              "label": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.59977806989369, 13.401202144342403]),
            {
              "label": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5995634931725, 13.401442188339837]),
            {
              "label": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60019649450001, 13.401536118534487]),
            {
              "label": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60058273259816, 13.401149960832983]),
            {
              "label": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60038961354908, 13.401056030487508]),
            {
              "label": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60015357915577, 13.401233454442611]),
            {
              "label": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60020722333607, 13.400941226682102]),
            {
              "label": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.60020722333607, 13.400795112668689]),
            {
              "label": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.6001213926476, 13.400482010912436]),
            {
              "label": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56919762649142, 13.510908235419723]),
            {
              "label": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56924054183565, 13.511680196282667]),
            {
              "label": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56928345717989, 13.511993152677277]),
            {
              "label": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5696267799338, 13.512243517497215]),
            {
              "label": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57031342544161, 13.512681655299518]),
            {
              "label": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56887576140963, 13.51270251898431]),
            {
              "label": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56855389632784, 13.512285244941642]),
            {
              "label": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5686182693442, 13.511909697678883]),
            {
              "label": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56866118468844, 13.511680196282667]),
            {
              "label": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56958386458956, 13.511721923825679]),
            {
              "label": 2,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56969115295016, 13.512994610379632]),
            {
              "label": 2,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56992718734347, 13.513224110510636]),
            {
              "label": 2,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56992718734347, 13.512952883059347]),
            {
              "label": 2,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57016322173678, 13.512598200542094]),
            {
              "label": 2,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57016322173678, 13.512368699808604]),
            {
              "label": 2,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56990572967135, 13.51226438122035]),
            {
              "label": 2,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56971261062228, 13.511805378889797]),
            {
              "label": 2,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56887576140963, 13.51178451512651]),
            {
              "label": 2,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56878993072115, 13.511513286037577]),
            {
              "label": 2,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5687255577048, 13.511388103277094]),
            {
              "label": 2,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56840369262301, 13.511680196282667]),
            {
              "label": 2,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57956168212496, 13.467111016021576]),
            {
              "label": 2,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57956168212496, 13.467382295537172]),
            {
              "label": 2,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57939002074801, 13.467862250849695]),
            {
              "label": 2,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57917544402682, 13.467465766095465]),
            {
              "label": 2,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57885357894503, 13.466985809987563]),
            {
              "label": 2,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57883212127291, 13.466714530022426]),
            {
              "label": 2,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57898232497774, 13.466631059202044]),
            {
              "label": 2,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57923981704317, 13.466923206945982]),
            {
              "label": 2,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57921835937105, 13.467069280684182]),
            {
              "label": 2,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56752392806612, 13.46176883366984]),
            {
              "label": 2,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56778142013155, 13.461873174310696]),
            {
              "label": 2,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56773850478731, 13.461581020401688]),
            {
              "label": 2,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56773850478731, 13.461455811474385]),
            {
              "label": 2,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56752392806612, 13.46153928409986]),
            {
              "label": 2,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56480953254305, 13.458993355927902]),
            {
              "label": 2,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5649275497397, 13.459076829412023]),
            {
              "label": 2,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5646378711661, 13.458722066903464]),
            {
              "label": 2,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56470224418246, 13.458732501102396]),
            {
              "label": 2,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56471297301852, 13.45868033010318]),
            {
              "label": 2,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56768486060702, 13.46136190473593]),
            {
              "label": 2,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5675561145743, 13.461445377394151]),
            {
              "label": 2,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56740591086947, 13.461581020401688]),
            {
              "label": 2,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56728789367281, 13.461727097400772]),
            {
              "label": 2,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56736299552523, 13.461967080848574]),
            {
              "label": 2,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56057164229952, 13.548481049695031]),
            {
              "label": 2,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56039998092257, 13.548720945886505]),
            {
              "label": 2,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56016394652926, 13.548773097200442]),
            {
              "label": 2,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.55994936980807, 13.548700085357712]),
            {
              "label": 2,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.55958458938204, 13.548585352416703]),
            {
              "label": 2,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56007811584078, 13.548293304680692]),
            {
              "label": 2,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56037852325045, 13.548387177206392]),
            {
              "label": 2,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56036779441439, 13.548543631333526]),
            {
              "label": 2,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56000301398836, 13.548585352416703]),
            {
              "label": 2,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.55977770843111, 13.548533201061588]),
            {
              "label": 2,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.55982062377535, 13.548428898317024]),
            {
              "label": 2,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.55991718329989, 13.54831416524517]),
            {
              "label": 2,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5030972675284, 13.54347446525231]),
            {
              "label": 2,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50305435218417, 13.5438603932188]),
            {
              "label": 2,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50302216567599, 13.544246320559104]),
            {
              "label": 2,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50294706382357, 13.544538373265244]),
            {
              "label": 2,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50271102943026, 13.544799134306965]),
            {
              "label": 2,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50285050429903, 13.544246320559104]),
            {
              "label": 2,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50282904662691, 13.54393340654742]),
            {
              "label": 2,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50282904662691, 13.5437143664943]),
            {
              "label": 2,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50282904662691, 13.543568339680169]),
            {
              "label": 2,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50312945403658, 13.543203272252596]),
            {
              "label": 2,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50322601356112, 13.543098967170364]),
            {
              "label": 2,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50332257308565, 13.543067675636797]),
            {
              "label": 2,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50295779265963, 13.543328438290882]),
            {
              "label": 2,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50282904662691, 13.543537048208329]),
            {
              "label": 2,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50321528472506, 13.544308903312027]),
            {
              "label": 2,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50283977546297, 13.545028603787182]),
            {
              "label": 2,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50247499503695, 13.545018173361074]),
            {
              "label": 2,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5023569778403, 13.545299794705642]),
            {
              "label": 2,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50268957175814, 13.54414201593429]),
            {
              "label": 2,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50283977546297, 13.54340145178279]),
            {
              "label": 2,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51809618033968, 13.568110015555687]),
            {
              "label": 2,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51809618033968, 13.568589768058374]),
            {
              "label": 2,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51858970679842, 13.568694061952419]),
            {
              "label": 2,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51897594489657, 13.568568909274067]),
            {
              "label": 2,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51852533378207, 13.568276886101375]),
            {
              "label": 2,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51831075706087, 13.568110015555687]),
            {
              "label": 2,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5173237041434, 13.567525967722176]),
            {
              "label": 2,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51773139991366, 13.567755415256691]),
            {
              "label": 2,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51906177558504, 13.568381180132858]),
            {
              "label": 2,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51936218299471, 13.568652344400292]),
            {
              "label": 2,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51936218299471, 13.56925724818845]),
            {
              "label": 2,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51906177558504, 13.569778715734198]),
            {
              "label": 2,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51871845283114, 13.569945585106908]),
            {
              "label": 2,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51826784171664, 13.570112454362306]),
            {
              "label": 2,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51884719886385, 13.569549270155187]),
            {
              "label": 2,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51848241843783, 13.569549270155187]),
            {
              "label": 2,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51788160361849, 13.56931982435442]),
            {
              "label": 2,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51798889197909, 13.569653563627696]),
            {
              "label": 2,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51768848456942, 13.56884007332708]),
            {
              "label": 2,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51695892371737, 13.56758854434449]),
            {
              "label": 2,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51695892371737, 13.567317378862024]),
            {
              "label": 2,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51745245017611, 13.567442532200113]),
            {
              "label": 2,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51775285758578, 13.56765112095032]),
            {
              "label": 2,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51816055335604, 13.567859709517265]),
            {
              "label": 2,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51876136817538, 13.568193450843195]),
            {
              "label": 2,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51895448722445, 13.568360321330218]),
            {
              "label": 2,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51798889197909, 13.567755415256691]),
            {
              "label": 2,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51904031791292, 13.569465835344207]),
            {
              "label": 2,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50589749373995, 13.565419211813364]),
            {
              "label": 2,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50592968024813, 13.56560694329654]),
            {
              "label": 2,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5061227992972, 13.565669520424615]),
            {
              "label": 2,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50639102019869, 13.565596513773597]),
            {
              "label": 2,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50660559691988, 13.565492218518896]),
            {
              "label": 2,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50630518951021, 13.565325346016127]),
            {
              "label": 2,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50568291701876, 13.56537749368585]),
            {
              "label": 2,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50566145934664, 13.565596513773597]),
            {
              "label": 2,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50587603606783, 13.565356634619338]),
            {
              "label": 2,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50611207046114, 13.565314916480817]),
            {
              "label": 2,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50600478210055, 13.56528362787211]),
            {
              "label": 2,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50641247787081, 13.565231480181795]),
            {
              "label": 2,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50679871596896, 13.565231480181795]),
            {
              "label": 2,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50680944480501, 13.565492218518896]),
            {
              "label": 2,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5065734104117, 13.565137614310336]),
            {
              "label": 2,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50656268157564, 13.565325346016127]),
            {
              "label": 2,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50644466437899, 13.565179332480014]),
            {
              "label": 2,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50621935882174, 13.565168902938277]),
            {
              "label": 2,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50611207046114, 13.565231480181795]),
            {
              "label": 2,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50600478210055, 13.565241909720767]),
            {
              "label": 2,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50591895141207, 13.56527319833497]),
            {
              "label": 2,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5057794765433, 13.565346205085389]),
            {
              "label": 2,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57847821807862, 13.341617944675734]),
            {
              "label": 2,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57766282653809, 13.340281713009219]),
            {
              "label": 2,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5786927947998, 13.338736685932835]),
            {
              "label": 2,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57950818634033, 13.338903716363301]),
            {
              "label": 2,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57873571014404, 13.338277351653746]),
            {
              "label": 2,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57787740325928, 13.337943289811463]),
            {
              "label": 2,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57646119689942, 13.337901532048702]),
            {
              "label": 2,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5759891281128, 13.337650985320655]),
            {
              "label": 2,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57766282653809, 13.337650985320655]),
            {
              "label": 2,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57895028686524, 13.337650985320655]),
            {
              "label": 2,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57955110168457, 13.338277351653746]),
            {
              "label": 2,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.57774865722656, 13.339697109331322]),
            {
              "label": 2,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56483162165719, 13.337734462001045]),
            {
              "label": 2,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56481016398507, 13.337985008642553]),
            {
              "label": 2,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56515348673898, 13.338277312729327]),
            {
              "label": 2,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56541097880441, 13.338360828117754]),
            {
              "label": 2,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56586158991891, 13.338214676169077]),
            {
              "label": 2,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5657328438862, 13.338235555024301]),
            {
              "label": 2,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56556118250924, 13.338277312729327]),
            {
              "label": 2,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56545389414865, 13.338193797312048]),
            {
              "label": 2,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.56521785975534, 13.338047645262344]),
            {
              "label": 2,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5649603676899, 13.337609188582896]),
            {
              "label": 2,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5650676560505, 13.337713583102527]),
            {
              "label": 2,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5042995286091, 13.334811398658536]),
            {
              "label": 2,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50434244395333, 13.335458651445881]),
            {
              "label": 2,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50477159739572, 13.335270739524862]),
            {
              "label": 2,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50517929316598, 13.335145464829706]),
            {
              "label": 2,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50492180110055, 13.334936673526814]),
            {
              "label": 2,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50507200480538, 13.334748761200032]),
            {
              "label": 2,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50511492014962, 13.334602607067078]),
            {
              "label": 2,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5045355630024, 13.334352056919302]),
            {
              "label": 2,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50496471644479, 13.334247660947744]),
            {
              "label": 2,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50541532755929, 13.334247660947744]),
            {
              "label": 2,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50472868205148, 13.335082827457779]),
            {
              "label": 2,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.504642851363, 13.335270739524862]),
            {
              "label": 2,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51957739115792, 13.29699630292864]),
            {
              "label": 2,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5189980340107, 13.297226009350945]),
            {
              "label": 2,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51919115305978, 13.297622774476832]),
            {
              "label": 2,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51947010279733, 13.298082185916588]),
            {
              "label": 2,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51987779856759, 13.297810715625594]),
            {
              "label": 2,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.52015674830514, 13.297518362664562]),
            {
              "label": 2,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.52015674830514, 13.296745713856076]),
            {
              "label": 2,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51979196787912, 13.296829243575726]),
            {
              "label": 2,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51925552607614, 13.29699630292864]),
            {
              "label": 2,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5192126107319, 13.297038067748899]),
            {
              "label": 2,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51161659480172, 13.30248831504771]),
            {
              "label": 2,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51161659480172, 13.303031244847382]),
            {
              "label": 2,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51161659480172, 13.303260945550258]),
            {
              "label": 2,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51138056040841, 13.303260945550258]),
            {
              "label": 2,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51131618739205, 13.303260945550258]),
            {
              "label": 2,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51108015299874, 13.303052126738445]),
            {
              "label": 2,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51108015299874, 13.302843307746686]),
            {
              "label": 2,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51118744135934, 13.30282242583761]),
            {
              "label": 2,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51131618739205, 13.302801543926739]),
            {
              "label": 2,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51131618739205, 13.302905953463105]),
            {
              "label": 2,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.51144493342477, 13.302676252423712]),
            {
              "label": 2,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48694027186471, 13.297946213582309]),
            {
              "label": 2,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48672569514352, 13.298196801413946]),
            {
              "label": 2,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4871548485859, 13.298635329495996]),
            {
              "label": 2,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48728359461862, 13.298551800398679]),
            {
              "label": 2,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48732650996286, 13.29813415448033]),
            {
              "label": 2,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48713339091378, 13.297779154883964]),
            {
              "label": 2,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48672569514352, 13.298071507530505]),
            {
              "label": 2,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48758400202829, 13.288548982945205]),
            {
              "label": 2,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48732650996286, 13.288653398619317]),
            {
              "label": 2,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48713339091378, 13.288757814248457]),
            {
              "label": 2,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48685444117623, 13.288945762267677]),
            {
              "label": 2,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4867042374714, 13.288862229832674]),
            {
              "label": 2,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48676861048776, 13.288736931126227]),
            {
              "label": 2,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48696172953683, 13.288590749220237]),
            {
              "label": 2,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48717630625802, 13.288528099804997]),
            {
              "label": 2,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48732650996286, 13.288528099804997]),
            {
              "label": 2,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48694027186471, 13.288528099804997]),
            {
              "label": 2,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.48651111842233, 13.288569866083618]),
            {
              "label": 2,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4867042374714, 13.288548982945205]),
            {
              "label": 2,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50244411193393, 13.35312383440588]),
            {
              "label": 2,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50248702727816, 13.353875425658277]),
            {
              "label": 2,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5025299426224, 13.354459995014313]),
            {
              "label": 2,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5025299426224, 13.354710524304918]),
            {
              "label": 2,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50222953521273, 13.354501749914142]),
            {
              "label": 2,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50227245055697, 13.354209465463656]),
            {
              "label": 2,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50270160399936, 13.354251220406828]),
            {
              "label": 2,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50295909606479, 13.35458525969212]),
            {
              "label": 2,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50300201140902, 13.35437648519299]),
            {
              "label": 2,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.50283035003207, 13.353958935652953]),
            {
              "label": 2,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.5027445193436, 13.353666650545147]),
            {
              "label": 2,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42616208755038, 13.34700662968833]),
            {
              "label": 2,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42616208755038, 13.347445069312004]),
            {
              "label": 2,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42596896850131, 13.347591215676328]),
            {
              "label": 2,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42594751082919, 13.34717365440073]),
            {
              "label": 2,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42575439178012, 13.346964873492185]),
            {
              "label": 2,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42558273040316, 13.347319800929322]),
            {
              "label": 2,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4256256457474, 13.346129748052997]),
            {
              "label": 2,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42575439178012, 13.34654731113357]),
            {
              "label": 2,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4265268679764, 13.34725716671361]),
            {
              "label": 2,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4265268679764, 13.34821755623592]),
            {
              "label": 2,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4265268679764, 13.347967020207042]),
            {
              "label": 2,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4262908335831, 13.348134044255177]),
            {
              "label": 2,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4260762568619, 13.348426336061422]),
            {
              "label": 2,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.42659124099276, 13.3480087762299]),
            {
              "label": 2,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.46464113853982, 13.37317108239885]),
            {
              "label": 2,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.46485571526101, 13.373567722881699]),
            {
              "label": 2,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4649630036216, 13.373880859643888]),
            {
              "label": 2,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.46438364647439, 13.373734729205507]),
            {
              "label": 2,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.46412615440896, 13.373525971282662]),
            {
              "label": 2,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.46391157768777, 13.373525971282662]),
            {
              "label": 2,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.46373991631081, 13.373338088997507]),
            {
              "label": 2,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.46378283165505, 13.373233709886899]),
            {
              "label": 2,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.46399740837624, 13.373191958230013]),
            {
              "label": 2,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.4641690697532, 13.373296337358688]),
            {
              "label": 2,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.46434073113015, 13.373296337358688]),
            {
              "label": 2,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.46449093483498, 13.373755604987831]),
            {
              "label": 2,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3646269287925, 13.332564171858113]),
            {
              "label": 2,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36477713249734, 13.332939999761923]),
            {
              "label": 2,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36537794731667, 13.333253189235458]),
            {
              "label": 2,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36627916954568, 13.333733412306868]),
            {
              "label": 2,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36647228859475, 13.333670774569049]),
            {
              "label": 2,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36602167748025, 13.334380667980655]),
            {
              "label": 2,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36565689705422, 13.333691653816791]),
            {
              "label": 2,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36578564308694, 13.334192755221636]),
            {
              "label": 2,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36621479652932, 13.333670774569049]),
            {
              "label": 2,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36610750816872, 13.333649895319489]),
            {
              "label": 2,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.3658500161033, 13.333587257560042]),
            {
              "label": 2,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36576418541482, 13.333336706359894]),
            {
              "label": 2,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36542086266091, 13.333148792789363]),
            {
              "label": 2,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36539940498879, 13.333023516994537]),
            {
              "label": 2,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36512045525124, 13.332919120449247]),
            {
              "label": 2,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36604313515237, 13.333023516994537]),
            {
              "label": 2,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36642937325051, 13.333190551373203]),
            {
              "label": 2,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36657957695535, 13.333357585636476]),
            {
              "label": 2,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36692289970925, 13.333921325422951]),
            {
              "label": 2,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36657957695535, 13.334610338932192]),
            {
              "label": 2,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.36647228859475, 13.334631218098792]),
            {
              "label": 2,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.25218524854253, 13.369895243531026]),
            {
              "label": 2,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.25235690991948, 13.370751162758754]),
            {
              "label": 2,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.25212087552617, 13.3709181710342]),
            {
              "label": 2,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.25197067182134, 13.370772038799519]),
            {
              "label": 2,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.25190629880498, 13.370312765485183]),
            {
              "label": 2,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.25201358716558, 13.370083128499886]),
            {
              "label": 2,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.25222816388677, 13.370563278310566]),
            {
              "label": 2,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.25233545224737, 13.370521526191077]),
            {
              "label": 2,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.25235690991948, 13.37033364156391]),
            {
              "label": 2,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2764216892011, 13.396928296609737]),
            {
              "label": 2,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27672209661077, 13.397095286731032]),
            {
              "label": 2,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27678646962713, 13.397471014080105]),
            {
              "label": 2,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27644314687322, 13.397867614534123]),
            {
              "label": 2,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27603545110296, 13.398076351352522]),
            {
              "label": 2,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27601399343084, 13.397825867148699]),
            {
              "label": 2,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2759710780866, 13.397638003824646]),
            {
              "label": 2,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2759710780866, 13.397575382684032]),
            {
              "label": 2,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27612128179143, 13.397429266625855]),
            {
              "label": 2,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27618565480779, 13.397575382684032]),
            {
              "label": 2,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2759710780866, 13.397178781748195]),
            {
              "label": 2,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27612128179143, 13.396928296609737]),
            {
              "label": 2,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27616419713567, 13.396844801505615]),
            {
              "label": 2,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27627148549627, 13.396677811210441]),
            {
              "label": 2,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.276765011955, 13.396907422836414]),
            {
              "label": 2,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.27650751988958, 13.396844801505615]),
            {
              "label": 2,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2764216892011, 13.397617130112929]),
            {
              "label": 2,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26607909123967, 13.39436080890328]),
            {
              "label": 2,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26584305684636, 13.394736540522997]),
            {
              "label": 2,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26586451451848, 13.395049649757867]),
            {
              "label": 2,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26620783727239, 13.395049649757867]),
            {
              "label": 2,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26637949864934, 13.395028775821547]),
            {
              "label": 2,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26665844838689, 13.395007901883412]),
            {
              "label": 2,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2665511600263, 13.394569548764439]),
            {
              "label": 2,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26648678700994, 13.394715666559506]),
            {
              "label": 2,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2664438716657, 13.394506926825109]),
            {
              "label": 2,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26629366796087, 13.394548674786481]),
            {
              "label": 2,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26620783727239, 13.394527800806705]),
            {
              "label": 2,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26704468648504, 13.390707832020768]),
            {
              "label": 2,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26687302510808, 13.391000072211966]),
            {
              "label": 2,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26665844838689, 13.391083569344264]),
            {
              "label": 2,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26650824468206, 13.391167066447604]),
            {
              "label": 2,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.2664438716657, 13.39122968925609]),
            {
              "label": 2,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26642241399358, 13.391062695063898]),
            {
              "label": 2,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26674427907537, 13.390916575050689]),
            {
              "label": 2,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26687302510808, 13.390833077860455]),
            {
              "label": 2,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.26695885579656, 13.390707832020768]),
            {
              "label": 2,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.28410353581975, 13.404922818571714]),
            {
              "label": 2,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.28388895909856, 13.405277660644433]),
            {
              "label": 2,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.28399624745916, 13.405590756155995]),
            {
              "label": 2,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.28431811254094, 13.405486391030784]),
            {
              "label": 2,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.28440394322942, 13.405402898897988]),
            {
              "label": 2,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.28440394322942, 13.405152422325624]),
            {
              "label": 2,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.28429665486883, 13.405027183941577]),
            {
              "label": 2,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.28410353581975, 13.405528137086316]),
            {
              "label": 2,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-86.28399624745916, 13.405173295383292]),
            {
              "label": 2,
              "system:index": "478"
            })]),
    visParams = ui.import && ui.import("visParams", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B11",
          "B8",
          "B4"
        ],
        "min": 0.02160000056028366,
        "max": 0.46540001034736633,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B11","B8","B4"],"min":0.02160000056028366,"max":0.46540001034736633,"gamma":1},
    imageVisParam3 = ui.import && ui.import("imageVisParam3", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B8",
          "B4",
          "B3"
        ],
        "max": 3000,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B8","B4","B3"],"max":3000,"gamma":1};
//v2.4######################################################################################################## 
//#                                                                                                    #\\
//#                                   MONITOREO COSECHA DE AGUA                                         #\\
//#                                                                                                    #\\
//########################################################################################################
// date: 2021-07-30
// author: Grettel Vargas | grettel.vargas@catie.ac.cr
// Unidad de Acción Climática         
// Laboratorio de Modelado Ecosistémico     
// Centro Agronómico Tropical de Investigación y Enseñanza
//########################################################################################################
//########################################################################################################
// Prepare data -----------------------------------------------------------------------------
Map.setOptions('HYBRID');
var contorno = ee.FeatureCollection(CA);
Map.centerObject(CA)
// Let us set a palette to visualize this elevation
var elevPalette = ['yellow', 'green', 'Brown', 'red'];
var elev = {min: 100, max: 3000, palette: elevPalette};
// But we are only interested to see our study area
// See above that the ULB boundary is aleady imported above as variable 'ulb'
Map.centerObject(contorno,7);
//Now let us select the first band 'DSM' and mosaic & clip the DSM to ULB boundary
var dsm_CA = dsm.select('DSM').filterBounds(contorno).mosaic().clip(contorno);
// The below command will add clipped DSM to the map view
Map.addLayer(dsm_CA, elev, 'Elevation (ALOS)');
// Sentinel2
//______________________________________________________________________________________________
//  DATA 2020 Epoca Seca 
// Cloud Masking Function
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
var rgb_vis = {min: 0, max: 0.3, bands: ['B4', 'B3', 'B2']};
var s2_20 = ee.ImageCollection("COPERNICUS/S2_SR");
var imagenS20 = s2_20.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 30))
   .filter(ee.Filter.date('2020-01-01', '2020-06-30'))
   .filter(ee.Filter.bounds(contorno))
var imagen = ee.Image(imagenS20.first());
function addNDVI(image) {
  var ndvi_1 = image.normalizedDifference(['B8', 'B4']);
  return image.addBands(ndvi_1);
}
var ndviS20 = addNDVI(imagen);
var imagS20_with_ndvi = imagenS20.map(addNDVI);
//var greenest_S20 = imagS20_with_ndvi.qualityMosaic('nd');
var NDVI = imagS20_with_ndvi.select(['nd']);
var NDVImed_S20 = NDVI.median();
var ndvi_pal = ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#d9ef8b',
'#a6d96a'];
var imagS20_with_ndvi = imagenS20.map(addNDVI);
//Map.addLayer(imagenS20.median(), rgb_vis, 'RGB (median)');
//var chart20 = ui.Chart.image.series(imagS20_with_ndvi.select('nd'), roi);
//print(chart20);
var greenestS20 = imagS20_with_ndvi.qualityMosaic('nd');
//Map.addLayer(greenestS20, rgb_vis, 'RGB (greenest pixel ES20)');
//___________________________________________________________________________________________
var imagenH20 = s2_20.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 30))
   .filter(ee.Filter.date('2020-07-01', '2020-12-31'))
   .filter(ee.Filter.bounds(contorno))
   var red = imagenH20.select('B4');
   var nir = imagenH20.select('B8');
   var imagen = ee.Image(imagenH20.first());
function addNDVI(image) {
  var ndvi_2 = image.normalizedDifference(['B8', 'B4']);
  return image.addBands(ndvi_2);
}
var ndviSH0 = addNDVI(imagen);
var imagH20_with_ndvi = imagenH20.map(addNDVI);
var NDVI = imagH20_with_ndvi.select(['nd']);
var NDVImed_H20 = NDVI.median();
var ndvi_pal = ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#d9ef8b',
'#a6d96a'];
//Map.addLayer(imagenH20.median(), rgb_vis, 'RGB (median)');
//var chartH20 = ui.Chart.image.series(imagH20_with_ndvi.select('nd'), roi);
//print(chartH20);
var greenestH20 = imagH20_with_ndvi.qualityMosaic('nd');
//Map.addLayer(greenestH20, rgb_vis, 'RGB (greenest pixel EH20)');
//____________________________________________________________________________________________   
// Here we create a mosaic 
var mosaicS20 = imagenS20.mosaic();
var mosaicH20 = imagenH20.mosaic();
// Calculate the median value of the temporal stack
var medianS20 = imagenS20.median();
var medianH20 = imagenH20.median();
var rgbVis = {
  min: 0.0,
  max: 3000,
  bands: ['B4', 'B3', 'B2']
};
var ndvi_pal = ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#d9ef8b',
'#a6d96a'];
//Map.addLayer(imagenS, rgbVis, 'Epoca Seca');
//Map.addLayer(imagenH, rgbVis, 'Epoca Húmeda');
//Map.addLayer(mosaicS20, rgbVis, 'Mosaico Epoca Seca 2020');
//Map.addLayer(mosaicH20, rgbVis, 'Mosaico Epoca Húmeda 2020');
Map.addLayer(medianS20.clip(contorno), rgbVis,  'Sentinel-2 ES 2020')  
Map.addLayer(medianH20.clip(contorno), rgbVis,  'Sentinel-2 EH 2020')  
Map.addLayer(NDVImed_S20.clip(contorno), {min:-0.5, max:0.9, palette: ndvi_pal}, 'NDVI ES 2020');
Map.addLayer(NDVImed_H20.clip(contorno), {min:-0.5, max:0.9, palette: ndvi_pal}, 'NDVI EH 2020');
//Map.addLayer(imagS20_with_ndvi.median(), {bands: 'nd', min: 0, max: 1}, 'NDVI ES 2020');
//Map.addLayer(imagH20_with_ndvi.median(), {bands: 'nd', min: 0, max: 1}, 'NDVI EH 2020');
var ndviVis = {
  min: 0.0,
  max: 1,
  palette: ['white', 'green']
};
// NDVI Formula
// Visualization parameters 
var visParams = {bands: ['B8', 'B4', 'B3'], max: 3048, gamma: 1};
var visParams_ndvi = {min: -0.2, max: 0.8, palette: 'FFFFFF, CE7E45, DF923D, F1B555, FCD163, 99B718, 74A901, 66A000, 529400,' +
    '3E8601, 207401, 056201, 004C00, 023B01, 012E01, 011D01, 011301'};
//Map.addLayer(ndviS20.clip(contorno), visParams_ndvi, 'NDVI Epoca Seca 2020');
//Map.addLayer(ndviH20.clip(contorno), visParams_ndvi, 'NDVI Epoca Húmeda 2020');
// Calculate Modified Normalized Difference Water Index (MNDWI)
// 'GREEN'(B3) and 'SWIR1' (B11)
var eviS20 = medianS20.expression(
    '2.5 * ((NIR - RED) / (NIR + 6 * RED - 7.5 * BLUE + 1))', {
      'NIR': medianS20.select('B8'),
      'RED': medianS20.select('B4'),
      'BLUE': medianS20.select('B2')
});
var eviH20 = medianH20.expression(
    '2.5 * ((NIR - RED) / (NIR + 6 * RED - 7.5 * BLUE + 1))', {
      'NIR': medianH20.select('B8'),
      'RED': medianH20.select('B4'),
      'BLUE': medianH20.select('B2')
});
Map.addLayer(eviS20.clip(contorno), visParams_ndvi, 'EVI ES 2020');
Map.addLayer(eviH20.clip(contorno), visParams_ndvi, 'EVI EH 2020');
var ndwiVis = {
  min: 0,
  max: 1,
  palette: ['white', 'black']
};
var ndwiViz = {min: 0.5, max: 1, palette: ['00FFFF', '0000FF']};
// The scale value is 0.0001 for Sentinel-2 dataset
var saviS20 = medianS20.expression(
  '1.5 * ((NIR - RED) / (NIR + RED + 0.5))', {
    'NIR': medianS20.select('B8').multiply(0.0001),
    'RED': medianS20.select('B4').multiply(0.0001)
}).rename('savi');
//Map.addLayer(saviS20.clip(contorno), ndviVis, 'SAVI ES 2020');
var saviH20 = medianH20.expression(
  '1.5 * ((NIR - RED) / (NIR + RED + 0.5))', {
    'NIR': medianH20.select('B8').multiply(0.0001),
    'RED': medianH20.select('B4').multiply(0.0001)
}).rename('savi');
//Map.addLayer(saviH20.clip(contorno), ndviVis, 'SAVI EH 2020');
//Map.addLayer(final_imageS20.clip(contorno), rgbVis,  'Sentinel-2 Indices Epoca Seca 2020')  
//Map.addLayer(final_imageH20.clip(contorno), rgbVis,  'Sentinel-2 Indices Epoca Húmeda 2020')  
//______________________________________________________________________________________________
//  DATA 2021
// Cloud Masking Function
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
var sent_2021 = ee.ImageCollection("COPERNICUS/S2_SR");
var ima2021 = sent_2021.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
   .filter(ee.Filter.date('2021-01-01', '2021-04-30'))
   .filter(ee.Filter.bounds(contorno))
   .map(maskS2clouds)
   .median()
// Here we create a mosaic 
//var mosaic = imagenT.mosaic();
//var medianS20 = imagenT.median();
var mapa2021 = ima2021.clip(contorno)
// Calculate the median value of the temporal stack
Map.addLayer(mapa2021, rgbVis,  'Sentinel2021')  
var addNDVI = function(image) {
return image.addBands(image.normalizedDifference(['B8', 'B4']));
};
var ndvi_map2021 = sent_2021.map(addNDVI);
var NDVI = ndvi_map2021.select(['nd']);
var NDVImed = NDVI.median();
var ndvi_pal = ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#d9ef8b',
'#a6d96a'];
//Map.addLayer(NDVImed.clip(contorno), {min:-0.5, max:0.9, palette: ndvi_pal},  'NDVI ES 2021')  
//Map.addLayer(imagenS21.median(), rgb_vis, 'RGB (median)');
//var chartS21 = ui.Chart.image.series(ndvi_map2021.select('nd'), roi);
//print(chartS21);
// Visualization parameters 
var visParams = {bands: ['B8', 'B4', 'B3'], max: 3048, gamma: 1};
var visParams_ndvi = {min: -0.2, max: 0.8, palette: 'FFFFFF, CE7E45, DF923D, F1B555, FCD163, 99B718, 74A901, 66A000, 529400,' +
    '3E8601, 207401, 056201, 004C00, 023B01, 012E01, 011D01, 011301'};
// Calculate EVI
var eviS21 = mapa2021.expression(
    '2.5 * ((NIR - RED) / (NIR + 6 * RED - 7.5 * BLUE + 1))', {
      'NIR': mapa2021.select('B8'),
      'RED': mapa2021.select('B4'),
      'BLUE': mapa2021.select('B2')
});
//Map.addLayer(eviS20.clip(contorno), visParams_ndvi, 'EVI ES 2021');
var saviS21 = mapa2021.expression(
  '1.5 * ((NIR - RED) / (NIR + RED + 0.5))', {
    'NIR': mapa2021.select('B8').multiply(0.0001),
    'RED': mapa2021.select('B4').multiply(0.0001)
}).rename('savi');
//Map.addLayer(saviS21.clip(contorno), ndviVis, 'SAVI ES 2021');
//_CLASIFICACION  SUPERVISADA
//__________________________________________________________________________________________
var sent_class = ee.ImageCollection("COPERNICUS/S2_SR");
var imagenT = sent_class.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
   .filter(ee.Filter.date('2020-01-01', '2020-12-31'))
   .filter(ee.Filter.bounds(contorno))
var red = imagenT.select('B4');
var nir = imagenT.select('B8');
var imagen = ee.Image(imagenT.first());
function addNDVI(image) {
  var ndviT = image.normalizedDifference(['B8', 'B4']);
  return image.addBands(ndviT);
}
var imagen_ndvi = addNDVI(imagen);
var S2 = imagenT.map(addNDVI);
//TRAINING DATA
//_________________________________________________________________________________
var c_agua = ee.FeatureCollection(water);
//Map.addLayer (c_agua, {}, 'agua');
var lat_abi = ee.FeatureCollection(lat_ab);
//Map.addLayer (c_agua, {}, 'lat_abi');
var lat_cerr = ee.FeatureCollection(lat_ce);
//Map.addLayer (lat_cerr, {}, 'lat_cerrado');
var pino_abierto = ee.FeatureCollection(bp_abi);
var pino_cerrado = ee.FeatureCollection(bp_cerr);
var bosque_reg = ee.FeatureCollection(b_rege);
var cafe_sombra = ee.FeatureCollection(cafe);
var poblados = ee.FeatureCollection(pobla);
var cult_citri = ee.FeatureCollection(citri);
var forestal_plan = ee.FeatureCollection(forestal);
var cult_maiz = ee.FeatureCollection(maiz);
var cult_hort = ee.FeatureCollection(horta);
var cult_frijol = ee.FeatureCollection(frijol);
var matorrales = ee.FeatureCollection(matorr);
var past_maleza = ee.FeatureCollection(p_malez);
var past_manejado = ee.FeatureCollection(p_manej);
var suelo_desnudo = ee.FeatureCollection(s_desn);
var b_regen= ee.FeatureCollection(b_rege);
var mang = ee.FeatureCollection(mango); 
//BANDS FOR PREDICTION.
var bands = ['B2', 'B3', 'B4', 'B5', 'B8', 'B9', 'B11', 'ndvi']
var samples = c_agua.merge(lat_abi).merge(lat_cerr);
// var classifier = ee.Classifier.smileRandomForest(10).train({
//   features: total_sample,
//   classProperty: 'id',
//   inputProperties: bands
// })
// var classification = final_image.selec(bands).classfy(classifier)
// Map.addLayer(classification.clip(contorno), igbpPalette, 'Clasificaciòn CA')
//ACCURACY
// var sample_rc = total_sample.randomColumn('rand')
// var training = sample_rc.filter(ee.Filter.lt('rand', 0.7))
// var validation = sample_rc.filter(ee.Filter.gte('rand', 0.7 ))
// var classifier = ee.Classifier.smileRandomForest(10).train({
//   features: training,
//   classProperty: 'id',
//   inputProperties: bands
// })
// var confusionMatrix = ee.ConfusionMatrix (validation.classify(classifier)
//                        .errorMatrix({
//                            actual: 'id',
//                            predicted: 'classification'
//                         }))
//var accuracy = confusionMatrix
  // print('Confusion Matrix', accuracy)// print('Overall Accuracy', accuracy.accuracy())
// Convert the Nigeria boundary feature collection to a line for map display.
var municipios =
    ee.Image().byte().paint({featureCollection: munis, color: 1, width: 3});
Map.centerObject(municipios, 6);
Map.addLayer(municipios, null, 'Municipios border');
// Paneles____________________________________________________________________________
Map.setCenter(-86.426, 13.50, 8);
//App title
var header = ui.Label('HERRAMIENTA DE MONITOREO DE COBERTURA/USO DE LA TIERRA, PROYECTO COSECHA DE AGUA, NICARAGUA', {fontSize: '20px', fontWeight: 'bold', color: '4A997E'});
//App summary
var text = ui.Label(
  'Esta herramienta expone mosaicos de imágenes Sentinel-2 para los años 2020 y 2021.',
      {fontSize: '14px'});
//3.2) Create a panel to hold text
var panel = ui.Panel({
  widgets:[header, text],//Adds header and text
  style:{width: '300px',position:'middle-right'}});
//3.3) Create variable for additional text and separators
//This creates another panel to house a line separator and instructions for the user
var intro = ui.Panel([
  ui.Label({
    value: '____________________________________________',
    style: {fontWeight: 'bold',  color: '4A997E'},
  }),
  ui.Label({
    value:'Unidad de Acción Climática, CATIE, CR',
    style: {fontSize: '15px', fontWeight: 'bold'}
  })]);
//Add this new panel to the larger panel we created 
panel.add(intro)
//3.4) Add our main panel to the root of our GUI
ui.root.insert(1,panel)