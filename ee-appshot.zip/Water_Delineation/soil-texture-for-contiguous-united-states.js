// Imports
var clay_mean = ee.ImageCollection('projects/sat-io/open-datasets/polaris/clay_mean');
var ksat_mean = ee.ImageCollection('projects/sat-io/open-datasets/polaris/ksat_mean');
var sand_mean = ee.ImageCollection('projects/sat-io/open-datasets/polaris/sand_mean');
var silt_mean = ee.ImageCollection('projects/sat-io/open-datasets/polaris/silt_mean');
// Clasification 
var SOIL_Texture_clay = ee.Image(clay_mean.filterMetadata('system:index', 'equals', 'clay_0_5').first()).divide(100.0);
var SOIL_Texture_Sand = ee.Image(sand_mean.filterMetadata('system:index', 'equals', 'sand_0_5').first()).divide(100.0);
var SOIL_Texture_Silt = ee.Image(1.0).subtract(SOIL_Texture_clay.select('b1')
                                .add(SOIL_Texture_Sand.select('b1'))).set('system:index', 'RC_silt_0_5');
var SOIL_Texture = SOIL_Texture_clay.select('b1').rename('clay_0_5')
                                    .addBands(SOIL_Texture_Sand.select('b1').rename('sand_0_5'))
                                    .addBands(SOIL_Texture_Silt.select('constant').rename('RC_silt_0_5'));
function Encoder(image, code, name)
{
  var image_Encoded = image.unmask(99999);
  var image_Encoded1 = image_Encoded.updateMask(image_Encoded.gt(100));
  var image_Encoded2 = image_Encoded1.unmask(code);
  var image_Encoded3 = image_Encoded2.mask(image_Encoded2.lt(1000));
  return image_Encoded3;
}
//________________________ Sand _____________________________________//
var SAND_filter = SOIL_Texture.select('RC_silt_0_5').add(SOIL_Texture.select('clay_0_5').multiply(1.5)).rename('Sand');
var SAND = SAND_filter.mask(SAND_filter.lt(0.15));
//________________________ LOAMY_SAND _____________________________________//
var LOAMY_SAND_filter1 = SOIL_Texture.select('RC_silt_0_5').add(SOIL_Texture.select('clay_0_5').multiply(1.5)).rename('LOAMY_SAND');
var LOAMY_SAND_filter2 = SOIL_Texture.select('RC_silt_0_5').add(SOIL_Texture.select('clay_0_5').multiply(2.0)).rename('LOAMY_SAND');
var LOAMY_SAND = LOAMY_SAND_filter1.mask(LOAMY_SAND_filter1.gte(0.15)).updateMask(LOAMY_SAND_filter2.lt(0.3));
//________________________ SANDY_LOAM1 _____________________________________//
var SANDY_LOAM_filter = SOIL_Texture.select('RC_silt_0_5').add(SOIL_Texture.select('clay_0_5').multiply(2)).rename('SANDY_LOAM');
var SANDY_LOAM = SANDY_LOAM_filter.mask(SANDY_LOAM_filter.gte(0.3)).updateMask(SOIL_Texture.select('clay_0_5').gte(0.07))
                                  .updateMask(SOIL_Texture.select('clay_0_5').lte(0.2))
                                  .updateMask(SOIL_Texture.select('sand_0_5').gt(0.52));
//________________________ SANDY_LOAM2 _____________________________________//
var SANDY_LOAM_filter2 = SOIL_Texture.select('RC_silt_0_5').add(SOIL_Texture.select('clay_0_5').multiply(2)).rename('SANDY_LOAM2');
var SANDY_LOAM2 = SANDY_LOAM_filter2.mask(SANDY_LOAM_filter2.gte(0.3)).updateMask(SOIL_Texture.select('clay_0_5').lt(0.07))
                                  .updateMask(SOIL_Texture.select('RC_silt_0_5').lt(0.5));
var SANDY_LOAM_merged = SANDY_LOAM.blend(SANDY_LOAM2);
//________________________ LOAM _____________________________________//
var LOAM_filter = SOIL_Texture.select('RC_silt_0_5').rename('LOAM');
var LOAM = LOAM_filter.mask(LOAM_filter.lt(0.5)).updateMask(SOIL_Texture.select('RC_silt_0_5').gte(0.28))
                                  .updateMask(SOIL_Texture.select('clay_0_5').gte(0.07))
                                  .updateMask(SOIL_Texture.select('clay_0_5').lte(0.27))
                                  .updateMask(SOIL_Texture.select('sand_0_5').lte(0.52));
//________________________ SILT_LOAM _____________________________________//
var SILT_LOAM_filter = SOIL_Texture.select('RC_silt_0_5').rename('SILT_LOAM');
var SILT_LOAM = SILT_LOAM_filter.mask(SILT_LOAM_filter.gte(0.5)).updateMask(SOIL_Texture.select('clay_0_5').gte(0.12))
                                  .updateMask(SOIL_Texture.select('clay_0_5').lt(0.27));
//________________________ SILT_LOAM2 _____________________________________//
var SILT_LOAM_filter2 = SOIL_Texture.select('RC_silt_0_5').rename('SILT_LOAM2');
var SILT_LOAM2 = SILT_LOAM_filter2.mask(SILT_LOAM_filter2.gte(0.5)).updateMask(SOIL_Texture.select('clay_0_5').lt(0.12))
                                  .updateMask(SOIL_Texture.select('RC_silt_0_5').lt(0.8));
var SILT_LOAM_merged = SILT_LOAM.blend(SILT_LOAM2);
//________________________ SILT _____________________________________//
var SILT_filter = SOIL_Texture.select('RC_silt_0_5').rename('SILT');
var SILT = SILT_filter.mask(SILT_filter.gte(0.8)).updateMask(SOIL_Texture.select('clay_0_5').lt(0.12));
//________________________ SANDY_CLAY_LOAM _____________________________________//
var SANDY_CLAY_LOAM_filter = SOIL_Texture.select('RC_silt_0_5').rename('SANDY_CLAY_LOAM');
var SANDY_CLAY_LOAM = SANDY_CLAY_LOAM_filter.mask(SANDY_CLAY_LOAM_filter.lt(0.28)).updateMask(SOIL_Texture.select('clay_0_5').gte(0.2))
                                            .updateMask(SOIL_Texture.select('clay_0_5').lt(0.35))
                                            .updateMask(SOIL_Texture.select('sand_0_5').gt(0.45));
//________________________ CLAY_LOAM _____________________________________//
var CLAY_LOAM_filter = SOIL_Texture.select('clay_0_5').rename('CLAY_LOAM');
var CLAY_LOAM = CLAY_LOAM_filter.mask(CLAY_LOAM_filter.gte(0.27)).updateMask(SOIL_Texture.select('clay_0_5').lt(0.4))
                                .updateMask(SOIL_Texture.select('sand_0_5').gt(0.2))
                                .updateMask(SOIL_Texture.select('sand_0_5').lte(0.45));
//________________________ SILTY_CLAY_LOAM _____________________________________//
var SILTY_CLAY_LOAM_filter = SOIL_Texture.select('clay_0_5').rename('SILTY_CLAY_LOAM');
var SILTY_CLAY_LOAM = SILTY_CLAY_LOAM_filter.mask(SILTY_CLAY_LOAM_filter.gte(0.27)).updateMask(SOIL_Texture.select('clay_0_5').lt(0.4))
                                            .updateMask(SOIL_Texture.select('sand_0_5').lte(0.2));
//________________________ SANDY_CLAY _____________________________________//
var SANDY_CLAY_filter = SOIL_Texture.select('clay_0_5').rename('SANDY_CLAY');
var SANDY_CLAY = SANDY_CLAY_filter.mask(SANDY_CLAY_filter.gte(0.35)).updateMask(SOIL_Texture.select('sand_0_5').gte(0.45));
//________________________ SILTY_CLAY _____________________________________//
var SILTY_CLAY_filter = SOIL_Texture.select('clay_0_5').rename('SILTY_CLAY');
var SILTY_CLAY = SILTY_CLAY_filter.mask(SILTY_CLAY_filter.gte(0.4)).updateMask(SOIL_Texture.select('RC_silt_0_5').gte(0.4));
//________________________ CLAY _____________________________________//
var CLAY_filter = SOIL_Texture.select('clay_0_5').rename('CLAY');
var CLAY = CLAY_filter.mask(CLAY_filter.gte(0.4)).updateMask(SOIL_Texture.select('RC_silt_0_5').lt(0.4))
                      .updateMask(SOIL_Texture.select('sand_0_5').lte(0.45));
var SAND_EN = Encoder(SAND, 1, 'Sand');
var LOAMY_SAND_EN = Encoder(LOAMY_SAND, 2, 'LOAMY_SAND');
var SANDY_LOAM_EN = Encoder(SANDY_LOAM_merged, 3, 'SANDY_LOAM');
var LOAM_EN = Encoder(LOAM, 4, 'LOAM');
var SILT_LOAM_EN = Encoder(SILT_LOAM_merged, 5, 'SILT_LOAM');
var SILT_EN = Encoder(SILT, 6, 'SILT');
var SANDY_CLAY_LOAM_EN = Encoder(SANDY_CLAY_LOAM, 7, 'SANDY_CLAY_LOAM');
var CLAY_LOAM_EN = Encoder(CLAY_LOAM, 8, 'CLAY_LOAM');
var SILTY_CLAY_LOAM_EN = Encoder(SILTY_CLAY_LOAM, 9, 'SILTY_CLAY_LOAM');
var SANDY_CLAY_EN = Encoder(SANDY_CLAY, 10, 'SANDY_CLAY');
var SILTY_CLAY_EN = Encoder(SILTY_CLAY, 11, 'SILTY_CLAY');
var CLAY_EN = Encoder(CLAY, 12, 'CLAY');
var names = ['SAND','LOAMY SAND','SANDY LOAM', 'LOAM','SILT LOAM','SILT','SANDY CLAY LOAM', 'CLAY LOAM','SILTY CLAY LOAM','SANDY CLAY','SILTY CLAY', 'CLAY'];
var Textures = SAND_EN.blend(SANDY_LOAM_EN).blend(LOAM_EN).blend(SILT_LOAM_EN).blend(SILT_EN).blend(SANDY_CLAY_LOAM_EN).blend(CLAY_EN)
                      .blend(CLAY_LOAM_EN).blend(SILTY_CLAY_LOAM_EN).blend(SANDY_CLAY_EN).blend(SILTY_CLAY_EN).blend(LOAMY_SAND_EN).rename('Texture');
Textures =  Textures.addBands([ksat_mean.first().rename("K_sat"), SOIL_Texture_clay.rename('Clay'), 
                                SOIL_Texture_Sand.rename('Sand'), SOIL_Texture_Silt.rename('Silt')]);
// Panel
var layerProperties = {
  'Soil Texture Classification': {
    name: 'Texture',
    visParams: {min: 1, max: 12, palette: ['#EEB2EE', '#9400D3', '#4B0082', '#0000FF', '#008000', '#00FF00', 
                '#3783FF', '#FFFF00', '#FF7F00', '#FF0000', 'grey', 'black']},
    legend: [
      {'Sand': '#EEB2EE'}, {'LOAMY SAND': '#9400D3'}, {'SANDY LOAM': '#4B0082'},
      {'LOAM': '#0000FF'}, {'SILT LOAM': '#008000'} , {'SILT': '#00FF00'},
      {'SANDY CLAY LOAM': '#3783FF'}, {'CLAY LOAM': '#FFFF00'}, {'SILTY CLAY LOAM': '#FF7F00'},
      {'SANDY CLAY': '#FF0000'}, {'SILTY CLAY': 'grey'} , {'CLAY': 'black'},
    ],
    defaultVisibility: true
  },
  'Mean K_sat': {
    name: 'K_sat',
    visParams: {min: 0, max: 2, palette: ['black', 'red']},
    legend:
        [{'Max K_sat 2 (cm/hr)': 'red'}, {'Min K_sat 0.001 (cm/hr)': 'black'}],
    defaultVisibility: false
  },
  'Mean Clay': {
    name: 'Clay',
    visParams: {min: 0, max: 1, palette: ['black', 'cyan']},
    legend: [
      {'75-100%': '#00FFFF'}, {'50-75%': '#007B72'}, {'25-50%': '#00423D'},
      {'0-25%': '#000000'}
    ],
    defaultVisibility: false
  },
   'Mean Sand': {
    name: 'Sand',
    visParams: {min: 0, max: 1, palette: ['black', 'orange']},
    legend: [
      {'75-100%': 'orange'}, {'50-75%': '#C69000'}, {'25-50%': '#664A00'},
      {'0-25%': '#000000'}
    ],
    defaultVisibility: false
  },
   'Mean Silt': {
    name: 'Silt',
    visParams: {min: 0, max: 1, palette: ['black', 'green']},
    legend: [
      {'75-100%': '#00ff00'}, {'50-75%': '#00aa00'}, {'25-50%': '#005500'},
      {'0-25%': '#000000'}
    ],
    defaultVisibility: false
  }
};
// Some pre-set locations of interest that will be loaded into a pulldown menu.
var locationDict = {
  'US': {lon: -102.16, lat: 40.26, zoom: 5}
};
// Now let's do some overall layout.
// Create a map panel.
var mapPanel = ui.Map();
// Take all tools off the map except the zoom and mapTypeControl tools.
mapPanel.setControlVisibility(
    {all: false, zoomControl: true, mapTypeControl: true});
// Center the map
var defaultLocation = locationDict.US;
mapPanel.setCenter(
    defaultLocation.lon, defaultLocation.lat, defaultLocation.zoom);
// Add these to the interface.
ui.root.widgets().reset([mapPanel]);
ui.root.setLayout(ui.Panel.Layout.flow('horizontal'));
// Add layers to the map and center it.
for (var key in layerProperties) {
  var layer = layerProperties[key];
  var image = Textures.select(layer.name).visualize(layer.visParams);
  //var masked = addZeroAndWaterMask(image, Textures.select(layer.name));
  mapPanel.add(ui.Map.Layer(image, {}, key, layer.defaultVisibility));
}
// Draws black and gray overlays for nodata/water/zero values.
function addZeroAndWaterMask(visualized, original) {
  // Places where there is nodata or water are drawn in gray.
  var water =
      hansen.select('datamask').neq(1).selfMask().visualize({palette: 'gray'});
  // Places where the underlying value is zero are drawn in black.
  var zero = original.eq(0).selfMask().visualize({palette: 'black'});
  // Stack the images, with the gray on top, black next, and the original below.
  return ee.ImageCollection([visualized, zero, water]).mosaic();
}
// Add a title and some explanatory text to a side panel.
var header = ui.Label('Contiguous US Soil Texture Classification', {fontSize: '36px', color: 'red'});
var text = ui.Label(
    'US soil texture classifications (defined by the USDA) derived from 30-m POLARIS Soil datset Over the Contiguous United States',
    {fontSize: '11px'});
var toolPanel = ui.Panel([header, text], 'flow', {width: '300px'});
ui.root.widgets().add(toolPanel);
// Create a hyperlink to an external reference.
var link = ui.Label(
    'Science paper by Chaney et al.', {},
    'https://agupubs.onlinelibrary.wiley.com/doi/full/10.1029/2018WR022797');
var linkPanel = ui.Panel(
    [ui.Label('For more information about POLARIS visit:', {fontWeight: 'bold'}), link]);
toolPanel.add(linkPanel);
// Create a layer selector pulldown.
// The elements of the pulldown are the keys of the layerProperties dictionary.
var selectItems = Object.keys(layerProperties);
// Define the pulldown menu.  Changing the pulldown menu changes the map layer
// and legend.
var layerSelect = ui.Select({
  items: selectItems,
  value: selectItems[0],
  onChange: function(selected) {
    // Loop through the map layers and compare the selected element to the name
    // of the layer. If they're the same, show the layer and set the
    // corresponding legend.  Hide the others.
    mapPanel.layers().forEach(function(element, index) {
      element.setShown(selected == element.getName());
    });
    setLegend(layerProperties[selected].legend);
  }
});
// Add the select to the toolPanel with some explanatory text.
toolPanel.add(ui.Label('Soil Layers', {'font-size': '24px'}));
toolPanel.add(layerSelect);
// Create the legend.
// Define a panel for the legend and give it a tile.
var legendPanel = ui.Panel({
  style:
      {fontWeight: 'bold', fontSize: '10px', margin: '0 0 0 8px', padding: '0'}
});
toolPanel.add(legendPanel);
var legendTitle = ui.Label(
    'Legend',
    {fontWeight: 'bold', fontSize: '10px', margin: '0 0 4px 0', padding: '0'});
legendPanel.add(legendTitle);
// Define an area for the legend key itself.
// This area will be replaced every time the layer pulldown is changed.
var keyPanel = ui.Panel();
legendPanel.add(keyPanel);
function setLegend(legend) {
  // Loop through all the items in a layer's key property,
  // creates the item, and adds it to the key panel.
  keyPanel.clear();
  for (var i = 0; i < legend.length; i++) {
    var item = legend[i];
    var name = Object.keys(item)[0];
    var color = item[name];
    var colorBox = ui.Label('', {
      backgroundColor: color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0'
    });
    // Create the label with the description text.
    var description = ui.Label(name, {margin: '0 0 4px 6px'});
    keyPanel.add(
        ui.Panel([colorBox, description], ui.Panel.Layout.Flow('horizontal')));
  }
}
// Set the initial legend.
setLegend(layerProperties[layerSelect.getValue()].legend);
// Create a visibility checkbox and an opacity slider.
//
// If the checkbox is clicked off, disable the layer pulldown and turn all the
// layers off. Otherwise, enable the select, and turn on the selected layer.
var checkbox = ui.Checkbox({
  label: 'Opacity',
  value: true,
  onChange: function(value) {
    var selected = layerSelect.getValue();
    // Loop through the layers in the mapPanel. For each layer,
    // if the layer's name is the same as the name selected in the layer
    // pulldown, set the visibility of the layer equal to the value of the
    // checkbox. Otherwise, set the visibility to false.
    mapPanel.layers().forEach(function(element, index) {
      element.setShown(selected == element.getName() ? value : false);
    });
    // If the checkbox is on, the layer pulldown should be enabled, otherwise,
    // it's disabled.
    layerSelect.setDisabled(!value);
  }
});
// Create an opacity slider. This tool will change the opacity for each layer.
// That way switching to a new layer will maintain the chosen opacity.
var opacitySlider = ui.Slider({
  min: 0,
  max: 1,
  value: 1,
  step: 0.01,
});
opacitySlider.onSlide(function(value) {
  mapPanel.layers().forEach(function(element, index) {
    element.setOpacity(value);
  });
});
var viewPanel =
    ui.Panel([checkbox, opacitySlider], ui.Panel.Layout.Flow('horizontal'));
toolPanel.add(viewPanel);
// Create the location pulldown.
var locations = Object.keys(locationDict);
var locationSelect = ui.Select({
  items: locations,
  value: locations[0],
  onChange: function(value) {
    var location = locationDict[value];
    mapPanel.setCenter(location.lon, location.lat, location.zoom);
  }
});
var locationPanel = ui.Panel([
  ui.Label('Visit Example Locations', {'font-size': '24px'}), locationSelect
]);
//toolPanel.add(locationPanel);