var roi = ui.import && ui.import("roi", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                114.32253418173079,
                -3.5267143827763525
              ],
              [
                114.95699463094954,
                -3.6637731791247394
              ],
              [
                115.63814697469954,
                -2.489951339008843
              ],
              [
                115.00917968954329,
                -2.355489147561675
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[114.32253418173079, -3.5267143827763525],
          [114.95699463094954, -3.6637731791247394],
          [115.63814697469954, -2.489951339008843],
          [115.00917968954329, -2.355489147561675]]]),
    p2015 = ui.import && ui.import("p2015", "table", {
      "id": "users/putriadinda2501/2015baru"
    }) || ee.FeatureCollection("users/putriadinda2501/2015baru"),
    p2018 = ui.import && ui.import("p2018", "table", {
      "id": "users/putriadinda2501/20181001"
    }) || ee.FeatureCollection("users/putriadinda2501/20181001"),
    p2017 = ui.import && ui.import("p2017", "table", {
      "id": "users/putriadinda2501/20170926"
    }) || ee.FeatureCollection("users/putriadinda2501/20170926"),
    gabungan = ui.import && ui.import("gabungan", "table", {
      "id": "users/putriadinda2501/gabungan"
    }) || ee.FeatureCollection("users/putriadinda2501/gabungan"),
    FIRE = ui.import && ui.import("FIRE", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            114.6402614882032,
            -3.4154927392993284
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            114.5922821333448,
            -3.390645731216263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            114.890268243397,
            -3.269288472527639
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            115.2411674357665,
            -2.9323287758782133
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            114.96854582599657,
            -2.6892878409955676
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([114.6402614882032, -3.4154927392993284]),
            {
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([114.5922821333448, -3.390645731216263]),
            {
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([114.890268243397, -3.269288472527639]),
            {
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([115.2411674357665, -2.9323287758782133]),
            {
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([114.96854582599657, -2.6892878409955676]),
            {
              "system:index": "4"
            })]),
    UNBURN = ui.import && ui.import("UNBURN", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            115.3247466780485,
            -2.69076463024489
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            114.94325258307175,
            -2.785345767042599
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            114.99480611453284,
            -3.0472814473858425
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            114.90927606882416,
            -3.5540654966359173
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            114.69340336539898,
            -3.1856963435427255
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ff3beb",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff3beb */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([115.3247466780485, -2.69076463024489]),
            {
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([114.94325258307175, -2.785345767042599]),
            {
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([114.99480611453284, -3.0472814473858425]),
            {
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([114.90927606882416, -3.5540654966359173]),
            {
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([114.69340336539898, -3.1856963435427255]),
            {
              "system:index": "4"
            })]),
    REGROWTH = ui.import && ui.import("REGROWTH", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            114.84660022812223,
            -3.1331617057285346
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            114.94716756443981,
            -3.0592439828820144
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            114.83898338134712,
            -2.77159288600263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            115.01428428565454,
            -2.6214979291788785
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            115.15568293953054,
            -2.7753348354913245
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([114.84660022812223, -3.1331617057285346]),
            {
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([114.94716756443981, -3.0592439828820144]),
            {
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([114.83898338134712, -2.77159288600263]),
            {
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([115.01428428565454, -2.6214979291788785]),
            {
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([115.15568293953054, -2.7753348354913245]),
            {
              "system:index": "4"
            })]);
// ----------------Memanggil Citra terbaik (c1,c2,c3 = pra ; c4,c5.c6 = pasca)--------------------
var c1 = ee.Image('LANDSAT/LC08/C01/T1_TOA/LC08_118062_20140901'); 
var c2 = ee.Image('LANDSAT/LC08/C01/T1_TOA/LC08_117062_20140825'); 
var c3 = ee.Image('LANDSAT/LC08/C01/T1_TOA/LC08_118062_20180928'); 
var c4 = ee.Image('LANDSAT/LC08/C01/T1_TOA/LC08_117062_20180820'); 
Map.centerObject(roi, 9);
//-----------------------------------------MOSAIC CITRA -----------------------------------------
var mosaic_pre = ee.ImageCollection([c1, c2]).mosaic();
var mosaic_post15 = ee.ImageCollection([c3, c4]).mosaic();
//Map.addLayer(mosaic_pre, {bands: ['B6', 'B5', 'B3'], max: [0.3, 0.4, 0.3]}, 'mosaic_pre');
//Map.addLayer(mosaic_post15, {bands: ['B6', 'B5', 'B3'], max: [0.3, 0.4, 0.3]}, 'mosaic_post15');
//-----------------------------------------CLIP DARATAN---------------------------------------------
var land_pre = mosaic_pre.normalizedDifference(['B3', 'B5']).lt(0);
var land1 = land_pre.selfMask();
//var land_post15 = mosaic_post15.normalizedDifference(['B3', 'B5']).lt(0);
//var land2 = land_post15.selfMask();
//----------------------------------------RASTER2VEKTOR DARATAN---------------------------------------
var classes = land1.reduceToVectors({reducer: ee.Reducer.countEvery(), scale: 30, geometry : roi,maxPixels: 1e8});
var result = ee.FeatureCollection(classes);
//Map.addLayer(result,{palette: ['white']}, 'pre landonly');
//var classes1 = land2.reduceToVectors({reducer: ee.Reducer.countEvery(), scale: 30, geometry : roi,maxPixels: 1e8});
//var result1 = ee.FeatureCollection(classes1);
//Map.addLayer(result1,{palette: ['white']}, 'post15 landonly');
//------------------------------------------CLIP CITRA -------------------------------------------
var clip_pre = (mosaic_pre.clip(roi).clip(result));
  //print('pre', clip_pre);
  Map.addLayer(clip_pre, {bands: ['B6', 'B5', 'B3'], max: [0.3, 0.4, 0.3]}, 'Satellite Imagery 2014');
var clip_post15 = (mosaic_post15.clip(roi).clip(result));
  //print('post15', clip_post15);
  Map.addLayer(clip_post15, {bands: ['B6', 'B5', 'B3'], max: [0.3, 0.4, 0.3]}, 'Satellite Imagery 2018');
//-------------------------------------NORMALIZED BURN RATIO-------------------------------------------
var preNBR = clip_pre.normalizedDifference(['B5', 'B7']);
  print("Pre-fire NBR ", preNBR);
var postNBR15 = clip_post15.normalizedDifference(['B5', 'B7']);
  print("Post-fire NBR 15", postNBR15);
//----------------------- Menghitung perbedaan antara citra pre dan post fire --------------------
// Delta NBR / dNBR
var dNBR_unscaled = preNBR.subtract(postNBR15);
// Skala produk sesuai standart USGS
var dNBR = dNBR_unscaled.multiply(1000);
print("Difference Normalized Burn Ratio ", dNBR);
//==========================================================================================
//                              MENAMBAHKAN LAYER KE PETA
//--------------------------- Burn Ratio Product - Greyscale -------------------------------
var grey = ['white', 'black'];
//Map.addLayer(preNBR, {min: -1, max: 1, palette: grey}, 'Prefire Normalized Burn Ratio');
//Map.addLayer(postNBR15, {min: -1, max: 1, palette: grey}, 'Postfire Normalized Burn Ratio');
//Map.addLayer(dNBR, {min: -2000, max: 2000, palette: grey}, 'dNBR greyscale');
//------------------------- Burn Ratio Product - Klasifikasi ----------------------------
// Menentukan style SLD style interval diskrit untuk diterapkan pada gambar/citra
var sld_intervals =
  '<RasterSymbolizer>' +
    '<ColorMap type="intervals" extended="false" >' +
      '<ColorMapEntry color="#ffffff" quantity="-500" label="-500"/>' +
      '<ColorMapEntry color="#7a8737" quantity="-250" label="-250" />' +
      '<ColorMapEntry color="#acbe4d" quantity="-100" label="-100" />' +
      '<ColorMapEntry color="#0ae042" quantity="100" label="100" />' +
      '<ColorMapEntry color="#fff70b" quantity="270" label="270" />' +
      '<ColorMapEntry color="#ffaf38" quantity="440" label="440" />' +
      '<ColorMapEntry color="#ff641b" quantity="660" label="660" />' +
      '<ColorMapEntry color="#a41fd6" quantity="2000" label="2000" />' +
    '</ColorMap>' +
  '</RasterSymbolizer>';
Map.addLayer(dNBR.sldStyle(sld_intervals), {}, 'Land Cover Change Classification');
// Memisahkan hasil dalam 8 kelas klasifikasi
var thresholds = ee.Image([-1000, -251, -101, 99, 269, 439, 659, 2000]);
var classified = dNBR.lt(thresholds).reduce('sum').toInt();
//==========================================================================================
//                                  STATISTIK BURNED AREA
// Menghitung jumpah pixel di seluruh lapisan
var allpix =  classified.updateMask(classified);  //menutupi seluruh layer
var pixstats = allpix.reduceRegion({
  reducer: ee.Reducer.count(),                  // menghitung pixel di satu lapisan
  geometry: roi,
  scale: 30,
  bestEffort:true,
  });
var allpixels = ee.Number(pixstats.get('sum')); // extract jumlah pixel menjadi angka
// Membuat daftar kosong untuk menyimpan suatu nilai area
var arealist = [];
// Membuat fungsi untuk memperoleh tingkat satu kelas keparahan luka bakar
// Argumen adalah nomor kelas dan nama kelas
var areacount = function(cnr, name) {
 var singleMask =  classified.updateMask(classified.eq(cnr));  // menutupi satu kelas
 var stats = singleMask.reduceRegion({
  reducer: ee.Reducer.count(),               // menghitung jumlah pixel dalam satu kelas
  geometry: roi,
  scale: 30,
  bestEffort:true,
  });
var pix =  ee.Number(stats.get('sum'));
var hect = pix.multiply(900).divide(10000);                // Landsat pixel = 30m x 30m --> 900 sqm
var perc = pix.divide(allpixels).multiply(10000).round().divide(100);   // membentuk presentase area berdasarkan kelas klasifikasi dan dalam bentuk desimal 2 dibelakang koma
arealist.push({Class: name, Pixels: pix, Hectares: hect, Percentage: perc});
};
// Urutan berbeda untuk kelas keparahan 
var names2 = ['NA', 'High Severity', 'Moderate-high Severity',
'Moderate-low Severity', 'Low Severity','Unburned', 'Enhanced Regrowth, Low', 'Enhanced Regrowth, High'];
// Menjalankan fungsi di setiap kelas
for (var i = 0; i < 8; i++) {
  areacount(i, names2[i]);
  }
print('Burned Area by Severity Class', arealist, '--> click list objects for individual classes');
//==========================================================================================
//                                      MENAMBAHKAN LEGENDA
// Mengatur posisi panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }});
// Membentuk judul legenda
var legendTitle = ui.Label({
  value: 'Classification',
  style: {fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }});
// Menambahkan judul di panel
legend.add(legendTitle);
// Menentukan dan mengatur style untuk 1 baris legenda
var makeRow = function(color, name) {
      // Membuat label dengan kotak berwarna
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Mengatur tinggi dan lebar kotak
          padding: '8px',
          margin: '0 0 4px 0'
        }});
      // Membuat label dengan isi teks deskripsi
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // kembali mengatur panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      })};
//  Membuat pallete dengan warna-warna berbeda
var palette =['7a8737', 'acbe4d', '0ae042', 'fff70b', 'ffaf38', 'ff641b', 'a41fd6', 'ffffff'];
// Keterangan dari legenda
var names = ['Enhanced Regrowth, High','Enhanced Regrowth, Low','Unburned', 'Low Severity',
'Moderate-low Severity', 'Moderate-high Severity', 'High Severity', 'NA'];
// Menambahkan warna dan nama
for (var i = 0; i < 8; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
Map.add(legend);
//========================================VALIDATION==============================================
//                          MENAMPILKAN NILAI PIKSEL PADA TIAP SAMPEL
var FIRE = dNBR.reduceRegions({
  collection: (FIRE),
  reducer: ee.Reducer.mean().setOutputs(['FIRE']),
  scale: 10
  });
print('FIRE', FIRE);
var UNBURN = dNBR.reduceRegions({
  collection: (UNBURN),
  reducer: ee.Reducer.mean().setOutputs(['UNBURN']),
  scale: 10
  });
print('UNBURN', UNBURN);
var REGROWTH = dNBR.reduceRegions({
  collection: (REGROWTH),
  reducer: ee.Reducer.mean().setOutputs(['REGROWTH']),
  scale: 10
  });
print('REGROWTH', REGROWTH);
//MENAMPILKAN GRAFIK TIAP KELOMPOK SAMPEL
var grafFIRE = ui.Chart.feature.byFeature({
  features: FIRE,
  yProperties: ['FIRE']}) 
  .setChartType('ColumnChart')
  .setOptions({
      interpolateNulls: false,
      lineWidth: 1,
      pointSize: 3,
      title: 'NILAI PIKSEL API TIAP SAMPEL',
      vAxis: {title: 'DN'},
      hAxis: {title: 'Sampel ke-'}
    });
print(grafFIRE);
var grafUNB = ui.Chart.feature.byFeature({
  features: UNBURN,
  yProperties: ['UNBURN']}) 
  .setChartType('ColumnChart')
  .setOptions({
      interpolateNulls: false,
      lineWidth: 1,
      pointSize: 3,
      title: 'NILAI PIKSEL UNBURN TIAP SAMPEL',
      vAxis: {title: 'DN'},
      hAxis: {title: 'Sampel ke-'}
    });
print(grafUNB);
var grafREG = ui.Chart.feature.byFeature({
  features: REGROWTH,
  yProperties: ['REGROWTH']}) 
  .setChartType('ColumnChart')
  .setOptions({
      interpolateNulls: false,
      lineWidth: 1,
      pointSize: 3,
      title: 'NILAI PIKSEL REGROWTH TIAP SAMPEL',
      vAxis: {title: 'DN'},
      hAxis: {title: 'Sampel ke-'}
    });
print(grafREG);
/*
Export.map.toCloudStorage(dNBR.sldStyle(sld_intervals));
// Export a KML file to Cloud Storage.
Export.table.toCloudStorage({
  collection: FIRE,
  description:'vectorsToCloudStorageExample',
  bucket: 'ee-docs-demos',
  fileNamePrefix: 'exampleTableExport',
  fileFormat: 'KML'
});
//===========================================================================================
//                                       EXPOT HASIL
Export.image.toDrive({
  image: clip_pre,
  description: "clip_pre",
  folder: "Kerja Praktik",
  fileNamePrefix: "clip_pre",
  region: roi, // batas daerah yang akan disimpan
  scale: 30,
  maxPixels: 10e10,
  fileFormat: "GeoTIFF"
});
Export.image.toDrive({
  image: clip_post15,
  description: "clip_post15",
  folder: "Kerja Praktik",
  fileNamePrefix: "clip_post15",
  region: roi, // batas daerah yang akan disimpan
  scale: 30,
  maxPixels: 10e10,
  fileFormat: "GeoTIFF"
});
*/