var gresik = ui.import && ui.import("gresik", "table", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/gresik"
    }) || ee.FeatureCollection("users/Rosmalisa_Dwiyaniek_ITS/gresik"),
    okt15 = ui.import && ui.import("okt15", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt15"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt15"),
    nop15 = ui.import && ui.import("nop15", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_nop15"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_nop15"),
    jul16 = ui.import && ui.import("jul16", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_jul16"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_jul16"),
    agt16 = ui.import && ui.import("agt16", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt16"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt16"),
    agt17 = ui.import && ui.import("agt17", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt17"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt17"),
    sep17 = ui.import && ui.import("sep17", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep17"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep17"),
    agt18 = ui.import && ui.import("agt18", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt18"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt18"),
    sep18 = ui.import && ui.import("sep18", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep18"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep18"),
    okt19 = ui.import && ui.import("okt19", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt19"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt19"),
    nop19 = ui.import && ui.import("nop19", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_nop19"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_nop19"),
    sep20 = ui.import && ui.import("sep20", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep20"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep20"),
    okt20 = ui.import && ui.import("okt20", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt20"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt20"),
    gresikec = ui.import && ui.import("gresikec", "table", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/gresik_kec"
    }) || ee.FeatureCollection("users/Rosmalisa_Dwiyaniek_ITS/gresik_kec");
// KLASIFIKASI TVDI 
// Menentukan style SLD style interval diskrit untuk diterapkan pada gambar/citra
Map.centerObject(gresik, 10.3);
var sld_intervals =
  '<RasterSymbolizer>' +
    '<ColorMap type="intervals" extended="false" >' +
      '<ColorMapEntry color="#ffffff" quantity="-5" label="-5"/>' +
      '<ColorMapEntry color="#7a8737" quantity="0" label="0"/>' +
      '<ColorMapEntry color="#0ae042" quantity="0.2" label="0.2" />' +
      '<ColorMapEntry color="#fff70b" quantity="0.4" label="0.4" />' +
      '<ColorMapEntry color="#ffaf38" quantity="0.6" label="0.6" />' +
      '<ColorMapEntry color="#ff641b" quantity="3" label="3" />' +
    '</ColorMap>' +
  '</RasterSymbolizer>';
// Memisahkan hasil dalam 8 kelas klasifikasi
var thresholds = ee.Image([-6.01,-0.1, 0.19, 0.39, 0.59, 2.99]);
var classified1 = okt15.lt(thresholds).reduce('sum').toInt();
var classified2 = nop15.lt(thresholds).reduce('sum').toInt();
var classified3 = jul16.lt(thresholds).reduce('sum').toInt();
var classified4 = agt16.lt(thresholds).reduce('sum').toInt();
var classified5 = agt17.lt(thresholds).reduce('sum').toInt();
var classified6 = sep17.lt(thresholds).reduce('sum').toInt();
var classified7 = agt18.lt(thresholds).reduce('sum').toInt();
var classified8 = sep18.lt(thresholds).reduce('sum').toInt();
var classified9 = okt19.lt(thresholds).reduce('sum').toInt();
var classified10 = nop19.lt(thresholds).reduce('sum').toInt();
var classified11 = sep20.lt(thresholds).reduce('sum').toInt();
var classified12 = okt20.lt(thresholds).reduce('sum').toInt();
//Menampilkan hasil tvdi
Map.addLayer(okt15.sldStyle(sld_intervals), {}, 'TVDI Okt 2015');
Map.addLayer(nop15.sldStyle(sld_intervals), {}, 'TVDI Nop 2015');
Map.addLayer(jul16.sldStyle(sld_intervals), {}, 'TVDI Jul 2016');
Map.addLayer(agt16.sldStyle(sld_intervals), {}, 'TVDI Agt 2016');
Map.addLayer(agt17.sldStyle(sld_intervals), {}, 'TVDI Agt 2017');
Map.addLayer(sep17.sldStyle(sld_intervals), {}, 'TVDI Sep 2017'); 
Map.addLayer(agt18.sldStyle(sld_intervals), {}, 'TVDI Agt 2018');
Map.addLayer(sep18.sldStyle(sld_intervals), {}, 'TVDI Sep 2018');
Map.addLayer(okt19.sldStyle(sld_intervals), {}, 'TVDI Okt 2019');
Map.addLayer(nop19.sldStyle(sld_intervals), {}, 'TVDI Nop 2019');
Map.addLayer(sep20.sldStyle(sld_intervals), {}, 'TVDI Sep 2020');
Map.addLayer(okt20.sldStyle(sld_intervals), {}, 'TVDI Okt 2020');
//MENGHITUNG LUAS TIAP KELAS DI TIAP CITRA
// Menghitung jumpah pixel di seluruh lapisan
var pixstats1 = classified1.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats2 = classified2.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats3 = classified3.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats4 = classified4.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats5 = classified5.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats6 = classified6.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats7 = classified7.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats8 = classified8.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats9 = classified9.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats10 = classified10.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats11 = classified11.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats12 = classified12.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var allpixels1 = ee.Number(pixstats1.get('sum')); // extract jumlah pixel menjadi angka
var allpixels2 = ee.Number(pixstats2.get('sum'));
var allpixels3 = ee.Number(pixstats3.get('sum'));
var allpixels4 = ee.Number(pixstats4.get('sum'));
var allpixels5 = ee.Number(pixstats5.get('sum'));
var allpixels6 = ee.Number(pixstats6.get('sum'));
var allpixels7 = ee.Number(pixstats7.get('sum'));
var allpixels8 = ee.Number(pixstats8.get('sum'));
var allpixels9 = ee.Number(pixstats9.get('sum'));
var allpixels10 = ee.Number(pixstats10.get('sum'));
var allpixels11 = ee.Number(pixstats11.get('sum'));
var allpixels12 = ee.Number(pixstats12.get('sum'));
// Membuat daftar kosong untuk menyimpan suatu nilai area
var arealist1 = [];
var arealist2 = [];
var arealist3 = [];
var arealist4 = [];
var arealist5 = [];
var arealist6 = [];
var arealist7 = [];
var arealist8 = [];
var arealist9 = [];
var arealist10 = [];
var arealist11 = [];
var arealist12 = [];
// Membuat fungsi untuk memperoleh tingkat satu kelas keparahan luka bakar
// Argumen adalah nomor kelas dan nama kelas
var areacount1 = function(cnr, name) {
  var singleMask =  classified1.updateMask(classified1.eq(cnr));
  var stats = singleMask.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix =  ee.Number(stats.get('sum'));
  var hect = pix.multiply(900).divide(10000);                
  var perc = pix.divide(allpixels1).multiply(10000).round().divide(100);   
             arealist1.push({Class: name, Pixels: pix, Hectares: hect, Percentage: perc})};
var areacount2 = function(cnr, name) {
  var singleMask2 =  classified2.updateMask(classified2.eq(cnr));
  var stats2 = singleMask2.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix2 =  ee.Number(stats2.get('sum'));
  var hect2 = pix2.multiply(900).divide(10000);                
  var perc2 = pix2.divide(allpixels2).multiply(10000).round().divide(100);   
             arealist2.push({Class: name, Pixels: pix2, Hectares: hect2, Percentage: perc2})};
var areacount3 = function(cnr, name) {
  var singleMask3 =  classified3.updateMask(classified3.eq(cnr));
  var stats3 = singleMask3.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix3 =  ee.Number(stats3.get('sum'));
  var hect3 = pix3.multiply(900).divide(10000);                
  var perc3 = pix3.divide(allpixels3).multiply(10000).round().divide(100);   
             arealist3.push({Class: name, Pixels: pix3, Hectares: hect3, Percentage: perc3})};
var areacount4 = function(cnr, name) {
  var singleMask4 =  classified4.updateMask(classified4.eq(cnr));
  var stats4 = singleMask4.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix4 =  ee.Number(stats4.get('sum'));
  var hect4 = pix4.multiply(900).divide(10000);                
  var perc4 = pix4.divide(allpixels4).multiply(10000).round().divide(100);   
             arealist4.push({Class: name, Pixels: pix4, Hectares: hect4, Percentage: perc4})};
var areacount5 = function(cnr, name) {
  var singleMask5 =  classified5.updateMask(classified5.eq(cnr));
  var stats5 = singleMask5.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix5 =  ee.Number(stats5.get('sum'));
  var hect5 = pix5.multiply(900).divide(10000);                
  var perc5 = pix5.divide(allpixels5).multiply(10000).round().divide(100);   
             arealist5.push({Class: name, Pixels: pix5, Hectares: hect5, Percentage: perc5})};
var areacount6 = function(cnr, name) {
  var singleMask6 =  classified6.updateMask(classified6.eq(cnr));
  var stats6 = singleMask6.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix6 =  ee.Number(stats6.get('sum'));
  var hect6 = pix6.multiply(900).divide(10000);                
  var perc6 = pix6.divide(allpixels6).multiply(10000).round().divide(100);   
             arealist6.push({Class: name, Pixels: pix6, Hectares: hect6, Percentage: perc6})};
var areacount7 = function(cnr, name) {
  var singleMask7 =  classified7.updateMask(classified7.eq(cnr));
  var stats7 = singleMask7.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix7 =  ee.Number(stats7.get('sum'));
  var hect7 = pix7.multiply(900).divide(10000);                
  var perc7 = pix7.divide(allpixels7).multiply(10000).round().divide(100);   
             arealist7.push({Class: name, Pixels: pix7, Hectares: hect7, Percentage: perc7})};
var areacount8 = function(cnr, name) {
  var singleMask8 =  classified8.updateMask(classified8.eq(cnr));
  var stats8 = singleMask8.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix8 =  ee.Number(stats8.get('sum'));
  var hect8 = pix8.multiply(900).divide(10000);                
  var perc8 = pix8.divide(allpixels8).multiply(10000).round().divide(100);   
             arealist8.push({Class: name, Pixels: pix8, Hectares: hect8, Percentage: perc8})};
var areacount9 = function(cnr, name) {
  var singleMask9 =  classified9.updateMask(classified9.eq(cnr));
  var stats9 = singleMask9.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix9 =  ee.Number(stats9.get('sum'));
  var hect9 = pix9.multiply(900).divide(10000);                
  var perc9 = pix9.divide(allpixels9).multiply(10000).round().divide(100);   
             arealist9.push({Class: name, Pixels: pix9, Hectares: hect9, Percentage: perc9})};
var areacount10 = function(cnr, name) {
  var singleMask10 =  classified10.updateMask(classified10.eq(cnr));
  var stats10 = singleMask10.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix10 =  ee.Number(stats10.get('sum'));
  var hect10 = pix10.multiply(900).divide(10000);                
  var perc10 = pix10.divide(allpixels10).multiply(10000).round().divide(100);   
             arealist10.push({Class: name, Pixels: pix10, Hectares: hect10, Percentage: perc10})};
var areacount11 = function(cnr, name) {
  var singleMask11 =  classified11.updateMask(classified11.eq(cnr));
  var stats11 = singleMask11.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix11 =  ee.Number(stats11.get('sum'));
  var hect11 = pix11.multiply(900).divide(10000);                
  var perc11 = pix11.divide(allpixels11).multiply(10000).round().divide(100);   
             arealist11.push({Class: name, Pixels: pix11, Hectares: hect11, Percentage: perc11})};
var areacount12 = function(cnr, name) {
  var singleMask12 =  classified12.updateMask(classified12.eq(cnr));
  var stats12 = singleMask12.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix12 =  ee.Number(stats12.get('sum'));
  var hect12 = pix12.multiply(900).divide(10000);                
  var perc12 = pix12.divide(allpixels12).multiply(10000).round().divide(100);   
             arealist12.push({Class: name, Pixels: pix12, Hectares: hect12, Percentage: perc12})};
// Urutan berbeda untuk kelas keparahan 
var names2 = [ 'NA', 'Kering','Agak Kering', 'Normal', '  Agak Basah','Basah'];
// Menjalankan fungsi di setiap kelas
for (var i = 0; i < 6; i++) {areacount1(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount2(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount3(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount4(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount5(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount6(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount7(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount8(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount9(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount10(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount11(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount12(i, names2[i]);}
print('Klasifikasi Indeks Kekeringan okt2015', arealist1);
print('Klasifikasi Indeks Kekeringan nop2015', arealist2);
print('Klasifikasi Indeks Kekeringan jul2016', arealist3);
print('Klasifikasi Indeks Kekeringan agt2016', arealist4);
print('Klasifikasi Indeks Kekeringan agt2017', arealist5);
print('Klasifikasi Indeks Kekeringan sep2017', arealist6);
print('Klasifikasi Indeks Kekeringan agt2018', arealist7);
print('Klasifikasi Indeks Kekeringan sep2018', arealist8);
print('Klasifikasi Indeks Kekeringan okt2019', arealist9);
print('Klasifikasi Indeks Kekeringan nop2019', arealist10);
print('Klasifikasi Indeks Kekeringan sep2020', arealist11);
print('Klasifikasi Indeks Kekeringan okt2020', arealist12);
//==========================================================================================
//MENAMPILKAN SHP BATAS KECAMATAN
// Paint all the polygon edges with the same number and width, display.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: gresikec,
  color: 1,
  width: 1});
Map.addLayer(outline, {palette: '000000'}, 'Batas Kecamatan');
var text = require('users/gena/packages:text');
var shp = ee.FeatureCollection(gresikec);
//Map.addLayer(shp, {},'Roads Layer');
var Scale = Map.getScale()*0.3
var labels = shp.map(function(feat){
  feat = ee.Feature(feat)
  var name = ee.String (feat.get("WADMKC"))
  var centroid = feat.geometry().centroid()
  var t = text.draw(name, centroid,Scale,{
    fontSize: 24,
    textColor:'black',
    OutlineWidth:1,
    OutlineColor:'red'})
  return t})
  var Labels_Final = ee.ImageCollection(labels)
  Map.addLayer(Labels_Final,{},"Nama Kecamatan")
//==========================================================================================
//MENAMBAHKAN LEGENDA
// Mengatur posisi panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }});
// Membentuk judul legenda
var legendTitle = ui.Label({
  value: 'Tingkat Kekeringan',
  style: {fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }});
// Menambahkan judul di panel
legend.add(legendTitle);
// Menentukan dan mengatur style untuk 1 baris legenda
var makeRow = function(color, name) {
      // Membuat label dengan kotak berwarna
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Mengatur tinggi dan lebar kotak
          padding: '8px',
          margin: '0 0 4px 0'
        }});
      // Membuat label dengan isi teks deskripsi
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // kembali mengatur panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      })};
//  Membuat pallete dengan warna-warna berbeda
var palette =['7a8737', '0ae042', 'fff70b', 'ffaf38', 'ff641b', 'ffffff'];
// Keterangan dari legenda
var names = ['Basah','Agak Basah','Normal', 'Agak Kering', 'Kering', 'NA'];
// Menambahkan warna dan nama
for (var i = 0; i < 6; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
Map.add(legend);
//=======================================================================================
//MEMBUAT TAMPILAN APPS
//Add the sidebar to the ui.root.
var title = ui.Label({
  value: 'Pola Persebaran Kekeringan Lahan Berbasis Time Series di Kabupaten Gresik, Jawa Timur',
  style: {fontSize: '22px', fontWeight: 'bold'}});
var sidebar = ui.Panel({widgets: [title], style: {width: '350px'}});
var lon = ui.Label();
var lat = ui.Label();
ui.root.add(sidebar);
var abstract = ui.Label({
  value: 'Kabupaten Gresik adalah salah satu kabupaten dengan tingkat kekeringan yang cukup parah di Jawa Timur. Oleh karena itu penelitian ini bertujuan untuk mengidentifikasi dan mengetahui pola persebaran kekeringan yang terjadi di Kabupaten Gresik dengan memanfaatkan data Citra Satelit Landsat 8 secara time series dari tahun 2015-2020. Dengan dilakukannya identifikasi secara berkala, dapat diketahui area mana saja yang terdampak sehingga hasil dari penelitian ini dapat digunakan sebagai tindakan preventif kedepannya dalam mengatasi bencana kekeringan di Kabupaten Gresik.',
  style: {fontSize: '12px'}});
sidebar.add(abstract);
var abstract2 = ui.Label({
  value: 'Berikut merupakan hasil perhitungan luasan lahan dengan tingkat 5 tingkat kekeringan di Kabupaten Gresik tahun 2015-2020 :',
  style: {fontSize: '12px'}});
sidebar.add(abstract2);
//GRAFIK LAHAN KERING
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '22 Oktober 2015'},  {v: 59633}]},
         {c: [{v: '23 Nopember 2015'}, {v: 64710}]},
         {c: [{v: '04 Juli 2016'},     {v: 42783}]},
         {c: [{v: '21 Agustus 2016'},  {v: 48043}]},
         {c: [{v: '24 Agustus 2017'},  {v: 52689}]},
         {c: [{v: '09 September 2017'},{v: 54503}]},
         {c: [{v: '11 Agustus 2018'},  {v: 53913}]},
         {c: [{v: '28 September 2018'},{v: 57714}]},
         {c: [{v: '01 Oktober 2019'},  {v: 57605}]},
         {c: [{v: '18 Nopember 2019'}, {v: 66261}]},
         {c: [{v: '17 September 2020'},{v: 51993}]},
         {c: [{v: '03 Nopember 2020'}, {v: 49324}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Luasan Lahan Kering',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Waktu',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN AGAK KERING
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '22 Oktober 2015'},  {v: 8973.72}]},
         {c: [{v: '23 Nopember 2015'}, {v: 5737.59}]},
         {c: [{v: '04 Juli 2016'},     {v: 9613.44}]},
         {c: [{v: '21 Agustus 2016'},  {v: 10319.04}]},
         {c: [{v: '24 Agustus 2017'},  {v: 6639.75}]},
         {c: [{v: '09 September 2017'},{v: 6763.32}]},
         {c: [{v: '11 Agustus 2018'},  {v: 8316.54}]},
         {c: [{v: '28 September 2018'},{v: 8696.79}]},
         {c: [{v: '01 Oktober 2019'},  {v: 8715.06}]},
         {c: [{v: '18 Nopember 2019'}, {v: 8808.57}]},
         {c: [{v: '17 September 2020'},{v: 8402.13}]},
         {c: [{v: '03 Nopember 2020'}, {v: 9070.74}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Luasan Lahan Agak Kering',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Waktu',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN NORMAL
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '22 Oktober 2015'},  {v: 6756.21}]},
         {c: [{v: '23 Nopember 2015'}, {v: 4528.26}]},
         {c: [{v: '04 Juli 2016'},     {v: 10717.74}]},
         {c: [{v: '21 Agustus 2016'},  {v: 15031.44}]},
         {c: [{v: '24 Agustus 2017'},  {v: 6453.99}]},
         {c: [{v: '09 September 2017'},{v: 6743.61}]},
         {c: [{v: '11 Agustus 2018'},  {v: 6621.21}]},
         {c: [{v: '28 September 2018'},{v: 6184.8}]},
         {c: [{v: '01 Oktober 2019'},  {v: 7038.54}]},
         {c: [{v: '18 Nopember 2019'}, {v: 5927.85}]},
         {c: [{v: '17 September 2020'},{v: 7508.25}]},
         {c: [{v: '03 Nopember 2020'}, {v: 7850.7}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Luasan Lahan Normal',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Waktu',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN AGAK BASAH
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '22 Oktober 2015'},  {v: 7570.53}]},
         {c: [{v: '23 Nopember 2015'}, {v: 12723.03}]},
         {c: [{v: '04 Juli 2016'},     {v: 30898.98}]},
         {c: [{v: '21 Agustus 2016'},  {v: 13366.89}]},
         {c: [{v: '24 Agustus 2017'},  {v: 19817.01}]},
         {c: [{v: '09 September 2017'},{v: 15702.21}]},
         {c: [{v: '11 Agustus 2018'},  {v: 15641.37}]},
         {c: [{v: '28 September 2018'},{v: 8446.05}]},
         {c: [{v: '01 Oktober 2019'},  {v: 9757.17}]},
         {c: [{v: '18 Nopember 2019'}, {v: 12210.75}]},
         {c: [{v: '17 September 2020'},{v: 17588.07}]},
         {c: [{v: '03 Nopember 2020'}, {v: 15509.25}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Luasan Lahan Agak Basah',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Waktu',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN BASAH
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '22 Oktober 2015'},  {v: 21237.48}]},
         {c: [{v: '23 Nopember 2015'}, {v: 16471.98}]},
         {c: [{v: '04 Juli 2016'},     {v: 10152.99}]},
         {c: [{v: '21 Agustus 2016'},  {v: 17409.06}]},
         {c: [{v: '24 Agustus 2017'},  {v: 18570.87}]},
         {c: [{v: '09 September 2017'},{v: 20456.28}]},
         {c: [{v: '11 Agustus 2018'},  {v: 19678.86}]},
         {c: [{v: '28 September 2018'},{v: 23128.56}]},
         {c: [{v: '01 Oktober 2019'},  {v: 21054.78}]},
         {c: [{v: '18 Nopember 2019'}, {v: 10962.45}]},
         {c: [{v: '17 September 2020'},{v: 18679.41}]},
         {c: [{v: '03 Nopember 2020'}, {v: 22415.31}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Luasan Lahan Basah',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Waktu',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//KETERANGAN
var ket = ui.Label({
  value: 'Disusun Oleh :',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Rosmalisa Dwiyaniek (03311740000014)',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Dosen Pembimbing :',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Prof. Dr. Ir. Bangun Muljo Sukojo, DEA., DESS',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Dr. Filsa Bioresita, ST., MT',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: ' ',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'DEPATEMEN TEKNIK GEOMATIKA',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'INSTITUT TEKNOLOGI SEPULUH NOPEMBER',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'SURABAYA',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: '2021',
  style: {fontSize: '12px'}});
sidebar.add(ket);