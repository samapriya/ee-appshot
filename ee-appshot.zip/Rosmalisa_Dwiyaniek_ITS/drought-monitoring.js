var gresik = ui.import && ui.import("gresik", "table", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/gresik"
    }) || ee.FeatureCollection("users/Rosmalisa_Dwiyaniek_ITS/gresik"),
    okt15 = ui.import && ui.import("okt15", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt15"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt15"),
    nop15 = ui.import && ui.import("nop15", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_nop15"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_nop15"),
    jul16 = ui.import && ui.import("jul16", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_jul16"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_jul16"),
    agt16 = ui.import && ui.import("agt16", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt16"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt16"),
    agt17 = ui.import && ui.import("agt17", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt17"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt17"),
    sep17 = ui.import && ui.import("sep17", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep17"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep17"),
    agt18 = ui.import && ui.import("agt18", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt18"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_agt18"),
    sep18 = ui.import && ui.import("sep18", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep18"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep18"),
    okt19 = ui.import && ui.import("okt19", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt19"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt19"),
    nop19 = ui.import && ui.import("nop19", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_nop19"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_nop19"),
    sep20 = ui.import && ui.import("sep20", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep20"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_sep20"),
    okt20 = ui.import && ui.import("okt20", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt20"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt20"),
    gresikec = ui.import && ui.import("gresikec", "table", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/gresik_kec"
    }) || ee.FeatureCollection("users/Rosmalisa_Dwiyaniek_ITS/gresik_kec"),
    sampelhujan = ui.import && ui.import("sampelhujan", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            112.52598218547836,
            -7.1739301937724615
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.49517628278113,
            -7.247721537894545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.42994495953894,
            -7.288929780488393
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.54045096376456,
            -7.362394389681815
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.5710500362054,
            -7.284046072074866
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.60160576130306,
            -7.332316722425936
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.51714836384213,
            -7.305755739996642
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.5528002436847,
            -7.312098792234345
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.4966912281692,
            -7.366274470708288
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.54117091889403,
            -7.216787696172813
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.56033768776398,
            -7.146131288543058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.58060841567628,
            -7.127690457176457
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.62730031020753,
            -7.153625483359297
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.5765127025346,
            -7.205975723243692
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.5856831602817,
            -7.172630292672662
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.53302813880826,
            -7.1240043101181225
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.57945128265844,
            -7.063521597037756
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.58502919526563,
            -7.076382433159385
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.5390898363899,
            -7.038546896488033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.56009459007365,
            -7.040812694255547
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.44065975189795,
            -6.966404915533724
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.42175783711198,
            -6.958344293783489
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.46717604361366,
            -6.944475506891918
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.56213730000461,
            -6.918224988900456
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.55857166625087,
            -6.9966150936339995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.57826235103911,
            -6.90102623167163
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.44232131380849,
            -6.977564342040741
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.46334983248525,
            -6.992558423321979
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.39912756574698,
            -6.978977494430888
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            112.64102784321402,
            -7.037257107051886
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.MultiPoint(
        [[112.52598218547836, -7.1739301937724615],
         [112.49517628278113, -7.247721537894545],
         [112.42994495953894, -7.288929780488393],
         [112.54045096376456, -7.362394389681815],
         [112.5710500362054, -7.284046072074866],
         [112.60160576130306, -7.332316722425936],
         [112.51714836384213, -7.305755739996642],
         [112.5528002436847, -7.312098792234345],
         [112.4966912281692, -7.366274470708288],
         [112.54117091889403, -7.216787696172813],
         [112.56033768776398, -7.146131288543058],
         [112.58060841567628, -7.127690457176457],
         [112.62730031020753, -7.153625483359297],
         [112.5765127025346, -7.205975723243692],
         [112.5856831602817, -7.172630292672662],
         [112.53302813880826, -7.1240043101181225],
         [112.57945128265844, -7.063521597037756],
         [112.58502919526563, -7.076382433159385],
         [112.5390898363899, -7.038546896488033],
         [112.56009459007365, -7.040812694255547],
         [112.44065975189795, -6.966404915533724],
         [112.42175783711198, -6.958344293783489],
         [112.46717604361366, -6.944475506891918],
         [112.56213730000461, -6.918224988900456],
         [112.55857166625087, -6.9966150936339995],
         [112.57826235103911, -6.90102623167163],
         [112.44232131380849, -6.977564342040741],
         [112.46334983248525, -6.992558423321979],
         [112.39912756574698, -6.978977494430888],
         [112.64102784321402, -7.037257107051886]]);
// KLASIFIKASI TVDI 
// Menentukan style SLD style interval diskrit untuk diterapkan pada gambar/citra
Map.centerObject(gresik, 10.3);
var sld_intervals = 
  '<RasterSymbolizer>' +
    '<ColorMap type="intervals" extended="false" >' +
      '<ColorMapEntry color="#ffffff" quantity="-5" label="-5"/>' +
      '<ColorMapEntry color="#7a8737" quantity="0" label="0"/>' +
      '<ColorMapEntry color="#0ae042" quantity="0.2" label="0.2" />' +
      '<ColorMapEntry color="#fff70b" quantity="0.4" label="0.4" />' +
      '<ColorMapEntry color="#ffaf38" quantity="0.6" label="0.6" />' +
      '<ColorMapEntry color="#ff641b" quantity="3" label="3" />' +
    '</ColorMap>' +
  '</RasterSymbolizer>';
// Memisahkan hasil dalam 8 kelas klasifikasi
var thresholds = ee.Image([-6.01,-0.1, 0.19, 0.39, 0.59, 2.99]);
var classified1 = okt15.lt(thresholds).reduce('sum').toInt();
var classified2 = nop15.lt(thresholds).reduce('sum').toInt();
var classified3 = jul16.lt(thresholds).reduce('sum').toInt();
var classified4 = agt16.lt(thresholds).reduce('sum').toInt();
var classified5 = agt17.lt(thresholds).reduce('sum').toInt();
var classified6 = sep17.lt(thresholds).reduce('sum').toInt();
var classified7 = agt18.lt(thresholds).reduce('sum').toInt();
var classified8 = sep18.lt(thresholds).reduce('sum').toInt();
var classified9 = okt19.lt(thresholds).reduce('sum').toInt();
var classified10 = nop19.lt(thresholds).reduce('sum').toInt();
var classified11 = sep20.lt(thresholds).reduce('sum').toInt();
var classified12 = okt20.lt(thresholds).reduce('sum').toInt();
//Menampilkan hasil tvdi
Map.addLayer(okt15.sldStyle(sld_intervals), {}, 'TVDI Oct 2015');
Map.addLayer(nop15.sldStyle(sld_intervals), {}, 'TVDI Nov 2015');
Map.addLayer(jul16.sldStyle(sld_intervals), {}, 'TVDI Jul 2016');
Map.addLayer(agt16.sldStyle(sld_intervals), {}, 'TVDI Aug 2016');
Map.addLayer(agt17.sldStyle(sld_intervals), {}, 'TVDI Aug 2017');
Map.addLayer(sep17.sldStyle(sld_intervals), {}, 'TVDI Sep 2017'); 
Map.addLayer(agt18.sldStyle(sld_intervals), {}, 'TVDI Aug 2018');
Map.addLayer(sep18.sldStyle(sld_intervals), {}, 'TVDI Sep 2018');
Map.addLayer(okt19.sldStyle(sld_intervals), {}, 'TVDI Oct 2019');
Map.addLayer(nop19.sldStyle(sld_intervals), {}, 'TVDI Nov 2019');
Map.addLayer(sep20.sldStyle(sld_intervals), {}, 'TVDI Sep 2020');
Map.addLayer(okt20.sldStyle(sld_intervals), {}, 'TVDI Oct 2020');
//==========================================================================================
//MENAMPILKAN SHP BATAS KECAMATAN
// Paint all the polygon edges with the same number and width, display.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: gresikec,
  color: 1,
  width: 1});
Map.addLayer(outline, {palette: '000000'}, 'District Administration');
var text = require('users/gena/packages:text');
var shp = ee.FeatureCollection(gresikec);
//Map.addLayer(shp, {},'Roads Layer');
var Scale = Map.getScale()*0.3
var labels = shp.map(function(feat){
  feat = ee.Feature(feat)
  var name = ee.String (feat.get("WADMKC"))
  var centroid = feat.geometry().centroid()
  var t = text.draw(name, centroid,Scale,{
    fontSize: 24,
    textColor:'black',
    OutlineWidth:1,
    OutlineColor:'red'})
  return t})
  var Labels_Final = ee.ImageCollection(labels)
  Map.addLayer(Labels_Final,{},"District Name")
//==========================================================================================
//MENAMBAHKAN LEGENDA
// Mengatur posisi panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }});
// Membentuk judul legenda
var legendTitle = ui.Label({
  value: 'Drought Levels',
  style: {fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }});
// Menambahkan judul di panel
legend.add(legendTitle);
// Menentukan dan mengatur style untuk 1 baris legenda
var makeRow = function(color, name) {
      // Membuat label dengan kotak berwarna
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Mengatur tinggi dan lebar kotak
          padding: '8px',
          margin: '0 0 4px 0'
        }});
      // Membuat label dengan isi teks deskripsi
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // kembali mengatur panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      })};
//  Membuat pallete dengan warna-warna berbeda
var palette =['7a8737', '0ae042', 'fff70b', 'ffaf38', 'ff641b', 'ffffff'];
// Keterangan dari legenda
var names = ['Wet','A Bit Wet','Normal', 'A Bit Dry', 'Dry', 'NA'];
// Menambahkan warna dan nama
for (var i = 0; i < 6; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
Map.add(legend);
//=======================================================================================
//MEMBUAT TAMPILAN APPS
//Add the sidebar to the ui.root.
var title = ui.Label({
  value: 'Drought Monitoring in Gresik Regency East Java using Satellite Image Time Series and Google Earth Engine',
  style: {fontSize: '22px', fontWeight: 'bold'}});
var sidebar = ui.Panel({widgets: [title], style: {width: '350px'}});
var lon = ui.Label();
var lat = ui.Label();
ui.root.add(sidebar);
var abstract = ui.Label({
  value: 'Gresik Regency is one of the districts with severe drought level in East Java. This research was conducted to periodically check or time series of droughts in Gresik Regency by utilizing Landsat 8 Satellite Imagery data.',
  style: {fontSize: '12px'}});
sidebar.add(abstract);
var abstract2 = ui.Label({
  value: 'This is the result of the calculation of land area with 5 levels of drought in Gresik Regency in 2015-2020 :',
  style: {fontSize: '12px'}});
sidebar.add(abstract2);
//GRAFIK LAHAN KERING
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '22 October 2015'},  {v: 59633}]},
         {c: [{v: '23 November 2015'}, {v: 64710}]},
         {c: [{v: '04 Juli 2016'},     {v: 42783}]},
         {c: [{v: '21 Agustus 2016'},  {v: 48043}]},
         {c: [{v: '24 Agustus 2017'},  {v: 52689}]},
         {c: [{v: '09 September 2017'},{v: 54503}]},
         {c: [{v: '11 Agustus 2018'},  {v: 53913}]},
         {c: [{v: '28 September 2018'},{v: 57714}]},
         {c: [{v: '01 October 2019'},  {v: 57605}]},
         {c: [{v: '18 November 2019'}, {v: 66261}]},
         {c: [{v: '17 September 2020'},{v: 51993}]},
         {c: [{v: '03 October 2020'}, {v: 49324}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Dry Land Area',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Time',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN AGAK KERING
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '22 October 2015'},  {v: 8973.72}]},
         {c: [{v: '23 November 2015'}, {v: 5737.59}]},
         {c: [{v: '04 July 2016'},     {v: 9613.44}]},
         {c: [{v: '21 August 2016'},  {v: 10319.04}]},
         {c: [{v: '24 August 2017'},  {v: 6639.75}]},
         {c: [{v: '09 September 2017'},{v: 6763.32}]},
         {c: [{v: '11 August 2018'},  {v: 8316.54}]},
         {c: [{v: '28 September 2018'},{v: 8696.79}]},
         {c: [{v: '01 October 2019'},  {v: 8715.06}]},
         {c: [{v: '18 November 2019'}, {v: 8808.57}]},
         {c: [{v: '17 September 2020'},{v: 8402.13}]},
         {c: [{v: '03 October 2020'}, {v: 9070.74}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'A Bit Dry Land Area',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Time',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN NORMAL
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '22 October 2015'},  {v: 6756.21}]},
         {c: [{v: '23 November 2015'}, {v: 4528.26}]},
         {c: [{v: '04 July 2016'},     {v: 10717.74}]},
         {c: [{v: '21 August 2016'},  {v: 15031.44}]},
         {c: [{v: '24 August 2017'},  {v: 6453.99}]},
         {c: [{v: '09 September 2017'},{v: 6743.61}]},
         {c: [{v: '11 August 2018'},  {v: 6621.21}]},
         {c: [{v: '28 September 2018'},{v: 6184.8}]},
         {c: [{v: '01 October 2019'},  {v: 7038.54}]},
         {c: [{v: '18 November 2019'}, {v: 5927.85}]},
         {c: [{v: '17 September 2020'},{v: 7508.25}]},
         {c: [{v: '03 October 2020'}, {v: 7850.7}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Normal Land Area',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Time',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN AGAK BASAH
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '22 October 2015'},  {v: 7570.53}]},
         {c: [{v: '23 November 2015'}, {v: 12723.03}]},
         {c: [{v: '04 July 2016'},     {v: 30898.98}]},
         {c: [{v: '21 August 2016'},  {v: 13366.89}]},
         {c: [{v: '24 August 2017'},  {v: 19817.01}]},
         {c: [{v: '09 September 2017'},{v: 15702.21}]},
         {c: [{v: '11 August 2018'},  {v: 15641.37}]},
         {c: [{v: '28 September 2018'},{v: 8446.05}]},
         {c: [{v: '01 October 2019'},  {v: 9757.17}]},
         {c: [{v: '18 November 2019'}, {v: 12210.75}]},
         {c: [{v: '17 September 2020'},{v: 17588.07}]},
         {c: [{v: '03 October 2020'}, {v: 15509.25}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'A Wet Land Area',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Time',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN BASAH
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '22 October 2015'},  {v: 21237.48}]},
         {c: [{v: '23 November 2015'}, {v: 16471.98}]},
         {c: [{v: '04 July 2016'},     {v: 10152.99}]},
         {c: [{v: '21 August 2016'},  {v: 17409.06}]},
         {c: [{v: '24 August 2017'},  {v: 18570.87}]},
         {c: [{v: '09 September 2017'},{v: 20456.28}]},
         {c: [{v: '11 August 2018'},  {v: 19678.86}]},
         {c: [{v: '28 September 2018'},{v: 23128.56}]},
         {c: [{v: '01 October 2019'},  {v: 21054.78}]},
         {c: [{v: '18 November 2019'}, {v: 10962.45}]},
         {c: [{v: '17 September 2020'},{v: 18679.41}]},
         {c: [{v: '03 October 2020'}, {v: 22415.31}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Wet Land Area',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Time',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//KETERANGAN
var ket = ui.Label({
  value: 'Arranged by:',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Rosmalisa Dwiyaniek (03311740000014)',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Supervisor :',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Prof. Dr. Ir. Bangun Muljo Sukojo, DEA., DESS',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Dr. Filsa Bioresita, ST., MT',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: ' ',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'GEOMATICS ENGINEERING',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'SEPULUH NOPEMBER INSTITUTE OF TECHNOLOGY',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'SURABAYA',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: '2021',
  style: {fontSize: '12px'}});
sidebar.add(ket);