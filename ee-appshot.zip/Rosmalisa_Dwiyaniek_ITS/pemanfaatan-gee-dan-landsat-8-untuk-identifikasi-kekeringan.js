var gresik = ui.import && ui.import("gresik", "table", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/gresik"
    }) || ee.FeatureCollection("users/Rosmalisa_Dwiyaniek_ITS/gresik"),
    okt19 = ui.import && ui.import("okt19", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt19"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_okt19"),
    nop19 = ui.import && ui.import("nop19", "image", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/tvdi_nop19"
    }) || ee.Image("users/Rosmalisa_Dwiyaniek_ITS/tvdi_nop19"),
    gresikec = ui.import && ui.import("gresikec", "table", {
      "id": "users/Rosmalisa_Dwiyaniek_ITS/gresik_kec"
    }) || ee.FeatureCollection("users/Rosmalisa_Dwiyaniek_ITS/gresik_kec");
// KLASIFIKASI TVDI  
// Menentukan style SLD style interval diskrit untuk diterapkan pada gambar/citra
Map.centerObject(gresik, 10.3);
var sld_intervals =
  '<RasterSymbolizer>' +
    '<ColorMap type="intervals" extended="false" >' +
      '<ColorMapEntry color="#ffffff" quantity="-5" label="-5"/>' +
      '<ColorMapEntry color="#7a8737" quantity="0" label="0"/>' +
      '<ColorMapEntry color="#0ae042" quantity="0.2" label="0.2" />' +
      '<ColorMapEntry color="#fff70b" quantity="0.4" label="0.4" />' +
      '<ColorMapEntry color="#ffaf38" quantity="0.6" label="0.6" />' +
      '<ColorMapEntry color="#ff641b" quantity="3" label="3" />' +
    '</ColorMap>' +
  '</RasterSymbolizer>';
// Memisahkan hasil dalam 8 kelas klasifikasi
var thresholds = ee.Image([-6.01,-0.1, 0.19, 0.39, 0.59, 2.99]);
var classified9 = okt19.lt(thresholds).reduce('sum').toInt();
var classified10 = nop19.lt(thresholds).reduce('sum').toInt();
//Menampilkan hasil tvdi
Map.addLayer(okt19.sldStyle(sld_intervals), {}, 'TVDI Okt 2019');
Map.addLayer(nop19.sldStyle(sld_intervals), {}, 'TVDI Nop 2019');
//MENGHITUNG LUAS TIAP KELAS DI TIAP CITRA
// Menghitung jumpah pixel di seluruh lapisan
var pixstats9 = classified9.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var pixstats10 = classified10.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
var allpixels9 = ee.Number(pixstats9.get('sum'));  // extract jumlah pixel menjadi angka
var allpixels10 = ee.Number(pixstats10.get('sum'));
// Membuat daftar kosong untuk menyimpan suatu nilai area
var arealist9 = [];
var arealist10 = [];
// Membuat fungsi untuk memperoleh tingkat satu kelas keparahan luka bakar
// Argumen adalah nomor kelas dan nama kelas
var areacount9 = function(cnr, name) {
  var singleMask9 =  classified9.updateMask(classified9.eq(cnr));
  var stats9 = singleMask9.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix9 =  ee.Number(stats9.get('sum'));
  var hect9 = pix9.multiply(900).divide(10000);                
  var perc9 = pix9.divide(allpixels9).multiply(10000).round().divide(100);   
             arealist9.push({Class: name, Pixels: pix9, Hectares: hect9, Percentage: perc9})};
var areacount10 = function(cnr, name) {
  var singleMask10 =  classified10.updateMask(classified10.eq(cnr));
  var stats10 = singleMask10.reduceRegion({reducer: ee.Reducer.count(),geometry: gresik, scale: 30, bestEffort:true,});
  var pix10 =  ee.Number(stats10.get('sum'));
  var hect10 = pix10.multiply(900).divide(10000);                
  var perc10 = pix10.divide(allpixels10).multiply(10000).round().divide(100);   
             arealist10.push({Class: name, Pixels: pix10, Hectares: hect10, Percentage: perc10})};
// Urutan berbeda untuk kelas keparahan 
var names2 = [ 'NA', 'Kering','Agak Kering', 'Normal', '  Agak Basah','Basah'];
// Menjalankan fungsi di setiap kelas
for (var i = 0; i < 6; i++) {areacount9(i, names2[i]);}
for (var i = 0; i < 6; i++) {areacount10(i, names2[i]);}
print('Klasifikasi Indeks Kekeringan okt2019', arealist9);
print('Klasifikasi Indeks Kekeringan nop2019', arealist10);
//==========================================================================================
//MENAMPILKAN SHP BATAS KECAMATAN
// Paint all the polygon edges with the same number and width, display.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: gresikec,
  color: 1,
  width: 1});
Map.addLayer(outline, {palette: '000000'}, 'Batas Kecamatan');
var text = require('users/gena/packages:text');
var shp = ee.FeatureCollection(gresikec);
//Map.addLayer(shp, {},'Roads Layer');
var Scale = Map.getScale()*0.3
var labels = shp.map(function(feat){
  feat = ee.Feature(feat)
  var name = ee.String (feat.get("WADMKC"))
  var centroid = feat.geometry().centroid()
  var t = text.draw(name, centroid,Scale,{
    fontSize: 24,
    textColor:'black',
    OutlineWidth:1,
    OutlineColor:'red'})
  return t})
  var Labels_Final = ee.ImageCollection(labels)
  Map.addLayer(Labels_Final,{},"Nama Kecamatan")
//==========================================================================================
//MENAMBAHKAN LEGENDA
// Mengatur posisi panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }});
// Membentuk judul legenda
var legendTitle = ui.Label({
  value: 'Tingkat Kekeringan',
  style: {fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }});
// Menambahkan judul di panel
legend.add(legendTitle);
// Menentukan dan mengatur style untuk 1 baris legenda
var makeRow = function(color, name) {
      // Membuat label dengan kotak berwarna
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Mengatur tinggi dan lebar kotak
          padding: '8px',
          margin: '0 0 4px 0'
        }});
      // Membuat label dengan isi teks deskripsi
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // kembali mengatur panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      })};
//  Membuat pallete dengan warna-warna berbeda
var palette =['7a8737', '0ae042', 'fff70b', 'ffaf38', 'ff641b', 'ffffff'];
// Keterangan dari legenda
var names = ['Basah','Agak Basah','Normal', 'Agak Kering', 'Kering', 'NA'];
// Menambahkan warna dan nama
for (var i = 0; i < 6; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
Map.add(legend);
//=======================================================================================
//MEMBUAT TAMPILAN APPS
//Add the sidebar to the ui.root.
var title = ui.Label({
  value: 'Pemanfaatan Google Earth Engine dan Citra Satelit Landsat 8 untuk Identifikasi Kekeringan Lahan di Kabupaten Gresik, Jawa Timur',
  style: {fontSize: '22px', fontWeight: 'bold'}});
var sidebar = ui.Panel({widgets: [title], style: {width: '350px'}});
var lon = ui.Label();
var lat = ui.Label();
ui.root.add(sidebar);
var abstract = ui.Label({
  value: 'Kabupaten Gresik adalah salah satu kabupaten dengan tingkat kekeringan yang cukup parah di Jawa Timur. Oleh karena itu penelitian ini bertujuan untuk mengidentifikasi dan mengetahui persebaran kekeringan yang terjadi di Kabupaten Gresik dengan memanfaatkan data Citra Satelit Landsat 8. Dengan dilakukannya identifikasi secara berkala, dapat diketahui area mana saja yang terdampak sehingga hasil dari penelitian ini dapat digunakan sebagai tindakan preventif kedepannya dalam mengatasi bencana kekeringan di Kabupaten Gresik.',
  style: {fontSize: '12px'}});
sidebar.add(abstract);
var abstract2 = ui.Label({
  value: 'Berikut merupakan hasil perhitungan luasan lahan dengan tingkat 5 tingkat kekeringan di Kabupaten Gresik tahun 2019 :',
  style: {fontSize: '12px'}});
sidebar.add(abstract2);
//GRAFIK LAHAN KERING
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [{c: [{v: '01 Oktober 2019'},  {v: 57605}]},
         {c: [{v: '18 Nopember 2019'}, {v: 66261}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Luasan Lahan Kering',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Waktu',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN AGAK KERING
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [
         {c: [{v: '01 Oktober 2019'},  {v: 8715.06}]},
         {c: [{v: '18 Nopember 2019'}, {v: 8808.57}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Luasan Lahan Agak Kering',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Waktu',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN NORMAL
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [
         {c: [{v: '01 Oktober 2019'},  {v: 7038.54}]},
         {c: [{v: '18 Nopember 2019'}, {v: 5927.85}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Luasan Lahan Normal',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Waktu',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN AGAK BASAH
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [
         {c: [{v: '01 Oktober 2019'},  {v: 9757.17}]},
         {c: [{v: '18 Nopember 2019'}, {v: 12210.75}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Luasan Lahan Agak Basah',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Waktu',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//GRAFIK LAHAN BASAH
// Define a DataTable using a JavaScript literal.
var dataTable = {
  cols: [{id: 'Class', label: 'Classification', type: 'string'},
         {id: 'Area', label: 'Area (ha)', type: 'number'}],
  rows: [
         {c: [{v: '01 Oktober 2019'},  {v: 21054.78}]},
         {c: [{v: '18 Nopember 2019'}, {v: 10962.45}]}]};
// Define a dictionary of customization options.
var options = {
  title: 'Luasan Lahan Basah',
  vAxis: {title: 'Area (ha)'},
  legend: {position: 'none'},
  hAxis: {title: 'Waktu',logScale: true}};
// Make a BarChart from the table and the options.
var chart = new ui.Chart(dataTable, 'ColumnChart', options);
sidebar.add(chart);
//KETERANGAN
var ket = ui.Label({
  value: 'Disusun Oleh :',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Rosmalisa Dwiyaniek (03311740000014)',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Dosen Pembimbing :',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Prof. Dr. Ir. Bangun Muljo Sukojo, DEA., DESS',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'Dr. Filsa Bioresita, ST., MT',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: ' ',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'DEPATEMEN TEKNIK GEOMATIKA',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'INSTITUT TEKNOLOGI SEPULUH NOPEMBER',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: 'SURABAYA',
  style: {fontSize: '12px'}});
sidebar.add(ket);
var ket = ui.Label({
  value: '2021',
  style: {fontSize: '12px'}});
sidebar.add(ket);