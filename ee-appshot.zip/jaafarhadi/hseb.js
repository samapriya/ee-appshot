var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                30.778036654864938,
                31.208392426408363
              ],
              [
                30.778036654864938,
                30.93785846859701
              ],
              [
                31.085653842364938,
                30.93785846859701
              ],
              [
                31.085653842364938,
                31.208392426408363
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#ff0000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || 
    /* color: #ff0000 */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[30.778036654864938, 31.208392426408363],
          [30.778036654864938, 30.93785846859701],
          [31.085653842364938, 30.93785846859701],
          [31.085653842364938, 31.208392426408363]]], null, false);
/// Import image collection 
var collection = require('users/jaafarhadi/HSEB:ForApp/imCol');
var ET_Coll = collection.ET_Coll;
// ===================
var map = ui.Map();
var palette =['#B59B75', '#D8C689', '#FEF3AC', '#78D062','#1c8591', '#0B2F7A'];
var viz = {min: 0, max: 5, palette: palette};
// Define symbols for the labels.
var symbol = {
  rectangle: '⬛',
  polygon: '🔺',
  point: '📍',
  pan: '🤚' 
};
// ------------------------------------------ //
//              Create the UI
// ------------------------------------------ //
Map.setControlVisibility({all: false, layerList: true, zoomControl:true, scaleControl:true,mapTypeControl:true,fullscreenControl:true});
Map.setCenter(-80,33.6,3);
var panel = ui.Panel({ style: {width: '300px'} });
panel.add(ui.Label({value:'30-m Annual ET Mapper based on HSEB from Landsat',
  style: {fontFamily:'Arial', fontSize:'25px', padding: '4px', color:'0A452E', fontWeight:"bold", textAlign: "center", maxWidth: '250px'} }));
panel.add(ui.Label(
'By: Jaafar et al. (2022)', {fontFamily:'Arial'}, "https://doi.org/10.1016/j.rse.2022.112995"
));
panel.add(ui.Label({
  value: "This interface allows users to visualize 30-m ETA (1985-2020) based on a hybrid single-source energy balance (HSEB) model for example locations.",
  style: {fontFamily:'Arial', padding: '5px',textAlign: "left", fontSize:'15px', border: '1px solid black'}
}));
panel.add(ui.Label({value: '1) Zoom to location', style: {fontWeight:"bold", fontFamily:'Arial', fontSize: '15px'}  }));
var places = {
California: [-120.93028323599903, 37.65036915299222],
Dawa: [44.90415906327988, 20.34554834568272],
// Erbil: [43.611929791023066, 35.79681136651826],
// Ghab: [36.712515728523066, 35.61839220451323],
// Harran: [38.975699322273066, 36.98186867784312],
// Iraq: [45.274295150662546, 32.8692632040747],
// Jazeera: [40.887320416023066, 36.87648185357238],
NileRiver: [31.117239535724313, 30.83031410555374],
Pakistan:	[68.74109202566254, 26.616829020719535],
// Paleo: [-114.5359764930256, 33.750914990491154],
Salton:	[-115.44024309437518, 32.97024367969304],
Skaka: [38.51298495622732, 30.169206855989625],
Morocco : [-6.475291539135926, 33.16916757558769]
};
var select = ui.Select({
  items: Object.keys(places),
  onChange: function(key) {
    Map.setCenter(places[key][0], places[key][1], 11);
  }
});
// Set a place holder.
select.setPlaceholder('Choose a location...');
panel.add(select);
panel.add(ui.Label({value: '2) Select year to visualize', style: {fontWeight:"bold", fontFamily:'Arial', fontSize: '15px'}  }));
  panel.add(ui.Label('The annual mean ETA will be displayed based on year of visualization.',{fontFamily:'Arial', fontSize:'12.5px',margin:'1px 8px 3px 8px',color:'#777'}));
// Use a DateSlider
// Use the start of the collection and now to bound the slider.
var start = ee.Date('1985-01-01').get('year').format();
var now = Date.now();
var end = ee.Date('2020-12-31').format();
var showLayer = function(range) {
  var ET = ET_Coll.filter(ee.Filter.calendarRange(range.start().get('year'), range.end().get('year'), 'year')); 
  var ET_layer = ui.Map.Layer(ET, viz, 'ETA');
  Map.layers().set(0, ET_layer);
  };
  // Asynchronously compute the date ange and show the slider.
  var dateSlider;
  var dateRange = ee.DateRange(start, end).evaluate(function(range) {
    var dateSlider = ui.DateSlider({
      start: range['dates'][0],
      end: range['dates'][1],
      value: ee.Date('1990-01-01').millis().getInfo(),
      period: 366,
      onChange: showLayer,
      style: {width:'250px'}
    });
    panel.add(dateSlider.setValue(ee.Date('1990-01-01').millis().getInfo()));
    panel.add(ui.Label({value: '3) Set date range for time-series chart', style: {fontWeight:"bold", fontFamily:'Arial', fontSize: '15px'}  }));
// Set date ui.Panel
var sYear = ui.Slider({min:1985,max:2020,value:1990,step:1,
  style:{stretch:'horizontal'}});
var eYear = ui.Slider({min:1990,max:2020,value:2020,step:1,
  style:{stretch:'horizontal'}});
var changeSliderYr = function() {
  var startYr = sYear.getValue();
  var endYr = eYear.getValue();
  if (endYr < startYr) {eYear.setValue(startYr)}
};
sYear.onChange(changeSliderYr);
eYear.onChange(changeSliderYr);
var startYear = ui.Panel([ui.Label('Start Year: ',{color:'#777',margin:'8px 3px 8px 8px'}),sYear],
              ui.Panel.Layout.Flow('horizontal'),{stretch:'horizontal',margin:'-5px -8px 0px 8px'});
var endYear = ui.Panel([ui.Label('End Year: ',{color:'#777',margin:'8px 3px 8px 8px'}),eYear],
              ui.Panel.Layout.Flow('horizontal'),{stretch:'horizontal',margin:'-5px -8px 0px 8px'});
panel.add(startYear);
panel.add(endYear);
var submitButton = ui.Button({label: 'Submit',  style: {stretch: 'horizontal', margin: '5px 13px 5px 8px'}});
panel.add(ui.Label('4) Draw region of interest',{fontSize:'15px',margin:'8px 8px 3px 8px', fontWeight: 'bold', fontFamily: 'Arial'}));
panel.add(ui.Label('On the map, draw a geometry to chart ETA time series for selected range of years, then click on submit. You can edit and move the geometry after clicking on \'Pan Map\'.',{fontFamily:'Arial', fontSize:'12.5px',margin:'1px 8px 3px 8px',color:'#777'}));
var drawingButton = ui.Panel([
  ui.Button({
          label: symbol.rectangle + ' Rectangle',
          onClick: drawRectangle,
          style: {stretch: 'horizontal'}}), 
  ui.Button({
          label: symbol.polygon + ' Polygon',
          onClick: drawPolygon,
          style: {stretch: 'horizontal'}})],
              ui.Panel.Layout.Flow('horizontal'),{stretch:'horizontal'});
panel.add(drawingButton);
panel.add( ui.Panel([ui.Button({
      label: symbol.point + ' Point',
      onClick: drawPoint,
      style: {stretch: 'horizontal'}
    }),ui.Button({
      label: symbol.pan + ' Pan Map',
      onClick: panMap,
      style: {stretch: 'horizontal'}})], ui.Panel.Layout.Flow('horizontal'),{stretch:'horizontal'}));
panel.add(submitButton);
var drawingTools = Map.drawingTools();
drawingTools.setShown(false);
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
var dummyGeometry =
    ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: 'red'});
drawingTools.layers().add(dummyGeometry);
// Define a function to clear the geometry from the layer when a
// drawing mode button is clicked.
function clearGeometry() {
  var layers = drawingTools.layers();
  var nGeom = layers.get(0).geometries().length();
  for (var iLayer = 0; iLayer < nGeom; iLayer++) {
    layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
  } 
}
// Define function for dealing with a click on the rectangle button.
function drawRectangle() {
  clearGeometry();
  drawingTools.setShape('rectangle');
  drawingTools.draw();
}
function drawPoint() {
  clearGeometry();
  drawingTools.setShape('point');
  drawingTools.draw()}
// Define function for dealing with a click on the polygon button.
function drawPolygon() {
  clearGeometry();
  drawingTools.setShape('polygon');
  drawingTools.draw();
}
function panMap() {
  drawingTools.stop();
}
var geometry;
if (ui.url.get('year_map') !== undefined) {
  Year.setValue(ui.url.get('year_map'));
}
if (ui.url.get('startYear') !== undefined) {
  sYear.setValue(ui.url.get('startYear'));
}
if (ui.url.get('endYear') !== undefined) {
  eYear.setValue(ui.url.get('endYear'));
}
// if (ui.url.get('geometry') !== undefined) {
//   geometry = ee.Deserializer.fromJSON(ui.url.get('geometry'));
// } else {
//   // Initialize a dummy GeometryLayer with default geometry acts as a placeholder
//   // for drawn geometries.
// }
// Define a panel to hold the time series chart.
var chartPanelParent = ui.Panel({
  style: {
    width: '600px',
    position: 'bottom-right',
    maxHeight: '90%'
  }
});
var chartPanel = ui.Panel([],null,{margin: '0 -8px 0px -18px'});
var chartSelectPanel = ui.Panel([],
  ui.Panel.Layout.Flow('horizontal'), {
    margin: '-8px 0 0 0', padding: '0', width: '270px'
  });
var hideChartMode = true;
var hideShowChartButton = ui.Button({
  label: 'Hide Chart',
  onClick: function() {
    hideChartMode = !hideChartMode;
    hideShowChartButton.setLabel(hideChartMode ? 'Hide Chart': 'Show Chart');
    if (!hideChartMode) {
      chartPanelParent.style().set({width: '92px', height: '45px'});
    } else {
      chartPanelParent.style().set({width: '600px', height: 'auto'});
    }
  },
    style: {padding: '0', margin: '0'}
});
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
var dirtyMap = false;
function chartETA(coords) {
  // Make the chart panel visible the first time.
  if (dirtyMap === false) {
    Map.add(chartPanelParent.add(hideShowChartButton).add(chartPanel));
    dirtyMap = true;
  }
  // Clear the chart and legend panels.
  chartPanel.clear(); // chartSelectPanel.clear();
  // legendPanel.clear();
  var startYear = sYear.getValue();
  var endYear = eYear.getValue();
  var ETAfiltered = ET_Coll
    .filter(ee.Filter.calendarRange(startYear,endYear,'year'))
  var ETA = ETAfiltered;
  // Map.layers().remove(Map.layers().get(0));
  // Map.addLayer(ETA.mean(),
  //   {palette:['#B59B75', '#D8C689', '#FEF3AC', '#78D062','#1c8591', '#0B2F7A'], min: 1, max: 5},
  //   'ETA');
  // lon.setValue('lon: ' + coords.lon.toFixed(2));
  // lat.setValue('lat: ' + coords.lat.toFixed(2));
  // Add a dot for the point clicked on.
  var aoi = drawingTools.layers().get(0).getEeObject();
  // Set drawing mode back to null.
  drawingTools.setShape(null);
  var getChart = function() {
    return ui.Chart.image.series({
      imageCollection: ETA, 
      region: aoi, 
      reducer: ee.Reducer.mean(), 
      scale: 100, 
      xProperty: 'system:time_start'
    }).setOptions({
        vAxis: {
          title: 'ETA (mm/day)',
          viewWindow: {
          min: 0,
        },
          format:'#####'
        },
        hAxis: {
          title: 'Year', format: 'YYYY'
        }, series: {0: {color: 'green', lineWidth: 2, pointVisible: true, pointSize: 3}},
        height: '211px'
    });
  };
  chartPanel.add(getChart());
// var region = aoi.buffer(250).bounds();
// // Visualization parameters.
// var args = {
//   crs: 'EPSG:3857',  
//   dimensions: '300',
//   region: region,
//   min: 0,
//   max: 5,
//   palette: palette,
//   framesPerSecond: 5,
// };
// // Create a video thumbnail and add it to the map.
// var thumb = ui.Thumbnail({
//   // Specifying a collection for "image" animates the sequence of images.
//   image: ETA,
//   params: args,
//   style: {
//     position: 'bottom-right',
//     width: '320px'
//   }});
// chartPanel.add(thumb);
  ui.url.set({
    'startYear':startYear,
    'endYear':endYear,
    'geometry': geometry
  });
}
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(viz.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(viz.min, {margin: '4px 8px'}),
    ui.Label(
        (viz.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(viz.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Legend',
  style: {fontWeight: 'bold', fontFamily:'Arial', fontSize: '15px'}
});
var headDivider = ui.Panel(ui.Label(),ui.Panel.Layout.flow('horizontal'),{margin: '5px 5px 5px 5px',height:'1.25px',border:'0.75px solid', color: 'black', stretch:'horizontal'});
panel.add(headDivider);
// Add the legendPanel to the map.
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
panel.add(legendPanel);
// Hint on layer selection
var hint = ui.Label({value:'Note: Layer transparency can be changed at the top-right of the screen (layers box).',style:{fontSize:'12.5px', color: '#777'}});
panel.add(hint);
// Create an inspector panel with a horizontal layout.
var inspector = ui.Panel({
  layout: ui.Panel.Layout.absolute(),
  style: {width: '375px', height: '40px', position: 'top-center', border: '3px solid black' } 
});
// Add a label to the panel.
// inspector.add(ui.Label('Draw a region to chart ETA timeseries', {fontFamily:'Arial'}));
submitButton.onClick(chartETA);
// Disclaimer | CREDITS //
var class_manual = ui.Label('A global 30-m ET model (HSEB) using harmonized Landsat and Sentinel-2, MODIS and VIIRS: Comparison to ECOSTRESS ET and LST',{},"https://doi.org/10.1016/j.rse.2022.112995");
var manuscript = ui.Label('Manuscript',{},"https://doi.org/10.1016/j.rse.2022.112995");
var manuscriptPanel = ui.Panel([ui.Label('For more information:', {fontWeight: 'bold', fontFamily:'Arial', fontSize: '15px'}),class_manual]);
// Download button for layer
var download = ui.Label('Download PDF',{},"https://doi.org/10.1016/j.rse.2022.112995");
// Contact
var contact = ui.Label('Contact',{},"mailto:hj01-at-aub.edu.lb");
var space2 = ui.Label('______________________________');
var headDivider2 = ui.Panel(ui.Label(),ui.Panel.Layout.flow('horizontal'),{margin: '5px 5px 5px 5px',height:'1.25px',border:'0.75px solid', color: 'black', stretch:'horizontal'});
// Disclaimers authors 
panel.add(headDivider2);
panel.add(manuscriptPanel);
panel.add(contact);
// Set the default map's cursor to a "crosshair".
Map.style().set('cursor', 'crosshair');
// Absolute layout
ui.root.setLayout(ui.Panel.Layout.absolute());
// Add panel to UI root
ui.root.add(panel);
// Add inspector box to root
// ui.root.add(inspector);
  });
showLayer(ee.DateRange('1990-01-01', '1990-12-31'));