var ecoregions = ee.FeatureCollection("EPA/Ecoregions/2013/L3")
var ned = ee.Image("USGS/NED").select('elevation').clip(ecoregions) 
var hollow = {color: 'indianred', width: 0.5, fillColor: '00000000'}
Map.addLayer(ned,{min:0,max:3000},'elevation') 
Map.addLayer(ecoregions.style(hollow),{},'ecoregions')
Map.setCenter(-96,38,5).setOptions('HYBRID')
var label = ui.Label('Click an ecoregion to create an elevation histogram')
var panel = ui.Panel(label,ui.Panel.Layout.flow('vertical'),{position:'bottom-left'})
Map.add(panel)
var chartOptions = {
  colors: ['crimson'],
  vAxis: {
    format: 'scientific',
  }
}
function pickRegion(location) {
  var coords = [location.lon, location.lat]
  var zone = ecoregions.filterBounds(ee.Geometry.Point(coords))
  var name = ee.Feature(zone.first()).get('us_l3name').getInfo()
  var area = ecoregions.filterMetadata('us_l3name','equals',name)
  var areaStyle = {color: 'gold', width: 1.5, fillColor: '00000000'}
  Map.layers().set(2, ui.Map.Layer(ee.Geometry.Point(coords),{color:'gold'},'dot'))
  Map.layers().set(3, ui.Map.Layer(area.style(areaStyle),{},'name'))
  panel.widgets().set(1,ui.Label(name,{fontWeight:'bold'}))
  panel.widgets().set(2,ui.Chart.image.histogram({
    image: ned,
    region: area,
    scale: 1000, // multiple of the 10-m spatial resolution to speed up processing
    maxPixels: 1e13
  }).setOptions(chartOptions))
  Map.centerObject(area)
}
Map.onClick(pickRegion)