var image = ui.import && ui.import("image", "image", {
      "id": "users/khanifar/NDVI"
    }) || ee.Image("users/khanifar/NDVI");
Map.centerObject(image);
var ndwiViz = {min: -1, max: 1, palette: ['00FFFF', '0000FF']};
Map.addLayer(image, ndwiViz);