var gfs = ee.ImageCollection("NOAA/GFS0P25"),
    dhaka = /* color: #007dd6 */ee.Geometry.Point([90.42230527287313, 23.823755096249904]);
/*
  Visualize 0-384hr forecast data using google earthengine
  later plan: detect cyclone using this
  -------------------------------------------------
  | data set details: NOAA/GFS0P25/2015070100F003 |
  -------------------------------------------------
 creation_time	DOUBLE  Time of creation
 forecast_hours	DOUBLE  Forecast hours
 forecast_time  DOUBLE  Forecast time
 creation_time      1435708800000
 system:time_start  2015-07-01 UTC
 forecast_time      1435719600000
 forecast_hours     3
 system:time_end    2015-07-01 UTC
*/
//  load libs
var cmaps = require('users/nzahasan/res:cmap.js');
var dt = require('users/nzahasan/res:ee_datetime.js');
print(dt.__doc__);
var UTC00EPOCH = dt.utc00_time_today().getTime();
print('utc0e',UTC00EPOCH);
var TODAYS_DATA=  gfs.filter( ee.Filter.eq('creation_time',UTC00EPOCH ) );
function getDataAtForecastHour(hour){
  // Returns today's forecast dat at a forecast time
  return TODAYS_DATA.filter( ee.Filter.eq('forecast_hours',hour) );
}
var tempVisParams = {
  min: -40.0,
  max: 35.0,
  palette: cmaps.colormaps.Spectral_r,
  opacity:0.6,
  bands:['temperature_2m_above_ground']
};
var velVisParams = {
  min: 0,
  max: 20,
  palette: cmaps.colormaps.coolwarm,
  opacity:0.6
};
/* ADD LAYERS */
var layers ={ 
  tempLayer: null,
  precipLayer: null,
};
function removeAllLayers(){
  var layers =  Map.layers();
  layers.forEach(function(layer){
    Map.remove(layer);
  });
}
var addGFS_Layers_lock = false;
function addGFS_Layers(data){
  //check lock
  if(addGFS_Layers_lock===true){print('layer locked');return null;}
  // lock this function
  addGFS_Layers_lock = true;
  print('l');
  // remove all existing layers
  removeAllLayers();
  // add temperature layer
  Map.addLayer(data.select(['temperature_2m_above_ground']),tempVisParams,'Temperature @ 2m (c)');
  // add velocity layer
  var velocity = data.select(['u_component_of_wind_10m_above_ground']).median().pow(2)
              .add( 
                data.select(['v_component_of_wind_10m_above_ground']).median().pow(2) 
              ).sqrt().multiply(3.6) ;
  Map.addLayer(velocity,velVisParams,'Velocity @ 2m (kmph)',false);
  //execution done unlock this function
  addGFS_Layers_lock=false;
  print('ul');
}
addGFS_Layers(getDataAtForecastHour(0));
//total_precipitation_surface
function labelText(value){
  return 'Forecast Date: UTC '+
  dt.date2str(dt.utc00_time_today(),'%d-%m-%Y  %H:%M')+
  '[Forecast Time: '+
  dt.date2str( dt.deltaHour(dt.utc00_time_today(), value),'%d-%m-%Y %H:%M' ) +']';
}
print('dada',dt.date2str(dt.utc00_time_today(),'%d-%m-%Y %H_%M'));
print(dt.utc00_time_today().getUTCHours());
var ForecastTimeSlider = ui.Slider({
  min:0,
  max:384,
  step:3,
  style:{
    width:'1000px',
    position: 'bottom-center',
    fontFamily: 'Noto Mono',
    stretch: 'horizontal',
    padding:'5px',
    // backgroundColor: 'white'
  },
  onChange: function (value){
    topLabel.setValue(labelText(value));
    addGFS_Layers(getDataAtForecastHour(value));
  }
});
var topLabel = ui.Label(labelText(0),
    {
      position:'top-center',
      fontSize: '14px',
      fontFamily: 'Noto Mono',
      // border:'1px solid #ccc',
      stretch: 'horizontal',
    });
Map.centerObject(dhaka,5);
Map.setOptions('TERRAIN',{});
Map.add(ForecastTimeSlider);
Map.add(topLabel);
Map.setControlVisibility({
  scaleControl:true, 
  mapTypeControl:true, 
  fullscreenControl:true
});