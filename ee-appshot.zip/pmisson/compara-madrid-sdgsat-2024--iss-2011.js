var imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "clouds"
        ],
        "min": 1,
        "max": 3,
        "palette": [
          "1eff02",
          "fcff00",
          "ff0000"
        ]
      }
    }) || {"opacity":1,"bands":["clouds"],"min":1,"max":3,"palette":["1eff02","fcff00","ff0000"]},
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "b1",
          "b2",
          "b3"
        ],
        "min": 7,
        "max": 4000,
        "gamma": 6
      }
    }) || {"opacity":1,"bands":["b1","b2","b3"],"min":7,"max":4000,"gamma":6},
    imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "projects/ee-pmisson/assets/SDGSAT-1_Spain_Clouds2"
    }) || ee.ImageCollection("projects/ee-pmisson/assets/SDGSAT-1_Spain_Clouds2"),
    imageCollection2 = ui.import && ui.import("imageCollection2", "imageCollection", {
      "id": "projects/ee-pmisson/assets/SDGSAT-1_Italy_Clouds2"
    }) || ee.ImageCollection("projects/ee-pmisson/assets/SDGSAT-1_Italy_Clouds2"),
    imageX = ui.import && ui.import("imageX", "image", {
      "id": "projects/ee-pmisson/assets/iss026e035949-SharpenAI-Motion_Noise_modificado"
    }) || ee.Image("projects/ee-pmisson/assets/iss026e035949-SharpenAI-Motion_Noise_modificado"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7600952048491765,
                40.337637760140154
              ],
              [
                -3.760610188980036,
                40.331749355264684
              ],
              [
                -3.7446456809233952,
                40.330571612628496
              ],
              [
                -3.7467914481353093,
                40.338749956697264
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.8748141501499367,
                40.48006188295802
              ],
              [
                -3.881594774539585,
                40.47307596446432
              ],
              [
                -3.8748999808384132,
                40.466677008859826
              ],
              [
                -3.8609095786167336,
                40.46602401992394
              ],
              [
                -3.849408266360874,
                40.472814794538394
              ],
              [
                -3.8518973563266945,
                40.4769933914565
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.MultiPolygon(
        [[[[-3.7600952048491765, 40.337637760140154],
           [-3.760610188980036, 40.331749355264684],
           [-3.7446456809233952, 40.330571612628496],
           [-3.7467914481353093, 40.338749956697264]]],
         [[[-3.8748141501499367, 40.48006188295802],
           [-3.881594774539585, 40.47307596446432],
           [-3.8748999808384132, 40.466677008859826],
           [-3.8609095786167336, 40.46602401992394],
           [-3.849408266360874, 40.472814794538394],
           [-3.8518973563266945, 40.4769933914565]]]]);
//Spain
    imageVisParam2 = {"opacity":1,"bands":["b1","b2","b3"],"min":7,"max":4000,"gamma":[2.5,2.5,3.5]},
function invertCloudsLayer(image) {
  // Assuming the 'clouds' layer is an 8-bit image with values from 0 to 255
  // Invert the 'clouds' layer by subtracting its values from 255
  var invertedClouds = image.select('clouds').subtract(3).multiply(-1);
  // Replace the original 'clouds' layer with the inverted one
  return image.addBands(invertedClouds.rename('clouds'), null, true);
}
var collection = imageCollection;
var processedCollection = collection//.map(invertCloudsLayer);
var image=processedCollection.qualityMosaic('clouds');
Map.addLayer(image,imageVisParam2,'image',false)
Map.addLayer(image.mask(image.select('clouds').gt(2)).unmask(7),imageVisParam2,'image C',false)
Map.addLayer(image.select('clouds'),imageVisParam,'Clouds', false)
function applyCloudMask(image) {
  // Assuming 'cloudMask' is the band indicating clouds (2 = cloud, 3 = clear)
  var mask = image.select('clouds').eq(3); // Clouds are masked out, clear conditions are kept
  return image.updateMask(mask);
}
// Apply the cloud mask to each image in the collection
var maskedCollection = collection.map(applyCloudMask);
var medianImage = maskedCollection.median();
Map.addLayer(medianImage.unmask(7).visualize(imageVisParam2),{},'SDGSAT-1 2021-2024')
var visual={"opacity":1,"bands":["b1","b2","b3"],"min":[0,0,0],"max":[300,255,255],"gamma":[0.7,1.1,1]}
Map.addLayer(imageX.visualize(visual),{},'2011',false)
// Select two images for PIF matching
var image1 = medianImage.unmask(7).visualize(imageVisParam2).clip(geometry);
var image2 = imageX.visualize(visual).clip(geometry);
// Select an area of interest and define multispectral bands to use
var aoi = geometry.buffer(3000).bounds();
var bands = ee.List(['vis-red', 'vis-green', 'vis-blue']);
// Select a pair of Planet SkySat images acquired before and after deforestation
var before = image1
  .select(bands)
  .clip(aoi);
var after = image2
  .select(bands)
  .clip(aoi)
  .register(before, 100);
// Calculate spectral distance as a measure of change between the images
var distance = before.spectralDistance(after, 'sid');
// Identify the 10th percentile of change
var threshold = distance.reduceRegion({
  reducer: ee.Reducer.percentile([10]),
  geometry: aoi,
  scale: 1,
  bestEffort: true,
  maxPixels: 1e6,
}).getNumber('distance');
// Define pseudo-invariant features below the change threshold
var pif = distance.lt(threshold);
function matchBand(band) {
  // Select just the PIF areas in each image
  var beforePif = before.select([band]).updateMask(pif);
  var afterPif = after.select([band]).updateMask(pif);
  // Define a linear reducer to calculate a transformation between images
  var args = {
    reducer: ee.Reducer.linearFit(),
    geometry: aoi,
    scale: 1,
    maxPixels: 1e6,
    bestEffort: true
    };
  // Calculate the linear coefficients
  var coeffs = ee.Image.cat([afterPif, beforePif])
    .reduceRegion(args);
  // Apply the coefficients to match the after band to the before band
  return after
    .select([band])
    .multiply(coeffs.getNumber('scale'))
    .add(coeffs.getNumber('offset'));
}
function matchBandC(band) {
  // Select just the PIF areas in each image
  var beforePif = before.select([band]).updateMask(pif);
  var afterPif = after.select([band]).updateMask(pif);
  // Define a linear reducer to calculate a transformation between images
  var args = {
    reducer: ee.Reducer.linearFit(),
    geometry: aoi,
    scale: 1,
    maxPixels: 1e6,
    bestEffort: true
    };
  // Calculate the linear coefficients
  var coeffs = ee.Image.cat([afterPif, beforePif])
    .reduceRegion(args);
  // Apply the coefficients to match the after band to the before band
  return coeffs;
}
// Match each band, then combine them back into a single multi-band image
var matchedBands = bands.map(matchBand);
print(matchedBands)
var matched = ee.ImageCollection(matchedBands).toBands().rename(bands);
var coeffs = bands.map(matchBandC).getInfo();
print(coeffs)
function applyOffsetAndScale(image, params) {
  // Extract the RGB bands
  var red = image.select('vis-red');
  var green = image.select('vis-green');
  var blue = image.select('vis-blue');
  print(params[0].scale)
  // Apply the offset and scale to each band
  var redScaled = red.multiply(params[0].scale).add(params[0].offset);
  var greenScaled = green.multiply(params[1].scale).add(params[1].offset);
  var blueScaled = blue.multiply(params[2].scale).add(params[2].offset);
  // Combine the scaled bands into an RGB image
  return ee.Image.cat([redScaled, greenScaled, blueScaled]).rename(['vis-red', 'vis-green', 'vis-blue']);
}
var afterAll = applyOffsetAndScale(imageX.visualize(visual), coeffs);
print(afterAll)
var mask=afterAll.select('vis-red').gt(81)
var matchedAll = ee.ImageCollection(afterAll).toBands().rename(bands);
Map.centerObject(aoi);
Map.addLayer(distance, {min: 0, max: 0.4}, 'Spectral distance',false);
Map.addLayer(pif, {}, 'PIF mask',false);
Map.addLayer(before, {min: 0, max: 255}, 'Before',false);
Map.addLayer(matched, {min: 0, max: 255}, 'After (Matched)',false);
Map.addLayer(after, {min: 0, max: 255}, 'After (Original)',false);
Map.addLayer(afterAll.mask(mask).unmask(0), {min: 0, max: 255}, 'ISS 2011');
// Center the map
Map.centerObject(geometry, 11);