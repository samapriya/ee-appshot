// ===========================================================
// Eclipse 2026 — 12-ago-2026 18:30 UTC
// - Altura solar aparente por píxel (NOAA + Bennett)
// - Sombra de terreno (az 284°) seleccionada por altura por píxel (0..11°)
// - Prob. despejado a esa elevación y DÍAS DESPEJADOS (0–39)
// - Leyenda de PROB (tu paleta) y leyenda de DÍAS (0–39)
// ===========================================================
alert('Doublecheck the location at least one day earlier to garantee that there are obstacles on your view direction. For higher acuracy try https://pyeclipsesimulator.streamlit.app/'); //d
// ---------- Entradas ----------
var geometry = ee.Geometry.Polygon(
      [[[-15.825098211054565, 46.65553568821407],
        [-15.825098211054565, 33.98717696631419],
        [7.773534601445435, 33.98717696631419],
        [7.773534601445435, 46.65553568821407]]], null, false),
    table   = ee.FeatureCollection("projects/ee-pmisson/assets/eclipse2026"),
    // VIIRS "días nublados" (0..39 ahora):
    image   = ee.Image("projects/ee-pmisson/assets/Eclipse2026_VIIRS_CMAsk");
// ---------- Parámetros ----------
var DATE_ISO = '2026-08-12';
var HOUR_UTC = 18;
var MIN_UTC  = 30;
var AZIMUTH  = 284;                // ° desde Norte (horario)
var MAX_ELEV = 11;                 // discretización/leyenda elev
var NEIGHBORHOOD = 200;            // px para hillShadow
var DEM = ee.Image('USGS/SRTMGL1_003');
var DAYS_TOTAL = 39;               // <<<<<< total de días
Map.centerObject(geometry, 6);
// ---------- Utilidades ----------
function deg2rad(x){ return ee.Image(x).multiply(Math.PI/180); }
function rad2deg(x){ return ee.Image(x).multiply(180/Math.PI); }
// ---------- Altura solar aparente por píxel (NOAA + Bennett) ----------
var lonlat  = ee.Image.pixelLonLat();
var lonImg  = lonlat.select('longitude');
var latImg  = lonlat.select('latitude');
var latRad  = deg2rad(latImg);
var date    = ee.Date(DATE_ISO + 'T00:00:00');
var doy     = ee.Number(date.getRelative('day', 'year')).add(1);
var timeUTC = ee.Image.constant(HOUR_UTC)
               .add(ee.Image.constant(MIN_UTC).divide(60));
var gamma = ee.Image.constant(2 * Math.PI / 365)
  .multiply(ee.Image.constant(doy.subtract(1)))
  .add(ee.Image.constant(2 * Math.PI / 365)
       .multiply(timeUTC.subtract(12).divide(24)));
var E = ee.Image.constant(229.18).multiply(
  ee.Image.constant(0.000075)
  .add(ee.Image.constant(0.001868).multiply(gamma.cos()))
  .subtract(ee.Image.constant(0.032077).multiply(gamma.sin()))
  .subtract(ee.Image.constant(0.014615).multiply(gamma.multiply(2).cos()))
  .subtract(ee.Image.constant(0.040849).multiply(gamma.multiply(2).sin()))
);
var decl = ee.Image.constant(0.006918)
  .subtract(ee.Image.constant(0.399912).multiply(gamma.cos()))
  .add(ee.Image.constant(0.070257).multiply(gamma.sin()))
  .subtract(ee.Image.constant(0.006758).multiply(gamma.multiply(2).cos()))
  .add(ee.Image.constant(0.000907).multiply(gamma.multiply(2).sin()))
  .subtract(ee.Image.constant(0.002697).multiply(gamma.multiply(3).cos()))
  .add(ee.Image.constant(0.00148 ).multiply(gamma.multiply(3).sin()));
var timeOffsetMin = E.add(lonImg.multiply(4)); // TZ=0
var tstMin = timeUTC.multiply(60).add(timeOffsetMin);
var H = deg2rad(tstMin.divide(4).subtract(180));
var sinAlt = latRad.sin().multiply(decl.sin())
  .add(latRad.cos().multiply(decl.cos()).multiply(H.cos()));
var altGeomRad = sinAlt.asin();
var altGeomDeg = rad2deg(altGeomRad);
// Refracción Bennett: R(deg) = 1.02 / tan( deg2rad(h + 10.3/(h+5.11)) ) / 60
var hSafeDeg = altGeomDeg.max(-1);
var argDeg   = hSafeDeg.add(ee.Image(10.3).divide(hSafeDeg.add(5.11)));
var Rdeg     = ee.Image(1.02).divide(deg2rad(argDeg).tan()).divide(60);
var altAppDeg = altGeomDeg.add(Rdeg).rename('solar_elevation_apparent_deg');
// Máscaras/derivadas
var isDay     = altAppDeg.gt(0);
var hClamped  = altAppDeg.max(0).min(MAX_ELEV);    // 0..11
var hClass    = hClamped.floor().toInt();          // 0..11
var sinAltApp = deg2rad(altAppDeg).sin();
// ---------- Sombra por altura seleccionada por píxel (az=284°) ----------
var elevList = ee.List.sequence(0, MAX_ELEV, 1);
var shadowByHeight = ee.ImageCollection(
  elevList.map(function(h){
    var zenithDeg = ee.Number(90).subtract(ee.Number(h));
    var sh = ee.Terrain.hillShadow({
      image: DEM,
      azimuth: AZIMUTH,
      zenith:  zenithDeg,
      neighborhoodSize: NEIGHBORHOOD,
      hysteresis: true
    }).clip(geometry);              // 1=sombra, 0=iluminado
    return sh.updateMask(hClass.eq(ee.Number(h)));
  })
).mosaic().updateMask(isDay);
// ---------- Probabilidad despejado y DÍAS DESPEJADOS (base DAYS_TOTAL=39) ----------
var p_clear_z = ee.Image(1).subtract(image.divide(DAYS_TOTAL))
  .clip(geometry).max(0).min(1).rename('p_clear_nadir');
// Modelo: P(a) = (p_clear_z)^(1/sin(a))  (ver PDF)
var invSinA = sinAltApp.max(1e-6).pow(-1);
var P_clear_a = p_clear_z.pow(invSinA)
  .updateMask(isDay)
  .rename('p_clear_at_elevation');
var clear_days_at_a = P_clear_a.multiply(DAYS_TOTAL).rename('clear_days_at_elevation');
// ---------- Visualización ----------
var hillshade = ee.Terrain.hillshade(DEM, 315, 45).clip(geometry);
Map.addLayer(hillshade, {min:0, max:255}, 'Hillshade', true);
// Sombra de terreno por altura real (az 284°)
Map.addLayer(shadowByHeight.unmask(1),
             {min:0, max:1, opacity:0.35},
             'Sombra (az 284°) por altura solar real, Totalidad', true);
// Prob. despejado (0..1) — tu paleta
var colorPaletteProb = [
  '0000FF','0055FF','00AAFF','00FFFF','00FF80','00FF00','FFFF00','FF8000','FF0000'
];
//Map.addLayer(P_clear_a, {min:0, max:1, palette: colorPaletteProb},'P(despejado) a elevación solar (18:30 UTC)', true);
// DÍAS DESPEJADOS (0..39)
var colorPaletteDays = ['440154','472c7a','3b528b','2c728e','21918c','28ae80','5ec962','addc30','fde725'];
//Map.addLayer(clear_days_at_a, {min:0, max:DAYS_TOTAL, palette: colorPaletteDays},'Días despejados / ' + DAYS_TOTAL, true);
// Camino del eclipse (opcional)
Map.addLayer(table, {color:'red'}, 'Eclipse 2026 path', true);
// ---------- LEYENDA #1: Probabilidad 0..1 ----------
var legendProb = ui.Panel({style: {position: 'bottom-left', padding: '8px 15px'}});
legendProb.add(ui.Label({
  value: 'Clear probability',
  style: {fontWeight:'bold', fontSize:'16px', margin:'0 0 4px 0', padding:'0'}
}));
var labelsProb = ['0','0.125','0.25','0.375','0.5','0.625','0.75','0.875','1.0'];
colorPaletteProb.forEach(function(color, i){
  var box = ui.Label({style:{backgroundColor:color, padding:'8px', margin:'0 0 4px 0'}});
  var lab = ui.Label({value: labelsProb[i], style:{margin:'0 0 4px 6px'}});
  legendProb.add(ui.Panel([box, lab], ui.Panel.Layout.Flow('horizontal')));
});
//Map.add(legendProb);
// ---------- LEYENDA #2: Días despejados 0..39 ----------
var legendDays = ui.Panel({style: {position: 'bottom-right', padding: '8px 15px'}});
legendDays.add(ui.Label({
  value: 'Clear days / ' + DAYS_TOTAL,
  style: {fontWeight:'bold', fontSize:'16px', margin:'0 0 4px 0', padding:'0'}
}));
// Cortes sugeridos para 0..39
var labelsDays = ['0','5','10','15','20','25','30','35','39'];
colorPaletteDays.forEach(function(color, i){
  var box = ui.Label({style:{backgroundColor:color, padding:'8px', margin:'0 0 4px 0'}});
  var lab = ui.Label({value: labelsDays[i], style:{margin:'0 0 4px 6px'}});
  legendDays.add(ui.Panel([box, lab], ui.Panel.Layout.Flow('horizontal')));
});
//Map.add(legendDays);
// ---------- (Opcional) Exportar ----------
/*
Export.image.toAsset({
  image: shadowByHeight.selfMask(),
  description: 'Shadow_bySolarHeight_20260812T1830Z_az284',
  assetId: 'users/tu_usuario/Shadow_bySolarHeight_20260812T1830Z_az284',
  region: geometry,
  scale: 90,
  maxPixels: 1e13
});
Export.image.toAsset({
  image: P_clear_a,
  description: 'Pclear_at_elevation_20260812T1830Z',
  assetId: 'users/tu_usuario/Pclear_at_elevation_20260812T1830Z',
  region: geometry,
  scale: 500,
  maxPixels: 1e13
});
Export.image.toAsset({
  image: clear_days_at_a,
  description: 'ClearDays_at_elevation_20260812T1830Z',
  assetId: 'users/tu_usuario/ClearDays_at_elevation_20260812T1830Z',
  region: geometry,
  scale: 500,
  maxPixels: 1e13
});
*/