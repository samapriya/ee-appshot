var image = ui.import && ui.import("image", "image", {
      "id": "projects/ee-pmisson/assets/ISS072-E-1079023_rotate_modified"
    }) || ee.Image("projects/ee-pmisson/assets/ISS072-E-1079023_rotate_modified"),
    image2 = ui.import && ui.import("image2", "image", {
      "id": "projects/ee-pmisson/assets/ISS072-E-1079024_modified"
    }) || ee.Image("projects/ee-pmisson/assets/ISS072-E-1079024_modified"),
    image3 = ui.import && ui.import("image3", "image", {
      "id": "projects/ee-pmisson/assets/ISS072-E-1079025_modified"
    }) || ee.Image("projects/ee-pmisson/assets/ISS072-E-1079025_modified"),
    image4 = ui.import && ui.import("image4", "image", {
      "id": "projects/ee-pmisson/assets/ISS072-E-1079026_modified"
    }) || ee.Image("projects/ee-pmisson/assets/ISS072-E-1079026_modified"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -70.73904491534424,
            -29.254414887857994
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Point([-70.73904491534424, -29.254414887857994]);
// Función para enmascarar píxeles donde b1, b2 y b3 son cero
function maskZeros(image) {
  var mask = image.select(['b1', 'b2', 'b3'])
                  .reduce(ee.Reducer.sum())
                  .gt(0);  // Crea una máscara donde la suma sea mayor que 0
  return image.updateMask(mask);
}
// Carga y enmascara las imágenes
var image1 = maskZeros(ee.Image("projects/ee-pmisson/assets/ISS072-E-1079023_rotate_modified"));
var image2 = maskZeros(ee.Image("projects/ee-pmisson/assets/ISS072-E-1079024_modified"));
var image3 = maskZeros(ee.Image("projects/ee-pmisson/assets/ISS072-E-1079025_modified"));
var image4 = maskZeros(ee.Image("projects/ee-pmisson/assets/ISS072-E-1079026_modified"));
// Crea el mosaico
var mosaic = ee.ImageCollection([image1, image2, image3, image4]).mosaic();
// Centra el mapa y visualiza
Map.centerObject(image2, 7);
Map.addLayer(mosaic.unmask(0), {bands: ['b1', 'b2', 'b3'], min: 0, max: 255}, 'Mosaico sin ceros');