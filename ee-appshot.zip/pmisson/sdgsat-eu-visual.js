var imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "clouds"
        ],
        "min": 1,
        "max": 3,
        "palette": [
          "1eff02",
          "fcff00",
          "ff0000"
        ]
      }
    }) || {"opacity":1,"bands":["clouds"],"min":1,"max":3,"palette":["1eff02","fcff00","ff0000"]},
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "b1",
          "b2",
          "b3"
        ],
        "min": 7,
        "max": 4000,
        "gamma": 6
      }
    }) || {"opacity":1,"bands":["b1","b2","b3"],"min":7,"max":4000,"gamma":6},
    imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "projects/ee-pmisson/assets/SDGSAT-1_Spain_Clouds2"
    }) || ee.ImageCollection("projects/ee-pmisson/assets/SDGSAT-1_Spain_Clouds2"),
    imageCollection2 = ui.import && ui.import("imageCollection2", "imageCollection", {
      "id": "projects/ee-pmisson/assets/SDGSAT-1_Italy_Clouds2"
    }) || ee.ImageCollection("projects/ee-pmisson/assets/SDGSAT-1_Italy_Clouds2"),
    imageCollection3 = ui.import && ui.import("imageCollection3", "imageCollection", {
      "id": "projects/ee-pmisson/assets/SDGSATCZ_Clouds"
    }) || ee.ImageCollection("projects/ee-pmisson/assets/SDGSATCZ_Clouds"),
    imageCollection5 = ui.import && ui.import("imageCollection5", "imageCollection", {
      "id": "projects/ee-pmisson/assets/SDGSATFR_Clouds"
    }) || ee.ImageCollection("projects/ee-pmisson/assets/SDGSATFR_Clouds"),
    imageCollection6 = ui.import && ui.import("imageCollection6", "imageCollection", {
      "id": "projects/ee-pmisson/assets/SDGSAT_DE_BE_NL_SK_Clouds"
    }) || ee.ImageCollection("projects/ee-pmisson/assets/SDGSAT_DE_BE_NL_SK_Clouds"),
    mosaicRGB3 = ui.import && ui.import("mosaicRGB3", "imageCollection", {
      "id": "users/pmisson/SDGSAT-1/SDGSAT_join"
    }) || ee.ImageCollection("users/pmisson/SDGSAT-1/SDGSAT_join"),
    imageVisParam22 = ui.import && ui.import("imageVisParam22", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "b3"
        ],
        "max": 10,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["b3"],"max":10,"gamma":1},
    imageVisParam3 = ui.import && ui.import("imageVisParam3", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "b1",
          "b2",
          "b3"
        ],
        "min": 8,
        "max": 1000,
        "gamma": 3
      }
    }) || {"opacity":1,"bands":["b1","b2","b3"],"min":8,"max":1000,"gamma":3},
    MosaicRGBX2 = ui.import && ui.import("MosaicRGBX2", "imageCollection", {
      "id": "users/pmisson/SDGSAT-1/SDGSAT1_masked"
    }) || ee.ImageCollection("users/pmisson/SDGSAT-1/SDGSAT1_masked"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -9.895089062499991,
                37.29226128540446
              ],
              [
                -8.195721630009977,
                36.118995096867955
              ],
              [
                -5.151590712099947,
                36.00437410782673
              ],
              [
                -1.9867398371877742,
                36.63035816333691
              ],
              [
                2.761160937499989,
                38.12663231544277
              ],
              [
                4.905796794584472,
                40.364750732164666
              ],
              [
                5.200125781249989,
                43.453581186540276
              ],
              [
                -9.213936718749991,
                43.803477167851305
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -20.096314687664403,
                26.985557386445677
              ],
              [
                -15.174439687664405,
                26.86801435230576
              ],
              [
                -13.087037343914405,
                28.28970606598723
              ],
              [
                -12.537720937664405,
                29.845246683599143
              ],
              [
                -18.668092031414403,
                29.405942405234182
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -17.086060781414403,
                33.655625421871875
              ],
              [
                -18.602174062664403,
                32.625339468946834
              ],
              [
                -16.888306875164403,
                31.7326804589488
              ],
              [
                -14.998658437664405,
                32.994686310798244
              ],
              [
                -15.547974843914405,
                34.038849964422695
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.228944070158065,
                35.92211307669092
              ],
              [
                -5.380006081876815,
                35.91766450343581
              ],
              [
                -5.371766335783065,
                35.874277803985166
              ],
              [
                -5.325074441251815,
                35.85981028735825
              ],
              [
                -5.21383786898619,
                35.85981028735825
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -2.944699676601099,
                35.325897777025695
              ],
              [
                -2.9587759095112554,
                35.31749407321503
              ],
              [
                -2.968045623866724,
                35.30432651463619
              ],
              [
                -2.9711355286518804,
                35.29003588809578
              ],
              [
                -2.966672332851099,
                35.27854551557363
              ],
              [
                -2.950192840663599,
                35.26425033767713
              ],
              [
                -2.929593475429224,
                35.27013689290691
              ],
              [
                -2.9206670838276616,
                35.27826524221525
              ],
              [
                -2.9148305970112554,
                35.29620078157936
              ],
              [
                -2.8956045227925054,
                35.33626114208875
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#bf04c2",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #bf04c2 */
    /* shown: false */
    /* locked: true */
    ee.Geometry({
      "type": "GeometryCollection",
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -9.895089062499991,
                37.29226128540446
              ],
              [
                -8.195721630009977,
                36.118995096867955
              ],
              [
                -5.151590712099947,
                36.00437410782673
              ],
              [
                -1.9867398371877742,
                36.63035816333691
              ],
              [
                2.761160937499989,
                38.12663231544277
              ],
              [
                4.905796794584472,
                40.364750732164666
              ],
              [
                5.200125781249989,
                43.453581186540276
              ],
              [
                -9.213936718749991,
                43.803477167851305
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -20.096314687664403,
                26.985557386445677
              ],
              [
                -15.174439687664405,
                26.86801435230576
              ],
              [
                -13.087037343914405,
                28.28970606598723
              ],
              [
                -12.537720937664405,
                29.845246683599143
              ],
              [
                -18.668092031414403,
                29.405942405234182
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -17.086060781414403,
                33.655625421871875
              ],
              [
                -18.602174062664403,
                32.625339468946834
              ],
              [
                -16.888306875164403,
                31.7326804589488
              ],
              [
                -14.998658437664405,
                32.994686310798244
              ],
              [
                -15.547974843914405,
                34.038849964422695
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.228944070158065,
                35.92211307669092
              ],
              [
                -5.380006081876815,
                35.91766450343581
              ],
              [
                -5.371766335783065,
                35.874277803985166
              ],
              [
                -5.325074441251815,
                35.85981028735825
              ],
              [
                -5.21383786898619,
                35.85981028735825
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -2.944699676601099,
                35.325897777025695
              ],
              [
                -2.9587759095112554,
                35.31749407321503
              ],
              [
                -2.968045623866724,
                35.30432651463619
              ],
              [
                -2.9711355286518804,
                35.29003588809578
              ],
              [
                -2.966672332851099,
                35.27854551557363
              ],
              [
                -2.950192840663599,
                35.26425033767713
              ],
              [
                -2.929593475429224,
                35.27013689290691
              ],
              [
                -2.9206670838276616,
                35.27826524221525
              ],
              [
                -2.9148305970112554,
                35.29620078157936
              ],
              [
                -2.8956045227925054,
                35.33626114208875
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "coordinates": []
    }),
    table = ui.import && ui.import("table", "table", {
      "id": "users/pmisson/NUTs/NUTS_RG_01M_2016_4326_LEVL_3"
    }) || ee.FeatureCollection("users/pmisson/NUTs/NUTS_RG_01M_2016_4326_LEVL_3"),
    imageVisParam4 = ui.import && ui.import("imageVisParam4", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "constant"
        ],
        "min": 731.8785508231963,
        "max": 6586.906957408766,
        "palette": [
          "ff0000",
          "ff8f02",
          "d6fffb",
          "74feff",
          "0e9aff",
          "0007ff"
        ]
      }
    }) || {"opacity":1,"bands":["constant"],"min":731.8785508231963,"max":6586.906957408766,"palette":["ff0000","ff8f02","d6fffb","74feff","0e9aff","0007ff"]},
    imageVisParam42 = ui.import && ui.import("imageVisParam42", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "constant"
        ],
        "min": 1900,
        "max": 3500,
        "palette": [
          "ff0000",
          "ff8f02",
          "ffc900",
          "ffed02",
          "fff9c8",
          "def7ff",
          "4fe6ff",
          "22eaff",
          "0c99ff",
          "0500ff",
          "7f08ff"
        ]
      }
    }) || {"opacity":1,"bands":["constant"],"min":1900,"max":3500,"palette":["ff0000","ff8f02","ffc900","ffed02","fff9c8","def7ff","4fe6ff","22eaff","0c99ff","0500ff","7f08ff"]},
    imageVisParam5 = ui.import && ui.import("imageVisParam5", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "R",
          "G",
          "B"
        ],
        "min": 0.000306129228,
        "max": 0.013004780172,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["R","G","B"],"min":0.000306129228,"max":0.013004780172,"gamma":1},
    imageVisParam6 = ui.import && ui.import("imageVisParam6", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "constant"
        ],
        "min": 731.8785508231963,
        "max": 6586.906957408766,
        "palette": [
          "ff0000",
          "ff8f02",
          "95fff6",
          "55bfff",
          "0a76ff",
          "0007ff"
        ]
      }
    }) || {"opacity":1,"bands":["constant"],"min":731.8785508231963,"max":6586.906957408766,"palette":["ff0000","ff8f02","95fff6","55bfff","0a76ff","0007ff"]},
    mosaicRGB2 = ui.import && ui.import("mosaicRGB2", "imageCollection", {
      "id": "users/pmisson/SDGSAT-1/sdgsat_SPAIN_2"
    }) || ee.ImageCollection("users/pmisson/SDGSAT-1/sdgsat_SPAIN_2"),
    mosaicRGBX = ui.import && ui.import("mosaicRGBX", "imageCollection", {
      "id": "users/pmisson/SDGSAT-1/Iberianpeninsula2"
    }) || ee.ImageCollection("users/pmisson/SDGSAT-1/Iberianpeninsula2"),
    geometry2 = ui.import && ui.import("geometry2", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -16.96797303008263,
                28.70165050159554
              ],
              [
                -16.96797303008263,
                27.964304756016283
              ],
              [
                -16.06709412383263,
                27.964304756016283
              ],
              [
                -16.06709412383263,
                28.70165050159554
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* locked: true */
    ee.Geometry.Polygon(
        [[[-16.96797303008263, 28.70165050159554],
          [-16.96797303008263, 27.964304756016283],
          [-16.06709412383263, 27.964304756016283],
          [-16.06709412383263, 28.70165050159554]]], null, false),
    imageVisParam7 = ui.import && ui.import("imageVisParam7", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "constant"
        ],
        "min": 1600,
        "max": 5000,
        "palette": [
          "ff8c00",
          "ff881e",
          "ffc518",
          "fff12f",
          "ffffff",
          "dcffff",
          "a9d7ff",
          "add8ff",
          "97c5ff",
          "4596ff",
          "3b76ff",
          "3500ff",
          "1200ff"
        ]
      }
    }) || {"opacity":1,"bands":["constant"],"min":1600,"max":5000,"palette":["ff8c00","ff881e","ffc518","fff12f","ffffff","dcffff","a9d7ff","add8ff","97c5ff","4596ff","3b76ff","3500ff","1200ff"]},
    gaul = ui.import && ui.import("gaul", "table", {
      "id": "FAO/GAUL/2015/level2"
    }) || ee.FeatureCollection("FAO/GAUL/2015/level2"),
    imageXXX = ui.import && ui.import("imageXXX", "image", {
      "id": "projects/ee-pmisson/assets/yjzxlogo_modificado"
    }) || ee.Image("projects/ee-pmisson/assets/yjzxlogo_modificado"),
    geometry3 = ui.import && ui.import("geometry3", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6474659179352042,
                40.55845309562446
              ],
              [
                -3.638882849087548,
                40.554344785875415
              ],
              [
                -3.632617208828759,
                40.547040501647565
              ],
              [
                -3.631072256436181,
                40.55362743609989
              ],
              [
                -3.6345054839752433,
                40.5574749495026
              ],
              [
                -3.627724859585595,
                40.55969206019604
              ],
              [
                -3.6275531982086417,
                40.56269156367325
              ],
              [
                -3.637509558071923,
                40.55910518509937
              ],
              [
                -3.6430885528228996,
                40.56236553719722
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.804303379863012,
                37.77699900595535
              ],
              [
                -3.790227146952856,
                37.777609569388936
              ],
              [
                -3.790398808329809,
                37.7810014966357
              ],
              [
                -3.8049900253708246,
                37.77998393480418
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6367756696265086,
                37.20245691333138
              ],
              [
                -3.631368336252485,
                37.20570415655798
              ],
              [
                -3.6363465161841257,
                37.21069438431751
              ],
              [
                -3.6420971723120554,
                37.20809677269136
              ],
              [
                -3.6375480464040244,
                37.20637065574602
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -6.9051148585241435,
                38.88996330752427
              ],
              [
                -6.904857366458714,
                38.88662289969552
              ],
              [
                -6.898935048953831,
                38.88675651902454
              ],
              [
                -6.89970752515012,
                38.88962927380989
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.8599080948364084,
                40.32128673271457
              ],
              [
                -3.860594740344221,
                40.32639083778392
              ],
              [
                -3.8679761795532053,
                40.324296892647965
              ],
              [
                -3.865057936145002,
                40.31775289543709
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.8434640253108392,
                38.98335674541821
              ],
              [
                -1.843120702556933,
                38.978019051389644
              ],
              [
                -1.836254247478808,
                38.97948695736133
              ],
              [
                -1.8401166284602533,
                38.98308987027377
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.8565235395325952,
                38.98713471367722
              ],
              [
                -1.8605575818909936,
                38.98893599845428
              ],
              [
                -1.863218333233767,
                38.985600249749595
              ],
              [
                -1.859098460186892,
                38.984199188418735
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.8584547300233178,
                38.982597941516076
              ],
              [
                -1.8547640104188257,
                38.982497862382154
              ],
              [
                -1.8543777723206811,
                38.98309833506357
              ],
              [
                -1.8582830686463647,
                38.983131694507655
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.840948532839417,
                38.9884704738115
              ],
              [
                -1.843695114870667,
                38.986469030289186
              ],
              [
                -1.8416351783472296,
                38.985201420122316
              ],
              [
                -1.8387169349390264,
                38.98820361794484
              ],
              [
                -1.8414635169702764,
                38.98953788721763
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.8479866492944952,
                38.99360725315687
              ],
              [
                -1.843695114870667,
                38.99374067102953
              ],
              [
                -1.847643326540589,
                38.99767638511758
              ],
              [
                -1.8510765540796514,
                38.996542388252834
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6434828381246076,
            37.2058707877872
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6449848751729474,
            37.20716964308999
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.645499859303807,
            37.20773361277393
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.646122131795262,
            37.20819503938037
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6440407375997053,
            37.20626386477723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6412083248799787,
            37.202640642811936
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.636251602620457,
            37.20200827020715
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.666051426495638,
            37.205475572923085
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6710296064272785,
            37.21019238637808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.671287098492708,
            37.20944045036405
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6823592573061847,
            37.211491167298746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6894832044497394,
            37.214635491683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.638585606183138,
            37.19898092708949
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.635839024151888,
            37.1989125594243
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6272559553042316,
            37.20916701722842
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.640302219952669,
            37.21306334587084
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6412463575259113,
            37.212243082876974
          ]
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.900734153832377,
                40.41397931907097
              ],
              [
                -3.90116330727476,
                40.417900191795304
              ],
              [
                -3.9082872544183145,
                40.420187262036265
              ],
              [
                -3.910948005761088,
                40.41770415358556
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.8588208415343983,
                40.494933578597134
              ],
              [
                -3.8565892436340077,
                40.497218028079224
              ],
              [
                -3.870493815167211,
                40.50426669616134
              ],
              [
                -3.8703221537902577,
                40.499893998545836
              ],
              [
                -3.865343973858617,
                40.499371866348525
              ],
              [
                -3.8631123759582264,
                40.49610844804561
              ],
              [
                -3.8607091166808827,
                40.493954505008354
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.893074861362793,
                40.49996260338143
              ],
              [
                -3.8879250200541993,
                40.49917940436245
              ],
              [
                -3.8841484697612305,
                40.4982656606173
              ],
              [
                -3.8888691576274415,
                40.505183696504005
              ],
              [
                -3.895993104770996,
                40.506293126438244
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0c02d6",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #0c02d6 */
    /* shown: false */
    /* locked: true */
    ee.Geometry({
      "type": "GeometryCollection",
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6474659179352042,
                40.55845309562446
              ],
              [
                -3.638882849087548,
                40.554344785875415
              ],
              [
                -3.632617208828759,
                40.547040501647565
              ],
              [
                -3.631072256436181,
                40.55362743609989
              ],
              [
                -3.6345054839752433,
                40.5574749495026
              ],
              [
                -3.627724859585595,
                40.55969206019604
              ],
              [
                -3.6275531982086417,
                40.56269156367325
              ],
              [
                -3.637509558071923,
                40.55910518509937
              ],
              [
                -3.6430885528228996,
                40.56236553719722
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.804303379863012,
                37.77699900595535
              ],
              [
                -3.790227146952856,
                37.777609569388936
              ],
              [
                -3.790398808329809,
                37.7810014966357
              ],
              [
                -3.8049900253708246,
                37.77998393480418
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6367756696265086,
                37.20245691333138
              ],
              [
                -3.631368336252485,
                37.20570415655798
              ],
              [
                -3.6363465161841257,
                37.21069438431751
              ],
              [
                -3.6420971723120554,
                37.20809677269136
              ],
              [
                -3.6375480464040244,
                37.20637065574602
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -6.9051148585241435,
                38.88996330752427
              ],
              [
                -6.904857366458714,
                38.88662289969552
              ],
              [
                -6.898935048953831,
                38.88675651902454
              ],
              [
                -6.89970752515012,
                38.88962927380989
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.8599080948364084,
                40.32128673271457
              ],
              [
                -3.860594740344221,
                40.32639083778392
              ],
              [
                -3.8679761795532053,
                40.324296892647965
              ],
              [
                -3.865057936145002,
                40.31775289543709
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.8434640253108392,
                38.98335674541821
              ],
              [
                -1.843120702556933,
                38.978019051389644
              ],
              [
                -1.836254247478808,
                38.97948695736133
              ],
              [
                -1.8401166284602533,
                38.98308987027377
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.8565235395325952,
                38.98713471367722
              ],
              [
                -1.8605575818909936,
                38.98893599845428
              ],
              [
                -1.863218333233767,
                38.985600249749595
              ],
              [
                -1.859098460186892,
                38.984199188418735
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.8584547300233178,
                38.982597941516076
              ],
              [
                -1.8547640104188257,
                38.982497862382154
              ],
              [
                -1.8543777723206811,
                38.98309833506357
              ],
              [
                -1.8582830686463647,
                38.983131694507655
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.840948532839417,
                38.9884704738115
              ],
              [
                -1.843695114870667,
                38.986469030289186
              ],
              [
                -1.8416351783472296,
                38.985201420122316
              ],
              [
                -1.8387169349390264,
                38.98820361794484
              ],
              [
                -1.8414635169702764,
                38.98953788721763
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.8479866492944952,
                38.99360725315687
              ],
              [
                -1.843695114870667,
                38.99374067102953
              ],
              [
                -1.847643326540589,
                38.99767638511758
              ],
              [
                -1.8510765540796514,
                38.996542388252834
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6434828381246076,
            37.2058707877872
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6449848751729474,
            37.20716964308999
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.645499859303807,
            37.20773361277393
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.646122131795262,
            37.20819503938037
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6440407375997053,
            37.20626386477723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6412083248799787,
            37.202640642811936
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.636251602620457,
            37.20200827020715
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.666051426495638,
            37.205475572923085
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6710296064272785,
            37.21019238637808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.671287098492708,
            37.20944045036405
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6823592573061847,
            37.211491167298746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6894832044497394,
            37.214635491683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.638585606183138,
            37.19898092708949
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.635839024151888,
            37.1989125594243
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6272559553042316,
            37.20916701722842
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.640302219952669,
            37.21306334587084
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6412463575259113,
            37.212243082876974
          ]
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.900734153832377,
                40.41397931907097
              ],
              [
                -3.90116330727476,
                40.417900191795304
              ],
              [
                -3.9082872544183145,
                40.420187262036265
              ],
              [
                -3.910948005761088,
                40.41770415358556
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.8588208415343983,
                40.494933578597134
              ],
              [
                -3.8565892436340077,
                40.497218028079224
              ],
              [
                -3.870493815167211,
                40.50426669616134
              ],
              [
                -3.8703221537902577,
                40.499893998545836
              ],
              [
                -3.865343973858617,
                40.499371866348525
              ],
              [
                -3.8631123759582264,
                40.49610844804561
              ],
              [
                -3.8607091166808827,
                40.493954505008354
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.893074861362793,
                40.49996260338143
              ],
              [
                -3.8879250200541993,
                40.49917940436245
              ],
              [
                -3.8841484697612305,
                40.4982656606173
              ],
              [
                -3.8888691576274415,
                40.505183696504005
              ],
              [
                -3.895993104770996,
                40.506293126438244
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "coordinates": []
    }),
    geometry4 = ui.import && ui.import("geometry4", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7580099846194304,
                40.33641527595336
              ],
              [
                -3.756121709472946,
                40.33065762579049
              ],
              [
                -3.7516585136721647,
                40.33222794273652
              ],
              [
                -3.7526884819338835,
                40.33576102226647
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7489928123807204,
                40.25945646875216
              ],
              [
                -3.7546576378201735,
                40.25460932366894
              ],
              [
                -3.748477828249861,
                40.25198910067373
              ],
              [
                -3.745731246218611,
                40.2581464637816
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.554689780551159,
                37.21061639073633
              ],
              [
                -3.5552476800262567,
                37.21253036511391
              ],
              [
                -3.556492225009167,
                37.212598720443744
              ],
              [
                -3.5585950768768426,
                37.20856565002708
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.8218542340650963,
                40.41181176645342
              ],
              [
                -3.823055863703768,
                40.40958976558583
              ],
              [
                -3.827776551569979,
                40.40749840363275
              ],
              [
                -3.8276907208815025,
                40.40671412614578
              ],
              [
                -3.822111726130526,
                40.40874015763026
              ],
              [
                -3.820566773737948,
                40.41246528215798
              ],
              [
                -3.821167588557284,
                40.41534067586016
              ],
              [
                -3.822540879572909,
                40.41501393276382
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.828034043635409,
                40.38743109755787
              ],
              [
                -3.8257166150465416,
                40.38501215844493
              ],
              [
                -3.8229700330152916,
                40.383835345844055
              ],
              [
                -3.819965958918612,
                40.38337769094691
              ],
              [
                -3.819965958918612,
                40.383966103815
              ],
              [
                -3.822884202326815,
                40.38448913316056
              ],
              [
                -3.8259741071119713,
                40.38645045703646
              ],
              [
                -3.828205705012362,
                40.389523082950525
              ],
              [
                -3.82975065740494,
                40.389523082950525
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6331878901573322,
                37.18659916570643
              ],
              [
                -3.630698800191512,
                37.18509481609839
              ],
              [
                -3.62675058852159,
                37.18283823550209
              ],
              [
                -3.623660683736434,
                37.18147057808598
              ],
              [
                -3.6215149165245197,
                37.18023966523859
              ],
              [
                -3.617566704854598,
                37.17866680296614
              ],
              [
                -3.616536736592879,
                37.17928227471208
              ],
              [
                -3.619111657247176,
                37.18010289590627
              ],
              [
                -3.6228882075401447,
                37.182496323469664
              ],
              [
                -3.6256347895713947,
                37.183385291534655
              ],
              [
                -3.6280380488487385,
                37.18502643585877
              ],
              [
                -3.6311279536338947,
                37.186257270699485
              ],
              [
                -3.6321579218956135,
                37.18837699479185
              ],
              [
                -3.6335312129112385,
                37.18844537199776
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6466633082481525,
                37.19159065654142
              ],
              [
                -3.6445175410362385,
                37.19131715873845
              ],
              [
                -3.6441742182823322,
                37.192958130696695
              ],
              [
                -3.646405816182723,
                37.19343674079999
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7007604296373575,
                37.16026619752964
              ],
              [
                -3.6981855089830606,
                37.1578720657494
              ],
              [
                -3.694151466624662,
                37.156435550287085
              ],
              [
                -3.6934648211168497,
                37.15835089817118
              ],
              [
                -3.6929498369859903,
                37.16231825013547
              ],
              [
                -3.6970697100328653,
                37.16300225529131
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ffb900",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #ffb900 */
    /* shown: false */
    /* locked: true */
    ee.Geometry({
      "type": "GeometryCollection",
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7580099846194304,
                40.33641527595336
              ],
              [
                -3.756121709472946,
                40.33065762579049
              ],
              [
                -3.7516585136721647,
                40.33222794273652
              ],
              [
                -3.7526884819338835,
                40.33576102226647
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7489928123807204,
                40.25945646875216
              ],
              [
                -3.7546576378201735,
                40.25460932366894
              ],
              [
                -3.748477828249861,
                40.25198910067373
              ],
              [
                -3.745731246218611,
                40.2581464637816
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.554689780551159,
                37.21061639073633
              ],
              [
                -3.5552476800262567,
                37.21253036511391
              ],
              [
                -3.556492225009167,
                37.212598720443744
              ],
              [
                -3.5585950768768426,
                37.20856565002708
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.8218542340650963,
                40.41181176645342
              ],
              [
                -3.823055863703768,
                40.40958976558583
              ],
              [
                -3.827776551569979,
                40.40749840363275
              ],
              [
                -3.8276907208815025,
                40.40671412614578
              ],
              [
                -3.822111726130526,
                40.40874015763026
              ],
              [
                -3.820566773737948,
                40.41246528215798
              ],
              [
                -3.821167588557284,
                40.41534067586016
              ],
              [
                -3.822540879572909,
                40.41501393276382
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.828034043635409,
                40.38743109755787
              ],
              [
                -3.8257166150465416,
                40.38501215844493
              ],
              [
                -3.8229700330152916,
                40.383835345844055
              ],
              [
                -3.819965958918612,
                40.38337769094691
              ],
              [
                -3.819965958918612,
                40.383966103815
              ],
              [
                -3.822884202326815,
                40.38448913316056
              ],
              [
                -3.8259741071119713,
                40.38645045703646
              ],
              [
                -3.828205705012362,
                40.389523082950525
              ],
              [
                -3.82975065740494,
                40.389523082950525
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6331878901573322,
                37.18659916570643
              ],
              [
                -3.630698800191512,
                37.18509481609839
              ],
              [
                -3.62675058852159,
                37.18283823550209
              ],
              [
                -3.623660683736434,
                37.18147057808598
              ],
              [
                -3.6215149165245197,
                37.18023966523859
              ],
              [
                -3.617566704854598,
                37.17866680296614
              ],
              [
                -3.616536736592879,
                37.17928227471208
              ],
              [
                -3.619111657247176,
                37.18010289590627
              ],
              [
                -3.6228882075401447,
                37.182496323469664
              ],
              [
                -3.6256347895713947,
                37.183385291534655
              ],
              [
                -3.6280380488487385,
                37.18502643585877
              ],
              [
                -3.6311279536338947,
                37.186257270699485
              ],
              [
                -3.6321579218956135,
                37.18837699479185
              ],
              [
                -3.6335312129112385,
                37.18844537199776
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6466633082481525,
                37.19159065654142
              ],
              [
                -3.6445175410362385,
                37.19131715873845
              ],
              [
                -3.6441742182823322,
                37.192958130696695
              ],
              [
                -3.646405816182723,
                37.19343674079999
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7007604296373575,
                37.16026619752964
              ],
              [
                -3.6981855089830606,
                37.1578720657494
              ],
              [
                -3.694151466624662,
                37.156435550287085
              ],
              [
                -3.6934648211168497,
                37.15835089817118
              ],
              [
                -3.6929498369859903,
                37.16231825013547
              ],
              [
                -3.6970697100328653,
                37.16300225529131
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "coordinates": []
    }),
    geometry5 = ui.import && ui.import("geometry5", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.703330886111189,
                40.256312414211486
              ],
              [
                -3.6969794151639235,
                40.256181408768505
              ],
              [
                -3.696721954340203,
                40.258768709912836
              ],
              [
                -3.694919478640486,
                40.2591944697872
              ],
              [
                -3.6932028648709547,
                40.260438955834964
              ],
              [
                -3.6965502617215407,
                40.26129043309929
              ],
              [
                -3.700069324851838,
                40.26004607305313
              ],
              [
                -3.7028159019803297,
                40.26161792150131
              ],
              [
                -3.7033308962068534,
                40.259096168195015
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.5709529051808686,
                37.143877116686426
              ],
              [
                -3.5658888945607514,
                37.14647693735795
              ],
              [
                -3.5709529051808686,
                37.150513323939464
              ],
              [
                -3.5752444396046967,
                37.14688742718957
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -0.4286077716447978,
                39.434791637160416
              ],
              [
                -0.4320409991838603,
                39.432405114490386
              ],
              [
                -0.42620451236745405,
                39.4312118224993
              ],
              [
                -0.42225630069753217,
                39.432802873945796
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Point",
          "coordinates": [
            -3.9929563489462683,
            40.436997270994134
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.995187946846659,
            40.43379615107146
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.9974195447470495,
            40.43392681201075
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.997934528877909,
            40.4343841232989
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8932938949653884,
            40.45368511574363
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.894323863227107,
            40.454272914022845
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8943667785713454,
            40.45486070716011
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8935084716865798,
            40.455154601800515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.893379725653865,
            40.45564442334453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.889131106574275,
            40.45006024606688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8903756515571852,
            40.451039959856104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8910622970649977,
            40.45172575101024
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.892478503424861,
            40.453195279916436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.746753500274036,
            40.28883909035806
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.742461965850208,
            40.291196011038465
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.749328420928333,
            40.29041037994436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7532766325982547,
            40.28936285761245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7512166960748172,
            40.28831531904471
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.818164633086536,
            40.28268452108174
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8203962309869266,
            40.28189879105213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.822112844756458,
            40.2829464290622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7017782195123172,
            40.25177225559683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.695770071318958,
            40.23604873681713
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.704009817412708,
            40.23814541699541
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.705726431182239,
            40.2374902114139
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7640912993463016,
            40.23552455662826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.767181204131458,
            40.23395199171564
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.768554495147083,
            40.232379390284194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7725027068170047,
            40.23932477106471
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7719877226861454,
            40.24024203224974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7747343047173954,
            40.237752294407336
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7762792571099735,
            40.23958684695707
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.5608958318314565,
            37.15253509097618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.5593508794388784,
            37.152603500622305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.563127429731847,
            37.15253509097618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.564500720747472,
            37.15219304181719
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.5612391545853628,
            37.14733577677962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.5604666783890737,
            37.14733577677962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.5777186467728628,
            37.15123529594054
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6248913156173534,
            37.141105185480455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6233463632247753,
            37.14014729918417
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6241188394210644,
            37.13665775367603
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6233463632247753,
            37.135289260520764
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6254921304366894,
            37.13768410729851
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.613819156803877,
            37.139394665728055
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.52458632336586,
            36.60898158348622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.5075918470475,
            36.61780006853196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.879899998632888,
            36.51146058410107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.880243321386795,
            36.51008086431734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.8951778611817165,
            36.52525642916877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.956460972753982,
            36.48758796442094
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ffff0e",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #ffff0e */
    /* shown: false */
    /* locked: true */
    ee.Geometry({
      "type": "GeometryCollection",
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.703330886111189,
                40.256312414211486
              ],
              [
                -3.6969794151639235,
                40.256181408768505
              ],
              [
                -3.696721954340203,
                40.258768709912836
              ],
              [
                -3.694919478640486,
                40.2591944697872
              ],
              [
                -3.6932028648709547,
                40.260438955834964
              ],
              [
                -3.6965502617215407,
                40.26129043309929
              ],
              [
                -3.700069324851838,
                40.26004607305313
              ],
              [
                -3.7028159019803297,
                40.26161792150131
              ],
              [
                -3.7033308962068534,
                40.259096168195015
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.5709529051808686,
                37.143877116686426
              ],
              [
                -3.5658888945607514,
                37.14647693735795
              ],
              [
                -3.5709529051808686,
                37.150513323939464
              ],
              [
                -3.5752444396046967,
                37.14688742718957
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -0.4286077716447978,
                39.434791637160416
              ],
              [
                -0.4320409991838603,
                39.432405114490386
              ],
              [
                -0.42620451236745405,
                39.4312118224993
              ],
              [
                -0.42225630069753217,
                39.432802873945796
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Point",
          "coordinates": [
            -3.9929563489462683,
            40.436997270994134
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.995187946846659,
            40.43379615107146
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.9974195447470495,
            40.43392681201075
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.997934528877909,
            40.4343841232989
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8932938949653884,
            40.45368511574363
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.894323863227107,
            40.454272914022845
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8943667785713454,
            40.45486070716011
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8935084716865798,
            40.455154601800515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.893379725653865,
            40.45564442334453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.889131106574275,
            40.45006024606688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8903756515571852,
            40.451039959856104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8910622970649977,
            40.45172575101024
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.892478503424861,
            40.453195279916436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.746753500274036,
            40.28883909035806
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.742461965850208,
            40.291196011038465
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.749328420928333,
            40.29041037994436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7532766325982547,
            40.28936285761245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7512166960748172,
            40.28831531904471
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.818164633086536,
            40.28268452108174
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.8203962309869266,
            40.28189879105213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.822112844756458,
            40.2829464290622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7017782195123172,
            40.25177225559683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.695770071318958,
            40.23604873681713
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.704009817412708,
            40.23814541699541
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.705726431182239,
            40.2374902114139
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7640912993463016,
            40.23552455662826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.767181204131458,
            40.23395199171564
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.768554495147083,
            40.232379390284194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7725027068170047,
            40.23932477106471
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7719877226861454,
            40.24024203224974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7747343047173954,
            40.237752294407336
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.7762792571099735,
            40.23958684695707
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.5608958318314565,
            37.15253509097618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.5593508794388784,
            37.152603500622305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.563127429731847,
            37.15253509097618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.564500720747472,
            37.15219304181719
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.5612391545853628,
            37.14733577677962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.5604666783890737,
            37.14733577677962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.5777186467728628,
            37.15123529594054
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6248913156173534,
            37.141105185480455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6233463632247753,
            37.14014729918417
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6241188394210644,
            37.13665775367603
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6233463632247753,
            37.135289260520764
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.6254921304366894,
            37.13768410729851
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -3.613819156803877,
            37.139394665728055
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.52458632336586,
            36.60898158348622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.5075918470475,
            36.61780006853196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.879899998632888,
            36.51146058410107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.880243321386795,
            36.51008086431734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.8951778611817165,
            36.52525642916877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -4.956460972753982,
            36.48758796442094
          ]
        }
      ],
      "coordinates": []
    }),
    geometry6 = ui.import && ui.import("geometry6", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6365104088711475,
                38.103333466449406
              ],
              [
                -3.6402869591641163,
                38.10150986117145
              ],
              [
                -3.6415744194912647,
                38.09860550695187
              ],
              [
                -3.6317897210049366,
                38.102387899023825
              ],
              [
                -3.6333346733975147,
                38.11157289319128
              ],
              [
                -3.637969530575249,
                38.111302762787425
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -6.938610017498063,
                38.92317976341236
              ],
              [
                -6.9459914567070475,
                38.919173130222575
              ],
              [
                -6.943759858806657,
                38.918371776435116
              ],
              [
                -6.936550080974626,
                38.920375143935445
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#f7ffe2",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #f7ffe2 */
    /* shown: false */
    /* locked: true */
    ee.Geometry.MultiPolygon(
        [[[[-3.6365104088711475, 38.103333466449406],
           [-3.6402869591641163, 38.10150986117145],
           [-3.6415744194912647, 38.09860550695187],
           [-3.6317897210049366, 38.102387899023825],
           [-3.6333346733975147, 38.11157289319128],
           [-3.637969530575249, 38.111302762787425]]],
         [[[-6.938610017498063, 38.92317976341236],
           [-6.9459914567070475, 38.919173130222575],
           [-6.943759858806657, 38.918371776435116],
           [-6.936550080974626, 38.920375143935445]]]]),
    geometry7 = ui.import && ui.import("geometry7", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.799694300028378,
                40.32449652688825
              ],
              [
                -3.7999517920938075,
                40.323024187175754
              ],
              [
                -3.798192262980038,
                40.32430021678202
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7145532921863977,
                37.145282573743366
              ],
              [
                -3.7134267640895313,
                37.14721103409399
              ],
              [
                -3.713920289402926,
                37.148181660720404
              ],
              [
                -3.7161357980577043,
                37.14830566052123
              ],
              [
                -3.7166776046765526,
                37.146856132828475
              ],
              [
                -3.7166561470044135,
                37.145573343557416
              ],
              [
                -3.715518888285776,
                37.14607790962799
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7174155553930266,
                37.14275067498664
              ],
              [
                -3.7172653516881926,
                37.140852037001295
              ],
              [
                -3.7146689733617766,
                37.13951783044813
              ],
              [
                -3.7140681585424407,
                37.14020204187642
              ],
              [
                -3.7157418569677336,
                37.14174149496369
              ],
              [
                -3.7164928754919035,
                37.14316118504193
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7215354284399016,
                37.14215201049582
              ],
              [
                -3.720505460178183,
                37.140903352167996
              ],
              [
                -3.7200333913915618,
                37.14174149496369
              ],
              [
                -3.7204625448339446,
                37.14249410507074
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.715033753787802,
                37.143417752695115
              ],
              [
                -3.714754804050253,
                37.14442691035414
              ],
              [
                -3.7152912458532317,
                37.145230805972986
              ],
              [
                -3.716235383426474,
                37.145162389657216
              ],
              [
                -3.7163212141149504,
                37.14367431947807
              ],
              [
                -3.715055211459921,
                37.14353748396879
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7135746320837004,
                37.145932069641454
              ],
              [
                -3.7139199993108774,
                37.14475189046296
              ],
              [
                -3.7129114887212777,
                37.144204554738316
              ],
              [
                -3.712503792951014,
                37.14153623636216
              ],
              [
                -3.711130501935389,
                37.141519131453556
              ],
              [
                -3.711430909345057,
                37.14458084847448
              ],
              [
                -3.71235358924618,
                37.145641302567995
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.716288710590019,
                37.131895915983556
              ],
              [
                -3.712941313739433,
                37.13163930925378
              ],
              [
                -3.711138869281425,
                37.13355528516155
              ],
              [
                -3.708649779315605,
                37.13533436220768
              ],
              [
                -3.709143305774345,
                37.13244334076546
              ],
              [
                -3.708671236987724,
                37.130783947203255
              ],
              [
                -3.7122975835758587,
                37.12814937133906
              ],
              [
                -3.7140571126896282,
                37.12700313113019
              ],
              [
                -3.712791110034599,
                37.12645566699423
              ],
              [
                -3.7098299512821575,
                37.1276190235496
              ],
              [
                -3.7081562528568646,
                37.12955220886496
              ],
              [
                -3.7067829618412396,
                37.13066419574463
              ],
              [
                -3.7071048269230267,
                37.131913023067945
              ],
              [
                -3.7073623189884564,
                37.13299076158712
              ],
              [
                -3.7070619115787884,
                37.134239550514344
              ],
              [
                -3.7085854062992474,
                37.13577912493306
              ],
              [
                -3.711439276691093,
                37.13521461795031
              ],
              [
                -3.713563586230888,
                37.13374345875043
              ],
              [
                -3.7145291814762493,
                37.13276837235594
              ],
              [
                -3.716481829639091,
                37.13300786842395
              ],
              [
                -3.718606139178886,
                37.13234069892053
              ],
              [
                -3.7181984434086224,
                37.12975749998026
              ],
              [
                -3.7160526761967083,
                37.12823491095706
              ],
              [
                -3.714915419574394,
                37.128012507749204
              ],
              [
                -3.7152802000004193,
                37.130236510416886
              ],
              [
                -3.7173186788517376,
                37.130903698472366
              ],
              [
                -3.7166749486881634,
                37.131947237225106
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.5844277927598545,
                40.341522495414516
              ],
              [
                -3.5838055202683994,
                40.340279502080676
              ],
              [
                -3.5805868694505283,
                40.342422015780045
              ],
              [
                -3.5817241260728427,
                40.34359955158494
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.5783338138780185,
                40.3457910218292
              ],
              [
                -3.5774540493211338,
                40.34466258708767
              ],
              [
                -3.5756945202073642,
                40.34544758716716
              ],
              [
                -3.575351197453458,
                40.34690308397453
              ],
              [
                -3.5761880466661045,
                40.34749181533462
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6257653970883363,
                40.33604446664219
              ],
              [
                -3.6261087198422426,
                40.33486679896637
              ],
              [
                -3.6219888467953676,
                40.33512850467058
              ],
              [
                -3.6142211694882387,
                40.33692770391054
              ],
              [
                -3.606496407525348,
                40.33885770066825
              ],
              [
                -3.597077530009556,
                40.341245586345586
              ],
              [
                -3.592056434733677,
                40.34297920381221
              ],
              [
                -3.593000572306919,
                40.344091312314745
              ],
              [
                -3.598622482402134,
                40.34222688472297
              ],
              [
                -3.6064759903977395,
                40.340296984345834
              ],
              [
                -3.6151448899338723,
                40.338301605569484
              ],
              [
                -3.6202518158982278,
                40.336862279324194
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6755701516871375,
                40.29193704878687
              ],
              [
                -3.6746260141138953,
                40.29102048833939
              ],
              [
                -3.673810622573368,
                40.29167517564175
              ],
              [
                -3.673982283950321,
                40.29383559874142
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.671664855361454,
                40.295537701629186
              ],
              [
                -3.6707207177882117,
                40.29406473047359
              ],
              [
                -3.669991156936161,
                40.2952103774805
              ],
              [
                -3.670634887099735,
                40.2960614169691
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6700769876246375,
                40.29710883547151
              ],
              [
                -3.66951908814954,
                40.29583229200736
              ],
              [
                -3.6590477441553992,
                40.30264024512855
              ],
              [
                -3.6601206277613563,
                40.30339300551477
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6563598193792624,
                40.306460397793614
              ],
              [
                -3.659063486066274,
                40.30408764543497
              ],
              [
                -3.65816226383727,
                40.303105792493085
              ],
              [
                -3.6545144595770163,
                40.305789490061116
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.206117159911968,
                40.71791335786246
              ],
              [
                -4.206632144042827,
                40.71648216129862
              ],
              [
                -4.201525218078472,
                40.71570149565892
              ],
              [
                -4.200838572570659,
                40.716612271348595
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6407288264755167,
                40.32587312503433
              ],
              [
                -3.6400636386398233,
                40.3259222014708
              ],
              [
                -3.640042180967704,
                40.3270018740459
              ],
              [
                -3.6406859111312784,
                40.3270018740459
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.9232791357549113,
                37.1429669683455
              ],
              [
                -3.92156252198538,
                37.14433532261956
              ],
              [
                -3.9273990088017863,
                37.14885071608844
              ],
              [
                -3.9287722998174113,
                37.14748244350575
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ff0000",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #ff0000 */
    /* shown: false */
    /* locked: true */
    ee.Geometry({
      "type": "GeometryCollection",
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.799694300028378,
                40.32449652688825
              ],
              [
                -3.7999517920938075,
                40.323024187175754
              ],
              [
                -3.798192262980038,
                40.32430021678202
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7145532921863977,
                37.145282573743366
              ],
              [
                -3.7134267640895313,
                37.14721103409399
              ],
              [
                -3.713920289402926,
                37.148181660720404
              ],
              [
                -3.7161357980577043,
                37.14830566052123
              ],
              [
                -3.7166776046765526,
                37.146856132828475
              ],
              [
                -3.7166561470044135,
                37.145573343557416
              ],
              [
                -3.715518888285776,
                37.14607790962799
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7174155553930266,
                37.14275067498664
              ],
              [
                -3.7172653516881926,
                37.140852037001295
              ],
              [
                -3.7146689733617766,
                37.13951783044813
              ],
              [
                -3.7140681585424407,
                37.14020204187642
              ],
              [
                -3.7157418569677336,
                37.14174149496369
              ],
              [
                -3.7164928754919035,
                37.14316118504193
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7215354284399016,
                37.14215201049582
              ],
              [
                -3.720505460178183,
                37.140903352167996
              ],
              [
                -3.7200333913915618,
                37.14174149496369
              ],
              [
                -3.7204625448339446,
                37.14249410507074
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.715033753787802,
                37.143417752695115
              ],
              [
                -3.714754804050253,
                37.14442691035414
              ],
              [
                -3.7152912458532317,
                37.145230805972986
              ],
              [
                -3.716235383426474,
                37.145162389657216
              ],
              [
                -3.7163212141149504,
                37.14367431947807
              ],
              [
                -3.715055211459921,
                37.14353748396879
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.7135746320837004,
                37.145932069641454
              ],
              [
                -3.7139199993108774,
                37.14475189046296
              ],
              [
                -3.7129114887212777,
                37.144204554738316
              ],
              [
                -3.712503792951014,
                37.14153623636216
              ],
              [
                -3.711130501935389,
                37.141519131453556
              ],
              [
                -3.711430909345057,
                37.14458084847448
              ],
              [
                -3.71235358924618,
                37.145641302567995
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.716288710590019,
                37.131895915983556
              ],
              [
                -3.712941313739433,
                37.13163930925378
              ],
              [
                -3.711138869281425,
                37.13355528516155
              ],
              [
                -3.708649779315605,
                37.13533436220768
              ],
              [
                -3.709143305774345,
                37.13244334076546
              ],
              [
                -3.708671236987724,
                37.130783947203255
              ],
              [
                -3.7122975835758587,
                37.12814937133906
              ],
              [
                -3.7140571126896282,
                37.12700313113019
              ],
              [
                -3.712791110034599,
                37.12645566699423
              ],
              [
                -3.7098299512821575,
                37.1276190235496
              ],
              [
                -3.7081562528568646,
                37.12955220886496
              ],
              [
                -3.7067829618412396,
                37.13066419574463
              ],
              [
                -3.7071048269230267,
                37.131913023067945
              ],
              [
                -3.7073623189884564,
                37.13299076158712
              ],
              [
                -3.7070619115787884,
                37.134239550514344
              ],
              [
                -3.7085854062992474,
                37.13577912493306
              ],
              [
                -3.711439276691093,
                37.13521461795031
              ],
              [
                -3.713563586230888,
                37.13374345875043
              ],
              [
                -3.7145291814762493,
                37.13276837235594
              ],
              [
                -3.716481829639091,
                37.13300786842395
              ],
              [
                -3.718606139178886,
                37.13234069892053
              ],
              [
                -3.7181984434086224,
                37.12975749998026
              ],
              [
                -3.7160526761967083,
                37.12823491095706
              ],
              [
                -3.714915419574394,
                37.128012507749204
              ],
              [
                -3.7152802000004193,
                37.130236510416886
              ],
              [
                -3.7173186788517376,
                37.130903698472366
              ],
              [
                -3.7166749486881634,
                37.131947237225106
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.5844277927598545,
                40.341522495414516
              ],
              [
                -3.5838055202683994,
                40.340279502080676
              ],
              [
                -3.5805868694505283,
                40.342422015780045
              ],
              [
                -3.5817241260728427,
                40.34359955158494
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.5783338138780185,
                40.3457910218292
              ],
              [
                -3.5774540493211338,
                40.34466258708767
              ],
              [
                -3.5756945202073642,
                40.34544758716716
              ],
              [
                -3.575351197453458,
                40.34690308397453
              ],
              [
                -3.5761880466661045,
                40.34749181533462
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6257653970883363,
                40.33604446664219
              ],
              [
                -3.6261087198422426,
                40.33486679896637
              ],
              [
                -3.6219888467953676,
                40.33512850467058
              ],
              [
                -3.6142211694882387,
                40.33692770391054
              ],
              [
                -3.606496407525348,
                40.33885770066825
              ],
              [
                -3.597077530009556,
                40.341245586345586
              ],
              [
                -3.592056434733677,
                40.34297920381221
              ],
              [
                -3.593000572306919,
                40.344091312314745
              ],
              [
                -3.598622482402134,
                40.34222688472297
              ],
              [
                -3.6064759903977395,
                40.340296984345834
              ],
              [
                -3.6151448899338723,
                40.338301605569484
              ],
              [
                -3.6202518158982278,
                40.336862279324194
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6755701516871375,
                40.29193704878687
              ],
              [
                -3.6746260141138953,
                40.29102048833939
              ],
              [
                -3.673810622573368,
                40.29167517564175
              ],
              [
                -3.673982283950321,
                40.29383559874142
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.671664855361454,
                40.295537701629186
              ],
              [
                -3.6707207177882117,
                40.29406473047359
              ],
              [
                -3.669991156936161,
                40.2952103774805
              ],
              [
                -3.670634887099735,
                40.2960614169691
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6700769876246375,
                40.29710883547151
              ],
              [
                -3.66951908814954,
                40.29583229200736
              ],
              [
                -3.6590477441553992,
                40.30264024512855
              ],
              [
                -3.6601206277613563,
                40.30339300551477
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6563598193792624,
                40.306460397793614
              ],
              [
                -3.659063486066274,
                40.30408764543497
              ],
              [
                -3.65816226383727,
                40.303105792493085
              ],
              [
                -3.6545144595770163,
                40.305789490061116
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.206117159911968,
                40.71791335786246
              ],
              [
                -4.206632144042827,
                40.71648216129862
              ],
              [
                -4.201525218078472,
                40.71570149565892
              ],
              [
                -4.200838572570659,
                40.716612271348595
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6407288264755167,
                40.32587312503433
              ],
              [
                -3.6400636386398233,
                40.3259222014708
              ],
              [
                -3.640042180967704,
                40.3270018740459
              ],
              [
                -3.6406859111312784,
                40.3270018740459
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.9232791357549113,
                37.1429669683455
              ],
              [
                -3.92156252198538,
                37.14433532261956
              ],
              [
                -3.9273990088017863,
                37.14885071608844
              ],
              [
                -3.9287722998174113,
                37.14748244350575
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "coordinates": []
    }),
    geometry8 = ui.import && ui.import("geometry8", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.686196469713965,
                37.195715889048216
              ],
              [
                -3.686695360590735,
                37.19525011295877
              ],
              [
                -3.686341309000769,
                37.19432709864074
              ],
              [
                -3.6852094167964844,
                37.19437837751002
              ],
              [
                -3.6852523321407227,
                37.19553214286071
              ],
              [
                -3.6858370537059693,
                37.19571161588613
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6295173810083963,
                42.74325835933892
              ],
              [
                -1.6242602513392068,
                42.749183296766915
              ],
              [
                -1.624303166683445,
                42.7510110886905
              ],
              [
                -1.6257622883875467,
                42.75112138475457
              ],
              [
                -1.629624669368992,
                42.74593725756934
              ],
              [
                -1.630096738155613,
                42.7440935576771
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#bf04c2",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #bf04c2 */
    /* shown: false */
    /* locked: true */
    ee.Geometry.MultiPolygon(
        [[[[-3.686196469713965, 37.195715889048216],
           [-3.686695360590735, 37.19525011295877],
           [-3.686341309000769, 37.19432709864074],
           [-3.6852094167964844, 37.19437837751002],
           [-3.6852523321407227, 37.19553214286071],
           [-3.6858370537059693, 37.19571161588613]]],
         [[[-1.6295173810083963, 42.74325835933892],
           [-1.6242602513392068, 42.749183296766915],
           [-1.624303166683445, 42.7510110886905],
           [-1.6257622883875467, 42.75112138475457],
           [-1.629624669368992, 42.74593725756934],
           [-1.630096738155613, 42.7440935576771]]]]),
    geometry9 = ui.import && ui.import("geometry9", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.728117878662126,
                43.52497079771975
              ],
              [
                -5.729491169677751,
                43.52416175515002
              ],
              [
                -5.72803204797365,
                43.52310376003317
              ],
              [
                -5.726572926269548,
                43.52422398957905
              ],
              [
                -5.727345402465837,
                43.5254064315323
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.0984231452334843,
                43.32575231691998
              ],
              [
                -3.098079822479578,
                43.327344484771636
              ],
              [
                -3.099581859527918,
                43.327344484771636
              ],
              [
                -3.0996676902163944,
                43.32600207149952
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.1049033622134647,
                43.33586655602777
              ],
              [
                -3.106491229950281,
                43.33702147000464
              ],
              [
                -3.1068345527041874,
                43.335804127619475
              ],
              [
                -3.1058045844424687,
                43.335429555821975
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                1.2158629778230479,
                41.1033103644749
              ],
              [
                1.2161419275605967,
                41.10400562354535
              ],
              [
                1.2151763323152354,
                41.10411880455783
              ],
              [
                1.2150046709382822,
                41.10319718206908
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.047525262372691,
                38.66411148401779
              ],
              [
                -4.046752786176402,
                38.66484868350667
              ],
              [
                -4.047997331159312,
                38.66568640098614
              ],
              [
                -4.048426484601695,
                38.66474815675054
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.050014352338511,
                38.66588745172292
              ],
              [
                -4.049456452863414,
                38.66732829881653
              ],
              [
                -4.050743913190562,
                38.66736180654351
              ],
              [
                -4.0507868285348,
                38.666323059715985
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.0479115004708355,
                38.67419705494804
              ],
              [
                -4.047825669782359,
                38.67500115891424
              ],
              [
                -4.048726892011363,
                38.67500115891424
              ],
              [
                -4.048855638044078,
                38.6738285042781
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.400286537521275,
                36.18948518444613
              ],
              [
                -5.402088981979283,
                36.190593516777966
              ],
              [
                -5.402775627487095,
                36.18955445567642
              ],
              [
                -5.40140233647147,
                36.18837683642869
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -6.89291189505931,
                37.17841576834107
              ],
              [
                -6.893083556436263,
                37.17773190269189
              ],
              [
                -6.892396910928451,
                37.17752674178995
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -6.893512709878646,
                37.17670609261064
              ],
              [
                -6.893083556436263,
                37.17609059987601
              ],
              [
                -6.89291189505931,
                37.17677448038273
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -6.90389822318431,
                37.18539084434192
              ],
              [
                -6.903469069741927,
                37.186690052039054
              ],
              [
                -6.904756530069076,
                37.186348157443554
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ff0000",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #ff0000 */
    /* shown: false */
    /* locked: true */
    ee.Geometry.MultiPolygon(
        [[[[-5.728117878662126, 43.52497079771975],
           [-5.729491169677751, 43.52416175515002],
           [-5.72803204797365, 43.52310376003317],
           [-5.726572926269548, 43.52422398957905],
           [-5.727345402465837, 43.5254064315323]]],
         [[[-3.0984231452334843, 43.32575231691998],
           [-3.098079822479578, 43.327344484771636],
           [-3.099581859527918, 43.327344484771636],
           [-3.0996676902163944, 43.32600207149952]]],
         [[[-3.1049033622134647, 43.33586655602777],
           [-3.106491229950281, 43.33702147000464],
           [-3.1068345527041874, 43.335804127619475],
           [-3.1058045844424687, 43.335429555821975]]],
         [[[1.2158629778230479, 41.1033103644749],
           [1.2161419275605967, 41.10400562354535],
           [1.2151763323152354, 41.10411880455783],
           [1.2150046709382822, 41.10319718206908]]],
         [[[-4.047525262372691, 38.66411148401779],
           [-4.046752786176402, 38.66484868350667],
           [-4.047997331159312, 38.66568640098614],
           [-4.048426484601695, 38.66474815675054]]],
         [[[-4.050014352338511, 38.66588745172292],
           [-4.049456452863414, 38.66732829881653],
           [-4.050743913190562, 38.66736180654351],
           [-4.0507868285348, 38.666323059715985]]],
         [[[-4.0479115004708355, 38.67419705494804],
           [-4.047825669782359, 38.67500115891424],
           [-4.048726892011363, 38.67500115891424],
           [-4.048855638044078, 38.6738285042781]]],
         [[[-5.400286537521275, 36.18948518444613],
           [-5.402088981979283, 36.190593516777966],
           [-5.402775627487095, 36.18955445567642],
           [-5.40140233647147, 36.18837683642869]]],
         [[[-6.89291189505931, 37.17841576834107],
           [-6.893083556436263, 37.17773190269189],
           [-6.892396910928451, 37.17752674178995]]],
         [[[-6.893512709878646, 37.17670609261064],
           [-6.893083556436263, 37.17609059987601],
           [-6.89291189505931, 37.17677448038273]]],
         [[[-6.90389822318431, 37.18539084434192],
           [-6.903469069741927, 37.186690052039054],
           [-6.904756530069076, 37.186348157443554]]]]),
    geometry10 = ui.import && ui.import("geometry10", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.989918650312234,
                40.56873695664043
              ],
              [
                -3.989918650312234,
                40.08803843284326
              ],
              [
                -3.3374122213696977,
                40.08803843284326
              ],
              [
                -3.3374122213696977,
                40.56873695664043
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* locked: true */
    ee.Geometry.Polygon(
        [[[-3.989918650312234, 40.56873695664043],
          [-3.989918650312234, 40.08803843284326],
          [-3.3374122213696977, 40.08803843284326],
          [-3.3374122213696977, 40.56873695664043]]], null, false),
    table2 = ui.import && ui.import("table2", "table", {
      "id": "projects/ee-pmisson/assets/merged_data_with_categories"
    }) || ee.FeatureCollection("projects/ee-pmisson/assets/merged_data_with_categories"),
    geometry11 = ui.import && ui.import("geometry11", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.309841558774199,
                40.68483239883251
              ],
              [
                -4.319454595883574,
                40.634827602832914
              ],
              [
                -4.208218023617949,
                40.673376277301195
              ],
              [
                -4.245296881039824,
                40.701492333661236
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.8351586503659885,
                40.58853373108445
              ],
              [
                -3.8310387773191135,
                40.522278111357785
              ],
              [
                -3.730101887670676,
                40.56558645108417
              ],
              [
                -3.7555077714597385,
                40.626587991374095
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.644131639364101,
                40.26495831889379
              ],
              [
                -3.6077394274500385,
                40.281722778605946
              ],
              [
                -3.6379518297937885,
                40.30005414748313
              ],
              [
                -3.6534013537195698,
                40.27779398124632
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.5679139879969135,
                40.32256873618224
              ],
              [
                -3.5857667712000385,
                40.304767124349034
              ],
              [
                -3.5593309191492573,
                40.28696081994138
              ],
              [
                -3.5363282946375385,
                40.31026518178569
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                1.816101091908351,
                39.05248234359057
              ],
              [
                2.714233416127101,
                39.22929197164838
              ],
              [
                2.565917986439601,
                39.441725394642425
              ],
              [
                1.879272478627101,
                39.35045812977281
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.552820307223936,
                40.20601736860633
              ],
              [
                -3.534967524020811,
                40.136234886705076
              ],
              [
                -3.53050432822003,
                40.17716865181249
              ],
              [
                -3.4917088570286237,
                40.17402077673253
              ],
              [
                -3.508874994723936,
                40.21047471183071
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.4261558956411786,
                40.59641832598012
              ],
              [
                -3.4546516842153974,
                40.59302928201547
              ],
              [
                -3.4289024776724286,
                40.53356274119545
              ],
              [
                -3.40589985316071,
                40.53121429391785
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.2530253725733504,
                40.679569917119316
              ],
              [
                -3.187794049331163,
                40.69805323909555
              ],
              [
                -3.213886578628038,
                40.72771996076773
              ],
              [
                -3.278431256362413,
                40.70534102690715
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -2.9793898437771715,
                40.00652129676228
              ],
              [
                -2.9120985840115465,
                39.966800468060484
              ],
              [
                -2.8746764038357653,
                40.01914294740391
              ],
              [
                -2.9505507324490465,
                40.017302435395166
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                0.8543586378810719,
                37.9283149810537
              ],
              [
                0.8586501723049,
                37.91368998858257
              ],
              [
                0.8610534315822438,
                37.91382541851905
              ],
              [
                0.85590359027365,
                37.92858578681932
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                0.8392524367091969,
                37.923981953154275
              ],
              [
                0.8368491774318532,
                37.94226018089073
              ],
              [
                0.8315276747463063,
                37.94144791172175
              ],
              [
                0.8378791456935719,
                37.92384654191812
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                0.854349588936378,
                38.3383638901125
              ],
              [
                1.0386491704864242,
                37.68822960846405
              ],
              [
                1.6107761803053395,
                37.80567400188878
              ],
              [
                1.3659822413931813,
                38.65912600502887
              ],
              [
                0.7910798439264841,
                38.547342932805954
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.715517575988721,
                37.829673327580636
              ],
              [
                -4.697664792785596,
                37.727643292315534
              ],
              [
                -4.575441892394971,
                37.77324858411966
              ],
              [
                -4.605654294738721,
                37.87846763331943
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.6447401975034257,
                39.7604581328664
              ],
              [
                2.6679970095994183,
                39.77097395661341
              ],
              [
                2.58591519613005,
                40.05847432788926
              ],
              [
                2.5667632582046545,
                40.060568453371054
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.756359958893362,
                39.66511294168317
              ],
              [
                2.761853122955862,
                39.665377227035464
              ],
              [
                2.7337006571355493,
                39.76520466757248
              ],
              [
                2.729237461334768,
                39.76520466757248
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.6683331065359672,
                39.79188239843175
              ],
              [
                2.689450768015824,
                39.7191981977254
              ],
              [
                2.690824059031449,
                39.71959431490308
              ],
              [
                2.669469303022902,
                39.79207099321709
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.5933875814897833,
                39.72456669087954
              ],
              [
                2.6180811062403686,
                39.63963963636757
              ],
              [
                2.6196260586329467,
                39.63957354052076
              ],
              [
                2.5947055642831263,
                39.72475156654076
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                1.9531974453354461,
                39.36136604886973
              ],
              [
                1.9559440273666961,
                39.36136604886973
              ],
              [
                1.8965619018645885,
                39.560324063038664
              ],
              [
                1.8920987060638073,
                39.56005937632571
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.499267007882425,
                39.55217536579423
              ],
              [
                -3.4130929966519563,
                39.538673469771595
              ],
              [
                -3.402793314034769,
                39.55323422692652
              ],
              [
                -3.442618753487894,
                39.5545577806151
              ],
              [
                -3.4776376743863313,
                39.57652508283518
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.574220968151282,
                37.290473547636104
              ],
              [
                -5.549501729870032,
                37.340714286388256
              ],
              [
                -5.598958738945396,
                37.3756294402787
              ],
              [
                -5.622991331718834,
                37.31667516805224
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.996604437098532,
                37.86134608128899
              ],
              [
                -3.9931712095594696,
                37.81606637520113
              ],
              [
                -3.9698252622938446,
                37.82284654327425
              ],
              [
                -3.985274786219626,
                37.86514072194742
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -6.5657632893061235,
                38.71108025158496
              ],
              [
                -6.6426675861811235,
                38.677853182142805
              ],
              [
                -6.6124551838373735,
                38.658016771443116
              ],
              [
                -6.5382974689936235,
                38.640320201324535
              ],
              [
                -6.5630167072748735,
                38.682141413195886
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -8.940032200944405,
                38.87577500921962
              ],
              [
                -8.92217941774128,
                38.9174584116543
              ],
              [
                -8.970931248795967,
                38.921732248956545
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.774599017027617,
                41.65778929496807
              ],
              [
                -5.701127947691679,
                41.64291022486996
              ],
              [
                -5.697694720152617,
                41.67215203266808
              ],
              [
                -5.743699969176054,
                41.667535787813605
              ],
              [
                -5.766359270933867,
                41.69163919475426
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.033525365258379,
                41.910594880940415
              ],
              [
                -3.978593724633379,
                41.93767178444714
              ],
              [
                -4.008806126977129,
                41.974947572771114
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Point",
          "coordinates": [
            2.931667153684434,
            39.48451985677674
          ]
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.9378469632547466,
                39.46861952339877
              ],
              [
                2.9378469632547466,
                39.485844720502136
              ],
              [
                2.931323830930528,
                39.48292998698921
              ],
              [
                2.934070412961778,
                39.46729433156804
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.772365395871934,
                39.41479644969875
              ],
              [
                2.758289162961778,
                39.41134823489692
              ],
              [
                2.772022073118028,
                39.39516587257753
              ],
              [
                2.777858559934434,
                39.40047197884796
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                3.2429760834709054,
                39.790140220369096
              ],
              [
                3.3432263276115304,
                39.79752642062017
              ],
              [
                3.4503430268302804,
                39.7584760934362
              ],
              [
                3.4984082123771554,
                39.69510414812075
              ],
              [
                3.8527172944084054,
                39.71517823267904
              ],
              [
                3.7703198334709054,
                39.97771429789839
              ],
              [
                3.2292431733146554,
                39.860804168352324
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                3.8362948949277875,
                40.083802152874604
              ],
              [
                4.3059604222715375,
                40.07224336492212
              ],
              [
                4.3526523168027875,
                39.860687450322125
              ],
              [
                4.3279330785215375,
                39.77524857727473
              ],
              [
                4.2043368871152875,
                39.797409595030615
              ],
              [
                3.9681308324277875,
                39.90916099369627
              ],
              [
                3.8720004613340375,
                39.8923045179283
              ],
              [
                3.8596408421934125,
                39.772082134916005
              ],
              [
                4.0244357640684125,
                39.66124539705596
              ],
              [
                4.2798678929746625,
                39.58508489692892
              ],
              [
                4.4542758519590375,
                39.64009811066744
              ],
              [
                4.577546279409916,
                39.858409321010036
              ],
              [
                4.50292095353555,
                40.12593820782464
              ],
              [
                4.36009868791055,
                40.204647016035565
              ],
              [
                4.01952251603555,
                40.22457209103954
              ],
              [
                3.8025425355667997,
                40.18471608279655
              ],
              [
                3.5320042054886747,
                40.04713816102923
              ],
              [
                3.5168980043167997,
                39.94929945610988
              ],
              [
                3.7242649476761747,
                39.978771018835715
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                3.0210470933226086,
                39.71027797941357
              ],
              [
                3.023107029846046,
                39.665364154897
              ],
              [
                3.10241458599839,
                39.68571109521328
              ],
              [
                3.091771580627296,
                39.720841691698574
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.205799158100081,
                40.929336991025004
              ],
              [
                -5.139881189350081,
                40.90339324367436
              ],
              [
                -5.098682458881331,
                40.93348704570161
              ],
              [
                -5.082202966693831,
                40.948010184204506
              ],
              [
                -5.084949548725081,
                40.96408564815531
              ],
              [
                -5.096622522357894,
                40.97601007553324
              ],
              [
                -5.060916955951644,
                40.972899563113195
              ],
              [
                -5.036197717670394,
                40.97704688041519
              ],
              [
                -5.034824426654769,
                40.99985246482842
              ],
              [
                -5.080143030170394,
                40.98378571493368
              ],
              [
                -5.102802331928206,
                40.998297789184804
              ],
              [
                -5.135074670795394,
                40.98119393698406
              ],
              [
                -5.187946374896956,
                40.958900442345666
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.630627254155449,
                41.2081389918775
              ],
              [
                -5.493298152592949,
                41.1430177842438
              ],
              [
                -5.447292903569512,
                41.19160640571544
              ],
              [
                -5.548916438725762,
                41.21898623189882
              ],
              [
                -5.642300227788262,
                41.23396279677584
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.743337259691028,
                41.055127861597825
              ],
              [
                -5.730977640550403,
                41.079459220622546
              ],
              [
                -5.831227884691028,
                41.103264172626716
              ],
              [
                -5.855260477464466,
                41.08463494390053
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.589173259010237,
                42.76559685242079
              ],
              [
                -1.58385175632469,
                42.746942627554695
              ],
              [
                -1.5828217880629714,
                42.74700565803804
              ],
              [
                -1.5884866135024245,
                42.765659863933095
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.5953530685805495,
                42.76578588676545
              ],
              [
                -1.588400782813948,
                42.74271943917509
              ],
              [
                -1.5875424759291823,
                42.74297157789985
              ],
              [
                -1.5937222854994948,
                42.76610094272469
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6065968887709792,
                42.76156398232002
              ],
              [
                -1.6026486771010573,
                42.74921168457844
              ],
              [
                -1.6010178940200026,
                42.75135460661144
              ],
              [
                -1.6055669205092604,
                42.76225715055156
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.601532878150862,
                42.74265640433367
              ],
              [
                -1.6000737564467604,
                42.73818076678265
              ],
              [
                -1.5982713119887526,
                42.73843292396492
              ],
              [
                -1.599558772315901,
                42.74271943917509
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.5819812652490217,
                42.73931333525511
              ],
              [
                -1.575629794301756,
                42.71844415639352
              ],
              [
                -1.5743423339746077,
                42.71882251214967
              ],
              [
                -1.5806079742333967,
                42.73994371477393
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.58163283502331,
                42.71808794710296
              ],
              [
                -1.5800020519422553,
                42.718151006917864
              ],
              [
                -1.5832636181043647,
                42.728933292829076
              ],
              [
                -1.5847227398084662,
                42.72943768137219
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.591846686952021,
                42.710204965578065
              ],
              [
                -1.590473395936396,
                42.710141897688565
              ],
              [
                -1.5964815441297553,
                42.731455194529154
              ],
              [
                -1.5977690044569037,
                42.73139214823634
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6795305329853716,
                42.73535897866635
              ],
              [
                -1.6782430726582231,
                42.735485063122994
              ],
              [
                -1.683392913966817,
                42.753890642845064
              ],
              [
                -1.6844228822285356,
                42.75370157220618
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6918808199074387,
                42.75202930334698
              ],
              [
                -1.6903358675148605,
                42.75152509855217
              ],
              [
                -1.6989189363625168,
                42.78177012586622
              ],
              [
                -1.7001205660011887,
                42.78151814498941
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.5904289461281418,
                42.76564128230866
              ],
              [
                -1.5969520784523605,
                42.79650922232494
              ],
              [
                -1.598840353598845,
                42.79638326201214
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.596093771567595,
                42.76690149947337
              ],
              [
                -1.5938621736672043,
                42.76677547891055
              ],
              [
                -1.601586935630095,
                42.79461979071175
              ],
              [
                -1.6038185335304855,
                42.79524960765927
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.543503102213566,
                42.77598546520353
              ],
              [
                -1.5416148270670815,
                42.77585946312252
              ],
              [
                -1.553287800699894,
                42.818307648721465
              ],
              [
                -1.555862721354191,
                42.818307648721465
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.684791308005542,
                42.759224937965875
              ],
              [
                -1.6892545038063234,
                42.776363469908354
              ],
              [
                -1.6911427789528077,
                42.77674147230575
              ],
              [
                -1.686164599021167,
                42.759224937965875
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.727191668112964,
                42.7837970935156
              ],
              [
                -1.7275349908668702,
                42.77598546520353
              ],
              [
                -1.7174069696266359,
                42.77711947239574
              ],
              [
                -1.7179219537574952,
                42.78417505053337
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.711735687827336,
                42.821153404668266
              ],
              [
                -1.7104482275001875,
                42.82140522417437
              ],
              [
                -1.7198896438657463,
                42.85859925557124
              ],
              [
                -1.723666194158715,
                42.85885092250988
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6193715343744408,
                42.8686073907663
              ],
              [
                -1.6125050792963158,
                42.84482409161898
              ],
              [
                -1.6107884655267846,
                42.845327536745216
              ],
              [
                -1.6178265819818627,
                42.86885901691009
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6382542858392846,
                42.869236454202486
              ],
              [
                -1.629156232860769,
                42.83865655585494
              ],
              [
                -1.6267529735834252,
                42.83890830406048
              ],
              [
                -1.6365376720697533,
                42.87074618029213
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                0.6357892468572723,
                39.28930170905872
              ],
              [
                0.6436856701971161,
                39.26073124702093
              ],
              [
                0.6454022839666473,
                39.26059833393203
              ],
              [
                0.6100209008775481,
                39.38982541164908
              ],
              [
                0.60847594848497,
                39.389427406945856
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#a9a9a9",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #a9a9a9 */
    /* shown: false */
    /* locked: true */
    ee.Geometry({
      "type": "GeometryCollection",
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.309841558774199,
                40.68483239883251
              ],
              [
                -4.319454595883574,
                40.634827602832914
              ],
              [
                -4.208218023617949,
                40.673376277301195
              ],
              [
                -4.245296881039824,
                40.701492333661236
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.8351586503659885,
                40.58853373108445
              ],
              [
                -3.8310387773191135,
                40.522278111357785
              ],
              [
                -3.730101887670676,
                40.56558645108417
              ],
              [
                -3.7555077714597385,
                40.626587991374095
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.644131639364101,
                40.26495831889379
              ],
              [
                -3.6077394274500385,
                40.281722778605946
              ],
              [
                -3.6379518297937885,
                40.30005414748313
              ],
              [
                -3.6534013537195698,
                40.27779398124632
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.5679139879969135,
                40.32256873618224
              ],
              [
                -3.5857667712000385,
                40.304767124349034
              ],
              [
                -3.5593309191492573,
                40.28696081994138
              ],
              [
                -3.5363282946375385,
                40.31026518178569
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                1.816101091908351,
                39.05248234359057
              ],
              [
                2.714233416127101,
                39.22929197164838
              ],
              [
                2.565917986439601,
                39.441725394642425
              ],
              [
                1.879272478627101,
                39.35045812977281
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.552820307223936,
                40.20601736860633
              ],
              [
                -3.534967524020811,
                40.136234886705076
              ],
              [
                -3.53050432822003,
                40.17716865181249
              ],
              [
                -3.4917088570286237,
                40.17402077673253
              ],
              [
                -3.508874994723936,
                40.21047471183071
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.4261558956411786,
                40.59641832598012
              ],
              [
                -3.4546516842153974,
                40.59302928201547
              ],
              [
                -3.4289024776724286,
                40.53356274119545
              ],
              [
                -3.40589985316071,
                40.53121429391785
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.2530253725733504,
                40.679569917119316
              ],
              [
                -3.187794049331163,
                40.69805323909555
              ],
              [
                -3.213886578628038,
                40.72771996076773
              ],
              [
                -3.278431256362413,
                40.70534102690715
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -2.9793898437771715,
                40.00652129676228
              ],
              [
                -2.9120985840115465,
                39.966800468060484
              ],
              [
                -2.8746764038357653,
                40.01914294740391
              ],
              [
                -2.9505507324490465,
                40.017302435395166
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                0.8543586378810719,
                37.9283149810537
              ],
              [
                0.8586501723049,
                37.91368998858257
              ],
              [
                0.8610534315822438,
                37.91382541851905
              ],
              [
                0.85590359027365,
                37.92858578681932
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                0.8392524367091969,
                37.923981953154275
              ],
              [
                0.8368491774318532,
                37.94226018089073
              ],
              [
                0.8315276747463063,
                37.94144791172175
              ],
              [
                0.8378791456935719,
                37.92384654191812
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                0.854349588936378,
                38.3383638901125
              ],
              [
                1.0386491704864242,
                37.68822960846405
              ],
              [
                1.6107761803053395,
                37.80567400188878
              ],
              [
                1.3659822413931813,
                38.65912600502887
              ],
              [
                0.7910798439264841,
                38.547342932805954
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.715517575988721,
                37.829673327580636
              ],
              [
                -4.697664792785596,
                37.727643292315534
              ],
              [
                -4.575441892394971,
                37.77324858411966
              ],
              [
                -4.605654294738721,
                37.87846763331943
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.6447401975034257,
                39.7604581328664
              ],
              [
                2.6679970095994183,
                39.77097395661341
              ],
              [
                2.58591519613005,
                40.05847432788926
              ],
              [
                2.5667632582046545,
                40.060568453371054
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.756359958893362,
                39.66511294168317
              ],
              [
                2.761853122955862,
                39.665377227035464
              ],
              [
                2.7337006571355493,
                39.76520466757248
              ],
              [
                2.729237461334768,
                39.76520466757248
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.6683331065359672,
                39.79188239843175
              ],
              [
                2.689450768015824,
                39.7191981977254
              ],
              [
                2.690824059031449,
                39.71959431490308
              ],
              [
                2.669469303022902,
                39.79207099321709
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.5933875814897833,
                39.72456669087954
              ],
              [
                2.6180811062403686,
                39.63963963636757
              ],
              [
                2.6196260586329467,
                39.63957354052076
              ],
              [
                2.5947055642831263,
                39.72475156654076
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                1.9531974453354461,
                39.36136604886973
              ],
              [
                1.9559440273666961,
                39.36136604886973
              ],
              [
                1.8965619018645885,
                39.560324063038664
              ],
              [
                1.8920987060638073,
                39.56005937632571
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.499267007882425,
                39.55217536579423
              ],
              [
                -3.4130929966519563,
                39.538673469771595
              ],
              [
                -3.402793314034769,
                39.55323422692652
              ],
              [
                -3.442618753487894,
                39.5545577806151
              ],
              [
                -3.4776376743863313,
                39.57652508283518
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.574220968151282,
                37.290473547636104
              ],
              [
                -5.549501729870032,
                37.340714286388256
              ],
              [
                -5.598958738945396,
                37.3756294402787
              ],
              [
                -5.622991331718834,
                37.31667516805224
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.996604437098532,
                37.86134608128899
              ],
              [
                -3.9931712095594696,
                37.81606637520113
              ],
              [
                -3.9698252622938446,
                37.82284654327425
              ],
              [
                -3.985274786219626,
                37.86514072194742
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -6.5657632893061235,
                38.71108025158496
              ],
              [
                -6.6426675861811235,
                38.677853182142805
              ],
              [
                -6.6124551838373735,
                38.658016771443116
              ],
              [
                -6.5382974689936235,
                38.640320201324535
              ],
              [
                -6.5630167072748735,
                38.682141413195886
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -8.940032200944405,
                38.87577500921962
              ],
              [
                -8.92217941774128,
                38.9174584116543
              ],
              [
                -8.970931248795967,
                38.921732248956545
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.774599017027617,
                41.65778929496807
              ],
              [
                -5.701127947691679,
                41.64291022486996
              ],
              [
                -5.697694720152617,
                41.67215203266808
              ],
              [
                -5.743699969176054,
                41.667535787813605
              ],
              [
                -5.766359270933867,
                41.69163919475426
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.033525365258379,
                41.910594880940415
              ],
              [
                -3.978593724633379,
                41.93767178444714
              ],
              [
                -4.008806126977129,
                41.974947572771114
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Point",
          "coordinates": [
            2.931667153684434,
            39.48451985677674
          ]
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.9378469632547466,
                39.46861952339877
              ],
              [
                2.9378469632547466,
                39.485844720502136
              ],
              [
                2.931323830930528,
                39.48292998698921
              ],
              [
                2.934070412961778,
                39.46729433156804
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.772365395871934,
                39.41479644969875
              ],
              [
                2.758289162961778,
                39.41134823489692
              ],
              [
                2.772022073118028,
                39.39516587257753
              ],
              [
                2.777858559934434,
                39.40047197884796
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                3.2429760834709054,
                39.790140220369096
              ],
              [
                3.3432263276115304,
                39.79752642062017
              ],
              [
                3.4503430268302804,
                39.7584760934362
              ],
              [
                3.4984082123771554,
                39.69510414812075
              ],
              [
                3.8527172944084054,
                39.71517823267904
              ],
              [
                3.7703198334709054,
                39.97771429789839
              ],
              [
                3.2292431733146554,
                39.860804168352324
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                3.8362948949277875,
                40.083802152874604
              ],
              [
                4.3059604222715375,
                40.07224336492212
              ],
              [
                4.3526523168027875,
                39.860687450322125
              ],
              [
                4.3279330785215375,
                39.77524857727473
              ],
              [
                4.2043368871152875,
                39.797409595030615
              ],
              [
                3.9681308324277875,
                39.90916099369627
              ],
              [
                3.8720004613340375,
                39.8923045179283
              ],
              [
                3.8596408421934125,
                39.772082134916005
              ],
              [
                4.0244357640684125,
                39.66124539705596
              ],
              [
                4.2798678929746625,
                39.58508489692892
              ],
              [
                4.4542758519590375,
                39.64009811066744
              ],
              [
                4.577546279409916,
                39.858409321010036
              ],
              [
                4.50292095353555,
                40.12593820782464
              ],
              [
                4.36009868791055,
                40.204647016035565
              ],
              [
                4.01952251603555,
                40.22457209103954
              ],
              [
                3.8025425355667997,
                40.18471608279655
              ],
              [
                3.5320042054886747,
                40.04713816102923
              ],
              [
                3.5168980043167997,
                39.94929945610988
              ],
              [
                3.7242649476761747,
                39.978771018835715
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                3.0210470933226086,
                39.71027797941357
              ],
              [
                3.023107029846046,
                39.665364154897
              ],
              [
                3.10241458599839,
                39.68571109521328
              ],
              [
                3.091771580627296,
                39.720841691698574
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.205799158100081,
                40.929336991025004
              ],
              [
                -5.139881189350081,
                40.90339324367436
              ],
              [
                -5.098682458881331,
                40.93348704570161
              ],
              [
                -5.082202966693831,
                40.948010184204506
              ],
              [
                -5.084949548725081,
                40.96408564815531
              ],
              [
                -5.096622522357894,
                40.97601007553324
              ],
              [
                -5.060916955951644,
                40.972899563113195
              ],
              [
                -5.036197717670394,
                40.97704688041519
              ],
              [
                -5.034824426654769,
                40.99985246482842
              ],
              [
                -5.080143030170394,
                40.98378571493368
              ],
              [
                -5.102802331928206,
                40.998297789184804
              ],
              [
                -5.135074670795394,
                40.98119393698406
              ],
              [
                -5.187946374896956,
                40.958900442345666
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.630627254155449,
                41.2081389918775
              ],
              [
                -5.493298152592949,
                41.1430177842438
              ],
              [
                -5.447292903569512,
                41.19160640571544
              ],
              [
                -5.548916438725762,
                41.21898623189882
              ],
              [
                -5.642300227788262,
                41.23396279677584
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -5.743337259691028,
                41.055127861597825
              ],
              [
                -5.730977640550403,
                41.079459220622546
              ],
              [
                -5.831227884691028,
                41.103264172626716
              ],
              [
                -5.855260477464466,
                41.08463494390053
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.589173259010237,
                42.76559685242079
              ],
              [
                -1.58385175632469,
                42.746942627554695
              ],
              [
                -1.5828217880629714,
                42.74700565803804
              ],
              [
                -1.5884866135024245,
                42.765659863933095
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.5953530685805495,
                42.76578588676545
              ],
              [
                -1.588400782813948,
                42.74271943917509
              ],
              [
                -1.5875424759291823,
                42.74297157789985
              ],
              [
                -1.5937222854994948,
                42.76610094272469
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6065968887709792,
                42.76156398232002
              ],
              [
                -1.6026486771010573,
                42.74921168457844
              ],
              [
                -1.6010178940200026,
                42.75135460661144
              ],
              [
                -1.6055669205092604,
                42.76225715055156
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.601532878150862,
                42.74265640433367
              ],
              [
                -1.6000737564467604,
                42.73818076678265
              ],
              [
                -1.5982713119887526,
                42.73843292396492
              ],
              [
                -1.599558772315901,
                42.74271943917509
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.5819812652490217,
                42.73931333525511
              ],
              [
                -1.575629794301756,
                42.71844415639352
              ],
              [
                -1.5743423339746077,
                42.71882251214967
              ],
              [
                -1.5806079742333967,
                42.73994371477393
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.58163283502331,
                42.71808794710296
              ],
              [
                -1.5800020519422553,
                42.718151006917864
              ],
              [
                -1.5832636181043647,
                42.728933292829076
              ],
              [
                -1.5847227398084662,
                42.72943768137219
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.591846686952021,
                42.710204965578065
              ],
              [
                -1.590473395936396,
                42.710141897688565
              ],
              [
                -1.5964815441297553,
                42.731455194529154
              ],
              [
                -1.5977690044569037,
                42.73139214823634
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6795305329853716,
                42.73535897866635
              ],
              [
                -1.6782430726582231,
                42.735485063122994
              ],
              [
                -1.683392913966817,
                42.753890642845064
              ],
              [
                -1.6844228822285356,
                42.75370157220618
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6918808199074387,
                42.75202930334698
              ],
              [
                -1.6903358675148605,
                42.75152509855217
              ],
              [
                -1.6989189363625168,
                42.78177012586622
              ],
              [
                -1.7001205660011887,
                42.78151814498941
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.5904289461281418,
                42.76564128230866
              ],
              [
                -1.5969520784523605,
                42.79650922232494
              ],
              [
                -1.598840353598845,
                42.79638326201214
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.596093771567595,
                42.76690149947337
              ],
              [
                -1.5938621736672043,
                42.76677547891055
              ],
              [
                -1.601586935630095,
                42.79461979071175
              ],
              [
                -1.6038185335304855,
                42.79524960765927
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.543503102213566,
                42.77598546520353
              ],
              [
                -1.5416148270670815,
                42.77585946312252
              ],
              [
                -1.553287800699894,
                42.818307648721465
              ],
              [
                -1.555862721354191,
                42.818307648721465
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.684791308005542,
                42.759224937965875
              ],
              [
                -1.6892545038063234,
                42.776363469908354
              ],
              [
                -1.6911427789528077,
                42.77674147230575
              ],
              [
                -1.686164599021167,
                42.759224937965875
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.727191668112964,
                42.7837970935156
              ],
              [
                -1.7275349908668702,
                42.77598546520353
              ],
              [
                -1.7174069696266359,
                42.77711947239574
              ],
              [
                -1.7179219537574952,
                42.78417505053337
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.711735687827336,
                42.821153404668266
              ],
              [
                -1.7104482275001875,
                42.82140522417437
              ],
              [
                -1.7198896438657463,
                42.85859925557124
              ],
              [
                -1.723666194158715,
                42.85885092250988
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6193715343744408,
                42.8686073907663
              ],
              [
                -1.6125050792963158,
                42.84482409161898
              ],
              [
                -1.6107884655267846,
                42.845327536745216
              ],
              [
                -1.6178265819818627,
                42.86885901691009
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -1.6382542858392846,
                42.869236454202486
              ],
              [
                -1.629156232860769,
                42.83865655585494
              ],
              [
                -1.6267529735834252,
                42.83890830406048
              ],
              [
                -1.6365376720697533,
                42.87074618029213
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                0.6357892468572723,
                39.28930170905872
              ],
              [
                0.6436856701971161,
                39.26073124702093
              ],
              [
                0.6454022839666473,
                39.26059833393203
              ],
              [
                0.6100209008775481,
                39.38982541164908
              ],
              [
                0.60847594848497,
                39.389427406945856
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "coordinates": []
    }),
    geometry12 = ui.import && ui.import("geometry12", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.772769972190917,
                40.44117859403722
              ],
              [
                -3.7765465224838857,
                40.434253961274386
              ],
              [
                -3.7707100356674794,
                40.42758996207951
              ],
              [
                -3.7760315383530263,
                40.41791945570247
              ],
              [
                -3.771396681175292,
                40.40863969007787
              ],
              [
                -3.7556038344956044,
                40.420271868991435
              ],
              [
                -3.7377510512924794,
                40.42562983664209
              ],
              [
                -3.7652168716049794,
                40.44196246978678
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.740036501357258,
                40.472015772506865
              ],
              [
                -3.7483620781394844,
                40.468881616872046
              ],
              [
                -3.7444138664695625,
                40.46143741101492
              ],
              [
                -3.7352299828025703,
                40.46202514147364
              ],
              [
                -3.7334275383445625,
                40.46463721463161
              ],
              [
                -3.737289919326008,
                40.46862043063323
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.64568739883673,
                40.42468418575348
              ],
              [
                -3.647489843294738,
                40.41690834951417
              ],
              [
                -3.6399367427088003,
                40.41560139805984
              ],
              [
                -3.6322978114343862,
                40.41632022450137
              ],
              [
                -3.637018499300597,
                40.4197182091741
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.5932448481775503,
                40.416712308414446
              ],
              [
                -3.5833743190027456,
                40.41651626674352
              ],
              [
                -3.5820010279871206,
                40.423704087834345
              ],
              [
                -3.590326604769347,
                40.426056298848536
              ],
              [
                -3.5945323085046987,
                40.427885739434316
              ],
              [
                -3.597622213289855,
                40.42167850688082
              ],
              [
                -3.6028578852869253,
                40.418738038900095
              ],
              [
                -3.6034587001062612,
                40.41292206821321
              ],
              [
                -3.5904124354578237,
                40.4101772782368
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.567992190764495,
                40.438698849433536
              ],
              [
                -3.5790643495779717,
                40.438176241245955
              ],
              [
                -3.5843858522635186,
                40.435367152637625
              ],
              [
                -3.5903081697684014,
                40.43798026212827
              ],
              [
                -3.5935697359305108,
                40.43216595510656
              ],
              [
                -3.58859155599887,
                40.42850725703234
              ],
              [
                -3.5806951326590264,
                40.42831124973249
              ],
              [
                -3.580952624724456,
                40.43216595510656
              ],
              [
                -3.5796651643973076,
                40.434779189006136
              ],
              [
                -3.571167926238128,
                40.43660839230885
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6586212626555237,
                40.35631776453639
              ],
              [
                -3.671324204550055,
                40.352851170709414
              ],
              [
                -3.667032670126227,
                40.345067037171674
              ],
              [
                -3.6637711039641174,
                40.349776872372146
              ],
              [
                -3.6587070933440002,
                40.35317821547628
              ],
              [
                -3.6526131144621643,
                40.352393305371116
              ],
              [
                -3.6449741831877502,
                40.350954279783544
              ],
              [
                -3.6430000773527893,
                40.35514045076905
              ],
              [
                -3.6494373789885315,
                40.35520585762874
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.62051243697193,
                40.36141921998598
              ],
              [
                -3.627207230673102,
                40.36024199529733
              ],
              [
                -3.6363052836516174,
                40.36259642411765
              ],
              [
                -3.6445450297453674,
                40.36325041753033
              ],
              [
                -3.640081833944586,
                40.35618695291071
              ],
              [
                -3.617594193563727,
                40.35958797269879
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.608324479208258,
                40.361680822680654
              ],
              [
                -3.6169075480559143,
                40.35370148380416
              ],
              [
                -3.6005997172453674,
                40.35108510156038
              ],
              [
                -3.592016648397711,
                40.348206963848234
              ],
              [
                -3.5908150187590393,
                40.352916579789685
              ],
              [
                -3.5978531352141174,
                40.35343985014778
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.551667376146048,
                40.46327423126426
              ],
              [
                -3.5590488153550326,
                40.464188451423375
              ],
              [
                -3.5588771539780795,
                40.46562505796218
              ],
              [
                -3.5657436090562045,
                40.46601685441276
              ],
              [
                -3.5660869318101107,
                40.46170696775715
              ],
              [
                -3.551324053392142,
                40.461968180881016
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.575013323411673,
                40.48207854105151
              ],
              [
                -3.5671169000718295,
                40.47332996864353
              ],
              [
                -3.5645419794175326,
                40.46732282607534
              ],
              [
                -3.5533839899155795,
                40.46640864857792
              ],
              [
                -3.5547572809312045,
                40.472285286796804
              ],
              [
                -3.5614520746323763,
                40.47633333841942
              ],
              [
                -3.569520159349173,
                40.48247024150862
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6060235923918627,
                40.454879849996146
              ],
              [
                -3.6003587669524095,
                40.46141053701888
              ],
              [
                -3.606195253768816,
                40.464022634076045
              ],
              [
                -3.609456819930925,
                40.4603656697554
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6277097935664826,
                40.495359875509884
              ],
              [
                -3.639382767199295,
                40.4940544491774
              ],
              [
                -3.6386961216914826,
                40.48883248987011
              ],
              [
                -3.631143021105545,
                40.48857138123785
              ],
              [
                -3.6290830845821076,
                40.487135265601374
              ],
              [
                -3.62427656602742,
                40.48791860521265
              ],
              [
                -3.6235899205196076,
                40.48439350496185
              ],
              [
                -3.618611740587967,
                40.486221357832626
              ],
              [
                -3.6162084813106232,
                40.49013801779318
              ],
              [
                -3.6217016453731232,
                40.49000746614375
              ],
              [
                -3.6271948094356232,
                40.492226809643476
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.590974258898514,
                40.51572123763415
              ],
              [
                -3.600587296007889,
                40.51232810653761
              ],
              [
                -3.59955732774617,
                40.50345295187837
              ],
              [
                -3.5863394017207795,
                40.507629641550594
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.665474197719564,
                39.552766122714885
              ],
              [
                2.6692507480125327,
                39.53926434164829
              ],
              [
                2.6761172030906577,
                39.54350047733865
              ],
              [
                2.6716540072898765,
                39.554883810784965
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.1536548158044555,
                41.27053878491374
              ],
              [
                2.1828372498864868,
                41.279311642113356
              ],
              [
                2.1677310487146118,
                41.30820212645444
              ],
              [
                2.1481616517419555,
                41.29117892513504
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.202575211325848,
                41.38178685608116
              ],
              [
                2.2266078040992854,
                41.30497604995594
              ],
              [
                2.2599101112281916,
                41.340299652158876
              ],
              [
                2.2351908729469416,
                41.403164336806654
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.261626724997723,
                41.446412900994126
              ],
              [
                2.2420573280250666,
                41.417583725482466
              ],
              [
                2.260253433982098,
                41.35164039628611
              ],
              [
                2.2832560584938166,
                41.37457359006875
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.0787083921344163,
                41.25263481526829
              ],
              [
                2.1240269956500413,
                41.25831306113636
              ],
              [
                2.1130406675250413,
                41.285148995673005
              ],
              [
                2.0684087095172288,
                41.27379667735454
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -0.30911052030861086,
                39.43956842901022
              ],
              [
                -0.31211459440529055,
                39.4410930044794
              ],
              [
                -0.3142603616172046,
                39.44175585297055
              ],
              [
                -0.3160628060752124,
                39.43844154743321
              ],
              [
                -0.3197535256797046,
                39.43525966575149
              ],
              [
                -0.3255041818076343,
                39.436585467447955
              ],
              [
                -0.3261908273154468,
                39.435524828109315
              ],
              [
                -0.316148636763689,
                39.43260798666358
              ],
              [
                -0.3124579171591968,
                39.43353608582468
              ],
              [
                -0.30619227690040773,
                39.43227651968127
              ],
              [
                -0.306535599654314,
                39.443015247724574
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -0.30068600154099956,
                39.45101302198936
              ],
              [
                -0.2994843719023277,
                39.43232075980465
              ],
              [
                -0.2699586150663902,
                39.42966896885986
              ],
              [
                -0.26704037165818706,
                39.45141067519127
              ],
              [
                -0.2926179168242027,
                39.44756659910639
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -0.33227169490037456,
                39.4183977314436
              ],
              [
                -0.32540523982224956,
                39.39306394835939
              ],
              [
                -0.30205929255662456,
                39.399829366933474
              ],
              [
                -0.30823910212693706,
                39.41534755385377
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -0.34188473200974956,
                39.416408500326476
              ],
              [
                -0.37347042536912456,
                39.409246798304025
              ],
              [
                -0.36437237239060893,
                39.381256058209416
              ],
              [
                -0.3509827849882652,
                39.38311361155333
              ],
              [
                -0.3372498748320152,
                39.39518650324771
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Point",
          "coordinates": [
            2.738260734341509,
            39.557601486583586
          ]
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.7380890729645557,
                39.55627799096826
              ],
              [
                2.7471871259430714,
                39.546086228915264
              ],
              [
                2.7612633588532276,
                39.54727755109983
              ],
              [
                2.7573151471833057,
                39.56236586170465
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.7078766706208057,
                39.544233020418964
              ],
              [
                2.7325959089020557,
                39.55680739224471
              ],
              [
                2.730020988247759,
                39.562101182784026
              ],
              [
                2.7169747235993214,
                39.552836784187434
              ],
              [
                2.7051300885895557,
                39.546350968946065
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.7375740888336964,
                39.545424374419405
              ],
              [
                2.7284760358551807,
                39.540658835701166
              ],
              [
                2.7319092633942432,
                39.53907025007503
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.730364311001665,
                39.53271554398076
              ],
              [
                2.731394279263384,
                39.535231018037365
              ],
              [
                2.7188629987458057,
                39.540658835701166
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.7322525861481495,
                39.52093132050948
              ],
              [
                2.7401490094879932,
                39.50795312066262
              ],
              [
                2.7470154645661182,
                39.50980729765334
              ],
              [
                2.7446122052887745,
                39.51431009291963
              ],
              [
                2.7349991681793995,
                39.52252032121523
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.6405854108551807,
                39.55389563522462
              ],
              [
                2.6604981305817432,
                39.55813087775897
              ],
              [
                2.67131279732979,
                39.55442505468272
              ],
              [
                2.6865906598786182,
                39.547012814604145
              ],
              [
                2.6898522260407276,
                39.550851394933225
              ],
              [
                2.6570649030426807,
                39.56342456728576
              ],
              [
                2.6563782575348682,
                39.561174798607
              ],
              [
                2.645220268032915,
                39.56104245700014
              ],
              [
                2.6357788923004932,
                39.55799853034391
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6729185466429626,
                40.33105399204203
              ],
              [
                -3.6788837794920837,
                40.328829326885995
              ],
              [
                -3.6759226207396423,
                40.32444521326833
              ],
              [
                -3.6736481074950134,
                40.31963544766159
              ],
              [
                -3.670686948742572,
                40.31809755914975
              ],
              [
                -3.6703007106444274,
                40.31845749364348
              ],
              [
                -3.672532308544818,
                40.3258848043639
              ],
              [
                -3.6706440333983337,
                40.329810805847416
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6640350703856384,
                40.31799939486392
              ],
              [
                -3.663949239697162,
                40.31394181285108
              ],
              [
                -3.6548941020628845,
                40.31237107048257
              ],
              [
                -3.6523191814085876,
                40.31750857129383
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.682983323311937,
                40.31147778053175
              ],
              [
                -3.6812237941981674,
                40.305358000686134
              ],
              [
                -3.669593735909593,
                40.305718003085424
              ],
              [
                -3.668477936959398,
                40.311641403397495
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.899654405200752,
                40.45854639624648
              ],
              [
                -3.8876381088140333,
                40.45724025394369
              ],
              [
                -3.8852348495366895,
                40.46148512358472
              ],
              [
                -3.893989579761299,
                40.46873343470939
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry({
      "type": "GeometryCollection",
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.772769972190917,
                40.44117859403722
              ],
              [
                -3.7765465224838857,
                40.434253961274386
              ],
              [
                -3.7707100356674794,
                40.42758996207951
              ],
              [
                -3.7760315383530263,
                40.41791945570247
              ],
              [
                -3.771396681175292,
                40.40863969007787
              ],
              [
                -3.7556038344956044,
                40.420271868991435
              ],
              [
                -3.7377510512924794,
                40.42562983664209
              ],
              [
                -3.7652168716049794,
                40.44196246978678
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.740036501357258,
                40.472015772506865
              ],
              [
                -3.7483620781394844,
                40.468881616872046
              ],
              [
                -3.7444138664695625,
                40.46143741101492
              ],
              [
                -3.7352299828025703,
                40.46202514147364
              ],
              [
                -3.7334275383445625,
                40.46463721463161
              ],
              [
                -3.737289919326008,
                40.46862043063323
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.64568739883673,
                40.42468418575348
              ],
              [
                -3.647489843294738,
                40.41690834951417
              ],
              [
                -3.6399367427088003,
                40.41560139805984
              ],
              [
                -3.6322978114343862,
                40.41632022450137
              ],
              [
                -3.637018499300597,
                40.4197182091741
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.5932448481775503,
                40.416712308414446
              ],
              [
                -3.5833743190027456,
                40.41651626674352
              ],
              [
                -3.5820010279871206,
                40.423704087834345
              ],
              [
                -3.590326604769347,
                40.426056298848536
              ],
              [
                -3.5945323085046987,
                40.427885739434316
              ],
              [
                -3.597622213289855,
                40.42167850688082
              ],
              [
                -3.6028578852869253,
                40.418738038900095
              ],
              [
                -3.6034587001062612,
                40.41292206821321
              ],
              [
                -3.5904124354578237,
                40.4101772782368
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.567992190764495,
                40.438698849433536
              ],
              [
                -3.5790643495779717,
                40.438176241245955
              ],
              [
                -3.5843858522635186,
                40.435367152637625
              ],
              [
                -3.5903081697684014,
                40.43798026212827
              ],
              [
                -3.5935697359305108,
                40.43216595510656
              ],
              [
                -3.58859155599887,
                40.42850725703234
              ],
              [
                -3.5806951326590264,
                40.42831124973249
              ],
              [
                -3.580952624724456,
                40.43216595510656
              ],
              [
                -3.5796651643973076,
                40.434779189006136
              ],
              [
                -3.571167926238128,
                40.43660839230885
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6586212626555237,
                40.35631776453639
              ],
              [
                -3.671324204550055,
                40.352851170709414
              ],
              [
                -3.667032670126227,
                40.345067037171674
              ],
              [
                -3.6637711039641174,
                40.349776872372146
              ],
              [
                -3.6587070933440002,
                40.35317821547628
              ],
              [
                -3.6526131144621643,
                40.352393305371116
              ],
              [
                -3.6449741831877502,
                40.350954279783544
              ],
              [
                -3.6430000773527893,
                40.35514045076905
              ],
              [
                -3.6494373789885315,
                40.35520585762874
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.62051243697193,
                40.36141921998598
              ],
              [
                -3.627207230673102,
                40.36024199529733
              ],
              [
                -3.6363052836516174,
                40.36259642411765
              ],
              [
                -3.6445450297453674,
                40.36325041753033
              ],
              [
                -3.640081833944586,
                40.35618695291071
              ],
              [
                -3.617594193563727,
                40.35958797269879
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.608324479208258,
                40.361680822680654
              ],
              [
                -3.6169075480559143,
                40.35370148380416
              ],
              [
                -3.6005997172453674,
                40.35108510156038
              ],
              [
                -3.592016648397711,
                40.348206963848234
              ],
              [
                -3.5908150187590393,
                40.352916579789685
              ],
              [
                -3.5978531352141174,
                40.35343985014778
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.551667376146048,
                40.46327423126426
              ],
              [
                -3.5590488153550326,
                40.464188451423375
              ],
              [
                -3.5588771539780795,
                40.46562505796218
              ],
              [
                -3.5657436090562045,
                40.46601685441276
              ],
              [
                -3.5660869318101107,
                40.46170696775715
              ],
              [
                -3.551324053392142,
                40.461968180881016
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.575013323411673,
                40.48207854105151
              ],
              [
                -3.5671169000718295,
                40.47332996864353
              ],
              [
                -3.5645419794175326,
                40.46732282607534
              ],
              [
                -3.5533839899155795,
                40.46640864857792
              ],
              [
                -3.5547572809312045,
                40.472285286796804
              ],
              [
                -3.5614520746323763,
                40.47633333841942
              ],
              [
                -3.569520159349173,
                40.48247024150862
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6060235923918627,
                40.454879849996146
              ],
              [
                -3.6003587669524095,
                40.46141053701888
              ],
              [
                -3.606195253768816,
                40.464022634076045
              ],
              [
                -3.609456819930925,
                40.4603656697554
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6277097935664826,
                40.495359875509884
              ],
              [
                -3.639382767199295,
                40.4940544491774
              ],
              [
                -3.6386961216914826,
                40.48883248987011
              ],
              [
                -3.631143021105545,
                40.48857138123785
              ],
              [
                -3.6290830845821076,
                40.487135265601374
              ],
              [
                -3.62427656602742,
                40.48791860521265
              ],
              [
                -3.6235899205196076,
                40.48439350496185
              ],
              [
                -3.618611740587967,
                40.486221357832626
              ],
              [
                -3.6162084813106232,
                40.49013801779318
              ],
              [
                -3.6217016453731232,
                40.49000746614375
              ],
              [
                -3.6271948094356232,
                40.492226809643476
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.590974258898514,
                40.51572123763415
              ],
              [
                -3.600587296007889,
                40.51232810653761
              ],
              [
                -3.59955732774617,
                40.50345295187837
              ],
              [
                -3.5863394017207795,
                40.507629641550594
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.665474197719564,
                39.552766122714885
              ],
              [
                2.6692507480125327,
                39.53926434164829
              ],
              [
                2.6761172030906577,
                39.54350047733865
              ],
              [
                2.6716540072898765,
                39.554883810784965
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.1536548158044555,
                41.27053878491374
              ],
              [
                2.1828372498864868,
                41.279311642113356
              ],
              [
                2.1677310487146118,
                41.30820212645444
              ],
              [
                2.1481616517419555,
                41.29117892513504
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.202575211325848,
                41.38178685608116
              ],
              [
                2.2266078040992854,
                41.30497604995594
              ],
              [
                2.2599101112281916,
                41.340299652158876
              ],
              [
                2.2351908729469416,
                41.403164336806654
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.261626724997723,
                41.446412900994126
              ],
              [
                2.2420573280250666,
                41.417583725482466
              ],
              [
                2.260253433982098,
                41.35164039628611
              ],
              [
                2.2832560584938166,
                41.37457359006875
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.0787083921344163,
                41.25263481526829
              ],
              [
                2.1240269956500413,
                41.25831306113636
              ],
              [
                2.1130406675250413,
                41.285148995673005
              ],
              [
                2.0684087095172288,
                41.27379667735454
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -0.30911052030861086,
                39.43956842901022
              ],
              [
                -0.31211459440529055,
                39.4410930044794
              ],
              [
                -0.3142603616172046,
                39.44175585297055
              ],
              [
                -0.3160628060752124,
                39.43844154743321
              ],
              [
                -0.3197535256797046,
                39.43525966575149
              ],
              [
                -0.3255041818076343,
                39.436585467447955
              ],
              [
                -0.3261908273154468,
                39.435524828109315
              ],
              [
                -0.316148636763689,
                39.43260798666358
              ],
              [
                -0.3124579171591968,
                39.43353608582468
              ],
              [
                -0.30619227690040773,
                39.43227651968127
              ],
              [
                -0.306535599654314,
                39.443015247724574
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -0.30068600154099956,
                39.45101302198936
              ],
              [
                -0.2994843719023277,
                39.43232075980465
              ],
              [
                -0.2699586150663902,
                39.42966896885986
              ],
              [
                -0.26704037165818706,
                39.45141067519127
              ],
              [
                -0.2926179168242027,
                39.44756659910639
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -0.33227169490037456,
                39.4183977314436
              ],
              [
                -0.32540523982224956,
                39.39306394835939
              ],
              [
                -0.30205929255662456,
                39.399829366933474
              ],
              [
                -0.30823910212693706,
                39.41534755385377
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -0.34188473200974956,
                39.416408500326476
              ],
              [
                -0.37347042536912456,
                39.409246798304025
              ],
              [
                -0.36437237239060893,
                39.381256058209416
              ],
              [
                -0.3509827849882652,
                39.38311361155333
              ],
              [
                -0.3372498748320152,
                39.39518650324771
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Point",
          "coordinates": [
            2.738260734341509,
            39.557601486583586
          ]
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.7380890729645557,
                39.55627799096826
              ],
              [
                2.7471871259430714,
                39.546086228915264
              ],
              [
                2.7612633588532276,
                39.54727755109983
              ],
              [
                2.7573151471833057,
                39.56236586170465
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.7078766706208057,
                39.544233020418964
              ],
              [
                2.7325959089020557,
                39.55680739224471
              ],
              [
                2.730020988247759,
                39.562101182784026
              ],
              [
                2.7169747235993214,
                39.552836784187434
              ],
              [
                2.7051300885895557,
                39.546350968946065
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.7375740888336964,
                39.545424374419405
              ],
              [
                2.7284760358551807,
                39.540658835701166
              ],
              [
                2.7319092633942432,
                39.53907025007503
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.730364311001665,
                39.53271554398076
              ],
              [
                2.731394279263384,
                39.535231018037365
              ],
              [
                2.7188629987458057,
                39.540658835701166
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.7322525861481495,
                39.52093132050948
              ],
              [
                2.7401490094879932,
                39.50795312066262
              ],
              [
                2.7470154645661182,
                39.50980729765334
              ],
              [
                2.7446122052887745,
                39.51431009291963
              ],
              [
                2.7349991681793995,
                39.52252032121523
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                2.6405854108551807,
                39.55389563522462
              ],
              [
                2.6604981305817432,
                39.55813087775897
              ],
              [
                2.67131279732979,
                39.55442505468272
              ],
              [
                2.6865906598786182,
                39.547012814604145
              ],
              [
                2.6898522260407276,
                39.550851394933225
              ],
              [
                2.6570649030426807,
                39.56342456728576
              ],
              [
                2.6563782575348682,
                39.561174798607
              ],
              [
                2.645220268032915,
                39.56104245700014
              ],
              [
                2.6357788923004932,
                39.55799853034391
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6729185466429626,
                40.33105399204203
              ],
              [
                -3.6788837794920837,
                40.328829326885995
              ],
              [
                -3.6759226207396423,
                40.32444521326833
              ],
              [
                -3.6736481074950134,
                40.31963544766159
              ],
              [
                -3.670686948742572,
                40.31809755914975
              ],
              [
                -3.6703007106444274,
                40.31845749364348
              ],
              [
                -3.672532308544818,
                40.3258848043639
              ],
              [
                -3.6706440333983337,
                40.329810805847416
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.6640350703856384,
                40.31799939486392
              ],
              [
                -3.663949239697162,
                40.31394181285108
              ],
              [
                -3.6548941020628845,
                40.31237107048257
              ],
              [
                -3.6523191814085876,
                40.31750857129383
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.682983323311937,
                40.31147778053175
              ],
              [
                -3.6812237941981674,
                40.305358000686134
              ],
              [
                -3.669593735909593,
                40.305718003085424
              ],
              [
                -3.668477936959398,
                40.311641403397495
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.899654405200752,
                40.45854639624648
              ],
              [
                -3.8876381088140333,
                40.45724025394369
              ],
              [
                -3.8852348495366895,
                40.46148512358472
              ],
              [
                -3.893989579761299,
                40.46873343470939
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "coordinates": []
    }),
    table3 = ui.import && ui.import("table3", "table", {
      "id": "FAO/GAUL/2015/level0"
    }) || ee.FeatureCollection("FAO/GAUL/2015/level0"),
    dataset = ui.import && ui.import("dataset", "table", {
      "id": "USDOS/LSIB_SIMPLE/2017"
    }) || ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017"),
    imageCollection8 = ui.import && ui.import("imageCollection8", "imageCollection", {
      "id": "projects/ee-pmisson/assets/SDGSAT_EU_Cal"
    }) || ee.ImageCollection("projects/ee-pmisson/assets/SDGSAT_EU_Cal"),
    geometry13 = ui.import && ui.import("geometry13", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                1.5032856373554626,
                35.73817265931419
              ],
              [
                9.237660637355463,
                37.710462218249475
              ],
              [
                11.874379387355463,
                37.710462218249475
              ],
              [
                12.841176262355463,
                34.15331576014714
              ],
              [
                19.52086376235546,
                33.422866083150836
              ],
              [
                34.63805126235546,
                31.344862099470955
              ],
              [
                35.51695751235546,
                36.09407428891881
              ],
              [
                30.85875438735546,
                41.30310558139264
              ],
              [
                30.85875438735546,
                45.82163923023019
              ],
              [
                28.48570751235546,
                48.85795510831007
              ],
              [
                25.40953563735546,
                48.4515375140165
              ],
              [
                24.61852001235546,
                50.785551503672146
              ],
              [
                24.09117626235546,
                52.58345816323787
              ],
              [
                29.45250438735546,
                54.25922278190012
              ],
              [
                31.21031688735546,
                57.74559292129397
              ],
              [
                31.29820751235546,
                71.52165274006332
              ],
              [
                13.192738762355463,
                70.22626874129823
              ],
              [
                10.292348137355463,
                64.80718395376674
              ],
              [
                4.931020012355463,
                62.75002172133685
              ],
              [
                -1.3092143626445374,
                61.51779540371068
              ],
              [
                -9.922495612644537,
                59.79546550587129
              ],
              [
                -13.965464362644537,
                53.79458209862782
              ],
              [
                -6.846323737644537,
                48.100569845248586
              ],
              [
                -3.5064799876445374,
                47.0930499377955
              ],
              [
                -2.4517924876445374,
                44.33221611150168
              ],
              [
                -10.010386237644537,
                45.01968799690904
              ],
              [
                -10.537729987644537,
                36.165062281687206
              ],
              [
                -18.359995612644536,
                35.38067308131806
              ],
              [
                -20.293589362644536,
                26.971671702106445
              ],
              [
                -14.404917487644537,
                26.971671702106445
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[1.5032856373554626, 35.73817265931419],
          [9.237660637355463, 37.710462218249475],
          [11.874379387355463, 37.710462218249475],
          [12.841176262355463, 34.15331576014714],
          [19.52086376235546, 33.422866083150836],
          [34.63805126235546, 31.344862099470955],
          [35.51695751235546, 36.09407428891881],
          [30.85875438735546, 41.30310558139264],
          [30.85875438735546, 45.82163923023019],
          [28.48570751235546, 48.85795510831007],
          [25.40953563735546, 48.4515375140165],
          [24.61852001235546, 50.785551503672146],
          [24.09117626235546, 52.58345816323787],
          [29.45250438735546, 54.25922278190012],
          [31.21031688735546, 57.74559292129397],
          [31.29820751235546, 71.52165274006332],
          [13.192738762355463, 70.22626874129823],
          [10.292348137355463, 64.80718395376674],
          [4.931020012355463, 62.75002172133685],
          [-1.3092143626445374, 61.51779540371068],
          [-9.922495612644537, 59.79546550587129],
          [-13.965464362644537, 53.79458209862782],
          [-6.846323737644537, 48.100569845248586],
          [-3.5064799876445374, 47.0930499377955],
          [-2.4517924876445374, 44.33221611150168],
          [-10.010386237644537, 45.01968799690904],
          [-10.537729987644537, 36.165062281687206],
          [-18.359995612644536, 35.38067308131806],
          [-20.293589362644536, 26.971671702106445],
          [-14.404917487644537, 26.971671702106445]]]),
    image = ui.import && ui.import("image", "image", {
      "id": "projects/ee-pmisson/assets/SDGSAT_EU_UK_Cal2"
    }) || ee.Image("projects/ee-pmisson/assets/SDGSAT_EU_UK_Cal2");
var imageVisParam22 = imageVisParam22, imageVisParamX = imageVisParam4, imageVisParam4 = imageVisParam42, imageCollection7 = imageCollection7;
//Spain
    imageVisParam2 = {"opacity":1,"bands":["b1","b2","b3"],"min":7,"max":4000,"gamma":[2.5,2.5,3.5]},
function invertCloudsLayer(image) {
  // Assuming the 'clouds' layer is an 8-bit image with values from 0 to 255
  // Invert the 'clouds' layer by subtracting its values from 255
  var invertedClouds = image.select('clouds').subtract(3).multiply(-1);
  // Replace the original 'clouds' layer with the inverted one
  return image.addBands(invertedClouds.rename('clouds'), null, true);
}
var image=image
Map.addLayer(image,imageVisParam2,'image',true)
var mapId = image.getMap(imageVisParam2);
// Get the map ID and token
print('Map ID: ' + mapId.mapid);
print('Token SDGSAT: ' + mapId.token);
print(mapId)
Map.addLayer(image.mask(image.select('clouds').gt(2)).unmask(7),imageVisParam2,'image C',false)
Map.addLayer(image.select('clouds'),imageVisParam,'Clouds',false)
//Map.addLayer(workong,imageVisParam2,'Working',false)
//Map.addLayer(imageCollection4.mosaic(),imageVisParam2,'France')
function applyCloudMask(image) {
  // Assuming 'cloudMask' is the band indicating clouds (2 = cloud, 3 = clear)
  var mask = image.select('clouds').eq(3); // Clouds are masked out, clear conditions are kept
  return image.updateMask(mask);
}
// Center the map on Praha
Map.setCenter(14.4378, 50.0755, 5); // Coordinates for Praha, zoom level 8
var municipios1 = ee.FeatureCollection('projects/ee-pmisson/assets/Municipios_IGN').filter(ee.Filter.eq('NAMEUNIT', "Majadahonda"));
var municipios2 = ee.FeatureCollection('projects/ee-pmisson/assets/Municipios_IGN').filter(ee.Filter.eq('NAMEUNIT', "Rivas-Vaciamadrid"));
print(municipios2)
// Filtra por España (código 203) y luego por las provincias de Aragón
var aragon = gaul.filter(ee.Filter.eq('ADM0_NAME', "Spain")).filter(
    ee.Filter.eq('ADM1_NAME', 'Aragón')
);
var Madrid = gaul.filter(ee.Filter.eq('ADM0_NAME', "Spain")).filter(
    ee.Filter.eq('ADM1_NAME', 'Comunidad de Madrid')
);
// Establece las propiedades de visualización
var visualization = {
  color: 'blue',
  fillColor: 'rgba(0, 0, 255, 0.1)'
};
print(Madrid)
// Añade las provincias de Aragón al mapa
//Map.addLayer(aragon, visualization, 'Aragón');
// Centra el mapa en Aragón
//Map.centerObject(aragon, 7);
// Load the LSIB_SIMPLE dataset (international boundaries).
// Filter the dataset for the Czech Republic.
var czechRepublicBorder = dataset.filter(ee.Filter.eq('country_na', 'Czechia'));
// Define the visualization parameters with a red line.
var visParams = {
  color: 'red',
  fillColor: '00000000', // transparent fill
  width: 3
};
// Add the Czech Republic border as a layer.
// Center the map over the Czech Republic.
Map.centerObject(czechRepublicBorder, 6);
// This function adds a band representing the image timestamp.
var addGR = function(image) {
  return image.addBands(image.select('b2').divide(image.select('b1')).rename('GR'));
};
var addBG = function(image) {
  return image.addBands(image.select('b3').divide(image.select('b2')).rename('BG'));
};
var addRG = function(image) {
  return image.addBands(image.select('b1').divide(image.select('b2')).rename('RG'));
};
var addBR = function(image) {
  return image.addBands(image.select('b3').subtract(6).divide(image.select('b1').subtract(6)).rename('BR'));
};
var addQ = function(image) {
  return image.addBands(image.select('b1_1').divide(7).rename('Q'));
};
/*
var maskRGB = function(image) {
  return image.addBands(image.select('GR').lt(3).multiply(image.select('BG').lt(3)).multiply(image.select('RG').lt(3)).rename('quality'));
};
*/
var maskRGB = function(image) {
  return image.addBands((image.select('GR').lt(6)).multiply(image.select('BG').lt(3)).multiply(image.select('RG').lt(5)).multiply(image.select('BR')).multiply(image.select('Q')).rename('quality'));
};
var maskRGB1 = function(image) {
  return image.addBands((image.select('GR').lt(6)).multiply(image.select('BG').lt(3)).multiply(image.select('RG').lt(5)).rename('mask'));
};
var calibrate = function(image) {
  // Obtener la fecha de la imagen desde los metadatos
  var date = ee.Date(image.get('system:time_start'));
  // Definir la fecha límite para aplicar una u otra calibración
  var dateLimit = ee.Date('2023-05-19');
  var calibration1 = function(img) {
    var geomX = img.geometry();
    var built = ee.Image("DLR/WSF/WSF2015/v1").divide(255).unmask(0).rename('Built');
    var RED = img.select('b1').divide(0.78687502);
    var GREEN = img.select('b2').divide(0.73618369);
    var BLUE = img.select('b3').divide(0.65442494);
    var pan = img.select('b1_1').rename('PAN');
    var evi = RED.expression('(u)*0.00001354+0.0000136754', {'u': RED}).rename('R');
    var evi2 = GREEN.expression('(u)* 0.00000507+0.000006084', {'u': GREEN}).rename('G');
    var evi3 = BLUE.expression('(u)* 0.0000099253+0.0000099253', {'u': BLUE}).rename('B');
    var evi4 = GREEN.expression('b/g', {'b': BLUE, 'g': GREEN}).rename('BG');
    var evi5 = GREEN.expression('g/r', {'r': RED, 'g': GREEN}).rename('GR');
    return RED.addBands([evi, evi2, evi3, evi4, evi5, built, pan]);
  };
  var calibration2 = function(img) {
    var geomX = img.geometry();
    var built = ee.Image("DLR/WSF/WSF2015/v1").divide(255).unmask(0).rename('Built');
    var RED = img.select('b1').divide(0.78687502);
    var GREEN = img.select('b2').divide(0.73618369);
    var BLUE = img.select('b3').divide(0.65442494);
    var pan = img.select('b1_1').rename('PAN');
    var evi = RED.expression('(u)*0.0000102744+0.0000099253', {'u': RED}).rename('R');  // Diferente calibración
    var evi2 = GREEN.expression('(u)* 0.0000041779+0.0000060840', {'u': GREEN}).rename('G');  // Diferente calibración
    var evi3 = BLUE.expression('(u)* 0.0000070119+0.0000136754', {'u': BLUE}).rename('B');  // Diferente calibración
    var evi4 = GREEN.expression('b/g', {'b': BLUE, 'g': GREEN}).rename('BG');
    var evi5 = GREEN.expression('g/r', {'r': RED, 'g': GREEN}).rename('GR');
    return RED.addBands([evi, evi2, evi3, evi4, evi5, built, pan]);
  };
  // Aplicar la calibración correspondiente según la fecha
  var calibratedImage = ee.Image(ee.Algorithms.If(
    date.difference(dateLimit, 'day').lte(0),
    calibration1(image),
    calibration2(image)
  ));
  return calibratedImage;
};
var built = ee.Image("DLR/WSF/WSF2015/v1").divide(255).unmask(0).rename('Built')
//print(mosaicRGB)
// Map the function over the collection and display the result.
var imageVisParam = {
  "opacity":1,"bands":["b1","b2","b3"],"min":[8,8, 8],
  "max":[4000,4000, 3000],"gamma":[2.5,2.5,3.5]};
var imageVisParam1 = {
  "opacity":1,"bands":["b1_1","b2_1","b3_1"],"min":[8,8, 8],
  "max":[100,100, 100],"gamma":2};
//////////////////////////////////////////////////
/*
// Definir el punto de interés
var point = ee.Geometry.Point([-0.80857, 51.52337]);
// Cargar la colección de imágenes
var collectionC = collection.filterBounds(point);
// Mostrar el número de imágenes filtradas
print("Número de imágenes filtradas:", collectionC.size());
// Centrar el mapa en el punto
Map.centerObject(point, 10);
// Definir parámetros de visualización (ajusta según las bandas disponibles)
// Definir parámetros de visualización (ajusta según las bandas disponibles)
var visParams = {
  bands: ['b1', 'b2', 'b3'], // Ajusta las bandas si la colección tiene diferentes nombres
  min: 0,
  max: 3000,
  gamma: 3
};
// Iterar sobre la colección y agregar cada imagen al mapa con su nombre
collectionC.evaluate(function(col) {
  col.features.forEach(function(f) {
    var img = ee.Image(f.id);
    var imageName = f.properties['id_no']; // Obtener el nombre de la imagen
    print(f.properties)
    Map.addLayer(img, visParams, imageName);
  });
});
// Agregar el punto al mapa
Map.addLayer(point, {color: 'red'}, "Punto de interés");
*/
////////////////////////////////////////////////
var outputImage =image
// Print the output image to the console
print('Output Image:', outputImage);
imageVisParam5 = {"opacity":1,"bands":["R","G","B"],"min":[0.000306129228,0.000452244,0.000307684],"max":[0.04548099540000001,0.016437953999999998,0.0308875336],"gamma":3};
Map.addLayer(image,imageVisParam5,'median_cal',false);
// Carga o define la imagen a procesar.
var image = image;// Reemplaza 'TU_IMAGEN_ID' por el ID de tu imagen
// Selecciona las bandas 'B' y 'G' individualmente.
var B = image.select('B');
var G = image.select('G');
// Calcula Mel usando la fórmula.
var mel = B.multiply(0.95).subtract(G.multiply(0.05)).rename('Mel');
// Muestra la imagen en el mapa.
Map.centerObject(image, 8);
//Map.addLayer(mel.unmask(0), {min: 0, max: 0.004238358671928919}, 'Mel');
    imageVisParam = {"min":1000.8785508231963,"max":5000.906957408766,"palette":["ff0000","ff8f02","95fff6","55bfff","0a76ff","0007ff"]};
var paleta = ['#FF8C00', '#FFD700', '#FFFFB3', '#FFFFCC', '#F0F8FF', '#FFFFFF', '#1E90FF', '#0000FF'];
var min = 1000;
var max = 5000;
// Suponiendo que 'miImagen' es tu imagen de entrada
Map.addLayer(outputImage.mask(image.select('R').gt(0.0023425554)),  imageVisParam7, 'CCT',false);
//Map.addLayer(mosaicRGB5a.select(['GR','BG']).mask(mosaicRGB3.select('b2').gt(200)),{},'GR,BG',false)
//Map.addLayer(imageXXX,{},'Logo CBAS')
//Map.addLayer(outputImage.mask(mosaicRGB5a.select('R').gt(0.0023425554)),imageVisParam,'CCT',false);
// Parámetros de visualización
var imageVisParam7 = {
  "opacity": 1,
  "bands": ["constant"],
  "min": 1600,
  "max": 5000,
  "palette": ["ff8c00", "ff881e", "ffc518", "fff12f", "ffffff", "dcffff", "a9d7ff", "add8ff", "97c5ff", "4596ff", "3b76ff", "3500ff", "1200ff"]
};
// Crear un panel principal para la leyenda
var leyenda2 = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px',
    shown: false // inicialmente ocultar la leyenda
  }
});
// Añadir un título a la leyenda
leyenda2.add(ui.Label({
  value: 'CCT(K)',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
  }
}));
// Añade aquí el resto de tu código para construir la leyenda
// ...
// Crear un panel separado para la casilla de verificación, posicionado en la parte inferior
var panelCheckbox = ui.Panel({
  style: {
    position: 'bottom-center',
    padding: '8px'
  }
});
// Crear una casilla de verificación para controlar la visibilidad de la leyenda
var checkboxLeyenda = ui.Checkbox('CCT legend', false, function(checked) {
  leyenda2.style().set('shown', checked);
});
// Añadir la casilla de verificación al panel de control
panelCheckbox.add(checkboxLeyenda);
// Añadir el panel de la leyenda y el panel de la casilla de verificación al mapa
Map.add(leyenda2);
Map.add(panelCheckbox);
// Función para añadir cada entrada de la paleta a la leyenda
var incremento = (imageVisParam7.max - imageVisParam7.min) / (imageVisParam7.palette.length - 1);
for (var i = 0; i < imageVisParam7.palette.length; i++) {
  var color = imageVisParam7.palette[i];
  var valor = imageVisParam7.min + i * incremento;
  var etiqueta = ui.Label({
    value: Math.round(valor) + '',
    style: {
      backgroundColor: '#' + color,
      padding: '8px',
      margin: '0 0 4px 0'
    }
  });
  leyenda2.add(etiqueta);
}
// Añadir la leyenda al mapa
//Map.add(leyenda2);
/*
// plot sampled features as a scatter chart
var chart = ui.Chart.feature.byFeature(values, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, titleX: 'GR', titleY: 'BG' })
var chart1 = ui.Chart.feature.byFeature(values1, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, titleX: 'GR', titleY: 'BG' })
var chart2 = ui.Chart.feature.byFeature(values2, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, titleX: 'GR', titleY: 'BG' })
var chart3 = ui.Chart.feature.byFeature(values3, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, titleX: 'GR', titleY: 'BG' })
var chart4 = ui.Chart.feature.byFeature(values4, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, titleX: 'GR', titleY: 'BG' })
print(chart) 
print(chart1) 
print(chart2) 
print(chart3) 
print(chart4) 
var histRegion = geometry;
// Define the chart and print it to the console.
var chart =
    ui.Chart.image.histogram({image: mosaicRGB5a.select(['GR','BG']).mask(mosaicRGB3.select('b2').gt(200)), region: histRegion, scale: 600,maxBuckets:20,minBucketWidth:.2,maxRaw:10})
        .setSeriesNames(['GR', 'BG'])
        .setOptions({
          title: 'SDGSAT-1 GR BG ratios',
          hAxis: {
            title: 'Ratio',
            titleTextStyle: {italic: false, bold: true},
          },
          vAxis:
              {title: 'Count', titleTextStyle: {italic: false, bold: true}},
          colors: ['cf513e', '1d6b99', 'f0af07']
        });
var chart1 =
    ui.Chart.image.histogram({image: mosaicRGB5a.select(['GR','BG']).mask(mosaicRGB3.select('b2').gt(200)), region: aragon, scale: 600,maxBuckets:20,minBucketWidth:.2,maxRaw:10})
        .setSeriesNames(['GR', 'BG'])
        .setOptions({
          title: 'SDGSAT-1 GR BG ratios',
          hAxis: {
            title: 'Ratio',
            titleTextStyle: {italic: false, bold: true},
          },
          vAxis:
              {title: 'Count', titleTextStyle: {italic: false, bold: true}},
          colors: ['cf513e', '1d6b99', 'f0af07']
        });
print(chart);
print(chart1);
/*
var image2area = ee.Image.pixelArea();
image2area.reproject(ee.Projection('EPSG:4326'),null, 400);
//var mosaicRGB5a = mosaicRGB5a.select(['b1'], ['RED']);
//print(mosaicRGB5a)
var country= "ES"
var  maineCounties  = 
    table.filter(ee.Filter.eq('CNTR_CODE', country));
//print(maineCounties)
var feat=  ee.Feature(maineCounties.toList(1, 13).get(0));
print(feat)
var feature_radR = mosaicRGB5a.select('R').reduceRegion({
      geometry: feat.geometry(),
      reducer: ee.Reducer.mean(),
      scale: 400
      });
//print(feature_radR)
//print(ee.Image(mosaicRGB5a).id())
var image=mosaicRGB5a
var viirs_rad = image.reproject(ee.Projection('EPSG:4326'),null, 400);
//print(viirs_rad)
var viirs_rad2 = viirs_rad.expression('IMA*PIX',{'IMA':viirs_rad.select(['R','G','B']),'PIX':image2area.select('area')});
//print(viirs_rad2)
    var feature_radR = viirs_rad2.select('R').reduceRegion({
      geometry: feat.geometry(),
      reducer: ee.Reducer.sum(),
      scale: 400
      });
print(feature_radR)
var summarize_viirs = function(feature){
  var viirs_all =  ee.ImageCollection([mosaicRGB5a]);
  var summarize_viirs_year = function(image, feat){
    feat = ee.Feature(feat);
    image = ee.Image(image);
    var viirs_rad = image.reproject(ee.Projection('EPSG:4326'),null, 40);
    var viirs_rad2 = viirs_rad.expression('IMA*PIX',{'IMA':viirs_rad.select(['R','G','B']),'PIX':image2area.select('area')});
    // Mask radiance values with cloud cover
    //var viirs_rad3 = viirs_rad2.mask(viirs_cld);
    // Average VIIRS Radiance
    var feature_radR = viirs_rad2.select('R').reduceRegion({
      geometry: feature.geometry(),
      reducer: ee.Reducer.mean(),
      scale: 40
      });
    // Sum VIIRS Radiance
    var feature_radG = viirs_rad2.select('G').reduceRegion({
      geometry: feature.geometry(),
      reducer: ee.Reducer.mean(),
      scale: 40
      });
    var feature_radB = viirs_rad2.select('B').reduceRegion({
      geometry: feature.geometry(),
      reducer: ee.Reducer.mean(),
      scale: 40
      });
    // Area
    var area = image2area.select('area').reduceRegion({
      geometry: feature.geometry(),
      reducer: ee.Reducer.sum(),
      scale: 40
      });      
    var mean_radB = feature_radB.get('B');
    var mean_radG = feature_radG.get('G');
    var mean_radR = feature_radR.get('R');
    mean_radR = ee.Number(mean_radR);
    mean_radG = ee.Number(mean_radG);
    mean_radB = ee.Number(mean_radB);
    var area1 = ee.Number(area);
    var area0 = ee.String("area");
    var mean_rad_nameR = ee.String("RED")//.cat(year_month);
    var mean_rad_nameG = ee.String("GREEN")//.cat(year_month);
    var mean_rad_nameB = ee.String("BLUE")//.cat(year_month);
    return feat.set(mean_rad_nameR, mean_radR,mean_rad_nameG, mean_radG,mean_rad_nameB, mean_radB,area0, area1);
  };  
  var new_feature = ee.Feature(viirs_all.iterate(summarize_viirs_year, 
      feature));
  return new_feature;
};
var maineCounties_output = maineCounties.map(summarize_viirs);
print(maineCounties_output);
Export.table.toDrive({
  collection: maineCounties_output,
  description:'Provinces_RGB_'+country+'_GOODX_3',
  fileFormat: 'CSV'
});
*/
// Add a label to the panel.
// Create an inspector panel with a vertical layout.
var inspector2 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical')
});
// Set the style of the panel
inspector2.style().set({
  width: '300px',
  position: 'bottom-right'
});
// Add labels to the panel.
inspector2.add(ui.Label('RALAN-MAP/Plan-B: EU + UK'));
inspector2.add(ui.Label('Collaboration between:'));
inspector2.add(ui.Label('Universidad Complutense de Madrid/University of Exeter and Plan-B'));
inspector2.add(ui.Label('and'));
inspector2.add(ui.Label('International Research Center of Big Data for Sustainable Development Goals (CBAS)'));
inspector2.add(ui.Label('Data source:It is acknowledged that the SDGSAT-1 data are kindly provided by CBAS'));
inspector2.add(ui.Label('UNA4CAREER:This project has received funding from the European Union’s Horizon 2020 Research and Innovation Programme under the Marie Sklodowska-Curie grant agreement Nº 847635.'));
//inspector2.add(ui.Label('Correlated Color Temperatures on Kelvin'));
// Replace 'your_logo_url' with the URL of your logo image
var logo = ee.Image('projects/ee-pmisson/assets/outputCBAS').visualize({
    bands:  ['b1', 'b2', 'b3'],
    min: 0,
    max: 255
    });
var thumb = ui.Thumbnail({
    image: logo,
    params: {
        dimensions: '642x291',
        format: 'png'
        },
    style: {height: '200px', width: '280px',padding :'0'}
    });
var toolPanel = ui.Panel(thumb, 'flow', {width: '300px'});
//ui.root.widgets().add(toolPanel);
// Add the logo to your panel
inspector2.add(toolPanel);
// Add citation information (if applicable)
// inspector2.add(ui.Label('Cite: [Your citation here]'));
var mosaicRGB5a=image
// Add the panel to the UI.
ui.root.add(inspector2);//Map.add(inspector1);
var R=mosaicRGB5a.select('R').gt(0.0003)
var B=mosaicRGB5a.select('B').gt(0.00002)
var G=mosaicRGB5a.select('G').gt(0.00004)
var Rhigh=mosaicRGB5a.select('R').lte(0.002)
var Rhigh2=mosaicRGB5a.select('R').lte(0.0005)
var Rhigh3=mosaicRGB5a.select('R').gte(0.00014)
var highCCT = mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN']).mask(mosaicRGB5a.select('b2').gt(30)).sample({ region: geometry3, scale: 40, numPixels: 500, geometries: true}) 
var HPS = mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN']).mask(mosaicRGB5a.select('b2').gt(30)).sample({ region: geometry4, scale: 40, numPixels: 500, geometries: true}) 
var Inter = mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN']).mask(mosaicRGB5a.select('b2').gt(30)).sample({ region: geometry5, scale: 40, numPixels: 500, geometries: true}) 
var White = mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN']).mask(mosaicRGB5a.select('b2').gt(30)).sample({ region: geometry6, scale: 40, numPixels: 500, geometries: true}) 
var redLow = mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN']).mask(R).sample({ region: geometry7, scale: 40, numPixels: 500, geometries: true}) 
var strange = mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN']).mask(R).mask(mosaicRGB5a.select('b2').gt(30)).sample({ region: geometry8, scale: 40, numPixels: 500, geometries: true}) 
var fire = mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN']).mask(mosaicRGB5a.select('b2').gt(30)).sample({ region: geometry9, scale: 40, numPixels: 500, geometries: true}) 
var  background = mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN']).mask(Rhigh).sample({ region: geometry11, scale: 40, numPixels: 1500, geometries: true}) 
var difuse = mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN']).mask(Rhigh2).mask(Rhigh3).sample({ region: geometry12, scale: 40, numPixels: 1500, geometries: true}) 
Map.addLayer(background,['red'],'background',false) ;
Map.addLayer(built,['red'],'Built',false) ;
Map.addLayer(mosaicRGB5a.mask(R).mask(G).mask(B),imageVisParam5,'Median masked', false)
/*
// Chart for highCCT
var chart1 = ui.Chart.feature.byFeature(highCCT, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, title: 'High CCT Data', titleX: 'GR', titleY: 'BG' });
print(chart1);
// Chart for HPS
var chart2 = ui.Chart.feature.byFeature(HPS, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, title: 'HPS Data', titleX: 'GR', titleY: 'BG' });
print(chart2);
// Chart for Inter
var chart3 = ui.Chart.feature.byFeature(Inter, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, title: 'Inter Data', titleX: 'GR', titleY: 'BG' });
print(chart3);
// Chart for White
var chart4 = ui.Chart.feature.byFeature(White, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, title: 'White Data', titleX: 'GR', titleY: 'BG' });
print(chart4);
// Chart for redLow
var chart5 = ui.Chart.feature.byFeature(redLow, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, title: 'Red Low Data', titleX: 'GR', titleY: 'BG' });
print(chart5);
// Chart for strange
var chart6 = ui.Chart.feature.byFeature(strange, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, title: 'Strange Data', titleX: 'GR', titleY: 'BG' });
print(chart6);
// Chart for fire
var chart7 = ui.Chart.feature.byFeature(fire, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, title: 'Fire Data', titleX: 'GR', titleY: 'BG' });
print(chart7);
// Chart for background
var chart8 = ui.Chart.feature.byFeature(background, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, title: 'Background Data', titleX: 'GR', titleY: 'BG' });
print(chart8);
// Chart for difuse
var chart9 = ui.Chart.feature.byFeature(difuse, 'BG', ['GR'])
  .setChartType('ScatterChart')
  .setOptions({ pointSize: 2, pointColor: 'red', width: 300, height: 300, title: 'Difuse Data', titleX: 'GR', titleY: 'BG' });
print(chart9);
// Generalized function to add properties to each feature
var addLampTypeProperties = function(featureCollection, lampType, lampTypeIndex) {
    return featureCollection.map(function(feature) {
        return feature.set({
            'LampType': lampType,
            'lampTypeIndex': lampTypeIndex
        });
    });
};
// Define lamp types and their indexes
var lampTypes = {
    'highCCT': 1,
    'HPS': 2,
    'Inter': 3,
    'White': 4,
    'redLow': 5,
    'strange': 6,
    'fire': 7,
    'background':8,
    'difuse':9
};
// Apply the function to each lamp type feature collection
var highCCTWithProperties = addLampTypeProperties(highCCT, 'highCCT', lampTypes['highCCT']);
var HPSWithProperties = addLampTypeProperties(HPS, 'HPS', lampTypes['HPS']);
var InterWithProperties = addLampTypeProperties(Inter, 'Inter', lampTypes['Inter']);
var WhiteWithProperties = addLampTypeProperties(White, 'White', lampTypes['White']);
var redLowWithProperties = addLampTypeProperties(redLow, 'redLow', lampTypes['redLow']);
var strangeWithProperties = addLampTypeProperties(strange, 'strange', lampTypes['strange']);
var fireWithProperties = addLampTypeProperties(fire, 'fire', lampTypes['fire']);
var backgroundWithProperties = addLampTypeProperties(background, 'background', lampTypes['background']);
var difuseWithProperties = addLampTypeProperties(difuse, 'difuse', lampTypes['difuse']);
// Print the updated feature collections to check
// Print statements for each feature collection with new properties
print('highCCT with new properties:', highCCTWithProperties);
print('HPS with new properties:', HPSWithProperties);
print('Inter with new properties:', InterWithProperties);
print('White with new properties:', WhiteWithProperties);
print('redLow with new properties:', redLowWithProperties);
print('strange with new properties:', strangeWithProperties);
print('fire with new properties:', fireWithProperties);
print('background with new properties:', backgroundWithProperties);
print('difuse with new properties:', difuseWithProperties);
// ... similarly for other feature collections
// Merge all the feature collections into a single feature collection
var mergedFeatureCollection = highCCTWithProperties
    .merge(HPSWithProperties)
    .merge(InterWithProperties)
    .merge(WhiteWithProperties)
    .merge(redLowWithProperties)
    .merge(strangeWithProperties)
    .merge(fireWithProperties)
    .merge(backgroundWithProperties)
    .merge(difuseWithProperties);
// Print the merged feature collection to check
print('Merged Feature Collection:', mergedFeatureCollection);
// Export 'highCCT' data to Google Drive
Export.table.toDrive({
  collection: highCCT,
  description: 'exportHighCCT',
  fileFormat: 'CSV'
});
// Export 'HPS' data to Google Drive
Export.table.toDrive({
  collection: HPS,
  description: 'exportHPS',
  fileFormat: 'CSV'
});
// Export 'Inter' data to Google Drive
Export.table.toDrive({
  collection: Inter,
  description: 'exportInter',
  fileFormat: 'CSV'
});
// Export 'White' data to Google Drive
Export.table.toDrive({
  collection: White,
  description: 'exportWhite',
  fileFormat: 'CSV'
});
// Export 'redLow' data to Google Drive
Export.table.toDrive({
  collection: redLow,
  description: 'exportRedLow',
  fileFormat: 'CSV'
});
// Export 'strange' data to Google Drive
Export.table.toDrive({
  collection: strange,
  description: 'exportStrange',
  fileFormat: 'CSV'
});
// Export 'fire' data to Google Drive
Export.table.toDrive({
  collection: fire,
  description: 'exportFire',
  fileFormat: 'CSV'
});
*/
// Load a pre-computed Landsat composite for input.
var built=ee.Image("DLR/WSF/WSF2015/v1").divide(255)
//Map.addLayer(built)
var input = mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN'])//.mask(R).mask(G).mask(B)//.mask(mosaicRGB5a.select('G').gt(0.00005)).mask(mosaicRGB5a.select('R').gt(0.0003))//.multiply(built)
var full=mosaicRGB5a.select(['BG','GR','R','G','B','Built','LandUse','VIIRS','PAN'])//.mask(R).mask(G).mask(B)//.mask(mosaicRGB5a.select('G').gt(0.00005)).mask(mosaicRGB5a.select('R').gt(0.0003))//.multiply(built)
/*
// Define a region in which to generate a sample of the input.
//var region = geometry10;
// Combine geometries using union
var region = geometry3.union(geometry4,ee.ErrorMargin(1)).union(geometry5,ee.ErrorMargin(1)).union(geometry6,ee.ErrorMargin(1)).union(geometry7,ee.ErrorMargin(1)).union(geometry8,ee.ErrorMargin(1)).union(geometry9,ee.ErrorMargin(1)).union(geometry10,ee.ErrorMargin(1)).union(geometry11,ee.ErrorMargin(1)).union(geometry12,ee.ErrorMargin(1));
// Display the sample region.
//Map.setCenter(-3, 40.3, 8);
//Map.addLayer(ee.Image().paint(region, 0, 2), {}, 'region');
// Make the training dataset.
var training = full.sample({
  region: trainingPoints,
  scale: 30,
  numPixels: 5000
});
var trainingPoints = mergedFeatureCollection
print('Training',trainingPoints)
// Make the training dataset.
var training = full.sample({
  region: trainingPoints,
  scale: 30,
  numPixels: 5000
});
// This will filter out features where lampTypeIndex is not between 1 and 9
var filtered = trainingPoints.filter(ee.Filter.or(
  ee.Filter.gt('lampTypeIndex', 0),
  ee.Filter.lt('lampTypeIndex', 10)
));
// Print the result to check
print('Filtered training data', filtered);
// Filter to find features where 'lampTypeIndex' is missing
var filteredMissing = trainingPoints.filter(ee.Filter.eq('lampTypeIndex', null));
// Alternatively, to find features with 'lampTypeIndex' not between 1 and 9, including missing ones
var filteredRangeOrMissing = trainingPoints.filter(
  ee.Filter.or(
    ee.Filter.lt('lampTypeIndex', 1),
    ee.Filter.gt('lampTypeIndex', 9),
    ee.Filter.eq('lampTypeIndex', null)
  )
);
// Print the result to check
print('Features with missing or out-of-range lampTypeIndex', filteredRangeOrMissing);
print('Features with missing', filteredMissing);
var sample = trainingPoints.randomColumn();
var trainingSample = sample.filter('random <= 0.8');
var validationSample = sample.filter('random > 0.8'); 
// Instantiate the clusterer and train it.
print('Sample:',sample)
print(trainingSample)
print(validationSample)
  // Assuming 'highCCT', 'HPS', etc. are your point data with a property 'class' for classification
// Combine all points into one FeatureCollection
var points = mergedFeatureCollection//table2
//var bands = ['BG','GR'];
// Extract training data from the image using the points
var training = full.sampleRegions({
  collection: points,
  properties: ['lampTypeIndex'],//[['CategoryNumber'], // Replace 'class' with the name of the property that defines the class
  scale: 30 // Set an appropriate scale for your data
});
var label='lampTypeIndex'
// Define a classifier, e.g., a CART classifier
var classifierCart = ee.Classifier.smileCart().train({
  features: trainingSample,
  classProperty: 'lampTypeIndex',// 'CategoryNumber', // Replace 'class' with the name of the class property
  inputProperties: full.bandNames()
});
// Classify the image
var classifiedCart = full.classify(classifierCart);
// Get information about the trained classifier.
print('Results of trained classifier CART', classifierCart.explain());
// Get a confusion matrix and overall accuracy for the training sample.
var trainAccuracy = classifierCart.confusionMatrix();
print('Training error matrix CART', trainAccuracy);
print('Training overall accuracy CART', trainAccuracy.accuracy());
// Get a confusion matrix and overall accuracy for the validation sample.
validationSample = validationSample.classify(classifierCart);
var validationAccuracy = validationSample.errorMatrix(label, 'classification');
print('Validation error matrix CART', validationAccuracy);
print('Validation accuracy CART', validationAccuracy.accuracy());
// Add the classified image to the map (for visualization in the Earth Engine Code Editor)
// Define the modified color palette in hexadecimal format
*/
var palette = [
    '#0000FF', // highCCT: Cool, bluish light (blue)
    '#FF8C00', // HPS: Warm, yellow-orange light (orange)
    '#FFFF00', // Inter: Unique color for "Inter" (Yellow)
    '#FFFFFF', // White: White color (white)
    '#FF0000', // redLow: Red color (purple, used to differentiate from fire)
    '#808080', // strange: Changed to standard grey
    '#A52A2A',  // fire: Fiery, deep red color (brownish-red)
    '#000000', // Backgound
    '#1C1C1C'  // Difuse Light: Changed to nearly black dark grey
];
/*
// Update the Map.addLayer call with the modified palette
Map.addLayer(classifiedCart.mask(R), {
  min: 1, 
  max: 9, 
  palette: palette
}, 'Supervised CART',false);
// Define a classifier, e.g., an SVM classifier
var classifierSVM = ee.Classifier.libsvm({
  kernelType: 'RBF',
  gamma: 0.5,
  cost: 10
}).train({
  features: trainingSample,
  classProperty: 'lampTypeIndex', // Ensure this is the name of your class property
  inputProperties: full.bandNames()
});
// Classify the image
var classifiedSVM = full.classify(classifierSVM);
// Get information about the trained classifier.
print('Results of trained classifier SVM', classifierSVM.explain());
// Get a confusion matrix and overall accuracy for the training sample.
var trainAccuracy = classifierSVM.confusionMatrix();
print('Training error matrix SVM', trainAccuracy);
print('Training overall accuracy SVM', trainAccuracy.accuracy());
// Get a confusion matrix and overall accuracy for the validation sample.
validationSample = validationSample.classify(classifierSVM);
var validationAccuracy = validationSample.errorMatrix(label, 'classification');
print('Validation error matrix SVM', validationAccuracy);
print('Validation accuracy SVM', validationAccuracy.accuracy());
// Add the classified image to the map (for visualization in the Earth Engine Code Editor)
// The palette remains the same as defined above for visualization
Map.addLayer(classifiedSVM.mask(R), {
  min: 1, 
  max: 9, 
  palette: palette
}, 'Supervised SVM', false);
// Define a classifier, e.g., a RandomForest classifier
var classifierRF = ee.Classifier.smileRandomForest(10) // Using 10 trees
  .train({
    features: trainingSample,
    classProperty: 'lampTypeIndex', // Ensure this is the name of your class property
    inputProperties: full.bandNames()
  });
*/
var classifierAssetId = "projects/ee-pmisson/assets/upscaled_SDGSAT_1_Spain_random_forest";
var classifierRF = ee.Classifier.load(classifierAssetId);
// Classify the image
var classifiedRF = full.classify(classifierRF);
// Get information about the trained classifier.
//print('Results of trained classifier RF', classifierRF.explain());
// Get a confusion matrix and overall accuracy for the training sample.
//var trainAccuracy = classifierCart.confusionMatrix();
//print('Training error matrix RF', trainAccuracy);
//print('Training overall accuracy RF', trainAccuracy.accuracy());
// Get a confusion matrix and overall accuracy for the validation sample.
//validationSample = validationSample.classify(classifierRF);
//var validationAccuracy = validationSample.errorMatrix(label, 'classification');
//print('Validation error matrix RF', validationAccuracy);
//print('Validation accuracy RF', validationAccuracy.accuracy());
// Add the classified image to the map (for visualization in the Earth Engine Code Editor)
// The palette remains the same as defined above for visualization
Map.addLayer(classifiedRF, {
  min: 1, 
  max: 9, 
  palette: palette
}, 'Supervised RandomForest', false);
/*
Export.classifier.toAsset(
  classifierRF,
  "Saved-random-forest-IGBP-classification",
  "upscaled_SDGSAT_1_Spain_random_forest"
);
// Define a classifier, e.g., a NaiveBayes classifier
var classifierNB = ee.Classifier.smileNaiveBayes()
  .train({
    features: trainingSample,
    classProperty: 'lampTypeIndex', // Ensure this is the name of your class property
    inputProperties: full.bandNames()
  });
  // Get information about the trained classifier.
print('Results of trained classifier NB', classifierNB.explain());
// Get a confusion matrix and overall accuracy for the training sample.
var trainAccuracy = classifierNB.confusionMatrix();
print('Training error matrix NB', trainAccuracy);
print('Training overall accuracy NB', trainAccuracy.accuracy());
// Get a confusion matrix and overall accuracy for the validation sample.
validationSample = validationSample.classify(classifierCart);
var validationAccuracy = validationSample.errorMatrix(label, 'classification');
print('Validation error matrix NB', validationAccuracy);
print('Validation accuracy NB', validationAccuracy.accuracy());
// Classify the image
var classifiedNB = full.classify(classifierNB);
// Add the classified image to the map (for visualization in the Earth Engine Code Editor)
// The palette remains the same as defined above for visualization
Map.addLayer(classifiedNB.mask(R), {
  min: 1, 
  max: 9, 
  palette: palette
}, 'Supervised NaiveBayes', false);
*/
// Define the names array corresponding to the palette
var names = [
    'HighCCT',  // highCCT
    'HPS',      // HPS
    'Inter',    // Inter
    'White',    // White
    'RedLow',   // redLow
    'Strange',  // strange
    'Blackbody',      // fire
    'Backgound',
    'Difuse light'
];
/*
var coordinates = [[0, 0.5, // Inicio del polígono en BG = 0, GR = 0.5
  0, 1.0, // BG = 0, GR = 1.5
  0.1, 1.0, // BG = 0.1, GR = 1.5
  0.1, 0.5, // BG = 0.1, GR = 0.5
  0, 0.5  // Cerrando el polígono al punto de inicio
  ]];
// Crear el clasificador spectralRegion con las coordenadas definidas
var classifier = ee.Classifier.spectralRegion(coordinates);
print(classifier);
// Preparar la imagen para la clasificación, seleccionando solo las bandas de interés
var inputForClassification = input.select(['BG', 'GR']).rename('u','v');
print(inputForClassification);
// Aplicar el clasificador a la imagen
var classified = inputForClassification.classify(classifier);
print(classified);
// Visualizar el resultado de la clasificación
Map.addLayer(classified, {min: 0, max: 1, palette: ['black', 'white']}, 'is Sodium Result');
*/
// Create the legend as a panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px',
    shown: false  // initially hide the legend
  }
});
// Function to create each row in the legend
var makeRow = function(color, name) {
  var colorBox = ui.Label({
    style: {
      backgroundColor: color,
      padding: '8px',
      margin: '0 0 4px 0'
    }
  });
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'}
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
// Adding the color boxes and labels to the legend
names.forEach(function(name, i) {
  legend.add(makeRow(palette[i], name));
});
// Add a checkbox to control the visibility of the legend
var checkbox = ui.Checkbox('Class legend', false, function(checked) {
  legend.style().set('shown', checked);
});
// Add the checkbox and the legend to the map
Map.add(checkbox);
Map.add(legend);
/*
// Export highCCT data to 'SDGSAT_classification' folder
Export.table.toDrive({
  collection: highCCT,
  description: 'highCCT_data',
  folder: 'SDGSAT_classification',
  fileFormat: 'CSV'
});
// Export HPS data to 'SDGSAT_classification' folder
Export.table.toDrive({
  collection: HPS,
  description: 'HPS_data',
  folder: 'SDGSAT_classification',
  fileFormat: 'CSV'
});
// Export Inter data to 'SDGSAT_classification' folder
Export.table.toDrive({
  collection: Inter,
  description: 'Inter_data',
  folder: 'SDGSAT_classification',
  fileFormat: 'CSV'
});
// Export White data to 'SDGSAT_classification' folder
Export.table.toDrive({
  collection: White,
  description: 'White_data',
  folder: 'SDGSAT_classification',
  fileFormat: 'CSV'
});
// Export redLow data to 'SDGSAT_classification' folder
Export.table.toDrive({
  collection: redLow,
  description: 'redLow_data',
  folder: 'SDGSAT_classification',
  fileFormat: 'CSV'
});
// Export strange data to 'SDGSAT_classification' folder
Export.table.toDrive({
  collection: strange,
  description: 'strange_data',
  folder: 'SDGSAT_classification',
  fileFormat: 'CSV'
});
// Export fire data to 'SDGSAT_classification' folder
Export.table.toDrive({
  collection: fire,
  description: 'fire_data',
  folder: 'SDGSAT_classification',
  fileFormat: 'CSV'
});
// Export background data to 'SDGSAT_classification' folder
Export.table.toDrive({
  collection: background,
  description: 'background_data',
  folder: 'SDGSAT_classification',
  fileFormat: 'CSV'
});
// Export difuse data to 'SDGSAT_classification' folder
Export.table.toDrive({
  collection: difuse,
  description: 'difuse_data',
  folder: 'SDGSAT_classification',
  fileFormat: 'CSV'
});
/*
var maskC=classifiedRF.gt(0).lt(7)
    var histogram = ui.Chart.image.histogram({
      image: classifiedRF.mask(maskC),
      region: region, // Define your region or omit for the whole image
      scale: 500, // Adjust based on your image's resolution
      minBucketWidth: 1
    });
    // Print the chart to the Console
    print(histogram);
  */  
//Map.addLayer(czechRepublicBorder.style(visParams), {}, 'Czech Republic Border');
// Get the map URL
// Cargar el FeatureCollection de las fronteras nacionales
var countries = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017');
// Lista de países de la UE más el Reino Unido
var euCountries = [
  'Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czech Republic',
  'Denmark', 'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary',
  'Ireland', 'Italy', 'Latvia', 'Lithuania', 'Luxembourg', 'Malta',
  'Netherlands', 'Poland', 'Portugal', 'Romania', 'Slovakia', 'Slovenia',
  'Spain', 'Sweden', 'United Kingdom'
];
// Filtrar el FeatureCollection por los países de la lista
var euPlusUK = countries.filter(ee.Filter.inList('country_na', euCountries));
// Función para calcular las estadísticas nacionales
var calculateNationalStatistics = function(image, country) {
  // Reducir la región utilizando una reducción zonal para contar los píxeles de cada clase
  var stats = image.reduceRegion({
    reducer: ee.Reducer.frequencyHistogram(),
    geometry: country.geometry(),
    scale: 30,
    maxPixels: 1e9,
    bestEffort: true
  });
  return ee.Feature(country.geometry(), stats).set('country', country.get('country_na'));
};
// Aplicar la función a cada país y crear un FeatureCollection con las estadísticas
var statistics = euPlusUK.map(function(country) {
  return calculateNationalStatistics(classifiedRF, country);
});
// Imprimir las estadísticas en la consola
print('Estadísticas nacionales para los países de la UE más el Reino Unido:', statistics);
// Exportar las estadísticas a Google Drive
Export.table.toDrive({
  collection: statistics,
  description: 'EU_plus_UK_National_Statistics',
  fileFormat: 'CSV'
});
// Step 2: Define a region (optional)
var region = ee.Geometry.Rectangle([-122.5, 37.0, -122.0, 37.5]);
// Step 3: Clip the image to the region (optional)
var clippedImage = mosaicRGB5a.unmask(0).clip(geometry13);
//var UKEiregeo=UKEIRE2.geometry()
//var EUgeo=geoimage.union(UKEiregeo)
// Step 4: Export the image to your Earth Engine assets
Export.image.toAsset({
  image: clippedImage,              // The image to export
  description: 'SDGSAT_EU_UK_Cal2',    // Name of the export task
  assetId: 'projects/ee-pmisson/assets/SDGSAT_EU_UK_Cal2',  // The asset path where the image will be stored
  scale: 40,                        // Resolution in meters
  region: geometry13,                   // Export region
  maxPixels: 1e13                   // Maximum number of pixels allowed in the export
});