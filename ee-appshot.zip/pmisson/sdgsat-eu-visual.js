var image = ui.import && ui.import("image", "image", {
      "id": "projects/ee-pmisson/assets/SDGSAT_EU_UK"
    }) || ee.Image("projects/ee-pmisson/assets/SDGSAT_EU_UK"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "R",
          "G",
          "B"
        ],
        "min": 0.00013,
        "max": 0.01,
        "gamma": 3
      }
    }) || {"opacity":1,"bands":["R","G","B"],"min":0.00013,"max":0.01,"gamma":3};
alert('Para funciones adicionales elige idioma antes de empezar (SOLO EN PC)/ For aditional feactures choose language before start (ONLY PC)')
Map.setCenter(10.0, 50.0, 4);  // Longitud: 10.0, Latitud: 50.0, Zoom: 4
// Definir el estilo del mapa
var mapStyle = [
  {
    "featureType": "administrative",
    "elementType": "labels.text.fill",
    "stylers": [{"color": "#ffffff"}]
  },
  {
    "featureType": "administrative",
    "elementType": "labels.text.stroke",
    "stylers": [{"color": "#2d2d2d"}]
  },
  {
    "featureType": "landscape",
    "elementType": "geometry",
    "stylers": [{"color": "#2d2d2d"}]
  },
  {
    "featureType": "road",
    "elementType": "labels.text.fill",
    "stylers": [{"color": "#ffffff"}]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [{"color": "#a68d29"}]
  }
];
// Aplicar el estilo al mapa base
Map.setOptions('Dark', {Dark: mapStyle});
// Añadir una imagen de prueba para verificar la visualización
var testImage = ee.ImageCollection("NOAA/VIIRS/DNB/ANNUAL_V22").first().select('average');
var viirsLayer = Map.addLayer(testImage, {min: 0, max: 150, gamma: 2}, "VIIRS Average DNB Radiance");
// Cargar la imagen principal y añadirla al mapa
var image = ee.Image("projects/ee-pmisson/assets/SDGSAT_EU_UK");
var imageVisParam = {
  "opacity": 1,
  "bands": ["R", "G", "B"],
  "min": [0.0003, 0.0003, 0.0003],
  "max": [0.01, 0.01, 0.01],
  "gamma": [1.5, 2.5, 3]
};
Map.addLayer(image, imageVisParam, "SDGSAT EU UK", true);
// Añadir el logo
var logo = ee.Image('projects/ee-pmisson/assets/outputCBAS').visualize({
  bands:  ['b1', 'b2', 'b3'],
  min: 0,
  max: 255
});
var thumb = ui.Thumbnail({
  image: logo,
  params: {
    dimensions: '642x291',
    format: 'png'
  },
  style: {height: '200px', width: '280px', padding: '0'}
});
// Panel de información sobre colaboración y financiamiento
var infoPanel = ui.Panel({
  style: {
    width: '300px',
    padding: '10px',
    position: 'bottom-right'
  }
});
infoPanel.add(thumb);
// Panel de control para manejar los parámetros de visualización
var controlPanel = ui.Panel({
  style: {
    width: '300px',
    padding: '10px',
    position: 'bottom-left'
  }
});
// Crear un panel para los checkboxes
var checkboxPanel = ui.Panel({
  style: {
    width: '200px',
    padding: '10px',
    position: 'top-center'
  }
});
// Checkboxes para mostrar/ocultar los paneles
var controlCheckbox = ui.Checkbox({
  label: 'Visualización',
  value: true,
  onChange: function(show) {
    if (show) {
      Map.add(controlPanel);
    } else {
      Map.remove(controlPanel);
    }
  }
});
var infoCheckbox = ui.Checkbox({
  label: 'Colaboración',
  value: true,
  onChange: function(show) {
    if (show) {
      Map.add(infoPanel);
    } else {
      Map.remove(infoPanel);
    }
  }
});
// Añadir los checkboxes al panel
checkboxPanel.add(controlCheckbox);
checkboxPanel.add(infoCheckbox);
// Crear un selector de idioma
var languageSelect = ui.Select({
  items: ['Español', 'English'],
  value: 'English',
  onChange: function(selected) {
    updateLabels(selected);
  },
  style: {
    position: 'top-left',
    width: '150px',
    padding: '8px'
  }
});
// Añadir elementos iniciales al mapa
Map.add(languageSelect);
Map.add(checkboxPanel);
Map.add(controlPanel);
Map.add(infoPanel);
// Función para actualizar las etiquetas según el idioma seleccionado
function updateLabels(language) {
  var labels = {
    'Español': {
      'collaboration': 'Colaboración entre:',
      'source': 'Fuente de los datos:',
      'ralan': 'RALAN:',
      'financing': 'Este proyecto ha recibido financiación del Programa Horizonte 2020 de la Unión Europea bajo el acuerdo de subvención Marie Sklodowska-Curie Nº 847635. Financiado por la Unión Europea bajo el Programa Horizonte Europa, Acuerdo de Subvención Nº 101135308 (PLAN-B). Investigación e Innovación | HORIZON-CL6-2023-BIODIV-01.',
      'sourceAcknowledgement': 'Se reconoce que los datos de SDGSAT-1 son proporcionados amablemente por CBAS.',
      'institutions': 'Universidad Complutense de Madrid / University of Exeter',
      'cbas': 'International Research Center of Big Data for Sustainable Development Goals (CBAS)',
      'viirsAcknowledgement': 'Imagen de fondo de comparación de VIIRS. Proveedor del Dataset: Earth Observation Group, Payne Institute for Public Policy, Colorado School of Mines',
      'visualControl': 'Control de visualización',
      'gammaR': 'Ajuste de Gamma (Rojo)',
      'gammaG': 'Ajuste de Gamma (Verde)',
      'gammaB': 'Ajuste de Gamma (Azul)',
      'opacity': 'Ajuste de Opacidad',
      'viirsToggle': 'Mostrar/Ocultar VIIRS',
      'checkboxTitle': 'Mostrar/Ocultar Paneles',
      'visualization': 'Visualización',
      'collaborationLabel': 'Colaboración'
    },
    'English': {
      'collaboration': 'Collaboration between:',
      'source': 'Data source:',
      'ralan': 'RALAN:',
      'financing': 'This project has received funding from the European Union\'s Horizon 2020 Research and Innovation Programme under the Marie Sklodowska-Curie grant agreement No. 847635. Funded by the European Union under the Horizon Europe Programme, Grant Agreement No. 101135308 (PLAN-B). Research and Innovation | HORIZON-CL6-2023-BIODIV-01.',
      'sourceAcknowledgement': 'Acknowledgment: SDGSAT-1 data kindly provided by CBAS.',
      'institutions': 'Complutense University of Madrid / University of Exeter',
      'cbas': 'International Research Center of Big Data for Sustainable Development Goals (CBAS)',
      'viirsAcknowledgement': 'Background image comparison from VIIRS. Dataset Provider: Earth Observation Group, Payne Institute for Public Policy, Colorado School of Mines',
      'visualControl': 'Visualization Control',
      'gammaR': 'Gamma Adjustment (Red)',
      'gammaG': 'Gamma Adjustment (Green)',
      'gammaB': 'Gamma Adjustment (Blue)',
      'opacity': 'Opacity Adjustment',
      'viirsToggle': 'Show/Hide VIIRS',
      'checkboxTitle': 'Show/Hide Panels',
      'visualization': 'Visualization',
      'collaborationLabel': 'Collaboration'
    }
  };
  var selectedLabels = labels[language];
  infoPanel.clear();
  // Añadir el logo al panel de información
  infoPanel.add(thumb);
  // Actualizar las etiquetas del panel de información
  infoPanel.add(ui.Label({
    value: selectedLabels['collaboration'],
    style: { fontWeight: 'bold', fontSize: '16px', margin: '0 0 5px 0' }
  }));
  infoPanel.add(ui.Label(selectedLabels['institutions']));
  infoPanel.add(ui.Label('y'));
  infoPanel.add(ui.Label(selectedLabels['cbas']));
  infoPanel.add(ui.Label({
    value: selectedLabels['source'],
    style: { fontWeight: 'bold', margin: '10px 0 5px 0' }
  }));
  infoPanel.add(ui.Label(selectedLabels['sourceAcknowledgement']));
  infoPanel.add(ui.Label(selectedLabels['viirsAcknowledgement']));
  infoPanel.add(ui.Label({
    value: selectedLabels['ralan'],
    style: { fontWeight: 'bold', margin: '10px 0 5px 0' }
  }));
  infoPanel.add(ui.Label(selectedLabels['financing']));
  // Actualizar las etiquetas del panel de control
  controlPanel.clear();
  controlPanel.add(ui.Label({
    value: selectedLabels['visualControl'],
    style: { fontSize: '18px', fontWeight: 'bold', margin: '0 0 10px 0' }
  }));
  controlPanel.add(ui.Label(selectedLabels['gammaR']));
  controlPanel.add(gammaRSlider);
  controlPanel.add(ui.Label(selectedLabels['gammaG']));
  controlPanel.add(gammaGSlider);
  controlPanel.add(ui.Label(selectedLabels['gammaB']));
  controlPanel.add(gammaBSlider);
  controlPanel.add(ui.Label(selectedLabels['opacity']));
  controlPanel.add(opacitySlider);
// Añadir la capa VIIRS y guardar el índice de la capa
//var viirsLayer = Map.addLayer(testImage, {min: 0, max: 150, gamma: 2}, "VIIRS Average DNB Radiance");
var viirsLayerIndex = Map.layers().length() - 2;  // Índice de la capa añadida
// Crear el checkbox con una función de cambio de visibilidad usando el índice
var viirsToggle = ui.Checkbox({
  label: selectedLabels['viirsToggle'],
  value: true,
  onChange: function(show) {
    Map.layers().get(viirsLayerIndex).setShown(show);
  }
});
controlPanel.add(viirsToggle);
  // Actualizar las etiquetas del panel de checkboxes
  checkboxPanel.clear();
  checkboxPanel.add(ui.Label({
    value: selectedLabels['checkboxTitle'],
    style: { fontWeight: 'bold', fontSize: '16px', margin: '0 0 10px 0' }
  }));
  controlCheckbox.setLabel(selectedLabels['visualization']);
  infoCheckbox.setLabel(selectedLabels['collaborationLabel']);
  checkboxPanel.add(controlCheckbox);
  checkboxPanel.add(infoCheckbox);
}
// Ajustes de gamma para cada banda RGB
var gammaRSlider = ui.Slider({
  min: 0.1,
  max: 5,
  value: 1.5,
  step: 0.1,
  onChange: function(value) {
    var gammaValues = [gammaRSlider.getValue(), gammaGSlider.getValue(), gammaBSlider.getValue()];
    Map.layers().get(1).setVisParams({
      "opacity": 1,
      "bands": ["R", "G", "B"],
      "min": [0.0003, 0.0003, 0.0003],
      "max": [0.01, 0.01, 0.01],
      "gamma": gammaValues
    });
  }
});
var gammaGSlider = ui.Slider({
  min: 0.1,
  max: 5,
  value: 2.5,
  step: 0.1,
  onChange: function(value) {
    var gammaValues = [gammaRSlider.getValue(), gammaGSlider.getValue(), gammaBSlider.getValue()];
    Map.layers().get(1).setVisParams({
      "opacity": 1,
      "bands": ["R", "G", "B"],
      "min": [0.0001, 0.0001, 0.0001],
      "max": [0.1, 0.1, 0.1],
      "gamma": gammaValues
    });
  }
});
var gammaBSlider = ui.Slider({
  min: 0.1,
  max: 5,
  value: 3,
  step: 0.1,
  onChange: function(value) {
    var gammaValues = [gammaRSlider.getValue(), gammaGSlider.getValue(), gammaBSlider.getValue()];
    Map.layers().get(1).setVisParams({
      "opacity": 1,
      "bands": ["R", "G", "B"],
      "min": [0.0001, 0.0001, 0.0001],
      "max": [0.1, 0.1, 0.1],
      "gamma": gammaValues
    });
  }
});
// Ajustes de opacidad
var opacitySlider = ui.Slider({
  min: 0,
  max: 1,
  value: 1,
  step: 0.1,
  onChange: function(value) {
    Map.layers().get(1).setOpacity(value);
  }
});
// Añadir el panel de opacidad para dispositivos móviles
if (isMobile()) {
  // Ajustes de opacidad
  Map.remove(viirsLayer);
  var opacitySlider = ui.Slider({
  min: 0,
  max: 1,
  value: 1,
  step: 0.1,
  onChange: function(value) {
    Map.layers().get(0).setOpacity(value);
  }
  });
  //
  var mobileOpacityPanel = ui.Panel({
    style: {
      width: '200px',
      padding: '10px',
      position: 'top-right'
    }
  });
  ////
  mobileOpacityPanel.add(ui.Label({
    value: 'Opacity Adjustment',
    style: { fontWeight: 'bold', fontSize: '16px', margin: '0 0 10px 0' }
  }));
  mobileOpacityPanel.add(opacitySlider);
  Map.add(mobileOpacityPanel);
  Map.remove(checkboxPanel);
  Map.remove(controlPanel);
  Map.remove(infoPanel);
  Map.remove(languageSelect);
}
// Detectar si se visualiza en un móvil y desactivar los paneles si es el caso
function isMobile() {
  return /Mobi|Android/i.test(navigator.userAgent) || window.innerWidth < 768;
}