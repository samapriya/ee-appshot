var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                13.273551112517485,
                52.565723171257424
              ],
              [
                13.273551112517485,
                52.431121414478135
              ],
              [
                13.567435389861235,
                52.431121414478135
              ],
              [
                13.567435389861235,
                52.565723171257424
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[13.273551112517485, 52.565723171257424],
          [13.273551112517485, 52.431121414478135],
          [13.567435389861235, 52.431121414478135],
          [13.567435389861235, 52.565723171257424]]], null, false),
    image2 = ui.import && ui.import("image2", "image", {
      "id": "users/pmisson/SantanderMosaic_low_modificado"
    }) || ee.Image("users/pmisson/SantanderMosaic_low_modificado"),
    image3 = ui.import && ui.import("image3", "image", {
      "id": "users/pmisson/iss067e359111_modificado"
    }) || ee.Image("users/pmisson/iss067e359111_modificado"),
    image4 = ui.import && ui.import("image4", "image", {
      "id": "users/pmisson/iss047e022994_modificado"
    }) || ee.Image("users/pmisson/iss047e022994_modificado");
Map.setOptions('SATELLITE');
Map.addLayer(image4,{},'Santander 2022');
Map.addLayer(image3,{},'Santander 2017');
Map.addLayer(image2,{},'Santander 2013');
Map.setCenter(-3.8006, 43.4655,11);