var imageX = ui.import && ui.import("imageX", "image", {
      "id": "users/pmisson/JL1GF03C01_MSS_20210924055731_200062031_105_0204_001_L1A_MSS_ORTHO_MS"
    }) || ee.Image("users/pmisson/JL1GF03C01_MSS_20210924055731_200062031_105_0204_001_L1A_MSS_ORTHO_MS"),
    imageXX = ui.import && ui.import("imageXX", "image", {
      "id": "users/pmisson/E_4PAQVUUAg_Ltz-denoise-low-light-sharpen-motion_modificado"
    }) || ee.Image("users/pmisson/E_4PAQVUUAg_Ltz-denoise-low-light-sharpen-motion_modificado"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "b1",
          "b2",
          "b3"
        ],
        "max": 4096,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["b1","b2","b3"],"max":4096,"gamma":1},
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -17.881887166505813,
                28.641022843914865
              ],
              [
                -17.881887166505813,
                28.608325205342837
              ],
              [
                -17.826612203126906,
                28.608325205342837
              ],
              [
                -17.826612203126906,
                28.641022843914865
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* locked: true */
    ee.Geometry.Polygon(
        [[[-17.881887166505813, 28.641022843914865],
          [-17.881887166505813, 28.608325205342837],
          [-17.826612203126906, 28.608325205342837],
          [-17.826612203126906, 28.641022843914865]]], null, false),
    image3 = ui.import && ui.import("image3", "image", {
      "id": "users/pmisson/LaPalma_volcan"
    }) || ee.Image("users/pmisson/LaPalma_volcan"),
    geometry2 = ui.import && ui.import("geometry2", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -17.8984146509803,
                28.630092985174176
              ],
              [
                -17.8984146509803,
                28.595281848127218
              ],
              [
                -17.84622959238655,
                28.595281848127218
              ],
              [
                -17.84622959238655,
                28.630092985174176
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* locked: true */
    ee.Geometry.Polygon(
        [[[-17.8984146509803, 28.630092985174176],
          [-17.8984146509803, 28.595281848127218],
          [-17.84622959238655, 28.595281848127218],
          [-17.84622959238655, 28.630092985174176]]], null, false),
    image4 = ui.import && ui.import("image4", "image", {
      "id": "users/pmisson/LaPalma_Cosmo_2"
    }) || ee.Image("users/pmisson/LaPalma_Cosmo_2"),
    image5 = ui.import && ui.import("image5", "image", {
      "id": "users/pmisson/ISS043-E-69142-denoise-low-light-sharpen-motion_modificado"
    }) || ee.Image("users/pmisson/ISS043-E-69142-denoise-low-light-sharpen-motion_modificado"),
    image6 = ui.import && ui.import("image6", "image", {
      "id": "users/pmisson/ISS065-E-415980-denoise-severe-noise_modificado"
    }) || ee.Image("users/pmisson/ISS065-E-415980-denoise-severe-noise_modificado"),
    image7 = ui.import && ui.import("image7", "image", {
      "id": "users/pmisson/iss065e439563-denoise-raw_modificado"
    }) || ee.Image("users/pmisson/iss065e439563-denoise-raw_modificado"),
    image8 = ui.import && ui.import("image8", "image", {
      "id": "users/pmisson/iss065e439574-denoise-raw_modificado"
    }) || ee.Image("users/pmisson/iss065e439574-denoise-raw_modificado"),
    geometry3 = ui.import && ui.import("geometry3", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -17.878759301757803,
                28.508564370595717
              ],
              [
                -17.878759301757803,
                28.497401123465636
              ],
              [
                -17.871206201171866,
                28.48080492512833
              ],
              [
                -17.839963830566397,
                28.486840208196085
              ],
              [
                -17.817991174316397,
                28.500418333750442
              ],
              [
                -17.75654556423814,
                28.57113703292362
              ],
              [
                -17.778852380371085,
                28.599033542711247
              ],
              [
                -17.848203576660147,
                28.500116616603915
              ],
              [
                -17.86090651855468,
                28.514296389841807
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-17.878759301757803, 28.508564370595717],
          [-17.878759301757803, 28.497401123465636],
          [-17.871206201171866, 28.48080492512833],
          [-17.839963830566397, 28.486840208196085],
          [-17.817991174316397, 28.500418333750442],
          [-17.75654556423814, 28.57113703292362],
          [-17.778852380371085, 28.599033542711247],
          [-17.848203576660147, 28.500116616603915],
          [-17.86090651855468, 28.514296389841807]]]),
    geometry4 = ui.import && ui.import("geometry4", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -17.91353043751422,
                28.578182717133952
              ],
              [
                -17.874734966322812,
                28.580594642209725
              ],
              [
                -17.86958512501422,
                28.623999832407865
              ],
              [
                -17.86683854298297,
                28.642682654775598
              ],
              [
                -17.854135601088437,
                28.646900896231994
              ],
              [
                -17.84486588673297,
                28.66286841629091
              ],
              [
                -17.858255474135312,
                28.66648336620513
              ],
              [
                -17.873704998061093,
                28.656240684298137
              ],
              [
                -17.89155778126422,
                28.659554602673907
              ],
              [
                -17.901170818373593,
                28.66889326354246
              ],
              [
                -17.91731154555888,
                28.67599194472372
              ],
              [
                -17.94992834011586,
                28.654167788780576
              ],
              [
                -17.94855299606867,
                28.634617720351425
              ],
              [
                -17.93619240904717,
                28.64131710010609
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-17.91353043751422, 28.578182717133952],
          [-17.874734966322812, 28.580594642209725],
          [-17.86958512501422, 28.623999832407865],
          [-17.86683854298297, 28.642682654775598],
          [-17.854135601088437, 28.646900896231994],
          [-17.84486588673297, 28.66286841629091],
          [-17.858255474135312, 28.66648336620513],
          [-17.873704998061093, 28.656240684298137],
          [-17.89155778126422, 28.659554602673907],
          [-17.901170818373593, 28.66889326354246],
          [-17.91731154555888, 28.67599194472372],
          [-17.94992834011586, 28.654167788780576],
          [-17.94855299606867, 28.634617720351425],
          [-17.93619240904717, 28.64131710010609]]]),
    geometry5 = ui.import && ui.import("geometry5", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -17.789437818827682,
                28.696904252348865
              ],
              [
                -17.787377882304245,
                28.690278673493243
              ],
              [
                -17.803170728983932,
                28.672508005632782
              ],
              [
                -17.796304273905807,
                28.66437466057461
              ],
              [
                -17.79321436912065,
                28.655336870197193
              ],
              [
                -17.799050855937057,
                28.649913821981063
              ],
              [
                -17.803170728983932,
                28.63936820320281
              ],
              [
                -17.793557691874557,
                28.63936820320281
              ],
              [
                -17.789437818827682,
                28.63605364691858
              ],
              [
                -17.782571363749557,
                28.61887654208525
              ],
              [
                -17.782914686503464,
                28.60953342796784
              ],
              [
                -17.78051142722612,
                28.601395199814604
              ],
              [
                -17.77124171287065,
                28.599586619065423
              ],
              [
                -17.75579218894487,
                28.610739037782878
              ],
              [
                -17.749612379374557,
                28.621588903397367
              ],
              [
                -17.757852125468307,
                28.641778723822625
              ],
              [
                -17.756478834452682,
                28.648708662068188
              ],
              [
                -17.763345289530807,
                28.66136215036122
              ],
              [
                -17.761971998515182,
                28.66889326354246
              ],
              [
                -17.764718580546432,
                28.68064071935777
              ],
              [
                -17.758195448222214,
                28.686363361611658
              ],
              [
                -17.759225416483932,
                28.694494999467484
              ],
              [
                -17.753388929667526,
                28.699614595553136
              ],
              [
                -17.74643694812903,
                28.714368841808387
              ],
              [
                -17.743260451405853,
                28.726412976137603
              ],
              [
                -17.742832104053484,
                28.748990966665037
              ],
              [
                -17.766091871562057,
                28.71467077951875
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-17.789437818827682, 28.696904252348865],
          [-17.787377882304245, 28.690278673493243],
          [-17.803170728983932, 28.672508005632782],
          [-17.796304273905807, 28.66437466057461],
          [-17.79321436912065, 28.655336870197193],
          [-17.799050855937057, 28.649913821981063],
          [-17.803170728983932, 28.63936820320281],
          [-17.793557691874557, 28.63936820320281],
          [-17.789437818827682, 28.63605364691858],
          [-17.782571363749557, 28.61887654208525],
          [-17.782914686503464, 28.60953342796784],
          [-17.78051142722612, 28.601395199814604],
          [-17.77124171287065, 28.599586619065423],
          [-17.75579218894487, 28.610739037782878],
          [-17.749612379374557, 28.621588903397367],
          [-17.757852125468307, 28.641778723822625],
          [-17.756478834452682, 28.648708662068188],
          [-17.763345289530807, 28.66136215036122],
          [-17.761971998515182, 28.66889326354246],
          [-17.764718580546432, 28.68064071935777],
          [-17.758195448222214, 28.686363361611658],
          [-17.759225416483932, 28.694494999467484],
          [-17.753388929667526, 28.699614595553136],
          [-17.74643694812903, 28.714368841808387],
          [-17.743260451405853, 28.726412976137603],
          [-17.742832104053484, 28.748990966665037],
          [-17.766091871562057, 28.71467077951875]]]),
    geometry6 = ui.import && ui.import("geometry6", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -17.998852834898084,
                28.774862687040855
              ],
              [
                -17.955594167905897,
                28.702614847950688
              ],
              [
                -17.944951162534803,
                28.65924217934517
              ],
              [
                -17.93156157513246,
                28.667375922716673
              ],
              [
                -17.937398061948866,
                28.701711433915488
              ],
              [
                -17.973446951109022,
                28.764028696526402
              ],
              [
                -17.960229949812184,
                28.779526447669078
              ],
              [
                -17.95799742718324,
                28.789005370462995
              ],
              [
                -17.907016668638516,
                28.80758152928093
              ],
              [
                -17.92442010132081,
                28.81825468137428
              ],
              [
                -17.931519541996547,
                28.83192866206722
              ],
              [
                -17.923746143900537,
                28.83822896499775
              ],
              [
                -17.937054832817747,
                28.841198043711934
              ],
              [
                -18.001256094175428,
                28.788102703289102
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ffc82d",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-17.998852834898084, 28.774862687040855],
          [-17.955594167905897, 28.702614847950688],
          [-17.944951162534803, 28.65924217934517],
          [-17.93156157513246, 28.667375922716673],
          [-17.937398061948866, 28.701711433915488],
          [-17.973446951109022, 28.764028696526402],
          [-17.960229949812184, 28.779526447669078],
          [-17.95799742718324, 28.789005370462995],
          [-17.907016668638516, 28.80758152928093],
          [-17.92442010132081, 28.81825468137428],
          [-17.931519541996547, 28.83192866206722],
          [-17.923746143900537, 28.83822896499775],
          [-17.937054832817747, 28.841198043711934],
          [-18.001256094175428, 28.788102703289102]]]),
    geometry7 = ui.import && ui.import("geometry7", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -17.884693399810246,
                28.83853754312966
              ],
              [
                -17.884006754302433,
                28.795221295974706
              ],
              [
                -17.765903726958683,
                28.788000170296385
              ],
              [
                -17.754917398833683,
                28.812068643879275
              ],
              [
                -17.799549356841496,
                28.839139030806056
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#00ffff",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-17.884693399810246, 28.83853754312966],
          [-17.884006754302433, 28.795221295974706],
          [-17.765903726958683, 28.788000170296385],
          [-17.754917398833683, 28.812068643879275],
          [-17.799549356841496, 28.839139030806056]]]);
/*
// Load the two images to be registered.
var image1 = image2;
var image2 = image;
// Use bicubic resampling during registration.
var image1Orig = image1.resample('bicubic');
var image2Orig = image2.resample('bicubic');
// Choose to register using only the 'R' band.
var image1RedBand = image1Orig.select('b1');
var image2RedBand = image2Orig.select('b1');
var displacement = image2RedBand.displacement({
  referenceImage: image1RedBand,
  maxOffset: 1000.0,
  patchWidth: 1000.0
});
var offset = displacement.select('dx').hypot(displacement.select('dy'));
var angle = displacement.select('dx').atan2(displacement.select('dy'));
// Display offset distance and angle.
Map.addLayer(offset, {min:0, max: 20}, 'offset');
Map.addLayer(angle, {min: -Math.PI, max: Math.PI}, 'angle');
Map.setCenter(-17.86888, 28.61529, 15);
// Use the computed displacement to register all original bands.
var registered = image2Orig.displace(displacement);
// Show the results of co-registering the images.
var visParams = {bands: ['b1', 'b2', 'b3'], max: 4000};
Map.addLayer(image1Orig, visParams, 'Reference');
Map.addLayer(image2Orig, visParams, 'Before Registration');
Map.addLayer(registered, visParams, 'After Registration');
*/
var geometry = 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-18.03935543849177, 28.86907995650056],
          [-18.03935543849177, 28.43523582021439],
          [-17.66307370021052, 28.43523582021439],
          [-17.66307370021052, 28.86907995650056]]], null, false),
    imageVisParam2 = {"opacity":1,"bands":["DNB_BRDF_Corrected_NTL"],"min":0,"max":25,"gamma":3},
    imageVisParam3 = {"opacity":1,"bands":["DNB_BRDF_Corrected_NTL"],"min":0,"max":2,"palette":["ff0000","fff600","00ff12"]},
    image = ee.Image("projects/ee-pmisson/assets/La_Palma/mean_dnb_2020"),
    image2 = ee.Image("projects/ee-pmisson/assets/La_Palma/mean_dnb_2023");
// Define the area of interest
var areaOfInterest = geometry
// Load the ImageCollection for the year 2022
// Function to apply the quality mask
// Function to apply the quality mask and intensity mask
function applyQualityAndIntensityMask(image) {
  var quality = image.select('Mandatory_Quality_Flag').eq(0); // Assuming 1 indicates good quality
  var intensity = image.select('DNB_BRDF_Corrected_NTL').gte(0); // Pixels with intensity >= 1
  var combinedMask = quality.and(intensity); // Combine quality and intensity masks
  return image.updateMask(combinedMask).select('DNB_BRDF_Corrected_NTL');
}
// Load the ImageCollection for the year 2020, apply the masks
var collection2020 = ee.ImageCollection("NOAA/VIIRS/001/VNP46A2")
    .filterDate('2020-01-01', '2020-12-31')
    .filterBounds(areaOfInterest)
    .map(applyQualityAndIntensityMask);
// Calculate the mean for the year 2022
var mean2020 = image//collection2020.median();
// Display the mean image for 2022
Map.addLayer(mean2020.clip(areaOfInterest).subtract(0.10000000000000005), imageVisParam2, 'Median DNB 2020');
//Map.addLayer(image, imageVisParam2, 'Median DNB 2022');
Map.centerObject(areaOfInterest);
// Load the ImageCollection for the year 2024, apply the masks
var collection2023 = ee.ImageCollection("NOAA/VIIRS/001/VNP46A2")
    .filterDate('2023-01-01', '2023-12-31') // Adjust the end date as needed
    .filterBounds(areaOfInterest)
    .map(applyQualityAndIntensityMask);
// Calculate the mean for the year 2023
var mean2023 = image2//collection2023.median();
// Display the mean image for 2024
//Map.addLayer(image2, imageVisParam2, 'Median DNB 2020');
Map.addLayer(mean2023.clip(areaOfInterest).subtract(0.29999999999999993), imageVisParam2, 'Median DNB 2023');
Map.centerObject(areaOfInterest);
// Export the mean image for 2024 to GEE Asset
Export.image.toAsset({
  image: mean2020,
  description: 'LaPAlma_mean_dnb_2020',
  assetId: 'projects/ee-pmisson/assets/La_Palma/mean_dnb_2020',
  scale: 500, // Adjust scale as needed
  region: areaOfInterest,
  maxPixels: 1e9
});
// Export the mean image for 2022 to GEE Asset
Export.image.toAsset({
  image: mean2023,
  description: 'LaPAlma_mean_dnb_2023',
  assetId: 'projects/ee-pmisson/assets/La_Palma/mean_dnb_2023',
  scale: 500, // Adjust scale as needed
  region: areaOfInterest,
  maxPixels: 1e9
});
var histogram2020 = mean2020.reduceRegion({
  reducer: ee.Reducer.frequencyHistogram(),
  geometry: areaOfInterest,
  scale: 500, // Adjust based on your data resolution and area of interest
  maxPixels: 1e8 // Adjust based on your needs
});
var histogram2023 = mean2023.reduceRegion({
  reducer: ee.Reducer.frequencyHistogram(),
  geometry: areaOfInterest,
  scale: 500, // Adjust based on your data resolution and area of interest
  maxPixels: 1e8 // Adjust based on your needs
});
var modeValue2020 = ee.Dictionary(histogram2020.get('DNB_BRDF_Corrected_NTL'))
  .toArray() // Convert the dictionary values to an array for sorting
  .sort() // Sort the array
  .get([-1]); // Attempt to get the last element, which should be the most frequent
// Note: This step is conceptual and intended to illustrate processing direction.
// Actual implementation might vary based on the specific structure of your data.
print(histogram2020);
var modeValue2023 = ee.Dictionary(histogram2023.get('DNB_BRDF_Corrected_NTL'))
  .toArray() // Convert the dictionary values to an array for sorting
  .sort() // Sort the array
  .get([-1]); // Attempt to get the last element, which should be the most frequent
// Note: This step is conceptual and intended to illustrate processing direction.
// Actual implementation might vary based on the specific structure of your data.
print(modeValue2023);
var mask1=mean2020.subtract(0.10000000000000005).gt(.7)
var ratio=mean2020.subtract(0.10000000000000005).mask(mask1).divide(mean2023.subtract(0.39999999999999995).mask(mask1))
Map.addLayer(ratio,  imageVisParam3, 'Ratio');
Map.setOptions('SATELLITE');
Map.addLayer(image5, visParams2, 'ISS_Samantha_Cristoforety');
Map.setCenter(-17.8561, 28.6132,12);
var image3=image3.clip(geometry2)
var visParams2 = {bands: ['b1', 'b2', 'b3'], max: 255};
Map.addLayer(imageXX, visParams2, 'ISS_Thomas_Pesquet');
Map.addLayer(image6, visParams2, 'ISS_Thomas_Pesquet_1');
var visParams = {bands: ['b1', 'b2', 'b3'],min:1, max: 4000,gamma:5};
Map.addLayer(image4, visParams2, 'ISS_Oleg_Novitskiy');
Map.addLayer(image7, visParams2, 'ISS_Thomas_Pesquet_2');
Map.addLayer(image8, visParams2, 'ISS_Thomas_Pesquet_3');
//Map.addLayer(image3, visParams, 'CGS');
var composite2=image3.visualize(visParams)
Map.addLayer(composite2, {}, 'CGS');
//Export.image.toDrive(composite2,'LaPalma','LaPalma',{scale:1, region: geometry,type: 'float'})
var polygonArea = geometry3.area({'maxError': 1});
// Print the result to the console.
print('polygon.area(...) =', polygonArea.multiply(1E-6));
var polygonArea = geometry4.area({'maxError': 1});
// Print the result to the console.
print('polygon.area(...) =', polygonArea.multiply(1E-6));
var polygonArea = geometry5.area({'maxError': 1});
// Print the result to the console.
print('polygon.area(...) =', polygonArea.multiply(1E-6));
var polygonArea = geometry6.area({'maxError': 1});
// Print the result to the console.
print('polygon.area(...) =', polygonArea.multiply(1E-6));
var polygonArea = geometry7.area({'maxError': 1});
// Print the result to the console.
print('polygon.area(...) =', polygonArea.multiply(1E-6));
var listOfFeatures = [
  ee.Feature(geometry3, {key: 'val1'}),
  ee.Feature(geometry4, {key: 'val2'}),
  ee.Feature(geometry5, {key: 'val3'}),
  ee.Feature(geometry6, {key: 'val4'}),
  ee.Feature(geometry7, {key: 'val5'})
];
var listOfFeaturesFc = ee.FeatureCollection(listOfFeatures);
Export.table.toDrive({
  collection: listOfFeaturesFc,
  description:'LaPalma',
  fileFormat: 'KML'
});
// Create the legend as a panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px',
    shown: false  // initially hide the legend
  }
});
// Function to create each row in the legend
var makeRow = function(color, name) {
  var colorBox = ui.Label({
    style: {
      backgroundColor: color,
      padding: '8px',
      margin: '0 0 4px 0'
    }
  });
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'}
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
var palette = [
    "ff0000", // highCCT: Cool, bluish light (blue)
    "fff600", // HPS: Warm, yellow-orange light (orange)
    "00ff12" // Inter: Unique color for "Inter" (Yellow)
];
//"palette":["ff0000","fff600","00ff12"
// Define the names array corresponding to the palette
var names = [
    '0%',  // highCCT
    '100%',      // HPS
    '200%',    // Inter
];
// Adding the color boxes and labels to the legend
names.forEach(function(name, i) {
  legend.add(makeRow(palette[i], name));
});
// Add a checkbox to control the visibility of the legend
var checkbox = ui.Checkbox('Class legend', false, function(checked) {
  legend.style().set('shown', checked);
});
// Add the checkbox and the legend to the map
Map.add(checkbox);
Map.add(legend);