// =============================================================================
// 1. DEFINICIÓN DE ASSETS Y GEOMETRÍAS
// =============================================================================
var imageCollection = ee.ImageCollection("projects/ee-pmisson/assets/ISS/TL_1merged");
var point = ee.Geometry.Point([9.556698046874995, 48.7065140979318]);
var imageCollection2 = ee.ImageCollection("NASA/VIIRS/002/VNP46A2"); // Gap Filled
var geometry2 = ee.Geometry.Polygon(
    [[[-29.306545610929458, 72.43090040379589], [-29.306545610929458, 21.234110901132976], 
    [51.90439188907054, 21.234110901132976], [51.90439188907054, 72.43090040379589]]], null, false);
// Imágenes individuales
var image2 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL5_iss053e216842_30");
var image3 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL4_iss053e425091_30");
var image4 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL3_iss053e041561_30");
var image5 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL2_iss053e253145_30");
var image6 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL1_iss053e248910_30");
var image7 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL7_iss053e020810_30");
var image8 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL6_iss053e031677_30");
var image9 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL8_iss053e462550_30");
var image10 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL9_iss053e037440_30");
var image11 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL10_iss053e041560_30");
var image12 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL11_iss053e288690_30");
var image13 = ee.Image("projects/ee-pmisson/assets/ISS/ISS_Mosaic_TL12_iss053E437070_30");
var image22 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL23_iss053e214580_30");
var image24 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL24_iss053e217890_30");
var image30 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL29_iss053e018900_25");
var image16 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL15_iss067e327360_60");
var image17 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL14_iss067e379703_60");
var image18 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL16_iss067e330280_30");
var image19 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL17_iss067e338900_80");
var image21 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL22_iss067e371080_30");
var image23 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL22_iss067e371080_30");
var image25 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL25_iss067e371080_30");
var image26 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL26_iss067e204066_30");
var image28 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL28_iss067e300449_30");
var image31 = ee.Image("users/pmisson/ISS/ISS_Mosaic_TL30_iss067e334201_25");
// IDs a excluir
var excludedIds = [
  'Corr_iss053e249220RGB_withQuality',
  'Corr_iss053e249261RGB_withQuality',
  'Corr_iss053e249255RGB_withQuality',
  'Corr_iss053e249329RGB_withQuality'
];
// =============================================================================
// 2. PARÁMETROS DE VISUALIZACIÓN
// =============================================================================
var visMin = [0.0010851758997887373, 0.0010851758997887373, 0.0010851758997887373];
var visMax = [0.29314690828323364, 0.1870129406452179, 0.1055438220500946];
var gamma = [2.5, 2.5, 4];
var issVisParams = {
  bands: ['b1', 'b2', 'b3'],
  min: visMin,
  max: visMax,
  gamma: gamma
};
var nighttimeVis = {min: 0.0, max: 160.0, gamma: 2.5};
// =============================================================================
// 3. PROCESAMIENTO DE IMÁGENES
// =============================================================================
// --- FONDO (VIIRS VNP46A2) ---
var viirsBackground2017 = imageCollection2
  .filterDate('2017-11-19', '2017-11-20')
  .select('Gap_Filled_DNB_BRDF_Corrected_NTL')
  .mosaic();
var viirsBackground2022 = imageCollection2
  .filterDate('2022-11-19', '2022-11-20')
  .select('Gap_Filled_DNB_BRDF_Corrected_NTL')
  .mosaic();
// --- ISS 2017 ---
var collectionX2017 = ee.ImageCollection([
  image2, image3, image4, image5, image6, image7, image8, image9, 
  image10, image11, image12, image13, image22, image24, image30
]).filterBounds(geometry2).filter(ee.Filter.inList('system:index', excludedIds).not());
var maskedCollectionX2017 = collectionX2017.map(function(image) {
  return image.updateMask(image.select('b4').gte(24));
});
var issMosaic2017 = maskedCollectionX2017.mean(); 
// --- ISS 2022 ---
var collectionX2022 = ee.ImageCollection([
  image16, image17, image18, image19, image21, image23, image25, 
  image26, image28, image31
]).filterBounds(geometry2).filter(ee.Filter.inList('system:index', excludedIds).not());
var maskedCollectionX2022 = collectionX2022.map(function(image) {
  return image.updateMask(image.select('b4').gte(25));
});
var issMosaic2022 = maskedCollectionX2022.mean();
// =============================================================================
// 4. CREACIÓN DE LA INTERFAZ (UI)
// =============================================================================
// Limpiar la raíz
ui.root.clear();
// --- 4.1 PANEL LATERAL DE INFORMACIÓN ---
var sidePanel = ui.Panel({
  style: {
    width: '320px', 
    padding: '10px',
    backgroundColor: '#f5f5f5',
    border: '1px solid #ddd'
  }
});
// Título del Panel
var mainTitle = ui.Label({
  value: 'Light Evolution\nEurope 2017 - 2022',
  style: {
    fontSize: '20px',
    fontWeight: 'bold',
    whiteSpace: 'pre',
    margin: '10px 0'
  }
});
// Descripción breve
var description = ui.Label({
  value: 'Comparison of ISS night images and VIIRS data to analyze light pollution evolution across Europe.',
  style: {fontSize: '13px', margin: '0 0 10px 0', color: '#555'}
});
// WARNING: APPLICACIÓN EN DESARROLLO
var warningPanel = ui.Panel({
  style: {
    border: '1px solid red',
    backgroundColor: '#ffe6e6',
    padding: '8px',
    margin: '10px 0'
  }
});
var warningText = ui.Label({
  value: '⚠ WARNING: Application under development.\nIf you want to contribute, please participate in the citizen science app below.',
  style: {
    color: '#cc0000',
    fontSize: '11px',
    fontWeight: 'bold',
    whiteSpace: 'pre-wrap',
    textAlign: 'center'
  }
});
warningPanel.add(warningText);
// Sección de Enlaces
var linksHeader = ui.Label({
  value: 'Useful Links:',
  style: {fontWeight: 'bold', margin: '15px 0 5px 0'}
});
// Enlace 1: Plan-B
var linkPlanB = ui.Label({
  value: '🔗 European Plan-B Project',
  style: {
    color: '#0000EE',
    textDecoration: 'underline',
    margin: '5px 0'
  },
  targetUrl: 'https://plan-b-project.eu/'
});
// Enlace 2: Lost at Night
var linkLostAtNight = ui.Label({
  value: '🔗 Citizen Science: Lost at Night',
  style: {
    color: '#0000EE',
    textDecoration: 'underline',
    margin: '5px 0'
  },
  targetUrl: 'https://lostatnight.org/'
});
// Separador visual
var separator = ui.Panel({
  style: {
    height: '1px',
    backgroundColor: '#ddd',
    margin: '15px 0'
  }
});
// Texto de desarrolladores (Nombres)
var developers = ui.Label({
  // Se han reemplazado los '1' por '¹' y '2' por '²'
  value: 'Developed by Alejandro Sánchez de Miguel¹², Raul Pérez Parras¹², Joaquín López Herraiz¹ and Sergio Pascual¹.',
  style: {
    fontSize: '11px',
    color: '#333',
    margin: '5px 0 2px 0',
    fontWeight: 'bold'
  }
});
// Texto de Instituciones (Nuevo)
var institutions = ui.Label({
  // Se han reemplazado los '1' por '¹' y '2' por '²'
  value: 'Universidad Complutense de Madrid (¹) and Instituto de Astrofísica de Andalucía-CSIC (²).',
  style: {
    fontSize: '10px',
    color: '#444',
    margin: '0 0 10px 0',
    fontStyle: 'italic'
  }
});
// Ejemplo de cómo se vería si lo añadieras a la raíz de la interfaz de GEE
// ui.root.add(developers);
// ui.root.add(institutions);
// Texto de Financiación (Horizon Europe)
var fundingText = ui.Label({
  value: 'Funded by the European Union under the Horizon Europe Programme, Grant Agreement No. 101135308 (PLAN-B). Research and Innovation Action | HORIZON-CL6-2023-BIODIV-01.',
  style: {
    fontSize: '10px',
    color: '#666',
    margin: '10px 0',
    whiteSpace: 'pre-wrap', 
    textAlign: 'justify'
  }
});
// Añadir widgets al panel lateral en orden
sidePanel.add(mainTitle);
sidePanel.add(description);
sidePanel.add(warningPanel); // Añadido el warning aquí
sidePanel.add(linksHeader);
sidePanel.add(linkPlanB);
sidePanel.add(linkLostAtNight);
sidePanel.add(separator);
sidePanel.add(developers);
sidePanel.add(institutions); // Añadido instituciones aquí
sidePanel.add(fundingText);
// --- 4.2 MAPAS Y SLIDER ---
// Mapa Izquierdo (2017)
var leftMap = ui.Map();
leftMap.setControlVisibility({layerList: false, zoomControl: false, mapTypeControl: false});
leftMap.addLayer(viirsBackground2017, nighttimeVis, 'VIIRS Background 2017');
leftMap.addLayer(issMosaic2017, issVisParams, 'Europe ISS 2017');
var label2017 = ui.Label('2017', {position: 'bottom-left', fontWeight: 'bold', fontSize: '24px', backgroundColor: 'rgba(255,255,255,0.7)'});
leftMap.add(label2017);
// Mapa Derecho (2022)
var rightMap = ui.Map();
rightMap.setControlVisibility({layerList: false, zoomControl: true, mapTypeControl: true}); 
rightMap.addLayer(viirsBackground2022, nighttimeVis, 'VIIRS Background 2022');
rightMap.addLayer(issMosaic2022, issVisParams, 'Europe ISS 2022');
var label2022 = ui.Label('2022', {position: 'bottom-right', fontWeight: 'bold', fontSize: '24px', backgroundColor: 'rgba(255,255,255,0.7)'});
rightMap.add(label2022);
// Vincular mapas
var linker = ui.Map.Linker([leftMap, rightMap]);
// Crear Slider
var splitMapPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe: true,
  style: {stretch: 'both'} 
});
// --- 4.3 LAYOUT PRINCIPAL ---
// Configurar layout horizontal
ui.root.setLayout(ui.Panel.Layout.flow('horizontal'));
// Añadir los componentes
ui.root.add(sidePanel);
ui.root.add(splitMapPanel);
// Centrar mapa
leftMap.centerObject(point, 5);