var image1 = ui.import && ui.import("image1", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/01_SVDNB_npp_d20250429_t0111575_e0117379_b69968_c20250429025038800000_oeac_ops_Radiance_modified"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/01_SVDNB_npp_d20250429_t0111575_e0117379_b69968_c20250429025038800000_oeac_ops_Radiance_modified"),
    image2 = ui.import && ui.import("image2", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/02_SVDNB_npp_d20250429_t0117392_e0123195_b69968_c20250429025053121000_oeac_ops_Radiance_modified"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/02_SVDNB_npp_d20250429_t0117392_e0123195_b69968_c20250429025053121000_oeac_ops_Radiance_modified"),
    image3 = ui.import && ui.import("image3", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/03_SVDNB_j01_d20250429_t0134444_e0140244_b38572_c20250429022430306000_oeac_ops_Radiance_modified"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/03_SVDNB_j01_d20250429_t0134444_e0140244_b38572_c20250429022430306000_oeac_ops_Radiance_modified"),
    image5 = ui.import && ui.import("image5", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/05_SVDNB_j02_d20250429_t0225567_e0231373_b12780_c20250429031528714000_oeac_ops_Radiance_modified"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/05_SVDNB_j02_d20250429_t0225567_e0231373_b12780_c20250429031528714000_oeac_ops_Radiance_modified"),
    image6 = ui.import && ui.import("image6", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/06_SVDNB_j02_d20250429_t0231385_e0237173_b12780_c20250429031512834000_oeac_ops_Radiance_modified"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/06_SVDNB_j02_d20250429_t0231385_e0237173_b12780_c20250429031512834000_oeac_ops_Radiance_modified"),
    image9 = ui.import && ui.import("image9", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/09_SVDNB_j01_d20250429_t0317085_e0322485_b38573_c20250429040425094000_oeac_ops_Radiance_modified"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/09_SVDNB_j01_d20250429_t0317085_e0322485_b38573_c20250429040425094000_oeac_ops_Radiance_modified"),
    image7 = ui.import && ui.import("image7", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/07_SVDNB_npp_d20250429_t0254231_e0300035_b69969_c20250429043050842000_oeac_ops_Radiance_modified"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/07_SVDNB_npp_d20250429_t0254231_e0300035_b69969_c20250429043050842000_oeac_ops_Radiance_modified"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "b1"
        ],
        "max": 1e-7,
        "gamma": 3
      }
    }) || {"opacity":1,"bands":["b1"],"max":1e-7,"gamma":3},
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -11.066893678699476,
                45.55406492217736
              ],
              [
                -11.066893678699476,
                34.99580498732296
              ],
              [
                6.4013680400505235,
                34.99580498732296
              ],
              [
                6.4013680400505235,
                45.55406492217736
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-11.066893678699476, 45.55406492217736],
          [-11.066893678699476, 34.99580498732296],
          [6.4013680400505235, 34.99580498732296],
          [6.4013680400505235, 45.55406492217736]]], null, false),
    imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "NASA/VIIRS/002/VNP46A2"
    }) || ee.ImageCollection("NASA/VIIRS/002/VNP46A2"),
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "DNB_BRDF_Corrected_NTL"
        ],
        "min": 0,
        "max": 200,
        "gamma": 3
      }
    }) || {"opacity":1,"bands":["DNB_BRDF_Corrected_NTL"],"min":0,"max":200,"gamma":3},
    image0 = ui.import && ui.import("image0", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/00_SVDNB_j02_d20250429_t0049126_e0054532_b12779_c20250429013301362000_oeac_ops_Radiance_modified"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/00_SVDNB_j02_d20250429_t0049126_e0054532_b12779_c20250429013301362000_oeac_ops_Radiance_modified"),
    image = ui.import && ui.import("image", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0048_021"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0048_021"),
    image4 = ui.import && ui.import("image4", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0112_002"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0112_002"),
    image8 = ui.import && ui.import("image8", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0136_021"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0136_021"),
    image10 = ui.import && ui.import("image10", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0224_021"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0224_021"),
    image11 = ui.import && ui.import("image11", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0230_021"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0230_021"),
    image12 = ui.import && ui.import("image12", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0254_002"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0254_002"),
    image13 = ui.import && ui.import("image13", "image", {
      "id": "projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0318_021"
    }) || ee.Image("projects/ee-pmisson/assets/Apagon/DNB_precise_A2025119_0318_021");
// --------------------------------------------------------
// Blackout Spain: RGB visualization of blackouts with GIF & max layer
// --------------------------------------------------------
// 1. Create a new map widget and center it
var map = ui.Map();
map.centerObject(geometry, 7);
// 2. Clear the default root and add only the map
ui.root.clear();
ui.root.add(map);
// 3. Info widget (title + warning) in top-center
var infoPanel = ui.Panel([
  ui.Label('Blackout Spain', {
    fontSize: '16px',
    fontWeight: 'bold',
    margin: '0 0 4px 0'
  }),
  ui.Label('⚠️ All times in UTC\nLocal time = UTC+2 (29 Apr 2025)', {
    fontSize: '10px',
    color: 'red'
  })
], ui.Panel.Layout.flow('vertical'), {
  position: 'top-center',
  padding: '6px',
  backgroundColor: 'white',
  maxWidth: '150px'
});
map.add(infoPanel);
// 4. Time window
var start = ee.Date('2024-09-01');
var end   = ee.Date('2024-10-01');
// 5. Visualization parameters
var viirsVis     = { bands: ['DNB_BRDF_Corrected_NTL'], min: 1,    max: 200,   gamma: 3 };
var generalVis   = { bands: ['b1'],                    min: 5e-9, max: 1e-7, gamma: 3 };
var compositeVis = { min: 0, max: 1, gamma: 3 };
var maxVis       = { bands: ['max_blackout'],          min: 0,    max: 1,    gamma: 3 };
// 6. Load VIIRS and compute mean
var viirs = ee.ImageCollection('NASA/VIIRS/002/VNP46A2')
               .filterDate(start, end)
               .select('DNB_BRDF_Corrected_NTL');
var viirsMean = viirs.mean().clip(geometry);
// 7. List of blackout images
var images = [
  image.set('time', '00:48'),
  image4.set('time', '01:12'),
  image8.set('time', '01:36'),
  image11.set('time', '02:30'),
  image12.set('time', '02:54'),
  image13.set('time', '03:18')
];
// 8. Main control panel (bottom-left)
var panel = ui.Panel({
  style: { width: '300px', padding: '8px', position: 'bottom-left' }
});
map.add(panel);
// 9. Sub-panels (always shown)
panel.add(ui.Label('— Original Layers —'));
var originalPanel = ui.Panel({ layout: ui.Panel.Layout.flow('vertical') });
panel.add(originalPanel);
panel.add(ui.Label('— Colored Layers —'));
var coloredPanel = ui.Panel({ layout: ui.Panel.Layout.flow('vertical') });
panel.add(coloredPanel);
panel.add(ui.Label('— Other Layers —'));
var otherPanel = ui.Panel({ layout: ui.Panel.Layout.flow('vertical') });
panel.add(otherPanel);
// 10. Helper to add layers
function addLayer(img, visParams, name, defaultVisible, container) {
  var layer = ui.Map.Layer(img.clip(geometry), visParams, name, defaultVisible);
  map.layers().add(layer);
  var controls = ui.Panel({
    layout: ui.Panel.Layout.flow('horizontal'),
    style: { stretch: 'horizontal', padding: '4px 0' }
  });
  var cb = ui.Checkbox(name, defaultVisible, function(vis) {
    layer.setShown(vis);
  });
  var slider = ui.Slider({
    min: 0, max: 1, value: 1, step: 0.01,
    style: { stretch: 'horizontal' }
  });
  slider.onChange(function(op) { layer.setOpacity(op); });
  controls.add(cb);
  controls.add(ui.Label('Opacity', { margin: '0 4px' }));
  controls.add(slider);
  container.add(controls);
}
// 11. Add VIIRS mean layer
addLayer(viirsMean, viirsVis, 'No Blackout (VIIRS)', true, otherPanel);
// 12. Build normalized & RGB collections
var normList = [];
var rgbCol = ee.ImageCollection(images.map(function(img) {
  var t = img.get('time').getInfo();
  var nb = img.select('b1').divide(generalVis.max)
               .updateMask(img.select('b1').divide(generalVis.max).gt(0))
               .clamp(0,1);
  var nv = viirsMean.divide(viirsVis.max)
                    .updateMask(viirsMean.divide(viirsVis.max).gt(0))
                    .clamp(0,1);
  normList.push(nb);
  addLayer(img.select('b1'), generalVis, 'Original ' + t, false, originalPanel);
  var rgb = ee.Image.cat([nb, nv, nb]).rename(['R','G','B']);
  addLayer(rgb, compositeVis, 'Colored ' + t, false, coloredPanel);
  return rgb.set('time', t);
}));
// 13. Max blackout layer
var maxBlk = ee.ImageCollection(normList).max()
               .rename('max_blackout').clip(geometry);
addLayer(maxBlk, maxVis, 'Max Blackout', false, otherPanel);
// 14. GIF animation
panel.add(ui.Label('🎞️ Blackout Animation (GIF):'));
var gifP = { region: geometry, dimensions: 600, framesPerSecond: 1, format: 'gif' };
panel.add(ui.Thumbnail(rgbCol, gifP));
print('GIF URL:', rgbCol.getVideoThumbURL(gifP));
// --------------------------------------------------------
//  Export all images to Drive
// --------------------------------------------------------
// Folder de destino en tu Drive
var driveFolder = 'BlackoutSpain_Exports';
// 1) Export de cada instante: Original y Colored
images.forEach(function(img) {
  // Obtener el timestamp, quitar “:” para el nombre
  var time = img.get('time').getInfo().replace(':', '');
  // 1.a) Original (band b1) visualizado
  Export.image.toDrive({
    image: img.select('b1').visualize(generalVis),
    description: 'Original_' + time,
    folder: driveFolder,
    fileNamePrefix: 'Original_' + time,
    region: geometry,
    scale: 500,
    crs: 'EPSG:4326',
    maxPixels: 1e13
  });
  // 1.b) Colored RGB
  var normBlackout = img.select('b1').divide(generalVis.max)
                         .updateMask(img.select('b1').divide(generalVis.max).gt(0))
                         .clamp(0,1);
  var normViirs    = viirsMean.divide(viirsVis.max)
                         .updateMask(viirsMean.divide(viirsVis.max).gt(0))
                         .clamp(0,1);
  var rgb = ee.Image.cat([normBlackout, normViirs, normBlackout])
                   .rename(['R','G','B']);
  Export.image.toDrive({
    image: rgb.visualize(compositeVis),
    description: 'Colored_' + time,
    folder: driveFolder,
    fileNamePrefix: 'Colored_' + time,
    region: geometry,
    scale: 500,
    crs: 'EPSG:4326',
    maxPixels: 1e13
  });
});
// 2) Export del máximo blackout
Export.image.toDrive({
  image: maxBlk.visualize(maxVis),
  description: 'Max_Blackout',
  folder: driveFolder,
  fileNamePrefix: 'Max_Blackout',
  region: geometry,
  scale: 500,
  crs: 'EPSG:4326',
  maxPixels: 1e13
});