var image = ui.import && ui.import("image", "image", {
      "id": "projects/ee-pmisson/assets/Vigo/JL1GF03C03_MSS_20250101044028_200336046_106_0017_001_L1A_"
    }) || ee.Image("projects/ee-pmisson/assets/Vigo/JL1GF03C03_MSS_20250101044028_200336046_106_0017_001_L1A_"),
    image2 = ui.import && ui.import("image2", "image", {
      "id": "projects/ee-pmisson/assets/Vigo/JL1GF03C03_MSS_20250101044028_200336046_106_0023_001_L1A_"
    }) || ee.Image("projects/ee-pmisson/assets/Vigo/JL1GF03C03_MSS_20250101044028_200336046_106_0023_001_L1A_");
// =====================================================
// ✅ VISOR VIGO + VIGO/2025 (UI limpia, sin duplicados)
//     - Selector de carpeta
//     - Slider (imagen individual) + mean + median
//     - Rectángulo + GIF de la zona seleccionada
// =====================================================
// 0) UI ROOT LIMPIO + MAPA PROPIO (evita el error de widgets)
var map = ui.Map();
ui.root.widgets().reset([map]);
map.setOptions('SATELLITE');
// =======================================
// 1) CONFIG: CARPETAS
// =======================================
var FOLDERS = {
  'Vigo (raíz)': 'projects/ee-pmisson/assets/Vigo',
  'Vigo/2025':   'projects/ee-pmisson/assets/Vigo/2025'
};
// Vigo raíz: tu patrón antiguo (si quieres, ponlo a false para incluir todo)
var ROOT_USE_PATTERN_FILTER = true;
var ROOT_PREFIX = 'JL1GF03C03_MSS_20250101044028_200336046_106_00';
var ROOT_SUFFIX_CONTAINS = '_001_L1A_';
// Vigo/2025: nombres tipo "Vigo_016" ... "Vigo_023"
var Y2025_USE_PATTERN_FILTER = true;
var Y2025_PREFIX = 'Vigo_';
var Y2025_MIN = 16;
var Y2025_MAX = 23;
// =======================================
// 2) VISUALIZACIÓN (nocturna)
// =======================================
var vis = {
  bands: ['b1', 'b2', 'b3'],
  min: 10.0,
  max: 250.0,
  gamma: 1.6
};
// =======================================
// 3) UI: PANEL IZQUIERDO (CONTROL)
// =======================================
var controlPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: { width: '330px', position: 'bottom-left' }
});
controlPanel.add(ui.Label({
  value: 'Visor Vigo – Zoom 16',
  style: { fontWeight: 'bold', fontSize: '16px' }
}));
controlPanel.add(ui.Label(
  'Orden de capas (de abajo a arriba):\n' +
  '• Capa 0: Imagen individual (Slider)\n' +
  '• Capa 1: Media\n' +
  '• Capa 2: Mediana\n'
));
controlPanel.add(ui.Label('Dataset:'));
var datasetSelect = ui.Select({
  items: Object.keys(FOLDERS),
  value: 'Vigo (raíz)',
  style: { width: '310px' }
});
controlPanel.add(datasetSelect);
var sliderPanel = ui.Panel({ layout: ui.Panel.Layout.flow('vertical') });
controlPanel.add(sliderPanel);
controlPanel.add(ui.Label('----------------'));
controlPanel.add(ui.Label('Generador de GIF:'));
controlPanel.add(ui.Label('Dibuja un rectángulo para definir la zona.'));
// =======================================
// 4) UI: PANEL DERECHO (GIF)
// =======================================
var gifPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: { width: '420px', position: 'bottom-right' }
});
function resetGifPanel(title) {
  gifPanel.clear();
  gifPanel.add(ui.Label({
    value: title || 'Vista previa del GIF',
    style: { fontWeight: 'bold', fontSize: '16px' }
  }));
}
resetGifPanel();
// Añadir widgets
ui.root.add(controlPanel);
ui.root.add(gifPanel);
// =======================================
// 5) DIBUJO: RECTÁNGULO
// =======================================
var drawingTools = map.drawingTools();
drawingTools.setShown(true);
drawingTools.setLinked(false);
drawingTools.setShape('rectangle');
drawingTools.draw();
var clearButton = ui.Button('1) Nuevo rectángulo', function () {
  while (drawingTools.layers().length() > 0) {
    drawingTools.layers().remove(drawingTools.layers().get(0));
  }
  drawingTools.setShape('rectangle');
  drawingTools.draw();
});
controlPanel.add(clearButton);
// =======================================
// 6) ESTADO GLOBAL
// =======================================
var STATE = {
  folderLabel: null,
  folderPath: null,
  colSorted: null,
  list: null,
  count: 0
};
// =======================================
// 7) FILTRO POR DATASET
// =======================================
function passesFilter(basename, folderLabel) {
  if (folderLabel === 'Vigo/2025') {
    if (!Y2025_USE_PATTERN_FILTER) return true;
    // Esperado: "Vigo_016" ... "Vigo_023"
    if (basename.indexOf(Y2025_PREFIX) !== 0) return false;
    // Extraer parte numérica tras "Vigo_"
    var numStr = basename.substring(Y2025_PREFIX.length); // "016"
    var num = parseInt(numStr, 10); // 16
    if (isNaN(num)) return false;
    return (num >= Y2025_MIN && num <= Y2025_MAX);
  }
  // Default: Vigo raíz
  if (!ROOT_USE_PATTERN_FILTER) return true;
  var okPrefix = basename.indexOf(ROOT_PREFIX) === 0;
  var okSuffix = basename.indexOf(ROOT_SUFFIX_CONTAINS) > -1;
  return okPrefix && okSuffix;
}
// =======================================
// 8) LISTAR ASSETS + CREAR COLECCIÓN
// =======================================
function buildCollectionFromFolder(folderPath, folderLabel) {
  var assetsInfo;
  try {
    assetsInfo = ee.data.listAssets(folderPath); // lado cliente
  } catch (e) {
    print('❌ Error listando assets en:', folderPath, e);
    return { ids: [], colSorted: ee.ImageCollection([]) };
  }
  var assets = assetsInfo.assets || [];
  // Debug: imprime basenames encontrados
  var basenames = assets
    .filter(function (a) { return a.type === 'IMAGE'; })
    .map(function (a) { return a.name.split('/').pop(); });
  print('🔎 Basenames en ' + folderPath + ':', basenames);
  // Solo imágenes
  var images = assets.filter(function (a) {
    return a.type === 'IMAGE';
  });
  // Filtrar por patrón según dataset
  var filtered = images.filter(function (a) {
    var basename = a.name.split('/').pop();
    return passesFilter(basename, folderLabel);
  });
  print('📁 Carpeta:', folderPath);
  print('✅ Assets filtrados:', filtered);
  var ids = filtered.map(function (a) { return a.name; });
  ids.sort();
  var imageList = ids.map(function (id) { return ee.Image(id); });
  var col = ee.ImageCollection.fromImages(imageList);
  var colSorted = col.sort('system:index');
  print('Colección:', colSorted);
  return { ids: ids, colSorted: colSorted };
}
// =======================================
// 9) REFRESCAR MAPA + SLIDER
// =======================================
function refreshDataset(folderLabel) {
  STATE.folderLabel = folderLabel;
  STATE.folderPath = FOLDERS[folderLabel];
  var out = buildCollectionFromFolder(STATE.folderPath, folderLabel);
  STATE.colSorted = out.colSorted;
  sliderPanel.clear();
  sliderPanel.add(ui.Label('Carpeta activa: ' + STATE.folderPath));
  sliderPanel.add(ui.Label('Cargando colección...'));
  map.layers().reset([]);
  resetGifPanel('Vista previa del GIF');
  STATE.colSorted.size().evaluate(function (count) {
    STATE.count = count;
    sliderPanel.clear();
    sliderPanel.add(ui.Label('Carpeta activa: ' + STATE.folderPath));
    if (count === 0) {
      sliderPanel.add(ui.Label('⚠️ No se encontraron imágenes (o no coinciden con el patrón).'));
      return;
    }
    // Centrar en primera imagen (zoom 16)
    var first = STATE.colSorted.first();
    first.geometry().centroid().coordinates().evaluate(function (coords) {
      if (coords && coords.length >= 2) {
        map.setCenter(coords[0], coords[1], 16);
      }
    });
    STATE.list = STATE.colSorted.toList(count);
    var mean = STATE.colSorted.mean();
    var median = STATE.colSorted.median();
    // Capa 0: imagen individual inicial
    var firstImg = ee.Image(STATE.list.get(0));
    map.addLayer(firstImg, vis, 'Imagen 0 (inicial)');
    // Capa 1: mean
    map.addLayer(mean, vis, 'Media (' + folderLabel + ')');
    // Capa 2: median
    map.addLayer(median, vis, 'Mediana (' + folderLabel + ')');
    // Slider
    var infoLabel = ui.Label('Imagen individual: 0 / ' + (count - 1));
    var slider = ui.Slider({
      min: 0,
      max: count - 1,
      step: 1,
      value: 0,
      style: { width: '310px' }
    });
    function updateMap(i) {
      i = Math.floor(i);
      infoLabel.setValue('Imagen individual: ' + i + ' / ' + (count - 1));
      var img = ee.Image(STATE.list.get(i));
      map.layers().set(0, ui.Map.Layer(img, vis, 'Imagen ' + i));
    }
    slider.onChange(updateMap);
    sliderPanel.add(slider);
    sliderPanel.add(infoLabel);
    updateMap(0);
  });
}
// =======================================
// 10) GENERAR GIF
// =======================================
function generateGif() {
  if (!STATE.colSorted || STATE.count === 0) {
    resetGifPanel('Vista previa del GIF');
    gifPanel.add(ui.Label('⚠️ No hay colección activa con imágenes.'));
    return;
  }
  if (drawingTools.layers().length() === 0) {
    resetGifPanel('Vista previa del GIF');
    gifPanel.add(ui.Label('⚠️ Primero dibuja un rectángulo en el mapa.'));
    return;
  }
  var layer = drawingTools.layers().get(0);
  var geom = layer.getEeObject();
  var videoArgs = {
    dimensions: 600,
    region: geom,
    framesPerSecond: 2,
    crs: 'EPSG:3857',
    min: vis.min,
    max: vis.max,
    gamma: vis.gamma,
    bands: vis.bands
  };
  resetGifPanel('Vista previa del GIF (' + STATE.folderLabel + ')');
  gifPanel.add(ui.Label('Generando... (puede tardar unos segundos)'));
  var thumbUrl = STATE.colSorted.getVideoThumbURL(videoArgs);
  var thumb = ui.Thumbnail({
    image: STATE.colSorted,
    params: videoArgs,
    style: { width: '400px' }
  });
  gifPanel.widgets().set(1, thumb);
  gifPanel.add(ui.Label({
    value: 'Haz clic aquí para descargar/ver en grande',
    targetUrl: thumbUrl
  }));
}
var gifButton = ui.Button('2) Generar GIF de zona seleccionada', generateGif);
controlPanel.add(gifButton);
// =======================================
// 11) EVENTO CAMBIO DATASET + INICIO
// =======================================
datasetSelect.onChange(function (label) {
  refreshDataset(label);
});
refreshDataset(datasetSelect.getValue());