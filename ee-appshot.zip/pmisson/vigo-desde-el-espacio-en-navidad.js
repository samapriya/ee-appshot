var image = ui.import && ui.import("image", "image", {
      "id": "projects/ee-pmisson/assets/Vigo/JL1GF03C03_MSS_20250101044028_200336046_106_0017_001_L1A_"
    }) || ee.Image("projects/ee-pmisson/assets/Vigo/JL1GF03C03_MSS_20250101044028_200336046_106_0017_001_L1A_"),
    image2 = ui.import && ui.import("image2", "image", {
      "id": "projects/ee-pmisson/assets/Vigo/JL1GF03C03_MSS_20250101044028_200336046_106_0023_001_L1A_"
    }) || ee.Image("projects/ee-pmisson/assets/Vigo/JL1GF03C03_MSS_20250101044028_200336046_106_0023_001_L1A_");
// ================================
// 1. LISTAR ASSETS Y CREAR COLECCIÓN
// ================================
var folder = 'projects/ee-pmisson/assets/Vigo';
// Obtenemos los assets de la carpeta (lado cliente)
var assetsInfo = ee.data.listAssets(folder);
var assets = assetsInfo.assets || [];
// Filtramos solo las imágenes JL1 que siguen el patrón
var filtered = assets.filter(function(a) {
  var id = a.name.split('/').pop();
  // Ajusta estos patrones si cambian los nombres de tus archivos
  var okPrefix = id.indexOf('JL1GF03C03_MSS_20250101044028_200336046_106_00') === 0;
  var okSuffix = id.indexOf('_001_L1A_') > -1;
  return okPrefix && okSuffix;
});
print('Assets filtrados (JL1 Vigo):', filtered);
// Paths completos de los assets
var ids = filtered.map(function(a) { return a.name; });
ids.sort();
// Creamos lista de imágenes
var imageList = ids.map(function(id) { return ee.Image(id); });
// ImageCollection ordenada
var col = ee.ImageCollection.fromImages(imageList);
var colSorted = col.sort('system:index');
print('Colección Vigo JL1:', colSorted);
// Si no hay imágenes, avisamos
colSorted.size().evaluate(function(n) {
  if (n === 0) {
    print('⚠️ No se han encontrado imágenes que coincidan con el patrón.');
  }
});
// Punto fijo para centrar todo (centro de la primera imagen)
// Usamos un evaluate para evitar errores si la colección está vacía al inicio
if (colSorted.size().getInfo() > 0) {
  var centerPoint = colSorted.first().geometry().centroid();
  var coords = centerPoint.coordinates().getInfo();
  Map.setCenter(coords[0], coords[1], 16);  // zoom fijo 16
}
// ================================
// 2. MEDIANA, MEDIA Y PARAMETROS VISUALES
// ================================
// AJUSTES VISUALES AVANZADOS
// Modificados para simular fotografía nocturna profesional
var vis = {
  bands: ['b1', 'b2', 'b3'],
  min: 10.0,       // Subimos el mínimo para "negros" más profundos y menos ruido
  max: 250.0,      // Bajamos el máximo (antes 255) para que las luces brillen más
  gamma: 1.6       // Gamma > 1 aclara los medios tonos sin saturar, dando el efecto "eléctrico"
};
var median = colSorted.median();
var mean   = colSorted.mean();
// Capa 0: empezamos poniendo una imagen individual inicial
var firstImg = colSorted.first();
Map.addLayer(firstImg, vis, 'Imagen 0 (inicial)');   // capa 0 = imagen individual
// Capa 1: media
Map.addLayer(mean, vis, 'Media Vigo JL1 (mean)');
// Capa 2: mediana (siempre arriba)
Map.addLayer(median, vis, 'Mediana Vigo JL1 (median)');
// ================================
// 3. PANEL DE CONTROL Y SLIDER
// ================================
var controlPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {width: '300px', position: 'bottom-left'}
});
controlPanel.add(ui.Label({
  value: 'Visor JL1 Vigo – Zoom 16',
  style: {fontWeight: 'bold', fontSize: '16px'}
}));
controlPanel.add(ui.Label(
  'Orden de capas (de abajo a arriba):\n' +
  '• Capa 0: Imagen individual (Slider)\n' +
  '• Capa 1: Media\n' +
  '• Capa 2: Mediana\n'
));
ui.root.add(controlPanel);
colSorted.size().evaluate(function(count) {
  if (count === 0) {
    controlPanel.add(ui.Label('⚠️ No se encontraron imágenes.'));
    return;
  }
  var list = colSorted.toList(count);
  var slider = ui.Slider({
    min: 0,
    max: count - 1,
    step: 1,
    value: 0,
    style: {width: '250px'}
  });
  var infoLabel = ui.Label('Cargando...');
  controlPanel.add(slider);
  controlPanel.add(infoLabel);
  var updateMap = function(i) {
    i = Math.floor(i);
    infoLabel.setValue('Imagen individual: ' + i + ' / ' + (count - 1));
    var img = ee.Image(list.get(i));
    // Capa 0 = imagen individual
    // Usamos la misma variable 'vis' para mantener el estilo
    Map.layers().set(0, ui.Map.Layer(img, vis, 'Imagen ' + i));
  };
  slider.onChange(updateMap);
  updateMap(0);
});
// ================================
// 4. HERRAMIENTA DE DIBUJO PARA ELEGIR ZONA DEL GIF
// ================================
var drawingTools = Map.drawingTools();
drawingTools.setShown(true);
drawingTools.setLinked(false);  // solo este mapa
drawingTools.setShape('rectangle');
drawingTools.draw();
var clearButton = ui.Button('1) Nuevo rectángulo', function() {
  // Eliminar todas las capas de dibujo existentes
  while (drawingTools.layers().length() > 0) {
    var layer = drawingTools.layers().get(0);
    drawingTools.layers().remove(layer);
  }
  drawingTools.setShape('rectangle');
  drawingTools.draw();
});
controlPanel.add(ui.Label('----------------'));
controlPanel.add(ui.Label('Generador de GIF:'));
controlPanel.add(ui.Label('Dibuja un rectángulo para definir la zona.'));
controlPanel.add(clearButton);
// ================================
// 5. PANEL DE GIF Y BOTÓN "GENERAR GIF"
// ================================
var gifPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {width: '420px', position: 'bottom-right'}
});
gifPanel.add(ui.Label({
  value: 'Vista previa del GIF',
  style: {fontWeight: 'bold', fontSize: '16px'}
}));
ui.root.add(gifPanel);
var generateGif = function() {
  if (drawingTools.layers().length() === 0) {
    gifPanel.widgets().set(1, ui.Label('⚠️ Primero dibuja un rectángulo en el mapa.'));
    return;
  }
  var layer = drawingTools.layers().get(0);
  var geom = layer.getEeObject();  // Geometría del rectángulo
  // Parámetros del vídeo: Usamos las mismas propiedades visuales (vis)
  var videoArgs = {
    dimensions: 600,
    region: geom,
    framesPerSecond: 2,
    crs: 'EPSG:3857', // Asegura proyección web mercator
    min: vis.min,
    max: vis.max,
    gamma: vis.gamma, 
    bands: vis.bands
  };
  // Limpiamos el panel del GIF (manteniendo el título)
  gifPanel.clear();
  gifPanel.add(ui.Label({
    value: 'Vista previa del GIF',
    style: {fontWeight: 'bold', fontSize: '16px'}
  }));
  gifPanel.add(ui.Label('Generando... (puede tardar unos segundos)'));
  // Generamos la URL del thumbnail/gif
  var thumbUrl = colSorted.getVideoThumbURL(videoArgs);
  // Mostramos el GIF en el panel
  var thumb = ui.Thumbnail({
    image: colSorted,
    params: videoArgs,
    style: {width: '400px'}
  });
  // Reemplazamos el mensaje de "Generando..." con la imagen y un link
  gifPanel.widgets().set(1, thumb);
  gifPanel.add(ui.Label({
    value: 'Haz clic aquí para descargar/ver en grande',
    targetUrl: thumbUrl
  }));
};
var gifButton = ui.Button('2) Generar GIF de zona seleccionada', generateGif);
controlPanel.add(gifButton);