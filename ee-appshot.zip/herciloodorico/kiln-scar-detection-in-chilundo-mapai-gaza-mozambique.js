// Define the AOI
var roi = ee.Geometry.Point([32.67487791613873, -22.229572459393825]);
// Define a dictionary which will be used to make legend and visualize image on map
var dict = {
  "names": [
    "Charcoal Kilns",
    "Forest",
    "Nonforest"
  ],
  "colors": [
    "#ce0000",
    "#00e41c",
    "#fffdd0"
  ]};
// Create a panel to hold the legend widget
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Function to generate the legend
function addCategoricalLegend(panel, dict, title) {
  // Create and add the legend title.
  var legendTitle = ui.Label({
    value: title,
    style: {
      fontWeight: 'bold',
      fontSize: '18px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  panel.add(legendTitle);
  var loading = ui.Label('Loading legend...', {margin: '2px 0 4px 0'});
  panel.add(loading);
  // Creates and styles 1 row of the legend.
  var makeRow = function(color, name) {
    // Create the label that is actually the colored box.
    var colorBox = ui.Label({
      style: {
        backgroundColor: color,
        // Use padding to give the box height and width.
        padding: '8px',
        margin: '0 0 4px 0'
      }
    });
    // Create the label filled with the description text.
    var description = ui.Label({
      value: name,
      style: {margin: '0 0 4px 6px'}
    });
    return ui.Panel({
      widgets: [colorBox, description],
      layout: ui.Panel.Layout.Flow('horizontal')
    });
  };
  // Get the list of palette colors and class names from the image.
  var palette = dict['colors'];
  var names = dict['names'];
  loading.style().set('shown', false);
  for (var i = 0; i < names.length; i++) {
    panel.add(makeRow(palette[i], names[i]));
  }
  Map.add(panel);
}
/*
  // Display map and legend ///////////////////////////////////////////////////////////////////////////////
*/
// Add the legend to the map
addCategoricalLegend(legend, dict, 'Legend');
// Add image to the map
var moz_lulc20 = ee.Image("projects/planet-level-2/assets/Charcoal_production_Chilundo_2023");
// Split-screen display
// Create the first map and add the Google Satellite layer
var linkedMap = ui.Map();
linkedMap.setOptions('SATELLITE');
// Create the second map and add the 2023 Moz LULC 20m layer
linkedMap.addLayer(moz_lulc20, {min:1, max:3, palette:dict['colors']}, 'Kiln Scar Detectation');
// Create a linker to synchronize the two maps
var linker = ui.Map.Linker([ui.root.widgets().get(0), linkedMap]);
// Create a split panel to swipe between the maps
var splitPanel = ui.SplitPanel({
  firstPanel: linker.get(0),
  secondPanel: linker.get(1),
  orientation: 'horizontal',
  wipe: true,
  style: {stretch: 'both'}
});
// Reset the widgets to include only the split panel
ui.root.widgets().reset([splitPanel]);
// Center both maps on the ROI (polygon)
linkedMap.centerObject(roi, 12);
Map.setOptions('SATELLITE');
// Add the title to the linked map
linkedMap.add(ui.Label(
'2023 Kiln Scar Map in Chilundo',{
   textDecoration: 'underline',
   position: 'top-center',
   fontWeight: 'bold',
   fontSize: '25px'
}));
// Add the title to the main map
Map.add(ui.Label(
'2023 Kiln Scar Map in Chilundo',{
   textDecoration: 'underline',
   position: 'top-center',
   fontWeight: 'bold',
   fontSize: '25px'
}));
// Function to open an email in a default email client
function openEmail() {
  var email = 'herciloodorico@gmail.com';
  var subject = 'Email Subject';
  var body = 'Email Content';
  var mailtoLink = 'mailto:' + email + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
  // Open the default email client
  window.open(mailtoLink);
}
// Function to open LinkedIn profile
function openLinkedIn() {
  var linkedin = 'https://www.linkedin.com/in/hercilo-odorico-51baa6104';
  var instruction = 'To view my LinkedIn profile, please copy and paste the following URL into your browser: ' + linkedin;
  alert(instruction);
}
// Create a panel to contain the buttons
var panel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left'
  }
});
// Create a button for the email address
var emailButton = ui.Button({
  label: 'Contact Info: herciloodorico@gmail.com',
  onClick: openEmail
});
// Create a button for the LinkedIn profile
var linkedinButton = ui.Button({
  label: 'LinkedIn Profile',
  onClick: openLinkedIn
});
// Style the buttons as links
emailButton.style().set('color', 'blue');
emailButton.style().set('textDecoration', 'underline');
emailButton.style().set('fontWeight', 'bold');
emailButton.style().set('fontSize', '15px');
linkedinButton.style().set('color', 'blue');
linkedinButton.style().set('textDecoration', 'underline');
linkedinButton.style().set('fontWeight', 'bold');
linkedinButton.style().set('fontSize', '15px');
// Add the buttons to the panel
panel.add(emailButton);
panel.add(linkedinButton);
// Add the panel directly to the map
Map.add(panel);