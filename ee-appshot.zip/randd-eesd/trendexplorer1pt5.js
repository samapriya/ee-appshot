var panels = require('users/randd-eesd/dev:trends/1.5/modules/panels');
ui.root.clear();
ui.root.add(panels.splitPanel);
ui.root.add(panels.panelMain);