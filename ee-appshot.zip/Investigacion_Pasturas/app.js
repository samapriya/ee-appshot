var regi = ui.import && ui.import("regi", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -60.39957355579372,
                -29.43197110015032
              ],
              [
                -60.39957355579372,
                -29.500720891179746
              ],
              [
                -60.28147052844997,
                -29.500720891179746
              ],
              [
                -60.28147052844997,
                -29.43197110015032
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Polygon(
        [[[-60.39957355579372, -29.43197110015032],
          [-60.39957355579372, -29.500720891179746],
          [-60.28147052844997, -29.500720891179746],
          [-60.28147052844997, -29.43197110015032]]], null, false),
    parafondo = ui.import && ui.import("parafondo", "image", {
      "id": "users/Investigacion_Pasturas/Archivos_Toba/2020-01-31_Menapace_Planet"
    }) || ee.Image("users/Investigacion_Pasturas/Archivos_Toba/2020-01-31_Menapace_Planet");
//para logo
var logo = ee.Image('users/carlosnavarrochamical/Imagenes/lOGO_QGIS_INTA2')
var geo = ee.Geometry.Rectangle([[-1.084958720480591,-0.828437958991397], [1.529787373269409,2.708121923804139]])
var imagelog = logo.clip(geo)
var Norte_de_santa_fe = ee.FeatureCollection('users/carlosnavarrochamical/Archivos_vectoriales/Norte_de_Santa_Fe')
var region = ee.FeatureCollection(Norte_de_santa_fe).style({fillColor: '00000000', width: 3, color: 'orange'})
//coleccion
var label = ui.Label('Referencias', {fontSize: '25px', color: 'green', textAlign: 'center'})
var label1 = ui.Label('Azul: NDVI entre -0.15 y 0.025 (Agua en superficie, lagunas, lagos, represas)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var label2 = ui.Label('Negro: NDVI entre 0.025 y 0.2 (Sin vegetación, suelos desnudos, caminos, rutas)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var label3 = ui.Label('Blanco: NDVI entre 0.2 y 0.375 (vegetación muy poco vigorosa)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var label4 = ui.Label('Amarillo: NDVI entre 0.375 y 0.55 (vegetación poco vigorosa)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var label5 = ui.Label('Verde: NDVI entre 0.55 y 0.725 (vegetación vigorosa)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var label6 = ui.Label('Rojo: NDVI entre 0.725 y 0.9 (vegetación muy vigorosa)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var map = ui.Map()
map.style().set('cursor', 'crosshair');
// map.setOptions({mapTypeId: 'SATELLITE'})
map.setControlVisibility({layerList: true, zoomControl: false, scaleControl: false, mapTypeControl: true, fullscreenControl: false, drawingToolsControl: false })
 var ap = function(image){
    var ndvi = image.normalizedDifference(['B8', 'B4'])
    image = image.addBands(ndvi.rename('NDVI'))
    return image.clip(Norte_de_santa_fe)
  }
var coleccionbase = ee.ImageCollection('COPERNICUS/S2')
.filterBounds(Norte_de_santa_fe)
.filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
.map(ap)
// //para miniatura
// var ap = function(image){
//     var ndvi = image.normalizedDifference(['B8', 'B4'])
//     image = image.addBands(ndvi.rename('NDVI'))
//     return image.clip(Norte_de_santa_fe)
//   }
// var coleccionmini = ee.ImageCollection('COPERNICUS/S2')
// .filterBounds(Norte_de_santa_fe)
// .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
// .map(ap)
//construccion de inicio y el final 1
var inicio = ee.Image(coleccionbase.first()).date().get('year').format()
var ahora = Date.now()
var final = ee.Date(ahora).format()
var rangodefecha = ee.DateRange(inicio, ahora)
print(rangodefecha)
/////////////////////////////////////////////////////////////////////////////////
// Map.style().set('cursor', 'crosshair');
//construccion de inicio y el final 1
var inicio1 = ee.Image(coleccionbase.first()).date().get('year').format()
var ahora1 = Date.now()
var final1 = ee.Date(ahora1).format()
var rangodefecha1 = ee.DateRange(inicio1, ahora1)
map.centerObject(Norte_de_santa_fe, 8)
print(rangodefecha1)
////////////////////////////////////////////////////////
//para Dateslider 1
var primera = function (preinicio){
  var ap = function(image){
    var ndvi = image.normalizedDifference(['B8', 'B4'])
    image = image.addBands(ndvi.rename('NDVI'))
    return image.clip(Norte_de_santa_fe)
  }
  var coleccion = ee.ImageCollection('COPERNICUS/S2')
    .filterBounds(Norte_de_santa_fe)
    .filterDate(rangodefecha.start(), rangodefecha.end())
    .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
    .map(ap)
  rangodefecha.start().get('year').evaluate(function(nombre){
    var paleta = {min: -0.15, max: 0.9, bands:['NDVI'], palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}
    var capa = ui.Map.Layer(coleccion, paleta, nombre+' NDVI')
    map.layers().set(0, capa)
  })
}
var segunda = function(prefinal){
  var ap = function(image){
    var ndvi = image.normalizedDifference(['B8', 'B4'])
    image = image.addBands(ndvi.rename('NDVI'))
    return image.clip(Norte_de_santa_fe)
  }
  var coleccion = ee.ImageCollection('COPERNICUS/S2')
    .filterBounds(Norte_de_santa_fe)
    .filterDate(prefinal.start(), prefinal.end())
    .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
    .map(ap)
  prefinal.start().get('year').evaluate(function(nombre){
    var paleta = {min: -0.15, max: 0.9, bands:['NDVI'], palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}
    var capa = ui.Map.Layer(coleccion, paleta, nombre+' NDVI')
    var regi = ui.Map.Layer(region)
    map.layers().set(0, capa)
    map.layers().set(1, regi)
  })
}
//DateSlider 1
var rango = ee.DateRange(inicio, final).evaluate(function(rango){
  var slider = ui.DateSlider({
    start: rango['dates'][0],
    end: rango['dates'][1],
    value: null,
    period: 7,
    onChange: function(rango){
      rangodefecha = rango;
      segunda(rangodefecha)},
    style:{
      position: 'bottom-left',
      backgroundColor: 'orange'
    }
   })
  map.add(slider.setValue(ahora));
})
//////colorcar grafico en el mapa////////////////////
var lon = ui.Label()
    var lat = ui.Label()
    var panel = ui.Panel([lon, lat])
   map.onClick(function(r){
     lon.setValue('Longitud: '+ r.lon.toFixed(2))
     lat.setValue('Latitud: '+ r.lat.toFixed(2))
     var punto = ee.Geometry.Point(r.lon, r.lat)
     var mapaddpunto = ee.FeatureCollection(punto).style({color: 'red', pointShape: 'star', pointSize: 10})
     var puntomap = ui.Map.Layer(mapaddpunto)
     map.layers().set(2, mapaddpunto)
     //////grafico///////////////
     var ap = function(image){
     var ndvi = image.normalizedDifference(['B8', 'B4'])
     image = image.addBands(ndvi.rename('NDVI'))
     var ndwi = image.normalizedDifference(['B8', 'B11'])
    image = image.addBands(ndwi.rename('NDWI'))
    var savi = image.expression('(1+L)*((nir-red)/(nir+red+L))',{
      nir: image.select('B8'),
      red: image.select('B4'),
      L : 0.5
    })
    image = image.addBands(savi.rename('SAVI'))
     return image.clip(Norte_de_santa_fe)
     }
     var coleccion = ee.ImageCollection('COPERNICUS/S2')
     .filterBounds(Norte_de_santa_fe)
     .filterDate('2017-01-01', '2021-01-01')
     .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
     .map(ap)
     var graficondvi = ui.Chart.image.series(coleccion.select(['NDVI', 'NDWI', 'SAVI']), punto, ee.Reducer.mean(), 10)
     .setOptions({
       title: 'Grafico de NDVI para el punto seleccionado desde 2017 hasta la actualidad',
       vAhis: {title: 'NDVI, NDWI, SAVI'},
       hAxis: {title: 'Fecha', format: 'YY-MM'},
       backgroundColor: 'orange',
     })
     var panell = ui.Panel([ui.Button('Cerrar Grafico', function(iii){
       iii = panell.clear()
     }, null, {margin: '-5px 1px -5px 1px', width: '480px'}), graficondvi],
     ui.Panel.Layout.Flow('vertical'), {margin: '0px 1px 1px 1px',width: '500px', position: 'top-left'})
     map.widgets().set(2, panell)
    })
var panel = ui.Panel({
  widgets: [label, label1, label2, label3, label4, label5, label6],
  style: {
    position: 'top-right',
    width: 150,
    height: 300,
  }
})
map.add(panel)
///segundo Date slider////////////////////////////////////////////////////////////////////////////////////////
var map1 = ui.Map()
map1.style().set('cursor', 'crosshair');
// map1.setOptions({mapTypeId: 'SATELLITE'})
map1.setControlVisibility({layerList: false, zoomControl: false, scaleControl: false, mapTypeControl: true, fullscreenControl: false, drawingToolsControl: false })
var tercera = function (terinicio){
  var ap = function(image){
    var ndvi = image.normalizedDifference(['B8', 'B4'])
    image = image.addBands(ndvi.rename('NDVI'))
    return image.clip(Norte_de_santa_fe)
  }
  var coleccion = ee.ImageCollection('COPERNICUS/S2')
    .filterBounds(Norte_de_santa_fe)
    .filterDate(rangodefecha1.start(), rangodefecha1.end())
    .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
    .map(ap)
  rangodefecha1.start().get('year').evaluate(function(nombre){
    var paleta = {min: -0.15, max: 0.9, bands:['NDVI'], palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}
    var capa = ui.Map.Layer(coleccion, paleta, nombre+' NDVI')
    map1.layers().set(0, capa)
  })
}
var cuarta = function(cufinal){
  var ap = function(image){
    var ndvi = image.normalizedDifference(['B8', 'B4'])
    image = image.addBands(ndvi.rename('NDVI'))
    return image.clip(Norte_de_santa_fe)
  }
  var coleccion = ee.ImageCollection('COPERNICUS/S2')
    .filterBounds(Norte_de_santa_fe)
    .filterDate(cufinal.start(), cufinal.end())
    .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
    .map(ap)
  cufinal.start().get('year').evaluate(function(nombre){
    var paleta = {min: -0.15, max: 0.9, bands:['NDVI'], palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}
    var capa = ui.Map.Layer(coleccion, paleta, nombre+' NDVI')
    var regi = ui.Map.Layer(region)
    map1.layers().set(0, capa)
    map1.layers().set(1, regi)
  })
}
var rango = ee.DateRange(inicio1, final1).evaluate(function(rango){
  var slider = ui.DateSlider({
    start: rango['dates'][0],
    end: rango['dates'][1],
    value: null,
    period: 7,
    onChange: function(rango){
      rangodefecha1 = rango;
      cuarta(rangodefecha1)},
    style:{position: 'bottom-right',
      backgroundColor: 'orange',
    }
  })
  map1.add(slider.setValue(ahora1));
})
//////colorcar grafico en el mapa////////////////////
var lon = ui.Label()
    var lat = ui.Label()
    var panel = ui.Panel([lon, lat])
   map1.onClick(function(r){
     lon.setValue('Longitud: '+ r.lon.toFixed(2))
     lat.setValue('Latitud: '+ r.lat.toFixed(2))
     var punto = ee.Geometry.Point(r.lon, r.lat)
     var mapaddpunto = ee.FeatureCollection(punto).style({color: 'red', pointShape: 'star', pointSize: 10})
     var puntomap = ui.Map.Layer(mapaddpunto)
     map1.layers().set(2, mapaddpunto)
     //////grafico///////////////
     var ap = function(image){
     var ndvi = image.normalizedDifference(['B8', 'B4'])
     image = image.addBands(ndvi.rename('NDVI'))
     var ndwi = image.normalizedDifference(['B8', 'B11'])
    image = image.addBands(ndwi.rename('NDWI'))
    var savi = image.expression('(1+L)*((nir-red)/(nir+red+L))',{
      nir: image.select('B8'),
      red: image.select('B4'),
      L : 0.5
    })
    image = image.addBands(savi.rename('SAVI'))
     return image.clip(Norte_de_santa_fe)
     }
     var coleccion = ee.ImageCollection('COPERNICUS/S2')
     .filterBounds(Norte_de_santa_fe)
     .filterDate('2017-01-01', '2021-01-01')
     .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 1)
     .map(ap)
     var graficondvi = ui.Chart.image.series(coleccion.select(['NDVI', 'NDWI', 'SAVI']), punto, ee.Reducer.mean(), 10)
     .setOptions({
       title: 'Grafico de NDVI para el punto seleccionado desde 2017 hasta la actualidad',
       vAhis: {title: 'NDVI, NDWI, SAVI'},
       hAxis: {title: 'Fecha', format: 'YY-MM'},
       backgroundColor: 'orange',
     })
     var panell = ui.Panel([ui.Button('Cerrar Grafico', function(iii){
       iii = panell.clear()
     }, null, {margin: '-5px 1px -5px 1px', width: '480px'}), graficondvi],
     ui.Panel.Layout.Flow('vertical'), {margin: '0px 1px 1px 1px',width: '500px', position: 'top-right'})
     map1.widgets().set(2, panell)
    })
// var visparmm = {
//   min: -0.15, 
//   max: 0.9, 
//   bands:['NDVI'], 
//   palette: ['blue', 'black', 'white', 'yellow', 'green', 'red'],
//   maxFrames: 200
// }
// var thin = ui.Thumbnail({
//   image: coleccionbase, 
//   params: visparmm,
//   style:{position: 'top-right',
//     width: 300,
//     height: 300,
//   }})
// map1.add(thin)
map1.centerObject(Norte_de_santa_fe, 8)
// map.add(panel)
var split = ui.SplitPanel({
  firstPanel: map,
  secondPanel: map1,
  wipe: true
})
var log = ui.Thumbnail(imagelog)
var visparfondo = {
  bands: ['b3', 'b2', 'b1'],
  min: 400,
  max: 2000,
  region: regi,
  gamma: 1.8
}
var fondopanel = ui.Thumbnail(parafondo, visparfondo, null, {width: '300px', height: '255px'})
var panellog1 = ui.Panel({
  widgets: [log, fondopanel],
  layout: ui.Panel.Layout.Flow('horizontal'),
  style: {
    position: 'top-center',
    width: '530px',
    backgroundColor: 'orange'
  }
})
var panellog = ui.Panel({
  widgets: [panellog1,
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'red',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '20px'} ),
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'red',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ),
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'orange',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ),
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'yellow',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ), 
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'lightgreen',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ) ,
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'cyan',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ), 
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'blue',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ), 
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'violet',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'}),
  ui.Button('Ingresar a la APP', function(l){
    l = ui.root.clear()
    l = ui.root.add(split)
  }
  , null, {margin: '5px 1px 1px 1px', width: '530px', position: 'top-left'})],
  style: {
    position: 'top-center',
    width: '550px',
    backgroundColor: 'green'
  }
})
Map.setControlVisibility({layerList: true, zoomControl: false, scaleControl: false, mapTypeControl: true, fullscreenControl: false, drawingToolsControl: false })
Map.setOptions({mapTypeId: 'SATELLITE'})
// Map.add(split)
Map.add(panellog)
// ui.root.clear()
// ui.root.add(panellog)