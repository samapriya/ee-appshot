/*
Segmentador SNIC aplicado a la delimitación y caracterización de Grandes Unidades de Paisajes (GUPas) del Gran Chaco Americano
Aplica el algoritmo de segmentación, transforma a vector el resultado y calcula los valores medios de
cada una de las variables del set de datos consideradas. 
Incorpora variables biofisicas y semillas a partir de TNC, 2005
Segmentacion actualizado 8/04/2021
Juana Lopez
*/
//******************************************************************************
//    Definicion de región de análisis, límites geográficos adicionales, escala
//******************************************************************************
//https://gis.stackexchange.com/questions/270033/convert-or-add-hand-drawn-geometries-to-featurecollection-as-they-are-drawn-on-g
var L_GChaco = ee.FeatureCollection('users/euroclimacomponente2/Zonificacion/General/L_GChaco_WWF');//Limite del Gran Chaco (Fuente: WMF)
var complejos = ee.FeatureCollection('users/euroclimacomponente2/Zonificacion/General/complejos_ecosis_tnc');//Complejos Ecosistemicos TNC 2005 para establecer las semillas
var sudamerica = ee.FeatureCollection('users/volante/VARIOS/Sudamerica');
var sitios_pilotos = ee.FeatureCollection('users/euroclimacomponente2/Zonificacion/General/sitiosPilotos'); //Sitios pilotos de la Componente 1 del Proyecto
// Acceso al set de datos (todas las variables)
var standOrig = ee.Image('users/euroclimacomponente2/Zonificacion/Stack/set_datos_escal_0_1_v2');//Variables escaladas al intervalo [0, 1]
var stackOrig = ee.Image('users/euroclimacomponente2/Zonificacion/Stack/set_datos_v2');//Variables con los valores originales
//var semillas = ee.FeatureCollection('users/galarzamartininta/Centroides_TNC');//Centroides de los Complejos Ecosistemicos (TNC, 2005)
var semillas = ee.FeatureCollection('users/lopezjuana/Chaco/semillas_con_agreg');//Centroides de los Complejos Ecosistemicos (TNC, 2005) con semillas agregadas
var scale = 0;
var version = 'V3'
//******************************************************************************
//                      Definiciones de estilos
//******************************************************************************
var colors = {'cyan': '#24C1E0', 'transparent': '#11ffee00', 'gray': '#F8F9FA'};
var TITLE_STYLE = {
  fontSize: '18px',
  padding: '8px',
  color: 'black',
  fontWeight: 'bold',
  backgroundColor: colors.transparent,
};
var SUBTITLE_STYLE = {
  fontSize: '14px',
  fontWeight: '80',
  color: 'black',
  padding: '2px',
  backgroundColor: colors.transparent,
};
var PARAGRAPH_STYLE = {
  fontSize: '14px',
  fontWeight: '50',
  color: 'black',
  padding: '8px',
  backgroundColor: colors.transparent,
};
var SUBPARAGRAPH_STYLE = {
  fontSize: '13px',
  fontWeight: '50',
  color: 'black',
  padding: '2px',
  backgroundColor: colors.transparent,
};
var LABEL_STYLE = {
  fontWeight: '50',
  textAlign: 'center',
  fontSize: '11px',
  backgroundColor: colors.transparent,
};
var THUMBNAIL_WIDTH = 128;
var BORDER_STYLE = '4px solid rgba(97, 97, 97, 0.05)';
//Paleta de colores asignados a los sitios pilotos
var colorTable = ee.Dictionary({
  'San Francisco': 'e10f2b',
  'Santo Domingo': '263bf4',//1 Santo Domingo
  'Algarrobales': '3ef426',//2 Algarrobales
  'Salta Forestal':'f9ab2c',//3 Salta Forestal'
  'Zona Norte':'63fced',//4 Salta Norte
  'Zona Norte Criollos': '63fced',
  'Marina':'8a30ea',//5 Marina
  'Ismael Pino':'3b9e2a',//6 Ismael Pino
  'Agua de la Paloma':'abb7d6',//7 Agua de la Paloma
  'Campo Cirilo Arriba': '9da64b',
  'Lote Cirilo Abajo':'9da64b',//8 Cirilo
  'Colonia':'6abebd',//9 Colonia
  'Campo Diego Maldonado':'d334eb',//10 Maldonado
  'El Escondido':'863b08',//11 El Escondido
  'La Iguana':'eed9dd',//12 La Iguana
  'Pozo Grande':'ffff00',//13 Pozo Grande
  'Fernandez Irala':'d2e9e0',//14 Fernández Irala
});
//Paleta para leyenda de sitios pilotos
var palette =['e10f2b',// 0 San Francisco
              '263bf4',//1 Santo Domingo
              '3ef426',//2 Algarrobales
              'f9ab2c',//3 Salta Forestal'
              '63fced',//4 Salta Norte
              '8a30ea',//5 Marina
              '3b9e2a',//6 Ismael Pino
              'abb7d6',//7 Agua de la Paloma
              '9da64b',//8 Cirilo
              '6abebd',//9 Colonia
              'd334eb',//10 Maldonado
              '863b08',//11 El Escondido
              'eed9dd',//12 La Iguana
              'ffff00',//13 Pozo Grande
              'd2e9e0',//14 Fernández Irala
];
//******************************************************************************
//                      Definición de Paneles
//******************************************************************************
ui.root.clear();
var mapPanel = ui.Map();
mapPanel.setControlVisibility({layerList: true, zoomControl: false, scaleControl: false, mapTypeControl: true, fullscreenControl: true, drawingToolsControl: true})
mapPanel.setCenter(-64,-27.5,8).setOptions('HYBRID').style().set('cursor', 'crosshair');
// Use un SplitPanel para que sea posible cambiar el tamaño de los dos paneles.
var mainPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical', true),
  style: {
    stretch: 'horizontal',
    height: '60%',
    width: '500px',
    backgroundColor: colors.gray,
    border: BORDER_STYLE,
    position: 'top-left'
  }
});
var splitPanel = ui.SplitPanel({
  firstPanel: mainPanel,
  secondPanel: mapPanel,
  orientation: 'horizontal',
  style: {stretch: 'both'}
});
ui.root.widgets().reset([splitPanel]);
//Crear un panel de avisos
var avisosPanel = new ui.Panel([], ui.Panel.Layout.Flow('horizontal', true),{width:'600px', height:'60px', color:'black',backgroundColor:'white', position: 'bottom-left', shown: false});
mapPanel.add(avisosPanel);
var descargasPanel = new ui.Panel([], ui.Panel.Layout.Flow('vertical', true), {shown: false});
mapPanel.add(descargasPanel);
var inspecPanel = ui.Panel([], ui.Panel.Layout.Flow('vertical', true),{width:'450px', height:'150px', color:'black',backgroundColor:'white', position: 'bottom-center', shown: false});
mapPanel.add(inspecPanel);
//******************************************************************************
//                      Seccion para generar interfaz de usuario
//******************************************************************************
var dicRegion = {
  'Dibujar Area': 'si',
  'Gran Chaco':[]
};
var dicSemillas = {
  'Semillas regulares':['semilla1'],
  'Semilla definidas desde cetroides de Complejos Ecosistémicos':['semilla2'],
  'Semillas definidas por el usuario':['semilla3']
};
var dicEscala = {
  'Escala 500 m':['500'],
  'Escala 1000 m':['1000'],
  'Escala 1500 m':['1500']
};
var variables = {
  banda: ['b01','b02','b03','b04','b05','b06','b07','b08', 'b09','b10','b11','b12','b13','b14','b15','b16','b17a','b17b',
    'b18','b19','b20','b21','b22','b23','b24','b25','b26','b27','b28','b29','b30','b31','b32','b33','b34','b35','b36','b37'],
  descripcion: ['B01- Distancia a cursos de agua','B02- Distancia a cuerpos de agua permanente','B03- Evapotranspiración promedio anual','B04- Precipitación promedio anual','B05- Índice de severidad de la sequía','B06- Temperatura mínima promedio',
    'B07- Temperatura máxima promedio','B08- Albedo','B09- Capacidad de intercambio de cationes','B10- Fragmentos gruesos','B11- Nitrogeno','B12- Arcilla','B13- Densidad de carbono orgánico',
    'B14- Stock de carbono orgánico','B15- Contenido de carbono orgánico','B16- Índice de pH en solución de agua','B17a- Arena','B17b- Limo','B18- Densidad aparente','B19- Riqueza del paisaje',
    'B20- Fragmentacion del paisaje','B21- Dominancia del paisaje','B22- Diversidad del paisaje','B23- Índice de provisión de servicios ecosistémicos','B24- Elevación','B25- Diversidad topografica',
    'B26- Distancia a instituciones','B27- Distancia a áreas protegidas','B28- Poblacion','B29- Impacto humano','B30- Distancia a uso agropecuario','B31- Distancia a uso forestal',
    'B32- Distancia a centros educativos','B33- Distancia a centros de salud','B34- Accesibilidad','B35- Distancia a comunidades originales','B36- Distancia a caminos','B37- Crecimiento poblacional'],
  seleccion: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
};
// Contenedor de variables
// Contenedor para selección y ponderacion de variables
var valLabels = {};
var valCheckbox = {};
var mediaLabel = {};
//Lista de variables y lista de pesos para correr el script
var listaVar = ee.List([]);
var listaPesos = ee.List([]);
//Activacion de banderas para ejecucion del proceso
var banderaArea = 0;
var banderaVari = 0;
var banderaSemi = 0;
var banderaEsca = 0;
var banderaPond = 0;
var banderaError = 0;
var tipoSemilla = 0;
var panelVar = 0;
var panelPond = 0;
var panelDesc = 0;
var panelFinSem = 0;
var mensaje = 'Aviso';
var areaInteres = ee.FeatureCollection([]);
var seedInput = ee.FeatureCollection([]);
var uniPaisajes = ee.Image([]);
var GUPasVector = ee.FeatureCollection([]);
//******************************************************************************
//                      Seccion de funciones
//******************************************************************************
//Crear un panel para contener las Bandas
function addSelVar(){
  //mapPanel.remove(panel);
  variables.seleccion = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
  var panel = ui.Panel([], ui.Panel.Layout.Flow('vertical', true),{width:'400px', height:'600px', color:'black',backgroundColor:'white'});
  var addVarLabel = ui.Label('Seleccione las variables, vea su descripción en Fichas de variables',  {'height':'30px','fontSize':'14px', 'fontWeight': 'bold', 'padding':'0px', 'margin':'1px'});
  panel.add(addVarLabel);
  var urlClick = ui.Label({
    value: 'Fichas de variables',
    style: {fontSize: "14px", backgroundColor:'00000000'},
    targetUrl: 'https://drive.google.com/file/d/1PB7z47IUXuRqX-rWHWHrL3By3RFLvhrT/view'
  });
  panel.add(urlClick);
  var addSelVarSubPanel = ui.Panel([], ui.Panel.Layout.Flow('vertical', true),{maxHeight:'450px',position:'bottom-center'});
  for (var i = 0; i < variables.banda.length; i++){
    //Agregar Checkbox para seleccionar las variables
    var varCheck = ui.Checkbox(variables.descripcion[i],{'height':'100px','fontSize':'8px', 'padding':'0px', 'margin':'1px'}).setValue(false);
    valCheckbox[variables.descripcion[i]] =  varCheck;
    addSelVarSubPanel.add(varCheck);
  }
  function stackearBandas(){
    listaVar = ee.List([]);
    for (var i = 0; i < variables.banda.length; i++){
      if(valCheckbox[variables.descripcion[i]].getValue()===true){
        listaVar = ee.List(listaVar).add(variables.banda[i]);
        variables.seleccion[i] = 1;
      }
    }
  }
  var aceptarButton = ui.Button({
    label: 'Aceptar',
    onClick: function(){
      stackearBandas();
      if(listaVar.length().getInfo() < 1){
        mensaje = 'Seleccione 1 o más variables';
        ee.String(mensaje).evaluate(advertir);
        banderaVari = 0;
      }
      else{
        banderaVari = 1;
        avisosPanel.style().set({shown: false});
      }
      mapPanel.remove(panel);
      banderaPond = 0;
      panelVar = 0;
    }
  });
  panel.add(addSelVarSubPanel);
  panel.add(aceptarButton);
  if(panelVar === 0){
    mapPanel.add(panel);
    panelVar = 1;
  }
}
//Función para mostrar mensajes de advertencia o información.
function advertir(mensaje) {
  avisosPanel.clear();
  var avisoLabel = ui.Label({value: 'Aviso: ' + mensaje, style: {fontWeight: 'bold', fontSize: '12px'}});
  var aceptarButton = ui.Button({
    label: 'OK',
    onClick: function(){
      avisosPanel.style().set({shown: false});
    }
  });
  avisosPanel.add(avisoLabel);
  avisosPanel.add(aceptarButton);
  avisosPanel.style().set({shown: true});
}
// Función para consultar los valores medios de las variables seleccionadas para realizar la segmentación.
function addInspect(){
  inspecPanel.clear();
  var inspecLabel = ui.Label('Clic para inspeccionar los valores medios de las variables.',{'height':'16px','fontSize':'12px', 'fontWeight': 'bold', 'padding':'1px', 'margin':'1px'});
  inspecPanel.add(inspecLabel);
  for (var i = 0; i < variables.banda.length;i++){
    if(variables.seleccion[i] === 1){
      var insLabel =  ui.Label(variables.descripcion[i],{'width':'280px','fontSize':'12px', 'padding':'0px', 'margin':'1px'});
      mediaLabel[variables.descripcion[i]] =  ui.Label('Clic en la GUPa',{'fontSize':'11px', 'padding':'0px', 'margin':'1px'});
      var inspecSubPanel = ui.Panel([insLabel, mediaLabel[variables.descripcion[i]]], ui.Panel.Layout.Flow('horizontal'));
      inspecPanel.add(inspecSubPanel);
    }
  }
  var aceptarButton = ui.Button({
    label: 'Aceptar',
    onClick: function(){
      avisosPanel.style().set({shown: false});
      inspecPanel.style().set({shown: false});
    }
  });
  inspecPanel.add(aceptarButton);
  inspecPanel.style().set({shown: true});
}
// function to update the inspect section once map is clicked
function fetchValues(lonlat){
  var point = ee.Geometry.Point(lonlat.lon, lonlat.lat);
  for (var i = 0; i < variables.banda.length;i++){
    if(variables.seleccion[i] === 1){
      mediaLabel[variables.descripcion[i]].setValue('Actualizando los valores');
    }
  }
  var limiteAOI = areaInteres.first().geometry();
  var condition2 = limiteAOI.contains(point);
  if(condition2.getInfo() === true){
    var pointSampled = GUPasVector.filterBounds(point).first().evaluate(updateValues);
  }
  else{
    for (i = 0; i < variables.banda.length;i++){
      if(variables.seleccion[i] === 1){
         mediaLabel[variables.descripcion[i]].setValue('Sin datos');
      }
    }
  }
}
function updateValues(feature){
  for (var i = 0; i < variables.banda.length;i++){
    if(variables.seleccion[i] === 1){
      var value = parseFloat(feature.properties[variables.banda[i]].toFixed(2));
      mediaLabel[variables.descripcion[i]].setValue(value);
    }
  }
}
//Calcular los pesos de las variables de acuerdo a la importancia asignada.
function addPonderacion(){
  panelPond = 1;
  var panel = ui.Panel([], ui.Panel.Layout.Flow('vertical', true),{width:'400px', height:'400px', color:'black',backgroundColor:'white'});
  var ponderLabel = ui.Label('Ingrese la importancia a las variables [1 mayor importancia,2,3, ....',{'height':'16px','fontSize':'12px', 'fontWeight': 'bold', 'padding':'1px', 'margin':'1px'});
  panel.add(ponderLabel);
  for (var i = 0; i < variables.banda.length;i++){
    if(variables.seleccion[i] === 1){
      var insLabel =  ui.Label(variables.descripcion[i],{'width':'140px','fontSize':'12px', 'padding':'0px', 'margin':'1px'});
      valLabels[variables.descripcion[i]] =  ui.Textbox({value: '1'}); 
      var ponderSubPanel = ui.Panel([insLabel, valLabels[variables.descripcion[i]]], ui.Panel.Layout.Flow('horizontal'));
      panel.add(ponderSubPanel);
    }
  }
  function calcularPesos(){
    var sumaImport = 0;
    var nroVari = listaVar.length().getInfo();
    print(nroVari, 'n');
    for (var i = 0; i < variables.banda.length;i++){
      if(variables.seleccion[i] === 1){
        var valor = ee.Number.parse((valLabels[variables.descripcion[i]].getValue()), 10);
        print(valor, 'valor');
        sumaImport = ee.Number(sumaImport).add(valor);
      }
    }
    print(sumaImport, 'suma');
    for (i = 0; i < variables.banda.length;i++){
      if(variables.seleccion[i] === 1){
        var peso = (ee.Number(nroVari).add(1).subtract(ee.Number.parse(valLabels[variables.descripcion[i]].getValue(),10))).divide(sumaImport);
        listaPesos = listaPesos.add(peso);
      }
    }
  }
  var aceptarButton = ui.Button({
    label: 'Aceptar',
    onClick: function(){
      calcularPesos();
      print(listaPesos, 'lista_pesos');
      banderaPond = 1;
      avisosPanel.style().set({shown: false});
      panelPond = 0;
      mapPanel.remove(panel);
    }
  });
  panel.add(aceptarButton);
  mapPanel.add(panel);
}
//throw ('stop')
var segmentar = function(){
  removeLayer('Region');
  var stack = stackOrig.select(listaVar);
  var stand = standOrig.select(listaVar);
  avisosPanel.style().set({shown: false});
  inspecPanel.style().set({shown: false});
  descargasPanel.style().set({shown: false});
  //Ponderacion de variables
  var stand_ponderadas = ee.Image([]);
  for (var i=0;i<listaVar.length().getInfo();i++){
    var pesovar = ee.Image.constant(listaPesos.get(i));
    var banda = stand.select([listaVar.get(i)]).multiply(pesovar);
    stand_ponderadas = stand_ponderadas.addBands([banda]);
  }
  if (tipoSemilla !== 1){
    var seed_SNIC = ee.Image().toByte().paint(seedInput,1).unmask();
    var snic = ee.Algorithms.Image.Segmentation.SNIC({
      image: stand_ponderadas, 
      size:128,
      compactness: 0,
      connectivity: 4,
      neighborhoodSize:256,
      seeds: seed_SNIC,
    }).reproject('EPSG:4326', null, scale);
  }
  else {snic = ee.Algorithms.Image.Segmentation.SNIC({
      image: stand_ponderadas, 
      size:128,
      compactness: 0,
      connectivity: 4,
      neighborhoodSize:256,
      }).reproject('EPSG:4326', null, scale);
  }
  print(snic);
  var snic_clip = snic.clip(areaInteres);
  return snic_clip;
};
  //Visualización de resultados finales
var imprimir = function(uniPaisajes, areaInteres){
  avisosPanel.style().set({shown: false});
  //mapPanel.clear();
  removeLayer('Semillas');
  removeLayer('Sitios_pilotos');
  removeLayer('Region');
  removeLayer('Limite Gran Chaco');
  if (tipoSemilla == 1){
    var semillasLayer  = ui.Map.Layer(uniPaisajes.select('seeds').focal_max(3), {}, 'Semillas', false);
  }
  else{semillasLayer= ui.Map.Layer(seedInput,{},'Semillas', true);
  }
  //Agregar sitios pilotos
  var outline_sit_pilotos = sitios_pilotos
  .map(function (feature) {
    return feature.set('style', {
      fillColor: colorTable.get(feature.get('Nombre'), '777777'),
      width: 1
    });
  })
  .style({
    styleProperty: 'style',
  });
  var sitiosPiloLayer = ui.Map.Layer(outline_sit_pilotos, {}, 'Sitios_pilotos'); 
  var datosLayer = ui.Map.Layer(standOrig, {}, 'Set de datos', false);
  var blank = ee.Image(0).mask(0);
  var outline_Sud = blank.paint(sudamerica, 'ff001d', 3);
  var outline_complejos = blank.paint(complejos, 'ff001d', 2);
  var outline_Gch = blank.paint(L_GChaco, 'ff001d', 2);
  var visParp = {'palette':'black','opacity': 1};
  //var visGupas = {'palette':'black','opacity': 0.8};
  var GChacoLayer = ui.Map.Layer(outline_Gch, visParp, "Limite Gran Chaco", true);
  var SudameLayer  = ui.Map.Layer(outline_Sud, visParp, "Limite Sudamérica", false);
  var CompEcosLayer = ui.Map.Layer(outline_complejos, visParp, "Complejos ecosistemicos TNC", false);
  var GUPasLayer  = ui.Map.Layer(uniPaisajes.randomVisualizer(), {}, 'Grandes Unidades de Paisajes');
  mapPanel.layers().add(GChacoLayer);
  mapPanel.layers().add(datosLayer);
  mapPanel.layers().add(GUPasLayer);
  mapPanel.layers().add(SudameLayer);
  mapPanel.layers().add(CompEcosLayer);
  mapPanel.layers().add(semillasLayer);
  mapPanel.layers().add(sitiosPiloLayer);
}
var exportar = function(uniPaisajes){
  //Exportar el resultado de la segmentación como imagen y como vector con sus valores medios
    //Vectorización de los cluster a escala definida
  avisosPanel.style().set({shown: false});
  descargasPanel.clear();
  var GUPasVec = uniPaisajes.reduceToVectors({
    reducer:ee.Reducer.mean(),
    geometry:areaInteres,
    scale:scale,
    maxPixels:1e12,
    bestEffort: true,
    tileScale: 4,
  });
    // Obtiene un nuevo vector con los valores medios de cada una de las variables originales.
  var GUPasVectorInfo = stackOrig.reduceRegions({
    collection: GUPasVec,
    reducer: ee.Reducer.mean(),
    scale: scale,
  });
  function downloadGUPas() { 
    var downloadArgs = {
      format: 'kml',
      filename: 'GUPAS_'+ version + '_e' +scale,
    };
    var url = GUPasVectorInfo.getDownloadURL(downloadArgs);
    print(url);
    urlLabel.setUrl(url);
    urlLabel.style().set({shown: true});
  }
  // Add UI elements to the Map.
  var downloadButton = ui.Button('Descargar GUPas', downloadGUPas);
  var urlLabel = ui.Label('Descargar', {shown: false});
  var cerrarButton = ui.Button({
    label: 'Cerrar',
    onClick: function(){
      descargasPanel.style().set({shown: false});
    }
  });
  descargasPanel.add(downloadButton);
  descargasPanel.add(urlLabel);
  descargasPanel.add(cerrarButton);
  descargasPanel.style().set({shown: true});
  return GUPasVectorInfo;
};
//Función para remover una layer
var removeLayer = function(name) {
  var layers = mapPanel.layers()
  // list of layers names
  var names = []
  layers.forEach(function(lay) {
    var lay_name = lay.getName()
    names.push(lay_name)
  })
  // get index
  var index = names.indexOf(name)
  if (index > -1) {
    // if name in names
    var layer = layers.get(index)
    mapPanel.remove(layer)
  } else {
    print('Layer '+name+' not found')
  }
}
// function to initialize the application
function init(){
  //Mostrar el límite del Gran Chaco y los sitios pilotos como referencia
  var visParp1 = {'palette':'black','opacity': 1};
  var blank = ee.Image(0).mask(0);
  var outline_Gch = blank.paint(L_GChaco, 'ff001d', 2);
  //var outline_sit_pilotos = blank.paint(sitios_pilotos, 'aa001d', 3);
  var GChacoLayer = ui.Map.Layer(outline_Gch, visParp1, "Limite Gran Chaco", true);
  //Asignar paleta a los sitios pilotos
  var outline_sit_pilotos = sitios_pilotos
  .map(function (feature) {
    return feature.set('style', {
      fillColor: colorTable.get(feature.get('Nombre'), '777777'),
      width: 1
    });
  })
  .style({
    styleProperty: 'style',
  });
 var sitiosPiloLayer = ui.Map.Layer(outline_sit_pilotos, {}, 'Sitios_pilotos'); 
 //var sitiosPiloLayer = ui.Map.Layer(outline_sit_pilotos, visParp1, 'Sitios_pilotos');
  mapPanel.layers().add(GChacoLayer);
  mapPanel.layers().add(sitiosPiloLayer);
  //Agregar elementos a los paneles
  // Añadir el logo y el título de la APP
  /*
  var kk = ui.Chart(
      [
        ['<img src=https://user-images.githubusercontent.com/9141391/112570076-22b00700-8dc4-11eb-9487-cd6dc278a310.PNG width=400px>']
      ],
      'Table', {allowHtml: true,padding:'0 0 0 0', margin:'0 0 0 0', minHeight: '200px' });
  //var titlePanel = ui.Panel([kk], 'flow', {padding:'0 0 0 0', margin:'0 0 0 0' ,width: '460px', backgroundColor: 'white'});
  */
  var table = ui.Chart(
    [
    ['<img src=https://user-images.githubusercontent.com/9141391/112570076-22b00700-8dc4-11eb-9487-cd6dc278a310.PNG width=450px height=175px>']
  ],
  'Table', {allowHtml: true});
  var titlePanel = ui.Panel([table], 'flow', {width: '500px', height:'300px', padding: '0 0 0 0', margin: '0 0 0 0'});
  mainPanel.insert(0, titlePanel);
  var titleLabel = ui.Label('Proyecto Euroclima + Vivir y Producir en el bosque Chaqueño', TITLE_STYLE);
  // añadir la descripcion de la app
  var descriptionText =
    'Esta herramienta permite obtener Unidades de Paisaje del Gran Chaco Americano a partir de un set de variables '+
    'biofísicas, socio-económicas y político institucionales, a diferentes escalas utilizando algoritmos de segmentación.'
  var descriptionLabel = ui.Label(descriptionText, PARAGRAPH_STYLE);
  var firstSubTitle_text = '1) Seleccionde la Region de Interes';
  var firstSubTitle = ui.Label(firstSubTitle_text, SUBTITLE_STYLE);
  var firstSubParagraph_text = 'Seleccione el área del Gran Chaco o dibuje su Región de interés (ROI) en el mapa.';
  var firstSubParagraph = ui.Label(firstSubParagraph_text, SUBPARAGRAPH_STYLE);
  //Agregar la leyenda de los sitios pilotos
  // Create a legend
  var labels = ['San Francisco','Santo Domingo', 'Algarrobales', 'Salta Forestal', 'Salta Norte', 'Marina', 'Ismael Pino', 
              'Agua de la Paloma', 'Cirilo', 'Colonia', 'Maldonado', 'El Escondido', 'La Iguana', 'Pozo Grande', 'Fernández Irala'];
  var add_legend = function(title, lbl, pal) {
    var legend = ui.Panel({style: {position: 'bottom-right'}}), entry;
    legend.add(ui.Label({value: title, style: { fontWeight: 'bold', fontSize: '18px', margin: '0 0 4px 0', padding: '0px' } }));
    for (var x = 0; x < lbl.length; x++){
      entry = [ ui.Label({style:{color: pal[x], border:'1px solid black', margin: '0 0 4px 0'}, value: '██'}),
        ui.Label({ value: labels[x], style: { margin: '0 0 4px 4px' } }) ];
      legend.add(ui.Panel(entry, ui.Panel.Layout.Flow('horizontal')));
    } 
    mapPanel.add(legend);
  };
  add_legend('Sitios Pilotos', labels, palette);
  //Función para evaluar área
  function validarArea(limite) {
    var limiteAOI = ee.FeatureCollection(limite).first().geometry();
    var condition3 = L_GChaco.first().geometry().contains(limiteAOI);
    if(condition3.getInfo() === true){
      banderaArea = 1;
      mapPanel.drawingTools().clear();
      var visParp1 = {'palette':'black','opacity': 1};
      var blank = ee.Image(0).mask(0);
      var outline_AOI = blank.paint(areaInteres, 'ff001d', 2);
      var AOILayer = ui.Map.Layer(outline_AOI, visParp1, 'Region', true);
      mapPanel.layers().add(AOILayer);
      //select.style().set('color', 'blue');
      //select.style().set({border: '5px solid darkgray', });
      //print(select.style(), 'esti1');
    }
    else{
      mensaje = 'El área de interés debe estar contenida en el Gran Chaco';
      ee.String(mensaje).evaluate(advertir);
      banderaArea = 0;
    }
  }
  //Seleccionar región
  var select = ui.Select({
    items: Object.keys(dicRegion),
    placeholder: 'Seleccione Región',
    onChange:function(selection) {
      select.style().set('color', 'black');
      select.style().set({border: '1px', });
      mapPanel.drawingTools().clear();
      removeLayer('Region');
      if(dicRegion[selection][0]=='s'){
        mapPanel.drawingTools().setLinked(false);
        // Limite los modos de dibujo a poligonos.
        mapPanel.drawingTools().setDrawModes(['polygon']);
        // Agregue una capa vacía para sostener el poligono dibujado.
        mapPanel.drawingTools().addLayer([]);
        // Establecer el tipo de geometría para ser poligono.
        mapPanel.drawingTools().setShape('polygon');
        // Ingrese al modo de dibujo.
        mapPanel.drawingTools().draw();
        mapPanel.drawingTools().onDraw(function (geometry) {
          // Haz algo con la geometría
          var AOI = mapPanel.drawingTools().toFeatureCollection(0);
          mapPanel.centerObject(AOI);
          mapPanel.drawingTools().stop();
          mapPanel.drawingTools().layers().forEach(function(layer) {
            layer.setShown(true);
          });
          areaInteres = AOI;
          areaInteres.evaluate(validarArea);
        });
      } else{
          areaInteres = L_GChaco;
          banderaArea = 1;
      }
    }
  });
  var secondSubParagraph_text = '2) Seleccione las variables a utilizar en la zonificación.';
  var secondSubParagraph = ui.Label(secondSubParagraph_text, SUBPARAGRAPH_STYLE);
  //Agregar botón de selección de variables, mostrar panel de variables.
  var selectBandButton = ui.Button({
    label: 'Seleccione variables',
    onClick: function(img){
      //selectBandButton.setDisabled(true);
      addSelVar();
    }
  });
  var thirdSubTitle_text = '3) Seleccione las semillas';
  var thirdSubTitle = ui.Label(thirdSubTitle_text, SUBTITLE_STYLE); 
  //Agregar desplegable para seleccionar la semilla a utilizar
  var selectSemilla = ui.Select({
    items: Object.keys(dicSemillas),
    placeholder: 'Seleccione Semilla',
    onChange:function(selection) {
      //mapPanel.drawingTools().clear();
      removeLayer('Semillas');
      seedInput = ee.FeatureCollection([]);
      if(dicSemillas[selection][0]=='semilla3'){
        var finalizarSemillas = ui.Button({
          label: 'Finalizar semillas', 
          style: {position: 'top-center'},
          onClick:function(){
            //mapPanel.drawingTools().stop();
            var seedTemp = mapPanel.drawingTools().toFeatureCollection(0);
            var numSemi = ee.Number.parse(seedTemp.size(),10).getInfo();
            if(numSemi > 1){
              var limiteAOI = areaInteres.first().geometry();
              var condition1 = limiteAOI.contains(seedTemp);
              if(condition1.getInfo() === true){
                tipoSemilla = 3;
                banderaSemi = 1;
                mapPanel.remove(finalizarSemillas);
                mapPanel.drawingTools().stop();
                mapPanel.drawingTools().clear();
                seedInput = seedTemp;
                var semillasLayer  = ui.Map.Layer(seedInput,{},'Semillas', true);
                mapPanel.layers().add(semillasLayer);
                panelFinSem = 0;
                avisosPanel.style().set({shown: false});
                //Mapear semillas de usuario
              }
              else{
                mensaje = 'Desplace las semillas al área de interés';
                ee.String(mensaje).evaluate(advertir);
                banderaSemi = 0;
              }
            }
            else{
              mensaje = 'Las semillas deben ser 2 o más, agréguelas con el marcador y haga clic en "Finalizar semillas"';
              ee.String(mensaje).evaluate(advertir);
              banderaSemi = 0;
            }
          }
        });
        if(panelFinSem === 0){
          mapPanel.add(finalizarSemillas);
          panelFinSem = 1;
          mapPanel.drawingTools().clear();
        }
        mapPanel.drawingTools().setLinked(false);
        mapPanel.drawingTools().setDrawModes(['point']);
        //Agregue una capa vacía para sostener el punto dibujado.
        mapPanel.drawingTools().addLayer([]);
        // Establecer el tipo de geometría para ser punto.
        mapPanel.drawingTools().setShape('point');
        // Ingrese al modo de dibujo.
        //mapPanel.centerObject(areaInteres, 8);
        mapPanel.drawingTools().draw();
        mapPanel.drawingTools().onDraw(function (geometry) {
          // Haz algo con la geometría
          var semillasUser = mapPanel.drawingTools().toFeatureCollection(0);
          //mapPanel.centerObject(semillasUser, 8);
          //mapPanel.drawingTools().stop();
          mapPanel.drawingTools().layers().forEach(function(layer) {
            layer.setShown(true);
          });
        });
        } else if(dicSemillas[selection][0]==='semilla2'){
                  seedInput = semillas;
                  tipoSemilla = 2;
                  banderaSemi = 1;
                  print(seedInput, 'SemillaTNC');
                  var semillasLayer  = ui.Map.Layer(seedInput,{},'Semillas', true);
                  mapPanel.layers().add(semillasLayer);
                  //Mapear semillas TNC
                }
                else {tipoSemilla = 1;
                  mensaje = 'Las semillas se definen en el proceso de segmentación'
                  ee.String(mensaje).evaluate(advertir);
                  banderaSemi = 1;
                  //mostrar mensaje semillas definidas durante la segmentación
                }
                print(seedInput, 'control');
    }
  });
  //Agregar selector de escala
  var fourthSubTitle_text = '4) Seleccione las escalas';
  var fourthSubTitle = ui.Label(fourthSubTitle_text, SUBTITLE_STYLE); 
  var selectEscala = ui.Select({
    items: Object.keys(dicEscala), 
    placeholder:'Seleccione escala',
    onChange: function(escala){
      if(dicEscala[escala][0]==='500'){
        scale = 500;
      }else if(dicEscala[escala][0]==='1000'){
        scale = 1000;
        }else scale = 1500;
      print(scale, 'scale');
      banderaEsca = 1;
    }
  });
  //Agregar panel de ponderación
  var fifthSubTitle_text = '5) Establece un ranking de importancia de las variables';
  var fifthSubTitle = ui.Label(fifthSubTitle_text, SUBTITLE_STYLE);
    //Agregar botón de selección de variables, mostrar panel de variables.
  var ingresePondButton = ui.Button({
    label: 'Establece orden',
    onClick: function(){
      if(panelPond === 0){
        if(banderaVari===1){
          addPonderacion();
        }
        else{
          mensaje = 'Seleccione las variables';
          ee.String(mensaje).evaluate(advertir);
        }
        }
      }
  });
  //Agregar botón para correr el script
  //************Agregar mensaje que avise que aún no se definió algún parámetro
  var zonificarButton = ui.Button({
    label: 'Zonificar',
    onClick:function(){
      areaInteres.evaluate(validarArea);
      print(banderaArea, 'area');
      print(banderaVari, 'vari');
      print(banderaSemi, 'semi');
      if(banderaArea == 1){
        if(banderaVari == 1){
          if(banderaSemi == 1){
            if(banderaEsca == 1){
              if(banderaPond == 1){
                uniPaisajes= segmentar();
                imprimir(uniPaisajes);
                GUPasVector = exportar(uniPaisajes);
                addInspect();
                mapPanel.onClick(fetchValues);
                banderaError = 1;
              }
              else mensaje = 'Complete la importancia de las variables';
              }
            else mensaje = 'Seleccione la escala de zonificación';
          }
          else mensaje = 'Seleccione las semillas';
        }
        else mensaje = 'Seleccione las variables';
      }
      else mensaje = 'Establezca el área de interés';
      if(banderaError === 0){
        ee.String(mensaje).evaluate(advertir);
      }
    }
  });
  var botonreinicio = ui.Button({
    label: 'Reset!',
    onClick: function(i) {
      mapPanel.clear();
      mainPanel.clear();
      avisosPanel = new ui.Panel([], ui.Panel.Layout.Flow('horizontal', true),{width:'600px', height:'60px', color:'black',backgroundColor:'white', position: 'bottom-left', shown: false});
      mapPanel.add(avisosPanel);
      descargasPanel = new ui.Panel([], ui.Panel.Layout.Flow('vertical', true), {shown: false});
      mapPanel.add(descargasPanel);
      inspecPanel = ui.Panel([], ui.Panel.Layout.Flow('vertical', true),{width:'450px', height:'150px', color:'black',backgroundColor:'white', position: 'bottom-center', shown: false});
      mapPanel.add(inspecPanel);
      mapPanel.drawingTools().clear();
      mapPanel.setControlVisibility({layerList: true, zoomControl: false, scaleControl: false, mapTypeControl: true, fullscreenControl: true, drawingToolsControl: true});
      mapPanel.setCenter(-64,-27.5,8).setOptions('HYBRID').style().set('cursor', 'crosshair');
      // Contenedor para selección y ponderacion de variables
      valLabels = {};
      valCheckbox = {};
      var mediaLabel = {};
      variables.seleccion = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
      //Lista de variables y lista de pesos para correr el script
      listaVar = ee.List([]);
      listaPesos = ee.List([]);
      //Activacion de banderas para ejecucion del proceso
      banderaArea = 0;
      banderaVari = 0;
      banderaSemi = 0;
      banderaEsca = 0;
      banderaPond = 0;
      tipoSemilla = 0;
      banderaError = 0;
      panelVar = 0;
      panelPond = 0;
      panelDesc = 0;
      panelFinSem = 0;
      areaInteres = ee.FeatureCollection([]);
      seedInput = ee.FeatureCollection([]);
      uniPaisajes = ee.Image([]);
      GUPasVector = ee.FeatureCollection([]);
      init();
    }
  });
  mainPanel.add(titleLabel);
  //mainPanel.add(titlePanel);
  //mainPanel.add(kk);
  mainPanel.add(descriptionLabel);
  mainPanel.add(firstSubTitle);
  mainPanel.add(firstSubParagraph);
  mainPanel.add(select);
  var paso1Style = select.style();
  print(paso1Style, 'estilo');
  mainPanel.add(secondSubParagraph);
  mainPanel.add(selectBandButton);
  mainPanel.add(thirdSubTitle);
  mainPanel.add(selectSemilla);
  mainPanel.add(fourthSubTitle);
  mainPanel.add(selectEscala);
  mainPanel.add(fifthSubTitle);
  mainPanel.add(ingresePondButton);
  mainPanel.add(zonificarButton);
  mainPanel.add(botonreinicio);
  mapPanel.setCenter (-64,-27.5,6);
}
init();