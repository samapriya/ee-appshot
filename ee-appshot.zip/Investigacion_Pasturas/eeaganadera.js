var coleccion = ui.import && ui.import("coleccion", "imageCollection", {
      "id": "users/Investigacion_Pasturas/EEA_Reconquista_Arhivos/Coleccion_EEA_Reconquista"
    }) || ee.ImageCollection("users/Investigacion_Pasturas/EEA_Reconquista_Arhivos/Coleccion_EEA_Reconquista"),
    Norte_de_santa_fe = ui.import && ui.import("Norte_de_santa_fe", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -59.75005371170879,
                -29.273256918313727
              ],
              [
                -59.70499260025859,
                -29.280069852445898
              ],
              [
                -59.70456344681621,
                -29.278422811097602
              ],
              [
                -59.70430595475078,
                -29.277674147163523
              ],
              [
                -59.69786865311504,
                -29.265095773063415
              ],
              [
                -59.693147965248826,
                -29.255885624977154
              ],
              [
                -59.69297630387187,
                -29.25307748801285
              ],
              [
                -59.69349128800273,
                -29.250943252362955
              ],
              [
                -59.6943495948875,
                -29.2494455165491
              ],
              [
                -59.695422478493455,
                -29.248359644373608
              ],
              [
                -59.69804031449199,
                -29.2466746474924
              ],
              [
                -59.70752460556865,
                -29.24517684919218
              ],
              [
                -59.711901970680955,
                -29.2570837399518
              ],
              [
                -59.74168521958232,
                -29.25333958405795
              ],
              [
                -59.74756462174297,
                -29.25996664659251
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Polygon(
                [[[-59.75005371170879, -29.273256918313727],
                  [-59.70499260025859, -29.280069852445898],
                  [-59.70456344681621, -29.278422811097602],
                  [-59.70430595475078, -29.277674147163523],
                  [-59.69786865311504, -29.265095773063415],
                  [-59.693147965248826, -29.255885624977154],
                  [-59.69297630387187, -29.25307748801285],
                  [-59.69349128800273, -29.250943252362955],
                  [-59.6943495948875, -29.2494455165491],
                  [-59.695422478493455, -29.248359644373608],
                  [-59.69804031449199, -29.2466746474924],
                  [-59.70752460556865, -29.24517684919218],
                  [-59.711901970680955, -29.2570837399518],
                  [-59.74168521958232, -29.25333958405795],
                  [-59.74756462174297, -29.25996664659251]]]),
            {
              "system:index": "0"
            })]),
    vis = ui.import && ui.import("vis", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "b3",
          "b2",
          "b1"
        ],
        "min": 604.7,
        "max": 1418.3,
        "gamma": 2.051
      }
    }) || {"opacity":1,"bands":["b3","b2","b1"],"min":604.7,"max":1418.3,"gamma":2.051};
//para logo
var logo = ee.Image('users/carlosnavarrochamical/Imagenes/lOGO_QGIS_INTA2')
var geo = ee.Geometry.Rectangle([[-1.084958720480591,-0.828437958991397], [1.529787373269409,2.708121923804139]])
var imagelog = logo.clip(geo)
var region = ee.FeatureCollection(Norte_de_santa_fe).style({fillColor: '00000000', width: 3, color: 'orange'})
//coleccion
var label = ui.Label('Referencias', {fontSize: '25px', color: 'green', textAlign: 'center'})
var label1 = ui.Label('Azul: NDVI entre -0.15 y 0.025 (Agua en superficie, lagunas, lagos, represas)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var label2 = ui.Label('Negro: NDVI entre 0.025 y 0.2 (Sin vegetación, suelos desnudos, caminos, rutas)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var label3 = ui.Label('Blanco: NDVI entre 0.2 y 0.375 (vegetación muy poco vigorosa)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var label4 = ui.Label('Amarillo: NDVI entre 0.375 y 0.55 (vegetación poco vigorosa)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var label5 = ui.Label('Verde: NDVI entre 0.55 y 0.725 (vegetación vigorosa)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var label6 = ui.Label('Rojo: NDVI entre 0.725 y 0.9 (vegetación muy vigorosa)', {fontSize: '11px',color: 'green', textAlign: 'center'})
var map = ui.Map()
map.style().set('cursor', 'crosshair');
// map.setOptions({mapTypeId: 'SATELLITE'})
//map.setControlVisibility({layerList: false, zoomControl: false, scaleControl: false, mapTypeControl: true, fullscreenControl: false, drawingToolsControl: false })
 var ap = function(image){
    var ndvi = image.normalizedDifference(['b4', 'b3'])
    image = image.addBands(ndvi.rename('NDVI'))
    return image.clip(Norte_de_santa_fe)
  }
var coleccionbase = coleccion.map(ap)
var inicio = ee.Image(coleccionbase.first()).date().get('year').format()
var ahora = Date.now()
var final = ee.Date(ahora).format()
var rangodefecha = ee.DateRange(inicio, ahora)
print(rangodefecha)
/////////////////////////////////////////////////////////////////////////////////
// Map.style().set('cursor', 'crosshair');
//construccion de inicio y el final 1
var inicio1 = ee.Image(coleccionbase.first()).date().get('year').format()
var ahora1 = Date.now()
var final1 = ee.Date(ahora1).format()
var rangodefecha1 = ee.DateRange(inicio1, ahora1)
map.centerObject(Norte_de_santa_fe, 13)
print(rangodefecha1)
////////////////////////////////////////////////////////
//para Dateslider 1
var primera = function (preinicio){
  var ap = function(image){
    var ndvi = image.normalizedDifference(['b4', 'b3'])
    image = image.addBands(ndvi.rename('NDVI'))
    return image.clip(Norte_de_santa_fe)
  }
  var coleccion1 = coleccion
    .filterDate(rangodefecha.start(), rangodefecha.end())
    .map(ap)
  rangodefecha.start().get('year').evaluate(function(nombre){
    var paleta = {min: -0.25, max: 0.8, bands:['NDVI'], palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}
    var capa = ui.Map.Layer(coleccion1, paleta, nombre+' NDVI')
    map.layers().set(0, capa)
  })
}
var segunda = function(prefinal){
  var ap = function(image){
    var ndvi = image.normalizedDifference(['b4', 'b3'])
    image = image.addBands(ndvi.rename('NDVI'))
    return image.clip(Norte_de_santa_fe)
  }
  var coleccion1 = coleccion
    .filterBounds(Norte_de_santa_fe)
    .filterDate(prefinal.start(), prefinal.end())
    .map(ap)
  prefinal.start().get('year').evaluate(function(nombre){
    var paleta = {min: -0.25, max: 0.8, bands:['NDVI'], palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}
    var capa = ui.Map.Layer(coleccion1, paleta, nombre+' NDVI')
    var capa1 = ui.Map.Layer(coleccion1, vis, nombre+' Imagen en color')
    var regi = ui.Map.Layer(Norte_de_santa_fe.style({fillColor: '00000000'}))
    map.layers().set(0, capa)
    map.layers().set(2, regi)
  })
}
//DateSlider 1
var rango = ee.DateRange(inicio, final).evaluate(function(rango){
  var slider = ui.DateSlider({
    start: rango['dates'][0],
    end: rango['dates'][1],
    value: null,
    period: 2,
    onChange: function(rango){
      rangodefecha = rango;
      segunda(rangodefecha)},
    style:{
      position: 'bottom-left',
      backgroundColor: 'orange'
    }
   })
  map.add(slider.setValue(ahora));
})
//////colorcar grafico en el mapa////////////////////
var lon = ui.Label()
    var lat = ui.Label()
    var panel = ui.Panel([lon, lat])
   map.onClick(function(r){
     lon.setValue('Longitud: '+ r.lon.toFixed(2))
     lat.setValue('Latitud: '+ r.lat.toFixed(2))
     var punto = ee.Geometry.Point(r.lon, r.lat)
     var mapaddpunto = ee.FeatureCollection(punto).style({color: 'red', pointShape: 'star', pointSize: 10})
     var puntomap = ui.Map.Layer(mapaddpunto)
     map.layers().set(2, mapaddpunto)
     //////grafico///////////////
     var ap = function(image){
     var ndvi = image.normalizedDifference(['b4', 'b3'])
     image = image.addBands(ndvi.rename('NDVI'))
     return image.clip(Norte_de_santa_fe)
     }
     var coleccion1 = coleccion
     .map(ap)
     var graficondvi = ui.Chart.image.series(coleccion1.select('NDVI'), punto, ee.Reducer.mean(), 10)
     .setOptions({
       title: 'Grafico de NDVI para el punto seleccionado desde 2017 hasta la actualidad',
       vAhis: {title: 'NDVI'},
       hAxis: {title: 'Fecha', format: 'YY-MM'},
       backgroundColor: 'orange',
     })
     var panell = ui.Panel([ui.Button('Cerrar Grafico', function(iii){
       iii = panell.clear()
     }, null, {margin: '-5px 1px -5px 1px', width: '480px'}), graficondvi],
     ui.Panel.Layout.Flow('vertical'), {margin: '0px 1px 1px 1px',width: '500px', position: 'top-left'})
     map.widgets().set(2, panell)
    })
var panel = ui.Panel({
  widgets: [label, label1, label2, label3, label4, label5, label6],
  style: {
    position: 'top-right',
    width: 150,
    height: 300,
  }
})
map.add(panel)
///segundo Date slider////////////////////////////////////////////////////////////////////////////////////////
var map1 = ui.Map()
map1.style().set('cursor', 'crosshair');
// map1.setOptions({mapTypeId: 'SATELLITE'})
//map1.setControlVisibility({layerList: false, zoomControl: false, scaleControl: false, mapTypeControl: true, fullscreenControl: false, drawingToolsControl: false })
var tercera = function (terinicio){
  var ap = function(image){
    var ndvi = image.normalizedDifference(['b4', 'b3'])
    image = image.addBands(ndvi.rename('NDVI'))
    return image.clip(Norte_de_santa_fe)
  }
  var coleccion1 = coleccion
    .filterDate(rangodefecha1.start(), rangodefecha1.end())
    .map(ap)
  rangodefecha1.start().get('year').evaluate(function(nombre){
    var paleta = {min: -0.25, max: 0.8, bands:['NDVI'], palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}
    var capa = ui.Map.Layer(coleccion1, paleta, nombre+' NDVI')
    map1.layers().set(0, capa)
  })
}
var cuarta = function(cufinal){
  var ap = function(image){
    var ndvi = image.normalizedDifference(['b4', 'b3'])
    image = image.addBands(ndvi.rename('NDVI'))
    return image.clip(Norte_de_santa_fe)
  }
  var coleccion1 = coleccion
    .filterDate(cufinal.start(), cufinal.end())
    .map(ap)
  cufinal.start().get('year').evaluate(function(nombre){
    var paleta = {min: -0.25, max: 0.8, bands:['NDVI'], palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}
    var capa = ui.Map.Layer(coleccion1, paleta, nombre+' NDVI')
    var capa1 = ui.Map.Layer(coleccion1, vis, nombre+' Imagen color')
    var regi = ui.Map.Layer(Norte_de_santa_fe.style({fillColor: '00000000'}))
    map1.layers().set(1, capa1)
    map1.layers().set(2, regi)
  })
}
var rango = ee.DateRange(inicio1, final1).evaluate(function(rango){
  var slider = ui.DateSlider({
    start: rango['dates'][0],
    end: rango['dates'][1],
    value: null,
    period: 2,
    onChange: function(rango){
      rangodefecha1 = rango;
      cuarta(rangodefecha1)},
    style:{position: 'bottom-right',
      backgroundColor: 'orange',
    }
  })
  map1.add(slider.setValue(ahora1));
})
//////colorcar grafico en el mapa////////////////////
var lon = ui.Label()
    var lat = ui.Label()
    var panel = ui.Panel([lon, lat])
   map1.onClick(function(r){
     lon.setValue('Longitud: '+ r.lon.toFixed(2))
     lat.setValue('Latitud: '+ r.lat.toFixed(2))
     var punto = ee.Geometry.Point(r.lon, r.lat)
     var mapaddpunto = ee.FeatureCollection(punto).style({color: 'red', pointShape: 'star', pointSize: 10})
     var puntomap = ui.Map.Layer(mapaddpunto)
     map1.layers().set(2, mapaddpunto)
     //////grafico///////////////
     var ap = function(image){
     var ndvi = image.normalizedDifference(['b4', 'b3'])
     image = image.addBands(ndvi.rename('NDVI'))
     return image.clip(Norte_de_santa_fe)
     }
     var coleccion1 = coleccion
     .map(ap)
     var graficondvi = ui.Chart.image.series(coleccion1.select('NDVI'), punto, ee.Reducer.mean(), 10)
     .setOptions({
       title: 'Grafico de NDVI para el punto seleccionado desde 2017 hasta la actualidad',
       vAhis: {title: 'NDVI'},
       hAxis: {title: 'Fecha', format: 'YY-MM'},
       backgroundColor: 'orange',
     })
     var panell = ui.Panel([ui.Button('Cerrar Grafico', function(iii){
       iii = panell.clear()
     }, null, {margin: '-5px 1px -5px 1px', width: '480px'}), graficondvi],
     ui.Panel.Layout.Flow('vertical'), {margin: '0px 1px 1px 1px',width: '500px', position: 'top-right'})
     map1.widgets().set(2, panell)
    })
// var visparmm = {
//   min: -0.15, 
//   max: 0.9, 
//   bands:['NDVI'], 
//   palette: ['blue', 'black', 'white', 'yellow', 'green', 'red'],
//   maxFrames: 200
// }
// var thin = ui.Thumbnail({
//   image: coleccionbase, 
//   params: visparmm,
//   style:{position: 'top-right',
//     width: 300,
//     height: 300,
//   }})
// map1.add(thin)
map1.centerObject(Norte_de_santa_fe, 13)
// map.add(panel)
var split = ui.SplitPanel({
  firstPanel: map,
  secondPanel: map1,
  wipe: true
})
// var log = ui.Thumbnail(imagelog)
// var visparfondo = {
//   bands: ['b3', 'b2', 'b1'],
//   min: 400,
//   max: 2000,
//   region: Norte_de_santa_fe,
//   gamma: 1.8
// }
// var fondopanel = ui.Thumbnail(parafondo, visparfondo, null, {width: '300px', height: '255px'})
// var panellog1 = ui.Panel({
//   widgets: [log, fondopanel],
//   layout: ui.Panel.Layout.Flow('horizontal'),
//   style: {
//     position: 'top-center',
//     width: '530px',
//     backgroundColor: 'orange'
//   }
// })
var panellog = ui.Panel({
  widgets: [
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'red',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '20px'} ),
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'red',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ),
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'orange',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ),
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'yellow',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ), 
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'lightgreen',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ) ,
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'cyan',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ), 
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'blue',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'} ), 
  ui.Button('APP generada en la Plataforma Google Earth Engine', null, null, {backgroundColor: 'violet',margin: '5px 1px 1px 1px',height: '25px', width: '530px', position: 'top-left', color: 'indigo', fontSize: '42px'}),
  ui.Button('Ingresar a la APP', function(l){
    l = ui.root.clear()
    l = ui.root.add(split)
  }
  , null, {margin: '5px 1px 1px 1px', width: '530px', position: 'top-left'})],
  style: {
    position: 'top-center',
    width: '550px',
    backgroundColor: 'green'
  }
})
Map.setControlVisibility({all: false})
Map.setOptions({mapTypeId: 'SATELLITE'})
// Map.add(split)
Map.add(panellog)
// ui.root.clear()
// ui.root.add(panellog)