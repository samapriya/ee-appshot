var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -61.85630632507288,
                -29.738542017211756
              ],
              [
                -61.85630632507288,
                -31.496991354587916
              ],
              [
                -58.91197038757288,
                -31.496991354587916
              ],
              [
                -58.91197038757288,
                -29.738542017211756
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-61.85630632507288, -29.738542017211756],
          [-61.85630632507288, -31.496991354587916],
          [-58.91197038757288, -31.496991354587916],
          [-58.91197038757288, -29.738542017211756]]], null, false),
    countries = ui.import && ui.import("countries", "table", {
      "id": "users/carlosnavarrochamical/DatosdeCampo1"
    }) || ee.FeatureCollection("users/carlosnavarrochamical/DatosdeCampo1"),
    Argentina = ui.import && ui.import("Argentina", "table", {
      "id": "users/carlosnavarrochamical/Argentina"
    }) || ee.FeatureCollection("users/carlosnavarrochamical/Argentina");
///////////////////////////Mapas principales///////////////////
var Map1 = ui.Map()
var Map2 = ui.Map()
///////////////////////////////////////interactividad con información de campo////////////////
/*
 * Visualization and styling
 */
// Constants used to visualize the data on the map.
var POPULATION_STYLE = {
  min: 0,
  max: 100,
  palette: ['lightyellow', 'steelblue', 'darkblue']
};
var POPULATION_VIS_MAX_VALUE = 1200;
var POPULATION_VIS_NONLINEARITY = 4;
var COUNTRIES_STYLE = {color: '26458d', fillColor: '00000000'};
var HIGHLIGHT_STYLE = {color: '8856a7', fillColor: '8856a7C0'};
// Apply a non-linear stretch to the population data for visualization.
function colorStretch(image) {
  return image.divide(POPULATION_VIS_MAX_VALUE)
      .pow(1 / POPULATION_VIS_NONLINEARITY);
}
// Inverts the nonlinear stretch we apply to the population data for
// visualization, so that we can back out values to display in the legend.
// This uses ordinary JavaScript math functions, rather than Earth Engine
// functions, since we're going to call it from JS to compute label values.
// Configure our map with a minimal set of controls.
// Map.setControlVisibility(false);
// map1.setControlVisibility({scaleControl: true, zoomControl: true});
Map2.style().set({cursor: 'crosshair'});
// Add our two base layers to the map: global population density and countries.
// Map.addLayer(colorStretch(ghslPop.unmask(0).updateMask(1)), POPULATION_STYLE);
// Map.addLayer(countries.style(COUNTRIES_STYLE));
// Create the application title bar.
// Map.add(ui.Label(
//     'Global Population Explorer', {fontWeight: 'bold', fontSize: '24px'}));
/*
 * The chart panel in the bottom-right
 */
function undoColorStretch(val) {
  return Math.pow(val, POPULATION_VIS_NONLINEARITY) * POPULATION_VIS_MAX_VALUE;
}
// A list of points the user has clicked on, as [lon,lat] tuples.
var selectedPoints = [];
// Returns the list of countries the user has selected.
function getSelectedCountries() {
  return countries.filterBounds(ee.Geometry.MultiPoint(selectedPoints));
}
// conruie grafico de barra 
function makeResultsBarChart(countries) {
  var chart = ui.Chart.feature.byFeature(countries, 'Activi-var','supha');
  chart.setChartType('PieChart');
  chart.setSeriesNames(countries)
  chart.setOptions({
    title: 'información del lote',
    vAxis: {title: null},
    hAxis: {title: 'Superficie en hectareas', minValue: 0},
    pointShape: 'star',
    pointSize: 7,
    backgroundColor: 'orange',
    series:{
      0: {color: 'green'}
    } ,
    is3D: true
  });
  chart.style().set({stretch: 'both'});
  return chart;
}
// hacer resultados en tabla
function makeResultsTable(countries) {
  var table = ui.Chart.feature.byFeature(countries, 'Lotes');
  table.setChartType('Table');
  table.setOptions({allowHtml: true, pageSize: 5});
  table.style().set({stretch: 'both'});
  return table;
}
// actualiza de los layer por campo
function updateOverlay() {
  var overlay = getSelectedCountries().style(HIGHLIGHT_STYLE);
  Map2.layers().set(2, ui.Map.Layer(overlay));
}
// Updates the chart using the currently-selected charting function,
function updateChart() {
  var chartBuilder = chartTypeToggleButton.value;
  var chart = chartBuilder(getSelectedCountries());
  resultsPanel.clear().add(chart).add(buttonPanel);
}
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  selectedPoints = [];
  Map2.layers().remove(Map2.layers().get(2));
  var instructionsLabel = ui.Label('Seleccionar campos para mas información', {backgroundColor: 'orange'});
  resultsPanel.widgets().reset([]);
}
// Register a click handler for the map that adds the clicked point to the
// list and updates the map overlay and chart accordingly.
function handleMapClick(location) {
  selectedPoints.push([location.lon, location.lat]);
  updateOverlay();
  updateChart();
}
//Map2.onClick(handleMapClick);
// A button widget that toggles (or cycles) between states.
// To construct a ToggleButton, supply an array of objects describing
// the desired states, each with 'label' and 'value' properties.
function ToggleButton(states, onClick) {
  var index = 0;
  var button = ui.Button(states[index].label);
  button.value = states[index].value;
  button.onClick(function() {
    index = ++index % states.length;
    button.setLabel(states[index].label);
    button.value = states[index].value;
    onClick();
  });
  return button;
}
// Our chart type toggle button: the button text is the opposite of the
// current state, since you click the button to switch states.
var chartTypeToggleButton = ToggleButton(
    [
      {
        label: 'Mostrar resultados en tabla',
        value: makeResultsBarChart,
      },
      {
        label: 'Mostrar resultados en grafíco',
        value: makeResultsTable,
      }
    ],
    updateChart);
// A panel containing the two buttons .
var buttonPanel = ui.Panel(
    [ui.Button('cerrar resultados', clearResults), chartTypeToggleButton],
    ui.Panel.Layout.Flow('horizontal'), {margin: '0 0 0 auto', width: '500px'});
var resultsPanel = ui.Panel({style: {position: 'top-left', backgroundColor: 'orange'}});
//Map2.add(resultsPanel);
//clearResults();
////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////Segunda parte//////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
////////////////////filtro/////////////////////////////////
var lotes = ee.FeatureCollection(countries)//.style({fillColor: '00000000', width: 3, color: 'orange'})
var filtro = lotes.filter(ee.Filter.eq('Establecim', 'Don Raul'))
///filtro campaña 2017-2018
var filtroA = filtro.filter(ee.Filter.eq('Campana', '2017-2018'))
///filtro campaña 2018-2019
var filtroB = filtro.filter(ee.Filter.eq('Campana', '2018-2019'))
///filtro campaña 2019-2020
var filtroC = filtro.filter(ee.Filter.eq('Campana', '2019-2020'))
/////////////////////////////////////////constuccion de ndvi//////////////////////////
var coleccion = ee.ImageCollection("COPERNICUS/S2")
.filterBounds(geometry)
.filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 1)
/////////////////////////////////////ndvi campaña 2017-2018///////////////////////
var ndvi20172018 = coleccion.filterDate('2017-02-01', '2018-08-31').map(function(ndvi1718){
  var ndvi = ndvi1718.normalizedDifference(['B8', 'B4'])
  ndvi1718 = ndvi1718.addBands(ndvi.rename('NDVI'))
  return ndvi1718
})
/////////////////////////////////////ndvi campaña 2018-2019///////////////////////
var ndvi20182019 = coleccion.filterDate('2018-02-01', '2019-08-31').map(function(ndvi1718){
  var ndvi = ndvi1718.normalizedDifference(['B8', 'B4'])
  ndvi1718 = ndvi1718.addBands(ndvi.rename('NDVI'))
  return ndvi1718
})
/////////////////////////////////////ndvi campaña 2019-2020///////////////////////
var ndvi20192020 = coleccion.filterDate('2019-02-01', '2020-08-31').map(function(ndvi1718){
  var ndvi = ndvi1718.normalizedDifference(['B8', 'B4'])
  ndvi1718 = ndvi1718.addBands(ndvi.rename('NDVI'))
  return ndvi1718
})
print(lotes)
// control de visibilidad 
Map2.setControlVisibility({layerList: false, zoomControl: false, scaleControl: true, mapTypeControl: false, fullscreenControl: true, drawingToolsControl: true})
Map2.setOptions({mapTypeId: 'SATELLITE'})
Map1.setOptions({mapTypeId: 'SATELLITE'})
Map1.add(ui.Map.DrawingTools())
// cuando enres a don Raul
var establecimiento = ui.Checkbox({
  label: 'Establecimiento Don Raul',
  onChange: function(f){
    f = Map1.remove(panel)
    /////////////////////////Campaña 2017-2018//////////////////////////////////////////////////
    var campana= ui.Checkbox({
      label : 'Campaña 2017-2018',
      onChange: function(i){
        ///////////////////Cultivos//////////////////
        var Maiz= ui.Checkbox({
          label: 'Maiz',
          onChange: function (Maiz1){
            // Map1.layers().get(0).setShown(Maiz1)
            // Map2.layers().get(0).setShown(Maiz1)
            Map1.layers().get(0).setShown(Maiz1)
            Map2.layers().get(0).setShown(Maiz1)
          }
        })
        //////////////////////////////////////////filtros/////////////////////////////////
        var filtro11 = filtroA.filter(ee.Filter.eq('Actividad', 'Maiz'))
        // Map1.addLayer(filtro.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        // Map2.addLayer(filtro.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        Map1.addLayer(ndvi20172018.map(function(i){return i.clip(filtro11)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20172018.map(function(i){return i.clip(filtro11)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map1.centerObject(filtroA,13)
        Map2.centerObject(filtroA,13)
        ///////////////////////////////
        var Soja = ui.Checkbox({
          label: 'Soja',
          onChange: function (Soja1){
            // Map1.layers().get(1).setShown(Soja1)
            // Map2.layers().get(1).setShown(Soja1)
            Map1.layers().get(1).setShown(Soja1)
            Map2.layers().get(1).setShown(Soja1)
          }
        })
        var filtro1 = filtroA.filter(ee.Filter.eq('Actividad', 'Soja'))
        // Map1.addLayer(filtro1.style({fillColor: '00000000', width: 3, color: 'orange'}), {}, 'soja').setShown(false)
        // Map2.addLayer(filtro1.style({fillColor: '00000000', width: 3, color: 'orange'}), {}, 'soja').setShown(false)
        Map1.addLayer(ndvi20172018.map(function(i){return i.clip(filtro1)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}, 'ndvi soja').setShown(false)
        Map2.addLayer(ndvi20172018.map(function(i){return i.clip(filtro1)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}, 'ndvi soja').setShown(false)
        var Trigo= ui.Checkbox({
          label: 'Trigo',
          onChange: function (Trigo1){
            Map1.layers().get(2).setShown(Trigo1)
            Map2.layers().get(2).setShown(Trigo1)
          }
        })
        var filtro22 = filtroA.filter(ee.Filter.eq('Actividad', 'Trigo'))
        // Map1.addLayer(filtro22.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        // Map2.addLayer(filtro22.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        Map1.addLayer(ndvi20172018.map(function(i){return i.clip(filtro22)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20172018.map(function(i){return i.clip(filtro22)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        var Girasol= ui.Checkbox({
          label: 'Girasol',
          onChange: function (Girasol1){
            Map1.layers().get(3).setShown(Girasol1)
            Map2.layers().get(3).setShown(Girasol1)
          }
        })
        var filtro3 = filtroA.filter(ee.Filter.eq('Actividad', 'Girasol'))
        // Map1.addLayer(filtro3).setShown(false)
        // Map2.addLayer(filtro3).setShown(false)
        Map1.addLayer(ndvi20172018.map(function(i){return i.clip(filtro3)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20172018.map(function(i){return i.clip(filtro3)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        var atrascultivo= ui.Checkbox({
          label: 'Atras',
          onChange: function(atras){
            atras = Map1.remove(panelcultivos)
            atras = Map1.clear()
            atras = Map2.clear()
            atras = Map1.add(panelcampana)
          }
        })
         var label = ui.Label('Cultivos de la Campaña 2017-2018')
         var panelcultivos = ui.Panel({
           widgets: [label , Maiz, Soja, Trigo, Girasol, atrascultivo],
           style: {
        position: 'top-right'}
         })
         i = Map1.remove(panelcampana)
         i = Map1.add(panelcultivos)
         ///////////////////////////////////////////////////////////////////////////////////////////////////////////
         ////////////////////////////interactividad campos///////////////////////////////////////////////
/*
 * The chart panel in the bottom-right
 */
// A list of points the user has clicked on, as [lon,lat] tuples.
var selectedPoints = [];
// Returns the list of countries the user has selected.
function getSelectedCountries() {
  return countries.filterBounds(ee.Geometry.MultiPoint(selectedPoints));
}
// conruie grafico de barra 
function graficondvi(countries) {
  var coleccionndvi = ee.ImageCollection("COPERNICUS/S2")
   .filterBounds(countries)
   .filterDate('2017-02-01', '2020-08-31')
   .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 1)
   .map(function(n){
     var ndvi = n.normalizedDifference(['B8','B4'])
     n = n.addBands(ndvi.rename('NDVI'))
     return n.clip(countries)
   })
  var chart = ui.Chart.image.seriesByRegion(coleccionndvi, countries, ee.Reducer.mean(), 'NDVI', 10, null, 'Lotes');
  chart.setChartType('LineChart');
  // chart.setSeriesNames(countries)
  chart.setOptions({
    title: 'Grafico de Indice Verde (NDVI) por lote seleccionado',
    vAxis: {title: null},
    hAxis: {title: 'Fecha', format: 'YYYY-MM'},
    backgroundColor: 'orange',
    series:{
      0: {color: 'green'}
    } ,
    is3D: true
  });
  chart.style().set({stretch: 'both'});
  return chart;
}
function makeResultsBarChart(countries) {
  var chart = ui.Chart.feature.byFeature(countries, 'Activi-var','supha');
  chart.setChartType('PieChart');
  chart.setSeriesNames(countries)
  chart.setOptions({
    title: '% de superficie ocupada por lote en relacion a los lotes seleccionados',
    vAxis: {title: null},
    hAxis: {title: 'Superficie en hectareas', minValue: 0},
    pointShape: 'star',
    pointSize: 7,
    backgroundColor: 'orange',
    series:{
      0: {color: 'green'}
    } ,
    is3D: true
  });
  chart.style().set({stretch: 'both'});
  return chart;
}
// hacer resultados en tabla
function makeResultsTable(countries) {
  var table = ui.Chart.feature.byFeature(countries, 'Lotes');
  table.setChartType('Table');
  table.setOptions({allowHtml: true, pageSize: 5});
  table.style().set({stretch: 'both'});
  return table;
}
// actualiza de los layer por campo
function updateOverlay() {
  var overlay = getSelectedCountries().style(HIGHLIGHT_STYLE);
  Map2.layers().set(2, ui.Map.Layer(overlay));
}
// Updates the chart using the currently-selected charting function,
function updateChart() {
  var chartBuilder = chartTypeToggleButton.value;
  var chart = chartBuilder(getSelectedCountries());
  resultsPanel.clear().add(chart).add(buttonPanel);
}
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  selectedPoints = [];
  Map2.layers().remove(Map2.layers().get(2));
  var instructionsLabel = ui.Label('Seleccionar campos para mas información', {backgroundColor: 'orange'});
  resultsPanel.widgets().reset([]);
}
// Register a click handler for the map that adds the clicked point to the
// list and updates the map overlay and chart accordingly.
function handleMapClick(location) {
  selectedPoints.push([location.lon, location.lat]);
  updateOverlay();
  updateChart();
}
Map2.onClick(handleMapClick);
// A button widget that toggles (or cycles) between states.
// To construct a ToggleButton, supply an array of objects describing
// the desired states, each with 'label' and 'value' properties.
function ToggleButton(states, onClick) {
  var index = 0;
  var button = ui.Button(states[index].label);
  button.value = states[index].value;
  button.onClick(function() {
    index = ++index % states.length;
    button.setLabel(states[index].label);
    button.value = states[index].value;
    onClick();
  });
  return button;
}
// Our chart type toggle button: the button text is the opposite of the
// current state, since you click the button to switch states.
var chartTypeToggleButton = ToggleButton(
    [
      {
        label: 'Tabla de Datos',
        value: makeResultsBarChart,////////corresponde a grafico 
      },
      {
        label: '% de superficie Ocupada',
        value: makeResultsTable,/////corresponde a tabla
      }
    ],
    updateChart);
////////PARA BOTON DE NDVI//////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
// actualiza de los layer por campo
function updateOverlay1() {
  var overlay = getSelectedCountries().style(HIGHLIGHT_STYLE);
  Map2.layers().set(2, ui.Map.Layer(overlay));
}
// Updates the chart using the currently-selected charting function,
function updateChart1() {
  var chartBuilder = chartTypeToggleButton1.value;
  var chart = chartBuilder(getSelectedCountries());
  resultsPanel.clear().add(chart).add(buttonPanel);
}
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  selectedPoints = [];
  Map2.layers().remove(Map2.layers().get(2));
  var instructionsLabel = ui.Label('Seleccionar campos para mas información', {backgroundColor: 'orange'});
  resultsPanel.widgets().reset([]);
}
// Register a click handler for the map that adds the clicked point to the
// list and updates the map overlay and chart accordingly.
function handleMapClick1(location) {
  selectedPoints.push([location.lon, location.lat]);
  updateOverlay1();
  updateChart1();
}
Map2.onClick(handleMapClick1);
// A button widget that toggles (or cycles) between states.
// To construct a ToggleButton, supply an array of objects describing
// the desired states, each with 'label' and 'value' properties.
function ToggleButton1(states, onClick) {
  var index = 0;
  var button = ui.Button(states[index].label);
  button.value = states[index].value;
  button.onClick(function() {
    index = ++index % states.length;
    button.setLabel(states[index].label);
    button.value = states[index].value;
    onClick();
  });
  return button;
}
// Our chart type toggle button: the button text is the opposite of the
// current state, since you click the button to switch states.
var chartTypeToggleButton1 = ToggleButton1(
    [
      {
        label: 'Grafico de NDVI',
        value: graficondvi,
      },
      {
        label: 'Grafico de NDVI',
        value: graficondvi,
      }
    ],
    updateChart1);
// A panel containing the two buttons .
var labeparabutonpanel = ui.Label('¡ Importante!!!!!!!!!')
var labeparabutonpanel2 = ui.Label('Al hacer click en el mapa, en primer orden se mostrara un grafico'+
', con datos de indice verde del lote seleccionado, posteriormente '+
', se puede seleccionar la tabla con un resumen de información de campo'+
', como un grafico de la superficie ocupada en % por los lotes seleccionados'+
' en relacion a la cantidad total de lotes seleccionados'
)
var labeparabutonpanel = ui.Panel(
    [labeparabutonpanel,labeparabutonpanel2,  ui.Button('Cerrar', function(h){h = Map2.remove(labeparabutonpanel)})],
    ui.Panel.Layout.Flow('vertical'), {margin: '0 0 0 auto', width: '300px'});
var booootomm = ui.Button('Atención ????...', function(i){i = Map2.add(labeparabutonpanel) })
var buttonPanel = ui.Panel(
    [ui.Button('cerrar resultados', clearResults), chartTypeToggleButton1, chartTypeToggleButton, booootomm],
    ui.Panel.Layout.Flow('horizontal'), {margin: '0 0 0 auto', width: '500px'});
var resultsPanel = ui.Panel({style: {position: 'top-left', backgroundColor: 'orange'}});
Map2.add(resultsPanel);
clearResults();
      }
    })
    ////////////Campaña 2018-2019//////////////////////////////////////////////////////////////////////////////////////
    var campana1= ui.Checkbox({
      label : 'Campaña 2018-2019',
      onChange: function(i){
        ///////////////////Cultivos//////////////////
        var Maiz = ui.Checkbox({
          label: 'Maiz',
          onChange: function (Maiz){
            Map1.layers().get(0).setShown(Maiz)
            Map2.layers().get(0).setShown(Maiz)
          }
        })
        var filtro4 = filtroB.filter(ee.Filter.eq('Actividad', 'Maiz'))
        // Map1.addLayer(filtro4.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        // Map2.addLayer(filtro4.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        Map1.addLayer(ndvi20182019.map(function(i){return i.clip(filtro4)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20182019.map(function(i){return i.clip(filtro4)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        var Soja = ui.Checkbox({
          label: 'Soja',
          onChange: function (Soja){
            Map1.layers().get(1).setShown(Soja)
            Map2.layers().get(1).setShown(Soja)
          }
        })
        var filtro5 = filtroB.filter(ee.Filter.eq('Actividad', 'Soja'))
        // Map1.addLayer(filtro5.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        // Map2.addLayer(filtro5.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        Map1.addLayer(ndvi20182019.map(function(i){return i.clip(filtro5)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20182019.map(function(i){return i.clip(filtro5)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        var Trigo= ui.Checkbox({
          label: 'Trigo',
          onChange: function (Trigo){
            Map1.layers().get(2).setShown(Trigo)
            Map2.layers().get(2).setShown(Trigo)
          }
        })
        var filtro6 = filtroB.filter(ee.Filter.eq('Actividad', 'Trigo'))
        // Map1.addLayer(filtro6.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        // Map2.addLayer(filtro6.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        Map1.addLayer(ndvi20182019.map(function(i){return i.clip(filtro6)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20182019.map(function(i){return i.clip(filtro6)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        var Girasol= ui.Checkbox({
          label: 'Girasol',
          onChange: function (Girasol){
            Map1.layers().get(3).setShown(Girasol)
            Map2.layers().get(3).setShown(Girasol)
          }
        })
        var filtro7 = filtroB.filter(ee.Filter.eq('Actividad', 'Girasol'))
        // Map1.addLayer(filtro7.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        // Map2.addLayer(filtro7.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        Map1.addLayer(ndvi20182019.map(function(i){return i.clip(filtro7)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20182019.map(function(i){return i.clip(filtro7)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map1.centerObject(countries,13)
        Map2.centerObject(countries,13)
        ////////////////////////////////atras//////////////////////////////////////////
        var atrascultivo= ui.Checkbox({
          label: 'Atras',
          onChange: function(atras){
            atras = Map1.remove(panelcultivos)
            atras = Map1.clear()
            atras = Map2.clear()
            atras = Map1.add(panelcampana)
          }
        })
         var label = ui.Label('Cultivos de la Campaña 2018-2019')
         var panelcultivos = ui.Panel({
           widgets: [label , Maiz, Soja, Trigo, Girasol, atrascultivo ],
           style: {
        position: 'top-right'}
         })
         i = Map1.remove(panelcampana)
         i = Map1.add(panelcultivos)
/*
 * The chart panel in the bottom-right
 */
// A list of points the user has clicked on, as [lon,lat] tuples.
var selectedPoints = [];
// Returns the list of countries the user has selected.
function getSelectedCountries() {
  return countries.filterBounds(ee.Geometry.MultiPoint(selectedPoints));
}
// conruie grafico de barra 
function graficondvi(countries) {
  var coleccionndvi = ee.ImageCollection("COPERNICUS/S2")
   .filterBounds(countries)
   .filterDate('2017-02-01', '2020-08-31')
   .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 1)
   .map(function(n){
     var ndvi = n.normalizedDifference(['B8','B4'])
     n = n.addBands(ndvi.rename('NDVI'))
     return n.clip(countries)
   })
  var chart = ui.Chart.image.seriesByRegion(coleccionndvi, countries, ee.Reducer.mean(), 'NDVI', 10, null, 'Lotes');
  chart.setChartType('LineChart');
  // chart.setSeriesNames(countries)
  chart.setOptions({
    title: 'Grafico de Indice Verde (NDVI) por lote seleccionado',
    vAxis: {title: null},
    hAxis: {title: 'Fecha', format: 'YYYY-MM'},
    backgroundColor: 'orange',
    series:{
      0: {color: 'green'}
    } ,
    is3D: true
  });
  chart.style().set({stretch: 'both'});
  return chart;
}
function makeResultsBarChart(countries) {
  var chart = ui.Chart.feature.byFeature(countries, 'Activi-var','supha');
  chart.setChartType('PieChart');
  chart.setSeriesNames(countries)
  chart.setOptions({
    title: '% de superficie ocupada por lote en relacion a los lotes seleccionados',
    vAxis: {title: null},
    hAxis: {title: 'Superficie en hectareas', minValue: 0},
    pointShape: 'star',
    pointSize: 7,
    backgroundColor: 'orange',
    series:{
      0: {color: 'green'}
    } ,
    is3D: true
  });
  chart.style().set({stretch: 'both'});
  return chart;
}
// hacer resultados en tabla
function makeResultsTable(countries) {
  var table = ui.Chart.feature.byFeature(countries, 'Lotes');
  table.setChartType('Table');
  table.setOptions({allowHtml: true, pageSize: 5});
  table.style().set({stretch: 'both'});
  return table;
}
// actualiza de los layer por campo
function updateOverlay() {
  var overlay = getSelectedCountries().style(HIGHLIGHT_STYLE);
  Map2.layers().set(2, ui.Map.Layer(overlay));
}
// Updates the chart using the currently-selected charting function,
function updateChart() {
  var chartBuilder = chartTypeToggleButton.value;
  var chart = chartBuilder(getSelectedCountries());
  resultsPanel.clear().add(chart).add(buttonPanel);
}
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  selectedPoints = [];
  Map2.layers().remove(Map2.layers().get(2));
  var instructionsLabel = ui.Label('Seleccionar campos para mas información', {backgroundColor: 'orange'});
  resultsPanel.widgets().reset([]);
}
// Register a click handler for the map that adds the clicked point to the
// list and updates the map overlay and chart accordingly.
function handleMapClick(location) {
  selectedPoints.push([location.lon, location.lat]);
  updateOverlay();
  updateChart();
}
Map2.onClick(handleMapClick);
// A button widget that toggles (or cycles) between states.
// To construct a ToggleButton, supply an array of objects describing
// the desired states, each with 'label' and 'value' properties.
function ToggleButton(states, onClick) {
  var index = 0;
  var button = ui.Button(states[index].label);
  button.value = states[index].value;
  button.onClick(function() {
    index = ++index % states.length;
    button.setLabel(states[index].label);
    button.value = states[index].value;
    onClick();
  });
  return button;
}
// Our chart type toggle button: the button text is the opposite of the
// current state, since you click the button to switch states.
var chartTypeToggleButton = ToggleButton(
    [
      {
        label: 'Tabla de Datos',
        value: makeResultsBarChart,////////corresponde a grafico 
      },
      {
        label: '% de superficie Ocupada',
        value: makeResultsTable,/////corresponde a tabla
      }
    ],
    updateChart);
////////PARA BOTON DE NDVI//////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
// actualiza de los layer por campo
function updateOverlay1() {
  var overlay = getSelectedCountries().style(HIGHLIGHT_STYLE);
  Map2.layers().set(2, ui.Map.Layer(overlay));
}
// Updates the chart using the currently-selected charting function,
function updateChart1() {
  var chartBuilder = chartTypeToggleButton1.value;
  var chart = chartBuilder(getSelectedCountries());
  resultsPanel.clear().add(chart).add(buttonPanel);
}
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  selectedPoints = [];
  Map2.layers().remove(Map2.layers().get(2));
  var instructionsLabel = ui.Label('Seleccionar campos para mas información', {backgroundColor: 'orange'});
  resultsPanel.widgets().reset([]);
}
// Register a click handler for the map that adds the clicked point to the
// list and updates the map overlay and chart accordingly.
function handleMapClick1(location) {
  selectedPoints.push([location.lon, location.lat]);
  updateOverlay1();
  updateChart1();
}
Map2.onClick(handleMapClick1);
// A button widget that toggles (or cycles) between states.
// To construct a ToggleButton, supply an array of objects describing
// the desired states, each with 'label' and 'value' properties.
function ToggleButton1(states, onClick) {
  var index = 0;
  var button = ui.Button(states[index].label);
  button.value = states[index].value;
  button.onClick(function() {
    index = ++index % states.length;
    button.setLabel(states[index].label);
    button.value = states[index].value;
    onClick();
  });
  return button;
}
// Our chart type toggle button: the button text is the opposite of the
// current state, since you click the button to switch states.
var chartTypeToggleButton1 = ToggleButton1(
    [
      {
        label: 'Grafico de NDVI',
        value: graficondvi,
      },
      {
        label: 'Grafico de NDVI',
        value: graficondvi,
      }
    ],
    updateChart1);
// A panel containing the two buttons .
var labeparabutonpanel = ui.Label('¡ Importante!!!!!!!!!')
var labeparabutonpanel2 = ui.Label('Al hacer click en el mapa, en primer orden se mostrara un grafico'+
', con datos de indice verde del lote seleccionado, posteriormente '+
', se puede seleccionar la tabla con un resumen de información de campo'+
', como un grafico de la superficie ocupada en % por los lotes seleccionados'+
' en relacion a la cantidad total de lotes seleccionados'
)
var labeparabutonpanel = ui.Panel(
    [labeparabutonpanel,labeparabutonpanel2,  ui.Button('Cerrar', function(h){h = Map2.remove(labeparabutonpanel)})],
    ui.Panel.Layout.Flow('vertical'), {margin: '0 0 0 auto', width: '300px'});
var booootomm = ui.Button('Atención ????...', function(i){i = Map2.add(labeparabutonpanel) })
var buttonPanel = ui.Panel(
    [ui.Button('cerrar resultados', clearResults), chartTypeToggleButton1, chartTypeToggleButton, booootomm],
    ui.Panel.Layout.Flow('horizontal'), {margin: '0 0 0 auto', width: '500px'});
var resultsPanel = ui.Panel({style: {position: 'top-left', backgroundColor: 'orange'}});
Map2.add(resultsPanel);
clearResults();
      }
    })
    ///////////////////////////////////////////////Campaña 2019-2020//////////////////////////////////////////////////////
    var campana2= ui.Checkbox({
      label : 'Campaña 2019-2020',
       onChange: function(i){
         ///////////////////Cultivos//////////////////
        var Maiz = ui.Checkbox({
          label: 'Maiz',
          onChange: function (Maiz){
            Map1.layers().get(0).setShown(Maiz)
            Map2.layers().get(0).setShown(Maiz)
          }
        })
        var filtro8 = filtroC.filter(ee.Filter.eq('Actividad', 'Maiz'))
        // Map1.addLayer(filtro4.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        // Map2.addLayer(filtro4.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        Map1.addLayer(ndvi20192020.map(function(i){return i.clip(filtro8)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20192020.map(function(i){return i.clip(filtro8)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        var Soja = ui.Checkbox({
          label: 'Soja',
          onChange: function (Soja){
            Map1.layers().get(1).setShown(Soja)
            Map2.layers().get(1).setShown(Soja)
          }
        })
        var filtro9 = filtroC.filter(ee.Filter.eq('Actividad', 'Soja'))
        // Map1.addLayer(filtro5.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        // Map2.addLayer(filtro5.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        Map1.addLayer(ndvi20192020.map(function(i){return i.clip(filtro9)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20192020.map(function(i){return i.clip(filtro9)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        var Trigo= ui.Checkbox({
          label: 'Trigo',
          onChange: function (Trigo){
            Map1.layers().get(2).setShown(Trigo)
            Map2.layers().get(2).setShown(Trigo)
          }
        })
        var filtro10 = filtroC.filter(ee.Filter.eq('Actividad', 'Trigo'))
        // Map1.addLayer(filtro6.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        // Map2.addLayer(filtro6.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        Map1.addLayer(ndvi20192020.map(function(i){return i.clip(filtro10)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20192020.map(function(i){return i.clip(filtro10)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        var Girasol= ui.Checkbox({
          label: 'Girasol',
          onChange: function (Girasol){
            Map1.layers().get(3).setShown(Girasol)
            Map2.layers().get(3).setShown(Girasol)
          }
        })
        var filtro11 = filtroC.filter(ee.Filter.eq('Actividad', 'Girasol'))
        // Map1.addLayer(filtro7.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        // Map2.addLayer(filtro7.style({fillColor: '00000000', width: 3, color: 'orange'})).setShown(false)
        Map1.addLayer(ndvi20192020.map(function(i){return i.clip(filtro11)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map2.addLayer(ndvi20192020.map(function(i){return i.clip(filtro11)}), {bands: ['NDVI'], min: -0.15, max: 0.9, palette: ['blue', 'black', 'white', 'yellow', 'green', 'red']}).setShown(false)
        Map1.centerObject(countries,13)
        Map2.centerObject(countries,13)
        ////////////////////////////////atras//////////////////////////////////////////
        var labelmapa2= ui.Label('Haga click en el lote para mas información', {position: 'top-left'})
        var atrascultivo= ui.Checkbox({
          label: 'Atras',
          onChange: function(atras){
            atras = Map1.remove(panelcultivos)
            atras = Map2.remove(labelmapa2)
            atras = Map1.clear()
            atras = Map2.clear()
            atras = Map1.add(panelcampana)
           }
        })
         var label = ui.Label('Cultivos de la Campaña 2019-2020')
         var panelcultivos = ui.Panel({
           widgets: [label , Maiz, Soja, Trigo, Girasol, atrascultivo ],
           style: {
        position: 'top-right'}
         })
         i = Map1.remove(panelcampana)
         i = Map1.add(panelcultivos)
         i = Map2.add(labelmapa2)
/*
 * The chart panel in the bottom-right
 */
// A list of points the user has clicked on, as [lon,lat] tuples.
var selectedPoints = [];
// Returns the list of countries the user has selected.
function getSelectedCountries() {
  return countries.filterBounds(ee.Geometry.MultiPoint(selectedPoints));
}
// conruie grafico de barra 
function graficondvi(countries) {
  var coleccionndvi = ee.ImageCollection("COPERNICUS/S2")
   .filterBounds(countries)
   .filterDate('2017-02-01', '2020-08-31')
   .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 1)
   .map(function(n){
     var ndvi = n.normalizedDifference(['B8','B4'])
     n = n.addBands(ndvi.rename('NDVI'))
     return n.clip(countries)
   })
  var chart = ui.Chart.image.seriesByRegion(coleccionndvi, countries, ee.Reducer.mean(), 'NDVI', 10, null, 'Lotes');
  chart.setChartType('LineChart');
  // chart.setSeriesNames(countries)
  chart.setOptions({
    title: 'Grafico de Indice Verde (NDVI) por lote seleccionado',
    vAxis: {title: null},
    hAxis: {title: 'Fecha', format: 'YYYY-MM'},
    backgroundColor: 'orange',
    series:{
      0: {color: 'green'}
    } ,
    is3D: true
  });
  chart.style().set({stretch: 'both'});
  return chart;
}
function makeResultsBarChart(countries) {
  var chart = ui.Chart.feature.byFeature(countries, 'Activi-var','supha');
  chart.setChartType('PieChart');
  chart.setSeriesNames(countries)
  chart.setOptions({
    title: '% de superficie ocupada por lote en relacion a los lotes seleccionados',
    vAxis: {title: null},
    hAxis: {title: 'Superficie en hectareas', minValue: 0},
    pointShape: 'star',
    pointSize: 7,
    backgroundColor: 'orange',
    series:{
      0: {color: 'green'}
    } ,
    is3D: true
  });
  chart.style().set({stretch: 'both'});
  return chart;
}
// hacer resultados en tabla
function makeResultsTable(countries) {
  var table = ui.Chart.feature.byFeature(countries, 'Lotes');
  table.setChartType('Table');
  table.setOptions({allowHtml: true, pageSize: 5});
  table.style().set({stretch: 'both'});
  return table;
}
// actualiza de los layer por campo
function updateOverlay() {
  var overlay = getSelectedCountries().style(HIGHLIGHT_STYLE);
  Map2.layers().set(2, ui.Map.Layer(overlay));
}
// Updates the chart using the currently-selected charting function,
function updateChart() {
  var chartBuilder = chartTypeToggleButton.value;
  var chart = chartBuilder(getSelectedCountries());
  resultsPanel.clear().add(chart).add(buttonPanel);
}
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  selectedPoints = [];
  Map2.layers().remove(Map2.layers().get(2));
  var instructionsLabel = ui.Label('Seleccionar campos para mas información', {backgroundColor: 'orange'});
  resultsPanel.widgets().reset([]);
}
// Register a click handler for the map that adds the clicked point to the
// list and updates the map overlay and chart accordingly.
function handleMapClick(location) {
  selectedPoints.push([location.lon, location.lat]);
  updateOverlay();
  updateChart();
}
Map2.onClick(handleMapClick);
// A button widget that toggles (or cycles) between states.
// To construct a ToggleButton, supply an array of objects describing
// the desired states, each with 'label' and 'value' properties.
function ToggleButton(states, onClick) {
  var index = 0;
  var button = ui.Button(states[index].label);
  button.value = states[index].value;
  button.onClick(function() {
    index = ++index % states.length;
    button.setLabel(states[index].label);
    button.value = states[index].value;
    onClick();
  });
  return button;
}
// Our chart type toggle button: the button text is the opposite of the
// current state, since you click the button to switch states.
var chartTypeToggleButton = ToggleButton(
    [
      {
        label: 'Tabla de Datos',
        value: makeResultsBarChart,////////corresponde a grafico 
      },
      {
        label: '% de superficie Ocupada',
        value: makeResultsTable,/////corresponde a tabla
      }
    ],
    updateChart);
////////PARA BOTON DE NDVI//////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
// actualiza de los layer por campo
function updateOverlay1() {
  var overlay = getSelectedCountries().style(HIGHLIGHT_STYLE);
  Map2.layers().set(2, ui.Map.Layer(overlay));
}
// Updates the chart using the currently-selected charting function,
function updateChart1() {
  var chartBuilder = chartTypeToggleButton1.value;
  var chart = chartBuilder(getSelectedCountries());
  resultsPanel.clear().add(chart).add(buttonPanel);
}
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  selectedPoints = [];
  Map2.layers().remove(Map2.layers().get(2));
  var instructionsLabel = ui.Label('Seleccionar campos para mas información', {backgroundColor: 'orange'});
  resultsPanel.widgets().reset([]);
}
// Register a click handler for the map that adds the clicked point to the
// list and updates the map overlay and chart accordingly.
function handleMapClick1(location) {
  selectedPoints.push([location.lon, location.lat]);
  updateOverlay1();
  updateChart1();
}
Map2.onClick(handleMapClick1);
// A button widget that toggles (or cycles) between states.
// To construct a ToggleButton, supply an array of objects describing
// the desired states, each with 'label' and 'value' properties.
function ToggleButton1(states, onClick) {
  var index = 0;
  var button = ui.Button(states[index].label);
  button.value = states[index].value;
  button.onClick(function() {
    index = ++index % states.length;
    button.setLabel(states[index].label);
    button.value = states[index].value;
    onClick();
  });
  return button;
}
// Our chart type toggle button: the button text is the opposite of the
// current state, since you click the button to switch states.
var chartTypeToggleButton1 = ToggleButton1(
    [
      {
        label: 'Grafico de NDVI',
        value: graficondvi,
      },
      {
        label: 'Grafico de NDVI',
        value: graficondvi,
      }
    ],
    updateChart1);
// A panel containing the two buttons .
var labeparabutonpanel = ui.Label('¡ Importante!!!!!!!!!')
var labeparabutonpanel2 = ui.Label('Al hacer click en el mapa, en primer orden se mostrara un grafico'+
', con datos de indice verde del lote seleccionado, posteriormente '+
', se puede seleccionar la tabla con un resumen de información de campo'+
', como un grafico de la superficie ocupada en % por los lotes seleccionados'+
' en relacion a la cantidad total de lotes seleccionados'
)
var labeparabutonpanel = ui.Panel(
    [labeparabutonpanel,labeparabutonpanel2,  ui.Button('Cerrar', function(h){h = Map2.remove(labeparabutonpanel)})],
    ui.Panel.Layout.Flow('vertical'), {margin: '0 0 0 auto', width: '300px'});
var booootomm = ui.Button('Atención ????...', function(i){i = Map2.add(labeparabutonpanel) })
var buttonPanel = ui.Panel(
    [ui.Button('cerrar resultados', clearResults), chartTypeToggleButton1, chartTypeToggleButton, booootomm],
    ui.Panel.Layout.Flow('horizontal'), {margin: '0 0 0 auto', width: '500px'});
var resultsPanel = ui.Panel({style: {position: 'top-left', backgroundColor: 'orange'}});
Map2.add(resultsPanel);
clearResults();
      }
    })
    var labelmapa2= ui.Label('Haga click en el lote para mas información', {position: 'top-left'})
    var atras1 = ui.Checkbox({
      label: 'Atras',
      onChange: function (atras){
        atras = Map1.remove(panelcampana)
        atras = Map2.remove(labelmapa2)
        atras = Map1.add(panel)
      }
    })
    var panelcampana = ui.Panel({
      widgets: [campana, campana1, campana2, atras1],
      style: {
        position: 'top-right',
      }
    })
    f = Map1.add(panelcampana)
  },
})
var splitpanel = ui.SplitPanel({
  firstPanel: Map2, 
  secondPanel: Map1, 
  wipe: true})
  var panel = ui.Panel({
    widgets: [establecimiento],
    style: {
        position: 'top-right'}
  })
var labelentrada = ui.Label(
'Bienvenido a tu APP '+
'Cómo te encuentras hoy????? '+
'Recuerda ser felízz cada día', {fontSize: '35px', color: 'indigo' , backgroundColor: 'orange', position: 'top-left'})
var paneldepresentacion1 = ui.Panel(
  [labelentrada],
  ui.Panel.Layout.flow('vertical'),
  {margin: '0 0 0 auto', width: '500px', backgroundColor: 'orange', position: 'top-center'})
var paneldepresentacion2 = ui.Panel(
  [paneldepresentacion1],
  ui.Panel.Layout.flow('vertical'),
  {margin: '0 0 0 auto', width: '750px', backgroundColor: 'red', position: 'top-center'})
var paneldepresentacion3 = ui.Panel(
  [paneldepresentacion2],
  ui.Panel.Layout.flow('vertical'),
  {margin: '0 0 0 auto', width: '925px', backgroundColor: 'green', position: 'top-center'})
var paneldepresentacion4 = ui.Panel(
  [paneldepresentacion3, ui.Label('creo en vosss', {fontSize: '25px',backgroundColor: 'yellow'})],
  ui.Panel.Layout.flow('vertical'),
  {margin: '0 0 0 auto', width: '1200px', backgroundColor: 'yellow', position: 'top-center'})
var paneldepresentacion = ui.Panel(
  [paneldepresentacion4, ui.Button('Entrar', function(h){
    h = ui.root.remove(paneldepresentacion)
    h = ui.root.clear()
    h = Map1.add(panel)
    h = ui.root.add(splitpanel)
  })],
  ui.Panel.Layout.Flow('vertical'),
  {margin: '0 0 0 auto', width: '1300px', backgroundColor: 'cyan', position: 'top-right'})
ui.root.clear()
ui.root.add(paneldepresentacion)
Map1.centerObject(Argentina, 6)
Map2.centerObject(Argentina, 6)