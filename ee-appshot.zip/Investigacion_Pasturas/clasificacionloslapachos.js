var abra = ui.import && ui.import("abra", "table", {
      "id": "users/Investigacion_Pasturas/abra_Los_Lapachos"
    }) || ee.FeatureCollection("users/Investigacion_Pasturas/abra_Los_Lapachos"),
    monte = ui.import && ui.import("monte", "table", {
      "id": "users/Investigacion_Pasturas/monte_Los_Lapachos"
    }) || ee.FeatureCollection("users/Investigacion_Pasturas/monte_Los_Lapachos"),
    monte_ralo = ui.import && ui.import("monte_ralo", "table", {
      "id": "users/Investigacion_Pasturas/monte_ralo_Los_Lapachos1"
    }) || ee.FeatureCollection("users/Investigacion_Pasturas/monte_ralo_Los_Lapachos1"),
    galpones = ui.import && ui.import("galpones", "table", {
      "id": "users/Investigacion_Pasturas/galpones_Los_Lapachos"
    }) || ee.FeatureCollection("users/Investigacion_Pasturas/galpones_Los_Lapachos"),
    pasto = ui.import && ui.import("pasto", "table", {
      "id": "users/Investigacion_Pasturas/pasto_Los_Lapachos"
    }) || ee.FeatureCollection("users/Investigacion_Pasturas/pasto_Los_Lapachos"),
    calles = ui.import && ui.import("calles", "table", {
      "id": "users/Investigacion_Pasturas/calles_Los_Lapachos"
    }) || ee.FeatureCollection("users/Investigacion_Pasturas/calles_Los_Lapachos"),
    Monte = ui.import && ui.import("Monte", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#ff3900",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff3900 */
    /* shown: false */
    ee.Geometry.MultiPoint(),
    Monte_ralo = ui.import && ui.import("Monte_ralo", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#5f9f00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #5f9f00 */
    /* shown: false */
    ee.Geometry.MultiPoint(),
    Abra = ui.import && ui.import("Abra", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#fbff04",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #fbff04 */
    /* shown: false */
    ee.Geometry.MultiPoint(),
    Pasto_sin_arboles = ui.import && ui.import("Pasto_sin_arboles", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#ffc82d",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.Geometry.MultiPoint(),
    Calles_suelo_desnudo = ui.import && ui.import("Calles_suelo_desnudo", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#f5fffc",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #f5fffc */
    /* shown: false */
    ee.Geometry.MultiPoint(),
    Galpones_de_pollos = ui.import && ui.import("Galpones_de_pollos", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#040004",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #040004 */
    /* shown: false */
    ee.Geometry.MultiPoint();
var app = function(image){
  //pixeles
var pixeles = ee.FeatureCollection('users/carlosnavarrochamical/TodoslosPixelesMODIS')
//campos de todos los prductores
var campos = ee.FeatureCollection('users/carlosnavarrochamical/camposdetodoslosproductores')
//definición de clases
var clases = abra.merge(monte_ralo).merge(monte).merge(galpones).merge(pasto).merge(calles)
//definir zonas de entrenamiento
print('clases', clases)
var entrenamiento = image.sampleRegions({
  collection: clases, 
  properties: ['ID'], 
  scale: 3, 
  projection: 'EPSG:4326'
})
//Clasificador
var clasificador = ee.Classifier.cart()
clasificador = clasificador.train({
  features: entrenamiento,
  classProperty: 'ID',
  inputProperties: ['b1', 'b2', 'b3', 'b4']
})
//clasificacion
var clasificacion = image.classify(clasificador)
image = image.addBands(clasificacion.rename('class'))
return image.clip(campos)
}
//coleccion de imagenes
var images = ee.ImageCollection('users/Investigacion_en_pasturas/Los_Lapachos').map(app)
// print('coleccion',coleccion)
// var clas = clasificacion.clip(pixeles)
// var clas1 = clasificacion.clip(campos)
// Map.addLayer(clas, {palette: ['yellow', 'green', 'red'], min: 1, max: 3}, 'imagen clasificada pixel')
// Map.addLayer(coleccion, {bands: ['class'], palette: ['yellow', 'green', 'red', 'black', 'orange', 'white'], min: 1, max: 6}, 'imagen clasificada campo')
// Map.addLayer(coleccion, {bands: ['b3', 'b2', 'b1'], min: 400, max: 1400}, 'imagen rgb')
//animación de la clasificación
//campos de todos los prductores
var campos = ee.FeatureCollection('users/carlosnavarrochamical/camposdetodoslosproductores')
var animation = require('users/gena/packages:animation')
var text = require('users/gena/packages:text')
var charting = require('users/gena/packages:charting')
var start = ee.Date('2019-08-01')
var stop = ee.Date('2020-08-31')
var geometry = ee.Geometry.Rectangle([[-59.733881439980316,-28.772122809483925],[-59.66984979758431,-28.745644608639168]])
var geometryPlot = ee.Geometry.Rectangle([[-59.73233453879525,-28.74775167695971],[-59.67087976584603,-28.74639713791882]])
geometry = geometry.bounds()
geometryPlot = geometryPlot.bounds()
Map.centerObject(geometry, 14)
var bounds = ee.Geometry(Map.getBounds(true))
var scale = Map.getScale()
var plot = new charting.Plot(geometryPlot)
plot.setMinMax(start.millis(), stop.millis(), 0, 1)
var times = ee.List(images.aggregate_array('system:time_start'))
plot.addRugSeries('rug S1', times, { width: 1.5, color: 'green' }, 1)
// get plot image
var plotImage = plot.getImage()
images = images.map(function(i) {
  // brush
  var position = ee.Geometry(plot.getVLine(i.get('system:time_start')).buffer(scale * 3).bounds())
  var brush = ee.FeatureCollection(position)
    .style({ width: 2, color: 'orange', fillColor: 'white' })
  // image
var image = i
    .visualize({bands: ['class'], palette: ['yellow', 'green', 'red', 'black', 'orange', 'white'], min: 1, max: 6})
    .clip(campos)
  // time label
  var pt =  text.getLocation(geometry, 'left', '15%', '3%')
  var time = i.date().format('YYYY-MM-dd').cat(' Campo UAA-Lanteri-CS')
  var label = text.draw(time, pt, scale, { 
    fontSize: 24, textColor: '000000', fontType: 'Consolas',
    outlineColor: 'ffffff', outlineWidth: 2.5, outlineOpacity: 0.8
  })
  // blend
  return image
    .blend(plotImage)
    .blend(brush)
    .blend(label)
    .set({ label: time })
})
animation.animate(images, {label: 'label', maxFrames: 100})
// Export.video.toDrive({
//   collection: images,
//   region: geometry,
//   description: 'video_de_clasificacion', 
//   framesPerSecond: 2, 
// })
// Export.table.toDrive({
//   collection: galpones, 
//   description: 'galpones', 
//   fileFormat: 'KMZ'})
// Export.table.toDrive({
//   collection: geometry, 
//   description: 'pasto', 
//   fileFormat: 'KMZ'})
// Export.table.toDrive({
//   collection: geometryPlot, 
//   description: 'geometryPlot', 
//   fileFormat: 'KMZ'})