// LEAF-Toolbox-SL2P
// 
/* GEE Javascript implementation of the 
   Simplified Level 2 Processor of Weiss and Baret (2016). 
 Input: Collection of either Landsat 5 or Landsat 7 or Landsat 8 
        or Sentinel 2a or Sentinel 2b surface reflectance products.
        Imported EE asset with polygon features used to define spatial output region.
        By default only the first polygon is used.  However, you can change the feature number
        in the first line of the script.
        Links toEE assets networks and a land cover map using the
        North American Land Cover 2015 30m legend.
        http://www.cec.org/tools-and-resources/map-files/land-cover-30m-2015-landsat-and-rapideye
        By default the SL2P algorithm is implemented for supported collections.
        To use other algorithms comment out the SL2P algorithm assets below and 
        uncomment the desired algorithm ( e.g. CCRS) and run the code.
 Output: Unsigned int16 geotiff with layers
            1.  Estimate scaled by 1000
            2.  Standard error of estimates caled by 1000
            3.  Network number 
            4.  Quality control flags coded in binary flags
            5.  Land cover class
            6.  Days since January 1, 1970 inclusive
          One of the following quantities are estimated 
          Albedo: Black sky albedo at 10:30 local time.
          D:      Directional canopy scattering factor.
          fAPAR:  Fraction of absorbed photosynthetically active radiation, black sky at 10:30 local time.
          fCover: Fraction of canopy cover.
          LAI:    Leaf area index.
          CCC:    Canopy chlorophyll content.
          CWC:    Canopy water content.
.                                        */
/*--------------------------------------------------------------------------------*/
/*Start of user specification                                                     */
/*--------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------*/
/* Region of interest , optional                                                  */
/*--------------------------------------------------------------------------------*/
//var featureNumber = ee.Number(1);
//var geometry = ee.FeatureCollection(ee.Feature(table.toList(table.size()).get(featureNumber))).geometry();
/*--------------------------------------------------------------------------------*/
/* Start of Helper functions                                                      */
/*--------------------------------------------------------------------------------*/
// convert number to string for mapping onto list
var toString = function(number) {
  return(ee.String(number));
};
/*--------------------------------------------------------------------------------*/
/* End  of Helper functions                                                      */
/*--------------------------------------------------------------------------------*/
// The namespace for our application.  All the state is kept in here.
var app = {};
// Read coefficients of a network from csv EE asset
//
// Should be deprecated to having a dictionary of tensor flow records
var getcoefs = function(netData,ind) {
  return((ee.Feature(netData)).getNumber(ee.String('tabledata').cat(ee.Number(ind).int())));
};
// Parse one row of CSV file for a network into a global variable
//
// We assume a two hidden layer network with tansig functions but
// allow for variable nodes per layer/
//
// Should be deprecated to parsing tensor flow records
var makeNets = function(feature, M) {
  var feature = ee.List(feature);
  var M = ee.Number(M);
  // get the requested network and initialize the created network
  var netData = ee.Feature(feature.get(M.subtract(1)));
  var net = {};
  // input slope
  var num = ee.Number(6);
  var start = num.add(1);
  var end = num.add(netData.getNumber(ee.String('tabledata').cat(ee.String(num))));
  net.inpSlope = ee.List.sequence(start,end).map(getcoefs.bind(null,netData));
  // input offset
  num = end.add(1);
  start = num.add(1);
  end = num.add(netData.getNumber(ee.String('tabledata').cat(ee.String(num))));
  net.inpOffset = ee.List.sequence(start,end).map(getcoefs.bind(null,netData));
  // hidden layer 1 weight
  num = end.add(1);
  start = num.add(1);
  end = num.add(netData.getNumber(ee.String('tabledata').cat(ee.String(num))));
  net.h1wt = ee.List.sequence(start,end).map(getcoefs.bind(null,netData));
  // hidden layer 1 bias
  num = end.add(1);
  start = num.add(1);
  end = num.add(netData.getNumber(ee.String('tabledata').cat(ee.String(num))));
  net.h1bi = ee.List.sequence(start,end).map(getcoefs.bind(null,netData));
  // hidden layer 2 weight
  num = end.add(1);
  start = num.add(1);
  end = num.add(netData.getNumber(ee.String('tabledata').cat(ee.String(num))));
  net.h2wt = ee.List.sequence(start,end).map(getcoefs.bind(null,netData));
  // hidden layer 2 bias
  num = end.add(1);
  start = num.add(1);
  end = num.add(netData.getNumber(ee.String('tabledata').cat(ee.String(num))));
  net.h2bi = ee.List.sequence(start,end).map(getcoefs.bind(null,netData));
  // output slope
  num = end.add(1);
  start = num.add(1);
  end = num.add(netData.getNumber(ee.String('tabledata').cat(ee.String(num))));
  net.outSlope = ee.List.sequence(start,end).map(getcoefs.bind(null,netData));
  // output offset
  num = end.add(1);
  start = num.add(1);
  end = num.add(netData.getNumber(ee.String('tabledata').cat(ee.String(num))));
  net.outBias = ee.List.sequence(start,end).map(getcoefs.bind(null,netData));
  return(ee.Dictionary(net));
};
// Parse CSV file with list of networks for a selected variable  
//
// This will parse one network for each landclass partition
var makeNetVars = function(assetName, variableNum){
   var asset= ee.FeatureCollection(assetName);
   var variable= ee.Number(variableNum);
   // Determine the network we need based on land cover partition
   var landclass = ee.Number(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Network_Ind.first()).propertyNames().remove('system:index').remove('lon').size()).subtract(1);
  // get selected network 
  var list_features = asset.flatten();
  var filtered_features = ee.FeatureCollection(asset.filter(ee.Filter.eq('tabledata3', variable))).toList(landclass);
  //Features should be one feature from each class for that variable
  var netList = ee.List.sequence(1,landclass).map(makeNets.bind(null,filtered_features));
  var net = netList.add(ee.Feature(assetName.first()).id());
  return(net);
};
// Applies the selection filters currently selected in the UI. 
app.applyFilters = function() {
  // set message we are loading images
  app.setLoadingMode(true);
  // Refresh the map layer.
  //app.refreshMapLayer();
  // Set filter variables.
  //Change to only take the first in the collection for debugging
  var start = app.filters.startDate.getValue();
  var end = app.filters.endDate.getValue();
  var filtered = ee.ImageCollection(app.filters.selectCollection.getValue())
                   .filterBounds(app.filters.mapBounds)
                   .filterDate(start[1], end[1])
                   .filterMetadata((app.COLLECTION_OPTIONS[app.filters.selectCollection.getValue()]).Cloudcover,'less_than',app.filters.maxCloudcover.getValue())
                   .filterMetadata((app.COLLECTION_OPTIONS[app.filters.selectCollection.getValue()]).Watercover,'less_than',ee.Number(100))
                   .limit(5000);
  // Display how many granules were found 
  print('Found product granules');
  print(filtered);
  // Get the list of computed ids.
  var computedIds = filtered.limit(app.IMAGE_COUNT_LIMIT)
                            .reduceColumns(ee.Reducer.toList(), ['system:index'])
                            .get('list');
  // updathe the UI and proceed only if we get products
  computedIds.evaluate(function(ids) {
    // Update the image picker with the given list of ids.
    app.setLoadingMode(false);
    app.picker.select.items().reset(ids);
    // Default the image picker to the first id.
    app.picker.select.setValue(app.picker.select.items().get(0));
    // Disable the all images checbox
    app.picker.allImages.setValue(false);
  });
    // Refresh the map layer.
  app.refreshMapLayer();
};
var makeCodeImage = function(bandlist, images){
  var images = ee.Image(images);
  var bandlist = ee.List(bandlist);
  var netOptions = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()];
  var scale = netOptions.inpCode;
  var inp = images.select(bandlist).multiply(0.001).round().multiply(0.1);
  //Multiply the input values by the inp array 
   var code= scale.multiply(ee.Image(inp.toArray())
                                    .arrayProject([0])
                                    .arrayFlatten([inp.bandNames()]))
                     .reduce('sum').int8();
 return(ee.Image([0]).addBands(code));
};
// Determine if inputs fall in domain of algorithm
// Need to be updated to allow for the domain to vary with partition
var InvalidInput = function(image){
  //Determine input features used for this collection
  var netOptions = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()];
  var inp = ee.List(netOptions.inp);
  //Determine domaine for this network
  var table = ee.Feature(ee.FeatureCollection(app.COLLECTION_OPTIONS[app.collectionName].sl2pDomainAssetName).first()).toDictionary();
  var getList = function(ind){
    //   var num = table.getNumber(ee.String('Var').cat(ee.Number(ind).int()));  This was for Camryns domains
  var num = table.getNumber(ee.String((ee.Number(ind).int())));
  return(num);
  };
  var netDomain = ee.List.sequence(1,table.size()).map(getList);
  //remap inputs to either 1 or 0 as the second bit in the code code band
  var codeBand = makeCodeImage(inp, image).remap(netDomain, ee.List.repeat(11, netDomain.length()),1,'sum');                   
   var codeImage = image.addBands(codeBand.rename('code'));
 return(codeImage);
 //return(image.updateMask(codeBand));
};
var getClassColl = function(img, landclass){
  var landclass = ee.Number(landclass);
  var img = ee.Image(img);
  var class_col = {};
  var code_layer = img.select('remapped');
  var updated_image = img.updateMask(code_layer.eq(landclass));
    //initialize dictionary 
    class_col.img = updated_image.select(ee.List(img.bandNames()).remove('remapped').remove('partition'));
    class_col.ind = ee.Number(landclass).int();
  return (class_col);
};
var applyNet = function(netList,class_col) {
  // Adds visualization band to collection
  var class_col = ee.Dictionary(class_col);
  var netList = ee.List(netList);
  var inp = ee.Image(class_col.get('img'));
  var net = ee.Dictionary(netList.get(ee.Number(class_col.get(ee.String('ind')))));
  // Input scaling
  var l1inp2D = inp.multiply(ee.Image(net.toArray(ee.List(['inpSlope']),0).transpose())
                                          .arrayProject([0])
                                          .arrayFlatten([inp.bandNames()]))
                   .add(ee.Image(net.toArray(ee.List(['inpOffset']),0).transpose())
                                          .arrayProject([0])
                                          .arrayFlatten([inp.bandNames()]));
  // Hidden layers
  var l12D = ee.Image(net.toArray(ee.List(['h1wt']),0).reshape([ee.List(net.get('h1bi')).length(),ee.List(net.get('inpOffset')).length()]))
              .matrixMultiply(l1inp2D.toArray().toArray(1))
              .add(ee.Image(net.toArray(ee.List(['h1bi']),0).transpose()))
              .arrayProject([0]).arrayFlatten([['h1w1','h1w2','h1w3','h1w4','h1w5']]);
  // apply tansig 2/(1+exp(-2*n))-1
  var l2inp2D = ee.Image(2)
                  .divide(ee.Image(1)
                            .add((ee.Image(-2).multiply(l12D)).exp()))
                            .subtract(ee.Image(1));
  // purlin hidden layers
  var l22D = l2inp2D.multiply(ee.Image(net.toArray(ee.List(['h2wt']),0).transpose())
                                          .arrayProject([0])
                                          .arrayFlatten([['h2w1','h2w2','h2w3','h2w4','h2w5']]))
                    .reduce('sum')
                    .add(ee.Image(net.toArray(ee.List(['h2bi']),0)))
                                          .arrayProject([0])
                                          .arrayFlatten([['h2bi']]);
  // Output scaling
      var outputBand = l22D.subtract(ee.Image(ee.Number(net.get('outBias'))))
                    .divide(ee.Image(ee.Number(net.get('outSlope'))))
                    .rename(ee.String(netList.get(netList.size().subtract(1))));
 // Return network output
  return (outputBand);
};
// makes combined network index and qc code layer
var make_codeLayer = function(landclass, list){
  var landclass = ee.Image(landclass);
  var bit_layer = landclass.remap(ee.List.sequence(0,list.size().subtract(1)),list,0,'remapped');
  // print(bit_layer);
  var qu_layer = landclass.select('code');
  var bit = bit_layer.select(['remapped'],['flag']);
  var code_band = ee.Image(bit.multiply(ee.Image([100]))).add(qu_layer);
  return (code_band);
};
//returns  
var make_bitList = function(num){
  var n = ee.Number(num);
  var binaryNum =ee.List.repeat(0,6);
  for(var i=0; i<6; i++){
    binaryNum =binaryNum.set(i,ee.Number(n.mod(2).toInt()));
    n = n.subtract(n.mod(2)).divide(2);
  }
  var scale= ee.Array([1,10,100,1000,10000,100000]);
  return(ee.Array(binaryNum).dotProduct(scale));
};
//returns image with remapped landclass indexes
var make_indexLayer = function(image){
  var legend = ee.FeatureCollection(app.COLLECTION_OPTIONS[app.collectionName].legend);
  var landcover_list = legend.toList(legend.size());
  var landclass = landcover_list.map(function(feature){return ee.Feature(feature).get('SL2P Network');});
  // print(landclass);
  var landcover= landcover_list.map(function(feature){return ee.Feature(feature).getNumber('Value');});
   //  print(landcover);
  var landclass_re = landclass.map(function(property){return ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Network_Ind.first()).toDictionary().getNumber(property);});
    //   print(landclass_re);
  var indexLayer = image.remap(landcover, landclass_re, 0, 'partition');
return(image.addBands(indexLayer));
};
// applies a set of shallow networks to an image based on a provided land cover map
var wrapperNNets = function(network, filtered_col){
  // typecast function parameters
  var network = ee.List(network);
  var filtered_col = ee.Image(filtered_col);
  // parse land classes used to identify network to use
  var partition = app.COLLECTION_OPTIONS[app.collectionName].partition.mosaic().clip(filtered_col.geometry()).select(['partition'],['partition']);
  var landclass = ee.Number(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Network_Ind.first()).propertyNames().remove('system:index').remove('lon').size()).subtract(2);
  // determine networks based on collection
  var netOptions = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()];
  var netList = ee.List(network.get(ee.Number(netOptions.variable).subtract(1))); 
  // extract solar angles, input features and land cover for this image
  var inp = ee.Image([1])
              .addBands((filtered_col.metadata(netOptions.sza)).multiply(3.1415).divide(180).cos()) 
              .addBands((filtered_col.metadata(netOptions.saa)).multiply(3.1415).divide(180).cos()) 
              .addBands(filtered_col.select(netOptions.inp).multiply(0.0001))
              .addBands(app.COLLECTION_OPTIONS[app.collectionName].partition.mosaic().clip(filtered_col.geometry()));
  // parse land cover into network index
  var landclass_inp = make_indexLayer(inp);
  //Send the image to another function which takes the image bands from ranges and remaps to landclass
  var class_list = ee.List.sequence(1, landclass).map(getClassColl.bind(null,landclass_inp));
  // Produce the estimated variable 
  // not sure why the max function is applied
  var outputBand = ee.ImageCollection(class_list.map(applyNet.bind(null,netList))).max();
  //Produce domain and range quality flags
  var bit_list = ee.List.sequence(0,landclass).map(make_bitList);
  var to_codeLayer = make_codeLayer(landclass_inp.addBands(filtered_col.select('code')),bit_list);
  // return the original image with the estimated variable and the quality flag     
  return (ee.Image(filtered_col).addBands(outputBand).addBands(to_codeLayer).addBands(partition));
};
// sentinel 2 land mask
var s2Mask = function(image) {
  var mask = (image.select('SCL').eq(4)).or(image.select('SCL').eq(5));
  return (image.updateMask(mask));
};
// landsat 8  land mask
// clear and no water, cloud shadow, snow, clouds or terrain obstructuon
var l08Mask = function(image) {
  var qa = image.select('pixel_qa');
  var mask = qa.bitwiseAnd(1).eq(0)
                  .and(qa.bitwiseAnd(1<<2).eq(0))
                  .and(qa.bitwiseAnd(1<<3).eq(0))
                  .and(qa.bitwiseAnd(1<<4).eq(0))
                  .and(qa.bitwiseAnd(1<<5).eq(0));
  return (image.updateMask(mask));
};
// sentinel 2 land mask
var ccrss2Mask = function(image) {
  var mask = (image.select('b15').eq(4)).or(image.select('b15').eq(5));
  return (image.updateMask(mask));
};
// wrapper to use app.mask.sentinel2 with CCRS s2 data
var ccrsSentinel2 = function(image) {
    return image.rename(['B1','B2','B3','B4','B5','B6','B7','B8','B8A','B9','B11','B12','AOT','WVP','SCL','TCI_R','TCI_G','TCI_B','QA10','QA20','QA60','date']);
}
var ExportCol = function(col, folder, scale, type, nimg, maxPixels) {
  type = type || "float";
  nimg = nimg || 100;
  scale = scale || 20;
  maxPixels = maxPixels || 1e10;
  var colList = col.toList(nimg);
  var n = colList.size().getInfo();
  for (var i = 0; i < n; i++) {
    // restrict image to map bounds
    var img = ee.Image(colList.get(i)).clip(app.filters.mapBounds);
    // determine fi there are any valid values by checking for a null return om a reduces
    if ( img.select('timestart').reduceRegion({ reducer: ee.Reducer.max(), geometry: app.filters.mapBounds, scale: 100}) !== null) {
      print('exporting')
      var id = img.id().getInfo() + "_" + app.vis.select.getValue();
      // set up type conversions
      var imgtype = {"float":img.toFloat(), 
                     "byte":img.toByte(), 
                     "unsigned int8":img.toByte(),
                     "unsigned int16":img.toUint16(),
                     "int":img.toInt(),
                     "double":img.toDouble(),
                     "unsigned int32":img.toUint32()
                    };
      // export image for map bounds only using desired type
      Export.image.toDrive({
        image:imgtype[type],
        description: id,
        folder: app.folder[0],
        fileNamePrefix: id,
        scale: scale,
        region: app.filters.mapBounds,
        maxPixels: app.pixels[0]});
  }
  }
};
// add a 'date' band: number of days since epoch
var addDate = function(img) {
  var d = ee.Date(img.date()).millis().divide(86400000)
  var days_img = ee.Image.constant(d).rename('date').toUint16()
  return img.addBands(days_img)
}
//computes a delta time property for an image
var deltaTime = function(midDate,image) {
  return ee.Image(image.set("deltaTime",ee.Number(image.date().millis()).subtract(ee.Number(midDate)).abs()))
}
// Refreshes the current map layer based on the UI widget states. 
app.exportMapLayer = function() {
  print('in export')
  // subset collection to one image if required
  var netOptions = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()];
  var start = app.filters.startDate.getValue();
  var end = app.filters.endDate.getValue();
  var midDate = ee.Number(start[0]).add(ee.Number(end[0])).divide(2);
  if (app.picker.allImages.getValue()) {
    // filter collection for all products 
    var filtered =  ee.ImageCollection(app.filters.selectCollection.getValue())
                  .filterBounds(app.filters.mapBounds)
                  .filterDate(start[0], end[0])
                  .filterMetadata((app.COLLECTION_OPTIONS[app.filters.selectCollection.getValue()])
                                        .Cloudcover,'less_than',app.filters.maxCloudcover.getValue())
                  .map(addDate)
                  .map(function(image){return image.clip(app.filters.mapBounds)})
                  .map(deltaTime.bind(null,midDate))
                  .sort('deltaTime');
  }
  else {
    // process selected image only
    var filtered =  ee.ImageCollection(app.filters.selectCollection.getValue())
                  .filter(ee.Filter.eq('system:index',app.picker.select.getValue()))
                  .map(addDate)
                  .map(function(image){return image.clip(app.filters.mapBounds)})
                  .map(deltaTime.bind(null,midDate))
                  .sort('deltaTime');
  }
  print('filtered for export')
  print(filtered)
  switch (app.filters.selectCollection.getValue()) {
    //insert try catch statements 
    case  'COPERNICUS/S2_SR':
      switch (app.vis.select.getValue()) {
        case 'Surface_Reflectance':
          var visCollection = filtered;
          break;
        default:
          var visCollection = filtered.map(app.mask.sentinel2())
                                  .map(s2Mask)
                                  .map(InvalidInput)
                                  .map(wrapperNNets.bind(null,app.SL2P))
                                  .map(wrapperNNets.bind(null,app.errorSL2P))
                                  .map(function(image){return image.addBands({
                                    srcImg: image.select(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P.first()).id()).multiply(1000).rename(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P.first()).id()),
                                    overwrite: true})})                                  .map(function(image){return image.addBands({
                                    srcImg: image.select(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors.first()).id()).multiply(1000).rename(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors.first()).id()),
                                    overwrite: true})})
                                    .select([ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P.first()).id(), ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors.first()).id(),'code','flag','partition','date'] , [netOptions.Name , netOptions.errorName,'code','flag','partition','date']);
          break;
      }
      switch(app.exportID){
        case 'Image by Image':
          var export_image = ExportCol(visCollection, 'Image_Export',20,"unsigned int16",100);
          break;
        case 'Full Map Mosaic':
         var export_image = visCollection.mosaic().toUint16()
         Export.image.toDrive({
           image: export_image,
           description:app.collectionName.replace('/','_') + "_" + start[0] + "_" + end[0] + "_" + app.vis.select.getValue(),
           folder: app.folder[0],
           scale:20,
           maxPixels: app.pixels[0],
           });
          break;
      }
      break;
    case  'LANDSAT/LC08/C01/T1_SR':
      switch (app.vis.select.getValue()) {
        case 'Surface_Reflectance':
          var visCollection = filtered;
          break;
        default:
          var visCollection = filtered.map(app.mask.landsatSR())
                                      .map(l08Mask)
                                      .map(InvalidInput)
                                      .map(wrapperNNets.bind(null,app.SL2P))
                                      .map(wrapperNNets.bind(null,app.errorSL2P))
                                      .map(function(image){return image.addBands({
                                        srcImg: image.select(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P.first()).id()).multiply(1000).rename(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P.first()).id()),
                                        overwrite: true})})                                  .map(function(image){return image.addBands({
                                        srcImg: image.select(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors.first()).id()).multiply(1000).rename(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors.first()).id()),
                                        overwrite: true})})
                                        .select([ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P.first()).id(), ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors.first()).id(),'code','flag','partition'] , [netOptions.Name , netOptions.errorName,'code','flag','partition']);
          break;
      }
      switch(app.exportID){
        case 'Image by Image':
          var export_image = ExportCol(visCollection, 'Image_Export',30,"unsigned int16",100);
          break;
        case 'Full Map Mosaic':
          print('export mosaic')
         var export_image = visCollection.mosaic().toUint16()
         Export.image.toDrive({
           image: export_image,
           description:app.collectionName.replace('/','_') + "_" + start[0] + "_" + end[0] + "_" + app.vis.select.getValue(),
           folder: app.folder[0],
           scale:30,
           maxPixels: app.pixels[0],
           });
          break;
      }
    break;
    case  'users/rfernand387/L2avalidation':
      switch (app.vis.select.getValue()) {
        case 'Surface_Reflectance':
          var visCollection = filtered;
          break;
        default:
          var visCollection = filtered.map(ccrsSentinel2)
                                  .map(app.mask.sentinel2())
                                  .map(s2Mask)
                                  .map(InvalidInput)
                                  .map(wrapperNNets.bind(null,app.SL2P))
                                  .map(wrapperNNets.bind(null,app.errorSL2P))
                                  .map(function(image){return image.addBands({
                                    srcImg: image.select(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P.first()).id()).multiply(1000).rename(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P.first()).id()),
                                    overwrite: true})})                                  .map(function(image){return image.addBands({
                                    srcImg: image.select(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors.first()).id()).multiply(1000).rename(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors.first()).id()),
                                    overwrite: true})})
                                    .select([ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P.first()).id(), ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors.first()).id(),'code','flag','partition','date'] , [netOptions.Name , netOptions.errorName,'code','flag','partition','date']);
          break;
      }
      switch(app.exportID){
        case 'Image by Image':
          var export_image = ExportCol(visCollection, 'Image_Export',20,"unsigned int16",100);
          break;
        case 'Full Map Mosaic':
         var export_image = visCollection.map(addqualityIndex).qualityMosaic("timestart").toUint16();
         print('export mosaic')
         Export.image.toDrive({
           image: export_image,
           description:app.collectionName.replace('/','_') + "_" + start[0] + "_" + end[0] + "_" + app.vis.select.getValue(),
           folder: app.folder[0],
           scale:20,
           maxPixels: app.pixels[0],
           });
          break;
      }
    break;
    default: print('invalid collection for masking');
    break;
  }
};
/** Refreshes the current map layer based on the UI widget states. */
app.refreshMapLayer = function() {
  // clear map
  Map.clear();
  var netOptions = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()];
  // subset collection to one image if required
  if (app.picker.select.getValue()) {
    var start = app.filters.startDate.getValue();
    var end = app.filters.endDate.getValue();
    var midDate = ee.Number(start[0]).add(ee.Number(end[0])).divide(2);
    if (app.picker.allImages.getValue()) {
      // filter collection for all products 
      var filtered =  ee.ImageCollection(app.filters.selectCollection.getValue())
                    .filterBounds(app.filters.mapBounds)
                    .filterDate(start[0], end[0])
                    .filterMetadata((app.COLLECTION_OPTIONS[app.filters.selectCollection.getValue()])
                                          .Cloudcover,'less_than',app.filters.maxCloudcover.getValue())
                    .limit(5000)
                    .map(addDate)
                    .map(function(image){return image.clip(app.filters.mapBounds)})
                    .map(deltaTime.bind(null,midDate))
                    .sort('deltaTime');
    }
    else {
      // process selected image only
      var filtered =  ee.ImageCollection(app.filters.selectCollection.getValue())
                    .filter(ee.Filter.eq('system:index',app.picker.select.getValue()))
                    .map(addDate)
                    .map(function(image){return image.clip(app.filters.mapBounds)})
                    .map(deltaTime.bind(null,midDate))
                    .sort('deltaTime');
    }
    print('filtered')
    print(filtered)
    // mask based on collection
    switch (app.filters.selectCollection.getValue()) {
      case  'COPERNICUS/S2_SR':
        var filtered = filtered.map(app.mask.sentinel2())
                                .map(s2Mask);
      break;
      case  'LANDSAT/LC08/C01/T1_SR': 
        var filtered = filtered.map(app.mask.landsatSR())
                                .map(l08Mask);
      break;
      case  'users/rfernand387/L2avalidation': 
        var filtered = filtered.map(ccrsSentinel2)
                                .map(app.mask.sentinel2())
                                .map(s2Mask);
      break;
      default: print('Invalid collection');
      break;
    }
    // display based on parameter value
    var partition = app.COLLECTION_OPTIONS[app.collectionName].partition.mosaic().clip(app.filters.mapBounds).select(['partition'],['partition']);
    Map.addLayer(partition, {bands:'partition',min:0, max:20, palette:app.partitionPalettes.partitions.NALCMS[20]},'Land Cover');
    switch (app.vis.select.getValue()) {
      case 'Surface_Reflectance':
        // Just show a RgB composite
        var visMosaic = filtered.mosaic();
        Map.addLayer(visMosaic, { bands:'date'},'Date');
        Map.addLayer(visMosaic, app.COLLECTION_OPTIONS[app.collectionName].visParams , 'Surface_Reflectance');
      break;
      default:
        //apply regression to estimate parameter
        var visMosaic = filtered.map(InvalidInput) 
                              .map(wrapperNNets.bind(null,app.SL2P))
                              .map(wrapperNNets.bind(null,app.errorSL2P))
                              .select([ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P.first()).id(), ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors.first()).id(),'code','flag','partition','date'] , [netOptions.Name , netOptions.errorName,'code','flag','partition','date'])
                              .mosaic();
        //Displays the Collection of filtered images with the vis parameters 
        var visParams = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()]['outputParams'];
        var errorParams = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()]['errorParams'];
        Map.addLayer(visMosaic, { bands:'date'},'Date');
        Map.addLayer(visMosaic, { bands:'code'},'Quality Code'); 
        Map.addLayer(visMosaic, errorParams , netOptions.errorName);
        Map.addLayer(visMosaic, visParams , netOptions.Name);
      break;
    }
  }
}
//  Creates the UI panels. 
app.createPanels = function() {
  // The introduction section. 
  app.intro = {
    panel: ui.Panel([
      ui.Label({
        value: 'LEAF Toolbox',
        style: {fontWeight: 'bold', fontSize: '24px', margin: '10px 5px'}
      }),
      ui.Label('This app allows you to display and export maps of  ' +
               'vegetation biophysical variables derived from the Sentinel 2 Multispectral Imager ' + 
               'or Landsat 8 Operational Land Imager .')
    ])
  };
  // The collection filter controls. 
  app.filters = {
    // Create a select with a function that reacts to the "change" event.
    selectCollection: ui.Select({
      items: Object.keys(app.COLLECTION_OPTIONS),
      onChange: function(value) {
        app.collectionName = value;       
       app.SL2P = ee.List.sequence(1,app.COLLECTION_OPTIONS[value].numVariables).map(makeNetVars.bind(null,app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P));
        app.errorSL2P = ee.List.sequence(1,app.COLLECTION_OPTIONS[value].numVariables).map(makeNetVars.bind(null,app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors));
      }
    }),
    startDate: ui.DateSlider({start: 1985-04-01, end: Date.now(), value: [Date.now()-1000*3600*24*30,Date.now()-1000*3600*24*30]}),
    endDate: ui.DateSlider({start:  1985-04-01, end: Date.now(), value: [Date.now(), Date.now()]}),
    maxCloudcover: ui.Slider({min: 0,max: 100,step:10}).setValue(90),
    selectminLng: ui.Textbox({
        placeholder:'min Long', 
        onChange:function(value){
          app.filters.selectBoundingBox.setValue(false);
          app.minLng = value; 
          return(value)}
    }),
    selectminLat: ui.Textbox({
        placeholder:'min Lat',
        onChange:function(value){
          app.filters.selectBoundingBox.setValue(false);
          app.minLat = value; 
          return(value)}
    }),
    selectmaxLng: ui.Textbox({
        placeholder:'max Long', 
        onChange:function(value){
          app.filters.selectBoundingBox.setValue(false);
          app.maxLng = value;
          return(value)}
    }),
    selectmaxLat: ui.Textbox({
        placeholder:'max Lat', 
        onChange:function(value){
          app.filters.selectBoundingBox.setValue(false);
          app.maxLat = value; 
          return(value);}
    }),
    selectBoundingBox: ui.Checkbox({
      label: "Use bounding box for ROI",
      onChange: function() {
        app.filters.mapBounds = ee.Geometry(Map.getBounds(true));
        if (app.filters.selectBoundingBox.getValue() === true) {
          app.filters.selectGeometry.setValue(false);
          var geo= ee.Geometry.Rectangle(ee.Number.parse(app.minLng), ee.Number.parse(app.minLat), ee.Number.parse(app.maxLng), ee.Number.parse(app.maxLat));
          app.filters.mapBounds = geo;
          Map.centerObject(geo);
        }
        //app.refreshMapLayer;
      }
    }),
    selectGeometry: ui.Checkbox({
      label: "Use geometry for ROI",
      onChange: function() {
        app.filters.mapBounds = ee.Geometry(Map.getBounds(true));
        if (app.filters.selectGeometry.getValue() === true) {
          app.filters.selectBoundingBox.setValue(false);
          var geo = geometry;
          app.filters.mapBounds = geo;
          Map.centerObject(geo);
        }
        //app.refreshMapLayer;
      }
    }),
    applyButton: ui.Button('Apply filters', app.applyFilters),
    loadingLabel: ui.Label({
      value: 'Loading...',
      style: {stretch: 'vertical', color: 'gray', shown: false}
    })
  };
  // Default the selectCollection to the first value.
  app.filters.selectCollection.setValue(app.filters.selectCollection.items().get(0));
  // Default bounds to current map bounds.
  app.filters.mapBounds = ee.Geometry(Map.getBounds(true));
  // The panel for the filter control widgets.
  app.filters.panel = ui.Panel({
    widgets: [
      ui.Label('1) Select filters', {fontWeight: 'bold'}),
      ui.Label('Collection', app.HELPER_TEXT_STYLE), app.filters.selectCollection,
      ui.Label('Start date', app.HELPER_TEXT_STYLE), app.filters.startDate,
      ui.Label('End date', app.HELPER_TEXT_STYLE), app.filters.endDate,
      ui.Label('Maximum cloud cover', app.HELPER_TEXT_STYLE), app.filters.maxCloudcover,
      app.filters.selectminLng,
      app.filters.selectminLat,
      app.filters.selectmaxLng,
      app.filters.selectmaxLat,
      app.filters.selectBoundingBox,
      app.filters.selectGeometry,
      ui.Panel([
        app.filters.applyButton,
        app.filters.loadingLabel
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    style: app.SECTION_STYLE
  });
  // The product picker section. 
  app.picker = {
    // Create a select with a function that reacts to the "change" event.
    allImages: ui.Checkbox(
      {label: 'Process all products', value: false,
        onChange: app.refreshMapLayer
      }),
    select: ui.Select({
      placeholder: 'Select product',
      onChange: app.refreshMapLayer
    })
  };
  // The panel for the picker section with corresponding widgets. 
  app.picker.panel = ui.Panel({
    widgets: [
      ui.Label('2) Select products', {fontWeight: 'bold'}),
      ui.Panel([
        app.picker.select,
      ], ui.Panel.Layout.flow('horizontal')),
      app.picker.allImages,
    ],
    style: app.SECTION_STYLE
  });
// The visualization section. 
  app.vis = {
    label: ui.Label(),
    // Create a select with a function that reacts to the "change" event.
    select: ui.Select({
      items: Object.keys(app.VIS_OPTIONS),
      //items: Object.keys(app.COLLECTION_OPTIONS[app.filters.selectCollection.getValue()].VIS_OPTIONS),
      onChange: function() {
        // Update the label's value with the select's description.
        var option = app.VIS_OPTIONS[app.vis.select.getValue()];
        app.vis.label.setValue(option.description);
        // Refresh the map layer.
        app.refreshMapLayer();
      }
    })
  }; 
  // The panel for the visualisation section with corresponding widgets. 
  app.vis.panel = ui.Panel({
    widgets: [
      ui.Label('3) Select a variable to display', {fontWeight: 'bold'}),
      app.vis.select,
      app.vis.label
    ],
    style: app.SECTION_STYLE
  }); 
  app.vis.select.setValue(app.vis.select.items().get(0));
  // The export section. 
  app.export = {
    label: ui.Label(),
    // Create a select with a function that reacts to the "change" event.
    select: ui.Select({
      items: Object.keys(app.EXP_OPTIONS),
        // Update the label's value with the select's description.
        onChange: function(value){
        app.exportID = value; 
        } 
    }),
       textbox1: ui.Textbox({
        placeholder:'Enter folder name',
        onChange: function(text){
          app.folder = [''];
          app.folder[0] =  app.export.textbox1.getValue();
          print('Into Folder:', app.folder[0]);
        }
      }),
        textbox2: ui.Textbox({
        placeholder:'Enter Max Pixels',
        onChange: function(text){
          app.pixels = [0];
          app.pixels[0] = app.export.textbox2.getValue();
          print('Max Pixels:', app.pixels[0]);
        }
      }),
    exportButton: ui.Button({
      label:'Apply Export',  
      onClick: function(){
        app.exportMapLayer();
       }
      })
  };
  // The panel for the export section with corresponding widgets. 
  app.export.panel = ui.Panel({
    widgets: [
      ui.Label('4) Exporting Results to Drive', {fontWeight: 'bold'}),
      app.export.select,
      app.export.label,
      app.export.textbox1,
      app.export.textbox2,
      app.export.exportButton
    ],
    style: app.SECTION_STYLE
  });
   app.export.select.setValue(app.export.select.items().get(0));
};
// Creates the app helper functions. 
app.createHelpers = function() {
  /**
   * Enables or disables loading mode.
   * @param {boolean} enabled Whether loading mode is enabled.
   */
  app.setLoadingMode = function(enabled) {
    // Set the loading label visibility to the enabled mode.
    app.filters.loadingLabel.style().set('shown', enabled);
    // Set each of the widgets to the given enabled mode.
    var loadDependentWidgets = [
      app.vis.select,
      app.filters.startDate,
      app.filters.endDate,
      app.filters.maxCloudcover,
      app.filters.selectminLng,
      app.filters.selectminLat,
      app.filters.selectmaxLng,
      app.filters.selectmaxLat,
      app.filters.selectBoundingBox,
      app.filters.selectGeometry,
      app.filters.applyButton,
      app.export.exportButton
    ];
    loadDependentWidgets.forEach(function(widget) {
      widget.setDisabled(enabled);
    });
  };
};
// Creates the app constants. 
app.createConstants = function() {
  // palettes for display
  // generic palette
  app.palettes = require('users/gena/packages:palettes');
  // palettes for parition layer, should be deprecated
  app.partitionPalettes = require('users/rfernand387/exports:partitionPalettes');
  app.partitionMin = ee.Number(0);
  app.partitionMax = ee.Number(20);
    // load modules
  app.mask  = require('users/fitoprincipe/geetools:cloud_masks');
  app.batch = require('users/fitoprincipe/geetools:batch');
  app.network = require('users/rfernand387/LEAFToolboxModules:SL2PNetwork');
  app.NOW = Date.Now;
  app.COLLECTION_ID = 'COPERNICUS/S2';
  app.SECTION_STYLE = {margin: '20px 0 0 0'};
  app.HELPER_TEXT_STYLE = {
      margin: '8px 0 -3px 8px',
      fontSize: '12px',
      color: 'gray'
  };
  app.IMAGE_COUNT_LIMIT = 100;
   app.EXP_OPTIONS = {'Image by Image':{Order :1},
                     'Full Map Mosaic':{Order: 2}};
  app.COLLECTION_OPTIONS = {
    'COPERNICUS/S2_SR': {
      name: 'S2',
      description: 'Sentinel 2A',
      visParams: {gamma: 1.3, min: 0, max: 3000, bands: ['B4', 'B3', 'B2']},
      Cloudcover: 'CLOUDY_PIXEL_PERCENTAGE',
      Watercover: 'WATER_PERCENTAGE',
      VIS_OPTIONS: app.VIS_OPTIONS,
      Collection_SL2P: ee.FeatureCollection(app.network.s2_createFeatureCollection_estimates()),
      Collection_SL2Perrors: ee.FeatureCollection(app.network.s2_createFeatureCollection_errors()),  
      sl2pDomainAssetName: ee.FeatureCollection(app.network.s2_createFeatureCollection_domains()),
      Network_Ind: ee.FeatureCollection(app.network.s2_createFeatureCollection_Network_Ind()),
      partition: ee.ImageCollection(app.network.s2_createImageCollection_partition()),
      legend:  ee.FeatureCollection(app.network.s2_createFeatureCollection_legend()),
      numVariables: 6,
    },
    'LANDSAT/LC08/C01/T1_SR': {
      name: 'L8',
      description: 'LANDSAT 8',
      visParams: {gamma: 1.3, min: 0, max: 3000, bands: ['B4', 'B3', 'B2']},
      Cloudcover: 'CLOUD_COVER_LAND',
      Watercover: 'CLOUD_COVER',
      VIS_OPTIONS: app.VIS_OPTIONS,
      Collection_SL2P: ee.FeatureCollection(app.network.l8_createFeatureCollection_estimates()),
      Collection_SL2Perrors: ee.FeatureCollection(app.network.l8_createFeatureCollection_errors()),
      sl2pDomainAssetName: ee.FeatureCollection(app.network.l8_createFeatureCollection_domains()),
      Network_Ind: ee.FeatureCollection(app.network.l8_createFeatureCollection_Network_Ind()),
      partition: ee.ImageCollection(app.network.l8_createImageCollection_partition()),
      legend:  ee.FeatureCollection(app.network.l8_createFeatureCollection_legend()),
      numVariables: 6,
    },
    'users/rfernand387/L2avalidation': {
      name: 'S2_CCRS',
      description: 'Sentinel 2A CCRS',
      visParams: {gamma: 1.3, min: 0, max: 3000, bands: ['B4', 'B3', 'B2']},
      Cloudcover: 'CLOUDY_PIXEL_PERCENTAGE',
      Watercover: 'WATER_PERCENTAGE',
      VIS_OPTIONS: app.VIS_OPTIONS,
      Collection_SL2P: ee.FeatureCollection(app.network.s2_createFeatureCollection_estimates()),
      Collection_SL2Perrors: ee.FeatureCollection(app.network.s2_createFeatureCollection_errors()),  
      sl2pDomainAssetName: ee.FeatureCollection(app.network.s2_createFeatureCollection_domains()),
      Network_Ind: ee.FeatureCollection(app.network.s2_createFeatureCollection_Network_Ind()),
      partition: ee.ImageCollection(app.network.s2_createImageCollection_partition()),
      legend:  ee.FeatureCollection(app.network.s2_createFeatureCollection_legend()),
      numVariables: 6,
    },  
  }; 
  app.ALG_OPTIONS = {
    'SL2P': {
      name: 'SL2P',
      description: 'Simplified Level 2 Processor',
      numVariables: 6,
    },
    'SL2P-D': {
      name: 'SL2P-D',
      description: 'Simplified Level 2 Processor - Distributed',
      numVariables: 6,
    },
  };
  app.VIS_OPTIONS = {
    'Surface_Reflectance': {
      'COPERNICUS/S2_SR': {
        Name: 'Surface_Reflectance',
        description: 'Surface_Reflectance',
        outpuParams: {gamma: 1.3, min: 0, max: 0.3, bands: ['B7', 'B6', 'B4']},
        },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'Surface_Reflectance',
        description: 'Surface_Reflectance',
        outpuParams: {gamma: 1.3, min: 0, max: 0.3, bands: ['B7', 'B6', 'B4']},
        },
      'users/rfernand387/L2avalidation': {
        Name: 'Surface_Reflectance',
        description: 'Surface_Reflectance',
        outpuParams: {gamma: 1.3, min: 0, max: 0.3, bands: ['B7', 'B6', 'B4']},
        }
      },
    'Albedo': {
      'COPERNICUS/S2_SR': {
        Name: 'Albedo',
        errorName: 'errorAlbedo',
        maskName: 'maskAlbedo',
        description: 'Black sky albedo',
        variable: 6,
        outputParams: { min: 0.1, max: 0.3, palette: app.palettes.misc.jet[7], bands: ['Albedo']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorAlbedo']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'Albedo',
        errorName: 'errorAlbedo',
        maskName: 'maskAlbedo',
        description: 'Black sky albedo',
        variable: 6,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['Albedo']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorAlbedo']},
        sza: 'SOLAR_ZENITH_ANGLE',
        vza: 'SOLAR_ZENITH_ANGLE',
        saa: 'SOLAR_AZIMUTH_ANGLE', 
        vaa: 'SOLAR_AZIMUTH_ANGLE',
        inp:      ['B3', 'B4', 'B5', 'B6', 'B7'],
        inpCode:  ee.Image([10,100,1000,10000,100000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
      'users/rfernand387/L2avalidation': {
        Name: 'Albedo',
        errorName: 'errorAlbedo',
        maskName: 'maskAlbedo',
        description: 'Black sky albedo',
        variable: 6,
        outputParams: { min: 0.1, max: 0.3, palette: app.palettes.misc.jet[7], bands: ['Albedo']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorAlbedo']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
    },
    'fAPAR': {
      'COPERNICUS/S2_SR': {
        Name: 'fAPAR',
        errorName: 'errorfAPAR',
        maskName: 'maskfAPAR',
        description: 'Fraction of absorbed photosynthetically active radiation',
        variable: 2,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['fAPAR']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfAPAR']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'fAPAR',
        errorName: 'errorfAPAR',
        maskName: 'maskfAPAR',
        description: 'Fraction of absorbed photosynthetically active radiation',
        variable: 2,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['fAPAR']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfAPAR']},
        sza: 'SOLAR_ZENITH_ANGLE',
        vza: 'SOLAR_ZENITH_ANGLE',
        saa: 'SOLAR_AZIMUTH_ANGLE', 
        vaa: 'SOLAR_AZIMUTH_ANGLE',
        inp:      ['B3', 'B4', 'B5', 'B6', 'B7'],
        inpMaskoff: ee.Image([-0.0027,0.0688,-0.3097,-0.7127,0.2235]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]]))) 
      },
      'users/rfernand387/L2avalidation': {
        Name: 'fAPAR',
        errorName: 'errorfAPAR',
        maskName: 'maskfAPAR',
        description: 'Fraction of absorbed photosynthetically active radiation',
        variable: 2,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['fAPAR']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfAPAR']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
    },
    'fCOVER': {
      'COPERNICUS/S2_SR': {
        Name: 'fCOVER',
        errorName: 'errorfCOVER',
        maskName: 'maskfCOVER',
        description: 'Fraction of canopy cover',
        variable: 3,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['fCOVER']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfCOVER']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]]))) 
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'fCOVER',
        errorName: 'errorfCOVER',
        maskName: 'maskfCOVER',
        description: 'Fraction of canopy cover',
        variable: 3,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['fCOVER']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfCOVER']},
        sza: 'SOLAR_ZENITH_ANGLE',
        vza: 'SOLAR_ZENITH_ANGLE',
        saa: 'SOLAR_AZIMUTH_ANGLE', 
        vaa: 'SOLAR_AZIMUTH_ANGLE',
        inp:      ['B3', 'B4', 'B5', 'B6', 'B7'],
        inpCode:  ee.Image([10,100,1000,10000,100000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
      'users/rfernand387/L2avalidation': {
        Name: 'fCOVER',
        errorName: 'errorfCOVER',
        maskName: 'maskfCOVER',
        description: 'Fraction of canopy cover',
        variable: 3,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['fCOVER']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfCOVER']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))  
      },
    },
    'LAI': {
      'COPERNICUS/S2_SR': {
        Name: 'LAI',
        errorName: 'errorLAI',
        maskName: 'maskLAI',
        description: 'Leaf area index',
        variable: 1,
        outputParams: { min: 0, max: 10, palette: app.palettes.misc.jet[7], bands: ['LAI']},
        errorParams: { min: -5, max: 5, palette: app.palettes.misc.jet[7], bands: ['errorLAI']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]]))) 
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'LAI',
        errorName: 'errorLAI',
        maskName: 'maskLAI',
        description: 'Leaf area index',
        variable: 1,
        outputParams: { min: 0, max: 10, palette: app.palettes.misc.jet[7], bands: ['LAI']},
        errorParams: { min: -5, max: 5, palette: app.palettes.misc.jet[7], bands: ['errorLAI']},
        sza: 'SOLAR_ZENITH_ANGLE',
        vza: 'SOLAR_ZENITH_ANGLE',
        saa: 'SOLAR_AZIMUTH_ANGLE', 
        vaa: 'SOLAR_AZIMUTH_ANGLE',
        inp:      ['B3', 'B4', 'B5', 'B6', 'B7'],
        inpCode:  ee.Image([10,100,1000,10000,100000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[10]])))
      },
      'users/rfernand387/L2avalidation': {
        Name: 'LAI',
        errorName: 'errorLAI',
        maskName: 'maskLAI',
        description: 'Leaf area index',
        variable: 1,
        outputParams: { min: 0, max: 10, palette: app.palettes.misc.jet[7], bands: ['LAI']},
        errorParams: { min: -5, max: 5, palette: app.palettes.misc.jet[7], bands: ['errorLAI']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]]))) 
      },
    },
    'CCC': {
      'COPERNICUS/S2_SR': {
        Name: 'CCC',
        errorName: 'errorCCC',
        maskName: 'maskCCC',
        description: 'Canopy chloropyll content',
        variable: 4,
        outputParams: { min: 0, max: 1000, palette: app.palettes.misc.jet[7], bands: ['CCC']},
        errorParams: { min: -500, max: 500, palette: app.palettes.misc.jet[7], bands: ['errorCCC']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1000]])))
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'CCC',
        errorName: 'errorCCC',
        maskName: 'maskCCC',
        description: 'Canopy chloropyll content',
        variable: 4,
        outputParams: { min: 0, max: 1000, palette: app.palettes.misc.jet[7], bands: ['CCC']},
        errorParams: { min: -500, max: 500, palette: app.palettes.misc.jet[7], bands: ['errorCCC']},
        sza: 'SOLAR_ZENITH_ANGLE',
        vza: 'SOLAR_ZENITH_ANGLE',
        saa: 'SOLAR_AZIMUTH_ANGLE', 
        vaa: 'SOLAR_AZIMUTH_ANGLE',
        inp:      ['B3', 'B4', 'B5', 'B6', 'B7'],
        inpCode:  ee.Image([10,100,1000,10000,100000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1000]])))
      },
      'users/rfernand387/L2avalidation': {
        Name: 'CCC', 
        errorName: 'errorCCC',
        maskName: 'maskCCC',
        description: 'Canopy chloropyll content',
        variable: 4,
        outputParams: { min: 0, max: 1000, palette: app.palettes.misc.jet[7], bands: ['CCC']},
        errorParams: { min: -500, max: 500, palette: app.palettes.misc.jet[7], bands: ['errorCCC']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1000]])))
      },
    },
     'CWC': {
       'COPERNICUS/S2_SR': {
        Name: 'CWC',
        errorName: 'errorCWC',
        maskName: 'maskCWC',
        description: 'Canopy water content',
        variable: 5,
        outputParams: { min: 0, max: 100, palette: app.palettes.misc.jet[7], bands: ['CWC']},
        errorParams: { min: -50, max: 50, palette: app.palettes.misc.jet[7], bands: ['errorCWC']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[100]])))
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'CWC',
        errorName: 'errorCWC',
        maskName: 'maskCWC',
        description: 'Canopy water content',
        variable: 5,
        outputParams: { min: 0, max: 100, palette: app.palettes.misc.jet[7], bands: ['CWC']},
        errorParams: { min: -50, max: 50, palette: app.palettes.misc.jet[7], bands: ['errorCWC']},
        sza: 'SOLAR_ZENITH_ANGLE',
        vza: 'SOLAR_ZENITH_ANGLE',
        saa: 'SOLAR_AZIMUTH_ANGLE', 
        vaa: 'SOLAR_AZIMUTH_ANGLE',
        inp:      ['B3', 'B4', 'B5', 'B6', 'B7'],
        inpCode:  ee.Image([10,100,1000,10000,100000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[100]]))) 
      },   
      'users/rfernand387/L2avalidation': {
        Name: 'CWC',
        errorName: 'errorCWC',
        maskName: 'maskCWC',
        description: 'Canopy water content',
        variable: 5,
        outputParams: { min: 0, max: 100, palette: app.palettes.misc.jet[7], bands: ['CWC']},
        errorParams: { min: -50, max: 50, palette: app.palettes.misc.jet[7], bands: ['errorCWC']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[100]])))
      },
    },
      'DASF' : {
      'COPERNICUS/S2_SR': {
        name: 'DASF',
        errorname: 'errorDASF',
        maskname: 'maskDASF',
        description: 'Canopy directional scattering factor',
        variable: 7,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['DASF']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorDASF']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[2]])))
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'DASF',
        errorName: 'errorDASF',
        maskName: 'maskDASF',
        description: 'Canopy directional scattering factor',
        variable: 7,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['DASF']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorDASF']},
        sza: 'SOLAR_ZENITH_ANGLE',
        vza: 'SOLAR_ZENITH_ANGLE',
        saa: 'SOLAR_AZIMUTH_ANGLE', 
        vaa: 'SOLAR_AZIMUTH_ANGLE',
        inp:      ['B3', 'B4', 'B5', 'B6', 'B7'],
        inpCode:  ee.Image([10,100,1000,10000,100000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[2]])))
      },   
      'users/rfernand387/L2avalidation': {
        name: 'DASF',
        errorname: 'errorDASF',
        maskname: 'maskDASF',
        description: 'Canopy directional scattering factor',
        variable: 7,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['DASF']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorDASF']},
        sza: 'MEAN_SOLAR_ZENITH_ANGLE',
        vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
        saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
        vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inpCode:  ee.Image([10,100,1000,10000,100000,1000000,10000000,100000000]),
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[2]])))
      },
    },
    };
};
// Creates the application interface
app.boot = function() {
  app.createConstants();
  app.createHelpers();
  app.createPanels();
  var main = ui.Panel({
    widgets: [
      app.intro.panel,
      app.filters.panel,
      app.picker.panel,
      app.vis.panel,
      app.export.panel
    ],
    style: {width: '320px', padding: '8px'}
  });
  ui.root.insert(0, main);
};
// Start app
app.boot();