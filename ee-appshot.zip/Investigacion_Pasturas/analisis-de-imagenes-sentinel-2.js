/*
Distritos
*/
var table2 = ee.FeatureCollection('users/Investigacion_Pasturas/distritos_mapa_Santa_Fe')
Map.setControlVisibility({layerList:true, zoomControl:false, scaleControl:true, mapTypeControl:false, fullscreenControl:false, drawingToolsControl:false})
Map.setOptions('SATELLITE')
var Departamentos = table2.filter(
  ee.Filter.inList('nombre_dep', ['General Obligado']))
print(Departamentos)
var style = require('users/gena/packages:style')
var palettes = require('users/gena/packages:palettes')
print(table2)
/* Diccionario de dictrictos*/
var Distritos = {
'Aarón Castellanos (Est. Castellanos)' : [ 1729 ] ,
'Acebal' : [ 1613 ] ,
'Aguará Grande' : [ 706 ] ,
'Albarellos' : [ 1621 ] ,
'Alcorta' : [ 1902 ] ,
'Aldao' : [ 810 ] ,
// 'Aldao' : [ i ] ,
'Alejandra' : [ 403 ] ,
'Álvarez' : [ 1611 ] ,
'Alvear' : [ 1609 ] ,
'Ambrosetti' : [ 703 ] ,
'Amenábar' : [ 1731 ] ,
'Andino' : [ 1405 ] ,
'Angélica' : [ 837 ] ,
'Angeloni' : [ 614 ] ,
'Arequito' : [ 1803 ] ,
'Arminda' : [ 1623 ] ,
'Armstrong' : [ 1306 ] ,
'Arocena': [ 1110 ] ,
'Arroyo Aguiar': [ 1008 ] ,
'Arroyo Ceibal' : [ 314 ] ,
'Arroyo Leyes' : [ 1015 ] ,
'Arroyo Seco' : [ 1618 ] ,
'Arrufó' : [ 711 ] ,
'Arteaga' : [ 1801 ] ,
'Ataliva' : [ 812 ] ,
'Aurelia Sur' : [ 826 ] ,
'Avellaneda' : [ 319 ] ,
'Barrancas' : [ 1115 ] ,
'Bauer Y Sigel' : [ 832 ] ,
'Bella Italia' : [ 825 ] ,
'Berabevú' : [ 1811 ] ,
'Berna' : [ 322 ] ,
'Bernardo de Irigoyen (Est. Irigoyen)' : [ 1113 ] ,
'Bigand' : [ 1807 ] ,
'Bombal' : [ 1901 ] ,
'Bouquet' : [ 1301 ] ,
'Bustinza' : [ 1409 ] ,
'Cabal' : [ 1002 ] ,
'Cacique Ariacaiquín' : [ 405 ] ,
'Caferata' : [ 1701 ] ,
'Calchaquí' : [ 205 ] ,
'Campo Andino' : [ 1004 ] ,
'Campo Garay (Juan de Garay)' : [ 109 ] ,
'Campo Piaggio' : [ 1107 ] ,
'Candioti' : [ 1007 ] ,
'Cañada De Gómez' : [ 1410 ] ,
'Cañada del Ucle' : [ 1705 ] ,
'Cañada Ombú' : [ 208 ] ,
'Cañada Rica' : [ 1911 ] ,
'Cañada Rosquín' : [ 1206 ] ,
'Capitán Bermúdez' : [ 1505 ] ,
'Capivara' : [ 718 ] ,
'Carcarañá' : [ 1509 ] ,
'Carlos Pellegrini' : [ 1211 ] ,
'Carmen' : [ 1711 ] ,
'Carmen Del Sauce' : [ 1614 ] ,
'Carreras' : [ 1708 ] ,
'Carrizales' : [ 1403 ] ,
'Casalegno' : [ 1114 ] ,
'Casas' : [ 1212 ] ,
'Casilda' : [ 1805 ] ,
'Castelar' : [ 1201 ] ,
'Castellanos' : [ 822 ] ,
'Cayastá' : [ 502 ] ,
'Cayastacito' : [ 617 ] ,
'Centeno' : [ 1122 ] ,
'Cepeda' : [ 1908 ] ,
'Ceres' : [ 701 ] ,
'Chabás' : [ 1808 ] ,
'Chañar Ladeado' : [ 1812 ] ,
'Chapuy' : [ 1712 ] ,
'Chovet' : [ 1704 ] ,
'Christophersen' : [ 1725 ] ,
'Clason' : [ 1401 ] ,
'Clucellas' : [ 835 ] ,
'Colonia Ana' : [ 713 ] ,
'Colonia Belgrano' : [ 1205 ] ,
'Colonia Bicha' : [ 807 ] ,
'Colonia Bigand' : [ 816 ] ,
'Colonia Bossi' : [ 729 ] ,
'Colonia Cavour' : [ 917 ] ,
'Colonia Cello' : [ 834 ] ,
'Colonia Dolores' : [ 618 ] ,
'Colonia Dos Rosas' : [ 728 ] ,
'Colonia Durán' : [ 402 ] ,
'Colonia Fidela' : [ 817 ] ,
'Colonia Iturraspe' : [ 836 ] ,
'Colonia Ituzaingó' : [ 904 ] ,
'Colonia La Clara' : [ 721 ] ,
'Colonia Margarita' : [ 845 ] ,
'Colonia Mascias' : [ 505 ] ,
'Colonia Mauá' : [ 802 ] ,
'Colonia Raquel' : [ 804 ] ,
'Colonia Rosa' : [ 715 ] ,
'Colonia San José' : [ 928 ] ,
'Colonia Teresa' : [ 408 ] ,
'Constanza' : [ 723 ] ,
'Coronda' : [ 1105 ] ,
'Coronel Arnold' : [ 1513 ] ,
'Coronel Bogado' : [ 1620 ] ,
'Coronel Domínguez' : [ 1615 ] ,
'Coronel Fraga' : [ 820 ] ,
'Correa' : [ 1411 ] ,
'Crispi' : [ 1202 ] ,
'Cululú' : [ 915 ] ,
'Curupaity' : [ 717 ] ,
'Desvío Arijón' : [ 1104 ] ,
'Diego De Alvear' : [ 1730 ] ,
'Egusquiza' : [ 815 ] ,
'El Arazá' : [ 321 ] ,
'El Rabón' : [ 303 ] ,
'El Sombrerito' : [ 313 ] ,
'El Trébol' : [ 1215 ] ,
'Elisa' : [ 901 ] ,
'Elortondo' : [ 1710 ] ,
'Emilia' : [ 1001 ] ,
'Empalme San Carlos' : [ 927 ] ,
'Empalme Villa Constitución' : [ 1916 ] ,
'Esmeralda' : [ 842 ] ,
'Esperanza' : [ 916 ] ,
'Estación Clucellas' : [ 838 ] ,
'Estación Díaz' : [ 1119 ] ,
'Esteban Rams' : [ 107 ] ,
'Esther' : [ 616 ] ,
'Eusebia' : [ 808 ] ,
'Eustolia' : [ 839 ] ,
'Felicia' : [ 912 ] ,
'Fighiera' : [ 1619 ] ,
'Firmat' : [ 1706 ] ,
'Florencia' : [ 302 ] ,
'Fortín Olmos' : [ 207 ] ,
'Franck' : [ 926 ] ,
'Fray Luis Beltrán' : [ 1504 ] ,
'Frontera' : [ 841 ] ,
'Fuentes' : [ 1514 ] ,
'Funes' : [ 1604 ] ,
'Gaboto' : [ 1117 ] ,
'Galisteo' : [ 813 ] ,
'Gálvez' : [ 1108 ] ,
'Garabato' : [ 211 ] ,
'Garibaldi' : [ 843 ] ,
'Gato Colorado' : [ 102 ] ,
'General Gelly' : [ 1912 ] ,
'General Lagos' : [ 1617 ] ,
'Gessler' : [ 1102 ] ,
'Gobernador Crespo' : [ 607 ] ,
'Godeken' : [ 1813 ] ,
'Godoy' : [ 1914 ] ,
'Golondrina' : [ 209 ] ,
'Granadero Baigorria' : [ 1602 ] ,
'Gregoria P. De Denis' : [ 101 ] ,
'Grutly Sur' : [ 913 ] ,
'Guadalupe Norte' : [ 327 ] ,
'Helvecia' : [ 501 ] ,
'Hersilia' : [ 702 ] ,
'Hipatia' : [ 910 ] ,
'Huanqueros' : [ 704 ] ,
'Hugentobler' : [ 809 ] ,
'Hughes' : [ 1720 ] ,
'Humberto 1º' : [ 803 ] ,
'Humboldt' : [ 918 ] ,
'Ibarlucea' : [ 1601 ] ,
'Ingeniero Chanourdie' : [ 312 ] ,
'Intiyaco' : [ 210 ] ,
'Irigoyen' : [ 1112 ] ,
'Jacinto L.  Aráuz' : [ 902 ] ,
'Josefina' : [ 833 ] ,
'Juan B. Molina' : [ 1913 ] ,
'Juncal' : [ 1903 ] ,
'La Brava' : [ 406 ] ,
'La Cabral' : [ 732 ] ,
'La Camila' : [ 602 ] ,
'La Chispa' : [ 1702 ] ,
'La Criolla' : [ 605 ] ,
'La Gallareta' : [ 203 ] ,
'La Lucila' : [ 720 ] ,
'La Pelada' : [ 903 ] ,
'La Penca y Caraguatá' : [ 606 ] ,
'La Rubia' : [ 712 ] ,
'La Sarita' : [ 326 ] ,
'La Vanguardia' : [ 1907 ] ,
'Labordeboy' : [ 1721 ] ,
'Laguna Paiva' : [ 1005 ] ,
'Landeta' : [ 1210 ] ,
'Lanteri' : [ 316 ] ,
'Larrechea' : [ 1103 ] ,
'Las Avispas' : [ 705 ] ,
'Las Bandurrias' : [ 1213 ] ,
'Las Garzas' : [ 315 ] ,
'Las Palmeras' : [ 730 ] ,
'Las Parejas' : [ 1303 ] ,
'Las Petacas' : [ 1209 ] ,
'Las Rosas' : [ 1302 ] ,
'Las Toscas' : [ 305 ] ,
'Las Tunas' : [ 924 ] ,
'Lazzarino' : [ 1728 ] ,
'Lehmann' : [ 814 ] ,
'Llambi Campbell' : [ 1003 ] ,
'Logroño' : [ 106 ] ,
'Loma Alta' : [ 1106 ] ,
'López' : [ 1101 ] ,
'Los Amores' : [ 212 ] ,
'Los Cardos' : [ 1214 ] ,
'Los Laureles' : [ 324 ] ,
'Los Molinos' : [ 1804 ] ,
'Los Quirquinchos' : [ 1810 ] ,
'Lucio V. López' : [ 1407 ] ,
'Luis Palacios' : [ 1508 ] ,
'Maciel' : [ 1118 ] ,
'Maggiolo' : [ 1715 ] ,
'Malabrigo' : [ 323 ] ,
'Marcelino Escalada' : [ 609 ] ,
'Margarita' : [ 204 ] ,
'María Juana' : [ 844 ] ,
'María Luisa' : [ 907 ] ,
'María Susana' : [ 1217 ] ,
'María Teresa' : [ 1717 ] ,
'Matilde' : [ 936 ] ,
'Máximo Paz' : [ 1904 ] ,
'Melincué' : [ 1709 ] ,
'Moisés Ville' : [ 724 ] ,
'Monigotes' : [ 725 ] ,
'Monje' : [ 1116 ] ,
'Monte Oscuridad' : [ 727 ] ,
'Monte Vera' : [ 1009 ] ,
'Montefiore' : [ 108 ] ,
'Montes De Oca' : [ 1304 ] ,
'Murphy' : [ 1703 ] ,
'Naré' : [ 612 ] ,
'Nelson' : [ 1006 ] ,
'Nicanor E. Molinas' : [ 328 ] ,
'Nuevo Torino' : [ 919 ] ,
'Ñanducita' : [ 719 ] ,
'Oliveros' : [ 1404 ] ,
'Palacios' : [ 731 ] ,
'Pavón' : [ 1919 ] ,
'Pavón Arriba' : [ 1905 ] ,
'Pedro Gómez Cello' : [ 601 ] ,
'Pérez' : [ 1606 ] ,
'Peyrano' : [ 1910 ] ,
'Piamonte' : [ 1216 ] ,
'Pilar' : [ 920 ] ,
'Piñero' : [ 1610 ] ,
'Portugalete' : [ 710 ] ,
'Pozo Borrado' : [ 104 ] ,
'Presidente Roca' : [ 823 ] ,
'Progreso' : [ 909 ] ,
'Providencia' : [ 906 ] ,
'Pueblo Esther' : [ 1625 ] ,
'Pueblo Marini' : [ 818 ] ,
'Pueblo Miguel Torres' : [ 1707 ] ,
'Pueblo Muñoz' : [ 1612 ] ,
'Pueblo San Antonio' : [ 830 ] ,
'Pueblo Uranga' : [ 1622 ] ,
'Puerto San Martin' : [ 1502 ] ,
'Pujato' : [ 1512 ] ,
'Pujato Norte' : [ 925 ] ,
'Rafaela' : [ 824 ] ,
'Ramayón' : [ 610 ] ,
'Ramona' : [ 819 ] ,
'Reconquista' : [ 320 ] ,
'Recreo' : [ 1010 ] ,
'Ricardone' : [ 1506 ] ,
'Rivadavia' : [ 914 ] ,
'Roldán' : [ 1511 ] ,
'Romang' : [ 401 ] ,
'Rosario' : [ 1603 ] ,
'Rueda' : [ 1915 ] ,
'Rufino' : [ 1727 ] ,
'Sa Pereira' : [ 932 ] ,
'Saguier' : [ 829 ] ,
'Saladero Cabal' : [ 506 ] ,
'Salto Grande' : [ 1408 ] ,
'San Agustín' : [ 929 ] ,
'San Antonio De Obligado' : [ 306 ] ,
'San Bernardo' : [ 103 ] ,
// 'San Bernardo' : [ 613 ] ,
'San Carlos Centro' : [ 935 ] ,
'San Carlos Norte' : [ 930 ] ,
'San Carlos Sud' : [ 937 ] ,
'San Cristóbal' : [ 708 ] ,
'San Eduardo' : [ 1716 ] ,
'San Eugenio' : [ 1109 ] ,
'San Fabián' : [ 1111 ] ,
'San Francisco De Santa Fe' : [ 1714 ] ,
'San Genaro' : [ 1121 ] ,
'San Gregorio' : [ 1724 ] ,
'San Guillermo' : [ 716 ] ,
'San Javier' : [ 404 ] ,
'San Jerónimo Del Sauce' : [ 931 ] ,
'San Jerónimo Norte' : [ 923 ] ,
'San Jerónimo Sur' : [ 1510 ] ,
'San Jorge' : [ 1208 ] ,
'San José De La Esquina' : [ 1802 ] ,
'San José Del Rincón' : [ 1016 ] ,
'San Justo' : [ 611 ] ,
'San Lorenzo' : [ 1503 ] ,
'San Mariano' : [ 933 ] ,
'San Martín De Las Escobas' : [ 1204 ] ,
'San Martín Norte' : [ 604 ] ,
'San Vicente' : [ 846 ] ,
'Sancti Spiritu' : [ 1726 ] ,
'Sanford' : [ 1806 ] ,
'Santa Clara De Buena Vista' : [ 934 ] ,
'Santa Clara De Saguier' : [ 831 ] ,
'Santa Fe' : [ 1011 ] ,
'Santa Isabel' : [ 1718 ] ,
'Santa Margarita' : [ 111 ] ,
'Santa María Centro' : [ 921 ] ,
'Santa María Norte' : [ 922 ] ,
'Santa Rosa' : [ 503 ] ,
'Santa Teresa' : [ 1906 ] ,
'Santo Domingo' : [ 908 ] ,
'Santo Tomé' : [ 1012 ] ,
'Santurce' : [ 709 ] ,
'Sargento Cabral' : [ 1909 ] ,
'Sarmiento' : [ 911 ] ,
'Sastre' : [ 1203 ] ,
'Sauce Viejo' : [ 1013 ] ,
'Serodino' : [ 1406 ] ,
'Silva' : [ 608 ] ,
'Soldini' : [ 1607 ] ,
'Soledad' : [ 722 ] ,
'Soutomayor' : [ 905 ] ,
'Suardi' : [ 726 ] ,
'Sunchales' : [ 811 ] ,
'Susana' : [ 827 ] ,
'Tacuarendí' : [ 307 ] ,
'Tacural' : [ 805 ] ,
'Tacurales' : [ 806 ] ,
'Tartagal' : [ 213 ] ,
'Teodelina' : [ 1723 ] ,
'Theobald' : [ 1917 ] ,
'Timbúes' : [ 1501 ] ,
'Toba' : [ 206 ] ,
'Tortugas' : [ 1305 ] ,
'Tostado' : [ 105 ] ,
'Totoras' : [ 1402 ] ,
'Traill' : [ 1207 ] ,
'Venado Tuerto' : [ 1713 ] ,
'Vera' : [ 202 ] ,
'Vera Y Pintado' : [ 603 ] ,
'Videla' : [ 615 ] ,
'Vila' : [ 821 ] ,
'Villa Amelia' : [ 1616 ] ,
'Villa Ana' : [ 309 ] ,
'Villa Cañás' : [ 1719 ] ,
'Villa Constitución' : [ 1918 ] ,
'Villa Eloísa' : [ 1412 ] ,
'Villa Gobernador Gálvez' : [ 1608 ] ,
'Villa Guillermina' : [ 304 ] ,
'Villa Minetti' : [ 110 ] ,
'Villa Mugueta' : [ 1515 ] ,
'Villa Ocampo' : [ 308 ] ,
'Villa San José' : [ 828 ] ,
'Villa Saralegui' : [ 707 ] ,
'Villa Trinidad' : [ 714 ] ,
'Villada' : [ 1809 ] ,
'Virginia' : [ 801 ] ,
'Wheelwright' : [ 1722 ] ,
'Zavalla' : [ 1605 ] ,
'Zenón Pereyra' : [ 840 ] ,
}
//seleccione la banda de trabajo
var coleccion = ee.ImageCollection('COPERNICUS/S2_SR')
/*fijar fecha actual*/
var ahora = ee.Date(Date.now())
var select = ui.Select({
  items: Object.keys(Distritos), 
  onChange: function(i){
    print(i)
  Map.centerObject(table2.filter(ee.Filter.inList('nombre_dis', [i])),13)
  var layer =table2.filter(ee.Filter.inList('nombre_dis', [i])).style({fillColor:'00000000',  width:3,color: 'orange'})
  Map.layers().set(0,layer)
  var panel = ui.Panel({widgets: [ui.Label(i,{backgroundColor:'00000000'})],layout:ui.Panel.Layout.Flow('vertical'),style:{position:'top-center', backgroundColor:'00000000',fontSize:'32px',color:'indigo'}})
  Map.widgets().set(1,panel)
  var coleccion = {
  nombre:{'COPERNICUS/S2_SR' : [],
  'LANDSAT/LC08/C01/T1_SR' : [],
  'MODIS/006/MOD13Q1':[]
    },
  bandas:{
    'NDVI':[],
    'B3-B2-B1':[],
    'B11-B8A-B2':[]
  }
  }
  var selectcollect = ui.Select({
    items:Object.keys(coleccion.nombre), 
    placeholder: 'Seleccione Colección', 
    onChange:function(s){
      if(s==='COPERNICUS/S2_SR'){
        var paneldate = ui.DateSlider({start:'2015-01-01', end:ahora, period:15, onChange:function(d){
        var coleccion1 = ee.ImageCollection(s).filterDate(d.start(), d.end()).filterBounds(table2.filter(ee.Filter.inList('nombre_dis', [i])))
        .filterMetadata('CLOUDY_PIXEL_PERCENTAGE','less_than',5).mosaic().clip(table2.filter(ee.Filter.inList('nombre_dis', [i])))
        print(coleccion1)
        var selectbands =ui.Select({
          items:Object.keys(coleccion.bandas),
          placeholder: 'Seleccione visualización', 
          onChange:function(v){
          if(v==='NDVI'){
            print(coleccion1)
          var colecc2 = coleccion1.normalizedDifference(['B8','B4']).visualize({bands:['nd'],min:-0.15,max:0.85,palette:['blue','black','white','yellow','green','red']})
          Map.layers().set(1,colecc2)
          var checkboox = ui.Checkbox({label:'Dibuje la Región a descargar!..',onChange:function(k){
           Map.drawingTools().clear();
            // No haga importaciones que correspondan a los rectángulos dibujados.
           Map.drawingTools().setLinked(false);
           // Limite los modos de dibujo a poligonos.
           Map.drawingTools().setDrawModes(['polygon']);
           // Agregue una capa vacía para sostener el poligono dibujado.
           Map.drawingTools().addLayer([]);
           // Establecer el tipo de geometría para ser poligono.
           Map.drawingTools().setShape('polygon');
           // Ingrese al modo de dibujo.
           Map.drawingTools().draw();
           Map.drawingTools().onDraw(function (geometry) {
          // Haz algo con la geometría
          var AOI = Map.drawingTools().toFeatureCollection(0);
          Map.centerObject(AOI);
          Map.drawingTools().stop();
          /*Calcular el area Dibujada*/
          var area = ee.Image(1).reduceRegion(ee.Reducer.sum(), AOI, 10)
          var numbrer_area = ee.Number(area.get('constant')).multiply(10).multiply(10).divide(10000)
          /*Construir panel para mapa*/
          var areadibujada=ui.Label('Area Dibujada en héctareas: '+numbrer_area.format("%(,.2f").getInfo(), {fontWeight:'bold',fontSize: '14px', backgroundColor:'00000000',color:'white'})
          panelprincipal.widgets().set(6,areadibujada);
          Map.drawingTools().layers().forEach(function(layer) {
            layer.setShown(true);
          })
          var Layer = 'Descargar Imagen'
          var url = colecc2.getDownloadURL({ 
          name: "TheGeoTIFF",
          region: AOI.geometry(),
          scale: 12,// or Map.getScale(),
          format: 'GeoTIFF',
          }); 
          var ExportingLinks=ui.Label(Layer, {fontWeight:'bold',backgroundColor:'00000000',fontSize:'20px'}).setUrl(url); //This creates a hyper link.
          panelprincipal.widgets().set(7,ExportingLinks);
           })
          }, style:{fontSize:'20px',color:'white',backgroundColor:'00000000', fontWeight:'bold'}})
          panelprincipal.widgets().set(5,checkboox)
        }else if(v ==='B3-B2-B1'){
          var colecc3 = coleccion1.visualize({bands:['B4','B3','B2'],min:100,max:200})
          Map.layers().set(1,colecc3)
        }}
        })
        panelprincipal.widgets().set(4,selectbands)
        },style:{backgroundColor:'orange'}})
        panelprincipal.widgets().set(3,paneldate)
      }else{
        var coleccion2 = ee.ImageCollection(s).filterBounds(table2.filter(ee.Filter.inList('nombre_dis', [i])))
        .filterMetadata('CLOUD_COVER','less_than',5).mosaic()
        .clip(table2.filter(ee.Filter.inList('nombre_dis', [i])))
        .visualize({bands:['B4','B3','B2'],min:120,max:150})
        Map.layers().set(1,coleccion2)
      }
    }, 
  })
   panelprincipal.widgets().set(2,selectcollect)
  }
})
var panelprincipal = ui.Panel({widgets: [ui.Label('Seleccione la Región de trabajo',{fontSize:'20px',fontWeight:'bold',color:'white',backgroundColor:'00000000'}),select],layout:ui.Panel.Layout.Flow('vertical'),style:{position:'top-left', backgroundColor:'00000555'}})
Map.widgets().set(0,panelprincipal)