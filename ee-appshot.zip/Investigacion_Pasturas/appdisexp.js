var table = ui.import && ui.import("table", "table", {
      "id": "users/Investigacion_Pasturas/Diseno_exp_Los_Lapachos"
    }) || ee.FeatureCollection("users/Investigacion_Pasturas/Diseno_exp_Los_Lapachos"),
    table2 = ui.import && ui.import("table2", "table", {
      "id": "users/Investigacion_Pasturas/Diseno_exp_Las_Gamas"
    }) || ee.FeatureCollection("users/Investigacion_Pasturas/Diseno_exp_Las_Gamas"),
    table3 = ui.import && ui.import("table3", "table", {
      "id": "users/Investigacion_Pasturas/Diseno_exp_Garabato"
    }) || ee.FeatureCollection("users/Investigacion_Pasturas/Diseno_exp_Garabato"),
    coleccionPlanet = ui.import && ui.import("coleccionPlanet", "imageCollection", {
      "id": "users/Investigacion_Pasturas/Mosaico_Planet_Norte_de_Santa_Fe/Mosaico_SANTA_FE"
    }) || ee.ImageCollection("users/Investigacion_Pasturas/Mosaico_Planet_Norte_de_Santa_Fe/Mosaico_SANTA_FE"),
    S2 = ui.import && ui.import("S2", "imageCollection", {
      "id": "COPERNICUS/S2_SR"
    }) || ee.ImageCollection("COPERNICUS/S2_SR");
/*
App de los experimentos realizados en los diferentes establecimeintos
*/
//Mapa de tipo SATELLITE
Map.setOptions('SATELLITE')
//Controles de visibilidad
Map.setControlVisibility({layerList:true, zoomControl:false, scaleControl:false, mapTypeControl:false, fullscreenControl:false, drawingToolsControl:false})
//paquetes estilo y paleta
var style = require('users/gena/packages:style')
var palettes = require('users/gena/packages:palettes')
//
var Sitio1 = table.map(function(i){
  i = i.set('nombre', 'Los Lapachos')
  i = i.copyProperties(i, ['id'])
  return i
})
var Sitio2 = table2.map(function(i){
  i = i.set('nombre', 'Las Gamas')
  i = i.copyProperties(i, ['id'])
  return i
})
var Sitio3 = table3.map(function(i){
  i = i.set('nombre', 'Campo Garabato')
  i = i.copyProperties(i, ['id'])
  return i
})
var Sitios = Sitio1.merge(Sitio2).merge(Sitio3)
/*
Seleccione Sitio
*/
/*Tipos de Bosque */
var dic = {
bosques:{
  'Sabana de Prosopis, Vachellia':[0],
  'Monte Fuerte de Caesalpinia, Gleditsia':[1],
  'Bosque de Schinopsis y Acacia praecox':[2]
},
Campos :{
  'Las Gamas':[],
  'Los Lapachos':[],
  'Campo Garabato':[]
}}
/*panel principal*/
var panel = ui.Panel({layout:ui.Panel.Layout.Flow('vertical'), style:{position:'top-left',backgroundColor:'00005555'}})
Map.widgets().set(0,panel)
/*panel para los gráficos*/
var panelgrafico = ui.Panel({layout:ui.Panel.Layout.Flow('vertical'),style:{width:'300px',position:'top-right'}})
/*
Colección Sentinel 2
*/
var coleccion = S2.filterBounds(Sitios)
.filterDate('2018-01-01', ee.Date(Date.now()))
.filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than',5)
.map(function(i){
  //modelo de fapar de ESA
  var biopar = require('users/kristofvantricht/s2_biopar:biopar');
  //contruir cada imagen fapar
  var fapar = biopar.get_fapar(i)
  i = i.addBands(fapar.rename('fRFA'))
  var ndvi = i.normalizedDifference(['B8', 'B4']).rename('NDVI')
  i = i.addBands(ndvi)
  return i
  })
function addcampos(){
var selectcampo = ui.Select({
  items: Object.keys(dic.Campos), 
  placeholder:'Seleccione Campo', 
  onChange:function(c){
    if(c === 'Las Gamas'){
      var label = ui.Label('Bosque de Schinopsis y Acacia praecox', {fontSize:'25px',fontWeight:'bold',backgroundColor:'00000000', color:'white'})
      Map.widgets().set(1,label)
      var grafico = ui.Chart.image.seriesByRegion(coleccion, Sitios.filter(ee.Filter.eq('nombre', c)), ee.Reducer.mean(), 'NDVI', 10, null, 'id')
      panelgrafico.widgets().set(0,grafico)
      var grafico1 = ui.Chart.image.seriesByRegion(coleccion, Sitios.filter(ee.Filter.eq('nombre', c)), ee.Reducer.mean(), 'fRFA', 10, null, 'id')
      panelgrafico.widgets().set(1,grafico1)
      var urlClick = ui.Label({
     value: 'Fotos estabecimiento: '+c,
     style: {fontSize: "18px", backgroundColor:'white', position:'bottom-right'},
     targetUrl: 'https://photos.app.goo.gl/y54nSjJqkhh1FKx77'
     });
     Map.widgets().set(2,urlClick);
  var addSelVarSubPanel = ui.Panel([], ui.Panel.Layout.Flow('vertical', true),{maxHeight:'450px',position:'bottom-center'});
    }else if(c ==='Los Lapachos'){
      var label = ui.Label('Sabana de Prosopis, Vachellia',{fontSize:'25px',fontWeight:'bold',backgroundColor:'00000000',color:'white'})
      Map.widgets().set(1,label)
      var grafico = ui.Chart.image.seriesByRegion(coleccion, Sitios.filter(ee.Filter.eq('nombre', c)), ee.Reducer.mean(), 'NDVI', 10, null, 'id')
      panelgrafico.widgets().set(0,grafico)
      var grafico1 = ui.Chart.image.seriesByRegion(coleccion, Sitios.filter(ee.Filter.eq('nombre', c)), ee.Reducer.mean(), 'fRFA', 10, null, 'id')
      panelgrafico.widgets().set(1,grafico1)
      var urlClick = ui.Label({
     value: 'Fotos estabecimiento: '+c,
     style: {fontSize: "18px", backgroundColor:'white', position:'bottom-right'},
     targetUrl: 'https://photos.app.goo.gl/k2tHhG1KNMB6zzj18'
     });
     Map.widgets().set(2,urlClick);
    }else{
      var label = ui.Label('Monte Fuerte de Caesalpinia, Gleditsia',{fontSize:'25px',fontWeight:'bold',backgroundColor:'00000000',color:'white'})
      Map.widgets().set(1,label)
      var grafico = ui.Chart.image.seriesByRegion(coleccion, Sitios.filter(ee.Filter.eq('nombre', c)), ee.Reducer.mean(), 'NDVI', 10, null, 'id')
      panelgrafico.widgets().set(0,grafico)
      var grafico1 = ui.Chart.image.seriesByRegion(coleccion, Sitios.filter(ee.Filter.eq('nombre', c)), ee.Reducer.mean(), 'fRFA', 10, null, 'id')
      panelgrafico.widgets().set(1,grafico1)
      var urlClick = ui.Label({
     value: 'Fotos estabecimiento: '+c,
     style: {fontSize: "18px", backgroundColor:'white', position:'bottom-right'},
     targetUrl: 'https://photos.app.goo.gl/SBCzTN9p3Ugt2uBp7'
     });
     Map.widgets().set(2,urlClick);
    }
    var layer = ui.Map.Layer(Sitios.filter(ee.Filter.inList('nombre', [c])).style({fillColor:'00000000', color:'orange'}))
    Map.layers().set(0,layer)
    var layer2 = ui.Map.Layer(style.Feature.label(Sitios.filter(ee.Filter.eq('nombre', c)),'id', { 
      textColor:'ffffff', 
      fontSize: 18, 
      outlineColor:'000000', 
      outlineWidth: 4, 
      alignX:'center', 
      alignY:'center'
    }), {},'Etiquetas')
    /*==============================================
    Mostrar zoom
    ===============================================*/
    var mostrarzoom = ui.Button('Mostrar Zoom', function(i){
    var ocultar = ui.Button('Ocultar zoom',function(i){
      i = panel.remove(mostrarzoom)
      i = instructions.style().set('shown', true);
      i = panelzoom.style().set('shown', false);
      i = panel.widgets().set(1,mostrarzoom)
    })
    panel.widgets().set(1, ocultar)
    // Crear el Mapa del Zoom
    var zoomBox = ui.Map({style: {stretch: 'both', shown: false}})
        .setControlVisibility(false);
    var mosaicplanet = ui.Map.Layer(coleccionPlanet.mosaic(), {bands: ["b3","b2","b1"],min: 561.5,max: 1365.5,gamma: 2}, 'Mosaico Planet 3m')
    zoomBox.layers().set(0, mosaicplanet)
    zoomBox.layers().set(1, Sitios.filter(ee.Filter.inList('nombre', [c])).style({fillColor:'00000000', color:'orange'}))
    zoomBox.layers().set(2, style.Feature.label(Sitios.filter(ee.Filter.eq('nombre', c)),'id', { 
      textColor:'ffffff', 
      fontSize: 18, 
      outlineColor:'000000', 
      outlineWidth: 4, 
      alignX:'center', 
      alignY:'center'
    }), {},'Etiquetas')
    // Actualizar al hacer algun Movimiento ya sea zoom o derecha-izquierda
    Map.onChangeCenter(function(coords) {
      centerZoomBox(coords.lon, coords.lat);
    });
    var centerZoomBox = function(lon, lat) {
      instructions.style().set('shown', false);
      zoomBox.style().set('shown', true);
      zoomBox.setCenter(lon, lat, 20);
      var bounds = zoomBox.getBounds();
      var w = bounds[0], e = bounds [2];
      var n = bounds[1], s = bounds [3];
      var outline = ee.Geometry.MultiLineString([
        [[w, s], [w, n]],
        [[e, s], [e, n]],
        [[w, s], [e, s]],
        [[w, n], [e, n]],
      ]);
      var layer = ui.Map.Layer(outline, {color: 'FFFFFF'}, 'Zoom Box Bounds');
      Map.layers().set(2, layer);
    };
    // Añadir instrucciones al Mapa
    var instructions = ui.Label('Hacer zoom o mover el mapa', {
      stretch: 'both',
      textAlign: 'center',
      backgroundColor: '#d3d3d3'
    });
    var panelzoom = ui.Panel({
      widgets: [zoomBox, instructions],
      style: {
        position: 'bottom-left',
        height: '500px',
        width: '500px',
      }
    });
    Map.widgets().set(3,panelzoom);
    })
    panel.widgets().set(1,mostrarzoom)
    Map.layers().set(1,layer2)
    Map.centerObject(Sitios.filter(ee.Filter.inList('nombre', [c])),20)
    /*==========
    Añadir panel de gráfico
    ============*/
    var botongrafico = ui.Button('Mostrar Gráfico', function(g){
      var ocultargrafico = ui.Button('Ocultar Gráfico', function(o){
        o = Map.widgets().remove(panelgrafico)
        o = panel.widgets().set(2,botongrafico)
        o = panel.remove(ocultargrafico)
      })
      g = panel.widgets().set(2,ocultargrafico)
      g = panel.remove(botongrafico)
      g = Map.widgets().set(4, panelgrafico)
    })
    panel.widgets().set(2,botongrafico)
  }
  })
  panel.widgets().set(0,selectcampo)
}
addcampos()