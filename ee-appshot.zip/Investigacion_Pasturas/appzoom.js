var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -62.802478821947425,
                -28.279222275933346
              ],
              [
                -62.807971986009925,
                -29.2518913957542
              ],
              [
                -61.385242493822425,
                -29.280643403995146
              ],
              [
                -61.407215150072425,
                -28.322751329603168
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-62.802478821947425, -28.279222275933346],
          [-62.807971986009925, -29.2518913957542],
          [-61.385242493822425, -29.280643403995146],
          [-61.407215150072425, -28.322751329603168]]], null, false);
// Compute the trend of nighttime lights from DMSP.
// Add a band containing image date as years since 1991.
function createTimeBand(img) {
  var ndvi = img.normalizedDifference(['B8', 'B4'])
  var year = ee.Date(img.get('system:time_start')).get('year').subtract(2017);
  return ee.Image(year).byte().addBands(ndvi);
}
// Fit a linear trend to the nighttime lights collection.
var collection = ee.ImageCollection('COPERNICUS/S2')
    .filterBounds(geometry)
    .filterDate('2017-01-01', '2020-12-31')
    .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 1)
    .map(createTimeBand);
var fit = collection//.reduce(ee.Reducer.linearFit());
// Display trend in red/blue, brightness in green.
var visParams = {min: -0.15, max: 0.9, bands: ['nd'], palette: ['blue', 'black', 'white', 'yellow', 'green', 'red'], };
Map.addLayer(fit, visParams);
Map.style().set('cursor', 'crosshair');
// Create a map to be used as the zoom box.
var zoomBox = ui.Map({style: {stretch: 'both', shown: false}})
    .setControlVisibility(false);
zoomBox.addLayer(fit, visParams);
// Update the center of the zoom box map when the base map is clicked.
Map.onClick(function(coords) {
  centerZoomBox(coords.lon, coords.lat);
});
var centerZoomBox = function(lon, lat) {
  instructions.style().set('shown', false);
  zoomBox.style().set('shown', true);
  zoomBox.setCenter(lon, lat, 13);
  var bounds = zoomBox.getBounds();
  var w = bounds[0], e = bounds [2];
  var n = bounds[1], s = bounds [3];
  var outline = ee.Geometry.MultiLineString([
    [[w, s], [w, n]],
    [[e, s], [e, n]],
    [[w, s], [e, s]],
    [[w, n], [e, n]],
  ]);
  var layer = ui.Map.Layer(outline, {color: 'FFFFFF'}, 'Zoom Mapa');
  Map.layers().set(1, layer);
};
// Add a label and the zoom box map to the default map.
var instructions = ui.Label('Click en el mapa para mas detalle', {
  stretch: 'both',
  textAlign: 'center',
  backgroundColor: '#d3d3d3'
});
var panel = ui.Panel({
  widgets: [zoomBox, instructions],
  style: {
    position: 'top-right',
    height: '400px',
    width: '500px',
  }
});
Map.add(ui.Label('INDICE VERDE PROMEDIO AÑO 2017', {position: 'bottom-left'}));
Map.add(panel);
Map.centerObject(geometry, 10)