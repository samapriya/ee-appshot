var table_ind2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_IND_2"),
    table_ind3 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_IND_3"),
    table_ind1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_IND_1"),
    imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_india_punjab_2022"),
    imageCollection2 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_india_west_bengal_2022"),
    imageCollection3 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_india_tamil_nadu_2022_update"),
    imageCollection4 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_india_assam_2022"),
    imageCollection5 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_india_gujarat_2022_update");
var img_paddy=imageCollection.merge(imageCollection2).merge(imageCollection3).merge(imageCollection4).merge(imageCollection5).max() ;              
print('img_paddy',img_paddy)
var adm1=table_ind1; 
var adm2=table_ind3;
print('adm2 size',adm2.size())
print('adm1',adm1)
var roi=adm2;
var iso3='IND';
var sel_export_id='IND.2_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var img_paddy=img_paddy.clip(roi);
var intensityVisParam = {
  bands: ['classification'],
  min: 1,
  max: 3,
  palette: ['#40E0D0','#DFFF00','red']
  //palette: ['1500ff','22ff00','FF0000']
};
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(8.1);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(8.1).add(int_2.multiply(8.1));
//triple
var img3_ch4=int_3.multiply(8.1).add(int_3.multiply(8.1)).add(int_3.multiply(8.1));
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
print(imgtotal_ch4);
//SD
//singgle late
var sdimg1_ch4=int_1.multiply(4.25);
//double middle late
var sdimg2_ch4=(int_2.multiply(4.25).multiply(4.25).add(int_2.multiply(4.25).multiply(4.25))).sqrt();
//triple
var sdimg3_ch4=(int_3.multiply(4.25).multiply(4.25).add(int_3.multiply(4.25).multiply(4.25)).add(int_3.multiply(4.25).multiply(4.25))).sqrt();
//total
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
var methaneVisParam = {
  bands: ['classification'],
  min: 0,
  max: 80,
  palette: ['yellow', 'red']
  //palette: ['1500ff','22ff00','FF0000']
};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'India Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
var gaul0 = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level0").sort('ADM0_CODE')
print('List of countries',(gaul0.sort('ADM0_NAME').aggregate_array('ADM0_NAME')))
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['India'
])).sort('ADM0_CODE'))
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'India edges',1); 
//end india
//2 bangladesh
var imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_bangladesh_2022"),
    table_bgd1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_BGD_1"),
    table_bgd2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_BGD_2");
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_bgd1; 
var adm2=table_bgd2;
print('adm1',adm1)
var roi=adm2;
var iso3='BGD';
var sel_export_id='BGD.1_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(16.82);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(16.82).add(int_2.multiply(16.82));
//triple
var img3_ch4=int_3.multiply(16.82).add(int_3.multiply(16.82)).add(int_3.multiply(16.82));
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
print(imgtotal_ch4);
//singgle late
var sdimg1_ch4=int_1.multiply(8.04);
//double middle late
var sdimg2_ch4=(int_2.multiply(8.04).multiply(8.04).add(int_2.multiply(8.04).multiply(8.04))).sqrt();
//triple
var sdimg3_ch4=(int_3.multiply(8.04).multiply(8.04).add(int_3.multiply(8.04).multiply(8.04)).add(int_3.multiply(8.04).multiply(8.04))).sqrt();
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['Bangladesh'
])).sort('ADM0_CODE'))
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Bangladesh edges',1); 
//end Bangladesh
//pakistan
var imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_pakistan_2022"),
    table_pak1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_PAK_1"),
    table_pak2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_PAK_2");
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_pak1; 
var adm2=table_pak2;
print('adm1',adm1)
var roi=adm2;
var iso3='PAK';
var sel_export_id='PAK.2_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(8.1);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(8.1).add(int_2.multiply(8.1));
//triple
var img3_ch4=int_3.multiply(8.1).add(int_3.multiply(8.1)).add(int_3.multiply(8.1));
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
print(imgtotal_ch4);
//SD
//singgle late
var sdimg1_ch4=int_1.multiply(4.25);
//double middle late
var sdimg2_ch4=(int_2.multiply(4.25).multiply(4.25).add(int_2.multiply(4.25).multiply(4.25))).sqrt();
//triple
var sdimg3_ch4=(int_3.multiply(4.25).multiply(4.25).add(int_3.multiply(4.25).multiply(4.25)).add(int_3.multiply(4.25).multiply(4.25))).sqrt();
//total
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Pakistan Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['Pakistan'
])).sort('ADM0_CODE'))
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Pakistan edges',1); 
//end Pakistan
//nepal
var imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_nepal_2022"),
    table_npl1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_NPL_1"),
    table_npl2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_NPL_2");
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_npl1; 
var adm2=table_npl2;
print('adm1',adm1)
var roi=adm2;
var iso3='NPL';
var sel_export_id='NPL.2_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(8.1);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(8.1).add(int_2.multiply(8.1));
//triple
var img3_ch4=int_3.multiply(8.1).add(int_3.multiply(8.1)).add(int_3.multiply(8.1));
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
print(imgtotal_ch4);
//singgle late
var sdimg1_ch4=int_1.multiply(4.25);
//double middle late
var sdimg2_ch4=(int_2.multiply(4.25).multiply(4.25).add(int_2.multiply(4.25).multiply(4.25))).sqrt();
//triple
var sdimg3_ch4=(int_3.multiply(4.25).multiply(4.25).add(int_3.multiply(4.25).multiply(4.25)).add(int_3.multiply(4.25).multiply(4.25))).sqrt();
//total
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Nepal Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['Nepal'
])).sort('ADM0_CODE'))
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Nepal edges',1); 
//end nepal
//sri lanka
var table_lka1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_LKA_1"),
    table_lka2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_LKA_2"),
    imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_srilanka_2022");
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_lka1; 
var adm2=table_lka2;
print('adm1',adm1)
var roi=adm2;
var iso3='LKA';
var sel_export_id='LKA.1_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(8.1);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(8.1).add(int_2.multiply(8.1));
//triple
var img3_ch4=int_3.multiply(8.1).add(int_3.multiply(8.1)).add(int_3.multiply(8.1));
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
print(imgtotal_ch4);
//singgle late
var sdimg1_ch4=int_1.multiply(4.25);
//double middle late
var sdimg2_ch4=(int_2.multiply(4.25).multiply(4.25).add(int_2.multiply(4.25).multiply(4.25))).sqrt();
//triple
var sdimg3_ch4=(int_3.multiply(4.25).multiply(4.25).add(int_3.multiply(4.25).multiply(4.25)).add(int_3.multiply(4.25).multiply(4.25))).sqrt();
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Sri Lanka Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['Sri Lanka'
])).sort('ADM0_CODE'))
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Sri Lanka edges',1); 
//end Sri Lanka
////
/**
 * Define UI components.
 */
var comp = {};
// Title.
comp.title = {};
comp.title.label = ui.Label('Methane emission from rice paddy cultivation (2022)', null, 
  'https://www.umt.edu.my');
// Legend.
comp.legend = {};
comp.legend.title = ui.Label();
comp.legend.colorbar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: methaneVisParam.palette
  }
});
comp.legend.leftLabel = ui.Label('[min]');
comp.legend.centerLabel = ui.Label();
comp.legend.rightLabel = ui.Label('[max]');
comp.legend.labelPanel = ui.Panel({
  widgets: [
    comp.legend.leftLabel,
    comp.legend.centerLabel,
    comp.legend.rightLabel,
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
comp.legend.panel = ui.Panel([
  comp.legend.title,
  comp.legend.colorbar,
  comp.legend.labelPanel
], null, {width: '300px', position: 'bottom-left'});
/**
 * Compose the components.
 */
//Map.add(comp.title.label);
Map.add(comp.legend.panel);
/**
 * Style the components.
 */
var style = {};
style.title = {};
style.title.label = {
  fontWeight: 'bold',
  fontSize: '16px'
};
style.legend = {};
style.legend.title = {
  fontWeight: 'bold',
  fontSize: '14px',
  color: '383838'
};
style.legend.colorbar = {
  stretch: 'horizontal',
  margin: '0px 8px',
  maxHeight: '20px'
};
style.legend.leftLabel = {
  margin: '4px 8px',
  fontSize: '14px'
};
style.legend.centerLabel = {
  margin: '4px 8px',
  fontSize: '14px',
  textAlign: 'center',
  stretch: 'horizontal'
};
style.legend.rightLabel = {
  margin: '4px 8px',
  fontSize: '14px'
};
style.legend.panel = {
};
style.title.label;
comp.title.label.style().set(style.title.label);
comp.legend.title.style().set(style.legend.title);
comp.legend.colorbar.style().set(style.legend.colorbar);
comp.legend.leftLabel.style().set(style.legend.leftLabel);
comp.legend.centerLabel.style().set(style.legend.centerLabel);
comp.legend.rightLabel.style().set(style.legend.rightLabel);
comp.legend.title.setValue('Methane Emission (g/m2/year)');
comp.legend.leftLabel.setValue(methaneVisParam.min + 0);
comp.legend.centerLabel.setValue(methaneVisParam.max / 2  + 0);
comp.legend.rightLabel.setValue(methaneVisParam.max  + 0);
//intensity
// Create legend title
// Create legend title
var legendTitle = ui.Label({
 // value: 'Rice cropping intensity',
  value: 'Month',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
//legend 2
// set position of panel
var legend2 = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle2 = ui.Label({
  value: 'Rice cropping intensity',
 // value: 'Month',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend2.add(legendTitle2);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
 //var palette =['FF0000', '22ff00', '1500ff'];
 var palette2 =['40E0D0','DFFF00','FF0000'];
// name of the legend
//var names = ['Red','Green','Blue'];
 var names2 = ['Single','Double','Triple'];
// Add color and and names
for (var i = 0; i < 3; i++) {
  legend2.add(makeRow(palette2[i], names2[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend2);
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['India'
])).sort('ADM0_CODE'))
Map.centerObject(adm0,4)
Map.setOptions('SATELLITE')