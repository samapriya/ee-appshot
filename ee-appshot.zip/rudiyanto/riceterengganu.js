var shp_iada_ketara = ui.import && ui.import("shp_iada_ketara", "table", {
      "id": "users/rudiyanto/Terengganu/roi_iada_ketara"
    }) || ee.FeatureCollection("users/rudiyanto/Terengganu/roi_iada_ketara"),
    img_paddy = ui.import && ui.import("img_paddy", "image", {
      "id": "users/rudiyanto/Terengganu/img_intensity_paddy_terengganu_2022"
    }) || ee.Image("users/rudiyanto/Terengganu/img_intensity_paddy_terengganu_2022"),
    imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "users/rudiyanto/Terengganu_rice"
    }) || ee.ImageCollection("users/rudiyanto/Terengganu_rice");
//var terengganu_binary = ee.ImageCollection("users/fatchurrachman01/rice_terengganu_s12/z_out_rice_s12_terengganu_binary"),
//    terengganu_cluster = ee.ImageCollection("users/fatchurrachman01/rice_terengganu_s12/z_out_rice_s12_terengganu_cluster");
var img_paddy=imageCollection.max()
// Create a composite for the selected region
var admin0 = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level0");
var admin1 = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level1");
var admin2 = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level2");
var iso3='MYS';
var selected0 = admin0.filter(ee.Filter.eq('ADM0_NAME', 'Malaysia'))
var selected1 = admin1.filter(ee.Filter.eq('ADM1_NAME', 'Terengganu'))
var selected2 = admin2.filter(ee.Filter.eq('ADM1_NAME', 'Terengganu'))
print(selected2)
print(selected2.aggregate_array('ADM2_NAME').sort())
var geometry = selected1.geometry()
//Map.addLayer(terengganu_binary,{min:0,max:1,palette:['blue','red'] },'terengganu_binary');
//Map.addLayer(terengganu_cluster,{min:0,max:2,palette:['blue','green'] },'terengganu_cluster',0);
//var img_paddy=terengganu_binary.max()
print(img_paddy)
//var img_kemaman=img_paddy.clip(geometry_kemaman).multiply(2).toByte()
//var img_col=ee.ImageCollection([img_paddy,img_kemaman])
//var img_paddy=img_col.max().rename('classification')
Map.addLayer(img_paddy,{min:1,max:2,palette:['orange','red'] },'terengganu_cluster',1);
//by class (number of harvest) and by country
var img_product=img_paddy.select('classification');
var imgscale=10;//img_product.projection().nominalScale().getInfo();
print('Scale in meters:',imgscale);
var img_class=img_product;//.select('nH');
print('shp_iada_ketara',shp_iada_ketara)
var areaImage = ee.Image.pixelArea().addBands(img_class)
var areas = areaImage.reduceRegion({
      reducer: ee.Reducer.sum().group({
      groupField: 1,
      groupName: 'class',
    }),
    geometry: shp_iada_ketara.geometry(),
    scale: imgscale,
    maxPixels: 1e13
    }); 
print('areas shp_iada_ketara',areas)
//by class (number of harvest) and by country
var img_class=img_product;//.select('nH');
var shp_adm=selected2;//.filter("NAME_1 == 'Selangor'");//shp_adm0;
print('shp_adm',selected2)
var areaImage = ee.Image.pixelArea().addBands(img_class)
var areas = areaImage.reduceRegion({
      reducer: ee.Reducer.sum().group({
      groupField: 1,
      groupName: 'class',
    }),
    geometry: shp_adm.geometry(),
    scale: imgscale,
    maxPixels: 1e13
    }); 
print('areas',areas)
// The result of reduceRegion() with a grouped reducer is a dictionary of dictionaries for each class
// The top level dictionary has a single key named 'groups'
// We can extract the individual dictionaries and merge them into a single one
var classAreas = ee.List(areas.get('groups'))
//Apply a function using .map() function to iterate over each class item
//We extract the class and area numbers and return a list for each class
//The result is a list of lists
// Important to note that dictionary key must be of type 'string'
// Our keys are class numbers, so we call .format() to convert the number to string
var classAreaLists = classAreas.map(function(item) {
  var areaDict = ee.Dictionary(item)
  var classNumber = ee.Number(areaDict.get('class')).format()
  var area = ee.Number(areaDict.get('sum')).divide(1e4).round()
  return ee.List([classNumber, area])
})
print('classAreaLists',classAreaLists)
// Introducting flatten()
// flatten() is an important function in Earth Engine required for data processing
// It takes a nested list and converts it to a flat list
// Many Earth Engine constructors such a ee.Dictionary, ee.FeatureCollection etc. expect a flat list
// So before creating such objects with nested objects, we must convert them to flat structures
var nestedList = ee.List([['a', 'b'], ['c', 'd'], ['e', 'f']])
print(nestedList)
print(nestedList.flatten())
// We can now create a dictionary using ee.Dictionary which accepts a list of key/value pairs
var result = ee.Dictionary(classAreaLists.flatten())
print('Hasil',result.size())
// Area Calculation by Class by Admin Area 
// We saw how we can calculate areas by class for the whole state
// What if we wanted to know the breakup of these class areas by each district?
// This requires one more level of processing.
// We can apply a similar computation as above, but
// by applying .map() on the Feature Collection to obtain the values by each district geometies
var calculateClassArea = function(feature) {
    var areas = ee.Image.pixelArea().addBands(img_class).reduceRegion({
      reducer: ee.Reducer.sum().group({
      groupField: 1,
      groupName: 'class',
    }),
    geometry: feature.geometry(),
    scale: imgscale,
    maxPixels: 1e13
    })
    var classAreas = ee.List(areas.get('groups'))
    var classAreaLists = classAreas.map(function(item) {
      var areaDict = ee.Dictionary(item)
      var classNumber = ee.Number(areaDict.get('class')).format()
      var area = ee.Number(areaDict.get('sum')).divide(1e4).round()
      return ee.List([classNumber, area])
    })
    var result = ee.Dictionary(classAreaLists.flatten())
    // The result dictionary has area for all the classes
    // We add the district name to the dictionary and create a feature
    //var Code_name = ['Begin_date','End_date','Alpha_3code','Country','ADM1_NAME','ADM2_NAME']; 
    // var Code_name = ['Begin_date','End_date','Alpha_3code','COUNTRY','NAME_1','NAME_2','VARNAME_2','GID_0','GID_1','GID_2'];
     var Code_name = ['ADM0_CODE','ADM0_NAME','ADM1_CODE','ADM1_NAME','ADM2_CODE','ADM2_NAME','ADM2_NAME'];
    var district = [feature.get(Code_name[0]),feature.get(Code_name[1]),feature.get(Code_name[2]),
                    feature.get(Code_name[3]),feature.get(Code_name[4]),feature.get(Code_name[5]),
                    feature.get(Code_name[6])];
    return ee.Feature(feature.geometry(), result.set(Code_name[0], district[0])
    .set(Code_name[1], district[1]).set(Code_name[2], district[2])
    .set(Code_name[3], district[3]).set(Code_name[4], district[4])
    .set(Code_name[5], district[5]).set(Code_name[6], district[6])
    );
}
var districtAreas = shp_adm.map(calculateClassArea);
// One thing to note is that each district may or may not have all 
// of the 17 classes present. So each feature will have different 
// number of attributes depending on which classes are present.
// We can explicitly set the expected fields in the output 
// so we get a homogeneous table with all classes
var classes = ee.List.sequence(1, 17);
// As we need to use the list of output fields in the Export function
// we have to call .getInfo() to get the list values on the client-side
//var Code_name = ['Begin_date','End_date','Alpha_3code','Country','ADM1_NAME','ADM2_NAME'];  
var Code_name = ['ADM0_CODE','ADM0_NAME','ADM1_CODE','ADM1_NAME','ADM2_CODE','ADM2_NAME','ADM2_NAME'];  
//var outputFields = ee.List(['district']).cat(classes).getInfo()
var outputFields = ee.List(Code_name).cat(classes).getInfo();
// Export the results as a CSV file
print('results CSV',districtAreas.limit(50));
var Datapaddy_area_by_class_country = districtAreas.map(function(feat){
  return ee.Feature(feat.geometry(), {
      country_name:feat.get('ADM0_NAME'),
      state:feat.get('ADM1_NAME'),
      county:feat.get('ADM2_NAME'),
      varcounty:feat.get('ADM1_NAME'),
      ADM0_NAME:feat.get('ADM0_NAME'),
      ADM1_NAME:feat.get('ADM1_NAME'),
      ADM2_NAME:feat.get('ADM2_NAME'),
     // polygonCoordinates_0 :feat.geometry().geometries().get(0),
     // polygonCoordinates_1 :feat.geometry().geometries().get(-1),
    //  area_m2 :feat.geometry().area().divide(10000),
     // rectangle :feat.bounds().geometries(),
      //tCH4: feat.get('tCH4'),
      parcel_single_paddy_ha: feat.toDictionary().get('1', 0),//feat.get('1'),
     parcel_double_paddy_ha: feat.toDictionary().get('2', 0),//feat.get('2'),
     parcel_triple_paddy_ha: feat.toDictionary().get('3', 0),//feat.get('3')
  })
})
print('Datapaddy_area_by_country',Datapaddy_area_by_class_country);
Export.table.toDrive({
    collection: Datapaddy_area_by_class_country,
    description: 'paddy_area_by_class_adm2',
    folder: 'GEE_paddy_area_terengganu_2022',
    fileNamePrefix: 'paddy_area_by_class_adm2_terengganu',
    fileFormat: 'CSV',
    selectors: ['ADM0_NAME','ADM1_NAME','ADM2_NAME','parcel_single_paddy_ha','parcel_double_paddy_ha','parcel_triple_paddy_ha']
    });
// Get the features as a list
var fc=Datapaddy_area_by_class_country;
// Define the chart and print it to the console.
/*
var chart =
    ui.Chart.feature
        .groups({
          features: fc,
          xProperty: 'ADM2_NAME',
          yProperty: 'parcel_double_paddy_ha',
          seriesProperty: 'warm'
        })
       // .setSeriesNames(['Warm', 'Cold'])
        .setChartType('ColumnChart')
        .setOptions({
          title: 'Rice field area by district (ha) in Terengganu',
          hAxis:
              {title: 'Distric', titleTextStyle: {italic: false, bold: true}},
          vAxis: {
            title: 'Area (ha)',
            titleTextStyle: {italic: false, bold: true}
          },
          bar: {groupWidth: '80%'},
          colors: [
                    '604791', '1d6b99', '39a8a7', '0f8755', '76b349', 'f0af07',
                    'e37d05', 'cf513e', '96356f', '724173', '9c4f97', '696969'
                  ],
         // colors: ['cf513e', '1d6b99'],
          isStacked: true
        });
print(chart);
*/
// Define the chart and print it to the console.
var chart =  ui.Chart.feature
        .groups({
          features: fc,
          xProperty: 'ADM2_NAME',
          yProperty: 'parcel_double_paddy_ha',
          seriesProperty: 'warm'
        })
                .setChartType('PieChart')
                .setOptions({
                  title: 'Rice area with double season by district (ha) in Terengganu',
                  colors: [
                    '604791', '1d6b99', '39a8a7', '0f8755', '76b349', 'f0af07',
                    'e37d05', 'cf513e', '96356f', '724173', '9c4f97', '696969'
                  ],
                  pieHole: 0.4,
                });
//print(chart);
var chart2 =  ui.Chart.feature
        .groups({
          features: fc,
          xProperty: 'ADM2_NAME',
          yProperty: 'parcel_single_paddy_ha',
          seriesProperty: 'warm'
        })
                .setChartType('PieChart')
                .setOptions({
                  title: 'Rice area with single season by district (ha) in Terengganu',
                  colors: [
                    '604791', '1d6b99', '39a8a7', '0f8755', '76b349', 'f0af07',
                    'e37d05', 'cf513e', '96356f', '724173', '9c4f97', '696969'
                  ],
                  pieHole: 0.4,
                });
var total_area1=(Datapaddy_area_by_class_country.reduceColumns({
  reducer: ee.Reducer.sum(),
  selectors: ['parcel_single_paddy_ha'],
 // weightSelectors: ['weight']
}));
print(total_area1);
var total_area2=(Datapaddy_area_by_class_country.reduceColumns({
  reducer: ee.Reducer.sum(),
  selectors: ['parcel_double_paddy_ha'],
 // weightSelectors: ['weight']
}));
print(total_area2);
var total_area3=(Datapaddy_area_by_class_country.reduceColumns({
  reducer: ee.Reducer.sum(),
  selectors: ['parcel_triple_paddy_ha'],
 // weightSelectors: ['weight']
}));
print(total_area3);
//add into country level
var added_date0 = function(feature) {
   var numb1=ee.Number(total_area1.get('sum'));//ee.Number.parse(feature.get('sum')); //ha
   var numb2=ee.Number(total_area2.get('sum'));//ee.Number.parse(feature.get('sum')); //ha
   var numb3=ee.Number(total_area3.get('sum'));//ee.Number.parse(feature.get('sum')); //ha
   var numb4=numb1.add(numb2.multiply(2)).add(numb3.multiply(3))
  return feature.set({start_date: '1/1/2022'}).set({end_date: '12/31/2022'}).set({iso3_country: iso3})
  .set({parcel_single_paddy_ha: numb1})
  .set({parcel_double_paddy_ha: numb2})
  .set({parcel_triple_paddy_ha: numb3})
  .set({harvested_area_paddy: numb4});
};
var table_adm0_area=selected1.map(added_date0);
//var table_vietnam0_ch4=table_vietnam.map(added_date0);//sub region
print('table_adm0_area',table_adm0_area)
Export.table.toDrive({
    collection: table_adm0_area,
    description: 'Table_total_paddy_area_terengganu_2022_'+iso3,
    folder: 'GEE_paddy_area_terengganu_2022',
    fileNamePrefix: 'Table_total_paddy_area_2022_terengganu_'+iso3,
    fileFormat: 'CSV',
    selectors: ['start_date','end_date','iso3_country',
                'parcel_single_paddy_ha','parcel_double_paddy_ha','parcel_triple_paddy_ha',
                'harvested_area_paddy']
    });
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
// Paint all the polygon edges with the same number and width, display.
var outline = empty.paint({
  featureCollection: selected0,
  color: 1,
  width: 3,
});
Map.addLayer(outline, {palette: 'gray'}, 'Coutry boundary');
var outline = empty.paint({
  featureCollection: selected1,
  color: 1,
  width: 1,
});
Map.addLayer(outline, {palette: '00FF00'}, 'State boundary');
var outline = empty.paint({
  featureCollection: selected2,
  color: 1,
  width: 1,
});
Map.addLayer(outline, {palette: '00FFFF'}, 'District boundary');
var outline = empty.paint({
  featureCollection: shp_iada_ketara,
  color: 1,
  width: 1,
});
Map.addLayer(outline, {palette: '00FF00'}, 'IADA KETARA boundary');
Map.centerObject(selected1)
Map.setOptions("SATELLITE")
var logo_umt = ee.Image("users/Rudipb/logo_umt_3");
var branding = ui.Thumbnail({image:logo_umt,params:{bands:['b1','b2','b3'],min:0,max:255},style:{width:'100px',height:'80px',padding:'2px'}});
//************************************************************************//
//*************** Create a panel next to the map *************************//
//*************** to view NDVI and VH chart ******************************//
//***** can we improve by selecting tertiary blocks instead of points? ***//
//************************************************************************//
var panel = ui.Panel({style:{width: '550px'}});
//ui.root.add(panel);
ui.root.insert(1, panel);
var label1 = ui.Label({
  value: 'Detailed Inventory and Mapping of Rice Extent and Cropping Pattern in Terengganu State Malaysia Using Sentinel-2 Data on the Google Earth Engine Platform',
  style: {
    fontSize: '16px',
    color: 'red',
   // fontWeight: 'bold',
    padding: '5px',
  }
});
 var label2 = ui.Label({
  value: "Fatchurrachman1, Norhidayah Che Soh1, Ramisah Mohd Shah1,\n"+  
  "Frisa Irawan Ginting1, Sunny Goh Eng Giap2, Muhammad Nazir Siham3,\n"+ 
 // "Dian Fiantis3, Budi Indra Setiawan4, Sam Schiller5,8, \n"+
  "Rudiyanto1*\n\n"+
"1-Universiti Malaysia Terengganu\n"+
"2-Universiti Malaysia Terengganu\n"+
"3-Malaysian Remote Sensing Agency\n", 
  style: {
    fontSize: '14px',
    color: 'black',
   // fontWeight: 'bold',
   whiteSpace:'pre',
    padding: '2px',
  }
});
 var label3 = ui.Label({
  value: 'Email: rudiyanto@umt.edu.my',
  style: {
    fontSize: '14px',
    color: 'black',
   // fontWeight: 'bold',
    padding: '5px',
  }
});
// ** instruction 2 (edit for ori script)
 var instructions = ui.Label({
  value: 'Choose irrigation block from the drop down list to view cluster area',
  style: {
    fontSize: '16px',
    color: 'black',
   // fontWeight: 'bold',
    padding: '5px',
  } });
  // var button = ui.Button('Load chart')
  panel.add(branding);
  panel.add(label1);
  panel.add(label2);
  panel.add(label3);
  //panel.add(instructions);
 panel.add(chart);
 panel.add(chart2);
 // *** Add legend
var legend = ui.Panel({style: {position: 'middle-right', padding: '8px 15px'}});
var makeRow = function(color, name) {
  var colorBox = ui.Label({
    style: {color: '#ffffff',
      backgroundColor: color,
      padding: '10px',
      margin: '0 0 4px 0',
    }
  });
  var description = ui.Label({
    value: name,
    style: {
      margin: '0px 0 4px 6px',
    }
  }); 
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')}
)};
var title = ui.Label({
  value: 'Legend',
  style: {fontWeight: 'bold',
    fontSize: '16px',
    margin: '0px 0 4px 0px'}});
legend.add(title);
legend.add(makeRow('red','Double season'))
//legend.add(makeRow('orange','Phase 1'))
//legend.add(makeRow('green','Phase 1'))
//legend.add(makeRow('magenta','Phase 2'))
legend.add(makeRow('orange','Single season'))
Map.add(legend);