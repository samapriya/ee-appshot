var grid_sea_rice = ui.import && ui.import("grid_sea_rice", "table", {
      "id": "users/rudiyanto/roi_grid_2deg/output_grid_sea_rice_ci10"
    }) || ee.FeatureCollection("users/rudiyanto/roi_grid_2deg/output_grid_sea_rice_ci10"),
    imageCollection_mean = ui.import && ui.import("imageCollection_mean", "imageCollection", {
      "id": "users/rudiyanto/GEE_SEA_Rice_Ci10_mean"
    }) || ee.ImageCollection("users/rudiyanto/GEE_SEA_Rice_Ci10_mean");
//Map.addLayer(imageCollection_mean.mean(),{min:1,max:3,palette:['40E0D0','DFFF00','FF0000']},'SEA_Rice_Ci10_2021')
//Map.addLayer(imageCollection_mean.mean(),{min:1,max:3,palette:['blue','green','red']},'NESEA_rice10 2019',0)
//https://essd.copernicus.org/articles/13/5969/2021/
//https://zenodo.org/record/5645344
var logo_umt = ee.Image("users/Rudipb/logo_umt_3");
var branding = ui.Thumbnail({image:logo_umt,params:{bands:['b1','b2','b3'],min:0,max:255},style:{width:'100px',height:'80px',padding:'2px'}});
var image7 = ee.Image("users/rudiyanto/asiaricemaps10m/SoutheastAsia2019_7"),
    image6 = ee.Image("users/rudiyanto/asiaricemaps10m/SoutheastAsia2019_6"),
    image5 = ee.Image("users/rudiyanto/asiaricemaps10m/SoutheastAsia2019_5"),
    image4 = ee.Image("users/rudiyanto/asiaricemaps10m/SoutheastAsia2019_4"),
    image3 = ee.Image("users/rudiyanto/asiaricemaps10m/SoutheastAsia2019_3"),
    image2 = ee.Image("users/rudiyanto/asiaricemaps10m/SoutheastAsia2019_2"),
    image1 = ee.Image("users/rudiyanto/asiaricemaps10m/SoutheastAsia2019_1");
var img_col=ee.ImageCollection([image1,image2,image3,image4,image5,image6,image7])
var imageCollection=img_col;
var img_paddy=imageCollection.max().rename('class')
var img_paddy=img_paddy.updateMask(img_paddy)
Map.addLayer(img_paddy,{min:1,max:3,palette:['blue','green','red']},'NESEA_rice10 2019',0)
//https://essd.copernicus.org/articles/15/1501/2023/
//https://zenodo.org/record/7315076
var img_paddy_MSEAsia2019=ee.Image("users/rudiyanto/MSEAsia2019/MSEAsia2019");
var img_paddy=img_paddy_MSEAsia2019.gt(125).rename('class')
var img_paddy=img_paddy.updateMask(img_paddy)
Map.addLayer(img_paddy,{min:1,max:3,palette:['orange','green','red']},'MSEAsia2019',0)
//print('grid_sea_rice',grid_sea_rice)
//Map.addLayer(grid_sea_rice,{},'grid')
/*
//SEA_Rice_Ci10 2021
var imageCollection2 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_sumatra"),
    imageCollection3 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_jawa_update"),
    imageCollection8 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_kalimantan"),
    imageCollection4 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_maluku"),
    imageCollection5 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_ntb_ntt"),
    imageCollection6 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_papua"),
    imageCollection7 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_sulawesi");
var imageCollection9 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_cambodia_update");
var imageCollection10 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_lao")
var imageCollection11 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_malaysia"),
    imageCollection12 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_malaysia_sabah")
var imageCollection13 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_myanmar")
var imageCollection14 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_philippines")
var imageCollection15 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_thailand")
var imageCollection16 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_vietnam")
var imageCollection17 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_timor_leste");
var imageCollection=imageCollection3.merge(imageCollection2)
                    .merge(imageCollection4).merge(imageCollection5)
                    .merge(imageCollection6).merge(imageCollection7)
                    .merge(imageCollection8).merge(imageCollection9)
                    .merge(imageCollection10).merge(imageCollection11).merge(imageCollection12)
                    .merge(imageCollection13).merge(imageCollection14)
                    .merge(imageCollection15).merge(imageCollection16).merge(imageCollection17);
*/
var imageCollection=ee.ImageCollection("users/rudiyanto/GEE_SEA_Rice_Ci10_mean")
var img_paddy=imageCollection.max().rename('class')
var fao_gaul0 = ee.FeatureCollection('FAO/GAUL/2015/level0');
var fao_gaul2 = ee.FeatureCollection('FAO/GAUL/2015/level2');
print('List of countries',(fao_gaul0.sort('ADM0_NAME').aggregate_array('ADM0_NAME')))
var sel_country_name=['Indonesia','Timor-Leste','Cambodia',
                      'Lao People\'s Democratic Republic','Malaysia','Philippines',
                      'Myanmar','Thailand','Viet Nam']
var sel_country=fao_gaul0.filter(ee.Filter.inList('ADM0_NAME', sel_country_name))
print('sel_country',sel_country)
print('List of sel_country',sel_country.sort('ADM1_NAME').aggregate_array('ADM1_NAME'))
print('List of sel_country',sel_country.sort('ADM2_NAME').aggregate_array('ADM2_NAME'))
Map.centerObject(sel_country,4)
//Map.setCenter(12.876, 42.682, 5);
var styleParams = {
  fillColor: 'b5ffb4',
  color: '00909F',
  width: 1.0,
};
var sel_country1 = sel_country.style(styleParams);
//Map.addLayer(sel_country1, {}, 'Second Level Administrative Units',0);
var ad0Border = ee.Image().byte().paint({featureCollection: sel_country, color: 1, width: 1.2});
//Map.addLayer(ad0Border, {palette: '#978787'}, 'Country Boundaries');
Map.addLayer(img_paddy,{min:1,max:3,palette:['40E0D0','DFFF00','FF0000']},'SEA_Rice_Ci10_2021')
//print(img_paddy)    
//Map.addLayer(ad0Border, {palette: '#978787'}, 'Country Boundaries');  
Map.addLayer(ad0Border, {palette: 'pink'}, 'Country Boundaries');  
Map.setOptions({mapTypeId:"HYBRID"}) 
/*
var nn=12+16;//ee.Number(vector_grid.aggregate_array('no_id').size()).getInfo();
for(var i=12; i<nn; i++) {
  print('iteration_No:',i)
  var select_grid = grid_sea_rice.filter(ee.Filter.inList('uniqueNumb', [i])).sort('no_id')
//var roi=select_grid;
 Export.image.toAsset({
  image:img_paddy.toByte().clip(select_grid), 
 // image:imgClassified.updateMask(img_paddy).toByte(), 
   description:'GEE_SEA_Rice_Ci10_'+i, 
   assetId:'GEE_SEA_Rice_Ci10_mean/GEE_SEA_Rice_Ci10_'+i, 
   pyramidingPolicy:'mean',
  region:select_grid.geometry(), 
  scale:10, 
  crs:'EPSG:4326',
  maxPixels:1e13})
 Export.image.toDrive({
  image:img_paddy.toByte().clip(select_grid), 
 // image:imgClassified.updateMask(img_paddy).toByte(), 
   description:'GEE_SEA_Rice_Ci10_'+i, 
   folder:'GEE_SEA_Rice_Ci10',
   fileNamePrefix:'GEE_SEA_Rice_Ci10_'+i, 
  region:select_grid.geometry(), 
  scale:10, 
  crs:'EPSG:4326',
  maxPixels:1e13})
  Map.addLayer(select_grid.geometry(), {color:'#e84c3d'}, 'footprint (red)'+i);
}//loop
*/
////
/**
 * Define UI components.
 */
var comp = {};
// Title.
comp.title = {};
comp.title.label = ui.Label('SEA-Rice-Ci10 (2021)', null, 
  'https://www.umt.edu.my');
//Map.add(comp.title.label);
//intensity
// Create legend title
// Create legend title
var legendTitle = ui.Label({
 // value: 'Rice cropping intensity',
  value: 'Month',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
//legend 2
// set position of panel
var legend2 = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle2 = ui.Label({
  value: 'Rice cropping intensity',
 // value: 'Month',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend2.add(legendTitle2);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
 //var palette =['FF0000', '22ff00', '1500ff'];
 var palette2 =['40E0D0','DFFF00','FF0000'];
// name of the legend
//var names = ['Red','Green','Blue'];
 var names2 = ['Single','Double','Triple'];
// Add color and and names
for (var i = 0; i < 3; i++) {
  legend2.add(makeRow(palette2[i], names2[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)
//Map.add(legend2);  
///
// Create a panel next to the map
var panel = ui.Panel({style:{width: '470px'}});
ui.root.add(panel);
 // value: 'SENTINEL-2 NDVI & SENTINEL-1 VH Explorer',
 var label1 = ui.Label({
  value: 'SEA-Rice-Ci10: High-resolution Mapping of Rice Cropping Intensity and Harvested Area Across Southeast Asia using the Integration of Sentinel-1 and Sentinel-2 Data ',
  style: {
    fontSize: '16px',
    color: 'red',
   // fontWeight: 'bold',
    padding: '2px',
  }
});
 var label2 = ui.Label({
  value: "Frisa Irawan Ginting1, Rudiyanto1,8*, Fatchurahman1,\n"+  
  "Ramisah Mohd Shah1,Norhidayah Che Soh1, Sunny Goh Eng Giap2,\n"+ 
  "Dian Fiantis3, Budi Indra Setiawan4, Sam Schiller5,8, \n"+
  "Aaron Davitt6,8, Budiman Minasny7\n\n"+
"1-Universiti Malaysia Terengganu, Malaysia\n"+
"2-Universiti Malaysia Terengganu, Malaysia\n"+
"3-Andalas University, Indonesia\n"+
"4-IPB University, Indonesia\n"+
"5-Carbon Yield, Chicago IL, USA\n"+
"6-WattTime, Oakland CA, USA\n"+
"7-The University of Sydney, Australia\n"+
"8-Climate TRACE, Global coalition – USA and Malaysia\n", 
  style: {
    fontSize: '14px',
    color: 'black',
   // fontWeight: 'bold',
   whiteSpace:'pre',
    padding: '2px',
  }
});
 var label3 = ui.Label({
  value: '*Email: rudiyanto@umt.edu.my',
  style: {
    fontSize: '12px',
    color: 'black',
   // fontWeight: 'bold',
    padding: '2px',
  }
});
 var instructions = ui.Label({
  value: 'https://climatetrace.org/',
  style: {
    fontSize: '12px',
    color: 'black',
   // fontWeight: 'bold',
    padding: '2px',
  },
  targetUrl:'https://climatetrace.org/'
}); 
 var instructions2 = ui.Label({
  value: 'https://doi.org/10.5281/zenodo.10707621',
  style: {
    fontSize: '12px',
    color: 'black',
   // fontWeight: 'bold',
    padding: '2px',
  },
  targetUrl:'https://doi.org/10.5281/zenodo.10707621'
}); 
panel.add(branding);
  panel.add(label1);
 panel.add(label2);
 panel.add(label3);
 panel.add(instructions);
  panel.add(instructions2);
 panel.add(legend2);