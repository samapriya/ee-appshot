var geometry_se_asia = ui.import && ui.import("geometry_se_asia", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                90.7876271500552,
                29.564178071936894
              ],
              [
                90.7876271500552,
                -13.720399562268888
              ],
              [
                144.92825215005521,
                -13.720399562268888
              ],
              [
                144.92825215005521,
                29.564178071936894
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[90.7876271500552, 29.564178071936894],
          [90.7876271500552, -13.720399562268888],
          [144.92825215005521, -13.720399562268888],
          [144.92825215005521, 29.564178071936894]]], null, false);
//1-vietnam
var img_vietnam = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_vietnam_2022").max(),
    table_vietnam = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_VNM_1_sub"),
    table_vietnam2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_VNM_2"),
     table_vietnam0 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_VNM_0");
print(table_vietnam)
print('table_vietnam2 ',table_vietnam2.limit(2))
var iso3='VNM';
var adm1=table_vietnam;
Map.centerObject(adm1)
 //1-south vietnam
var select_boundary=table_vietnam.filter(ee.Filter.inList('sub_region', ['south'])).sort('sub_region')
//Map.addLayer(img_vietnam,{min:1,max:3,palette:['blue','green','red']},'Rice intensity vietnam 2022',1);
var intensityVisParam = {
  bands: ['classification'],
  min: 1,
  max: 3,
  palette: ['#40E0D0','#DFFF00','red']
  //palette: ['1500ff','22ff00','FF0000']
};
Map.addLayer(img_vietnam,intensityVisParam ,'paddy_inten')
var adm2=ee.List(select_boundary.aggregate_array('NAME_1'));
print(adm2)
var select_boundary1=table_vietnam2.filter(ee.Filter.inList('NAME_1', adm2)).sort('NAME_1')
print(select_boundary1)
//Map.addLayer(table_vietnam)
//Map.addLayer(select_boundary1,{},'ad2',0)
print(img_vietnam)
var int_1=img_vietnam.select('classification').eq(1).clip(select_boundary1);//.unmask()
var int_2=img_vietnam.select('classification').eq(2).clip(select_boundary1);//.unmask()
var int_3=img_vietnam.select('classification').eq(3).clip(select_boundary1);//.unmask()
//Map.addLayer(int_1,{min:0,max:1,palette:['white','blue']},'1vietnam 2022',1);
//Map.addLayer(int_2,{min:0,max:1,palette:['white','green']},'2vietnam 2022',1);
//Map.addLayer(int_3,{min:0,max:1,palette:['white','red']},'3vietnam 2022',1);
//singgle late
var img1_ch4=int_1.multiply(35.6); //g/m2/season
var sdimg1_ch4=int_1.multiply(48.1); //g/m2/season
//double middle late
var img2_ch4=int_2.multiply(35.6).add(int_2.multiply(27.7));
var sdimg2_ch4=(int_2.multiply(48.1).multiply(48.1).add(int_2.multiply(11.6).multiply(11.6))).sqrt();
//triple early middle late
var img3_ch4=int_3.multiply(35.6).add(int_3.multiply(27.7)).add(int_3.multiply(17.4));
var sdimg3_ch4=(int_3.multiply(48.1).multiply(48.1).add(int_3.multiply(11.6).multiply(11.6)).add(int_3.multiply(8.2).multiply(8.2))).sqrt();
var imgtotal_ch4_s=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_vietnam);
var sdimgtotal_ch4_s=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
print(imgtotal_ch4_s);
//Map.addLayer(imgtotal_ch4_s,{min:0,max:900,palette:['white','orange','red']},'imgtotal_ch4 2022',0);
// 2-central vietnam
 var select_boundary=table_vietnam.filter(ee.Filter.inList('sub_region', ['central'])).sort('sub_region')
//Map.addLayer(img_vietnam,{min:1,max:3,palette:['blue','green','red']},'vietnam 2022',1);
var adm2=ee.List(select_boundary.aggregate_array('NAME_1'));
print(adm2)
 var select_boundary1=table_vietnam2.filter(ee.Filter.inList('NAME_1', adm2)).sort('NAME_1')
 print(select_boundary1)
//Map.addLayer(table_vietnam)
//Map.addLayer(select_boundary1,{},'ad2',0)
print(img_vietnam)
var int_1=img_vietnam.select('classification').eq(1).clip(select_boundary1);//.unmask()
var int_2=img_vietnam.select('classification').eq(2).clip(select_boundary1);//.unmask()
//var int_3=img_vietnam.select('classification').eq(3).unmask().clip(select_boundary1);
//Map.addLayer(int_1,{min:0,max:1,palette:['white','blue']},'1vietnam 2022',1);
//Map.addLayer(int_2,{min:0,max:1,palette:['white','green']},'2vietnam 2022',1);
//Map.addLayer(int_3,{min:0,max:1,palette:['white','red']},'3vietnam 2022',1);
//singgle late
var img1_ch4=int_1.multiply(32.1);
var sdimg1_ch4=int_1.multiply(23.7);
//double middle late
var img2_ch4=int_2.multiply(32.1).add(int_2.multiply(32.1));
var sdimg2_ch4=(int_2.multiply(23.7).multiply(23.7).add(int_2.multiply(23.7).multiply(23.7))).sqrt();
//triple early middle late
//var img3_ch4=int_3.multiply(356).add(int_3.multiply(277)).add(int_3.multiply(174));
var imgtotal_ch4_c=img1_ch4.add(img2_ch4);//.updateMask(img_vietnam);//.add(img3_ch4);
var sdimgtotal_ch4_c=sdimg1_ch4.add(sdimg2_ch4);
print(imgtotal_ch4_c);
//Map.addLayer(imgtotal_ch4_c,{min:0,max:900,palette:['white','orange','red']},'imgtotal_ch4 2022',0);
//
// 3-north vietnam
 var select_boundary=table_vietnam.filter(ee.Filter.inList('sub_region', ['north'])).sort('sub_region')
//Map.addLayer(img_vietnam,{min:1,max:3,palette:['blue','green','red']},'harvested vietnam 2022',1);
var adm2=ee.List(select_boundary.aggregate_array('NAME_1'));
print(adm2)
 var select_boundary1=table_vietnam2.filter(ee.Filter.inList('NAME_1', adm2)).sort('NAME_1')
 print(select_boundary1)
//Map.addLayer(table_vietnam)
//Map.addLayer(select_boundary1,{},'ad2',0)
print(img_vietnam)
var int_1=img_vietnam.select('classification').eq(1).clip(select_boundary1);//.unmask()
var int_2=img_vietnam.select('classification').eq(2).clip(select_boundary1);//.unmask()
//var int_3=img_vietnam.select('classification').eq(3).unmask().clip(select_boundary1);
//Map.addLayer(int_1,{min:0,max:1,palette:['white','blue']},'1vietnam 2022',1);
//Map.addLayer(int_2,{min:0,max:1,palette:['white','green']},'2vietnam 2022',1);
//Map.addLayer(int_3,{min:0,max:1,palette:['white','red']},'3vietnam 2022',1);
//singgle late
var img1_ch4=int_1.multiply(27.1);
var sdimg1_ch4=int_1.multiply(15);
//double middle late
var img2_ch4=int_2.multiply(27.1).add(int_2.multiply(40.4));
var sdimg2_ch4=(int_2.multiply(15).multiply(15).add(int_2.multiply(17.3).multiply(17.3))).sqrt();
//triple early middle late
//var img3_ch4=int_3.multiply(356).add(int_3.multiply(277)).add(int_3.multiply(174));
var imgtotal_ch4_n=img1_ch4.add(img2_ch4);//.updateMask(img_vietnam);//.add(img3_ch4);
var sdimgtotal_ch4_n=sdimg1_ch4.add(sdimg2_ch4);
print('imgtotal_ch4_n',imgtotal_ch4_n);
//Map.addLayer(imgtotal_ch4_n,{min:0,max:900,palette:['white','orange','red']},'imgtotal_ch4 2022',0);
//total 
var img_ch4_vietnam=ee.ImageCollection([imgtotal_ch4_s,imgtotal_ch4_c,imgtotal_ch4_n]).max();//.updateMask(img_vietnam).clip(table_vietnam0)// g/m2 (pixel size = 10 x 10 m2)
//var img_ch4_vietnam=ee.ImageCollection([imgtotal_ch4_s]).max();
//var img_ch4_vietnam=ee.ImageCollection([imgtotal_ch4_c]).max();
//var img_ch4_vietnam=ee.ImageCollection([imgtotal_ch4_n]).max();
//SD
var sdimg_ch4_vietnam=ee.ImageCollection([sdimgtotal_ch4_s,sdimgtotal_ch4_c,sdimgtotal_ch4_n]).max();
//var img_ch4_vietnam=sdimg_ch4_vietnam.multiply(sdimg_ch4_vietnam);
//var img_ch4_vietnam=imgtotal_ch4_s.add(imgtotal_ch4_c).add(imgtotal_ch4_n).updateMask(img_vietnam).clip(table_vietnam0)
//var img_ch4_vietnam=img_ch4_vietnam.multiply()
print('img_ch4_vietnam',img_ch4_vietnam)
//Map.addLayer(img_ch4_vietnam,{min:0,max:80,palette:['white','yellow','orange','red']},'CH4 flux 2022',1);
var upper=img_ch4_vietnam.add(sdimg_ch4_vietnam);
var lower=img_ch4_vietnam.subtract(sdimg_ch4_vietnam);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
var methaneVisParam = {
  bands: ['classification'],
  min: 0,
  max: 80,
 // palette: ['white','blue','green', 'red']
  palette: ['yellow', 'red']
};
Map.addLayer(img_ch4_vietnam, methaneVisParam, 'Viet Nam Methane g/m2/year',1);
//Map.addLayer(sdimg_ch4_vietnam, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
// Paint all the polygon edges with the same number and width, display.
var outline = empty.paint({
  featureCollection: table_vietnam0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Viat Nam edges');   
Map.centerObject(table_vietnam0,5);
//end vietnam
//2-Thailand
var img_paddy_thailand = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_thailand_2022"),
    adm0 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_THA_0"),
    table_grid = ee.FeatureCollection("users/rudiyanto/roi_grid_2deg/grid_thailand_2deg"),
    table_thailand_2_region = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_THA_2_sub_region");
print(table_thailand_2_region.aggregate_array('sub_region').sort())
var img_paddy=img_paddy_thailand.max();
print('img_paddy',img_paddy)
//Map.addLayer(img_paddy,{min:1,max:3,palette:['blue','green','red']},'paddy_inten')
Map.addLayer(img_paddy,intensityVisParam ,'paddy_inten')
Map.centerObject(table_thailand_2_region,5)
var adm2=table_thailand_2_region;
var roi=adm2;
var iso3='THA';
Map.addLayer(adm2,{},'adm2',0)
 //1-Chai Nat
var select_boundary=adm2.filter(ee.Filter.inList('sub_region', ['Chai Nat'])).sort('sub_region')
Map.addLayer(select_boundary,{color:'orange'},'1-Chai Nat',0)
//Map.addLayer(img_vietnam,{min:1,max:3,palette:['blue','green','red']},'Rice intensity vietnam 2022',1);
var int_1=img_paddy.select('classification').eq(1).clip(select_boundary);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2).clip(select_boundary);//.unmask().clip(roi);
Map.addLayer(int_1.add(int_2.multiply(2)),{min:0,max:3,palette:['white','blue','green','red']},'intensity_1_Chai_Nat')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(2.5);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(2.5).add(int_2.multiply(2.5));
var imgtotal_ch4_1_Chai_Nat=img1_ch4.add(img2_ch4).toFloat();//.updateMask(img_paddy);//.add(img3_ch4);
//1 end
//2-Chiang Mai
var select_boundary=adm2.filter(ee.Filter.inList('sub_region', ['Chiang Mai'])).sort('sub_region')
Map.addLayer(select_boundary,{color:'gray'},'2-Chiang Mai',0)
//Map.addLayer(img_vietnam,{min:1,max:3,palette:['blue','green','red']},'Rice intensity vietnam 2022',1);
var int_1=img_paddy.select('classification').eq(1).clip(select_boundary);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2).clip(select_boundary);//.unmask().clip(roi);
Map.addLayer(int_1.add(int_2.multiply(2)),{min:0,max:3,palette:['white','blue','green','red']},'intensity_2_Chiang Mai')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(39.8);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(39.8).add(int_2.multiply(21.3));
var imgtotal_ch4_2_Chiang_Mai=img1_ch4.add(img2_ch4).toFloat();//.updateMask(img_paddy);//.add(img3_ch4);
//2 end
//3-Khon Kaen
var select_boundary=adm2.filter(ee.Filter.inList('sub_region', ['Khon Kaen'])).sort('sub_region')
Map.addLayer(select_boundary,{color:'gray'},'3_Khon Kaen',0)
var int_1=img_paddy.select('classification').eq(1).clip(select_boundary);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2).clip(select_boundary);//.unmask().clip(roi);
Map.addLayer(int_1.add(int_2.multiply(2)),{min:0,max:3,palette:['white','blue','green','red']},'intensity_3_Khon Kaen')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(50.8);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(50.8).add(int_2.multiply(38.2));
var imgtotal_ch4_3_Khon_Kaen=img1_ch4.add(img2_ch4).toFloat();//.updateMask(img_paddy);//.add(img3_ch4);
//3 end
//4-Pathum Thani
var select_boundary=adm2.filter(ee.Filter.inList('sub_region', ['Pathum Thani'])).sort('sub_region')
Map.addLayer(select_boundary,{color:'gray'},'4_Pathum Thani',0)
var int_1=img_paddy.select('classification').eq(1).clip(select_boundary);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2).clip(select_boundary);//.unmask().clip(roi);
Map.addLayer(int_1.add(int_2.multiply(2)),{min:0,max:3,palette:['white','blue','green','red']},'intensity_4_Pathum Thani')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(50.8);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(50.8).add(int_2.multiply(38.2));
var imgtotal_ch4_4_Pathum_Thani=img1_ch4.add(img2_ch4).toFloat();//.updateMask(img_paddy);//.add(img3_ch4);
//4 end
//5-Phitsanulok
var select_boundary=adm2.filter(ee.Filter.inList('sub_region', ['Phitsanulok'])).sort('sub_region')
Map.addLayer(select_boundary,{color:'gray'},'5_Phitsanulok',0)
var int_1=img_paddy.select('classification').eq(1).clip(select_boundary);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2).clip(select_boundary);//.unmask().clip(roi);
Map.addLayer(int_1.add(int_2.multiply(2)),{min:0,max:3,palette:['white','blue','green','red']},'intensity_5_Phitsanulok')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(17.4);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(17.4).add(int_2.multiply(17.8));
var imgtotal_ch4_5_Phitsanulok=img1_ch4.add(img2_ch4).toFloat();//.updateMask(img_paddy);//.add(img3_ch4);
//5 end
//6-Phra Nakhon
var select_boundary=adm2.filter(ee.Filter.inList('sub_region', ['Phra Nakhon'])).sort('sub_region')
Map.addLayer(select_boundary,{color:'gray'},'6_Phra Nakhon',0)
var int_1=img_paddy.select('classification').eq(1).clip(select_boundary);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2).clip(select_boundary);//.unmask().clip(roi);
Map.addLayer(int_1.add(int_2.multiply(2)),{min:0,max:3,palette:['white','blue','green','red']},'intensity_6_Phra_Nakhon')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(55.5);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(55.5).add(int_2.multiply(19));
var imgtotal_ch4_6_Phra_Nakhon=img1_ch4.add(img2_ch4).toFloat();//.updateMask(img_paddy);//.add(img3_ch4);
//6 end
//7-Phrae
var select_boundary=adm2.filter(ee.Filter.inList('sub_region', ['Phrae'])).sort('sub_region')
Map.addLayer(select_boundary,{color:'gray'},'7_Phrae',0)
var int_1=img_paddy.select('classification').eq(1).clip(select_boundary);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2).clip(select_boundary);//.unmask().clip(roi);
Map.addLayer(int_1.add(int_2.multiply(2)),{min:0,max:3,palette:['white','blue','green','red']},'intensity_7_Phrae')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(68.2);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(68.2).add(int_2.multiply(48.5));
var imgtotal_ch4_7_Phrae=img1_ch4.add(img2_ch4).toFloat();//.updateMask(img_paddy);//.add(img3_ch4);
//7 end
//8-Surin
var select_boundary=adm2.filter(ee.Filter.inList('sub_region', ['Surin'])).sort('sub_region')
Map.addLayer(select_boundary,{color:'gray'},'8_Surin',0)
var int_1=img_paddy.select('classification').eq(1).clip(select_boundary);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2).clip(select_boundary);//.unmask().clip(roi);
Map.addLayer(int_1.add(int_2.multiply(2)),{min:0,max:3,palette:['white','blue','green','red']},'intensity_8_Surin')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(39.3);//g/m2/season
//double middle late
var img2_ch4=int_2.multiply(39.3).add(int_2.multiply(44.4));
var imgtotal_ch4_8_Surin=img1_ch4.add(img2_ch4).toFloat();//.updateMask(img_paddy);//.add(img3_ch4);
//8 end
//total 
var imgtotal_ch4=ee.ImageCollection([imgtotal_ch4_1_Chai_Nat,imgtotal_ch4_2_Chiang_Mai,
                                     imgtotal_ch4_3_Khon_Kaen,imgtotal_ch4_4_Pathum_Thani,
                                     imgtotal_ch4_5_Phitsanulok,imgtotal_ch4_6_Phra_Nakhon,
                                     imgtotal_ch4_7_Phrae,imgtotal_ch4_8_Surin]).max().rename('classification');
//var imgtotal_ch4=imgtotal_ch4_1_Chai_Nat.add(imgtotal_ch4_2_Chiang_Mai).rename('classification');
print('imgtotal_ch4',imgtotal_ch4);
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Thailand Methane g/m2/year',1);
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
// Paint all the polygon edges with the same number and width, display.
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Thailand edges',1);   
//end 2 thailand
//3-cambodia
var imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_cambodia_2022"),
    table_khm1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_KHM_1"),
    table_khm2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_KHM_2"),
 adm0 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_KHM_0");
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
//Map.addLayer(img_paddy,{min:1,max:3,palette:['blue','green','red']},'paddy_inten')
Map.addLayer(img_paddy,intensityVisParam ,'paddy_inten')
var adm1=table_khm1; 
var adm2=table_khm2;
print('adm1',adm1)
var roi=adm2;
var iso3='KHM';
var sel_export_id='KHM.1_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(14.53);
var sdimg1_ch4=int_1.multiply(3.1);
//double middle late
var img2_ch4=int_2.multiply(14.53).add(int_2.multiply(14.53));
var sdimg2_ch4=(int_2.multiply(3.1).multiply(3.1).add(int_2.multiply(3.1).multiply(3.1))).sqrt();
//triple
var img3_ch4=int_3.multiply(14.53).add(int_3.multiply(14.53)).add(int_3.multiply(14.53));
var sdimg3_ch4=(int_3.multiply(3.1).multiply(3.1).add(int_3.multiply(3.1).multiply(3.1)).add(int_3.multiply(3.1).multiply(3.1))).sqrt();
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
print(imgtotal_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Cambodia Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
// Paint all the polygon edges with the same number and width, display.
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'edges',1);  
// end 3 cambodia
//4-Lao
var table_lao1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_LAO_1"),
    table_lao2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_LAO_2"),
    imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_lao_2022_update_3"),
    adm0 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_LAO_0");
var img_paddy=imageCollection.max().rename('classification')
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_lao1; 
var adm2=table_lao2;
print('adm1',adm1)
var roi=adm2;
var iso3='LAO';
var sel_export_id='LAO.1_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
//singgle late
var img1_ch4=int_1.multiply(7.83);
var sdimg1_ch4=int_1.multiply(3.16);
//double middle late
var img2_ch4=int_2.multiply(7.83).add(int_2.multiply(7.83));
var sdimg2_ch4=(int_2.multiply(3.16).multiply(3.16).add(int_2.multiply(3.16).multiply(3.16))).sqrt();
//triple
var img3_ch4=int_3.multiply(7.83).add(int_3.multiply(7.83)).add(int_3.multiply(7.83));
var sdimg3_ch4=(int_3.multiply(3.16).multiply(3.16).add(int_3.multiply(3.16).multiply(3.16)).add(int_3.multiply(3.16).multiply(3.16))).sqrt();
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
print(imgtotal_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Lao Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
// Paint all the polygon edges with the same number and width, display.
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Lao edges',1);  
//end 4 lao
//5 myanmar
var imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_myanmar_2022"),
    table_mmr2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_MMR_2"),
    table_mmr1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_MMR_1"),
    adm0 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_MMR_0");
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_mmr1; 
var adm2=table_mmr2;
print('adm1',adm1)
var roi=adm2;
var iso3='MMR';
var sel_export_id='MMR.3_1'; //dummy export
Map.centerObject(adm1,4) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(3.01);
var sdimg1_ch4=int_1.multiply(1.25);
//double middle late
var img2_ch4=int_2.multiply(3.01).add(int_2.multiply(3.01));
var sdimg2_ch4=(int_2.multiply(1.25).multiply(1.25).add(int_2.multiply(1.25).multiply(1.25))).sqrt();
//triple
var img3_ch4=int_3.multiply(3.01).add(int_3.multiply(3.01)).add(int_3.multiply(3.01));
var sdimg3_ch4=(int_3.multiply(1.25).multiply(1.25).add(int_3.multiply(1.25).multiply(1.25)).add(int_3.multiply(1.25).multiply(1.25))).sqrt();
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
print(imgtotal_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Myanmar Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
// Paint all the polygon edges with the same number and width, display.
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Myanmar edges',1);  
// end 5 myanmar
//6 Malaysia
var imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_malaysia_sabah_2022"),
    table_mys2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_MYS_2"),
    table_mys1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_MYS_1"),
    imageCollection2 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_malaysia_2022"),
    adm0 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_MYS_0");
var img_paddy=imageCollection.merge(imageCollection2).max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_mys1; 
var adm2=table_mys2;
print('adm1',adm1)
var roi=adm2;
var iso3='MYS';  
Map.centerObject(adm1,4) 
Map.addLayer(adm1,{},'adm3',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
//var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(17.83);
var sdimg1_ch4=int_1.multiply(11.85);
//double middle late
var img2_ch4=int_2.multiply(17.83).add(int_2.multiply(17.83));
var sdimg2_ch4=(int_2.multiply(11.85).multiply(11.85).add(int_2.multiply(11.85).multiply(11.85))).sqrt();
//triple
//var img3_ch4=int_3.multiply(33.98).add(int_3.multiply(33.98)).add(int_3.multiply(33.98));
var imgtotal_ch4=img1_ch4.add(img2_ch4)//.add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=img1_ch4.add(img2_ch4);
print(imgtotal_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Malaysia Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
// Paint all the polygon edges with the same number and width, display.
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Malaysia edges',1);     
// end 6 malaysia
//7 Philippines
var table_phl2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_PHL_2"),
    table_phl1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_PHL_1"),
    imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_philippines_2022"),
    adm0 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_PHL_0");
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_phl1; 
var adm2=table_phl2;
print('adm1',adm1)
var roi=adm2;
var iso3='PHL';
var sel_export_id='PHL.26_1'; //dummy export
Map.centerObject(adm1,4) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
//var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(25.8);
var sdimg1_ch4=int_1.multiply(19.27);
//double middle late
var img2_ch4=int_2.multiply(25.8).add(int_2.multiply(25.8));
var sdimg2_ch4=(int_2.multiply(19.27).multiply(19.27).add(int_2.multiply(19.27).multiply(19.27))).sqrt();
//triple
//var img3_ch4=int_3.multiply(33.98).add(int_3.multiply(33.98)).add(int_3.multiply(33.98));
var imgtotal_ch4=img1_ch4.add(img2_ch4)//.add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4)
print(imgtotal_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Philippines Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Philippines edge',1); 
// end 7 philipines
//8 Indonesia
var imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_jawa_2022_update"),
    imageCollection2 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_kalimantan_2022"),
    imageCollection3 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_ntb_ntt_2022"),
    imageCollection4 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_papua_2022"),
    imageCollection5 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_sulawesi_2022"),
    imageCollection6 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_indonesia_sumatra_2022"),
    table_ina1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_IDN_1"),
    table_ina3 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_IDN_3");
var gaul0 = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level0").sort('ADM0_CODE')
print('List of countries',(gaul0.sort('ADM0_NAME').aggregate_array('ADM0_NAME')))
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['Indonesia'
])).sort('ADM0_CODE'))
var img_paddy=imageCollection.merge(imageCollection2)
                             .merge(imageCollection3)
                             .merge(imageCollection4)
                             .merge(imageCollection5)
                             .merge(imageCollection6).max()
print('img_paddy',img_paddy)
var intensityVisParam = {
  bands: ['classification'],
  min: 1,
  max: 3,
  palette: ['#40E0D0','#DFFF00','red']
  //palette: ['1500ff','22ff00','FF0000']
};
Map.addLayer(img_paddy,intensityVisParam ,'paddy_inten')
var adm1=table_ina1; 
var adm2=table_ina3;
print('adm1',adm1)
var roi=adm2;
var iso3='IDN';//'INA';  
Map.centerObject(table_ina1,4) 
Map.addLayer(table_ina3,{},'adm3',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(33.98);
var sdimg1_ch4=int_1.multiply(10.21);
//double middle late
var img2_ch4=int_2.multiply(33.98).add(int_2.multiply(33.98));
var sdimg2_ch4=(int_2.multiply(10.21).multiply(10.21).add(int_2.multiply(10.21).multiply(10.21))).sqrt();
//triple
var img3_ch4=int_3.multiply(33.98).add(int_3.multiply(33.98)).add(int_3.multiply(33.98));
var sdimg3_ch4=(int_3.multiply(10.21).multiply(10.21).add(int_3.multiply(10.21).multiply(10.21)).add(int_3.multiply(10.21).multiply(10.21))).sqrt();
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
print(imgtotal_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
var methaneVisParam = {
  bands: ['classification'],
  min: 0,
  max: 80,
 // palette: ['white','blue','green', 'red']
  palette: ['yellow', 'red']
};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Indonesia Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Indonesia edges',1); 
////
/**
 * Define UI components.
 */
var comp = {};
// Title.
comp.title = {};
comp.title.label = ui.Label('Methane emission from rice paddy cultivation (2022)', null, 
  'https://www.umt.edu.my');
// Legend.
comp.legend = {};
comp.legend.title = ui.Label();
comp.legend.colorbar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: methaneVisParam.palette
  }
});
comp.legend.leftLabel = ui.Label('[min]');
comp.legend.centerLabel = ui.Label();
comp.legend.rightLabel = ui.Label('[max]');
comp.legend.labelPanel = ui.Panel({
  widgets: [
    comp.legend.leftLabel,
    comp.legend.centerLabel,
    comp.legend.rightLabel,
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
comp.legend.panel = ui.Panel([
  comp.legend.title,
  comp.legend.colorbar,
  comp.legend.labelPanel
], null, {width: '300px', position: 'bottom-left'});
/**
 * Compose the components.
 */
//Map.add(comp.title.label);
Map.add(comp.legend.panel);
/**
 * Style the components.
 */
var style = {};
style.title = {};
style.title.label = {
  fontWeight: 'bold',
  fontSize: '16px'
};
style.legend = {};
style.legend.title = {
  fontWeight: 'bold',
  fontSize: '14px',
  color: '383838'
};
style.legend.colorbar = {
  stretch: 'horizontal',
  margin: '0px 8px',
  maxHeight: '20px'
};
style.legend.leftLabel = {
  margin: '4px 8px',
  fontSize: '14px'
};
style.legend.centerLabel = {
  margin: '4px 8px',
  fontSize: '14px',
  textAlign: 'center',
  stretch: 'horizontal'
};
style.legend.rightLabel = {
  margin: '4px 8px',
  fontSize: '14px'
};
style.legend.panel = {
};
style.title.label;
comp.title.label.style().set(style.title.label);
comp.legend.title.style().set(style.legend.title);
comp.legend.colorbar.style().set(style.legend.colorbar);
comp.legend.leftLabel.style().set(style.legend.leftLabel);
comp.legend.centerLabel.style().set(style.legend.centerLabel);
comp.legend.rightLabel.style().set(style.legend.rightLabel);
comp.legend.title.setValue('Methane Emission (g/m2/year)');
comp.legend.leftLabel.setValue(methaneVisParam.min + 0);
comp.legend.centerLabel.setValue(methaneVisParam.max / 2  + 0);
comp.legend.rightLabel.setValue(methaneVisParam.max  + 0);
//intensity
// Create legend title
// Create legend title
var legendTitle = ui.Label({
 // value: 'Rice cropping intensity',
  value: 'Month',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
//legend 2
// set position of panel
var legend2 = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle2 = ui.Label({
  value: 'Rice cropping intensity',
 // value: 'Month',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend2.add(legendTitle2);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
 //var palette =['FF0000', '22ff00', '1500ff'];
 var palette2 =['40E0D0','DFFF00','FF0000'];
// name of the legend
//var names = ['Red','Green','Blue'];
 var names2 = ['Single','Double','Triple'];
// Add color and and names
for (var i = 0; i < 3; i++) {
  legend2.add(makeRow(palette2[i], names2[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend2);
Map.centerObject(geometry_se_asia);
Map.setOptions('SATELLITE')