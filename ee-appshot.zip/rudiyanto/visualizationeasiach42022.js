var geometry_e_asia = ui.import && ui.import("geometry_e_asia", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.MultiPoint();
//1 Japan
var table_jpn1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_JPN_1"),
    table_jpn2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_JPN_2"),
    imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_japan_2022");
var gaul0 = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level0").sort('ADM0_CODE')
print('List of countries',(gaul0.sort('ADM0_NAME').aggregate_array('ADM0_NAME')))
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['Japan'
])).sort('ADM0_CODE')) 
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
var intensityVisParam = {
  bands: ['classification'],
  min: 1,
  max: 3,
  palette: ['#40E0D0','#DFFF00','red']
  //palette: ['1500ff','22ff00','FF0000']
};
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_jpn1; 
var adm2=table_jpn2;
print('adm1',adm1)
var roi=adm2;
var iso3='JPN';
var sel_export_id='JPN.12_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(46.98);
//double middle late
var img2_ch4=int_2.multiply(46.98).add(int_2.multiply(46.98));
//triple
var img3_ch4=int_3.multiply(46.98).add(int_3.multiply(46.98)).add(int_3.multiply(46.98));
//singgle late
var sdimg1_ch4=int_1.multiply(30.24);
//double middle late
var sdimg2_ch4=(int_2.multiply(30.24).multiply(30.24).add(int_2.multiply(30.24).multiply(30.24))).sqrt();
//triple
var sdimg3_ch4=(int_3.multiply(30.24).multiply(30.24).add(int_3.multiply(30.24).multiply(30.24)).add(int_3.multiply(30.24).multiply(30.24))).sqrt();
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
print(imgtotal_ch4);
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
var methaneVisParam = {
  bands: ['classification'],
  min: 0,
  max: 80,
 // palette: ['white','blue','green', 'red']
  palette: ['yellow', 'red']
};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Japan Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Japan edge',1); 
//end 1 japan
//2-south korea 
var imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_korea_south_2022"),
    table_kor1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_KOR_1"),
    table_kor2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_KOR_2");
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['Republic of Korea'
])).sort('ADM0_CODE')) 
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_kor1; 
var adm2=table_kor2;
print('adm1',adm1)
var roi=adm2;
var iso3='KOR';
var sel_export_id='KOR.1_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(34.94);
//double middle late
var img2_ch4=int_2.multiply(34.94).add(int_2.multiply(34.94));
//triple
var img3_ch4=int_3.multiply(34.94).add(int_3.multiply(34.94)).add(int_3.multiply(34.94));
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
print(imgtotal_ch4);
//singgle late
var sdimg1_ch4=int_1.multiply(9.3);
//double middle late
var sdimg2_ch4=(int_2.multiply(9.3).multiply(9.3).add(int_2.multiply(9.3).multiply(9.3))).sqrt();
//triple
var sdimg3_ch4=(int_3.multiply(9.3).multiply(9.3).add(int_3.multiply(9.3).multiply(9.3)).add(int_3.multiply(9.3).multiply(9.3))).sqrt();
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'South Korea Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'South Korea edge',1); 
// end 2 south korea
//3 north korea
var table_prk1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_PRK_1"),
    table_prk2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_PRK_2"),
    imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_korea_north_2022");
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_prk1; 
var adm2=table_prk2;
print('adm1',adm1)
var roi=adm2;
var iso3='PRK';
var sel_export_id='PRK.1_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(34.94);
//double middle late
var img2_ch4=int_2.multiply(34.94).add(int_2.multiply(34.94));
//triple
var img3_ch4=int_3.multiply(34.94).add(int_3.multiply(34.94)).add(int_3.multiply(34.94));
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
print(imgtotal_ch4);
//singgle late
var sdimg1_ch4=int_1.multiply(9.3);
//double middle late
var sdimg2_ch4=(int_2.multiply(9.3).multiply(9.3).add(int_2.multiply(9.3).multiply(9.3))).sqrt();
//triple
var sdimg3_ch4=(int_3.multiply(9.3).multiply(9.3).add(int_3.multiply(9.3).multiply(9.3)).add(int_3.multiply(9.3).multiply(9.3))).sqrt();
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['Dem People\'s Rep of Korea'
])).sort('ADM0_CODE'))
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'North Korea edges',1); 
// end 3 North korea
//4 China
var table_china0 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_CHN_0"),
    table_china3 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_CHN_3_sub_region"),
    table_china1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_CHN_1_subregion");
//1-huang hui
var imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_china_heilongjiang_2022"),
    imageCollection3 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_china_ningxia_2022"),
    imageCollection5 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_china_sichuan_2022"),
    imageCollection6 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_china_xinjiang_2022"),
    imageCollection7 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_china_hunan_2022_update"),
    imageCollection8 = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_china_shandong_update");///z_out_rice_s12_1deg_china_shandong_2022");
var img_paddy=imageCollection.merge(imageCollection7).merge(imageCollection3)
            .merge(imageCollection8).merge(imageCollection5).merge(imageCollection6).max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten whole china',0)
var adm0=table_china0;
var adm1=table_china1;
var adm3=table_china3;
print('adm2',adm3.limit(5))
Map.addLayer(adm1,{},'adm1',0)
//1) South
print(adm1.aggregate_array('sub_region'))
var select_adm1=adm1.filter(ee.Filter.inList('sub_region', ['Huang Huai Hai'])).sort('sub_region')
var select_adm3=adm3.filter(ee.Filter.inList('sub_region', ['Huang Huai Hai'])).sort('sub_region')
var roi=select_adm1;
Map.centerObject(roi,5)
var iso3='CHN';
Map.addLayer(roi,{},'select_adm11',0)
var select_img_paddy=img_paddy.clip(select_adm1)
Map.addLayer(select_img_paddy,intensityVisParam,'select_img_paddy_inten')
var int_1=select_img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=select_img_paddy.select('classification').eq(2);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(4.32); //g/m2/season
var sdimg1_ch4=int_1.multiply(1.541);
//double middle late
var img2_ch4=int_2.multiply(0).add(int_2.multiply(0));
var imgtotal_ch4=img1_ch4.add(img2_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4;
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
print(imgtotal_ch4);
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'China Huang Huai Hui Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lower, methaneVisParam, 'lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// end a huang huai
//b) northeast
print(adm1.aggregate_array('sub_region'))
var select_adm1=adm1.filter(ee.Filter.inList('sub_region', ['Northeast'])).sort('sub_region')
var select_adm3=adm3.filter(ee.Filter.inList('sub_region', ['Northeast'])).sort('sub_region')
var roi=select_adm1;
Map.centerObject(roi,5)
var iso3='CHN';
Map.addLayer(roi,{},'select_adm11',0)
var select_img_paddy=img_paddy.clip(select_adm1)
Map.addLayer(select_img_paddy,intensityVisParam,'select_img_paddy_inten')
var int_1=select_img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=select_img_paddy.select('classification').eq(2);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(7.44);
var sdimg1_ch4=int_1.multiply(13.362);
//double middle late
var img2_ch4=int_2.multiply(0).add(int_2.multiply(0));
var imgtotal_ch4=img1_ch4.add(img2_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4;
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
// Display the resulting image
//Map.addLayer(imageWithZeros, {}, 'Image with Negative Values as Zero');
print(imgtotal_ch4);
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'China NorthEast Methane g/m2/year',1);
///Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
//end b northeast    
//c yangtze
//1) South
print(adm1.aggregate_array('sub_region'))
var select_adm1=adm1.filter(ee.Filter.inList('sub_region', ['Yangtze River'])).sort('sub_region')
var select_adm3=adm3.filter(ee.Filter.inList('sub_region', ['Yangtze River'])).sort('sub_region')
var roi=select_adm1;
Map.centerObject(roi,5)
var iso3='CHN';
Map.addLayer(roi,{},'select_adm11',0)
var select_img_paddy=img_paddy.clip(select_adm1)
Map.addLayer(select_img_paddy,intensityVisParam,'select_img_paddy_inten')
var int_1=select_img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=select_img_paddy.select('classification').eq(2);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(18.88);
var sdimg1_ch4=int_1.multiply(17.332);
//double middle late
var img2_ch4=int_2.multiply(9.92).add(int_2.multiply(22.48));
var sdimg2_ch4=(int_2.multiply(14.068).multiply(14.068).add(int_2.multiply(22.403).multiply(22.403))).sqrt();
var imgtotal_ch4=img1_ch4.add(img2_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4);
print(imgtotal_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'China Yangtze_River Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
 // c end yangtze   
//d) South
print(adm1.aggregate_array('sub_region'))
var select_adm1=adm1.filter(ee.Filter.inList('sub_region', ['South'])).sort('sub_region')
var select_adm3=adm3.filter(ee.Filter.inList('sub_region', ['South'])).sort('sub_region')
var roi=select_adm1;
Map.centerObject(roi,5)
var iso3='CHN';
Map.addLayer(roi,{},'select_adm11',0)
var select_img_paddy=img_paddy.clip(select_adm1)
Map.addLayer(select_img_paddy,intensityVisParam,'select_img_paddy_inten')
var int_1=select_img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=select_img_paddy.select('classification').eq(2);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(5.05); //g/m2/season
var sdimg1_ch4=int_1.multiply(8.341); 
//double middle late
var img2_ch4=int_2.multiply(5.05).add(int_2.multiply(18.23));
var sdimg2_ch4=(int_2.multiply(8.341).multiply(8.341).add(int_2.multiply(15.665).multiply(15.665))).sqrt();
var imgtotal_ch4=img1_ch4.add(img2_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4);
print(imgtotal_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'china south Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// end d south
//e) Southwest
print(adm1.aggregate_array('sub_region'))
var select_adm1=adm1.filter(ee.Filter.inList('sub_region', ['Southwest'])).sort('sub_region')
var select_adm3=adm3.filter(ee.Filter.inList('sub_region', ['Southwest'])).sort('sub_region')
var roi=select_adm1;
Map.centerObject(roi,5)
var iso3='CHN';
Map.addLayer(roi,{},'select_adm11',0)
var select_img_paddy=img_paddy.clip(select_adm1)
Map.addLayer(select_img_paddy,intensityVisParam,'select_img_paddy_inten')
var int_1=select_img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=select_img_paddy.select('classification').eq(2);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(24.4);//g/m2/season
var sdimg1_ch4=int_1.multiply(22.036);
//double middle late
var img2_ch4=int_2.multiply(0).add(int_2.multiply(0));
var imgtotal_ch4=img1_ch4.add(img2_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4;//.add(img2_ch4);
print(imgtotal_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'China Southwest Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// end e Southwest
//1) West_China
print(adm1.aggregate_array('sub_region'))
var select_adm1=adm1.filter(ee.Filter.inList('sub_region', ['West_China'])).sort('sub_region')
var select_adm3=adm3.filter(ee.Filter.inList('sub_region', ['West'])).sort('sub_region')
print('select_adm1',select_adm1)
print('select_adm3',select_adm3)
var roi=select_adm1;
Map.centerObject(roi,5)
var iso3='CHN';
Map.addLayer(roi,{},'select_adm11',0)
var select_img_paddy=img_paddy.clip(select_adm1)
Map.addLayer(select_img_paddy,intensityVisParam,'select_img_paddy_inten')
var int_1=select_img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=select_img_paddy.select('classification').eq(2);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//singgle late
var img1_ch4=int_1.multiply(24.4);
var sdimg1_ch4=int_1.multiply(22.036);
//double middle late
var img2_ch4=int_2.multiply(0).add(int_2.multiply(0));
var imgtotal_ch4=img1_ch4.add(img2_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
var sdimgtotal_ch4=sdimg1_ch4
print(imgtotal_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
//  min: 0,
//  max: 80,
//  palette: ['white','blue','green', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'China Northwest Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
// end west china
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['China'
])).sort('ADM0_CODE'))
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'China edges',1); 
// end 4 china 
//taiwan
var imageCollection = ee.ImageCollection("users/rudiyanto/z_out_rice_s12_1deg_taiwan_2022"),
    table_twn1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_TWN_1"),
    table_twn2 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_TWN_2");
var img_paddy=imageCollection.max()
print('img_paddy',img_paddy)
Map.addLayer(img_paddy,intensityVisParam,'paddy_inten')
var adm1=table_twn1; 
var adm2=table_twn2;
print('adm1',adm1)
var roi=adm2;
var iso3='TWN';
var sel_export_id='TWN.1_1'; //dummy export
Map.centerObject(adm1) 
Map.addLayer(adm2,{},'adm2',0)
var int_1=img_paddy.select('classification').eq(1);//.unmask().clip(roi);
var int_2=img_paddy.select('classification').eq(2);//.unmask().clip(roi);
var int_3=img_paddy.select('classification').eq(3);//.unmask().clip(roi);
//Map.addLayer(int_1,{min:0,max:3,palette:['white','red','green','orange']},'int_1')
//Map.addLayer(int_2,{min:0,max:3,palette:['white','blue','green','red']},'int_2')
//Map.addLayer(int_3,{min:0,max:3,palette:['white','yellow','green','red']},'int_3')
//singgle late
var img1_ch4=int_1.multiply(11.2);
//double middle late
var img2_ch4=int_2.multiply(11.2).add(int_2.multiply(11.2));
//triple
var img3_ch4=int_3.multiply(11.2).add(int_3.multiply(11.2)).add(int_3.multiply(11.2));
var imgtotal_ch4=img1_ch4.add(img2_ch4).add(img3_ch4);//.updateMask(img_paddy);//.add(img3_ch4);
print(imgtotal_ch4);
//singgle late
var sdimg1_ch4=int_1.multiply(9.14);
//double middle late
var sdimg2_ch4=(int_2.multiply(9.14).multiply(9.14).add(int_2.multiply(9.14).multiply(9.14))).sqrt();
//triple
var sdimg3_ch4=(int_3.multiply(9.14).multiply(9.14).add(int_3.multiply(9.14).multiply(9.14)).add(int_3.multiply(9.14).multiply(9.14))).sqrt();
var sdimgtotal_ch4=sdimg1_ch4.add(sdimg2_ch4).add(sdimg3_ch4);
var upper=imgtotal_ch4.add(sdimgtotal_ch4);
var lower=imgtotal_ch4.subtract(sdimgtotal_ch4);
// Replace negative values with zero using ee.Image.expression
var lowerimageWithZeros = lower.expression('b(0) < 0 ? 0 : b(0)', {
  'b': lower
});
//var methaneVisParam = {
//  bands: ['classification'],
 // min: 0,
//  max: 80,
 // palette: ['white','blue','green', 'red']
//  palette: ['yellow', 'red']
//};
Map.addLayer(imgtotal_ch4, methaneVisParam, 'Taiwan Methane g/m2/year',1);
//Map.addLayer(sdimgtotal_ch4, methaneVisParam, 'SD Methane g/m2/year',1);
//Map.addLayer(lowerimageWithZeros, methaneVisParam, 'Lower Methane g/m2/year',1);
//Map.addLayer(upper, methaneVisParam, 'Upper Methane g/m2/year',1);
var adm0 = (gaul0.filter(ee.Filter.inList('ADM0_NAME', ['Taiwan'
])).sort('ADM0_CODE'))
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: adm0,
  color: 1,
  width: 1
});
Map.addLayer(outline, {palette: '#FF00FF'}, 'Taiwan edges',1); 
////
/**
 * Define UI components.
 */
var comp = {};
// Title.
comp.title = {};
comp.title.label = ui.Label('Methane emission from rice paddy cultivation (2022)', null, 
  'https://www.umt.edu.my');
// Legend.
comp.legend = {};
comp.legend.title = ui.Label();
comp.legend.colorbar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: methaneVisParam.palette
  }
});
comp.legend.leftLabel = ui.Label('[min]');
comp.legend.centerLabel = ui.Label();
comp.legend.rightLabel = ui.Label('[max]');
comp.legend.labelPanel = ui.Panel({
  widgets: [
    comp.legend.leftLabel,
    comp.legend.centerLabel,
    comp.legend.rightLabel,
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
comp.legend.panel = ui.Panel([
  comp.legend.title,
  comp.legend.colorbar,
  comp.legend.labelPanel
], null, {width: '300px', position: 'bottom-left'});
/**
 * Compose the components.
 */
//Map.add(comp.title.label);
Map.add(comp.legend.panel);
/**
 * Style the components.
 */
var style = {};
style.title = {};
style.title.label = {
  fontWeight: 'bold',
  fontSize: '16px'
};
style.legend = {};
style.legend.title = {
  fontWeight: 'bold',
  fontSize: '14px',
  color: '383838'
};
style.legend.colorbar = {
  stretch: 'horizontal',
  margin: '0px 8px',
  maxHeight: '20px'
};
style.legend.leftLabel = {
  margin: '4px 8px',
  fontSize: '14px'
};
style.legend.centerLabel = {
  margin: '4px 8px',
  fontSize: '14px',
  textAlign: 'center',
  stretch: 'horizontal'
};
style.legend.rightLabel = {
  margin: '4px 8px',
  fontSize: '14px'
};
style.legend.panel = {
};
style.title.label;
comp.title.label.style().set(style.title.label);
comp.legend.title.style().set(style.legend.title);
comp.legend.colorbar.style().set(style.legend.colorbar);
comp.legend.leftLabel.style().set(style.legend.leftLabel);
comp.legend.centerLabel.style().set(style.legend.centerLabel);
comp.legend.rightLabel.style().set(style.legend.rightLabel);
comp.legend.title.setValue('Methane Emission (g/m2/year)');
comp.legend.leftLabel.setValue(methaneVisParam.min + 0);
comp.legend.centerLabel.setValue(methaneVisParam.max / 2  + 0);
comp.legend.rightLabel.setValue(methaneVisParam.max  + 0);
//intensity
// Create legend title
// Create legend title
var legendTitle = ui.Label({
 // value: 'Rice cropping intensity',
  value: 'Month',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
//legend 2
// set position of panel
var legend2 = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle2 = ui.Label({
  value: 'Rice cropping intensity',
 // value: 'Month',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend2.add(legendTitle2);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
 //var palette =['FF0000', '22ff00', '1500ff'];
 var palette2 =['40E0D0','DFFF00','FF0000'];
// name of the legend
//var names = ['Red','Green','Blue'];
 var names2 = ['Single','Double','Triple'];
// Add color and and names
for (var i = 0; i < 3; i++) {
  legend2.add(makeRow(palette2[i], names2[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend2);
var table_china0 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_CHN_0"),
    table_china3 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_CHN_3_sub_region"),
    table_china1 = ee.FeatureCollection("users/rudiyanto/gadm_shp/gadm41_CHN_1_subregion");
var adm0=table_china0;
var adm1=table_china1;
var adm3=table_china3;
print('adm2',adm3.limit(5))
Map.addLayer(adm1,{},'adm1',0)
//1) South
print(adm1.aggregate_array('sub_region'))
var select_adm1=adm1.filter(ee.Filter.inList('sub_region', ['Huang Huai Hai'])).sort('sub_region')
var select_adm3=adm3.filter(ee.Filter.inList('sub_region', ['Huang Huai Hai'])).sort('sub_region')
var roi=select_adm1;
Map.centerObject(roi,4)
Map.setOptions('SATELLITE')