/**
 * Inspired by EE Apps: Tasting Menu
 *  
 * A simple "sampler platter" for the Earth Engine Apps User Interface library.
 * This example is composed of several simple widgets tied together, to give
 * readers a sense of what components are available and how to wire them 
 * together to make a simple application.
 * 
 * This app has several sections:
 *   - declaring the widgets and nesting them in panels
 *   - styling everything (individual widgets and panels)
 *   - composing the styled subcomponents into the map
 *   - defining behaviors (actions, callbacks, etc.)
 * 
 * @author Michael DeWitt (mdewitt@google.com)
 * 
 * 2021-02-18
 * @author Eligio R. MAURE (eligiomaure@gmail.com)
 */
/******************
 * Required files *
 ******************/
var cepMap = require('users/ermaure/gew:cepMap');
var trendMap = require('users/ermaure/gew:trendMap');
var alphaMap = require('users/ermaure/gew:alphaMap');
var monthAmaxSeries = require('users/ermaure/gew:annuMax');
// A UI application to interactively explore CEP.
var app = {
    model: {},
    views: {},
    controller: { main: {}, update: {} },
    getter: {}
};
/* Sets up the model object */
function initModel(model, mobileStyle) {
    var today = new Date();
    var lastYear = today.getFullYear() - 1;
    model.INIT_MAP_CENTER = { lon: 131, lat: 37, zoom: 4 };
    model.CEP_TRIGGER = { lon: 134.6829, lat: 36.3483 };
    model.CEP_ITEMS = ['CEP', 'Trend', 'Composite'];
    model.SECTION_STYLE = { margin: '20px 0 0 0' };
    model.HEADER_STYLE = {
        fontWeight: 'bold',
        fontSize: mobileStyle ? '16px' : '14px',
        color: 'blue'
    };
    model.HIDDEN = { fontSize: mobileStyle ? '14px' : '12px', shown: true };
    model.ENTER_STYLE = {
        margin: '0 8px 8px 0',
        fontSize: mobileStyle ? '16px' : '14px',
        width: mobileStyle ? '65px' : '55px',
        height: mobileStyle ? '24px' : '35px'
    };
    model.TEXT_STYLE = { fontSize: mobileStyle ? '14px' : '12px' };
    model.YEAR_STYLE = {
        margin: '0 8px 8px 0',
        fontSize: mobileStyle ? '14px' : '12px',
        width: mobileStyle ? '65px' : '55px'
    };
    model.SLIDER_STYLE = {
        // margin: '0 8px 8px 0',
        fontSize: mobileStyle ? '14px' : '12px',
        width: '190px',
        // stretch: 'vertical'
    };
    model.DATE_STYLE = {
        margin: '0 0 8px 0',
        fontSize: mobileStyle ? '14px' : '12px',
        width: mobileStyle ? '120px' : '100px',
        color: 'gray'
    };
    model.MOBILE = mobileStyle ? true : false;
    model.EPS = 1e-6; // single precision (float32) has 6 or fewer significant decimal digits 
    // visualization settings
    // For the 3-year mean 
    model.ALPHA = 5;
    model.ALPHA_VIS = {
        bands: ['alpha'],
        min: -1,
        max: 1,
        palette: ['2000E0', 'BE0600']
    };
    // For the Sen slope
    model.TREND_VIS = {
        bands: ['trend'],
        min: -1,
        max: 1,
        palette: ['2000E0', 'BFAB04', 'BE0600']
    };
    model.CEP_VIS = {
        min: 1, //'FFFFFF', 
        max: 6,
        palette: ['BA26F7', '0C00C4', '96D8E8', 'FFDF02', 'FFAF82', 'BE0600']
        // palette: ['2000E0', '01C4FF', '00FF02', 'FFDF02', 'FFAF82', 'BE0600']
    };
    model.legend = function () {
        return ui.Panel({
            style: mobileStyle ? { position: 'bottom-left', padding: '16px' } : {
                fontWeight: 'bold',
                fontSize: '12px',
                margin: '0 0 10px 12px',
                padding: '0'
            }
        });
    };
    model.yearInterval = function (image) {
        image = ee.Image(image);
        var start = ee.Date(image.get('system:time_start')).format('Y');
        var end = ee.Date(image.get('system:time_end')).format('Y');
        return ee.List([start, end]);
    };
    model.date2YMD = function (date) {
        var d = date.getDate();
        var m = date.getMonth() + 1; //Month from 0 to 11
        var y = date.getFullYear();
        return '' + y + '-' + (m <= 9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d);
    };
    model.clientNum = function (value, year) {
        if (year == 'start') { model.START_YEAR = value + 0 }
        if (year == 'end') { model.START_END = value + 0 }
    };
    model.START_YEAR = 2003;
    model.END_YEAR = lastYear;
    model.START_DAY = model.date2YMD(new Date(model.END_YEAR - 2, 0, 1));
    model.END_DAY = model.date2YMD(new Date(model.END_YEAR, 11, 31));
    // All of the application's state is kept here.
    model.state = {
        annuMaxSeries: null,
        maxSeries: null,
        maxSeriesRight: null,
        dataset: null,
        splitMode: false,
        alphaMap: null,
        trendMap: null,
        trendMapRight: null,
        cepMap: null,
        cepMapRight: null,
        selectMap: null,
        currentDataset: 'default',
        chartTs: null,
        mask: null,
        chartTsRight: null
    };
    // model.ITEMS = model.dateItems(1970, model.END_YEAR);
    // margin-top, margin-right, margin-bottom, margin-left
    // The namespaces for dataset-specific values.
    model.addBand = function (image) {
        var bdate = ee.Date('19971231');
        var date = ee.Date(image.get('system:time_start'));
        var time = ee.Image(date.difference(bdate, "year"))
            .double()
            .rename("time");
        // .reproject(model.proj);
        return image.addBands(time);
    };
    model.defaultDataset = function () {
        var dayColl = ee.ImageCollection('users/nwatchs/OCEANCOLOUR/MODIS-Aqua/L3M')
            .select(['chlor_a']);
        model.proj = dayColl
            .first()
            .projection();
        // .nominalScale();
        model.START_YEAR = 2003;
        model.END_YEAR = lastYear;
        var mseries = monthAmaxSeries.getMonthSeries(dayColl, 2003, lastYear, model.proj);
        model.state.maxSeries = monthAmaxSeries.getMaxSeries(mseries, 2003, lastYear, model.proj);
        return mseries;
    };
    model.imgColl = function (caller, assetPath) {
        switch (caller) {
            case 'yoc':
                var yseries = ee.ImageCollection('users/nwatchs/OCEANCOLOUR/YOC/L4M')
                    .select(['chlor_a']);
                model.proj = yseries
                    .first()
                    .projection();
                // .nominalScale();
                model.START_YEAR = 1998;
                model.END_YEAR = lastYear;
                yseries = yseries.map(model.addBand);
                model.state.annuMaxSeries = monthAmaxSeries.getMaxSeries(yseries, 1998, lastYear, model.proj);
                return yseries;
            case 'UserAsset':
                try {
                    var useries = ee.ImageCollection(assetPath).select(['chlor_a']);
                    model.proj = useries
                        .first()
                        .projection();
                    // .nominalScale();
                    useries = useries.map(model.addBand);
                    var years = useries
                        .toList(useries.size())
                        .map(model.yearInterval)
                        .flatten().distinct().sort();
                    years.get(0).evaluate(function (value) { model.clientNum(value, 'start') });
                    years.get(-1).evaluate(function (value) { model.clientNum(value, 'end') });
                    // var range = useries.reduceColumns(
                    // ee.Reducer.minMax(), ["system:time_start"]);
                    // print('Date range: ', range.get('min'), range.get('max'))
                    // ee.Date(range.get('min')).format('Y').evaluate(
                    //     function (value) { model.clientNum(value, 'start') });
                    // ee.Date(range.get('max')).format('Y').evaluate(
                    //     function (value) { model.clientNum(value, 'end') });
                    model.state.annuMaxSeries = monthAmaxSeries.getMaxSeries(
                        mseries, model.START_YEAR, model.END_YEAR, model.proj);
                    return useries;
                }
                catch (error) { app.views.userAssetLog.setValue('assetReadError') }
                return;
            // .filterDate(model.START_DATE, model.END_DATE);
            default:
                return model.defaultDataset();
        }
    };
    model.state.dataset = model.imgColl();
}
// Map Layers
/* Sets up the views object */
function initViews(views) {
    views.rootPanel = ui.Panel(); // Highest-level container.
    views.mapPanel = ui.Panel(); // Maps!
    views.controlPanel = ui.Panel(); // Control panel
    views.dataPanel = ui.Panel(); // Data panel
    views.inspector = ui.Panel(); // Inspector panel
    views.inspectorRight = ui.Panel(); // Inspector panel
    views.trendPanel = ui.Panel(); // Trend panel
    views.alphaPanel = ui.Panel(); // Threshold panel
    views.wcep = ui.Panel([]); // WCEP panel
    /*************
     * Map panel *
     *************/
    views.standaloneMap = ui.Map();
    views.leftMap = ui.Map();
    views.rightMap = ui.Map();
    views.splitMap = ui.SplitPanel({
        firstPanel: views.leftMap,
        secondPanel: views.rightMap,
        orientation: 'horizontal',
        wipe: true
    });
    views.mapPanel.add(views.standaloneMap);
    views.layout = function (value) {
        switch (value) {
            case 'v':
                return ui.Panel.Layout.flow('vertical');
            default:
                return ui.Panel.Layout.flow('horizontal');
        }
    };
    var alphaItems = [];
    for (var i = 1; i <= 100; i++) { alphaItems.push(i.toString()) }
    // The UI components used to control views
    views.userAsset = ui.Textbox('Enter asset path here'); // EE Asset
    views.userAssetLog = ui.Textbox(''); // Log on success/failure loading user asset
    var yocUrl = ui.Label('Use YOC Product (Regional)');
    var articleDoi = ui.Label('https://doi.org/10.1038/s41467-021-26391-9');
    articleDoi.setUrl('https://doi.org/10.1038/s41467-021-26391-9');
    yocUrl.style().set({ backgroundColor: '#ececec' });
    yocUrl.setUrl("https://ocean.nowpap3.go.jp/?page_id=2297#33_The_Blended_CHL_Dataset");
    views.yocAsset = ui.Checkbox(''); // YOC Asset
    views.yocAsset.style().set({ backgroundColor: '#ececec' });
    views.yocAssetPanel = ui.Panel({
        widgets: [views.yocAsset, yocUrl],
        style: { backgroundColor: '#ececec' }, layout: views.layout()
    });
    views.yocAssetPanel.style().set({ width: '210px' });
    views.defaultAsset = ui.Label('default: MODIS/Aqua Level-3 (Global)');
    views.defaultAsset.setUrl('https://oceancolor.gsfc.nasa.gov/data/aqua/');
    var endY = app.model.END_YEAR;
    views.startYear = ui.Slider({ min: 2003, max: endY, value: 2003, step: 1, style: app.model.SLIDER_STYLE });
    views.endYear = ui.Slider({ min: 2003, max: endY, value: endY, step: 1, style: app.model.SLIDER_STYLE });
    views.submit = ui.Button({ label: 'enter', style: app.model.ENTER_STYLE });
    views.toggleStartYear = ui.Slider({ min: 2003, max: endY, value: 2003, step: 1, style: app.model.SLIDER_STYLE });
    views.toggleEndYear = ui.Slider({ min: 2003, max: endY, value: endY, step: 1, style: app.model.SLIDER_STYLE });
    views.toggleViews = ui.Button('Toggle map views, comparative assessment!');
    views.submitToggle = ui.Button({ label: 'enter', style: app.model.ENTER_STYLE });
    views.togglePanel = ui.Panel();
    views.trendLegend = app.model.legend();
    views.alphaStartDay = ui.Textbox({ placeholder: app.model.START_DAY, style: app.model.DATE_STYLE });
    views.alphaEndDay = ui.Textbox({ placeholder: app.model.END_DAY, style: app.model.DATE_STYLE });
    views.alpha = ui.Select({ items: alphaItems, placeholder: 'CHL Threshold', style: app.model.DATE_STYLE });
    views.alphaSubmit = ui.Button({ label: 'enter', style: app.model.ENTER_STYLE });
    views.alphaLegend = app.model.legend();
    views.leftSelect = ui.Select({ items: app.model.CEP_ITEMS, placeholder: "Select Display Image" });
    views.leftLabel = ui.Label({ value: '(YYYY-YYYY)', style: app.model.TEXT_STYLE });
    views.rightSelect = ui.Select({ items: app.model.CEP_ITEMS, placeholder: "Select Display Image" });
    views.rightLabel = ui.Label({ value: '(YYYY-YYYY)', style: app.model.TEXT_STYLE });
    views.leftMap.add(ui.Panel({ widgets: [views.leftLabel, views.leftSelect], style: { position: 'top-left' } }));
    views.rightMap.add(ui.Panel({ widgets: [views.rightLabel, views.rightSelect], style: { position: 'top-right' } }));
    // Configure the output panel.
    // PANELS TO HOLD LON/LAT VALUES. 
    views.lon = ui.Label();
    views.lat = ui.Label();
    views.clickStatus = ui.Label('Point Status :: ', app.model.TEXT_STYLE);
    views.clickStatusRight = ui.Label('Point Status :: ', app.model.TEXT_STYLE);
    views.tsLengend = ui.Label('Timeseries: ', app.model.SECTION_STYLE);
    views.tsLengendRight = ui.Label('Timeseries: ', app.model.SECTION_STYLE);
    views.tsChart = ui.Chart.array.values([[]], 'x');  // Empty for now.
    views.tsChartRight = ui.Chart.array.values([[]], 'x');  // Empty for now
    /***********
     * Styling *
     ***********/
    views.userAsset.style().set({ width: '65%', fontSize: app.model.MOBILE ? '14px' : '12px' });
    views.userAssetLog.style().set({ shown: false });
    views.defaultAsset.style().set({ fontWeight: 'bold', fontSize: app.model.MOBILE ? '12px' : '10px' });
    views.alphaLegend.style().set({ shown: false });
    views.trendLegend.style().set({ shown: false });
    views.togglePanel.style().set({ shown: false });
    views.yocAssetPanel.style().set(app.model.TEXT_STYLE);
    views.dataPanel.style().set(app.model.SECTION_STYLE);
    views.trendPanel.style().set(app.model.SECTION_STYLE);
    views.alphaPanel.style().set(app.model.SECTION_STYLE);
    views.toggleViews.style().set({ shown: !app.model.MOBILE });
    views.leftSelect.style().set(app.model.TEXT_STYLE);
    views.rightSelect.style().set(app.model.TEXT_STYLE);
    views.alphaSubmit.style().set({ margin: '0 8px 8px 8px' });
    views.toggleViews.style().set({ width: '250px' });
    views.tsLengend.style().set({ shown: false, fontWeight: 'bold' });
    views.tsLengendRight.style().set({ shown: false, fontWeight: 'bold' });
    views.clickStatusRight.style().set({ shown: false });
    views.tsChartRight.style().set({ shown: false });
    views.rootPanel.style().set({
        height: '100%',
        width: '100%',
        backgroundColor: 'red'
    });
    views.mapPanel.style().set({
        height: '100%',
        width: '57%',
        padding: '8px'
    });
    views.inspector.style().set({
        height: '100%',
        width: '20%',
        backgroundColor: 'white',
        padding: '8px'
    });
    views.controlPanel.style().set({
        height: '100%',
        width: app.model.MOBILE ? '40%' : '23%',
        padding: '8px'
    });
    // The application's intro panel
    views.intro = ui.Panel([
        ui.Label('Global Eutrophication Watch',
            { fontWeight: 'bold', fontSize: '20px', margin: '5px 5px' })]);
    // Dataset Panel 
    views.dataPanel.add(ui.Label('Dataset Specification', app.model.HEADER_STYLE))
        .add(ui.Label('Specify the path to your monthly CHL asset below. ' +
            'The dataset should contain a variable named "chlor_a".', app.model.TEXT_STYLE))
        .add(ui.Panel({ widgets: [app.views.userAsset, app.views.userAssetLog], layout: views.layout() }))
        .add(app.views.yocAssetPanel)
        .add(app.views.defaultAsset);
    // Control panel
    var sytWidgets = [ui.Label('Start year: ', app.model.TEXT_STYLE), views.toggleStartYear];
    var eytWidgets = [ui.Label('End year: ', app.model.TEXT_STYLE), views.toggleEndYear];
    views.togglePanel
        .add(ui.Label(
            'Different start/end year interval can be specified to compare' +
            ' trends in different periods.', app.model.TEXT_STYLE))
        .add(ui.Panel({ widgets: sytWidgets, layout: views.layout(), style: { stretch: 'vertical' } }))
        .add(ui.Panel({ widgets: eytWidgets, layout: views.layout(), style: { stretch: 'vertical' } }));
    // Trend Panel
    var syWidgets = [ui.Label('Start year: ', app.model.TEXT_STYLE), views.startYear];
    var eyWidgets = [ui.Label('End year: ', app.model.TEXT_STYLE), views.endYear];
    views.trendPanel.add(ui.Label('Trend Detection Interval', app.model.HEADER_STYLE))
        .add(ui.Label('Select the start/end year interval for' +
            ' trend detection.', app.model.TEXT_STYLE))
        .add(ui.Panel({ widgets: syWidgets, layout: views.layout(), style: { stretch: 'vertical' } }))
        .add(ui.Panel({ widgets: eyWidgets, layout: views.layout(), style: { stretch: 'vertical' } }))
        .add(views.toggleViews)
        .add(views.togglePanel);
    views.trendTitle = ui.Label('CHL Trend', app.model.HEADER_STYLE);
    // This is used as the threshold to discriminated between high vs. low ' +
    // 'values based on the selected cutoff level. Default interval, the last 3-year ' +
    // 'in the series. Push submit after entering the dates.
    // Alpha Panel
    views.alphaPanel.add(ui.Label('CHL Composite Interval', app.model.HEADER_STYLE))
        .add(ui.Label(
            'The start/end date for computing the temporal composite of CHL.', app.model.TEXT_STYLE))
        .add(ui.Label('Start date', app.model.TEXT_STYLE))
        .add(views.alphaStartDay)
        .add(ui.Label('End date', app.model.TEXT_STYLE))
        .add(ui.Panel({ widgets: [views.alphaEndDay, views.alphaSubmit], layout: views.layout() }))
        .add(ui.Label('Select cutoff level', app.model.TEXT_STYLE))
        .add(ui.Panel({ widgets: [views.alpha, ui.Label('[mg/m^3]', app.model.TEXT_STYLE)], layout: views.layout() }));
    views.alphaTitle = ui.Label('CHL Level', app.model.HEADER_STYLE);
    // CEP Colorbar Legend
    views.wcepLegend = app.model.legend();
    views.wcepColorbar = app.model.legend();
    views.wcepTitle = ui.Label('Eutrophication Watch', app.model.HEADER_STYLE);
    views.wcepColorbar.style().set(app.model.SECTION_STYLE);
    // Creates and styles 1 row of the legend.
    var makeLegendRow = function (name, color, cb) {
        // Create the label that is actually the colored box.
        var margin = '0 0 4px 0';
        var marginDesc = '0 0 4px 6px';
        if (cb == 'cep') { margin = '0 1px 0 1px' }
        if (cb == 'cep') { marginDesc = '4px 1px 0 10px' }
        var style = {
            backgroundColor: '#' + color,
            // Use padding to give the box height and width.
            padding: app.MOBILE ? '10px' : '8px',
            margin: margin,
            border: 'solid 0.5px',
        };
        if (cb == 'cep') {
            style = {
                backgroundColor: '#' + color,
                stretch: 'horizontal',
                margin: margin,
                width: '35px',
                height: '20px',
                border: 'solid 0.5px',
            };
        }
        var colorBox = ui.Label({ style: style });
        // Create the label filled with the description text.
        var description = ui.Label({
            value: name, style: { margin: marginDesc, fontSize: app.EXT_STYLE },
        });
        return ui.Panel({
            widgets: [colorBox, description],
            layout: cb ? views.layout('v') : views.layout()
        });
    };
    // CEP Color-codes
    views.wcepColorbar.add(views.wcepTitle);
    var colors = [];
    for (i = 0; i < 6; i++) {
        colors.push(makeLegendRow(
            ['LD', 'LN', 'LI', 'HD', 'HN', 'HI'][i],
            ['BA26F7', '0C00C4', '96D8E8', 'FFDF02',
            'FFAF82', 'BE0600'][i], 'cep'));
    }
    views.wcepColorbar.add(ui.Panel({ widgets: colors, layout: views.layout() }));
    // Toggle CEP
    for (i = 0; i < 6; i++) {
        views.wcepLegend.add(
            makeLegendRow(
                ['LD', 'LN', 'LI', 'HD', 'HN', 'HI'][i],
                ['BA26F7', '0C00C4', '96D8E8', 'FFDF02',
                'FFAF82', 'BE0600'][i]));
    }
    // Level: Alpha Color-codes
    if (!app.model.MOBILE) { views.alphaLegend.add(views.alphaTitle) }
    for (i = 0; i < 2; i++) {
        views.alphaLegend.add(
            makeLegendRow(
                ['L: Low CHL', 'H: High CHL'][i],
                ['2000E0', 'BE0600'][i]));
    }
    // Trend Color-codes
    if (!app.model.MOBILE) { views.trendLegend.add(views.trendTitle) }
    for (i = 0; i < 3; i++) {
        views.trendLegend.add(
            makeLegendRow(
                ['D: Decreasing Trend', 'N: No Trend', 'I: Increasing Trend'][i],
                ['2000E0', 'BFAB04', 'BE0600'][i]));
    }
    // Controls.
    views.controlPanel.add(
        ui.Panel({
            widgets: [
                views.intro, views.dataPanel, views.trendPanel, views.trendLegend,
                views.alphaPanel,
                views.alphaLegend,
                ui.Label('', { margin: '30px 0 40px 0' })
                // views.wcepColorbar
            ],
            // layout: app.model.MOBILE ? views.layout() : views.layout('v')
        }))
        .add(ui.Button({
            label: 'Less',
            style: { position: 'bottom-left', shown: app.model.MOBILE ? true : false },
            // React to the button's click event.
            onClick: function () {
                app.views.standaloneMap.remove(app.views.controlPanel);
                ui.root.widgets().add(app.views.wcepLegend);
            }
        }));
    // Get more A Learn More button for mobile screens.
    views.controlPanel.moreButton = ui.Button({
        label: 'More',
        style: { position: 'top-left', padding: '0' },
        // React to the button's click event.
        onClick: function () {
            ui.root.widgets().remove(app.views.wcepLegend);
            views.standaloneMap.add(app.views.controlPanel);
        }
    });
    var info = ui.Label(
            'The Global Eutrophication Watch is designed to allow users to perform ' +
            'a preliminary screening of costal eutrophication using satellite-derived ' +
            'chlorophyll (CHL) data. A default MODIS/Aqua-derived CHL product is bundled '+
            'with the App. However, users can also provide a link to their own asset of '+
            'monthly CHL. In addition to that, the YOC CHL product (a regional dataset in'+
            'the Northwest Pacific region) is also provided with the App.',
            { margin: '30px 0 1px 0', fontSize: app.model.MOBILE ? '14px' : '12px' });
    var epclass = ui.Label(
            'The article for this app, accessible from the link: https://doi.org/10.1038/s41467-021-26391-9, '+
            'introduces the terms eutrophic potential, eutrophication potential, '+
            'and oligotrophication potential for waters with high CHL levels (HD, HN, and HI), '+
            'with increasing CHL trends (LI and HI), and with decreasing CHL trends (LD and HD), '+
            'respectively. LI and HI are of a particular interest as they indicate waters in a '+
            'process of becoming eutrophic (LI) or a progression of an already eutrophic (HI) water body.',
            { margin: '30px 0 40px 0', fontSize: app.model.MOBILE ? '14px' : '12px' });
    // Inspector.
    views.inspector.add(
        ui.Label('Click a point on the map to update the chart.', app.model.TEXT_STYLE))
        .add(ui.Panel({ widgets: [views.lon, views.lat], layout: views.layout() }))
        .add(views.clickStatus)
        .add(views.tsLengend)
        .add(views.tsChart)
        .add(views.clickStatusRight)
        .add(views.tsLengendRight)
        .add(views.tsChartRight)
        .add(views.wcepColorbar)
        .add(info)
        .add(epclass);
    // .add(views.areaChart);
}
// Get Methods
function initGetter(get) {
    // Return MCEP
    get.getMcep = function (mtrend, malpha) {
        return cepMap.getCep(malpha, mtrend);
    };
    // Return ui.Map.Layer
    get.getMapLayer = function (eeImage, visParam, thisName) {
        return ui.Map.Layer(
            eeImage, visParam, thisName);
    };
    // Reurn trend
    get.getTrend = function (caller) {
        if (caller == 'right') {
            app.model.state.maxSeriesRight = ee.ImageCollection(
                app.model.state.annuMaxSeries).filterDate(
                    ee.Date.fromYMD(app.model.START_YEAR, 1, 1),
                    ee.Date.fromYMD(app.model.END_YEAR, 12, 31));
            return trendMap.getTrend(
                app.model.state.maxSeriesRight.toList(
                    app.model.state.maxSeriesRight.size()),
                app.model.EPS, app.model.state.mask);
            // , app.model.proj, app.model.state.mask
        }
        app.model.state.maxSeries = ee.ImageCollection(
            app.model.state.annuMaxSeries).filterDate(
                ee.Date.fromYMD(app.model.START_YEAR, 1, 1),
                ee.Date.fromYMD(app.model.END_YEAR, 12, 31));
        return trendMap.getTrend(
            app.model.state.maxSeries.toList(
                app.model.state.maxSeries.size()),
            app.model.EPS, app.model.state.mask);
        // app.model.proj, app.model.state.mask
    };
    // Return Alpha
    get.getAlpha = function () {
        var alpha = alphaMap.getAlpha(app.model.state.dataset,
            app.model.START_DAY, app.model.END_DAY, app.model.ALPHA);
        app.model.state.mask = alpha.select('alpha'); //.mask();
        return alpha;
    };
    // Return select image
    get.getSelect = function (selectName, caller) {
        if (selectName == 'Trend') {
            if (caller == 'right') {
                return app.getter.getMapLayer(
                    app.model.state.trendMapRight.select('trend'),
                    app.model.TREND_VIS, selectName);
            }
            return app.getter.getMapLayer(
                app.model.state.trendMap.select('trend'),
                app.model.TREND_VIS, selectName);
        }
        if (selectName == 'Composite') {
            return app.getter.getMapLayer(
                app.model.state.alphaMap.select('alpha'),
                app.model.ALPHA_VIS, selectName);
        }
        if (selectName == 'CEP') {
            if (caller == 'right') {
                return app.getter.getMapLayer(
                    app.model.state.cepMapRight,
                    app.model.CEP_VIS, selectName);
            }
            return app.getter.getMapLayer(
                app.model.state.cepMap,
                app.model.CEP_VIS, selectName);
        }
    };
    get.getColl = function (caller, value) {
        if (caller == 'yoc') {
            if (value) { app.model.state.dataset = app.model.imgColl(caller, value) }
            else { app.model.state.dataset = app.model.imgColl(); caller = 'default' }
        }
        if (caller == 'userAsset') {
            if (value) {
                app.views.userAssetLog.setValue('Loading...');
                app.views.userAssetLog.style().set({ shown: true });
                app.model.state.dataset = app.model.imgColl(caller, value);
                app.views.userAssetLog.style().set({ shown: false });
            }
            else { app.model.state.dataset = app.model.imgColl(); caller = 'default' }
        }
        return caller;
    };
    get.chartSeries = function (imList, trend) {
        var slope = ee.Image(trend).select('slope');
        var offset = ee.Image(trend).select('offset');
        // Create a chart, a time series plot at a single location and its current status
        return ee.ImageCollection(imList).map(
            function (image) {
                var timeDef = image.select('time');
                var linTrend = timeDef
                    .multiply(slope)
                    .add(offset)
                    .rename('Trend');
                return image.select('chlor_a').addBands(linTrend);
            });
    };
}
// Initi Controller
function initController(control) {
    // Main functions
    control.update.stateDataset = function () {
        app.model.state.annuMaxSeries = monthAmaxSeries.getMaxSeries(
            app.model.state.dataset, app.model.START_YEAR,
            app.model.END_YEAR, app.model.proj
        );
        app.model.state.alphaMap = app.getter.getAlpha();
        app.model.state.trendMap = app.getter.getTrend();
        // app.model.state.cepMap = app.getter.getMcep(
        //     app.model.state.trendMap,
        //     app.model.state.alphaMap
        // );
        app.model.state.chartTs = app.getter.chartSeries(
            app.model.state.maxSeries, app.model.state.trendMap);
        if (app.model.state.splitMode) {
            var startY = app.views.toggleStartYear.getValue();
            var endY = app.views.toggleEndYear.getValue();
            app.model.state.maxSeriesRight = monthAmaxSeries.getMaxSeries(
                app.model.state.dataset, startY, endY, app.model.proj);
            app.model.state.chartTsRight = app.getter.chartSeries(
                app.model.state.maxSeriesRight, app.model.state.trendMap);
        }
    };
    control.update.selectPanel = function (caller) {
        var start = app.views.startYear.getValue();
        var end = app.views.endYear.getValue();
        app.model.START_YEAR = start;
        app.model.END_YEAR = end;
        if (!app.model.state.splitMode) {
            app.model.state.trendMap = app.getter.getTrend(caller);
            app.model.state.chartTs = app.getter.chartSeries(
                app.model.state.maxSeries, app.model.state.trendMap);
            return;
        }
        if (caller == 'left') {
            app.views.leftLabel.setValue("(" + start + "–" + end + ")");
            app.views.tsLengend.setValue('Timeseries: ' + start + '–' + end);
            app.model.state.trendMap = app.getter.getTrend(caller);
            app.model.state.chartTs = app.getter.chartSeries(
                app.model.state.maxSeries, app.model.state.trendMap);
        }
        if (caller == 'right') {
            start = app.views.toggleStartYear.getValue();
            end = app.views.toggleEndYear.getValue();
            app.model.START_YEAR = start;
            app.model.END_YEAR = end;
            app.views.rightLabel.setValue("(" + start + "–" + end + ")");
            app.views.tsLengendRight.setValue('Timeseries: ' + start + '–' + end);
            app.model.state.trendMapRight = app.getter.getTrend(caller);
            app.model.state.chartTsRight = app.getter.chartSeries(
                app.model.state.maxSeriesRight, app.model.state.trendMapRight);
        }
    };
    // STANDALONE
    control.main.standalone = function () {
        app.model.state.cepMap = app.getter.getMcep(
            app.model.state.trendMap,
            app.model.state.alphaMap
        );
        app.views.standaloneMap.layers().set(0,
            app.model.state.cepMap.visualize(app.model.CEP_VIS));
    };
    /************************************************************/
    // LEFT
    control.main.left = function (selectMap) {
        // Can choose between the 3 options MCEP, Trend, Composite
        app.model.state.cepMap = app.getter.getMcep(
            app.model.state.trendMap,
            app.model.state.alphaMap
        );
        if (!selectMap) { selectMap = app.model.state.selectMap }
        app.views.leftMap.layers().set(0, app.getter.getSelect(selectMap, 'left'));
    };
    /************************************************************/
    // RIGHT
    control.main.right = function (selectMap) {
        // Can choose between the 3 options MCEP, Trend, Composite
        app.model.state.cepMapRight = app.getter.getMcep(
            app.model.state.trendMapRight,
            app.model.state.alphaMap
        );
        if (!selectMap) { selectMap = app.model.state.selectMap }
        app.views.rightMap.layers().set(0, app.getter.getSelect(selectMap, 'right'));
    };
    /************************************************************/
    control.main.splitter = function (caller) {
        var left = app.views.leftSelect.getValue();
        var right = app.views.rightSelect.getValue();
        if (caller == 'alphaValue' || caller == 'alphaDate' || caller == 'dataset') {
            // Update all
            control.update.stateDataset();
            app.model.state.selectMap = left;
            control.update.selectPanel('left');
            app.controller.main.left();
            app.model.state.selectMap = right;
            control.update.selectPanel('right');
            app.controller.main.right();
            return;
        }
        if (!('Composite' in [left, right])) {
            control.update.selectPanel(caller);
        }
        if (caller == 'left') {
            app.model.state.selectMap = left;
            app.controller.main.left();
        }
        if (caller == 'right') {
            app.model.state.selectMap = right;
            app.controller.main.right();
        }
    };
    control.update.dataset = function (caller, value) {
        caller = app.getter.getColl(caller, value);
        app.model.state.currentDataset = caller;
        app.views.startYear.setMin(app.model.START_YEAR);
        app.views.startYear.setValue(app.model.START_YEAR);
        app.views.endYear.setMax(app.model.END_YEAR);
        app.views.toggleStartYear.setMin(app.model.START_YEAR);
        app.views.toggleStartYear.setValue(app.model.START_YEAR);
        app.views.toggleEndYear.setMax(app.model.END_YEAR);
        if (!app.model.state.splitMode) {
            control.update.stateDataset();
            app.controller.main.standalone();
        } else { app.controller.main.splitter('dataset') }
    };
    // Update trend
    control.update.trend = function (caller) {
        if (!app.model.state.splitMode) {
            control.update.selectPanel(caller);
            app.controller.main.standalone();
        }
        if (app.model.state.splitMode) {
            app.controller.main.splitter(caller);
        }
    };
    // Update threshold 
    control.update.alpha = function (caller, value) {
        if (caller == 'alphaValue') { app.model.ALPHA = ee.Number.parse(value) }
        if (caller == 'alphaDate') {
            app.model.START_DAY = ee.Date.parse('Y-MM-dd', app.views.alphaStartDay.getValue());
            app.model.END_DAY = ee.Date.parse('Y-MM-dd', app.views.alphaEndDay.getValue());
        }
        if (app.model.state.cepMap === null) {
            control.update.stateDataset();
        } else {
            app.model.state.alphaMap = app.getter.getAlpha();
            app.model.state.cepMap = app.getter.getMcep(
                app.model.state.trendMap, app.model.state.alphaMap);
        }
        if (app.model.state.splitMode) { app.controller.main.splitter(caller) }
        if (!app.model.state.splitMode) { app.controller.main.standalone() }
    };
    // Toggle views
    control.toggleViewMode = function () {
        app.model.state.splitMode = !app.model.state.splitMode;
        app.views.togglePanel.style().set({ shown: app.model.state.splitMode });
        app.views.trendLegend.style().set({ shown: app.model.state.splitMode });
        app.views.alphaLegend.style().set({ shown: app.model.state.splitMode });
        app.views.clickStatusRight.style().set({ shown: app.model.state.splitMode });
        app.views.tsLengend.style().set({ shown: app.model.state.splitMode });
        app.views.tsLengendRight.style().set({ shown: app.model.state.splitMode });
        app.views.tsChartRight.style().set({ shown: app.model.state.splitMode });
        if (!app.model.state.splitMode) {
            app.views.mapPanel.remove(app.views.splitMap);
            app.views.mapPanel.add(app.views.standaloneMap);
            app.controller.main.standalone();
        }
        if (app.model.state.splitMode) {
            app.views.mapPanel.remove(app.views.standaloneMap);
            app.views.mapPanel.add(app.views.splitMap);
            app.views.leftMap.setCenter(app.model.INIT_MAP_CENTER);
            ui.Map.Linker([app.views.leftMap, app.views.rightMap]);
            if (app.model.state.currentDataset === 'yoc' || app.model.state.currentDataset == 'default') {
                app.views.endYear.setValue(app.model.END_YEAR - 5);
                app.model.CEP_TRIGGER = { lon: 120.1357, lat: 39.5608 };
            }
            control.update.selectPanel('left');
            app.views.leftSelect.setValue('CEP');
            control.update.selectPanel('right');
            app.views.rightSelect.setValue('CEP');
            // } else { updateInspector(app.model.CEP_TRIGGER, 'right')}
            updateInspector(app.model.CEP_TRIGGER, 'right');
        }
    };
}
/** Registers callbacks between the views and controls. */
function registerHandlers(views) {
    // data handles
    views.userAsset.onChange(function (value) { app.controller.update.dataset('userAsset', value) });
    views.yocAsset.onChange(function (value) { app.controller.update.dataset('yoc', value) });
    // trend handles
    views.startYear.onChange(function () { app.controller.update.trend('left') });
    views.endYear.onChange(function () { app.controller.update.trend('left') });
    views.toggleStartYear.onChange(function () { app.controller.update.trend('right') });
    views.toggleEndYear.onChange(function () { app.controller.update.trend('right') });
    views.toggleViews.onClick(app.controller.toggleViewMode);
    // alpha handles
    views.alphaSubmit.onClick(function () { app.controller.update.alpha('alphaDate') });
    views.alpha.onChange(function (value) { app.controller.update.alpha('alphaValue', value) });
    // Image selection
    views.leftSelect.onChange(function () { app.controller.main.splitter('left') });
    views.rightSelect.onChange(function () { app.controller.main.splitter('right') });
    // Inspector
    views.standaloneMap.onClick(function (coords) { updateInspector(coords, 'standalone') });
    views.leftMap.onClick(function (coords) { updateInspector(coords, 'left') });
    views.rightMap.onClick(function (coords) { updateInspector(coords, 'right') });
}
// Retrieves the className of the clicked point
var cepStatuses = [1, 2, 3, 4, 5, 6];
var cepLabels = ['LD', 'LN', 'LI', 'HD', 'HN', 'HI'];
var labelDict = Object.keys(cepStatuses).reduce(
    function (obj, x) {
        obj[Number(x) + 1] = cepLabels[x];
        return obj;
    }, {});
function pointStatus(value) {
    if (cepStatuses.indexOf(value) > -1) {
        [labelDict[value]].map(function (value) { updateStatus(value, 'left') });
    }
    else { ['Unknown'].map(function (value) { updateStatus(value, 'left') }) }
}
function pointStatusRight(value) {
    if (cepStatuses.indexOf(value) > -1) {
        [labelDict[value]].map(function (value) { updateStatus(value, 'right') });
    }
    else { ['Unknown'].map(function (value) { updateStatus(value, 'right') }) }
}
var updateStatus = function (statusName, updateMap) {
    if (updateMap == 'right') { app.views.clickStatusRight.setValue('Point Status :: ' + statusName) }
    else { app.views.clickStatus.setValue('Point Status :: ' + statusName) }
};
function chartStyle() {
    return {
        title: 'Chlorophyll-a (CHL) Annual Max',
        vAxis: { title: 'CHL [mg/m^3]', scaleType: 'linear' },
        hAxis: { title: 'Date', format: 'MMM-yy' }, //, gridlines: { count: 7 } 
        // trendlines: { 0: { color: 'CC0000', lineWidth: 1.5, } },
        series: {
            1: { color: '#008000', lineWidth: 2, pointsVisible: true, pointSize: 6 },
            0: { color: '#CC0000', lineWidth: 1.5, pointsVisible: false }
        },
        chartArea: { backgroundColor: 'EBEBEB' }
    };
}
function updateInspector(coords, caller) {
    // Update the lon/lat panel1 with values from the click event.
    app.views.lon.setValue('Latitude: ' + coords.lat.toFixed(2));
    app.views.lat.setValue('Longitude: ' + coords.lon.toFixed(2));
    // Add a red dot for the point clicked on.
    var point = ee.Geometry.Point(coords.lon, coords.lat);
    var dot = ui.Map.Layer(point, { color: 'FF0000' }, 'Select Point');
    if (caller == 'standalone') { app.views.standaloneMap.layers().set(1, dot) }
    if (caller == 'left') { app.views.leftMap.layers().set(1, dot) }
    if (caller == 'right') { app.views.rightMap.layers().set(1, dot) }
    /////////////////////////////////////////////////////
    // Retrieve and update the value of the clicked point
    app.model.state.cepMap.reduceRegion({
        reducer: ee.Reducer.first(),
        geometry: point,
        scale: app.model.proj.nominalScale()
    }).get('mcep').evaluate(pointStatus);
    // ts.aside(print);
    app.views.tsChart = ui.Chart.image.series(
        app.model.state.chartTs, point, ee.Reducer.mean(), 1)
        .setChartType('ScatterChart')
        .setSeriesNames(['chlor_a', 'Trend']);
    app.views.tsChart.setOptions(chartStyle());
    app.views.inspector.widgets().set(4, app.views.tsChart);
    if (app.model.state.splitMode) {
        app.model.state.cepMapRight.reduceRegion({
            reducer: ee.Reducer.first(),
            geometry: point,
            scale: app.model.proj.nominalScale()
        }).get('mcep').evaluate(pointStatusRight);
        app.views.tsChartRight = ui.Chart.image.series(
            app.model.state.chartTsRight, point, ee.Reducer.mean(), 1)
            .setChartType('ScatterChart')
            .setSeriesNames(['chlor_a', 'Trend']);
        app.views.tsChartRight.setOptions(chartStyle());
        app.views.inspector.widgets().set(7, app.views.tsChartRight);
    }
}
/**
 * Boots the application.
 * Initializes views, initializes controls, registers handlers, and creates
 * the interface.
 */
var boot = function (deviceInfo) {
    if (!deviceInfo.is_desktop || deviceInfo.width < 900) {
        initModel(app.model, true);
        initViews(app.views);
        initGetter(app.getter);
        initController(app.controller);
        registerHandlers(app.views);
        // Configuration for mobile screen.
        app.views.standaloneMap.setOptions('SATELLITE');
        app.views.standaloneMap.setControlVisibility(false);
        app.views.standaloneMap.setCenter(131, 37, 4);
        // app.views.standaloneMap.style().set('cursor', 'crosshair');
        // Add "learn more" button if it hasn't been added to the map.
        if (app.views.standaloneMap.widgets().length() < 1) {
            app.views.standaloneMap.add(app.views.controlPanel.moreButton);
        }
        ui.root.clear();
        ui.root.add(app.views.rootPanel);
        ui.root.widgets().reset([app.views.standaloneMap, app.views.wcepLegend]);
        ui.root.setLayout(ui.Panel.Layout.absolute());
        app.views.alpha.setValue('5'); //
    } else {
        initModel(app.model, false);
        initViews(app.views);
        initGetter(app.getter);
        initController(app.controller);
        registerHandlers(app.views);
        // Configure the layouts for how the panels flow together.
        // ui.root.setLayout(ui.Panel.Layout.flow('vertical'));
        app.views.rootPanel.setLayout(ui.Panel.Layout.flow('horizontal'));
        // Web page configuration.
        app.views.standaloneMap.setControlVisibility(true);
        app.views.standaloneMap.setOptions('SATELLITE');
        app.views.standaloneMap.style().set('cursor', 'crosshair');
        app.views.leftMap.style().set('cursor', 'crosshair');
        app.views.leftMap.setOptions('SATELLITE');
        app.views.rightMap.style().set('cursor', 'crosshair');
        app.views.rightMap.setOptions('SATELLITE');
        app.views.standaloneMap.setCenter(131, 37, 4);
        /***************
        * Composition *
        ***************/
        ui.root.clear();
        ui.root.add(app.views.rootPanel);
        app.views.rootPanel.add(app.views.controlPanel);
        app.views.rootPanel.add(app.views.mapPanel);
        app.views.rootPanel.add(app.views.inspector);
        app.views.alpha.setValue('5'); //
        updateInspector(app.model.CEP_TRIGGER, 'standalone');
        // Remove button if it has been added to the map.
        if (app.views.standaloneMap.widgets().length() > 0) {
            app.views.standaloneMap.widgets().reset();
        }
    }
};
ui.root.onResize(boot);