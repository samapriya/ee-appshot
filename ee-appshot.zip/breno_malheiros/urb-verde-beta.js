var estado_sp = ui.import && ui.import("estado_sp", "table", {
      "id": "users/breno_malheiros/Estado_SP"
    }) || ee.FeatureCollection("users/breno_malheiros/Estado_SP"),
    censo2010 = ui.import && ui.import("censo2010", "table", {
      "id": "users/breno_malheiros/Censo2010-SP"
    }) || ee.FeatureCollection("users/breno_malheiros/Censo2010-SP"),
    municipios_sp = ui.import && ui.import("municipios_sp", "table", {
      "id": "users/breno_malheiros/sp_municipios"
    }) || ee.FeatureCollection("users/breno_malheiros/sp_municipios");
// ########### MOTOR ########### 
//  ==== VETORIZAÇÃO MANCHA URBANA  ====
var mancha_urbana = function () {
  var mapbiomas = ee.Image("projects/mapbiomas-workspace/public/collection5/mapbiomas_collection50_integration_v1")
  .select([34]);
  var mancha = mapbiomas.clip(estado_sp)
      mancha = mancha.select('classification_2019').eq(24) //Selecionando Valor do pixel pra zona urbana
      mancha = mancha.updateMask(mancha); //remove os valores diferentes de 24 (urbano)
      mancha = mancha.reduceToVectors({scale:165, geometry: estado_sp}); //vetoriza imagem
  return mancha
}
// ==== NDVI ESTADO ====
var ndvi_sp = function(data_inicial,data_final){
  var sentinel2 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate(data_inicial,data_final )
                  .filterBounds(estado_sp)
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .min();
  var img = ee.Image(sentinel2);
  //normalizedDifference (NIR,RED) = (NIR - RED) / (NIR + RED)
  var ndvi = img.normalizedDifference(['B8', 'B4']).clip(estado_sp);
  return ndvi
}
// ==== NDVI MÉDIO ====
var ndvi_medio = function (feicao,ndvi){
  //Cálculo do NDVI médio no Setor selecionado
  var setor_alvo = ndvi.clip(feicao).reduce(ee.Reducer.mean())
  var ndvi_medio = setor_alvo.reduceRegion(ee.Reducer.mean(),feicao, 30);
      ndvi_medio = ndvi_medio.get('mean')
      print('ndvi',ndvi_medio)
  return ndvi_medio
}
// ==== MLME ESTADO ====
var fracao_sp = function(data_inicial, data_final){
  var start = data_inicial;
  var end = data_final;
  var L8_img = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA')
        .filterBounds(estado_sp)
        .filterDate(start, end)
        .map(maskL8)
        .median()
        .clip(estado_sp)
        .select(['B2','B3','B4','B5','B6','B7'],['B1','B2','B3','B4','B5','B7'])
  // MODELO LINEAR DE MISTURA ESPECTRA (MLME)
  // Definindo os "endmenbers"  (global endmembers by Small & Millesi)
  var substrate = [0.211200, 0.317455, 0.426777, 0.525177, 0.623311, 0.570544];
  var veg =       [0.093026, 0.086723, 0.049961, 0.611243, 0.219628, 0.079601];
  var dark =      [0.081085, 0.044215, 0.025971, 0.017209, 0.004792, 0.002684];
  // Função para aplicar o MLME no conjunto de imagens Landsat Filtrado na região
  var addUnmix = function(bestImages) {
    var unmix = bestImages.unmix([substrate, veg, dark], true, true).rename('sub', 'veg', 'dark');
    return bestImages.addBands(unmix);
  };
  // Mapeia a função unmix e retorna uma lista
  var unmixed = L8_img.map(addUnmix);
  var LSUall = ee.ImageCollection(unmixed)
      .select(['veg']).min().clip(feicao);
}
// ==== MLME MÉDIO ====
var fracao_sp = function (feicao, fracao){
  //Cálculo da Média do MLME no setor selecionado
  var setor_alvo_mlme = fracao.clip(feicao).reduce(ee.Reducer.mean())
  var media_mlme = setor_alvo_mlme.reduceRegion(ee.Reducer.mean(),feicao, 30);
  var result_mlme = media_mlme.get('mean')
  return result_mlme
}
var dados_ibge = function(cod_setor){
  var area_km2 = censo2010.filterMetadata('CD_GEODI','equals',cod_setor).first().get('AREA')
  var ipvs = censo2010.filterMetadata('CD_GEODI','equals',cod_setor).first().get('V10')
  var pop = censo2010.filterMetadata('CD_GEODI','equals',cod_setor).first().get('V14')
  var renda = censo2010.filterMetadata('CD_GEODI','equals',cod_setor).first().get('V19') //Renda per capita nos domicílios particulares permanentes do setor censitário
  return [area_km2,ipvs,pop,renda]
}
// ########### INTERFACE ###########
// Menu Lateral
ui.root.clear();
var panel = ui.Panel({style: {width: '230px'}});
var map = ui.Map();
ui.root.add(panel).add(map);
map.style().set('cursor', 'crosshair');
map.setCenter(-47.89164, -22.00919, 8);
//Inserção da logo através do método ui.Chart (utilizando HTML)
var logo = ui.Chart(
    [
      ['<h6><b>Projeto Machine Learning</b></h6>'],
      ['<img src=https://livreopiniaoportal.files.wordpress.com/2014/08/iau2.jpg width=180px>']
    ],
    'Table', {allowHtml: true});
panel.add(ui.Panel(logo));
//Coleta coordenadas de um ponto selecionado no mapa
var click = function (feicao){
  map.onClick(function(coords) {
  var points = []
  points.push([coords.lon, coords.lat])
  print('entrou no click - coord',point)
  feicao = feicao.filterBounds(ee.Geometry.MultiPoint(points))
  print('click')
  return point
  })
}
//Carrega os os contornos base
var reload = function  (select1,select2){
  print('entrou no reload com valor '+select1+' e '+select2)
    map.layers().reset()
    var feicao
    if(select1 == 'Setores Censitários IBGE'){
      feicao = censo2010
      print ('entrou em setor')
    } else if (select1 == 'Manchas Urbanas MapBiomas'){
      feicao = mancha_urbana()
      print('entrou em mancha')
    } else if (select1 == 'Municípios'){
      feicao = municipios_sp
      print('entrou em municípios')
    } else {
      print('ERRO!!!!!!!!!!!!!!!!!')
    }
  map.addLayer(feicao,{color:'gray'})
  click(feicao)
  //posso transformar feicao em uma lista onde armazeno as feições pra calcular o ndvi mlme e outros
  print('feição',feicao.size())
}
//Selecionar Feição Baser de Seleção
var select1 = ui.Select({
  items: ['Setores Censitários IBGE', 'Manchas Urbanas MapBiomas','Municípios'],
  value:null,
  onChange: reload
});
panel.add(ui.Label('Escolha a forma de Seleção:')).add(select1);
// Seleção de Ano
var select2 = ui.Select({
  items: ['2021','2020', '2019','2018','2017', '2016'],
  value:'2020',
  onChange: reload
});
panel.add(ui.Label('Escolha o Ano:')).add(select2);
/*
//Botão iniciar
var iniciar = ui.Button({
  label:'Iniciar', 
  onClick:reload(select1.getValue(),select2.getValue()),
   style: {stretch: 'horizontal'}
})
panel.add(iniciar)
*/