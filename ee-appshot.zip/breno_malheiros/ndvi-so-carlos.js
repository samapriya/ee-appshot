var setores = ui.import && ui.import("setores", "table", {
      "id": "users/breno_malheiros/Setores_IBGE"
    }) || ee.FeatureCollection("users/breno_malheiros/Setores_IBGE"),
    sanca = ui.import && ui.import("sanca", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -47.9549218669836,
                -21.978283315474243
              ],
              [
                -47.9549218669836,
                -22.062944992957213
              ],
              [
                -47.82754912528438,
                -22.062944992957213
              ],
              [
                -47.82754912528438,
                -21.978283315474243
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-47.9549218669836, -21.978283315474243],
          [-47.9549218669836, -22.062944992957213],
          [-47.82754912528438, -22.062944992957213],
          [-47.82754912528438, -21.978283315474243]]], null, false);
//Estrutura Básica NDVI utilizando bandas com resolução de 10m 
// NDVI = (NIR - RED) / (NIR + RED), onde B4=RED e B8=NIR
var year = [2016,2018,2020]
year.map(function(year){
var sentinel2 = ee.ImageCollection('COPERNICUS/S2')
                      .filterDate(year+'-01-01', year+'-12-30')
                      //.filterBounds(setores) //erro: muitas feições para usar isso
                      .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                      .min();
var img = ee.Image(sentinel2).clip(sanca);
//normalizedDifference (NIR,RED) = (NIR - RED) / (NIR + RED)
var ndvi = img.normalizedDifference(['B8', 'B4']);
// Paleta de cores em Hexa.
var palette = ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
               '74A901', '66A000', '529400', '3E8601', '207401', '056201',
               '004C00', '023B01', '012E01', '011D01', '011301'];
// Centralizando em São Carlos
Map.setCenter(-47.89063468131465, -22.01925187991944, 14);
Map.addLayer(ndvi, {min: 0, max: 1, palette: palette}, 'NDVI_'+year);
//Map.addLayer(feicao, {color:'gray'}, 'Setores');
})