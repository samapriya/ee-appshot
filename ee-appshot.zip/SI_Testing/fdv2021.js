///*************************IMPORTS**************************************///
var FDV = ee.FeatureCollection("users/SI_Testing/FDVORI"); //Franja de diversidad
var FDVSAFA = ee.FeatureCollection("users/SI_Testing/FDVSAFA");//Etnias
var FDVbuffer = ee.FeatureCollection("users/SI_Testing/FDVBuffer2");//Area buffer
var S2collection = ee.ImageCollection('COPERNICUS/S2');
var L8collection = ee.ImageCollection('LANDSAT/LC8_L1T_TOA'); 
//**************************SET VAR*************************************///
var scale = 30;
var startDate = '2015-01-01' ;
var endDate = '2021-01-31';
var anio = ee.Number(1);
var anioTxt= anio.toString();
var lossTxt;
var lossFDV, lossColono, lossShuar, lossWaorani, lossKichwa;
var lossBuffer;
// Canopy cover percentage (e.g. 10%)
var cc = ee.Number(10);
// Minimum forest area in pixels (e.g. 6 pixels, approximately 0.5 ha in this example)
var pixels = ee.Number(6);
// Minimum mapping area for tree loss (usually same as the minimum forest area)
var lossPixels = ee.Number(6);
var palette =['96ED89',//treeCover  (purple)
              'ff0000'// treeloss  (red)
];
//**************************INITIALIZING*******************************///
Map.setOptions('SATELLITE');
Map.centerObject(FDV,10);
//**************************PROGRAM*************************************///
var S2fdv = S2collection
                        .filterDate(startDate,endDate)
                        .filterBounds(FDV);
var L8fdv = L8collection
                        .filterDate(startDate,endDate)
                        .filterBounds(FDV);                        
Map.addLayer(S2fdv,{},'S2FDV',false);
Map.addLayer(L8fdv,{},'L8FDV',false);
Map.addLayer(FDV,{},'FDV',false);
//*************************ETNIA OPTIONS****************************************//
// Load watersheds from a data table.
var fdvColono = ee.FeatureCollection(FDVSAFA.filter(ee.Filter.stringContains('etnia', "Colono")));
//Map.addLayer(fdvColono,{palette:['#00FFFF']},'Colono',false);
var fdvShuar = ee.FeatureCollection(FDVSAFA.filter(ee.Filter.stringContains('etnia', "Shuar")));
var fdvWaorani = ee.FeatureCollection(FDVSAFA.filter(ee.Filter.stringContains('etnia', "Waorani")));
var fdvKichwa = ee.FeatureCollection(FDVSAFA.filter(ee.Filter.stringContains('etnia', "Kichwa")));
//*********************************DATASET GFC****************************//
var gfc2018 = ee.Image('UMD/hansen/global_forest_change_2021_v1_9');
var canopyCover = gfc2018.select(['treecover2000']);
var canopyCover10 = canopyCover.gte(cc).selfMask();
// Use connectedPixelCount() to get contiguous area.
var contArea = canopyCover10.connectedPixelCount();
// Apply the minimum area requirement.
var minArea = contArea.gte(pixels).selfMask();
var prj = gfc2018.projection();
var scale = prj.nominalScale();
Map.addLayer((minArea.reproject(prj.atScale(scale))).clip(FDV), {
   palette: ['#96ED89']}, 'tree cover: >= min canopy cover & area (light green)');// 
var forestArea = minArea.multiply(ee.Image.pixelArea()).divide(10000);
var forestSize = forestArea.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: FDV,
    scale: scale,
    maxPixels: 1e13
});
print(
    'Year 2000 tree cover (ha) \nmeeting minimum canopy cover and \nforest area thresholds \n ',
    forestSize.get('treecover2000'));
var pixelCount = minArea.reduceRegion({
    reducer: ee.Reducer.count(),
    geometry: FDV,
    scale: scale,
    maxPixels: 1e13
});
var onePixel = forestSize.getNumber('treecover2000').divide(pixelCount.getNumber('treecover2000'));
var minAreaUsed = onePixel.multiply(pixels);
print('Minimum forest area used (ha)\n ', minAreaUsed);
//**************tree lost
var treeLoss = gfc2018.select(['lossyear']);
var treeLoss01 = treeLoss.eq(1).selfMask(); // tree loss in year 2001
// Select the tree loss within the derived tree cover (>= canopy cover and area requirements).
var treecoverLoss01 = minArea.and(treeLoss01).rename('loss2001').selfMask();
// Create connectedPixelCount() to get contiguous area.
var contLoss = treecoverLoss01.connectedPixelCount();
// Apply the minimum area requirement.
var minLoss = contLoss.gte(lossPixels).selfMask();
var lossArea = minLoss.multiply(ee.Image.pixelArea()).divide(10000);
var lossSize = lossArea.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: FDV,
    scale: scale,
    maxPixels: 1e13
});
print(
    'Year 2001 tree loss (ha) \nmeeting minimum canopy cover and \nforest area thresholds \n ',
    lossSize.get('loss2001'));
//******************tree lost per year
function loosYearTree(anio){
        var lossIn2012 = gfc2018.select(['lossyear']).eq(anio);
        var areaImage = lossIn2012.multiply(ee.Image.pixelArea()).divide(1000*1000); //area in km2
        var etniasList = ee.List(['FDV','fdvColono','fdvShuar','fdvWaorani','fdvKichwa']);
       // var myReturns = ee.List(etniasList.map(areaCalculate));
      //  print(myReturns)
              lossFDV= areaCalculate(FDV).toString();
              lossColono= areaCalculate(fdvColono).toString();
              lossShuar= areaCalculate(fdvShuar).toString();
              lossWaorani= areaCalculate(fdvWaorani).toString();
              lossKichwa= areaCalculate(fdvKichwa).toString();
              lossBuffer= areaCalculate(FDVbuffer).toString();
        function areaCalculate(etniaFc){
                // Calculate the area of loss pixels in the Congo Republic.
                var stats = areaImage.reduceRegion({
                  reducer: ee.Reducer.sum(),
                  geometry: etniaFc,
                  scale: scale,
                  maxPixels: 1e9
                });
                print(
                  'Forest area lost in the Franja \nde diversidad de la vida  :(Km²)',
                  stats.get('lossyear'),
                  'square Kmeters'
                );
                lossTxt = stats.get('lossyear').getInfo().toString();
                //print(lossTxt);
          return (lossTxt)
        }
      var  imageLoss= (ee.Image(lossIn2012).selfMask()).clip(FDV)
      Map.addLayer((minArea.reproject(prj.atScale(scale))).clip(FDV), {
   palette: ['#96ED89']}, 'tree cover: >= min canopy cover & area (light green)');// 
        //Map.addLayer((ee.Image(lossIn2012).selfMask()).clip(FDV),{
          // palette: ['#FF0000']},'lostArea');
  return (imageLoss)
}
//*********************************UI*******************************************//
//Create title label
var title = ui.Label('Forest Changing - Franja de Biodiversidad de la vida (ECUADOR)', {
          stretch: 'horizontal',
          textAlign: 'center',
          fontWeight: 'bold',
          fontSize: '24px'
        });
// Create a label and pull-down menu.
var label = ui.Label('Forest area was lost in ');
var select = ui.Select({
  items: ['2001', '2002', '2003', '2004', '2005', '2006','2007','2008','2009','2010',
          '2011', '2012', '2013', '2014', '2015', '2016','2017','2018', '2019','2020','2021'],
  value: '2001',
  onChange: redraw,
  style: {stretch:'horizontal'}
});
// Create a panel that contains both the pull-down menu and the label.
var panel = ui.Panel({
  widgets: [title,label, select],
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    position: 'top-center',
    width: '300px',
    padding: '10px'
  }
});
//Main Panel
// Add the panel to the map.
Map.add(panel);
 // forest lost label
//function repanel(valkm){
//Map.add(ui.Panel(
//    [
//      ui.Label('Forest area lost (Km²)'),
//      ui.Label( valkm ),
//    ],
//    ui.Panel.Layout.flow('vertical'),
//    {width: '350px', margin: '1px 1px 4px 1px', position: 'bottom-right'}));
//}  
//  
// forest lost label
var lossLabelPanel= ui.Label(' ');  
var lossLabelPanel_woa= ui.Label(' ');
var lossLabelPanel_shu= ui.Label(' ');
var lossLabelPanel_kic= ui.Label(' ');
var lossLabelPanel_col= ui.Label(' ');
var lossLabelPanel_buf= ui.Label(' ');
var lossPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    position: 'bottom-right',
    width: '300px',
    padding: '10px'
  }
});
Map.add(lossPanel);
function repanel(lossFDV_km,lossWoarani_km, lossShuar_km,lossKichwa_km,lossColono_km,lossBuffer_km){
  lossLabelPanel= ui.Label('Forest area lost in FDV (Km²): ' + lossFDV_km)
  lossLabelPanel_woa= ui.Label('Forest area lost in Woarani (Km²): ' + lossWoarani_km);
  lossLabelPanel_shu= ui.Label('Forest area lost in Shuar (Km²): ' + lossShuar_km);
  lossLabelPanel_kic= ui.Label('Forest area lost in Kichwa (Km²): ' + lossKichwa_km);
  lossLabelPanel_col= ui.Label('Forest area lost in Colono (Km²): ' + lossColono_km);
  lossLabelPanel_buf= ui.Label('Forest area lost in Buffer Area (Km²): ' + lossBuffer_km);
  lossPanel.add(lossLabelPanel);
  lossPanel.add(lossLabelPanel_woa);
  lossPanel.add(lossLabelPanel_shu);
  lossPanel.add(lossLabelPanel_kic);
  lossPanel.add(lossLabelPanel_col);
  lossPanel.add(lossLabelPanel_buf);
}
// Create a function to render a map layer configured by the user inputs.
function redraw() {
  Map.layers().reset();
  lossPanel.clear();
  var valAnio = select.getValue();
      valAnio = valAnio.slice(2,4);
      anio = ee.Number(parseInt(valAnio));  
  var image = loosYearTree(anio);
  repanel(lossFDV, lossWaorani, lossShuar,lossKichwa,lossColono,lossBuffer);
  Map.addLayer(image, {palette: ['#FF0000']},'lostArea');//red color
  Map.addLayer(fdvShuar,{color:'00FFFF'},'Shuar',false);
  Map.addLayer(fdvColono,{color:'00FF00'},'Colono',false);
  Map.addLayer(fdvWaorani,{color:'DAA520'},'Waorani',false);
  Map.addLayer(fdvKichwa,{color:'000080'},'Kichwa',false);
  Map.addLayer(FDVbuffer,{color:'ffff00'},'Buffer Area',false);
   //Map.add(lossPanel);
}
// Invoke the redraw function once at start up to initialize the map.
redraw();
// Create a legend.
var labels = ['Tree Cover 2000','Tree Loss'];
var add_legend = function(title, lbl, pal) {
  var legend = ui.Panel({style: {position: 'bottom-left'}}), entry;
  legend.add(ui.Label({style: { fontWeight: 'bold', fontSize: '15px', margin: '1px 1px 4px 1px', padding: '2px' } }));
  for (var x = 0; x < lbl.length; x++){
    entry = [ ui.Label({style:{color: pal[x], border:'1px solid black', margin: '1px 1px 4px 1px'}, value: '██'}),
      ui.Label({ value: labels[x], style: { margin: '1px 1px 4px 4px' } }) ];
    legend.add(ui.Panel(entry, ui.Panel.Layout.Flow('horizontal')));
  } Map.add(legend); };
add_legend('Legend', labels, palette);