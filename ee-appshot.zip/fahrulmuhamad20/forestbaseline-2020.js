var legend = require('users/fahrulmuhamad20/DEFORESTATION/:Utilities/Add_Legend')
// SBTN Natural Land
var SBTN = ee.Image('WRI/SBTN/naturalLands/v1/2020').select('classification')
var forest = SBTN.eq(2).or(SBTN.eq(5)).or(SBTN.eq(8)).or(SBTN.eq(9))
var wetland = SBTN.eq(5).or(SBTN.eq(8)).or(SBTN.eq(9)).or(SBTN.eq(10)).or(SBTN.eq(11)).or(SBTN.eq(17)).or(SBTN.eq(18)).or(SBTN.eq(19)).or(SBTN.eq(20))
SBTN = SBTN.updateMask(wetland)
// Global Forest Cover 2020 EUFO
var GFC = ee.ImageCollection('JRC/GFC2020/V1').mosaic()
// Global Forest Cover 2020 EUFO V2
var GFC_v2 = ee.ImageCollection('JRC/GFC2020/V2').mosaic()
// ESA World Cover
var ESAWC = ee.ImageCollection('ESA/WorldCover/v100').first()
ESAWC = ESAWC.updateMask(ESAWC.eq(10)) //Masking Tree Cover only
// TMF Annual Change
var TMF_ann = ee.ImageCollection("projects/JRC/TMF/v1_2024/AnnualChanges").select('Dec2020').mosaic()
TMF_ann = TMF_ann.lte(2).selfMask() // Masking Forest Only
TMF_ann = TMF_ann.connectedPixelCount() 
TMF_ann = TMF_ann.gte(5).selfMask() // Masking Connected pixel greater than 1 ha = 30mx30mx5
Map.addLayer(SBTN,{'palette':'#f096ff'}, 'SBTN Natural Lands Map v1 2020',false,0.4)
Map.addLayer(ESAWC, {'bands': ['Map']}, 'ESA Landcover',false,0.4)
Map.addLayer(GFC,{'palette':'#fa0000'}, 'EC JRC Global forest cover 2020 – V1',false,0.4)
Map.addLayer(GFC_v2,{'palette':'#0064c8'}, 'EC JRC Global forest cover 2020 – V2',false,0.4)
Map.addLayer(TMF_ann,{'palette':'#ffbb22'},'TMF Undisturbed Forest 2020',false,0.4)
// Visualize Legend
var title = 'Forest Baseline'
var unit = '2020'
var length = 5
var palette = ['006400','fa0000','0064c8','ffbb22','f096ff']
var names = ['ESA Landcover Forest Cover','EC JRC Global forest cover 2020 – V1','EC JRC Global forest cover 2020 – V2','TMF Undisturbed Forest 2020','SBTN Natural Lands Map v1 2020']
var legend_def= legend.addLegend(title,unit,length,palette,names)
Map.add(legend_def)