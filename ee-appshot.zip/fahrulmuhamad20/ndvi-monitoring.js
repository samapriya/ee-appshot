var imageCollection = ee.ImageCollection("MODIS/006/MOD13Q1");
var geometry = ee.FeatureCollection("users/fahrulmuhamad20/Kalbar_province")//KALBAR
//NDVI
var collection_merge = ee.ImageCollection('MODIS/006/MOD13Q1')
                      .select('NDVI').filterBounds(geometry)
//Define State Forest Indonesia
var table = ee.FeatureCollection("users/fahrulmuhamad20/Kalbar_stateforest");
var concess = ee.FeatureCollection("users/fahrulmuhamad20/Kalbar_concession");
var empty = ee.Image().byte();
var paletteforest = [
  'white',//APL 
  'mediumvioletred',//CA
  'royalblue',//Danau
  'forestgreen',//HL
  'yellow',//HP
  'hotpink',//HPK
  'lawngreen',//HPT
  'mediumvioletred',//KSA
  'mediumvioletred',//TN
  'royalblue',//TubuhAir
  'mediumvioletred'//TWA
  ];
var VPforest = {min:1,max:11,palette:paletteforest}
var fills = empty.paint({
  featureCollection: table,
  color: 'OBJECTID',
});
var conbound = empty.paint({
  featureCollection: concess,
  color:1,
  width:1
  })
var dict = [
  'Area Penggunaan Lain (APL)',
  'Cagar Alam (CA)',
  'Danau',
  'Hutan Lindung (HL)',
  'Hutan Produksi Tetap (HP)',
  'Hutan Produksi Konversi (HPK)',
  'Hutan Produksi Terbatas (HPT)',
  'KSA/KPA',
  'Taman Nasional (TN)',
  'Tubuh Air',
  'Taman Wisata Alam (TWA)']
//NDVI VP
var VP = {
  min: 0.5,
  max: 0.8,
  palette: ['#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850'],
};
var years = ee.List.sequence(2000, 2019)
//Merge to annual image
var collectYear = ee.ImageCollection(years.map(function(y){
    var start = ee.Date.fromYMD(y, 1, 1)
    var end = start.advance(12, 'month');
    return collection_merge.filterDate(start, end).mean().divide(10000).set('yearof',y)
}))
//Map content
var NDVI = collectYear.toList(collectYear.size())
//annual image
var y2000 = ee.Image(NDVI.get(0))
var y2001 = ee.Image(NDVI.get(1))
var y2002 = ee.Image(NDVI.get(2))
var y2003 = ee.Image(NDVI.get(3))
var y2004 = ee.Image(NDVI.get(4))
var y2005 = ee.Image(NDVI.get(5))
var y2006 = ee.Image(NDVI.get(6))
var y2007 = ee.Image(NDVI.get(7))
var y2008 = ee.Image(NDVI.get(8))
var y2009 = ee.Image(NDVI.get(9))
var y2010 = ee.Image(NDVI.get(10))
var y2011 = ee.Image(NDVI.get(11))
var y2012 = ee.Image(NDVI.get(12))
var y2013 = ee.Image(NDVI.get(13))
var y2014 = ee.Image(NDVI.get(14))
var y2015 = ee.Image(NDVI.get(15))
var y2016 = ee.Image(NDVI.get(16))
var y2017 = ee.Image(NDVI.get(17))
var y2018 = ee.Image(NDVI.get(18))
var y2019 = ee.Image(NDVI.get(19))
//Image List
var images = {
  'State Forest' : fills.visualize(VPforest),
  '2000': y2000.visualize(VP).clip(geometry),
  '2001': y2001.visualize(VP).clip(geometry),
  '2002': y2002.visualize(VP).clip(geometry),
  '2003': y2003.visualize(VP).clip(geometry),  
  '2004': y2004.visualize(VP).clip(geometry),
  '2005': y2005.visualize(VP).clip(geometry),
  '2006': y2006.visualize(VP).clip(geometry),
  '2007': y2007.visualize(VP).clip(geometry),  
  '2008': y2008.visualize(VP).clip(geometry),
  '2009': y2009.visualize(VP).clip(geometry),
  '2010': y2010.visualize(VP).clip(geometry),
  '2011': y2011.visualize(VP).clip(geometry),  
  '2012': y2012.visualize(VP).clip(geometry),
  '2013': y2013.visualize(VP).clip(geometry),
  '2014': y2014.visualize(VP).clip(geometry),
  '2015': y2015.visualize(VP).clip(geometry),  
  '2016': y2016.visualize(VP).clip(geometry),
  '2017': y2017.visualize(VP).clip(geometry),
  '2018': y2018.visualize(VP).clip(geometry),
  '2019': y2019.visualize(VP).clip(geometry),
};
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(VP.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(VP.min, {margin: '4px 8px'}),
    ui.Label(
        ((VP.min + (VP.max - VP.min) / 2)),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(VP.max  , {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'NDVI Value :',
  style: {fontSize: '14px',fontWeight: 'bold'}
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
// Set legend for forest state
var legendstate = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 20px'
  }
})
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 2px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {
          margin: '0 0 8px 5px'
          }
      });
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal'),
      });      
};
// Add color and and names
for (var i = 0; i < 10; i++) {
  // var num = i+1
  // var labelf = dict.get(num.toString())
  legendstate.add(makeRow(paletteforest[i], dict[i]))
  }
// Create the left map, and have it display layer 0.
var leftMap = ui.Map();
leftMap.setControlVisibility(false);
addLayerSelector(leftMap, 0, 'top-left',images);
var bottomleft = ui.Label({
  value: 'Select a concession to show the graph',
  style:{fontSize: '10px'}})
var panelbotleft = ui.Panel({
  widgets: bottomleft,
  style : {
    position:'bottom-left'}})
leftMap.add(panelbotleft)
// Create the right map, and have it display layer 1.
var rightMap = ui.Map();
rightMap.setControlVisibility(false);
addLayerSelector(rightMap, 1, 'top-right',images);
var bottomright = ui.Label({
  value: 'Click on the map to show the graph',
  style:{fontSize: '10px'}})
var panelbotright = ui.Panel({
  widgets: bottomright,
  style : {
    position:'bottom-right'}})
rightMap.add(panelbotright)
//Button to show oil Palm concession
var button1 = (ui.Checkbox({
  label: 'Show Oil Palm Concession',
  onChange: function(checked){
    var layer1 = ui.Map.Layer(concess.draw({color: 'black',strokeWidth: 1}),{}, 'State Forest',true,0.5)
    var layer2 = ui.Map.Layer(concess.draw({color: 'black',strokeWidth: 1}),{}, 'State Forest',true,0.5)
    // rightMap.layers().set(1,layer1)
    // rightMap.layers().get(1).setShown(checked)
    leftMap.layers().set(1,layer2)
    leftMap.layers().get(1).setShown(checked)
  },
  style: {stretch: 'horizontal'}}));
//addlegendandchartPanel
function addLegendandDescription(panel) {
  var label1 = ui.Label({
    value: 'NDVI Change 2000 - 2019 West Kalimantan',
    style: {fontSize: '22px', fontWeight: 'bold'}})
  var label2 = ui.Label({
  value: 'Sources : \n1.MODIS Terra Vegetation Indices 16-Day Global 250m\n2.Indonesia State Forest Map (MoEF 2015)\n3.Oil Palm Concession (GFW 2019)',
  style: {fontSize: '12px',whiteSpace:'pre'}})
  var label3 = ui.Label({
  value: '© Muhamad Fakhrul (2020)',
  style: {fontSize: '10px'}})
  var label4 = ui.Label({
  value: 'Map Legend',
  style: {fontSize: '18px',fontWeight: 'bold'}})
  var label5 = ui.Label({
  value: 'State Forest Class :',
  style: {fontSize: '14px',fontWeight: 'bold'}})
  var controlPanel =
      ui.Panel({widgets: [label1,button1,label4,legendPanel,label5,legendstate,label2,label3]});
  panel.add(controlPanel);
}
// which image is displayed in the associated map.
function addLayerSelector(mapToChange, defaultValue, position, imgcol) {
  var label = ui.Label('Select an image to visualize');
  // This function changes the given map to show the selected image.
  function updateMap(selection) {
    mapToChange.layers().set(0, ui.Map.Layer(imgcol[selection]))
    }
  // Configure a selection dropdown to allow the user to choose between images,
  // and set the map to update when a user makes a selection.
  var select = ui.Select({items: Object.keys(imgcol), onChange: updateMap});
  select.setValue(Object.keys(imgcol)[defaultValue], true);
  var controlPanel =
      ui.Panel({widgets: [label, select], style: {position: position}});
  mapToChange.add(controlPanel)}
// Create a SplitPanel to hold the adjacent, linked maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: 'both'}
});
var inspectorPanel = ui.Panel({style: {width: '20%'}});
addLegendandDescription(inspectorPanel);
function clickonmap(coords,maptochange,paneltochange) {
  // Create or update the location label (the second widget in the panel)
  var location = 'lon: ' + coords.lon.toFixed(2) + ' ' +
                'lat: ' + coords.lat.toFixed(2);
  paneltochange.widgets().set(1, ui.Label(location));
  // Add a red dot to the map where the user clicked.
  if (maptochange == rightMap){
    var point = ee.Geometry.Point(coords.lon, coords.lat)
    maptochange.layers().set(1, ui.Map.Layer(point, {color: 'blue'}));
  }
    else {
      point = concess.filterBounds(ee.Geometry.MultiPoint(coords.lon, coords.lat))
      var PTis = point.first()
      var numPT = PTis.get('NAMA_PT')
      maptochange.layers().set(2, ui.Map.Layer(point, {color: 'blue'}));
    }
  var geomstate = table.filterBounds(ee.Geometry.MultiPoint(coords.lon, coords.lat))
  var stateis = geomstate.first()
  var numstate = stateis.get('Fungsi')
  if(maptochange == rightMap){
    paneltochange.widgets().set(2, ui.Label({value: 'State Forest: ' + numstate.getInfo()}))}
    else paneltochange.widgets().set(2, ui.Label({value: 'Concession Name: ' + numPT.getInfo()}))
  //Graph
  var options = {
    title: 'Annual NDVI Value',
    hAxis: {title: 'Year'},
    vAxis: {title: 'NDVI'}}
  var chart =ui.Chart.image.series(collectYear, point, ee.Reducer.mean(), 250, 'yearof')
  .setChartType('ColumnChart').setOptions(options)
  paneltochange.widgets().set(3,chart)
  }
leftMap.onClick(function(x){return clickonmap(x,leftMap,panelbotleft)})
rightMap.onClick(function(x){return clickonmap(x,rightMap,panelbotright)})
ui.root.clear();
ui.root.add(inspectorPanel)
ui.root.add(splitPanel);
ui.Map.Linker([leftMap, rightMap]);
leftMap.setCenter(111.47352964064066,-0.3036070765508314, 8);
leftMap.style().set('cursor', 'crosshair');
rightMap.style().set('cursor', 'crosshair');