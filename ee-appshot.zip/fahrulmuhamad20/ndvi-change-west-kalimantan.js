var imageCollection = ee.ImageCollection("MODIS/006/MOD13Q1");
var geometry = ee.FeatureCollection("users/fahrulmuhamad20/Kalbar")//KALBAR
//NDVI
var collection_merge = ee.ImageCollection('MODIS/006/MOD13Q1')
                      .select('NDVI').filterBounds(geometry)
//NDVI VP
var VP = {
  min: 0.5,
  max: 0.8,
  palette: ['#d73027','#f46d43','#fdae61','#fee08b','#d9ef8b','#a6d96a','#66bd63','#1a9850'],
};
var years = ee.List.sequence(2000, 2019)
//Merge to annual image
var collectYear = ee.ImageCollection(years.map(function(y){
    var start = ee.Date.fromYMD(y, 1, 1)
    var end = start.advance(12, 'month');
    return collection_merge.filterDate(start, end).mean().divide(10000).set('yearof',y)
}))
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(VP.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(VP.min, {margin: '4px 8px'}),
    ui.Label(
        ((VP.min + (VP.max - VP.min)) / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(VP.max  , {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Map Legend: NDVI value',
  style: {fontWeight: 'bold'}
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
var NDVI = collectYear.toList(collectYear.size())
// var keys = NDVI.map(function(item) {
//   return ee.String(ee.Image(item).get('yearof'))});
// var value = NDVI.map(function(item) {
//   return ee.Image(item).visualize(VP).clip(geometry)});
var y2000 = ee.Image(NDVI.get(0))
var y2001 = ee.Image(NDVI.get(1))
var y2002 = ee.Image(NDVI.get(2))
var y2003 = ee.Image(NDVI.get(3))
var y2004 = ee.Image(NDVI.get(4))
var y2005 = ee.Image(NDVI.get(5))
var y2006 = ee.Image(NDVI.get(6))
var y2007 = ee.Image(NDVI.get(7))
var y2008 = ee.Image(NDVI.get(8))
var y2009 = ee.Image(NDVI.get(9))
var y2010 = ee.Image(NDVI.get(10))
var y2011 = ee.Image(NDVI.get(11))
var y2012 = ee.Image(NDVI.get(12))
var y2013 = ee.Image(NDVI.get(13))
var y2014 = ee.Image(NDVI.get(14))
var y2015 = ee.Image(NDVI.get(15))
var y2016 = ee.Image(NDVI.get(16))
var y2017 = ee.Image(NDVI.get(17))
var y2018 = ee.Image(NDVI.get(18))
var y2019 = ee.Image(NDVI.get(19))
// var dictNDVI = ee.Dictionary.fromLists({
//   keys :keys ,
//   values:value
//   })
//Image List Before Fire
var images = {
  '2000': y2000.visualize(VP).clip(geometry),
  '2001': y2001.visualize(VP).clip(geometry),
  '2002': y2002.visualize(VP).clip(geometry),
  '2003': y2003.visualize(VP).clip(geometry),  
  '2004': y2004.visualize(VP).clip(geometry),
  '2005': y2005.visualize(VP).clip(geometry),
  '2006': y2006.visualize(VP).clip(geometry),
  '2007': y2007.visualize(VP).clip(geometry),  
  '2008': y2008.visualize(VP).clip(geometry),
  '2009': y2009.visualize(VP).clip(geometry),
  '2010': y2010.visualize(VP).clip(geometry),
  '2011': y2011.visualize(VP).clip(geometry),  
  '2012': y2012.visualize(VP).clip(geometry),
  '2013': y2013.visualize(VP).clip(geometry),
  '2014': y2014.visualize(VP).clip(geometry),
  '2015': y2015.visualize(VP).clip(geometry),  
  '2016': y2016.visualize(VP).clip(geometry),
  '2017': y2017.visualize(VP).clip(geometry),
  '2018': y2018.visualize(VP).clip(geometry),
  '2019': y2019.visualize(VP).clip(geometry),
};
// Create the left map, and have it display layer 0.
var leftMap = ui.Map();
leftMap.setControlVisibility(false);
addLayerSelector(leftMap, 0, 'top-left',images);
// Create the right map, and have it display layer 1.
var rightMap = ui.Map();
rightMap.setControlVisibility(false);
addLayerSelector(rightMap, 1, 'top-right',images);
//addlegendandchart
function addLegendandDescription(panel) {
  var label1 = ui.Label({
    value: 'NDVI Change 2000 - 2019 West Kalimantan',
    style: {fontSize: '20px', fontWeight: 'bold'}})
  var label2 = ui.Label({
  value: 'Source : MODIS Terra Vegetation Indices 16-Day Global 250m',
  style: {fontSize: '14px'}})
  var label3 = ui.Label({
  value: '© Muhamad Fakhrul (2020)',
  style: {fontSize: '10px'}})
  var label4 = ui.Label({
  value: 'Click on the map to show the graph',
  style: {fontSize: '10px'}})
  var controlPanel =
      ui.Panel({widgets: [label1,label2,label3,legendPanel,label4]});
  panel.add(controlPanel);
}
// which image is displayed in the associated map.
function addLayerSelector(mapToChange, defaultValue, position, imgcol) {
  var label = ui.Label('Choose an image to visualize');
  // This function changes the given map to show the selected image.
  function updateMap(selection) {
    mapToChange.layers().set(0, ui.Map.Layer(imgcol[selection]));
  }
  // Configure a selection dropdown to allow the user to choose between images,
  // and set the map to update when a user makes a selection.
  var select = ui.Select({items: Object.keys(imgcol), onChange: updateMap});
  select.setValue(Object.keys(imgcol)[defaultValue], true);
  var controlPanel =
      ui.Panel({widgets: [label, select], style: {position: position}});
  mapToChange.add(controlPanel);
}
// Create a SplitPanel to hold the adjacent, linked maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: 'both'}
});
var inspectorPanel = ui.Panel({style: {width: '20%'}});
addLegendandDescription(inspectorPanel);
function clickonmap(coords,maptochange) {
  // Create or update the location label (the second widget in the panel)
  var location = 'lon: ' + coords.lon.toFixed(2) + ' ' +
                 'lat: ' + coords.lat.toFixed(2);
  inspectorPanel.widgets().set(1, ui.Label(location));
  // Add a red dot to the map where the user clicked.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  maptochange.layers().set(1, ui.Map.Layer(point, {color: 'FF0000'}));
  //Graph
  var options = {
    title: 'Average NDVI West Kalimantan',
    hAxis: {title: 'Year'},
    vAxis: {title: 'NDVI'}}
  var chart =ui.Chart.image.series(collectYear, point, ee.Reducer.mean(), 250, 'yearof')
  .setChartType('ColumnChart').setOptions(options)
  inspectorPanel.widgets().set(2,chart)}
leftMap.onClick(function(x){return clickonmap(x,leftMap)})
rightMap.onClick(function(x){return clickonmap(x,rightMap)})
ui.root.clear();
ui.root.add(inspectorPanel)
ui.root.add(splitPanel);
ui.Map.Linker([leftMap, rightMap]);
leftMap.setCenter(111.47352964064066,-0.3036070765508314, 8);
leftMap.style().set('cursor', 'crosshair');
rightMap.style().set('cursor', 'crosshair');