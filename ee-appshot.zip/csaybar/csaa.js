var dataset = ee.ImageCollection('LANDSAT/LC08/C01/T1_ANNUAL_NDVI')
                  .filterDate('2017-01-01', '2019-12-31');
var colorized = dataset.select('NDVI').max();
var colorizedVis = {
  min: 0.0,
  max: 1.0,
  palette: [
    'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01', '011301'
  ],
};
Map.addLayer(colorized);