// การโหลดขอบเขตประเทศและตัดเฉพาะขอบเขตของประเทศไทย
var WBD = ee.FeatureCollection('USDOS/LSIB/2017');
var setExtent = WBD.filterMetadata('COUNTRY_NA', 'equals', 'Thailand');
Map.addLayer(setExtent, {}, 'Thailand Boundary');
// การดึงข้อมูล Land Cover ของประเทศไทย
var landcover = ee.Image('USGS/GFSAD1000_V1').select('landcover').clip(setExtent);
// การกำหนดวันเริ่มต้นและวันสิ้นสุดในการนำไปใช้ในการดึงข้อมูลที่ต้องการ
var StartDate = '2020-01-01';
var EndDate = '2020-12-31';
// การโหลดข้อมูลอนุกรมเวลาของภาพถ่ายดาวเทียม MODIS EVI
var collectionModEvi = ee.ImageCollection('MODIS/006/MOD13Q1')
    .filterDate(StartDate,EndDate)
    .filterBounds(setExtent)
    .select('EVI');
// การโหลดข้อมูลอนุกรมเวลาของภาพถ่ายดาวเทียม MODIS NDVI
var collectionModNDVI = ee.ImageCollection('MODIS/006/MOD13Q1')
    .filterDate(StartDate,EndDate)
    .filterBounds(setExtent)
    .select('NDVI');
// การแสดงผล
Map.centerObject(setExtent, 5);
// การกำหนดค่าสีสำหรับใช้ในการแสดงผลค่า EVI Map A nice 
var palette = [
  'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
  '74A901', '66A000', '529400', '3E8601', '207401', '056201',
  '004C00', '023B01', '012E01', '011D01', '011301'];
Map.addLayer(landcover, {}, 'landcover', true);
// การสร้างส่วนติดต่อผู้ใช้ (Graphic User Interface)
var panel = ui.Panel();
panel.style().set('width', '300px');
// การสร้างแถบด้านข้างในการแสดงผลข้อมูล
var intro = ui.Panel([
  ui.Label({
    value: 'แผนภูมิแสดงข้อมูลอนุกรมเวลาของค่า EVI และ NDVI',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
  ui.Label('กรุณาคลิกตำแหน่งบนแผนที่เพื่อแสดงผลแผนภูมิ')
]);
panel.add(intro);
// การเพิ่มการแสดงผลละติจูด ลองจิจูดในแถบด้านข้าง
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// การสร้างฟังก์ชันเพื่อใช้ในกรณีผู้ใช้คลิกบนแผนที่
Map.onClick(function(coords) {
  // การอัพเดตการแสดงผลค่าละติจูด ลองจิจูดเมื่อผู้ใช้คลิก
  lon.setValue('lon: ' + coords.lon.toFixed(2)),
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  // การสร้างแผนภูมิ MODIS EVI 
  var eviChart = ui.Chart.image.series(collectionModEvi, point, ee.Reducer.mean(), 250);
  eviChart.setOptions({
    title: 'MODIS EVI',
    vAxis: {title: 'EVI', maxValue: 9000},
    hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
  });
  panel.widgets().set(2, eviChart);
  // การสร้างแผนภูมิ MODIS NDVI
  var ndviChart = ui.Chart.image.series(collectionModNDVI, point, ee.Reducer.mean(), 250);
  ndviChart.setOptions({
    title: 'MODIS NDVI',
    vAxis: {title: 'NDVI', maxValue: 9000},
    hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
  });
  panel.widgets().set(3, ndviChart);
});
Map.style().set('cursor', 'crosshair');
// การเพิ่มแถบด้านข้างไปในส่วนติดต่อผู้ใช้
ui.root.insert(0, panel);