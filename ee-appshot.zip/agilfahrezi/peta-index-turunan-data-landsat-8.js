var l8 = ui.import && ui.import("l8", "imageCollection", {
      "id": "LANDSAT/LC08/C01/T1_SR"
    }) || ee.ImageCollection("LANDSAT/LC08/C01/T1_SR"),
    citarum = ui.import && ui.import("citarum", "table", {
      "id": "users/agilfahrezi/DASCitarum"
    }) || ee.FeatureCollection("users/agilfahrezi/DASCitarum"),
    bluetogreen = ui.import && ui.import("bluetogreen", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI Citarum"
        ],
        "min": -1,
        "palette": [
          "0400ff",
          "23ffff",
          "e9e9e9",
          "4bff49",
          "1ea505"
        ]
      }
    }) || {"opacity":1,"bands":["NDVI Citarum"],"min":-1,"palette":["0400ff","23ffff","e9e9e9","4bff49","1ea505"]},
    srtm = ui.import && ui.import("srtm", "image", {
      "id": "USGS/SRTMGL1_003"
    }) || ee.Image("USGS/SRTMGL1_003"),
    srtmvis = ui.import && ui.import("srtmvis", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "elevation"
        ],
        "min": 0,
        "max": 2500,
        "palette": [
          "21b418",
          "59ff3b",
          "fcff21",
          "ffa929",
          "f90f0f"
        ]
      }
    }) || {"opacity":1,"bands":["elevation"],"min":0,"max":2500,"palette":["21b418","59ff3b","fcff21","ffa929","f90f0f"]},
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B4",
          "B3",
          "B2"
        ],
        "min": 28.29,
        "max": 1266.21,
        "gamma": 1.4840000000000002
      }
    }) || {"opacity":1,"bands":["B4","B3","B2"],"min":28.29,"max":1266.21,"gamma":1.4840000000000002},
    image = ui.import && ui.import("image", "image", {
      "id": "USGS/SRTMGL1_003"
    }) || ee.Image("USGS/SRTMGL1_003"),
    ndbivis = ui.import && ui.import("ndbivis", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B6"
        ],
        "min": -0.41144051751762434,
        "max": 0.018973104397854934,
        "palette": [
          "ff0404",
          "ff6218",
          "fff939",
          "93ff31",
          "3eba4d"
        ]
      }
    }) || {"opacity":1,"bands":["B6"],"min":-0.41144051751762434,"max":0.018973104397854934,"palette":["ff0404","ff6218","fff939","93ff31","3eba4d"]},
    buvis = ui.import && ui.import("buvis", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI Citarum"
        ],
        "min": 0.29594976718593147,
        "max": 1.3143481292600403,
        "palette": [
          "ff0000",
          "ff9221",
          "fcff35",
          "5cff27",
          "1db128"
        ]
      }
    }) || {"opacity":1,"bands":["NDVI Citarum"],"min":0.29594976718593147,"max":1.3143481292600403,"palette":["ff0000","ff9221","fcff35","5cff27","1db128"]},
    mndwivis = ui.import && ui.import("mndwivis", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B3"
        ],
        "min": 882.3749726447074,
        "max": 2386.524526068649,
        "palette": [
          "1e16a5",
          "2bffff",
          "ffffff",
          "5cff49",
          "3dab29"
        ]
      }
    }) || {"opacity":1,"bands":["B3"],"min":882.3749726447074,"max":2386.524526068649,"palette":["1e16a5","2bffff","ffffff","5cff49","3dab29"]},
    ndvivis = ui.import && ui.import("ndvivis", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI Citarum"
        ],
        "min": 0.2855564210201652,
        "max": 0.9322740623060338,
        "palette": [
          "ff0c0c",
          "ff8319",
          "fcff29",
          "8aff1f",
          "2bb32f"
        ]
      }
    }) || {"opacity":1,"bands":["NDVI Citarum"],"min":0.2855564210201652,"max":0.9322740623060338,"palette":["ff0c0c","ff8319","fcff29","8aff1f","2bb32f"]};
//Memilih waktu perekaman, memotong citra, memilih awan
var l8 = l8.filterDate('2019-01-01', '2020-03-20')
          .filterBounds(citarum)
          .filterMetadata('CLOUD_COVER_LAND', 'less_than', 3)
          .median()
          .clip(citarum);
//menambahkan citra
Map.addLayer(l8, imageVisParam2,'RGB');
//Perhitunga NDVI
var NIR = l8.select ('B5');
var Red = l8.select ('B4');
var ndvi = NIR.subtract(Red).divide((NIR).add(Red)).rename('NDVI Citarum');
//Nilai NDVI
var ndviParam = {min:-1, max:1, palette: ["0400ff","23ffff","e9e9e9","4bff49","1ea505"]};
//menambahkan ke peta
Map.addLayer(ndvi, ndvivis, 'NDVI Citarum');
//NDBI
var swir = l8.select('B6');
var nir = l8.select('B5');
var ndbi = swir.subtract(nir).divide((swir).add(nir));
//Nilai NDBI
var ndbiparam = {min:-1, max:1};
//Menambahkan ke peta
Map.addLayer(ndbi, ndbivis, 'NDBI Citarum');
//membuat dan menampilkan buildup index
var bu = ndvi.subtract(ndbi);
var buParam = {min:-1, max:1};
Map.addLayer(bu, buvis, "Build-Up Index");
//Membuat dan melakukan visualisasi SRTM
var srtm = srtm.clip(citarum);
Map.addLayer(srtm, srtmvis, 'Ketinggian');
//Membuat MNDWI (Modifies Normalized Difference Water Index)
var green = l8.select('B3');
var swir = l8.select('B6');
var mndwi = green.subtract(swir).divide(green).add(swir);
//Tambahkan ke peta
var mndwiParam = {min:-1, max:1};
Map.addLayer(mndwi, mndwivis, 'MNDWI');
// setting posisi panel legenda
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// membuat judul legenda
var legendTitle = ui.Label({
  value: 'Legenda',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
//Membuat Legenda NDVI NDBI
// membuat judul di panel
legend.add(legendTitle);
// membuat style row.
var makeRow = function(color, name) {
// membuat label yang ada di kotak.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
// membuat padding yang menjadi kotak.
          padding: '10px',
          margin: '0 0 6px 0'
        }
      });
// membuat label yang diisi dengan text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
// return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette =['ff0c0c','ff8319','fcff29','8aff1f','2bb32f', 
              '1e16a5','2bffff','ffffff','5cff49','3dab29' ];
// name of the legend
var names = ['Sangat Rendah','rendah','Sedang','Tinggi','Sangat Tinggi',
              'Sangat Basah', 'Basah', 'Sedang', 'Kering', 'Sangat Kering'];
// Add color and and names
for (var i = 0; i < 10; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend);
// Create the title label.
var title = ui.Label('Index DAS Citarum');
title.style().set('position', 'top-center');
var Label = ui.Label({
  value: 'Index Turunan Data Landsat 8 OLI/TIRS di Daerah Aliran Sungai Citarum Tahun 2019',
  style:  {
    fontWeight: 'bold',
    fontSize: '20px',
     margin: '0 0 0 0',
    padding: '0',
    }
}) ;
// add legend to map (alternatively you can also print the legend to the console)
Map.add(Label);