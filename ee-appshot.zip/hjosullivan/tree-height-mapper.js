var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                11.935262547349232,
                43.87333457349713
              ],
              [
                11.774244175767201,
                43.86219637670376
              ],
              [
                11.788663731431264,
                43.805730859674675
              ],
              [
                12.013883457993764,
                43.81365906755222
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#bf04c2",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #bf04c2 */ee.Geometry.Polygon(
        [[[11.935262547349232, 43.87333457349713],
          [11.774244175767201, 43.86219637670376],
          [11.788663731431264, 43.805730859674675],
          [12.013883457993764, 43.81365906755222]]]);
// Functions
// UI to run the following function
//function globalTreeHmapping(aoi, year, start_date, end_date, cloudsTh, quantile, scale)
// Draw AOI 
function drawCustomAoi(){
   while (Map.drawingTools().layers().length() > 0) {
    Map.drawingTools().layers().remove(Map.drawingTools().layers().get(0));
   } 
   function f() {
   // Map.onClick();
   // turns drawing off.
   // Map.drawingTools().setShape(null);
   }
 Map.drawingTools().onDraw(ui.util.debounce(f, 500));
 Map.drawingTools().setShape('polygon');
 Map.drawingTools().setLinked(true);
 Map.drawingTools().draw();
}
// load inputs
function loadInputs(){
var u_chooseAoi               = chooseAoiCheckSelector          .getValue();
var u_aoiImage                = aoiTexbox                       .getValue();
var u_choose_model             = selectmodel                   .getValue();
var u_year                    = YearTexbox                     .getValue();
var u_start_date               = startDateTexbox               .getValue();
var u_end_date                = endDateTexbox                  .getValue();
var u_cloud_threshold          = cloudThresholdSlider         .getValue();
var u_quantile                = quantileSlider                .getValue();
var u_scale                   = scaleSlider                   .getValue();
//var u_DownloadOutput          = u_DownloadOutputCheckbox         .getValue();
//var u_outputFolder            = u_outputFolderTexbox             .getValue();
// adjust inputs
var u_aoi;
if (u_chooseAoi == 'Upload'){
  u_aoiImage = ee.FeatureCollection(u_aoiImage);
  u_aoi = u_aoiImage.geometry();  
}else if (u_chooseAoi == 'Draw'){
  u_aoi = Map.drawingTools().layers().get(0).getEeObject();
}
u_choose_model     = String(u_choose_model     );
u_year             = Number(u_year             );
u_start_date       = String(u_start_date);
u_end_date         = String(u_end_date);
u_cloud_threshold  = Number(u_cloud_threshold  );
u_quantile         = "rh"+u_quantile;
//file_name = ee.String("my_file_").cat(date_string);
//u_quantile         = String("rh", u_quantile   );
u_scale            = Number(u_scale            );
  return { 
          u_chooseAoi              : u_chooseAoi, // aoi path
          u_aoiImage               : u_aoiImage, // template image
          u_aoi                    : u_aoi, // general aoi
          u_choose_model           : u_choose_model,
          u_year                   : u_year,
          u_start_date             : u_start_date,
          u_end_date               : u_end_date,
          u_cloud_threshold        : u_cloud_threshold,
          u_quantile               : u_quantile,
          u_scale                  : u_scale,
          //u_DownloadOutput         : u_DownloadOutput,
          //u_outputFolder           : u_outputFolder
          };
}
// Run the model
function mapheigts(){
  var Inputs = loadInputs();
  print(Inputs);
  var library = require("users/hjosullivan/GEE-summer-school:tree_heights_app"); 
  //if(Inputs.u_chooseAoi!="Global"){Map.centerObject(Inputs.u_aoi, 8)}
  var tree_heights = library.globalTreeHmapping(Inputs.u_aoi, Inputs.u_year, Inputs.u_start_date, 
  Inputs.u_end_date, Inputs.u_cloud_threshold, Inputs.u_quantile,  Inputs.u_scale, Inputs.u_choose_model);
}
function removeLayers(){
  // while (Map.drawingTools().layers().length() > 0) {
  // Map.drawingTools().layers().remove(Map.drawingTools().layers().get(0));
  // } 
  Map.clear();
  var widgets = ui.root.widgets();
  if (widgets.length()>3){
  ui.root.remove(ui.root.widgets().get(3));
  }
}
// UI for Tree Heights map
// Add title
var Title = ui.Label({value: "GEDI Global Tree Height Mapper", style:{
backgroundColor : "#424457", color: "white", fontSize: "18px", fontFamily: "monospace"}});
// Add subtitle 
var Subtitle = ui.Label({value: "Select/upload a geometry to predict tree height", style:{
backgroundColor : "#424457", color: "white", fontFamily: "monospace"}});
// Add AOI
// path to file textbox
var aoiTexbox = ui.Textbox({
  placeholder: 'Area of interest (image)',
  value: 'users/spatialanalysis/AM',
  style: {shown: true, width: '250px'}
});
// select options for AOI  
var chooseAoiCheckSelector = ui.Select({
 items: [
   {label: 'Draw study area', value: "Draw"},
   {label: 'Upload template ', value: "Upload"}
   ]}).setValue("Upload");
chooseAoiCheckSelector.onChange(function(aoiOption){   
                         if(aoiOption=="Upload"){
                           aoiTexbox.style().set('shown', true);
                           aoiTexbox.setValue('users/spatialanalysis/AM');
                           //u_DownloadOutputCheckbox.style().set('shown', true);
                           //runDrawNewStdyArea.style().set('shown', false);
                           //u_DownloadOutputCheckbox.setValue(false);
                           Map.drawingTools().setShape(null);
                         }
                         if(aoiOption=="Draw"){
                           aoiTexbox.style().set('shown', false);
                           aoiTexbox.setValue('none');
                           //u_DownloadOutputCheckbox.style().set('shown', true);
                           //u_DownloadOutputCheckbox.setValue(false);
                           aoiTexbox.setValue('Draw');
                           //runDrawNewStdyArea.style().set('shown', true);
                           drawCustomAoi();
                         }
                       });
// Add year
var YearTexbox = ui.Select({
  items: [
    //{label: '2015',       value: "2015"},
    //{label: '2016',       value: "2016"},
    {label: '2017',       value: "2017"},
    {label: '2018',       value: "2018"},
    {label: '2019',       value: "2019"},
    {label: '2020',       value: "2020"},
    {label: '2021',       value: "2021"},
    {label: '2022',       value: "2022"}
    ]}).setValue("2021");
// Add model selection
var selectmodel = ui.Select({
items: [
     {label: 'Random Forest',       value: "RF"},
     {label: 'CART',       value: "SC"},
     {label: 'Gradient Boosting',       value: "GB"}
     ]}).setValue("GB");
// Add start and end date     
var startDateTexbox = ui.Textbox({
placeholder: 'startDate (e.g. 05-20)',
value: '07-01',
style: {width: '155px'}});
var endDateTexbox = ui.Textbox({
placeholder: 'endDate (e.g. 09-20)',
value: '08-31',
style: {width: '155px'}});
// Define aesthetics
var cloudThresholdSlider = ui.Slider({min: 0, max: 100, value:70, step: 1,
                            style: { width: '165px', backgroundColor : "#424457", color: "white"}});
var cloudThresholdLabel = ui.Label({value: "Maximum percentage of clouds in the image", 
                  style:{backgroundColor : "#424457", color: "white", shown: true, fontFamily: "monospace"}});
var quantileSlider = ui.Slider({min: 0, max: 99, value:20, step: 1,
                            style: { width: '165px', backgroundColor : "#424457", color: "white"}});
var quantileLabel = ui.Label({value: "Relative height quantile (m)", 
                  style:{backgroundColor : "#424457", color: "white", shown: true, fontFamily: "monospace"}});
var scaleSlider = ui.Slider({min: 0, max: 1000, step: 5, value:100,
style: { width: '195px', backgroundColor : "#424457", color: "white", shown: true}});
var scaleLabel = ui.Label({value: "Scale (m)", 
                  style:{backgroundColor : "#424457", color: "white", shown: true, fontFamily: "monospace"}});
// global  panel
var panel = ui.Panel({style: {width: '30%', backgroundColor: "#424457", 
border: '2px solid black', textAlign: "center", whiteSpace: "nowrap", shown: true}});
// var testdata = ee.List([0, 1, 2, 3, 4, 5]);
// var chart = ui.Chart.array.values(testdata, 0, testdata);
// var chartPanel = ui.Panel(chart);
// chartPanel.style().set({
//   width:"400px",
//   //position: "bottom"
// })
// Scatter plot
// Make a scatter plot 
// var chart = ui.Chart.array.values({
//   array: trueValues,
//   axis: 0,
//   xLabels: predictedValues})
//   .setChartType('ScatterChart')
//   .setOptions({
//     title: 'Relationship among predicted Values and true Values',
//     legend: {position: 'none'},
//     hAxis: {'title': 'trueValues'},
//     vAxis: {'title': 'predictedValues'},
//     series: {
//       0: {
//         pointSize: 3,
//         dataOpacity: 0.5,
//       },
//       1: {
//         pointSize: 3,
//         lineWidth: 2,
//       }
//     }
//   });
var library = require("users/hjosullivan/GEE-summer-school:tree_heights_app");
//var chartPanel = ui.Panel(library.scatterChart);
//print(chartPanel);
var tvalues= library.trueValues
print(tvalues);
// chartPanel.style().set({
//   width:"400px",
//   position: "bottom-left"
// })
// Run boxes 
var runTreeHeights = ui.Button('Run');
runTreeHeights.onClick(mapheigts);  
var removeLayersButton = ui.Button('Reset');
//var runDrawNewStdyArea = ui.Button({
//   label: 'Reset study area',
//   onClick: drawNewStdyArea,
//   style: {shown: false}
// }); 
// Add boxes
panel.add(Title);
panel.add(Subtitle);
panel.add(chooseAoiCheckSelector);
panel.add(aoiTexbox);
panel.add(selectmodel);
panel.add(YearTexbox);
panel.add(startDateTexbox);
panel.add(endDateTexbox);
panel.add(cloudThresholdLabel);
panel.add(cloudThresholdSlider);
panel.add(quantileLabel);
panel.add(quantileSlider);
panel.add(scaleLabel);
panel.add(scaleSlider);
panel.add(runTreeHeights);
//panel.add(chartPanel);
panel.add(removeLayersButton);
ui.root.add(panel);
// end