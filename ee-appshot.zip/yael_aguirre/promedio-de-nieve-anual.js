var ROI = ui.import && ui.import("ROI", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -71.633,
                -33.2
              ],
              [
                -71.633,
                -32.229
              ],
              [
                -69.943,
                -32.229
              ],
              [
                -69.943,
                -33.2
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-71.633, -33.2],
          [-71.633, -32.229],
          [-69.943, -32.229],
          [-69.943, -33.2]]]),
    aconcagua = ui.import && ui.import("aconcagua", "table", {
      "id": "users/yael_aguirre/Cuenca_rio_Aconcagua"
    }) || ee.FeatureCollection("users/yael_aguirre/Cuenca_rio_Aconcagua"),
    hidro_aconcagua = ui.import && ui.import("hidro_aconcagua", "table", {
      "id": "users/yael_aguirre/hidro_principal_aconcagua"
    }) || ee.FeatureCollection("users/yael_aguirre/hidro_principal_aconcagua"),
    ciudades_aconcagua = ui.import && ui.import("ciudades_aconcagua", "table", {
      "id": "users/yael_aguirre/Ciudades_aconcagua"
    }) || ee.FeatureCollection("users/yael_aguirre/Ciudades_aconcagua");
//-----------------------------------------------------------------------------------------------------------------
//ANIMACIONES GIF CON ETIQUETAS/MODIS
//ANIMATION GIF WITH LABEL/MODIS
//Yael Aguirre
//Actualizado:12-02-21
//---------------------------------------------------------------------------------------------------------
//Centar el mapa /Center the map
Map.addLayer(aconcagua,{}, 'Aconcagua');
Map.centerObject(aconcagua,9);
//Definir colección 6 MOD10A1 /Define MOD10A1 Collection 6.
var colMODIS = ee.ImageCollection('MODIS/006/MOD10A1')
                 .select('NDSI_Snow_Cover'); //Banda de nieve
//Agregar colección de entidades-FeatureCollection
//Hidrologia /Hidrology
var hidro_A = ee.FeatureCollection('users/yael_aguirre/hidro_principal_aconcagua');
Map.addLayer(hidro_A,{}, "hidrologia_Aconcagua");
//Ciudades /Cities
//var ciudades_A = ee.FeatureCollection('users/yael_aguirre/Ciudades_aconcagua');
//Map.addLayer(ciudades_A,{}, "ciudades_Aconcagua");
//Muestra la primera imagen de la colección
//print(colMODIS.first());
//Promedio SC /Overall SCI mean
//var SCmean = colMODIS.mean();
//print('SC_Mean', SCImean);
//Map.addLayer(SCmean.clip(aconcagua), {}, 'SC mean');
//Cuenta todas las imágenes disponibles de la colección
var count = colMODIS.size();
print('Count: ', count);
//---------------------------------------------------------------------------------------------------------------
//Rango de años /Years time range
var years = ee.List.sequence(2000, 2020);
//Calcular ICN anual, crea una colección con 1 imagen para cada año 
//Calculate yearly SCI, create a collection with 1 image for each year
var byYear = ee.ImageCollection.fromImages(
  years.map(function(y) {
    var start = ee.Date.fromYMD(y, 1, 1);
    var end = start.advance(12, 'month');
    return colMODIS.filterDate(start, end)
       .select('NDSI_Snow_Cover').mean()//.clip(geometry)
       .set('year',y)
       .set({ 'system:time_start': start.millis() });
}));
print('ICNbyYear', byYear);
//-----------------------------------------------------------------------------------------------------------
//Se declara una variable especificando el año  
var IMG2000 = ee.Image(byYear.filter(ee.Filter.eq('year', 2000)).first());
var IMG2001 = ee.Image(byYear.filter(ee.Filter.eq('year', 2001)).first());
var IMG2002 = ee.Image(byYear.filter(ee.Filter.eq('year', 2002)).first());
var IMG2003 = ee.Image(byYear.filter(ee.Filter.eq('year', 2003)).first());
var IMG2004 = ee.Image(byYear.filter(ee.Filter.eq('year', 2004)).first());
var IMG2005 = ee.Image(byYear.filter(ee.Filter.eq('year', 2005)).first());
var IMG2006 = ee.Image(byYear.filter(ee.Filter.eq('year', 2006)).first());
var IMG2007 = ee.Image(byYear.filter(ee.Filter.eq('year', 2007)).first());
var IMG2008 = ee.Image(byYear.filter(ee.Filter.eq('year', 2008)).first());
var IMG2009 = ee.Image(byYear.filter(ee.Filter.eq('year', 2009)).first());
var IMG2010 = ee.Image(byYear.filter(ee.Filter.eq('year', 2010)).first());
var IMG2011 = ee.Image(byYear.filter(ee.Filter.eq('year', 2011)).first());
var IMG2012 = ee.Image(byYear.filter(ee.Filter.eq('year', 2012)).first());
var IMG2013 = ee.Image(byYear.filter(ee.Filter.eq('year', 2013)).first());
var IMG2014 = ee.Image(byYear.filter(ee.Filter.eq('year', 2014)).first());
var IMG2015 = ee.Image(byYear.filter(ee.Filter.eq('year', 2015)).first());
var IMG2016 = ee.Image(byYear.filter(ee.Filter.eq('year', 2016)).first());
var IMG2017 = ee.Image(byYear.filter(ee.Filter.eq('year', 2017)).first());
var IMG2018 = ee.Image(byYear.filter(ee.Filter.eq('year', 2018)).first());
var IMG2019 = ee.Image(byYear.filter(ee.Filter.eq('year', 2019)).first());
var IMG2020 = ee.Image(byYear.filter(ee.Filter.eq('year', 2020)).first());
//print('year2020', IMG2020);
//------------------------------------------------------------------------------------------------------------
//Exportar la imagen como un activo en GEE
//Export the image to an Earth Engine asset.
Export.image.toAsset({
  image: IMG2020,
  description: 'ICN_2020_MOD10A1',
  assetId: 'ICN_2020_MOD10A1',
  scale: 500,
  region: aconcagua,
});
//-----------------------------------------------------------------------------------------
//Serie de tiempo /Timelapses 2000-2020 
print(
  ui.Chart.image.series({
    imageCollection: byYear,
    region: aconcagua,
    reducer: ee.Reducer.mean(),
    scale: 500,
    xProperty:'year'
  }).setOptions({
    title: 'Frecuencia de presencia de nieve promedio anual 2000-2020 en la cuenca del Rio Aconcagua, usando MODIS',
    vAxis: {title:'Cobertura Nieve (%)'},
    hAxis: {title:'Años', format:0}, 
  })
);
// Count number of bands in each image, if 0 remove from image collection
/*var nullimages = SCIbyYear
    .map(function(image) {
      return image.set('count', image.bandNames().length());//.clip(geometry)
    })
    .filter(ee.Filter.eq('count', 1));
print('nullImages', nullimages);
*/
//Agregar etiqueta al GIF /Add label to GIF
var text = require('users/gena/packages:text');
// get text location
var pt = text.getLocation(ROI, 'left', '20%', '20%'); //Desplazamiento años arriba o abajo 20% /izquierda o derecha 30%
var scale1 = 600; //Define tamaño titulo
var pt1 = text.getLocation(ROI, 'right', '5%', '85%'); //Desplazamiento titulo 5% abajo/ izquierda o derecha 75%
var textVis1 = { fontSize: 18, textColor: 'ffffff',outlineColor: '7aeb34', outlineWidth: 0.5, outlineOpacity: 0.1}; //verde 7aeb34
var title=text.draw('Cobertura de nieve', pt1, scale1, textVis1);
//Crea una visualización de imagenes RGB para utilizarla en el marco de datos 
//Create RGB visualization images for use as animation frames
var rgbVis = byYear.map(function(img) {
  var scale = 600; //Define tamaño años
  var textVis = { fontSize: 14, textColor: 'ffffff', outlineColor: '000000', outlineWidth: 0.1, outlineOpacity: 0.6 };
  var label = text.draw(img.date().format('YYYY'), pt, scale, textVis);
  return img.visualize({bands: ['NDSI_Snow_Cover'],
  min: 0.0, max: 100, 
  palette: [
            'ffffff', //  0 - 10 blanco
            'ffffb4', // 10 - 20 crema pálido
            'ebeba6', // 20 - 30 crema tono oscuro //'ffebbe'
            'ffd37f', // 30 - 40 café crema
            'ffaa00', // 40 - 50 mostaza
            '853212', // 50 - 60 café oscuro
            '22d895', // 60 - 70 turquesa         //21d291  //179164
            '0cbcd8', // 70 - 80 celeste         //14dada
            '027fff', // 80 - 90 azul claro
            '042766', // 90- 100 azul oscuro
           // '00a884', // 70 - 80 verde agua
          //  '0084a8', // 80 - 90 azul
 ],
  })
  .clip(aconcagua)
  .blend(label).blend(title)
  .paint(hidro_A, '0524ff', 0.5); //Muestra una colección de características encima de una imagen
//.paint(ciudades_A);
});
/*
// Define RGB visualization parameters.
var visParams = {
  min: 0.0,
  max: 100.0,
  palette: [
            'fffff0', //  0 - 10
            'ffffb4', // 10 - 20
            'ffebbe', // 20 - 30
            'ffd37f', // 30 - 40
            'ffaa00', // 40 - 50
            'ff9800', // 50 - 60
            '70a800', // 60 - 70
            '00a884', // 70 - 80
            '0084a8', // 80 - 90
            '004c99'  // 90 - 100
 ],
};
// Create RGB visualization images for use as animation frames.
var rgbVis = SCIbyYear.map(function(img) {
  return img.visualize(visParams).clip(aconcagua);
});
*/
//Definir el GIF y visualización de parámetros 
//Define GIF visualization parameters.
var gifParams = {
  'region': ROI,
  'dimensions': 600,
  'crs': 'EPSG:3857',
  'framesPerSecond': 1,
  'format': 'gif'
};
//Imprimir el URL GIF en la consola /Print the GIF URL to the console.
print(rgbVis.getVideoThumbURL(gifParams));
//Elaborar el GIF de animación en la consola/ Render the GIF animation in the console.
print(ui.Thumbnail(rgbVis, gifParams));
//Elaborar el GIF de animación y visualizar en el mapa /Render the GIF animation in the map.
Map.add(ui.Thumbnail(rgbVis, gifParams,null, { position: 'bottom-right'}));