var aconcagua = ui.import && ui.import("aconcagua", "table", {
      "id": "users/yael_aguirre/Cuenca_rio_Aconcagua"
    }) || ee.FeatureCollection("users/yael_aguirre/Cuenca_rio_Aconcagua");
// #####################################################################################
// ############## Curso de Introducción a Google Earth Engine ##########################
// ####              TeleAmb - Universidad de Playa Ancha                           ####
// ####                             Sesión 3                                        ####
// ####                             Creación de Widgets                             ####
// #####################################################################################
// Cargar y mostrar datos NDSI
var ndsi = ee.ImageCollection('MODIS/006/MOD10A1')
             .select('NDSI_Snow_Cover')
             .filterDate('2014-01-01', '2015-01-01')
             .map(function(image){return image.clip(aconcagua)});
Map.addLayer(ndsi.mean(), {min: 0, max: 100, palette: ['black', '0cbcd8']}, 'NDSI');
//Configura el mapa
Map.setCenter(-70.8484, -32.839, 8);
Map.style().set('cursor', 'crosshair');
// Cree un panel vacío en el que organizar los widgets.
// El diseño es de flujo vertical por defecto.
var panel = ui.Panel({style: {width: '400px'}})
    .add(ui.Label('Seleccione click dentro del mapa'));
// Establecer una función de devolución de llamada para cuando el usuario haga clic en el mapa.
Map.onClick(function(coords) {
  // Cree o actualice la etiqueta de ubicación (el segundo widget en el panel) 
  var location = 'longitud: ' + coords.lon.toFixed(2) + ' ' +
                 'latitud: ' + coords.lat.toFixed(2);
  panel.widgets().set(1, ui.Label(location));
  // Agregar un punto rojo al mapa donde el usuario hizo clic.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  Map.layers().set(1, ui.Map.Layer(point, {color: 'FF0000'}));
  // Cree un gráfico de NDSI a lo largo del tiempo.
  var chart = ui.Chart.image.series(ndsi, point, ee.Reducer.mean(), 200)
      .setOptions({
        title: 'Serie de tiempo datos diarios NDSI producto MOD10A1',
        vAxis: {title: 'NDSI'},
        lineWidth: 1,
        pointSize: 3,
      });
 // Agrega o reemplaza el tercer widget en el panel manipulando 
//la lista de widgets.
  panel.widgets().set(2, chart);
});
// Agregue el panel a ui.root.
ui.root.add(panel);