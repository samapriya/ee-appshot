var logo_Observatorio = ui.import && ui.import("logo_Observatorio", "image", {
      "id": "users/observatorionieves/Logos/Logo_Observatorio"
    }) || ee.Image("users/observatorionieves/Logos/Logo_Observatorio"),
    logo_Teleamb = ui.import && ui.import("logo_Teleamb", "image", {
      "id": "users/observatorionieves/Logos/Logo_TeleAmb"
    }) || ee.Image("users/observatorionieves/Logos/Logo_TeleAmb"),
    aconcagua_cuenca = ui.import && ui.import("aconcagua_cuenca", "table", {
      "id": "users/observatorionieves/DGA/aconcagua_cuenca"
    }) || ee.FeatureCollection("users/observatorionieves/DGA/aconcagua_cuenca"),
    aconcagua_ms = ui.import && ui.import("aconcagua_ms", "table", {
      "id": "users/observatorionieves/DGA/aconcagua_subsubcuencas_ms"
    }) || ee.FeatureCollection("users/observatorionieves/DGA/aconcagua_subsubcuencas_ms");
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// A través de un panel este código presenta información anual y mensual: 
// 1) Valor promedio del Indice Normalizado de Nieve (NDSI),
// 2) Promedio del área cubierta de nieve (SCA)
// 3) Promedio de "no datos" productos de la presencia de nubes, ángulo de visión, saturación del sensor, etc.
// Selección personalizada por subsubcuencas sección media-superior cuenca del Río Aconcagua
// Producto MOD10A1 colección 6 de MODIS
// Autora: Yael Aguirre
// Actualizado 18/08/21
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------------------------------------------------------------------------------
/////////////////////////////// DATOS DE ENTRADA (Data input) ////////////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------------------------------------------------------------------------------
// Colección original MODIS Terra
var MODcollection = ee.ImageCollection('MODIS/006/MOD10A1')
                      .select('NDSI_Snow_Cover','Snow_Albedo_Daily_Tile_Class')
                      .filterDate('2000-01-01', '2020-12-31');
// var MYDcollection = ee.ImageCollection('MODIS/006/MYD10A1').select('NDSI_Snow_Cover','Snow_Albedo_Daily_Tile_Class');
// Asset NDSI anual
var MODIS_yearly  = ee.ImageCollection('users/observatorionieves/MODIS/MOD10A1_Snow_Yearly');
// Variable para presentarla al inicio del codigo
var NDSI = MODIS_yearly.select('NDSI_Snow_Cover').mean().clip(aconcagua_ms);
// NDSI promedio utilizado para la selección personalizada
var NDSImean = MODcollection.select('NDSI_Snow_Cover').mean();
// Construye una imagen vacía para utilizarla en el contorno del ROI
var empty = ee.Image().byte();
var outlineC = empty.paint({
    featureCollection: aconcagua_cuenca,
    color: 1,
    width: 1
    });
var outlineSSC = empty.paint({
    featureCollection: aconcagua_ms,
    color: 1,
    width: 1
    });
// Time ranges
var years = ee.List.sequence(2000, 2020);
var months = ee.List.sequence(1, 12);
var umbralNDSI = 40;
// Add colorbars, default hidden.
var SCFpaletteLabels = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
var palette_scf = 'ffffff,ffffd9,edf8b1,c7e9b4,7fcdbb,41b6c4,1d91c0,225ea8,253494,081d58';
var visParams = {
  min: 0.0,
  max: 100.0,
  palette: palette_scf,
};
//---------------------------------------------------------------------------------------------------------------------------------------------------------
//////////////////////////// PARÁMETROS DE VISUALIZACIÓN /////////////////////////////////////////////////////////////////////////////////////
//----------------------------------------------------------------------------------------------------------------------------------------------------------
 Map.addLayer(outlineC, {palette: 'FF0000'}, 'Cuenca Río Aconcagua');
 Map.addLayer(NDSI,visParams, 'NDSI promedio');
 Map.addLayer(outlineSSC,{},'Subsubcuencas cuenca del Río Aconcagua');
 Map.centerObject(aconcagua_cuenca, 8);
//---------------------------------------------------------------------------------------------------------------------------------
////////////////////////////////////////FEATURES///////////////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------------------------------------------------------------------
// Load a FeatureCollection from a table dataset.
var subsubcuencas_ms = ee.FeatureCollection('users/observatorionieves/DGA/aconcagua_subsubcuencas_ms');
// Define subsubwatershed subsubcuencas aconcagua ms 
var ssc05400 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05400')); //05400, Rio Juncal antes junta Estero Juncalillo
var ssc05401 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05401')); //05401, Rio Juncal Antes Junta Estero Juncalillo y Junta Rio Blanco
var ssc05402 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05402')); //05402, Rio Blanco
var ssc05403 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05403')); //05403, Rio Aconcagua entre Rio Blanco y Rio Colorado
var ssc05404 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05404')); //05404, Rio Colorado antes junta Estero Riecillos
var ssc05405 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05405')); //05405, Estero Riecillos
var ssc05406 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05406')); //05406, Rio Colorado Entre Estero Riecillos y Rio Aconcagua
var ssc05410 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05410')); //05410, Rio Aconcagua entre Rio Colorado y Rio Putaendo
var ssc05411 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05411')); //05411, Estero Pocuro
var ssc05412 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05412')); //05412, Rio Putaendo bajo junta Rio Hidalgo
var ssc05413 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05413')); //05413, Rio Putaendo Entre Rio Hidalgo y Bajo Junta Estero Chalaco
var ssc05414 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05414')); //05414, Rio Putaendo Entre Estero Chalaco y Rio Aconcagua
var ssc05415 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05415')); //05416, Estero Seco
var ssc05416 = aconcagua_ms.filter(ee.Filter.eq('COD_SSUBC', '05416')); //05415, Estero Quilpue
//------------------------------------------------------------------------------------------------------------------------------------------
///////////////////////////////////// FUNCIONES ////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////   NODATA  /////////////////////////////////////////////////////////////////////////////////////////////
//------------------------------------------------------------------------------------------------------------------------------------------
var ReclassifyModis = function(img) {
  var nodata = img.remap([101, 111, 125, 137, 139, 150, 151, 250, 251, 252, 253, 254], // Original values MODIS 
                         [100, 100,   0,   0,   0, 100, 100, 100, 100, 100, 100, 100], // Valores reclasificados: 100--cloud/no decision/ missing etc; 0-- land/ocean/inland water 
                          null,                        // All other MODIS snow product pixel values (0, 1, 11, 50, 254, 255)
                         'Snow_Albedo_Daily_Tile_Class').rename('nodata'); // La banda que se quiere reclasificar 
  var snow = img.select('NDSI_Snow_Cover').gte(0).multiply(0).rename('snow');
  var imageTemp = ee.Image.cat([nodata, snow]); // hace una imagen con dos bandas
  var nodata_data = imageTemp.reduce(ee.Reducer.max()).rename('nodata_data'); // reduce a una imagen de una banda sacando el max entre ellas
 return img.addBands(nodata_data);
}; 
var MODcollectionND = MODcollection.map(ReclassifyModis);
//-----------------------------------------------------------------------------------------------------------------------------------------
//////////////////////////////////////// FUNCIONES /////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////  BINARIA /////////////////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------------------------------------------------------------
// Función para identificar y establecer los valores binarios de nieves (MOD10A1)
var snowMask = function(image){
  var snow = image.select('NDSI_Snow_Cover').gte(umbralNDSI).multiply(100).rename('Snow_Cover_Area');
  return image.addBands(snow);
};
//-----------------------------------------------------------------------------------------------------------------------------------------
//////////////////////////////////// REDUCCIÓN DE DATOS ///////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------------------------------------------------------------
// Aplicar máscara de nieve %
var SnowCollection = MODcollectionND.map(snowMask).select('NDSI_Snow_Cover','Snow_Cover_Area','nodata_data');
// Daily NDSI                    
var deca01 = SnowCollection.filterDate("2000-01-01","2010-01-01");
var deca02 = SnowCollection.filterDate("2010-01-01","2022-01-01");
// Monthly NDSI
var NDSIbyMonth = ee.ImageCollection.fromImages(
  months.map(function(m) {
    return SnowCollection
    .filter(ee.Filter.calendarRange(m, m, 'month'))
    .mean()
    .set('month', m)
    .set('system:time_start', ee.Date.fromYMD(m, 1, 1).millis());
  }).flatten());
// print('NDSIbyMonth', NDSIbyMonth);
// Year/month NDSI
var NDSIbyMonthYear = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return months.map(function (m) {
      return SnowCollection
        .filter(ee.Filter.calendarRange(y, y, 'year'))
        .filter(ee.Filter.calendarRange(m, m, 'month'))
        .mean()
        .set('month', m)
        .set('year', y)
        .set('system:time_start', ee.Date.fromYMD(y, m, 1).millis());
  });
}).flatten());
//print('NDSIbyMonthYear', NDSIbyMonthYear);
// Yearly NDSI
var NDSIbyYear = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return SnowCollection
    .filter(ee.Filter.calendarRange(y, y, 'year'))
    .mean()
    .set('year', y)
    .set('system:time_start', ee.Date.fromYMD(y, 1, 1).millis());
    //.clip(ROI);
  }).flatten());
//print('NDSIbyYear', NDSIbyYear);
//-----------------------------------------------------------------------------------------------------------------------------------------
//////////////////////////////////// INTERFAZ DE USUARIO ///////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------------------------------------------------------------
var places = {
  Juncal_Juncalillo : [ssc05400,'Rio Juncal antes junta Estero Juncalillo'],
  Juncal_Blanco     : [ssc05401,'Rio Juncal Antes Junta Estero Juncalillo y Junta Rio Blanco'],
  Rio_Blanco        : [ssc05402,'Rio Blanco'],
  Aconcagua_Colorado: [ssc05403,'Rio Aconcagua entre Rio Blanco y Rio Colorado'],
  Rio_Colorado      : [ssc05404,'Rio Colorado antes junta Estero Riecillos'],
  Estero_Riecillos  : [ssc05405,'Estero Riecillos'],
  Colorado_Riecillo : [ssc05406,'Rio Colorado Entre Estero Riecillos y Rio Aconcagua'],
  Aconcagua_Putaendo: [ssc05410,'Rio Aconcagua entre Rio Colorado y Rio Putaendo'],
  Estero_Pocuro     : [ssc05411,'Estero Pocuro'],
  Putaendo_Hidalgo  : [ssc05412,'Rio Putaendo bajo junta Rio Hidalgo'],
  Putaendo_Chalaco  : [ssc05413,'Rio Putaendo Entre Rio Hidalgo y Bajo Junta Estero Chalaco'],
  Putaendo_Aconcagua: [ssc05414,'Rio Putaendo Entre Estero Chalaco y Rio Aconcagua'],
  Estero_Seco       : [ssc05415,'Estero Seco'],
  Estero_Quilpue    : [ssc05416,'Estero Quilpue'],
};
//---------------------------------------------------------------------------------------------------------------------------------
var place = ui.Select({
  items: Object.keys(places),
  onChange: function(key) {
  Map.clear();
 Map.addLayer(outlineC, {palette: 'FF0000'}, 'Cuenca Río Aconcagua');
 Map.addLayer(outlineSSC,{},'Subsubcuencas cuenca del Río Aconcagua');
    var ROI = places[key][0];
    Map.addLayer(NDSImean.clip(ROI),visParams, 'NDSI Mean');
    var streamflow = ee.FeatureCollection("WWF/HydroSHEDS/v1/FreeFlowingRivers")
                   .filter(ee.Filter.bounds(ROI))
                   .style({color: "B2B2B3", width: 2.0,});
    Map.addLayer(streamflow,{}, 'Red hídrica');
    Map.centerObject(ROI,10);
//-----------------------------------------------------------------------------------------------------------------------------------------
////////////////////////////////////////////// GRÁFICOS ///////////////////////////////////////////////////////////////////
//----------------------------------------------------------------------------------------------------------------------------------------- 
// Daily time serie 2000-2010
var chartDaily01 = 
  ui.Chart.image.series({
    imageCollection: deca01,
    region: ROI,
    reducer: ee.Reducer.mean(),
    scale: 500,
  }).setOptions({
    title: 'NDSI diario, usando MOD10A1. 2000-2010',
    vAxis: {title:'Promedio (%)'},
    hAxis: {title:'Tiempo'}, 
});
// Daily time serie 2011-2020
var chartDaily02 = 
  ui.Chart.image.series({
    imageCollection: deca02,
    region: ROI,
    reducer: ee.Reducer.mean(),
    scale: 500,
  }).setOptions({
    title: 'NDSI diario, usando MOD10A1. 2010-2020',
    vAxis: {title:'Promedio (%)'},
    hAxis: {title:'Tiempo'}, 
});
// Monthly time serie 2000-2020
var chartMonth =
  ui.Chart.image.series({
    imageCollection: NDSIbyMonth,
    region: ROI,
    reducer: ee.Reducer.mean(),
    scale: 500,
    xProperty:'month'
  }).setOptions({
    title: 'Promedios mensuales NDSI y Snowcover, usando MOD10A1. 2000-2020',
    curveType: 'function',
    vAxis: {title:'Promedio (%)'},
    hAxis: {title:'Tiempo'}, 
});
// Year/month time serie 2000-2020 
var chartYearMonth = 
  ui.Chart.image.series({
    imageCollection: NDSIbyMonthYear,
    region: ROI,
    reducer: ee.Reducer.mean(),
    scale: 500,
  }).setOptions({
    title: 'Promedios mensuales por año NDSI y Snowcover, usando MOD10A1. 2000-2020',
    curveType: 'function',
    vAxis: {title:'Promedio (%)'},
    hAxis: {title:'Tiempo'}, 
});
// Yearly time serie 2000-2022
var chartYear =
  ui.Chart.image.series({
    imageCollection: NDSIbyYear,
    region: ROI,
    reducer: ee.Reducer.mean(),
    scale: 500,
  }).setOptions({
    title: 'Promedios anuales NDSI y Snowcover, usando MOD10A1. 2000-2020',
    curveType: 'function',
    vAxis: {title:'Promedio (%)'},
    hAxis: {title:'Tiempo'}, 
});
    panel.clear();
    panel.add(logo_observatorio);
    panel.add(link);
    panel.add(intro);
    panel.add(description);
    panel.add(placeLabel);
    panel.add(place);
    panel.add(chartYear);
    panel.add(chartYearMonth);
    panel.add(chartMonth);
//  panel.add(chartDaily01);    
//  panel.add(chartDaily02);
    Map.add(makeLegend('Frecuencia de nieve', SCFpaletteLabels, palette_scf, 0, 1, 'top-left'));
}
});
// Set a place holder.
place.setPlaceholder('Seleccione subsubcuencas');
//-----------------------------------------------------------------------------------------------------------------------------------------
/////////////////////////////////////// WIDGET PANEL ////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------------------------------------------------------------
// Create UI Panels
var panel = ui.Panel({style: {width:'25.0%'}});
ui.root.insert(0,panel);
// Introduction 
var intro = ui.Label('Observatorio Satelital de Nieves', 
  {fontWeight: 'bold', fontSize: '24px', margin: '10px 5px'}
);
var description = ui.Label('A partir de imágenes diarias del sensor satelital MODIS (MOD10A1)'+
  ' se determina la variabilidad espacio temporal de nieves sobre la sección media-superior de la cuenca del Río Aconcagua.'+
  ' Se presenta la información del valor promedio del Indice Normalizado de Nieve (NDSI),'+
  ' el promedio del área cubierta de nieve (SCA) considerando un NDSI>40 y el promedio de "no datos" productos'+
  ' de la presencia de nubes, ángulo de visión, saturación del sensor, etc.'+
  ' El periodo de medición comprende desde el 2000-2020, entregando información a una escala anual y mensual.' +
  ' Puede personalizar su búsqueda seleccionando las subsubcuencas de su área de interés.', {});
var placeLabel = ui.Label('1) Seleccione área de interés', 
  {fontWeight: 'bold', fontSize: '18px', margin: '10px 5px'}
);
////////////////////////////////////////////////////////// PANEL INICIAL ///////////////////////////////////////////////////////////////////
// Define link para thumbnail
var link = ui.Label('Observatorio Satelital de Nieve', {},'http://observatorionieves.cl/');
// Logo Observatorio 
var logo_observatorio = ui.Thumbnail({image:logo_Observatorio,params:{dimensions: '250x114', bands:['b1','b2','b3'],min:0,max:255}, style:{width:'250px',height:'114px',padding :'0'}});
// Logo Teleamb 
var logo_teleamb = ui.Thumbnail({image:logo_Teleamb,params:{dimensions: '300x93', bands:['b1','b2','b3'],min:0,max:255}, style:{width:'300px',height:'93px',padding :'0'}});
panel.add(logo_observatorio);
panel.add(link);
panel.add(intro);
panel.add(description);
panel.add(placeLabel);
panel.add(place);
panel.add(logo_teleamb);
//-----------------------------------------------------------------------------------------------------------------------------------------
//////////////////////////////////////////////////// Create labeled colorbar legend ///////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------------------------------------------------------------
// Create colorbar.
function makeColorBar(palette, min, max) {
  return ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 1, 0.1],
      dimensions: '200x15',
      format: 'png',
      min: min,
      max: max,
      palette: palette,
    },
    style: {stretch: 'horizontal', margin: '0px 0px', position: 'bottom-left'},
  });
}
function makeLegend(title, labels, palette, min, max, position) {
  var labelPanel = ui.Panel();
  for (var i = 0; i < labels.length; i++) {
    var label = ui.Label({
      value: labels[i],
      style: {
        maxWidth: '35px',
        margin: '4px 4px',
        position: 'bottom-left'
      }
    });
    labelPanel.add(label);
  }
  labelPanel.setLayout(ui.Panel.Layout.flow('horizontal'));
  var titleLabel = ui.Label({
    value: title,
    style: {
      fontSize: '14px',
      fontWeight: 'bold',
      position: 'top-center'
    }
  });
  return ui.Panel({
    widgets: [titleLabel, makeColorBar(palette, min, max), labelPanel],
    style: {position: position}
  });
}