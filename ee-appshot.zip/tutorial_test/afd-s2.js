var cl = ui.import && ui.import("cl", "image", {
      "id": "users/tutorial_test/climate_zone/Beck_KG_V1_present_0p083"
    }) || ee.Image("users/tutorial_test/climate_zone/Beck_KG_V1_present_0p083"),
    ba = ui.import && ui.import("ba", "imageCollection", {
      "id": "MODIS/006/MCD64A1"
    }) || ee.ImageCollection("MODIS/006/MCD64A1"),
    s2 = ui.import && ui.import("s2", "imageCollection", {
      "id": "COPERNICUS/S2"
    }) || ee.ImageCollection("COPERNICUS/S2"),
    firms = ui.import && ui.import("firms", "imageCollection", {
      "id": "FIRMS"
    }) || ee.ImageCollection("FIRMS"),
    s2_vis = ui.import && ui.import("s2_vis", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B12",
          "B11",
          "B8A"
        ],
        "min": 0.0745920006930828,
        "max": 0.4198079864680767,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B12","B11","B8A"],"min":0.0745920006930828,"max":0.4198079864680767,"gamma":1},
    s2_vis_true = ui.import && ui.import("s2_vis_true", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B4",
          "B3",
          "B2"
        ],
        "min": 0.032149999625980856,
        "max": 0.46174999583512544,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B4","B3","B2"],"min":0.032149999625980856,"max":0.46174999583512544,"gamma":1},
    L8_vis = ui.import && ui.import("L8_vis", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B7",
          "B6",
          "B5"
        ],
        "min": 0.07374356180429459,
        "max": 0.30234048277139663,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B7","B6","B5"],"min":0.07374356180429459,"max":0.30234048277139663,"gamma":1},
    Congo = ui.import && ui.import("Congo", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                15.452562115221895,
                -2.891267295697806
              ],
              [
                15.452562115221895,
                -2.9560708326669656
              ],
              [
                15.51436021092502,
                -2.9560708326669656
              ],
              [
                15.51436021092502,
                -2.891267295697806
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #98ff00 */ee.Geometry.Polygon(
        [[[15.452562115221895, -2.891267295697806],
          [15.452562115221895, -2.9560708326669656],
          [15.51436021092502, -2.9560708326669656],
          [15.51436021092502, -2.891267295697806]]], null, false),
    Ind = ui.import && ui.import("Ind", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                114.7840099985566,
                -3.2049689798896925
              ],
              [
                114.7840099985566,
                -3.26803960482314
              ],
              [
                114.94056517433785,
                -3.26803960482314
              ],
              [
                114.94056517433785,
                -3.2049689798896925
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[114.7840099985566, -3.2049689798896925],
          [114.7840099985566, -3.26803960482314],
          [114.94056517433785, -3.26803960482314],
          [114.94056517433785, -3.2049689798896925]]], null, false),
    Aus = ui.import && ui.import("Aus", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                135.99828373176626,
                -15.47853208533497
              ],
              [
                135.99828373176626,
                -15.713646743791074
              ],
              [
                136.15792881233267,
                -15.713646743791074
              ],
              [
                136.15792881233267,
                -15.47853208533497
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[135.99828373176626, -15.47853208533497],
          [135.99828373176626, -15.713646743791074],
          [136.15792881233267, -15.713646743791074],
          [136.15792881233267, -15.47853208533497]]], null, false),
    Cali = ui.import && ui.import("Cali", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -119.73390922410499,
                34.68224925478291
              ],
              [
                -119.73390922410499,
                34.20205083411461
              ],
              [
                -118.81380424363624,
                34.20205083411461
              ],
              [
                -118.81380424363624,
                34.68224925478291
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-119.73390922410499, 34.68224925478291],
          [-119.73390922410499, 34.20205083411461],
          [-118.81380424363624, 34.20205083411461],
          [-118.81380424363624, 34.68224925478291]]], null, false),
    Sib = ui.import && ui.import("Sib", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                119.48259568342723,
                65.78820620447466
              ],
              [
                119.48259568342723,
                65.34170945571272
              ],
              [
                120.32030320295848,
                65.34170945571272
              ],
              [
                120.32030320295848,
                65.78820620447466
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[119.48259568342723, 65.78820620447466],
          [119.48259568342723, 65.34170945571272],
          [120.32030320295848, 65.34170945571272],
          [120.32030320295848, 65.78820620447466]]], null, false),
    Camp = ui.import && ui.import("Camp", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -121.81560000000002,
                39.9462
              ],
              [
                -121.81628664550783,
                39.595000000000006
              ],
              [
                -121.34730000000002,
                39.595
              ],
              [
                -121.34730000000002,
                39.9462
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-121.81560000000002, 39.9462],
          [-121.81628664550783, 39.595000000000006],
          [-121.34730000000002, 39.595],
          [-121.34730000000002, 39.9462]]]),
    Elephant = ui.import && ui.import("Elephant", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -121.52258824090251,
                50.97575505962509
              ],
              [
                -121.52052696713724,
                50.77378536476736
              ],
              [
                -121.1242425292059,
                50.77465405939213
              ],
              [
                -121.12424242401761,
                50.97488984460536
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-121.52258824090251, 50.97575505962509],
          [-121.52052696713724, 50.77378536476736],
          [-121.1242425292059, 50.77465405939213],
          [-121.12424242401761, 50.97488984460536]]]),
    Geraneia = ui.import && ui.import("Geraneia", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                23.110639752627094,
                38.042641400235134
              ],
              [
                23.110639752627094,
                37.965270569079706
              ],
              [
                23.232004346132953,
                37.965270569079706
              ],
              [
                23.232004346132953,
                38.042641400235134
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[23.110639752627094, 38.042641400235134],
          [23.110639752627094, 37.965270569079706],
          [23.232004346132953, 37.965270569079706],
          [23.232004346132953, 38.042641400235134]]], null, false),
    George = ui.import && ui.import("George", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                22.322384300590784,
                -33.78682165094788
              ],
              [
                22.322384300590784,
                -33.95899330831856
              ],
              [
                22.551037254692346,
                -33.95899330831856
              ],
              [
                22.551037254692346,
                -33.78682165094788
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ffc82d",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[22.322384300590784, -33.78682165094788],
          [22.322384300590784, -33.95899330831856],
          [22.551037254692346, -33.95899330831856],
          [22.551037254692346, -33.78682165094788]]], null, false),
    Charagua = ui.import && ui.import("Charagua", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -60.79153610303172,
                -15.542630274904889
              ],
              [
                -60.79153610303172,
                -15.838783917822147
              ],
              [
                -60.45919967725047,
                -15.838783917822147
              ],
              [
                -60.45919967725047,
                -15.542630274904889
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#00ffff",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-60.79153610303172, -15.542630274904889],
          [-60.79153610303172, -15.838783917822147],
          [-60.45919967725047, -15.838783917822147],
          [-60.45919967725047, -15.542630274904889]]], null, false),
    Noralee = ui.import && ui.import("Noralee", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -125.98811921614987,
                53.88119524005425
              ],
              [
                -125.98811921614987,
                53.81962779817576
              ],
              [
                -125.88443574447018,
                53.81962779817576
              ],
              [
                -125.88443574447018,
                53.88119524005425
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ff0000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff0000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-125.98811921614987, 53.88119524005425],
          [-125.98811921614987, 53.81962779817576],
          [-125.88443574447018, 53.81962779817576],
          [-125.88443574447018, 53.88119524005425]]], null, false),
    Ind_pin = ui.import && ui.import("Ind_pin", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            114.79903036904113,
            -3.2472197688559126
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#00ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ff00 */
    /* shown: false */
    ee.Geometry.Point([114.79903036904113, -3.2472197688559126]),
    Boli_pin = ui.import && ui.import("Boli_pin", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -60.616133200528395,
            -15.624907844145927
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0000ff",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0000ff */
    /* shown: false */
    ee.Geometry.Point([-60.616133200528395, -15.624907844145927]),
    nA_pin = ui.import && ui.import("nA_pin", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            133.03120570523015,
            -14.729258207342006
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#999900",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #999900 */
    /* shown: false */
    ee.Geometry.Point([133.03120570523015, -14.729258207342006]),
    Gree_pin = ui.import && ui.import("Gree_pin", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            23.16682567500129,
            38.01024195076681
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#009999",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #009999 */
    /* shown: false */
    ee.Geometry.Point([23.16682567500129, 38.01024195076681]),
    Camp_pin = ui.import && ui.import("Camp_pin", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -121.39043030141227,
            39.813375381954216
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ff00ff",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff00ff */
    /* shown: false */
    ee.Geometry.Point([-121.39043030141227, 39.813375381954216]),
    SA_pin = ui.import && ui.import("SA_pin", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            22.4315609363332,
            -33.87022327841275
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ff9999",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff9999 */
    /* shown: false */
    ee.Geometry.Point([22.4315609363332, -33.87022327841275]),
    BC_pin = ui.import && ui.import("BC_pin", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -125.94726380843201,
            53.84595936765333
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#99ff99",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #99ff99 */
    /* shown: false */
    ee.Geometry.Point([-125.94726380843201, 53.84595936765333]),
    Sib_pin = ui.import && ui.import("Sib_pin", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            119.69465838530834,
            65.65746167722543
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#9999ff",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #9999ff */
    /* shown: false */
    ee.Geometry.Point([119.69465838530834, 65.65746167722543]),
    Aus2 = ui.import && ui.import("Aus2", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                132.8442700823456,
                -14.577083914197445
              ],
              [
                132.8442700823456,
                -14.885214399042145
              ],
              [
                133.2452710589081,
                -14.885214399042145
              ],
              [
                133.2452710589081,
                -14.577083914197445
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[132.8442700823456, -14.577083914197445],
          [132.8442700823456, -14.885214399042145],
          [133.2452710589081, -14.885214399042145],
          [133.2452710589081, -14.577083914197445]]], null, false),
    firms_vis = ui.import && ui.import("firms_vis", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "vis-red",
          "vis-green",
          "vis-blue"
        ],
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["vis-red","vis-green","vis-blue"],"gamma":1},
    s2_vis_swir = ui.import && ui.import("s2_vis_swir", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B12",
          "B11",
          "B12"
        ],
        "min": 0.06539999693632126,
        "max": 1.3645000457763672,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B12","B11","B12"],"min":0.06539999693632126,"max":1.3645000457763672,"gamma":1},
    Kangaroo = ui.import && ui.import("Kangaroo", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            137.00917482480463,
            -35.713692170475376
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([137.00917482480463, -35.713692170475376]),
    Mallacoota = ui.import && ui.import("Mallacoota", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            147.93284708945305,
            -37.59557509545945
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Point([147.93284708945305, -37.59557509545945]),
    NewCastle = ui.import && ui.import("NewCastle", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            150.3863,
            -33.0628
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Point([150.3863, -33.0628]),
    AZ_pin = ui.import && ui.import("AZ_pin", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -111.38742218017578,
            33.76998943780156
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Point([-111.38742218017578, 33.76998943780156]),
    MG_pin = ui.import && ui.import("MG_pin", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -112.3,
            36.7
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #98ff00 */ee.Geometry.Point([-112.3, 36.7]),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B12",
          "B11",
          "B12"
        ],
        "min": 0.07330104019342354,
        "max": 0.2592261323228595,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B12","B11","B12"],"min":0.07330104019342354,"max":0.2592261323228595,"gamma":1};
/////////// Functions ///////////////////
function img2fc(img, roi, scale){
  img = img.reduce(ee.Reducer.anyNonZero())
  // Map.addLayer(img,{},"img_tep_nonzero",false)
  var poly = img.reduceToVectors({
  geometry: roi, 
  scale: scale,
  crs:"EPSG:3857",
  geometryType: 'polygon',
  maxPixels:1e9,
  // geometryInNativeProjection:true
  })
  poly = ee.FeatureCollection(poly);
  return poly;
}
function getDateString(img){
  var yy = ee.String(img.date().get("year"))
  var mm = ee.String(img.date().get("month"))
  var dd = ee.String(img.date().get("day"))
  // var hh = ee.String(img.date().get("hour"))
  // var minute = ee.String(img.date().get("minute"))
  var dateString = yy.cat("-").cat(mm).cat("-").cat(dd)
  // .cat(" (").cat(hh).cat(":").cat(minute).cat(")")
  return dateString
}
function groupSameDay(imgcollection){
  var d = imgcollection.distinct(['system:time_end']);
  var di = ee.ImageCollection(d);
  // Join collection to itself grouped by date
  var date_eq_filter = ee.Filter.equals({leftField: 'system:time_end',
                                        rightField: 'system:time_end'});
  var saveall = ee.Join.saveAll("to_mosaic");
  var j = saveall.apply(di, imgcollection, date_eq_filter);
  var ji = ee.ImageCollection(j);
  var original_proj = ee.Image(ji.first()).select(0).projection();
  var imgcollection_grouped = ji.map(function(img) {
    var mosaiced = ee.ImageCollection.fromImages(img.get('to_mosaic')).mosaic().copyProperties(img,img.propertyNames());
    return ee.Image(mosaiced); //lost bounds maybe with mosaic operation
  });
return ee.ImageCollection(imgcollection_grouped.copyProperties(imgcollection,imgcollection.propertyNames()));
}
// set one more property about time year-month-day (hour: min)
function setNewTime(img){
  var group_days = getDateString(img)
  return img
  .set('system:time_end', group_days)
}
function maskS2clouds(image) {
  var qa = image.select('QA60')
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
            qa.bitwiseAnd(cirrusBitMask).eq(0))
  // Return the masked and scaled data, without the QA bands.
  return image.updateMask(mask)//.divide(10000)
      // .select(['B8', 'B11', 'B12'])
      .copyProperties(image, ["system:time_start"])
}
var addNDVI = function(image) {
  return image
    .addBands(image.normalizedDifference(['B8A', 'B4'])
    .rename('NDVI'))
    .float();
};
function export_img(img, descri, geo, vis){
  // undefined vis is {}
  vis = (typeof vis !== 'undefined') ? vis : {};
  Export.image.toDrive({
  image: img.visualize(vis),
  description: descri,
  region: geo, 
  folder: 'AFD',
  crs: "EPSG:3857",
  scale: 20
  })
}
function export_poly(collection, descri, folder){
  Export.table.toDrive({
  collection:collection, 
  description: descri, 
  folder: 'AFD/' + folder,
  fileFormat:'SHP'
  })
}
function AFDS2_LC_lr_fun(img, LC_coe, LC_inter){
  var swir2 = img.select('B12') // 2.20
  var red = img.select('B4') // 0.66
  var temp_img = ee.Image(LC_coe).multiply(swir2).add(ee.Image(LC_inter))
  var AFDS2_LC_lr = ee.Image(red.lte(temp_img))
  return (img.addBands(AFDS2_LC_lr.rename('AFDS2_LC_lr'))
    .set('system:time_start', img.get('system:time_start'))
    .set('system:time_end', img.get('system:time_end')))
}
function AFDS2_CZ_lr_fun(img, CZ_coe, CZ_inter){
  var swir2 = img.select('B12') // 2.20
  var red = img.select('B4') // 0.66
  var temp_img = ee.Image(CZ_coe).multiply(swir2).add(ee.Image(CZ_inter))
  var AFDS2_CZ_lr = ee.Image(red.lte(temp_img))
  return (img.addBands(AFDS2_CZ_lr.rename('AFDS2_CZ_lr'))
    .set('system:time_start', img.get('system:time_start'))
    .set('system:time_end', img.get('system:time_end')))
}
function AFDS2_CZ_th_fun(img, CZ_th_B12){
  var swir2 = img.select('B12')
  var red = img.select('B4')
  var AFDS2_CZ_th = ee.Image(swir2.gte(ee.Image(CZ_th_B12)))
  return (img.addBands(AFDS2_CZ_th.rename('AFDS2_CZ_th'))
    .set('system:time_start', img.get('system:time_start'))
    .set('system:time_end', img.get('system:time_end')))
}
function AFDS2_LC_th_fun(img, LC_th_B12){
  var swir2 = img.select('B12')
  var red = img.select('B4')
  var AFDS2_LC_th = ee.Image(swir2.gte(ee.Image(LC_th_B12)))
  return (img.addBands(AFDS2_LC_th.rename('AFDS2_LC_th'))
    .set('system:time_start', img.get('system:time_start'))
    .set('system:time_end', img.get('system:time_end')))
}
function AFDS2_SWIR_fun(img){
  var swir1 = img.select('B11')
  var swir2 = img.select('B12')
  var unambi5 = swir1.gt(1.0)
  var unambi6 = swir2.gt(1.0)
  var unambi7 = unambi5.or(unambi6)
  var unambi8 = swir1.lte(1.0)
  var unambi9 = swir2.lte(1.0) 
  var unambi4 = ee.Image(swir2.gte(ee.Image(swir1)))
  unambi4 = unambi4.and(unambi8).and(unambi9)
  unambi4 = unambi4.or(unambi7)
  return (img.addBands(unambi4.rename('AFDS2_SWIR'))
    .set('system:time_start', img.get('system:time_start'))
    .set('system:time_end', img.get('system:time_end')))
}
///////////////// ====================== AFD threshold Dic ===========================/////////
// data_B4_099,	data_B12_099, coe, interept
// B12_0.99, bin_coe, bin_inter
var CZ_dry =   {
  '1': [0.17, 0.349, 0.017],
  '3': [0.274, 0.372, 0.015],
  '8': [0.281, 0.419, 0.012],
  '9':[0.279,0.352,0.015],
  '14': [0.285, 0.423, 0.011],  
  '15': [0.317, 0.342, 0.018],
  '19': [0.245, 0.256, 0.033], 
  '28':[0.176, 0.278, 0.023]}
var LC_dry =   {
  "10": [0.16,	0.269, 0.020],
  '20': [0.24, 0.326, 0.02],
  '30': [0.31, 0.394, 0.016],
  '40': [0.33, 0.393, 0.016]
}
///////////////// ========================= AFD threshold bag ======================== //////////
var A = {
  'name': "Indonesia",
  'ill_pin': Ind_pin,
  "ClimateZone": "1",
  'LandCover': "10",
  'startDate': "2018-09-27",
  'endDate': "2018-09-29",
  'thre':0.21,
  "roi": Ind}
// var dic_nA = {
//   'name': "North_Australia",
//   'ill_pin': nA_pin,
//   "ClimateZone": "3",
//   'LandCover': "40",
//   'startDate': "2018-08-28",
//   'endDate': "2018-08-30",
//   "roi": Aus2}
var B = {
  'name': 'Charagua_Bolivia',
  'ill_pin':Boli_pin,
  'roi': Charagua,
  "ClimateZone": "3",
  'LandCover': "10",
  'startDate': '2019-08-20', 
  'thre':0.37,  
  'endDate': '2019-08-25'
};
var C = {
  'name': "North_Australia",
  'ill_pin': nA_pin,
  "ClimateZone": "3",
  'LandCover': "30",
  'startDate': "2018-09-02",
  'endDate': "2018-10-10",
  'thre':0.31,  
  "roi": Aus2}
var D = {
  'name': 'Geraneia_Greece',
  'ill_pin': Gree_pin,
  'roi': Geraneia,
  "ClimateZone": "8",
  'LandCover': "30",
  'startDate': '2018-07-23', 
  'thre':0.31,  
  'endDate': '2018-07-26'
};
var E = {
  'name': "CampFire_US",
  'ill_pin': Camp_pin,
  "ClimateZone": "8",
  'LandCover': "20",
  'startDate': '2018-11-08',
  'endDate': '2018-11-20',
  'thre':0.36,  
  "roi": Camp}
var F = {
  'name': 'George_South_Africa',
  'ill_pin': SA_pin,
  'roi': George,
  "ClimateZone": "15",
  'LandCover': "10",
  'thre':0.32,  
  'startDate': '2018-10-25', 
  'endDate': '2018-10-30'
};
var G = {
  'name': "Bulkley_Nechako_BC",
  'ill_pin': BC_pin,  
  "ClimateZone": "19",
  'LandCover': "20",
  'startDate': "2018-08-06",
  'endDate': "2018-08-30",
  'thre':0.25,  
  "roi": Noralee}
var H = {
  'name': "Siberia_Russia",
  'ill_pin': Sib_pin,
  "ClimateZone": "28",
  'LandCover': "20",
  'startDate': "2018-07-18",
  'endDate': "2018-07-20",
  'thre':0.48,  
  "roi": Sib}
// var dic_Cal = {
//   'name': "Thomas Fire, CA, US",
//   // 'fireSeason': 'Winter',
//   "ClimateZone": "8",
//   'LandCover': "20",
//   'startDate': "2017-12-04",
//   'endDate': "2017-12-14",
//   "roi": Cali}
var I = {
  'name': 'Kangaroo Island, Australia',
  'ill_pin': Kangaroo,
  "ClimateZone": "9",
  'LandCover': "20",
  'startDate': "2019-12-25", //12-20
  'endDate': "2020-01-08",
  'thre':0.31, 
};
var J = {
  'name': 'Mallacoota, Australia',
  'ill_pin': Mallacoota,
  "ClimateZone": "15",
  'LandCover': "10",
  'startDate': "2019-12-05", //12-20,12-05(good)
  'endDate': "2020-01-08",
  'thre':0.31, 
};
var K = {
  'name': 'NewCastle, Australia',
  'ill_pin': NewCastle,
  "ClimateZone": "14",
  'LandCover': "10",
  'startDate': "2019-10-27", //1028, 1115, 1205
  'endDate': "2020-01-08",
  'thre':0.31, 
};
var L = {
  'name': 'Phonenix, US',
  'ill_pin': AZ_pin,
  "ClimateZone": "8",
  'LandCover': "30",
  'startDate': "2020-06-15", //1028, 1115, 1205
  'endDate': "2020-06-17",
  'thre':0.31, 
};
var P = {
  'name': 'Phonenix, US',
  'ill_pin': AZ_pin,
  "ClimateZone": "8",
  'LandCover': "30",
  'startDate': "2020-06-15",
  'endDate': "2020-06-17",
  'thre':0.31, 
};
var M = {
  'name': 'Mangum, US',
  'ill_pin': MG_pin,
  "ClimateZone": "8",
  'LandCover': "30",
  'startDate': "2020-06-15", 
  'endDate': "2020-06-17",
  'thre':0.31, 
};
//////// ====================== Global parameter ======================== ////
var LC,CZ,LC_th,CZ_th,LC_coe,LC_inter,CZ_coe,CZ_inter,LC_th_B12,CZ_th_B12,startDate,endDate
var poly,pin,ill_region,thre
var s2_ic,s2_img,AFDS2_LC_lr,AFDS2_CZ_lr,AFDS2_CZ_th,AFDS2_LC_th,AFDS2_SWIR,AFDS2_merge
var img_date,start_date,firms_img,firms_img_fc_img
var ref_B12,ref_B12_fc
var ROI, ROI_str, ROI_active, WATER_MASK
var app = {};
app.createConstants = function() {
  app.COLLECTIONS = {
    'A': A,
    'B': B,
    'C': C,
    'D': D,
    'E': E,
    'F': F,
    'G': G,    
    'H': H,
    'P': P,
    'M': M
  }
  app.WATER_MASK = ee.Image('UMD/hansen/global_forest_change_2015').select('datamask').neq(1);
  app.SECTION_STYLE = {margin: '10px 0 0 0'};
  app.HELPER_TEXT_STYLE = {
      margin: '8px 0 -8px 8px',
      //fontSize: '12px',
      color: 'gray',
      stretch: 'horizontal'
  };
};
app.createPanels = function() {
  /* The introduction section. */
  app.intro = {
    panel: ui.Panel([
      ui.Label({
        value: ' Active Fire Detection with Sentinel-2',
        style: {fontWeight: 'bold', fontSize: '20px', margin: '4px 4px'}
      })
    ])
  };
  var collection_names = Object.keys(app.COLLECTIONS);
  /* The collection filter controls. */
  app.filters = {
    subsetSelect: ui.Select({
      items: collection_names,
      placeholder: 'Select a subset...',
      value: 'A',
      // onChange: app.refreshMapLayer
    }),
    applyAFDButton:ui.Button({
      label: 'Active Fire Detection',
      onClick: app.applyActiveFireDetection,
      disabled: false,
      // style
    }),
  };
  function HorizontalPanel(widget_list) {
    return ui.Panel({
        widgets: widget_list,
        layout: ui.Panel.Layout.flow('horizontal')
      });
  }
  app.filters.panel = ui.Panel({
    widgets: [
      ui.Label('Select Subset', {fontWeight: 'bold'}),
      HorizontalPanel([
        ui.Label('Subset:', app.HELPER_TEXT_STYLE), app.filters.subsetSelect
      ]),
      ui.Panel([
        app.filters.applyAFDButton,
      ], ui.Panel.Layout.flow('horizontal')),
   ],
    style: app.SECTION_STYLE
  });
};
// if(guiFlag){
//   graphButton.onClick(function(){
//   if(userCheckDict.A){
//     var ROI = A
//   }
//   if(userCheckDict.B){
//     var ROI = B
//   }
//     if(userCheckDict.C){
//     var ROI = C
//   }
//     if(userCheckDict.D){
//     var ROI = D
//   }
//     if(userCheckDict.E){
//     var ROI = E
//   }
//     if(userCheckDict.F){
//     var ROI = F
//   }
//     if(userCheckDict.G){
//     var ROI = G
//   }
//     if(userCheckDict.H){
//     var ROI = H
//   }
// })}
app.createHelpers = function() {
app.globleParameter = function(){
  ROI_str =  app.filters.subsetSelect.getValue()
  ROI = app.COLLECTIONS[ROI_str];
  print(ROI,'ROI')
  LC = LC_dry
  CZ = CZ_dry
  LC_th = LC[ROI["LandCover"]]
  CZ_th = CZ[ROI["ClimateZone"]]
  print(CZ_th,'CZ_th')
  LC_coe = LC_th[1]
  LC_inter = LC_th[2]
  CZ_coe = CZ_th[1]
  CZ_inter = CZ_th[2]
  LC_th_B12 = LC_th[0]
  CZ_th_B12 = CZ_th[0]
  startDate = ROI['startDate']
  endDate = ROI['endDate']
  poly = ROI['roi']
  pin = ROI['ill_pin']
  ill_region = pin.buffer(8000).bounds()
  poly = ill_region
  Map.centerObject(poly, 12)
  thre = ROI['thre']
  }
app.getActiveFire = function() {
/////////////////// Climate Zone 1: ROI Indonesia /////////////////////
s2_ic = s2.filterDate(startDate, endDate)
.filterBounds(poly).map(setNewTime)
.map(function(img){return img.unitScale(0, 10000).copyProperties(img,img.propertyNames())})
s2_ic = groupSameDay(s2_ic)
s2_img= ee.Image(s2_ic.first())
print(s2_img,'s2_img')
s2_img = s2_img.set('system:footprint', s2_img.geometry())
s2_img = s2_img.clip(poly)
Map.addLayer(s2_img,s2_vis,"S2_B12_B11_B8A")
Map.addLayer(s2_img,imageVisParam,"S2_B12_B11_B12")
Map.addLayer(s2_img,s2_vis_true,"S2_True_Color")
s2_img = s2_img.updateMask(app.WATER_MASK.not());
AFDS2_LC_lr = AFDS2_LC_lr_fun(s2_img, LC_coe, LC_inter)
AFDS2_LC_lr = AFDS2_LC_lr.updateMask(AFDS2_LC_lr.eq(1)).select('AFDS2_LC_lr')
Map.addLayer(AFDS2_LC_lr,{},"LC_EQ(7)")
AFDS2_CZ_lr = AFDS2_CZ_lr_fun(s2_img, CZ_coe, CZ_inter)
AFDS2_CZ_lr = AFDS2_CZ_lr.updateMask(AFDS2_CZ_lr.eq(1)).select('AFDS2_CZ_lr')
Map.addLayer(AFDS2_CZ_lr,{},"CZ_EQ(6)")
AFDS2_CZ_th = AFDS2_CZ_th_fun(s2_img, CZ_th_B12)
AFDS2_CZ_th = AFDS2_CZ_th.updateMask(AFDS2_CZ_th.eq(1)).select('AFDS2_CZ_th')
Map.addLayer(AFDS2_CZ_th,{},"CZ_EQ(8)")
AFDS2_LC_th = AFDS2_LC_th_fun(s2_img, LC_th_B12)
AFDS2_LC_th = AFDS2_LC_th.updateMask(AFDS2_LC_th.eq(1)).select('AFDS2_LC_th')
Map.addLayer(AFDS2_LC_th,{},"LC_EQ(9)")
AFDS2_SWIR = AFDS2_SWIR_fun(s2_img)
AFDS2_SWIR = AFDS2_SWIR.updateMask(AFDS2_SWIR.eq(1)).select('AFDS2_SWIR')
Map.addLayer(AFDS2_SWIR,{},"SWIRs_EQ(10)")
AFDS2_merge = 
AFDS2_CZ_lr
.and(AFDS2_LC_lr)
.and(AFDS2_CZ_th)
.and(AFDS2_LC_th)
.and(AFDS2_SWIR)
Map.addLayer(AFDS2_merge,{},"AFD-S2")
img_date = s2_img.date()
print(img_date,'img date')
start_date = img_date.advance(-1,'day')
print(start_date,'start_date')
////// ===================  FIRMS MODIS =================
firms_img = firms.filterDate(start_date, img_date)
.filterBounds(poly).map(setNewTime)
firms_img = groupSameDay(firms_img)
firms_img = ee.Image(firms_img.first()).select('T21').gt(0).clip(poly)
// Map.addLayer(firms_img,{},"firms_img")
var firms_img_fc = img2fc(firms_img, poly, 20)
// Map.addLayer(firms_img_fc,{},"firms_img_fc")
firms_img_fc_img = firms_img_fc.style(
      {
        color:"red", 
        fillColor: "#ff000000"
      });
Map.addLayer(firms_img_fc_img,{},"FIRMS")  
//============================ export S2 image and FIRMS ==============================////
s2_img = ee.Image(s2_img)
ref_B12 = s2_img.select('B12').gt(thre)
ref_B12 = ref_B12.mask(ref_B12.eq(1))
ref_B12 = ref_B12.and(AFDS2_SWIR)
// ref_B12_fc = img2fc(ref_B12, poly, 20)
Map.addLayer(ref_B12,{},"Reference_SWIRs")
  }
app.applyActiveFireDetection = function() {
    Map.layers().reset()
    app.globleParameter();
    app.getActiveFire();
}
}
app.boot = function() {
  app.createConstants();
  app.createHelpers();
  app.createPanels();
  var main = ui.Panel({
    widgets: [
      app.intro.panel,
      app.filters.panel,
    ],
    style: {width: '480px', padding: '32px'}
  });
  Map.setCenter(-119.30397033691406, 34.38764597384264);
  ui.root.insert(0, main);
};
app.boot();