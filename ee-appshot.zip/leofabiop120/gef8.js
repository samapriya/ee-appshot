var Limite_Proyecto = ui.import && ui.import("Limite_Proyecto", "table", {
      "id": "users/leofabiop120/Plagas_BID/Limite_Proyecto_Buffer"
    }) || ee.FeatureCollection("users/leofabiop120/Plagas_BID/Limite_Proyecto_Buffer"),
    Tipologia = ui.import && ui.import("Tipologia", "image", {
      "id": "users/leofabiop120/Plagas_BID/Tipologia_2023"
    }) || ee.Image("users/leofabiop120/Plagas_BID/Tipologia_2023"),
    Plaga_HN = ui.import && ui.import("Plaga_HN", "image", {
      "id": "users/leofabiop120/Plagas_BID/Plaga_LimHN"
    }) || ee.Image("users/leofabiop120/Plagas_BID/Plaga_LimHN"),
    Coll_Hansen = ui.import && ui.import("Coll_Hansen", "image", {
      "id": "UMD/hansen/global_forest_change_2021_v1_9"
    }) || ee.Image("UMD/hansen/global_forest_change_2021_v1_9"),
    Limite_Proyecto2 = ui.import && ui.import("Limite_Proyecto2", "table", {
      "id": "projects/ee-leofabiop120/assets/GEF8/Limite_GEF_8_gee"
    }) || ee.FeatureCollection("projects/ee-leofabiop120/assets/GEF8/Limite_GEF_8_gee"),
    AP = ui.import && ui.import("AP", "table", {
      "id": "projects/ee-leofabiop120/assets/GEF8/areas_protegidas_clipGEF8"
    }) || ee.FeatureCollection("projects/ee-leofabiop120/assets/GEF8/areas_protegidas_clipGEF8"),
    AA = ui.import && ui.import("AA", "table", {
      "id": "projects/ee-leofabiop120/assets/GEF8/areas_asignadas_clipGEF8_utm"
    }) || ee.FeatureCollection("projects/ee-leofabiop120/assets/GEF8/areas_asignadas_clipGEF8_utm"),
    MC = ui.import && ui.import("MC", "table", {
      "id": "projects/ee-leofabiop120/assets/GEF8/microcuencas_declaradas_clipGEF8_utm"
    }) || ee.FeatureCollection("projects/ee-leofabiop120/assets/GEF8/microcuencas_declaradas_clipGEF8_utm"),
    PM = ui.import && ui.import("PM", "table", {
      "id": "projects/ee-leofabiop120/assets/GEF8/planes_de_manejo_aprobados_clipGEF8"
    }) || ee.FeatureCollection("projects/ee-leofabiop120/assets/GEF8/planes_de_manejo_aprobados_clipGEF8"),
    Limite_Proyecto3 = ui.import && ui.import("Limite_Proyecto3", "table", {
      "id": "projects/ee-leofabiop120/assets/GEF8/Limite_GEF8_clip"
    }) || ee.FeatureCollection("projects/ee-leofabiop120/assets/GEF8/Limite_GEF8_clip"),
    Omecs_Priorizada = ui.import && ui.import("Omecs_Priorizada", "table", {
      "id": "projects/ee-leofabiop120/assets/GEF8/OMECs_priorizadas"
    }) || ee.FeatureCollection("projects/ee-leofabiop120/assets/GEF8/OMECs_priorizadas");
//*************************************APP ANÁLISIS MULTIPORPOSITO**************************************************//
//PROYECTO: GEF8-FAO
//FINANCIADO POR: GEF
//AÑO: 2023
//DISEÑADA POR : FABIO CASCO
//************************************---------------STYLE-------------------**************************************************//
var colors = {'cyan': '#24C1E0', 'transparent': '#11ffee00', 'gray': '#F8F9FA', 'grayish': '#F5F8F8', 'black': '#000000'};
var TITLE_STYLE = {
  fontWeight: 'bold',
  fontFamily: 'century gothic',
  fontSize: '16px',
  textAlign: 'center',
  padding: '8px',
  color: 'MidnightBlue',
};
var SUBTITLE_STYLE = {
  fontWeight: 'bold',
  fontSize: '14px',
  textAlign: 'center',
  fontFamily: 'century gothic',
  color: '#616161',
  padding: '2px',
  backgroundColor: colors.transparent,
};
var PARAMETERS_STYLE = {
  fontWeight: 'bold',
  fontSize: '12px',
  textAlign: 'left',
  fontFamily: 'century gothic',
  color: '#616161',
  padding: '2px',
  stretch:'horizontal',
  backgroundColor: colors.grayish,
};
var SUBPARAMETERS_STYLE = {
  //fontWeight: '80',
  fontSize: '8px',
  textAlign: 'justify',
  fontFamily: 'century gothic',
  color: '#616161',
  padding: '2px',
  stretch:'horizontal',
  backgroundColor: colors.gray,
};
var VARIABLES_STYLE = {
  fontWeight: '80',
  fontSize: '10px',
  textAlign: 'justify',
  fontFamily: 'century gothic',
  color: '#616161',
  padding: '2px',
  stretch:'horizontal',
  backgroundColor: colors.transparent,
};
var VARIABLES_STYLE2 = {
  //height: '4px',
  margin: '1px 1px 1px 5px',
  fontWeight: '50',
  fontSize: '10px',
  textAlign: 'left',
  //fontFamily: 'monospace',
  color: 'DarkBlue',
  padding: '2px',
  stretch:'horizontal',
  backgroundColor: colors.transparent,
};
var PARAGRAPH_STYLE = {
  fontWeight: '50',
  fontSize: '11px',
  textAlign: 'justify',
  fontFamily: 'century gothic',
  //color: '#9E9E9E',
  padding: '8px',
  backgroundColor: colors.transparent,
};
var noteStyle = {backgroundColor: colors.transparent, 
                 color:'#616161',
                 fontFamily: 'century gothic',
                 fontSize: '10px', 
                 fontWeight: '50', 
                 margin: '8px 8px 1px 8px'};
// #############################################################################
// ### PANEL PRINCIPAL ###
// #############################################################################
var infoPanel = ui.Panel({style: {width: '15%'}});
var swipeSwitchIndex = 4;
var Label_Titulo = ui.Panel([
  ui.Label({
    value: 'Análisis Multipropósito ',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
  ui.Label('Proyecto “GEF8-Honduras"')
]);
var Description = ui.Label('Herramienta de procesamiento inteligente con datos geoespaciales diseñada para la mejora en la toma de decisiones '+ " "+ 
                           'y diseño de indicadores para el proyecto GEF8.',PARAGRAPH_STYLE);
// Add widgets to the info panel.
var panelBreak25 = ui.Panel(null, null, {stretch: 'horizontal', height: '1px', backgroundColor: '000', margin: '8px 0px 8px 0px'});
// #############################################################################
// ### NOTAS Y MANUAL DE USO ###
// #############################################################################
// Function to handle showing and hiding the notes panel.
var notesShow1 = false;
function notesButtonHandler1() {
  if(notesShow1){
    notesShow1 = false;
    notesPanel1.style().set('shown', false);
    //notesPanel1.style().set('width', '83px');
    notesButton1.setLabel('MANUAL DE USO');
    notesButton0.style().set('shown', true);
    //RESETButton.style().set('shown', true);
  } else {
    notesShow1 = true;
    notesPanel1.style().set('shown', true);
    notesPanel1.style().set('width', '315px');
    notesButton1.setLabel('OCULTAR');
    notesButton0.style().set('shown', false);
    //RESETButton.style().set('shown', false);
  }
}
var notesShow0 = false;
function notesButtonHandler0() {
  if(notesShow0){
    notesShow0 = false;
    notesPanel0.style().set('shown', false);
    //notesPanel0.style().set('width', '83px');
    notesButton1.style().set('shown', true);
    notesButton0.setLabel('🌎');
    //RESETButton.style().set('shown', true);
  } else {
    notesShow0 = true;
    notesPanel0.style().set('shown', true);
    notesPanel0.style().set('width', '315px');
    notesButton0.setLabel('OCULTAR');
    notesButton1.style().set('shown', false);
    //RESETButton.style().set('shown', false);
  }
}
var DrainagePanel = ui.Panel({ style: {
          /*height: '290px',*/ width: '180px', border: '5px outset gray',  padding: '0px 1px', position: 'bottom-left',}});
// Show/hide note button.
var notesButton0 = ui.Button({label: '🌎', onClick: notesButtonHandler0, style: {fontFamily: 'century gothic',margin:'5px 15.5px 5px 12.5px'}});
var notesButton1 = ui.Button({label: 'MANUAL DE USO', onClick: notesButtonHandler1, style: {fontFamily: 'century gothic',  margin:'5px 40px'}});
// #############################################################################
// ### RESET BUTTON ###
// #############################################################################
//Reset
/*
var RESETButton = ui.Button({
  label: '↻', style: {position: 'bottom-right', 
        border : '5px #81E29188',
       margin:'5px 5px 5px 17.5px',
       fontFamily: 'Century Gothic',color:'Tomato', fontSize: '20px',},
  onClick: resetfunction})
  */
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var notesPanel0 = ui.Panel({
  widgets: [
//INFO LABELS
ui.Label(({value: 'Fuentes:', style: SUBTITLE_STYLE})),
ui.Label(({value: ('1. Capas Administrativas: Geoportal ICF'), style: noteStyle})),
ui.Label(({value: ('2. Mapas de Cobertura y Uso de la Tierra: Geoportal ICF'), style: noteStyle})),
ui.Label(({value: ('3. Zonificación: Análisis Multripropósito'),style: noteStyle})),
ui.Label(({value: ('4. Imagenes Planet: NICFI'),style: noteStyle})),
ui.Label(({value: ('5. Riesgo a Incendios: Departamento de Protección Forestal, ICF'),style: noteStyle})),
ui.Label(({value: ('6. Deforestación: ICF y Hansen et al.'),style: noteStyle})),
ui.Label(({value: ('7. Clima: CHIRP, MODIS, TERRACLIMATE.'),style: noteStyle})),
ui.Label(({value: 'Sitios Sugeridos:', style: SUBTITLE_STYLE})),
//ui.Label('Smart-Fire: \n(Casco, F.; Orellana, O.; Sarmiento, R.; Maradiaga, I. 2020) ', {color: '81E291', fontSize: '10px', fontFamily: 'Century Gothic',backgroundColor: colors.transparent},
//    'https://leofabiop120.users.earthengine.app/view/smart-fire'),
ui.Label('Análisis Multipropósito:', {color: '81E291', fontSize: '10px', fontFamily: 'Century Gothic',backgroundColor: colors.transparent},
    'https://tungsten-mist-491.notion.site/An-lisis-Multiprop-sito-baf4e35fc4c841739b4da2660f8d1c18'),
ui.Label('Geoportal ICF:', {color: '81E291', fontSize: '10px', fontFamily: 'Century Gothic',backgroundColor: colors.transparent},
    'http://geoportal.icf.gob.hn/geoportal/main'),
ui.Label(
    'Earth Map', {color: '81E291', fontSize: '10px', fontFamily: 'Century Gothic', backgroundColor: colors.transparent},
    'https://earthmap.org/'),
ui.Label(({
    value: 'Fabio Casco',
    style: {height: '12px', textAlign: 'left', fontWeight:'bold', color: 'gray',stretch: 'horizontal', backgroundColor: 'gray',fontFamily: 'Century Gothic', fontSize: '1px', }})),
//ui.Label('Llenar Fomulario 📋 ', {color: '81E291', height: '14px',fontSize: '12px', fontFamily: 'Century Gothic',position: 'top-center', stretch: 'vertical' ,textAlign: 'justify',backgroundColor: colors.transparent},
//    'https://forms.gle/QskPWN4xeB4aM4847'),
ui.Label(({
    value: 'Contacto:', style:SUBTITLE_STYLE})),
ui.Label(({
    value: 'Fabio Casco',
    style: {height: '13px', textAlign: 'left', fontWeight:'bold', color: 'black', fontFamily: 'Century Gothic', fontSize: '12px',backgroundColor: colors.transparent }})),
ui.Label(({
    value: 'T +504 32852656',
    style: {height: '12px', textAlign: 'left', fontWeight:'50', color: 'black', fontFamily: 'Century Gothic', fontSize: '12px',backgroundColor: colors.transparent }})),
ui.Label(({
    value: 'E fabio.cascogutierrez@fao.org',
    style: {height: '13px', textAlign: 'left', fontWeight:'50', color: 'black', fontFamily: 'Century Gothic', fontSize: '12px', backgroundColor: colors.transparent}})),
ui.Label(({
    value: '- Powered by Google Earth Engine',
    style: {position: 'top-center', textAlign: 'middle', fontWeight:'italic', color: 'black', fontFamily: 'Century Gothic', fontSize: '10px', backgroundColor: colors.transparent}})),
  ],
  style: {shown: false, backgroundColor: colors.transparent, fontSize: '12px', fontWeight: '500'}
});
var notesPanel1 = ui.Panel({
  widgets: [
  ui.Label({value:'Para su uso adecuado, siga los siguientes pasos:', style: noteStyle}),
  ui.Label({value:'1) Defina los parámetros del mapa en el panel izquierdo (Capas de Interés, zona de ínteres y selección de variables)', style: noteStyle}),
  ui.Label({value:'2) Haga clic en el botón "PROCESAR DATOS" para que la herramienta procese su requerimiento (parte inferior central).', style: noteStyle}),
  ui.Label({value:'3) Espere a que cargue su requerimiento. Esto puede tardar unos minutos.', style: noteStyle}),
  ui.Label({value:'4) En el visor de mapa (parte superior derecha), haga clic en "Layers", para activar o desactivar las capas.', style: noteStyle}),
  ui.Label({value:'5) Dependiendo de las variables que seleccione, se mostrará información estadísticas segun los parámetros seleccionado (Panel de Estadística).', style: noteStyle}),
  ui.Label({value:'6) Espere a cargue las estadísticas. Esto puede demorar unos minutos.', style: noteStyle}),
  //ui.Label({value:'7) Haga click en el botón "↻" si desea actualizar los párametros seleccionados.', style: noteStyle}),
  ui.Label({value:'*NOTA 2: Cada vez que quiera analizar otras variables, debe limpiar la aplicación o seleccionar las variables y correr la aplicación otra vez.', style: noteStyle}),
  ],
  style: {shown: false, backgroundColor: colors.transparent, fontSize: '12px', fontWeight: '500'}
});
// Notes panel container.
var notesContainer0 = ui.Panel({widgets: [notesButton0, notesPanel0],
  style: {position: 'bottom-right', border : '#81E29188', padding: '0px',
       fontFamily: 'Century Gothic',color:'Tomato', fontSize: '20px', backgroundColor: colors.gray,}});
var notesContainer1 = ui.Panel({widgets: [notesButton1, notesPanel1],
  style: {position: 'bottom-right', color:'Midnightblue', fontSize: '20px', backgroundColor: colors.gray,}});
var Container =  ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {//position: 'bottom-right', padding: '0', 
  backgroundColor: colors.gray,}})
Container.add(notesContainer0);
Container.add(notesContainer1);
var panelBreak24 = ui.Panel(null, null, {stretch: 'horizontal', height: '1px', backgroundColor: '000', margin: '8px 0px 8px 0px'});
// #############################################################################
// ### PANEL INFERIOR PARA GRAFICO ###
// #############################################################################
var mapChartSplitPanel = ui.Panel(ui.SplitPanel({
  firstPanel: ui.Panel(sliderPanel, null, {height: '62%'}), //
  secondPanel: tsChart,
  orientation: 'vertical',
  wipe: false,
}));
// #############################################################################
// ### PANEL DE MAPAS ###
// #############################################################################
var leftMap = ui.Map();
var rightMap = ui.Map();
// left map draw only.
//var rightMapDrawLabel = ui.Label({value: 'Drawing disabled on this side', style: {color: 'EE605E', position: 'top-right', backgroundColor: 'rgba(255, 255, 255, 1.0)'}})
//rightMap.add(rightMapDrawLabel);
// Set map properties
//leftMap.setControlVisibility({layerList: false, zoomControl: false, fullscreenControl: false});
//rightMap.setControlVisibility({layerList: false, zoomControl: false, fullscreenControl: false});
//leftMap.drawingTools().setLinked(true);
//rightMap.drawingTools().setLinked(true);
//leftMap.drawingTools().setShown(false);
//rightMap.drawingTools().setShown(false);
leftMap.setOptions('Dark', {Dark: darkMap()});
rightMap.setOptions('Dark', {Dark: darkMap()});
// Link the default Map to the other map.
var linker = ui.Map.Linker([leftMap, rightMap]);
// Create a SplitPanel which holds the linked maps side-by-side.
// Get the initial AOI from the url parameter.
var swipeStatus = ui.url.get('swipe', false);
ui.url.set('swipe', swipeStatus); // need to set incase this is the initial load.
var sliderPanel = ui.SplitPanel({
  firstPanel: linker.get(0),
  secondPanel: linker.get(1),
  orientation: 'horizontal',
  wipe: swipeStatus,
  style: {stretch: 'both'}
});
var swipeButtonLabel = 'Mostrar pantalla deslizante';
if(swipeStatus) {
  swipeButtonLabel = 'Mostrar visualización en paralelo';
}
var swipeButton = ui.Button(swipeButtonLabel, switchSwipe, null, {position: 'top-left', });
//mapComparison.widgets().set(swipeSwitchIndex, swipeButton);
function switchSwipe() {
  if(swipeStatus) {
    sliderPanel.setWipe(false);
    swipeButton.setLabel('Mostrar pantalla deslizante');
    swipeStatus = false;
    ui.url.set('swipe', 'false');
  } else {
    sliderPanel.setWipe(true);
    swipeButton.setLabel('Mostrar visualización en paralelo');
    swipeStatus = true;
    ui.url.set('swipe', 'true');
  }
}
// #############################################################################
// ### SETUP THE CHARTS PANEL ###
// #############################################################################
var noPlotLabel = ui.Label({value: 'Drawn geometry is too large', style: {position: 'top-left', color: 'EE605E', fontWeight: 'bold', shown: false}});
var contChart = ui.Label({value: '', style: {position: 'top-left', shown: true}}); // [Continuous time series chart]
var yoyChart = ui.Label({value: '', style: {position: 'top-left', shown: true}}); // [Year-over-year time series chart]
var tsChart = ui.Panel([noPlotLabel, contChart, yoyChart]); //, null, {minHeight: '300px'}
// #############################################################################
// ### SETUP APP DISPLAY ###
// #############################################################################
//
var mapChartSplitPanel = ui.Panel(ui.SplitPanel({
  firstPanel: ui.Panel(sliderPanel, null, {height: '80%'}), //
  secondPanel: tsChart,
  orientation: 'vertical',
  wipe: false,
}));
// Make the info panel and slider panel split.
var splitPanel = ui.SplitPanel(infoPanel, mapChartSplitPanel);
// Set the SplitPanel as the only thing in root.
// #############################################################################
// ### PANEL DE NOTAS ###
// #############################################################################
var chartNotes0 = ui.Label({
  value: 'Chart notes:',
  style: {fontSize: '12px', margin: '8px 8px 1px 8px', fontWeight: 'bold'}
});
var panelBreak = ui.Panel(null, null, {stretch: 'horizontal', height: '1px', backgroundColor: '000', margin: '8px 0px 8px 0px'});
var panelBreak1 = ui.Panel(null, null, {stretch: 'horizontal', height: '1px', backgroundColor: '000', margin: '8px 0px 8px 0px'});
var notesShow_statistics = false;
function notesButtonHandler_statistics () {
  if(notesShow_statistics ){
    notesShow_statistics  = false;
    notesPanel_statistics .style().set('shown', false);
    notesButton_statistics .setLabel('Ver Estadísticas');
  } else {
    notesShow_statistics  = true;
    notesPanel_statistics .style().set('shown', true);
    notesButton_statistics .setLabel('Esconder Panel');    
  }
}
var notesButton_statistics  = ui.Button({label: 'Ver Estadísticas', onClick: notesButtonHandler_statistics });
var notesPanel_statistics  = ui.Panel({
  widgets: [
    chartNotes0,
  ],
  style: {shown: false, backgroundColor: 'rgba(255, 255, 255, 0.8)', fontSize: '11px', fontWeight: '500'}
});
// #############################################################################
// ### Panel de Mosaicos 2013-2017 ###
// #############################################################################
var Label_Paramentros = ui.Panel([
  ui.Label({
    value: 'Parámetros de Mapa',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
]);
var Label_AE = ui.Panel([
  ui.Label('1. Área de Estudio')
]);
//ETIQUETAS DEL PANEL PRINCIPAL
var label_Area_Interes = ui.Label('ÁREA DE ESTUDIO',PARAMETERS_STYLE);
var GEF8_selection = ui.Checkbox({
  label: 'Área de estudio GEF8',  
  value: true,
  onChange: function(value) {
    var GEF8_select = value
  }
});
var GEF82_selection = ui.Checkbox({
  label: 'Corredor Priorizado GEF8',  
  value: false,
  onChange: function(value) {
    var GEF82_select = value
  }
});
var OMECs_selection = ui.Checkbox({
  label: 'OMECs',  
  value: false,
  onChange: function(value) {
    var OMECs_select = value
  }
});
//----------------------------------------------------------------------------------------------------------------------------------------------------------//
//AGREGAR UN BOTON DE SELECCIÓN MULTIPLE PARA DEFINIR EL ÁREA DE ESTUDIO
var dropdownPanel;
var resultPanel;
var admin1Selected;
var admin0Selected;
var admin0Select;
var admin1Select;
var admin2Select;
var admin0Names;
var admin1Names;
//Inicio de Filtro Dinámico
// Drill-down (Formas en Cascada) en Earth Engine
// Este script muestra cómo crear una selección jerárquica usando widgets de interfaz de usuario
var admin00 = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level0");
var admin0 = admin00.filter(ee.Filter.inList('ADM0_NAME', ['Honduras']));
var admin11= ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level1").filterBounds(Limite_Proyecto2);
var admin1 = admin11.filter(ee.Filter.inList('ADM0_NAME', ['Honduras']));
var admin22= ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level2").filterBounds(Limite_Proyecto2);
var admin2 = admin22.filter(ee.Filter.inList('ADM0_NAME', ['Honduras']));
// Crea un panel para contener los cuadros desplegables
 dropdownPanel = ui.Panel();
// Crea un panel para guardar el resultado
var resultPanel = ui.Panel();
// Manténgalos deshabilitados. Agregaremos artículos más tarde
 admin0Select = ui.Select({
    placeholder: 'Espere por favor..',
  }).setDisabled(true)
 admin1Select = ui.Select({
    placeholder: 'Seleccione un Municipio',
  }).setDisabled(true)
 admin2Select = ui.Select({
  placeholder: 'Seleccione un Municipio',
}).setDisabled(true)
dropdownPanel.add(admin0Select)
dropdownPanel.add(admin1Select)
//dropdownPanel.add(admin2Select)
// *************************
// Definir funciones de devolución de llamada
// *************************
// Necesitamos hacer esto primero ya que las funciones necesitan
// definirse antes de que se utilicen.
// Definir la función onChange() para admin0Select
 var admin0Selected = function(admin0Selection) {
  resultPanel.clear()
  admin1Select.setPlaceholder('Por favor espere..')
// Ahora que tenemos valores admin0, obtenga valores admin1 para ese país
  admin1Names = admin2
    .filter(ee.Filter.eq('ADM1_NAME', admin0Selection))
    .aggregate_array('ADM2_NAME')
    .sort()
// Usar evaluar() para no bloquear la interfaz de usuario
  admin1Names.evaluate(function(items){
    admin1Select.setPlaceholder('Seleccione un Municipio')
    admin1Select.items().reset(items)
// Ahora que tenemos elementos, habilite el menú
    admin1Select.setDisabled(false)
  })
}
// Definir la función onChange() para admin1Select
 admin1Selected = function(admin1Selection) {
 var admin0Value = admin0Select.getValue()
   var admin1Value = admin1Select.getValue()
  //var admin2Value = admin2Select.getValue()
  var result =  admin1Value + ',' + admin0Value
   Map.clear();
  var label = ui.Label('Usted seleccionó: ' + result)
  resultPanel.add(label)
//Mostrará unicamente el país seleccionado
var country = admin1.filterMetadata('ADM1_NAME', 'equals',admin0Value); 
    studyarea = ee.FeatureCollection([country.geometry()]);    
}
// Registrar las funciones de devolución de llamada
admin0Select.onChange(admin0Selected)
//admin1Select.onChange(admin1Selected)
//admin2Select.onChange(admin2Selected)
// ******************
// Rellenar los elementos
// ******************
// Obtener todos los nombres de países y ordenarlos
 admin0Names = admin1.aggregate_array('ADM1_NAME').sort()
// Obtenga el valor usando evaluar () para no bloquear la interfaz de usuario
admin0Names.evaluate(function(items){
  admin0Select.items().reset(items)
  // Ahora que tenemos elementos, habilite el menú
  admin0Select.setDisabled(false)
  // Cambiar marcador de posición
  admin0Select.setPlaceholder('Seleccione un Departamento')
})
//--------------------------------------------------------------------------------------------------------------------//
//////////////////////////////ZONIFICACIÓN///////////////////////////////////////////
var AMBIENT0 = false;
var VARAMB0 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {backgroundColor: colors.gray, position: 'bottom-center'}
});
var SUBPARAM0 = ui.Panel(ui.Button({label: 'ZONIFICACIÓN',style: SUBPARAMETERS_STYLE,onClick:
    function () {
  if(AMBIENT0){
    AMBIENT0 = false;
   VARAMB0.style().set('shown', false);
      SUBPARAM0.remove(VARAMB0);
  } else {
    AMBIENT0 = true;
   VARAMB0.style().set('shown', true);
     SUBPARAM0.add(VARAMB0)
     //SUBPARAM1.remove(VARMER)//POSSIBLE TO ELIMINATE
     //SUBPARAM3.remove(VAREDA)//POSSIBLE TO ELIMINATE
     //SUBPARAM4.remove(VARGEI)//POSSIBLE TO ELIMINATE
  }
}}));
var label_Capas_Mapa_Derecho = ui.Label('CAPAS MAPA DERECHO',PARAMETERS_STYLE);
//Panel de Mosaicos 2013-2017
var Label_Mapa_HN_18 = ui.Checkbox({
  label: 'Mapa HN 18', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Mapa_HN_18_select = value
  }
});
var Label_Mapa_BNB_18 = ui.Checkbox({
  label: 'Mapa BNB 18', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Mapa_BNB_18_select = value
  }
});
var panel_Mosaicos = ui.Panel({
        widgets: [Label_Mapa_HN_18,Label_Mapa_BNB_18],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
var label_Capas_Mapa_Izq = ui.Label('CAPAS MAPA IZQUIERDO',PARAMETERS_STYLE);
var Label_Zonificacion1 = ui.Checkbox({
  label: 'Zonificación 1', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Zonificacion1_select = value
  }
});
var Label_Zonificacion2 = ui.Checkbox({
  label: 'Zonificación 2', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Zonificacion2_select = value
  }
});
var panel_Zonificacion = ui.Panel({
        widgets: [Label_Zonificacion1,Label_Zonificacion2],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
var Label_Indice_Conectividad = ui.Checkbox({
  label: 'Índice Conectividad', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Indice_Conectividad_select = value
  }
});
var Label_Corredor = ui.Checkbox({
  label: 'Corredores', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Corredores_select = value
  }
});
var panel_Corredores = ui.Panel({
        widgets: [Label_Indice_Conectividad,Label_Corredor],
        layout: ui.Panel.Layout.Flow('horizontal')
      });    
var Label_Tipologia_pino = ui.Checkbox({
  label: 'Máscara de Pino', 
  value: false,
  onChange: function(value) {
    var Label_Tipologia_pino_select = value
  }
});
//////////////AREAS BAJO REGIMEN ESPECIAL DE MANEJO FORESTAL///////////////////////////
//var label_Indices = ui.Label('CÁLCULO DE ÍNDICES',PARAMETERS_STYLE);
var AMBIENT = false;
var VARAMB = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {backgroundColor: colors.gray, position: 'bottom-center'}
});
//NDVI
var AP_selection = ui.Checkbox({
  label: 'Area Protegida', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var AP_select = value
    //print('NDVI')
  }
});
//NDWI
var MC_selection = ui.Checkbox({
  label: 'Microcuenca', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var MC_select = value
   // print('NDwI')
  }
});
//NDFI
var AA_selection = ui.Checkbox({
  label: 'Area Asignada', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var AA_select = value
   // print('NDFI')
  }
});
//EVI
var PM_selection = ui.Checkbox({
  label: 'Planes de Manejo', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var PM_select = value
    //print('EVI')
  }
});
var SUBPARAM2 = ui.Panel(ui.Button({label: 'ÁREAS BAJO REGIMEN FORESTAL',style: SUBPARAMETERS_STYLE,onClick:
    function () {
  if(AMBIENT){
    AMBIENT = false;
   VARAMB.style().set('shown', false);
      SUBPARAM2.remove(VARAMB);
  } else {
    AMBIENT = true;
   VARAMB.style().set('shown', true);
     SUBPARAM2.add(VARAMB)
     //SUBPARAM1.remove(VARMER)//POSSIBLE TO ELIMINATE
     //SUBPARAM3.remove(VAREDA)//POSSIBLE TO ELIMINATE
     //SUBPARAM4.remove(VARGEI)//POSSIBLE TO ELIMINATE
  }
}}));
//////////////ZONIFICACIÓN NIVEL 1///////////////////////////
var label_Zonificacion1 = ui.Label('Zonificación Nivel 1',PARAMETERS_STYLE);
var AMBIENT3 = false;
var VARAMB3 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {backgroundColor: colors.gray, position: 'bottom-center'}
});
//Zona de Desarrollo Agricola/Ganadero
var ZDAG_selection = ui.Checkbox({
  label: 'Zona de Desarrollo Agricola/Ganadero', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var ZDAG_select = value
    //print('NDVI')
  }
});
//Zona de Desarrollo Forestal
var ZDF_selection = ui.Checkbox({
  label: 'Zona de Desarrollo Forestal', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var ZDF_select = value
   // print('NDwI')
  }
});
//Zona de Baja Productividad Ambiental
var ZBPA_selection = ui.Checkbox({
  label: 'Zona de Baja Productividad Ambiental', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var ZBPA_select = value
   // print('NDFI')
  }
});
//Zona de Desarrollo Poblacional
var ZDP_selection = ui.Checkbox({
  label: 'Zona de Desarrollo Poblacional', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var ZDP_select = value
    //print('EVI')
  }
});
//Zona de Restauracion de Paisaje
var ZRP_selection = ui.Checkbox({
  label: 'Zona de Restauracion de Paisaje', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var ZRP_select = value
    //print('EVI')
  }
});
//Zona de Desarrollo Agroforestal
var ZDA_selection = ui.Checkbox({
  label: 'Zona de Desarrollo Agroforestal', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var ZDA_select = value
    //print('EVI')
  }
});
//Sistemas Bajo Conflicto de Uso
var SBCU_selection = ui.Checkbox({
  label: 'Sistemas Bajo Conflicto de Uso', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var SBCU_select = value
    //print('EVI')
  }
});
//////////////Areas bajo Regimen Especial de Manejo Foresal///////////////////////////
var label_AP = ui.Label('Áreas Protegidas',PARAMETERS_STYLE);
//Zona de Desarrollo Agricola/Ganadero
var Dentro_AP_selection = ui.Checkbox({
  label: 'Dentro de AP', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Dentro_AP_select = value
    //print('NDVI')
  }
});
//Zona de Desarrollo Forestal
var Afuera_AP_selection = ui.Checkbox({
  label: 'Fuera de AP', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Afuera_AP_select = value
   // print('NDwI')
  }
});
//////////////Areas bajo Regimen Especial de Manejo Foresal///////////////////////////
var label_MC = ui.Label('Microcuencas Declaradas',PARAMETERS_STYLE);
//Zona de Desarrollo Agricola/Ganadero
var Dentro_MC_selection = ui.Checkbox({
  label: 'Dentro de MC', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Dentro_MC_select = value
    //print('NDVI')
  }
});
//Zona de Desarrollo Forestal
var Afuera_MC_selection = ui.Checkbox({
  label: 'Fuera de MC', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Afuera_MC_select = value
   // print('NDwI')
  }
});
//////////////Areas bajo Regimen Especial de Manejo Foresal///////////////////////////
var label_AA = ui.Label('Áreas Asignadas',PARAMETERS_STYLE);
//Areas Asignadas
var Dentro_AA_selection = ui.Checkbox({
  label: 'Dentro de AA', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Dentro_AA_select = value
    //print('NDVI')
  }
});
//Areas Asignadas
var Afuera_AA_selection = ui.Checkbox({
  label: 'Fuera de AA', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Afuera_AA_select = value
   // print('NDwI')
  }
});
//////////////Areas bajo Regimen Especial de Manejo Foresal///////////////////////////
var label_PM = ui.Label('Planes de Manejo Aprobados',PARAMETERS_STYLE);
//Areas Asignadas
var Dentro_PM_selection = ui.Checkbox({
  label: 'Dentro de PMF', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Dentro_PM_select = value
    //print('NDVI')
  }
});
//Areas Asignadas
var Afuera_PM_selection = ui.Checkbox({
  label: 'Fuera de PMF', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Afuera_PM_select = value
   // print('NDwI')
  }
});
//////////////Areas bajo Regimen Especial de Manejo Foresal///////////////////////////
var label_ABREMF = ui.Label('ABREMF',PARAMETERS_STYLE);
//ABREMF
var Dentro_ABREMF_selection = ui.Checkbox({
  label: 'Dentro de ABREMF', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Dentro_ABREMF_select = value
    //print('NDVI')
  }
});
//ABREMF
var Afuera_ABREMF_selection = ui.Checkbox({
  label: 'Fuera de ABREMF', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Afuera_ABREMF_select = value
   // print('NDwI')
  }
});
//////////////Areas bajo Regimen Especial de Manejo Foresal///////////////////////////
var label_OMEC = ui.Label('OMEC',PARAMETERS_STYLE);
//OMEC
var Dentro_OMEC_selection = ui.Checkbox({
  label: 'Dentro de OMEC', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Dentro_OMEC_select = value
    //print('NDVI')
  }
});
//OMEC
var Afuera_OMEC_selection = ui.Checkbox({
  label: 'Fuera de OMEC', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Afuera_OMEC_select = value
   // print('NDwI')
  }
});
//////////////Areas bajo Regimen Especial de Manejo Foresal///////////////////////////
var label_PH = ui.Label('Protección Hídrica',PARAMETERS_STYLE);
//PH
var Dentro_PH_selection = ui.Checkbox({
  label: 'Dentro de PH', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Dentro_PH_select = value
    //print('NDVI')
  }
});
//PH
var Afuera_PH_selection = ui.Checkbox({
  label: 'Fuera de PH', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Afuera_PH_select = value
   // print('NDwI')
  }
});
//////////////Areas bajo Regimen Especial de Manejo Foresal///////////////////////////
var label_Slope = ui.Label('Pendiente',PARAMETERS_STYLE);
//Pendiente
var Slope_0_15_selection = ui.Checkbox({
  label: '0-15%', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Dentro_PH_select = value
    //print('NDVI')
  }
});
//Pendiente
var Slope_15_30_selection = ui.Checkbox({
  label: '15-30%', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Slope_15_30_select = value
   // print('NDwI')
  }
});
//Pendiente
var Slope_30_45_selection = ui.Checkbox({
  label: '30-45%', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Slope_30_45_select = value
   // print('NDwI')
  }
});
//Pendiente
var Slope_45_60_selection = ui.Checkbox({
  label: '45-60%', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Slope_45_60_select = value
   // print('NDwI')
  }
});
//Pendiente
var Slope_60_selection = ui.Checkbox({
  label: '>60%', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Slope_60_select = value
   // print('NDwI')
  }
});
var SUBPARAM3 = ui.Panel(ui.Button({label: 'ANÁLISIS MULTIPROPÓSITO',style: SUBPARAMETERS_STYLE,onClick:
    function () {
  if(AMBIENT3){
    AMBIENT3 = false;
   VARAMB3.style().set('shown', false);
      SUBPARAM3.remove(VARAMB3);
  } else {
    AMBIENT3 = true;
   VARAMB3.style().set('shown', true);
     SUBPARAM3.add(VARAMB3)
     //SUBPARAM1.remove(VARMER)//POSSIBLE TO ELIMINATE
     //SUBPARAM3.remove(VAREDA)//POSSIBLE TO ELIMINATE
     //SUBPARAM4.remove(VARGEI)//POSSIBLE TO ELIMINATE
  }
}}));
//////////////INCENDIOS//////////////////////////////////////////////////
//var label_Indices = ui.Label('CÁLCULO DE ÍNDICES',PARAMETERS_STYLE);
var AMBIENT4 = false;
var VARAMB4 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {backgroundColor: colors.gray, position: 'bottom-center'}
});
//RI
var RI_selection = ui.Checkbox({
  label: 'Riesgo a Incendios', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var RI_select = value
    //print('NDVI')
  }
});
//Puntos Incendios
var Puntos_Incendios_selection = ui.Checkbox({
  label: 'Incendios', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Puntos_Incendios_select = value
   // print('NDwI')
  }
});
//Incendios MODIS
var Incendios_MODIS_selection = ui.Checkbox({
  label: 'Incendios MODIS', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Incendios_MODIS_select = value
   // print('NDFI')
  }
});
//Frecuencia Incendios
var Frecuencia_Incendios_selection = ui.Checkbox({
  label: 'Frecuencia Incendios', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Frecuencia_Incendios_select = value
    //print('EVI')
  }
});
var SUBPARAM4 = ui.Panel(ui.Button({label: 'LB: INCENDIOS',style: SUBPARAMETERS_STYLE,onClick:
    function () {
  if(AMBIENT4){
    AMBIENT4 = false;
   VARAMB4.style().set('shown', false);
      SUBPARAM4.remove(VARAMB4);
  } else {
    AMBIENT4 = true;
   VARAMB4.style().set('shown', true);
     SUBPARAM4.add(VARAMB4)
     //SUBPARAM1.remove(VARMER)//POSSIBLE TO ELIMINATE
     //SUBPARAM3.remove(VAREDA)//POSSIBLE TO ELIMINATE
     //SUBPARAM4.remove(VARGEI)//POSSIBLE TO ELIMINATE
  }
}}));
//////////////DEFORESTACION//////////////////////////////////////////////////
//var label_Indices = ui.Label('CÁLCULO DE ÍNDICES',PARAMETERS_STYLE);
var AMBIENT5 = false;
var VARAMB5 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {backgroundColor: colors.gray, position: 'bottom-center'}
});
//Deforestacion HN
var Defo_HN_selection = ui.Checkbox({
  label: 'Deforestación HN', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Defo_HN_select = value
    //print('NDVI')
  }
});
//Puntos Incendios
var Defo_Hansen_selection = ui.Checkbox({
  label: 'Deforestación Hansen', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Defo_Hansen_select = value
   // print('NDwI')
  }
});
var SUBPARAM5 = ui.Panel(ui.Button({label: 'LB: DEFORESTACIÓN',style: SUBPARAMETERS_STYLE,onClick:
    function () {
  if(AMBIENT5){
    AMBIENT5 = false;
   VARAMB5.style().set('shown', false);
      SUBPARAM5.remove(VARAMB5);
  } else {
    AMBIENT5 = true;
   VARAMB5.style().set('shown', true);
     SUBPARAM5.add(VARAMB5)
     //SUBPARAM1.remove(VARMER)//POSSIBLE TO ELIMINATE
     //SUBPARAM3.remove(VAREDA)//POSSIBLE TO ELIMINATE
     //SUBPARAM4.remove(VARGEI)//POSSIBLE TO ELIMINATE
  }
}}));
//////////////CLIMA//////////////////////////////////////////////////
//var label_Indices = ui.Label('CÁLCULO DE ÍNDICES',PARAMETERS_STYLE);
var AMBIENT6 = false;
var VARAMB6 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {backgroundColor: colors.gray, position: 'bottom-center'}
});
//Precipitación HN
var Precipitacion_selection = ui.Checkbox({
  label: 'Precipitación', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Precipitacion_select = value
    //print('NDVI')
  }
});
//Temperatura
var Temperatura_selection = ui.Checkbox({
  label: 'Temperatura', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Temperatura_select = value
   // print('NDwI')
  }
});
//Sequia
var Sequia_selection = ui.Checkbox({
  label: 'Sequia', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var Sequia_select = value
   // print('NDwI')
  }
});
var SUBPARAM6 = ui.Panel(ui.Button({label: 'LB: CLIMA',style: SUBPARAMETERS_STYLE,onClick:
    function () {
  if(AMBIENT6){
    AMBIENT6 = false;
   VARAMB6.style().set('shown', false);
      SUBPARAM6.remove(VARAMB6);
  } else {
    AMBIENT6 = true;
   VARAMB6.style().set('shown', true);
     SUBPARAM6.add(VARAMB6)
     //SUBPARAM1.remove(VARMER)//POSSIBLE TO ELIMINATE
     //SUBPARAM3.remove(VAREDA)//POSSIBLE TO ELIMINATE
     //SUBPARAM4.remove(VARGEI)//POSSIBLE TO ELIMINATE
  }
}}));
//--------------------------------------------------------------------------------------------------------------------//
//////////////////////////////VEGETACION///////////////////////////////////////////
var AMBIENT7 = false;
var VARAMB7 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {backgroundColor: colors.gray, position: 'bottom-center'}
});
var SUBPARAM7 = ui.Panel(ui.Button({label: 'LB: VEGETACIÓN',style: SUBPARAMETERS_STYLE,onClick:
    function () {
  if(AMBIENT7){
    AMBIENT7 = false;
   VARAMB7.style().set('shown', false);
      SUBPARAM7.remove(VARAMB7);
  } else {
    AMBIENT7 = true;
   VARAMB7.style().set('shown', true);
     SUBPARAM7.add(VARAMB7)
     //SUBPARAM1.remove(VARMER)//POSSIBLE TO ELIMINATE
     //SUBPARAM3.remove(VAREDA)//POSSIBLE TO ELIMINATE
     //SUBPARAM4.remove(VARGEI)//POSSIBLE TO ELIMINATE
  }
}}));
//NDVI
var NDVI17_selection = ui.Checkbox({
  label: 'NDVI 2017 Planet', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var NDVI17_select = value
  }
});
var NDVI23_selection = ui.Checkbox({
  label: 'NDVI 2023 Planet', 
  style: VARIABLES_STYLE2,
  value: false,
  onChange: function(value) {
    var NDVI23_select = value
  }
});
var label_Clasificacion = ui.Label('RESULTADO DE CLASIFICACIÓN',PARAMETERS_STYLE);
var Check_Analisis_Dinamica = ui.Checkbox({
  label: 'Dinámica', 
  value: false,
  onChange: function(value) {
    var Label_Analisis_Dinamica_select = value
  }
});
var Check_Analisis_Dinamica_Plaga = ui.Checkbox({
  label: 'Plaga Modelada', 
  value: false,
  onChange: function(value) {
    var Check_Analisis_Dinamica_Plaga_select = value
  }
});
var Check_Plaga_HN = ui.Checkbox({
  label: 'Plaga ICF', 
  value: false,
  onChange: function(value) {
    var Check_Plaga_HN_select = value
  }
});
var panel_Dinamica = ui.Panel({
        widgets: [Check_Analisis_Dinamica,Check_Analisis_Dinamica_Plaga,Check_Plaga_HN],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
var label_Analisis_Estadistico = ui.Label('PRECISIÓN TEMÁTICA',PARAMETERS_STYLE);
var Check_Precision_Tematica = ui.Checkbox({
  label: 'Validación cruzada K-Fold', 
  value: false,
  onChange: function(value) {
    var Check_Precision_Tematica_select = value
  }
});
var label_Analisis_Hansen = ui.Label('ANÁLISIS COMPARATIVO',PARAMETERS_STYLE);
var Check_Hansen = ui.Checkbox({
  label: 'Pérdidas Hansen 2013-2017', 
  value: false,
  onChange: function(value) {
    var Check_Hansen_select = value
  }
});
var add2 = function (){
infoPanel.add(Label_Titulo);
infoPanel.add(Description);
infoPanel.add(panelBreak25);
infoPanel.add(Container);
infoPanel.add(panelBreak24);
infoPanel.add(swipeButton);
infoPanel.add(panelBreak);
infoPanel.add(notesButton_statistics );
infoPanel.add(notesPanel_statistics);
infoPanel.add(panelBreak1);
infoPanel.add(Label_Paramentros);
infoPanel.add(label_Area_Interes);
infoPanel.add(dropdownPanel);
infoPanel.add(GEF8_selection);
infoPanel.add(GEF82_selection);
infoPanel.add(OMECs_selection);
infoPanel.add(SUBPARAM0);
VARAMB0.add(label_Capas_Mapa_Derecho);
VARAMB0.add(Label_Mapa_HN_18);
VARAMB0.add(Label_Mapa_BNB_18);
VARAMB0.add(label_Capas_Mapa_Izq);
VARAMB0.add(Label_Zonificacion1);
VARAMB0.add(Label_Zonificacion2);
VARAMB0.add(Label_Indice_Conectividad);
VARAMB0.add(Label_Corredor);
//infoPanel.add(Label_Tipologia_pino);
//infoPanel.add(label_Muestras);
//infoPanel.add(panel_Muestras);
//infoPanel.add(label_Indices);
infoPanel.add(SUBPARAM2);
VARAMB.add(AP_selection);
VARAMB.add(MC_selection);
VARAMB.add(AA_selection);
VARAMB.add(PM_selection);
infoPanel.add(SUBPARAM3);
VARAMB3.add(label_Zonificacion1);
VARAMB3.add(ZDAG_selection);
VARAMB3.add(ZDF_selection);
VARAMB3.add(ZBPA_selection);
VARAMB3.add(ZDP_selection);
VARAMB3.add(ZRP_selection);
VARAMB3.add(ZDA_selection);
VARAMB3.add(SBCU_selection);
VARAMB3.add(label_AP);
VARAMB3.add(Dentro_AP_selection);
VARAMB3.add(Afuera_AP_selection);
VARAMB3.add(label_MC);
VARAMB3.add(Dentro_MC_selection);
VARAMB3.add(Afuera_MC_selection);
VARAMB3.add(label_AA);
VARAMB3.add(Dentro_AA_selection);
VARAMB3.add(Afuera_AA_selection);
VARAMB3.add(label_PM);
VARAMB3.add(Dentro_PM_selection);
VARAMB3.add(Afuera_PM_selection);
VARAMB3.add(label_ABREMF);
VARAMB3.add(Dentro_ABREMF_selection);
VARAMB3.add(Afuera_ABREMF_selection);
VARAMB3.add(label_OMEC);
VARAMB3.add(Dentro_OMEC_selection);
VARAMB3.add(Afuera_OMEC_selection);
VARAMB3.add(label_PH);
VARAMB3.add(Dentro_PH_selection);
VARAMB3.add(Afuera_PH_selection);
VARAMB3.add(label_Slope);
VARAMB3.add(Slope_0_15_selection);
VARAMB3.add(Slope_15_30_selection);
VARAMB3.add(Slope_30_45_selection);
VARAMB3.add(Slope_45_60_selection);
VARAMB3.add(Slope_60_selection);
infoPanel.add(SUBPARAM4);
VARAMB4.add(RI_selection);
VARAMB4.add(Puntos_Incendios_selection);
VARAMB4.add(Incendios_MODIS_selection);
VARAMB4.add(Frecuencia_Incendios_selection);
infoPanel.add(SUBPARAM5);
VARAMB5.add(Defo_HN_selection);
VARAMB5.add(Defo_Hansen_selection);
infoPanel.add(SUBPARAM6);
VARAMB6.add(Temperatura_selection);
VARAMB6.add(Precipitacion_selection);
VARAMB6.add(Sequia_selection);
infoPanel.add(SUBPARAM7);
VARAMB7.add(NDVI17_selection);
VARAMB7.add(NDVI23_selection);
//infoPanel.add(label_Clasificacion);
//infoPanel.add(panel_Dinamica);
//infoPanel.add(label_Analisis_Estadistico);
//infoPanel.add(Check_Precision_Tematica);
//infoPanel.add(panelBreak50);
//infoPanel.add(timeSeries);
//infoPanel.add(label_Analisis_Hansen);
//infoPanel.add(Check_Hansen);
// #############################################################################
// ### Panel de Notas ###
// #############################################################################
// #############################################################################
// ### BOTON RUN ###
// #############################################################################
//BUTTON
var AddButton = function(){
  var button = ui.Button({label: 'PROCESAR DATOS'});
      button.style().set({
       position: 'bottom-center',
       //margin: '10px 112px',
       border : '5px inset gray',
       padding: '0px',
     //  radius: "25px",
       fontFamily: 'Century Gothic',
      // fontSize: '20px',
      //  border: '10px',
       whiteSpace:'pre',
      });
      button.onClick(function(){return runPMBS();
});
      //ValidateArea();
      infoPanel.add(button);
} ;
AddButton();
};
add2();
// #############################################################################
// ### AGREGAR LOS BOTONES A LA PANTALLA ###
// #############################################################################
ui.root.clear()
ui.root.widgets().reset([splitPanel]);
var INFOPANEL;
// #############################################################################
// ### FUNCIÓN PARA PROCESAR LOS DATOS ###
// #############################################################################
var runPMBS = function(){
//Limpiar cada Panel de Mapa una vez inicie el proceso de cálculo   
leftMap .clear();
rightMap.clear();
tsChart .clear();
leftMap.setOptions('Dark', {Dark: darkMap()});
rightMap.setOptions('Dark', {Dark: darkMap()});
//Agregar de nuevo el Boton del Panel de Datos (Panel Derecho)
//rightMap.add(Button_notesPanel_statistics);
//--------------------------Obtener los valores de cada Parámetro ---------------------------------------//
var depa_names                  = admin0Select        .getValue();
var muni_names                  = admin1Select        .getValue();
var GEF8_select                 =   GEF8_selection    .getValue();
var GEF82_select                 =   GEF82_selection    .getValue();
var OMECs_select                 =   OMECs_selection    .getValue();
var Mapa_HN_18_select           = Label_Mapa_HN_18.getValue();
var Mapa_BNB_18_select          = Label_Mapa_BNB_18.getValue();
var Zonificacion1_select          = Label_Zonificacion1.getValue();
var Zonificacion2_select          = Label_Zonificacion2.getValue();
var Indice_Conectividad_select          = Label_Indice_Conectividad.getValue();
var Corredores_select          = Label_Corredor.getValue();
//var Label_Tipologia_pino_select = Label_Tipologia_pino.getValue();
//var Label_Muestras_BE_select    =    Label_Muestras_BE.getValue();
//var Label_Muestras_NBE_select   =  Label_Muestras_NBE .getValue();
//var Label_Muestras_Plaga_select = Label_Muestras_Plaga.getValue();
var AP_select                 =      AP_selection .getValue();
var MC_select                 =      MC_selection .getValue();
var AA_select                 =     AA_selection .getValue();
var PM_select                  =    PM_selection .getValue();
var ZDAG_select                 =      ZDAG_selection .getValue();
var ZDF_select                 =      ZDF_selection .getValue();
var ZRP_select                 =     ZRP_selection .getValue();
var ZBPA_select                  =    ZBPA_selection .getValue();
var ZDP_select                 =      ZDP_selection .getValue();
var ZDA_select                 =      ZDA_selection .getValue();
var SBCU_select                 =     SBCU_selection .getValue();
var Dentro_AP_select                 =     Dentro_AP_selection .getValue();
var Afuera_AP_select                 =     Afuera_AP_selection .getValue();
var Dentro_MC_select                 =     Dentro_MC_selection .getValue();
var Afuera_MC_select                 =     Afuera_MC_selection .getValue();
var Dentro_AA_select                 =     Dentro_AA_selection .getValue();
var Afuera_AA_select                 =     Afuera_AA_selection .getValue();
var Dentro_PM_select                 =     Dentro_PM_selection .getValue();
var Afuera_PM_select                 =     Afuera_PM_selection .getValue();
var Dentro_ABREMF_select                 =     Dentro_ABREMF_selection .getValue();
var Afuera_ABREMF_select                 =     Afuera_ABREMF_selection .getValue();
var Dentro_OMEC_select                 =     Dentro_OMEC_selection .getValue();
var Afuera_OMEC_select                 =     Afuera_OMEC_selection .getValue();
var Dentro_PH_select                 =     Dentro_PH_selection .getValue();
var Afuera_PH_select                 =     Afuera_PH_selection .getValue();
var Slope_0_15_select                 =     Slope_0_15_selection .getValue();
var Slope_15_30_select                 =    Slope_15_30_selection .getValue();
var Slope_30_45_select                 =    Slope_30_45_selection .getValue();
var Slope_45_60_select                 =    Slope_45_60_selection .getValue();
var Slope_60_select                 =    Slope_60_selection .getValue();
var RI_select                 =     RI_selection .getValue();
var Puntos_Incendios_select                 =    Puntos_Incendios_selection .getValue();
var Incendios_MODIS_select                 =    Incendios_MODIS_selection .getValue();
var Frecuencia_Incendios_select                 =    Frecuencia_Incendios_selection .getValue();
var Defo_HN_select                 =     Defo_HN_selection .getValue();
var Defo_Hansen_select                 =    Defo_Hansen_selection .getValue();
var Temperatura_select                 =     Temperatura_selection .getValue();
var Precipitacion_select                 =    Precipitacion_selection .getValue();
var Sequia_select                 =    Sequia_selection .getValue();
var NDVI17_select                 =    NDVI17_selection .getValue();
var NDVI23_select                 =    NDVI23_selection .getValue();
var Check_Analisis_Dinamica_select = Check_Analisis_Dinamica.getValue();
var Check_Analisis_Dinamica_Plaga_Select = Check_Analisis_Dinamica_Plaga.getValue();
var Check_Plaga_HN_select = Check_Plaga_HN .getValue();
var Check_Precision_Tematica_select = Check_Precision_Tematica .getValue();
var Check_Hansen_select = Check_Hansen.getValue();
//------------------------------Crear las fuciones condicionales -----------------------------------------//
//----------------------------------------------------------------------------------------------------------------------------------------------------------//
//DEFINIR EL ÁREA DE ESTUDIO
var admin00 = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level0")
var admin0 = admin00.filter(ee.Filter.inList('ADM0_NAME', ['Honduras']));
var studyarea = ee.FeatureCollection([admin0.geometry()]);
var admin11= ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level1").filterBounds(Limite_Proyecto2);;
var admin11 = admin11.filter(ee.Filter.inList('ADM0_NAME', ['Honduras']));
var depa = ee.FeatureCollection(admin11).filter(ee.Filter.inList('ADM1_NAME', [depa_names])); // Country border polygons of high accuracy
var studyarea2 = ee.FeatureCollection([depa.geometry()]);
var admin22= ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level2").filterBounds(Limite_Proyecto2);;
var admin22 = admin22.filter(ee.Filter.inList('ADM0_NAME', ['Honduras']));
var depar = ee.FeatureCollection(admin22).filter(ee.Filter.inList('ADM1_NAME', [depa_names]));
var muni = ee.FeatureCollection(depar).filter(ee.Filter.inList('ADM2_NAME', [muni_names]));
var Area_Estudio = ee.FeatureCollection([muni.geometry()]);  
//SE DEFINE UN FUNCIÓN PARA QUE ENTIENDA QUE SI NO SE SELECCIONA UN MUNICIPIO, CONSIDERE UNICAMENTE EL LÍMITE DEL DEPARTAMENTO
if (muni_names === null){
  Area_Estudio = studyarea2.map(function(studyarea2) {
  // Obtenemos la geometría del municipio actual.
  var geomMunicipio = studyarea2.geometry();
  // Calculamos la intersección del municipio con el área de estudio.
  var interseccion = geomMunicipio.intersection(Limite_Proyecto2, ee.ErrorMargin(1));
  // Retornamos el municipio original con su geometría actualizada a la intersección.
  // Nota: Esto reemplazará la geometría original del municipio por la intersección.
  // Si necesitas mantener la geometría original y la intersección, considera usar set en lugar de retornar un Feature nuevo.
  return studyarea2.setGeometry(interseccion);
});
  rightMap.addLayer(ee.Image().paint(Area_Estudio,1,2), {'palette': 'black','width':1},'Area Estudio',true);
}
if (GEF8_select === true){
  Area_Estudio = Limite_Proyecto2;
leftMap.addLayer(ee.Image().paint(Area_Estudio,1,2), {'palette': 'black','width':1},'Area Estudio',true);
}
if (GEF82_select === true){
  Area_Estudio = Limite_Proyecto3;
leftMap.addLayer(ee.Image().paint(Area_Estudio,1,2), {'palette': 'black','width':1},'Area Estudio',true);
}
if (OMECs_select === true){
  Area_Estudio = Omecs_Priorizada;
leftMap.addLayer(ee.Image().paint(Area_Estudio,1,2), {'palette': 'black','width':1},'Area Estudio',true);
}
//-------------------------------------------Centrar El Mapa---- -----------------------------------------//
//Centrar nuestros Mapas en función del Área de Estudio
leftMap.centerObject(Area_Estudio)
//-------------------------------------------CAPAS MAPA DERECHO-------------- -----------------------------------------//
var Pino = Tipologia.eq(3).clip(Area_Estudio);
    Pino = Pino.updateMask(Pino);
var Col_Hansen = Coll_Hansen.clip(Area_Estudio);
var Mapa_HN = ee.Image('users/leofabiop120/Mapa_Cobertura_HN_2018').clip(Area_Estudio);
// Cargar la capa de 'Nivel3' desde tu Asset
var nivel3 = ee.Image('projects/ee-leofabiop120/assets/GEF8/Nivel_3').clip(Area_Estudio);
var nivel1 = ee.Image('projects/ee-leofabiop120/assets/GEF8/Nivel_1').clip(Area_Estudio);
var Area_Protegida = ee.Image('projects/ee-leofabiop120/assets/GEF8/AP');
var Area_Asiganada = ee.Image('projects/ee-leofabiop120/assets/GEF8/AA');
var Microcuencas = ee.Image('projects/ee-leofabiop120/assets/GEF8/MC');
var Planes_Manejo = ee.Image('projects/ee-leofabiop120/assets/GEF8/PMF');
var ABREMF = ee.Image('projects/ee-leofabiop120/assets/GEF8/ABREMF');
var OMEC = ee.Image('projects/ee-leofabiop120/assets/GEF8/Omecs');
var Pueblos_Indigenas = ee.Image('projects/ee-leofabiop120/assets/GEF8/PI');
var PH = ee.Image('projects/ee-leofabiop120/assets/GEF8/Protecion_Hidrica');
var Pendientes = ee.Image('projects/ee-leofabiop120/assets/GEF8/Pendiente');
var Riesgo_Incendio = ee.Image('projects/ee-leofabiop120/assets/GEF8/Riesgo_Incendio').clip(Area_Estudio);
var Indice_Conectividad = ee.Image('projects/ee-leofabiop120/assets/GEF8/indice_conectividad_ajustadoFinal').clip(Area_Estudio);
var Corredor_Principal = ee.FeatureCollection('projects/ee-leofabiop120/assets/GEF8/corredor_principal');
var Corredor_Vecino = ee.FeatureCollection('projects/ee-leofabiop120/assets/GEF8/corredores_vecinos');
var Defo_HN = ee.Image('projects/ee-leofabiop120/assets/GEF8/Defo_00_18').clip(Area_Estudio);
var Defo_Hansen = ee.Image('UMD/hansen/global_forest_change_2022_v1_10').clip(Area_Estudio);
//-------------------------------------------------Gráfico de Cobertura BNB---------------------------------------------//
var reclass_cobertura = Mapa_HN.where(Mapa_HN.lte(10), 1)
                               .where(Mapa_HN.eq(11), 2)
                               .where(Mapa_HN.eq(12), 1)
                               .where(Mapa_HN.gt(12), 2)
//---------------------------------MÁSCARAS----------------------------------------------------------------------------//
//Máscaras para Zonificación Nivel 1
var ZDAG = nivel1.eq(1).updateMask(nivel1.eq(1))
var ZDF = nivel1.eq(2).updateMask(nivel1.eq(2))
var ZRP = nivel1.where(nivel1.eq(3), 3)
                .where(nivel1.eq(7), 3)
var ZRP = ZRP.eq(3).updateMask(ZRP.eq(3))
var ZBPA = nivel1.where(nivel1.eq(4), 4)
                .where(nivel1.eq(10), 4)
var ZBPA = ZBPA.eq(4).updateMask(ZBPA.eq(4))
var ZDP = nivel1.eq(5).updateMask(nivel1.eq(5))
var ZDA = nivel1.eq(8).updateMask(nivel1.eq(8))
var SBCU = nivel1.eq(9).updateMask(nivel1.eq(9))
//Areas Protegidas
var Dentro_AP = Area_Protegida.eq(2).updateMask(Area_Protegida.eq(2))
var Afuera_AP = Area_Protegida.eq(1).updateMask(Area_Protegida.eq(1))
//Microcuenca 
var Dentro_MC = Microcuencas.eq(2).updateMask(Microcuencas.eq(2))
var Afuera_MC = Microcuencas.eq(1).updateMask(Microcuencas.eq(1))
//Areas ASignadas 
var Dentro_AA = Area_Asiganada.eq(2).updateMask(Area_Asiganada.eq(2))
var Afuera_AA = Area_Asiganada.eq(1).updateMask(Area_Asiganada.eq(1))
//Planes de Manejo 
var Dentro_PM = Planes_Manejo.eq(2).updateMask(Planes_Manejo.eq(2))
var Afuera_PM = Planes_Manejo.eq(1).updateMask(Planes_Manejo.eq(1))
//ABREMF 
var Dentro_ABREMF = ABREMF.eq(2).updateMask(ABREMF.eq(2))
var Afuera_ABREMF = ABREMF.eq(1).updateMask(ABREMF.eq(1))
//OMEC 
var Dentro_OMEC = OMEC.eq(2).updateMask(OMEC.eq(2))
var Afuera_OMEC = OMEC.eq(1).updateMask(OMEC.eq(1))
//PH 
var Dentro_PH = PH.eq(2).updateMask(PH.eq(2))
var Afuera_PH = PH.eq(1).updateMask(PH.eq(1))
//Slope 
var Slope_0_15 = Pendientes.eq(1).updateMask(Pendientes.eq(1))
var Slope_15_30 = Pendientes.eq(2).updateMask(Pendientes.eq(2))
var Slope_30_45 = Pendientes.eq(3).updateMask(Pendientes.eq(3))
var Slope_45_60 = Pendientes.eq(4).updateMask(Pendientes.eq(4))
var Slope_60 = Pendientes.eq(5).updateMask(Pendientes.eq(5))
// Inicializa una imagen con todos los píxeles a 0 (máscara falsa)
var combinedMask = ee.Image(0);
var combinedMask_AP = ee.Image(0);
var combinedMask_MC = ee.Image(0);
var combinedMask_AA = ee.Image(0);
var combinedMask_PM = ee.Image(0);
var combinedMask_ABREMF = ee.Image(0);
var combinedMask_OMEC = ee.Image(0);
var combinedMask_PH = ee.Image(0);
var combinedMask_Slope = ee.Image(0);
// Agrega a la máscara combinada las categorías seleccionadas
combinedMask = ZDAG_select ? combinedMask.add(nivel1.eq(1)) : combinedMask;
combinedMask = ZDF_select ? combinedMask.add(nivel1.eq(2)) : combinedMask;
combinedMask = ZRP_select ? combinedMask.add(nivel1.eq(3).add(nivel1.eq(7))) : combinedMask;
combinedMask = ZBPA_select ? combinedMask.add(nivel1.eq(4).add(nivel1.eq(10))) : combinedMask;
combinedMask = ZDP_select ? combinedMask.add(nivel1.eq(5)) : combinedMask;
combinedMask = ZDA_select ? combinedMask.add(nivel1.eq(8)) : combinedMask;
combinedMask = SBCU_select ? combinedMask.add(nivel1.eq(9)) : combinedMask;
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
combinedMask_AP = Dentro_AP_select ? combinedMask_AP.add(Dentro_AP) : combinedMask_AP;
combinedMask_AP = Afuera_AP_select ? combinedMask_AP.add(Afuera_AP) : combinedMask_AP;
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
combinedMask_MC = Dentro_MC_select ? combinedMask_MC.add(Dentro_MC) : combinedMask_MC;
combinedMask_MC = Afuera_MC_select ? combinedMask_MC.add(Afuera_MC) : combinedMask_MC;
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
combinedMask_AA = Dentro_AA_select ? combinedMask_AA.add(Dentro_AA) : combinedMask_AA;
combinedMask_AA = Afuera_AA_select ? combinedMask_AA.add(Afuera_AA) : combinedMask_AA;
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
combinedMask_PM = Dentro_PM_select ? combinedMask_PM.add(Dentro_PM) : combinedMask_PM;
combinedMask_PM = Afuera_PM_select ? combinedMask_PM.add(Afuera_PM) : combinedMask_PM;
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
combinedMask_ABREMF = Dentro_ABREMF_select ? combinedMask_ABREMF.add(Dentro_ABREMF) : combinedMask_ABREMF;
combinedMask_ABREMF = Afuera_ABREMF_select ? combinedMask_ABREMF.add(Afuera_ABREMF) : combinedMask_ABREMF;
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
combinedMask_OMEC = Dentro_OMEC_select ? combinedMask_OMEC.add(Dentro_OMEC) : combinedMask_OMEC;
combinedMask_OMEC = Afuera_OMEC_select ? combinedMask_OMEC.add(Afuera_OMEC) : combinedMask_OMEC;
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
combinedMask_PH = Dentro_PH_select ? combinedMask_PH.add(Dentro_PH) : combinedMask_PH;
combinedMask_PH = Afuera_PH_select ? combinedMask_PH.add(Afuera_PH) : combinedMask_PH;
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
combinedMask_Slope = Slope_0_15_select ? combinedMask_Slope.add(Pendientes.eq(1)) : combinedMask_Slope;
combinedMask_Slope = Slope_15_30_select ? combinedMask_Slope.add(Pendientes.eq(2)) : combinedMask_Slope;
combinedMask_Slope = Slope_30_45_select ? combinedMask_Slope.add(Pendientes.eq(3)) : combinedMask_Slope;
combinedMask_Slope = Slope_45_60_select ? combinedMask_Slope.add(Pendientes.eq(4)) : combinedMask_Slope;
combinedMask_Slope = Slope_60_select ? combinedMask_Slope.add(Pendientes.eq(5)) : combinedMask_Slope;
// Repetir para las demás categorías...
// Inicializa una variable para rastrear si alguna categoría fue seleccionada
var anyCategorySelected = false;
// Inicializa una variable para rastrear si alguna opción de AP fue seleccionada
var anyAPSelected = false;
var anyMCSelected = false;
var anyAASelected = false;
var anyPMSelected = false;
var anyABREMFSelected = false;
var anyOMECSelected = false;
var anyPHSelected = false;
var anySlopeSelected = false;
// Agrega a la máscara combinada las categorías seleccionadas y actualiza el rastreador
if (ZDAG_select) {
  combinedMask = combinedMask.add(nivel1.eq(1));
  anyCategorySelected = true;
}
if (ZDF_select) {
  combinedMask = combinedMask.add(nivel1.eq(2));
  anyCategorySelected = true;
}
if (ZRP_select) {
  combinedMask = combinedMask.add(nivel1.eq(3).add(nivel1.eq(7)));
  anyCategorySelected = true;
}
if (ZDP_select) {
  combinedMask = combinedMask.add(nivel1.eq(5));
  anyCategorySelected = true;
}
if (ZDA_select) {
  combinedMask = combinedMask.add(nivel1.eq(8));
  anyCategorySelected = true;
}
if (SBCU_select) {
  combinedMask = combinedMask.add(nivel1.eq(9));
  anyCategorySelected = true;
}
if (Dentro_AP_select) {
  combinedMask = combinedMask.add(Area_Protegida.eq(2));
  anyCategorySelected = true;
}
if (Afuera_AP_select) {
  combinedMask = combinedMask.add(Area_Protegida.eq(1));
  anyCategorySelected = true;
}
// Repetir para las demás categorías...
// Si alguna categoría fue seleccionada, crea una máscara booleana
if (anyCategorySelected) {
  combinedMask = combinedMask.gt(0);
} else {
  // Si no se seleccionó ninguna categoría, crea una máscara que sea verdadera para todos los píxeles
  combinedMask = ee.Image(1);
}
//******Condición para definir que hacer cuando no se seleccione ninguna opcion en AP******//
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
if (Dentro_AP_select) {
  combinedMask_AP = combinedMask_AP.add(Dentro_AP);
  anyAPSelected = true;
}
if (Afuera_AP_select) {
  combinedMask_AP = combinedMask_AP.add(Afuera_AP);
  anyAPSelected = true;
}
// Si alguna opción de AP fue seleccionada, crea una máscara booleana
if (anyAPSelected) {
  combinedMask_AP = combinedMask_AP.gt(0);
} else {
  // Si no se seleccionó ninguna opción de AP, crea una máscara que sea verdadera para todos los píxeles
  combinedMask_AP = ee.Image(1);
}
//******Condición para definir que hacer cuando no se seleccione ninguna opcion en AP******//
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
if (Dentro_MC_select) {
  combinedMask_MC = combinedMask_MC.add(Dentro_MC);
  anyMCSelected = true;
}
if (Afuera_MC_select) {
  combinedMask_MC = combinedMask_MC.add(Afuera_MC);
  anyMCSelected = true;
}
// Si alguna opción de AP fue seleccionada, crea una máscara booleana
if (anyMCSelected) {
  combinedMask_MC = combinedMask_MC.gt(0);
} else {
  // Si no se seleccionó ninguna opción de AP, crea una máscara que sea verdadera para todos los píxeles
  combinedMask_MC = ee.Image(1);
}
//******Condición para definir que hacer cuando no se seleccione ninguna opcion en AP******//
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
if (Dentro_AA_select) {
  combinedMask_AA = combinedMask_AA.add(Dentro_AA);
  anyAASelected = true;
}
if (Afuera_AA_select) {
  combinedMask_AA = combinedMask_AA.add(Afuera_AA);
  anyAASelected = true;
}
// Si alguna opción de AP fue seleccionada, crea una máscara booleana
if (anyAASelected) {
  combinedMask_AA = combinedMask_AA.gt(0);
} else {
  // Si no se seleccionó ninguna opción de AP, crea una máscara que sea verdadera para todos los píxeles
  combinedMask_AA = ee.Image(1);
}
//******Condición para definir que hacer cuando no se seleccione ninguna opcion en AP******//
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
if (Dentro_PM_select) {
  combinedMask_MC = combinedMask_PM.add(Dentro_PM);
  anyMCSelected = true;
}
if (Afuera_PM_select) {
  combinedMask_PM = combinedMask_PM.add(Afuera_PM);
  anyMCSelected = true;
}
// Si alguna opción de AP fue seleccionada, crea una máscara booleana
if (anyMCSelected) {
  combinedMask_PM = combinedMask_PM.gt(0);
} else {
  // Si no se seleccionó ninguna opción de AP, crea una máscara que sea verdadera para todos los píxeles
  combinedMask_PM = ee.Image(1);
}
//******Condición para definir que hacer cuando no se seleccione ninguna opcion en AP******//
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
if (Dentro_ABREMF_select) {
  combinedMask_ABREMF = combinedMask_ABREMF.add(Dentro_ABREMF);
  anyABREMFSelected = true;
}
if (Afuera_ABREMF_select) {
  combinedMask_ABREMF = combinedMask_ABREMF.add(Afuera_ABREMF);
  anyABREMFSelected = true;
}
// Si alguna opción de AP fue seleccionada, crea una máscara booleana
if (anyABREMFSelected) {
  combinedMask_ABREMF = combinedMask_ABREMF.gt(0);
} else {
  // Si no se seleccionó ninguna opción de AP, crea una máscara que sea verdadera para todos los píxeles
  combinedMask_ABREMF = ee.Image(1);
}
//******Condición para definir que hacer cuando no se seleccione ninguna opcion en AP******//
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
if (Dentro_OMEC_select) {
  combinedMask_OMEC = combinedMask_OMEC.add(Dentro_OMEC);
  anyOMECSelected = true;
}
if (Afuera_OMEC_select) {
  combinedMask_OMEC = combinedMask_OMEC.add(Afuera_OMEC);
  anyOMECSelected = true;
}
// Si alguna opción de AP fue seleccionada, crea una máscara booleana
if (anyOMECSelected) {
  combinedMask_OMEC = combinedMask_OMEC.gt(0);
} else {
  // Si no se seleccionó ninguna opción de AP, crea una máscara que sea verdadera para todos los píxeles
  combinedMask_OMEC = ee.Image(1);
}
//******Condición para definir que hacer cuando no se seleccione ninguna opcion en AP******//
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
if (Dentro_PH_select) {
  combinedMask_PH = combinedMask_PH.add(Dentro_PH);
  anyPHSelected = true;
}
if (Afuera_PH_select) {
  combinedMask_PH = combinedMask_PH.add(Afuera_PH);
  anyPHSelected = true;
}
// Si alguna opción de AP fue seleccionada, crea una máscara booleana
if (anyPHSelected) {
  combinedMask_PH = combinedMask_PH.gt(0);
} else {
  // Si no se seleccionó ninguna opción de AP, crea una máscara que sea verdadera para todos los píxeles
  combinedMask_PH = ee.Image(1);
}
//******Condición para definir que hacer cuando no se seleccione ninguna opcion en AP******//
// Agrega a la máscara combinada de Áreas Protegidas según las selecciones
if (Slope_0_15_select) {
  combinedMask_Slope = combinedMask_Slope.add(Pendientes.eq(1));
  anySlopeSelected = true;
}
if (Slope_15_30_select) {
  combinedMask_Slope = combinedMask_Slope.add(Pendientes.eq(2));
  anySlopeSelected = true;
}
if (Slope_30_45_select) {
  combinedMask_Slope = combinedMask_Slope.add(Pendientes.eq(3));
  anySlopeSelected = true;
}
if (Slope_45_60_select) {
  combinedMask_Slope = combinedMask_Slope.add(Pendientes.eq(4));
  anySlopeSelected = true;
}
if (Slope_60_select) {
  combinedMask_Slope = combinedMask_Slope.add(Pendientes.eq(5));
  anySlopeSelected = true;
}
// Si alguna opción de AP fue seleccionada, crea una máscara booleana
if (anySlopeSelected) {
  combinedMask_Slope = combinedMask_Slope.gt(0);
} else {
  // Si no se seleccionó ninguna opción de AP, crea una máscara que sea verdadera para todos los píxeles
  combinedMask_Slope = ee.Image(1);
}
// Ahora combina la máscara de zonificación Nivel 1 con la máscara de Áreas Protegidas
// Utiliza una operación lógica que permita cualquier combinación de selecciones
var finalCombinedMask = combinedMask.and(combinedMask_AP)
                                    .and(combinedMask_MC)
                                    .and(combinedMask_AA)
                                    .and(combinedMask_PM)
                                    .and(combinedMask_ABREMF)
                                    .and(combinedMask_OMEC)
                                    .and(combinedMask_PH)
                                    .and(combinedMask_Slope);
// Aplicar la máscara combinada final a todas las imágenes de interés
var nivel1_masked = nivel1.updateMask(finalCombinedMask);
var nivel3_masked = nivel3.updateMask(finalCombinedMask);
var reclass_cobertura_masked = reclass_cobertura.updateMask(finalCombinedMask);
var Mapa_HN_masked = Mapa_HN.updateMask(finalCombinedMask);
var nivel1_masked_reclass = nivel1_masked.where(nivel1_masked.eq(1), 1)
                               .where(nivel1_masked.eq(2), 2)
                               .where(nivel1_masked.eq(3), 3)
                               .where(nivel1_masked.eq(4), 4)  
                               .where(nivel1_masked.eq(5), 5)  
                               .where(nivel1_masked.eq(6), 6)  
                               .where(nivel1_masked.eq(7), 3)  
                               .where(nivel1_masked.eq(8), 7)  
                               .where(nivel1_masked.eq(9), 8)  
                               .where(nivel1_masked.eq(10), 4)
//Importar Modulo de Leyendas
var leyendaModule = require('users/leofabiop120/GEF8:Leyenda');
// Continuar con el procesamiento o visualización de las capas enmascaradas
if (Mapa_HN_18_select === true){
var palette3=  [
    '000000', //No Data
    '006400', //1
    '8CA038', //2
    '4d5100', //3
    '357953', //4
    '437d12', //5
    '6dcd3d', //6
    '9f1fee', //7
    'ee82ee', //8
    'd24588', //9
    'a32a2a', //10
    '006400', //11 
    'c58000', //12
    '8775ad', //13
    'ffa600', //14
    'F4F4DB', //15
    'F4F4DB', //16
    '33615f', //17
    'a0522d', //18
    '004200', //19
    '851f4f', //20
    'ff6800', //21
    'e88573', //22
    'ffc0cc', //23
    'f7f45a', //24
    'e65214', //25
    'f60909', //26
    'a50000', //27
    'ffffff', //28
    '7f7f7f', //29
    '00ffff', //30
    '4183be', //31
    '009ee0', //32
    '0fbbee', //33
    '0000ff', //34
    '3869c7', //35
    '588e98', //36
    '00006f', //37
  ];
var Paleta_Color = {
  min: 0,
  max: 37,
  palette: palette3}
rightMap.addLayer(Mapa_HN_masked, Paleta_Color,"Cobertura 2018 HN");
leyendaModule.addLegendToMap(rightMap);
}
if (Mapa_BNB_18_select === true){
var paletteBNB=  [
    'green', //1 Bosque
    'f7f45a', //2 No Bosque 
  ];  
var Paleta_Color_BNB = {
  min: 1,
  max: 2,
  palette: paletteBNB}
//print('reclass_cobertura',reclass_cobertura)
rightMap.addLayer(reclass_cobertura_masked, Paleta_Color_BNB,"BNB 2018 HN");
leyendaModule.addLegendToMapBNB(rightMap);
}
//Zonificacion1_select
if (Zonificacion1_select === true){
var paleta_nivel1 = [
'LightYellow', // 1 = Zona de Desarrollo Agricola/Ganaderal
'ForestGreen', // 2 = Zona de Desarrollo Forestal
'LightGreen', // 3 = Zonas de Restauración de Paisajes
'LightGrey', // 4 = Zona de Baja Productividad Ambiental
'Maroon', // 5 = Zonas de Desarrollo Poblacional
'LightSkyBlue', // 6 = Cuerpos de Agua
'LightGreen', // 7 = Zonas de Restauración de Paisajesl
'DarkGoldenRod', // 8 = Zona de Desarrollo Agroforestal
'Crimson', // 9 = Sistemas Bajo Conflicto de Uso
'LightGrey', // 10 = Zona de Baja Productividad Ambientall
];
//Map.addLayer(nivel1, {palette: paleta_nivel1, min: 1, max: 10}, 'Nivel1');
leftMap.addLayer(nivel1_masked, {palette: paleta_nivel1, min: 1, max: 10},"Zonificación 1");
leyendaModule.addLegendToMapZ1(leftMap);
}
//Zonificacion2_select
if (Zonificacion2_select === true){
var paleta_nivel3 = [
  '6DB65B', // Sistema Agropecuario con Obras de Cons. de Suelo - Verde
  '967117', // Sistema Agro-Silvopastoriles - Marrón dorado
  '228B22', // Protección Forestal - Verde bosque
  'F4A460', // Sistema Agrícola de Baja Escala - Marrón arena
  '4682B4', // Reforestación con fines Hídricos - Azul acero
  '9ACD32', // Protección de Vegetación Arbustiva en Suceción - Verde amarillento
  '32CD32', // Manejo de Regeneración con fines Hídricos - Verde lima
  '00CED1', // Conservación Hídrica - Turquesa oscuro
  '3CB371', // Manejo de Regeneración Natural para fines de Protección Forestal - Verde mar medio
  '4682B4', // Reforestación con Fines de Hídricos - Azul acero
  '9ACD32', // Manejo de Vegetación Arbustiva en Suceción - Verde amarillento
  '006400', // Conservación Forestal - Verde oscuro
  '556B2F', // Reforestación para fines de Protección Forestal - Verde oliva oscuro
  '66CDAA', // Reforestación con Fines de Conservación - Aguamarina medio
  '8FBC8F', // Manejo de Regeneración Natural con Fines de Conservación - Verde mar oscuro
  'BDB76B', // Obras de Conservación de Suelo - Caqui oscuro
  'B22222', // Necesidad Pública - Ladrillo refractario
  '8B4513', // Manejo de Restauración Natural - SaddleBrown
  '1E90FF', // Cuerpos de Agua - DodgerBlue
  '2E8B57', // Restauración Hidríca de Areas Degradadas - Verde mar
  'A9A9A9', // Zona Urbana Con Baja Densidad Poblacional - Gris oscuro
  '32CD32', // Reforestación Implementada - Verde lima
  'FFD700', // Manejo Sostenible con Fines Productivos - Oro
  'FFA500', // Reforestación con Fines Productivos - Naranja
  '90EE90', // Regeneración Natural Indentificada en Campo - Verde claro
  'FFD700', // Manejo de Regeneración Natural con Fines Productivos - Oro
  'FF4500', // Zona Urbana Con Alta Densidad Poblacional - Naranja rojizo
  '8B4513', // Manejo de Sistemas Agroforestales - SaddleBrown
  'DAA520', // Sistemas Agrícolas Técnificados - Oro vara
  'FF6347', // Sistemas Agroforestales en Conflicto - Tomate
  'FF0000', // Zona Agroalimentaria Industrial en Conflicto - Rojo
  'DEB887', // Obras de Conservación de Suelo y Agua - Burlywood
];
leftMap.addLayer(nivel3_masked, {palette: paleta_nivel3, min: 1, max: 31},"Zonificación 2");
leyendaModule.addLegendToMapZ2(leftMap);
}
//Indice_Conectividad_select, Corredores_select
if (Indice_Conectividad_select === true){
var visParams = {
    min: 0,  // El valor mínimo de tu índice
    max: 1,  // El valor máximo de tu índice
    palette: [
        'C2523C', // Color inicial que diste (rojo anaranjado)
        'FFFF00', // Amarillo
        '00FF00', // Verde claro
        '0000FF', // Azul
        'DE5B30'  // Color final que diste (azul)
    ]
};
leftMap.addLayer(Indice_Conectividad, visParams,"Indice de Conectividad");
leyendaModule.addLegendToMapIndiceConectividad(leftMap);
}
//Indice_Conectividad_select, Corredores_select
if (Corredores_select === true){
leftMap.addLayer(ee.Image().paint(Corredor_Vecino,1,2), {'palette': 'yellow','width':1},'Corredor Principal',true);
leftMap.addLayer(ee.Image().paint(Corredor_Principal,1,1), {'palette': 'red','width':1},'Corredor Vecino',true);
}
if (RI_select === true){
// Definir los parámetros de visualización con la paleta de colores para cada nivel de riesgo
var visParams = {
    min: 1,   // el valor mínimo de la capa
    max: 4,   // el valor máximo de la capa
    palette: [
        '008000', // 1: Bajo - Verde
        'FFFF00', // 2: Medio - Amarillo
        'FFA500', // 3: Alto - Naranja
        'FF0000'  // 4: Muy alto - Rojo
    ]
};
// Añadir la capa al mapa con los parámetros de visualización
leftMap.addLayer(Riesgo_Incendio, visParams, 'Riesgo de Incendios');
leyendaModule.addLegendToMapRI(leftMap);
}
if (Puntos_Incendios_select === true){
// Cargar la FeatureCollection que contiene los puntos
var capaPuntos = ee.FeatureCollection('projects/ee-leofabiop120/assets/GEF8/Incendios_14_23').filterBounds(Area_Estudio);
// Definir los parámetros de estilo para los puntos
var estiloPuntos = {
    color: 'FF0000', // Color rojo en formato hexadecimal
    pointSize: 1     // Tamaño del punto, ajusta según sea necesario
};
// Añadir la capa de puntos al mapa con el estilo definido
leftMap.addLayer(capaPuntos.style(estiloPuntos), {}, 'Incendios ICF 14-23');
}
if (Incendios_MODIS_select === true){
var datasetModis = ee.ImageCollection("MODIS/061/MCD64A1") //MODIS/061/MCD64A1
                  .filter(ee.Filter.date('2000-01-01', '2023-12-31'))
                  .select('BurnDate')
                  .map(function(image) {
      return image.clip(Area_Estudio);
    });
var burnedArea = datasetModis.select('BurnDate');
//Leyenda
var palette0 = ['Red', 'Chartreuse'];
var vis0 = {
  'min': 1,
  'max': 365,
  'opacity': 0.8,
  'palette': palette0
};
rightMap.addLayer(datasetModis, vis0, 'Área Quemada');
leyendaModule.addLegendToMapIncendiosMODIS(rightMap);
}
if (Frecuencia_Incendios_select === true){
// Cargar la colección MODIS/061/MCD64A1 y filtrar por fechas.
var datasetModis = ee.ImageCollection("MODIS/061/MCD64A1")
    .filter(ee.Filter.date('2000-01-01', '2023-12-31'))
    .select('BurnDate');
// Convertir a imagen binaria
var binaryBurn = datasetModis.map(function(image) {
  return image.gt(0).rename('burned');
});
// Sumar todas las imágenes binarias
var burnFrequency = binaryBurn.reduce(ee.Reducer.sum()).clip(Area_Estudio);
// Enmascarar los píxeles con un valor de 0
var maskedBurnFrequency = burnFrequency.updateMask(burnFrequency.gt(0));
// Visualiza el resultado
rightMap.addLayer(maskedBurnFrequency, {min: 1, max: 10, palette: ['YellowGreen','yellow', 'orange', 'red']}, 'Frecuencia de Incendios');
leyendaModule.addLegendToMapFrecuenciaIncendio(rightMap);  
}
if (Defo_HN_select === true){
var paletteDefoHN=  [
    'FF1493', //1 Defo 2000-2006
    'FF8C00', //2 Defo 200-2012
    'FFD700', //3 Defo 2012-2016
    'DC143C' // 4 Defo 2016-2018
  ];  
var Paleta_Color_DefoHN = {
  min: 1,
  max: 4,
  palette: paletteDefoHN}
leftMap.addLayer(Defo_HN, Paleta_Color_DefoHN,"Deforestacion HN");
leyendaModule.addLegendToMapDefoHN(leftMap);
}
if (Defo_Hansen_select === true){
var lossYear = Defo_Hansen.select(['lossyear']).clip(Area_Estudio);
// The lossYear image contains pixel values from 0 to 22
// indicating the year in which the loss occurred
// We visualize this layer on the map.
var palette = [
  '0083ba', '#4394b6', '#5ca5b2', '#74b6ad', '#8dc8a9',
  '#a5d9a5', '#b7e2a8', '#c7e8ad', '#d7efb2', '#e7f5b7',
  '#f7fcbc', '#fff7b6', '#fee8a4', '#fed890', '#fec980',
  '#fdba6e', '#fba75e', '#f48b51', '#ed6e43', '#e5522a',
  '#de3519', '#d7191c'];
var lossYearVis = {
  min: 0,
  max: 22,
  palette: palette
}
// Visualize the loss on the map
rightMap.addLayer(lossYear, lossYearVis, 'Loss Year');
leyendaModule.addLegendToMapDefoHansen(rightMap);
}
if (Temperatura_select === true){
//Temperatura
var modisLSTday = ee.ImageCollection("MODIS/061/MOD11A1").filterBounds(Area_Estudio).filterDate('2010-01-01', '2022-12-01').select('LST_Day_1km');
var modLSTday =ee.ImageCollection(modisLSTday).map(function(img) {
  return img.multiply(0.02).subtract(273.15).copyProperties(img,['system:time_start','system:time_end']); 
});
// Calculando el promedio de precipitación anual acumulada para los años de interes
var averageAnnualTemp = modLSTday.reduce(ee.Reducer.mean()).clip(Area_Estudio);
var landSurfaceTemperatureVis = {
  min: 15,
  max: 35,
  palette: [
    '040274', '040281', '0502a3', '0502b8', '0502ce', '0502e6',
    '0602ff', '235cb1', '307ef3', '269db1', '30c8e2', '32d3ef',
    '3be285', '3ff38f', '86e26f', '3ae237', 'b5e22e', 'd6e21f',
    'fff705', 'ffd611', 'ffb613', 'ff8b13', 'ff6e08', 'ff500d',
    'ff0000', 'de0101', 'c21301', 'a71001', '911003'
  ],
};
// Añadir capas al mapa
leftMap.addLayer(averageAnnualTemp, landSurfaceTemperatureVis, 'Temperatura Promedio Anual'); 
leyendaModule.addLegendToMapTemperatura(leftMap);
}
if (Sequia_select === true){
var dataset2 = ee.ImageCollection('IDAHO_EPSCOR/TERRACLIMATE')
                  //.first()
                 .filterDate("2020-12-01", "2020-12-31")
                  .select('pdsi')
                  //.mean()
                  .map(function(img) {
  var date = img.get('system:time_start');
  return img.multiply(0.01).clip(Area_Estudio)
  .set('system_time_start', date)
  .copyProperties(img,['system:time_start','system:time_end'])
 });
var pdsiVis = {
  min: -6.0,
  max: 6.0,
  palette: [
'800026', 'BD0026', 'E31A1C', 'FC4E2A', 'FD8D3C',
'FEB24C', 'FED976', 'FFFFB2', 'A1DAB4', '41B6C4',
'1D91C0', '225EA8', '253494', '081D58'  
  ],
};
//Map.setCenter(71.72, 52.48, 3);
leftMap.addLayer(dataset2, pdsiVis, 'pdsi');
leyendaModule.addLegendToMapSequia(leftMap);
}
if (Precipitacion_select === true) {
var Año_inicial = 2000;
var Año_Final = 2023;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//************************************************PRECIPITACIÓN*******************************************************//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Datos de CHIRP
var CHIRP =  ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY")
  .select("precipitation")
  .filterBounds(Area_Estudio);
// Calculando la precipitación anual
var years = ee.List.sequence(Año_inicial, Año_Final);
// Calculando la precipitación anual para cada año
var years = ee.List.sequence(Año_inicial, Año_Final);
var annualPrecip = ee.ImageCollection.fromImages(
  years.map(function(y) {
    var filtered = CHIRP.filter(ee.Filter.calendarRange(y, y, 'year'))
                         .sum()
                         .clip(Area_Estudio);
    return filtered.set('year', y)
                   .set('system:time_start', ee.Date.fromYMD(y, 1, 1));
  })
);
// Calculando el promedio de precipitación anual acumulada para los años de interes
var averageAnnualPrecip = annualPrecip.reduce(ee.Reducer.mean()).rename('averageAnnualPrecip').clip(Area_Estudio);
// Añadir capas al mapa
rightMap.addLayer(averageAnnualPrecip, {min: 0, max: 2800, palette: ["red", "blue"]}, 'Precipitación Promedio Anual');  
leyendaModule.addLegendToMapPrecipitacion(rightMap);
}
if (NDVI17_select === true) {
var nicfi = ee.ImageCollection('projects/planet-nicfi/assets/basemaps/americas');
// Filter basemaps by date and get the first image from filtered results
//'2022-01-01','2022-03-28'
var Planett= nicfi.filter(ee.Filter.date('2017-01-01','2017-12-30'))//Belice y RD Jura
                 .filterBounds(Area_Estudio)
                 .median()
                 .clip(Area_Estudio);
//print("Mosaico Planet",Planet)
// Definir la escala de la imagen (en metros)
var scale = nicfi.first().projection().nominalScale();
print(scale.getInfo())
//Calculo de NDVI
var NDVI = Planett.normalizedDifference(['N','R']).rename('NDVI');
//Map.centerObject(studyarea)
var vis = {"bands":["R","G","B"],"min":64,"max":5454,"gamma":1.8};
var vis_NDVI = {min:0,max:0.85,palette: ['8bc4f9', 'c9995c', 'c7d270','8add60','097210']};
leftMap.addLayer(Planett, vis, 'mosaic 2017');
leftMap.addLayer(NDVI,vis_NDVI, 'NDVI 2017'); 
leyendaModule.addLegendToMapNDVI(leftMap);
}
if (NDVI23_select === true) {
var nicfi = ee.ImageCollection('projects/planet-nicfi/assets/basemaps/americas');
// Filter basemaps by date and get the first image from filtered results
//'2022-01-01','2022-03-28'
var Planett= nicfi.filter(ee.Filter.date('2023-01-01','2023-12-30'))//Belice y RD Jura
                 .filterBounds(Area_Estudio)
                 .median()
                 .clip(Area_Estudio);
//print("Mosaico Planet",Planet)
// Definir la escala de la imagen (en metros)
var scale = nicfi.first().projection().nominalScale();
print(scale.getInfo())
//Calculo de NDVI
var NDVI = Planett.normalizedDifference(['N','R']).rename('NDVI');
//Map.centerObject(studyarea)
var vis = {"bands":["R","G","B"],"min":64,"max":5454,"gamma":1.8};
var vis_NDVI = {min:0,max:0.85,palette: ['8bc4f9', 'c9995c', 'c7d270','8add60','097210']};
rightMap.addLayer(Planett, vis, 'mosaic 2023');
rightMap.addLayer(NDVI,vis_NDVI, 'NDVI 2023');  
leyendaModule.addLegendToMapNDVI(rightMap);
}
//-----------------------------------------Calculo de indices espectrales-----------------------------------------------------//
/*//Agregar Índices espectrales al mosaico
var addIndices = require("users/leofabiop120/El_Salvador:addIndices_Landsat");
//Calcular los indices espectrales a cada mosaico
var mosaicoT1indices = addIndices.addIndices(Mosaico_13);
var mosaicoT2indices = addIndices.addIndices(Mosaico_17);
//print(mosaicoT1indices.bandNames())
*/
var Banda_NDVI = {min: 0,  max: 1, bands: ["NDVI"], palette: ['red', 'yellow', 'green']};
var Banda_NDWI = {min:-1,  max: 1, bands: ["NDWI"], palette: ['RED', 'ORANGE', 'YELLOW','CYAN','BLUE']};
var Banda_NDFI = {min:-1,  max: 1, bands: ["NDFI"], palette: ['GREEN', 'WHITE','BLUE']};
var Banda_EVI =  {min:-5,  max: 5, bands: ["EVI" ], palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
                                                              '74A901', '66A000', '529400', '3E8601', '207401', '056201',
                                                              '004C00', '023B01', '012E01', '011D01', '011301']
};
if (AP_select === true){
leftMap.addLayer(ee.Image().paint(AP,1,2), {'palette': 'green','width':1},'Areas Protegidas',true);
rightMap.addLayer(ee.Image().paint(AP,1,2), {'palette': 'green','width':1},'Area Protegidas',true);
}
if (MC_select === true){
leftMap.addLayer(ee.Image().paint(MC,1,2), {'palette': 'blue','width':1},'Microcuencas',true);
rightMap.addLayer(ee.Image().paint(MC,1,2), {'palette': 'blue','width':1},'Microcuencas',true);
}
if (AA_select === true){
leftMap.addLayer(ee.Image().paint(AA,1,2), {'palette': 'orange','width':1},'Areas Asignada',true);
rightMap.addLayer(ee.Image().paint(AA,1,2), {'palette': 'orange','width':1},'Areas Asignada',true);
}
if (PM_select === true){
leftMap.addLayer(ee.Image().paint(PM,1,2), {'palette': 'yellow','width':1},'Planes de Manejo',true);
rightMap.addLayer(ee.Image().paint(PM,1,2), {'palette': 'yellow','width':1},'Planes de Manejo',true);
//leftMap .addLayer(mosaicoT1indices, Banda_EVI,'EVI-2013',true);
//rightMap.addLayer(mosaicoT2indices, Banda_EVI,'EVI-2017',true);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//****************************************OBTENER PARAMETROS ESTADÍSTICOS**************************************//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// add checkbox to activate selector when checkbox is clicked
var checkbox = ui.Checkbox({label: 'Indentificador (Dar clic Mapa Izquierdo)', style: {position: 'top-center'}});
INFOPANEL = ui.Panel({ style: {position: 'middle-left' }});
checkbox.onChange(function(checked) {
leftMap.style().set('cursor', checked ? 'crosshair' : 'hand');
// Crear el mapa y el panel del inspector.
//leftMap.style().set('cursor', 'crosshair');
var inspector = ui.Panel([ui.Label('Click en un punto del mapa')]);
leftMap.add(inspector);
// Función para actualizar el panel del inspector al hacer clic en el mapa.
//leftMap.onClick(function(coords) {
  // Mostrar mensaje de carga.
  inspector.widgets().set(0, ui.Label({
    value: 'Cargando...',
    style: {color: 'gray'}
  }));
//COORDINATES
leftMap.onClick(function(coords) {
// Añadir el mapa a la interfaz de usuario.
var Label_Fisiograficos = ui.Label('Datos Fisiográficos:')
var Linea_Divisora = ui.Label('_____________________________________________')
var Linea_Divisora2 = ui.Label('_____________________________________________')
var Label_Cobertura = ui.Label('Datos Cobertura:')
var Label_Clima = ui.Label('Datos Clima:')
  var lon = ui.Label();
  var lat = ui.Label();
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2)),
  lat.setValue('lat: ' + coords.lat.toFixed(2));
var location = 'lon: ' + coords.lon.toFixed(5) + ' ' +
                 'lat: ' + coords.lat.toFixed(5);
  // Add a red dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'FF0000'}, 'Point');
  //Map.layers().set(10, dot);
var latLabel = ui.Label({
    value: 'Latitud: ' + Math.round(coords.lat * 1000) / 1000,
    style: {fontFamily:'Century Gothic',  fontSize: '10px'}
    });
 var lonLabel = ui.Label({
    value: 'Longitud: ' + Math.round(coords.lon * 1000) / 1000,
    style: {fontFamily:'Century Gothic',  fontSize: '10px'}
    });  
var panel_lat_long = ui.Panel({
        widgets: [latLabel,lonLabel],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
var SRTM = ee.Image("USGS/SRTMGL1_003");
var mean_value = SRTM.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: point,
    scale: 30,
    bestEffort: true,
    maxPixels: 1e12,
    tileScale:16
  })
var value_results_eleva = ee.Number(mean_value.get('elevation').getInfo());  
var Pendiente= ee.Algorithms.Terrain(SRTM)
              .select("slope")
              //.clip(studyarea);
var mean_value_slope = Pendiente.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: point,
    scale: 30,
    bestEffort: true,
    maxPixels: 1e12,
    tileScale:16
  })             
var value_results_slope = ee.Number(mean_value_slope.get('slope').getInfo());  
var Elevacion_label = ui.Label(
  {value: "Elevación:"+ " "+value_results_eleva.getInfo()+ " "+"msnm",
    style: { fontFamily:'Century Gothic',  fontSize: '10px'}
  })
var slope_label = ui.Label(
  {value: "Pendiente:"+ " "+value_results_slope.getInfo()+ " "+"°",
    style: { fontFamily:'Century Gothic',  fontSize: '10px'}
  })
var panel_Elevacion_Slope = ui.Panel({
        widgets: [Elevacion_label,slope_label],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
//----------------------------------------------------------------------------------------------------------------------------------//
//-----------------------------------------------Inspector para Cobertura-----------------------------------------------------------//
//----------------------------------------------------------------------------------------------------------------------------------//
// Añade tu capa al mapa (Asegúrate de que Nivel2 es una imagen de EE con la categoría codificada).
var Cober18 = Mapa_HN_masked;
//leftMap.addLayer(Nivel2, {min: 0, max: 31, palette: /* tu paleta de colores */}, 'Categorías');
// Define un objeto con los nombres de las categorías.
var categoryNamesCober = {
  1: 'Bosque Latifoliado Maduro',
  2: 'Bosque Latifoliado Deciduo',
  3: 'Bosque Mixto',
  4: 'Bosque Latifoliado Húmedo Inundable',
  5: 'Bosque de Conífera Denso',
  6: 'Bosque de Conífera Ralo',
  7: 'Bosque de Mangle Alto',
  8: 'Bosque de Mangle Bajo',
  9: 'Tique (Acoelorraphe wright)',
  10: 'Bosque de Conífera Plagado',
  11: 'Arboles Dispersos',
  12: 'Cafetales',
  13: 'Frutales',
  14: 'Vegetación Secundaria Húmeda',
  15: 'Vegetación Secundaria Decidua',
  16: 'sabanas',
  17: 'Palma Africana',
  18: 'Otras especies de Palmaa',
  19: 'Musácea',
  20: 'Caña de Azucar',
  21: 'Piña',
  22: 'Arrozales',
  23: 'Agricultura Tecnificada',
  24: 'Pastos/Cultivos',
  25: 'Zona Urbana Continua',
  26: 'Zona Urbana Discontinua',
  27: 'Zonas Industriales y Comerciales',
  28: 'Arenal de Playa',
  29: 'Suelo Desnudo Continental',
  30: 'Área Húmeda Continental',
  31: 'Área Húmeda Costero',
  32: 'Lagos y Lagunas Naturales de Agua Dulc',
  33: 'Cuerpos de Agua Artificial',
  34: 'Ríos y Otras Superficies de Agua Dulce',
  35: 'Mares y Océanos',
  36: 'Lagos y Lagunas Salitres',
  37: 'Camaroneras/salineras',
  };
  // Reduce la región de la imagen a ese punto para obtener la categoría.
  Cober18.reduceRegion({
    reducer: ee.Reducer.first(), // Use first to get the category value directly.
    geometry: point,
    scale: leftMap.getScale() // Reducir a la escala del mapa
  }).evaluate(function (result) {
    // Obtener la categoría y actualizar el panel.
    var categoryValueCober = result['b1']; // Asegúrate de reemplazar 'band_name' con el nombre de la banda real de Nivel2 que contiene las categorías.
    var categoryNameCober = categoryNamesCober[categoryValueCober];
    INFOPANEL.widgets().set(10, ui.Label({
      value: 'Cobertura: '+ categoryNameCober || 'Categoría no encontrada',
      style: {fontFamily:'Century Gothic',  fontSize: '10px'}
    }));
  });
//----------------------------------------------------------------------------------------------------------------------------------//
//--------------------------------------------------Inspector para BNB--------------------------------------------------------------//
//----------------------------------------------------------------------------------------------------------------------------------//
// Añade tu capa al mapa (Asegúrate de que Nivel2 es una imagen de EE con la categoría codificada).
var CoberBNB = reclass_cobertura_masked;
//leftMap.addLayer(Nivel2, {min: 0, max: 31, palette: /* tu paleta de colores */}, 'Categorías');
// Define un objeto con los nombres de las categorías.
var categoryNamesBNB = {
  1: 'Bosque',
  2: 'No Bosque',
  };
  // Reduce la región de la imagen a ese punto para obtener la categoría.
  CoberBNB.reduceRegion({
    reducer: ee.Reducer.first(), // Use first to get the category value directly.
    geometry: point,
    scale: leftMap.getScale() // Reducir a la escala del mapa
  }).evaluate(function (result) {
    // Obtener la categoría y actualizar el panel.
    var categoryValueBNB = result['b1']; // Asegúrate de reemplazar 'band_name' con el nombre de la banda real de Nivel2 que contiene las categorías.
    var categoryNameBNB = categoryNamesBNB[categoryValueBNB];
    INFOPANEL.widgets().set(11, ui.Label({
      value: 'BNB: '+ categoryNameBNB || 'Categoría no encontrada',
      style: {fontFamily:'Century Gothic',  fontSize: '10px'}
    }));
  });
//----------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------Inspector para Zonificación Nivel1------------------------------------------------------//
//----------------------------------------------------------------------------------------------------------------------------------//
// Añade tu capa al mapa (Asegúrate de que Nivel2 es una imagen de EE con la categoría codificada).
var Nivel_1 = nivel1_masked_reclass;
//leftMap.addLayer(Nivel2, {min: 0, max: 31, palette: /* tu paleta de colores */}, 'Categorías');
// Define un objeto con los nombres de las categorías.
var categoryNamesZ1 = {
  1: 'Zona de Desarrollo Agricola/Ganadera',
  2: 'Zona de Desarrollo Forestal',
  3: 'Zonas de Restauración de Paisajes',
  4: 'Zona de Baja Productividad Ambiental',
  5: 'Zonas de Desarrollo Poblacional',
  6: 'Cuerpos de Agua',
  7: 'Zona de Desarrollo Agroforestal',
  8: 'Sistemas Bajo Conflicto de Uso',
  9: 'Zona de Baja Productividad Ambiental',
  };
  // Reduce la región de la imagen a ese punto para obtener la categoría.
  Nivel_1.reduceRegion({
    reducer: ee.Reducer.first(), // Use first to get the category value directly.
    geometry: point,
    scale: leftMap.getScale() // Reducir a la escala del mapa
  }).evaluate(function (result) {
    // Obtener la categoría y actualizar el panel.
    var categoryValueZ1 = result['b1']; // Asegúrate de reemplazar 'band_name' con el nombre de la banda real de Nivel2 que contiene las categorías.
    var categoryNameZ1 = categoryNamesZ1[categoryValueZ1];
    INFOPANEL.widgets().set(12, ui.Label({
      value: 'Z1: '+ categoryNameZ1 || 'Categoría no encontrada',
      style: {fontFamily:'Century Gothic',  fontSize: '10px'}
    }));
  });
//----------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------Inspector para Zonificación Nivel2------------------------------------------------------//
//----------------------------------------------------------------------------------------------------------------------------------//
// Añade tu capa al mapa (Asegúrate de que Nivel2 es una imagen de EE con la categoría codificada).
var Nivel2 = nivel3_masked;
//leftMap.addLayer(Nivel2, {min: 0, max: 31, palette: /* tu paleta de colores */}, 'Categorías');
// Define un objeto con los nombres de las categorías.
var categoryNamesZ2 = {
  0: 'Sistema Agropecuario con Obras de Cons. de Suelo',
  1: 'Sistema Agro-Silvopastoriles',
  2: 'Protección Forestal',
  3: 'Sistema Agrícola de Baja Escala',
  4: 'Reforestación con fines Hídricos',
  5: 'Protección de Vegetación Arbustiva en Sucesión',
  6: 'Manejo de Regeneración con fines Hídricos',
  7: 'Conservación Hídrica',
  8: 'Manejo de Regeneración Natural para fines de Protección Forestal',
  9: 'Reforestación con Fines de Hídricos',
  10: 'Manejo de Vegetación Arbustiva en Sucesión',
  11: 'Conservación Forestal',
  12: 'Reforestación para fines de Protección Forestal',
  13: 'Reforestación con Fines de Conservación',
  14: 'Manejo de Regeneración Natural con Fines de Conservación',
  15: 'Obras de Conservación de Suelo',
  16: 'Necesidad Pública',
  17: 'Manejo de Restauración Natural',
  18: 'Cuerpos de Agua',
  19: 'Restauración Hídrica de Áreas Degradadas',
  20: 'Zona Urbana Con Baja Densidad Poblacional',
  21: 'Reforestación Implementada',
  22: 'Manejo Sostenible con Fines Productivos',
  23: 'Reforestación con Fines Productivos',
  24: 'Regeneración Natural Identificada en Campo',
  25: 'Manejo de Regeneración Natural con Fines Productivos',
  26: 'Zona Urbana Con Alta Densidad Poblacional',
  27: 'Manejo de Sistemas Agroforestales',
  28: 'Sistemas Agrícolas Técnificados',
  29: 'Sistemas Agroforestales en Conflicto',
  30: 'Zona Agroalimentaria Industrial en Conflicto',
  31: 'Obras de Conservación de Suelo y Agua'
};
  // Crear un punto con las coordenadas clickeadas.
 // var point = ee.Geometry.Point([coords.lon, coords.lat]);
  // Reduce la región de la imagen a ese punto para obtener la categoría.
  Nivel2.reduceRegion({
    reducer: ee.Reducer.first(), // Use first to get the category value directly.
    geometry: point,
    scale: leftMap.getScale() // Reducir a la escala del mapa
  }).evaluate(function (result) {
    // Obtener la categoría y actualizar el panel.
    var categoryValueZ2 = result['b1']; // Asegúrate de reemplazar 'band_name' con el nombre de la banda real de Nivel2 que contiene las categorías.
    var categoryNameZ2 = categoryNamesZ2[categoryValueZ2];
    inspector.widgets().set(0, ui.Label({
      value: categoryNameZ2 || 'Categoría no encontrada'
    }));
      INFOPANEL.widgets().set(13, ui.Label({
      value: 'Z2: '+ categoryNameZ2 || 'Categoría no encontrada',
      style: {fontFamily:'Century Gothic',  fontSize: '10px'}
    }));
  });
//});
//----------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------Inspector para Precipitacion------------------------------------------------------//
//----------------------------------------------------------------------------------------------------------------------------------//
var Año_inicial = 2000;
var Año_Final = 2022;
// Datos de CHIRP
var CHIRP =  ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY")
  .select("precipitation")
  .filterBounds(Area_Estudio);
// Calculando la precipitación anual
var years = ee.List.sequence(Año_inicial, Año_Final);
var annualPrecip = ee.ImageCollection.fromImages(
  years.map(function(y) {
    var filtered = CHIRP.filter(ee.Filter.calendarRange(y, y, 'year'))
                         .sum()
                         .clip(Area_Estudio);
    return filtered.set('year', y)
                   .set('system:time_start', ee.Date.fromYMD(y, 1, 1));
  })
);
// Calculando el promedio de precipitación anual acumulada para los años de interes
var averageAnnualPrecip = annualPrecip.reduce(ee.Reducer.mean()).rename('averageAnnualPrecip').clip(Area_Estudio);
var mean_value_Prec = averageAnnualPrecip.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: point,
    scale: 5000,
    bestEffort: true,
    maxPixels: 1e12,
    tileScale:16
  }) 
var value_results_Prec = ee.Number(mean_value_Prec.get('averageAnnualPrecip').getInfo()); 
var Prec_label = ui.Label(
  {value: "Precipitación:" + " "+value_results_Prec.format("%(,.2f").getInfo()+ " "+"mm",
    style: { fontFamily:'Century Gothic',  fontSize: '10px'}
  })
//----------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------Inspector para Temperatura------------------------------------------------------//
//----------------------------------------------------------------------------------------------------------------------------------//
//Temperatura
var modisLSTday = ee.ImageCollection('MODIS/061/MOD11A1')
                                    .filterBounds(Area_Estudio)
                                    .filterDate('2010-01-01', '2022-12-01')
                                    .select('LST_Day_1km');
var modLSTday = ee.ImageCollection(modisLSTday).map(function(img) {
  return img.multiply(0.02).subtract(273.15).copyProperties(img,['system:time_start','system:time_end']); 
});
// Calculando el promedio de precipitación anual acumulada para los años de interes
var averageAnnualTemp = modLSTday.reduce(ee.Reducer.mean()).clip(Area_Estudio);
var mean_value_Temp = averageAnnualTemp.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: point,
    scale: 1000,
    bestEffort: true,
    maxPixels: 1e12,
    tileScale:16
  })             
var value_results_Temp = ee.Number(mean_value_Temp.get('LST_Day_1km_mean').getInfo());  
var Temp_label = ui.Label(
  {value: "Temperatura:"+ " "+value_results_Temp.format("%(,.2f").getInfo()+ " "+"°C",
    style: { fontFamily:'Century Gothic',  fontSize: '10px'}
  })
//----------------------------------------------------------------------------------------------------------------------------------//
//------------------------------------------Inspector para Sequia------------------------------------------------------//
//----------------------------------------------------------------------------------------------------------------------------------//
var dataset2 = ee.ImageCollection('IDAHO_EPSCOR/TERRACLIMATE')
                  //.first()
                 .filterDate("2000-01-01", "2020-12-31")
                  .select('pdsi')
                  //.mean()
                  .map(function(img) {
  var date = img.get('system:time_start');
  return img.multiply(0.01).clip(Area_Estudio)
  .set('system_time_start', date)
  .copyProperties(img,['system:time_start','system:time_end'])
 });
// Calculando el promedio de precipitación anual acumulada para los años de interes
var averageAnnualSequia = dataset2.reduce(ee.Reducer.mean()).clip(Area_Estudio);
var mean_value_Sequia = averageAnnualSequia.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: point,
    scale: 5000,
    bestEffort: true,
    maxPixels: 1e12,
    tileScale:16
  })             
var value_results_Sequia = ee.Number(mean_value_Sequia.get('pdsi_mean').getInfo());  
var Sequia_label = ui.Label(
  {value: "Sequia :"+ " "+value_results_Sequia.format("%(,.2f").getInfo()+ " "+"",
    style: { fontFamily:'Century Gothic',  fontSize: '10px'}
  })
INFOPANEL.clear();
INFOPANEL.widgets().set(0,Label_Fisiograficos);
INFOPANEL.widgets().set(1,panel_lat_long);
INFOPANEL.widgets().set(2,panel_Elevacion_Slope);
INFOPANEL.widgets().set(3,Linea_Divisora);
INFOPANEL.widgets().set(4,Label_Clima);
INFOPANEL.widgets().set(5,Prec_label);
INFOPANEL.widgets().set(6,Temp_label);
INFOPANEL.widgets().set(7,Sequia_label);
INFOPANEL.widgets().set(8,Linea_Divisora2);
INFOPANEL.widgets().set(9,Label_Cobertura);
//INFOPANEL.widgets().set(3,panel_NDVI_13_17);
//INFOPANEL.widgets().set(4,table);
/////////////////////////////////////////////////////////////////////////////////////////////
});
});
notesPanel_statistics.clear();
notesPanel_statistics.widgets().set(0, ui.Label({value: 'Datos', style: { textAlign: 'justify', color:'Midnightblue', stretch: 'horizontal',  
             fontFamily: 'Century Gothic', fontSize: '14px', backgroundColor: 'gray', fontWeight: 'Bold'}}));
notesPanel_statistics.widgets().set(1, checkbox);
notesPanel_statistics.widgets().set(2, INFOPANEL);
notesPanel_statistics.widgets().set(3, ui.Label({value: 'Gráficos', style: { textAlign: 'justify', color:'Midnightblue', stretch: 'horizontal',  
             fontFamily: 'Century Gothic', fontSize: '14px', backgroundColor: 'gray', fontWeight: 'Bold'}}));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//***************************************************GRAFICOS**************************************************//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////***************************************GRAFICO DE AREA QUEMADA POR MES******************************************//
//Mapa_HN_18_select
if (Mapa_HN_18_select === true){
var classified = Mapa_HN_masked.rename('classification');
var worldCoverClassNames= [
             '0-No DAta',
             '1-Bosque Latifoliado Maduro',
             '2-Bosque Latifoliado Deciduo', 
             '3-Bosque Mixto',
             '4-Bosque Latifoliado Húmedo Inundable',
             '5-Bosque de Conífera Denso',
             '6-Bosque de Conífera Ralo',
             '7-Bosque de Mangle Alto',
             '8-Bosque de Mangle Bajo', 
             '9-Tique (Acoelorraphe wright)',
             '10-Bosque de Conífera Plagado',
             '11-Arboles Dispersos',
             '12-Cafetales',
             '13-Frutales',
             '14-Vegetación Secundaria Húmeda',
             '15-Vegetación Secundaria Decidua',
             '16-sabanas',
             '17-Palma Africana',
             '18-Otras especies de Palma',
             '19-Musácea',
             '20-Caña de Azucar',
             '21-Piña',
             '22-Arrozales',
             '23-Agricultura Tecnificada',
             '24-Pastos/Cultivos',
             '25-Zona Urbana Continua',
             '26-Zona Urbana Discontinua',
             '27-Zonas Industriales y Comerciales',
             '28-Arenal de Playa',
             '29-Suelo Desnudo Continental',
             '30-Área Húmeda Continental',
             '31-Área Húmeda Costero',
             '32-Lagos y Lagunas Naturales de Agua Dulce',
             '33-Cuerpos de Agua Artificial',
             '34-Ríos y Otras Superficies de Agua Dulce',
             '35-Mares y Océanos',
             '36-Lagos y Lagunas Salitres',
             '37-Camaroneras/salineras'];
// Define a list of class colors
var worldCoverPalette = [
    '000000', //0
    '006400', //1
    '8CA038', //2
    '4d5100', //3
    '357953', //4
    '437d12', //5
    '6dcd3d', //6
    '9f1fee', //7
    'ee82ee', //8
    'd24588', //9
    'a32a2a', //10
    '006400', //11 
    'c58000', //12
    '8775ad', //13
    'ffa600', //14
    'F4F4DB', //15
    'F4F4DB', //16
    '33615f', //17
    'a0522d', //18
    '004200', //19
    '851f4f', //20
    'ff6800', //21
    'e88573', //22
    'ffc0cc', //23
    'f7f45a', //24
    'e65214', //25
    'f60909', //26
    'a50000', //27
    'ffffff', //28
    '7f7f7f', //29
    '00ffff', //30
    '4183be', //31
    '009ee0', //32
    '0fbbee', //33
    '0000ff', //34
    '3869c7', //35
    '588e98', //36
    '00006f' //37 
    ];
// We define a dictionary with class names
var classNames = ee.Dictionary.fromLists(
  ['0','1','2','3','4','5','6','7','8','9', '10','11','12','13','14','15','16','17','18','19','20',
  '21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37'],
  worldCoverClassNames
);
// We define a dictionary with class colors
var classColors = ee.Dictionary.fromLists(
  ['0','1','2','3','4','5','6','7','8','9', '10','11','12','13','14','15','16','17','18','19','20',
  '21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37'],
  worldCoverPalette
);
var areaImage = ee.Image.pixelArea().divide(1e4);
var areaImageWithClass = areaImage.addBands(classified);
var areas = areaImageWithClass.reduceRegion({
      reducer: ee.Reducer.sum().group({
      groupField: 1,
      groupName: 'classification',
    }),
    geometry: Area_Estudio.geometry(),
    scale: 10,
    maxPixels: 1e10
    }); 
var classAreas = ee.List(areas.get('groups'))
var classAreaList = classAreas.map(function(item) {
  var areaDict = ee.Dictionary(item);
  var classNumber = areaDict.getNumber('classification').format();
  var classArea = areaDict.getNumber('sum');
  var className = classNames.get(classNumber);
  var classColor = classColors.get(classNumber);
  // Create a feature with geometry and 
  // required data as a dictionary
  return ee.Feature(Area_Estudio.geometry(), {
    'class': classNumber,
    'class_name': className,
    'Area': classArea,
    'color': classColor
  });
});
var classAreaFc = ee.FeatureCollection(classAreaList);
//print('Class Area (FeatureCollection)', classAreaFc);
var colors = classAreaFc.aggregate_array('color');
colors.evaluate(function(colorlist) {
  // Let's create a Pie Chart
  var areaChart = ui.Chart.feature.byFeature({
    features: classAreaFc,
    xProperty: 'class_name',
    yProperties: ['Area']
  }).setChartType('PieChart')
    .setOptions({
      title: 'Cobertura Forestal',
      colors: colorlist,
      pieSliceBorderColor: '#fafafa',
      pieSliceTextStyle: {'color': '#252525'}, 
      pieSliceText: 'percentage',
      //is3D: true,
      pieHole: 0.4,
      slices: {  0: {offset: 0.2},
               },
  });
  //print(areaChart); 
  notesPanel_statistics.widgets().set(4, areaChart);
})
}
//Mapa_BNB_18_select
if (Mapa_BNB_18_select === true){
var classifiedBNB = reclass_cobertura_masked.rename('classification');
var worldCoverClassNamesBNB= [
             '0-No DAta',
             'Bosque',
             'No Bosque' 
             ];
// Define a list of class colors
var worldCoverPaletteBNB = [
    '000000', //0
    'green', //1 Bosque
    'f7f45a', //2 No Bosque 
    ];
// We define a dictionary with class names
var classNamesBNB = ee.Dictionary.fromLists(
  ['0','1','2'],
  worldCoverClassNamesBNB
);
// We define a dictionary with class colors
var classColorsBNB = ee.Dictionary.fromLists(
  ['0','1','2'],
  worldCoverPaletteBNB
);
var areaImageBNB = ee.Image.pixelArea().divide(1e4);
var areaImageWithClassBNB = areaImageBNB.addBands(classifiedBNB);
var areasBNB = areaImageWithClassBNB.reduceRegion({
      reducer: ee.Reducer.sum().group({
      groupField: 1,
      groupName: 'classification',
    }),
    geometry: Area_Estudio.geometry(),
    scale: 10,
    maxPixels: 1e10
    }); 
var classAreasBNB = ee.List(areasBNB.get('groups'))
var classAreaListBNB = classAreasBNB.map(function(item) {
  var areaDictBNB = ee.Dictionary(item);
  var classNumberBNB = areaDictBNB.getNumber('classification').format();
  var classAreaBNB = areaDictBNB.getNumber('sum');
  var classNameBNB = classNamesBNB.get(classNumberBNB);
  var classColorBNB = classColorsBNB.get(classNumberBNB);
  // Create a feature with geometry and 
  // required data as a dictionary
  return ee.Feature(Area_Estudio.geometry(), {
    'class': classNumberBNB,
    'class_name': classNameBNB,
    'Area': classAreaBNB,
    'color': classColorBNB
  });
});
var classAreaFcBNB = ee.FeatureCollection(classAreaListBNB);
//print('Class Area (FeatureCollection)', classAreaFc);
var colorsBNB = classAreaFcBNB.aggregate_array('color');
colorsBNB.evaluate(function(colorlistBNB) {
  // Let's create a Pie Chart
  var areaChartBNB = ui.Chart.feature.byFeature({
    features: classAreaFcBNB,
    xProperty: 'class_name',
    yProperties: ['Area']
  }).setChartType('PieChart')
    .setOptions({
      title: 'Bosque y No Bosque',
      colors: colorlistBNB,
      pieSliceBorderColor: '#fafafa',
      pieSliceTextStyle: {'color': '#252525'}, 
      pieSliceText: 'percentage',
      //is3D: true,
      pieHole: 0.4,
      slices: {  2: {offset: 0.2},
               },
  });
  //print(areaChart); 
  notesPanel_statistics.widgets().set(5, areaChartBNB);
})
}
//Zonificacion1_select
if (Zonificacion1_select === true){
var classifiedZ1 = nivel1_masked_reclass.rename('classification');
var worldCoverClassNamesZ1= [
    '0-No DAta',
    'Zona de Desarrollo Agricola/Ganadera',
    'Zona de Desarrollo Forestal',
    'Zonas de Restauración de Paisajes',
    'Zona de Baja Productividad Ambiental',
    'Zonas de Desarrollo Poblacional',
    'Cuerpos de Agua',
    'Zona de Desarrollo Agroforestal',
    'Sistemas Bajo Conflicto de Uso'
             ];
// Define a list of class colors
var worldCoverPaletteZ1 = [
'000000', //0
'FFFFE0', // 1 = Zona de Desarrollo Agricola/Ganaderal
'228B22', // 2 = Zona de Desarrollo Forestal
'90EE90', // 3 = Zonas de Restauración de Paisajes
'D3D3D3', // 4 = Zona de Baja Productividad Ambiental
'800000', // 5 = Zonas de Desarrollo Poblacional
'87CEFA', // 6 = Cuerpos de Agua
'B8860B', // 7 = Zona de Desarrollo Agroforestal
'DC143C' // 8 = Sistemas Bajo Conflicto de Uso
    ];
// We define a dictionary with class names
var classNamesZ1 = ee.Dictionary.fromLists(
  ['0','1','2','3','4','5','6','7','8'],
  worldCoverClassNamesZ1
);
// We define a dictionary with class colors
var classColorsZ1 = ee.Dictionary.fromLists(
  ['0','1','2','3','4','5','6','7','8'],
  worldCoverPaletteZ1
);
var areaImageZ1 = ee.Image.pixelArea().divide(1e4);
var areaImageWithClassZ1 = areaImageZ1.addBands(classifiedZ1);
var areasZ1 = areaImageWithClassZ1.reduceRegion({
      reducer: ee.Reducer.sum().group({
      groupField: 1,
      groupName: 'classification',
    }),
    geometry: Area_Estudio.geometry(),
    scale: 30,
    maxPixels: 1e10
    }); 
var classAreasZ1 = ee.List(areasZ1.get('groups'))
var classAreaListZ1 = classAreasZ1.map(function(item) {
  var areaDictZ1 = ee.Dictionary(item);
  var classNumberZ1 = areaDictZ1.getNumber('classification').format();
  var classAreaZ1 = areaDictZ1.getNumber('sum');
  var classNameZ1 = classNamesZ1.get(classNumberZ1);
  var classColorZ1 = classColorsZ1.get(classNumberZ1);
  // Create a feature with geometry and 
  // required data as a dictionary
  return ee.Feature(Area_Estudio.geometry(), {
    'class': classNumberZ1,
    'class_name': classNameZ1,
    'Area': classAreaZ1,
    'color': classColorZ1
  });
});
var classAreaFcZ1 = ee.FeatureCollection(classAreaListZ1);
//print('Class Area (FeatureCollection)', classAreaFc);
var colorsZ1 = classAreaFcZ1.aggregate_array('color');
colorsZ1.evaluate(function(colorlistZ1) {
  // Let's create a Pie Chart
  var areaChartZ1 = ui.Chart.feature.byFeature({
    features: classAreaFcZ1,
    xProperty: 'class_name',
    yProperties: ['Area']
  }).setChartType('PieChart')
    .setOptions({
      title: 'Zonificación Nivel 1',
      colors: colorlistZ1,
      pieSliceBorderColor: '#fafafa',
      pieSliceTextStyle: {'color': '#252525'}, 
      pieSliceText: 'percentage',
      //is3D: true,
      pieHole: 0.4,
      slices: {  3: {offset: 0.2},
               },
  });
  //print(areaChart); 
  notesPanel_statistics.widgets().set(6, areaChartZ1);
})
}
//Zonificacion1_select
if (Zonificacion2_select === true){
var classifiedZ2 = nivel3_masked.rename('classification');
var worldCoverClassNamesZ2= [
    'Sistema Agropecuario con Obras de Cons. de Suelo',
    'Sistema Agro-Silvopastoriles',
    'Protección Forestal',
    'Sistema Agrícola de Baja Escala',
    'Reforestación con fines Hídricos',
    'Protección de Vegetación Arbustiva en Suceción',
    'Manejo de Regeneración con fines Hídricos',
    'Conservación Hídrica',
    'Manejo de Regeneración Natural para fines de Protección Forest',
    'Reforestación con Fines de Hídricos',
    'Manejo de Vegetación Arbustiva en Suceción',
    'Conservación Forestal',
    'Reforestación para fines de Protección Forestal',
    'Reforestación con Fines de Conservación',
    'Manejo de Regeneración Natural con Fines de Conservación',
    'Obras de Conservación de Suelo',
    'Necesidad Pública',
    'Manejo de Restauración Natural',
    'Cuerpos de Agua',
    'Restauración Hidríca de Areas Degradadas',
    'Zona Urbana Con Baja Densidad Poblacional',
    'Reforestación Implementada',
    'Manejo Sostenible con Fines Productivos',
    'Reforestación con Fines Productivos',
    'Regeneración Natural Indentificada en Campo',
    'Manejo de Regeneración Natural con Fines Productivos',
    'Zona Urbana Con Alta Densidad Poblacional',
    'Manejo de Sistemas Agroforestales',
    'Sistemas Agrícolas Técnificados',
    'Sistemas Agroforestales en Conflicto',
    'Zona Agroalimentaria Industrial en Conflicto',
    'Obras de Conservación de Suelo y Agua'
             ];
// Define a list of class colors
var worldCoverPaletteZ2= [
  '6DB65B', // Sistema Agropecuario con Obras de Cons. de Suelo - Verde
  '967117', // Sistema Agro-Silvopastoriles - Marrón dorado
  '228B22', // Protección Forestal - Verde bosque
  'F4A460', // Sistema Agrícola de Baja Escala - Marrón arena
  '4682B4', // Reforestación con fines Hídricos - Azul acero
  '9ACD32', // Protección de Vegetación Arbustiva en Suceción - Verde amarillento
  '32CD32', // Manejo de Regeneración con fines Hídricos - Verde lima
  '00CED1', // Conservación Hídrica - Turquesa oscuro
  '3CB371', // Manejo de Regeneración Natural para fines de Protección Forestal - Verde mar medio
  '4682B4', // Reforestación con Fines de Hídricos - Azul acero
  '9ACD32', // Manejo de Vegetación Arbustiva en Suceción - Verde amarillento
  '006400', // Conservación Forestal - Verde oscuro
  '556B2F', // Reforestación para fines de Protección Forestal - Verde oliva oscuro
  '66CDAA', // Reforestación con Fines de Conservación - Aguamarina medio
  '8FBC8F', // Manejo de Regeneración Natural con Fines de Conservación - Verde mar oscuro
  'BDB76B', // Obras de Conservación de Suelo - Caqui oscuro
  'B22222', // Necesidad Pública - Ladrillo refractario
  '8B4513', // Manejo de Restauración Natural - SaddleBrown
  '1E90FF', // Cuerpos de Agua - DodgerBlue
  '2E8B57', // Restauración Hidríca de Areas Degradadas - Verde mar
  'A9A9A9', // Zona Urbana Con Baja Densidad Poblacional - Gris oscuro
  '32CD32', // Reforestación Implementada - Verde lima
  'FFD700', // Manejo Sostenible con Fines Productivos - Oro
  'FFA500', // Reforestación con Fines Productivos - Naranja
  '90EE90', // Regeneración Natural Indentificada en Campo - Verde claro
  'FFD700', // Manejo de Regeneración Natural con Fines Productivos - Oro
  'FF4500', // Zona Urbana Con Alta Densidad Poblacional - Naranja rojizo
  '8B4513', // Manejo de Sistemas Agroforestales - SaddleBrown
  'DAA520', // Sistemas Agrícolas Técnificados - Oro vara
  'FF6347', // Sistemas Agroforestales en Conflicto - Tomate
  'FF0000', // Zona Agroalimentaria Industrial en Conflicto - Rojo
  'DEB887' // Obras de Conservación de Suelo y Agua - Burlywood
    ];
// We define a dictionary with class names
var classNamesZ2 = ee.Dictionary.fromLists(
  ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20',
  '21','22','23','24','25','26','27','28','29','30','31'],
  worldCoverClassNamesZ2
);
// We define a dictionary with class colors
var classColorsZ2 = ee.Dictionary.fromLists(
  ['0','1','2','3','4','5','6','7','8','9', '10','11','12','13','14','15','16','17','18','19','20',
  '21','22','23','24','25','26','27','28','29','30','31'],
  worldCoverPaletteZ2
);
var areaImageZ2 = ee.Image.pixelArea().divide(1e4);
var areaImageWithClassZ2 = areaImageZ2.addBands(classifiedZ2);
var areasZ2 = areaImageWithClassZ2.reduceRegion({
      reducer: ee.Reducer.sum().group({
      groupField: 1,
      groupName: 'classification',
    }),
    geometry: Area_Estudio.geometry(),
    scale: 30,
    maxPixels: 1e10
    }); 
var classAreasZ2 = ee.List(areasZ2.get('groups'))
var classAreaListZ2 = classAreasZ2.map(function(item) {
  var areaDictZ2 = ee.Dictionary(item);
  var classNumberZ2 = areaDictZ2.getNumber('classification').format();
  var classAreaZ2 = areaDictZ2.getNumber('sum');
  var classNameZ2 = classNamesZ2.get(classNumberZ2);
  var classColorZ2 = classColorsZ2.get(classNumberZ2);
  // Create a feature with geometry and 
  // required data as a dictionary
  return ee.Feature(Area_Estudio.geometry(), {
    'class': classNumberZ2,
    'class_name': classNameZ2,
    'Area': classAreaZ2,
    'color': classColorZ2
  });
});
var classAreaFcZ2 = ee.FeatureCollection(classAreaListZ2);
//print('Class Area (FeatureCollection)', classAreaFc);
var colorsZ2 = classAreaFcZ2.aggregate_array('color');
colorsZ2.evaluate(function(colorlistZ2) {
  // Let's create a Pie Chart
  var areaChartZ2 = ui.Chart.feature.byFeature({
    features: classAreaFcZ2,
    xProperty: 'class_name',
    yProperties: ['Area']
  }).setChartType('PieChart')
    .setOptions({
      title: 'Zonificación Nivel 2',
      colors: colorlistZ2,
      pieSliceBorderColor: '#fafafa',
      pieSliceTextStyle: {'color': '#252525'}, 
      pieSliceText: 'percentage',
      //is3D: true,
      pieHole: 0.4,
      slices: {  3: {offset: 0.2},
               },
  });
  //print(areaChart); 
  notesPanel_statistics.widgets().set(7, areaChartZ2);
})
}
if (Incendios_MODIS_select === true){
var fire_modis = ee.ImageCollection('MODIS/061/MCD64A1')
  .select('BurnDate');
var years = ee.List.sequence(2001, 2022);
var months = ee.List.sequence(1, 12);
var monthlyFire = ee.ImageCollection.fromImages(
  years.map(function (year) {
    return months.map(function(month){
      var monthly = fire_modis
          .filter(ee.Filter.calendarRange(year, year, 'year'))
          .filter(ee.Filter.calendarRange(month, month, 'month'))
          .map(function(image) {
            return image.gte(1).rename('Burned').set('year', year).set('month', month);
          })
          .sum()
          .selfMask();  // Aseguramos que la imagen tenga datos
      return monthly.updateMask(Area_Protegida)
        .set('year', year)
        .set('month', month)
        .set('system:time_start', ee.Date.fromYMD(year, month, 1));
    });
}).flatten());
var lossByMonth = monthlyFire.map(function(image) {
  var lossImage = image.multiply(ee.Image.pixelArea().divide(10000)).rename('Area');
  var stats = lossImage.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: Area_Estudio,
    scale: 500,
    maxPixels: 1e12
  });
  return ee.Feature(null, {
    'date': ee.Date.fromYMD(image.get('year'), image.get('month'), 1),
    'area': stats.get('Area')
  });
}).filter(ee.Filter.notNull(['area']));  // Solo consideramos los elementos que tienen un área
var statsList = lossByMonth.reduceColumns({
  reducer: ee.Reducer.toList(2),
  selectors: ['date', 'area']
}).get('list');
var statsFormatted = ee.List(statsList)
  .map(function(el) {
    var list = ee.List(el);
    return [ee.Date(list.get(0)).format("YYYY-MM"), list.get(1)];
  });
var statsDictionary = ee.Dictionary(statsFormatted.flatten());
var chart_Loss = ui.Chart.array.values({
  array: statsDictionary.values(),
  axis: 0,
  xLabels: statsDictionary.keys()
}).setChartType('ColumnChart')
  .setOptions({
    title: 'Área quemada por Mes (MODIS)',
    hAxis: {title: 'Fecha', format: 'YYYY-MM'},
    vAxis: {title: 'Área: ha'},
    legend: { position: "none" },
    lineWidth: 1,
    pointSize: 3,
    colors: ['red']
  });
tsChart.widgets().reset([chart_Loss]); 
}
if (Defo_Hansen_select === true){
// Create an area image and convert to Hectares
var areaImage = ee.Image.pixelArea().divide(1e5);
// Add the band containing yearly loss
var areaImageWithYear = areaImage.addBands(lossYear);
var areas = areaImageWithYear.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'year'
    }),
  geometry: Area_Estudio,
  scale: 30,
  maxPixels: 1e10
});
var yearAreas = ee.List(areas.get('groups'));
// Process results to extract the areas and
// create a list
var yearAreasList = ee.List(yearAreas.map(function(item) {
  var areaDict = ee.Dictionary(item);
  var yearString = ee.Number(areaDict.get('year')).format('20%02d');
  var area = ee.Number(
    areaDict.get('sum'));
  return ee.List([yearString, area])
}));
//print('Year Areas', yearAreasList);
// We create a list of rows in the DataTable format
var rowList = yearAreasList.map(function(item) {
  var year = ee.List(item).get(0);
  var x = ee.String('Date(')
    .cat(year)
    .cat(', ')
    .cat('0')
    .cat(', ')
    .cat('1')
    .cat(ee.String(')'))
  var y = ee.List(item).get(1);
  // We will assign the color to each year from the palette
  var color = ee.List(palette).get(yearAreasList.indexOf(item));
  var rowDict = {
    c: [{v: x}, {v: y}, {v: color}]
  };
  return rowDict;
});
//print('Rows', rowList);
// Create the DataTable
rowList.evaluate(function(rowListClient) {
  var dataTable = {
    cols: [
      {id: 'x', type: 'date'},
      {id: 'y', label: 'area', type: 'number'},
      {id: 'style', label: 'Style', type: 'string', role: 'style'},
    ],
    rows: rowListClient
  };
  var options = {
    title: 'Pérdida de Bosque Anual (Hansen 2000-2022)',
    vAxis: {
      title: 'Area (Hectares)', 
    },
    hAxis: {
      title: 'Year',
      gridlines: {color: 'transparent'}
    },
    legend: {position:'none'},
    //height: '400px',
    //width: '600px'
  };
  var chart = ui.Chart(dataTable, 'ColumnChart', options);
  // Add the chart on the map
  //Map.add(chartPanel);
  tsChart.widgets().reset([chart]); 
});
}
if (Defo_HN_select === true) {
//************************------------Estimación de áreas por tipo de clase por héctarea-------------************************************//
var areas = ee.Image.pixelArea().divide(10000).addBands(Defo_HN)
var reduc = areas.reduceRegion({
        reducer: ee.Reducer.sum().unweighted().group(1),
        geometry: Area_Estudio,
        'maxPixels': 1e12,
        scale: 30
    })
var noml = ee.List(["","2000-2006","2006-2012", "2012-2016", "2016-2018"])
var groups = ee.List(reduc.get("groups"))
var newred = groups.map(function(e){
  var dict = ee.Dictionary(e)
  var grupo = dict.get("group")
  var nom = noml.get(grupo)
  var newdict = dict.set("label", nom)
  return newdict
})
//print('Area ',  newred);
//************************************************************************************************************************//
//***************************-------------Parámetros para configuración de Gráficos-----------------**********************.
//------------------*********************************************************************************---------------------//
// Propiedades del Gráfico//.
  var options = {
  lineWidth: 1,
  pointSize: 2,
  hAxis: {title: 'Deforestación por Período HN'},
  vAxis: {title: 'Área (ha)'},
  title: 'Estimación de Área: Deforestación',
  colors: ['FF1493', 'FF8C00', 'FFD700', 'DC143C']
};
//Agragar Gráfico//
var chartArea = ui.Chart.image.byClass
({image: areas,
  classBand: "area",
  reducer: ee.Reducer.sum().unweighted(),
  scale: 100,
  region: Area_Estudio.geometry(),
  classLabels: noml})
.setOptions(options);
notesPanel_statistics.widgets().set(8, chartArea);
}
if (Precipitacion_select === true) {
// set start and end year
var startyear = 2000; 
var endyear = 2023;
// make a list with years
var years = ee.List.sequence(startyear, endyear);
// make a list with months
var months = ee.List.sequence(1, 12);
//var chirps = ee.ImageCollection('IDAHO_EPSCOR/TERRACLIMATE')
var chirps =  ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY")
  .select("precipitation")
  .filterBounds(Area_Estudio);
var annualPrecip = ee.ImageCollection.fromImages(
  years.map(function (year) {
    var annual = chirps
        .filter(ee.Filter.calendarRange(year, year, 'year'))
        .sum();
    return annual
        .set('year', year)
        .set('system:time_start', ee.Date.fromYMD(year, 1, 1));
}));
var monthlyPrecip =  ee.ImageCollection.fromImages(
  years.map(function (y) {
    return months.map(function(m) {
      var w = chirps.filter(ee.Filter.calendarRange(y, y, 'year'))
                    .filter(ee.Filter.calendarRange(m, m, 'month'))
                    .sum();
      return w.set('year', y)
              .set('month', m)
              .set('system:time_start', ee.Date.fromYMD(y, m, 1));
    });
  }).flatten()
);
var atitle = {
  title: 'Precipitación Anual',
  hAxis: {title: 'Time'},
  vAxis: {title: 'Precipitation (mm)'},
};
var chartannual = ui.Chart.image.seriesByRegion({
  imageCollection: annualPrecip, 
  regions: Area_Estudio.geometry(),
  reducer: ee.Reducer.mean(),
  band: 'precipitation',
  scale: 5566,
  xProperty: 'system:time_start',
  seriesProperty: 'SITE'
}).setOptions(atitle)
  .setChartType('ColumnChart');
//print(chartannual);
notesPanel_statistics.widgets().set(9, chartannual);
var atitle = {
  title: 'Precipitación Mensual',
  hAxis: {title: 'Time'},
  vAxis: {title: 'Precipitation (mm)'},
};
var chartmonthly = ui.Chart.image.seriesByRegion({
  imageCollection: monthlyPrecip, 
  regions: Area_Estudio.geometry().bounds(),
  reducer: ee.Reducer.mean(),
  band: 'precipitation',
  scale: 5566,
  xProperty: 'system:time_start',
  seriesProperty: 'SITE'
}).setOptions(atitle)
  .setChartType('ColumnChart');
//print(chartmonthly);
notesPanel_statistics.widgets().set(10, chartmonthly);
//CLIMOGRAMA
var Col = ee.ImageCollection('IDAHO_EPSCOR/TERRACLIMATE');
//Renames
function changeBandName(image) {
  return image.select(
  ['aet','pet','pr'],  
  ['ETr','ETP','P'])}
var newCol = changeBandName(Col)
var Varibles_Interes = newCol.select(['ETr','ETP','P'])
                             //.filter(ee.Filter.date('2019-01-01', '2019-12-31'))
//print('Variables_Interes',Varibles_Interes)
var Calculo = Varibles_Interes.map(function(img) {
  var date = img.get('system:time_start');
  return img.select('ETr').multiply(0.1)
  .addBands(img.select('ETP').multiply(0.1))
  .addBands(img.select('P').multiply(1))
  .set('system_time_start', date)
  .copyProperties(img,['system:time_start','system:time_end'])
 });
// Let's compute seasonal rainfall deviation for the state
var lpaYears = ee.List.sequence(1981, 2020)
var months = ee.List.sequence(1, 12)
// Map over the years and create a monthly totals collection
var monthlyImages = lpaYears.map(function(year) {
  return months.map(function(month) {
    var filtered = Calculo.select(['ETr','ETP','P'])
      .filter(ee.Filter.calendarRange(year, year, 'year'))
      .filter(ee.Filter.calendarRange(month, month, 'month'))
    var monthly = filtered.sum()
    return monthly.set({'month': month, 'year': year})
  })
}).flatten()
// We now have 1 image per month for entire long-period duratioon
var monthlyCol = ee.ImageCollection.fromImages(monthlyImages)
// We can compute average for each month across all years
// i.e. Average July precipitation for all July months in the collection
var longTermMeans = months.map(function(month) {
    var filtered = monthlyCol.filter(ee.Filter.eq('month', month))
    var monthlyMean = filtered.mean()
    return monthlyMean.set('month', month)
})
var monthlyRainfall = ee.ImageCollection.fromImages(longTermMeans).sum()
//print('longTermMeans',longTermMeans)
 // Create an NDVI chart.
  var indexChart = ui.Chart.image.series({
   imageCollection: longTermMeans,//.select(['ETr','ETP','P']),
   region: Area_Estudio,
   reducer: ee.Reducer.mean(),
   scale: 3000,
   xProperty: 'month'
});
  indexChart.setOptions({
    title: 'Climograma',
    curveType:'function',  
    vAxis: {title: 'mm'},
    hAxis: {title: 'Fecha', format: 'month'},
    lineWidth: 3,
     colors: ['blue', 'green','red'],
     });
  indexChart.setSeriesNames(['ETr','ETP','P']); //,'GNDVI','NBRI','NDWI','NDSI'
  //print(indexChart);
  notesPanel_statistics.widgets().set(11, indexChart);
}
if (Temperatura_select === true) {
//Temperatura
var modisLSTday = ee.ImageCollection("MODIS/061/MOD11A1").filterBounds(Area_Estudio).filterDate('2010-01-01', '2022-12-01').select('LST_Day_1km');
var modLSTday =ee.ImageCollection(modisLSTday).map(function(img) {
  return img.multiply(0.02).subtract(273.15).copyProperties(img,['system:time_start','system:time_end']); 
});
var Temp_Chart = ui.Chart.image.series({
  imageCollection: modLSTday,
   region: Area_Estudio.geometry().bounds(),
   reducer: ee.Reducer.mean(),
  scale: 5000,
  xProperty: 'system:time_start'
});
  Temp_Chart.setOptions({
    title: 'Temperatura Superficial',
    curveType:'function',  
    vAxis: {title: 'Grados C'},
    hAxis: {title: 'Fecha', format: 'MMM-YY'},
    lineWidth: 3,
     colors: ['red'],
     });
  notesPanel_statistics.widgets().set(12, Temp_Chart);
}
// #############################################################################
// ### ANÁLISIS HANSEN ###
// #############################################################################
if (Check_Hansen_select === true){
//To display as a map
//var gfc2019 = ee.Image('UMD/hansen/global_forest_change_2019_v1_7');
//Whole script
var lossImage = Col_Hansen.select(['loss']);
var mask2 = lossImage.clip(Area_Estudio);
var gainImage = Col_Hansen.select(['gain']);
var mask3 = gainImage.clip(Area_Estudio);
var lossYear  = Col_Hansen.select(['lossyear']); 
var def_2013_2017 = lossYear.gte(13).and(lossYear.lte(17)).clip(Area_Estudio);
var def_2013_2017 = def_2013_2017.updateMask(def_2013_2017);
// Add the treecover2000 layer.
var treeCoverVisParam = {
  bands: ['treecover2000'],
  min: 0,
  max: 100,
  palette: ['Cornsilk', 'green']
};
rightMap.addLayer(Col_Hansen.clip(Area_Estudio), treeCoverVisParam, 'Cobertura Bosque 2000 (Hansen)');
// Add the loss layer in red.
var treeLossVisParam = {
  //bands: ['lossyear'],
  min: 13,
  max: 17,
  palette: ['DeepPink']
};
rightMap.addLayer(def_2013_2017, treeLossVisParam, 'Pérdida Acumuladas 2013-2017 (Hansen)');
// Get the loss image.
// This dataset is updated yearly, so we get the latest version.
//var Col_Hansen = ee.Image('UMD/hansen/global_forest_change_2021_v1_9');
var lossImage = Col_Hansen.select(['loss']);
var lossAreaImage = lossImage.multiply(ee.Image.pixelArea().divide(10000));
var lossYear = Col_Hansen.select(['lossyear']);
var lossByYear = lossAreaImage.addBands(lossYear).reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1
    }),
  geometry: Area_Estudio,
  scale: 30,
  maxPixels: 1e9
});
//print(lossByYear);
//Notice that we are using the format() method to convert the year values from 0-18 to 2000-2018.
var statsFormatted = ee.List(lossByYear.get('groups'))
  .map(function(el) {
    var d = ee.Dictionary(el);
    return [ee.Number(d.get('group')).format("20%02d"), d.get('sum')];
  });
var statsDictionary = ee.Dictionary(statsFormatted.flatten());
print(statsDictionary);
//prepare a chart
var chart_Loss = ui.Chart.array.values({
  array: statsDictionary.values(),
  axis: 0,
  xLabels: statsDictionary.keys()
}).setChartType('ColumnChart')
  .setOptions({
    title: 'Pérdida de Bosque por Año (Hansen)',
    hAxis: {title: 'Años', format: '####'},
    vAxis: {title: 'Área: ha'},
    legend: { position: "none" },
    lineWidth: 1,
    pointSize: 3,
    colors: ['Salmon']
  });
tsChart.widgets().reset([chart_Loss]); 
//**************************************************Inspector para determinar el año de pérdida Hansen*************************************************//
leftMap.style().set('cursor', 'crosshair');
// Create a panel and add it to the map.
 var inspector = ui.Panel([ui.Label('Dar clic en un Polígono')]);
leftMap.add(inspector);
var image = Col_Hansen.clip(Area_Estudio)
leftMap.addLayer(image.updateMask(def_2013_2017), {bands: 'lossyear', min: 13, max: 17, palette: '#085CF8, #3C9E49, #98BB18, #F3CC1D, #FE8F7B, #F64497, #D70500'}, 'Pérdidas por Año 2013-2017 (Hansen)')
leftMap.onClick(function(coords) {
  // Show the loading label.
  inspector.widgets().set(0, ui.Label({
    value: 'Loading...',
    style: {color: 'gray'}
  }));
  var point = ee.Geometry.Point([coords.lon, coords.lat])
  image
    .reduceRegion({
      reducer: ee.Reducer.mean(), 
      geometry: point, 
      scale: leftMap.getScale() // Reduce at the scale of the map
    })
    .evaluate(function (data) { // Get the value in the background
      inspector.widgets().set(0, ui.Label({
        value: typeof data.lossyear === 'number'
          ? data.lossyear + 2000
          : 'no loss'
      }))
    })
})
//*******************************************CALCULO DE AREA***************************************//
var area_2013_2017 = def_2013_2017.multiply(ee.Image.pixelArea().divide(10000));
// Calcular la superficie de perdida en Héctarea
var stats = area_2013_2017.reduceRegion({
  reducer: ee.Reducer.sum(),
  geometry: Area_Estudio,
  scale: 30,
  maxPixels:  1e12});
//obtener los valores (Número)  
var value_results_Area_Hansen= ee.Number(stats.get('lossyear').getInfo());  
//Convertir los valores de Número a Cadena y dejar 2 decimales
value_results_Area_Hansen = value_results_Area_Hansen.format("%(,.2f").getInfo()
var leftLabel = ui.Label(value_results_Area_Hansen +' Ha', {shown: true, position: 'bottom-center', color:'000', fontSize: '18px', backgroundColor: 'rgba(255, 255, 255, 1.0)'}); //'
leftMap.add(leftLabel)
//print('Área de Pérdida 2013_2017 (Hansen): ', stats.get('lossyear'), ' Ha');
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//-------------------------------------------------------Gráficas Dinámicas------------------------------------------------------//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var drawingTools = leftMap.drawingTools();
drawingTools.setShown(true);
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
var dummyGeometry =
    ui.Map.GeometryLayer({geometries: null, name: 'Poli', color: '23cba7'});
function clearGeometry() {
  var layers = drawingTools.layers();
  layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
}
function drawRectangle() {
  clearGeometry();
  drawingTools.setShape('rectangle');
  drawingTools.draw();
}
function drawPolygon() {
  clearGeometry();
  drawingTools.setShape('polygon');
  drawingTools.draw();
}
function drawPoint() {
  clearGeometry();
  drawingTools.setShape('point');
  drawingTools.draw();
}
drawingTools.layers().add(dummyGeometry);
var chartPanel = ui.Panel({
  style:
      {height: '235px', width: '600px', position: 'bottom-right', shown: false}
});
function Graficas_dinamicas() {
  // Make the chart panel visible the first time a geometry is drawn.
  if (!chartPanel.style().get('shown')) {
    chartPanel.style().set('shown', true);
  }
  // Get the drawn geometry; it will define the reduction region.
  var point = drawingTools.layers().get(0).getEeObject();
  // Set the drawing mode back to null; turns drawing off.
  drawingTools.setShape(null);
  // Reduction scale is based on map scale to avoid memory/timeout errors.
  var mapScale = leftMap.getScale();
  var scale = mapScale > 5000 ? mapScale * 2 : 5000;
//if (contaminacion === "O3") { 
if (NDVI17_select === true || Zonificacion1_select === true || Zonificacion2_select === true) {
var Fecha_1 = '2013-01-01';
var Fecha_2 = '2023-12-31';
// Load MODIS veg indices collection
var vi = ee.ImageCollection('MODIS/061/MOD13A1')
  .filterDate(Fecha_1, Fecha_2)
  .select(['NDVI']);
//print(vi)
var vicov = vi.map(function(image) {
  var date = image.get('system:time_start');
  return image.multiply(0.0001)
  .set('system_time_start', date)
  .copyProperties(image,['system:time_start','system:time_end']);
});
//print(vicov);
var chart_TimeSeries2 = ui.Chart.image.series({
    imageCollection: vicov.select('NDVI'),
    region: point
    }).setOptions({
      interpolateNulls: true,
      explorer: {axis: 'vertical'},
      lineWidth: 1,
      //pointSize: 3,
      trendlines: {type: 'exponential', 0: {color: 'CC0000'}, visibleInLegend: true},
      title: 'Análisis de Serie Temporal NDVI: MODIS',
      curveType:'function', 
      vAxis: {title: 'NDVI'},
      hAxis: {
      titleTextStyle: {italic: false, fontSize: 14, bold: true},
      title: 'Date', 
      //format: 'MM-yy', 
      gridlines: {color: 'FFF'}, //count: 2, 
      //ticks: [early, late]
    }
    })
//print(chart_TimeSeries2)
tsChart.widgets().reset([chart_TimeSeries2]);
}
if (Sequia_select === true){
// Define el punto sobre el cual quieres realizar la serie temporal
var punto = ee.Geometry.Point([-87.65, 14.1]); // Coordenadas de ejemplo para Honduras
var m = {};
m.palette = {
  minRgb: [255, 0, 0],
  midRgb: [255, 255, 255],
  maxRgb: [0, 0, 255],
  minVal: -6,
  midVal: 0,
  maxVal: 6
};
m.drought = ee.ImageCollection('IDAHO_EPSCOR/TERRACLIMATE');
m.droughtBand = 'pdsi';
m.dateRange = ['2000-01-01', '2023-12-31'];
/*******************************************************************************
 * Behaviors *
 ******************************************************************************/
// Converts RGB integer component to hex string. 
function componentToHex(c) {
  var hex = c.toString(16);
  return hex.length == 1 ? '0' + hex : hex;
}
// Converts RGB color list to hex color string.
function rgbToHex(rgb) {
  return "#" +
  componentToHex(rgb[0]) +
  componentToHex(rgb[1]) +
  componentToHex(rgb[2]);
}
// Identifies the RGB color for a value in a divergent palette.
function getRgbDivergent(cMin, cMid, cMax, min, mid, max, val) {
  var dif, frac, c1, c2, r, g, b;
  if (val <= mid) {
    val = val < min ? min : val;
    dif = mid - min;
    frac = Math.abs(val/dif);
    c1 = cMin;
    c2 = cMid;
    r = (c1[0] - c2[0]) * frac + c2[0];
    g = (c1[1] - c2[1]) * frac + c2[1];
    b = (c1[2] - c2[2]) * frac + c2[2];
  } else {
    val = val > max ? max : val;
    dif = max - mid;
    frac = Math.abs(val/dif);
    c1 = cMid;
    c2 = cMax;
    r = (c2[0] - c1[0]) * frac + c1[0];
    g = (c2[1] - c1[1]) * frac + c1[1];
    b = (c2[2] - c1[2]) * frac + c1[2];
  }
  var rgb = [];
  [r, g, b].forEach(function(c) {
    rgb.push(Math.round(c));
  });
  return rgb;
}
// Adds date information to images.
function addYearWeek(img) {
  var date = img.date();
  var year = date.get('year');
  var week = date.get('month');
  var id = ee.Algorithms.String(year).cat(ee.Algorithms.String(week));
  return img.set({
    year: year,
    week: week,
    date_id: id,
  });
}
// Calculates mean monthly PDSI image collection.
function getPdsiSummary() {
  var pdsi = m.drought
          .filterDate(m.dateRange[0], m.dateRange[1])
          .map(addYearWeek)
          .select(m.droughtBand)
  var distinctId = pdsi.distinct('date_id');
  var filter = ee.Filter.equals({leftField: 'date_id', rightField: 'date_id'});
  var join = ee.Join.saveAll('id_matches');
  var joinCol = ee.ImageCollection(join.apply(distinctId, pdsi, filter));
  var pdsiSummary = joinCol.map(function(img) {
    var col = ee.ImageCollection.fromImages(img.get('id_matches'));
    var meanTime = col.reduceColumns({
      reducer: ee.Reducer.mean(),
      selectors: ['system:time_start']
    }).get('mean');
    meanTime = ee.Number(meanTime).round();
    return col.median().multiply(0.01).set('system:time_start', meanTime);
  });
  return pdsiSummary;
}
var Mundo = ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level2");
var Honduras = Mundo.filter(ee.Filter.eq('ADM0_NAME', 'Honduras'))
// Generates a PDSI time series chart and adds it to chart panel.
  //var point = punto//ee.Geometry.Point(coords.lon, coords.lat);
  var pdsiSummary = getPdsiSummary();
  var pdsiDf = pdsiSummary.map(function(img) {
    var stat = img.reduceRegion({
      'geometry': point,
      'reducer': ee.Reducer.mean(),
      'scale': 4000,
      'crs': 'EPSG:5070'
    });
    return ee.Feature(null, stat)
            .set({'millis': img.date().millis()});  
  }).sort('millis');
  var pdsiVal = pdsiDf.aggregate_array(m.droughtBand);
  var evalInfo = ee.Dictionary({
    pdsiVal: pdsiVal,
    //aoiName: aoiName,
  });
  evalInfo.evaluate(function(evalInfo) {
    var colors = [];
    for (var i in evalInfo.pdsiVal) {
      var rgb = getRgbDivergent(
        m.palette.minRgb, m.palette.midRgb, m.palette.maxRgb,
        m.palette.minVal, m.palette.midVal, m.palette.maxVal,
        evalInfo.pdsiVal[i]);
      colors.push(rgbToHex(rgb));
    }
    var chart = ui.Chart.feature.groups(pdsiDf, 'millis', 'pdsi', 'millis')
      .setChartType('ColumnChart')
      .setOptions({
        title: evalInfo.aoiName,
        bar: {groupWidth: '100%'},
        colors: colors,
        legend: {position: 'none'},
        vAxis: {
          title: 'PDSI',
          viewWindow: {min: -8, max: 8},
          titleTextStyle: {italic: false, bold: true}
        },
        hAxis: {
          minorGridlines: {count: 0}
        },
        isStacked: true,
        explorer: {axis: 'horizontal'}
      });
    //chart.style().set(s.chartStyle);
   // print(chart);
    tsChart.widgets().reset([chart]);
  });
}
}
drawingTools.onDraw(ui.util.debounce(Graficas_dinamicas, 500));
drawingTools.onEdit(ui.util.debounce(Graficas_dinamicas, 500));
/*
var symbol = {
  rectangle: '⬛',
  polygon: '🔺',
  point: '📍',
};
var controlPanel = ui.Panel({
  widgets: [
    ui.Button({
      label: symbol.rectangle + ' Rectángulo',
      onClick: drawRectangle,
      style: {stretch: 'horizontal'}
    }),
    ui.Button({
      label: symbol.polygon + ' Polígono',
      onClick: drawPolygon,
      style: {stretch: 'horizontal'}
    }),
    ui.Button({
      label: symbol.point + ' Punto',
      onClick: drawPoint,
      style: {stretch: 'horizontal'}
    }),
  ],
  style: {position: 'bottom-left'},
  layout: null,
});
leftMap.add(controlPanel);
//lowerPanel.add(chartPanel);
*/
// Define el panel de control con los botones para dibujar
var controlPanel = ui.Panel({
  widgets: [
    ui.Button({label: '⬛ Rectángulo', onClick: drawRectangle, style: {stretch: 'horizontal'}}),
    ui.Button({label: '🔺 Polígono', onClick: drawPolygon, style: {stretch: 'horizontal'}}),
    ui.Button({label: '📍 Punto', onClick: drawPoint, style: {stretch: 'horizontal'}}),
  ],
  style: {shown: false},layout: null, // El panel inicia oculto
});
// Crear el botón de mostrar/ocultar
var showHideControlButton = ui.Button({
  label: 'Serie Histórica',
  onClick: function() {
    // Alternar la visibilidad del panel de control
    var isShown = controlPanel.style().get('shown');
    controlPanel.style().set('shown', !isShown);
    // Actualizar la etiqueta del botón basado en la visibilidad del panel de control
    showHideControlButton.setLabel(isShown ? 'Serie Histórica' : 'Ocultar Herramientas');
  },
});
// Crea el panel principal que contendrá tanto el botón como el panel de control
var mainPanel = ui.Panel({
  widgets: [showHideControlButton, controlPanel],
  style: {position: 'bottom-left', padding: '2px 2px'},
  layout: ui.Panel.Layout.flow('vertical'), // Asegura que los widgets se dispongan verticalmente
});
// Añade el panel principal al mapa
leftMap.add(mainPanel);
}//FIN RUN
// #############################################################################
// ### CUSTOM MAP STYLE ###
// #############################################################################
function darkMap() {
return [
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#3e3e3e" //"474747" //#333333"//"#212121"
      }
    ]
  },
  {
    "elementType": "labels.icon",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#3e3e3e" //""#474747" //"#333333" //"#212121"
      }
    ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "administrative.country",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#9e9e9e"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "administrative.locality",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#bdbdbd"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#181818"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#616161"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#1b1b1b"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#2c2c2c"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#8a8a8a"
      }
    ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#373737"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#3c3c3c"
      }
    ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#4e4e4e"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#616161"
      }
    ]
  },
  {
    "featureType": "transit",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#757575"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#000000"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#3d3d3d"
      }
    ]
  }
]
}