// Created by Alfonso Sanchez-Paus
// If you improve it please share the code!
// Improvements from the example on ui.SplitPanel
var misc = require("users/sanchezpauspro/Apps:misc");
var polygonAreas = require("users/sanchezpauspro/Apps:PolygonDrawing");
var CoordenadaXY = require('users/leofabiop120/Data_Intelligence:export_salud2');
//Rango de fecha
function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;
    //return [year, month, day].join('-');
    return year + "-" + month + "-" + day;
}
//Fechas
var valorDia =  86400000;
var cantidadDia = 6;
var fechaInicial = Date.now() - valorDia * cantidadDia;
//var Fecha_inicial= "2020-01-28";//ee.Date(fechaInicial,String); 
//var Fecha_final= "2020-01-29";//ee.Date(Date.now(),String);
var Fecha_inicial= formatDate(fechaInicial); 
var Fecha_final= formatDate(Date.now() - 86400000 * 0);
var Date1= ee.Date(Fecha_inicial).format("YYYY-MM-dd").getInfo();
var Date2= ee.Date(Fecha_final)  .format("YYYY-MM-dd").getInfo();
// Import country features 
var countries = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017');
var ndviPaletteColors = ["000000", "8B592C", "A46A34", "BD7B3D" , "CF9F2B", "DDBC1E", "EDDD0E", "FEFE00", "D8F20B", "B1E418", "8BD825", "64CB32" , "56B931", "47A72E", "39952C", "2A842A" , "247224", "1e5c1e", "1a4b1a", "173b01"];
var BASEMAP = { name : "Google Maps Basemap", period : 5, start : "2014-10-14" };
var sentinel2Url = "https://sentinel.esa.int/web/sentinel/user-guides/sentinel-2-msi/overview";
var SENTINEL_1 = { name : "Sentinel-1 SAR Radar", period : 6, start : "2014-10-14" , pixelSize: "10", url:"https://sentinel.esa.int/web/sentinel/user-guides/sentinel-1-sar/overview", info:"The 'Sentinel 1 mosaic' product is derived from processing ESA's Sentinel-1 C-band Synthetic Aperture Radar (SAR) images available for a certain date-range. The imagery is based on radar data which means that the land-cover is detected though the different textures rather than colors. Imaging radars equipped with C-band are generally not hindered by atmospheric effects and are capable of imaging through tropical clouds and rain showers. Its penetration capability with regard to vegetation canopies or soils is limited and is restricted to the top layers." };
var SENTINEL_2_NATURAL = { name : "Sentinel-2 Natural ( RGB )", period : 5, start : "2015-06-23", pixelSize: "10", url:sentinel2Url, info:"The 'Sentinel 2, cloud free mosaic' product is derived from processing ESA Sentinel-2 MultiSpectral Instrument (MSI), Level-1C images available from June 2015 to present. This image is a true color composite that uses visible light bands red, green and blue in the corresponding red, green and blue color channels, resulting in a natural colored result, that is a good representation of the Earth as humans would see it naturally." };
var SENTINEL_2_FALSE_20 = { name : "Sentinel-2 False 20 m (nir-swir1-red)", period : 5, pixelSize: "20", start : "2015-06-23",  url:sentinel2Url, info:"The 'Sentinel 2, cloud free mosaic' product is derived from processing ESA Sentinel-2 MultiSpectral Instrument (MSI), Level-1C images available from June 2015 to present. This image is a false color composite using near infrared, short wave infrared and red bands. "};
var SENTINEL_2_FALSE_10 = { name : "Sentinel-2 False 10 m (nir-red-green)", period : 5, pixelSize: "10", start : "2015-06-23",  url:sentinel2Url, info:"The 'Sentinel 2, cloud free mosaic' product is derived from processing ESA Sentinel-2 MultiSpectral Instrument (MSI), Level-1C images available from June 2015 to present. This image is a false color composite using near infrared, red and green bands, which is very popular. It is most commonly used to assess plant density and health, as plants reflect near infrared and green light, while absorbing red. Since they reflect more near infrared than green, plant-covered land appears deep red."};
var SENTINEL_2_NDVI = { name : "Sentinel-2 NDVI 20 m", period : 5, start : "2015-06-23", palette: { colors: ndviPaletteColors , min: 0, med:0.5, max: 1, label:"NDVI Values" }, pixelSize: "10",  url:sentinel2Url, info:"The 'Sentinel 2, cloud free mosaic' product is derived from processing ESA Sentinel-2 MultiSpectral Instrument (MSI), Level-1C images available from June 2015 to present. The NDVI is a simple, but effective index for quantifying green vegetation. It normalizes green leaf scattering in near infra-red wavelengths with chlorophyll absorption in red wavelengths. The value range of the NDVI is -1 to 1. Negative values of NDVI (values approaching -1) correspond to water. Values close to zero (-0.1 to 0.1) generally correspond to barren areas of rock, sand, or snow. Low, positive values represent shrub and grassland (approximately 0.2 to 0.4), while high values indicate temperate and tropical rainforests (values approaching 1). It is a good proxy for live green vegetation."};
var LANDSAT_8_NATURAL = { name : "Landsat-8 Natural (RGB)", period : 16, start : "2013-04-21", pixelSize: "30", url:"https://landsat.gsfc.nasa.gov/landsat-8/landsat-8-overview", info:"Landsat 8  is the eighth satellite in the Landsat program. Landsat 8 provides moderate-resolution imagery, from 15 to 100 metres, of Earth's land surface and polar regions and operates in the visible, near-infrared, short wave infrared, and thermal infrared spectrums. This image is a true color composite that uses visible light bands red, green and blue in the corresponding red, green and blue color channels, resulting in a natural colored result, that is a good representation of the Earth as humans would see it naturally."};
var LANDSAT_8_FALSE = { name : "Landsat-8 False (nir-swir-red)", period : 16, start : "2013-04-21", pixelSize: "30", url:"https://landsat.gsfc.nasa.gov/landsat-8/landsat-8-overview", info:"Landsat 8 provides moderate-resolution imagery, from 15 to 100 metres, of Earth's land surface and polar regions and operates in the visible, near-infrared, short wave infrared, and thermal infrared spectrums. This image is a false color composite using near infrared, short wave infrared and red bands."};
var LANDSAT_7_NATURAL = { name : "Landsat-7 Natural (RGB)", period : 16, start : "1999-01-01", pixelSize: "30", url:"https://landsat.gsfc.nasa.gov/landsat-7", info:"Landsat 7 is the seventh satellite of the Landsat program. Landsat 7 provides moderate-resolution imagery, scanning across the entire Earth's surface and operates in the visible, near-infrared, short wave infrared, and thermal infrared spectrums. This image is a true color composite that uses visible light bands red, green and blue in the corresponding red, green and blue color channels, resulting in a natural colored result, that is a good representation of the Earth as humans would see it naturally."};
var LANDSAT_7_FALSE = { name : "Landsat-7 False (nir-swir-red)", period : 16, start : "1999-01-01", pixelSize: "30", url:"https://landsat.gsfc.nasa.gov/landsat-7", info:"Landsat 7 is the seventh satellite of the Landsat program. Landsat 7 provides moderate-resolution imagery, scanning across the entire Earth's surface and operates in the visible, near-infrared, short wave infrared, and thermal infrared spectrums. This image is a false color composite using near infrared, short wave infrared and red bands."};
var NIGHTLIGHTS = { name : "Night lights (VIIRS)", start : "2012-04-01" , end : "2020-06-01", monthly: true, period : 15, pixelSize: "450", url:"https://eogdata.mines.edu/products/vnl/", info:"The Visible Infrared Imaging Radiometer Suite (VIIRS) provides monthly average radiance composite images using nighttime data from the Day/Night Band (DNB). As these data are composited monthly, there are many areas of the globe where it is impossible to get good quality data coverage for that month. This can be due to cloud cover, especially in the tropical regions, or due to solar illumination, as happens toward the poles in their respective summer months"};
var SENTINEL_5_NO2 = { name : "Sentinel-5 NO2", period : 5, start : "2018-07-28", pixelSize: "1120", url:"https://sentinel.esa.int/web/sentinel/missions/sentinel-5/data-products", info:"The SENTINEL-5 mission consists of high resolution spectrometer system operating in the ultraviolet to shortwave infrared range with 7 different spectral bands. SENTINEL-5 is focused on air quality and composition-climate interaction with the main data products being O3, NO2, SO2, HCHO, CHOCHO and aerosols. This image shows nitrogen dioxide (NO2) concentrations in the atmosphere. NO2 primarily gets in the air from the burning of fuel. NO2 forms from emissions from cars, trucks and buses, power plants, and off-road equipment."};
var BURNED_AREA = { name : "MODIS Burned Area Monthly",  start : "2000-11-01", monthly: true, period : 15, pixelSize: "500", url:"https://lpdaac.usgs.gov/products/mcd64a1v006/", info:"The Terra and Aqua combined MCD64A1 Version 6 Burned Area data product is a monthly, global gridded 500m product containing per-pixel burned-area and quality information. The MCD64A1 burned-area mapping approach employs 500m MODIS Surface Reflectance imagery coupled with 1km MODIS active fire observations."};
var selectionSource = [];
var selectionDate = [];
var selectionMap = [];
var leftMap;
var rightMap;
var preselected_geometry;
var selectPredefinedArea;
var urlLabel;
//------------------------------------------------------------------------------------------------------------------------------ 
// START OF THE CODE THAT YOU NEED TO CHANGE IN ORDER TO CUSTOMIZE THE AREAS OF INTEREST
var NO_SELECTION = "SHOWCASES - Choose an example of how to use the imagery comparison tool";
var DEFAULT_AREA = "Mauritius - MV Wakashio Oil Spill"; // This variable must match the name of one of the PREDEFINED_AREAS
// FOLLOW THE SAME STRUCTURE AND YOU SHOULD BE FINE
// THIS IS AN ARRARY OF JAVASCRIPT OBJECTS. [ { name:XXXX, } ]
var PREDEFINED_AREAS = [
  {
    name : DEFAULT_AREA,  // THE NAME THAT IS SHOWN ON THE SELECTION FIELD
      location : [-88.16282590315755,14.315390682457041],                           // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      zoomLevel : 11,
      before : {                                         // BEFORE THE EVENT
        source : SENTINEL_2_NATURAL,                             // IMAGERY TO SHOW, OPTIOdNS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date :  Date1                             // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : SENTINEL_2_NATURAL,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date : Date2                            // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    },
    {
    name : "Olanchito, Yoro",  // THE NAME THAT IS SHOWN ON THE SELECTION FIELD
      location : [-86.57252769520176,15.481197018659339],                         // THE COORDINATES TO ZOOM INTO
      zoomLevel : 11,                                    // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      before : {                                         // BEFORE THE EVENT
        source : SENTINEL_1,                             // IMAGERY TO SHOW, OPTIOdNS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date :  Date1                             // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : SENTINEL_2_FALSE_10,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date : Date2                              // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    },
    {
    name : "Tegucigalpa, F.M",  // THE NAME THAT IS SHOWN ON THE SELECTION FIELD
      location : [-87.21110801746738,14.083021711899232],                         // THE COORDINATES TO ZOOM INTO
      zoomLevel : 6,                                    // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      before : {                                         // BEFORE THE EVENT
        source : SENTINEL_5_NO2,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date :  Date1                            // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : SENTINEL_5_NO2,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date : Date2                              // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    },
  {
    name : "Siguatepeque, Comayagua",  // THE NAME THAT IS SHOWN ON THE SELECTION FIELD
      location : [-87.83149223377598,14.596926787016058],                         // THE COORDINATES TO ZOOM INTO
      zoomLevel : 6,                                    // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      before : {                                         // BEFORE THE EVENT
        source : SENTINEL_5_NO2,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date :  Date1                             // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : SENTINEL_5_NO2,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date : Date2                             // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    },
  {
    name : "Comayagua, Comayagua",  // THE NAME THAT IS SHOWN ON THE SELECTION FIELD
      location : [-87.64747123768223,14.448032528289787],                         // THE COORDINATES TO ZOOM INTO
      zoomLevel : 13,                                    // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      before : {                                         // BEFORE THE EVENT
        source : SENTINEL_2_FALSE_10,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date :  Date1                            // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : SENTINEL_2_FALSE_10,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date : Date2                              // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    },
  {
    name : "Gracias, Lempira",  // THE NAME THAT IS SHOWN ON THE SELECTION FIELD
      location : [-88.58182411243808,14.587291580739258],                         // THE COORDINATES TO ZOOM INTO
      zoomLevel : 15,                                    // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      before : {                                         // BEFORE THE EVENT
        source : SENTINEL_2_NATURAL,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date :  Date1                            // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : SENTINEL_2_FALSE_10,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date : Date2                              // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    },{
    name : "Santa Rosa de Copán, Copán",  // THE NAME THAT IS SHOWN ON THE SELECTION FIELD
      location : [-88.77837638904941,14.767300279185664],                         // THE COORDINATES TO ZOOM INTO
      zoomLevel : 15,                                    // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      before : {                                         // BEFORE THE EVENT
        source : SENTINEL_2_FALSE_10,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE ,SENTINEL_5_NO2N2O
        date :  Date1                            // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : SENTINEL_2_FALSE_10,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date : Date2                              // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    },
    {
    name : "Juticalpa",  // THE NAME THAT IS SHOWN ON THE SELECTION FIELD
      location : [-86.22268180897129,14.661039985425928],                         // THE COORDINATES TO ZOOM INTO
      zoomLevel : 10,                                    // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      before : {                                         // BEFORE THE EVENT
        source : SENTINEL_1,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date :  Date1                             // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : SENTINEL_1,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date : Date2                             // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    },
    {
    name : "Choluteca, Choluteca",  // THE NAME THAT IS SHOWN ON THE SELECTION FIELD
      location : [ -87.1640160433951,13.31704983139699],                         // THE COORDINATES TO ZOOM INTO
      zoomLevel : 11,                                    // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      before : {                                         // BEFORE THE EVENT
        source : SENTINEL_1,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date :  Date1                            // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : SENTINEL_1,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date : Date2                            // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    },
    {
    name : "Intibucá, Intibucá",  // THE NAME THAT IS SHOWN ON THE SELECTION FIELD
      location : [ -88.16727874536205,14.308874682071224],                         // THE COORDINATES TO ZOOM INTO
      zoomLevel : 12,                                    // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      before : {                                         // BEFORE THE EVENT
        source : SENTINEL_2_FALSE_10,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date :  Date1                             // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : SENTINEL_2_FALSE_10,                             // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        date : Date2                              // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    },
  {
    name : "Puerto Lempira, G.A",
    location : [-83.7817243360997,15.26154737707023],
    zoomLevel : 13,
    before : {
      source : SENTINEL_2_FALSE_10,
      date :  Date1
    },
    after : {
      source : SENTINEL_2_FALSE_10,
      date : Date2
    }
  },
  {
    name : "Embalse F.M, El Cajón",
    location : [ -87.69187737137263,14.99036464863465 ],
    zoomLevel : 12,
    before : {
      source : BURNED_AREA,
      date :  Date1
    },
    after : {
      source : SENTINEL_2_FALSE_10,
      date : Date2 
    }
  },
  {
    name : "San Francisco, Lempira",
    location : [ -88.3745228932751,14.121708686350823],
    zoomLevel : 14,
    before : {
      source : SENTINEL_2_FALSE_20,
      date :  Date1
    },
    after : {
      source : SENTINEL_2_FALSE_10,
      date : Date2 
    }
  },
  {
    name : "Esquias, Comayagua",
    location : [ -87.37264908764465,14.742238555897265 ],
    zoomLevel : 11,
    before : {
      source : SENTINEL_2_FALSE_20,
      date :  Date1
    },
    after : {
      source : SENTINEL_2_FALSE_10,
      date : Date2
    }
  },
  {
    name : "La Entrada Copán",
    location : [-88.7494686494078,15.062253311360752 ],
    zoomLevel : 15,
    before : {
      source : SENTINEL_1,
      date :  Date1
    },
    after : {
      source : SENTINEL_2_NATURAL,
      date : Date2 
    }
  }
];
//------------------------------------------------------------------------------------------------------------------------------ 
// END OF THE CODE THAT YOU NEED TO CHANGE IN ORDER TO CUSTOMIZE TO THE 
//------------------------------------------------------------------------------------------------------------------------------ 
function getSentinel1Composite(range) {
  // Only include the VV polarization, for consistent compositing.
  var polarization = 'VV';
  var sentinel1 = ee.ImageCollection('COPERNICUS/S1_GRD')
                      .filterDate(range[0], range[1])
                      .filter(ee.Filter.listContains(
                          'transmitterReceiverPolarisation', polarization))
                      //.filter(ee.Filter.eq('instrumentMode', 'IW'))
                      .select(polarization)
                      .mean();
  return sentinel1.visualize({min: -25, max: 0, palette: ['aqua', 'black']});
}
function getSentinel2Images(range, cloudOriginal, geometry){
    var filter =  ee.Filter.date( range[0], range[1] );
    if( cloudOriginal){
      filter = ee.Filter.and(
        filter,
        ee.Filter.lte('CLOUDY_PIXEL_PERCENTAGE', cloudOriginal)
      );
    }
    if( geometry){
      filter = ee.Filter.and(
        filter,
        ee.Filter.bounds( geometry )
      );
    }
    /* 
    This code will merge the Level 1 (TOA) and Level 2 (SR) collections.
    If there is a Level 2 version of the same image it will be used, otherwise the level 1 will de returned
    */
    var commonBands = [ 'B2', 'B3' , 'B4',  'B8', 'B11' ];
    var sr = ee.ImageCollection('COPERNICUS/S2_SR').filter(filter).select( commonBands );
    var toa = ee.ImageCollection(
      ee.Join.inverted().apply({
        primary: ee.ImageCollection('COPERNICUS/S2').filter(filter).select( commonBands ),
        secondary: sr,
        condition: ee.Filter.equals({leftField: 'system:index', rightField: 'system:index'})
    }));
    var s2_collection = sr.merge(toa);
    //print( s2_collection );
    return s2_collection;
}
function getSentinel2Composite(range, imageType, cloudOriginal) {
    var sentinel2 = getSentinel2Images(range,cloudOriginal )
                      .median();
    // Natural Color
    var viz = {min: 300,  max: 3500,  bands: ['B4', 'B3', 'B2']};
    if( imageType === SENTINEL_2_FALSE_20.name ){
      viz = {bands:['B8','B11','B4'], min: 300, max:3500};
    }else  if( imageType ===  SENTINEL_2_FALSE_10.name ){
      viz = {bands:['B11','B8' , 'B2' ],min:300, max:3000};
    }
    return sentinel2.visualize( viz );
}
function getGoodSentinel2Images( geometry, cloudyCoverPercentage, yearsBack ){
  yearsBack = yearsBack || 1; 
  var now = new Date( Date.now() );
  var today = now.getFullYear()+'-'+ ( now.getMonth() +1) +'-'+now.getDate();
  var lastYearToday = ( now.getFullYear() - 1 )+'-'+ ( now.getMonth() +1) +'-'+now.getDate();
  var imagesNow = getSentinel2Images([lastYearToday, today], cloudyCoverPercentage, geometry);
  var imagesBefore;
  if( yearsBack == 1 ){
    imagesBefore = imagesNow;
  }else{
    var previousPeriodEnd = ( now.getFullYear()  - yearsBack+1 ) +'-'+ ( now.getMonth() +1) +'-'+now.getDate();
    var previousPeriodStart = ( now.getFullYear() - yearsBack )+'-'+ ( now.getMonth() +1) +'-'+now.getDate();
    imagesBefore = getSentinel2Images([previousPeriodStart, previousPeriodEnd], cloudyCoverPercentage, geometry);
  }
  if( imagesNow.size().getInfo() > 2 ){
    var first = imagesBefore.sort( "system:time_start", true).first().get("system:time_start").getInfo();
    var last = imagesNow.sort( "system:time_start", false).first().get("system:time_start").getInfo() ;
    return [ first, last ];
  }else{
    //print( "Not enough images found at cloud cover : " + cloudyCoverPercentage);
     return null;
  }
}
var getNdviImage = function(image){
  var ndvi = image.normalizedDifference( [  "B8", "B4" ]);
  // type might be "intervals" (default), "ramp" or "values" 
  // see explanation here : http://docs.geoserver.org/stable/en/user/styling/sld/reference/rastersymbolizer.html
  var generateSldStyle = function(classColors, classValues, type){ 
    var sldStyle = '<RasterSymbolizer><ColorMap  type="'+type+'" extended="true" >';
    // Exporting properties to the asset only works if the values are Strings or Numbers  
    for(var z =0;z<classColors.length; z++){
      sldStyle += '<ColorMapEntry color="#' + classColors[z] + '" quantity="' + classValues[z] + '" label="'+ z +'"/>';
    }
    sldStyle +='</ColorMap></RasterSymbolizer>';
    return sldStyle;
  };
  var classValues = [0,0.5,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75,0.8,0.85,0.9, 1];
  return ee.Image( ndvi ).sldStyle( generateSldStyle( ndviPaletteColors, classValues, "ramp" )  );
};
function getSentinel2CompositeNDVI(range, imageType, cloudOriginal) {
  var sentinel2 = getSentinel2Images(range,cloudOriginal ).median();
  return getNdviImage( sentinel2 );
}
function getModisBurnedArea(range) {
  var date = ee.Date(range[0]);
  var month = date.get('month');
  var year = date.get('year');
  var burned = ee.ImageCollection('MODIS/006/MCD64A1')
                      .filter(
        ee.Filter.and( ee.Filter.calendarRange( year, year, "year" ) , ee.Filter.calendarRange( month, month, "month" ) ) 
      ).max().gt(0)
                      ;
  var viz = {min: 0 ,  max: 1 , palette : ['white', 'red'],  bands: ['BurnDate'] };
  return burned.visualize( viz );
}
function getSentinel5Composite(range, imageType) {
    // Define an empty image to paint features to.
  var empty = ee.Image().byte();
  // Paint country feature edges to the empty image.
  var countriesOutline = empty
    .paint({featureCollection: countries, color: 1, width: 1})
    // Convert to an RGB visualization image; set line color to black.
    .visualize({palette: '000000'});
  var sentinel5 = ee.ImageCollection('COPERNICUS/S5P/NRTI/L3_NO2')
                      .select('NO2_column_number_density')
                      .filterDate(range[0], range[1])
                      .max();
  var viz = {    min: 0.00005, max: 0.0002,  opacity: 0.8,  palette: ["blue", "purple", "cyan", "green", "yellow", "red"]  };
  sentinel5 = sentinel5.mask( sentinel5.gt( 0.00005) );
  var image = sentinel5.visualize( viz );
  image = image.blend(countriesOutline);
  return image;
}
function getLandsat8(range, falseColor) {
  var viz = {  min: 0.0,max: 2500, bands : ['B4', 'B3', 'B2']  };
  if( falseColor ){
    viz = {bands:['B5','B6','B4'],min:0, max:2500};
  }
  var landsat8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
                      .filterDate( range[0], range[1] )
                      .mean();
  return landsat8.visualize(  viz );
}
function getLandsat7(range, falseColor) {
  var bands = ['B3', 'B2', 'B1'];
  if( falseColor ){
    bands = ['B4','B5','B3'];
  }
  var landsat7 = ee.ImageCollection('LANDSAT/LE07/C01/T1_SR')
                      .filterDate( range[0], range[1] )
                      .mean()
                      .select( bands , ['R', 'G', 'B'] );
  return landsat7.visualize(  { 
    min:[200,200,200],
    max:[3100,3100,3100],
    gamma : 1.3
  } );
}
function getNightLights(range) {
  var date = ee.Date(range[0]);
  var month = date.get('month');
  var year = date.get('year');
  var nightlights = ee.ImageCollection("NOAA/VIIRS/DNB/MONTHLY_V1/VCMCFG").filter(
        ee.Filter.and( ee.Filter.calendarRange( year, year, "year" ) , ee.Filter.calendarRange( month, month, "month" ) ) 
      ).mean();
  var viz = {"opacity":1,"bands":["avg_rad"],"min":1,"max":30,"palette":["181801","f3f509"]};
      // Define an empty image to paint features to.
  var empty = ee.Image().byte();
  // Paint country feature edges to the empty image.
  var countriesOutline = empty
    .paint({featureCollection: countries, color: 1, width: 1})
    // Convert to an RGB visualization image; set line color to black.
    .visualize({palette: 'e40000'});
  var image = nightlights.visualize( viz );
  image = image.blend(countriesOutline);
  return image;
}
function updatePeriod( dateSlider, source ) {
  if( source.monthly) {
    var start = dateSlider.getValue()[0];
    var dt = new Date( start );
    print("day", dt.getDate());
    var startOfMonth = new Date( dt.getFullYear(), dt.getMonth(),2);
    print( "start month", startOfMonth );
    dateSlider= dateSlider.setValue( startOfMonth, false );
  }
  dateSlider.setPeriod( source.period );
  dateSlider.setStart( source.start );
  if( source.end ){
    dateSlider.setEnd( source.end );
  }else{
    dateSlider.setEnd( getLastWeek() );
  }
}
function getImageryObjectByName(source ){
  var obj;
  switch( source ){
    case SENTINEL_1.name:
      return SENTINEL_1;
    case SENTINEL_2_NATURAL.name:
      return SENTINEL_2_NATURAL;
    case SENTINEL_2_FALSE_20.name:
      return SENTINEL_2_FALSE_20;
    case SENTINEL_2_FALSE_10.name:
      return SENTINEL_2_FALSE_10;
    case SENTINEL_2_NDVI.name:
      return SENTINEL_2_NDVI;
    case LANDSAT_8_NATURAL.name:
      return LANDSAT_8_NATURAL;
    case LANDSAT_7_NATURAL.name:
      return LANDSAT_7_NATURAL;
    case LANDSAT_7_FALSE.name:
      return LANDSAT_7_FALSE;
    case SENTINEL_5_NO2.name:
      return SENTINEL_5_NO2;
    case BURNED_AREA.name:
      return BURNED_AREA;
    case NIGHTLIGHTS.name:
      return NIGHTLIGHTS;
    default:
      misc.showMessage("ERROR", "No imagery found for " + source);
  }
  return null;
}
function getSingleImage(source, dateSlider ){
  var range = dateSlider.getValue();
  if( source == SENTINEL_1.name){
    updatePeriod( dateSlider, SENTINEL_1 );
    return getSentinel1Composite(range);
  }else if( source == SENTINEL_2_NATURAL.name){
    updatePeriod( dateSlider, SENTINEL_2_NATURAL );
    return getSentinel2Composite(range, source);
  }else if( source == SENTINEL_2_FALSE_20.name || source == SENTINEL_2_FALSE_10.name ){
    updatePeriod( dateSlider, SENTINEL_2_FALSE_20 );
    return getSentinel2Composite(range, source);
  }else if( source == SENTINEL_2_NDVI.name){
    updatePeriod( dateSlider, SENTINEL_2_NDVI );
    return getSentinel2CompositeNDVI(range, source);
  }else if( source == LANDSAT_8_NATURAL.name){
    updatePeriod( dateSlider, LANDSAT_8_NATURAL );
    return getLandsat8(range, false);
  }else if( source == LANDSAT_8_FALSE.name){
    updatePeriod( dateSlider, LANDSAT_8_FALSE );
    return getLandsat8(range, true);
  }else if( source == LANDSAT_7_NATURAL.name){
    updatePeriod( dateSlider, LANDSAT_7_NATURAL );
    return getLandsat7(range, false);
  }else if( source == LANDSAT_7_FALSE.name){
    updatePeriod( dateSlider, LANDSAT_7_FALSE );
    return getLandsat7(range, true);
  }else if( source == SENTINEL_5_NO2.name ){
    updatePeriod( dateSlider, SENTINEL_5_NO2 );
    return getSentinel5Composite(range);
  }else if( source == BURNED_AREA.name ){
    updatePeriod( dateSlider, BURNED_AREA );
    return getModisBurnedArea(range);
  }else if( source == NIGHTLIGHTS.name ){
    updatePeriod( dateSlider, NIGHTLIGHTS );
    return getNightLights(range);
  }
  // For BASEMAP
  return null;
}
/*
 * Set up the maps and control widgets
 */
function getLastWeek() {
  var today = new Date();
  var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 7);
  return lastWeek;
}
function getThumbUrl(image, map){
  return ee.Image( image ).getThumbURL({
    params : {
      region : map.getBounds( true ), 
      scale : map.getScale(),
      format:"png"
    }
  });
}
function getRawGeoTiffUrl(image, map){
  /*
  var region =  ee.Geometry( map.getBounds( true ) );
  image = ee.Image( image ).clip( region ).reproject( "EPSG:4326")
  var bestFit = require('users/openforisinitiative/EarthMap:Utils/CalculateBestFitScale');
	var scale = bestFit.calculateBestFit(region, image, 31.7);
	print( "SCALE", scale)
  return ee.Image( image ).getDownloadURL({
    params : {
      name : "DownloadedFromImageryCompare",
      scale : scale,
      filePerBand : false,
      region: region
    }
  });
  */
  return ee.Image( image ).getDownloadURL({
    params : {
      name : "DownloadedFromImageryCompare",
      region : map.getBounds( true ), 
      scale : map.getScale(),
      filePerBand : false
    }
  });
}
// This function changes the given map to show the selected image.
function updateMap( selectSource, dateSlider, map ) {
  var source = selectSource.getValue();
  var image = getSingleImage(source, dateSlider  );
  var imageMap = ui.Map.Layer( image );
  if( preselected_geometry ){
    if(map.layers().length()>1){
      map.layers().set(0, imageMap); // For cases when here is a polygon loaded on the window
    }else{
      map.layers().insert(0, imageMap); // When the polygon is loaded but there is no maps shown previously
    }
  }else{
    map.layers().set(0, imageMap);
  }
}
function getObjectSelected( selectedArea ){
  for (var i = 0; i < PREDEFINED_AREAS.length; i++){
    var obj = PREDEFINED_AREAS[i];
    if ( obj.name === selectedArea )
      return obj;
  }
  return null;
}
function setArea( selectedArea ){
  selectPredefinedArea.setValue( selectedArea, true );
}
function getURLObject(){
  var center = leftMap.getCenter().coordinates();
  var beforeDate  =  new Date( selectionDate[0].getValue()[0] );
  beforeDate.setDate(beforeDate.getDate() + 1);
  var afterDate  =  new Date( selectionDate[1].getValue()[0] );
  afterDate.setDate(afterDate.getDate() + 1);
  return {
      location : center.getInfo(),                       // THE COORDINATES TO ZOOM INTO
      zoomLevel : leftMap.getZoom(),                        // THE ZOOM LEVEL - MINIUM IS 1, MAXIMUM ZOOM LEVEL IS 18
      before : {                                        // BEFORE THE EVENT
        source : {
          name : selectionSource[0].getValue()          // IMAGERY TO SHOW, OPTIOdNS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        },         
        date : beforeDate.getFullYear() + "-" + (beforeDate.getMonth()+1) + "-" + beforeDate.getDate() ,           // DATE FOR THE IMAGERY TO SHOW - BEFORE EVENT  
      },
      after : {                                          // AFTER THE EVENT
        source : {
          name : selectionSource[1].getValue(),          // IMAGERY TO SHOW, OPTIONS : BURNED_AREA , SENTINEL_1 , SENTINEL_2_NATURAL , SENTINEL_2_FALSE_20 , SENTINEL_2_FALSE_10 , LANDSAT_8_NATURAL , LANDSAT_8_FALSE , SENTINEL_5_NO2
        },
        date : afterDate.getFullYear() + "-" + (afterDate.getMonth()+1) + "-" + afterDate.getDate(),             // DATE FOR THE IMAGERY TO SHOW - AFTER EVENT  
      }
    };
}
var printUrlToLabel = function(){
  var url =  "https://earthmap.org/compare.html?selectedArea=" + JSON.stringify( getURLObject() );
  misc.showMessage( "Shareable URL generated",
        "You can keep this URL or send it to anyone and they will have the same view as you do right now!",
        "Click to open URL (copy it manually)",
        url,
        leftMap
    );
};
// This is the public function of the class
// you need to set the Map to which the panel must be added, the style of the panel, and if yu want to show area measurement and the download link
var addGetURLButton = function( map, style ){
  var comps = [];
  var getLinkButton = ui.Button({ label : "SHARE LINK", style : {}, onClick : printUrlToLabel  } );
  comps.push( getLinkButton);
  var urlPanel = ui.Panel({ widgets : comps, style : style});
  map.add(  urlPanel );
};
function usePredefinedObject( predefinedObject ){
    selectionSource[0].setValue( predefinedObject.before.source.name );
    selectionSource[1].setValue( predefinedObject.after.source.name );
    selectionDate[0].setValue( predefinedObject.before.date );
    selectionDate[1].setValue( predefinedObject.after.date );
    //selectionDate[0].setPeriod( predefinedObject.before.source.period );
    //selectionDate[1].setPeriod( predefinedObject.after.source.period );
    selectionMap[0].setCenter(predefinedObject.location[0], predefinedObject.location[1],  predefinedObject.zoomLevel);
    selectionMap[1].setCenter(predefinedObject.location[0], predefinedObject.location[1],  predefinedObject.zoomLevel);
    updateMap(selectionSource[0], selectionDate[0], selectionMap[0] );
    updateMap(selectionSource[1], selectionDate[1], selectionMap[1]  );
}
function updateSelection( selectedArea ) {
  var predefinedObject = getObjectSelected( selectedArea );
  if(predefinedObject ){
    usePredefinedObject( predefinedObject );
  }
}
function addSelectPredefinedAreas(mapToChange, position){
  function getPredefinedAreas(){
    var arr =[ NO_SELECTION ];
    for (var i = 0; i < PREDEFINED_AREAS.length; i++){
      var obj = PREDEFINED_AREAS[i];
      arr.push( obj.name  );
    }
    return( arr );
  }
  selectPredefinedArea = ui.Select({
        placeholder : "Choose predefined area/date",
        items: getPredefinedAreas(),
        onChange : updateSelection,
        style: {position: position, width : "220px"}
  });
  selectPredefinedArea.setValue( NO_SELECTION, false );
  mapToChange.add(selectPredefinedArea);
}
var showUrlForDownload = function(img, mapToChange){
  var url =  getThumbUrl(img, mapToChange ); 
  var url2 = getRawGeoTiffUrl(img, mapToChange ); 
  misc.showMessage( "Download imagery",
        "",
        "Click to download PNG Image",
        url,
        mapToChange,
        "Click to download as GeoTIFF",
        url2
    );
};
// Adds a layer selection widget to the given map, to allow users to change
// which image is displayed in the associated map.
function addLayerSelector(mapToChange, position) {
  // This function changes the given map to show the selected image.
  function updateMapLocal(selection) {
    updateMap(selectSource, dateSlider, mapToChange /*, cloudThreshold*/ );
  }
  var selectSource = ui.Select({
        placeholder : "Select Satellite Imagery and Date",
        items:[BASEMAP.name, SENTINEL_1.name,SENTINEL_2_NATURAL.name, SENTINEL_2_FALSE_20.name, SENTINEL_2_FALSE_10.name, SENTINEL_2_NDVI.name,
        LANDSAT_8_NATURAL.name,LANDSAT_8_FALSE.name, BURNED_AREA.name ,NIGHTLIGHTS.name ,LANDSAT_7_NATURAL.name,LANDSAT_7_FALSE.name,SENTINEL_5_NO2.name, 
        ],
        onChange : updateMapLocal
  });
  selectionSource.push( selectSource );
  var dateSlider = ui.DateSlider({
    start : "2000-01-01",
    end : Date.now(),
    value : getLastWeek(), // Last weeks to make sure there is imager
    period: 5,
    onChange : updateMapLocal });
  selectionDate.push( dateSlider );
  var buttonDownload = new ui.Button({ 
    label : "Download Image" , 
    onClick : function(){ 
      var img = mapToChange.layers().get(0).getEeObject();
      showUrlForDownload(img, mapToChange);
    }
  });
  var infoButton = ui.Button({ 
    label : "+ Info" , 
    onClick : function(){ 
      var imagery = getImageryObjectByName(selectSource.getValue());
      var compsMsg = [];
      var blob1 = ui.Label(imagery.info , {  fontSize:"14px" , padding : "10px"});
      compsMsg.push( blob1 );
      if( imagery.palette ){
        var legend = misc.makeLegend( imagery.palette.colors, imagery.palette.min, imagery.palette.med, imagery.palette.max  );
        var legendLabel = ui.Label( imagery.palette.label , {fontWeight: 'bold', backgroundColor: 'rgba(255, 255, 255, 0.0)'});
        compsMsg.push( legendLabel );
        compsMsg.push( legend );
      }
      var availableText = "Available from " + imagery.start;
      if( imagery.end ){
        availableText = availableText + " until " + imagery.end;
      }else{
        if( imagery.monthly ){
          availableText = availableText + " until present ( ∼2 months delay for generation and ingestion )";
        }else{
          availableText = availableText + " until present ( ∼3 days delay for ingestion )";
        }
      }
      compsMsg.push( ui.Label( availableText  , {fontWeight: 'bold', backgroundColor: 'rgba(255, 255, 255, 0.0)'}) );       
      var periodicity;
      if( imagery.monthly ){
        periodicity = ui.Label( "Periodicity : Monhtly Imagery" , {fontWeight: 'bold', backgroundColor: 'rgba(255, 255, 255, 0.0)'});
      }else{
        periodicity = ui.Label( "Periodicity : " + imagery.period + " days" , {fontWeight: 'bold', backgroundColor: 'rgba(255, 255, 255, 0.0)'});
      }
      compsMsg.push( periodicity );  
      var scaleLabel = ui.Label( "Pixel size : " + imagery.pixelSize + " m." , {fontWeight: 'bold', backgroundColor: 'rgba(255, 255, 255, 0.0)'});
      compsMsg.push( scaleLabel ); 
      if( imagery.url ){
        var linkLabel = ui.Label( "Link with more information" , {color:"#144863"}, imagery.url);
        compsMsg.push( linkLabel ); 
      }
      var msgPanel = ui.Panel(compsMsg);
      misc.showMessagePanel( 
        imagery.name,
        msgPanel,
        mapToChange
      );
    }
  });
  var panelSelectSource = ui.Panel( [selectSource, infoButton], ui.Panel.Layout.flow('horizontal') );
  var controlPanel =
      ui.Panel({widgets: [panelSelectSource, dateSlider, buttonDownload], style: {position: position, width : "280px"}});
  mapToChange.add(controlPanel);
  selectionMap.push( mapToChange );
}
function drawPolygon( geometry, zoomLevel ){
  leftMap.addLayer( geometry, { color: "yellow"} );
  rightMap.addLayer( geometry, { color: "yellow"} );
  if( geometry.type().getInfo() == "Point"){
    leftMap.centerObject( geometry, zoomLevel );
    rightMap.centerObject( geometry, zoomLevel );
  }else{
    leftMap.centerObject( geometry, zoomLevel  );
  }
}
var preselectImageryOnGeometry = function(geometry, yearsBack){
    var imageryDates = getGoodSentinel2Images( geometry, 5, yearsBack );
    // if npot images with less than 5% cloud cover
    imageryDates = imageryDates || getGoodSentinel2Images( geometry, 15, yearsBack  );
    imageryDates = imageryDates || getGoodSentinel2Images( geometry, 30, yearsBack  );
    selectionSource[0].setValue( SENTINEL_2_FALSE_20.name );
    selectionSource[1].setValue( SENTINEL_2_FALSE_20.name );
    selectionDate[0].setValue( imageryDates[0] );
    selectionDate[1].setValue( imageryDates[1] );
    selectionDate[0].setPeriod( SENTINEL_2_FALSE_20.period );
    selectionDate[1].setPeriod( SENTINEL_2_FALSE_20.period );
    updateMap(selectionSource[0], selectionDate[0], selectionMap[0] );
    updateMap(selectionSource[1], selectionDate[1], selectionMap[1]  );
};
var initRightMap = function( addDrawPolygon ){
  rightMap = ui.Map();
    // Create the right map, and have it display layer 1.
  rightMap.setControlVisibility(false);
  var rightSelector = addLayerSelector(rightMap, 'bottom-right');
  rightMap.setOptions('HYBRID');
  rightMap.setControlVisibility({  "zoomControl":true,  "mapTypeControl":true, "layerList":true });
  if( addDrawPolygon)
    polygonAreas.addDrawPolygonButton( rightMap, {position : "top-right"}, true, true );
    return rightMap;
};
var initLetfMap = function( addPreselectedAreas ){
  leftMap = ui.Map();
  leftMap.setOptions('HYBRID');
  leftMap.setControlVisibility({ "zoomControl":true,  "mapTypeControl":true, "layerList":true   });
  leftMap.setControlVisibility(false);
  var leftSelector = addLayerSelector(leftMap, 'bottom-left');
  if( addPreselectedAreas ){
    addSelectPredefinedAreas( leftMap, 'top-left');
  }
  addGetURLButton(leftMap, {position : "top-left"});
  return leftMap;
};
var getLeftMap = function(){
  return leftMap;
};
var getRightMap = function(){
  return rightMap;
};
/*
 * Tie everything together
 */
// Create the left map, and have it display layer 0.
// Create a SplitPanel to hold the adjacent, linked maps.
var getSplitPanel = function( addDrawPolygon, addPreselectedAreas){
  initLetfMap( addPreselectedAreas );
  initRightMap (addDrawPolygon);
  var Buscar_Coord = CoordenadaXY.buscardor_Coord(rightMap)
  rightMap.add(Buscar_Coord)
  var linker = ui.Map.Linker([leftMap, rightMap]);
  return ui.SplitPanel({
    firstPanel: leftMap,
    secondPanel: rightMap,
    wipe: true,
    style: {stretch: 'both'}
  });
};
exports = { 
  getSplitPanel : getSplitPanel , 
  preselectImageryOnGeometry : preselectImageryOnGeometry, 
  usePredefinedObject : usePredefinedObject,
  drawPolygon : drawPolygon, 
  setArea : setArea,
  getLeftMap: getLeftMap,
  getRightMap : getRightMap,
  DEFAULT_AREA : DEFAULT_AREA
};