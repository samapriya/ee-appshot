// var imageOne = ee.Image('JRC/GHSL/P2016/POP_GPW_GLOBE_V1/1990');
// var imageTwo = ee.Image('JRC/GHSL/P2016/POP_GPW_GLOBE_V1/2015');
// var imageForAnalysis = imageTwo.subtract(imageOne)
var imageForAnalysis = ee.Image('WorldPop/GP/100m/pop/BRA_2020');
var imageForAnalysis2 = ee.Image('WorldPop/GP/100m/pop/BRA_2020');
var imageForAnalysis3 = ee.Image('WorldPop/GP/100m/pop/BRA_2020');
var imageForAnalysis4 = ee.Image('WorldPop/GP/100m/pop/BRA_2020');
// imageForAnalysis = imageForAnalysis.clip(geometry)
var mask = imageForAnalysis.select("population");
imageForAnalysis = imageForAnalysis.updateMask(mask).multiply(0.017);
// imageForAnalysis = imageForAnalysis.clip(geometry)
var mask2 = imageForAnalysis2.select("population");
imageForAnalysis2 = imageForAnalysis2.updateMask(mask2).multiply(0.05);
// imageForAnalysis = imageForAnalysis.clip(geometry)
var mask3 = imageForAnalysis3.select("population");
imageForAnalysis3 = imageForAnalysis3.updateMask(mask3).multiply(0.5);
// imageForAnalysis = imageForAnalysis.clip(geometry)
var mask4 = imageForAnalysis4.select("population");
imageForAnalysis4 = imageForAnalysis4.updateMask(mask4);
// var proj = imageForAnalysis.projection();
// var mask = imageForAnalysis.neq(0)
// var masked = imageForAnalysis.updateMask(mask).neq(0)
// var conn = masked.connectedPixelCount(2).reproject(proj)
// var zeros_around = conn.neq(1)
// imageForAnalysis = imageForAnalysis.updateMask(zeros_around);
var populationCountVis = {
  min: 3,
  max: 0,
   opacity: 0.53,
  palette: ['660000','ffff88'],
};
var populationCountVis2 = {
  min: 15,
  max: 0,
   opacity: 0.53,
  palette: ['660000','ffff88'],
};
var populationCountVis3 = {
  min: 100,
  max: 0,
   opacity: 0.53,
  palette: [ '660000','ffff88'],
};
var populationCountVis4 = {
  min: 200,
  max: 0,
   opacity: 0.53,
  palette: [ '660000','ffff88'],
};
// Map.setCenter(-9.103678,27.420197, 13);
Map.addLayer(imageForAnalysis.resample(), populationCountVis, 'Mortos 3,4% de 50% Pop.');
Map.addLayer(imageForAnalysis2.resample(), populationCountVis2, 'Hospitalizados 10% de 50% Pop.');
Map.addLayer(imageForAnalysis2.resample(), populationCountVis2, 'Hospitalizados 10% de 50% Pop.');
Map.addLayer(imageForAnalysis3.resample(), populationCountVis3, 'Infectados');
Map.addLayer(imageForAnalysis4.resample(), populationCountVis4, 'População');
Map.style().set('cursor', 'crosshair', true);
// Create an empty panel in which to arrange widgets.
// The layout is vertical flow by default.
var panel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {width: '25%', height: '100%'}})
    .add(ui.Label('Clique no mapa para ver os valores estimados OMS da População total por cada 100x100 metros, da população hospitalizada 10% da pop. infectada COVID-19 que é 50% pop. total, e da População falecida 3.4% da pop. infectada COVID-19 que é 50% pop. total'));
// Create an inspector panel with a horizontal layout.
var inspector0 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
    width: '100%',
  }
});
ui.Panel({style: {width: '100%'}})
// Add a label to the panel.
inspector0.add(ui.Label('Acumulados'));
var inspector = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
  }
});
// Add a label to the panel.
inspector.add(ui.Label('Acumulados'));
var inspector1 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
    width: '100%',
  }
});
ui.Panel({style: {width: '100%'}})
// Add a label to the panel.
inspector1.add(ui.Label('Acumulados'));
var inspector2 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
    width: '100%',
  }
});
ui.Panel({style: {width: '100%'}})
// Add a label to the panel.
inspector2.add(ui.Label('Acumulados'));
var inspector3 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
    width: '100%',
  }
});
ui.Panel({style: {width: '100%'}})
// Add a label to the panel.
inspector3.add(ui.Label('Acumulados'));
// Set a callback function for when the user clicks the map.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector3.clear();
   inspector2.clear();
   inspector1.clear();
 inspector0.clear();
   inspector.clear();
  panel.clear();
  // Create or update the location label (the second widget in the panel)
  var location = 'População '+ 
                  'nas Coord. : lon: ' + coords.lon.toFixed(2) + ' ' +
                 'lat: ' + coords.lat.toFixed(2);
  inspector0.widgets().set(1, ui.Label(location));
  // Add a red dot to the map where the user clicked.
  var geometry = ee.Geometry.Point(coords.lon, coords.lat);
  Map.layers().set(1, ui.Map.Layer(geometry, {color: 'FF0000'},'ponto', true));
  var sampledPoint6m = imageForAnalysis4.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue6m = sampledPoint6m.get('population');
  // Request the value from the server and use the results in a function.
  computedValue6m.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector.widgets().set(2, ui.Label({
      value: 'População Local: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
   var sampledPoint6 = imageForAnalysis3.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue6 = sampledPoint6.get('population');
  // Request the value from the server and use the results in a function.
  computedValue6.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector1.widgets().set(3, ui.Label({
      value: 'População Infectada: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
   var sampledPoint = imageForAnalysis2.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue = sampledPoint.get('population');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector2.widgets().set(4, ui.Label({
      value: 'População Hospitalizada: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
   var sampledPoint3 = imageForAnalysis.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue3 = sampledPoint3.get('population');
  // Request the value from the server and use the results in a function.
  computedValue3.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector3.widgets().set(5, ui.Label({
      value: 'População Falecida: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
//print(TS4);
var panel2 = ui.Panel({style: {width: '100%'}})
    .add(ui.Label('Fontes: Dados da População Global do Projeto WorldPop: População Residencial Estimada por Quadrado de Grade de 100x100m, da População total, valores médios da OMS da população hospitalizada: 10% da pop. infectada COVID-19 que é 50% pop. total, e da População falecida 3.4% da pop. infectada COVID-19 que é 50% pop. total' )); 
Map.centerObject(geometry, 14);
panel.widgets().set(1, inspector0).set(2, inspector).set(3, inspector1).set(4, inspector2).set(5, inspector3).set(5, panel2);
});
Map.setCenter(-44, -20, 4);
Map.setOptions('HYBRID');
// Add the panel to the ui.root.
// Add the panel to the ui.root.
ui.root.add(panel);