var geometry = /* color: #98ff00 */ee.Geometry.Point([-49.36443824768065, -17.494208767734378]);
var dataset = ee.ImageCollection('WORLDCLIM/V1/MONTHLY');
var meanTemperature = dataset.select('tavg', 'tmin', 'tmax','prec'  );
var meanTemperatureVis = {
  min: 0.0,
  max: 300.0,
  palette: ['blue', 'purple', 'cyan', 'green', 'yellow', 'red'],
};
var precipvis = {
  min: 0.0,
  max: 3000,
  palette: ['dbfffc', '29c9ff', '66aeff', '3801ff']
};
Map.centerObject(geometry, 4);
Map.addLayer(meanTemperature.select('tmax').mean(), meanTemperatureVis, 'Temperaturas Máximas');
Map.addLayer(meanTemperature.select('tavg').mean(), meanTemperatureVis, 'Temperaturas Médias');
Map.addLayer(meanTemperature.select('tmin').mean(), meanTemperatureVis, 'Temperaturas Mínimas');
Map.addLayer(meanTemperature.select('prec').sum(), precipvis, 'Precipitação');
Map.style().set('cursor', 'crosshair');
// Create an empty panel in which to arrange widgets.
// The layout is vertical flow by default.
var panel = ui.Panel({style: {width: '75%'}})
    .add(ui.Label('Click on the map'));
// Set a callback function for when the user clicks the map.
Map.onClick(function(coords) {
  // Create or update the location label (the second widget in the panel)
  var location = 'lon: ' + coords.lon.toFixed(2) + ' ' +
                 'lat: ' + coords.lat.toFixed(2);
  panel.widgets().set(1, ui.Label(location));
  // Add a red dot to the map where the user clicked.
  var geometry = ee.Geometry.Point(coords.lon, coords.lat);
  Map.layers().set(1, ui.Map.Layer(geometry, {color: 'FF0000'}));
var TS5 = ui.Chart.image.series(meanTemperature, geometry,  ee.Reducer.mean(), 10, 'month')
.setOptions({
          title: 'Normais Climatológicas',
         intervals: {'style': 'area'},
          series: {
          // Gives each series an axis name that matches the Y-axis below.
          0: {axis: 'tmin', color: 'blue'},
          1: {axis:  'tmax', color: 'green'},
          2: {axis:  'tavg', color: 'red'},
          3: {axis:  'prec', color: 'yellow'}
                  },
          vAxis: {title: 'Graus Celsius x10 e mm/m2'},
          hAxis: {
        title: 'Mêses',
        ticks: [{v: 1, f: 'Jan'},
                {v: 2, f: 'Fev'},
                {v: 3, f: 'Mar'},
                {v: 4, f: 'Abr'},
                {v: 5, f: 'Mai'},
                {v: 6, f: 'Jun'},
                {v: 7, f: 'Jul'},
                {v: 8, f: 'Ago'},
                {v: 9, f: 'Set'},
                {v: 10, f: 'Out'},
                {v: 11, f: 'Nov'},
                {v: 12, f: 'Dez'},]
                },
}).setSeriesNames(["Precipitação", "Temperatura média", "Temperatura Máxima", "Temperatura Mínima"]);
;
//print(TS5);
panel.widgets().set(2, TS5)
});
// Add the panel to the ui.root.
ui.root.add(panel);