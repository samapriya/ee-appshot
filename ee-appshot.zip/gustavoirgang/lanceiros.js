var image = ee.Image("users/gustavoirgang/lanceiros/imagem"),
    table = ee.FeatureCollection("users/gustavoirgang/lanceiros/plantas_talhoes"),
    table2 = ee.FeatureCollection("users/gustavoirgang/lanceiros/plantas_ll");
var limites = ee.FeatureCollection("users/gustavoirgang/lanceiros/limite");
var talhoes = ee.FeatureCollection("users/gustavoirgang/lanceiros/talhoes");
var plantas = ee.FeatureCollection("users/gustavoirgang/lanceiros/plantas_ll");
var  image = ee.Image("users/gustavoirgang/lanceiros/imagem");
var visParams = {
  palette: ['green', 'MAROON', 'purple',  'yellow', 'black', 'blue', 'DARKGOLDENROD',  'orange', 'white', 'red'],
  min: 0,
  max: 50,
  opacity: 0.5,
};
var visParams1 = {
  palette: ['green', 'purple',  'yellow', 'black', 'blue', 'red'],
    opacity: 1,
  pointSize: 1
};
// Turn the strings into numbers
talhoes = talhoes.map(function (f) {
  return f.set('talhao', ee.Number.parse(f.get('talhao')));
});
var talhao = ee.Image().float().paint(talhoes, 'talhao');
var empty = ee.Image().byte();
// Paint the edges with different colors, display.
var outlines0 = empty.paint({
  featureCollection: limites,
  color: 'red',
  width: 3
});
var Outlines = ee.Image().float().paint({
  featureCollection: talhao,
  color: 'red',
  width: 1
});
var palette1 = ['green', 'purple',  'yellow', 'white', 'blue', 'red'];
  var bufferedBart = plantas.map(function(f){
    return f.buffer(2,100)});
    var outlines1 = empty.paint({
  featureCollection: bufferedBart,
  color: 'variedades',
  });
var palette = ['red'];
var ndfiColorTable = function(){
  var ndfi_color = 
    'FFFFFF,FFFCFF,FFF9FF,FFF7FF,FFF4FF,FFF2FF,FFEFFF,FFECFF,FFEAFF,FFE7FF,'+
    'FFE5FF,FFE2FF,FFE0FF,FFDDFF,FFDAFF,FFD8FF,FFD5FF,FFD3FF,FFD0FF,FFCEFF,'+
    'FFCBFF,FFC8FF,FFC6FF,FFC3FF,FFC1FF,FFBEFF,FFBCFF,FFB9FF,FFB6FF,FFB4FF,'+
    'FFB1FF,FFAFFF,FFACFF,FFAAFF,FFA7FF,FFA4FF,FFA2FF,FF9FFF,FF9DFF,FF9AFF,'+
    'FF97FF,FF95FF,FF92FF,FF90FF,FF8DFF,FF8BFF,FF88FF,FF85FF,FF83FF,FF80FF,'+
    'FF7EFF,FF7BFF,FF79FF,FF76FF,FF73FF,FF71FF,FF6EFF,FF6CFF,FF69FF,FF67FF,'+
    'FF64FF,FF61FF,FF5FFF,FF5CFF,FF5AFF,FF57FF,FF55FF,FF52FF,FF4FFF,FF4DFF,'+
    'FF4AFF,FF48FF,FF45FF,FF42FF,FF40FF,FF3DFF,FF3BFF,FF38FF,FF36FF,FF33FF,'+
    'FF30FF,FF2EFF,FF2BFF,FF29FF,FF26FF,FF24FF,FF21FF,FF1EFF,FF1CFF,FF19FF,'+
    'FF17FF,FF14FF,FF12FF,FF0FFF,FF0CFF,FF0AFF,FF07FF,FF05FF,FF02FF,FF00FF,'+
    'FF00FF,FF0AF4,FF15E9,FF1FDF,FF2AD4,FF35C9,FF3FBF,FF4AB4,FF55AA,FF5F9F,'+
    'FF6A94,FF748A,FF7F7F,FF8A74,FF946A,FF9F5F,FFAA55,FFB44A,FFBF3F,FFC935,'+
    'FFD42A,FFDF1F,FFE915,FFF40A,FFFF00,FFFF00,FFFB00,FFF700,FFF300,FFF000,'+
    'FFEC00,FFE800,FFE400,FFE100,FFDD00,FFD900,FFD500,FFD200,FFCE00,FFCA00,'+
    'FFC600,FFC300,FFBF00,FFBB00,FFB700,FFB400,FFB000,FFAC00,FFA800,FFA500,'+
    'FFA500,F7A400,F0A300,E8A200,E1A200,D9A100,D2A000,CA9F00,C39F00,BB9E00,'+
    'B49D00,AC9C00,A59C00,9D9B00,969A00,8E9900,879900,7F9800,789700,709700,'+
    '699600,619500,5A9400,529400,4B9300,439200,349100,2D9000,258F00,1E8E00,'+
    '168E00,0F8D00,078C00,008C00,008C00,008700,008300,007F00,007A00,007600,'+
    '007200,006E00,006900,006500,006100,005C00,005800,005400,005000,004C00';
    return ndfi_color;
};
var styleParams = {
  color: ('green', 'purple',  'yellow', 'black', 'blue', 'red'),
  pointSize: 10,
  opacity: 1
};
var visPar = {'bands':['B7','B5','B4'], gain: [1100.0,400.0,1100.0]};
var visPar = {'min':0.1, 'max':-0.05, 'palette':ndfiColorTable()};//'613F00,FEFFA1,006C00'};
var ndvi = image.normalizedDifference(['b1','b2']);//.max(10);//.multiply(2);
Map.addLayer(ndvi, visPar, 'NDVI', true);
Map.addLayer(
    image,
    {bands: ['b1', 'b2', 'b3'], min: 0, max: 250, gamma: [1.1, 1.1, 1]},
    'Ortofoto rgb');
 Map.addLayer(outlines1, {palette: palette1, max: 6,width: '4'}, 'Plantas');
Map.addLayer(talhao, visParams, 'Talhões');
Map.addLayer(outlines0, {palette: palette, max: 1}, 'Limites');
Map.centerObject(limites, 15);
Map.setOptions('HYBRID');