var table = ee.FeatureCollection("users/gustavoirgang/J_Talhoes"),
    aoi = ee.FeatureCollection("users/gustavoirgang/J_Talhoes");
//var geom = ee.Geometry.Point(102.61270444371178,12.220111410685075).buffer(100) ; // you can change buffer to pixles
var aoi = ee.FeatureCollection("users/gustavoirgang/J_Talhoes"); // add here shapefile
// The layout is vertical flow by default.
var panel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {width: '65%', height: '100%'}})
    .add(ui.Label('Clique no mapa')); 
 // CARREGAR ASSETS E FILTRAR A PARTIR DOS METADADOS
var talhoes = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','A1'),
ee.Filter.eq('Talhao','A2'),
ee.Filter.eq('Talhao','A3'),
ee.Filter.eq('Talhao','A4'),
ee.Filter.eq('Talhao','B1'),
ee.Filter.eq('Talhao','B2'),
ee.Filter.eq('Talhao','B3'),
ee.Filter.eq('Talhao','B4'),
ee.Filter.eq('Talhao','B5'),
ee.Filter.eq('Talhao','C1'),
ee.Filter.eq('Talhao','C2'),
ee.Filter.eq('Talhao','C3'),
ee.Filter.eq('Talhao','C4'),
ee.Filter.eq('Talhao','C5'),
ee.Filter.eq('Talhao','D1'),
ee.Filter.eq('Talhao','D2'),
ee.Filter.eq('Talhao','D3'),
ee.Filter.eq('Talhao','D4'),
ee.Filter.eq('Talhao','E1'),
ee.Filter.eq('Talhao','E2'),
ee.Filter.eq('Talhao','E3'),
ee.Filter.eq('Talhao','E4'),
ee.Filter.eq('Talhao','F1'),
ee.Filter.eq('Talhao','F2'),
ee.Filter.eq('Talhao','F3'),
ee.Filter.eq('Talhao','F4'),
ee.Filter.eq('Talhao','G1'),
ee.Filter.eq('Talhao','G2'),
ee.Filter.eq('Talhao','G3'),
ee.Filter.eq('Talhao','H1'),
ee.Filter.eq('Talhao','H2'),
ee.Filter.eq('Talhao','H3'),
ee.Filter.eq('Talhao','H4'),
ee.Filter.eq('Talhao','I1'),
ee.Filter.eq('Talhao','I2'),
ee.Filter.eq('Talhao','I3'),
ee.Filter.eq('Talhao','I4'),
ee.Filter.eq('Talhao','J1'),
ee.Filter.eq('Talhao','J2'),
ee.Filter.eq('Talhao','J3'),
ee.Filter.eq('Talhao','J4')));
// Function to calculate and add an NDVI band
var addNDVI = function(image) {
return image.addBands(image.normalizedDifference(['B8', 'B4']).multiply(1000).add(-100));
};
var collection = ee.ImageCollection('COPERNICUS/S2')
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 75))
    .filterDate('2018-01-01', ee.Date(Date.now()).advance(0,'day'))
.map(addNDVI)
function maskcloud2(image) {
  var qa = image.select('QA60')
  // 60-meter quality band out of the Sentinel-2 image. 
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0))
  // Return the masked and scaled data, without the QA bands.
  return image.updateMask(mask).divide(10000)
      .select("B.*")
      .copyProperties(image, ["system:time_start"])
}
// Apply 2nd cloud-masking to image collection
var ndvi2 = collection.map(maskcloud2);
var start = ee.Image(ndvi2.first()).date().get('year').format();
var now = Date.now();
var end = ee.Date(now).format();
// Create and print a histogram chart
var ndvi = collection.map(addNDVI).select('nd')
var chart3 = ui.Chart.image.series(ndvi, talhoes, ee.Reducer.mean(), 10, 'system:time_start')
panel.add(chart3);
// CRIAR UM GRÁFICO A PARTIR DOS DADOS ANUAIS DE NDVI
// USANDO ÁREA DE INTERESSE E UM REDUTOR PARA CALCULAR A NDVI MÉDIA NA ÁREA.
// CARREGAR ASSETS E FILTRAR A PARTIR DOS METADADOS
var talhoesA = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','A1'),
ee.Filter.eq('Talhao','A2'),
ee.Filter.eq('Talhao','A3'),
ee.Filter.eq('Talhao','A4')
));
var title2 = {
  title: 'Total NDVI anual',
  hAxis: {title: 'Ano'},
  vAxis: {title: 'NDVI'},
};
var chart3 = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesA,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title2)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chart3);
var talhoesB = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','B1'),
ee.Filter.eq('Talhao','B2'),
ee.Filter.eq('Talhao','B3'),
ee.Filter.eq('Talhao','B4'),
ee.Filter.eq('Talhao','B5')
));
var titleB = {
  title: 'Total NDVI anual',
  hAxis: {title: 'Ano'},
  vAxis: {title: 'NDVI'},
};
var chartB = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesB,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title2)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartB);
var talhoesC = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','C1'),
ee.Filter.eq('Talhao','C2'),
ee.Filter.eq('Talhao','C3'),
ee.Filter.eq('Talhao','C4'),
ee.Filter.eq('Talhao','C5')
));
var titleC = {
  title: 'Total NDVI',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartC = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesC,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title2)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartC);
var talhoesD = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','D1'),
ee.Filter.eq('Talhao','D2'),
ee.Filter.eq('Talhao','D3'),
ee.Filter.eq('Talhao','D4')
));
var titleD = {
  title: 'Total NDVI',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartD = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesD,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title2)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartD);
var talhoesE = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','E1'),
ee.Filter.eq('Talhao','E2'),
ee.Filter.eq('Talhao','E3'),
ee.Filter.eq('Talhao','E4')
));
var titleE = {
  title: 'Total NDVI',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartE = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesE,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title2)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartE);
var talhoesF = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','F1'),
ee.Filter.eq('Talhao','F2'),
ee.Filter.eq('Talhao','F3'),
ee.Filter.eq('Talhao','F4')
));
var titleF = {
  title: 'Total NDVI',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartF = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesF,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title2)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartF);
var talhoesG = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','G1'),
ee.Filter.eq('Talhao','G2'),
ee.Filter.eq('Talhao','G3')
));
var titleG = {
  title: 'Total NDVI',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartG = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesG,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title2)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartG);
var talhoesH = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','H1'),
ee.Filter.eq('Talhao','H2'),
ee.Filter.eq('Talhao','H3'),
ee.Filter.eq('Talhao','H4')
));
var titleH = {
  title: 'Total NDVI',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartH = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesH,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title2)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartH);
var talhoesI = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','I1'),
ee.Filter.eq('Talhao','I2'),
ee.Filter.eq('Talhao','I3'),
ee.Filter.eq('Talhao','I4')
));
var titleI = {
  title: 'Total NDVI',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartI = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesI,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title2)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartI);
var talhoesJ = aoi.filter(ee.Filter.or(
ee.Filter.eq('Talhao','J1'),
ee.Filter.eq('Talhao','J2'),
ee.Filter.eq('Talhao','J3'),
ee.Filter.eq('Talhao','J4')
));
var titleI = {
  title: 'Total NDVI',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartJ = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesJ,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title2)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartJ);
var title = {
  title: 'Total NDVI anual',
  hAxis: {title: 'Ano'},
  vAxis: {title: 'NDVI'},
};
var chart = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoes,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Talhao'
}).setOptions(title)
  .setChartType('Table');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chart);
// Run this function on a change of the dateSlider.
var showMosaic = function(range) {
var collection = ee.ImageCollection('COPERNICUS/S2')
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 75))
    .filterDate('2017-09-01', ee.Date(Date.now()))
    .filterDate(range.start(), range.end())
.map(addNDVI)
function maskcloud2(image) {
  var qa = image.select('QA60')
  // 60-meter quality band out of the Sentinel-2 image. 
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0))
  // Return the masked and scaled data, without the QA bands.
  return image.updateMask(mask).divide(10000).clip(aoi)
      .select("B.*")
      .copyProperties(image, ["system:time_start"])
}
// Apply 2nd cloud-masking to image collection
var ndvi2 = collection.map(maskcloud2);
var start = ee.Image(ndvi2.first()).date().get('year').format();
var now = Date.now();
var end = ee.Date(now).format();
// Create and print a histogram chart
var ndvi = ndvi2.map(addNDVI).select('nd')
// Display results in map window
range.start().get('month').evaluate(function(name) {
   var vhVizParam2 = {"opacity":1,"bands":['nd'],palette: ['FFFFFF','CC9966','CC9900', '996600', '33CC00', '009900','006600','000000'],"min": 200 ,"max": 820}
//Map.addLayer(ws1, precipvis2,  name + "Velociade Corrente");
 var layer3 = ui.Map.Layer(ndvi, vhVizParam2,  name + " Índice de Bagas m²");
Map.layers().set(1, layer3)
});
range.start().get('month').evaluate(function(name) {
 var visParams = {bands: ['B4', 'B3', 'B2'], max: 1900};
    var layer = ui.Map.Layer(collection, visParams, name + ' composite');
    Map.layers().set(0, layer);
});
var text = require('users/gena/packages:text')
// scale text font relative to the current map scale
var scale = Map.getScale() * 0.4
var labels = aoi.map(function(feat) {
  feat = ee.Feature(feat)
  var name = ee.String(feat.get("Talhao"))
  var centroid = feat.geometry().centroid()
  var t = text.draw(name, centroid, scale, {
    fontSize:18, 
    textColor:'red',
    outlineWidth: 1,
    outlineColor: 'red'
  })
  return t
})
labels = ee.ImageCollection(labels)
Map.addLayer(labels)
ui.root.add(panel);
Map.centerObject(talhoes, 15);
};
// Asynchronously compute the date range and show the slider.
var dateRange = ee.DateRange(start, end).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: 5,
    onChange: showMosaic,
    style: {
    position: 'bottom-center',
    padding: '7px'
  }
  });
 Map.add(dateSlider.setValue( now)); //.setValue(now));
// Add the panel to the map.
});