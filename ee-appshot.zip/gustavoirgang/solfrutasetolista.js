var geometry = /* color: #98ff00 */ee.Geometry.Point([-40.903225, -9.246154]);
// Define RGB visualization parameters.
var visParams = {
  min: 0.0,
  max: 10.0,
  opacity: 0.30,
  palette: [
    'FFFFFF', '000088','008800','777700', '880000'
  ],
};
var date = ee.Date(Date.now());
  print(date)
  var date100 = date.format("YYYY-MM-dd");
  date100 =date100.getInfo();
var date01 = ee.Date(Date.now()).advance(-31,'day');
  print(date01)
  var date1 = date01.format("YYYY-MM-dd");
  date1 =date1.getInfo();
  var date02 = ee.Date(Date.now()).advance(-30,'day');
  print(date02)
  var date2 = date02.format("YYYY-MM-dd");
  date2 =date2.getInfo();
  var date03 = ee.Date(Date.now()).advance(-29,'day');
  print(date03)
  var date3 = date03.format("YYYY-MM-dd");
  date3 =date3.getInfo();
   var date04 = ee.Date(Date.now()).advance(-28,'day');
  print(date04)
  var date4 = date04.format("YYYY-MM-dd");
  date4 =date4.getInfo();
   var date05 = ee.Date(Date.now()).advance(-27,'day');
 // print(date05)
  var date5 = date05.format("YYYY-MM-dd");
  date5 =date5.getInfo();
    var date06 = ee.Date(Date.now()).advance(-26,'day');
 // print(date06)
  var date6 = date06.format("YYYY-MM-dd");
  date6 =date6.getInfo();
   var date07 = ee.Date(Date.now()).advance(-25,'day');
 // print(date07)
  var date7 = date07.format("YYYY-MM-dd");
  date7 =date7.getInfo();
    var date08 = ee.Date(Date.now()).advance(-24,'day');
 // print(date07)
  var date8 = date08.format("YYYY-MM-dd");
  date8 =date8.getInfo();
    var date09 = ee.Date(Date.now()).advance(-23,'day');
 // print(date07)
  var date9 = date09.format("YYYY-MM-dd");
  date9 =date9.getInfo();
    var date010 = ee.Date(Date.now()).advance(-22,'day');
 // print(date07)
  var date10 = date010.format("YYYY-MM-dd");
  date10 =date10.getInfo();
    var date011 = ee.Date(Date.now()).advance(-21,'day');
 // print(date07)
  var date11 = date011.format("YYYY-MM-dd");
  date11 =date11.getInfo();
    var date012 = ee.Date(Date.now()).advance(-20,'day');
 // print(date07)
  var date12 = date012.format("YYYY-MM-dd");
  date12 =date12.getInfo();
    var date013 = ee.Date(Date.now()).advance(-19,'day');
 // print(date07)
  var date13 = date013.format("YYYY-MM-dd");
  date13 =date13.getInfo();
    var date014 = ee.Date(Date.now()).advance(-18,'day');
 // print(date07)
  var date14 = date014.format("YYYY-MM-dd");
  date14 =date14.getInfo();
    var date015 = ee.Date(Date.now()).advance(-17,'day');
 // print(date07)
  var date15 = date015.format("YYYY-MM-dd");
  date15 =date15.getInfo();
   var date016 = ee.Date(Date.now()).advance(-16,'day');
 // print(date07)
  var date16 = date016.format("YYYY-MM-dd");
  date16 =date16.getInfo();
   var date017 = ee.Date(Date.now()).advance(-15,'day');
 // print(date07)
  var date17 = date017.format("YYYY-MM-dd");
  date17 =date17.getInfo();
   var date018 = ee.Date(Date.now()).advance(-14,'day');
 // print(date07)
  var date18 = date018.format("YYYY-MM-dd");
  date18 =date18.getInfo();
   var date019 = ee.Date(Date.now()).advance(-13,'day');
 // print(date07)
  var date19 = date019.format("YYYY-MM-dd");
  date19 =date19.getInfo();
   var date020 = ee.Date(Date.now()).advance(-12,'day');
 // print(date07)
  var date20 = date020.format("YYYY-MM-dd");
  date20 =date20.getInfo();
   var date021 = ee.Date(Date.now()).advance(-11,'day');
 // print(date07)
  var date21 = date021.format("YYYY-MM-dd");
  date21 =date21.getInfo();
   var date022 = ee.Date(Date.now()).advance(-10,'day');
 // print(date07)
  var date22 = date022.format("YYYY-MM-dd");
  date22 =date22.getInfo();
   var date023 = ee.Date(Date.now()).advance(-9,'day');
 // print(date07)
  var date23 = date023.format("YYYY-MM-dd");
  date23 =date23.getInfo();
   var date024 = ee.Date(Date.now()).advance(-8,'day');
 // print(date07)
  var date24 = date024.format("YYYY-MM-dd");
  date24 =date24.getInfo();
   var date025 = ee.Date(Date.now()).advance(-7,'day');
 // print(date07)
  var date25 = date025.format("YYYY-MM-dd");
  date25 =date25.getInfo();
   var date026 = ee.Date(Date.now()).advance(-6,'day');
 // print(date07)
  var date26 = date026.format("YYYY-MM-dd");
  date26 =date26.getInfo();
   var date027 = ee.Date(Date.now()).advance(-5,'day');
 // print(date07)
  var date27 = date027.format("YYYY-MM-dd");
  date27 =date27.getInfo();
   var date028 = ee.Date(Date.now()).advance(-4,'day');
 // print(date07)
  var date28 = date028.format("YYYY-MM-dd");
  date28 =date28.getInfo();
   var date029 = ee.Date(Date.now()).advance(-3,'day');
 // print(date07)
  var date29 = date029.format("YYYY-MM-dd");
  date29 =date29.getInfo();
   var date030 = ee.Date(Date.now()).advance(-2,'day');
 // print(date07)
  var date30 = date030.format("YYYY-MM-dd");
  date30 =date30.getInfo();
   var date031 = ee.Date(Date.now()).advance(-1,'day');
 // print(date07)
  var date31 = date031.format("YYYY-MM-dd");
  date31 =date31.getInfo();
var dataset0d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-32,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-31,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-90,'day'), ee.Date(Date.now()).advance(-0,'day')));  
var dataset00d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-365,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-31,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-90,'day'), ee.Date(Date.now()).advance(-0,'day')));
var UmidityAboveGround3m1 = dataset00d.select('relative_humidity_2m_above_ground').median();
var UmidadeAboveGroundX11 = UmidityAboveGround3m1.gte(80).divide(UmidityAboveGround3m1.gte(80)).multiply(80);
var UmidadeAboveGroundX12 = UmidityAboveGround3m1.updateMask(UmidityAboveGround3m1.lt(80));
//var UmidadeAboveGroundX13 = UmidadeAboveGroundX1.multiply(UmidadeAboveGroundX12)
var UmidadeAboveGroundX14 = UmidadeAboveGroundX12.unmask(UmidadeAboveGroundX11);
var TERRACLIMATE0d = dataset0d.select( 'temperature_2m_above_ground');
var dia0d = (TERRACLIMATE0d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset1d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-31,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-30,'day').millis()));
 //.filter(ee.Filter.date( ee.Date(Date.now()).advance(-50,'hour'), ee.Date(Date.now()).advance(0,'hour')));
var TERRACLIMATE1d = dataset1d.select( 'temperature_2m_above_ground');
var dia1d = (TERRACLIMATE1d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset2d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-30,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-29,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-28,'hour'), ee.Date(Date.now()).advance(0,'hour')));
var TERRACLIMATE2d = dataset2d.select( 'temperature_2m_above_ground');
var dia2d = (TERRACLIMATE2d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset3d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-29,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-28,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-76,'hour'), ee.Date(Date.now()).advance(0,'hour')));
var TERRACLIMATE3d = dataset3d.select( 'temperature_2m_above_ground');
var dia3d = (TERRACLIMATE3d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset4d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-28,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-27,'day').millis()));
 //.filter(ee.Filter.date( ee.Date(Date.now()).advance(-7,'day'), ee.Date(Date.now()).advance(0,'hour')));
var UmidityAboveGround4d = dataset4d.select('relative_humidity_2m_above_ground');
var TERRACLIMATE4d = dataset4d.select( 'temperature_2m_above_ground');
var dia4d = (TERRACLIMATE4d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset5d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-27,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-26,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-14,'day'), ee.Date(Date.now()).advance(-7,'day')));
var TERRACLIMATE5d = dataset5d.select( 'temperature_2m_above_ground');
var dia5d = (TERRACLIMATE5d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset6d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-26,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-25,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-21,'day'), ee.Date(Date.now()).advance(-14,'day')));
var TERRACLIMATE6d = dataset6d.select( 'temperature_2m_above_ground');
var dia6d = (TERRACLIMATE6d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset7d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-25,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-24,'day').millis()));
 //.filter(ee.Filter.date( ee.Date(Date.now()).advance(-30,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE7d = dataset7d.select( 'temperature_2m_above_ground');
var dia7d = (TERRACLIMATE7d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset8d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-24,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-23,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE8d = dataset8d.select( 'temperature_2m_above_ground');
var dia8d = (TERRACLIMATE8d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset9d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-23,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-22,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE9d = dataset9d.select( 'temperature_2m_above_ground');
var dia9d = (TERRACLIMATE9d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset10d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-22,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-21,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE10d = dataset10d.select( 'temperature_2m_above_ground');
var dia10d = (TERRACLIMATE10d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset11d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-21,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-20,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE11d = dataset11d.select( 'temperature_2m_above_ground');
var dia11d = (TERRACLIMATE11d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset12d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-20,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-19,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE12d = dataset12d.select( 'temperature_2m_above_ground');
var dia12d = (TERRACLIMATE12d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset13d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-19,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-18,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE13d = dataset13d.select( 'temperature_2m_above_ground');
var dia13d = (TERRACLIMATE13d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset14d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-18,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-17,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE14d = dataset14d.select( 'temperature_2m_above_ground');
var dia14d = (TERRACLIMATE14d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset15d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-17,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-16,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE15d = dataset15d.select( 'temperature_2m_above_ground');
var dia15d = (TERRACLIMATE15d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset16d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-16,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-15,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE16d = dataset16d.select( 'temperature_2m_above_ground');
var dia16d = (TERRACLIMATE16d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset17d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-15,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-14,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE17d = dataset17d.select( 'temperature_2m_above_ground');
var dia17d = (TERRACLIMATE17d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset18d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-14,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-13,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE18d = dataset18d.select( 'temperature_2m_above_ground');
var dia18d = (TERRACLIMATE18d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset19d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-13,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-12,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE19d = dataset19d.select( 'temperature_2m_above_ground');
var dia19d = (TERRACLIMATE19d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset20d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-12,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-11,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE20d = dataset20d.select( 'temperature_2m_above_ground');
var dia20d = (TERRACLIMATE20d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset21d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-10,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-9,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE21d = dataset21d.select( 'temperature_2m_above_ground');
var dia21d = (TERRACLIMATE21d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset22d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-10,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-9,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE22d = dataset22d.select( 'temperature_2m_above_ground');
var dia22d = (TERRACLIMATE22d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset23d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-9,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-8,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE23d = dataset23d.select( 'temperature_2m_above_ground');
var dia23d = (TERRACLIMATE23d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset24d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-8,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-7,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE24d = dataset24d.select( 'temperature_2m_above_ground');
var dia24d = (TERRACLIMATE24d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset25d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-7,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-6,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE25d = dataset25d.select( 'temperature_2m_above_ground');
var dia25d = (TERRACLIMATE25d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset26d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-6,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-5,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE26d = dataset26d.select( 'temperature_2m_above_ground');
var dia26d = (TERRACLIMATE26d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset27d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-5,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-4,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE27d = dataset27d.select( 'temperature_2m_above_ground');
var dia27d = (TERRACLIMATE27d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset28d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-4,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-3,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE28d = dataset28d.select( 'temperature_2m_above_ground');
var dia28d = (TERRACLIMATE28d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset29d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-3,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-2,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE29d = dataset29d.select( 'temperature_2m_above_ground');
var dia29d = (TERRACLIMATE29d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset30d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-2,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).advance(-1,'day').millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE30d = dataset30d.select( 'temperature_2m_above_ground');
var dia30d = (TERRACLIMATE30d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var dataset31d = ee.ImageCollection('NOAA/GFS0P25').filter(ee.Filter.eq('forecast_hours', 0))
.filter(ee.Filter.gt('forecast_time', ee.Date(Date.now()).advance(-1,'day').millis())).filter(ee.Filter.lt('forecast_time',  ee.Date(Date.now()).millis()));
// .filter(ee.Filter.date( ee.Date(Date.now()).advance(-182,'day'), ee.Date(Date.now()).advance(-0,'day')));
var TERRACLIMATE31d = dataset31d.select( 'temperature_2m_above_ground');
var dia31d = (TERRACLIMATE31d.median().multiply(3.7)).multiply((((((UmidadeAboveGroundX14)).multiply(-1)).add(100)).multiply(0.0145))).multiply(58.93).multiply(1).divide(365);
var brasil = ee.FeatureCollection('users/gustavoirgang/BRPais');
Map.setCenter(-40.903225, -9.246154, 4)
Map.addLayer(dia1d.resample(), visParams, 'Acumulado 1 dia', false);
Map.addLayer(dia2d.resample(), visParams, 'Acumulado 2 dia', false);
Map.addLayer(dia2d.resample(), visParams, 'Acumulado 2 dia', false);
Map.addLayer(dia3d.resample(), visParams, 'Acumulado 3 dia', false);
Map.addLayer(dia3d.resample(), visParams, 'Acumulado 3 dia', false);
Map.addLayer(dia4d.resample(), visParams, 'Acumulado 4 dia', false);
Map.addLayer(dia5d.resample(), visParams, 'Acumulado 5 dia', false);
Map.addLayer(dia6d.resample(), visParams, 'Acumulado 6 dia', false);
Map.addLayer(dia7d.resample(), visParams, 'Acumulado 7 dia', false);
Map.addLayer(dia8d.resample(), visParams, 'Acumulado 8 dia', false);
Map.addLayer(dia9d.resample(), visParams, 'Acumulado 9 dia', false);
Map.addLayer(dia10d.resample(), visParams, 'Acumulado 10 dia', false);
Map.addLayer(dia11d.resample(), visParams, 'Acumulado 11 dia', false);
Map.addLayer(dia12d.resample(), visParams, 'Acumulado 12 dia', false);
Map.addLayer(dia13d.resample(), visParams, 'Acumulado 13 dia', false);
Map.addLayer(dia14d.resample(), visParams, 'Acumulado 14 dia', false);
Map.addLayer(dia15d.resample(), visParams, 'Acumulado 15 dia', false);
Map.addLayer(dia16d.resample(), visParams, 'Acumulado 16 dia', false);
Map.addLayer(dia17d.resample(), visParams, 'Acumulado 17 dia', false);
Map.addLayer(dia18d.resample(), visParams, 'Acumulado 18 diq', false);
Map.addLayer(dia19d.resample(), visParams, 'Acumulado 19 dia', false);
Map.addLayer(dia20d.resample(), visParams, 'Acumulado 20 dia', false);
Map.addLayer(dia21d.resample(), visParams, 'Acumulado 21 dia', false);
Map.addLayer(dia22d.resample(), visParams, 'Acumulado 22 dia', false);
Map.addLayer(dia23d.resample(), visParams, 'Acumulado 23 dia', false);
Map.addLayer(dia24d.resample(), visParams, 'Acumulado 24 dia', false);
Map.addLayer(dia25d.resample(), visParams, 'Acumulado 25 dia', false);
Map.addLayer(dia26d.resample(), visParams, 'Acumulado 26 dia', false);
Map.addLayer(dia27d.resample(), visParams, 'Acumulado 27 dia', false);
Map.addLayer(dia28d.resample(), visParams, 'Acumulado 28 dia', false);
Map.addLayer(dia29d.resample(), visParams, 'Acumulado 29 dia', false);
Map.addLayer(dia30d.resample(), visParams, 'Acumulado 30 dia', false);
Map.addLayer(dia31d.resample(), visParams, 'Acumulado 31 dia');
Map.style().set('cursor', 'crosshair', true);
// Create an empty panel in which to arrange widgets.
// The layout is vertical flow by default.
var panel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {width: '65%', height: '100%'}})
.add(ui.Label('OBSERVATÓRIO AGROCLIMÁTICO POMARTEC '))
    .add(ui.Label('Clique no mapa para ver os valores Evapotranspiração ETo por dia nos últimos 31 dias'));
// Create an inspector panel with a horizontal layout.
var inspector0 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
  }
});
// Add a label to the panel.
inspector0.add(ui.Label('Acumulados'));
var inspector00 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
  }
});
// Add a label to the panel.
inspector00.add(ui.Label('Acumulados'));
var inspector = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
  }
});
var inspector1 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      }
});
// Add a label to the panel.
inspector1.add(ui.Label(''));
var inspector2 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      }
});
// Add a label to the panel.
inspector2.add(ui.Label(''));
// Add the panel to the default map.
var inspector3 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      }
});
// Add a label to the panel.
inspector3.add(ui.Label(''));
var inspector4 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      }
});
// Add a label to the panel.
inspector4.add(ui.Label(''));
var inspector5 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      } });
// Add a label to the panel.
inspector5.add(ui.Label(''));
var inspector6 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      } });
// Add a label to the panel.
inspector6.add(ui.Label(''));
var inspector7 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      } });
// Add a label to the panel.
inspector7.add(ui.Label(''));
var inspector8 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      } });
// Add a label to the panel.
inspector8.add(ui.Label(''));
var inspector9 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      } });
// Add a label to the panel.
inspector9.add(ui.Label(''));
var inspector10 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      } });
// Add a label to the panel.
inspector10.add(ui.Label(''));
var inspector11 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
      } });
// Add a label to the panel.
inspector11.add(ui.Label(''));
var inspector20 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
  }
});
// Add a label to the panel.
inspector5.add(ui.Label('Acumulados'));
// Set the default map's cursor to a "crosshair".
Map.style().set('cursor', 'crosshair');
// Set a callback function for when the user clicks the map.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector00.clear();
  inspector0.clear();
  inspector.clear();
  inspector2.clear();
  inspector3.clear();
  inspector4.clear();
  inspector5.clear();
  inspector6.clear();
  inspector7.clear();
  inspector8.clear();
  inspector9.clear();
  inspector10.clear();
  inspector11.clear();
  panel.clear();
  // Create or update the location label (the second widget in the panel)
  var location1 = 'OBSERVATÓRIO AGROCLIMÁTICO POMARTEC Consulta realizada em: '+ date100 ;
   var location =   'Evapotranspiração ETo em mm/m²'+ 
                  ' da amostra para cada dia analisada nas Coordenadas : lon: ' + coords.lon.toFixed(2) + ' ' +
                 'lat: ' + coords.lat.toFixed(2);
 inspector.widgets().set(1, ui.Label(location));
  inspector0.widgets().set(1, ui.Label(location1));
  // Add a red dot to the map where the user clicked.
  var geometry = ee.Geometry.Point(coords.lon, coords.lat);
  Map.layers().set(1, ui.Map.Layer(geometry, {color: 'FF0000'},'ponto', true));
  var geometryyy = /* color: #d63000 */ee.Geometry.Point([-40.903225, -9.246154]);
Map.layers().set(3, ui.Map.Layer(geometryyy, {color: 'FFFF00'},'Fazenda')); 
  var sampledPoint1d = dia1d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue1d = sampledPoint1d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue1d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector1.widgets().set(1, ui.Label({
      value: 'Dia 1, ' + date1 +' ETo: '  + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint2d = dia2d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue2d = sampledPoint2d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue2d.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector1.widgets().set(2, ui.Label({
      value: 'Dia 2, ' + date2 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
   var sampledPoint3d = dia3d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue3d = sampledPoint3d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue3d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector1.widgets().set(3, ui.Label({
      value: 'Dia 3, ' + date3 +' ETo: '  + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
   var sampledPoint4d = dia4d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue4d = sampledPoint4d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue4d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector2.widgets().set(1, ui.Label({
      value: 'Dia 4, ' + date4 +' ETo: '  + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
   var sampledPoint5d = dia5d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue5d = sampledPoint5d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue5d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector2.widgets().set(2, ui.Label({
      value: 'Dia 5, ' + date5 +' ETo: '  + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint6d = dia6d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue6d = sampledPoint6d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue6d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector2.widgets().set(3, ui.Label({
      value: 'Dia 6, ' + date6 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
   var sampledPoint7d = dia7d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue7d = sampledPoint7d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue7d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector3.widgets().set(1, ui.Label({
      value: 'Dia 7, ' + date7 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
   var sampledPoint8d = dia8d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue8d = sampledPoint8d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue8d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector3.widgets().set(2, ui.Label({
      value: 'Dia 8, ' + date8 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint9d = dia9d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue9d = sampledPoint9d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue9d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector3.widgets().set(3, ui.Label({
      value: 'Dia 9, ' + date9 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint10d = dia10d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue10d = sampledPoint10d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue10d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector4.widgets().set(1, ui.Label({
      value: 'Dia 10, ' + date10 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint11d = dia11d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue11d = sampledPoint11d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue11d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector4.widgets().set(2, ui.Label({
      value: 'Dia 11, ' + date11 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint12d = dia12d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue12d = sampledPoint12d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue12d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector4.widgets().set(3, ui.Label({
      value: 'Dia 12, ' + date12 +' ETo: '  + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint13d = dia13d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue13d = sampledPoint13d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue13d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector5.widgets().set(1, ui.Label({
      value: 'Dia 13, ' + date13 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
var sampledPoint14d = dia14d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue14d = sampledPoint14d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue14d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector5.widgets().set(1, ui.Label({
      value: 'Dia 14, ' + date14 +' ETo: '  + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
var sampledPoint15d = dia15d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue15d = sampledPoint15d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue15d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector5.widgets().set(2, ui.Label({
      value: 'Dia 15, ' + date15 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint16d = dia16d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue16d = sampledPoint16d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue16d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector6.widgets().set(1, ui.Label({
      value: 'Dia 16, ' + date16 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint17d = dia17d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue17d = sampledPoint17d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue17d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector6.widgets().set(2, ui.Label({
      value: 'Dia 17, ' + date17 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint18d = dia18d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue18d = sampledPoint18d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue18d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector6.widgets().set(3, ui.Label({
      value: 'Dia 18, ' + date18 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint19d = dia19d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue19d = sampledPoint19d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue19d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector7.widgets().set(1, ui.Label({
      value: 'Dia 19, ' + date19 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint20d = dia20d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue20d = sampledPoint20d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue20d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector7.widgets().set(2, ui.Label({
      value: 'Dia 20, ' + date20 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint21d = dia15d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue21d = sampledPoint21d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue21d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector7.widgets().set(3, ui.Label({
      value: 'Dia 21, ' + date21 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint22d = dia22d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue22d = sampledPoint22d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue22d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector8.widgets().set(1, ui.Label({
      value: 'Dia 22, ' + date22 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint23d = dia23d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue23d = sampledPoint23d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue23d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector8.widgets().set(2, ui.Label({
      value: 'Dia 23, ' + date23 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint24d = dia24d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue24d = sampledPoint24d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue24d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector8.widgets().set(3, ui.Label({
      value: 'Dia 24, ' + date24 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint25d = dia25d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue25d = sampledPoint25d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue25d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector9.widgets().set(1, ui.Label({
      value: 'Dia 25, ' + date25 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint26d = dia26d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue26d = sampledPoint26d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue26d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector9.widgets().set(2, ui.Label({
      value: 'Dia 26, ' + date26 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint27d = dia27d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue27d = sampledPoint27d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue27d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector9.widgets().set(3, ui.Label({
      value: 'Dia 27, ' + date27 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint28d = dia28d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue28d = sampledPoint28d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue28d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector10.widgets().set(1, ui.Label({
      value: 'Dia 28, ' + date15 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint29d = dia29d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue29d = sampledPoint29d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue29d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector10.widgets().set(2, ui.Label({
      value: 'Dia 29, ' + date29 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint30d = dia30d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue30d = sampledPoint30d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue30d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector10.widgets().set(3, ui.Label({
      value: 'Dia 30, ' + date30 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint31d = dia31d.reduceRegion(ee.Reducer.mean(), geometry, 1);
  var computedValue31d = sampledPoint31d.get('temperature_2m_above_ground');
  // Request the value from the server and use the results in a function.
  computedValue31d.evaluate(function(result) {
       // Add a label with the results from the server.
    inspector11.widgets().set(2, ui.Label({
      value: 'Dia 31, ' + date31 +' ETo: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
var panel2 = ui.Panel({style: {width: '65%'}})
    .add(ui.Label('Fontes:  Global Forecast System - GFS do National Centers for Environmental Prediction (NCEP): Sistema de previsão global de dados de atmosfera de 384 horas. OBS.: Se não alinhar os dados clique novamente' )); 
Map.centerObject(geometry, 16);
panel.widgets().set(1, inspector0).set(2, inspector).set(3, inspector1).set(4, inspector2).set(5, inspector3).set(6, inspector4).set(7, inspector5).set(8, inspector6).set(9, inspector7).set(10, inspector8).set(11, inspector9).set(12, inspector10).set(13, inspector11).set(20, panel2);
});
Map.setOptions('HYBRID');
var geometryyy = /* color: #d63000 */ee.Geometry.Point([-40.903225, -9.246154]);
Map.centerObject(geometryyy, 14);
Map.layers().set(3, ui.Map.Layer(geometryyy, {color: 'FFFF00'},'Fazenda')); 
// Add the panel to the ui.root.
// Add the panel to the ui.root.
ui.root.add(panel);