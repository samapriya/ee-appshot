var geometry = /* color: #d63000 */ee.Geometry.Point([-50.843911707401276, -28.10139041303475]),
    imageCollection = ee.ImageCollection("NOAA/GFS0P25"),
    table = ee.FeatureCollection("users/gustavoirgang/BRPais");
var modisLSTnight = ee.ImageCollection('MODIS/006/MYD11A1').select('LST_Night_1km');
var modLSTnight = modisLSTnight.map(function(img) {
  return img.multiply(0.02).subtract(273.15).copyProperties(img,['system:time_start','system:time_end']); 
});
// Select dates
var collection05night = ee.ImageCollection(modLSTnight.filterDate(ee.Date(Date.now()).advance(-180,'day'), ee.Date(Date.now()).advance(386,'hour')));
var collection05night2 = ee.ImageCollection(modLSTnight.filterDate(ee.Date(Date.now()).advance(-1825,'day'), ee.Date(Date.now()).advance(0,'hour')));
var quality = function(image){ 
  var mask1 = image.select("LST_Night_1km").lte(7.2);
  return image.updateMask(mask1);
};
var clean_collection = collection05night.map(quality);
var clean_collection2 = collection05night2.map(quality);
var visParams = {
  min: 600,
  max:0,
  opacity:0.65,
  palette: ["blue", "purple", "cyan", "green", "yellow", "red"]
};
Map.setCenter(-88.6, 26.4, 1);
Map.addLayer(clean_collection.count().multiply(10), visParams, 'Horas de Frio Último semestre');
var months = ee.List.sequence(1, 12);
var years = ee.List.sequence(2000, 2019);
var byMonthYear = ee.ImageCollection.fromImages(
  months.map(function (m) {
     return clean_collection
      .filter(ee.Filter.calendarRange(m, m, 'month'))
      .count().multiply(10)
      .set('month', m);
 }).flatten());
//print(byMonthYear)
var Brazil = ee.FeatureCollection('users/gustavoirgang/BRPais');
Map.addLayer(Brazil, visParams,'Brasil');
var dataset = ee.ImageCollection('NOAA/GFS0P25')
              .filter(ee.Filter.date( ee.Date(Date.now()).advance(-1,'day'), ee.Date(Date.now()).advance(386,'hour')));
     var data = ee.Date(Date.now());
     print (data);
      var collection = dataset
                .select('temperature_2m_above_ground');       
               // .filter(ee.Filter.eq('creation_time',ee.Date(0).update(year, month, day, hour, minute, second, timeZone).millis()));
               // .filter(ee.Filter.eq('forecast_hours',3));  
var temperatureAboveGround = collection; //dataset.select('temperature_2m_above_ground');
var quality = function(image){ 
  var mask1 = image.select("temperature_2m_above_ground").lte(7.2);
  return image.updateMask(mask1).copyProperties(image,['system:time_start','system:forecast_time']);
};
var Hfrio = collection.map(quality);
Map.setCenter(-54, -18, 4);
Map.addLayer(Hfrio.count().multiply(10), visParams, 'Previsão de Hora de Frio');
Map.centerObject(geometry, 5);
Map.style().set('cursor', 'crosshair', true);
// Create an empty panel in which to arrange widgets.
// The layout is vertical flow by default.
var panel = ui.Panel({style: {width: '65%'}})
    .add(ui.Label('Click no mapa'));
// Set a callback function for when the user clicks the map.
Map.onClick(function(coords) {
  // Create or update the location label (the second widget in the panel)
  var location = 'lon: ' + coords.lon.toFixed(2) + ' ' +
                 'lat: ' + coords.lat.toFixed(2);
  panel.widgets().set(1, ui.Label(location));
  // Add a red dot to the map where the user clicked.
  var geometry = ee.Geometry.Point(coords.lon, coords.lat);
  Map.layers().set(1, ui.Map.Layer(geometry, {color: 'FF0000'},'ponto', false));
// Define a chart with one series precip in the forest region, averaged by DOY.
var Grafico5 = ui.Chart.image.series(
    Hfrio, geometry, ee.Reducer.median(),1,'forecast_time')
    .setChartType('ScatterChart')
    .setOptions({
          title: 'Previsão de Registros de Horas de Frio Temperaturas =<7.2ºC',
          vAxis: {title: 'Graus Celsius (ºC)'},
          hAxis: {title: 'dia do ano'},
          trendlines: {
      0: {
        type: 'polynomial',
        degree: 8,
        color: 'red',
        visibleInLegend: false,
      }
    }
});
var Grafico4 = ui.Chart.image.series(
    clean_collection, geometry, ee.Reducer.median(),1)
    .setChartType('ScatterChart')
    .setOptions({
          title: 'Registros ultimos seis meses de Horas de Frio com Temperaturas =<7.2ºC',
          vAxis: {title: 'Graus Celsius (ºC)'},
          hAxis: {title: 'dia do ano'},
          trendlines: {
      0: {
        type: 'polynomial',
        degree: 8,
        color: 'red',
        visibleInLegend: false,
      }
    }
});
// Display the three charts
//print(Grafico5);
//print(Grafico4);
//print(TS4);
var panel2 = ui.Panel({style: {width: '65%'}})
    .add(ui.Label('Fontes: temperatura da superfície diurna e nocturna e as suas camadas indicadoras de qualidade são as bandas MODIS e Global Forecast System (GFS) é um modelo de previsão meteorológica de 384 horas com intervalo de previsão de 3 horas' )); 
var Grafico3 = ui.Chart.image.series(
    clean_collection2, geometry, ee.Reducer.median(),1)
    .setChartType('ScatterChart')
    .setOptions({
          title: 'Registros ultimos seis anos de Horas de Frio com Temperaturas =<7.2ºC',
          vAxis: {title: 'Graus Celsius (ºC)'},
          hAxis: {title: 'dia do ano'},
          trendlines: {
      0: {
        type: 'polynomial',
        degree: 18,
        color: 'red',
        visibleInLegend: false,
      }
    }
});
Map.centerObject(geometry, 6);
panel.widgets().set(2, Grafico5).set(3, Grafico4).set(4, Grafico3).set(5, panel2);
});
// Add the panel to the ui.root.
ui.root.add(panel);
Map.setCenter(-54, -26.4, 4);