var table = ui.import && ui.import("table", "table", {
      "id": "users/gustavoirgang/J_Talhoes"
    }) || ee.FeatureCollection("users/gustavoirgang/J_Talhoes"),
    aoi = ui.import && ui.import("aoi", "table", {
      "id": "users/gustavoirgang/J_Talhoes"
    }) || ee.FeatureCollection("users/gustavoirgang/J_Talhoes"),
    table2 = ui.import && ui.import("table2", "table", {
      "id": "users/gustavoirgang/JMM_SETORES"
    }) || ee.FeatureCollection("users/gustavoirgang/JMM_SETORES");
//var geom = ee.Geometry.Point(102.61270444371178,12.220111410685075).buffer(100) ; // you can change buffer to pixles
var aoi = ee.FeatureCollection(table2); // add here shapefile
// The layout is vertical flow by default.
var panel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {width: '65%', height: '100%'}})
    .add(ui.Label('Clique na data no seletor de tempo do mapa para ver a imagem do período')); 
 // CARREGAR ASSETS E FILTRAR A PARTIR DOS METADADOS
var talhoes = table2.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-01-P01-V1'),
ee.Filter.eq('Valvula','L-01-P01-V2'),
ee.Filter.eq('Valvula','L-01-P02-V1'),
ee.Filter.eq('Valvula','L-01-P02-V2'),
ee.Filter.eq('Valvula','L-01-P02-V3'),
ee.Filter.eq('Valvula','L-01-P02-V4'),
ee.Filter.eq('Valvula','L-01-P02-V5'),
ee.Filter.eq('Valvula','L-02-P03-A-V1'),
ee.Filter.eq('Valvula','L-02-P03-A-V2'),
ee.Filter.eq('Valvula','L-02-P03-A-V3'),
ee.Filter.eq('Valvula','L-02-P03-A-V4'),
ee.Filter.eq('Valvula','L-02-P03-B-V5'),
ee.Filter.eq('Valvula','L-02-P03-B-V6'),
ee.Filter.eq('Valvula','L-02-P04-AV1'),
ee.Filter.eq('Valvula','L-02-P04-AV2'),
ee.Filter.eq('Valvula','L-02-P04-AV3'),
ee.Filter.eq('Valvula','L-02-P04-AV4'),
ee.Filter.eq('Valvula','L-02-P04-BV5'),
ee.Filter.eq('Valvula','L-02-P04-BV6'),
ee.Filter.eq('Valvula','L-03-P05-V1'),
ee.Filter.eq('Valvula','L-03-P05-V2'),
ee.Filter.eq('Valvula','L-03-P05-V3'),
ee.Filter.eq('Valvula','L-03-P05-V4'),
ee.Filter.eq('Valvula','L-03-P05-V5'),
ee.Filter.eq('Valvula','L-04-P06-V1'),
ee.Filter.eq('Valvula','L-04-P06-V2'),
ee.Filter.eq('Valvula','L-05-P07-V1'),
ee.Filter.eq('Valvula','L-05-P07-V2'),
ee.Filter.eq('Valvula','L-05-P07-V3'),
ee.Filter.eq('Valvula','L-05-P07-V4'),
ee.Filter.eq('Valvula','L-05-P07-V5'),
ee.Filter.eq('Valvula','L-06-P08-V1'),
ee.Filter.eq('Valvula','L-06-P08-V2'),
ee.Filter.eq('Valvula','L-06-P08-V3'),
ee.Filter.eq('Valvula','L-06-P08-V4'),
ee.Filter.eq('Valvula','L-06-P08-V5'),
ee.Filter.eq('Valvula','L-07-P09-V1'),
ee.Filter.eq('Valvula','L-08-P10A-V1'),
ee.Filter.eq('Valvula','L-08-P10A-V2'),
ee.Filter.eq('Valvula','L-08-P10A-V3'),
ee.Filter.eq('Valvula','L-08-P10B-V4'),
ee.Filter.eq('Valvula','L-08-P10B-V5'),
ee.Filter.eq('Valvula','L-539-Q1-V1'),
ee.Filter.eq('Valvula','L-539-Q1-V2'),
ee.Filter.eq('Valvula','L-539-Q1-V3'),
ee.Filter.eq('Valvula','L-539-Q1-V4'),
ee.Filter.eq('Valvula','L-539-Q2-V1'),
ee.Filter.eq('Valvula','L-539-Q2-V2'),
ee.Filter.eq('Valvula','L-539-Q2-V3'),
ee.Filter.eq('Valvula','L-539-Q2-V4'),
ee.Filter.eq('Valvula','L-539-Q2-V5'),
ee.Filter.eq('Valvula','L-539-Q3-AV1'),
ee.Filter.eq('Valvula','L-539-Q3-AV2'),
ee.Filter.eq('Valvula','L-539-Q3-AV3'),
ee.Filter.eq('Valvula','L-539-Q3-AV4'),
ee.Filter.eq('Valvula','L-539-Q3-AV5'),
ee.Filter.eq('Valvula','L-539-Q4-V1'),
ee.Filter.eq('Valvula','L-539-Q4-V2'),
ee.Filter.eq('Valvula','L-539-Q4-V3'),
ee.Filter.eq('Valvula','L-539-Q4-V4'),
ee.Filter.eq('Valvula','L-539-Q4-V5'),
ee.Filter.eq('Valvula','L-539-Q5-V1'),
ee.Filter.eq('Valvula','L-539-Q5-V2'),
ee.Filter.eq('Valvula','L-539-Q5-V3'),
ee.Filter.eq('Valvula','L-539-Q5-V4'),
ee.Filter.eq('Valvula','L-539-Q5-V5')
));
// Function to calculate and add an NDVI band
var addNDVI = function(image) {
return image.addBands(image.normalizedDifference(['B8', 'B4']));
};
var collection = ee.ImageCollection('COPERNICUS/S2')
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',  75))
    .filterDate(ee.Date(Date.now()).advance(-365,'day'), ee.Date(Date.now()).advance(0,'day'))
.map(addNDVI)
function maskcloud2(image) {
  var qa = image.select('QA60')
  // 60-meter quality band out of the Sentinel-2 image. 
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0))
  // Return the masked and scaled data, without the QA bands.
  return image.updateMask(mask).divide(10000)
      .select("B.*")
      .copyProperties(image, ["system:time_start"])
}
// Apply 2nd cloud-masking to image collection
var ndvi2 = collection.map(maskcloud2);
var start = ee.Date(Date.now()).advance(-365,'day')
var now = Date.now();
var end = ee.Date(now).format();
// Create and print a histogram chart
var ndvi = collection.map(addNDVI).select('nd')
var talhoesA1 = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-01-P01-V1'),
ee.Filter.eq('Valvula','L-01-P01-V2'),
ee.Filter.eq('Valvula','L-01-P02-V1'),
ee.Filter.eq('Valvula','L-01-P02-V2'),
ee.Filter.eq('Valvula','L-01-P02-V3'),
ee.Filter.eq('Valvula','L-01-P02-V4'),
ee.Filter.eq('Valvula','L-01-P02-V5'),
ee.Filter.eq('Valvula','L-02-P03-A-V1'),
ee.Filter.eq('Valvula','L-02-P03-A-V2'),
ee.Filter.eq('Valvula','L-02-P03-A-V3'),
ee.Filter.eq('Valvula','L-02-P03-A-V4'),
ee.Filter.eq('Valvula','L-02-P03-B-V5'),
ee.Filter.eq('Valvula','L-02-P03-B-V6'),
ee.Filter.eq('Valvula','L-02-P04-AV1'),
ee.Filter.eq('Valvula','L-02-P04-AV2'),
ee.Filter.eq('Valvula','L-02-P04-AV3'),
ee.Filter.eq('Valvula','L-02-P04-AV4'),
ee.Filter.eq('Valvula','L-02-P04-BV5'),
ee.Filter.eq('Valvula','L-02-P04-BV6'),
ee.Filter.eq('Valvula','L-03-P05-V1'),
ee.Filter.eq('Valvula','L-03-P05-V2'),
ee.Filter.eq('Valvula','L-03-P05-V3'),
ee.Filter.eq('Valvula','L-03-P05-V4'),
ee.Filter.eq('Valvula','L-03-P05-V5'),
ee.Filter.eq('Valvula','L-04-P06-V1'),
ee.Filter.eq('Valvula','L-04-P06-V2'),
ee.Filter.eq('Valvula','L-05-P07-V1'),
ee.Filter.eq('Valvula','L-05-P07-V2'),
ee.Filter.eq('Valvula','L-05-P07-V3'),
ee.Filter.eq('Valvula','L-05-P07-V4'),
ee.Filter.eq('Valvula','L-05-P07-V5'),
ee.Filter.eq('Valvula','L-06-P08-V1'),
ee.Filter.eq('Valvula','L-06-P08-V2'),
ee.Filter.eq('Valvula','L-06-P08-V3'),
ee.Filter.eq('Valvula','L-06-P08-V4'),
ee.Filter.eq('Valvula','L-06-P08-V5'),
ee.Filter.eq('Valvula','L-07-P09-V1'),
ee.Filter.eq('Valvula','L-08-P10A-V1'),
ee.Filter.eq('Valvula','L-08-P10A-V2'),
ee.Filter.eq('Valvula','L-08-P10A-V3'),
ee.Filter.eq('Valvula','L-08-P10B-V4'),
ee.Filter.eq('Valvula','L-08-P10B-V5'),
ee.Filter.eq('Valvula','L-539-Q1-V1'),
ee.Filter.eq('Valvula','L-539-Q1-V2'),
ee.Filter.eq('Valvula','L-539-Q1-V3'),
ee.Filter.eq('Valvula','L-539-Q1-V4'),
ee.Filter.eq('Valvula','L-539-Q2-V1'),
ee.Filter.eq('Valvula','L-539-Q2-V2'),
ee.Filter.eq('Valvula','L-539-Q2-V3'),
ee.Filter.eq('Valvula','L-539-Q2-V4'),
ee.Filter.eq('Valvula','L-539-Q2-V5'),
ee.Filter.eq('Valvula','L-539-Q3-AV1'),
ee.Filter.eq('Valvula','L-539-Q3-AV2'),
ee.Filter.eq('Valvula','L-539-Q3-AV3'),
ee.Filter.eq('Valvula','L-539-Q3-AV4'),
ee.Filter.eq('Valvula','L-539-Q3-AV5'),
ee.Filter.eq('Valvula','L-539-Q4-V1'),
ee.Filter.eq('Valvula','L-539-Q4-V2'),
ee.Filter.eq('Valvula','L-539-Q4-V3'),
ee.Filter.eq('Valvula','L-539-Q4-V4'),
ee.Filter.eq('Valvula','L-539-Q4-V5'),
ee.Filter.eq('Valvula','L-539-Q5-V1'),
ee.Filter.eq('Valvula','L-539-Q5-V2'),
ee.Filter.eq('Valvula','L-539-Q5-V3'),
ee.Filter.eq('Valvula','L-539-Q5-V4'),
ee.Filter.eq('Valvula','L-539-Q5-V5')
));
var titleA1 = {
  title: 'Total NDVI diário todas as Válvulas',
  hAxis: {title: 'Dia'},
  vAxis: {title: 'NDVI'},
};
var chartA1 = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesA1,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleA1)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartA1);
var titlez = {
  title: 'Total NDVI diário média de todas as Válvulas',
  hAxis: {title: 'Dia'},
  vAxis: {title: 'NDVI'},
};
var chartz = ui.Chart.image.series(ndvi, talhoes, ee.Reducer.mean(), 10, 'system:time_start')
.setOptions(titlez)
panel.add(chartz);
// CRIAR UM GRÁFICO A PARTIR DOS DADOS ANUAIS DE NDVI
// USANDO ÁREA DE INTERESSE E UM REDUTOR PARA CALCULAR A NDVI MÉDIA NA ÁREA.
// CARREGAR ASSETS E FILTRAR A PARTIR DOS METADADOS
var talhoesA = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-01-P01-V1'),
ee.Filter.eq('Valvula','L-01-P01-V2')
));
var titleA = {
  title: 'Total NDVI anual Válvulas:L-01-P01',
  hAxis: {title: 'Ano'},
  vAxis: {title: 'NDVI'},
};
var chartA = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesA,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleA)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartA);
var talhoesB = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-01-P02-V1'),
ee.Filter.eq('Valvula','L-01-P02-V2'),
ee.Filter.eq('Valvula','L-01-P02-V3'),
ee.Filter.eq('Valvula','L-01-P02-V4'),
ee.Filter.eq('Valvula','L-01-P02-V5')
));
var titleB = {
  title: 'Total NDVI anual Válvulas:L-01-P02',
  hAxis: {title: 'Ano'},
  vAxis: {title: 'NDVI'},
};
var chartB = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesB,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleB)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartB);
var talhoesC = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-02-P03-A-V1'),
ee.Filter.eq('Valvula','L-02-P03-A-V2'),
ee.Filter.eq('Valvula','L-02-P03-A-V3'),
ee.Filter.eq('Valvula','L-02-P03-A-V4'),
ee.Filter.eq('Valvula','L-02-P03-B-V5'),
ee.Filter.eq('Valvula','L-02-P03-B-V6')
));
var titleC = {
  title: 'Total NDVI Válvulas: L-02-P03',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartC = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesC,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleC)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartC);
var talhoesD = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-02-P04-AV1'),
ee.Filter.eq('Valvula','L-02-P04-AV2'),
ee.Filter.eq('Valvula','L-02-P04-AV3'),
ee.Filter.eq('Valvula','L-02-P04-AV4'),
ee.Filter.eq('Valvula','L-02-P04-BV5'),
ee.Filter.eq('Valvula','L-02-P04-BV6')
));
var titleD = {
  title: 'Total NDVI Válvulas: L-02-P04',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartD = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesD,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleD)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartD);
var talhoesE = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-03-P05-V1'),
ee.Filter.eq('Valvula','L-03-P05-V2'),
ee.Filter.eq('Valvula','L-03-P05-V3'),
ee.Filter.eq('Valvula','L-03-P05-V4'),
ee.Filter.eq('Valvula','L-03-P05-V5')
));
var titleE = {
  title: 'Total NDVI Válvulas: L-03-P05',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartE = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesE,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleE)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartE);
var talhoesF = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-04-P06-V1'),
ee.Filter.eq('Valvula','L-04-P06-V2')
));
var titleF = {
  title: 'Total NDVI Válvulas: L-04-P06',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartF = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesF,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleF)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartF);
var talhoesG = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-05-P07-V1'),
ee.Filter.eq('Valvula','L-05-P07-V2'),
ee.Filter.eq('Valvula','L-05-P07-V3'),
ee.Filter.eq('Valvula','L-05-P07-V4'),
ee.Filter.eq('Valvula','L-05-P07-V5')
));
var titleG = {
  title: 'Total NDVI Válvulas: L-05-P07',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartG = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesG,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleG)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartG);
var talhoesH = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-06-P08-V1'),
ee.Filter.eq('Valvula','L-06-P08-V2'),
ee.Filter.eq('Valvula','L-06-P08-V3'),
ee.Filter.eq('Valvula','L-06-P08-V4'),
ee.Filter.eq('Valvula','L-06-P08-V5'),
ee.Filter.eq('Valvula','L-07-P09-V1')
));
var titleH = {
  title: 'Total NDVI Válvulas: L-06-P08 e L-07-P09',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartH = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesH,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleH)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartH);
var talhoesI = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-08-P10A-V1'),
ee.Filter.eq('Valvula','L-08-P10A-V2'),
ee.Filter.eq('Valvula','L-08-P10A-V3'),
ee.Filter.eq('Valvula','L-08-P10B-V4'),
ee.Filter.eq('Valvula','L-08-P10B-V5')
));
var titleI = {
  title: 'Total NDVI Válvulas: L-08-P10A e L-08-P10B',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartI = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesI,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleI)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartI);
var talhoesK = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-539-Q1-V1'),
ee.Filter.eq('Valvula','L-539-Q1-V2'),
ee.Filter.eq('Valvula','L-539-Q1-V3'),
ee.Filter.eq('Valvula','L-539-Q1-V4')
));
var titleK = {
  title: 'Total NDVI Válvulas: L-539-Q1',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartK = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesK,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleK)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartK);
var talhoesL = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-539-Q2-V1'),
ee.Filter.eq('Valvula','L-539-Q2-V2'),
ee.Filter.eq('Valvula','L-539-Q2-V3'),
ee.Filter.eq('Valvula','L-539-Q2-V4')
));
var titleL = {
  title: 'Total NDVI Válvulas: L-539-Q2',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartL = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesL,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleL)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartL);
var talhoesM = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-539-Q3-AV1'),
ee.Filter.eq('Valvula','L-539-Q3-AV2'),
ee.Filter.eq('Valvula','L-539-Q3-AV3'),
ee.Filter.eq('Valvula','L-539-Q3-BV4'),
ee.Filter.eq('Valvula','L-539-Q3-BV5')
));
var titleM = {
  title: 'Total NDVI Válvulas: L-539-Q3',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartM = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesM,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleM)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartM);
var talhoesO = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-539-Q4-V1'),
ee.Filter.eq('Valvula','L-539-Q4-V2'),
ee.Filter.eq('Valvula','L-539-Q4-V3'),
ee.Filter.eq('Valvula','L-539-Q4-V4')
));
var titleO = {
  title: 'Total NDVI Válvulas: L-539-Q4',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartO = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesO,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleO)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartO);
var talhoesP = aoi.filter(ee.Filter.or(
ee.Filter.eq('Valvula','L-539-Q5-V1'),
ee.Filter.eq('Valvula','L-539-Q5-V2'),
ee.Filter.eq('Valvula','L-539-Q5-V3'),
ee.Filter.eq('Valvula','L-539-Q5-V4')
));
var titleP = {
  title: 'Total NDVI Válvulas: L-539-Q5',
  hAxis: {title: 'dia'},
  vAxis: {title: 'NDVI'},
};
var chartP = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoesP,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 10,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(titleP)
  .setChartType('LineChart');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chartP);
var title = {
  title: 'Total NDVI anual Todas as Válvulas',
  hAxis: {title: 'Ano'},
  vAxis: {title: 'NDVI'},
};
var chart = ui.Chart.image.seriesByRegion({
  imageCollection: ndvi, 
  regions: talhoes,
  reducer: ee.Reducer.mean(),
  band: 'nd',
  scale: 1000,
  xProperty: 'system:time_start',
  seriesProperty: 'Valvula'
}).setOptions(title)
  .setChartType('Table');
 //GRÁFICO DE PRECIPITAÇÃO MÉDIA AO MAPA
panel.add(chart);
// Run this function on a change of the dateSlider.
var showMosaic = function(range) {
var collection = ee.ImageCollection('COPERNICUS/S2')
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 150))
    .filterDate(ee.Date(Date.now()).advance(-365,'day'), ee.Date(Date.now()))
    .filterDate(range.start(), range.end())
.map(addNDVI)
function maskcloud2(image) {
  var qa = image.select('QA60')
  // 60-meter quality band out of the Sentinel-2 image. 
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0))
  // Return the masked and scaled data, without the QA bands.
  return image.updateMask(mask).divide(10000).clip(aoi)
      .select("B.*")
      .copyProperties(image, ["system:time_start"])
}
// Apply 2nd cloud-masking to image collection
var ndvi2 = collection.map(maskcloud2);
var start = ee.Image(ndvi2.first()).date().get('year').format();
var now = Date.now();
var end = ee.Date(now).format();
// Create and print a histogram chart
var ndvi = ndvi2.map(addNDVI).select('nd')
// Display results in map window
range.start().get('month').evaluate(function(name) {
   var vhVizParam2 = {"opacity":1,"bands":['nd'],palette: ['FFFFFF','CC9966','CC9900', '996600', '33CC00', '009900','006600','000000'],"min": 0 ,"max": 1}
//Map.addLayer(ws1, precipvis2,  name + "Velociade Corrente");
 var layer3 = ui.Map.Layer(ndvi, vhVizParam2,  name + " Índice de NDVI m²");
Map.layers().set(1, layer3)
});
range.start().get('month').evaluate(function(name) {
 var visParams = {bands: ['B4', 'B3', 'B2'], max: 1900};
    var layer = ui.Map.Layer(collection, visParams, name + ' composite');
    Map.layers().set(0, layer);
});
var text = require('users/gena/packages:text')
// scale text font relative to the current map scale
var scale = Map.getScale() * 0.3
var labels = table2.map(function(feat) {
  feat = ee.Feature(feat)
  var name = ee.String(feat.get("Valvula"))
  var centroid = feat.geometry().centroid()
  var t = text.draw(name, centroid, scale, {
    fontSize:18, 
    textColor:'red',
    outlineWidth: 1,
    outlineColor: 'black'
  })
  return t
})
labels = ee.ImageCollection(labels)
Map.addLayer(labels)
ui.root.add(panel);
Map.centerObject(table2, 14);
};
// Asynchronously compute the date range and show the slider.
var dateRange = ee.DateRange(start, end).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: 5,
    onChange: showMosaic,
    style: {
    position: 'bottom-center',
    padding: '7px'
  }
  });
 Map.add(dateSlider.setValue( now)); //.setValue(now));
// Add the panel to the map.
});