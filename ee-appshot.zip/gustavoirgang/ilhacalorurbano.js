var dataset = ee.ImageCollection("YALE/YCEO/UHI/Summer_UHI_yearly_pixel/v4").mean();
var visualization = {
  bands: ['Daytime'],
  min: -1.5,
  max: 7.5,
  palette: [
    "#313695","#74add1","#fed976","#feb24c","#fd8d3c","#fc4e2a",
    "#e31a1c","#b10026",
  ]
};
Map.setOptions('SATELLITE');
  Map.addLayer(dataset, visualization, "Daytime UHI");
// #############################################################################
// ### MAP LEGEND ###
// #############################################################################
// Create a panel to hold title, intro text, chart and legend components.
var panel = ui.Panel({style: {width: '300px', position: 'bottom-left'}});
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: 'Surface urban heat island intensity\nSummertime, daytime °C',
    style: {fontSize: '15px', fontWeight: 'bold', whiteSpace: 'pre'}
  })
]);
panel.add(intro);
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
/*
 * Legend setup
 */
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(visualization.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(visualization.min, {margin: '4px 8px'}),
    ui.Label(visualization.max, {margin: '4px 8px', textAlign: 'right', stretch: 'horizontal'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendPanel = ui.Panel([colorBar, legendLabels], null, {margin: '-14px 0px 0px 0px'});
panel.widgets().set(3, legendPanel);
Map.setCenter(-51.18757714642867,-29.92251787236288, 10);
Map.add(panel);