// Import DEM
var collection = 'WWF/HydroSHEDS/03VFDEM';
var band = 'b1';
var dataset = ee.Image(collection).select(band);
var elevationVis = {
  min: -50.0,
  max: 3000.0,
  gamma: 2.0,
};
// create point geometry (will call an asset in the real script)
var point = ee.Geometry.Point([-61.334, 15.416]);
Map.setCenter(-61.334, 15.416, 10);
Map.addLayer(dataset, elevationVis, collection);
Map.addLayer(point, {}, "acou");
// example from Google Map API
// should be placed earlier in the script but causes GEE to stop runing
var contentString = '<div id="content">'+
            '<p><b>Hello</b>'+
            '</div>';
var infowindow = new google.maps.InfoWindow({
          content: contentString
        });
var marker = new google.maps.Marker({
          position: point,
          map: map,
          title: 'Uluru (Ayers Rock)' });
        marker.addListener('click', function() {
          infowindow.open(map, marker);
        });