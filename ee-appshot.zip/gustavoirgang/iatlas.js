var image = ee.Image("users/gustavoirgang/BR_vegetacao"),
    image2 = ee.Image("USGS/SRTMGL1_003");
// Interactive exploration of population and elevation.
// Allows filtering based on constraints and a popup info window.
// Set up the overall structure of the app, with a control panel to the left
// of a full-screen map.//
ui.root.clear();
var panel = ui.Panel({style: {width: '250px'}});
var legend = ui.Panel({style: {
    position: 'bottom-right',
    padding: '8px 15px',
    shown: true
  }});
var map = ui.Map();
ui.root.add(panel).add(map).add(legend);
map.setCenter(-49, -18, 4);
map.style().set('cursor', 'crosshair');
Map.setCenter;
// Define some constants.
var POPULATION = 'População';
var ELEVATION = 'Atitudes';
var SLOPE = 'Declividades';
var VEG = 'Vegetacão';
var GREATER_THAN = 'Maior que';
var LESS_THAN = 'Menor que';
var EQUALS = 'Igual';
//  Palette with the colors
var palette =['00cc00', '086a10', 'ff4dff', '800080', 'e60000', '3333ff', '54a708', 'ff00bf', 'ffccf2', 'dcd159', 'dade48', 'fbff13', 'c6b044', 'ff4dff', '27ff87', 'cccc00', '1affa3', '78d203', 'ffffe6', '80ffe5', '4dff4d', '9494b8', '004d4d', 'e6e600', 'b6ff05', '666600', 'ffff00', 'ccff99'];
var palettes =['00cc00', '006600', 'ff4dff', '800080', 'e60000', '00ccff', '54a708', 'ff00bf', 'ffccf2', 'dcd159', 'dade48', 'fbff13', 'c6b044', 'ff4dff', '27ff87', 'cccc00', '1affa3', '78d203', 'ffffe6', '80ffe5', '4dff4d', '9494b8', '004d4d', 'e6e600', 'b6ff05', '666600', 'ffff00', 'ccff99'];
var POPULATION_STYLE = {
  min: 0,
  max: 1,
  palette: ['ffffff', '990033', '000000']};
var POPULATION_VIS_MAX_VALUE = 1200;
var POPULATION_VIS_NONLINEARITY = 4;
var COUNTRIES_STYLE = {color: '26458d', fillColor: '00000000'};
var HIGHLIGHT_STYLE = {color: '8856a7', fillColor: '8856a7C0'};
var table = ee.FeatureCollection("users/gustavoirgang/BRPais");
// Apply a non-linear stretch to the population data for visualization.
function colorStretch(image) {
  return image.divide(POPULATION_VIS_MAX_VALUE)
      .pow(1 / POPULATION_VIS_NONLINEARITY);
}
// Inverts the nonlinear stretch we apply to the population data for
// visualization, so that we can back out values to display in the legend.
// This uses ordinary JavaScript math functions, rather than Earth Engine
// functions, since we're going to call it from JS to compute label values.
function undoColorStretch(val) {
  return Math.pow(val, POPULATION_VIS_NONLINEARITY) * POPULATION_VIS_MAX_VALUE;
}
// Configure our map with a minimal set of controls.
Map.setControlVisibility(false); 
// Create an empty list of filter constraints.
var constraints = [];
// Load the WorldPop 2015 UN-adjusted population density estimates.//
// (Note that these are only available for some countries, e.g. not the US.)//
var pop = ee.ImageCollection('WorldPop/POP')
  .filter(ee.Filter.equals('year', 2015))
  .filter(ee.Filter.equals('UNadj', 'yes'))
  .mosaic();
var popVis = pop.where(pop.gt(0), pop.log())
  .visualize({min:0, max:6, palette: ['ffffff', '990033', '000000']});
// Load SRTM 30m elevation and compute local terrain slope.
var elevation = ee.Image('USGS/SRTMGL1_003');
var elevationVis = elevation.visualize({min: 0, max: 1400, palette: ['33cccc', '006600', 'ffff00', 'cccc00', '993300', '330000', '663300', '9999cc', 'ffffff']});
var slope = ee.Terrain.slope(elevation);
var slopeVis = slope.visualize({min: 0, max: 10, palette: ['009900', 'ffffff', ' ffff33',  '990033', '330000']});
var veg = ee.Image('users/gustavoirgang/BR_vegetacao');
var vegVis = veg.visualize({min: 1, max: 27, palette:palette}).clip(table);
// Create a layer selector that dictates which layer is visible on the map.
var select = ui.Select({
  items: [VEG, POPULATION, ELEVATION, SLOPE],
  value: VEG,
  onChange: redraw,
});
panel.add(ui.Label('Seletor de Tema:')).add(select);
// Check-boxes to control which layers are shown in the inspector.
panel.add(ui.Label('Click para consultar valores:'));
var popCheck = ui.Checkbox(POPULATION).setValue(true);
panel.add(popCheck);
var elevationCheck = ui.Checkbox(ELEVATION).setValue(true);
panel.add(elevationCheck);
var slopeCheck = ui.Checkbox(SLOPE).setValue(false);
panel.add(slopeCheck);
var vegCheck = ui.Checkbox(VEG).setValue(true);
panel.add(vegCheck);
// Create the inspector panel, initially hiding it.
var inspector = ui.Panel({style: {shown: false}});
panel.add(inspector);
// Register an onClick handler that populates and shows the inspector panel.
map.onClick(function(coords) {
  // Gather the image bands into a single Image that we can asynchronously sample.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  // Add a red dot to the map where the user clicked.
 var location = 'lon: ' + coords.lon.toFixed(2) + ' ' +
                 'lat: ' + coords.lat.toFixed(2);
 panel1.widgets().set(1, ui.Label(location));
  Map.layers().set(1, ui.Map.Layer(point, {color: 'FF0000'}));
//print (point)
  var sample = ee.Image.cat(veg, pop, elevation, slope )
      .unmask(0).sample(point, 10).first().toDictionary();
  sample.evaluate(function(values) {
    inspector.clear();
    // Display a label that corresponds to a checked checkbox.
    if (popCheck.getValue()) {
      inspector.add(ui.Label('Population: ' + values.population + ' people/cell'));
    }
    if (elevationCheck.getValue()) {
      inspector.add(ui.Label('Elevation: ' + values.elevation + ' meters'));
    }
    if (slopeCheck.getValue()) {
      inspector.add(ui.Label('Slope: ' + values.slope + ' degrees'));
    }
    if (vegCheck.getValue()) {
      inspector.add(ui.Label('Veg: ' + values.veg + ' m2'));
    }
    inspector.add(ui.Button('Fecha', function() {
      inspector.style().set({shown: false});
    }));
    inspector.style().set({shown: true});
  });
});
var panel1 = ui.Panel({style: {shown: true}});
panel.add(panel1);
// Add a label and select to enable adding a new filter.
panel.add(ui.Label('Filtro por valores:'));
var constraint = ui.Select({
  items: [POPULATION, ELEVATION, SLOPE, VEG],
  placeholder: '[Escolha variavel...]',
  onChange: selectConstraint,
});
panel.add(constraint);
// Create a function that configures a new constraint.
function addConstraint(name, image, defaultValue) {
  panel1.add(ui.Label('Filtrar por ' + name + ':'));
  panel1.add(ui.Button('Fecha', function() {
      panel1.style().set({shown: false});
    }));
    panel1.style().set({shown: true});
  var subpanel = ui.Panel({layout: ui.Panel.Layout.flow('horizontal')});
  // Create a greater-than / less-than selector.
  var mode = ui.Select({
    items: [GREATER_THAN, LESS_THAN, EQUALS],
    value: GREATER_THAN,
    onChange: redraw,
  });
  subpanel.add(mode);
  // Create a textbox for the filter threshold.
  var input = ui.Textbox({
    value: defaultValue,
    style: {width: '100px'},
    onChange: redraw,
  });
  subpanel.add(input);
  panel1.add(subpanel);
  // Add this constraint to the global list so we can access the
  // constraints from the redraw() function in the future.
  constraints.push({
    image: image,
    mode: mode,
    value: input,
  });
  redraw();
}
// Create a function that adds a constraint of the requested type.
function selectConstraint(name) {
  if (name == POPULATION) {
    addConstraint(name, pop, 50);
  } else if (name == ELEVATION) {
    addConstraint(name, elevation, 100);
  } else if (name == SLOPE) {
    addConstraint(name, slope, 3);
  } else if (name == VEG) {
    addConstraint(name, veg, 2);  
  }
}
// Create a function to render a map layer configured by the user inputs.
function redraw() {
  map.layers().reset();
  var layer = select.getValue();
  var image;
  if (layer == ELEVATION) {
    image = elevationVis;
  } else if (layer == SLOPE) {
    image = slopeVis;
  } else if (layer == POPULATION) {
    image = popVis;
  } else if (layer == VEG) {
    image = vegVis;  
  }
  for (var i = 0; i < constraints.length; ++i) {
    var constraint = constraints[i];
    var mode = constraint.mode.getValue();
    var value = parseFloat(constraint.value.getValue());
    if (mode == GREATER_THAN) {
      image = image.updateMask(constraint.image.gt(value));
    } else {
      image = image.updateMask(constraint.image.lt(value));
    }
  }
  map.addLayer(image, {}, layer);
 var image2 = image;
var image3 = ee.Image(1).mask(image2.select(1).gte(0.3));
Map.addLayer(image3);
var legendarea = ui.Panel([ui.Label('Click para valores')]);
//Maneira correta de calcular áreas
var area_pxa = image3.multiply(ee.Image.pixelArea()) 
                    .reduceRegion(ee.Reducer.sum(),table,1000,null,null,false,1e13)
                    .get('constant')
                    print ('Área usando o ee.Image.pixelArea', ee.Number(area_pxa).divide(1e6))
  var area_pxa2 =  ee.Number(area_pxa).divide(1e6)
  // Request the value from the server.
  area_pxa2.evaluate(function(result) {
    // When the server returns the value, show it.
    legendarea.widgets().set(0, ui.Label({
      value: 'Area selecionada km2: ' + result.toFixed(2),
    }));
   legendarea.add(ui.Button('Fecha', function() {
      legendarea.style().set({shown: false});
    }));
    legendarea.style().set({shown: true});  
});
// Create are title
//var legendarea2 = ee.Number(area_pxa).divide(1e4);
//var area_pxa2 =  ee.String(legendarea2);
//var legendarea = ui.Label('Área: ' + print(legendarea2) + ' hectares')
//print  ( area_pxa2)
//;
// Add the title to the panel
panel.add(legendarea);  
// Create legend title
var legendTitle = ui.Label({
  value: ('Vegetação Natural'),
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
 legend.clear();
// Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette =['00cc00', '086a10', 'ff4dff', '800080', 'e60000', '3333ff', '54a708', 'ff00bf', 'ffccf2', 'dcd159', 'dade48', 'fbff13', 'c6b044', 'ff4dff', '27ff87', 'cccc00', '1affa3', '78d203', 'ffffe6', '80ffe5', '4dff4d', '9494b8', '004d4d', 'e6e600', 'b6ff05', '666600', 'ffff00', 'ccff99'];
// name of the legend
var names = ['Floresta Ombrófila Aberta' , 'Floresta Ombrófila Densa', 'Campinarana Arborizada', 'Campinarana Florestada', 'Refúgio Vegetacional', 'Água', 'Floresta Estacional Semidecidual', 'Campinarana Arbustiva', 'Campinarana Gramíneo-Lenhosa', 'Savana Arborizada', 'Savana Parque', 'Savana Gramíneo-Lenhosa', 'Savana Florestada', 'Campinarana', 'Formação Pioneira Fluviolacustre', 'Savana Estépica', 'Formação Pioneira Fluviomarinha', 'Floresta Estacional Decidual', 'Dunas', 'Formação Pioneira Marinha', 'Formações Pioneiras', 'Afloramento Rochoso', 'Floresta Ombrófila Mista', 'Estepe Gramíneo-Lenhosa', 'Estepe', 'Estepe Florestada', 'Estepe Arborizada', 'Estepe Parque'];
var numes = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27];  
// Add color and and names
//legend.clear();
for (var i = 0; i < 28; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
 /*
 * The legend panel in the bottom-left
 */
// A color bar widget. Makes a horizontal color bar to display the given
// color palette.
function ColorBar(palette) {
  return ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 1, 0.1],
      dimensions: '100x10',
      format: 'png',
      min: 0,
      max: 1,
      palette: palette,
      onChange: redraw,
    },
    style: {stretch: 'horizontal', margin: '0px 8px'},
  });
}
// Returns our labeled legend, with a color bar and three labels representing
// the minimum, middle, and maximum values.
function makeLegend() {
  var labelPanel = ui.Panel(
      [
        ui.Label(Math.round(undoColorStretch(0)), {margin: '4px 8px'}),
        ui.Label(
            Math.round(undoColorStretch(0.5)),
            {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
        ui.Label(Math.round(undoColorStretch(1)), {margin: '4px 8px'})
      ],
      ui.Panel.Layout.flow('horizontal'));
  return ui.Panel([ColorBar(POPULATION_STYLE.palette), labelPanel]);
}
// Styling for the legend title.
var LEGEND_TITLE_STYLE = {
  fontSize: '20px',
  fontWeight: 'bold',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '4px',
};
// Styling for the legend footnotes.
var LEGEND_FOOTNOTE_STYLE = {
  fontSize: '10px',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '4px',
};
// Assemble the legend panel.
legend.add(ui.Panel(
    [
      ui.Label('Densidade Populacional', LEGEND_TITLE_STYLE), makeLegend(),
      ui.Label(
          '(milhares de pessoas por km2)', LEGEND_FOOTNOTE_STYLE),
      ui.Label(
          'Fonte: Global Human Settlement Layer (JRC)', LEGEND_FOOTNOTE_STYLE),
      ui.Label('modelo de terreno SRTM10', LEGEND_FOOTNOTE_STYLE)
    ],
    ui.Panel.Layout.flow('vertical'),
    {width: '230px', position: 'bottom-left'}));
// add legend to map (alternatively you can also print the legend to the console)
map.add(legend).reset();    
ui.root.clear().remove(legend);
}
//Map.centerObject(image, 8);
//Map.centerObject(inspector, 8);
// Invoke the redraw function once at start up to initialize the map.
redraw();