var poly = ui.import && ui.import("poly", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -80.88909321608385,
                -0.41304134875419624
              ],
              [
                -81.11294703017016,
                -6.76275172829084
              ],
              [
                -74.15436462340783,
                -17.502513736878228
              ],
              [
                -56.15717462881727,
                -16.982358964613724
              ],
              [
                -49.608954111812686,
                -10.885630227165375
              ],
              [
                -45.58775480696268,
                -1.3575501491953659
              ],
              [
                -52.07968202353158,
                6.2424865055540035
              ],
              [
                -62.37021074652731,
                9.20598431272277
              ],
              [
                -72.36140089182844,
                9.056758576258826
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-80.88909321608385, -0.41304134875419624],
          [-81.11294703017016, -6.76275172829084],
          [-74.15436462340783, -17.502513736878228],
          [-56.15717462881727, -16.982358964613724],
          [-49.608954111812686, -10.885630227165375],
          [-45.58775480696268, -1.3575501491953659],
          [-52.07968202353158, 6.2424865055540035],
          [-62.37021074652731, 9.20598431272277],
          [-72.36140089182844, 9.056758576258826]]]);
var sentinel1 = ee.ImageCollection('COPERNICUS/S1_GRD');
var spatialFiltered = sentinel1.filter(ee.Filter.eq('instrumentMode', 'IW')).filterBounds(poly)
                               .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
                               .select('VH');
var image = spatialFiltered.filterDate('2017-08-25', '2021-09-05').mosaic().clip(poly);
print (image);
//Extended Directional Smoothing
function eds(image) {
  // Create a list of weights for a 3x3 kernel.
  var dir1 = [[0, 0, 0], [0.5, 0, 0.5], [0, 0, 0]];
  var dir2 = [[0, 0.5, 0], [0, 0, 0], [0, 0.5, 0]];
  var dir3 = [[0, 0, 0.5], [0, 0, 0], [0.5, 0, 0]];
  var dir4 = [[0.5, 0, 0], [0, 0, 0], [0, 0, 0.5]];
  //Convolve directional kernels with the image
  var d1 = image.convolve(ee.Kernel.fixed(3, 3, dir1, -1, -1));
  var d2 = image.convolve(ee.Kernel.fixed(3, 3, dir2, -1, -1));
  var d3 = image.convolve(ee.Kernel.fixed(3, 3, dir3, -1, -1));
  var d4 = image.convolve(ee.Kernel.fixed(3, 3, dir4, -1, -1));
  //Absolute value of the difference from convolved image with original values
  var D1=(d1.subtract(image)).abs();
  var D2=(d2.subtract(image)).abs();
  var D3=(d3.subtract(image)).abs();
  var D4=(d4.subtract(image)).abs();
  //Pick min pixel value based on abs difference(first input) using reducers
  var Dd=ee.ImageCollection([[D1,d1],[D2,d2],[D3,d3],[D4,d4]]);
  var reducer =ee.Reducer.min(2);
  //Select the second input to the reducer
  var v = Dd.reduce(reducer).select('min1');
  return v;
}
function msd(denoised,original) {
  var diff = denoised.subtract(original);
  var sq= diff.pow(2).toArray();
  var meanDict = diff.reduceRegion({
  reducer: ee.Reducer.mean(),
  geometry: poly,
  scale: 10 ,
  bestEffort:true
  });
  return meanDict;
}
//plane smoothing to remove speckle noise
var smooth = ee.Image(image.focal_median(100, 'circle', 'meters'));
var image_spk = eds(image);
print (image_spk);
Map.centerObject(poly, 10);
Map.addLayer(image,{min:-30,max:30},'sentinel 1 raw', false);
Map.addLayer(smooth,{min:-30,max:30},'sentinel 1 smooth', false);
Map.addLayer(image_spk,{min:-15,max:-12},'sentinel 1 EDS');
var msd1=msd(smooth,image);
print (msd1);
var msd2=msd(image_spk,image);
print (msd2);
var geometry = /* color: #98ff00 */ee.Geometry.Point([-52.29582, 0.20854]);
Map.addLayer(geometry, {palette: '555555'}, 'piramide', 1);
Map.centerObject(geometry, 10);