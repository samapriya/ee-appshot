var dataset = ee.ImageCollection('MODIS/006/MYD09GQ')
                  .filter(ee.Filter.date('2019-07-24', '2019-07-25'));
var falseColorVis = {
  min: -100.0,
  max: 8000.0,
  bands: ['sur_refl_b02'],
};
Map.setCenter(6.746, 46.529, 2);
Map.addLayer(dataset, falseColorVis, 'False Color');