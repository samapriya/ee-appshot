// Nome do Projeto
var Projeto = 'Projeto Nascente do Arvoredo, Agroflorestor: Nicolas Zalavski na Cidade: São Pedro de Alcantara, Estado: SC; Mata Atlântica: Plantio Compensado por: 3 em 1 Alimentos Saudáveis. Cod_C12d005'
// Ano inicio Projeto
var ano_inicio = 2018
// Ano fim Projeto
var ano_fim = 2022
// Data inicio Projeto
var inicio = ano_inicio +'-01-01'
// Data fim Projeto
var fim = ano_fim +'-12-31' 
//Distância do Buffer adicinalidade
var distancia = 30000
//Valor do Dolar
var dolar = 5.00
// valor da tonelada de CO²eq em dolares
var $ton = 10
//Duração do Projeto em anos
var anos = ano_fim - ano_inicio + 1;
var max = anos*2;
//limites da propriedade certificada conforme memorial descritivo SIGEF-INCRA    
var limites = ee.Geometry.MultiPolygon(
        [[[
[	-48.890903010700001	,	-27.578858934700001	],
[	-48.889622908600003	,	-27.578938783400002	],
[	-48.889497813900000	,	-27.581344245800000	],
[	-48.889778790100003	,	-27.581340968799999	],
[	-48.889946945600002	,	-27.581369886600001	],
[	-48.890646365700000	,	-27.581593290000001	],
[	-48.890508342300002	,	-27.582877824699999	],
[	-48.890035130199998	,	-27.582942908300002	],
[	-48.889900605599998	,	-27.583574326200001	],
[	-48.891022596299997	,	-27.583805772400002	],
[	-48.890976149799997	,	-27.584823792600002	],
[	-48.891541699299999	,	-27.584849001900000	],
[	-48.890903010700001	,	-27.578858934700001	]
           ]]]);
 // Buffer da adicionalidade
var poly_outer = limites.buffer(distancia);
var limites1 = poly_outer.difference(limites);
var geometry = /* color: #d63000 */ee.FeatureCollection(
        [ee.Feature(
           limites,
            {
              "nome": "limites",
                         }),
        ee.Feature(
            limites1,
            {
              "nome": "entorno"
            })]);
Map.centerObject(poly_outer,8);
Map.addLayer(limites, {color:'red'}, 'Limites Propiedade', false);
Map.addLayer(geometry, {color:'blue'}, 'poly_outer (blue)', false);
Map.addLayer(limites1, {color:'00660033'}, 'Buffer Propriedade');
//Limites geográficos de áreas de referência fornecidas por MapBiomas
var TI = ee.FeatureCollection('projects/mapbiomas-workspace/AUXILIAR/ESTATISTICAS/COLECAO6/indigenous_land');
//print(TI.limit(5));
Map.addLayer(TI.style({
                color: 'ffff00',
                width: 1,
                fillColor: 'ffff0033',
            }), {}, 'Terras Indígenas', false);
      var TIimage = TI.map(function(feature) {
  return feature.set('n', 0.5)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
//Map.addLayer(TIimage, {min: 0, max: 1}, 'TIimage', false);      
var UCPIF = ee.FeatureCollection('projects/mapbiomas-workspace/AUXILIAR/ESTATISTICAS/COLECAO6/federal_conservation_units_integral_protection');
//print(UCPIF.limit(5));
Map.addLayer(UCPIF.style({
                color: '005500',
                width: 1,
                fillColor: '00550033',
            }), {}, 'UCPIF', false);
   var UCPIFimage = UCPIF.map(function(feature1) {
  return feature1.set('n', 0.25)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
//Map.addLayer(UCPIFimage, {min: 0, max: 1}, 'UCPIFimage', false);               
var UCUSF = ee.FeatureCollection('projects/mapbiomas-workspace/AUXILIAR/ESTATISTICAS/COLECAO6/federal_conservation_units_sustainable_use');
//print(UCUSF.limit(5));
Map.addLayer(UCUSF.style({
                color: '558800',
                width: 1,
                fillColor: '55880033',
            }), {}, 'UCUSF', false);   
     var UCUSFimage = UCUSF.map(function(feature1) {
  return feature1.set('n', 0.15)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
//Map.addLayer(UCUSFimage, {min: 0, max: 1}, 'UCUSFimage', false);           
var UCUSE = ee.FeatureCollection('projects/mapbiomas-workspace/AUXILIAR/ESTATISTICAS/COLECAO6/state_conservation_units_sustainable_use');
//print(UCUSE.limit(5));
Map.addLayer(UCUSE.style({
                color: '88ff00',
                width: 1,
                fillColor: '88ff0033',
            }), {}, 'UCUSE', false);  
       var UCUSEimage = UCUSE.map(function(feature1) {
  return feature1.set('n', 0.15)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
//Map.addLayer(UCUSEimage, {min: 0, max: 1}, 'UCUSEimage', false);              
var UCPIE = ee.FeatureCollection('projects/mapbiomas-workspace/AUXILIAR/ESTATISTICAS/COLECAO6/state_conservation_units_integral_protection');
//print(UCPIF.limit(5));
Map.addLayer(UCPIE.style({
                color: '008800',
                width: 1,
                fillColor: '00880033',
            }), {}, 'UCPIE', false);    
         var UCPIEimage = UCPIE.map(function(feature1) {
  return feature1.set('n', 0.25)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
//Map.addLayer(UCPIEimage, {min: 0, max: 1}, 'UCPIEimage', false);           
var Quilombos = ee.FeatureCollection('projects/mapbiomas-workspace/AUXILIAR/ESTATISTICAS/COLECAO6/quilombo');
//print(Quilombos.limit(5));
Map.addLayer(Quilombos.style({
                color: '880055',
                width: 1,
                fillColor: '88005533',
            }), {}, 'Quilombos', false);
           var Quilombosimage = Quilombos.map(function(feature1) {
  return feature1.set('n', 0.20)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
//Map.addLayer(Quilombosimage, {min: 0, max: 1}, 'Quilombosimage', false);           
var Semiarido = ee.FeatureCollection('projects/mapbiomas-workspace/AUXILIAR/ESTATISTICAS/COLECAO6/semiarid');
//print(Semiarido.limit(5));
Map.addLayer(Semiarido.style({
                color: '880000',
                width: 1,
                fillColor: '88000033',
            }), {}, 'Semiárido', false);   
  var Semiaridoimage = Semiarido.map(function(feature1) {
  return feature1.set('n', 0.15)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
///Map.addLayer(Semiaridoimage, {min: 0, max: 1}, 'Semiaridoimage', false);  
var Mata_Atlantica = ee.FeatureCollection('projects/mapbiomas-workspace/AUXILIAR/ESTATISTICAS/COLECAO6/atlantic_forest_law');
//print(Mata_Atlantica.limit(5));
Map.addLayer(Mata_Atlantica.style({
                color: '555555',
                width: 1,
                fillColor: '55555533',
            }), {}, 'Lei da Mata Atlântica', false);     
   var Mata_Atlanticaimage = Mata_Atlantica.map(function(feature1) {
  return feature1.set('n', 0.15)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
//Map.addLayer(Mata_Atlanticaimage, {min: 0, max: 1}, 'Mata_Atlanticaimage', false);  
var Biosfera = ee.FeatureCollection('projects/mapbiomas-workspace/AUXILIAR/ESTATISTICAS/COLECAO6/biosphere_reserve');
//print(Biosfera.limit(5));
Map.addLayer(Biosfera.style({
                color: '885500',
                width: 1,
                fillColor: '88550033',
            }), {}, 'Reservas da Biosfera', false);              
  var Biosferaimage = Biosfera.map(function(feature1) {
  return feature1.set('n', 0.10)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
//Map.addLayer(Biosferaimage, {min: 0, max: 1}, 'Biosferaimage', false);  
var biomes = ee.FeatureCollection('projects/mapbiomas-workspace/AUXILIAR/biomas');
//print(Biosfera.limit(5));
Map.addLayer(biomes.style({
                color: '885500',
                width: 1,
                fillColor: '88550033',
            }), {}, 'Biomas', false);  
 var biomesimage = biomes.map(function(feature1) {
  return feature1.set('n', 0.001)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
//Map.addLayer(biomesimage, {min: 0, max: 1}, 'biomes1image', false);  
var UHE = ee.FeatureCollection("users/gustavoirgang/BR_UHE_maximorum_Buffer_Mult");
//print(Biosfera.limit(5));
Map.addLayer(UHE.style({
                color: '885500',
                width: 1,
                fillColor: '88550033',
            }), {}, 'Reservas da Biosfera', false);              
  var UHEimage = UHE.map(function(feature1) {
  return feature1.set('n', 0.20)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
//Map.addLayer(UHEimage, {min: 0, max: 1}, 'UHEimage', false);  
var biomes_reduced = biomes.reduceToImage(['featureid'], 'mode');
var biomesremap = biomes_reduced .remap([1,2,3,4,5,6],
           [0.009,0.099,0.019,0.079,0.039,0.059,]);
//limites do SAF certificado conforme memorial descritivo 
var limite_SAF1 = ee.FeatureCollection(ee.Geometry.MultiPolygon(
        [[[
[	-48.890460888400000	,	-27.581356459999999	],
[	-48.890553687400001	,	-27.581387393000000	],
[	-48.890684557699998	,	-27.581365977800001	],
[	-48.890803530800000	,	-27.581285076099999	],
[	-48.890858258400002	,	-27.581137549600001	],
[	-48.890860637800003	,	-27.580970987299999	],
[	-48.890813048600002	,	-27.580878188300002	],
[	-48.890679798800001	,	-27.580711625999999	],
[	-48.890520374899999	,	-27.580556961100001	],
[	-48.890446611599998	,	-27.580492715599998	],
[	-48.890144420100000	,	-27.580426090700001	],
[	-48.889925509699999	,	-27.580366604200002	],
[	-48.889816054500002	,	-27.580473679899999	],
[	-48.889896956100003	,	-27.580880567800001	],
[	-48.889942165900003	,	-27.580937674800001	],
[	-48.890172973600002	,	-27.581054268399999	],
[	-48.890325259100003	,	-27.581161344200002	],
[	-48.890387125099998	,	-27.581316009100000	],
[	-48.890460888400000	,	-27.581356459999999	],
 ]]]));
 Map.addLayer(limite_SAF1.style({
                color: '338800',
                width: 1,
                fillColor: '33880033',
            }), {}, 'Limite SAF', false);   
 var limite_SAF = limite_SAF1.map(function(feature1) {
  return feature1.set('n', 0.50)
}).reduceToImage({
    'properties': ['n'],
    'reducer': ee.Reducer.first()
});
var PSA = ee.ImageCollection([limite_SAF, UHEimage, Mata_Atlanticaimage, Biosferaimage, Semiaridoimage, Quilombosimage, TIimage, UCPIFimage, UCUSFimage, UCUSEimage, UCPIEimage, biomesimage]).sum().add(biomesremap);
Map.addLayer(PSA, {min: 0, max: 1}, 'PSA', false);            
//Paleta de cores Uso do Solo
var sld_intervals =
'<RasterSymbolizer>' +
 ' <ColorMap  type="intervals" extended="false" >' +
'<ColorMapEntry color="#129912" quantity="1" label="1. Floresta"/>' +
'<ColorMapEntry color="#006400" quantity="3" label="3. Formação Florestal"/>' +
'<ColorMapEntry color="#00ff00" quantity="4" label="4. Formação Savânica"/>' +
'<ColorMapEntry color="#687537" quantity="5" label="5. Mangue"/>' +
'<ColorMapEntry color="#6b9932" quantity="49" label="49. Restinga Arborizada (beta)"/>' +
'<ColorMapEntry color="#BBFCAC" quantity="10" label="10. Formação Natural não Florestal"/>' +
'<ColorMapEntry color="#45C2A5" quantity="11" label="11. Campo Alagado e Área Pantanosa"/>' +
'<ColorMapEntry color="#B8AF4F" quantity="12" label="12. Formação Campestre"/>' +
'<ColorMapEntry color="#968c46" quantity="32" label="32. Apicum"/>' +
'<ColorMapEntry color="#665a3a" quantity="29" label="29. Afloramento Rochoso"/>' +
'<ColorMapEntry color="#f1c232" quantity="13" label="13. Outras Formações não Florestais"/>' +
'<ColorMapEntry color="#FFFFB2" quantity="14" label="14. Agropecuária"/>' +
'<ColorMapEntry color="#FFD966" quantity="15" label="15. Pastagem"/>' +
'<ColorMapEntry color="#E974ED" quantity="18" label="18. Agricultura"/>' +
'<ColorMapEntry color="#D5A6BD" quantity="19" label="19. Lavoura Temporária"/>' +
'<ColorMapEntry color="#e075ad" quantity="39" label="39. Soja"/>' +
'<ColorMapEntry color="#C27BA0" quantity="20" label="20. Cana"/>' +
'<ColorMapEntry color="#982c9e" quantity="40" label="40. Arroz (beta)"/>' +
'<ColorMapEntry color="#e787f8" quantity="41" label="41. Outras Lavouras Temporárias"/>' +
'<ColorMapEntry color="#f3b4f1" quantity="36" label="36. Lavoura Perene"/>' +
'<ColorMapEntry color="#cca0d4" quantity="46" label="46. Café (beta)"/>' +
'<ColorMapEntry color="#d082de" quantity="47" label="47. Citrus (beta)"/>' +
'<ColorMapEntry color="#cd49e4" quantity="48" label="48. Outras Lavouras Perenes"/>' +
'<ColorMapEntry color="#ad4413" quantity="9" label="9. Silvicultura"/>' +
'<ColorMapEntry color="#fff3bf" quantity="21" label="21. Mosaico de Agricultura e Pastagem"/>' +
'<ColorMapEntry color="#EA9999" quantity="22" label="22. Área não Vegetada"/>' +
'<ColorMapEntry color="#DD7E6B" quantity="23" label="23. Praia, Duna e Areal"/>' +
'<ColorMapEntry color="#aa0000" quantity="24" label="24. Área Urbanizada"/>' +
'<ColorMapEntry color="#af2a2a" quantity="30" label="30. Mineração"/>' +
'<ColorMapEntry color="#ff3d3d" quantity="25" label="25. Outras Áreas não Vegetadas"/>' +
'<ColorMapEntry color="#0000FF" quantity="26" label="26. Corpo Dágua"/>' +
'<ColorMapEntry color="#0000FF" quantity="33" label="33. Rio, Lago e Oceano"/>' +
'<ColorMapEntry color="#02106f" quantity="31" label="31. Aquicultura"/>' +
'<ColorMapEntry color="#D5D5E5" quantity="27" label="27. Não Observado"/>' +
'</ColorMap>' +
'</RasterSymbolizer>';
var reclass  = {
  min: 0,
  max: 1,
  palette: [
"#000000",
"#00FF00"
]};
//Paletas de cores carbono
var PsnNetVis = {
  min: 0.0,
  max: 13.0,
  palette: ['FFFFFF',  '661100', 'c9995c', 'c7d270','8add60','004400'],
};
var PsnNetVis3 = {
  min: 0.0,
  max: 11.0,
  palette: ['FFFFFF', '0a9501', '074b03'],
};
var PsnNetVis1 = {
  min: 8.0,
  max: 65,
  palette: ['FFFFFF',  '661100', 'c9995c', 'c7d270','8add60','004400'],
};
var PsnGPP = {
  min: 4,
  max: 29.0,
  palette: ['FFFFFF',  '661100', 'c9995c', 'c7d270','8add60','004400'],
};
var dwVisParams = {
  min: 0,
  max: 8,
  palette: ['#419BDF', '#397D49', '#88B053', '#7A87C6',
    '#E49635', '#DFC35A', '#C4281B', '#A59B8F', '#B39FE1']
};
// Asset S2 Uso do Solo
var dw = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1')
   .filter(ee.Filter.date('2018-01-01', '2018-12-31'))
  .filter(ee.Filter.bounds(poly_outer))
// Create a Mode Composite
var classification = dw.select('label')
var dwComposite = classification.reduce(ee.Reducer.mode());
// Clip the composite and add it to the Map
Map.addLayer(dwComposite.clip(poly_outer), dwVisParams, 'Classified Composite 2018', false) 
 var mapbiomas_reclass_2018 =   dwComposite.remap([0, 1, 2, 3, 4, 5, 6, 7, 8],
[0, 1, 0, 1, 0, 0, 0, 0, 0]).rename('mato').set('system:time_start', '2018-01-01');
Map.addLayer(mapbiomas_reclass_2018, reclass, '2018 Mato', false);
var netYearly2018 = ee.ImageCollection('projects/planet-nicfi/assets/basemaps/americas')
 .filter(ee.Filter.date('2018-01-01', '2018-12-31'));
// Convert T carbono m² para t carbono hectare
var netYearly20181 = netYearly2018.map(function(image) {
  return image.normalizedDifference(['N','R']).divide(0.0703)});
var Npp20181 = netYearly20181.median().multiply(mapbiomas_reclass_2018).set('system:time_start', '2018-01-01').rename('Npp')
Map.addLayer(Npp20181, PsnNetVis, 'NPP_2018', false);
var dw = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1')
   .filter(ee.Filter.date('2019-01-01', '2019-12-31'))
  .filter(ee.Filter.bounds(poly_outer))
// Create a Mode Composite
var classification = dw.select('label')
var dwComposite = classification.reduce(ee.Reducer.mode());
// Clip the composite and add it to the Map
Map.addLayer(dwComposite.clip(poly_outer), dwVisParams, 'Classified Composite 2019', false) 
 var mapbiomas_reclass_2019 =   dwComposite.remap([0, 1, 2, 3, 4, 5, 6, 7, 8],
[0, 1, 0, 1, 0, 0, 0, 0, 0]).rename('mato').set('system:time_start', '2019-01-01');
Map.addLayer(mapbiomas_reclass_2019, reclass, '2019 Mato', false);
var netYearly2019 = ee.ImageCollection('projects/planet-nicfi/assets/basemaps/americas')
 .filter(ee.Filter.date('2019-01-01', '2019-12-31'));
// Convert T carbono m² para t carbono hectare
var netYearly20191 = netYearly2019.map(function(image) {
  return image.normalizedDifference(['N','R']).divide(0.0703)});
var Npp20191 = netYearly20191.median().multiply(mapbiomas_reclass_2019).set('system:time_start', '2019-01-01').rename('Npp')
Map.addLayer(Npp20191, PsnNetVis, 'NPP_2019', false);
var dw = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1')
   .filter(ee.Filter.date('2020-01-01', '2020-12-31'))
  .filter(ee.Filter.bounds(poly_outer))
// Create a Mode Composite
var classification = dw.select('label')
var dwComposite = classification.reduce(ee.Reducer.mode());
// Clip the composite and add it to the Map
Map.addLayer(dwComposite.clip(poly_outer), dwVisParams, 'Classified Composite 2020', false) 
 var mapbiomas_reclass_2020 =   dwComposite.remap([0, 1, 2, 3, 4, 5, 6, 7, 8],
[0, 1, 0, 1, 0, 0, 0, 0, 0]).rename('mato').set('system:time_start', '2020-01-01');
Map.addLayer(mapbiomas_reclass_2020, reclass, '2020 Mato', false);
var netYearly2020 = ee.ImageCollection('projects/planet-nicfi/assets/basemaps/americas')
 .filter(ee.Filter.date('2020-01-01', '2020-12-31'));
// Convert T carbono m² para t carbono hectare
var netYearly20201 = netYearly2020.map(function(image) {
  return image.normalizedDifference(['N','R']).divide(0.0703)});
var Npp20201 = netYearly20201.median().multiply(mapbiomas_reclass_2020).set('system:time_start', '2020-01-01').rename('Npp')
Map.addLayer(Npp20201, PsnNetVis, 'NPP_2020', false);
var dw = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1')
   .filter(ee.Filter.date('2021-01-01', '2021-12-31'))
  .filter(ee.Filter.bounds(poly_outer))
// Create a Mode Composite
var classification = dw.select('label')
var dwComposite = classification.reduce(ee.Reducer.mode());
// Clip the composite and add it to the Map
Map.addLayer(dwComposite.clip(poly_outer), dwVisParams, 'Classified Composite 2021', false) 
 var mapbiomas_reclass_2021 =   dwComposite.remap([0, 1, 2, 3, 4, 5, 6, 7, 8],
[0, 1, 0, 1, 0, 0, 0, 0, 0]).rename('mato').set('system:time_start', '2021-01-01');
Map.addLayer(mapbiomas_reclass_2021, reclass, '2021 Mato', false);
Map.addLayer(mapbiomas_reclass_2021, reclass, '2021 rec', false);
var netYearly2021 = ee.ImageCollection('projects/planet-nicfi/assets/basemaps/americas')
 .filter(ee.Filter.date('2021-01-01', '2021-12-31'));
// Convert T carbono m² para t carbono hectare
var netYearly20211 = netYearly2021.map(function(image) {
  return image.normalizedDifference(['N','R']).divide(0.0703)});
var Npp20211 = netYearly20211.median().multiply(mapbiomas_reclass_2021).set('system:time_start', '2021-01-01').rename('Npp')
Map.addLayer(Npp20211, PsnNetVis, 'NPP_2021', false);
var dw = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1')
   .filter(ee.Filter.date('2022-01-01', '2022-12-31'))
  .filter(ee.Filter.bounds(poly_outer))
// Create a Mode Composite
var classification = dw.select('label')
var dwComposite = classification.reduce(ee.Reducer.mode());
// Clip the composite and add it to the Map
Map.addLayer(dwComposite.clip(poly_outer), dwVisParams, 'Classified Composite 2022', false) 
 var mapbiomas_reclass_2022 =   dwComposite.remap([0, 1, 2, 3, 4, 5, 6, 7, 8],
[0, 1, 0, 1, 0, 0, 0, 0, 0]).rename('mato').set('system:time_start', '2022-01-01');
Map.addLayer(mapbiomas_reclass_2022, reclass, '2022 Mato', false);
Map.addLayer(mapbiomas_reclass_2022, reclass, '2022 rec', false);
var netYearly2022 = ee.ImageCollection('projects/planet-nicfi/assets/basemaps/americas')
 .filter(ee.Filter.date('2022-01-01', '2022-12-31'));
// Convert T carbono m² para t carbono hectare
var netYearly20221 = netYearly2022.map(function(image) {
  return image.normalizedDifference(['N','R']).divide(0.0703)});
var Npp20221 = netYearly20221.median().multiply(mapbiomas_reclass_2022).set('system:time_start', '2022-01-01').rename('Npp')
Map.addLayer(Npp20221, PsnNetVis, 'NPP_2022', false);
var mapbioma = mapbiomas_reclass_2022.multiply(mapbiomas_reclass_2021).multiply(mapbiomas_reclass_2020).multiply(mapbiomas_reclass_2019).multiply(mapbiomas_reclass_2018);
var mapbioma2 = ee.ImageCollection([mapbiomas_reclass_2022,mapbiomas_reclass_2021,mapbiomas_reclass_2020,mapbiomas_reclass_2019,mapbiomas_reclass_2018]) .filter(ee.Filter.date(ano_inicio + '-01-01', ano_fim + '-12-31'));
Map.addLayer(mapbioma, reclass, 'Mapbioma rec', false);
//Total de carbono para linha de base
var base2 = ee.ImageCollection([Npp20221,Npp20211,Npp20201,Npp20191,Npp20181]) .filter(ee.Filter.date(ano_inicio + '-01-01', ano_fim + '-12-31'));
//print(base2)
var NppYearlyes = base2.sum().multiply(mapbioma)
var Npp1 = NppYearlyes
  //Calculo de áreas p adicionalidade
  var table = ee.FeatureCollection(limites);
  var table1 = ee.FeatureCollection(limites1);
  //Dados da produção liquida anual de carbono para o gráfico
var netYearly = ee.ImageCollection('projects/planet-nicfi/assets/basemaps/americas')
 .filter(ee.Filter.date(inicio, fim));
// Convert pressure levels from Pa to hPa - Example for surface pressure
var netYearly = netYearly.map(function(image) {
  return image.normalizedDifference(['N','R']).divide(0.0703).set(
      'system:time_start', image.get('system:time_start'));
});
//delimitação do Projeto para cáculo de área adicionalidade
var Npp3 = netYearly.mean().rename('Npp')
Map.addLayer(Npp3,PsnNetVis1, 'Linha de Base', false);
  var area_pxa_base1 = Npp3.gte(1).multiply(ee.Image.pixelArea()) 
                    .reduceRegion(ee.Reducer.sum(),table,30,null,null,false,1e13)
                    .get('Npp')
//print(area_pxa_base1)                    
var area_pxa_base = Npp1.gte(1).multiply(ee.Image.pixelArea()) 
                    .reduceRegion(ee.Reducer.sum(),table,30,null,null,false,1e13)
                    .get('Npp')
//print(area_pxa_base)                     
                  //  print ('Área usando o ee.Image.pixelArea', ee.Number(area_pxa).divide(1e6))
  var area_pxa2_base =  ee.Number(((ee.Number(area_pxa_base1).divide(1e4)).subtract(ee.Number(area_pxa_base).divide(1e4))).divide(ee.Number(area_pxa_base1).divide(1e4))).multiply(100)
//print(area_pxa2_base)
   //Calculo de áreas
var area_pxa_ref1 = Npp3.gte(1).multiply(ee.Image.pixelArea()) 
                    .reduceRegion(ee.Reducer.sum(),table1,30,null,null,false,1e13)
                    .get('Npp')
var area_pxa_ref = Npp1.gte(1).multiply(ee.Image.pixelArea()) 
                    .reduceRegion(ee.Reducer.sum(),table1,30,null,null,false,1e13)
                    .get('Npp')
                  //  print ('Área usando o ee.Image.pixelArea', ee.Number(area_pxa).divide(1e6))
  var area_pxa2_ref =  ee.Number(((ee.Number(area_pxa_ref1).divide(1e4)).subtract(ee.Number(area_pxa_ref).divide(1e4))).divide(ee.Number(area_pxa_ref1).divide(1e4))).multiply(100)
//print(area_pxa2_ref)
var referencia1 = ee.Number(area_pxa2_ref)
var base = ee.Number(area_pxa2_base)
var prop = ee.Number(ee.Number(area_pxa2_ref).subtract(ee.Number(area_pxa2_base)))
//print(prop)
//Soma de anos com Carbono em vegetação preservada
var mapbiomas =  mapbioma
Map.addLayer(mapbiomas,PsnNetVis3, 'Mapbiomas anos', false);
//Área com carbono em vegetação preservada
var Nppgt =(Npp1.gte(1)).clip(limites)
Map.addLayer((NppYearlyes), PsnNetVis1, 'Npp total');
//Carbono da produção Bruta anual
var dataset = ee.ImageCollection('projects/planet-nicfi/assets/basemaps/americas')
                  .filter(ee.Filter.date(inicio, fim));
// Conversão de t de carbono por m² para t de carbono hectares
var dataset = dataset.map(function(image) {
  return image.normalizedDifference(['N','R']).divide(0.0302).rename('Gpp')
  .set(
      'system:time_start', image.get('system:time_start'));
});
var gpp = dataset.median().clip(limites).multiply(mapbioma);
var gpp1 = dataset.median().multiply(mapbioma);
var gpp2 = dataset.median().multiply(mapbioma)
Map.addLayer(gpp2, PsnGPP, 'Gpp', false);
//Map.addLayer(gpp1, PsnGPP, 'gpp1');
//Cálculo do valor final de carbono pela adicionalidade
var tc12 = (NppYearlyes.add(gpp2))
//Transformação de t de carbono para t de CO²
var tco2e = tc12.multiply(3.67).multiply((prop).divide(100))
//Adicional Biomas
var bioma = tco2e.multiply(PSA)
//Total de CO²e
var c12 = tco2e.add(bioma)
//Percentagem Adicionall
var percentagem = (ee.Number(bioma.reduceRegion(ee.Reducer.sum(), limites, 50).get('Npp')).divide(ee.Number(tco2e.reduceRegion(ee.Reducer.sum(), limites, 50).get('Npp')))).multiply(100);
//Total de CO²e em Dollar
//var U$D = c12.multiply($ton)
//Total de CO²e em Reais
//var R$ = U$D.multiply(dolar)
var tc12_perc = tc12 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')  
  var tco2e_p =       tco2e
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')  
        //            print(tco2e_p)
//Total de CO²e em Dollar
var U$D = c12.multiply(10)
//Total de CO²e em Reais
var R$ = U$D.multiply(dolar)
//Paineis Legendas
var legendarea = ui.Panel([ui.Label('Calculando área com vegetação natural da propriedade')]);
var legendarea2 = ui.Panel([ui.Label('Calculando área total da propriedade')]);
//Calculo de áreas
var area_pxa = Nppgt.gte(1).multiply(ee.Image.pixelArea()) 
                    .reduceRegion(ee.Reducer.sum(),table,30,null,null,false,1e13)
                    .get('Npp')
                  //  print ('Área usando o ee.Image.pixelArea', ee.Number(area_pxa).divide(1e6))
  var area_pxa2 =  ee.Number(area_pxa).divide(1e4)
  // Request the value from the server.
  area_pxa2.evaluate(function(result) {
    // When the server returns the value, show it.
    legendarea.widgets().set(0, ui.Label({
      value: 'Área com vegetação natural em hectares: ' + result.toFixed(2),
    }));
});
//Maneira correta de calcular áreas
var area_pxa4 = Npp3.gte(0.00001).multiply(ee.Image.pixelArea()) 
                    .reduceRegion(ee.Reducer.sum(),table,30,null,null,false,1e13)
                    .get('Npp')
                  //  print ('Área usando o ee.Image.pixelArea', ee.Number(area_pxa).divide(1e6))
  var area_pxa3 =  ee.Number(area_pxa4).divide(1e4)
  // Request the value from the server.
  area_pxa3.evaluate(function(result) {
    // When the server returns the value, show it.
    legendarea2.widgets().set(0, ui.Label({
      value: 'Área do imóvel em hectares: ' + result.toFixed(2),
    }));
});  
  //Toneladas de carbono por hectares
var area_pxa22 =  ee.Number(area_pxa).divide(1e4)
var tCha_area = area_pxa22
//print(tCha_area)
var tCha_carbonoB = (gpp2)
//print(tCha_carbonoB)
var tCha_carbonoB_perc1 = gpp2
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Gpp')
var tCha_carbonoB_perc2 = tc12 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')                    
var tCha_carbonoB_perc =  (ee.Number(tCha_carbonoB_perc1).divide(ee.Number(tCha_carbonoB_perc2))).multiply(100);
//print(tCha_carbonoB_perc)
var tChaB = tCha_carbonoB.divide(area_pxa22);
//print(tChaB)
var tChaB_perc1 = (tChaB) 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Gpp')
var tChaB_perc2 = tc12 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')                    
var tChaB_perc =  (ee.Number(tChaB_perc1).divide(ee.Number(tChaB_perc2))).multiply(100);
var tChaBano = tCha_carbonoB.divide(area_pxa22).divide(anos);
//print(tChaBano)
var tChaBano_perc1 = (tChaBano) 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Gpp')
var tChaBano_perc2 = tc12 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')                    
var tChaBano_perc =  (ee.Number(tChaBano_perc1).divide(ee.Number(tChaBano_perc2))).multiply(100);
var tCha_carbonoL = (NppYearlyes)
 // print(tCha_carbonoL)
var tChaL = (tCha_carbonoL).divide(area_pxa22)
//print(tChaL)
var tChaL_perc1 = (tChaL) 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')
var tChaL_perc2 = tc12 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')                    
var tChaL_perc =  (ee.Number(tChaL_perc1).divide(ee.Number(tChaL_perc2))).multiply(100);
var tCha_carbonoL_perc1 = (NppYearlyes) 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')
var tCha_carbonoL_perc2 = tc12 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')                    
var tCha_carbonoL_perc =  (ee.Number(tCha_carbonoL_perc1).divide(ee.Number(tCha_carbonoL_perc2))).multiply(100);
var tChaLano = (tCha_carbonoL).divide(area_pxa22).divide(anos)
var tChaLano_perc1 = (tChaLano) 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')
var tChaLano_perc2 = tc12 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')                    
var tChaLano_perc =  (ee.Number(tChaLano_perc1).divide(ee.Number(tChaLano_perc2))).multiply(100);
var tCha_carbonoT = tc12
 // print(tCha_carbonoT)
 var tCha_carbonoT_perc1 = (tCha_carbonoT) 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')
var tCha_carbonoT_perc2 = tc12 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')                    
var tCha_carbonoT_perc =  (ee.Number(tCha_carbonoT_perc1).divide(ee.Number(tCha_carbonoT_perc2))).multiply(100);
var tChaT = (tCha_carbonoT).divide(area_pxa22)
//print(tChaT)
 var tChaT_perc1 = (tChaT) 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')
var tChaT_perc2 = tc12 
                    .reduceRegion(ee.Reducer.sum(),table,50)
                    .get('Npp')                    
var tChaT_perc =  (ee.Number(tChaT_perc1).divide(ee.Number(tChaT_perc2))).multiply(100);
var tChaT_anos = ee.Number(tc12_perc).divide(anos)
//print(tChaT_anos)
var tChaT_anos_perc1 = (tChaT_anos) 
var tChaT_anos_perc2 = tc12_perc                   
var tChaT_anos_perc =  (ee.Number(tChaT_anos_perc1).divide(ee.Number(tChaT_anos_perc2))).multiply(100);
//Map.addLayer(limites, {color:'red'}, 'Limites Propiedade' );
Map.addLayer(ee.FeatureCollection(limites).style({
                color: 'red',
                width: 2,
                fillColor: 'ffff0010',
            }), {}, 'Limites');
Map.centerObject(limites,12);
// Create an empty panel in which to arrange widgets.
// The layout is vertical flow by default.
var panel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {width: '60%', height: '100%'}})
    .add(ui.Label('EXTRATO C12d DOS SERVIÇOS AMBIENTAIS EM SAF-SISTEMAS AGROFLORESTAL E EM VEGETAÇÃO NATURAL PARA O PERÍODO DE: ' + ano_inicio +' a ' + ano_fim +', TOTALIZANDO: ' + anos + ' ANOS COMPROVADOS DE EMISSÕES DE CARBONO (tCO2eq=Toneladas de Dióxido de Carbono equivalente) REMOVIDAS E OU EVITADAS PELO PROJETO:  '
    + Projeto));
// Create an inspector panel with a horizontal layout.
var inspector0tChaBanos = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0tChaLanos = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0tChaB = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-left',
  }
});
var inspector0tChaL = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0tChaT = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
// Add a label to the panel.
inspector0.add(ui.Label('Acumulados'));
var inspector00 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector001 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector002 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector003 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector004 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector005 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector006 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector007 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector008 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector009 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0010 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0011 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0012 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0013 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0014 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0015 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0016 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
var inspector0017 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    stretch: 'horizontal',
  }
});
   var sampledPoint0wtChaB = tChaB.reduceRegion(ee.Reducer.sum(), limites, 50);
  var computedValue0wtChaB = sampledPoint0wtChaB.get('Gpp');
  // Request the value from the server and use the results in a function.
  computedValue0wtChaB.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector0tChaB.widgets().set(1, ui.Label({
      value: 'Toneladas de carbono p.p. Bruta (Gpp) por hectare: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
   var sampledPointtChaB_perc = tChaB_perc;
  var computedValuetChaB_perc = sampledPointtChaB_perc;
  // Request the value from the server and use the results in a function.
  computedValuetChaB_perc.evaluate(function(result) {
    // Add a label with the results from the server.
     inspector0tChaB.widgets().set(2, ui.Label({
      value: '% Total: ' + result.toFixed(3),
      style: {stretch: 'horizontal'}
    }));
  });
var sampledPoint0wtChaLanos = tChaLano.reduceRegion(ee.Reducer.sum(), limites, 50);
  var computedValue0wtChaLanos = sampledPoint0wtChaLanos.get('Npp');
  // Request the value from the server and use the results in a function.
  computedValue0wtChaLanos.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector0tChaLanos.widgets().set(3, ui.Label({
      value: 'Toneladas de carbono p.p. Líquida (Npp) por hectare ano: ' + result.toFixed(3),
      style: {stretch: 'horizontal'}
    }));
  });
     var sampledPointtChaLano_perc = tChaLano_perc;
  var computedValuetChaLano_perc = sampledPointtChaLano_perc;
  // Request the value from the server and use the results in a function.
  computedValuetChaLano_perc.evaluate(function(result) {
    // Add a label with the results from the server.
     inspector0tChaLanos.widgets().set(2, ui.Label({
      value: '% Total: ' + result.toFixed(4),
      style: {stretch: 'horizontal'}
    }));
  });
var sampledPoint0wtChaL = tChaL.reduceRegion(ee.Reducer.sum(), limites, 50);
  var computedValue0wtChaL = sampledPoint0wtChaL.get('Npp');
  // Request the value from the server and use the results in a function.
  computedValue0wtChaL.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector0tChaL.widgets().set(3, ui.Label({
      value: 'Toneladas de carbono p.p. Líquida (Npp) por hectare: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPointtChaL_perc = tChaL_perc;
  var computedValuetChaL_perc = sampledPointtChaL_perc;
  // Request the value from the server and use the results in a function.
  computedValuetChaL_perc.evaluate(function(result) {
    // Add a label with the results from the server.
     inspector0tChaL.widgets().set(2, ui.Label({
      value: '% Total: ' + result.toFixed(3),
      style: {stretch: 'horizontal'}
    }));
  });
var sampledPoint0wtChaT = tChaT.reduceRegion(ee.Reducer.sum(), limites, 50);
  var computedValue0wtChaT = sampledPoint0wtChaT.get('Npp');
  // Request the value from the server and use the results in a function.
  computedValue0wtChaT.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector0tChaT.widgets().set(3, ui.Label({
      value: 'Toneladas de carbono p.p. Total (Gpp+Npp) por hectare: ' + result.toFixed(3),
      style: {stretch: 'horizontal'}
    }));
  });
var sampledPointtChaT_perc = tChaT_perc;
  var computedValuetChaT_perc = sampledPointtChaT_perc;
  // Request the value from the server and use the results in a function.
  computedValuetChaT_perc.evaluate(function(result) {
    // Add a label with the results from the server.
      inspector0tChaT.widgets().set(2, ui.Label({
      value: '% Total: ' + result.toFixed(4),
      style: {stretch: 'horizontal'}
    }));
  });
var sampledPoint0w = gpp2.reduceRegion(ee.Reducer.sum(), limites, 50);
  var computedValue0w = sampledPoint0w.get('Gpp');
  // Request the value from the server and use the results in a function.
  computedValue0w.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector00.widgets().set(1, ui.Label({
      value: 'Produtividade primária bruta em Toneladas de carbono (GPP): ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPointtCha_carbonoB_perc = tCha_carbonoB_perc;
  var computedValuetCha_carbonoB_perc = sampledPointtCha_carbonoB_perc;
  // Request the value from the server and use the results in a function.
  computedValuetCha_carbonoB_perc.evaluate(function(result) {
    // Add a label with the results from the server.
     inspector00.widgets().set(2, ui.Label({
      value: '% Total: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
var sampledPoint1w = NppYearlyes.reduceRegion(ee.Reducer.sum(), limites, 50);
  var computedValue1w = sampledPoint1w.get('Npp');
  // Request the value from the server and use the results in a function.
  computedValue1w.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector001.widgets().set(1, ui.Label({
      value: 'Produtividade primária líquida em Toneladas de carbono (NPP): ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
 var sampledPointtCha_carbonoL_perc = tCha_carbonoL_perc;
  var computedValuetCha_carbonoL_perc = sampledPointtCha_carbonoL_perc;
  // Request the value from the server and use the results in a function.
  computedValuetCha_carbonoL_perc.evaluate(function(result) {
    // Add a label with the results from the server.
     inspector001.widgets().set(2, ui.Label({
      value: '% Total: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint5w = tChaT_anos;
 var computedValue5w = tChaT_anos;
  // Request the value from the server and use the results in a function.
 computedValue5w.evaluate(function(result) {
    // Add a label with the results from the server.
   inspector0014.widgets().set(3, ui.Label({
      value: 'Toneladas de carbono p.p. Total (Gpp+Npp) por ano: ' + result.toFixed(2),      style: {stretch: 'horizontal'}
    }));
  });
   var sampledPointtChaT_anos_perc = tChaT_anos_perc;
  var computedValuetChaT_anos_perc = sampledPointtChaT_anos_perc;
  // Request the value from the server and use the results in a function.
  computedValuetChaT_anos_perc.evaluate(function(result) {
    // Add a label with the results from the server.
     inspector0014.widgets().set(2, ui.Label({
      value: '% Total: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint5w = base;
  var computedValue5w = base;
  // Request the value from the server and use the results in a function.
  computedValue5w.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector0017.widgets().set(3, ui.Label({
      value: '% de área alterada de Referência da propriedade: ' + result.toFixed(2),      style: {stretch: 'horizontal'}
    }));
  });
 var sampledPoint6w = referencia1;
  var computedValue6w = referencia1;
  // Request the value from the server and use the results in a function.
  computedValue6w.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector0015.widgets().set(3, ui.Label({
      value: '% de área alterada na Linha de Base '+ distancia + ' metros no entorno da propriedade: ' + result.toFixed(2),      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint7w = prop;
  var computedValue7w = prop;
  // Request the value from the server and use the results in a function.
  computedValue7w.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector0016.widgets().set(3, ui.Label({
      value: 'Adicionalidade igual a diferença entre as % de referência e de base: ' + result.toFixed(2),      style: {stretch: 'horizontal'}
    }));
  });
var sampledPoint2w = tc12.reduceRegion(ee.Reducer.sum(), limites, 50);
  var computedValue2w = sampledPoint2w.get('Npp');
  // Request the value from the server and use the results in a function.
  computedValue2w.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector002.widgets().set(3, ui.Label({
      value: 'Safras em Toneladas de Carbono total (NPP+GPP): ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPointtCha_carbonoT_perc = tCha_carbonoT_perc;
  var computedValuetCha_carbonoT_perc = sampledPointtCha_carbonoT_perc;
  // Request the value from the server and use the results in a function.
  computedValuetCha_carbonoT_perc.evaluate(function(result) {
    // Add a label with the results from the server.
     inspector002.widgets().set(2, ui.Label({
      value: '% Total: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint222w = tco2e.reduceRegion(ee.Reducer.sum(), limites, 50);
  var computedValue222w = sampledPoint222w.get('Npp');
  // Request the value from the server and use the results in a function.
  computedValue222w.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector0013.widgets().set(3, ui.Label({
      value: 'Safras em tCO2eq = % Adicionalidade x (NPP+GPP) x 3.67: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
 var sampledPoint26w = percentagem//.reduceRegion(ee.Reducer.mean(), limites, 500);
  var computedValue26w = sampledPoint26w//.get('Npp');
  // Request the value from the server and use the results in a function.
  computedValue26w.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector006.widgets().set(3, ui.Label({
      value: 'Percentagem Ganho Adicional total (%): ' + result.toFixed(2),
     style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint210w = bioma.reduceRegion(ee.Reducer.sum(), limites, 50);
  var computedValue210w = sampledPoint210w.get('Npp');
  // Request the value from the server and use the results in a function.
  computedValue210w.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector0010.widgets().set(3, ui.Label({
      value: 'Acréscimo PSA % de Safras em tCO2eq: ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
  var sampledPoint212w = c12.reduceRegion(ee.Reducer.sum(), limites, 50);
  var computedValue212w = sampledPoint212w.get('Npp');
  // Request the value from the server and use the results in a function.
  computedValue212w.evaluate(function(result) {
    // Add a label with the results from the server.
    inspector0012.widgets().set(3, ui.Label({
      value: 'Ganho Líquido total Safras de tCO2eq em Unidade de Carbono Verificada" (UCV) : ' + result.toFixed(2),
      style: {stretch: 'horizontal'}
    }));
  });
// ---------------------------------------------------------------
// Visualize Data in a Chart
// ---------------------------------------------------------------
// Chart annual time series of carbon
var chart20 = ui.Chart.image.seriesByRegion({
  imageCollection: base2,
  regions: geometry,
  reducer: ee.Reducer.mean(), 
  scale: 500,
  seriesProperty: 'nome'
}).setOptions({
          title: 'Gráfico dos dados de Produtividade primária líquida média em Toneladas de carbono (NPP) por ano',
          vAxis: {title: 'toneladas'},
          hAxis: {title: 'Datas: dados anuais', format: 'YYYY'},
          series: {
          // Gives each series an axis name that matches the Y-axis below.
          0: {axis: 'Produtividade primária'},
           },
})
//print(chart2)
var chart0 = ui.Chart.image.seriesByRegion({
  imageCollection: base2,
  regions: geometry,
  reducer: ee.Reducer.sum(), 
  scale: 500,
  seriesProperty: 'nome'
}).setOptions({
          title: 'Gráfico das áreas em hectares com média vegetação natural por ano',
          vAxis: {title: 'toneladas'},
          hAxis: {title: 'Data', format: 'YYYY'},
          series: {
          // Gives each series an axis name that matches the Y-axis below.
          0: {axis: 'Produtividade primária'},
           },
          }).setChartType('Table');
//print(chart0)
//Total de Carbono para referência
var chart21 = ui.Chart.image.seriesByRegion({
  imageCollection: mapbioma2,
  regions: geometry,
  reducer: ee.Reducer.mean(), 
    seriesProperty: 'nome',
    xProperty: 'system:time_start',
    scale: 100
}).setOptions({
          title: 'Gráfico das áreas em hectares com vegetação natural por ano',
          vAxis: {title: 'hectares'},
          hAxis: {title: 'Date', format: 'YYYY'},
          series: {
          // Gives each series an axis name that matches the Y-axis below.
          0: {axis: 'àrea em hectares'},
           },
})
//print(chart20)
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
var legendTitle = ui.Label({
  value: ('Uso do Solo 2020'),
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend.add(legendTitle);
panel.add(legend); 
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette =['129912','006400','00ff00','687537','6b9932','BBFCAC','45C2A5','B8AF4F','968c46','665a3a','f1c232','FFFFB2','FFD966','E974ED','D5A6BD','e075ad','C27BA0','982c9e','e787f8','f3b4f1','cca0d4','d082de','cd49e4','ad4413','fff3bf','EA9999','DD7E6B','aa0000','af2a2a','ff3d3d','0000FF','0000FF','02106f','D5D5E5'];
// name of the legend
var names = ['1. Floresta',  '3. Formação Florestal',  '4. Formação Savânica',  '5. Mangue',  '49. Restinga Arborizada',  '10. Formação Natural não Florestal',  '11. Campo Alagado e Área Pantanosa',  '12. Formação Campestre',  '32. Apicum',  '29. Afloramento Rochoso',  '13. Outras Formações não Florestais',  '14. Agropecuária',  '15. Pastagem',  '18. Agricultura',  '19. Lavoura Temporária',  '39. Soja',  '20. Cana',  '40. Arroz',  '41. Outras Lavouras Temporárias',  '36. Lavoura Perene',  '46. Café (beta)',  '47. Citrus',  '48. Outras Lavouras Perenes',  '9. Silvicultura',  '21. Mosaico de Agricultura e Pastagem',  '22. Área não Vegetada',  '23. Praia, Duna e Areal',  '24. Área Urbanizada',  '30. Mineração',  '25. Outras Áreas não Vegetadas',  '26. Corpo Dágua',  '33. Rio, Lago e Oceano',  '31. Aquicultura',  '27. Não Observado'];
var numes = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34];  
// Add color and and names
for (var i = 0; i < 18; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)
//Map.add(legend);
/*
 * The legend panel in the bottom-left
 */
// A color bar widget. Makes a horizontal color bar to display the given
// color palette.
var POPULATION_VIS_MAX_VALUE = 5000;
var POPULATION_VIS_NONLINEARITY = 4;
// Apply a non-linear stretch to the population data for visualization.
function colorStretch(image) {
  return image.divide(POPULATION_VIS_MAX_VALUE)
      .pow(1 / POPULATION_VIS_NONLINEARITY);
}
// Inverts the nonlinear stretch we apply to the population data for
// visualization, so that we can back out values to display in the legend.
// This uses ordinary JavaScript math functions, rather than Earth Engine
// functions, since we're going to call it from JS to compute label values.
function undoColorStretch(val) {
  return Math.pow(val, POPULATION_VIS_NONLINEARITY) * POPULATION_VIS_MAX_VALUE;
}
function ColorBar(palette) {
  return ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 1, 0.1],
      dimensions: '100x10',
      format: 'png',
      min: 0,
      max: 1,
      palette: palette,
    },
    style: {stretch: 'horizontal', margin: '0px 8px'},
  });
}
// Returns our labeled legend, with a color bar and three labels representing
// the minimum, middle, and maximum values.
function makeLegend() {
  var labelPanel = ui.Panel(
      [
        ui.Label(Math.round(undoColorStretch(0)), {margin: '4px 8px'}),
        ui.Label(
            Math.round(undoColorStretch(0.5)),
            {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
        ui.Label(Math.round(undoColorStretch(1)), {margin: '4px 8px'})
      ],
      ui.Panel.Layout.flow('horizontal'));
  return ui.Panel([ColorBar(PsnNetVis.palette), labelPanel]);
}
// Styling for the legend title.
var LEGEND_TITLE_STYLE = {
  fontSize: '20px',
  fontWeight: 'bold',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '4px',
};
// Styling for the legend footnotes.
var LEGEND_FOOTNOTE_STYLE = {
  fontSize: '10px',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '4px',
};
// Assemble the legend panel.
// set position of panel
var legend1 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
panel.add(legend1); 
legend1.add(ui.Panel(
    [
      ui.Label('Toneladas de Carbono', LEGEND_TITLE_STYLE), makeLegend(),
      ui.Label(
          '(tCO2eq=Toneladas de Dióxido de Carbono equivalente)', LEGEND_FOOTNOTE_STYLE),
      ui.Label(
          'Satélite MODIS MOD17A2H V6', LEGEND_FOOTNOTE_STYLE),
    ],
    ui.Panel.Layout.flow('vertical'),
    {width: '230px', position: 'bottom-left'}));
 var panel2 = ui.Panel({style: {width: '100%'}})
    .add(ui.Label('Fontes: Dados carbono da Planet Team (2017). Planet Application Program Interface: In Space for Life on Earth. San Francisco, CA. https://api.planet.com - Produtividade Primária Bruta (GPP) dcom resolução de 5 m.  fornece informações sobre a produtividade primária líquida (NPP) anual com resolução de pixel de 5 m. NPP anual;  limites áreas protegidas do https://mapbiomas.org/ Coleção 7 (1985-2021);  Dynamic World, Near real-time global 10 m land use land cover mapping. Sci Data 9, 251 (2022). doi:10.1038/s41597-022-01307-4' )); 
panel.widgets().set(1, legendarea2).set(2, legendarea).set(3, inspector0017).set(4, inspector0015).set(5, inspector0016).set(6, inspector00).set(7, inspector001).set(8, inspector0014).set(9, inspector0tChaB).set(10, inspector0tChaBanos).set(11, inspector0tChaL).set(12, inspector0tChaLanos).set(13, inspector0tChaT).set(14, inspector002).set(15, inspector0013).set(16, inspector007).set(17, inspector0010).set(18, inspector0011).set(19, inspector006).set(20, inspector0012).set(21, inspector003).set(22, inspector004).set(23, chart20).set(24,chart21).set(25, chart0).set(26, legend).set(27, legend1).set(28, panel2);
//});
// Add the panel to the ui.root.
ui.root.add(panel);