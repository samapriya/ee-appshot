// This version use NCEP/CFSv2 weather dataset (available from 1979 to present)
//================================================= INPUT SETTINGS ======================================================= 
//var InsertStartYear = prompt('Enter with the Start Year:',2010); 
//var InsertEndYear = prompt('Enter with the End Year:',2019);
//var InsertWRS_Path = prompt('Enter with the WRS Path:',217); // 2 or 3 digits
//var InsertWRS_Row = prompt('Enter with the WRS Row:',67); // 2 digits
var Set_date_viz = 'N';//prompt('Enter "Y" for Yes or "N" for No.' + 
//' If Yes enter next a Date to visualize in map.' +
//' If No, will be show a more recently less-cloudy image: ','N');
var DateViz = ee.Date(Date.now()).advance(-90,'day');//prompt('Type the date to visualize in map (format: YYYY-MM-DD):','2019-09-20');
var Set_k_value = 'Y'; // If Yes 'Y', k parameter use in SSEBop will be the value set below (k_value). If No, k will be computed as averaged ratio between ET0-alfafa and ET0-grass in period. 
var k_value = 1.2; // coefficient to scale the grass ETo to the maximum level ET for an aerodynamically rougher crop such as alfalfa
var Insertcloud_tresh = 30;//prompt('Enter a cloud percent value to select best scenes in collection' +
//' (Set to change the number of selected scenes) :',30);
var geometry = /* color: #d63000 */ee.Geometry.Point([-40, -9]);
Map.centerObject(geometry, 8);
Map.setOptions('HYBRID'); 
// Set the default map's cursor to a "crosshair".
Map.style().set('cursor', 'crosshair');
//================================================= INPUT SETTINGS PANEL ======================================================= 
// Compute time offset in years.
var panel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {width: '65%', height: '100%'}})
    .add(ui.Label('Clique no mapa para ver evapotranspiração real para séries temporais do Satélite Landsat para o ponto'))
.add(ui.Label('Este APP em plataforma Google Earth Engine (GEE) permite a aplicação do modelo SSEBop (Operational Simplified Surface Energy Balance calculada pelo método Penman-Monteith FAO) para estimar a evapotranspiração real na escala de 30m usando dados meteorológicos da grade das séries Landsat (TM, ETM) e grade NCEP / CFSv2. Desvios são apresentados especialmente em corpos dágua e em áreas topograficamente complexas e/ou com baixa cobertura florestal'))
.add(ui.Label('Este script é experimental e, portanto, sujeito a instabilidades e imprecisões e na variação da pilha de imagens tratadas, caso de erro clique em outro local, o processo e longo e portanto relativamente lento.'
))
.add(ui.Label('APP desenvolvida com base no proposto por Ricardo Neves de Souza Lima Para maiores Informações:(https://proceedings.science/proceedings/100063/_papers/97173/download/abstract_file1)'));
// create vizualization parameters
var viz = {min:0.0,max:8.0,palette: ['Chocolate','SandyBrown','Yellow','LimeGreen','DarkBlue']};
panel.add(ui.Button('Fecha', function() {
      panel.style().set({shown: false});
    }));
var StartYear1 = ee.Date(Date.now()).advance(-10,'year');
var StartYear = StartYear1.get('year');
var EndYear1 = ee.Date(Date.now());//ee.Number.parse(InsertEndYear).getInfo();
var EndYear = EndYear1.get('year');
//var WRS_Path = ee.Number.parse(InsertWRS_Path).getInfo();
//var WRS_Path2 = WRS_Path;
//var WRS_Row = ee.Number.parse(InsertWRS_Row).getInfo();
var cloud_tresh = 30;//ee.Number.parse(Insertcloud_tresh).getInfo();
// Add a red dot to the map where the user clicked.
Map.onClick(function(coords) {
var panel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {width: '35%', height: '100%'}})
    .add(ui.Label('Clique no mapa'));
 panel.clear();
//ui.root.clear().remove(panel); 
  Map.layers().reset();
  var geometry = ee.Geometry.Point(coords.lon, coords.lat);
//==================================== CONSTANTS ======================================================= 
var cloud_score_tresh = 20; // For use in the mask clouds function
var cosi_threshold = 0.1; // For Self shadow mask
var a_coeffic = 110;
// Constants for reference ET calculation
var lhv = 2.45; // Latent Heat of Vaporization (λ)
var albedo_mean = 0.23;
var Gsc_h = 4.92; // solar constant MJ.m-2.h-1
var Kt = 1.0; // turbidity coefficient (1.0 for clean air and 0.5 for extremely turbid)
var sigma = 0.000000004901; // Stefan-Boltzmann constant MJ.K-4.m-2.d-1
// Constants for SEB processing
var L = 0.5; // for SAVI calculation
var Gsc = 1367; // solar constant W.m-2 (Same of Isc)
var st_boltz = 0.0000000567; // Stefan-Boltzmann constant W.m-2.K-4
var Cp = 1004; // specific heat of air at constant pressure J.kg−1.K−1
var Cp_SSEBop = 1013; // specific heat of air at constant pressure J.kg−1.°C−1
// Constraining parameters for producing c factor (Senay et al, 2017)
var ndvi_threshold = 0.8;
var ndvi_percent = 99; // Top % NDVI to select forested areas (where maximum NDVI is less than 0.8)
var Ts_limit_min = 270;
var Ts_limit_max = 330;
var Tdiff_min = 0;
var Tdiff_max = 30;
//===================================================== VISUALIZATION PARAMETERS ======================================================= 
var vizParamsL8 = {bands: ['B6', 'B5', 'B4'],min: 0,max: 5000};
var vizParamsL5 = {bands: ['B5', 'B4', 'B3'],min: 0,max: 5000};
//======================================================= GEOGRAPHICAL COVERAGE ======================================================= 
var envelopegeodesic = ee.Geometry.Rectangle([-179, -89, 179, 89]);
var envelope = ee.Geometry(envelopegeodesic, null, false);
//===================================================== MAIN COLLECTIONS AND OTHER INPUTS =================================================================== 
// Paraiba do Sul basin limits (from ANA ottobacias)
var BHPS = ee.FeatureCollection('users/ricardogeo/BH_ParaibaDoSul');
// Brazil Land Cover maps from 1985 to 2017 (Landsat based)
var Brazil_Landcover_coll3 = ee.Image('projects/mapbiomas-workspace/public/collection4/mapbiomas_collection40_integration_v1');
// Input Digital Elevation Model (DEM)
var DEM_input = ee.Image('USGS/SRTMGL1_003');
// Insert a NCEP CFSv2 6-hourly products
var CFSv2_collection = ee.ImageCollection('NOAA/CFSV2/FOR6H');
// Landsat-8 Surface reflectance collection
var L8_SR_collection = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR');
var L8_SR = L8_SR_collection.filter(ee.Filter.calendarRange(StartYear, EndYear,'year'))
.filterBounds(geometry)
.filterMetadata('CLOUD_COVER', 'less_than', cloud_tresh);
// Landsat-5 Surface reflectance collection
var L5_SR_collection = ee.ImageCollection('LANDSAT/LT05/C01/T1_SR');
var L5_SR = L5_SR_collection.filter(ee.Filter.calendarRange(StartYear, EndYear,'year'))
.filterBounds(geometry)
.filterMetadata('CLOUD_COVER', 'less_than', cloud_tresh);
// MOD16A2.006: Terra Net Evapotranspiration 8-Day Global 500m (For validation)
var MOD16A2 = ee.ImageCollection('MODIS/006/MOD16A2');
// Merging Landsat collections
var Landsat_col = L5_SR.select([0,1,2,3,4,5,6])
  .merge(L8_SR.select([0,1,2,3,4,5,6]))
var Landsat_SR_Collection = Landsat_col.map(function(img){
              var d = ee.Date(ee.Number(img.get('system:time_start')));
              var date = d.format('yyyy-MM-dd');
              var millis = ee.Date(date).millis();
              var DOY = ee.Number(d.format('DDD'));
              var day = ee.Number(d.get('day'));
              var m = ee.Number(d.get('month'));
              var y = ee.Number(d.get('year'));
              return img.set({'day':day,'month':m, 'year':y,'date':date,'millis':millis,'DOY':DOY});
            });
// ======================================================= FUNCTIONS =================================================================== 
// Functions to stack image colletion series into image bands  
var stackCollection = function(collection) {
  // Create an initial image.
  var first = ee.Image(collection.first()).select([]);
  // Write a function that appends a band to an image.
  var appendBands = function(image, previous) 
  {return ee.Image(previous).addBands(image);};
  return ee.Image(collection.iterate(appendBands, first));};
// Function to apply weighting values to compute refelectance factor 
function reflctValues (image){return image.multiply(0.0001)}
// ------------------------------------------------------ Function to delete clouds (START) ---------------------------------------------------
var getQABits = function(image, start, end, newName) {
    // Compute the bits we need to extract.
    var pattern = 0;
    for (var i = start; i <= end; i++) {
       pattern += Math.pow(2, i);
    }
    // Return a single band image of the extracted QA bits, giving the band
    // a new name.
    return image.select([0], [newName])
                  .bitwiseAnd(pattern)
                  .rightShift(start);
};
// A function to mask out cloudy pixels.
var cloud_shadows = function(image) {
  // Select the QA band.
  var QA = image.select(['pixel_qa']);
  // Get the internal_cloud_algorithm_flag bit.
  return getQABits(QA, 3,3, 'Cloud_shadows').eq(0);
  // Return an image masking out cloudy areas.
};
// A function to mask out cloudy pixels.
var clouds = function(image) {
  // Select the QA band.
  var QA = image.select(['pixel_qa']);
  // Get the internal_cloud_algorithm_flag bit.
  return getQABits(QA, 5,5, 'Cloud').eq(0);
  // Return an image masking out cloudy areas.
};
var cirrus_shadows = function(image) {
  // Select the QA band.
  var QA = image.select(['sr_aerosol']);
  // Get the internal_cloud_algorithm_flag bit.
  return getQABits(QA, 4,4, 'Cirrus_shadows').eq(0);
  // Return an image masking out cloudy areas.
};
var cirrus_clouds = function(image) {
  // Select the QA band.
  var QA = image.select(['sr_aerosol']);
  // Get the internal_cloud_algorithm_flag bit.
  return getQABits(QA, 3,3, 'Cirrus_cloud').eq(0);
  // Return an image masking out cloudy areas.
};
// A function to mask out cloudy quality pixels.
var cloud_qa = function(image) {
  // Select the QA band.
  var QA = image.select(['sr_cloud_qa']);
  // Get the internal_cloud_algorithm_flag bit.
  return getQABits(QA, 1,1, 'Cloud').eq(0);
  // Return an image masking out cloudy areas.
};
var cloud_qa_shadow = function(image) {
  // Select the QA band.
  var QA = image.select(['sr_cloud_qa']);
  // Get the internal_cloud_algorithm_flag bit.
  return getQABits(QA, 2,2, 'Cloud_shadows').eq(0);
  // Return an image masking out cloudy areas.
};
var adj_cloud_qa = function(image) {
  // Select the QA band.
  var QA = image.select(['sr_cloud_qa']);
  // Get the internal_cloud_algorithm_flag bit.
  return getQABits(QA, 3,3, 'Adjacent_to_Cloud').eq(0);
  // Return an image masking out cloudy areas.
};
var maskClouds_L57 = function(image) {
  var cs = cloud_shadows(image);
  var c = clouds(image);
  var c_qa = cloud_qa(image);
  var cs_qa = cloud_qa_shadow(image);
  var adj_c_qa = adj_cloud_qa(image);
  return image.updateMask(cs)
              .updateMask(c)
              //.updateMask(c_qa)
              //.updateMask(cs_qa)
              .updateMask(adj_c_qa)
              .copyProperties(image,['system:time_start']);
};
var maskClouds_L8 = function(image) {
  var cirrus_cs = cirrus_shadows(image);
  var cirrus_c = cirrus_clouds(image);
  var cs = cloud_shadows(image);
  var c = clouds(image);
  return image.updateMask(cs)
              .updateMask(c)
              .updateMask(cirrus_cs)
              .updateMask(cirrus_c)
              .copyProperties(image,['system:time_start']);
};
// ------------------------------------------------------ Function to delete clouds (END) ---------------------------------------------------
// Landsat scenes in surface reflectance values
var L8_SR_refl = L8_SR.select(['B1','B2','B3','B4','B5','B6','B7']).map(reflctValues);
var L5_SR_refl = L5_SR.select(['B1','B2','B3','B4','B5','B7']).map(reflctValues);
// Compute the Normalized Difference Vegetation Index (NDVI).
var calcNDVIL8 = function(scene) {
  // get a string representation of the date.
  var dateString = ee.Date(scene.get('system:time_start')).format('yyyy-MM-dd');
  var ndvi_col = scene.normalizedDifference(['B5', 'B4']);
  return ndvi_col.rename(dateString);};
var calcNDVIL5 = function(scene) {
  // get a string representation of the date.
  var dateString = ee.Date(scene.get('system:time_start')).format('yyyy-MM-dd');
  var ndvi_col = scene.normalizedDifference(['B4', 'B3']);
  return ndvi_col.rename(dateString);};
// Generate mask for entire Landsat Collection.
function getmask (image) {return image.mask().gt(0).updateMask(image.mask().gt(0)).rename('mask')}
function masking (image) {return image.mask()}
var ndvi_scenesL5 = L5_SR.map(calcNDVIL5);
var maskScenesL5 = ndvi_scenesL5.map(getmask).mean();
var ndvi_scenesL8 = L8_SR.map(calcNDVIL8);
var maskScenesL8 = ndvi_scenesL8.map(getmask).mean();
var maskScenes = maskScenesL5.blend(maskScenesL8);
// Function to generate mask for each Landsat Scene.
var getSceneMask = function(scene) {
  var dateString = ee.Date(scene.get('system:time_start')).format('yyyy-MM-dd');
  var mask_Landsat = scene.select('B1').gt(-9999).updateMask(ee.Image(1));
  return mask_Landsat.rename(dateString);};
var getSceneMaskMillis = function(scene) {
  var dateString = ee.String(ee.Date(scene.get('system:time_start')).millis());
  var mask_Landsat = scene.select('B1').gt(-9999).updateMask(ee.Image(1));
  return mask_Landsat.rename(dateString);};
// Convert the Landsat scene mask to polygon
var Landsat_Scene = maskScenes.int().reduceToVectors({
  scale: 30,geometry: envelope, geometryType:'polygon', eightConnected: false,labelProperty: 'zone',bestEffort:true});
var AI_regression = Landsat_Scene.filter(ee.Filter.eq('zone', 1));
// Function to get bound box for collections
function getboundingBox (feature) {return feature.bounds(1)}
var boundingBox = AI_regression.map(getboundingBox); //Get Bounding box for poly
var boundingBoxAI = boundingBox.geometry(); // convert feature collection to feature
// Surface albedo - Weighting coefficients using SMARTS2 (Tasumi method - Case 1)
var albedo_weight_L5 = ee.Image([0.254,0.149,0.147,0.311,0.103,0.036]).float()
.rename(['B1','B2','B3','B4','B5','B7']);
var albedo_weight_L8 = ee.Image([0.246,0.146,0.191,0.304,0.105,0.008]).float()
.rename(['B2','B3','B4','B5','B6','B7']); // Olmedo et al 2017
// Surface albedo using surface reflectance Landsat bands 
var apllyAlbedoWeightL8 = function(image){return image.multiply(albedo_weight_L8).reduce(ee.Reducer.sum()).rename('albedo')
  .copyProperties(image, ['system:time_start'])};
var apllyAlbedoWeightL5 = function(image){return image.multiply(albedo_weight_L5).reduce(ee.Reducer.sum()).rename('albedo')
  .copyProperties(image, ['system:time_start'])};
// Generic function to get count, mean and sum values from multiband images
var getmeanvalueCol = function(image) {return image.reduceRegion({
  reducer:ee.Reducer.mean(),geometry:boundingBoxAI,scale:30,bestEffort:true,tileScale: 16})};
var getsumvalueCol = function(image) {return image.reduceRegion({
  reducer:ee.Reducer.sum(),geometry:boundingBoxAI,scale:30,bestEffort:true})};
var getcountvalueCol = function(image) {return image.reduceRegion({
  reducer:ee.Reducer.count(),geometry:boundingBoxAI,scale:30,bestEffort:true})};
var getStdvalueCol = function(image) {return image.reduceRegion({
  reducer:ee.Reducer.stdDev(),geometry:boundingBoxAI,scale:30,bestEffort:true})};
// Function to compute sun elevation for Landsat-8 Collection
var getSunElevDate = function(scene) {
  // get a string representation of the date.
  var dateString = ee.Date(scene.get('system:time_start')).format('yyyy-MM-dd');
  var sunelev_str = function(image) {return ee.Image(ee.Number(image.get('SUN_ELEVATION')))};
  var sunelev = sunelev_str(scene);
  return sunelev.rename(dateString);};
// Function to compute sun azimuth for Landsat-8 Collection
var getSunAzimuthDate = function(scene) {
  // get a string representation of the date.
  var dateString = ee.Date(scene.get('system:time_start')).format('yyyy-MM-dd');
  var sunazimuth_str = function(image) {return ee.Image(ee.Number(image.get('SUN_AZIMUTH')))};
  var sunazimuth = sunazimuth_str(scene);
  return sunazimuth.rename(dateString);};
// Get the timestamp and convert it to a date and hour.
var getLandsatTime = function(scene) {
  var dateString = ee.Date(scene.get('system:time_start')).format('yyyy-MM-dd');
  var getDate = function(scene) {return ee.Image(ee.Number(scene.get('system:time_start')))};
  var tms_img = getDate(scene);
  var tms_img_rename = tms_img.rename(dateString);
  var getmeanDate = function(scene) {return scene.reduceRegion({
  reducer:ee.Reducer.mean(),geometry:boundingBoxAI,scale:1000,bestEffort:true}).get(dateString)};
  var hour = ee.Date(getmeanDate(tms_img_rename)).get('hour');
  var minute = ee.Date(getmeanDate(tms_img_rename)).get('minute');
  var second = ee.Date(getmeanDate(tms_img_rename)).get('second');
  var fr_second = ee.Date(getmeanDate(tms_img_rename)).getFraction('second');
  return ee.Image(ee.Number(hour).add(ee.Number(minute).divide(60)).add((ee.Number(second).add(ee.Number(fr_second))).divide(3600))).rename(dateString);};
// Forest function (get the percent threshold of NDVI value)
var getForest = function(image){return image.reduceRegion({
  reducer:ee.Reducer.percentile([ndvi_percent]),geometry:boundingBoxAI,scale:30,bestEffort:true})};
//============================================== MASKING AND DATELIST =================================================================
//Mask for each Landsat scene
var MaskL5_temp = stackCollection(L5_SR.map(getSceneMask));
var MaskL8_temp = stackCollection(L8_SR.map(getSceneMask));
var MaskLandsat_temp = MaskL5_temp.addBands(MaskL8_temp);
// Get date List from name bands of Landsat mask
var datelistDOY = ee.List(MaskLandsat_temp.bandNames()).map(function(date){return ee.Date(date).format('DDD')});
var datelistL5 = ee.List(MaskL5_temp.bandNames()).map(function(date){return ee.Date(date).format('yyyy-MM-dd')});
var datelistL8 = ee.List(MaskL8_temp.bandNames()).map(function(date){return ee.Date(date).format('yyyy-MM-dd')});
var datelist = ee.List(MaskLandsat_temp.bandNames()).map(function(date){return ee.Date(date).format('yyyy-MM-dd')});
var datelistFull = ee.List(MaskLandsat_temp.bandNames()).map(function(date){return ee.Date(date).format('yyyy-MM-dd-HH')});
var datelistMilli = ee.List(MaskLandsat_temp.bandNames()).map(function(date){return ee.Date(date).millis()});
// Count Landsat Scenes
var CountImages = ee.Number(datelist.length());
// Count 6-hourly bands
var CountBands = CountImages.multiply(4);
//Mask for each Landsat scene (rename to YYYY-MM-DD)
var MaskL5 = MaskL5_temp.rename(datelistL5);
var MaskL8 = MaskL8_temp.rename(datelistL8);
var MaskLandsat = MaskL5.addBands(MaskL8);
// Mask Core scene
var maskCoreScene = (((MaskLandsat.reduce(ee.Reducer.sum())).divide(CountImages)).gte(0.95))
  .updateMask(((MaskLandsat.reduce(ee.Reducer.sum())).divide(CountImages)).gte(0.95));
var maskAllScenes = (((MaskLandsat.reduce(ee.Reducer.sum())).divide(CountImages)).gte(0))
  .updateMask(((MaskLandsat.reduce(ee.Reducer.sum())).divide(CountImages)).gte(0));
var maskCenterScene = (((MaskLandsat.reduce(ee.Reducer.sum())).divide(CountImages)).gte(1))
  .updateMask(((MaskLandsat.reduce(ee.Reducer.sum())).divide(CountImages)).gte(1));
var MaskLandsat_dates = ee.Image.constant(ee.List.repeat(1, CountImages)).int().mask(maskAllScenes).rename(datelist);
// Get hourly date list from selected scenes
var datelistStart00 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).format('yyyy-MM-dd-HH')});
var datelistStart06 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).advance(6,'hour').format('yyyy-MM-dd-HH')});
var datelistStart12 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).advance(12,'hour').format('yyyy-MM-dd-HH')});
var datelistStart18 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).advance(18,'hour').format('yyyy-MM-dd-HH')});
var datelistStart00d = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).advance(24,'hour').format('yyyy-MM-dd-HH')});
// Get hourly date list for CFSv2 selection 
var datelistStart00_v2 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).format('yyyyMMddHH')});
var datelistStart06_v2 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).advance(6,'hour').format('yyyyMMddHH')});
var datelistStart12_v2 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).advance(12,'hour').format('yyyyMMddHH')});
var datelistStart18_v2 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).advance(18,'hour').format('yyyyMMddHH')});
var datelistStart00d_v2 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).advance(24,'hour').format('yyyyMMddHH')});
// Concatenate date list for each 6 hours
var datelistCFSv2 = (datelistStart00.cat(datelistStart06)
  .cat(datelistStart12).cat(datelistStart18)).sort();
var datelistCFSv2_v2 = (datelistStart00_v2.cat(datelistStart06_v2)
  .cat(datelistStart12_v2).cat(datelistStart18_v2)).sort();
//===================================================== LANDSAT RAW AND TOA COLLECTION =================================================================== 
// Landsat-5 TOA collection
var L5_collection = ee.ImageCollection('LANDSAT/LT05/C01/T1_TOA');
var L5_TOA = L5_collection.filter(ee.Filter.calendarRange(StartYear, EndYear,'year'))
.filterBounds(geometry)
.filter(ee.Filter.inList("DATE_ACQUIRED",datelistL5));
var L5_collection_raw = ee.ImageCollection('LANDSAT/LT05/C01/T1');
var L5_raw = L5_collection_raw.filter(ee.Filter.calendarRange(StartYear, EndYear,'year'))
.filterBounds(geometry)
.filter(ee.Filter.inList("DATE_ACQUIRED",datelistL5));
// Landsat-8 TOA collection
var L8_TOA_collection = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA');
var L8_TOA = L8_TOA_collection.filter(ee.Filter.calendarRange(StartYear, EndYear,'year'))
.filterBounds(geometry)
.filter(ee.Filter.inList("DATE_ACQUIRED",datelistL8));
var L8_collection_raw = ee.ImageCollection('LANDSAT/LC08/C01/T1');
var L8_raw = L8_collection_raw.filter(ee.Filter.calendarRange(StartYear, EndYear,'year'))
.filterBounds(geometry)
.filter(ee.Filter.inList("DATE_ACQUIRED",datelistL8));
// ========================== calculate Albedo for entire Landsat collection (with mask clouds) ===========================================
// Albedo from original surface reflectance data
var albedo_L5_col = L5_SR.map(function(img){
  var d = ee.Date(ee.Number(img.get('system:time_start')));
  var millis = d.millis();
  var reflect = img.select(['B1','B2','B3','B4','B5','B7']).multiply(0.0001);
  var weight = ee.Image([0.254,0.149,0.147,0.311,0.103,0.036]).float()
  .rename(['B1','B2','B3','B4','B5','B7']);
  var albedo = reflect.multiply(weight).reduce(ee.Reducer.sum());
  return albedo.rename('albedo').set({'system:time_start':millis})});
var albedo_L8_col = L8_SR.map(function(img){
  var d = ee.Date(ee.Number(img.get('system:time_start')));
  var millis = d.millis();
  var reflect = img.select(['B1','B2','B3','B4','B5','B6','B7']).multiply(0.0001);
  var reflect2 = img.select(['B2','B3','B4','B5','B6','B7']).multiply(0.0001);
  var weight = ee.Image([0.1269,0.1111,0.1271,0.1733,0.2872,0.1250,0.0494]).float()
  .rename(['B1','B2','B3','B4','B5','B6','B7']);
  var weight_olmedo = ee.Image([0.246,0.146,0.191,0.304,0.105,0.008]).float()
  .rename(['B2','B3','B4','B5','B6','B7']);
  var albedo = reflect.multiply(weight).reduce(ee.Reducer.sum());
  var albedo_olm = reflect2.multiply(weight_olmedo).reduce(ee.Reducer.sum());
  return albedo_olm.rename('albedo').set({'system:time_start':millis})});
var albedo_L58 = albedo_L5_col.merge(albedo_L8_col).sort('system:time_start', true);
var albedo_temp = stackCollection(albedo_L58).rename(datelist);
// =================================================== MASKING CLOUDS =================================================================== 
// Generate NoClouds mask for Landsat collection
var NC_mask_col_L57 = (L5_SR.map(maskClouds_L57)).map(function(image){
  return image.select('B1').gt(-9999).rename('NC').copyProperties(image,['system:time_start'])});
var NoCloudsMaskL5 = stackCollection(NC_mask_col_L57).rename(datelistL5)
var NC_mask_col_L8 = (L8_SR.map(maskClouds_L8)).map(function(image){
  return image.select('B1').gt(-9999).rename('NC').copyProperties(image,['system:time_start'])});
var NoCloudsMaskL8 = stackCollection(NC_mask_col_L8).rename(datelistL8)
var NC_mask_col = NC_mask_col_L57.merge(NC_mask_col_L8).sort('system:time_start', true);
//Mask Cloud pixels for each Landsat scene
var NoCloudsMask_temp1 = stackCollection(NC_mask_col).rename(datelist).where(albedo_temp.gte(0.6),100);
var NoCloudsMask = NoCloudsMask_temp1.updateMask(NoCloudsMask_temp1.neq(100)).rename(datelist);
// Compute albedo with final cloud mask 
var albedo = albedo_temp.mask(NoCloudsMask).rename(datelist);
// ============================================== METEOROLOGICAL PRE-PROCESSING DATA ===================================================================
// Select a NCEP CFSv2 6-hourly products for each date
var CFSv2_date = CFSv2_collection.filter(ee.Filter.inList("system:index",datelistCFSv2_v2));
// Select and stack variable series into image bands
var Tmin_date = stackCollection(CFSv2_date.select('Minimum_temperature_height_above_ground_6_Hour_Interval')).rename(datelistCFSv2);
var Tmax_date = stackCollection(CFSv2_date.select('Maximum_temperature_height_above_ground_6_Hour_Interval')).rename(datelistCFSv2);
var Tair_date = stackCollection(CFSv2_date.select('Temperature_height_above_ground')).rename(datelistCFSv2);
var Wind_U_date = stackCollection(CFSv2_date.select('u-component_of_wind_height_above_ground')).rename(datelistCFSv2);
var Wind_V_date = stackCollection(CFSv2_date.select('v-component_of_wind_height_above_ground')).rename(datelistCFSv2);
var Wind_date = Wind_U_date.expression('sqrt(u**2 + v**2)',{'u':Wind_U_date,'v':Wind_V_date});
var SWdown_date = stackCollection(CFSv2_date.select('Downward_Short-Wave_Radiation_Flux_surface_6_Hour_Average')).rename(datelistCFSv2);
var Qair_date = stackCollection(CFSv2_date.select('Specific_humidity_height_above_ground')).rename(datelistCFSv2);
var Psurf_date = stackCollection(CFSv2_date.select('Pressure_surface')).rename(datelistCFSv2);
// CALCULATE DAILY MEAN
// --- create a list with limits where to slice bands
var cut_list = ee.List.sequence(0, CountBands.subtract(4), 4);
// --- create a list of daily images
var Tmin_daily_images_list = cut_list.map(function (cut) {
    var cut_end = ee.Number(cut).add(4);
    return ee.Image(Tmin_date).slice(ee.Number(cut), cut_end);});
var Tmax_daily_images_list = cut_list.map(function (cut) {
    var cut_end = ee.Number(cut).add(4);
    return ee.Image(Tmax_date).slice(ee.Number(cut), cut_end);});
var Tair_daily_images_list = cut_list.map(function (cut) {
    var cut_end = ee.Number(cut).add(4);
    return ee.Image(Tair_date).slice(ee.Number(cut), cut_end);});
var Wind_daily_images_list = cut_list.map(function (cut) {
    var cut_end = ee.Number(cut).add(4);
    return ee.Image(Wind_date).slice(ee.Number(cut), cut_end);});
var Qair_daily_images_list = cut_list.map(function (cut) {
    var cut_end = ee.Number(cut).add(4);
    return ee.Image(Qair_date).slice(ee.Number(cut), cut_end);});
var Psurf_daily_images_list = cut_list.map(function (cut) {
    var cut_end = ee.Number(cut).add(4);
    return ee.Image(Psurf_date).slice(ee.Number(cut), cut_end);});
var SWdown_daily_images_list = cut_list.map(function (cut) {
    var cut_end = ee.Number(cut).add(4);
    return ee.Image(SWdown_date).slice(ee.Number(cut), cut_end);});
// --- create a list of daily images containing the min, max and mean values
var Tmin_daily_list = ee.ImageCollection(Tmin_daily_images_list).map(function(image) {
    return ee.Image(image).reduce(ee.Reducer.min());});
var Tmax_daily_list = ee.ImageCollection(Tmax_daily_images_list).map(function(image) {
    return ee.Image(image).reduce(ee.Reducer.max());});
var Tair_daily_means_list = ee.ImageCollection(Tair_daily_images_list).map(function(image) {
    return ee.Image(image).reduce(ee.Reducer.mean());});
var Wind_daily_means_list = ee.ImageCollection(Wind_daily_images_list).map(function(image) {
    return ee.Image(image).reduce(ee.Reducer.mean());});
var Qair_daily_means_list = ee.ImageCollection(Qair_daily_images_list).map(function(image) {
    return ee.Image(image).reduce(ee.Reducer.mean());});
var Psurf_daily_means_list = ee.ImageCollection(Psurf_daily_images_list).map(function(image) {
    return ee.Image(image).reduce(ee.Reducer.mean());});
var SWdown_daily_means_list = ee.ImageCollection(SWdown_daily_images_list).map(function(image) {
    return ee.Image(image).reduce(ee.Reducer.mean());});
// Stack daily min, max and mean images into date bands
var Tmin_daily_min = stackCollection(Tmin_daily_list).rename(datelist).resample('bilinear').mask(MaskLandsat_dates);
var Tmax_daily_max = stackCollection(Tmax_daily_list).rename(datelist).resample('bilinear').mask(MaskLandsat_dates);
var Tair_daily_mean = stackCollection(Tair_daily_means_list).rename(datelist).resample('bilinear').mask(MaskLandsat_dates);
var Wind_daily_mean = stackCollection(Wind_daily_means_list).rename(datelist).resample('bilinear').mask(MaskLandsat_dates);
var Qair_daily_mean = stackCollection(Qair_daily_means_list).rename(datelist).resample('bilinear').mask(MaskLandsat_dates);
var Psurf_daily_mean = stackCollection(Psurf_daily_means_list).rename(datelist).resample('bilinear').mask(MaskLandsat_dates);
var SWdown_daily_mean = stackCollection(SWdown_daily_means_list).rename(datelist).resample('bilinear').mask(MaskLandsat_dates);
// Unit conversions
var Tmin_daily_min_C = Tmin_daily_min.subtract(273.15);
var Tmax_daily_max_C = Tmax_daily_max.subtract(273.15);
var Tair_daily_mean_C = Tair_daily_mean.subtract(273.15);
var Tmin_date_C = Tmin_date.subtract(273.15);
var Tmax_date_C = Tmax_date.subtract(273.15);
var Tair_date_C = Tair_date.subtract(273.15);
var Psurf_daily_mean_kpa = Psurf_daily_mean.multiply(0.001);
var Psurf_date_kpa = Psurf_date.multiply(0.001);
// ======================================== Terrain and Astronomical parameters =====================================================
// Generate a 6-hourly band mask
var value_6hourly = ee.List.repeat(1, CountBands);
var MaskAI_6hourly = (ee.Dictionary.fromLists(datelistCFSv2, value_6hourly)).toImage(datelistCFSv2).mask(maskScenes);
// Add the SRTMGL1 Digital Elevation Model and clip with Landsat mask
var DEM = DEM_input.mask(maskScenes);
var slp = ee.Terrain.slope(DEM);
var slp_rad = slp.multiply(0.017453293);
var asp = ee.Terrain.aspect(DEM);
var asp_rad = (asp.multiply(0.017453293)).subtract(3.14159265359);
//var maskdem = DEM.mask();
var P_mbar = DEM.expression('(101.3*((293-0.0065*z)/293)**5.26)*10',{'z': DEM});
var P_kPa = DEM.expression('101.3*((293-0.0065*z)/293)**5.26',{'z': DEM});
var P_calc_Kpa = P_kPa;
var P_calc_Pa = P_calc_Kpa.multiply(1000);
// Generate Latitude and Longitude raster
var Lat = ee.Image.pixelLonLat().select('latitude').mask(maskScenes);
var Lat_rad = Lat.multiply(0.017453293);
var Long = ee.Image.pixelLonLat().select('longitude').mask(maskScenes).rename('constant');
var Long_rad = Long.multiply(0.017453293);
// Get sun elevation and azimuth for Landsat Collection
var sunelev_L8 = stackCollection(L8_TOA.map(getSunElevDate));
var sunelev_L5 = stackCollection(L5_TOA.map(getSunElevDate));
var sunelev = sunelev_L5.addBands(sunelev_L8).mask(MaskLandsat).rename(datelist);
var sunazim_L8 = stackCollection(L8_TOA.map(getSunAzimuthDate));
var sunazim_L5 = stackCollection(L5_TOA.map(getSunAzimuthDate));
var sunazimuth = sunazim_L5.addBands(sunazim_L8).mask(MaskLandsat).rename(datelist);
// Get Landsat UTC time for entire collection
var tms_img_L8_temp = L8_TOA.map(getLandsatTime);
var tms_img_L5_temp = L5_TOA.map(getLandsatTime);
var L8_UTC_time = stackCollection(tms_img_L8_temp);
var L5_UTC_time = stackCollection(tms_img_L5_temp);
var LandsatTimeUTC = L5_UTC_time.addBands(L8_UTC_time).mask(MaskLandsat).rename(datelist);
// Get the UTC zone of the Landsat scene.
var getmeanvalue = function(image) {return image.reduceRegion({
  reducer:ee.Reducer.mean(),geometry:boundingBoxAI,scale:1000,bestEffort:true}).get('constant')};
var Mean_Long = getmeanvalue(Long);
var UTC_zone_number = (ee.Number(Mean_Long).divide(ee.Number(15)));
var UTC_zone_temp = UTC_zone_number.round();
var UTC_zone = MaskLandsat.multiply(UTC_zone_temp).rename(datelist);
// Generate the slope, aspect and sun angles rasters
var slope = ee.Terrain.slope(DEM);
var asp = ee.Terrain.aspect(DEM);
var sunzenith = ee.Image(90).subtract(sunelev);
// Clip the terrain and Sun angles using the Landsat mask.
var slope_clip = slope.mask(maskScenes);
var asp_clip = asp.mask(maskScenes);
var sunzenith_clip = sunzenith.mask(MaskLandsat);
var sunazimuth_clip = sunazimuth.mask(MaskLandsat);
// Conversion to radian (pi/180 = 0.0174532925199433)
var aspect_rad = asp_clip.multiply(0.0174532925199433);
var asp_rad = (asp_clip.multiply(0.0174532925199433)).subtract(3.14159265359);
var sunzenith_rad = sunzenith_clip.multiply(0.0174532925199433);
var sunazimuth_rad = sunazimuth_clip.multiply(0.0174532925199433);
var slope_rad = slope_clip.multiply(0.0174532925199433);
//create date band (day of  year - DOY) for each image in collection
var addDate = function(image){
  var doy = image.date().getRelative('day', 'year');
  var doyBand = ee.Image.constant(doy).uint16().rename('doy');
  return image.addBands(doyBand).add(ee.Number(1));};
var withDateL5 = L5_SR.map(addDate).select('doy');
var withDateL8 = L8_SR.map(addDate).select('doy');
var DOY_L5 = stackCollection(withDateL5);
var DOY_L8 = stackCollection(withDateL8);
var DOY = DOY_L5.addBands(DOY_L8).rename(datelist).mask(MaskLandsat);
// Compute sun angles and astronomical parameters (daily)
var Lz // longitude of the center of the local time zone (integer)
= Long.expression('(6*(int(Long/6)))+3',{'Long':Long});
var TimeZone = UTC_zone;
var B_eqTime = ((DOY.subtract(ee.Image(1))).multiply(ee.Image(360).divide(ee.Image(365)))).multiply(ee.Image(0.0174532925199433));
var EqTime = B_eqTime.expression('229.2*(0.000075+0.001868*cos(B)-0.032077*sin(B)-0.014615*cos(2*B)-0.04089*sin(2*B))',
{'B':B_eqTime});
var SolarTimeUTC = ee.Image(LandsatTimeUTC).mask(MaskLandsat).expression('UTC+(4*(Lst-Lloc)+E)/60'
  ,{'UTC':ee.Image(LandsatTimeUTC).mask(MaskLandsat),'Lst':Lz,'Lloc':Long,'E':EqTime});
var sun_decl = DOY.expression('23.45*sin(2*PI*((284+DOY)/365))',{'DOY':DOY,'PI':3.14159265358979});
var sun_decl_rad = DOY.expression('0.409*sin((2*PI/365)*DOY-1.39)',{'DOY':DOY,'PI':3.14159265358979});
var es_dist = DOY.expression('1+0.033*cos(2*PI/365*DOY)',{'DOY':DOY,'PI':3.14159265358979});
var sunset_h = ((Lat_rad.multiply(-1).tan().multiply(sun_decl_rad.tan())).acos()).multiply(57.29577951);
var sunset_h_rad = Lat_rad.expression('acos(-tan(Lat) * tan(decl))',{'Lat':Lat_rad,'decl':sun_decl_rad});
var hour_angle = ((SolarTimeUTC.add(ee.Image(TimeZone))).subtract(ee.Image(12))).multiply(ee.Image(15));
var hour_angle_rad_temp = hour_angle.multiply(0.0174532925199433);
var hour_angle_rad = hour_angle_rad_temp.where(hour_angle_rad_temp.lt(-3.141592654),-3.141592654);
var cosZ = Lat_rad.expression('cos(Lat)*cos(decl)*cos(h_ang)+sin(Lat)*sin(decl)',
{'Lat':Lat_rad,'decl':sun_decl_rad,'h_ang':hour_angle_rad});
var day_ang = DOY.expression('2*3.14159265358979*((doy-1)/365)',{'doy':DOY});
var E0 = day_ang.expression('1.00011+0.034221*cos(d)+0.00128*sin(d)+0.000719*cos(2*d)+0.000077*sin(2*d)',{'d':day_ang});
// Computation of Cosine of the Solar Incidence Angle (cosi) (daily)
var Ltime = SolarTimeUTC.add(UTC_zone);
var b = DOY.expression('(2*3.14159265359*(DOY-81))/364',{'DOY':DOY});
var Sc // Seasonal correction for solar time
= b.expression('(0.1645*sin(2*b)-0.1255*cos(b)-0.025*sin(b))',{'b':b});
var h_ang // hour angle (in radians) 
= Long.expression('3.14159265359/12*((Ltime+0.06667*(Lz-Long)+Sc)-12)',
{'Ltime':Ltime,'Lz':Lz,'Long':Long,'Sc':Sc});
var cosi1 // Cosine of the Solar Incidence Angle
= sun_decl_rad.expression('sin(SD)*sin(Lat)*cos(slp)-sin(SD)*cos(Lat)*sin(slp)*cos(asp)+cos(SD)*cos(Lat)*cos(slp)*cos(h_ang)+cos(SD)*sin(Lat)*sin(slp)*cos(asp)*cos(h_ang)+cos(SD)*sin(asp)*sin(slp)*sin(h_ang)'
,{'SD':sun_decl_rad,'Lat':Lat_rad,'slp':slope_rad,'asp':asp_rad,'h_ang':hour_angle_rad});
var cosi // Corrected Cosine of the Solar Incidence Angle (replace negative values to 0) 
= cosi1.where(cosi1.lt(0),0.001).where(slope_clip.eq(0),cosZ).mask(MaskLandsat);
// Create Non-self shadow mask
var nonselfshadowmask = cosi1.gte(cosi_threshold).updateMask(cosi1.gte(cosi_threshold));
// ========================== calculate NDVI for entire Landsat collection (with mask clouds) ===========================================
var NDVI_L5_col = L5_SR.map(calcNDVIL5);
var NDVI_L8_col = L8_SR.map(calcNDVIL8);
var NDVI_L5 = stackCollection(NDVI_L5_col);
var NDVI_L8 = stackCollection(NDVI_L8_col);
var NDVI = NDVI_L5.addBands(NDVI_L8).rename(datelist);
var NDVI_NC = NDVI.mask(NoCloudsMask);
//====================================== START OF REFERENCE EVAPOTRANSPIRATION COMPUTATION ================================================
// Compute Weather parameters
// Saturation Vapor Pressure (es) for 6-hourly interval
var e0_Tmin_6h = Tmin_date_C.expression('0.6108 * exp((17.27 * T) / (T + 237.3))',{'T': Tmin_date_C});
var e0_Tmax_6h = Tmax_date_C.expression('0.6108 * exp((17.27 * T) / (T + 237.3))',{'T': Tmax_date_C});
var es_kPa_6h = (e0_Tmin_6h.add(e0_Tmax_6h)).divide(2);
// Saturation Vapor Pressure (es) for daily interval
var e0_Tmin = Tmin_daily_min_C.expression('0.6108 * exp((17.27 * T) / (T + 237.3))',{'T': Tmin_daily_min_C});
var e0_Tmax = Tmax_daily_max_C.expression('0.6108 * exp((17.27 * T) / (T + 237.3))',{'T': Tmax_daily_max_C});
var es_kPa = (e0_Tmin.add(e0_Tmax)).divide(2);
// Actual Vapor Pressure (ea) for 6-hourly interval (Ref.: Pohl et al. 2015 - Appendix A)
var mix_ratio_6h = Qair_date.divide(ee.Image(1).subtract(Qair_date));
var ea_Pa_6h = (P_calc_Pa.multiply(mix_ratio_6h)).divide(mix_ratio_6h.add(0.622));
var ea_kPa_6h = ea_Pa_6h.multiply(0.001);
// Actual Vapor Pressure (ea) for daily interval (Ref.: Pohl et al. 2015 - Appendix A)
var mix_ratio = Qair_daily_mean.divide(ee.Image(1).subtract(Qair_daily_mean));
var ea_Pa = (P_calc_Pa.multiply(mix_ratio)).divide(mix_ratio.add(0.622));
var ea_kPa = ea_Pa.multiply(0.001);
// Relative Humidity
var RH_daily = (ea_kPa.divide(es_kPa)).multiply(100); // Relative humidity
// Psychrometric and Atmospheric Variables
var DPV = es_kPa.subtract(ea_kPa);
var psy = ee.Image(0.000665).multiply(P_calc_Kpa);
var delta = Tair_daily_mean.expression('(2503 * exp((17.27 * T) / (T + 237.3))) / ((T + 237.3)**2)', {
'T': Tair_daily_mean_C});
var wind2m_gr = Wind_daily_mean.expression('uz*(4.87/(log(67.8*zw-5.42)))',
{'uz':Wind_daily_mean,'zw':10});
var d = ee.Image(0.67).multiply(0.5);
var z0m = ee.Image(0.123).multiply(0.5);
var wind2m_alf = Wind_daily_mean.expression('uz*(log((2-d)/z0m)/(log((zw-d)/z0m)))',
{'uz':Wind_daily_mean,'zw':10,'d':d,'z0m':z0m});
// Precipitable water-vapour thickness under the actual conditions (mm)
var W_mm = (ee.Image(0.14).multiply(ea_kPa).multiply(P_calc_Kpa).add(ee.Image(2.1)));
var W_mm_6h = (ee.Image(0.14).multiply(ea_kPa_6h).multiply(P_calc_Kpa).add(ee.Image(2.1)));
// Radiation parameters
var sin_24h_temp = Lat_rad.expression('sin(0.85 + 0.3 * Lat * sin(2*PI/365 * DOY - 1.39)-0.42 * Lat**2)',
{'Lat':Lat_rad,'PI':3.14159265358979,'DOY': DOY });
var sin_24h = sin_24h_temp.where(sin_24h_temp.lt(0),0);
var KB_temp = P_calc_Kpa.expression('0.977*exp((-0.00146*P)/(Kt*sinLat)-0.075*(W/sinLat)**0.4)',
{'P':P_calc_Kpa, 'Kt':Kt, 'sinLat': sin_24h, 'W': W_mm});
var KB = KB_temp.where(sin_24h.eq(0),0);
var KD_temp = (KB.where(KB.gte(0.15),ee.Image(0.35).subtract(ee.Image(0.36).multiply(KB))))
.where(KB.lt(0.15),ee.Image(0.18).add(ee.Image(0.82).multiply(KB)));
var KD = KD_temp.where(KD_temp.lt(0),0);
var Ra_hor = Lat_rad.expression(
    '24/3.14159265358979 * Gsc * dr * (ws * sin(Lat) * sin(decl) + cos(Lat) * cos(decl) * sin(ws))', 
    {'Gsc': Gsc_h, 'dr': es_dist,'ws': sunset_h_rad, 'Lat': Lat_rad, 'decl': sun_decl_rad,});
var Rs_hor = SWdown_daily_mean.multiply(ee.Number(86400).divide(ee.Number(1000000)));// Conversion from W.m² to MJ.m².d
var Rns_hor = (ee.Image(1).subtract(albedo_mean)).multiply(Rs_hor);
var Rso_hor = (KB.add(KD)).multiply(Ra_hor);
var Rns_hor = (ee.Image(1).subtract(albedo_mean)).multiply(Rs_hor);
var Rs_Rso = (Rs_hor.divide(Rso_hor)).where((Rs_hor.divide(Rso_hor)).gt(1),ee.Image(1.0));
var fcd_day_hor = ee.Image(1.35).multiply(Rs_Rso).subtract(ee.Image(0.35));
var fcd_hor = fcd_day_hor.where(Rs_Rso.lt(0.3),ee.Image(0.0));
var Rnl_hor = ea_kPa.expression('sigma*fcd*(0.34-0.14*sqrt(ea))*Tk**4',
{'sigma':sigma,'fcd':fcd_hor,'ea':ea_kPa,'Tk':Tair_daily_mean});
var Rn_hor = Rns_hor.subtract(Rnl_hor);
var Rn_hor_Wm2_temp = Rn_hor.multiply(ee.Number(1000000).divide(ee.Number(86400))); // Conversion from MJ.m².d to W.m² 
var Rn_hor_Wm2 = Rn_hor_Wm2_temp.where(Rn_hor_Wm2_temp.lt(0),0); 
var Cn_gr = 900;
var Cn_alf = 1600;
var Cd_gr = 0.34;
var Cd_alf = 0.38;
var ET0_gr_24h_hor_temp = delta.expression('(0.408*delta*(Rn)+psy*(Cn/(TC+273))*wind*(es-ea))/(delta+psy*(1+Cd*wind))',{
  'delta': delta,
  'Rn':Rn_hor,
  'psy':psy,
  'Cn':Cn_gr,
  'TC':Tair_daily_mean_C,
  'wind':wind2m_gr,
  'es':es_kPa,
  'ea':ea_kPa,
  'Cd':Cd_gr
});
var ET0_alf_24h_hor_temp = delta.expression('(0.408*delta*(Rn)+psy*(Cn/(TC+273))*wind*(es-ea))/(delta+psy*(1+Cd*wind))',{
  'delta': delta,
  'Rn':Rn_hor,
  'psy':psy,
  'Cn':Cn_alf,
  'TC':Tair_daily_mean_C,
  'wind':wind2m_alf,
  'es':es_kPa,
  'ea':ea_kPa,
  'Cd':Cd_alf
});
// Set zero or negative values to 0.01
var ET0_gr_24h_hor = ET0_gr_24h_hor_temp.where(ET0_gr_24h_hor_temp.lte(0),0.01);
var ET0_alf_24h_hor = ET0_alf_24h_hor_temp.where(ET0_alf_24h_hor_temp.lte(0),ET0_gr_24h_hor);
var scaling_coef_k_temp = ET0_alf_24h_hor.divide(ET0_gr_24h_hor); // For SSEBop ETa computation
var scaling_coef_k = scaling_coef_k_temp.where(scaling_coef_k_temp.lte(0),0.01);
//======================================== START OF SURFACE ENERGY BALANCE USING SEBAL/METRIC METHOD =============================================
// Landsat Spectral bands
var nir_L5 = stackCollection(L5_SR_refl.select('B4'));
var nir_L8 = stackCollection(L8_SR_refl.select('B5'));
var nir = nir_L5.addBands(nir_L8).rename(datelist);
var red_L5 = stackCollection(L5_SR_refl.select('B3'));
var red_L8 = stackCollection(L8_SR_refl.select('B4'));
var red = red_L5.addBands(red_L8).rename(datelist);
var green_L5 = stackCollection(L5_SR_refl.select('B2'));
var green_L8 = stackCollection(L8_SR_refl.select('B3'));
var green = green_L5.addBands(green_L8).rename(datelist);
var blue_L5 = stackCollection(L5_SR_refl.select('B1'));
var blue_L8 = stackCollection(L8_SR_refl.select('B2'));
var blue = blue_L5.addBands(blue_L8).rename(datelist);
var swir1_L5 = stackCollection(L5_SR_refl.select('B5'));
var swir1_L8 = stackCollection(L8_SR_refl.select('B6'));
var swir1 = swir1_L5.addBands(swir1_L8).rename(datelist);
var swir2_L5 = stackCollection(L5_SR_refl.select('B7'));
var swir2_L8 = stackCollection(L8_SR_refl.select('B7'));
var swir2 = swir2_L5.addBands(swir2_L8).rename(datelist);
// Landsat Spectral Indices
var ndmi // Normalized Difference Moisture Index (NDMI)
= nir.expression('(B5-B6)/(B5+B6)',{'B5':nir,'B6':swir1}).rename('ndmi');
var nbr // Normalized Burn Ratio (NBR)
= nir.expression('(B5-B7)/(B5+B7)',{'B5':nir,'B7':swir2}).rename('nbr');
var nbr2 // Normalized Burn Ratio 2 (NBR2)
= swir1.expression('(B6-B7)/(B6+B7)',{'B6':swir1,'B7':swir2}).rename('nbr2');
var bi // bare soil index (BI)
= swir2.expression('((B7+B4)-(B5+B2))/((B7+B4)+(B5+B2))',
{'B2':blue,'B4':red,'B5':nir,'B7':swir2}).rename('bi');
var ndsi // normalized  difference  soil  index  (NDSI)
= swir1.expression('(B6-B5)/(B6+B5)',{'B6':swir1,'B5':nir}).rename('ndsi');
// Modified Normalized Difference Water Index (MNDWI)
var mndwi = green.expression('(green - swir1)/(green + swir1)',
{'green':green,'swir1':swir1});
// Function to extract parameters for Landsat time (To select NCEP/CFSv2 data)
var getmean = function(image) {return image.reduceRegion({
  reducer:ee.Reducer.mean(),geometry:boundingBoxAI,scale:1000,bestEffort:true})};
// Select the UTC time between Landsat overpass using as reference the NCEP/CFSv2 initialization time (0,6,12,18 UTC) 
var RefUTC = ee.Image(LandsatTimeUTC);
var Initial_TimeUTC_image = ((MaskLandsat.multiply(0)).where(RefUTC.gt(0),0)).where(RefUTC.gt(6),6).where(RefUTC.gt(12),12)
.where(RefUTC.gt(18),18).where(RefUTC.gt(21),0);
var RefUTC_T1_image = Initial_TimeUTC_image.reduce(ee.Reducer.last());
var RefUTC_T2_image = Initial_TimeUTC_image.reduce(ee.Reducer.last()).add(6);
var RefUTC_T1 = ee.Number(getmean(RefUTC_T1_image).get('last')).floor();
var RefUTC_T2 = ee.Number(getmean(RefUTC_T2_image).get('last')).floor();
var datelistStartT1 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).advance(RefUTC_T1,'hour').format('yyyy-MM-dd-HH')});
var datelistStartT2 = ee.List(MaskLandsat.bandNames()).map(function(date){return ee.Date(date).advance(RefUTC_T2,'hour').format('yyyy-MM-dd-HH')});
var getValueLT = function(image){return image.expression('VT1+((VT2-VT1)*(LT-T1))/(T2-T1)',
{'VT1':image.select(datelistStartT1),'VT2':image.select(datelistStartT2),'LT':LandsatTimeUTC,'T1':RefUTC_T1,'T2':RefUTC_T2})};
// Compute Weather parameters for Landsat overpass Time (LT)
var e0_kPa_LT = getValueLT(es_kPa_6h).rename(datelist).mask(MaskLandsat);
var ea_kPa_LT = getValueLT(ea_kPa_6h).rename(datelist).mask(MaskLandsat);
var W_mm_LT = getValueLT(W_mm_6h).rename(datelist).mask(MaskLandsat);
var tsw = P_kPa.expression('0.977*exp((-0.00146*P)/(Kt*cosZ)-0.075*(W/cosZ)**0.4)',
{'P':P_kPa, 'Kt':Kt, 'cosZ': cosZ, 'W': W_mm_LT});
var wind_LT = getValueLT(Wind_date).rename(datelist).mask(MaskLandsat);
var Tair_K_LT = getValueLT(Tair_date).rename(datelist).mask(MaskLandsat);
//-------------------------------- Compute Outgoing Long-Wave Radiation----------------------------------------
// Compute SAVI and LAI
var SAVI_temp = red.expression('((1+L)*(B5-B4))/(L+(B5+B4))',
{'B5':nir,'B4':red,'L':L});
var SAVI = (SAVI_temp.where(SAVI_temp.lt(0.1),0.1)).where(SAVI_temp.gt(0.687),0.687);
var LAI_temp = SAVI.expression('-(log((0.69-SAVI)/0.59)/0.91)',
{'SAVI':SAVI});
var LAI = (LAI_temp.where(SAVI_temp.lt(0.1),0)).where(SAVI_temp.gt(0.687),6.0);
var emiss_e0 // broad-band surface thermal emissivity
= ((MaskLandsat.multiply(0.98)).where(LAI.lte(3),MaskLandsat.multiply(0.95).add((MaskLandsat.multiply(0.01)).multiply(LAI))))
.where(mndwi.gt(0),MaskLandsat.multiply(0.985));
// Compute Surface temperature
var thermal_DN_L5 = stackCollection(L5_raw.select('B6'));
var thermal_rad_L5 = thermal_DN_L5.expression('((LMAX - LMIN)/255) * DN + LMIN',
  {'LMIN':1.2378,'LMAX':15.303,'DN':thermal_DN_L5});
var calcThermalRadL8 = function(image){return ee.Algorithms.Landsat.calibratedRadiance(image)};
var thermal_rad_L8 = stackCollection(L8_raw.select('B10').map(calcThermalRadL8));
var thermal_rad = thermal_rad_L5.addBands(thermal_rad_L8).rename(datelist);
var emiss_eNB // Narrow band surface thermal emissivity
= ((MaskLandsat.multiply(0.98)).where(LAI.lte(3),(MaskLandsat.multiply(0.97))
  .add((MaskLandsat.multiply(0.0033)).multiply(LAI)))).where(mndwi.gt(0),MaskLandsat.multiply(0.985));
var Rp = 0;
var tNB = 1;
var Rsky = Tair_K_LT.expression('(1.807*10**-10)*(Ta**4)*(1-0.26*exp(-7.77*(10**-4)*(273.15-Ta)**2))',
  {'Ta':Tair_K_LT});
var Rc = Rsky.expression('((L-Rp)/tNB)-(1-eNB)*Rsky',
  {'L':thermal_rad,'Rp':Rp,'tNB':tNB,'eNB':emiss_eNB,'Rsky':Rsky});
// Get K1 and K2 for Thermal band from Landsat metadata
var getK1_L5 = function(image) {return ee.Image(ee.Number(image.get('K1_CONSTANT_BAND_6')))};
var getK1_L8 = function(image) {return ee.Image(ee.Number(image.get('K1_CONSTANT_BAND_10')))};
var getK2_L5 = function(image) {return ee.Image(ee.Number(image.get('K2_CONSTANT_BAND_6')))};
var getK2_L8 = function(image) {return ee.Image(ee.Number(image.get('K2_CONSTANT_BAND_10')))};
var K1_L5 = stackCollection(L5_raw.map(getK1_L5));
var K1_L8 = stackCollection(L8_raw.map(getK1_L8));
var K2_L5 = stackCollection(L5_raw.map(getK2_L5));
var K2_L8 = stackCollection(L8_raw.map(getK2_L8));
var K1 = K1_L5.addBands(K1_L8).rename(datelist);
var K2 = K2_L5.addBands(K2_L8).rename(datelist);
var Ts // Surface temperature (Kelvin)
= Rc.expression('K2/(log((eNB*K1/Rc)+1))',{'K1':K1,'K2':K2,'eNB':emiss_eNB,'Rc':Rc}).mask(NoCloudsMask);
var RLup_Wm2 = emiss_e0.multiply(ee.Image(st_boltz)).multiply(Ts.pow(4));
var Tb_Bands = thermal_rad.expression('K2/(log((K1/L)+1))',
{'K1':K1,'K2':K2,'L':thermal_rad}).mask(NoCloudsMask);
// Compute the TS DEM-corrected
var DEM_col = MaskLandsat.multiply(DEM);
var mean_Alt_scene = getmeanvalueCol(DEM_col).toImage(datelist).mask(MaskLandsat);
var default_lapse_rate = MaskLandsat.multiply(0.0065);
//=================================== START OF Operational Simplified Surface Energy Balance (SSEBop) =============================================
// Compute net radiation for Clear-Sky conditions - for bare soil  (FAO56 - Allen et al., 1998)
var ea_kPa_SSEBop = Tmin_daily_min_C.expression('exp((17.27 * T) / (T + 237.3))',{'T': Tmin_daily_min_C});
// Compute net radiation for Clear-Sky conditions - for bare soil  (FAO56 - Allen et al., 1998)
var Rs_FAO = Ra_hor.multiply(DEM.multiply(0.00002).add(0.75));
var Rso_FAO = Rs_FAO; // Becomes equal to Rs due Clear-Sky assumption
var Rns_FAO = (ee.Image(1).subtract(albedo_mean)).multiply(Rs_FAO);
var Rs_Rso_FAO = ee.Image(1.0);
var fcd_day_FAO = ee.Image(1.35).multiply(Rs_Rso_FAO).subtract(ee.Image(0.35));
var fcd_FAO = fcd_day_FAO.where(Rs_Rso_FAO.lt(0.3),ee.Image(0.0));
var Rnl_FAO = ea_kPa_SSEBop.expression('sigma*((Tmax**4 + Tmin**4)/2)*(0.34-0.14*sqrt(ea))*fcd',
{'sigma':sigma,'fcd':fcd_FAO,'ea':ea_kPa_SSEBop,'Tmax':Tmax_daily_max,'Tmin':Tmin_daily_min});
var Rn_FAO = Rns_FAO.subtract(Rnl_FAO);
var Rn_FAO_Wm2_temp = Rn_FAO.multiply(ee.Number(1000000).divide(ee.Number(86400))); // Conversion from MJ.m².d to W.m² 
var Rn_FAO_Wm2 = Rn_FAO_Wm2_temp.where(Rn_FAO_Wm2_temp.lt(0),0).float();
// Compute T-air daily Maximum
var Tair_max_list = ee.ImageCollection(Tair_daily_images_list).map(function(image) {
    return ee.Image(image).reduce(ee.Reducer.max());});
var Tair_max_daily = (stackCollection(Tair_max_list).rename(datelist)).resample('bilinear').mask(MaskLandsat);
// Ts correction (For high albedo and Lapse-rate)
var Ts_correction_factor = (MaskLandsat.multiply(100)).multiply(albedo.subtract(0.25)).unmask(0).mask(MaskLandsat); // Only for albedo > 0.25
var Ts_cor = Ts.where(albedo.gt(0.25),Ts.add(Ts_correction_factor));
//var Ts_delapsed = Ts_cor.add(lapse_rate.multiply(alt_diff)); // (VERIFICAR APLICABILIDADE)
var Ts_delapsed = Ts_cor.add(default_lapse_rate.multiply(DEM)); // (VERIFICAR APLICABILIDADE)
//------------------------------ Computing c factor ----------------------------------
var ndvi_thres_default = MaskLandsat.multiply(ndvi_threshold);
var ndvi_thres_percent = getForest(NDVI_NC).toImage(datelist).mask(MaskLandsat);
var ndvi_max = NDVI_NC.reduceRegion({
  reducer:ee.Reducer.max(),
  geometry:boundingBoxAI,
  scale:100,bestEffort:true}).toImage(datelist).mask(maskScenes);
var ndvi_threshold_final = ndvi_thres_default.where(ndvi_max.lt(ndvi_thres_default),ndvi_thres_percent);
// Generate constraints masks
var mask_ndvi_limits = (NDVI_NC.gte(ndvi_threshold_final)).updateMask(NDVI_NC.gte(ndvi_threshold_final));
var mask_Ts_limits_min = (Ts_cor.gte(Ts_limit_min)).updateMask(Ts_cor.gte(Ts_limit_min));
var mask_Ts_limits_max = (Ts_cor.lt(Ts_limit_max)).updateMask(Ts_cor.lt(Ts_limit_max));
var mask_Ts_limits = mask_Ts_limits_min.multiply(mask_Ts_limits_max);
var Tdiff_ini = (Tmax_daily_max.subtract(Ts_cor));
var mask_Tdiff_limits = ((Tdiff_ini.gte(0)).bitwiseAnd(Tdiff_ini.lte(30)))
  .updateMask((Tdiff_ini.gte(0)).bitwiseAnd(Tdiff_ini.lte(30)));
var vegetated_pixels_mask = mask_ndvi_limits.multiply(mask_Ts_limits).multiply(mask_Tdiff_limits);
// Compute c factor
var Tair_max_forest_temp = Tmax_daily_max.mask(vegetated_pixels_mask);
var Ts_forest = Ts_cor.mask(vegetated_pixels_mask);
var Tcorr = Ts_forest.divide(Tair_max_forest_temp);
var mean_Tcorr = getmeanvalueCol(Tcorr).toImage(datelist).mask(MaskLandsat);
var SD_Tcorr = getStdvalueCol(Tcorr).toImage(datelist).mask(MaskLandsat);
var c_factor = mean_Tcorr;//.subtract(SD_Tcorr.multiply(2)); AVALIAR MELHOR SE É APLICÁVEL (SENAY ET AL, 2017)
// Compute Cold and Hot Boundary Condition
var T_cold = c_factor.multiply(Tmax_daily_max);
var dens_air = ee.Image(3.486).multiply(P_calc_Kpa.divide(ee.Image(1.01).multiply(Tair_daily_mean_C.add(273))));
var rah_fix = ee.Image(110);
var dT = (Rn_FAO_Wm2.multiply(rah_fix)).divide(dens_air.multiply(Cp_SSEBop));
var T_hot = T_cold.add(dT);
// Compute ET fraction adjusted to remove extreme unrealistic values - set between 0 to 1.05 (Senay, 2018)
var ETf_temp = (T_hot.subtract(Ts_cor)).divide(T_hot.subtract(T_cold));
var ETf_temp2 = (ETf_temp.where(ETf_temp.lt(0),0)).where(ETf_temp.gt(1.05).and(ETf_temp.lte(1.3)),1.05).where(ETf_temp.gt(1.3),-1);
var ETf = ETf_temp2.updateMask(ETf_temp2.neq(-1));
// Compute ET fraction adjusted for elevation (Senay et al, 2011; Senay et al, 2013)
var ETf_el_temp = (T_hot.subtract(Ts_delapsed)).divide(T_hot.subtract(T_cold));
var ETf_el_temp2 = (ETf_el_temp.where(ETf_el_temp.lt(0),0)).where(ETf_el_temp.gt(1.05).and(ETf_el_temp.lte(1.3)),1.05).where(ETf_el_temp.gt(1.3),-1);
var ETf_el = ETf_el_temp2.updateMask(ETf_el_temp2.neq(-1));
// Apply the vegetation index (NDVI) adjustment for ETf (Senay et al, 2011)
var ndvi_vi = NDVI_NC.where(NDVI_NC.lt(0),0);
var vi_factor = ((MaskLandsat_dates.multiply(0.35)).multiply(ndvi_vi.divide(0.7)).add(0.65));
var ETf_vi_temp = vi_factor.multiply(ETf);
var ETf_vi_temp2 = (ETf_vi_temp.where(ETf_vi_temp.lt(0),0)).where(ETf_vi_temp.gt(1.05).and(ETf_vi_temp.lte(1.3)),1.05).where(ETf_vi_temp.gt(1.3),-1);
var ETf_vi = ETf_vi_temp2.updateMask(ETf_vi_temp2.neq(-1));
//var ETf_elvi = ETf_el.where(mndwi.lte(0),vi_factor.multiply(ETf));
var ETf_elvi = vi_factor.multiply(ETf_el);
// Compute final ETa (ETa = ETf * k * ET0_grass) or (ETa = ETf * ET0_alfafa) 
var k_value_calc_temp = (ET0_alf_24h_hor.divide(ET0_gr_24h_hor));//.reduce(ee.Reducer.mean()); // coefficient to scale the grass ETo to the maximum level ET for an aerodynamically rougher crop such as alfalfa
var k_value_calc = k_value_calc_temp.where(k_value_calc_temp.gt(1.3),1.3);
var k_coeffic = ee.Algorithms.If(ee.Algorithms.IsEqual(Set_k_value, 'Y'), ee.Image(k_value).mask(maskScenes), k_value_calc);
var ETa_SSEBop_temp = ETf.multiply(k_coeffic).multiply(ET0_gr_24h_hor);
var ETa_SSEBop = ETa_SSEBop_temp.where(ETa_SSEBop_temp.lt(0),0);
// Confidence (fraction of cloud-free pixels)
var CloudFreeIndex = (NoCloudsMask.reduce(ee.Reducer.sum()).divide(CountImages)).mask(maskCoreScene);
//====================================== Convert results to Image Collections ============================================
var InitialCol = ee.ImageCollection.fromImages(
      datelistMilli.map(function(millis){
        return Landsat_SR_Collection.select('B1').filterMetadata('millis', 'equals', millis)
        .median().set('millis', millis)}));
var MasterCollection = Landsat_SR_Collection.select('B2');
var cut_list_img = ee.List.sequence(0, CountImages.subtract(1), 1);
var ETf_images_list = cut_list_img.map(function (cut) {
    var cut_end = ee.Number(cut).add(1);
    return ETf.slice(ee.Number(cut), cut_end);});
var ETa_images_list = cut_list_img.map(function (cut) {
    var cut_end = ee.Number(cut).add(1);
    return ETa_SSEBop.slice(ee.Number(cut), cut_end);});
var results_col = InitialCol
  .combine(ee.ImageCollection(ETf_images_list))
  .combine(ee.ImageCollection(ETa_images_list))
  .map(function(image){
    return ee.Image(image).rename(['B1','ETf','ETa']);})
    .sort('millis')
  .map(function(img){
      var d = ee.Date(ee.Number(img.get('millis')));
      var date = d.format('yyyy-MM-dd');
      var millis = ee.Date(date).millis();
      var DOY = ee.Number(d.format('DDD'));
      var day = ee.Number(d.get('day'));
      var m = ee.Number(d.get('month'));
      var y = ee.Number(d.get('year'));
  return img.set({'day':day,'month':m, 'year':y,'date':date,'millis':millis,'DOY':DOY});
  });
// Use an equals filter to define how the collections match.
var filter = ee.Filter.equals({
  leftField: 'millis',
  rightField: 'millis'
});
var JoinCol = (ee.Join.inner('primary', 'secondary')).apply(MasterCollection, results_col, filter);
var results_Join = ee.ImageCollection(JoinCol.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));}))
var SSEBop_col = results_Join.select('ETf','ETa');
// Calculate aridity index (AI) = [(ET0 - ETa)/ ET0] x 100
var AI_index = ((ET0_alf_24h_hor.subtract(ETa_SSEBop)).divide(ET0_alf_24h_hor)).multiply(100);
var mean_AI_index = getmeanvalueCol(AI_index.mask(MaskLandsat));
// Long-Term statistics
var LongTerm_ETa_SSEBop_avg = ETa_SSEBop.mask(maskCoreScene).reduce(ee.Reducer.median());
var LongTerm_ETa_SSEBop_var = ETa_SSEBop.mask(maskCoreScene).reduce(ee.Reducer.variance());
var LongTerm_ETa_SSEBop_std = ETa_SSEBop.mask(maskCoreScene).reduce(ee.Reducer.stdDev());
var LongTerm_ETa_SSEBop_CV = (LongTerm_ETa_SSEBop_std.divide(LongTerm_ETa_SSEBop_avg)).multiply(100);
//var LongTerm_ETa_SSEBopEL_avg = ETa_SSEBop_el.mask(maskCoreScene).reduce(ee.Reducer.mean());
//============================================ LANDCOVER ANALYSIS (BRAZIL) =============================================
var Brazil_Landcover = Brazil_Landcover_coll3
// Land Cover reclass -> Forest = 1; Non Forest Natural = 2; Farming = 3; Non Vegetated = 4; Water = 5. 
var forests_class = ((Brazil_Landcover.gte(1)).and(Brazil_Landcover.lte(9))).mask(maskCoreScene);
var forests = forests_class.updateMask(forests_class.eq(1));
var forest_sum = forests.reduce(ee.Reducer.sum()).eq(33).clip(BHPS);
var NonForestNatural_class = ((Brazil_Landcover.gte(10)).and(Brazil_Landcover.lte(13)).or(Brazil_Landcover.eq(32))).mask(maskCoreScene);
var NonForestNatural = NonForestNatural_class.updateMask(NonForestNatural_class.eq(1));
var NonForestNatural_sum = NonForestNatural.reduce(ee.Reducer.sum()).eq(33).clip(BHPS);
var Farming_class = ((Brazil_Landcover.gte(14).and(Brazil_Landcover.lte(21)))).mask(maskCoreScene);
var Farming = Farming_class.updateMask(Farming_class.eq(1));
var Farming_sum = Farming.reduce(ee.Reducer.sum()).eq(33).clip(BHPS);
var Non_vegetated_area_class = (((Brazil_Landcover.gte(22))
  .and(Brazil_Landcover.lte(25))).or((Brazil_Landcover.gte(29)).and(Brazil_Landcover.lte(30)))).mask(maskCoreScene);
var Non_vegetated_area = Non_vegetated_area_class.updateMask(Non_vegetated_area_class.eq(1));
var Non_vegetated_area_sum = Non_vegetated_area.reduce(ee.Reducer.sum()).eq(33).clip(BHPS);
var Water_class = (Brazil_Landcover.eq(26).or(Brazil_Landcover.eq(27)).or(Brazil_Landcover.eq(31))
  .or(Brazil_Landcover.eq(33))).mask(maskCoreScene);
var Water = Water_class.updateMask(Water_class.eq(1));
var Water_sum = Water.reduce(ee.Reducer.sum()).eq(33).clip(BHPS);
// Final Land Cover reclass maps
var LandCover_reclass = forests.blend(NonForestNatural.multiply(2))
  .blend(Farming.multiply(3))
  .blend(Non_vegetated_area.multiply(4))
  .blend(Water.multiply(5)).mask(maskCoreScene);
// Statistics over LandCover class (for BHPS)
var mean_ETa_Forest = getmeanvalueCol(ETa_SSEBop.clip(BHPS).mask(forest_sum.updateMask(forest_sum.eq(1))));
var mean_ETa_NonForestNat = getmeanvalueCol(ETa_SSEBop.clip(BHPS).mask(NonForestNatural_sum.updateMask(NonForestNatural_sum.eq(1))));
var mean_ETa_Farming = getmeanvalueCol(ETa_SSEBop.clip(BHPS).mask(Farming_sum.updateMask(Farming_sum.eq(1))));
var mean_ETa_NonVeget = getmeanvalueCol(ETa_SSEBop.clip(BHPS).mask(Non_vegetated_area_sum.updateMask(Non_vegetated_area_sum.eq(1))));
var mean_ETa_Water = getmeanvalueCol(ETa_SSEBop.clip(BHPS).mask(Water_sum.updateMask(Water_sum.eq(1))));
//var std_ETa_Forest = getStdvalueCol(ETa_SSEBop.mask(forest_sum.updateMask(forest_sum.eq(1))));
//var std_ETa_NonForestNat = getStdvalueCol(ETa_SSEBop.mask(NonForestNatural_sum.updateMask(NonForestNatural_sum.eq(1))));
//var std_ETa_Farming = getStdvalueCol(ETa_SSEBop.mask(Farming_sum.updateMask(Farming_sum.eq(1))));
//var std_ETa_NonVeget = getStdvalueCol(ETa_SSEBop.mask(Non_vegetated_area_sum.updateMask(Non_vegetated_area_sum.eq(1))));
//var std_ETa_Water = getStdvalueCol(ETa_SSEBop.mask(Water_sum.updateMask(Water_sum.eq(1))));
//var CV_ETa_Forest = ee.Dictionary.fromLists(datelist,((ee.Array(std_ETa_Forest.values()).divide(ee.Array(mean_ETa_Forest.values())).multiply(100))).toList());
//var CV_ETa_NonForestNat = ee.Dictionary.fromLists(datelist,((ee.Array(std_ETa_NonForestNat.values()).divide(ee.Array(mean_ETa_NonForestNat.values())).multiply(100))).toList());
//var CV_ETa_Farming = ee.Dictionary.fromLists(datelist,((ee.Array(std_ETa_Farming.values()).divide(ee.Array(mean_ETa_Farming.values())).multiply(100))).toList());
//var CV_ETa_NonVeget = ee.Dictionary.fromLists(datelist,((ee.Array(std_ETa_NonVeget.values()).divide(ee.Array(mean_ETa_NonVeget.values())).multiply(100))).toList());
//var CV_ETa_Water = ee.Dictionary.fromLists(datelist,((ee.Array(std_ETa_Water.values()).divide(ee.Array(mean_ETa_Water.values())).multiply(100))).toList());
//============================================ EXPORT RESULTS ============================================================
// Generate url in console to download results 
var region = ee.Geometry(boundingBoxAI.getInfo()).toGeoJSONString(); // convert to GeoJSON format
var project = ee.Image(L8_TOA.select('B1').first()).projection(); // extract the native Landsat-8 projection
// Export images to an Earth Engine asset.
//Export.image.toAsset({image: LongTerm_ETa_SSEBop_avg, 
//  description: 'LT_ETa_SSEBop_avg_'+WRS_Path+WRS_Row+'_'+StartYear+'_to_'+EndYear,
//  assetId: 'LT_ETa_SSEBop_avg_'+WRS_Path+WRS_Row+'_'+StartYear+'_to_'+EndYear,
//  scale: 30,
//  region: region});
//Export.image.toAsset({image: LongTerm_ETa_SSEBop_CV, 
//  description: 'LT_ETa_SSEBop_CV_'+WRS_Path+WRS_Row+'_'+StartYear+'_to_'+EndYear,
//  assetId: 'LT_ETa_SSEBop_CV_'+WRS_Path+WRS_Row+'_'+StartYear+'_to_'+EndYear,
//  scale: 30,
//  region: region});
//Export.image.toAsset({image: CloudFreeIndex, 
//  description: 'CloudFreeIndex_'+WRS_Path+WRS_Row+'_'+StartYear+'_to_'+EndYear,
//  assetId: 'CloudFreeIndex_'+WRS_Path+WRS_Row+'_'+StartYear+'_to_'+EndYear,
//  scale: 30,
//  region: region});
// Export Land Cover Analysis to a CSV file into Google Drive.
//Export.table.toDrive({
//  collection: ee.FeatureCollection([ee.Feature(null, mean_ETa_Forest)]),
//  description: 'mean_ETa_Forest_'+WRS_Path+WRS_Row+'_'+StartYear+'_to_'+EndYear,
//  folder: 'SSEBop',
//  fileFormat: 'CSV'});
//============================================ VISUALIZATION RESULTS ============================================================
var AutoDate = ee.String(L8_TOA.sort('CLOUD_COVER').first().get('DATE_ACQUIRED'));
var SelectDate = ee.Algorithms.If(ee.Algorithms.IsEqual(Set_date_viz, 'Y'), DateViz, AutoDate.getInfo());
//print('Visualization Date (YYYY-MM-DD):',SelectDate);
Map.centerObject(L8_SR,8);
Map.addLayer(L8_SR.filter(ee.Filter.date(SelectDate, ee.Date(SelectDate).advance(1,'day'))), vizParamsL8, 'L8 Image SR / '+'Date: ' + SelectDate.getInfo());
//Map.addLayer(L5_SR.filter(ee.Filter.date(SelectDate, ee.Date(SelectDate).advance(1,'day'))), vizParamsL5, 'L5 Image SR / '+'Date: ' + SelectDate.getInfo());
Map.addLayer(SSEBop_col.select('ETa').filter(ee.Filter.date(SelectDate, ee.Date(SelectDate).advance(1,'day'))), {min:0,max:8,palette: ['Chocolate','SandyBrown','Yellow','LimeGreen','DarkBlue']}, 'ETa da imagem');
//Map.addLayer(ETa_SSEBop.select(SelectDate.getInfo()), {min:0,max:8,palette: ['Chocolate','SandyBrown','Yellow','LimeGreen','DarkBlue']}, 'ETa daily - '+' '+WRS_Path+'/'+WRS_Row+' - Date: ' + SelectDate.getInfo());
//Map.addLayer(SSEBop_col, {min:0,max:8}, 'ETa diário médio');
Map.addLayer(LongTerm_ETa_SSEBop_avg,{min:0,max:8,palette: ['Chocolate','SandyBrown','Yellow','LimeGreen','DarkBlue']},'Long-Term SSEBop');
//Map.addLayer(ETa_col, {min:0,max:8}, 'ETa daily Coll - '+' '+WRS_Path+'/'+WRS_Row+' from '+StartYear+' to '+EndYear,false);
//print("Date List: "+StartYear+' to '+EndYear+" - WRS: (YYYY-MM-DD)",datelist);
print("mean ETa (mm/day), Class: Forest",mean_ETa_Forest);
print("mean ETa (mm/day), Class: Non-Forest Natural",mean_ETa_NonForestNat);
print("mean ETa (mm/day), Class: Farming",mean_ETa_Farming);
print("mean ETa (mm/day), Class: Non-Vegetation",mean_ETa_NonVeget);
print("mean ETa (mm/day), Class: Water",mean_ETa_Water);
//===================================================== VISUALIZATION LEGEND IN MAP =========================================================
// Create a panel to hold the chart.
var panel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {width: '55%', height: '100%'}})
    .add(ui.Label('Clique no mapa'));
// create vizualization parameters
var viz = {min:0.0,max:8.0,palette: ['Chocolate','SandyBrown','Yellow','LimeGreen','DarkBlue']};
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'top-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'ETa (mm/day)',
  style: {
    fontWeight: 'bold',
    fontSize: '13px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
 // Add the title to the panel
legend.add(legendTitle); 
// create the legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// create text on top of legend
var panel1 = ui.Panel({
    widgets: [
      ui.Label(viz['max'])
    ],
  });
legend.add(panel1);
// create thumbnail from the image
var thumbnail = ui.Thumbnail({
  image: legendImage, 
  params: {bbox:'0,0,10,100', dimensions:'40x200'},  
  style: {padding: '1px', position: 'top-right'}
});
// add the thumbnail to the legend
legend.add(thumbnail);
// create text on top of legend
var panel2 = ui.Panel({
    widgets: [
      ui.Label(viz['min'])
    ],
  });
panel2.clear();
legend.add(panel2);
panel.add(legend);
//============================================ ETa TIME SERIES CHART VISUALIZATION ============================================================
// Load a Landsat 8 composite and display on the map.
var image = ETa_SSEBop;
Map.style().set('cursor', 'crosshair');
//Map.addLayer(image, {bands:['B4','B3','B2'], min: 0, max: 0.3});
// Create the title label.
var title = ui.Label(
  'Click to inspect: ETa from '+StartYear+' to '+EndYear +
  ' (Total scenes: '+ CountImages.getInfo() + ')');
title.style().set('position', 'top-center');
panel.add(title);
// Register a function to draw a chart when a user clicks on the map.
  panel.clear();
  // create vizualization parameters
var viz = {min:0.0,max:8.0,palette: ['Chocolate','SandyBrown','Yellow','LimeGreen','DarkBlue']};
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'top-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'ETa (mm/dia)' + ' - Data: ' + SelectDate.getInfo(),
  style: {
    fontWeight: 'bold',
    fontSize: '13px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
 // Add the title to the panel
legend.add(legendTitle); 
// create the legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// create text on top of legend
var panel1 = ui.Panel({
    widgets: [
      ui.Label(viz['max'])
    ],
  });
legend.add(panel1);
// create thumbnail from the image
var thumbnail = ui.Thumbnail({
  image: legendImage, 
  params: {bbox:'0,0,10,100', dimensions:'40x200'},  
  style: {padding: '1px', position: 'top-right'}
});
// add the thumbnail to the legend
legend.add(thumbnail);
// create text on top of legend
var panel2 = ui.Panel({
    widgets: [
      ui.Label(viz['min'])
    ],
  });
legend.add(panel2);
panel.add(ui.Button('Fecha', function() {
      panel.style().set({shown: false});
    }));
panel.add(legend);
//============================================ ETa TIME SERIES CHART VISUALIZATION ============================================================
// Load a Landsat 8 composite and display on the map.
// Create the title label.
var title = ui.Label(
  'Clique para ver valores: ETa do '+
  ' (Total cenas: '+ CountImages.getInfo() + ')');
title.style().set('position', 'top-center');
panel.add(title);
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: '000000'}, 'Local');
  var chart = ui.Chart.image.regions(image, point, null, 500).setSeriesNames('ETa',0);
  chart.setOptions({
    title: 'ETa (mm/dia)',
    color: 'blue',
    colors:['#0000ff'],
    vAxis: {title: 'ETa (mm/dia)'},
    hAxis:{title: 'Datas Imagens'},
    series: {
      0: {
        color: 'blue',
        lineWidth: 1,
        pointsVisible: true,
        pointSize: 2,
      },
    },
  });
  panel.add(chart);
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: '000000'}, 'Local');
    var chart3 = ui.Chart.image.regions(image, point, null, 500).setSeriesNames('ETa',0);
  chart3.setChartType('Table')
  .setOptions({
    title: 'ETa (mm/dia): ',
    color: 'blue',
    colors:['#0000ff'],
    vAxis: {title: 'ETa (mm/dia)'},
    hAxis:{title: 'Data Imagens'},
    series: {
      0: {
        color: 'blue',
        lineWidth: 1,
        pointsVisible: true,
        pointSize: 2,
      },
    },
  });
  panel.add(chart3);
  Map.add(dot);
//============================================ ETf TIME SERIES CHART VISUALIZATION ============================================================
// Create a panel to hold the chart.
//Map.add(panel2);
// Register a function to draw a chart when a user clicks on the map.
  var chart1 = ui.Chart.image.regions(ETf, point, null, 500).setSeriesNames('ETf',0);
  chart1.setOptions({
    title: 'ET Fraction (ETf): ',
    color: 'green',
    colors:['#0000ff'],
    vAxis: {title: 'ETa (mm/dia)'},
   hAxis:{title: 'Datas Imagens'},
    series: {
      0: {
        color: 'green',
        lineWidth: 1,
        pointsVisible: true,
        pointSize: 2,
      },
    },
  });
  panel.add(chart1);
ui.root.add(panel);
Map.centerObject(point, 12);
});
ui.root.add(panel);