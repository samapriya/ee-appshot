var geometry = /* color: #d63000 */ee.Geometry.MultiPoint(),
    imageCollection = ee.ImageCollection("LANDSAT/LT5_L1T_ANNUAL_NDVI"),
    imageCollection2 = ee.ImageCollection("LANDSAT/LT5_L1T_ANNUAL_GREENEST_TOA"),
    table = ee.FeatureCollection("users/gustavoirgang/BRPais");
/**
 * Function to mask clouds based on the pixel_qa band of Landsat SR data.
 * @param {ee.Image} image Input Landsat SR image
 * @return {ee.Image} Cloudmasked Landsat image
 */
var table = ee.FeatureCollection("users/gustavoirgang/BRPais");
var cloudMaskL457 = function(image) {
  var qa = image.select('pixel_qa');
  // If the cloud bit (5) is set and the cloud confidence (7) is high
  // or the cloud shadow bit is set (3), then it's a bad pixel.
  var cloud = qa.bitwiseAnd(1 << 5)
                  .and(qa.bitwiseAnd(1 << 7))
                  .or(qa.bitwiseAnd(1 << 3));
  // Remove edge pixels that don't occur in all bands
  var mask2 = image.mask().reduce(ee.Reducer.min());
  return image.updateMask(cloud.not()).updateMask(mask2);
};
var images = {
  '2011': getAnnualNDVI('2011-01-01'),
  '2010': getAnnualNDVI('2010-01-01'),
  '2009': getAnnualNDVI('2009-01-01'),
  '2008': getAnnualNDVI('2008-01-01'),
  '2006': getAnnualNDVI('2006-01-01'),
  '2005': getAnnualNDVI('2005-01-01'),
  '2004': getAnnualNDVI('2004-01-01'),
  '2003': getAnnualNDVI('2003-01-01'),
  '2002': getAnnualNDVI('2002-01-01'),
  '2001': getAnnualNDVI('2001-01-01'),
  '2000': getAnnualNDVI('2000-01-01'),
  '1999': getAnnualNDVI('1999-01-01'),
  '1998': getAnnualNDVI('1998-01-01'),
  '1997': getAnnualNDVI('1997-01-01'),
  '1996': getAnnualNDVI('1996-01-01'),
  '1995': getAnnualNDVI('1995-01-01'),
  '1994': getAnnualNDVI('1994-01-01'),
  '1993': getAnnualNDVI('1993-01-01'),
  '1992': getAnnualNDVI('1992-01-01'),
  '1991': getAnnualNDVI('1991-01-01'),
  '1990': getAnnualNDVI('1990-01-01'),
  '1989': getAnnualNDVI('1989-01-01'),
  '1988': getAnnualNDVI('1988-01-01'),
  '1987': getAnnualNDVI('1987-01-01'),
  '1986': getAnnualNDVI('1986-01-01'),
  '1985': getAnnualNDVI('1985-01-01'),
  '1984': getAnnualNDVI('1984-01-01'),
};
function getAnnualNDVI(date) {
  var date = ee.Date(date);
print (date.advance(1, 'year'));
// A helper function to show the image for a given year on the default map.
var ndfiColorTable = function(){
  var ndfi_color = 
    'FFFFFF,FFFCFF,FFF9FF,FFF7FF,FFF4FF,FFF2FF,FFEFFF,FFECFF,FFEAFF,FFE7FF,'+
    'FFE5FF,FFE2FF,FFE0FF,FFDDFF,FFDAFF,FFD8FF,FFD5FF,FFD3FF,FFD0FF,FFCEFF,'+
    'FFCBFF,FFC8FF,FFC6FF,FFC3FF,FFC1FF,FFBEFF,FFBCFF,FFB9FF,FFB6FF,FFB4FF,'+
    'b3ffb3,99ff99,80ff80,66ff66,4dff4d,1aff1a,00ff00,00e600,00cc00,00b300,'+
    'B49D00,AC9C00,A59C00,9D9B00,969A00,8E9900,879900,7F9800,789700,709700,'+
    '699600,619500,5A9400,529400,4B9300,439200,349100,2D9000,258F00,1E8E00,'+
    '168E00,0F8D00,078C00,008C00,008C00,008700,008300,007F00,007A00,007600,'+
    '007200,006E00,006900,006500,006100,005C00,005800,005400,005000,004C00';
    return ndfi_color;
};
  // Only include the VV polarization, for consistent compositing.
  var dataset = ee.ImageCollection('LANDSAT/LT05/C01/T1_SR')
                      .filterDate(date, date.advance(1, 'year'))
                      .map(cloudMaskL457)
                      .filterMetadata('CLOUD_COVER', 'less_than', 70.0)
                      .min().clip(table)
                      ;
  return dataset.normalizedDifference(['B4','B5']).visualize({ 'min':-0.13, 'max':0.75, palette: ['FFFFFF','FFFCFF','FFF9FF','FFF7FF','FFF4FF','FFF2FF','FFEFFF','FFECFF','FFEAFF','FFE7FF',
    'FFE5FF','FFE2FF','FFE0FF','FFDDFF','FFDAFF','FFD8FF','FFD5FF','FFD3FF','FFD0FF','FFCEFF',
    'FFCBFF','FFC8FF','FFC6FF','FFC3FF','FFC1FF','FFBEFF','FFBCFF','FFB9FF','FFB6FF','FFB4FF',
    'b3ffb3','99ff99','80ff80','66ff66','4dff4d','1aff1a','00ff00','00e600','00cc00','00b300',
    'B49D00','AC9C00','A59C00','9D9B00','969A00','8E9900','879900','7F9800','789700','709700',
    '699600','619500','5A9400','529400','4B9300','439200','349100','2D9000','258F00','1E8E00',
    '168E00','0F8D00','078C00','008C00','008C00','008700','008300','007F00','007A00','007600',
    '007200','006E00','006900','006500','006100','005C00','005800','005400','005000','004C00','0744EC','000066','0744EC','000066','0744EC','000066','0744EC','000066','0744EC','000066','0744EC','000066','0744EC','000066','0744EC','000066']});
}
//var visParams = {
 // bands: ['B3', 'B2', 'B1'],
 // min: 0,
 // max: 2000,
//  gamma: 1.0,
//};
//Map.setCenter(-54, -12, 5);
//Map.addLayer(dataset.median().clip(table), visParams);
//var mediana = dataset.min().clip(table);
//var ndfi = mediana.normalizedDifference(["B4","B5"]);
// Adiciona a imagem NDFI ao mapa
//var visNDFI = { eeObject: ee.Image(ndfi),'palette':ndfiColorTable()+',0000FF', 'min':-0.13, 'max':0.75,name: String(year)};
//Map.addLayer(ndfi, visNDFI, 'NDFI', true);
//};
//var vis = {min: -0.1, max: 0.19, palette: ['99c199', '66a266', '006400']};
//Map.addLayer(ndfi, vis, 'NDVI');
/*
 * Set up the maps and control widgets
 */
// Create the left map, and have it display layer 0.
var leftMap = ui.Map();
leftMap.setControlVisibility(false);
var leftSelector = addLayerSelector(leftMap, 0, 'top-left');
// Create the right map, and have it display layer 1.
var rightMap = ui.Map();
rightMap.setControlVisibility(false);
var rightSelector = addLayerSelector(rightMap, 1, 'top-right');
// Adds a layer selection widget to the given map, to allow users to change
// which image is displayed in the associated map.
function addLayerSelector(mapToChange, defaultValue, position) {
  var label = ui.Label('Escolha o ano');
  // This function changes the given map to show the selected image.
  function updateMap(selection) {
    mapToChange.layers().set(0, ui.Map.Layer(images[selection]));
  }
  // Configure a selection dropdown to allow the user to choose between images,
  // and set the map to update when a user makes a selection.
  var select = ui.Select({items: Object.keys(images), onChange: updateMap});
  select.setValue(Object.keys(images)[defaultValue], true);
  var controlPanel =
      ui.Panel({widgets: [label, select], style: {position: position}});
  mapToChange.add(controlPanel);
}
/*
 * Tie everything together
 */
// Create a SplitPanel to hold the adjacent, linked maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in the UI root.
ui.root.widgets().reset([splitPanel]);
var linker = ui.Map.Linker([leftMap, rightMap]);
leftMap.setCenter(-50, -25, 4);