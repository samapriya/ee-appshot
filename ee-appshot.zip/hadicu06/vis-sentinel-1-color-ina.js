var VH_0 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VH_dry_median_extraProc_d42d6b511226463dacd18944b1d3aed4_0")
var VH_1 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VH_dry_median_extraProc_d42d6b511226463dacd18944b1d3aed4_1")
var VH_2 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VH_dry_median_extraProc_d42d6b511226463dacd18944b1d3aed4_2")
var VH_3 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VH_dry_median_extraProc_d42d6b511226463dacd18944b1d3aed4_3")
var VH_4 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VH_dry_median_extraProc_d42d6b511226463dacd18944b1d3aed4_4")
var VH_5 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VH_dry_median_extraProc_d42d6b511226463dacd18944b1d3aed4_5")
var VH_6 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VH_dry_median_extraProc_d42d6b511226463dacd18944b1d3aed4_6")
var VV_0 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VV_dry_median_extraProc_45ae2ca8c8cd4e5902ec4c524164a8ba_0")
var VV_1 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VV_dry_median_extraProc_45ae2ca8c8cd4e5902ec4c524164a8ba_1")
var VV_2 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VV_dry_median_extraProc_45ae2ca8c8cd4e5902ec4c524164a8ba_2")
var VV_3 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VV_dry_median_extraProc_45ae2ca8c8cd4e5902ec4c524164a8ba_3")
var VV_4 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VV_dry_median_extraProc_45ae2ca8c8cd4e5902ec4c524164a8ba_4")
var VV_5 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VV_dry_median_extraProc_45ae2ca8c8cd4e5902ec4c524164a8ba_5")
var VV_6 = ee.Image("users/hadicu06/IIASA/composite/newBiggerAsset/S1_2018_10m_VV_dry_median_extraProc_45ae2ca8c8cd4e5902ec4c524164a8ba_6")
var VV_mosaic = ee.ImageCollection.fromImages([
  VV_0, VV_1, VV_2, VV_3, VV_4, VV_5, VV_6
]).mosaic()
var VH_mosaic = ee.ImageCollection.fromImages([
  VH_0, VH_1, VH_2, VH_3, VH_4, VH_5, VH_6
]).mosaic()
// Merge VV & VH
var VV_VH = ee.Image.cat(VV_mosaic, VH_mosaic)
// Add band VV/VH
VV_VH = VV_VH.addBands(
  VV_VH.select('VV_median_dry').divide(VV_VH.select('VH_median_dry')).rename('VV_div_VH_median_dry'))
// print('VV_VH', VV_VH)
var bands = ['VV_median_dry', 'VH_median_dry', 'VV_div_VH_median_dry']
var minVV = -1200
var maxVV = -500
var minVH = -1800
var maxVH = -1100
var minRatio = 0.5
var maxRatio = 0.7
Map.addLayer(VV_VH, {bands:bands, min:[minVV, minVH, minRatio], max:[maxVV, maxVH, maxRatio]}, 'Sentinel-1 VV,VH,VV/VH (2018)')
Map.setOptions('SATELLITE')
Map.setCenter(119.973, -1.551, 5)