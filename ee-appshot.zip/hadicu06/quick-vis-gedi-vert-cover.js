var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -67.96191084430674,
                -10.086310286826516
              ],
              [
                -67.9615782503889,
                -10.087065542046929
              ],
              [
                -67.96100962207774,
                -10.086812030002578
              ],
              [
                -67.96097207115153,
                -10.08631556833771
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #0b4a8b */ee.Geometry.Polygon(
        [[[-67.96191084430674, -10.086310286826516],
          [-67.9615782503889, -10.087065542046929],
          [-67.96100962207774, -10.086812030002578],
          [-67.96097207115153, -10.08631556833771]]]);
/*
v0.0 - no custom filters by users
*/
//////////////////////////////////////////////////////////////////////////////
//// Interactive chart
///////////////////////////////////////////////////////////////////////////////
///////////////  Map
var app = {};
app.mapPanel = ui.Map()
//app.mapPanel = ui.Map({style: {cursor: 'crosshair'}})                                      // These panels to be put in init() function
app.mapPanel.setOptions('HYBRID')
app.mapPanel.setControlVisibility({zoomControl:true, layerList:false})
ui.root.clear()
ui.root.add(app.mapPanel)
////////////////////// How to use
app.info = ui.Label("How to use");
app.info.setUrl("https://www.loom.com/share/9a3c17195aeb452bbd594a7838d251fe");
app.info.style().set({
     position: 'bottom-right',
     fontSize: '22px', margin: '6px 0 4px 0', // 18.5px
     fontWeight: 'bold',
     width: 60
});
app.mapPanel.add(app.info);
/////////////// Create a panel to hold time series widget
app.chartPanel = ui.Panel();
app.chartPanel.style().set({
    position: 'bottom-left',
    height: '250px',
    width: '400px',
})
// Add the panel to the ui.root.
app.mapPanel.add(app.chartPanel)
/////////////// Draw polygon
app.mapPanel.drawingTools().setShown(true)
// var drawingTools = app.mapPanel.drawingTools(); 
// drawingTools.setDrawModes(['polygon']);   
app.mapPanel.drawingTools().setDrawModes(['polygon']);   
/////////////// Button to reset i.e. clear Map layers and drawing tool layers
app.resetButton = ui.Button({
            label:'Clear geometry',
           });
app.resetButton.style().set({
     position: 'bottom-center',
     fontSize: '18.5px', margin: '6px 0 4px 0', // 18.5px
     fontWeight: 'bold',
     width: 60
});
app.mapPanel.add(app.resetButton);
/// here?
app.resetButton.onClick(function(){
  app.mapPanel.drawingTools().clear(); 
  var drawingTools = app.mapPanel.drawingTools(); 
  drawingTools.setDrawModes(['polygon']);   
})
/////////////// Button to load GEDI data for the viewport
app.loadButton = ui.Button({
            label:'Load and QA-filter GEDI L2B data',
           });
app.loadButton.style().set({
     position: 'top-center',
     fontSize: '18.5px', margin: '6px 0 4px 0', // 18.5px
     fontWeight: 'bold',
     width: 120
});
app.mapPanel.add(app.loadButton);
app.loadButton.onClick(function(){
  var fc = app.mapPanel.getBounds(true);
  // Get and filterBound GEDI data to the polygon area
  var gedi_col_L2A = ee.ImageCollection("LARSE/GEDI/GEDI02_A_002_MONTHLY")  
                  .filterBounds(fc);
  var gedi_col_L2B = ee.ImageCollection("LARSE/GEDI/GEDI02_B_002_MONTHLY")
                  .filterBounds(fc);
  // Apply QA to GEDI
  var gedi_col_L2A_filt = gedi_col_L2A.map(filterGediImageL2A);
  var gedi_col_L2B_filt = gedi_col_L2B.map(filterGediImageL2B);
  // Filter to summer months (relevant for Europe, OK for Brazil and Indonesia)
  var gedi_col_L2A_filt_northernSummer = gedi_col_L2A_filt.filter(ee.Filter.inList('month', [6,7,8]));
  var gedi_col_L2B_filt_northernSummer = gedi_col_L2B_filt.filter(ee.Filter.inList('month', [6,7,8]));
  // Aggregate monthly GEDI data into all-time median 
  var regex_rh = "rh.*";
  var gedi_L2A_filt_northernSummer_median = gedi_col_L2A_filt_northernSummer.select(regex_rh).median();   
  var regex_cover = "cover_z.*";
  var gedi_L2B_filt_northernSummer_median = gedi_col_L2B_filt_northernSummer.select(regex_cover).median();   
  var gedi_L2B_filt_northernSummer_median_COVER = gedi_col_L2B_filt_northernSummer.select(["cover"]).median();   
  //// DISPLAY GEDI FOOTPRINTS
  app.mapPanel.layers().reset()
  app.mapPanel.layers().add(ui.Map.Layer(gedi_L2B_filt_northernSummer_median_COVER, {min:0, max:1, palette:'yellow,green,cyan'}, "total cover (fraction)"));
})
/////////////// Button to chart 
app.chartButton = ui.Button({
            label:'Plot vertical profile of cover',
           });
app.chartButton.style().set({
     position: 'bottom-center',
     fontSize: '18.5px', margin: '6px 0 4px 0', // 18.5px
     fontWeight: 'bold',
     width: 120
});
app.mapPanel.add(app.chartButton);
app.chartButton.onClick(function(){
  var layer = app.mapPanel.drawingTools().layers().get(0);
  var fc = ee.FeatureCollection(layer.getEeObject());
  // Get and filterBound GEDI data to the polygon area
  var gedi_col_L2A = ee.ImageCollection("LARSE/GEDI/GEDI02_A_002_MONTHLY")  
                  .filterBounds(fc);
  var gedi_col_L2B = ee.ImageCollection("LARSE/GEDI/GEDI02_B_002_MONTHLY")
                  .filterBounds(fc);
  // Apply QA to GEDI
  var gedi_col_L2A_filt = gedi_col_L2A.map(filterGediImageL2A);
  var gedi_col_L2B_filt = gedi_col_L2B.map(filterGediImageL2B);
  // Filter to summer months (relevant for Europe, OK for Brazil and Indonesia)
  var gedi_col_L2A_filt_northernSummer = gedi_col_L2A_filt.filter(ee.Filter.inList('month', [6,7,8]));
  var gedi_col_L2B_filt_northernSummer = gedi_col_L2B_filt.filter(ee.Filter.inList('month', [6,7,8]));
  // Aggregate monthly GEDI data into all-time median 
  var regex_rh = "rh.*";
  var gedi_L2A_filt_northernSummer_median = gedi_col_L2A_filt_northernSummer.select(regex_rh).median();   
  var regex_cover = "cover_z.*";
  var gedi_L2B_filt_northernSummer_median = gedi_col_L2B_filt_northernSummer.select(regex_cover).median();   
  var gedi_L2B_filt_northernSummer_median_COVER = gedi_col_L2B_filt_northernSummer.select(["cover"]).median();   
  ////// Format data for chart API
  var selZ = ee.List.sequence(0,14).map(function(n){return ee.String("cover_z").cat(ee.Number(n).format("%.0f")) });
  var gedi_L2B_filt_northernSummer_median_selZ = gedi_L2B_filt_northernSummer_median.select(selZ)
  var res_L2B_pixel_medianReduc = gedi_L2B_filt_northernSummer_median_selZ.reduceRegion({
    reducer: ee.Reducer.median(), 
    geometry: fc, 
    scale: 25, 
    maxPixels: 1e12,
    tileScale: 8
  });
  // print("res_L2B_pixel_medianReduc", res_L2B_pixel_medianReduc)  // debug
  var res_L2B_fc = ee.Dictionary(res_L2B_pixel_medianReduc).map(objToFc_coverz);
  // print("res_L2B_fc", res_L2B_fc); // debug
  res_L2B_fc = ee.FeatureCollection(res_L2B_fc.values());
  /// cover = 0 set to null for plotting
  res_L2B_fc = res_L2B_fc.map(function(ft){
    return ee.Feature(ft).set('cover_z_val_null', ee.Algorithms.If(ee.Feature(ft).getNumber("cover_z_val").gt(0), ee.Feature(ft).getNumber("cover_z_val")));
  });
  res_L2B_fc = res_L2B_fc.select(["z_number", "cover_z_val_null"])
  // MAKE THE CHART
  var chart =
    ui.Chart.feature
        .byFeature({
          features: res_L2B_fc,
          xProperty: 'cover_z_val_null',
        })
        .setChartType('ScatterChart')
        .setOptions({
          title: 'Vertical profile of canopy cover',
          hAxis:
              {title: 'cover at z-th (fraction)', titleTextStyle: {italic: false, bold: true}},
          vAxis: {
            title: 'z-th (dz = 5m)',
            titleTextStyle: {italic: false, bold: true}
          },
          lineSize: 0,
          pointSize: 4
        });
  // Insert the chart widget into the panel          
  app.chartPanel.widgets().set(0, chart);
})
/////////////// Reactive component
// Map.onClick(function(coords) {
//   // Button to click to display time series? Later
//   // GEDI displayed responds to the viewport? No, as filterBound will show the GEDI tile which is pretty big
//   // When to delete drawn polygon? Button to reset i.e. clear Map layers and drawing tool layers. Done.
// });
/////////////////////////////////////////////////////////////////////////////////////////////////////////
////$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
function filterGediImageL2A(img){
  var quality_mask = img.select('quality_flag').eq(1);
  var degrade_mask = img.select("degrade_flag").eq(0);
  var sensitivity_mask = (img.select("pft_class").eq(2).and(img.select('sensitivity').gt(0.98))).or(
    img.select("pft_class").neq(2).and(img.select('sensitivity').gt(0.95)));
  var leafOffOn_mask = img.select("leaf_off_flag").eq(0);
  return img.updateMask(quality_mask)
            .updateMask(degrade_mask)
            .updateMask(sensitivity_mask)
            .updateMask(leafOffOn_mask)
            .copyProperties(img, img.propertyNames());
}
function filterGediImageL2B(img){  // TODO
  var quality_mask = img.select('l2b_quality_flag').neq(0); // 1 ?
  var degrade_mask = img.select("degrade_flag").lt(1);
  // var sensitivity_mask = (img.select("pft_class").eq(2).and(img.select('sensitivity').gt(0.98))).or(
  //   img.select("pft_class").neq(2).and(img.select('sensitivity').gt(0.95)));
  // no "pft_class", maybe need to link to L2A based on "shot_number":
  var sensitivity_mask = img.select('sensitivity').gt(0.98);   // 0.98 so very strict
  // var leafOffOn_mask = img.select("leaf_off_flag").eq(0);
  // no "leaf_off_flag", maybe need to link to L2A based on "shot_number"
  return img.updateMask(quality_mask)
            .updateMask(degrade_mask)
            .updateMask(sensitivity_mask)
            // .updateMask(leafOffOn_mask)
            .copyProperties(img, img.propertyNames());
}
function objToFc_coverz(objKey, objVal) {
  var z_number_str = ee.String(objKey).slice(7);
  var z_number = ee.Number.parse(z_number_str);
  var cover_z_val = ee.Number(objVal);
  return ee.Feature(null, {'z_number': z_number, 'cover_z_val': cover_z_val});
}