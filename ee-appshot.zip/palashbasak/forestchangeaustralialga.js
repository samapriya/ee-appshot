// Author: Palash Basak, GIS Supervisor, Wingecarribee Shire Council, NSW, Palash.Basak@wsc.nsw.gov.au
// Version 1: 04 June 2021
// This script will generate year by year forest loss in LGAs of Australia.
// The analysis was done based on Hansen's Global Forest Change v1.8 (2000-2020) .
// http://earthenginepartners.appspot.com/science-2013-global-forest
// User will have to input the name of the LGA and State.
// The script will generate series of layers.
// Bedefault most of the layers will be turned off.
// Users will be able to turn then on from the Layers menu.
// The tree loss boundaries could be download as a TIFF image using Google Drive.
// However, by default the code for exporting is turned off.
// User will have to uncomment the code and re-run the code.
//
// User input for the LGA Name
// Make sure that the lga name is exactly as the input shapefile.
// Find the LGA and State Names at the bottom of the sript.
// var lgaName = "Goulburn Mulwaree";
var lgaName = "Wingecarribee";
// var lgaName = "Campbelltown";
// var lgaName = "Albury";
// var lgaName = "Unincorporated ACT";
var stateName = "New South Wales";
// var stateName = "Australian Capital Territory";
// The LGA Names and Boundary are shown as per 
// "Local Government Areas ASGS Ed 2016 Digital Boundaries" downloaded from ABS website
// https://www.abs.gov.au/AUSSTATS/abs@.nsf/DetailsPage/1270.0.55.003July%202016?OpenDocument
// Get the LGA boundary
var lgaBoundary = ee.FeatureCollection("users/palashbasak/LGA_2016_AUST_WGS84")
                      .filterMetadata('LGA_Name', 'equals', lgaName)
                      .filterMetadata("STE_NAME16", 'equals', stateName);
// Center the map to the lga
Map.centerObject(lgaBoundary);
//Change style of cursor to 'crosshair'
Map.style().set('cursor', 'crosshair');
// Hansen Global Forest Change v1.8 (2000-2020) 
var gfc = ee.Image("UMD/hansen/global_forest_change_2020_v1_8")
// Calculate Forest loss by year and plot graph
var lossImage = gfc.select(['loss']).clip(lgaBoundary);
var lossAreaImage = lossImage.multiply(ee.Image.pixelArea());
var lossYear = gfc.select(['lossyear']);
var lossByYear = lossAreaImage.addBands(lossYear).reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1
    }),
  geometry: lgaBoundary,
  scale: 30,
  maxPixels: 1e9
});
var statsFormatted = ee.List(lossByYear.get('groups'))
  .map(function(el) {
    var d = ee.Dictionary(el);
    return [ee.Number(d.get('group')).format("20%02d"), d.get('sum')];
  });
var statsDictionary = ee.Dictionary(statsFormatted.flatten());
var chart = ui.Chart.array.values({
  array: statsDictionary.values(),
  axis: 0,
  xLabels: statsDictionary.keys()
}).setChartType('ColumnChart')
  .setOptions({
    title: 'Yearly Forest Loss',
    hAxis: {title: 'Year', format: '####'},
    vAxis: {title: 'Area (square meters)'},
    legend: { position: "none" },
    lineWidth: 1,
    pointSize: 3
  });
print(chart);
var gainImage = gfc.select(['gain']).clip(lgaBoundary);
// Use and operation to create lossAndGain image
var gainAndLoss = gainImage.and(lossImage).clip(lgaBoundary);
var netLoss = lossImage.subtract(gainImage).clip(lgaBoundary);
// Show the loos and gain image
var treeCover = gfc.select(['treecover2000']).clip(lgaBoundary);
Map.addLayer(treeCover.updateMask(treeCover), {palette: ['00FF00', 'green'], max: 100}, 'Forest Cover 2000');
Map.addLayer(gainImage.updateMask(gainImage), {palette: 'blue'}, 'Forest Gain - Between 2000 and 2020', false);
Map.addLayer(lossImage.updateMask(lossImage), {palette: 'red'}, 'Forest Loss - Between 2000 and 2020');
Map.addLayer(gainAndLoss.updateMask(gainAndLoss), {palette: 'FF00FF'}, 'Loss and Gain - Between 2000 and 2020', false);
//Map.addLayer(netLoss, {pelette: 'yellow'}, 'Net Loss')
// Color palette
// https://www.icolorpalette.com/download/shades/ff964f_color_shades.jpg
var lossImage2001 = gfc.select(['lossyear']).eq(1).clip(lgaBoundary);
Map.addLayer(lossImage2001.updateMask(lossImage2001), {palette: 'fed5b9'}, 'Forest Loss in 2001', false);
var lossImage2002 = gfc.select(['lossyear']).eq(2).clip(lgaBoundary);
Map.addLayer(lossImage2002.updateMask(lossImage2002), {palette: 'ffcba9'}, 'Forest Loss in 2002', false);
var lossImage2003 = gfc.select(['lossyear']).eq(3).clip(lgaBoundary);
Map.addLayer(lossImage2003.updateMask(lossImage2003), {palette: 'ffc299'}, 'Forest Loss in 2003', false);
var lossImage2004 = gfc.select(['lossyear']).eq(4).clip(lgaBoundary);
Map.addLayer(lossImage2004.updateMask(lossImage2004), {palette: 'ffb888'}, 'Forest Loss in 2004', false);
var lossImage2005 = gfc.select(['lossyear']).eq(5).clip(lgaBoundary);
Map.addLayer(lossImage2005.updateMask(lossImage2005), {palette: 'ffae78'}, 'Forest Loss in 2005', false);
var lossImage2006 = gfc.select(['lossyear']).eq(6).clip(lgaBoundary);
Map.addLayer(lossImage2006.updateMask(lossImage2006), {palette: 'ffa468'}, 'Forest Loss in 2006', false);
var lossImage2007 = gfc.select(['lossyear']).eq(7).clip(lgaBoundary);
Map.addLayer(lossImage2007.updateMask(lossImage2007), {palette: 'ff9b57'}, 'Forest Loss in 2007', false);
var lossImage2008 = gfc.select(['lossyear']).eq(8).clip(lgaBoundary);
Map.addLayer(lossImage2008.updateMask(lossImage2008), {palette: 'ff9147'}, 'Forest Loss in 2008', false);
var lossImage2009 = gfc.select(['lossyear']).eq(9).clip(lgaBoundary);
Map.addLayer(lossImage2009.updateMask(lossImage2009), {palette: 'ff8737'}, 'Forest Loss in 2009', false);
var lossImage2010 = gfc.select(['lossyear']).eq(10).clip(lgaBoundary);
Map.addLayer(lossImage2010.updateMask(lossImage2010), {palette: 'ff7d26'}, 'Forest Loss in 2010', false);
var lossImage2011 = gfc.select(['lossyear']).eq(11).clip(lgaBoundary);
Map.addLayer(lossImage2011.updateMask(lossImage2011), {palette: 'ff7416'}, 'Forest Loss in 2011', false);
var lossImage2012 = gfc.select(['lossyear']).eq(12).clip(lgaBoundary);
Map.addLayer(lossImage2012.updateMask(lossImage2012), {palette: 'ff6a06'}, 'Forest Loss in 2012', false);
var lossImage2013 = gfc.select(['lossyear']).eq(13).clip(lgaBoundary);
Map.addLayer(lossImage2013.updateMask(lossImage2013), {palette: 'fc6600'}, 'Forest Loss in 2013', false);
var lossImage2014 = gfc.select(['lossyear']).eq(14).clip(lgaBoundary);
Map.addLayer(lossImage2014.updateMask(lossImage2014), {palette: 'ec5f00'}, 'Forest Loss in 2014', false);
var lossImage2015 = gfc.select(['lossyear']).eq(15).clip(lgaBoundary);
Map.addLayer(lossImage2015.updateMask(lossImage2015), {palette: 'dc5800'}, 'Forest Loss in 2015', false);
var lossImage2016 = gfc.select(['lossyear']).eq(16).clip(lgaBoundary);
Map.addLayer(lossImage2016.updateMask(lossImage2016), {palette: 'cc5200'}, 'Forest Loss in 2016', false);
var lossImage2017 = gfc.select(['lossyear']).eq(17).clip(lgaBoundary);
Map.addLayer(lossImage2017.updateMask(lossImage2017), {palette: 'bb4b00'}, 'Forest Loss in 2017', false);
var lossImage2018 = gfc.select(['lossyear']).eq(18).clip(lgaBoundary);
Map.addLayer(lossImage2018.updateMask(lossImage2018), {palette: 'b34800'}, 'Forest Loss in 2018', false);
var lossImage2019 = gfc.select(['lossyear']).eq(19).clip(lgaBoundary);
Map.addLayer(lossImage2019.updateMask(lossImage2019), {palette: 'a34100'}, 'Forest Loss in 2019', false);
var lossImage2020 = gfc.select(['lossyear']).eq(20).clip(lgaBoundary);
Map.addLayer(lossImage2020.updateMask(lossImage2020), {palette: 'yellow'}, 'Forest Loss in 2020');
// Draw LGA Boundary
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: lgaBoundary,
  color: 1,
  width: 2
});
Map.addLayer(outline, {palette: 'black'}, 'LGA Boundary');
// Export.image.toDrive({
//   image: lossImage2020,
//   description: 'ForestLoss2020',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: gainAndLoss,
//   description: 'ForestGainAndLoss2000T2020',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage,
//   description: 'ForestLoss2000T2020',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: gainImage,
//   description: 'ForestGain2000T2020',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: treeCover,
//   description: 'ForestCover2000',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2019,
//   description: 'LGA_Forest_Loss_2019',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2018,
//   description: 'LGA_Forest_Loss_2018',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2017,
//   description: 'LGA_Forest_Loss_2017',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2016,
//   description: 'LGA_Forest_Loss_2016',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2015,
//   description: 'LGA_Forest_Loss_2015',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2014,
//   description: 'LGA_Forest_Loss_2014',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2013,
//   description: 'LGA_Forest_Loss_2013',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2012,
//   description: 'LGA_Forest_Loss_2012',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2011,
//   description: 'LGA_Forest_Loss_2011',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2010,
//   description: 'LGA_Forest_Loss_2010',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2009,
//   description: 'LGA_Forest_Loss_2009',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2008,
//   description: 'LGA_Forest_Loss_2008',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2007,
//   description: 'LGA_Forest_Loss_2007',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2006,
//   description: 'LGA_Forest_Loss_2006',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2005,
//   description: 'LGA_Forest_Loss_2005',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2004,
//   description: 'LGA_Forest_Loss_2004',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2003,
//   description: 'LGA_Forest_Loss_2003',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2002,
//   description: 'LGA_Forest_Loss_2002',
//   scale: 30,
//   region: lgaBoundary
// });
// Export.image.toDrive({
//   image: lossImage2001,
//   description: 'LGA_Forest_Loss_2001',
//   scale: 30,
//   region: lgaBoundary
// });
// LGA and State Names
// Albury, New South Wales
// Armidale Regional, New South Wales
// Ballina, New South Wales
// Balranald, New South Wales
// Bathurst Regional, New South Wales
// Bega Valley, New South Wales
// Bellingen, New South Wales
// Berrigan, New South Wales
// Blacktown, New South Wales
// Bland, New South Wales
// Blayney, New South Wales
// Blue Mountains, New South Wales
// Bogan, New South Wales
// Botany Bay, New South Wales
// Bourke, New South Wales
// Brewarrina, New South Wales
// Broken Hill, New South Wales
// Burwood, New South Wales
// Byron, New South Wales
// Cabonne, New South Wales
// Camden, New South Wales
// Campbelltown, New South Wales
// Canada Bay, New South Wales
// Canterbury-Bankstown, New South Wales
// Carrathool, New South Wales
// Central Coast, New South Wales
// Central Darling, New South Wales
// Cessnock, New South Wales
// Clarence Valley, New South Wales
// Cobar, New South Wales
// Coffs Harbour, New South Wales
// Coolamon, New South Wales
// Coonamble, New South Wales
// Cowra, New South Wales
// Cumberland, New South Wales
// Dungog, New South Wales
// Edward River, New South Wales
// Eurobodalla, New South Wales
// Fairfield, New South Wales
// Federation, New South Wales
// Forbes, New South Wales
// Georges River, New South Wales
// Gilgandra, New South Wales
// Glen Innes Severn, New South Wales
// Goulburn Mulwaree, New South Wales
// Greater Hume Shire, New South Wales
// Griffith, New South Wales
// Gundagai, New South Wales
// Gunnedah, New South Wales
// Gwydir, New South Wales
// Hawkesbury, New South Wales
// Hay, New South Wales
// Hilltops, New South Wales
// Hornsby, New South Wales
// Hunters Hill, New South Wales
// Inner West, New South Wales
// Inverell, New South Wales
// Junee, New South Wales
// Kempsey, New South Wales
// Kiama, New South Wales
// Ku-ring-gai, New South Wales
// Kyogle, New South Wales
// Lachlan, New South Wales
// Lake Macquarie, New South Wales
// Lane Cove, New South Wales
// Leeton, New South Wales
// Lismore, New South Wales
// Lithgow, New South Wales
// Liverpool, New South Wales
// Liverpool Plains, New South Wales
// Lockhart, New South Wales
// Maitland, New South Wales
// Mid-Coast, New South Wales
// Mid-Western Regional, New South Wales
// Moree Plains, New South Wales
// Mosman, New South Wales
// Murray River, New South Wales
// Murrumbidgee, New South Wales
// Muswellbrook, New South Wales
// Nambucca, New South Wales
// Narrabri, New South Wales
// Narrandera, New South Wales
// Narromine, New South Wales
// Newcastle, New South Wales
// North Sydney, New South Wales
// Northern Beaches, New South Wales
// Oberon, New South Wales
// Orange, New South Wales
// Parkes, New South Wales
// Parramatta, New South Wales
// Penrith, New South Wales
// Port Macquarie-Hastings, New South Wales
// Port Stephens, New South Wales
// Queanbeyan-Palerang Regional, New South Wales
// Randwick, New South Wales
// Richmond Valley, New South Wales
// Rockdale, New South Wales
// Ryde, New South Wales
// Shellharbour, New South Wales
// Shoalhaven, New South Wales
// Singleton, New South Wales
// Snowy Monaro Regional, New South Wales
// Snowy Valleys, New South Wales
// Strathfield, New South Wales
// Sutherland Shire, New South Wales
// Sydney, New South Wales
// Tamworth Regional, New South Wales
// Temora, New South Wales
// Tenterfield, New South Wales
// The Hills Shire, New South Wales
// Tweed, New South Wales
// Upper Hunter Shire, New South Wales
// Upper Lachlan Shire, New South Wales
// Uralla, New South Wales
// Wagga Wagga, New South Wales
// Walcha, New South Wales
// Walgett, New South Wales
// Warren, New South Wales
// Warrumbungle Shire, New South Wales
// Waverley, New South Wales
// Weddin, New South Wales
// Wentworth, New South Wales
// Western Plains Regional, New South Wales
// Willoughby, New South Wales
// Wingecarribee, New South Wales
// Wollondilly, New South Wales
// Wollongong, New South Wales
// Woollahra, New South Wales
// Yass Valley, New South Wales
// Unincorporated NSW, New South Wales
// No usual address, New South Wales
// Migratory - Offshore - Shipping, New South Wales
// Alpine, Victoria
// Ararat, Victoria
// Ballarat, Victoria
// Banyule, Victoria
// Bass Coast, Victoria
// Baw Baw, Victoria
// Bayside, Victoria
// Benalla, Victoria
// Boroondara, Victoria
// Brimbank, Victoria
// Buloke, Victoria
// Campaspe, Victoria
// Cardinia, Victoria
// Casey, Victoria
// Central Goldfields, Victoria
// Colac-Otway, Victoria
// Corangamite, Victoria
// Darebin, Victoria
// East Gippsland, Victoria
// Frankston, Victoria
// Gannawarra, Victoria
// Glen Eira, Victoria
// Glenelg, Victoria
// Golden Plains, Victoria
// Greater Bendigo, Victoria
// Greater Dandenong, Victoria
// Greater Geelong, Victoria
// Greater Shepparton, Victoria
// Hepburn, Victoria
// Hindmarsh, Victoria
// Hobsons Bay, Victoria
// Horsham, Victoria
// Hume, Victoria
// Indigo, Victoria
// Kingston, Victoria
// Knox, Victoria
// Latrobe, Victoria
// Loddon, Victoria
// Macedon Ranges, Victoria
// Manningham, Victoria
// Mansfield, Victoria
// Maribyrnong, Victoria
// Maroondah, Victoria
// Melbourne, Victoria
// Melton, Victoria
// Mildura, Victoria
// Mitchell, Victoria
// Moira, Victoria
// Monash, Victoria
// Moonee Valley, Victoria
// Moorabool, Victoria
// Moreland, Victoria
// Mornington Peninsula, Victoria
// Mount Alexander, Victoria
// Moyne, Victoria
// Murrindindi, Victoria
// Nillumbik, Victoria
// Northern Grampians, Victoria
// Port Phillip, Victoria
// Pyrenees, Victoria
// Queenscliffe, Victoria
// South Gippsland, Victoria
// Southern Grampians, Victoria
// Stonnington, Victoria
// Strathbogie, Victoria
// Surf Coast, Victoria
// Swan Hill, Victoria
// Towong, Victoria
// Wangaratta, Victoria
// Warrnambool, Victoria
// Wellington, Victoria
// West Wimmera, Victoria
// Whitehorse, Victoria
// Whittlesea, Victoria
// Wodonga, Victoria
// Wyndham, Victoria
// Yarra, Victoria
// Yarra Ranges, Victoria
// Yarriambiack, Victoria
// Unincorporated Vic, Victoria
// No usual address, Victoria
// Migratory - Offshore - Shipping, Victoria
// Aurukun, Queensland
// Balonne, Queensland
// Banana, Queensland
// Barcaldine, Queensland
// Barcoo, Queensland
// Blackall-Tambo, Queensland
// Boulia, Queensland
// Brisbane, Queensland
// Bulloo, Queensland
// Bundaberg, Queensland
// Burdekin, Queensland
// Burke, Queensland
// Cairns, Queensland
// Carpentaria, Queensland
// Cassowary Coast, Queensland
// Central Highlands, Queensland
// Charters Towers, Queensland
// Cherbourg, Queensland
// Cloncurry, Queensland
// Cook, Queensland
// Croydon, Queensland
// Diamantina, Queensland
// Doomadgee, Queensland
// Douglas, Queensland
// Etheridge, Queensland
// Flinders, Queensland
// Fraser Coast, Queensland
// Gladstone, Queensland
// Gold Coast, Queensland
// Goondiwindi, Queensland
// Gympie, Queensland
// Hinchinbrook, Queensland
// Hope Vale, Queensland
// Ipswich, Queensland
// Isaac, Queensland
// Kowanyama, Queensland
// Livingstone, Queensland
// Lockhart River, Queensland
// Lockyer Valley, Queensland
// Logan, Queensland
// Longreach, Queensland
// Mackay, Queensland
// McKinlay, Queensland
// Mapoon, Queensland
// Maranoa, Queensland
// Mareeba, Queensland
// Moreton Bay, Queensland
// Mornington, Queensland
// Mount Isa, Queensland
// Murweh, Queensland
// Napranum, Queensland
// Noosa, Queensland
// North Burnett, Queensland
// Northern Peninsula Area, Queensland
// Palm Island, Queensland
// Paroo, Queensland
// Pormpuraaw, Queensland
// Quilpie, Queensland
// Redland, Queensland
// Richmond, Queensland
// Rockhampton, Queensland
// Scenic Rim, Queensland
// Somerset, Queensland
// South Burnett, Queensland
// Southern Downs, Queensland
// Sunshine Coast, Queensland
// Tablelands, Queensland
// Toowoomba, Queensland
// Torres, Queensland
// Torres Strait Island, Queensland
// Townsville, Queensland
// Weipa, Queensland
// Western Downs, Queensland
// Whitsunday, Queensland
// Winton, Queensland
// Woorabinda, Queensland
// Wujal Wujal, Queensland
// Yarrabah, Queensland
// No usual address, Queensland
// Migratory - Offshore - Shipping, Queensland
// Adelaide, South Australia
// Adelaide Hills, South Australia
// Alexandrina, South Australia
// Anangu Pitjantjatjara, South Australia
// Barossa, South Australia
// Barunga West, South Australia
// Berri and Barmera, South Australia
// Burnside, South Australia
// Campbelltown, South Australia
// Ceduna, South Australia
// Charles Sturt, South Australia
// Clare and Gilbert Valleys, South Australia
// Cleve, South Australia
// Coober Pedy, South Australia
// Copper Coast, South Australia
// Elliston, South Australia
// Flinders Ranges, South Australia
// Franklin Harbour, South Australia
// Gawler, South Australia
// Goyder, South Australia
// Grant, South Australia
// Holdfast Bay, South Australia
// Kangaroo Island, South Australia
// Karoonda East Murray, South Australia
// Kimba, South Australia
// Kingston, South Australia
// Light, South Australia
// Lower Eyre Peninsula, South Australia
// Loxton Waikerie, South Australia
// Mallala, South Australia
// Maralinga Tjarutja, South Australia
// Marion, South Australia
// Mid Murray, South Australia
// Mitcham, South Australia
// Mount Barker, South Australia
// Mount Gambier, South Australia
// Mount Remarkable, South Australia
// Murray Bridge, South Australia
// Naracoorte and Lucindale, South Australia
// Northern Areas, South Australia
// Norwood Payneham St Peters, South Australia
// Onkaparinga, South Australia
// Orroroo/Carrieton, South Australia
// Peterborough, South Australia
// Playford, South Australia
// Port Adelaide Enfield, South Australia
// Port Augusta, South Australia
// Port Lincoln, South Australia
// Port Pirie City and Dists, South Australia
// Prospect, South Australia
// Renmark Paringa, South Australia
// Robe, South Australia
// Roxby Downs, South Australia
// Salisbury, South Australia
// Southern Mallee, South Australia
// Streaky Bay, South Australia
// Tatiara, South Australia
// Tea Tree Gully, South Australia
// The Coorong, South Australia
// Tumby Bay, South Australia
// Unley, South Australia
// Victor Harbor, South Australia
// Wakefield, South Australia
// Walkerville, South Australia
// Wattle Range, South Australia
// West Torrens, South Australia
// Whyalla, South Australia
// Wudinna, South Australia
// Yankalilla, South Australia
// Yorke Peninsula, South Australia
// Unincorporated SA, South Australia
// No usual address, South Australia
// Migratory - Offshore - Shipping, South Australia
// Albany, Western Australia
// Armadale, Western Australia
// Ashburton, Western Australia
// Augusta-Margaret River, Western Australia
// Bassendean, Western Australia
// Bayswater, Western Australia
// Belmont, Western Australia
// Beverley, Western Australia
// Boddington, Western Australia
// Boyup Brook, Western Australia
// Bridgetown-Greenbushes, Western Australia
// Brookton, Western Australia
// Broome, Western Australia
// Broomehill-Tambellup, Western Australia
// Bruce Rock, Western Australia
// Bunbury, Western Australia
// Busselton, Western Australia
// Cambridge, Western Australia
// Canning, Western Australia
// Capel, Western Australia
// Carnamah, Western Australia
// Carnarvon, Western Australia
// Chapman Valley, Western Australia
// Chittering, Western Australia
// Claremont, Western Australia
// Cockburn, Western Australia
// Collie, Western Australia
// Coolgardie, Western Australia
// Coorow, Western Australia
// Corrigin, Western Australia
// Cottesloe, Western Australia
// Cranbrook, Western Australia
// Cuballing, Western Australia
// Cue, Western Australia
// Cunderdin, Western Australia
// Dalwallinu, Western Australia
// Dandaragan, Western Australia
// Dardanup, Western Australia
// Denmark, Western Australia
// Derby-West Kimberley, Western Australia
// Donnybrook-Balingup, Western Australia
// Dowerin, Western Australia
// Dumbleyung, Western Australia
// Dundas, Western Australia
// East Fremantle, Western Australia
// East Pilbara, Western Australia
// Esperance, Western Australia
// Exmouth, Western Australia
// Fremantle, Western Australia
// Gingin, Western Australia
// Gnowangerup, Western Australia
// Goomalling, Western Australia
// Gosnells, Western Australia
// Greater Geraldton, Western Australia
// Halls Creek, Western Australia
// Harvey, Western Australia
// Irwin, Western Australia
// Jerramungup, Western Australia
// Joondalup, Western Australia
// Kalamunda, Western Australia
// Kalgoorlie/Boulder, Western Australia
// Karratha, Western Australia
// Katanning, Western Australia
// Kellerberrin, Western Australia
// Kent, Western Australia
// Kojonup, Western Australia
// Kondinin, Western Australia
// Koorda, Western Australia
// Kulin, Western Australia
// Kwinana, Western Australia
// Lake Grace, Western Australia
// Laverton, Western Australia
// Leonora, Western Australia
// Mandurah, Western Australia
// Manjimup, Western Australia
// Meekatharra, Western Australia
// Melville, Western Australia
// Menzies, Western Australia
// Merredin, Western Australia
// Mingenew, Western Australia
// Moora, Western Australia
// Morawa, Western Australia
// Mosman Park, Western Australia
// Mount Magnet, Western Australia
// Mount Marshall, Western Australia
// Mukinbudin, Western Australia
// Mundaring, Western Australia
// Murchison, Western Australia
// Murray, Western Australia
// Nannup, Western Australia
// Narembeen, Western Australia
// Narrogin, Western Australia
// Nedlands, Western Australia
// Ngaanyatjarraku, Western Australia
// Northam, Western Australia
// Northampton, Western Australia
// Nungarin, Western Australia
// Peppermint Grove, Western Australia
// Perenjori, Western Australia
// Perth, Western Australia
// Pingelly, Western Australia
// Plantagenet, Western Australia
// Port Hedland, Western Australia
// Quairading, Western Australia
// Ravensthorpe, Western Australia
// Rockingham, Western Australia
// Sandstone, Western Australia
// Serpentine-Jarrahdale, Western Australia
// Shark Bay, Western Australia
// South Perth, Western Australia
// Stirling, Western Australia
// Subiaco, Western Australia
// Swan, Western Australia
// Tammin, Western Australia
// Three Springs, Western Australia
// Toodyay, Western Australia
// Trayning, Western Australia
// Upper Gascoyne, Western Australia
// Victoria Park, Western Australia
// Victoria Plains, Western Australia
// Vincent, Western Australia
// Wagin, Western Australia
// Wandering, Western Australia
// Wanneroo, Western Australia
// Waroona, Western Australia
// West Arthur, Western Australia
// Westonia, Western Australia
// Wickepin, Western Australia
// Williams, Western Australia
// Wiluna, Western Australia
// Wongan-Ballidu, Western Australia
// Woodanilling, Western Australia
// Wyalkatchem, Western Australia
// Wyndham-East Kimberley, Western Australia
// Yalgoo, Western Australia
// Yilgarn, Western Australia
// York, Western Australia
// No usual address, Western Australia
// Migratory - Offshore - Shipping, Western Australia
// Break O'Day, Tasmania
// Brighton, Tasmania
// Burnie, Tasmania
// Central Coast, Tasmania
// Central Highlands, Tasmania
// Circular Head, Tasmania
// Clarence, Tasmania
// Derwent Valley, Tasmania
// Devonport, Tasmania
// Dorset, Tasmania
// Flinders, Tasmania
// George Town, Tasmania
// Glamorgan/Spring Bay, Tasmania
// Glenorchy, Tasmania
// Hobart, Tasmania
// Huon Valley, Tasmania
// Kentish, Tasmania
// King Island, Tasmania
// Kingborough, Tasmania
// Latrobe, Tasmania
// Launceston, Tasmania
// Meander Valley, Tasmania
// Northern Midlands, Tasmania
// Sorell, Tasmania
// Southern Midlands, Tasmania
// Tasman, Tasmania
// Waratah/Wynyard, Tasmania
// West Coast, Tasmania
// West Tamar, Tasmania
// No usual address, Tasmania
// Migratory - Offshore - Shipping, Tasmania
// Alice Springs, Northern Territory
// Barkly, Northern Territory
// Belyuen, Northern Territory
// Central Desert, Northern Territory
// Coomalie, Northern Territory
// Darwin, Northern Territory
// East Arnhem, Northern Territory
// Katherine, Northern Territory
// Litchfield, Northern Territory
// MacDonnell, Northern Territory
// Palmerston, Northern Territory
// Roper Gulf, Northern Territory
// Tiwi Islands, Northern Territory
// Victoria Daly, Northern Territory
// Wagait, Northern Territory
// West Arnhem, Northern Territory
// West Daly, Northern Territory
// Unincorporated NT, Northern Territory
// No usual address, Northern Territory
// Migratory - Offshore - Shipping, Northern Territory
// Unincorporated ACT, Australian Capital Territory
// No usual address, Australian Capital Territory
// Migratory - Offshore - Shipping, Australian Capital Territory
// Unincorp. Other Territories, Other Territories
// No usual address, Other Territories
// Migratory - Offshore - Shipping, Other Territories