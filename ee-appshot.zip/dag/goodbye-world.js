Map.addLayer(ee.Image(0))
Map.add(ui.Label("Goodbye World!"))