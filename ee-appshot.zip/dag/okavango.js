Map.addLayer(ee.Image(1000), {opacity: 0.5})
Map.setCenter(24,-24,6)