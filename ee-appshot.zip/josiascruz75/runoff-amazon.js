var Amazon = ui.import && ui.import("Amazon", "table", {
      "id": "projects/ee-josiascruz75/assets/RHA_TOA"
    }) || ee.FeatureCollection("projects/ee-josiascruz75/assets/RHA_TOA"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 0.01,
        "gamma": 0.1
      }
    }) || {"opacity":0.01,"gamma":0.1};
/******************************************area inicial*********************************************/
Map.setOptions('SATELLITE');
var Amazon = ee.FeatureCollection('projects/ee-josiascruz/assets/RH')
  .filter(ee.Filter.eq('NOME', 'AMAZON'));
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: Amazon,
  color: 1,
  width: 0.5
});
 Map.centerObject(Amazon, 5);
var mainPanel = ui.Panel({
  style: { width: '400px' }
});
/**********************************Legend - precipitation - CHIRPS *********************************/
var palette1 = ['red', 'orange', 'yellow', 'green', 'cyan', 'blue', 'darkblue'];
function createColorBar(titleText, palette, min, max) {
  // Legend Title
  var title = ui.Label({
    value: titleText, 
    style: {fontWeight: 'bold', textAlign: 'center', stretch: 'horizontal'}});
  // Colorbar
  var legend = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 50, 0.1],
      dimensions: '400x10',
      format: 'png', 
      min: 0, max: 50,
      palette: palette},
    style: {stretch: 'vertical', margin: '4px 4px', maxHeight: '4px'},
  });
  // Legend Labels
  var labels = ui.Panel({
    widgets: [
      ui.Label(min, {margin: '4px 20px',textAlign: 'left', stretch: 'horizontal'}),
      ui.Label((min+max)/2, {margin: '4px 20px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(max, {margin: '2px 20px',textAlign: 'right', stretch: 'horizontal'})],
    layout: ui.Panel.Layout.flow('horizontal')});
  // Create a panel with all 3 widgets
  var legendPanel = ui.Panel({
    widgets: [title, legend, labels],
    style: {position: 'bottom-right', padding: '4px 5px'}
  });
  return legendPanel;
}
// Call the function to create a colorbar legend  
var colorBar = createColorBar('Precipitation (mm)', palette1, 0, 50);
/**********************************Legenda Runoff CHIRPS********************************************/
var palette1 = ['1a3678', '2955bc', '5699ff', '8dbae9', 'acd1ff', 'caebff', 'e5f9ff', 'fdffb4', 'ffe6a2', 'ffc969', 'ffa12d', 'ff7c1f', 'ca531a', 'ff0000', 'ab0000'];
function createColorBar1(titleText, palette, min, max) {
  // Legend Title
  var title = ui.Label({
    value: titleText, 
    style: {fontWeight: 'bold', textAlign: 'center', stretch: 'horizontal'}});
  // Colorbar
  var legend = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 15, 0.1],
      dimensions: '400x10',
      format: 'png', 
      min: 0, max: 15,
      palette: palette},
    style: {stretch: 'vertical', margin: '4px 4px', maxHeight: '4px'},
  });
  // Legend Labels
  var labels = ui.Panel({
    widgets: [
      ui.Label(min, {margin: '4px 20px',textAlign: 'left', stretch: 'horizontal'}),
      ui.Label((min+max)/2, {margin: '4px 20px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(max, {margin: '2px 20px',textAlign: 'right', stretch: 'horizontal'})],
    layout: ui.Panel.Layout.flow('horizontal')});
  // Create a panel with all 3 widgets
  var legendPanel = ui.Panel({
    widgets: [title, legend, labels],
    style: {position: 'bottom-right', padding: '4px 5px'}
  });
  return legendPanel;
}
// Call the function to create a colorbar legend  
var colorBar1 = createColorBar1('Runoff (mm)', palette1, 0, 15);
/**********************************Parâmentros inicias do runoff, título e botões******************/
var title3 = ui.Label({
  value: 'GEE RUNOFF AMAZON CHIRPS',
  style: { 'fontSize': '20px', 'fontWeight': 'bold', 'textAlign': 'center', 'padding': '10px 1px 1px 60px' }
});
mainPanel.add(title3);
var title = ui.Label({
  value: ('Start date                 End data                 Curve Number            λ'),
  style: { whiteSpace: 'pre-wrap','fontSize': '12px','fontWeight': 'bold' }
});
mainPanel.add(title);
// Valor padrão para lambda (indice de perda inicial)
var λ = 0.2;
// Variáveis globais
var Ia = ee.Image().byte();  // Inicializa com uma imagem vazia
var S;  // Será definido posteriormente
// Função para calcular o runoff diário para cada imagem na coleção CHIRPS.
var calculateDailyRunoff = function (image) {
  var a = image.subtract(Ia);
  var mask = a.gt(0);
  var Pef = a.multiply(mask);
  var percent = 1 - λ;
  // Cálculo de runoff diário.
  var runoff_daily = Pef.pow(2).divide(image.add(S.multiply(percent))).rename('runoff_daily');
  // Adicionar uma propriedade de tempo válido
  runoff_daily = runoff_daily.set('system:time_start', image.get('system:time_start'));
  return runoff_daily;
};
var dropdownPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
});
mainPanel.add(dropdownPanel);
var dropdownPanel1 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
});
mainPanel.add(dropdownPanel1);
// Adicionar botões e caixas de texto para entrada de dados
var startChirpsDateTextbox = ui.Textbox({ placeholder: 'yyyy-mm-dd', style: { width: '90px' ,'fontSize': '10px','fontWeight': 'bold' }});
// Adicione um texto acima do botão
var endChirpsDateTextbox = ui.Textbox({ placeholder: 'yyyy-mm-dd',  style: { width: '90px' ,'fontSize': '10px','fontWeight': 'bold' }});
//var button = ui.Button('Load');
dropdownPanel.add(startChirpsDateTextbox );
dropdownPanel.add(endChirpsDateTextbox);
var cnYearSelector = ui.Select({
  placeholder: 'Year CN',
  items: [
    { label: '2009', value: 2009 },
    { label: '2014', value: 2014 },
    { label: '2019', value: 2019 },
    { label: '2024', value: 2024 },
    { label: '2029', value: 2029 },
    { label: '2034', value: 2034 },
    { label: '2039', value: 2039 },
    { label: '2044', value: 2044 },
    { label: '2049', value: 2049 }
  ],
});
dropdownPanel.add(cnYearSelector);
// Adicionar caixa de seleção para o valor de Ia
var iaValueSelector = ui.Select({
  items: ['0.15', '0.2', '0.25', '0.3'],  // Adicione ou remova valores conforme necessário
  value: '0.2'
});
iaValueSelector.setPlaceholder('Selecione o valor de λ ');
// Adicionar o evento de mudança para capturar o novo valor selecionado
iaValueSelector.onChange(function (value) {
  Ia = S.multiply(parseFloat(value));
});
dropdownPanel.add(iaValueSelector);
// Adicionar botão de reset
var resetButton = ui.Button({
  label: 'Reset',
  onClick: function () {
    Map.clear();
    // Redefinir variáveis globais
    Ia = ee.Image().byte();
    S = null;
  },
});
/**********************************carrega os cálculos e as coleções*******************************/
var loadButton = ui.Button('Load Data', function () {
  // Obter as datas e o ano selecionado
  var startChirpsDate = startChirpsDateTextbox.getValue();
  var endChirpsDate = endChirpsDateTextbox.getValue();
  var cnYear = cnYearSelector.getValue();
  // Carregar imagens CHIRPS para o intervalo especificado
  var CHIRPS = ee.ImageCollection('UCSB-CHG/CHIRPS/DAILY')
    .select('precipitation')
    .filter(ee.Filter.date(startChirpsDate, endChirpsDate))
    .filterBounds(Amazon)
    .map(function (image) {
      var time_start = image.get('system:time_start');
      var clippedImage = image.clip(Amazon);
      var resampledImage = clippedImage.resample('bilinear').reproject({
        crs: 'EPSG:4326',
        scale: 27830
      });
      return resampledImage.set('system:time_start', time_start).clip(Amazon);
    });
  // Carregar a imagem CN para o ano selecionado
  var CN = ee.Image('projects/ee-josiascruz75/assets/CN_' + cnYear);
  // Definir variável global S
  S = CN.expression('(25400 / (cn))-254', { 'cn': CN.select('b1') });
  // Cálculo de perdas iniciais = 0.2S
  Ia = S.multiply(parseFloat(iaValueSelector.getValue()));
  // Aplicar a função a cada imagem na coleção CHIRPS.
  var runoff_daily_collection = CHIRPS.map(calculateDailyRunoff);
  // Adicionar camada CHIRPS
  Map.addLayer(CHIRPS, { min: 0, max: 80, palette: ["04fff3", "01b8b8", "075fe4", "0310b4", "03017c"] }, 'Precipitation CHIRPS');
Map.onClick(function(coords) {
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chartPoint = ui.Chart.image.seriesByRegion({
    imageCollection: CHIRPS,
    regions: point,
    reducer: ee.Reducer.mean(),
    scale: 2500,
    xProperty: 'system:time_start',
    seriesProperty: 'system:index'
  })
  .setOptions({
    title: 'Daily precipitation CHIRPS',
    hAxis: {title: 'Day'},
    vAxis: {title: 'Precipitation (mm)'}
  })
  .setChartType('LineChart');
  // Adicionar o gráfico na posição inferior esquerda
  var chartPanel1 = ui.Panel({
    widgets: [chartPoint],
    style: {
      width: '500px',
      position: 'bottom-left'
    }
  });
  // Adicionar o botão de fechar ao painel do gráfico
  var closeButton = ui.Button({
    label: 'Fechar Gráfico',
    onClick: function () {
      // Remover o painel do gráfico ao clicar no botão
      Map.remove(chartPanel1);
    }
  });
  chartPanel1.add(closeButton);
  Map.add(chartPanel1);
});
  // Adicionar camada de runoff
  var runoffLayer = runoff_daily_collection;
  Map.addLayer(runoffLayer, { min: 0, max: 15, palette:['1a3678', '2955bc', '5699ff', '8dbae9', 'acd1ff', 
  'caebff', 'e5f9ff', 'fdffb4', 'ffe6a2', 'ffc969', 'ffa12d', 
  'ff7c1f', 'ca531a', 'ff0000', 'ab0000']}, 'Runoff CHIRPS');
  Map.setOptions('SATELLITE');
  Map.centerObject(Amazon, 5);
  Map.addLayer(outline, { palette: '#000000' }, 'Hydrographic basins', 1);
Map.onClick(function(coords) {
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chartPoint = ui.Chart.image.seriesByRegion({
    imageCollection: runoff_daily_collection,
    regions: point,
    reducer: ee.Reducer.mean(),
    scale: 2500,
    xProperty: 'system:time_start',
    seriesProperty: 'system:index'
  })
  .setOptions({
    title: 'Runoff Diário - CHIRPS',
    hAxis: {title: 'Dias'},
    vAxis: {title: 'Runoff (mm)'}
  })
  .setChartType('LineChart');
  // Adicionar o gráfico na posição inferior esquerda
  var chartPanel1 = ui.Panel({
    widgets: [chartPoint],
    style: {
      width: '500px',
      position: 'bottom-right'
    }
  });
  // Adicionar o botão de fechar ao painel do gráfico
  var closeButton = ui.Button({
    label: 'Fechar Gráfico',
    onClick: function () {
      // Remover o painel do gráfico ao clicar no botão
      Map.remove(chartPanel1);
    }
  });
  chartPanel1.add(closeButton);
  Map.add(chartPanel1);
});
/******************* Criar uma série temporal para representar o runoff diário para cada região.***/
  var series = runoff_daily_collection.map(function (image) {
    var runoff = image.reduceRegions({
      collection: Amazon,
      reducer: ee.Reducer.mean(),
      scale: 2500
    });
    var time = image.get('system:time_start');
    return runoff.map(function (feature) {
      return feature.set('time', time);
    });
  }).flatten();
  // Exportar os dados como CSV
  Export.table.toDrive({
    collection: series,
    description: 'Runoff_Data',
    fileFormat: 'CSV'
  });
/*********************add os botões ao painel******************************************************/
});
mainPanel.add(colorBar);
mainPanel.add(colorBar1);
dropdownPanel1.add(loadButton);
dropdownPanel1.add(resetButton);
/*************************************area of aplication*******************************************/
var Amazon = ee.FeatureCollection('projects/ee-josiascruz/assets/RH')
  .filter(ee.Filter.eq('NOME', 'AMAZON'));
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: Amazon,
  color: 1,
  width: 0.5
});
/**************************************side panel**************************************************/
 //var mainPanel = ui.Panel({
 // style: { width: '400px' }
//});
/**********************************Legend - corrected precipitation GCM ***************************/
var palette1 = ['red', 'orange', 'yellow', 'green', 'cyan', 'blue', 'darkblue'];
function createColorBar(titleText, palette, min, max) {
  // Legend Title
  var title = ui.Label({
    value: titleText, 
    style: {fontWeight: 'bold', textAlign: 'center', stretch: 'horizontal'}});
  // Colorbar
  var legend = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 50, 0.1],
      dimensions: '400x10',
      format: 'png', 
      min: 0, max: 50,
      palette: palette},
    style: {stretch: 'vertical', margin: '8px 8px', maxHeight: '10px'},
  });
  // Legend Labels
  var labels = ui.Panel({
    widgets: [
      ui.Label(min, {margin: '4px 20px',textAlign: 'left', stretch: 'horizontal'}),
      ui.Label((min+max)/2, {margin: '4px 20px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(max, {margin: '2px 20px',textAlign: 'right', stretch: 'horizontal'})],
    layout: ui.Panel.Layout.flow('horizontal')});
  // Create a panel with all 3 widgets
  var legendPanel = ui.Panel({
    widgets: [title, legend, labels],
    style: {position: 'bottom-right', padding: '8px 10px'}
  });
  return legendPanel;
}
// Call the function to create a colorbar legend  
var colorBar = createColorBar('Precipitation (mm)', palette1, 0, 50);
/*****************************************************************************************/
/************************Legend Runoff GCM**************************************************/
var palette1 = ['1a3678', '2955bc', '5699ff', '8dbae9', 'acd1ff', 'caebff', 'e5f9ff', 'fdffb4', 'ffe6a2', 'ffc969', 'ffa12d', 'ff7c1f', 'ca531a', 'ff0000', 'ab0000'];
function createColorBar1(titleText, palette, min, max) {
  // Legend Title
  var title = ui.Label({
    value: titleText, 
    style: {fontWeight: 'bold', textAlign: 'center', stretch: 'horizontal'}});
  // Colorbar
  var legend = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 10, 0.1],
      dimensions: '400x10',
      format: 'png', 
      min: 0, max: 10,
      palette: palette},
    style: {stretch: 'vertical', margin: '8px 8px', maxHeight: '10px'},
  });
  // Legend Labels
  var labels = ui.Panel({
    widgets: [
      ui.Label(min, {margin: '4px 20px',textAlign: 'left', stretch: 'horizontal'}),
      ui.Label((min+max)/2, {margin: '4px 20px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(max, {margin: '2px 20px',textAlign: 'right', stretch: 'horizontal'})],
    layout: ui.Panel.Layout.flow('horizontal')});
  // Create a panel with all 3 widgets
  var legendPanel = ui.Panel({
    widgets: [title, legend, labels],
    style: {position: 'bottom-right', padding: '8px 10px'}
  });
  return legendPanel;
}
// Call the function to create a colorbar legend  
var colorBar1 = createColorBar1('Runoff (mm)', palette1, 0, 10);
/********************************************************************************************/
/**********************************Títulos e Texto Runoff GCM *******************************************/
var title3 = ui.Label({
  value: 'GEE RUNOFF AMAZON CMIP6',
  style: { 'fontSize': '20px', 'fontWeight': 'bold', 'textAlign': 'center', 'padding': '10px 1px 1px 60px' }
});
mainPanel.add(title3);
var title = ui.Label({
  value: (' Start date                  End data               Curve Number            λ'),
  style: { whiteSpace: 'pre-wrap','fontSize': '12px','fontWeight': 'bold' }
});
mainPanel.add(title);
/******************************************************************************************************/
/*********************************funções de cálculo de runoff ********************************/
// Valor padrão para lambda (indice de perda inicial)
var λ = 0.2;
// Variáveis globais
var Ia = ee.Image().byte();  // Inicializa com uma imagem vazia
var S;  // Será definido posteriormente
// Função para calcular o runoff diário para cada imagem na coleção CHIRPS.
var calculateDailyRunoff = function (image) {
  var a = image.subtract(Ia);
  var mask = a.gt(0);
  var Pef = a.multiply(mask);
  var percent = 1 - λ;
  // Cálculo de runoff diário.
  var runoff_daily = Pef.pow(2).divide(image.add(S.multiply(percent))).rename('runoff_daily');
  // Adicionar uma propriedade de tempo válido
  runoff_daily = runoff_daily.set('system:time_start', image.get('system:time_start'));
  return runoff_daily;
};
/*********************************************************************************************************/
/******************************Função de gráfico por região ********************************************/
// Função para criar o gráfico de dispersão
var createScatterChart = function (series, year) {
  var charts = ui.Chart.feature.groups({
    features: series,
    xProperty: 'time',
    yProperty: 'mean',
    seriesProperty: 'PS1_NM_1'
  }).setOptions({
    title: 'Runoff Diário CHIRPS - ' + year,
    hAxis: { title: 'Data' },
    vAxis: { title: 'Runoff (mm)' },
    lineWidth: 1,
    pointSize: 3,
  });
  // Adicionar o gráfico na posição inferior esquerda
  var chartPanel = ui.Panel({
    widgets: [charts],
    style: {
      width: '500px',
      position: 'bottom-rigth'
    }
  });
    var closeButton = ui.Button({
    label: 'Fechar Gráfico',
    onClick: function () {
      // Remover o painel do gráfico ao clicar no botão
      Map.remove(chartPanel);
    }
  });
  chartPanel.add(closeButton);
   Map.add(chartPanel);
};
/*******************************Lista de modelos, cenários, datas e botões*************************/
var dropdownPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
});
mainPanel.add(dropdownPanel);
var dropdownPanel1 = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
});
mainPanel.add(dropdownPanel1);
// Adicionar botões e caixas de texto para entrada de dados
var startGCMDateTextbox = ui.Textbox({ placeholder: 'yyyy-mm-dd', style: { width: '90px' ,'fontSize': '10px','fontWeight': 'bold' }});
// Adicione um texto acima do botão
var endGCMDateTextbox = ui.Textbox({ placeholder: 'yyyy-mm-dd', style: { width: '90px' ,'fontSize': '10px','fontWeight': 'bold' }});
dropdownPanel.add(startGCMDateTextbox );
dropdownPanel.add(endGCMDateTextbox);
var modelScenarioPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
});
var modelSelectorpr = ui.Select({
  placeholder: 'please wait..',
});
var RCPSelectorpr = ui.Select({
  placeholder: 'please wait..',
});
var RCP = ee.List(['ssp245', 'ssp585','historical']);
var modelpr = ee.List(['ACCESS-CM2', 'ACCESS-ESM1-5', 'BCC-CSM2-MR', 'CESM2', 'CESM2-WACCM', 
'CMCC-CM2-SR5', 'CMCC-ESM2', 'CNRM-CM6-1', 'CNRM-ESM2-1', 'CanESM5', 'EC-Earth3', 'EC-Earth3-Veg-LR',
'FGOALS-g3', 'GFDL-CM4', 'GFDL-ESM4', 'GISS-E2-1-G', 'HadGEM3-GC31-LL', 'IITM-ESM',
'INM-CM4-8', 'INM-CM5-0', 'IPSL-CM6A-LR', 'KACE-1-0-G', 'KIOST-ESM', 'MIROC-ES2L', 'MIROC6', 
'MPI-ESM1-2-HR', 'MPI-ESM1-2-LR', 'MRI-ESM2-0', 'NESM3', 'NorESM2-LM', 'NorESM2-MM', 'TaiESM1', 'UKESM1-0-LL']);
//var button = ui.Button('Load');
var RCPStrings = RCP.map(function(RCP){
  return RCP;
});
var modelStrings = modelpr.map(function(modelpr){
  return modelpr;
});
RCPStrings.evaluate(function(RCPList) {
  RCPSelectorpr.items().reset(RCPList);
  RCPSelectorpr.setPlaceholder('Scenario');
});
  modelStrings.evaluate(function(modelList) {
  modelSelectorpr.items().reset(modelList);
  modelSelectorpr.setPlaceholder('Model');
});
dropdownPanel1.add(modelSelectorpr);
dropdownPanel1.add(RCPSelectorpr);
var cnGCMYearSelector = ui.Select({
  placeholder: 'Year CN',
  items: [
    { label: '2009', value: 2009 },
    { label: '2014', value: 2014 },
    { label: '2019', value: 2019 },
    { label: '2024', value: 2024 },
    { label: '2029', value: 2029 },
    { label: '2034', value: 2034 },
    { label: '2039', value: 2039 },
    { label: '2044', value: 2044 },
    { label: '2049', value: 2049 }
  ],
});
dropdownPanel.add(cnGCMYearSelector);
// Adicionar caixa de seleção para o valor de Ia
var iaValueSelector = ui.Select({
  items: ['0.15', '0.2', '0.25', '0.3'],  // Adicione ou remova valores conforme necessário
  value: '0.2'
});
iaValueSelector.setPlaceholder('Selecione o valor de λ ');
// Adicionar o evento de mudança para capturar o novo valor selecionado
iaValueSelector.onChange(function (value) {
  Ia = S.multiply(parseFloat(value));
});
dropdownPanel.add(iaValueSelector);
// Adicionar botão de reset
var resetButton = ui.Button({
  label: 'Reset',
  onClick: function () {
    Map.clear();
    // Redefinir variáveis globais
    Ia = ee.Image().byte();
    S = null;
  },
});
/***************************************carrega os cálculos de runoff******************************/
var loadButton = ui.Button('Load Data', function () {
  // Obter as datas e o ano selecionado
  var startGCMDate = startGCMDateTextbox.getValue();
  var endGCMDate = endGCMDateTextbox.getValue();
  var cnGCMYear = cnGCMYearSelector.getValue();
    // Carrega a coleção de features para as bacias hidrográficas da Amazônia
  var Fator = ee.Image('projects/ee-josiascruz/assets/FC-'+modelSelectorpr.getValue());
// Coleção de imagem dos modelos GCM do CMIP6 para o período de 2015 a 2025
var chuva = ee.ImageCollection('NASA/GDDP-CMIP6')
  .select('pr')
  .filterMetadata('scenario', 'equals', RCPSelectorpr.getValue())
  .filterMetadata('model', 'equals', modelSelectorpr.getValue())
  .filter(ee.Filter.date(startGCMDate, endGCMDate))
  .filterBounds(Amazon)
  .map(function (image) {
    var time_start = image.get('system:time_start');
    return image.multiply(86400).set('system:time_start', time_start).clip(Amazon);
  });
// Função para multiplicar cada imagem pelo seu correspondente fator
var multiplyByFactor = function (image) {
  // Obtém o mês da imagem
  var month = ee.Date(image.get('system:time_start')).get('month');
  // Obtém o nome do mês em inglês a partir do número do mês
  var monthNames = [
    'January', 'February', 'March', 'April',
    'May', 'June', 'July', 'August',
    'September', 'October', 'November', 'December'
  ];
  var monthName = ee.List(monthNames).get(month.subtract(1)); // subtrai 1 porque os meses começam do zero no Earth Engine
  // Multiplica a banda 'pr' pela banda correspondente do fator
  var multipliedImage = image.multiply(Fator.select([monthName]));
  // Define propriedades adicionais, se necessário
  multipliedImage = multipliedImage.set({
    'system:time_start': image.get('system:time_start'),
    'month': monthName
  });
  return multipliedImage.rename(['pr']);
};
 // Aplica a função a cada imagem na coleção 'NASA/GDDP-CMIP6'
  var chuvacorrigidaGCM = chuva.map(multiplyByFactor);
  // Adiciona a camada ao mapa
  Map.addLayer(chuvacorrigidaGCM, { min: 0, max: 80, palette: ["04fff3", "01b8b8", "075fe4", "0310b4", 
  "03017c"] }, 'corrected precipitation GCM'+modelSelectorpr.getValue());
/*******************************************gráficos***********************************************/
Map.onClick(function(coords) {
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chartPoint = ui.Chart.image.seriesByRegion({
    imageCollection: chuvacorrigidaGCM,
    regions: point,
    reducer: ee.Reducer.mean(),
    scale: 2500,
    xProperty: 'system:time_start',
    seriesProperty: 'system:index'
  })
  .setOptions({
    title: 'Daily precipitation corrected' +' '+  modelSelectorpr.getValue(),
    hAxis: {title: 'Day'},
    vAxis: {title: 'Precipitation (mm)'}
  })
  .setChartType('LineChart');
  // Adicionar o gráfico na posição inferior esquerda
  var chartPanel1 = ui.Panel({
    widgets: [chartPoint],
    style: {
      width: '500px',
      height:'280px',
      position: 'bottom-left',
    }
  });
  // Adicionar o botão de fechar ao painel do gráfico
  var closeButton = ui.Button({
    label: 'Fechar Gráfico',
    onClick: function () {
      // Remover o painel do gráfico ao clicar no botão
      Map.remove(chartPanel1);
    }
  });
  chartPanel1.add(closeButton);
  Map.add(chartPanel1);
});
  // Carregar a imagem CN para o ano selecionado
  var CNGCM = ee.Image('projects/ee-josiascruz75/assets/CN_' + cnGCMYear);
  // Definir variável global S
  S = CNGCM.expression('(25400 / (cn))-254', { 'cn': CNGCM.select('b1') });
  // Cálculo de perdas iniciais = 0.2S
  Ia = S.multiply(parseFloat(iaValueSelector.getValue()));
  // Aplicar a função a cada imagem na coleção CHIRPS.
  var runoff_daily_collectionGCM = chuvacorrigidaGCM.map(calculateDailyRunoff);
  // Adicionar camada de runoff
  //var runoffLayer = runoff_daily_collectionGCM.mean();
  Map.addLayer(runoff_daily_collectionGCM, { min: 0, max: 15, palette:['1a3678', '2955bc', '5699ff',
  '8dbae9', 'acd1ff', 'caebff', 'e5f9ff', 'fdffb4', 'ffe6a2', 'ffc969', 'ffa12d',
  'ff7c1f', 'ca531a', 'ff0000', 'ab0000'] }, 'Runoff'+ modelSelectorpr.getValue());
  Map.setOptions('SATELLITE');
  Map.centerObject(Amazon, 5);
  Map.addLayer(outline, { palette: '#000000' }, 'Bacias Hidrográficas Amazon', 1);
Map.onClick(function(coords) {
  var pointGCM = ee.Geometry.Point(coords.lon, coords.lat);
  var chartPointGCM = ui.Chart.image.seriesByRegion({
    imageCollection: runoff_daily_collectionGCM,
    regions: pointGCM,
    reducer: ee.Reducer.mean(),
    scale: 2500,
    xProperty: 'system:time_start',
    seriesProperty: 'system:index'
  })
  .setOptions({
    title: 'Runoff Diário'+' '+  modelSelectorpr.getValue(),
    hAxis: {title: 'Dias'},
    vAxis: {title: 'Runoff (mm)'}
  })
  .setChartType('LineChart');
  // Adicionar o gráfico na posição inferior esquerda
  var chartPanel1 = ui.Panel({
    widgets: [chartPointGCM],
    style: {
      width: '500px',
       height:'280px',
      position: 'bottom-right'
    }
  });
  // Adicionar o botão de fechar ao painel do gráfico
  var closeButton = ui.Button({
    label: 'Fechar Gráfico',
    onClick: function () {
      // Remover o painel do gráfico ao clicar no botão
      Map.remove(chartPanel1);
    }
  });
  chartPanel1.add(closeButton);
  Map.add(chartPanel1);
});
});
mainPanel.add(colorBar)
mainPanel.add(colorBar1);
dropdownPanel1.add(loadButton);
dropdownPanel1.add(resetButton);
// Adicionar o painel principal ao mapa
ui.root.add(mainPanel);
var title2 = ui.Label({
  value: 'Reference' ,
  style: {'fontSize': '16px'}
});
mainPanel.add(title2);
/**************************************************************referencias*******************************/
var reference = ui.Label({
  value: 'DA SILVA CRUZ, Josias; BLANCO, Claudio José Cavalcante; DE OLIVEIRA JÚNIOR, José Francisco.'+
  'Modeling of land use and land cover change dynamics for future projection of the Amazon number curve.'+
  'Science of The Total Environment, v. 811, p. 152348, 2022.\nhttps://doi.org/10.1016/j.scitotenv.2021.152348',
   style: {'fontSize': '10px'}
 });
mainPanel.add(reference);
var reference2 = ui.Label({
  value: 'Funk, Chris, Pete Peterson, Martin Landsfeld, Diego Pedreros, James Verdin, Shraddhanand Shukla,'+
  'Gregory Husak, James Rowland, Laura Harrison, Andrew Hoell & Joel Michaelsen. "The climate hazards infrared'+
  'precipitation with stations—a new environmental record for monitoring extremes". Scientific Data 2, 150066.'+
  'doi:10.1038/sdata.2015.66 2015.',
  style: {'fontSize': '10px'}
 });
mainPanel.add(reference2);
var reference3 = ui.Label({
  value:'Thrasher, B., Maurer, E. P., McKellar, C., & Duffy, P. B., 2012: Technical Note: Bias correcting '+
  'climate model simulated daily temperature extremes with quantile mapping. Hydrology and Earth System Sciences,'+
  '16(9), 3309-3314. doi:10.5194/hess-16-3309-2012',
  style: {'fontSize': '10px'}
 });
mainPanel.add(reference3);
var reference4 = ui.Label({
  value:'Thrasher, B., Wang, W., Michaelis, A. et al. NASA Global Daily Downscaled Projections, CMIP6.'+
  ' Sci Data 9, 262 (2022). https://doi.org/10.1038/s41597-022-01393-4',
  style: {'fontSize': '10px'}
 });
mainPanel.add(reference4);
var logo = ui.Thumbnail({
  image: ee.Image('projects/ee-josiascruz/assets/Logos_aap1'), 
  params: {min: 0, max: 255}, 
  style: {
    height: '220px',
    width: '290px'
  }
});
var logoPanel = ui.Panel({
  widgets: [logo], 
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {height: '17%', margin: '20px 4px 4px 16px','position':'bottom-center'}
});
mainPanel.add(logoPanel);
//Map.add(logoPanel);
var autor = ui.Label({
  value:'Authors: Cruz and Blanco.',
  style: {'fontSize': '12px', 'position':'bottom-left'}
 });
mainPanel.add(autor);
var instructionPanel = ui.Panel({
  widgets: [
    ui.Label({
      value: 'Instrution:\nGEEAmazonRunoff generates the runoff for the Amazon and Tocantins-Araguaia Watershed from the year 2009 until 2050.' +
        'To generate the runoff just add the precipitation year and the CN referring to the year, each CN has a time window' +
        'of 5 years, for example: the CN of 2009 can be used until 2013.' + '            ' + 'Attention: reset when generating runoff. ',
      style: {'fontSize': '12px', 'fontWeight': 'bold', 'color': 'red', 'width': '400px', 'padding': '2px'},
    }),
    ui.Button({
      label: 'Close',
      onClick: function() {
        Map.clear();
      }
    })
  ],
  style: {position: 'top-center'}
});
Map.add(instructionPanel);