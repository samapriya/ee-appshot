var left = ui.Map();
var right = ui.Map();
var right2 = ui.Map();
ui.root.clear();
ui.root.add(left);
ui.root.add(right);
ui.root.add(right2);
ui.Map.Linker([left, right,right2], 'change-bounds');
var fires = ee.ImageCollection('FIRMS')
  .filterDate('2019-01-01','2019-08-20')
  .select(['confidence']);
right2.addLayer(ee.Image(0).visualize({palette:['ff0000']}).mask(fires.mosaic().gt(20)),{min:50,max:100});
right2.add(ui.Label('Enero - Agosto /2019',{position: 'bottom-center',fontSize:'24px',backgroundColor:'blue'}))
var fires2 = ee.ImageCollection('FIRMS')
  .filterDate('2018-01-01','2018-08-20')
  .select(['confidence']);
right.addLayer(ee.Image(0).visualize({palette:['ff0000']}).mask(fires2.mosaic().gt(20)),{min:50,max:100});
right.add(ui.Label('Enero - Agosto /2018',{position: 'bottom-center',fontSize:'24px',backgroundColor:'blue'}))
var fires3 = ee.ImageCollection('FIRMS')
  .filterDate('2017-01-01','2017-08-20')
  .select(['confidence']);
left.addLayer(ee.Image(0).visualize({palette:['ff0000']}).mask(fires3.mosaic().gt(20)),{min:50,max:100});
left.add(ui.Label('Enero - Agosto /2017',{position: 'bottom-center',fontSize:'24px',backgroundColor:'blue'}))
left.setCenter(-51.701, -10.271,5)