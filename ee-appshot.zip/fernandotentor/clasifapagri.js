var imageVisParam2 = {"opacity":1,"bands":["classification"],"palette":["ff460f","ffec09","09ff11","0dffc7","0f22ff","ff0fe1"]};
var imageVisParam = {"opacity":1,"bands":["B8","B12","B4"],"min":0.1108011021850418,"max":0.5501495175739778,"gamma":1};
var imageVisParam2 = {'min': 0,'max':8,"opacity":1,"bands":["classification"],"palette":["ff460f","ffec09","09ff11","0dffc7","0f22ff","ff0fe1"]};
// tabla con campos (ultivo,codigo,random) capa de puntos
var area = ee.FeatureCollection('ft:1a_4eJQuzeXZ4FeaiGD-hv-k_JMX6y3dGuZ5m894r');
var lotes = ee.FeatureCollection('ft:1rCMtplTShQEuDDWDXLpxDP28SlGK9Q4diNg_GxK1');
var table = ee.FeatureCollection('ft:1XP0vzziwXjwoa2ztbvOD_wKggdPu1t6M2328uopq');// capa de puntos
print (lotes)
var producto = ee.ImageCollection('COPERNICUS/S2');
// centrar en área de estudio
Map.centerObject(table, 12);
Map.addLayer(table,{},'Cultivos',false)
Map.addLayer(area,{},'area',false)
// Bandas a utilizar
var bandas = ['B3','B4','B5','B6','B7','B8','B11','B12'];
// Filtrar colección
var coleccion1 = producto
      .filterBounds(area)
      .filterDate('2018-10-01', '2018-11-01')
      .sort('CLOUDY_PIXEL_PERCENTAGE',false)
      //.select(bandas)
       //.limit(4);
print (coleccion1);
// mascara de nubes NUEVO
function sentinelCloudScore(toa) {
  var score = toa.select('B2').multiply(toa.select('B9')).multiply(1e4);
  var cloudScoreThreshold = 200;
  var cloud = score.gt(cloudScoreThreshold);
  return cloud;
}
function shadowMask(toa,cloud){
  var azi = ee.Number(toa.get('solar_azimuth'));
  var zen = ee.Number(toa.get('solar_zenith')).multiply(1.6);
  var azimuth =azi.multiply(Math.PI).divide(180.0).add(ee.Number(0.5).multiply(Math.PI));
  var zenith  =ee.Number(0.5).multiply(Math.PI ).subtract(zen.multiply(Math.PI).divide(180.0));
  var nominalScale = cloud.projection().nominalScale();
  var cloudHeights = ee.List.sequence(200,5000,500);
  function cloudH (cloudHeight){
    cloudHeight = ee.Number(cloudHeight);
    var shadowVector = zenith.tan().multiply(cloudHeight);
    var x = azimuth.cos().multiply(shadowVector).divide(nominalScale).round();
    var y = azimuth.sin().multiply(shadowVector).divide(nominalScale).round();
    return cloud.changeProj(cloud.projection(), cloud.projection().translate(x, y));
  }
  var shadows = cloudHeights.map(cloudH);
  var potentialShadow = ee.ImageCollection.fromImages(shadows).max();
  var potentialShadow1 = potentialShadow.and(cloud.not());
  var darkPixels = toa.select(['B8','B11','B12']).reduce(ee.Reducer.sum()).multiply(1e3).lt(250).rename(['dark_pixels']);
  var shadow = potentialShadow1.and(darkPixels).rename('shadows');
  return shadow;
}
function sentinel2toa(img) {
  var toa = img//.select(['B2','B3','B4', 'B8', 'B9', 'B11','B12'])  
     .divide(10000)
     .set('solar_azimuth',img.get('MEAN_SOLAR_AZIMUTH_ANGLE'))
     .set('solar_zenith', img.get('MEAN_SOLAR_ZENITH_ANGLE'));
  return toa;
}
function cloud_and_shadow_mask(img) {
  var toa = sentinel2toa(img);
  var cloud = sentinelCloudScore(toa);
  var shadow = shadowMask(toa,cloud);
  var mask = cloud.or(shadow).fastDistanceTransform(75, 'pixels').gt(75);
  return toa.updateMask(mask);
}
// Image processing
var imagecloudFree = coleccion1.map(cloud_and_shadow_mask).mosaic().clip(area);
// 3. Convertir a Imagen. 
var stack1 = ee.Image(imagecloudFree);
var date = ee.Date((coleccion1.first()).get('system:time_start')).format('yyyy-MM-dd');
print (date);
// ver imagen en mapa:
Map.addLayer (stack1,imageVisParam, "Sentinel FCC" ,true);
// ver caracteristicas de FeatureCollection
//print ("muestras", table);
// Separacion de set de datos (polígonos) para entrenamiento y validación
// generación de atributo con números al azar (columna "random")
// para hacer muestreo
var seed = 100;
table = table.randomColumn('random', seed);
//print (table);
// extraccion de información incluyendo atributos clase y "random"
var set_datos = stack1.sampleRegions({
  collection: table,
  properties: ['codigo','random'],
  scale: 10,
  tileScale: 2,
});
//print (set_datos)
// Separación entre Entrenamiento y validación. Identificar umbral de separación
var training = set_datos.filterMetadata('random', 'not_less_than', 0.1);
var testing = set_datos.filterMetadata('random', 'less_than', 0.5);
print ("Set de datos entrenamiento", training);
print ("Set de datos validación", testing);
// Entrenamiento
var bandas_entr = ['B4','B8','B11'];
var trained = ee.Classifier.randomForest().train(training, 'codigo', bandas_entr);
// clasificación con el modelo entrenado
var classified = stack1.select(bandas).classify(trained);
//Map.addLayer(classified.randomVisualizer(), {}, 'Clasificacion',false);
//Map.centerObject(area,10);
// majority filter
var filtered = classified.focal_mode(20, 'square', 'meters', 2);
Map.addLayer(filtered,imageVisParam2, 'Resultado Clasificacion',true);
//Map.addLayer(lotes,{},'Lotes');
// print (classified);
// Generación de matriz de confusión y resultados
var validation = testing.classify(trained);
var errorMatrix = validation.errorMatrix('codigo', 'classification');
print('Matriz de Confusión:\n (actual/predict)', errorMatrix);
print('Exactitud General:', errorMatrix.accuracy());
print('Indice Kappa:', errorMatrix.kappa());
print('Exactitudes de Usuario(Fila):', errorMatrix.consumersAccuracy());
print('Exactitudes de Productor(Columna):', errorMatrix.producersAccuracy());
/* #################################################################################
Exactitud global (overall accuracy). 
Se calcula dividiendo el número total de pixeles correctamente clasificados por el número 
total de pixeles de referencia y expresándolo como porcentaje.
Exactitud del usuario (user’s accuracy). 
Se calcula dividiendo el número de pixeles correctamente clasificados en cada categoría por 
el número total de pixeles que fueron clasificados en dicha categoría (total de la fila)
Se justifica este índice en el sentido de que el usuario está especialmente interesado en el
porcentaje de cada clase que ha sido correctamente clasificado. 
Exactitud de productor (producer’s accuracy). 
Resulta de dividir el número de pixeles correctamente clasificados en cada categoría por el
número de pixeles de referencia utilizados para dicha categoría (total de la columna). 
El productor está más interesado en este índice pues le dice cuan bien los pixeles de 
referencia han sido clasificados.
Coeficiente de Kappa
Este estadístico es una medida de la diferencia entre la exactitud lograda en la clasificación
con un clasificador automático y la  chance de lograr una clasificación correcta con un 
clasificador aleatorio. 
####################################################################################*/
/*
// Publicacion
var image_info = stack1.visualize(imageVisParam).getMap();
var mapid = ee.Dictionary(image_info).get('mapid');
var token = ee.Dictionary(image_info).get('token');
var url = "https://earthengine.googleapis.com/map/"+mapid.getInfo()+"/{z}/{x}/{y}?token="+token.getInfo();
print (url);
// Exportar imagen a Drive
var clasif = ee.Image(filtered.randomVisualizer().select('viz-red','viz-green','viz-blue'));
Export.image.toCloudStorage({
    image:filtered,
    description  : "clasificacion_"+ date.getInfo(),
    bucket : 'clasificacion',
    scale : 10
});
Export.map.toCloudStorage({
  image : stack1.visualize(imageVisParam),
  description: "FCC_" + date.getInfo(),
  bucket:"clasificacion",
  scale : 10
});
*/
var filtered = filtered.set({'class_palette':["ff460f","ffec09","09ff11","0dffc7","0f22ff","ff0fe1","ff0000","ff0af0"]
,'class_names':['Soja','Cana','Milho','Pasto','Mata','Eucalipto','Cafe','Braquiria']});
//Exporta Mapa (XYZ Tiles) a Cloud Storage
// Export.map.toCloudStorage(clasif,"clasif","map_gee");
// https://storage.cloud.google.com/storage/browser/map_gee/clasif/index.html
//print('https://storage.googleapis.com/clasificacion/FCC_'+date.getInfo()+'/{z}/{x}/{y}')
//print('https://storage.googleapis.com/clasificacion/clasificacion_'+date.getInfo()+'/{z}/{x}/{y}')
// Create the panel for the legend items.
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '30px 35px'
  }
});
// Create and add the legend title.
var legendTitle = ui.Label({
  value: 'Clases',
  style: {
    fontWeight: 'bold',
    fontSize: '22px',
    margin: '0 0 4px 0',
    padding: '0'
  }
});
legend.add(legendTitle);
var loading = ui.Label('Cargando leyenda...', {margin: '2px 0 4px 0'});
legend.add(loading);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      // Use padding to give the box height and width.
      padding: '12px',
      margin: '0 0 4px 0'
    }
  });
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'}
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
// Get the list of palette colors and class names from the image.
filtered.toDictionary().evaluate(function(result) {
  var palette = result['class_palette'];
  var names = result['class_names'];
  loading.style().set('shown', false);
  for (var i = 0; i < names.length; i++) {
    legend.add(makeRow(palette[i], names[i]));
  }
});
// Add the legend to the map.
Map.add(legend);