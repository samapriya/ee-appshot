var left = ui.Map();
var right = ui.Map();
var right2 = ui.Map();
var right3 = ui.Map();
ui.root.clear();
ui.root.add(left);
ui.root.add(right);
ui.root.add(right2);
ui.root.add(right3);
ui.Map.Linker([left, right,right2,right3], 'change-bounds');
var month = ee.Date(Date.now()).format('MMM')
print (month)
var fires = ee.ImageCollection('FIRMS')
  .filterDate('2020-03-01','2020-07-28')
  .select(['confidence']);
right2.addLayer(ee.Image(0).visualize({palette:['ff0000']}).mask(fires.mosaic().gt(20)),{min:50,max:100});
right2.add(ui.Label('Marzo - Julio /2020',{position: 'bottom-center',fontSize:'24px',backgroundColor:'blue'}))
var fires2 = ee.ImageCollection('FIRMS')
  .filterDate('2019-03-01','2019-07-28')
  .select(['confidence']);
right.addLayer(ee.Image(0).visualize({palette:['ff0000']}).mask(fires2.mosaic().gt(20)),{min:50,max:100});
right.add(ui.Label('Marzo - Julio /2019',{position: 'bottom-center',fontSize:'24px',backgroundColor:'blue'}))
var fires3 = ee.ImageCollection('FIRMS')
  .filterDate('2018-03-01','2018-07-28')
  .select(['confidence']);
left.addLayer(ee.Image(0).visualize({palette:['ff0000']}).mask(fires3.mosaic().gt(20)),{min:50,max:100});
left.add(ui.Label('Marzo - Julio /2018',{position: 'bottom-center',fontSize:'24px',backgroundColor:'blue'}))
var fires4 = ee.ImageCollection('FIRMS')
  .filterDate('2008-03-01','2008-07-28')
  .select(['confidence']);
right3.addLayer(ee.Image(0).visualize({palette:['ff0000']}).mask(fires4.mosaic().gt(20)),{min:50,max:100});
right3.add(ui.Label('Marzo - Julio /2008',{position: 'bottom-center',fontSize:'24px',backgroundColor:'red'}))
left.setCenter(-60.4685, -32.9087,9)