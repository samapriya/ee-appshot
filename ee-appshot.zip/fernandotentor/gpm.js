var table = ee.FeatureCollection("users/ftentor/unigro/new_area"),
    table2 = ee.FeatureCollection("users/ftentor/unigro/afgri_aoi");
var imageVisParam = {"opacity":1,"bands":["Precipitation"],'min':90,'max':150,"palette":["ff0000","00ff00","0000ff"]};
var table2 = ee.Feature(table2.first());
var union = ee.Feature(table.first()).union(table2,1000)
var hoy = new Date();
var GPM = ee.ImageCollection('NASA/GPM_L3/IMERG_V05')
    .filterDate('2018-10-01', hoy)
var PREC = GPM.select(['precipitationCal',]);
function imgcol_last(imgcol){
    // ee.Image(imgcol_grace.reduce(ee.Reducer.last())); properties are missing
    return ee.Image(imgcol.toList(1, imgcol.size().subtract(1)).get(0));
}
function aggregate_prop(ImgCol, prop, reducer, delta){
    if (typeof reducer === 'undefined') {reducer = 'mean'}
    if (typeof delta   === 'undefined') {delta   = false}
    var dates = ee.Dictionary(ImgCol.aggregate_histogram(prop)).keys().aside(print)
    .map(function(p){
        return ee.Image(0).set(prop, p).set('system:id', p);
    });
    // print(dates);
    var filterDateEq = ee.Filter.equals({ leftField : prop, rightField: prop});
    var saveAllJoin = ee.Join.saveAll({
        matchesKey: 'matches',
        ordering  : 'system:time_start',
        ascending : true
    });
    var ImgCol_new = saveAllJoin.apply(dates, ImgCol, filterDateEq)
    // .aside(print)
    .map(function(img){
        img = ee.Image(img);
        var imgcol = ee.ImageCollection.fromImages(img.get('matches')).sort('system:time_start'); //.fromImages
        var first = ee.Image(imgcol.first());
        var last  = imgcol_last(imgcol);
        var res = ee.Algorithms.If(delta, last.subtract(first), imgcol.reduce(reducer))
        return ee.Image(res)
            .copyProperties(ee.Image(imgcol.first()), 
                ['Year', 'YearStr', 'YearMonth', 'Month', 'Season', 'dn', 'system:time_start'])
            .copyProperties(img, ['system:id', prop]);
    });
    return ee.ImageCollection(ImgCol_new);
}
var PREC = GPM.map(function(image) {
  var prec = image.divide(2).copyProperties(image,['system:time_start'])
  var date  = ee.Date(image.get('system:time_start'));
  var day = date.get('day');
  var month = date.get('month');
  var year  = date.get("year").format("%d");
  var month2_flag = month//.subtract(1).divide(2).floor().add(1);
  var day_flag = day.format('-%02d')
  month2_flag = month2_flag.format('-%02d');
  return prec
      .set('day', day)
      .set('month', month)
      .set('month2_flag', year.cat(month2_flag).cat(day_flag));
});
print (PREC)
var gpm2 = PREC.select(['precipitationCal'],['Precipitation'])
var prop = 'month2_flag', 
    reducer = ee.Reducer.sum(); 
//var pkg_trend = require('users/kongdd/public:Math/pkg_trend.js');
var prec_mth =aggregate_prop(gpm2, prop, reducer).select(['Precipitation_sum'],['Precipitation']);
print (prec_mth)
//////////////////////////
var vis = {min: 0, max: 200, palette: [
  'FFFFFF', 'CE7E45', 'FCD163', '66A000', '207401',
  '056201', '004C00', '023B01', '012E01', '011301'
]};
//Map.addLayer(PREC,vis);
Map.setCenter(-60.4893, -31.7667, 10);
// Create a panel to hold our widgets.
var panel = ui.Panel();
panel.style().set('width', '300px');
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: 'GPM Preciptaciones ',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
  ui.Label('Click en el mapa.')
]);
panel.add(intro);
// Create an NDVI chart.
  var GPMChart = ui.Chart.image.series(prec_mth, table, ee.Reducer.mean(), 500);
  GPMChart.setOptions({
    title: 'GPM Precipitation Delmas, 2018-10-01 - Today',
    vAxis: {title: 'Precipitation'},
    hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
  });
  panel.widgets().set(0, GPMChart.setChartType('ColumnChart'));
  var GPMChart2 = ui.Chart.image.series(prec_mth, table2, ee.Reducer.mean(), 500);
  GPMChart2.setOptions({
    title: 'GPM Precipitation Dipaleseng, 2018-10-01 - Today',
    vAxis: {title: 'Precipitation'},
    hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
  });
  panel.widgets().set(1, GPMChart2.setChartType('ColumnChart'));
// Add the panel to the ui.root.
ui.root.insert(0, panel);
Map.addLayer(prec_mth.sum().resample('bicubic').clip(union).visualize(imageVisParam).paint(table,'black',2).paint(table2,'black',2),{},'Sum period');
Map.centerObject(union,10)
//Map.addLayer(prec_mth.sum())
//var pkg_vis  = require('users/ftentor/Fernando:legend');
//var lg_vi    = pkg_vis.grad_legend(imageVisParam, 'Sum period ', false)
 //pkg_vis.add_lgds([lg_vi]);
var pkg_vis  = require('users/kongdd/public:pkg_vis.js');
var lg_vi    = pkg_vis.grad_legend(imageVisParam  , 'VI', false)
pkg_vis.add_lgds([lg_vi, lg_diff]);