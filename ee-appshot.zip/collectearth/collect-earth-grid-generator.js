var tool = require("users/sanchezpauspro/Apps:grid/toolGrid");
tool.initialize();