var table3 = ui.import && ui.import("table3", "table", {
      "id": "users/estimacionesmagyp/CITIRICOSCOMPLETO"
    }) || ee.FeatureCollection("users/estimacionesmagyp/CITIRICOSCOMPLETO"),
    provincias = ui.import && ui.import("provincias", "table", {
      "id": "users/estimacionesmagyp/PROVINCIAS"
    }) || ee.FeatureCollection("users/estimacionesmagyp/PROVINCIAS"),
    table = ui.import && ui.import("table", "table", {
      "id": "users/estimacionesmagyp/DepartamentosIGN2023"
    }) || ee.FeatureCollection("users/estimacionesmagyp/DepartamentosIGN2023"),
    image5 = ui.import && ui.import("image5", "image", {
      "id": "users/estimacionesmagyp/recDel3ARROYOS9x8g23"
    }) || ee.Image("users/estimacionesmagyp/recDel3ARROYOS9x8g23"),
    image3 = ui.import && ui.import("image3", "image", {
      "id": "users/estimacionesmagyp/recDelTANDIL9x8g2223"
    }) || ee.Image("users/estimacionesmagyp/recDelTANDIL9x8g2223"),
    image6 = ui.import && ui.import("image6", "image", {
      "id": "users/estimacionesmagyp/recDelPIGUEg23_9x8"
    }) || ee.Image("users/estimacionesmagyp/recDelPIGUEg23_9x8"),
    image7 = ui.import && ui.import("image7", "image", {
      "id": "users/estimacionesmagyp/madariagag2223"
    }) || ee.Image("users/estimacionesmagyp/madariagag2223"),
    image8 = ui.import && ui.import("image8", "image", {
      "id": "users/estimacionesmagyp/GRUESA-22-23/LAPLATAg2223"
    }) || ee.Image("users/estimacionesmagyp/GRUESA-22-23/LAPLATAg2223"),
    image4 = ui.import && ui.import("image4", "image", {
      "id": "users/estimacionesmagyp/recVillegasg2223"
    }) || ee.Image("users/estimacionesmagyp/recVillegasg2223"),
    image10 = ui.import && ui.import("image10", "image", {
      "id": "users/estimacionesmagyp/recPehuajog2223"
    }) || ee.Image("users/estimacionesmagyp/recPehuajog2223"),
    image11 = ui.import && ui.import("image11", "image", {
      "id": "users/estimacionesmagyp/recPICOg23"
    }) || ee.Image("users/estimacionesmagyp/recPICOg23"),
    image12 = ui.import && ui.import("image12", "image", {
      "id": "users/estimacionesmagyp/recVenadog2223"
    }) || ee.Image("users/estimacionesmagyp/recVenadog2223"),
    image9 = ui.import && ui.import("image9", "image", {
      "id": "users/estimacionesmagyp/recGomezg2223"
    }) || ee.Image("users/estimacionesmagyp/recGomezg2223"),
    image13 = ui.import && ui.import("image13", "image", {
      "id": "users/estimacionesmagyp/recBBlancag23"
    }) || ee.Image("users/estimacionesmagyp/recBBlancag23"),
    image15 = ui.import && ui.import("image15", "image", {
      "id": "projects/ee-estimacionesmagyp/assets/Rclas_AvellanedaG22-23"
    }) || ee.Image("projects/ee-estimacionesmagyp/assets/Rclas_AvellanedaG22-23"),
    image16 = ui.import && ui.import("image16", "image", {
      "id": "projects/ee-estimacionesmagyp/assets/Reclas_MJG22-23"
    }) || ee.Image("projects/ee-estimacionesmagyp/assets/Reclas_MJG22-23"),
    image14 = ui.import && ui.import("image14", "image", {
      "id": "users/estimacionesmagyp/reclasSROSAg2223"
    }) || ee.Image("users/estimacionesmagyp/reclasSROSAg2223"),
    table2 = ui.import && ui.import("table2", "table", {
      "id": "users/estimacionesmagyp/DelegacionesIGN23geo"
    }) || ee.FeatureCollection("users/estimacionesmagyp/DelegacionesIGN23geo"),
    image19 = ui.import && ui.import("image19", "image", {
      "id": "projects/ee-estimacionesmagyp/assets/Rc_Salta_G2223"
    }) || ee.Image("projects/ee-estimacionesmagyp/assets/Rc_Salta_G2223"),
    image20 = ui.import && ui.import("image20", "image", {
      "id": "projects/ee-estimacionesmagyp/assets/REClasCG2223_RIOCUARTOdeleg"
    }) || ee.Image("projects/ee-estimacionesmagyp/assets/REClasCG2223_RIOCUARTOdeleg"),
    image25 = ui.import && ui.import("image25", "image", {
      "id": "users/estimacionesmagyp/recdelBolivarg2223"
    }) || ee.Image("users/estimacionesmagyp/recdelBolivarg2223"),
    image = ui.import && ui.import("image", "image", {
      "id": "users/estimacionesmagyp/GRUESA-22-23/SALIQUELOGRUESA2223"
    }) || ee.Image("users/estimacionesmagyp/GRUESA-22-23/SALIQUELOGRUESA2223"),
    image2 = ui.import && ui.import("image2", "image", {
      "id": "users/estimacionesmagyp/GRUESA-22-23/Roca2223"
    }) || ee.Image("users/estimacionesmagyp/GRUESA-22-23/Roca2223"),
    image18 = ui.import && ui.import("image18", "image", {
      "id": "users/estimacionesmagyp/GRUESA-22-23/SaenzPena2223"
    }) || ee.Image("users/estimacionesmagyp/GRUESA-22-23/SaenzPena2223"),
    image21 = ui.import && ui.import("image21", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_SanFra_G22-23"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_SanFra_G22-23"),
    image22 = ui.import && ui.import("image22", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Clasif_SFE_Gr2223_DelegRafaela"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Clasif_SFE_Gr2223_DelegRafaela"),
    image23 = ui.import && ui.import("image23", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_VillaMaria_final_G22_23"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_VillaMaria_final_G22_23"),
    image24 = ui.import && ui.import("image24", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_Saez_G22_23_VF"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_Saez_G22_23_VF"),
    image26 = ui.import && ui.import("image26", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/recJUNINg2223"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/recJUNINg2223"),
    image28 = ui.import && ui.import("image28", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/rec25MAYOg2223"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/rec25MAYOg2223"),
    image29 = ui.import && ui.import("image29", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/reclasificacion_pergamino_G_22-23"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/reclasificacion_pergamino_G_22-23"),
    image30 = ui.import && ui.import("image30", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/ReClasif_G2223_Parana"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/ReClasif_G2223_Parana"),
    image31 = ui.import && ui.import("image31", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/REClassifiedFILTRADA_bragado_G_22-23-final-UTMS20"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/REClassifiedFILTRADA_bragado_G_22-23-final-UTMS20"),
    image32 = ui.import && ui.import("image32", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_CASILDA_G22_23_final"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_CASILDA_G22_23_final"),
    image33 = ui.import && ui.import("image33", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_G2223_Avellaneda_reproyect"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_G2223_Avellaneda_reproyect"),
    image34 = ui.import && ui.import("image34", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Clasif_Gr2223_CHA_DelegCharata"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Clasif_Gr2223_CHA_DelegCharata"),
    image35 = ui.import && ui.import("image35", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Clasif_Gr2223_CHA_DelegRSaenzPenia"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Clasif_Gr2223_CHA_DelegRSaenzPenia"),
    image36 = ui.import && ui.import("image36", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/ReClasif_Gr22-23_SanLuis"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/ReClasif_Gr22-23_SanLuis"),
    image37 = ui.import && ui.import("image37", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/ReClasif_Gr22-23_EntreRios"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/ReClasif_Gr22-23_EntreRios"),
    image38 = ui.import && ui.import("image38", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_Tucuman_gr2223"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_Tucuman_gr2223"),
    image39 = ui.import && ui.import("image39", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_G22_23_Madariaga"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_G22_23_Madariaga"),
    image41 = ui.import && ui.import("image41", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_G22_23_Quimili"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_G22_23_Quimili"),
    image42 = ui.import && ui.import("image42", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_G22_23_Madariaga"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_G22_23_Madariaga"),
    image17 = ui.import && ui.import("image17", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Clasif_Gr2223_SDE_Rivadavia"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Clasif_Gr2223_SDE_Rivadavia"),
    image27 = ui.import && ui.import("image27", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Clasif_Gr2223_SDE_DelegSantiago"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Clasif_Gr2223_SDE_DelegSantiago"),
    image40 = ui.import && ui.import("image40", "image", {
      "id": "projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_G22_23_EntreRios_RdelTala"
    }) || ee.Image("projects/ee-estimaciones/assets/GRUESA-22-23/Reclass_G22_23_EntreRios_RdelTala");
//Función para enmascarar valores que no entran la visualización del mapa
function noDataMask(image){
    var mask = image.lt(1).or(image.gte(21).or(image.eq(18)));
   // var mask1 = image.eq(18);
  return image.updateMask(mask.eq(0));
}
/*//Función para enmascarar forraje
function forraje(image){
    var mask1 = image.eq(18);
  return image.updateMask(mask1.eq(0));
}
*/
var roi1 = provincias.filterMetadata("NAM","equals","BUENOS AIRES");
var deptos = ee.FeatureCollection(table);
//var departamentos = deptos.filter('nam');
//////////////////////////////////////////////////////////////////////////////////////////////
Map.setCenter(-61.132, -33.133, 6);
//***************************************************************************************************************
//VISUALIZACION EN UNA SOLA CAPA  IMAGECOLLECTION
// Crea una lista de imágenes
var listaImagenes = [image5, image3, image6, image7, image8, 
                     image4, image10, image11, image12, image9, 
                     image13, image33, image16, image14,image,
                     image2, image18, image17, image19, image20, image21, image22, 
                     image23, image35, image25, image26, image28,
                     image29, image30, image31, image32, image34, image36,
                      image38, image27, image40, image41];
// Convierte la lista en una ImageCollection
var lista = ee.ImageCollection(listaImagenes).map(noDataMask);
// Puedes imprimir la colección para verificarla
print("Image Collection:", lista);
// Create and define visualization parameters and display ImageCollection
var paleta =['#499445','#eaea59','#fea458','#b33771','#55e6c1','#3b3b98','#fd7272','#82589f','#d6a2e8','#f97f51','#eab543','#1b9cfc','#58b19f','#6d214f','#182c61','#FF3333','#9aecdb','#bdc581','#f8efba','#fc427b','#cad3c8'];   
Map.addLayer(lista, {min:1, max:21, palette: paleta}, 'Mapa Cult. 22/23',1);
// Crear una máscara con una cobertura: soja.
function masksoja(lista) {
var sojaMask = lista.eq(1);
  // Aplicar la máscara a la imagen original.
  return lista.updateMask(sojaMask);
}
// Aplicar la función de máscara a cada imagen en la colección.
var maskedCollection = lista.map(masksoja);
Map.addLayer(maskedCollection, { palette: ['#499445']}, 'Soja 22/23',1)
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var l8 = ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
        .filterDate('2022-08-30', '2023-06-30')
        .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5));
    var ndvi = l8.map(function(image) {
      return image.select().addBands(image.normalizedDifference(['B8','B4'])).rename("NDVI");});
    var panel = ui.Panel();
    panel.style().set('width', '300px');
//    var branding = ui.Thumbnail({image:logo,params:{bands:['b1','b2','b3'],min:0,max:255},style:{width:'200px',height:'60px'}});
//        panel.add(branding);
    var intro = ui.Panel([
      ui.Label({value: 'NDVI Campaña 22/23',
        style: {fontSize: '20px', fontWeight: 'bold'}  }),
      ui.Label('Realice click sobre un lote.')]);
    panel.add(intro);
    var lat = ui.Label();
    var lon = ui.Label();
    panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
    Map.onClick(function(coords) {
      lat.setValue('lat: ' + coords.lat.toFixed(5)),
      lon.setValue('lon: ' + coords.lon.toFixed(5));
      var point = ee.Geometry.Point(coords.lon, coords.lat);
      var dot = ui.Map.Layer(point, {color: 'FF0000'});
      Map.layers().set(1, dot);
      var ndviChart = ui.Chart.image.series(ndvi, point, ee.Reducer.mean(), 500);
      ndviChart.setOptions({
        title: 'NDVI Serie de Tiempo',vAxis: {title: 'NDVI', gridlines: {count: 6}},
        hAxis: {title: 'Fecha', format: 'MM-yy', gridlines: {count: 7}},
        lineWidth: 2,
        pointSize: 3,
        colors:["green"],
      });  panel.widgets().set(2, ndviChart);});
    Map.style().set('cursor', 'crosshair')
    ui.root.insert(0, panel);
//EXPORTAR A DRIVE 
/*Export.image.toDrive({
  image:image7,
  description: 'Reclass_Madariaga_G22_23',
  scale: 30,
  crs:  'EPSG:4326',
  maxPixels: 1.0E13,
  fileFormat: 'GeoTIFF'
});*/
//*******************************************************************************************************************
// Define an SLD style of discrete intervals to apply to the image.
/*
var paleta =
'<RasterSymbolizer>' +
  '<ColorMap type="values" extended="false">' +
    '<ColorMapEntry color="#499445" quantity="0" label="no data" opacity="0"/>' +
    '<ColorMapEntry color="#499445" quantity="1" label="Soja"/>' +
    '<ColorMapEntry color="#eaea59" quantity="2" label="Maiz"/>' +
    '<ColorMapEntry color="#fea458" quantity="3" label="Girasol"/>' +
    '<ColorMapEntry color="#b33771" quantity="4" label="Sorgo"/>' +
    '<ColorMapEntry color="#55e6c1" quantity="5" label="Mani"/>' +
    '<ColorMapEntry color="#3b3b98" quantity="6" label="Algodon"/>' +
    '<ColorMapEntry color="#fd7272" quantity="7" label="Arroz"/>' +
    '<ColorMapEntry color="#82589f" quantity="8" label="Poroto"/>' +
    '<ColorMapEntry color="#d6a2e8" quantity="9" label="Caña de azucar"/>' +
    '<ColorMapEntry color="#f97f51" quantity="10" label="Cereales de invierno"/>' +
    '<ColorMapEntry color="#eab543" quantity="11" label="Legumbres de invierno"/>' +
    '<ColorMapEntry color="#1b9cfc" quantity="12" label="Colza"/>' +
    '<ColorMapEntry color="#58b19f" quantity="13" label="Lino"/>' +
    '<ColorMapEntry color="#6d214f" quantity="14" label="Tabaco"/>' +
    '<ColorMapEntry color="#182c61" quantity="15" label="Cultivos de cobertura"/>' +
    '<ColorMapEntry color="#9aecdb" quantity="17" label="Otros cultivos"/>' +
    '<ColorMapEntry color="#bdc581" quantity="18" label="Recursos forrajeros"/>' +
    '<ColorMapEntry color="#f8efba" quantity="19" label="Barbecho y forraje"/>' +
    '<ColorMapEntry color="#fc427b" quantity="20" label="Frutales"/>' +
    '<ColorMapEntry color="#cad3c8" quantity="21" label="No agricola" opacity="0"/>' +
      '</ColorMap>' +
'</RasterSymbolizer>';
Map.addLayer(listaImagenes.sldStyle(paleta), {}, 'Mosaico 2023',1);*/
//////////////////////////////////////////////  IMAGENES GRUESA 2023 //////////////////////////////////////////////////////////////////////////////////
var empty1 = ee.Image().byte();
// Paint all the polygon edges with the same number and width, display.
var outline = empty1.paint({
  featureCollection: table,
  color: 0.5,
  width: 0.3
});
Map.addLayer(outline, {palette: 'black'}, 'Deptos',1);
//////////////////////////////////////////////////////////////////////////////////////////////
// Create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
// Paint all the polygon edges with the same number and width, display.
var outline = empty.paint({
  featureCollection: table2,
  color: 1,
  width: 2
});
Map.addLayer(outline, {palette: 'black'}, 'Delegaciones SAGyP',1);
///////////////////////////////// Cartografía forestal 
var cartografia_plantaciones = ee.FeatureCollection( 'users/mgaute/macizos_mapa_fina')
/// Estilos borde cartografía 
//Map.addLayer(cartografia_plantaciones.draw({color: '330033', strokeWidth: 1}), {}, 'macizos');
var palette2 = ['FED90D'];
// Paint the interior of the polygons with different colors.
var fills = empty.paint({
  featureCollection: cartografia_plantaciones,
  color: 'FED90D',
});
//Map.addLayer(fills, {palette: palette2, max: 14}, 'Macizos');
//////////////////////////////////////////////////////////////////////////////////////////////
// Create an empty image into which to paint the features, cast to byte.
var Frutales= ee.FeatureCollection('users/estimacionesmagyp/CITIRICOSCOMPLETO');
var palette = ['fc427b'];
// Paint the interior of the polygons with different colors.
var fills = empty.paint({
  featureCollection: Frutales,
  color: 'fc427b',
});
Map.addLayer(fills, {palette: palette, max: 20}, 'Frutales');
// Cartografía forestal Cortinas
/// Estilos borde cartografía 
var cartografia_plantaciones_cortinas = ee.FeatureCollection( 'users/mgaute/cortinas_mapa_fina')
//Map.addLayer(cartografia_plantaciones_cortinas.draw({color: '330066', strokeWidth: 1}), {}, 'cortinas');
var palette1 = ['#f5cf00'];
// Paint the interior of the polygons with different colors.
var fills = empty.paint({
  featureCollection: cartografia_plantaciones_cortinas,
  color: '#f5cf00',
});
//Map.addLayer(fills, {palette: palette1, max: 14}, 'Cortinas');
// Add the maps and title to the ui.root.
//ui.root.widgets().reset([title, mapGrid]);
//ui.root.setLayout(ui.Panel.Layout.Flow('vertical'));
Map.add(ui.Label(
    'Mapa de Cultivos, Cosecha Gruesa 2022-2023   v01' 
    , {fontWeight: 'bold', fontSize: '18px'}));
// Leyenda
var legend = ui.Panel({style: {position: 'bottom-right', padding: '8px 15px'}});
var loading = ui.Label('', {margin: '2px 0 4px 0'});
legend.add(loading);
//var title = ui.Label('Referencias', {fontWeight: 'bold', fontSize: '20px', color: 'green'});
var descr = ui.Label("Color - Clase ",{fontWeight: 'bold', fontSize: '18px', color: 'black'});
//legend.add(title);
legend.add(descr);
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0 0 4px 0'
    }
  });
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'}
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
legend.add(makeRow('499445', 'Soja'));
legend.add(makeRow('eaea59', 'Maíz'));
legend.add(makeRow('fea458', 'Girasol'));
legend.add(makeRow('b33771', 'Sorgo granífero'));
legend.add(makeRow('55e6c1', 'Maní'));
legend.add(makeRow('3b3b98', 'Algodón'));
legend.add(makeRow('fd7272', 'Arroz'));
legend.add(makeRow('82589f', 'Poroto')); 
legend.add(makeRow('b17eff', 'Caña de Azucar'));
legend.add(makeRow('00ae4c', 'Tabaco'));
legend.add(makeRow('9aecdb', 'Papa'));
legend.add(makeRow('f8efba', 'Rastrojos y Barbechos'));
legend.add(makeRow('fc427b', 'Frutales')); 
//legend.add(makeRow('cad3c8', 'Bajos'));
Map.add(legend);
// Add a title and some explanatory text to a side panel.
var header = ui.Label('Estimaciones Agrícolas SAGyP', {fontSize: '10px', color: 'red'});
var text = ui.Label(
    'Clasificación de uso y coberturas en base a la verdad de terreno obtenida por las delegaciones SAGyP',
    {fontSize: '11px'});
var toolPanel = ui.Panel([header, text], 'flow', {width: '100px'});
ui.root.widgets().add(toolPanel);
// Create a hyperlink to an external reference.
var link2 = ui.Label(
    'DESCARGAS', {},
    'https://docs.google.com/document/d/1NYbMC13R2spZJzjBus_rOPwIgYxNbBOoycjisjzlOrQ/edit');
var link1 = ui.Label(
    'Informe Técnico', {},
    'https://www.magyp.gob.ar/sitio/areas/estimaciones/acerca_de/mapa_cultivo_fina/index.php');
var link = ui.Label(
    'Metodo de Segmentos Aleatorios', {},
    'https://www.magyp.gob.ar/sitio/areas/estimaciones/')
var linkPanel = ui.Panel(
    [ui.Label('Para mayor información', {fontWeight: 'bold'}), link, link1, link2]);
toolPanel.add(linkPanel);
//var branding = ui.Thumbnail({image:logo,params:{bands:['b1','b2','b3'],min:0,max:255},style:{width:'150px',height:'50px'}});
//        legend.add(branding);
var dires = ui.Label("Dir. de Estimaciones Agrícolas",{fontWeight: 'bold', fontSize: '15px', color: 'black'});
legend.add(dires);
var diresi = ui.Label("SAGYP",{fontWeight: 'bold', fontSize: '16px', color: 'black'});
legend.add(diresi);
/*
//Dirección Nacional de Desarrollo Foresto Industrial
var dires2 = ui.Label("Dirección Nacional de Desarrollo Foresto Industrial",{fontWeight: 'bold', fontSize: '15px', color: 'black'});
legend.add(dires2);
*/
/*
var image21 = image2.clip(roi1);
var image51 = image56.clip(roi1);
// Exportar imagen de clasificación
Export.image.toDrive({
  image:image21,
  description: 'bsassur',
  folder: 'my_folder',
  scale: 30,
  maxPixels: 1.0E13,
  region: roi1
});
*/
///////////////////////////ÁREA/////////////////////////////////////////////////////////
/*var imageMosaic = lista.mosaic();
var calculateClassArea = function(feature) {
    var areas = ee.Image.pixelArea().addBands(imageMosaic).reduceRegion({
      reducer: ee.Reducer.sum().group({
      groupField: 1,
      groupName: 'class',
    }),
    geometry: table.geometry(),
    scale: 500,
    maxPixels: 1e10
    })
    var classAreas = ee.List(areas.get('groups'))
    var classAreaLists = classAreas.map(function(item) {
      var areaDict = ee.Dictionary(item)
      var classNumber = ee.Number(areaDict.get('class')).format()
      var area = ee.Number(areaDict.get('sum')).divide(1e6)//.round()
      return ee.List([classNumber, area])
    })
    var result = ee.Dictionary(classAreaLists.flatten())
    // The result dictionary has area for all the classes
    // We add the district name to the dictionary and create a feature
    var district = provincias.get('NAM')
    return ee.Feature(provincias.geometry(), result.set('Provincia', provincias))
}
var districtAreas = deptos.map(calculateClassArea);
// One thing to note is that each district may or may not have all 
// of the 17 classes present. So each feature will have different 
// number of attributes depending on which classes are present.
// We can explicitly set the expected fields in the output 
// so we get a homogeneous table with all classes
var classes = ee.List.sequence(1, 21)
// As we need to use the list of output fields in the Export function
// we have to call .getInfo() to get the list values on the client-side
var outputFields = ee.List(['departamentos']).cat(classes).getInfo()
// Export the results as a CSV file
Export.table.toDrive({
    collection: districtAreas,
    description: 'class_area_by_district',
    folder: 'earthengine',
    fileNamePrefix: 'class_area_by_district',
    fileFormat: 'CSV',
    selectors: outputFields
    })
*/
var SubtleGrayscale
 = 
[
  {
    "featureType": "administrative",
    "elementType": "all",
    "stylers": [
      {
        "saturation": "-100"
      }
    ]
  },
  {
    "featureType": "administrative.province",
    "elementType": "all",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "landscape",
    "elementType": "all",
    "stylers": [
      {
        "saturation": -100
      },
      {
        "lightness": 65
      },
      {
        "visibility": "on"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "all",
    "stylers": [
      {
        "saturation": -100
      },
      {
        "lightness": "50"
      },
      {
        "visibility": "simplified"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "all",
    "stylers": [
      {
        "saturation": "-100"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "all",
    "stylers": [
      {
        "visibility": "simplified"
      }
    ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "all",
    "stylers": [
      {
        "lightness": "30"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "all",
    "stylers": [
      {
        "lightness": "40"
      }
    ]
  },
  {
    "featureType": "transit",
    "elementType": "all",
    "stylers": [
      {
        "saturation": -100
      },
      {
        "visibility": "simplified"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      {
        "hue": "#ffff00"
      },
      {
        "lightness": -25
      },
      {
        "saturation": -97
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels",
    "stylers": [
      {
        "lightness": -25
      },
      {
        "saturation": -100
      }
    ]
  }
]
Map.setOptions('SubtleGrayscale', {SubtleGrayscale
: SubtleGrayscale
})