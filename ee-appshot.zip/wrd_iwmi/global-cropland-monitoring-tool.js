var met_Locations = ui.import && ui.import("met_Locations", "table", {
      "id": "users/wrd_iwmi/afghanistan/met_Locations"
    }) || ee.FeatureCollection("users/wrd_iwmi/afghanistan/met_Locations");
//Map.setOptions("HYBRID"); 
var label = ui.Label('Global Cropland Monitoring Tool (v1)',   
{fontWeight: 'bold', fontSize: '22px', margin: '0 0 0 0',padding: '0', position:'top-center'});
//var inspector = ui.Panel([label]);
var inspector = ui.Panel([label], ui.Panel.Layout.Flow('vertical'),{position:'top-center'});
Map.add(inspector); 
// var label = ui.Label('Disclaimer: The product prepared by the International Water Management Institute (IWMI) has not been validated in the field and limited evaluation carried out with few country crop sown datasets. The views expressed may not be regarded as an official position of the IWMI, CGIAR WLE and ICAR (India) in any circumstances. National borders are purely a graphical representation, only intended to be indicative, and do not reflect the official position of the IWMI, CGIAR WLE and ICAR (India). Neither the IWMI nor any person acting on behalf of the program are responsible for the use that might be made of this application', 
// {fontWeight: 'Italic', fontSize: '11px', margin: '0 0 0 0',padding: '0', position:'bottom-right', width: '700px', height: '40px'});
// //var inspector = ui.Panel([label]);
// var inspector = ui.Panel([label], ui.Panel.Layout.Flow('vertical'),{position:'bottom-center'});
// Map.add(inspector);
//var aoi = ee.FeatureCollection('users/wrd_iwmi/afghanistan/AFG_adm0')
var aoi=ee.FeatureCollection('users/wrd_iwmi/World_boundary')
//var Rivers = ee.FeatureCollection('users/wrd_iwmi/afghanistan/Rivers')
var Rivers = ee.FeatureCollection('users/wrd_iwmi/India_States_New') 
//var Basins = ee.FeatureCollection('users/wrd_iwmi/afghanistan/Basins')
var Basins = ee.FeatureCollection("WWF/HydroSHEDS/v1/Basins/hybas_3")
var Subbasins = ee.FeatureCollection('WWF/HydroSHEDS/v1/Basins/hybas_4')
var gsw = ee.Image('JRC/GSW1_0/GlobalSurfaceWater');
var occurrence = gsw.select('occurrence').clip(aoi);
var VIS_OCCURRENCE = {
  min:0,
  max:100,
  palette: ['red', 'blue']
};
Map.addLayer(occurrence.updateMask(occurrence.divide(100)).clip(aoi), VIS_OCCURRENCE, 'Water occurrence (1984-2015) [JRC]',0);
var start="2020-03-18"
var end="2020-03-21"
var start1="2020-04-11"
var end1="2020-04-14"
var dataset = ee.ImageCollection('COPERNICUS/Landcover/100m/Proba-V/Global');
var landcover = dataset.select('discrete_classification').mean();
landcover=landcover.updateMask(landcover.eq(40))
//Map.setCenter(-88.6, 26.4, 3);
var cropMaskVis12 = {
  min: 0.0,
  max: 40.0,
  palette: ['orange', 'orange', 'orange', 'orange', 'orange', 'yellow'],
};
Map.addLayer(landcover, cropMaskVis12, 'Global Agricultural Area (COPERNICUS Proba-V)',0);
var dataset1 = ee.Image('USGS/GFSAD1000_V1');
var cropMask = dataset1.select('landcover');
var cropMaskVis = {
  min: 0.0,
  max: 5.0,
  palette: ['black', 'orange', 'brown', '02a50f', 'green', 'yellow'],
};
var cropMaskVis1 = {
  min: 0.0,
  max: 5.0,
  palette: ['yellow', 'yellow', 'yellow', 'yellow', 'yellow', 'yellow'],
};
var cropMaskVis2 = {
  min: 0.0,
  max: 5.0,
  palette: ['orange', 'orange', 'orange', 'orange', 'orange', 'orange'],
};
//Map.setCenter(-17.22, 13.72, 2);
//1+2;3+4+5
// 0	black	Non-croplands
// 1	orange	Croplands: irrigation major
// 2	brown	Croplands: irrigation minor
// 3	02a50f	Croplands: rainfed
// 4	green	Croplands: rainfed, minor fragments
// 5	yellow	Croplands: rainfed, very minor fragments
var mask =cropMask.updateMask(cropMask.lt(3))
mask =mask.updateMask(mask.gt(0))
var mask1 =cropMask.updateMask(cropMask.gt(2))
mask1 =mask1.updateMask(mask1.gt(0))
// mask =mask.updateMask(mask.gt(0))
//Map.addLayer(mask, cropMaskVis1, 'Irrigated area');//orange
//Map.addLayer(mask1, cropMaskVis2, 'Rainfed area');//yellow
var mask =mask.updateMask(landcover.eq(40))
mask =mask.updateMask(mask.gt(0))
var mask1 =mask1.updateMask(landcover.eq(40))
mask1 =mask1.updateMask(mask1.gt(0))
Map.addLayer(mask, cropMaskVis1, 'Global Irrigated area (GFSAD)',0);//orange
Map.addLayer(mask1, cropMaskVis2, 'Global Rainfed area (GFSAD)',0);//yellow
var dataset1 = ee.Image('users/wrd_iwmi/NRSC_LULC');
var cropMaskVis12 = {
  min: 0, 
  max: 1,
  palette: ['white', 'orange'],
};
// dataset1=dataset1.updateMask(dataset1.eq(5))
var Counties = ee.FeatureCollection('users/wrd_iwmi/India_States_New') 
  //.filter(ee.Filter.eq('S_NAME', 'BIHAR'));
var dataset1 = dataset1
       .select(['LULC'])
       .remap
      ([1,	2,	3,	4,	5,	6,	7,	8,	9,10,11,12,13,14,15,16,17,18,19	],
       [0,	0,	1,	0,	1,	0,	0,	0,	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0	]);
// Get slope.
dataset1=dataset1.updateMask(dataset1.eq(1))
Map.addLayer(dataset1.clip(Counties), cropMaskVis12, 'Agriculture Areas for Rabi Season (NRSC/ISRO)',0); 
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
var start="2020-03-18"
var end="2020-03-21"
var start1="2020-04-11"
var end1="2020-04-14"
//var aoi=ee.FeatureCollection('users/wrd_iwmi/World_boundary')
var dataset = ee.ImageCollection('MODIS/MOD09GA_006_EVI')//MODIS/006/MOD13Q1
                  .filter(ee.Filter.date(start1, end1));
var colorized = dataset.select('EVI')//.mean(); 
var colorizedVis = {
  min:0,
  max:1,
  palette: [
 'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01'
  ],
};
//Map.setCenter(73.32, 32.0529339857, 6);
colorized=colorized.mean()//.updateMask(dataset1.eq(1))
Map.addLayer(colorized.clip(aoi), colorizedVis, "MODIS Terra EVI [11-14 April 2020]",0);
var dataset = ee.ImageCollection('MODIS/MOD09GA_006_EVI')//MODIS/006/MOD13Q1
                  .filter(ee.Filter.date(start, end));
var colorized = dataset.select('EVI')//.mean();
var colorizedVis = {
  min:0,
  max:1,
  palette: [
 'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01'
  ],
};
//Map.setCenter(73.32, 32.0529339857, 6);
colorized=colorized.mean()//.updateMask(dataset1.eq(1))
Map.addLayer(colorized.clip(aoi), colorizedVis, "MODIS Terra EVI [18-21 March 2020]",0);
////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
var dataset = ee.ImageCollection('MODIS/006/MOD09GA')
                  .filter(ee.Filter.date(start,end));
var trueColor143 =
    dataset.select(['sur_refl_b01', 'sur_refl_b04', 'sur_refl_b03']);
var trueColor143Vis = {
  min: -100.0,
  max: 2000.0,
  gamma:1.1
};
//Map.setCenter(-7.03125, 31.0529339857, 2);
//Map.addLayer(trueColor143.median().clip(aoi), trueColor143Vis, 'True Color March');
var dataset = ee.ImageCollection('MODIS/006/MOD09GA')
                  .filter(ee.Filter.date(start1,end1));
var trueColor143 =
    dataset.select(['sur_refl_b01', 'sur_refl_b04', 'sur_refl_b03']);
var trueColor143Vis = {
  min: -100.0,
  max: 2000.0,
  gamma:1.1
};
//Map.setCenter(-7.03125, 31.0529339857, 2);
//Map.addLayer(trueColor143.median().clip(aoi), trueColor143Vis, 'True Color April');
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
var curr_wk_start="2020-04-01"
var curr_wk_end="2020-04-07"
var curr_wk_lastyear_start="2020-03-15" // last week
var curr_wk_lastyear_end="2020-03-23"
var one_wk_ahead_last_year_start="2020-04-08" 
var one_wk_ahead_last_year_end="2020-04-15"
var two_wk_ahead_last_year_start="2019-04-16"
var two_wk_ahead_last_year_end="2019-04-23"
var EVIvalue=0.28
var binarycolorizedVis = {
  min:0,
  max:1,
  palette: [
 'FFFFFF', 'green'
  ],
};
var dataset = ee.ImageCollection('COPERNICUS/Landcover/100m/Proba-V/Global');
var landcover = dataset.select('discrete_classification').mean();
landcover=landcover.updateMask(landcover.eq(40))
//Map.setCenter(-88.6, 26.4, 3);
var cropMaskVis12 = {
  min: 0.0,
  max: 40.0,
  palette: ['orange', 'orange', 'orange', 'orange', 'orange', 'lightgreen'],
};
//Map.addLayer(landcover, cropMaskVis12, 'Agri Landcover - Proba');
var dataset1 = ee.Image('USGS/GFSAD1000_V1');
var cropMask = dataset1.select('landcover');
var cropMaskVis = {
  min: 0.0,
  max: 5.0,
  palette: ['black', 'orange', 'brown', '02a50f', 'green', 'yellow'],
};
var cropMaskVis1 = {
  min: 0.0,
  max: 5.0,
  palette: ['orange', 'orange', 'orange', 'orange', 'orange', 'orange'],
};
var cropMaskVis2 = {
  min: 0.0,
  max: 5.0,
  palette: ['yellow', 'yellow', 'yellow', 'yellow', 'yellow', 'yellow'],
};
//Map.setCenter(-17.22, 13.72, 2);
//1+2;3+4+5
// 0	black	Non-croplands
// 1	orange	Croplands: irrigation major
// 2	brown	Croplands: irrigation minor
// 3	02a50f	Croplands: rainfed
// 4	green	Croplands: rainfed, minor fragments
// 5	yellow	Croplands: rainfed, very minor fragments
var mask =cropMask.updateMask(cropMask.lt(3))
mask =mask.updateMask(mask.gt(0))
var mask1 =cropMask.updateMask(cropMask.gt(2))
mask1 =mask1.updateMask(mask1.gt(0))
// mask =mask.updateMask(mask.gt(0))
//Map.addLayer(mask, cropMaskVis1, 'Irrigated area');//orange
//Map.addLayer(mask1, cropMaskVis2, 'Rainfed area');//yellow
var mask =mask.updateMask(landcover.eq(40))
mask =mask.updateMask(mask.gt(0))
var mask1 =mask1.updateMask(landcover.eq(40))
mask1 =mask1.updateMask(mask1.gt(0))
//Map.addLayer(mask, cropMaskVis1, 'Irrigated area under proba landcover ');//orange
//Map.addLayer(mask1, cropMaskVis2, 'Rainfed area under proba landcover');//yellow
var dataset = ee.ImageCollection('MODIS/MOD09GA_006_EVI')//MODIS/006/MOD13Q1
                  .filter(ee.Filter.date(curr_wk_start, curr_wk_end));
var colorized = dataset.select('EVI')//.mean();
var colorizedVis = {
  min:0,
  max:1,
  palette: [
 'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01'
  ],
};
//Map.setCenter(73.32, 32.0529339857, 6);
colorized=colorized.mean().updateMask(landcover.gt(0))
var colorized= colorized.expression(
    "(b('EVI') > 0.28) ? 1" +
      ": (b('EVI') <=0.28) ? 0" +
        ": 0"
    );
//colorized=colorized.updateMask(colorized.gt(EVIvalue))
//Map.addLayer(colorized, binarycolorizedVis, "Total Crop - current week");
var colorized_bin=colorized.updateMask(colorized.gt(0))
//Map.addLayer(colorized_bin, binarycolorizedVis, "Total Crop binary - current week");
var dataset_1 = ee.ImageCollection('MODIS/MOD09GA_006_EVI')//MODIS/006/MOD13Q1
                  .filter(ee.Filter.date(curr_wk_lastyear_start, curr_wk_lastyear_end));
var colorized_1 = dataset_1.select('EVI')//.mean();
var colorizedVis = {
  min:0,
  max:1,
  palette: [
 'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01'
  ],
};
//Map.setCenter(73.32, 32.0529339857, 6);
colorized_1=colorized_1.mean().updateMask(landcover.gt(0))
var colorized_1= colorized_1.expression(
    "(b('EVI') > 0.28) ? 1" +
      ": (b('EVI') <=0.28) ? 0" +
        ": 0"
    );
// colorized_1=colorized_1.updateMask(colorized_1.gt(EVIvalue))
//Map.addLayer(colorized, binarycolorizedVis, "Total Crop - current week 2019");
var colorized_1_bin=colorized_1.updateMask(colorized_1.gt(0))
//Map.addLayer(colorized_1_bin, binarycolorizedVis, "Total Crop binary - previous week");
var dataset_2 = ee.ImageCollection('MODIS/MOD09GA_006_EVI')//MODIS/006/MOD13Q1
                  .filter(ee.Filter.date(one_wk_ahead_last_year_start, one_wk_ahead_last_year_end));
var colorized_2 = dataset_2.select('EVI')//.mean();
var colorizedVis = {
  min:0,
  max:1,
  palette: [
 'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01'
  ],
};
//Map.setCenter(73.32, 32.0529339857, 6);
colorized_2=colorized_2.mean().updateMask(landcover.gt(0))
//colorized_2=colorized_2.updateMask(colorized_2.gt(EVIvalue))
var colorized_2= colorized_2.expression(
    "(b('EVI') > 0.28) ? 1" +
      ": (b('EVI') <=0.28) ? 0" +
        ": 0"
    );
//Map.addLayer(colorized_2, binarycolorizedVis, "Total Crop one week ahead ");
var colorized_2_bin=colorized_2.updateMask(colorized_2.gt(0))
//Map.addLayer(colorized_2_bin, binarycolorizedVis, "Total Crop binary one week ahead ");
var dataset_3 = ee.ImageCollection('MODIS/MOD09GA_006_EVI')//MODIS/006/MOD13Q1
                  .filter(ee.Filter.date(two_wk_ahead_last_year_start, two_wk_ahead_last_year_end));
var colorized_3 = dataset_3.select('EVI')//.mean();
var colorizedVis = {
  min:0,
  max:1,
  palette: [
 'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01'
  ],
};
//Map.setCenter(73.32, 32.0529339857, 6);
colorized_3=colorized_3.mean().updateMask(landcover.gt(0))
var colorized_3= colorized_3.expression(
    "(b('EVI') > 0.28) ? 1" +
      ": (b('EVI') <=0.28) ? 0" +
        ": 0"
    );
//colorized_3=colorized_3.updateMask(colorized_2.gt(EVIvalue))
//Map.addLayer(colorized_3, binarycolorizedVis, "Total Crop - two week ahead");
var colorized_3_bin=colorized_3.updateMask(colorized_3.gt(0))
//Map.addLayer(colorized_3_bin, binarycolorizedVis, "Total Crop binary - two week ahead ");
var crop_harvest_one_wk_ahead=colorized.subtract(colorized_2)
crop_harvest_one_wk_ahead=crop_harvest_one_wk_ahead.updateMask(crop_harvest_one_wk_ahead.gt(0))
//Map.addLayer(crop_harvest_one_wk_ahead, {min:0,  max:1,  palette: [ 'FFFFFF', 'red']}, "Projected Harvest - one weak ahead");
var crop_harvest_two_wk_ahead=colorized.subtract(colorized_3)
crop_harvest_two_wk_ahead=crop_harvest_two_wk_ahead.updateMask(crop_harvest_two_wk_ahead.gt(0))
//Map.addLayer(crop_harvest_two_wk_ahead, {min:0,  max:1,  palette: [ 'FFFFFF', 'red']}, "ProjectedHarvest - two weak ahead");
var prev_week=colorized_1.multiply(2)
var curr_week=colorized.multiply(10)
var next_week=colorized_2.multiply(100)
var next2_week=colorized_3.multiply(1000)
// Map.addLayer(curr_week, {min:0,  max:2,  palette: [ 'FFFFFF', 'red']}, "curr_week");
// Map.addLayer(next_week, {min:0,  max:10,  palette: [ 'FFFFFF', 'red']}, "next_week");
// Map.addLayer(next2_week, {min:0,  max:100,  palette: [ 'FFFFFF', 'red']}, "next2_week");
 var all=prev_week.add(curr_week).add(next_week).add(next2_week)
  all=all.updateMask(all.gt(1))
// var all=all.select('Constant')
//           .remap
//           ([2,10,12,100,102,110,112],
//           [1,2,3,4,5,6,7]);
//var mask =LULC1.updateMask(LULC1.gt(0))
//Map.addLayer(all, {min:2,  max:112,  palette: ['A4C400', 'FFFF00','FFBB00','FF7700','FF2600','A52A2A','2E8B57']}, "ProjectedHarvest - all");
var all_1=all.updateMask(all.eq(2))
var all_2=all.updateMask(all.eq(12))
var all_3=all.updateMask(all.eq(112))
var all_4=all.updateMask(all.eq(1112))
Map.addLayer(all_4, {palette: ['2E8B57']}, "Crop areas likely continues to grow beyond 23 April 2020",1);
Map.addLayer(all_3, {palette: ['A4C400']}, " Areas likely harvested in 16-23 April 2020",1);
Map.addLayer(all_2, {palette: ['FFBB00']}, " Areas likely harvested in 08-15 April 2020",1);
Map.addLayer(all_1, {palette: ['FF2600']}, " Areas likely harvested in 01-07 April 2020",1);
Map.addLayer(colorized_1.updateMask(colorized_1.gt(0)), binarycolorizedVis, "Peak crop area [15-23 March 2020] ",0);
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette =['FF2600','FFBB00','A4C400','2E8B57'];//'A4C400', 'FFFF00','FFBB00','FF7700','FF2600','A52A2A','2E8B57' 
// name of the legend
 var names = ['Crop areas likely harvested in 01-07 April 2020','Crop areas likely harvested in 08-15 April 2020','Crop areas likely harvested in 16-23 April 2020',' Crop areas likely continues to grow beyond 23 April 2020'];
// Add color and and names
for (var i = 0; i < 4; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend);
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
///////////////////////////////////////////
//Map.addLayer(ee.Image().paint(geometry, 0, 0.4), {}, 'Afghanistan');
var geometry1 = aoi//ee.FeatureCollection('users/wrd_iwmi/afghanistan/AFG_adm1');
//Map.addLayer(ee.Image().paint(geometry1, 0, 0.4), {palette:'black'}, 'World Boundary',0);
//Map.addLayer(ee.Image().paint(geometry1, 0, 0.6), {palette:'black'}, 'Senegal District',0);
//var geometry2 = ee.FeatureCollection('users/wrd_iwmi/afghanistan/AFG_adm2');
//Map.addLayer(ee.Image().paint(geometry2, 0, 0.6), {palette:'black'}, 'Afghanistan Sub District',0);
//Map.addLayer(ee.Image().paint(met_Locations, 0, 0.6), {palette:'black'}, 'Met Stations');
///Map.addLayer(met_Locations, {}, 'Met Stations',1);
//Map.addLayer(met_Locations.style({ color: 'red', pointSize: 3}), {}, 'Met Stations',1)
//Map.addLayer(ee.Image().paint(Subbasins, 0, 0.2), {palette:'skyblue'}, 'Subbasins',0);
Map.addLayer(ee.Image().paint(Rivers, 0, 0.4), {palette:'black'}, 'India (State)',0);
Map.addLayer(ee.Image().paint(Basins, 0, 0.2), {palette:'blue'}, 'World Basin Boundary',1);
////////////////////////////////
//var aoi = ee.FeatureCollection('users/wrd_iwmi/afghanistan/AFG_adm0');
//var MapLeft = ui.Map();
var TitleLabel = ui.Label('Global Cropland Monitoring Tool (v1)',{height: 18, fontWeight: 'bold'});
var ExplaLabel = ui.Label('An initiative by International Water Management Institute (IWMI), CGIAR Research Program of Water, Land and Ecosystems (WLE) and Indian Council of Agricultural Research (ICAR) during COVID-19 lockdown',{textAlign:'justify',fontSize: '14px', width: '360px', height: '90px'});
//var info= (ui.Label('For more Info, please visit: http://...',{fontWeight: 'bold',fontSize: '09px',position: 'top-right'}));
//panel.add(info);
var TitleLabel0 = ui.Label('Disclaimer: The product prepared by the International Water Management Institute (IWMI) has not been validated in the field and limited evaluation carried out with few country crop sown datasets. The views expressed may not be regarded as an official position of the IWMI, CGIAR WLE and ICAR (India) in any circumstances. National borders are purely a graphical representation, only intended to be indicative, and do not reflect the official position of the IWMI, CGIAR WLE and ICAR (India). Neither the IWMI nor any person acting on behalf of the program are responsible for the use that might be made of this application.',{width: '360px',height: 100, textAlign:'justify',fontSize: '11px', fontWeight: 'Italic'});
var EarthPanel0 = ui.Panel([TitleLabel0],ui.Panel.Layout.flow('horizontal'),{width: '400px', height: '1000px', position: 'bottom-left'});
//var ExplaLabel2 = ui.Label('Long term mean annual precipitation',{textAlign:'justify',fontSize: '14px', width: '400px', height: '100px'});
//var ExplaLabel2 = ui.Label('Long term mean annual precipitation',{height: 10, fontWeight: 'bold'});
//// Add minimap
var EarthMap = ui.Map();
EarthMap.setControlVisibility(false);
//EarthMap.addLayer(aoi,{palette: 'FFFF0000'});
var empty = ee.Image().byte();
var outline1 = empty.paint({
  featureCollection: aoi,
  color: 1,
  width: 0.3
});
//EarthMap.addLayer(outline1,{palette: 'black'});
//Map.addLayer(outline1, {palette: 'black'}, 'India Boundary');
//Map.setOptions("HYBRID");
//EarthMap.centerObject(aoi,2.2);
EarthMap.setCenter(78.17, 26.125,2.2) 
var EarthPanel = ui.Panel([EarthMap],ui.Panel.Layout.flow('horizontal'),{width: '400px', height: '240px', position: 'bottom-left'});
//var TitleLabel12 = ui.Label('Long term mean monthly precipitation',{height: 10, fontWeight: 'bold'});
//var EarthPanel12 = ui.Panel([TitleLabel2],ui.Panel.Layout.flow('horizontal'),{width: '520px', height: '320px', position: 'bottom-left'});
var TitleLabel01 = ui.Label('',{height: 10, fontWeight: 'bold'});
var TitleLabel1 = ui.Label('',{height: 10, fontWeight: 'bold'});
var TitleLabel2 = ui.Label('',{height: 10, fontWeight: 'bold'});
var EarthPanel01 = ui.Panel([TitleLabel01],ui.Panel.Layout.flow('horizontal'),{width: '400px', height: '200px', position: 'bottom-left'});
var EarthPanel1 = ui.Panel([TitleLabel1],ui.Panel.Layout.flow('horizontal'),{width: '400px', height: '200px', position: 'bottom-left'});
//var EarthPanel2 = ui.Panel([TitleLabel2],ui.Panel.Layout.flow('horizontal'),{width: '400px', height: '200px', position: 'bottom-left'});
var TitleLabel3 = ui.Label('',{width: '380px', height: 10,textAlign:'justify'});
var EarthPanel3 = ui.Panel([TitleLabel3],ui.Panel.Layout.flow('horizontal'),{width: '400px', height: '200px', position: 'bottom-left'});
// Setup screen
//ui.root.clear();
// Create User Interface portion --------------------------------------------------
// Create a panel to hold our widgets.
var panel = ui.Panel();
panel.style().set('width', '400px');
// Create an intro panel with labels.
var intro = ui.Panel([
 /*
 ui.Label({
    value: 'Statistics',
    style: {fontSize: '14px', fontWeight: 'bold'}
  }),
  */
  ui.Label
  ({
    value: '........',
    style: {fontSize: '10px', fontWeight: 'bold'}
  })
]);
//panel.add(intro);
/// Define a DataTable using a JavaScript literal.
// Define a dictionary of customization options.
var options = {
 // title: 'Cactus Suitability Status: India',
  /*hAxis: {title: 'Suitability class'},
  legend: {position: 'none'},
  vAxis: {
    title: 'Suitability value (%)',
    logScale: true
  },*/
  width:300,
  height: 100,
  title: '.....',
  colors: ['00FF00', 'yellow','orange', 'FF0000'],// less
 // fontcolor: 'black',
  // pieSliceText: 'label'
  pieSliceTextStyle: {color:'black'}
};
// var image = ee.Image('users/wrd_iwmi/iwmi_logo').visualize({
//   bands: ['b1', 'b2', 'b3'],
//   min: 0,
//   max: 255,
//   //gamma: [1, 1, 1]
// });
// // Print a thumbnail to the console.
// var p1=ui.Thumbnail({
//   image: image,
//   params: {
//     dimensions: '100x100',
//     //region: box,
//     format: 'png'
//   },
//   style: {backgroundColor: 'white', position: 'top-left', textAlign:'justify',height: '90px', width: '140px'}
// });
 //ui.root.add(p1);
// EarthPanel0.widgets().set(2, p1);
//ui.root.add(ui.Panel([TitleLabel, EarthPanel0,  ExplaLabel, EarthPanel,EarthPanel3],ui.Panel.Layout.flow('vertical'),{width: '400px'}));
ui.root.add(ui.Panel([TitleLabel,  ExplaLabel, EarthPanel,EarthPanel0,EarthPanel3],ui.Panel.Layout.flow('vertical'),{width: '400px'}));
//////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//Map.centerObject(aoi, 2.2);
Map.setCenter(78.17, 26.125,6)
///////////////////////////////////////////////////////////////
// // set position of panel
// var legend = ui.Panel({
//   style: {
//     position: 'bottom-left', 
//     padding: '8px 15px'
//   }
// });
// // Create legend title
// var legendTitle = ui.Label({
//   value: 'Agriculture Class',
//   style: {
//     fontWeight: 'bold',
//     fontSize: '14px',
//     margin: '0 0 4px 0',
//     padding: '0'
//     }
// });
// // Add the title to the panel
// legend.add(legendTitle);
// // Creates and styles 1 row of the legend.
// var makeRow = function(color, name) {
//       // Create the label that is actually the colored box.
//       var colorBox = ui.Label({
//         style: {
//           backgroundColor: '#' + color,
//           // Use padding to give the box height and width.
//           padding: '8px',
//           margin: '0 0 4px 0'
//         }
//       });
//       // Create the label filled with the description text.
//       var description = ui.Label({
//         value: name,
//         style: {margin: '0 0 4px 6px'}
//       });
//       // return the panel
//       return ui.Panel({
//         widgets: [colorBox, description],
//         layout: ui.Panel.Layout.Flow('horizontal')
//       });
// };
// //  Palette with the colors
// var palette =['F7FF00', 'FFA500'];
// // name of the legend
// var names = ['Irrigated','Rainfed'];
// // Add color and and names
// for (var i = 0; i < 2; i++) {
//   legend.add(makeRow(palette[i], names[i]));
//   }  
// // add legend to map (alternatively you can also print the legend to the console)
// Map.add(legend);
//////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// // Create a panel to hold title, intro text, chart and legend components.
// var panel3 = ui.Panel([], ui.Panel.Layout.Flow('vertical'),{position:'bottom-left'});
// var vis = {min: 400, max: 5000}//, palette: ['3ae237', 'b5e22e', 'd6e21f', 'fff705', 'ffd611', 'ffb613', 'ff8b13',
//   //  'ff6e08', 'ff500d', 'ff0000', 'de0101', 'c21301', '0602ff', '235cb1',
//   // '307ef3', '269db1', '30c8e2', '32d3ef', '3be285', '3ff38f', '86e26f']};
// function makeColorBarParams(palette) {
//   return {
//     bbox: [0, 0, 1, 0.1],
//     dimensions: '150x10',
//     format: 'png',
//     min: 0,
//     max: 1,
//     palette: palette,
//     position: 'top-left',
// padding: '6px 9px'
//   };
// }
// // Create the color bar for the legend.
// var colorBar = ui.Thumbnail({
//   image: ee.Image.pixelLonLat().select(0),
//   params: makeColorBarParams(vis.palette),
//   style: {stretch: 'horizontal', margin: '0px 8px', position: 'top-left',maxHeight: '24px'},
// });
// // Create a panel with three numbers for the legend.
// var legendLabels = ui.Panel({
//   widgets: [
//     ui.Label(vis.min, {margin: '4px 0px'}),
//     ui.Label(
//         (vis.max / 2),
//         {margin: '4px 0px', textAlign: 'center', stretch: 'horizontal'}),
//     ui.Label(vis.max, {margin: '4px 0px'})
//   ],style: {position: 'top-left',padding: '2px 5px'},
//   layout: ui.Panel.Layout.flow('horizontal')
// });
// var legendTitle = ui.Label({
//   value: 'Elevation (meter)',
//   style: {fontWeight: 'bold',position: 'bottom-right'}
// });
// var yearSubPanel = ui.Panel([legendTitle, colorBar, legendLabels], ui.Panel.Layout.Flow('vertical'),{position: 'bottom-right'});
// panel3.add(yearSubPanel);
// Map.add(panel3);
// // Create a panel to hold title, intro text, chart and legend components.
// var panel3 = ui.Panel([], ui.Panel.Layout.Flow('vertical'),{position:'bottom-left'});
// var vis = {
//   min:0,
//   max:100,
//   palette: ['red', 'blue']
// };
// function makeColorBarParams(palette) {
//   return {
//     bbox: [0, 0, 1, 0.1],
//     dimensions: '150x10',
//     format: 'png',
//     min: 0,
//     max: 1,
//     palette: palette,
//     position: 'top-left',
// padding: '6px 9px'
//   };
// }
// // Create the color bar for the legend.
// var colorBar = ui.Thumbnail({
//   image: ee.Image.pixelLonLat().select(0),
//   params: makeColorBarParams(vis.palette),
//   style: {stretch: 'horizontal', margin: '0px 8px', position: 'top-left',maxHeight: '24px'},
// });
// // Create a panel with three numbers for the legend.
// var legendLabels = ui.Panel({
//   widgets: [
//     ui.Label(vis.min, {margin: '4px 0px'}),
//     ui.Label(
//         (vis.max / 2),
//         {margin: '4px 0px', textAlign: 'center', stretch: 'horizontal'}),
//     ui.Label(vis.max, {margin: '4px 0px'})
//   ],style: {position: 'top-left',padding: '2px 5px'},
//   layout: ui.Panel.Layout.flow('horizontal')
// });
// var legendTitle = ui.Label({
//   value: 'Water Occurrence (%)',
//   style: {fontWeight: 'bold',position: 'bottom-right'}
// });
// var yearSubPanel = ui.Panel([legendTitle, colorBar, legendLabels], ui.Panel.Layout.Flow('vertical'),{position: 'bottom-right'});
// panel3.add(yearSubPanel);
// Map.add(panel3);