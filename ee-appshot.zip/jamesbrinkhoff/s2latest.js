var bounds = ui.import && ui.import("bounds", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                140.78422367130472,
                -28.11952763635639
              ],
              [
                140.78422367130472,
                -35.80806631986364
              ],
              [
                153.92387210880472,
                -35.80806631986364
              ],
              [
                153.92387210880472,
                -28.11952763635639
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[140.78422367130472, -28.11952763635639],
          [140.78422367130472, -35.80806631986364],
          [153.92387210880472, -35.80806631986364],
          [153.92387210880472, -28.11952763635639]]], null, false);
var date = Date.now();
var start = ee.Date(date).advance(-15, 'days');
var stop = ee.Date(date);
var cloud_pal = ['#feebe2', '#fbb4b9', '#f768a1', '#c51b8a', '#7a0177'];
var filter_ic = function(ic) {
    return ic
        .filterDate(start, stop)
        //.filterBounds(bounds);
};
Map.centerObject(bounds);
var add_date = function(image) {
    var date = ee.Date(image.get('system:time_start')).format('yyyy-MM-dd', 'Australia/Sydney');
    return image.set('date', date);
};
var ic_s2 = filter_ic(ee.ImageCollection("COPERNICUS/S2_HARMONIZED")).select(['B4','B3','B2']);
var ic_s2sr = filter_ic(ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")).select(['B4','B3','B2'],['B4_sr','B3_sr','B2_sr']);
var ic_cs = filter_ic(ee.ImageCollection("GOOGLE/CLOUD_SCORE_PLUS/V1/S2_HARMONIZED"));
var ic_cp = filter_ic(ee.ImageCollection("COPERNICUS/S2_CLOUD_PROBABILITY"));
// Map layers
var layer_s2 = 0;
Map.layers().set(layer_s2, ui.Map.Layer(ee.Image.constant(0), {}, '', false));
var layer_s2_masked = 1;
Map.layers().set(layer_s2_masked, ui.Map.Layer(ee.Image.constant(0), {}, '', false));
var layer_s2_sr = 2;
Map.layers().set(layer_s2_sr, ui.Map.Layer(ee.Image.constant(0), {}, '', false));
var layer_cs = 3;
Map.layers().set(layer_cs, ui.Map.Layer(ee.Image.constant(0), {}, '', false));
var layer_cp = 4;
Map.layers().set(layer_cp, ui.Map.Layer(ee.Image.constant(0), {}, '', false));
var ic = ic_s2
    .linkCollection(ic_cs, ['cs'])
    .linkCollection(ic_cp, ['probability'])
    //.linkCollection(ic_s2sr, ['B4_sr','B3_sr','B2_sr']) //causes errors with masked tiles sometimes
    //.map(add_date);
var dates = ic.filterBounds(bounds).map(add_date).distinct('date')
    .reduceColumns(ee.Reducer.toList(), ['date'])
    .get('list')
    .getInfo();
var date_sel = dates[dates.length - 1]; // most recent date
var change_date = function(new_date) {
    date_sel = new_date;
    var start = ee.Date(date_sel, 'Australia/Sydney');
    var stop = start.advance(1,'day');
    print(date_sel,start,stop);
    var im = ic.filterDate(start,stop).mosaic();
    Map.layers().set(layer_s2, ui.Map.Layer(im.select(['B4', 'B3', 'B2']), {min: 0, max: 3000}, 'RGB TOA', true));
    Map.layers().set(layer_s2_masked, ui.Map.Layer(im.updateMask(im.select('cs').gt(0.7)).select(['B4', 'B3', 'B2']), {min: 0, max: 3000}, 'RGB TOA masked', false));
    //Map.layers().set(layer_s2_sr, ui.Map.Layer(im.select(['B4_sr', 'B3_sr', 'B2_sr']), {min: 0, max: 3000}, 'RGB SR', false));
    Map.layers().set(layer_cs, ui.Map.Layer(im.select(['cs']), {min: 0, max: 1, palette: cloud_pal.reverse()}, 'Cloud score +', false));
    Map.layers().set(layer_cp, ui.Map.Layer(im.select(['probability']), {min: 0, max: 100, palette: cloud_pal}, 'Cloud probability', false));
};
change_date(date_sel);
var date_select = ui.Select(dates, date_sel, date_sel, change_date);
var panel = ui.Panel({
    widgets: [date_select],
    layout: ui.Panel.Layout.flow('vertical'),
    style: {
        position: 'top-right',
        padding: '0px',
        width: '100px',
        //height: '400px'
    }
});
Map.add(panel);