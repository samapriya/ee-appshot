var table = ui.import && ui.import("table", "table", {
      "id": "projects/inegi-datos/assets/entmx2018"
    }) || ee.FeatureCollection("projects/inegi-datos/assets/entmx2018"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.MultiPoint();
// incluye paquete de visualización
var legends = require('users/jsilvan/tools:legends');
var gui = require('users/jsilvan/tools:gui');
//legends.width = '200px';
var gsw = ee.Image("JRC/GSW1_4/GlobalSurfaceWater").aside(print);
var TITLE = 'JRC Global Surface Water Mapping Layers, v1.4';
var TITLE_STYLE = {
  color: '555555',
  fontSize: '20px',
  fontWeight: 'bold',
  textAlign: 'center',
  width: '100'
};
var DESCR = 'This dataset contains maps of the location and temporal distribution of surface water from 1984 to 2021 and provides statistics on the extent and change of those water surfaces. For more information see the associated journal article: High-resolution mapping of global surface water and its long-term changes (Nature, 2016) and the online Data Users Guide.\n\n' +
'These data were generated using 4,716,475 scenes from Landsat 5, 7, and 8 acquired between 16 March 1984 and 31 December 2021. Each pixel was individually classified into water / non-water using an expert system and the results were collated into a monthly history for the entire time period and two epochs (1984-1999, 2000-2021) for change detection.\n\n'+
'This mapping layers product consists of 1 image containing 7 bands. It maps different facets of the spatial and temporal distribution of surface water over the last 38 years. Areas where water has never been detected are masked.';
//gsw.get('description').getInfo();
//var doc = jsoup.parse(DESCR);
//rint(doc)
var DESCR_STYLE = {
  fontSize: '11px',
  textAlign: 'left',
  margin: '0px 4px 8px 16px',
  whiteSpace: 'pre-wrap',
  stretch: 'horizontal'
};
var HEADER_STYLE = {
  fontSize: '14px',
  fontWeight: 'bold',
};
// objeto de prpiedades de las capas
var layer = {
  transition: {
    visParams: {
      bands: ['transition'],
      min: 0,
      max: 10,
      palette: ['ffffff','0000ff','22b14c','d1102d','99d9ea','b5e61d',
        'e6a1aa','ff7f27','ffc90e','7f7f7f','c3c3c3'],
    },
    label: 'Transition classes (1984-2022)',
    visibility: false,
    classes: ['No change','Permanent','New permanent','Lost permanent','Seasonal',
      'New seasonal','Lost seasonal','Seasonal to permanent','Permanent to seasonal',
      'Ephemeral permanent','Ephemeral seasonal']
  },
  change_abs: {
    visParams: {
      bands: ['change_abs'],
      min:-100,
      max:100,
      palette: ['orange','white','blue'],
    },
    label: "Occurrence Change: 1984-1999 vs 2000-2021",
    visibility: false,
  },
  occurrence: {
    visParams: {
      bands: ['occurrence'],
      min:0,
      max:100,
      palette: ['#caffea','#76fbea','#2cd4f1','#2077ff','#00008b'],
    },
    label: "Water Occurrence (1984-2022)",
    visibility: true,
  },
  seasonality: {
    visParams: {
      bands: ['seasonality'],
      min:0,
      max:12,
      palette: ['red','yellow','green','blue'],
    },
    label: "Seasonality (1984-2022)",
    visibility: false,
  },
  recurrence: {
    visParams: {
      bands: ['recurrence'],
      min:0,
      max: 100,
      palette: ['#ffffff','#e1afff','#0000ff'],
    },
    label: "Annual Recurrence (1984-2022)",
    visibility: false,
  },
  max_extent: {
    visParams: {
      bands: ['max_extent'],
      min:0,
      max: 1,
      palette: ['black','gray'],
    },
    style: {
      color: '8899aa',  
      width: 2, 
      fillColor: 'ffffff00', 
      lineType: 'solid',
      },
    label: "Max Extent",
    visibility: true,
    }
};
// vector de la cobertura
var outline = gsw
  .select('max_extent')
  .convolve(ee.Kernel.fixed(3,3,[[0,-1,0],[-1,4,-1],[0,-1,0]],1,1))
  .gt(0)
  .selfMask()
  .rename('max_extent');
Map.layers().set(0,ui.Map.Layer(gsw,layer.occurrence.visParams, layer.occurrence.label, layer.occurrence.visibility));
Map.layers().set(1,ui.Map.Layer(gsw,layer.change_abs.visParams, layer.change_abs.label, layer.change_abs.visibility));
Map.layers().set(2,ui.Map.Layer(gsw,layer.seasonality.visParams, layer.seasonality.label, layer.seasonality.visibility));
Map.layers().set(3,ui.Map.Layer(gsw,layer.recurrence.visParams, layer.recurrence.label, layer.recurrence.visibility));
Map.layers().set(4,ui.Map.Layer(gsw,layer.transition.visParams, layer.transition.label, layer.transition.visibility));
Map.layers().set(5,ui.Map.Layer(outline,layer.max_extent.visParams, layer.max_extent.label,layer.max_extent.visibility));
//.style(layer.max_extent.style)
Map.setCenter(-100.717, 20.967,5);
// Callback del boton Herramientas
var showTools = function(widget) {
  if (widget.value)
    ui.root.insert(0,toolsPanel);
  else
    ui.root.remove(toolsPanel);
};
// define botón cíclico para mostrar descripción
var showToolsButton = gui.toggleButton(
    [
      {
        label: '>>',
        value: false,
      },
      {
        label: '<<',
        value: true,
      }
    ],
    showTools); 
showToolsButton.style().set({
  position: 'bottom-left'});
Map.add(showToolsButton);
// Panel de leyendas
var toolsPanel = ui.Panel([
  ui.Label(TITLE,TITLE_STYLE),
  ui.Label('by jsilvan',{fontSize: '11px',textAlign: 'left',margin: '0px 4px 8px 16px'},'https://www.centrogeo.org.mx/areas-profile/jsilvan/'),
  ui.Label(DESCR,DESCR_STYLE)],'flow',{width: '250px'});
// Callback del boton Leyenda
var showLegend = function(widget) {
  if (widget.value)
    ui.root.add(legendPanel);
  else
    ui.root.remove(legendPanel);
};
// Panel de leyendas
var legendPanel = ui.Panel([
  ui.Label('Simbología',TITLE_STYLE),
    legends.classes(layer.transition.label,layer.transition.visParams,layer.transition.classes),
    legends.value(layer.recurrence.label,layer.recurrence.visParams),
    legends.value(layer.seasonality.label,layer.seasonality.visParams),
    legends.value(layer.change_abs.label,layer.change_abs.visParams),
    legends.value(layer.occurrence.label,layer.occurrence.visParams),
    legends.features('',layer.max_extent),
  ],'flow',{width: legends.width});
// define botón cíclico para mostrar leyenda
var showLegendButton = gui.toggleButton(
    [
      {
        label: '<<',
        value: false,
      },
      {
        label: '>>',
        value: true,
      }
    ],
    showLegend); 
showLegendButton.style().set('position','bottom-right');
Map.add(showLegendButton);