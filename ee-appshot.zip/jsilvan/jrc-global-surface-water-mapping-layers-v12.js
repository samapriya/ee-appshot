// incluye paquete de visualización
var legends = require('users/jsilvan/tools:legends');
var gui = require('users/jsilvan/tools:gui');
legends.width = '200px';
var gsw = ee.Image('JRC/GSW1_2/GlobalSurfaceWater');
var TITLE = 'JRC Global Surface Water Mapping Layers, v1.2';
var TITLE_STYLE = {
  color: '555555',
  fontSize: '20px',
  fontWeight: 'bold',
  textAlign: 'center',
  width: '100'
};
var DESCR = gsw.get('description').getInfo();
//var doc = jsoup.parse(DESCR);
//rint(doc)
var DESCR_STYLE = {fontSize: '11px',textAlign: 'left',margin: '0px 4px 8px 16px'};
var HEADER_STYLE = {
  fontSize: '14px',
  fontWeight: 'bold',
};
var TRANS_PROPS = {
  visParams: {
    min: 0,
    max: 10,
    palette: ['ffffff','0000ff','22b14c','d1102d','99d9ea','b5e61d',
      'e6a1aa','ff7f27','ffc90e','7f7f7f','c3c3c3'],
  },
  label: 'Transition classes (1984-2019)',
  visibility: false,
  classes: ['No change','Permanent','New permanent','Lost permanent','Seasonal',
    'New seasonal','Lost seasonal','Seasonal to permanent','Permanent to seasonal',
    'Ephemeral permanent','Ephemeral seasonal']
};
var OCC_PROPS = {
  visParams: {
    min:0,
    max:100,
    palette: ['red','blue'],
  },
  label: "Water Occurrence (1984-2015)",
  visibility: true,
};
var transition = gsw.select('transition');
var max_extent = gsw.select('max_extent');
var occurrence = gsw.select('occurrence');
//.updateMask(max_extent); //.clip(usumacinta);
//var occurrence = gsw.select('occurrence')
Map.setCenter(-100.717, 20.967,5);
Map.layers().set(0,ui.Map.Layer(occurrence,OCC_PROPS.visParams, OCC_PROPS.label, OCC_PROPS.visibility));
Map.layers().set(1,ui.Map.Layer(transition,TRANS_PROPS.visParams, TRANS_PROPS.label, TRANS_PROPS.visibility));
// Callback del boton Herramientas
var showTools = function(widget) {
  if (widget.value)
    ui.root.insert(0,toolsPanel);
  else
    ui.root.remove(toolsPanel);
};
// define botón cíclico para mostrar descripción
var showToolsButton = gui.toggleButton(
    [
      {
        label: '+Descripción',
        value: false,
      },
      {
        label: '-Descripción',
        value: true,
      }
    ],
    showTools); 
showToolsButton.style().set({
  position: 'bottom-left'});
Map.add(showToolsButton);
// Panel de leyendas
var toolsPanel = ui.Panel([
  ui.Label(TITLE,TITLE_STYLE),
  ui.Label(DESCR,DESCR_STYLE)],'flow',{width: '250px'});
// Callback del boton Leyenda
var showLegend = function(widget) {
  if (widget.value)
    ui.root.add(legendPanel);
  else
    ui.root.remove(legendPanel);
};
// Panel de leyendas
var legendPanel = ui.Panel([
  ui.Label('Simbología',TITLE_STYLE),
  legends.value(OCC_PROPS.label,OCC_PROPS.visParams),
  legends.classes(TRANS_PROPS.label,TRANS_PROPS.visParams,TRANS_PROPS.classes)],
  'flow',{width: legends.width});
// define botón cíclico para mostrar leyenda
var showLegendButton = gui.toggleButton(
    [
      {
        label: '+Leyendas',
        value: false,
      },
      {
        label: '-Leyendas',
        value: true,
      }
    ],
    showLegend); 
showLegendButton.style().set('position','bottom-right');
Map.add(showLegendButton);
// Panel de leyendas
var legendPanel = ui.Panel([
  ui.Label('Simbología',TITLE_STYLE),
  legends.value(OCC_PROPS.label,OCC_PROPS.visParams),
  legends.classes(TRANS_PROPS.label,TRANS_PROPS.visParams,TRANS_PROPS.classes)],
  'flow',{width: '200px'});