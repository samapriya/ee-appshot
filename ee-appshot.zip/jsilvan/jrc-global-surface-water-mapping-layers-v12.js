var table = ui.import && ui.import("table", "table", {
      "id": "projects/inegi-datos/assets/entmx2018"
    }) || ee.FeatureCollection("projects/inegi-datos/assets/entmx2018");
// incluye paquete de visualización
var legends = require('users/jsilvan/tools:legends');
var gui = require('users/jsilvan/tools:gui');
// Define los datos
var gsw = ee.Image("JRC/GSW1_4/GlobalSurfaceWater");
var units = ee.FeatureCollection('projects/ee-centrogeo/assets/GSW1_4_Stats');
var TITLE = 'Aguas Superficiales Globales';
var DESCR = 'Esta app se base en el conjunto de datos JRC Global Surface Water v1.4, el cual contiene mapas de la ubicación y distribución temporal de las aguas superficiales desde 1984 hasta 2021 y proporciona estadísticas sobre la extensión y el cambio de esas superficies de agua. Para obtener más información, consulte el artículo de revista asociado: High-resolution mapping of global surface water and its long-term changes (Nature, 2016) y la Guía de usuarios de datos en línea.\n\n' +
'Estos datos se generaron utilizando 4 716 475 escenas de Landsat 5, 7 y 8 adquiridas entre el 16 de marzo de 1984 y el 31 de diciembre de 2021. Cada píxel se clasificó individualmente en agua/no agua mediante un sistema experto y los resultados se recopilaron en un historial mensual. para todo el período de tiempo y dos épocas (1984-1999, 2000-2021) para la detección de cambios.\n\n'+
'Este producto de capas de mapeo consta de 1 imagen que contiene 7 bandas. Mapea diferentes facetas de la distribución espacial y temporal de las aguas superficiales durante los últimos 38 años. Las áreas donde nunca se ha detectado agua se enmascaran.';
// Define estilos
var TITLE_STYLE = {
  color: '555555',
  fontSize: '20px',
  fontWeight: 'bold',
  textAlign: 'center',
  width: '100'
};
var DESCR_STYLE = {
  fontSize: '11px',
  textAlign: 'left',
  margin: '0px 4px 8px 16px',
  whiteSpace: 'pre-wrap',
  stretch: 'horizontal'
};
var HEADER_STYLE = {
  fontSize: '14px',
  fontWeight: 'bold',
};
// objeto de propiedades de las capas
var layer = {
  transition: {
    visParams: {
      bands: ['transition'],
      min: 0,
      max: 10,
      palette: ['ffffff','0000ff','22b14c','d1102d','99d9ea','b5e61d',
        'e6a1aa','ff7f27','ffc90e','7f7f7f','c3c3c3'],
    },
    label: 'Transition classes (1984-2022)',
    visibility: false,
    classes: ['No change','Permanent','New permanent','Lost permanent','Seasonal',
      'New seasonal','Lost seasonal','Seasonal to permanent','Permanent to seasonal',
      'Ephemeral permanent','Ephemeral seasonal']
  },
  change_abs: {
    visParams: {
      bands: ['change_abs'],
      min:-100,
      max:100,
      palette: ['orange','white','blue'],
    },
    label: "Occurrence Change: 1984-1999 vs 2000-2021",
    visibility: false,
  },
  occurrence: {
    visParams: {
      bands: ['occurrence'],
      min:0,
      max:100,
      palette: ['#caffea','#76fbea','#2cd4f1','#2077ff','#00008b'],
    },
    label: "Water Occurrence (1984-2022)",
    visibility: true,
  },
  seasonality: {
    visParams: {
      bands: ['seasonality'],
      min:0,
      max:12,
      palette: ['red','yellow','green','blue'],
    },
    label: "Seasonality (1984-2022)",
    visibility: false,
  },
  recurrence: {
    visParams: {
      bands: ['recurrence'],
      min:0,
      max: 100,
      palette: ['#ffffff','#e1afff','#0000ff'],
    },
    label: "Annual Recurrence (1984-2022)",
    visibility: false,
  },
  max_extent: {
    visParams: {
      bands: ['max_extent'],
      min:0,
      max: 1,
      palette: ['black','gray'],
    },
    style: {
      color: '8899aa',  
      width: 2, 
      fillColor: 'ffffff00', 
      lineType: 'solid',
      },
    label: "Max Extent",
    visibility: true,
    },
  units: {
    label: 'Estados',
    style: {width: 0.5, color: '7b9acd', fillColor: '00000000'},
    visibility: true 
    },
  hilighted: {  
    style: {color: '8856a7', fillColor: '8856a788'},
    index: 7,
    label: 'Selección',
  }
};
// vector de la cobertura
var outline = gsw
  .select('max_extent')
  .convolve(ee.Kernel.fixed(3,3,[[0,-1,0],[-1,4,-1],[0,-1,0]],1,1))
  .gt(0)
  .selfMask()
  .rename('max_extent');
Map.layers().set(0,ui.Map.Layer(gsw,layer.occurrence.visParams, layer.occurrence.label, layer.occurrence.visibility));
Map.layers().set(1,ui.Map.Layer(gsw,layer.change_abs.visParams, layer.change_abs.label, layer.change_abs.visibility));
Map.layers().set(2,ui.Map.Layer(gsw,layer.seasonality.visParams, layer.seasonality.label, layer.seasonality.visibility));
Map.layers().set(3,ui.Map.Layer(gsw,layer.recurrence.visParams, layer.recurrence.label, layer.recurrence.visibility));
Map.layers().set(4,ui.Map.Layer(gsw,layer.transition.visParams, layer.transition.label, layer.transition.visibility));
Map.layers().set(5,ui.Map.Layer(outline,layer.max_extent.visParams, layer.max_extent.label,layer.max_extent.visibility));
Map.layers().set(6,ui.Map.Layer(units.style(layer.units.style),{}, layer.units.label,layer.units.visibility));
//.style(layer.max_extent.style)
Map.setCenter(-100.717, 20.967,5);
// Callback del boton Herramientas
var showTools = function(state,widget) {
  if (state)
    ui.root.insert(0,toolsPanel);
  else
    ui.root.remove(toolsPanel);
};
// define botón cíclico para mostrar descripción
var showToolsButton = gui.toggleIcon([gui.Emoji.question,gui.Emoji.times],0,showTools);
showToolsButton.style().set({
  position: 'bottom-left'});
Map.add(showToolsButton);
// Panel de leyendas
var toolsPanel = ui.Panel([
  ui.Label(TITLE,TITLE_STYLE),
  ui.Label('por jsilvan',{fontSize: '11px',textAlign: 'left',margin: '0px 4px 8px 16px'},'https://www.centrogeo.org.mx/areas-profile/jsilvan/'),
  ui.Label(DESCR,DESCR_STYLE)],'flow',{width: '250px'});
// Callback del boton Leyenda
var showLegend = function(state,widget) {
  if(state)
    ui.root.add(legendPanel);
  else
    ui.root.remove(legendPanel);
};
// Panel de leyendas
var legendPanel = ui.Panel([
  ui.Label('Simbología',TITLE_STYLE),
    legends.classes(layer.transition.label,layer.transition.visParams,layer.transition.classes),
    legends.value(layer.recurrence.label,layer.recurrence.visParams),
    legends.value(layer.seasonality.label,layer.seasonality.visParams),
    legends.value(layer.change_abs.label,layer.change_abs.visParams),
    legends.value(layer.occurrence.label,layer.occurrence.visParams),
    legends.features('',layer.max_extent),
  ],'flow',{width: legends.width});
// define botón cíclico para mostrar leyenda
var showLegendButton = gui.toggleIcon([gui.Emoji.map,gui.Emoji.times],0,showLegend);
showLegendButton.style().set('position','bottom-right');
Map.add(showLegendButton);
/*
 * The chart panel in the bottom-right
 */
// A list of points the user has clicked on, as [lon,lat] tuples.
var selectedPoints = [];
// Returns the list of countries the user has selected.
function getSelectedFeats() {
  return units.filterBounds(ee.Geometry.MultiPoint(selectedPoints));
}
// Updates the map overlay using the currently-selected countries.
function updateOverlay() {
  var overlay = getSelectedFeats().style(layer.hilighted.style);
  Map.layers().set(layer.hilighted.index, ui.Map.Layer(overlay,{},layer.hilighted.label));
}
function makeResultsBarChart(col) {
  var chart = ui.Chart.feature.byFeature(col, 'ESTADO',['AREA_KM2']);
  chart.setChartType('BarChart');
  chart.setOptions({
    title: 'Estados seleccionados',
    vAxis: {title: null},
    hAxis: {title: 'Cobertura máxima de cuerpos de agua [km2]', minValue: 0}
  });
  chart.style().set({stretch: 'both'});
  return chart;
}
// Makes a table of the given FeatureCollection of countries by name.
function makeResultsTable(col) {
  var table = ui.Chart.feature.byFeature(col, 'ESTADO');
  table.setChartType('Table');
  table.setOptions({allowHtml: true, pageSize: 5});
  table.style().set({stretch: 'both'});
  return table;
}
// Updates the chart using the currently-selected charting function,
function updateChart(state,widget) {
  var chartBuilder;
  if(state)
    chartBuilder = makeResultsBarChart;
  else
    chartBuilder = makeResultsTable;
  var chart = chartBuilder(getSelectedFeats());
  //resultsPanel.clear().add(chart).add(buttonPanel);
  resultsPanel.clear().add(chartCloseButton).add(chart).add(chartTypeToggleButton);
}
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  selectedPoints = [];
  Map.layers().remove(Map.layers().get(layer.hilighted.index));
  var instructionsLabel = ui.Label('Selecciona los Estados a comparar.');
  resultsPanel.widgets().reset([instructionsLabel]);
}
// Register a click handler for the map that adds the clicked point to the
// list and updates the map overlay and chart accordingly.
function handleMapClick(location) {
  selectedPoints.push([location.lon, location.lat]);
  updateOverlay();
  updateChart(chartTypeToggleButton.getState());
}
Map.onClick(handleMapClick);
// A button widget that toggles (or cycles) between states.
// To construct a ToggleButton, supply an array of objects describing
// the desired states, each with 'label' and 'value' properties.
function ToggleButton(states, onClick) {
  var index = 0;
  var button = ui.Button(states[index].label);
  button.value = states[index].value;
  button.onClick(function() {
    index = ++index % states.length;
    button.setLabel(states[index].label);
    button.value = states[index].value;
    onClick();
  });
  return button;
}
// Our chart type toggle button: the button text is the opposite of the
// current state, since you click the button to switch states.
// Makes a bar chart of the given FeatureCollection of countries by name.
var chartTypeToggleButton = gui.toggleIcon([gui.Emoji.bars,gui.Emoji.notes],0,updateChart);
var chartCloseButton = gui.icon(gui.Emoji.times, clearResults);
// A panel containing the two buttons .
var resultsPanel = ui.Panel({style: {position: 'bottom-left', width: '400px'}});
Map.add(resultsPanel);
clearResults();
Map.style().set({cursor: 'crosshair'});