/* GSIM - App para cáculo de indices espectrales empleando compuesto configurable
  Característica              Incluído    Nota
  Filtrado temático de indice     Si      Por tag y por sensor
  Selección de indice             Si
  Textura de indice               Si      Operador espacial
  Configuración de compuesto      Si      Colección y período
  Histograma de escenas           Si      Muestra el numero de escenas disponibles por período
  Comparación de dos índices      Si      Varias métricas, inlcuido campo vectorial
  Comparación de comparaciones    No
  Carga de capas vectoriales      Si      Solamente desde assets precargados y compartidos
  Carga de capas raster           No
  Creación de nuevos índices      No      Algunos se pueden implementar como operaciones binarias
  Leyendas                        Si      Hay que mejorar posiciónamiento
  Mapa llave (inset)              Si      Limitado al panel principal
  Mensaje de estado               Si      Limitado al panel principal
  Enmascaramiento interactivo     Si      Un solo umbral, invertible
  Área de máscara                 Si      A la escala del mapa
  Consulta de valores             Si
  Perfiles temporales             Si      Limitado a indices de primer orden
  Selector de fecha               Si      También desde perfil temporal e histograma
  Perfiles espectrales            Si      Solo un panel
  Perfiles espaciales             Si      Falta corregir para polyline
  Lineas de maximo descenso       Si      De escala fija
  Histogramas                     Si      Incluye estadisticas básicas, pero no incluye correlación
  Scatterplots                    Si      Falta ajuste de modelo corrrelacional
  Descarga de datos               Si      Interactividad limitada 
  Compartir mapas                 Si      Copiando y pegando el url, mapa de fondo no se configura
  Visualización configurable      Si      A través de la leyenda se configura
  Tipo de mapas base en url       Si      Solo por url, no se configura al cambiar el tipo de mapa
  Generación de huella de escenas Si      Limitado a 100
  Animación de colleccion         Si
  Capa de numero de escenas       Si      Campo Count creado al vuelo
  Enmascaramiento de nubes        Sí      Solo productos con mascara de nubes
  Ayuda en línea                  Si
  Sección de ejemplos             Si      Se inclyen en la ayuda
  Compuestos progamables x 2      Si      Los compuestos son progamables desde el url
  Trazons ligados en dos paneles  No
  Filtrado de nubes               Si      Para colecciones que tienen definida la propiedad CloudProp
*/
/*
 Bugs:
 1. Cuando el url indica texturas con reescalamiento el rango de despliegue es el mismo antes y después del cálculo de texturas
 2. Cuando se procesa el URL y tiene doble panel con comparación puede no generarse debido a que el retraso no es suficiente
 3. Cuando se cambia la geometría con la consulta puntual, de línea o de área, ésta se desactiva
 4. Al duplicar el panel se pierde el campo de consulta de una geometría cargada
*/
// Importa módulos externos
var legends = require('users/jsilvan/modules:legends');
var images = require('users/jsilvan/modules:images');
var terrain = require('users/jsilvan/modules:terrain');
var geometries = require('users/jsilvan/modules:geometries');
var iofun = require('users/jsilvan/modules:iofun');
var gui = require('users/jsilvan/modules:gui');
var text = require('users/gena/packages:text'); 
var TRANSPARENT = 'ffffff00';
var BGCOLOR  = '333333';
var FGCOLOR = 'eeeeee';
var ROW_STYLE = {
  backgroundColor: TRANSPARENT,
  color: FGCOLOR,
  stretch: 'horizontal',
  height: '31px', 
  margin: '0px', 
  padding: '0px'};
legends.titleStyle({fontSize: '12px',fontWeight: 'bold',stretch: 'both'});
legends.itemStyle({stretch: 'horizontal',border: '1px solid darkgray',backgroundColor: TRANSPARENT},FGCOLOR,BGCOLOR);
/* Funciones Auxiliares
*/
// muestra el tiempo transcurrido desde t0 en segundos
var eTime = function(){
  var t = new Date();
  var et = t-t0;
  t0 = t;
  return et;
};
// define propiedad startsWith
if (!String.prototype.startsWith) {
    Object.defineProperty(String.prototype, 'startsWith', {
        value: function(search, rawPos) {
            var pos = rawPos > 0 ? rawPos|0 : 0;
            return this.substring(pos, pos + search.length) === search;
        }
    });
}
// define propiedad format
if (!Date.prototype.format) {
    Object.defineProperty(Date.prototype, 'format', {
        value: function(fmt) {
            var yyyy = this.getUTCFullYear();
            var MM = this.getUTCMonth()+1;
            var dd = this.getUTCDate();
            var MMM = this.toLocaleString('default', {month: 'short' });
            var HH = this.getUTCHours();
            var mm = this.getUTCMinutes();
            var ss = this.getUTCSeconds();
            return fmt
              .replace('yyyy',yyyy)
              .replace('MMM',MMM)
              .replace('MM',(MM > 9?'':'0')+MM.toString())
              .replace('D',dd.toString())
              .replace('dd',(dd > 9?'':'0')+dd.toString())
              .replace('HH',(HH > 9?'':'0')+HH.toString())
              .replace('mm',(mm > 9?'':'0')+mm.toString())
              .replace('ss',(ss > 9?'':'0')+ss.toString());
        }
    });
}
// Función para formatear fecha a formato yyyy-MM-dd HH:mm
function dateStr(datenum,fmtStr){
  var date = new Date(datenum);  
  return date.format(fmtStr); //toISOString().slice(0,16).replace('T',' '); 
}
// cambia la visibilidad de una lista de widgets
function setShown(widgets,value){
  for(var i = 0; i< widgets.length; i++)
    widgets[i].style().set({shown: true});
}
/**************************/
// Define algunas variables globales
var t0;
/******************************************
 * Modelo de Datos
********************************************/
var app = {};
app.data = {};
// Define algunas constantes de la app
app.data.startUpDelayStep = 500; // retrazo durante generación de mapa al iniciar
app.data.maxROCthresholds = 32;
app.data.maxProfilePoints = 512;
app.data.maxflowLinePoints = 256;
app.data.maxHistogramBuckets = 128;
app.data.maxScatterPoints = 1024;
app.data.maxStatsPoints = 128;
app.data.maxCatchAreaIter = 128;
app.data.maxFootprints = 100;
app.data.panelWidth = 350;
app.data.periodFactors = {minute: 1/24/60, hour: 1/24, day: 1, month: 30.436875, year: 365.2425};
app.data.defaultProj = ee.Projection('EPSG:4326'); // WGS84_GEOG
app.data.mapProj = ee.Projection('EPSG:3857'); // WGS84_PROJ
app.data.sensorsList = Object.keys(images.SensorsList);
app.data.indexList = Object.keys(images.SI).sort();       // Lista de índices
app.data.indexInfo = app.data.indexList.map(function(i){return i + '/' + images.SI[i].name + '/' + images.SI[i].reference + '/' + images.SI[i].notes});
app.data.indexNameList = app.data.indexList.map(function(i){return images.SI[i].name});       // Lista de índices
app.data.indexTags = Object.keys(images.SI).map(function(key){return images.SI[key].tags;})
  .reduce(function(acc, val){
    return acc.concat(val.filter(function(item){return acc.indexOf(item) < 0;}));
    },['Current Sensor']).sort(); // ,'Search Terms'
app.data.textureList = Object.keys(images.SF).sort();            // lista de texturas
app.data.textureNameList =  app.data.textureList.map(function(i){return images.SF[i].name});            // lista de texturas
app.data.comparisonList = Object.keys(images.Comparisons).sort();  // lista de metricas de comparación
app.data.dateFormat = 'MMM D, yyyy'; // formato de fechas
app.data.dateFormatLong = 'yyyy-MM-dd HH:mmZ'; //  HH:mm formato de fechas
app.data.colReducers = {
  First: ee.Reducer.firstNonNull(),
  Min: ee.Reducer.min(),
  Max: ee.Reducer.max(),
  Mean: ee.Reducer.mean(),
  Median: ee.Reducer.median(),
  };
// define contadores y nombres base
app.data.profiles = 0;
app.data.areas = 0;
app.data.points = 0;
app.data.flowlines = 0;
app.data.catchments = 0;
app.data.contours = 0;
app.data.pointName = 'QueryPoint'; // nombre base de los puntos de consulta;
app.data.lineName = 'ProfileLine'; // nombre base de las lineas de perfiles;
app.data.flowlineName = 'FlowLine'; // nombre base de las lineas de flujo;
app.data.catchmentName = 'CatchmentArea'; // nombre base de las lineas de flujo;
app.data.contourName = 'MaskedArea'; // nombre base de las lineas de contorno;
app.data.polygonName = 'StatsPolygon'; // nombre base de las lineas de perfiles;
app.data.selectable = []; // aquí van pares nombres de capas y campo consultables
app.data.positions = ['left','right'];
app.data.dualpars = ['index','collection','date','startDate','endDate',
    'period','reducer','cloudMask','cloudFilter','maxCloud',
    'mask','threshold','invert','texture','descriptor','rescale',
    'rescaleMin','rescaleMax','kernel','mapType',
    'cbands','cmin','cmax','cpalette','cgamma','copacity',
    'ibands','imin','imax','ipalette','igamma','iopacity','ireverse','creverse'
    ]; // parametros duplicables
app.data.singlepars = ['tools','layer','asset','property', 'clip',
  'inspector','timeseries','spectrum','marker','histogram','profile',
  'lon','lat','zoom','split','normalize','comparison',
  'inset','insetPos','legends','legendsPos','iitem','citem','iitem2','citem2',
  ]; // parametros no duplicables
app.data.autopars = ['index','collection','startDate','endDate','period','ibands','cbands','imin','cmin',
    'imax','cmax','ipalette','cpalette','igamma','cgamma']; // parametros calculados automaticamente
app.data.url = 'https://jsilvan.users.earthengine.app/view/indices-espectrales-globales';
// Define textos de la interface
app.data.text = {};
app.data.text.title = 'Global Spectral Index Mapper';
app.data.text.descr = 'Use this app to compute, visualize, query and export ' +
  'spectral indices based on composites from varied image collections and time ' +
  'periods. Map will update upon change of options. (Last update ' + new Date().format('MMM, yyyy') + ')';
app.data.text.aoi = 'Centering map on your area of interest may help to accelerate computation of layers.' + 
  'Use the search box or the map navigation tools to locate your area of interest.\n' + 
  'Additionally, you may use the following tools from the tool bar:';
app.data.text.layer = '📍 Center on your location.' +
   '\n 📁 Load a vector layer from your GEE Assets (requires a GEE account). ' +
  'The Asset name must reference a public feature collection, and ' +
  'the Info property (optional), must be a valid string property.';
app.data.text.index = 'There are ' + app.data.indexList.length  + 
  ' indices to choose from. Use this section to filter, select and learn about available indices.';
app.data.text.composite = 'There are ' + app.data.sensorsList.length +
  ' collections that are filtered according to selected index. ' +
  'Configure the composite image by selecting the collection, ' + 
  'date, and other options.'; 
app.data.text.scenes = 'Scenes per period in current view'; 
app.data.text.operator = 'Optionally, perform some operations on selected index. '+
  'You may need to adjust the zoom level and/or index range before applying some operators.';
app.data.text.compare = 'Update the composite and\/or index (left panel), and then apply ' +
  'a binary operation between left and right indices. Result is shown on the left panel.';
app.data.text.explore = 'Use this section to change map and layer appearence and share the link.';
app.data.text.point = 'Click map to query value...';
app.data.text.profile = 'Draw a line to plot profile...';
app.data.text.polygon = 'Draw a polygon to compute statistics...';
app.data.text.download = 'Adjust the image resolution, image size and ' + 
  'download area, then click refresh to update the dowload URL. Maximum ' +
  'file size is 32 MB.';
app.data.text.about = 'This app has been created for academic, non-commercial purposes. ' +
 'It is made available free of charge as long as Google service is provided. ';
app.data.text.cite = 'Silván-Cárdenas, J.L. (2024). Global Spectral Index Mapper, a Google Earth Engine App. CentroGeo. On line: <https://jsilvan.users.earthengine.app/view/indices-espectrales-globales> \n\n';
app.data.text.disclaimer = 'Disclaimer: The author and his institution are not responsible for any errors or omissions, or for the results obtained from the ' + 
 'use of this app. All information in this site is provided "as is", with no guarantee of ' +
 'completeness, accuracy, timeliness or of the results obtained from the use of this information.';
app.data.text.examplesUrl = 'https://sites.google.com/centrogeo.edu.mx/gsim-ejemplos';
app.data.text.mapUrl = 'Update map url 👉';
app.data.text.indexGEE = '';
app.data.text.compositeGEE = '';
// define opciones por default, algunas se modifican desde el url
app.data.defaultopt = {
  tools: true,
  // opciones de AOI
  layer: false,
  asset: '',
  property: '',
  //opciones de imágenes
  index: 'NDVI',  // índice por defaut
  collection: 'MODIS-Terra SR 8-Day', // sensor por default
  date: Date.now() - 30*24*60*60*1000, // hace 30 dias
  startDate: undefined, //new Date('2000-02-18T00:00:00').getTime() inicio de adquisicion de MODIS
  endDate: undefined, //Date.now(),
  period: undefined, // forza default
  reducer: 'First',
  cloudFilter: false,
  cloudMask: false,
  maxCloud: 30,
  // opciones de procesamiento
  rescale: false,
  rescaleMin: 0,
  rescaleMax: 255,
  texture: false,
  descriptor: 'Mean',
  kernel:  3,
  mask: false,
  invert: false,
  threshold: 0,
  normalize: false,
  comparison: 'Normalized Difference',
  // opciones de consulta
  inspector: false,
  timeseries: false,
  spectrum: false,
  marker: true,
  histogram: false,
  profile: true,
  // opciones de mapa y legenda
  lon: 0,//-100.818, 
  lat: 0, ////21.123,
  zoom: 3,
  mapType: 'HYBRID',
  split: false,
  inset:  false,
  insetPos: 'right',
  legends: false,
  legendsPos: 'right',
  iitem: true,
  citem: false,
  iitem2: false,
  citem2: false,
  // opciones de visualizacion
  copacity: 1,
  iopacity: 1,
  ibands: undefined,
  cbands: undefined,
  imin: undefined,
  cmin: undefined,
  imax: undefined,
  cmax: undefined,
  ipalette: undefined,
  cpalette: undefined,
  igamma: undefined,
  cgamma: undefined,
  ireverse: false,
  creverse: false,
};
// opciones de graficas
app.data.specChart = {
  title: 'SensorID Spectral Signature',
  hAxis: {
    title: 'Wavelength (micrometer)',
    titleTextStyle: {italic: false, bold: true},
    viewWindow: {min: 0.3, max: 2.5}
  },
  vAxis: {
    title: 'Value',
    titleTextStyle: {italic: false, bold: true},
    //viewWindow: {min: 0, max: 0.5}
  },
  //legend: { position: "none" },
  series: {0: {labelInLegend: 'Point #'}},
  //colors: [color],
  pointSize: 0,
  lineSize: 2,
  curveType: 'function'
};
app.data.timeSeriesChart = {
  title: 'Sensor ID-index Time Series',
  hAxis: {title: 'time'},
  vAxis: {title: 'index'},
  //backgroundColor: 'FFFFAA',
  series: {0: {labelInlegend: 'point #', lineWidth: 1, pointSize: 0}}, //, color: color}},
};
app.data.profileChart = {
  title: 'Sensor ID-index Profile',
  vAxis: {
    title: 'index'
  },
  hAxis: {
    title: 'distance [m]'
  },  
//  legend: 'none',
  lineWidth: 1,
  series: {0: {labelInLegend: 'profile #'}}
  //pointSize: 2,
  //colors: [line_gl.getColor()],
};
app.data.histChart = {
  title: 'SensorID-index Histogram',
  bar: {groupWidth: '100%', gap: 0},
  series:  {0: {labelInLegend: 'polygon #'}},
  hAxis: {title: 'index', viewWindow: {min: 0, max: 1}},
  vAxis: {title: 'Count'},
};
app.data.scatterplot = {
  title: 'Scatterplot',
  pointSize: 2,
  hAxis: {
    title: 'xLabel',
    //viewWindow: {min: visParams_right.min, max: visParams_right.max}
  },
  vAxis: {
    title: 'yLabel',
    //viewWindow: {min: visParams_left.min, max: visParams_left.max}
  },
  series:  {0: {labelInLegend: 'polygon #'}},
  trendlines: {
    0: {  // add a trend line to the 1st series
      type: 'linear',  // or 'polynomial', 'exponential'
      color: 'black',
      lineWidth: 5,
      opacity: 0.5,
      visibleInLegend: true,
    }
  }
};
app.data.colHistChart = {
  bar: {groupWidth: '99%', gap: 1},
  hAxis: {baselineColor: 'none',viewWindow: {min: 0, max: 1}, gridlines: {count: 0}},// textPosition: 'none',
  vAxis: {baselineColor: 'none',  textPosition: 'none', gridlines: {count: 0}},
  colors: ['333333'],
  explorer: {axis: 'horizontal'},
  //backgroundColor: {fill: TRANSPARENT},
  strokeWidth: 0,
  chartArea: {height: '100%',width: '100%',left: 0, top: 0, backgroundColor: '888888'},
  height: 30,
  tooltip: {ignoreBounds: false, textStyle: {bold: false, fontSize: 8},trigger: 'focus'}, //, isHtml: true
  crosshair: {orientation: 'vertical',trigger: 'selection', focused: { color: 'red' }} //{ trigger: 'vertical' }
};
// define las variables de capas
app.data.layer = {};
app.data.layer.index = {};
app.data.layer.index.image = null;
app.data.layer.index.masked = null; // copia con máscara
app.data.layer.index.name = 'index';
app.data.layer.index.visParams = {};
app.data.layer.index.scale = 1;
app.data.layer.composite = {};
app.data.layer.composite.image = null;
app.data.layer.composite.name = 'composite';
app.data.layer.composite.visParams = {};
app.data.layer.composite.clipGeometry = null;
app.data.layer.downloadArea = null;
/******************************************
 * Objetos
********************************************/
// Componentes del Mapa
app.map = {};
app.map.bounds = ee.List([-137, -60, 137, 60]);
app.map.scale = ee.Number(1000); // escala del mapa, se actualizará al cambiar el zoom
app.map.main = ui.Map();
app.map.inset = ui.Map({style: {position: "bottom-right"}});
app.map.copy = ui.Map();
app.map.layer = {};
app.map.layer.composite = ui.Map.Layer();  
app.map.layer.index = ui.Map.Layer(); 
app.map.layer.composite2 = ui.Map.Layer();  
app.map.layer.index2 = ui.Map.Layer(); 
app.map.linker = ui.Map.Linker([app.map.main, app.map.copy],'change-bounds');
app.map.split = ui.SplitPanel({
    orientation: 'horizontal',
    wipe: true,
    style: {stretch: 'both'},
    firstPanel: app.map.linker.get(0),
    secondPanel: app.map.linker.get(1),
});
app.dateSelector = {};
app.dateSelector.closeDateSlider = gui.icon(gui.Emoji.times); 
app.dateSelector.configDateSlider = gui.icon(gui.Emoji.gear);
app.dateSelector.showColHist = gui.toggleIcon([gui.Emoji.bars,gui.Emoji.bars],0);
app.dateSelector.updateColHist = gui.icon(gui.Emoji.circArrowR);
app.dateSelector.showCalendar = gui.toggleIcon([gui.Emoji.calendar,gui.Emoji.calendar],0);
app.map.legends = {};
app.map.legends.panel = ui.Panel();
app.map.legends.index = legends.image(app.map.layer.index,app.map.main);
app.map.legends.composite = legends.image(app.map.layer.composite,app.map.main);
app.map.legends.index2 = legends.image(app.map.layer.index2,app.map.main);
app.map.legends.composite2 = legends.image(app.map.layer.composite2,app.map.main);
app.drawingTools = geometries.newDrawingTools(app.map.main);//app.map.main.drawingTools();
// Charts
app.chart = {};
app.chart.colHist = null;
// Widgets
app.title = ui.Label(app.data.text.title);
app.author = ui.Label('By jsilvan');
app.intro = ui.Label(app.data.text.descr);
app.control = {};
// AOI 
app.control.aoi = gui.curtainPanel('Area of Interest',0);
app.control.aoi.help = ui.Label(app.data.text.aoi);
app.control.aoi.layerHelp = ui.Label(app.data.text.layer);
// index
app.control.index = gui.curtainPanel('Spectral Index',0);
app.control.index.help = ui.Label(app.data.text.index);
app.control.index.panel = ui.Panel();
app.control.index.filterTags = ui.Select();
app.control.index.search = ui.Textbox('e.g. SAVI, Drought');
app.control.index.selector = ui.Select();
app.control.index.name = ui.Label('',{fontWeight : 'bold',stretch: 'horizontal'});
app.control.index.descr = ui.Label('');
// composite
app.control.composite = gui.curtainPanel('Image Composite',0);
app.control.composite.help = ui.Label(app.data.text.composite);
app.control.composite.collCount = ui.Label();
app.control.composite.collections = ui.Select({placeholder: 'There are NO collections for selected index!'});
app.control.composite.collection = ui.Label();
app.control.composite.showDateSlider = ui.Checkbox('Show date selector',false); 
app.control.composite.scenesCount = ui.Label();
app.control.composite.sceneTools = ui.Checkbox('Enable scenes geometry tools');
app.control.composite.dateRangeLabel = ui.Label();
app.control.composite.selDateLabel = ui.Label();
app.control.composite.dateSlider = ui.DateSlider();
// Map appearence
app.control.explore = gui.curtainPanel('Map Appearance',0);
app.control.explore.help = ui.Label(app.data.text.explore);
app.control.explore.mapType = ui.Select(["ROADMAP", "SATELLITE", "HYBRID","TERRAIN"]);
app.control.explore.showLayerList = ui.Checkbox('Show layer list',true);
app.control.explore.indexEdit = gui.toggleIcon([gui.Emoji.gear,gui.Emoji.times],0);//app.map.legends.index.widgets().get(0).remove(app.map.legends.index.edit);
app.control.explore.compositeEdit = gui.toggleIcon([gui.Emoji.gear,gui.Emoji.times],0); //app.map.legends.composite.widgets().get(0).remove(app.map.legends.composite.edit);
app.control.explore.index2Edit = gui.toggleIcon([gui.Emoji.gear,gui.Emoji.times],0); //app.map.legends.index2.widgets().get(0).remove(app.map.legends.index2.edit);
app.control.explore.composite2Edit = gui.toggleIcon([gui.Emoji.gear,gui.Emoji.times],0); //app.map.legends.composite2.widgets().get(0).remove(app.map.legends.composite2.edit);
app.control.explore.legends = ui.Checkbox('Insert map legend');
app.control.explore.index = ui.Checkbox('Include index',true);
app.control.explore.composite = ui.Checkbox('Include composite',true);
app.control.explore.index2 = ui.Checkbox('Include index (right panel)');
app.control.explore.composite2 = ui.Checkbox('Include composite (right panel)');
app.control.explore.inset = ui.Checkbox('Insert key map');
app.control.explore.showMapTypes = ui.Checkbox('Show map types',true);
app.control.explore.genUrl = gui.icon(gui.Emoji.link);
app.control.explore.urlText = ui.Label(app.data.text.mapUrl);
// operator
app.control.operator = gui.curtainPanel('Advanced Operations',0);
app.control.operator.help = ui.Label(app.data.text.operator);
app.control.operator.texture = ui.Checkbox('Apply spatial operator');
app.control.operator.selector = ui.Select(app.data.textureNameList);
app.control.operator.kernel = ui.Slider(3,15,app.data.defaultopt.kernel,2);
app.control.operator.rescale = ui.Checkbox('Apply pre-scalling');
app.control.operator.rescaleMin = ui.Textbox();
app.control.operator.rescaleMax = ui.Textbox();
app.control.operator.updateRange = gui.icon(gui.Emoji.circArrowR);
app.control.operator.name = ui.Label('',{fontWeight : 'bold',stretch: 'horizontal'});
app.control.operator.descr = ui.Label('');
app.control.operator.maskPolygon = gui.icon(gui.Emoji.polygonFilled);
app.control.operator.maskOutline = gui.icon(gui.Emoji.polygonOutline);
app.control.operator.mask = ui.Checkbox('Apply threshold mask');
app.control.operator.threshold = ui.Slider();
app.control.operator.invertMask = ui.Checkbox('Invert masked pixels');
app.control.operator.maskArea = ui.Label('Mask area:');
app.control.operator.compare = ui.Checkbox('Apply binary operation (needs two panels)');
app.control.operator.comparison = ui.Select(app.data.comparisonList,'',app.data.defaultopt.comparison);
app.control.operator.showQueryTool = ui.Checkbox('Enable query tools (requires drawing tool)',true);
// download
app.control.download = gui.curtainPanel('Download Data',0);
app.control.download.help = ui.Label(app.data.text.download);
app.control.download.index = ui.Label('Download Index Image (TIF)');
app.control.download.indexRefresh = gui.icon(gui.Emoji.circArrowR); // ui.Button('refresh');
app.control.download.composite = ui.Label('Download Composite image (TIF)');
app.control.download.compositeRefresh = gui.icon(gui.Emoji.circArrowR); //ui.Button('refresh');
app.control.download.samples = ui.Label('Download Geometry layers (KML)');
app.control.download.samplesRefresh = gui.icon(gui.Emoji.circArrowR); // ui.Button('refresh');  
app.control.download.video = ui.Label('Open Index animation (GIF)');
app.control.download.videoRefresh = gui.icon(gui.Emoji.circArrowR); //ui.Button('refresh');  
app.control.download.scale = ui.Slider();
app.control.download.scalePanel = ui.Panel([
    ui.Label('Pixel size (meters):',ROW_STYLE),
    app.control.download.scale
    ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE); 
app.control.download.rows = ui.Slider(100,10000,1000,1);
app.control.download.rowsPanel = ui.Panel([
    ui.Label('Rows (pixels):',ROW_STYLE),
    app.control.download.rows
    ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.download.cols = ui.Slider(100,10000,1000,1);
app.control.download.colsPanel = ui.Panel([
    ui.Label('Columns (pixels):',ROW_STYLE),
    app.control.download.cols
    ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.download.frames  = ui.Slider(1,100,10,1);
app.control.download.framesPanel = ui.Panel([
    ui.Label('Frames per seconds:',ROW_STYLE),
    app.control.download.frames
    ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.download.panel = ui.Panel();
app.control.panel = ui.Panel();
// about panel
app.control.about = gui.curtainPanel('About this App...',1);
app.control.about.help = ui.Label(app.data.text.about);
app.control.about.cite = ui.Label(app.data.text.cite);
app.control.about.disclaimer = ui.Label(app.data.text.disclaimer);
// toolBar
app.toolBar = {};
app.toolBar.showControlPanel = gui.toggleIcon([gui.Emoji.listItem,"<<"],1);
app.toolBar.centerOnMe = gui.icon(gui.Emoji.pin2);
app.toolBar.loadLayer = gui.icon(gui.Emoji.folder);
app.toolBar.indexExpr = gui.icon(gui.Emoji.xsquare);
app.toolBar.showDateSlider = gui.toggleIcon([gui.Emoji.watch,gui.Emoji.watch],0);
app.toolBar.clipComposite = gui.toggleIcon([gui.Emoji.puzzle,gui.Emoji.image],0);
app.toolBar.sceneCentroids = gui.icon(gui.Emoji.star6);
app.toolBar.sceneOutline = gui.icon(gui.Emoji.polygonOutline);
app.toolBar.scenePolygon = gui.icon(gui.Emoji.polygonFilled);
app.toolBar.duplicate = gui.toggleIcon([gui.Emoji.duplicate,gui.Emoji.single],0);
app.toolBar.swap = gui.icon(gui.Emoji.horArrow);
app.toolBar.queryIcon = gui.toggleIcon([gui.Emoji.info,gui.Emoji.stop],0);
app.toolBar.configQuery = gui.icon(gui.Emoji.gear);
app.toolBar.configLayer = gui.icon(gui.Emoji.gear);
app.toolBar.setClipping = gui.icon(gui.Emoji.scissors);
app.toolBar.bufferLayer = gui.icon(gui.Emoji.circularCrown);
app.toolBar.sampleLine = gui.icon(gui.Emoji.dotsDigonalL);
app.toolBar.sampleArea = gui.icon(gui.Emoji.dotsPyramid);
app.toolBar.showLegend = gui.toggleIcon([gui.Emoji.legend,gui.Emoji.legend],1);
app.toolBar.legendsPos = gui.toggleIcon([gui.Emoji.rightArrow,gui.Emoji.leftArrow],0);
app.toolBar.showInset = gui.toggleIcon([gui.Emoji.map,gui.Emoji.map],1);
app.toolBar.insetPos = gui.toggleIcon([gui.Emoji.rightArrow,gui.Emoji.leftArrow],0);
app.toolBar.showDrawingTools = gui.toggleIcon([gui.Emoji.pencil,gui.Emoji.pencil],1);
app.toolBar.showMapTools =gui.toggleIcon([gui.Emoji.search,gui.Emoji.search],1);
app.toolBar.centerArea = gui.icon(gui.Emoji.circArrowLR); 
app.toolBar.centerView = gui.icon(gui.Emoji.squareInSquare); 
// dialog widgets
app.dialog = {};
// Load Layer
app.dialog.loadLayer = {};
app.dialog.loadLayer.asset = ui.Textbox('projects/<project-name>/assets/<asset-name>');
app.dialog.loadLayer.property = ui.Textbox('to be shown upon selection');
app.dialog.loadLayer.load = ui.Button('Load');
app.dialog.loadLayer.cancel = ui.Button('Cancel');
app.dialog.loadLayer.clipping = ui.Checkbox('Use as clipping layer (polygons only)');
// timeSlice
app.dialog.timeSlice = {};
app.dialog.timeSlice.starDate = ui.Textbox(app.data.dateFormatLong,dateStr(app.data.defaultopt.startDate,app.data.dateFormatLong));
app.dialog.timeSlice.endDate = ui.Textbox(app.data.dateFormatLong,dateStr(app.data.defaultopt.endDate,app.data.dateFormatLong));
app.dialog.timeSlice.period = ui.Slider(1,30,app.data.defaultopt.period,1);
app.dialog.timeSlice.periodUnit = ui.Select(['year','month','day','hour','minute'],'','day');
app.dialog.timeSlice.reducer = ui.Select(Object.keys(app.data.colReducers),null,app.data.defaultopt.reducer);
app.dialog.timeSlice.cloudFilter = ui.Checkbox('Filter scenes by max CCP');
app.dialog.timeSlice.maxCloud = ui.Slider(0,100,0,1);
app.dialog.timeSlice.cloudMask = ui.Checkbox('Apply cloud masking');
app.dialog.timeSlice.apply = ui.Button('Apply');
app.dialog.timeSlice.reset = ui.Button('Reset Default');
app.dialog.timeSlice.cancel = gui.icon(gui.Emoji.times);
// query
app.dialog.queryOpts = {};
app.dialog.queryOpts.queryBar = gui.radioButtons(['Point','Line','Area'],'horizontal',0);
app.dialog.queryOpts.keepMarker = ui.Checkbox('Keep query point',true);
app.dialog.queryOpts.timeseries = ui.Checkbox('Include time series chart');
app.dialog.queryOpts.spectrum = ui.Checkbox('Include spectral signature chart');
app.dialog.queryOpts.flowline = ui.Checkbox('Generate flowline (downhill)');
app.dialog.queryOpts.catchment = ui.Checkbox('Generate catchment area (uphill)');
app.dialog.queryOpts.deletePoints = gui.icon(gui.Emoji.trashcan);
app.dialog.queryOpts.keepLine = ui.Checkbox('Keep query line',true);
app.dialog.queryOpts.profile = ui.Checkbox('Include profile plot',true);
app.dialog.queryOpts.deleteLines = gui.icon(gui.Emoji.trashcan);
app.dialog.queryOpts.keepPolygon = ui.Checkbox('Keep query polygon',true);
app.dialog.queryOpts.histogram = ui.Checkbox('Include histogram',false);
app.dialog.queryOpts.scatterplot = ui.Checkbox('Include scatterplot');
app.dialog.queryOpts.ROCplot = ui.Checkbox('Include ROC plot (MultiPoint)');
app.dialog.queryOpts.timeseries2 = ui.Checkbox('Include time series chart');
app.dialog.queryOpts.deletePolygons = gui.icon([gui.Emoji.trashcan]);
app.dialog.queryOpts.close = gui.icon(gui.Emoji.times);
/******************************************
 * Composición
********************************************/
// Panel de leyendas
app.map.legends.panel.add(app.map.legends.index);
app.map.legends.panel.add(app.map.legends.composite);
app.map.legends.panel.add(app.map.legends.index2);
app.map.legends.panel.add(app.map.legends.composite2);
// aoi
app.control.aoi.panel.add(app.control.aoi.help);
app.control.aoi.panel.add(app.control.aoi.layerHelp);
// index
app.control.index.panel.add(app.control.index.help);
app.control.index.searchPanel = ui.Panel([
  ui.Label('Search index: ',ROW_STYLE),
  app.control.index.search
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE)  
app.control.index.panel.add(app.control.index.searchPanel);
app.control.index.panel.add(ui.Panel([
  ui.Label('Or filter by tag: ',ROW_STYLE),
  app.control.index.filterTags
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE));
app.control.index.panel.add(ui.Panel([
  ui.Label('Selected index: ',ROW_STYLE),
  app.control.index.selector,
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE));
app.control.index.panel.add(app.control.index.name);
app.control.index.panel.add(app.control.index.descr);
// composite
app.control.composite.panel.add(app.control.composite.help);
app.control.composite.panel.add(ui.Panel([
    ui.Panel([
      ui.Label('Compatible collections:',ROW_STYLE),
      app.control.composite.collCount
      ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE),
    app.control.composite.collections,
    app.control.composite.collection
    ],ui.Panel.Layout.flow('vertical'),{backgroundColor: TRANSPARENT}));
// Toolbar de la app
app.toolBar.layerTools = ui.Panel([
    app.toolBar.bufferLayer,
    app.toolBar.sampleLine,
    app.toolBar.sampleArea,
    app.toolBar.setClipping,
    app.toolBar.configLayer,
  ],ui.Panel.Layout.flow('horizontal'));
app.toolBar.panel = ui.Panel([    
    app.toolBar.showControlPanel,
    gui.iconSep(10,BGCOLOR),
    // AOI
    app.toolBar.centerOnMe,
    app.toolBar.loadLayer,
    gui.iconSep(10,BGCOLOR),
    // index
    app.toolBar.indexExpr,
    gui.iconSep(10,BGCOLOR),
    // composite
    app.toolBar.showDateSlider,
    app.dateSelector.showColHist,
    app.dateSelector.updateColHist,
    app.dateSelector.showCalendar,
    app.dateSelector.configDateSlider,
    gui.iconSep(),
    app.toolBar.clipComposite,
    gui.iconSep(),
    app.toolBar.sceneCentroids,
    app.toolBar.sceneOutline,
    app.toolBar.scenePolygon,    
    gui.iconSep(10,BGCOLOR),
    app.toolBar.showMapTools,
    gui.iconSep(),
    app.toolBar.showLegend,
    app.toolBar.legendsPos,
    gui.iconSep(),
    app.toolBar.showInset,
    app.toolBar.insetPos,
    gui.iconSep(),
    app.toolBar.duplicate,    
    app.toolBar.swap,
    gui.iconSep(),
    gui.iconSep(10,BGCOLOR),
    app.toolBar.showDrawingTools,
    app.toolBar.queryIcon,
    app.toolBar.configQuery,
    gui.iconSep(10,BGCOLOR),
    app.toolBar.layerTools,
    gui.iconSep(10,BGCOLOR),
    app.toolBar.centerArea,
    app.toolBar.centerView,
  ],ui.Panel.Layout.flow('horizontal'));
// Controles de panel de tiempo
app.dateSelector.panel = ui.Panel([ 
  //app.dateSelector.toolBar,
  ui.Label('Updating scenes histogram...',{textAlign: 'center',stretch: 'both',backgroundColor: TRANSPARENT}),
  app.control.composite.dateSlider
  ],ui.Panel.Layout.flow('vertical'),{stretch: 'both',maxHeight: '200px',backgroundColor: '888888'});
app.control.composite.panel.add(app.control.composite.dateRangeLabel);
app.control.composite.panel.add(ui.Panel([
  ui.Label('Composite period:',{backgroundColor: TRANSPARENT}), 
  app.control.composite.selDateLabel,
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE));
app.control.composite.panel.add(ui.Panel([
  ui.Label('Global scenes in period:',{backgroundColor: TRANSPARENT}), 
  app.control.composite.scenesCount,
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE));
app.control.composite.panel.add(app.control.composite.showDateSlider);
app.control.composite.panel.add(app.control.composite.sceneTools);
// Map Appearence Panel
app.control.explore.panel.add(app.control.explore.help);
app.control.explore.panel.add(ui.Panel([
  app.control.explore.showMapTypes,
  app.control.explore.mapType,
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE));
// panel Configure layers
app.control.explore.panel.add(app.control.explore.showLayerList);
app.control.explore.iitem =   ui.Panel([
    app.control.explore.index,
    app.control.explore.indexEdit
    ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.explore.citem = ui.Panel([
    app.control.explore.composite,
    app.control.explore.compositeEdit
    ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.explore.iitem2 = ui.Panel([
    app.control.explore.index2,
    app.control.explore.index2Edit
    ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.explore.citem2 =   ui.Panel([
    app.control.explore.composite2,
    app.control.explore.composite2Edit
    ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.explore.layersOptions = ui.Panel([
  app.control.explore.iitem,
  app.control.explore.citem,
  app.control.explore.iitem2,
  app.control.explore.citem2,
],ui.Panel.Layout.flow('vertical'),{backgroundColor: TRANSPARENT});
app.control.explore.panel.add(app.control.explore.layersOptions);
// panel Show legend
app.control.explore.panel.add(app.control.explore.legends),
// panel Show inset map
app.control.explore.panel.add(app.control.explore.inset);
// panel generate link
app.control.explore.panel.add(ui.Panel([    
    app.control.explore.urlText,
    app.control.explore.genUrl,
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE)
  );
// Advanced Operations Panel
app.control.operator.panel.add(app.control.operator.help);
app.control.operator.rangePanel = ui.Panel([
      ui.Label('Index range: ',ROW_STYLE),
      app.control.operator.rescaleMin,
      ui.Label('-',{backgroundColor: TRANSPARENT}),
      app.control.operator.rescaleMax,
      ui.Label(' ',{backgroundColor: TRANSPARENT}),
      app.control.operator.updateRange,
    ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.operator.panel.add(app.control.operator.rangePanel);
app.control.operator.thresholdPanel = ui.Panel([
  ui.Label('Threshold: ',ROW_STYLE),
  app.control.operator.threshold
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.operator.maskOptions = ui.Panel([
    app.control.operator.thresholdPanel,
    app.control.operator.invertMask,
    app.control.operator.maskArea,
    ui.Panel([
      ui.Label('Vectorize mask',ROW_STYLE),
      app.control.operator.maskOutline,
      app.control.operator.maskPolygon,
      ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE),
    ]);
app.control.operator.panel.add(app.control.operator.mask);
app.control.operator.panel.add(app.control.operator.maskOptions);    
app.control.operator.textureOptions = ui.Panel([
    ui.Panel([
      ui.Label('Spatial operator:',ROW_STYLE),
      app.control.operator.selector,
      ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE),
    app.control.operator.name,
    app.control.operator.descr,
    ui.Panel([
      ui.Label('Kernel size (pixels): ',ROW_STYLE),
      app.control.operator.kernel,
      ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE),
    app.control.operator.rescale,
    ]);
app.control.operator.panel.add(app.control.operator.texture);
app.control.operator.panel.add(app.control.operator.textureOptions);
app.control.operator.panel.add(app.control.operator.compare);
app.control.operator.compareOptions = ui.Panel([
      ui.Label('Binary operator:',ROW_STYLE),
      app.control.operator.comparison
      ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.operator.panel.add(app.control.operator.compareOptions);
// Query configuration panels
app.control.operator.panel.add(app.control.operator.showQueryTool);
// Panel +Download Data
app.control.download.panel.add(app.control.download.help);
app.control.download.panel.add(app.control.download.scalePanel);
app.control.download.panel.add(app.control.download.rowsPanel);
app.control.download.panel.add(app.control.download.colsPanel);
app.control.download.panel.add(app.control.download.framesPanel);
app.control.download.panel.add(ui.Panel([
  app.control.download.index,
  app.control.download.indexRefresh
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE));
app.control.download.panel.add(ui.Panel([
  app.control.download.composite,
  app.control.download.compositeRefresh
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE));
app.control.download.panel.add(ui.Panel([
  app.control.download.samples,
  app.control.download.samplesRefresh
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE));
app.control.download.videoRow = ui.Panel([
  app.control.download.video,
  app.control.download.videoRefresh
  ],ui.Panel.Layout.flow('horizontal'),ROW_STYLE);
app.control.download.panel.add(app.control.download.videoRow);
// about panel
app.control.about.panel.add(app.control.about.help);
app.control.about.panel.add(ui.Panel([
  ui.Label('If you use it in your research, please cite it as:', ROW_STYLE),
  app.control.about.cite
  ],ui.Panel.Layout.flow('vertical'),{backgroundColor: TRANSPARENT}));
app.control.about.panel.add(ui.Label('Here are some examples of its use',ROW_STYLE,app.data.text.examplesUrl));
app.control.about.panel.add(app.control.about.disclaimer);
// tool panel
app.control.panel.add(app.title);
app.control.panel.add(app.author);
app.control.panel.add(app.intro);
app.control.panel.add(app.control.aoi.header);
app.control.panel.add(app.control.aoi.panel);
app.control.panel.add(app.control.index.header);
app.control.panel.add(app.control.index.panel);
app.control.panel.add(app.control.composite.header);
app.control.panel.add(app.control.composite.panel);
app.control.panel.add(app.control.explore.header);
app.control.panel.add(app.control.explore.panel);
app.control.panel.add(app.control.operator.header);
app.control.panel.add(app.control.operator.panel);
app.control.panel.add(app.control.download.header);
app.control.panel.add(app.control.download.panel);
app.control.panel.add(app.control.about.header);
app.control.panel.add(app.control.about.panel);
// dialogs
var DIALOG_TITLE_STYLE = {stretch: 'horizontal',fontWeight: 'bold',textAlign: 'center'};
app.dialog.loadLayer.panel = ui.Panel([
  ui.Label('Load Vector Layer',DIALOG_TITLE_STYLE),
  ui.Panel([
    ui.Label('Asset name:'),
    app.dialog.loadLayer.asset,
    ],ui.Panel.Layout.flow('horizontal')),
  ui.Panel([
    ui.Label('Info property:'),
    app.dialog.loadLayer.property,
    ],ui.Panel.Layout.flow('horizontal')),
  app.dialog.loadLayer.clipping,
  ui.Panel([
    app.dialog.loadLayer.load,
    app.dialog.loadLayer.cancel,
    ],ui.Panel.Layout.flow('horizontal'),{stretch: 'horizontal'}),
]);
app.dialog.timeSlice.cloudCoverPanel = ui.Panel([
      app.dialog.timeSlice.cloudFilter,
      app.dialog.timeSlice.maxCloud
      ],ui.Panel.Layout.flow('horizontal'));
app.dialog.timeSlice.panel = ui.Panel([
  ui.Panel([
     ui.Label('Configure Period Selector',DIALOG_TITLE_STYLE),
     app.dialog.timeSlice.cancel,
     ],ui.Panel.Layout.flow('horizontal')),
  ui.Panel([
    ui.Label('Start date: '), 
    app.dialog.timeSlice.starDate,
  ],ui.Panel.Layout.flow('horizontal')),
  ui.Panel([
    ui.Label('End date: '), 
    app.dialog.timeSlice.endDate,
  ],ui.Panel.Layout.flow('horizontal')),
  ui.Panel([
    ui.Label('Period: '), 
    app.dialog.timeSlice.period,
    app.dialog.timeSlice.periodUnit,
  ],ui.Panel.Layout.flow('horizontal'),{stretch: 'horizontal'}),
  ui.Panel([
    ui.Label('Reducer: '), 
    app.dialog.timeSlice.reducer,
  ],ui.Panel.Layout.flow('horizontal')),
 app.dialog.timeSlice.cloudCoverPanel,
 app.dialog.timeSlice.cloudMask,
  ui.Panel([
    app.dialog.timeSlice.apply, 
    app.dialog.timeSlice.reset,
  ],ui.Panel.Layout.flow('horizontal')),
  ]);
app.dialog.queryOpts.point = ui.Panel([  
  ui.Panel([
    app.dialog.queryOpts.keepMarker,
    app.dialog.queryOpts.deletePoints
    ],ui.Panel.Layout.flow('horizontal')),
  app.dialog.queryOpts.spectrum,
  app.dialog.queryOpts.timeseries,
  app.dialog.queryOpts.ROCplot,
  app.dialog.queryOpts.flowline,
  app.dialog.queryOpts.catchment,
]);
app.dialog.queryOpts.line = ui.Panel([
  ui.Panel([
    app.dialog.queryOpts.keepLine,    
    app.dialog.queryOpts.deleteLines,
    ],ui.Panel.Layout.flow('horizontal')),
    app.dialog.queryOpts.profile,
  ]);
app.dialog.queryOpts.polygon = ui.Panel([
  ui.Panel([
    app.dialog.queryOpts.keepPolygon,
    app.dialog.queryOpts.deletePolygons,
    ],ui.Panel.Layout.flow('horizontal'),{backgroundColor: TRANSPARENT}),
  app.dialog.queryOpts.histogram,
  app.dialog.queryOpts.timeseries2,
  app.dialog.queryOpts.scatterplot,
  ]);
app.dialog.queryOpts.panel = ui.Panel([
  ui.Panel([
    ui.Label('Configure Query Tool',DIALOG_TITLE_STYLE),
    app.dialog.queryOpts.close,
    ],ui.Panel.Layout.flow('horizontal')),
  app.dialog.queryOpts.queryBar,
  app.dialog.queryOpts.point,
  app.dialog.queryOpts.line,
  app.dialog.queryOpts.polygon,
  ]);
// extrae los dialogos incrustados en la legenda
app.dialog.configIndex = app.map.legends.index.remove(app.map.legends.index.config);
app.dialog.configComposite = app.map.legends.composite.remove(app.map.legends.composite.config);
app.dialog.configIndex2 = app.map.legends.index2.remove(app.map.legends.index2.config);
app.dialog.configComposite2 = app.map.legends.composite2.remove(app.map.legends.composite2.config);
// dialogos de mensajes
app.dialog.message = ui.Panel();
app.dialog.inspector = gui.inspector(''); // panel de inspección
// map
app.map.legends.index.config.insert(0,ui.Panel([
  ui.Label('Adjust Visualization Parameters',DIALOG_TITLE_STYLE),
  app.map.legends.index.widgets().get(0).remove(app.map.legends.index.edit)
  ],ui.Panel.Layout.flow('horizontal')));
app.map.legends.composite.config.insert(0,ui.Panel([
  ui.Label('Adjust Visualization Parameters',DIALOG_TITLE_STYLE),
  app.map.legends.composite.widgets().get(0).remove(app.map.legends.composite.edit)
  ],ui.Panel.Layout.flow('horizontal')));
app.map.legends.index2.config.insert(0,ui.Panel([
  ui.Label('Adjust Visualization Parameters',DIALOG_TITLE_STYLE),
  app.map.legends.index2.widgets().get(0).remove(app.map.legends.index2.edit)
  ],ui.Panel.Layout.flow('horizontal')));  
app.map.legends.composite2.config.insert(0,ui.Panel([
  ui.Label('Adjust Visualization Parameters',DIALOG_TITLE_STYLE),
  app.map.legends.composite2.widgets().get(0).remove(app.map.legends.composite2.edit)
  ],ui.Panel.Layout.flow('horizontal')));
app.map.main.add(app.dialog.message);
app.map.main.add(app.dialog.inspector.panel);
app.map.main.add(app.dialog.timeSlice.panel);
app.map.main.add(app.dialog.queryOpts.panel);
app.map.main.add(app.dialog.loadLayer.panel);
app.map.main.add(app.dialog.configIndex);
app.map.main.add(app.dialog.configComposite);
app.map.copy.add(app.dialog.configIndex2);
app.map.copy.add(app.dialog.configComposite2);
app.map.panel = ui.Panel([
  app.map.main,
  app.dateSelector.panel,
  app.toolBar.panel,
  ],ui.Panel.Layout.flow('vertical'),{stretch: 'both'});
ui.root.clear();
ui.root.widgets().add(ui.Panel([
  app.control.panel,
  app.map.panel,
  ],ui.Panel.Layout.flow('horizontal'),{stretch: 'both'}));
/******************************************
 * Estilos 
********************************************/
var HEADER_STYLE = {
  backgroundColor: FGCOLOR,
  color: BGCOLOR,
  border: '1px solid gray',
  fontWeight: 'bold',
  fontSize: '13px',
  height: '31px',
  //padding: '0px 200px 0px 0px',
};
var PANEL_STYLE = {
    stretch: 'horizontal', 
    border: '2px solid gray',
    backgroundColor: BGCOLOR,
    margin: '0px 2px 4px 2px',
    padding: '0px 6px 6px 10px',
    textAlign: 'left',
};
var ICON_STYLE = {
    backgroundColor: 'cccccc',
    color: '000000',
};
var ITEM_STYLE = {
  fontSize: '11px',
  fontWeight:'bold',
  margin: '0px',
  padding: '8px 0px',
  stretch:'both',
  backgroundColor: TRANSPARENT
};
var WIDGET_STYLE = {
    stretch: 'horizontal',     
    backgroundColor: 'cccccc',
    color: '000000',
    height: '29px',
    margin: '0px',
    padding: '0px',
};
var CENTERED_TITLE_STYLE = {
  fontSize: '16px',
  fontWeight: 'bold',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '4px',
  backgroundColor: BGCOLOR,
};
var LEGEND_TITLE_STYLE = {
  fontSize: '12px',
  fontWeight: 'bold',
  backgroundColor: BGCOLOR,
//  stretch: 'both',
//  padding: '16px',
};
var TOGGLE_BUTTON_STYLE = {
  textAlign: 'left',
  padding: '0px',
  margin: '0px',
  fontWeight: 'bold',
  backgroundColor: BGCOLOR,
};
var INFO_STYLE = {
    backgroundColor: TRANSPARENT,
    color: '8888aa',
    //margin: '0px -32px 0px 0px',
    stretch: 'horizontal',
    whiteSpace: 'break-spaces',
};
var TOOLBAR_STYLE = {
  maxHeight: '46px',
  margin: 0,
  padding: 0,
  backgroundColor: BGCOLOR,
  shown: true
};
var WIDGET_INDENT = {
  padding: '0px 0px 0px 30px',
  backgroundColor: TRANSPARENT,
  stretch: 'vertical',
};
var BORDER_STYLE = {
  border: '1px solid darkgray'
};
var DATE_SLIDER_STYLE = {
  stretch: 'horizontal',
  margin: '0px',
  padding: '0px',
  height: '55px',
  backgroundColor: '888888',
  color: BGCOLOR,
};
var NDII_VISPARAMS = {
  min: -1,
  max: 1,
  palette: images.Palettes.bluered
};
var DOWNLOAD_AREA_ID = 'Download_Area';
var DIALOG_STYLE = {shown: false, width: '300px'};
app.title.style().set({
    fontSize: '24px', 
    color: 'darkgray',
    textAlign: 'center',
    stretch: 'horizontal',
    backgroundColor: BGCOLOR,
  });
app.author = app.author.setUrl('https://www.centrogeo.org.mx/areas-profile/jsilvan/');
app.author.style().set(INFO_STYLE).set({fontWeight: 'bold'});
app.intro.style().set({
  fontSize: '12px', 
  stretch: 'horizontal',
  backgroundColor: BGCOLOR,
  });
//AOI
//makeTransparent(app.control.aoi);
app.control.aoi.header.style().set(HEADER_STYLE);
app.control.aoi.panel.style().set(PANEL_STYLE).set({shown: false});
app.control.aoi.help.style().set(INFO_STYLE);
app.control.aoi.layerHelp.style().set(INFO_STYLE);
// index
//makeTransparent(app.control.index);
app.control.index.header.style().set(HEADER_STYLE);
app.control.index.panel.style().set(PANEL_STYLE).set({shown: false});
app.control.index.help.style().set(INFO_STYLE);
app.control.index.name.style().set(INFO_STYLE).set('maxWidth','340px');
app.control.index.descr.style().set(INFO_STYLE);
app.control.index.filterTags.style().set(WIDGET_STYLE);
app.control.index.selector.style().set(WIDGET_STYLE);
app.control.index.search.style().set(WIDGET_STYLE);
//app.control.index.searchPanel.style().set('shown',false);
// composite
//makeTransparent(app.control.composite);
app.control.composite.panel.style().set(PANEL_STYLE).set({shown: false});
app.control.composite.header.style().set(HEADER_STYLE);
app.control.composite.help.style().set(INFO_STYLE);
app.control.composite.scenesCount.style().set(ROW_STYLE);
app.control.composite.collCount.style().set(ROW_STYLE);
app.control.composite.collection.style().set(INFO_STYLE).set({fontWeight: 'bold', textAlign: 'center'});
app.control.composite.collections.style().set(WIDGET_STYLE);
app.control.composite.dateRangeLabel.style().set(INFO_STYLE).set({fontWeight: 'bold', textAlign: 'center'});
app.control.composite.selDateLabel.style().set(ROW_STYLE);
app.control.composite.showDateSlider.style().set(ROW_STYLE);
app.control.composite.sceneTools.style().set(ROW_STYLE);
app.control.composite.dateSlider.style().set(DATE_SLIDER_STYLE).set('shown',false);
// explore - estilos
//makeTransparent(app.control.explore);
app.control.explore.panel.style().set(PANEL_STYLE).set({shown: false});
app.control.explore.header.style().set(HEADER_STYLE);
app.control.explore.help.style().set(INFO_STYLE);
app.control.explore.showMapTypes.style().set(ROW_STYLE);
app.control.explore.mapType.style().set(WIDGET_STYLE);
app.control.explore.showLayerList.style().set(ROW_STYLE);
app.control.explore.index.style().set(ITEM_STYLE);
app.control.explore.composite.style().set(ITEM_STYLE);
app.control.explore.index2.style().set(ITEM_STYLE);
app.control.explore.composite2.style().set(ITEM_STYLE);
app.control.explore.iitem.style().set(ROW_STYLE);
app.control.explore.citem.style().set(ROW_STYLE);
app.control.explore.iitem2.style().set(ROW_STYLE).set('shown',false);
app.control.explore.citem2.style().set(ROW_STYLE).set('shown',false);
app.control.explore.index2Edit.style().set({shown: false});
app.control.explore.composite2Edit.style().set({shown: false});
app.control.explore.layersOptions.style().set(WIDGET_INDENT).set({shown: true});
app.control.explore.inset.style().set(ROW_STYLE);
app.control.explore.legends.style().set(ROW_STYLE);
app.control.explore.urlText.style().set(INFO_STYLE).set({stretch: 'horizontal'});
//operator
//makeTransparent(app.control.operator);
app.control.operator.header.style().set(HEADER_STYLE);
app.control.operator.panel.style().set(PANEL_STYLE).set({shown: false});
app.control.operator.help.style().set(INFO_STYLE);
app.control.operator.rescale.style().set(ROW_STYLE);
app.control.operator.rescaleMin.style().set(WIDGET_STYLE);
app.control.operator.rescaleMax.style().set(WIDGET_STYLE);
app.control.operator.updateRange.style().set(WIDGET_STYLE);
app.control.operator.mask.style().set(ROW_STYLE);
app.control.operator.invertMask.style().set(ROW_STYLE);
app.control.operator.threshold.style().set(ROW_STYLE);
app.control.operator.maskOptions.style().set(WIDGET_INDENT);
app.control.operator.maskPolygon.style().set(WIDGET_STYLE);
app.control.operator.maskOutline.style().set(WIDGET_STYLE);
app.control.operator.maskArea.style().set(INFO_STYLE);
app.control.operator.texture.style().set(ROW_STYLE);
app.control.operator.name.style().set(INFO_STYLE);
app.control.operator.descr.style().set(INFO_STYLE);
app.control.operator.selector.style().set(WIDGET_STYLE);
app.control.operator.kernel.style().set(ROW_STYLE);
app.control.operator.textureOptions.style().set(WIDGET_INDENT);
app.control.operator.compare.style().set(ROW_STYLE);
app.control.operator.comparison.style().set(WIDGET_STYLE);
app.control.operator.compareOptions.style().set(WIDGET_INDENT);
app.control.operator.showQueryTool.style().set(ROW_STYLE);
// download
app.control.download.header.style().set(HEADER_STYLE);
app.control.download.panel.style().set(PANEL_STYLE).set({shown: false});
app.control.download.help.style().set(INFO_STYLE);
app.control.download.scale.style().set(ROW_STYLE);
app.control.download.rows.style().set(ROW_STYLE);
app.control.download.cols.style().set(ROW_STYLE);
app.control.download.frames.style().set(ROW_STYLE);
app.control.download.index.style().set(ROW_STYLE);
app.control.download.indexRefresh.style().set(WIDGET_STYLE);
app.control.download.composite.style().set(ROW_STYLE);
app.control.download.compositeRefresh.style().set(WIDGET_STYLE);
app.control.download.samples.style().set(ROW_STYLE);
app.control.download.samplesRefresh.style().set(WIDGET_STYLE);
app.control.download.video.style().set(ROW_STYLE);
app.control.download.videoRefresh.style().set(WIDGET_STYLE);
// about
app.control.about.header.style().set(HEADER_STYLE);
app.control.about.panel.style().set(PANEL_STYLE).set({shown: true});
app.control.about.help.style().set(INFO_STYLE);
app.control.about.cite.style().set({
  fontSize: '12px', 
  stretch: 'horizontal',
  backgroundColor: BGCOLOR,
  margin: '12px',
  });
app.control.about.disclaimer.style().set(INFO_STYLE).set('fontStyle','italic');
app.control.panel.style().set({
  width: app.data.panelWidth + 'px', 
  margin: '0px', 
  backgroundColor: BGCOLOR,
  color: 'white',
  stretch: 'vertical',
  });
app.map.legends.panel.style().set({width: '220px', margin: '4px',padding: '0px',backgroundColor: FGCOLOR,color: BGCOLOR});
app.map.legends.index.config.title.style().set({fontSize: '14px'});
app.map.legends.composite.config.title.style().set({fontSize: '14px'});
app.map.legends.index2.config.title.style().set({fontSize: '14px'});
app.map.legends.composite2.config.title.style().set({fontSize: '14px'});
app.map.legends.index.config.style().set(BORDER_STYLE).set({position: 'top-center'});
app.map.legends.index2.config.style().set(BORDER_STYLE).set({position: 'top-center'});
app.map.legends.composite.config.style().set(BORDER_STYLE).set({position: 'top-center'});
app.map.legends.composite2.config.style().set(BORDER_STYLE).set({position: 'top-center'});
app.map.legends.index2.style().set({shown: false});
app.map.legends.composite2.style().set({shown: false});
app.dialog.timeSlice.panel.style().set(DIALOG_STYLE).set({shown: false});
app.dialog.timeSlice.period.style().set({stretch: 'horizontal'});
app.dialog.timeSlice.starDate.style().set({stretch: 'horizontal'});
app.dialog.timeSlice.endDate.style().set({stretch: 'horizontal'});
app.dialog.timeSlice.reducer.style().set({stretch: 'horizontal'});
app.dialog.timeSlice.maxCloud.style().set({stretch: 'horizontal'});
app.dialog.timeSlice.apply.style().set({stretch: 'horizontal'});
app.dialog.timeSlice.reset.style().set({stretch: 'horizontal'});
app.dialog.timeSlice.cancel.style().set({stretch: 'horizontal'});
app.dialog.loadLayer.panel.style().set(DIALOG_STYLE).set({shown: false});
app.dialog.loadLayer.asset.style().set({stretch: 'horizontal'});
app.dialog.loadLayer.property.style().set({stretch: 'horizontal'});
app.dialog.loadLayer.clipping.style().set({stretch: 'horizontal'});
app.dialog.loadLayer.load.style().set({stretch: 'horizontal'});
app.dialog.loadLayer.cancel.style().set({stretch: 'horizontal'});
app.toolBar.clipComposite.setDisabled(true);
app.dialog.queryOpts.point.style().set(BORDER_STYLE); //.set({shown: true});
app.dialog.queryOpts.polygon.style().set(BORDER_STYLE).set({shown: false});
app.dialog.queryOpts.line.style().set(BORDER_STYLE).set({shown: false});
app.dialog.queryOpts.keepMarker.style().set({stretch: 'horizontal'});
app.dialog.queryOpts.keepLine.style().set({stretch: 'horizontal'});
app.dialog.queryOpts.profile.style().set({stretch: 'horizontal'});
app.dialog.queryOpts.keepPolygon.style().set({stretch: 'horizontal'});
app.dialog.queryOpts.panel.style().set(DIALOG_STYLE);
app.dialog.inspector.info.style({whiteSpace: 'break-spaces'});
app.dialog.message.style().set({
  shown: false, 
  stretch: 'horizontal',
  position: 'bottom-center'
});
app.dateSelector.showCalendar.setDisabled(true);
app.dateSelector.showColHist.setDisabled(true);
app.dateSelector.updateColHist.setDisabled(true);
app.dateSelector.configDateSlider.setDisabled(true);
app.dateSelector.updateColHist.setDisabled(true);
app.toolBar.panel.style().set(TOOLBAR_STYLE);
app.toolBar.layerTools.style().set(TOOLBAR_STYLE).set({shown: false, stretch: 'horizontal'});
app.toolBar.sceneCentroids.setDisabled(true);
app.toolBar.sceneOutline.setDisabled(true);
app.toolBar.scenePolygon.setDisabled(true);
app.toolBar.legendsPos.setDisabled(true);
app.toolBar.insetPos.setDisabled(true);
app.toolBar.showLegend.setDisabled(true);
app.toolBar.showInset.setDisabled(true);
app.toolBar.swap.setDisabled(true);
app.toolBar.centerArea.style().set({shown: false});
app.toolBar.centerView.style().set({shown: false});
app.map.main.setControlVisibility(true);
app.map.copy.setControlVisibility(true);
app.map.inset.setControlVisibility(false);
// liga los trazos para dos paneles
//app.drawingTools.setLinked(true)
//app.map.copy.drawingTools().setLinked(true);
/******************************************
 * Eventos 
********************************************/
var configGeomLayer = function(layer,dt){
  if(layer === null)
    return;
  if(layer.getName() === DOWNLOAD_AREA_ID)
    return;
  var bounds = layer.toGeometry()
    .bounds();
  bounds.getInfo(function(b){
    if(b)
      app.map.main.centerObject(b);
    })
  dt.getSelected().openConfigurationDialog();
};
app.toolBar.configLayer.onClick(function(widget){
  configGeomLayer(app.drawingTools.getSelected(),app.drawingTools);
  });
app.toolBar.bufferLayer.onClick(function(widget){
  var selected = app.drawingTools.getSelected();
  if(selected === null)
     return;
  var width = 100; // ancho del buffer por default
  var layerName = selected.getName();
  // checa si el nombre especifica un ancho
  var last_word = layerName.match(/[^\s]+$/g);
  if (last_word !== null) {
    var n = last_word[0].match(/^[-+]?([0-9]+(\.[0-9]*)?|\.[0-9]+)|(m|km)$/g);
    if (n !== null)
      width = n[0] * (1+(n[1] == 'km')*999);
  }
  var buffName = layerName + '-buffer';
  var buffered = ee.Geometry(selected.toGeometry())
    .buffer(width)
    .evaluate(function(geom){
      app.drawingTools.addLayer({
        geometries: [geom],
        name: buffName,
    });
  });
});
// Funcion que muestrea una línea
app.toolBar.sampleLine.onClick(function(widget){
  var selected = app.drawingTools.getSelected();
  if(selected === null)
    return;
  var numSamp = 10; // numbero de muestras
  var layerName = selected.getName();
  // checa si el nombre especifica numero de muestras
  var last_word = layerName.match(/[^\s]+$/g);
  if (last_word !== null) {
    var n = last_word[0].match(/^[0-9]+$/g);
    if (n !== null){
      numSamp = (Number(n[0]) > 1) ? Number(n[0]): numSamp;
    }  
  }
  var sampName = layerName + '-samples';
  var geom = selected.toGeometry();
  var length = geom.length(1);
  var dist_inc = length.divide(numSamp-1);
  var cuts = ee.List.sequence(0,length,dist_inc);
  // Construye geometría multipunto
  var segms = ee.List(geom
    .cutLines(cuts) // corta en segmentos
    .coordinates()); 
  var points = segms.map(function(segm){return ee.List(segm).get(1)}); // vertice final de segmento
  var samples = ee.Geometry.MultiPoint(
    points.insert(0,ee.List(segms.get(0)).get(0))
    ); // inserte el vertice inicial del primer segmento
  // agrega la geometría aal mapa
  samples.evaluate(function(points,error){
      if(points === null)
        return; // algo falló
      app.drawingTools.addLayer({
        geometries: [points],
        name: sampName,
    });
  });
});
// Funcion que muestrea una línea
app.toolBar.sampleArea.onClick(function(widget){
  var selected = app.drawingTools.getSelected();
  if(selected === null)
     return;
  var numSamp = 30; // numero de muestras
  var layerName = selected.getName();
  // checa si el nombre especifica numero de muestras
  var last_word = layerName.match(/[^\s]+$/g);
  if (last_word !== null) {
    var n = last_word[0].match(/^[0-9]+$/g);
    if (n !== null){
      numSamp = (Number(n[0]) > 1) ? Number(n[0]): numSamp;
    }  
  }
  var sampName = layerName + '-samples';
  var geom = selected.toGeometry();
  ee.FeatureCollection.randomPoints(geom.simplify(1), numSamp)
    .geometry()
    .aside(print)
    .evaluate(function(points,error){
      print(points)
      if(!points)
        return; // algo falló
      app.drawingTools.addLayer({
        geometries: [points],
        name: sampName,
    });
  });
});
// define geometría de recorte y aplica recorte
app.toolBar.setClipping.onClick(function(widget){
  var selected = app.drawingTools.getSelected();
  print(selected)
  if(selected === null) {
    app.toolBar.layerTools.style().set({shown: false});
    return;
  }
  app.toolBar.clipComposite.setState(0); // deshabilita si está habilitado
  app.data.layer.composite.clipGeometry = selected.toGeometry();    
  app.toolBar.clipComposite.setDisabled(false);
  app.toolBar.clipComposite.setState(1); //  habilita para aplicar nuevo
});
app.drawingTools.onLayerSel(function(layer,dt){
  var stopped = dt.state === 'Stopped';
  app.toolBar.layerTools.style().set({shown: !stopped});
  if(stopped)
    return;
  // oculta botones dependiendo del tipo de geometría
  layer.toGeometry().type().getInfo(function(type){
    app.toolBar.sampleLine.style().set({shown: type === 'Line'});
    app.toolBar.sampleArea.style().set({shown: type === 'Polygon' || type === 'MultiPolygon'});
    app.toolBar.setClipping.style().set({shown: type === 'Polygon' || type === 'MultiPolygon'});
    app.toolBar.configLayer.style().set({shown: layer !== null});
  });
  });
app.drawingTools.onDrawStop(function(layer,dt){
  app.toolBar.layerTools.style().set({shown: false});
  });
// detiene las consultas al cerrar el inspector
app.dialog.inspector.onClose(function(){
  app.toolBar.queryIcon.setState(0);
  });
var showGeomInfo = function(geom,layer,dt) {
  //print('Querying geometry...');
  var names = app.data.selectable
    .map(function(elem){return elem.asset;});
  if(names.indexOf(layer.getName()) < 0)
    return;
  var infoField = app.dialog.loadLayer.property.getValue();
  var point = ee.Feature(
    ee.FeatureCollection(layer.getName())
      .filter(ee.Filter.withinDistance(1e-6,'.geo',geom))
      .first());
  var info = point.get(infoField);
  app.dialog.inspector.charts.clear();
  app.dialog.inspector.info.setValue('Retrieving value...');
  info.getInfo(function(info_str) {
    app.dialog.inspector.info.setValue(info_str);
  });
  app.dialog.inspector.panel.style().set({shown: true});
};
app.drawingTools.onSelect(showGeomInfo);
// Función para generar un nombre valido de geometrías
var validGeomName = function(string){
  var strings = string.split('/'); 
  return strings[strings.length-1] // ultimo nombre 
    .replace(/[^a-z0-9]/gi, ''); // elimina caracteres no alfanumericos
};
// carga una capa especificada
var loadLayer = function() {
  app.toolBar.queryIcon.setState(0); // deshabilita consultas
  var assetName = app.dialog.loadLayer.asset.getValue();
  if(assetName.length === 0)
    return;
  var fc = iofun.featureCollectionFromKML(assetName);  
  if(fc === null) {
    fc = ee.FeatureCollection(assetName);
    if(!fc)
      return;
  } else
    assetName = 'KML';
  fc.geometry().geometries()
    .evaluate(function(geom){
    app.drawingTools.addLayer({
      geometries: geom,
      name: assetName,
      //name: validGeomName(assetName),
      //locked: true,
    });
  });
  var clip = app.dialog.loadLayer.clipping.getValue();  
  if(clip) {
    app.data.layer.composite.clipGeometry = fc;    
    app.toolBar.clipComposite.setDisabled(false);
  } else
    app.data.layer.composite.clipGeometry = null;
  ui.url.set('layer',true);  
  ui.url.set('asset',assetName);  
  ui.url.set('clip',clip);
  // asigna el campo de consulta
  var propName = app.dialog.loadLayer.property.getValue();
  if(propName) 
    if(propName.length) {
      app.data.selectable[app.data.selectable.length] = {
        asset: assetName, 
        property: propName
      };
      ui.url.set('property',propName);
    }
  app.map.main.centerObject(fc);
  resetUrl();
};
// Crea lista indice-tags
var getIndexList = function(tag){
  var keys;
  if (tag === "Current Sensor") {
    // Busca indices compatibles con el sensor
    var sensorID =  app.control.composite.collections.getValue();
    var bands = images.SensorsList[sensorID].mappedBandNames;
    keys = app.data.indexList
      .map(function(key){
        var indexBands = images.SIexpresion(key) //images.SI[key].expression
        .match(/'([^']*)'/g); 
        return [key,indexBands];
      }).filter(function(key){
        // filtra por bandas
        return key[1].every(function(band){          
          return bands.indexOf(band.slice(1,-1)) >= 0; // quita comoillas
      });
    });
  } else {
    // Busca indices que continenen el tag
    keys = app.data.indexList
    .map(function(key){
      return [key, images.SI[key].tags];
    }).filter(function(key){
      // filtra por tags
      return key[1].indexOf(tag) >= 0; //key[1].includes(tag);
  });
 }
  return keys.map(function(key){
    return images.SI[key[0]].name;
  }).sort();
};
var getIndexAcronym = function(name){
  return app.data.indexList[app.data.indexNameList.indexOf(name)];
};
var getTextureAcronym = function(name){
  return app.data.textureList[app.data.textureNameList.indexOf(name)];
};
// Genera lista de sensores para un índice dado
var getSensors = function(index) {  
  if(index === 'Count')
   return keys;
// extrae los nombres de las bandas en la expresion (incluye comillas)
  var indexBands = images.SIexpression(index)
    .match(/'([^']*)'/g); 
  // Crea lista doble sensor-bandas
  var bands = app.data.sensorsList.map(function(key){
    return [key,images.SensorsList[key].mappedBandNames];
  })
  // filtra sensores que incluyen todas las bandas requeridas
  .filter(function(elem){
    return indexBands.every(function(band){
      return elem[1].indexOf(band.slice(1,-1)) >= 0; // quita comoillas
    });
  });
  // returna lista de sensores
  return bands.map(function(sensor){
    return sensor[0];
  }).sort();
};
// control panel
app.toolBar.showLegend.onChange(function(state,widget) {
  var shown = state === 1;
  app.map.legends.panel.style().set('shown',shown);
  app.toolBar.legendsPos.setDisabled(!shown);
});
app.toolBar.showControlPanel.onChange(function(state,widget) {
  app.control.panel.style().set({shown: state == 1});
  ui.url.set('tools',state === 1);
  resetUrl();
  var daterange = app.control.composite.dateSlider.getValue();
});
// aoi
// Carga una capa vectorial desde la cuenta del usuario
app.dialog.loadLayer.load.onClick(function(widget){
  app.dialog.loadLayer.panel.style().set({shown: false});
  app.toolBar.panel.style().set({shown: true});
  loadLayer();
  });
app.dialog.loadLayer.cancel.onClick(function(widget){
  app.dialog.loadLayer.panel.style().set({shown: false});
  app.toolBar.panel.style().set({shown: true});
});
app.toolBar.centerOnMe.onClick(
  function(widget) {
    ui.util.getCurrentPosition(
      function(loc){
        app.map.main.centerObject(loc);
      }, 
      function(msg){
        app.map.main.setCenter(app.data.option.lon,app.data.option.lat,app.data.option.zoom);
      }
    );
  });
app.toolBar.loadLayer.onClick(
  function(widget){
    app.dialog.loadLayer.panel.style().set({shown: true});
    app.toolBar.panel.style().set({shown: false}); 
  });
// remove la geometría de recorte
app.toolBar.clipComposite.onChange(
  function(state,widget){
    updateLayers();
  });  
// index
var updateIndexList = function(newList){
  var newVal;
  var curVal = app.control.index.selector.getValue(); //ui.url.get('index');//
  // Determina el nuevo valor con los siguientes criterios:
  // 1. valor actual si no es nulo
  // 2. valor por defecto
  // 3. primer valor de la lista
  if(!curVal)
    newVal = images.SI[app.data.option.index].name;
  else
    newVal = curVal; //images.SI[curVal].name;  
  if(newList.indexOf(newVal) < 0) 
    newVal = newList[0];
  app.control.index.selector.setValue(null,false);
  app.control.index.selector.items().reset(newList); 
  if(newList.length > 0)
    app.control.index.selector.setValue(newVal,newVal !== curVal); // actualiza selección
 /* else {
    app.control.index.name.setValue('No index');
    app.control.index.descr.setValue('');
    app.control.index.name.setImageUrl('');
  }*/
};
app.control.index.filterTags.onChange(
  function(tag){
  print(eTime() + ': selecting index...');
  /*if(tag === "Search Terms"){
    app.control.index.searchPanel.style().set('shown',true);
    return;
  } else
    app.control.index.searchPanel.style().set('shown',false);  
  */
  var newList = getIndexList(tag);
  updateIndexList(newList);
});
// busca indices que continenen el termino en su info
app.control.index.search.onChange(
  function(pattern){
    print(pattern)
    if(pattern === "") {
      app.control.index.filterTags.setValue('All'); 
      return;
    }
    var indexList = app.data.indexInfo.map(
      function(text){
        var re = "\\b" + pattern + "\\b"; // "\\b"  + pattern.slice(0,pattern.length/2)+"\\w*\\b";
        var matches = text.match(new RegExp(re,'i'));
        var count = (matches !== null)? matches.length: 0;
        var key = text.match(/^\b\w+\b/);
        return [key[0], count];
      }).filter(function(item){
        return item[1] > 0;
      }).map(function(item){
        return images.SI[item[0]].name;
      }); 
    updateIndexList(indexList);
  });
// Abre dialogo para configurar el indice actual (solo indices configurables)
app.toolBar.indexExpr.onClick(function(widget){
  app.toolBar.indexExpr.setDisabled(true);
  var index = getIndexAcronym(app.control.index.selector.getValue());
  var SIexpression = images.SIexpression(index);
  var texture = app.control.operator.texture.getValue();
  var compare = app.control.operator.compare.getValue();
  var expr = texture ? getTextureAcronym(app.control.operator.selector.getValue()) +'(' + SIexpression + ')': SIexpression;
  var conf = {
    ok: 'Refresh',
    cancel: 'Close',
    title: index + ' = ' + expr,
  };
  var onClose = function(result,handle){  
    app.toolBar.indexExpr.setDisabled(false);
    if(result !== null) {
      images.SI[index].parameters = result;
      updateIndex(index,texture,compare);
      updateIndexLayer(0);
    } else
      app.map.main.widgets().remove(handle);
  };
  var dialog = gui.getVals(conf,onClose,images.SI[index].parameters);
  app.map.main.add(dialog);
  });
// covierte numero de dias a unidades enteras
var getPeriod = function(days){
  var period = {val: days, unit: 'day'};
  if(days >= app.data.periodFactors.year) {
    period.unit = 'year',
    period.val = days/app.data.periodFactors.year;
  } else {
    if(days >= app.data.periodFactors.month) {
      period.unit = 'month',
      period.val = days/app.data.periodFactors.month;    
    } else {
      if(days >= app.data.periodFactors.day) {
        period.unit = 'day',
        period.val = days;    
      } else {
        if(days >= app.data.periodFactors.hour) {
          period.unit = 'hour',
          period.val = days/app.data.periodFactors.hour;    
        } else {
          if(days >= app.data.periodFactors.minute) {
            period.unit = 'minute',
            period.val = days/app.data.periodFactors.minute;    
          }           
        }  
      }
    }
  }
  return period;  
};
// actualiza la colección
function updateSensor(indexName){
  var period;
  var index = getIndexAcronym(indexName);
  print(eTime() + ': selecting collection...');
  if(app.data.option.ivisParams) {
    app.data.layer.index.visParams = app.data.option.ivisParams;
    app.data.option.ivisParams = null;
  } else {
    app.data.layer.index.visParams = images.SI[index].visParams; // define vis params
    app.data.layer.index.visParams.bands = [0]; // se asegura que la banda esta definida
  }
  //app.control.operator.rescaleMin.setValue(app.data.layer.index.visParams.min);
  //app.control.operator.rescaleMax.setValue(app.data.layer.index.visParams.max);
  var newVal;
  var curVal = app.control.composite.collections.getValue();
  // actualiza información del índice
  app.control.index.name.setValue(images.SI[index].name + ' (' +index+')');
  app.control.index.descr.setValue(images.SI[index].notes + '\n See: \n' + images.SI[index].reference);
  //app.control.index.name.setImageUrl(images.SI[index].imageUrl);
  // borra colección seleccionada para forzar llaamada de evento de cambio
  app.control.composite.collections.setValue(null,false);
  // actualiza el listado de sensores
  var newList = getSensors(index);
  app.control.composite.collections.items().reset(newList); 
  app.control.composite.collCount.setValue(newList.length);
  if (newList.length === 0) {
    // en caso de que un índice no tenga colecciones
    app.dialog.message.style().set({shown: true});
    app.dialog.message.widgets().reset([
        ui.Label('No available collections for selected Index!')
        ]);
          // desabilita las secciones
    //app.control.operator.setDisabled(true);
    //app.control.explore.setDisabled(true);
    //app.control.download.setDisabled(true);
    return;
  }
  // oculta el mensaje de mapa de alguna llamada previa
  app.dialog.message.style().set({shown: false});
  // determina el nuevo valor en el siguiente orden:
  // 1- valor por default
  // 2- selección previa
  // 3. primero de la lista
  if(app.data.option.collection) {
    newVal = app.data.option.collection; 
    app.data.option.collection = null;
  } else
    newVal = curVal;
  // si la selección no está en la lista
  if (newList.indexOf(newVal) < 0) 
    newVal = newList[0]; // selecciona la primera opción
  if(newVal === curVal) { 
    // solo actualiza las capas, no los controles
    app.control.composite.collections.setValue(newVal,false);
    updateLayers(); 
  } else 
    app.control.composite.collections.setValue(newVal); // dispara actualizaciones de controles del time slice
}
// Genera la geometria de escenas individuales
var addSceneGeoms = function(type){
  var bounds = ee.Geometry.Rectangle(app.map.bounds);
  var geoms;
  if(type === 'polygon' ) {
    geoms = app.data.layer.composite.collection
      .filterBounds(bounds)
      .limit(app.data.maxFootprints)
      .geometry(1);
  }
  if(type === 'outline') {
      geoms = ee.FeatureCollection(app.data.layer.composite.collection
      .filterBounds(bounds)
      .limit(app.data.maxFootprints)
      .map(function(f){
          return ee.Feature(ee.Geometry.LinearRing(f.geometry(1).coordinates().get(0)));
        }))
      .geometry(1);
    }
    if(type === "centroid") {
      geoms = ee.FeatureCollection(app.data.layer.composite.collection
        .filterBounds(bounds)
        .limit(app.data.maxFootprints)
        .map(function(f){
          return ee.Feature(f.geometry(1).centroid());
        }))
        .geometry(1);
    }
    geoms.evaluate(function(geometries) {
      var layerName = app.data.layer.composite.name + ' Scenes ' + type;
      if(geometries === undefined)
        return;
      app.drawingTools.addLayer({
        geometries: [geometries],
        name: layerName,
      });
    });
  };
app.control.composite.sceneTools.onChange(
  function(value,widget){
    app.toolBar.sceneCentroids.setDisabled(!value);
    app.toolBar.sceneOutline.setDisabled(!value);
    app.toolBar.scenePolygon.setDisabled(!value);
  });
app.toolBar.sceneCentroids.onClick(
  function(icon){
    addSceneGeoms('centroid');
    });
app.toolBar.sceneOutline.onClick(
  function(icon){
    addSceneGeoms('outline');
    });
app.toolBar.scenePolygon.onClick(
  function(icon){
    addSceneGeoms('polygon');
    });
// actualiza el sensor seleccionado
app.control.index.selector.onChange(updateSensor);
// actualiza el índice
var updateIndex = function(index,texture,compare){
  var min, max;
  // actualiza la capa de indice
  print(eTime() + ': updating index...');
  //app.toolBar.indexExpr.style().set({shown: images.SI[index].parameters !== undefined});
  app.data.layer.index.image = app.data.layer.composite.image
      .expression(images.SIexpression(index),images.SI[index].parameters)
      .rename(index);
  /*app.data.text.indexGEE = 'var ' + index + ' = composite\n' + 
    '\t.expression(' + images.SI[index].expression + ')\n' + 
    '\t.rename(' + index + ')\n;';
    */
  app.data.layer.index.scale = app.data.layer.index.image.projection().nominalScale();
  var scale = app.map.scale.max(app.data.layer.index.scale);
  app.data.layer.index.name = images.SI[index].name;
  // aplica filtro de textura
  if(texture){
    print(eTime() + ': computing spatial operator...');
    var selection = getTextureAcronym(app.control.operator.selector.getValue());
    var band = images.SF[selection].band;
    var radius = (app.control.operator.kernel.getValue()-1)/2;
    index = index + '_' + selection;
    if(app.control.operator.rescale.getValue()){
      min = app.control.operator.rescaleMin.getValue()*1;
      max = app.control.operator.rescaleMax.getValue()*1;      
    } else {
      min = 0.0;
      max = 255.0;
    }
    var img = app.data.layer.index.image;
    app.data.layer.index.name = app.data.layer.index.name + ' ' + selection;
    app.data.layer.index.image = images.SF[selection]
        .feature(img,{min: min,max: max},radius,band,{scale: app.map.scale, bounds: app.map.bounds})
        .rename(index);
        //.setDefaultProjection('EPSG:3857',null,scale); // WGS 84 / Pseudo-Mercator -- Spherical Mercator
        //.reproject('EPSG:3857',null,scale);
  }
  // aplica normalización
  if(compare) {
    print(eTime() + ': comaparing two indices...');
    var comparison = app.control.operator.comparison.getValue();
    var right = app.map.split
        .getSecondPanel()
        .layers()
        .get(1)
        .getEeObject();
    app.data.layer.index.name = images.Comparisons[comparison].shortName + 
      " of " + app.data.layer.index.name;
    index = images.Comparisons[comparison].shortName + '_' + index;
    min = app.control.operator.rescaleMin.getValue()*1;
    max = app.control.operator.rescaleMax.getValue()*1;      
    app.data.layer.index.image = images.Comparisons[comparison]
      .compare(app.data.layer.index.image,right,min,max)
      .rename(index);
  }
  // actualiza opciones de visualización
  app.data.layer.index.visParams.bands = [index];
  app.control.explore.index.setLabel(app.data.layer.index.name);
  app.map.legends.index.config.title.setValue(app.data.layer.index.name);
};
// actualiza el compuesto
var updateComposite = function(sensorID,dateRange){
  // actualiza la capa del compuesto
  print(eTime() + ': updating composite...');
  app.data.layer.composite.start = dateRange.start().format('dd/MMM/yyyy').getInfo();
  app.data.layer.composite.end = dateRange.end().format('dd/MMM/yyyy').getInfo();
  app.data.layer.composite.name = sensorID + ' ' +
     app.data.layer.composite.start.replace(/\//gi,'') + ' to '+
     app.data.layer.composite.end.replace(/\//gi,'');
  var reducer = app.data.colReducers[app.dialog.timeSlice.reducer.getValue()];
  var cloudMask = app.dialog.timeSlice.cloudMask.getValue();
  if(app.dialog.timeSlice.cloudFilter.getValue()){
    app.dialog.timeSlice.maxCloud.setDisabled(false);
    app.data.layer.composite.maxCloud = app.dialog.timeSlice.maxCloud.getValue();
  } else {
    app.dialog.timeSlice.maxCloud.setDisabled(true);
    app.data.layer.composite.maxCloud = 100;
  }
  // Extre colección y crea compuesto
  app.data.layer.composite.collection = images.collection(sensorID,dateRange,app.data.layer.composite.maxCloud);
  app.data.layer.composite.image = app.data.layer.composite.collection
    .makeComposite(reducer,cloudMask);
  if(app.data.layer.composite.clipGeometry !== null & app.toolBar.clipComposite.getState())
    app.data.layer.composite.image = app.data.layer.composite.image.clip(app.data.layer.composite.clipGeometry);
  app.data.layer.composite.bands = app.data.layer.composite.image.bandNames(); //images.SensorsList[sensorID].bands;
  return app.data.layer.composite.collection.size(); // number of images in collection
};
// actualiza capas del mapa
var updateLayers = ui.util.debounce(function(range) {
  var dateLabel = '';
  // se asegura que cuenta con los valores actuales de rango
  var daterange = app.control.composite.dateSlider.getValue();
  range = ee.DateRange(daterange[0],daterange[1]);
  print(eTime() + ': processing layers...');
  app.map.main.layers().reset([]);
  // determina la visibilidad actual de las capas
  var sensorID = app.control.composite.collections.getValue();
  var index = getIndexAcronym(app.control.index.selector.getValue());
  var texture = app.control.operator.texture.getValue();
  var compare = app.control.operator.compare.getValue();
  // actualiza variables de las capas
  app.data.count = updateComposite(sensorID,range);  
  app.control.composite.scenesCount.setValue('updating...');
  app.control.operator.thresholdPanel.widgets().reset([
      ui.Label('Threshold: updating...',INFO_STYLE)
    ]);
  app.dialog.message.style().set({shown: true});
  app.dialog.message.widgets().reset([ui.Label('Updating image layers...')]);
  // actualiza asincronamente
  app.data.count.gt(0).evaluate(function(val){
    if (!val) { 
      dateLabel = 'No images in selected period!';
      app.dialog.message.widgets().reset([ui.Label(dateLabel)]);
      // desabilita las secciones
      app.control.operator.setDisabled(true);
      app.control.explore.setDisabled(true);
      app.control.download.setDisabled(true);
      app.map.layer.composite = ui.Map.Layer();  
      app.map.layer.index = ui.Map.Layer(); 
      app.dialog.queryOpts.spectrum.setValue(false);
  } else {
      dateLabel = dateStr(daterange[0],app.data.dateFormat) + ' - ' + dateStr(daterange[1],app.data.dateFormat);
    // habilita opciones de operaciones subsecuentes
      app.control.operator.setDisabled(false);
      app.control.explore.setDisabled(false);
      app.control.download.setDisabled(false);
    // habililta grafica de firma
      var spectrum = images.SensorsList[sensorID].wavelengths.length > 1;  
      var value = app.dialog.queryOpts.spectrum.getValue();
      app.dialog.queryOpts.spectrum
        .setValue(value & spectrum)
        .setDisabled(!spectrum);
    app.control.explore.composite.setLabel(app.data.layer.composite.name);
    app.map.legends.composite.config.title.setValue(app.data.layer.composite.name);
    // actualiza compuesto
      app.map.layer.composite = ui.Map.Layer({
        eeObject: app.data.layer.composite.image,
        visParams: app.data.layer.composite.visParams,
        name: app.data.layer.composite.name,
        opacity: app.data.option.copacity,
        shown: app.control.explore.composite.getValue(),
      });
      app.map.layer.composite.visParams = app.data.layer.composite.visParams; // para gui:visParams
      app.map.main.layers().set(0,app.map.layer.composite);
      updateIndex(index,texture,compare);
      updateThrSlider(); // actualiza umbrales
      updateScaleSlider();      
      app.dialog.message.style().set({shown: false});
    }
    app.control.composite.selDateLabel.setValue(dateLabel);
  });
  // prepara reseteo de cuenta de escenas
  app.control.composite.scenesCount.setValue('updating...');
  app.data.count.evaluate(function(val){
    app.control.composite.scenesCount.setValue(val);
    app.data.count = val;
  });
  // actualiza el url y de descarga
  ui.url.set('date',daterange[0]);
  resetUrl();
  resetDownloadUrls();
  updateColHistView(daterange);
},1000);
app.control.composite.showDateSlider.onChange(
  function(value){
     app.toolBar.showDateSlider.setState(value*1);
  });
app.dateSelector.closeDateSlider.onClick(
  function(widget){
    app.toolBar.showDateSlider.toggles();
  });
app.toolBar.showDateSlider.onChange(function(state,widget){
  var value = (state === 1);
    app.control.composite.showDateSlider.setValue(value,false);
    app.dateSelector.panel.style().set('shown',value);
    app.dateSelector.configDateSlider.setDisabled(!value);
    app.dateSelector.showCalendar.setDisabled(!value);
    app.dateSelector.showColHist.setDisabled(!value);
    app.dateSelector.updateColHist.setDisabled(!value || app.dateSelector.showColHist.getState() === 0);
});
app.dateSelector.configDateSlider.onClick(
  function(widget){
    app.dialog.timeSlice.panel.style().set({shown : true});
    app.toolBar.panel.style().set({shown: false});
});
// actualiza el selector de fecha del compuesto
var updateDateSlider = function(sensorID) {
  var newVal;
  // asegura que se tiene la última selección
  sensorID = app.control.composite.collections.getValue();
  if(!sensorID) {
    app.dateSelector.panel.style().set('shown',false);
    return;
  }
  // define parametros de visualización del compuesto
  if(app.data.option.cvisParams) {
    app.data.layer.composite.visParams = app.data.option.cvisParams;
    app.data.option.cvisParams = null;
  } else
    app.data.layer.composite.visParams = images.SensorsList[sensorID].visParams;
  print(eTime() + ': selecting date...');
  var periodUnits = app.dialog.timeSlice.periodUnit.getValue();
  var period = Math.max(1,Math.round(app.dialog.timeSlice.period.getValue() * app.data.periodFactors[periodUnits]));
  var startDate = new Date(app.dialog.timeSlice.starDate.getValue()).getTime();
  var endDate = new Date(app.dialog.timeSlice.endDate.getValue()).getTime();
 if(images.SensorsList[sensorID].collectionUrl === undefined)
    images.SensorsList[sensorID].collectionUrl = '';
  // actualiza la descripción del sensor
  app.control.composite.collection
    .setValue(images.SensorsList[sensorID].description)
    .setUrl(images.SensorsList[sensorID].collectionUrl);
  //var range = ee.List(images.SensorsList[sensorID].collection.get('date_range'));
  // muestra el panel de fecha
  app.dateSelector.panel.style()
    .set('shown',app.control.composite.showDateSlider.getValue());
  // determina la nueva fecha seleccionada usando uno de los siguientes:
  // 1- valor de default
  // 2- selección previa
  // 3- fecha más reciente disponible en el rango
  if(app.data.option.date) {
    newVal = app.data.option.date;
    app.data.option.date = null;
  } else {
    newVal =  app.control.composite.dateSlider.getValue();
    if(newVal)
      newVal = (newVal[0]+newVal[1])/2; // valor medio del rango
  }
  // forza nueva fecha al limite de fechas
  newVal = Math.max(Math.min(newVal,endDate),startDate);
  // crea un nuevo selector de fecha nuevamente 
  app.control.composite.dateSlider = ui.DateSlider({
    start: startDate,
    end: endDate,
    period: period,
    onChange: updateLayers,
    style: DATE_SLIDER_STYLE,
  });
  app.control.composite.dateSlider.style()
  .set('height',55 + 45*app.dateSelector.showCalendar.getState() + 'px');
    //.set('height',55 + 45*app.control.composite.showCalendar.getValue() + 'px');
  // pone el selector de vuelta en el panel
  app.dateSelector.panel.widgets().set(1,app.control.composite.dateSlider);
  // aculta el mensaje
  app.dialog.message.style().set({shown: false});
  // actualiza la fecha seleccionada y llama la actualización de las capas
  app.control.composite.dateSlider.setValue(newVal,false);
  var daterange = app.control.composite.dateSlider.getValue();
  updateColHist(startDate,endDate,period,daterange);
  updateLayers(); // asegura la llamada la primera vez
};
app.dialog.timeSlice.starDate.onChange(
  function(text,widget){
    var startDate = Date.parse(text);
    if(startDate) 
      app.dialog.timeSlice.starDate.setValue(dateStr(startDate,app.data.dateFormatLong),false); 
    else {
      startDate = ui.url.get('startdate');
      app.dialog.timeSlice.starDate.setValue(dateStr(startDate,app.data.dateFormatLong),false); 
    }
 });
app.dialog.timeSlice.endDate.onChange(
  function(text,widget){
    var endDate = Date.parse(text);
    if(endDate) 
      app.dialog.timeSlice.endDate.setValue(dateStr(endDate,app.data.dateFormatLong),false); 
    else {
      endDate = ui.url.get('enddate');
      app.dialog.timeSlice.endDate.setValue(dateStr(endDate,app.data.dateFormatLong),false); 
    }
 });
var resetDateConfig = function(butt){
    var periodUnits = 'day';
    var period = getPeriod(images.SensorsList[val].period);
    var startDate = new Date(app.dialog.timeSlice.starDate.getValue()).getTime();
    var endDate = new Date(app.dialog.timeSlice.endDate.getValue()).getTime();
    ui.url.set('startdate',startDate);
    ui.url.set('enddate',endDate);
    ui.url.set('period',app.dialog.timeSlice.period.getValue() * app.data.periodFactors[periodUnits]);
    ui.url.set('reducer',app.dialog.timeSlice.reducer.getValue());
    ui.url.set('cloudmask',app.dialog.timeSlice.cloudMask.getValue()); 
    ui.url.set('cloudfilter',app.dialog.timeSlice.cloudFilter.getValue()); 
    ui.url.set('maxcloud',app.data.defaultopt.maxCloud); 
    resetUrl();
    updateDateSlider();
};
var applyDateConfig = function(butt){
    var periodUnits = app.dialog.timeSlice.periodUnit.getValue();
    var startDate = new Date(app.dialog.timeSlice.starDate.getValue()).getTime();
    var endDate = new Date(app.dialog.timeSlice.endDate.getValue()).getTime();
    ui.url.set('startdate',startDate);
    ui.url.set('enddate',endDate);
    ui.url.set('period',app.dialog.timeSlice.period.getValue() * app.data.periodFactors[periodUnits]);
    ui.url.set('reducer',app.dialog.timeSlice.reducer.getValue());
    ui.url.set('cloudmask',app.dialog.timeSlice.cloudMask.getValue()); 
    ui.url.set('cloudfilter',app.dialog.timeSlice.cloudFilter.getValue()); 
    ui.url.set('maxcloud',app.dialog.timeSlice.maxCloud.getValue()); 
    resetUrl();
    updateDateSlider();
};
app.dialog.timeSlice.apply.onClick(applyDateConfig);
app.dialog.timeSlice.cancel.onClick(
  function(butt){
    var opt = updateFromUrl(['period','endDate','startDate','reducer','cloudMask','cloudFilter','maxCloud'],app.data.defaultopt);
    app.toolBar.panel.style().set({shown: true});
    app.dialog.timeSlice.panel.style().set({shown: false});
    var period = getPeriod(opt.period);
    app.dialog.timeSlice.endDate.setValue(dateStr(opt.endDate,app.data.dateFormatLong),false); 
    app.dialog.timeSlice.starDate.setValue(dateStr(opt.startDate,app.data.dateFormatLong),false); 
    app.dialog.timeSlice.periodUnit.setValue(period.unit);
    app.dialog.timeSlice.period.setValue(period.val);
    app.dialog.timeSlice.reducer.setValue(opt.reducer);
    app.dialog.timeSlice.cloudMask.setValue(opt.cloudMask); 
    app.dialog.timeSlice.cloudFilter.setValue(opt.cloudFilter); 
    app.dialog.timeSlice.maxCloud.getValue(opt.maxCloud); 
});
app.dialog.timeSlice.cloudFilter.onChange(
  function(newValue) {
    app.dialog.timeSlice.maxCloud.setDisabled(!newValue); 
  });
var updateTimeSlice = function(val){
// resetea los controles del compuesto
    var period, startDate, endDate;
    // deshabilita la descarga del compuesto si está restringido
    var downloadable = images.SensorsList[val].downloadable;
    downloadable = (downloadable === undefined)? true: downloadable;
    app.control.download.compositeRefresh.setDisabled(!downloadable);
    // muestra/oculta opción de enmascaramiento de nubes
    var cloudMask = images.SensorsList[val].qualityBand.length > 0;
    var cloudFilter = false;
    if(images.SensorsList[val].cloudCoverProp !== undefined)
      cloudFilter = images.SensorsList[val].cloudCoverProp.length > 0;
    if(!cloudMask)
      app.dialog.timeSlice.cloudMask.setValue(false);
    app.dialog.timeSlice.cloudMask.style().set('shown',cloudMask);
    app.dialog.timeSlice.cloudCoverPanel.style().set('shown',cloudFilter);
    if(app.data.option.period) {
      period = getPeriod(app.data.option.period);
      app.data.option.period = null; // el valor por default sólo se usa una vez
    } else
      period = getPeriod(images.SensorsList[val].period);
    app.dialog.timeSlice.period.setValue(period.val,false);
    app.dialog.timeSlice.periodUnit.setValue(period.unit,false);
    ee.List(images.SensorsList[val].collection.get('date_range'))
      .evaluate(function(range){
        var dateRangeLabel = dateStr(range[0],app.data.dateFormatLong) + ' - ' + dateStr(range[1],app.data.dateFormatLong);
        app.control.composite.dateRangeLabel.setValue(dateRangeLabel);
        if(app.data.option.startDate) {
          startDate = app.data.option.startDate;
          app.data.option.startDate = null;
        } else 
          startDate = range[0];
        app.dialog.timeSlice.starDate.setValue(dateStr(startDate,app.data.dateFormatLong),false);
        if(app.data.option.endDate) {
          endDate = app.data.option.endDate;
          app.data.option.endDate = null;
        } else
          endDate = range[1];
        app.dialog.timeSlice.endDate.setValue(dateStr(endDate,app.data.dateFormatLong),false);
        applyDateConfig();
     });
};
app.control.composite.collections.onChange(updateTimeSlice);
// actualiza la vista del histograma
var updateColHistView = function(daterange){
  if(app.chart.colHist === null)
    return;
  var period_ms = daterange[1]-daterange[0];
  var period = app.control.composite.dateSlider.getPeriod();
  var startDate = app.control.composite.dateSlider.getStart();
  var endDate = app.control.composite.dateSlider.getEnd();
  var delta = (period >= 20)?40:20; // ancho de las barras
  var W = (app.data.windowSize.width-app.data.panelWidth)*period_ms/delta;
  var t0 = daterange[0]; //(daterange[1]+daterange[0])/2;
  var skip = 8;
  var k = Math.round((t0-startDate)/(skip*period_ms));  
  var dW = Math.abs(app.data.colHistChart.hAxis.viewWindow.max-app.data.colHistChart.hAxis.viewWindow.min-W);
  if(t0 < app.data.colHistChart.hAxis.viewWindow.min | t0 > app.data.colHistChart.hAxis.viewWindow.max | dW > period_ms) {    
    app.data.colHistChart.hAxis.viewWindow.max = Math.min(endDate,startDate+skip*k*period_ms+W);
    app.data.colHistChart.hAxis.viewWindow.min = app.data.colHistChart.hAxis.viewWindow.max-W;
  } 
  if(t0 < app.data.colHistChart.hAxis.viewWindow.min - period_ms) {
    app.data.colHistChart.hAxis.viewWindow.min = app.data.colHistChart.hAxis.viewWindow.min - period_ms;
    app.data.colHistChart.hAxis.viewWindow.max = app.data.colHistChart.hAxis.viewWindow.max - period_ms;
  }
  if(t0 > app.data.colHistChart.hAxis.viewWindow.max - period_ms) {
    app.data.colHistChart.hAxis.viewWindow.min = app.data.colHistChart.hAxis.viewWindow.min + period_ms;
    app.data.colHistChart.hAxis.viewWindow.max = app.data.colHistChart.hAxis.viewWindow.max + period_ms;
  }
  app.chart.colHist.setOptions(app.data.colHistChart);
};
// actualiza el histograma de la colección
var updateColHist = function (startDate,endDate,period,daterange){ 
  startDate = Math.max(0,startDate); // descarta las fechas previas a 1970-01-01
  print(eTime() + ': updating histogram...');
  app.dateSelector.panel.widgets()
      .set(0,ui.Label('Updating scenes histogram...',{textAlign: 'center',stretch: 'both',backgroundColor: TRANSPARENT}));
  var sensorID = app.control.composite.collections.getValue();
  var period_ms = daterange[1]-daterange[0];
  var steps = Math.ceil((endDate - startDate)/period_ms);
  //var shown = app.control.composite.showColHist.getValue();
  var shown = app.dateSelector.showColHist.getState();
  // update end
  var max = startDate + steps*period_ms;
  var dateRange = ee.DateRange(startDate,endDate);
  var bounds = ee.Geometry.Rectangle(app.map.bounds);
  var collection = images.collection(sensorID,dateRange,app.data.layer.composite.maxCloud,bounds);
  // calcula histograma de escenas  
  var hist = ee.Array(collection    
    .aggregate_array('system:time_start')
    .reduce(ee.Reducer.fixedHistogram(startDate,max,steps)))
    .toList()
    .map(function(row){
      row = ee.List(row);
      var millis = ee.Date(row.get(0)).millis().format();
      return row.set(0,ee.String('Date(').cat(millis).cat(')'));
      });    
  var columnHeader = ee.List([[
    {label: 'Date', role: 'domain', type: 'date'},
    {label: 'Scenes', role: 'data', type: 'number'}
  ]]);
  // despliega y configura
  columnHeader.cat(hist)
    .evaluate(function(dataTable,error){
      if(dataTable === undefined) {
        print(error)
        app.dateSelector.panel.widgets()
         .set(0,ui.Label('Empty scenes histogram!',{textAlign: 'center',stretch: 'both',backgroundColor: TRANSPARENT}));
         return;
      }
      app.chart.colHist = ui.Chart(dataTable)
      .setChartType('ColumnChart')
      .setOptions(app.data.colHistChart)
      .setSeriesNames(['Scenes']);
      //.setDownloadable(false)
      app.chart.colHist.style()
        .set({margin: '0px', padding: '0px',shown: shown});
      app.dateSelector.panel.widgets()
        .set(0,app.chart.colHist);
      app.chart.colHist.onClick(setDate);
  });
};
//app.control.composite.showColHist.onChange(
app.dateSelector.showColHist.onChange(
  function(value){
    //app.control.composite.updateColHist.style().set('shown',value);
    app.dateSelector.updateColHist.setDisabled(!value);
    app.dateSelector.panel.widgets().get(0).style().set('shown',value);
    });
//app.control.composite.updateColHist.onClick(
app.dateSelector.updateColHist.onClick(
  function(widget){
    var periodUnits = app.dialog.timeSlice.periodUnit.getValue();
    var period = Math.round(app.dialog.timeSlice.period.getValue() * app.data.periodFactors[periodUnits]);
    var startDate = new Date(app.dialog.timeSlice.starDate.getValue()).getTime();
    var endDate = new Date(app.dialog.timeSlice.endDate.getValue()).getTime();
    var daterange = app.control.composite.dateSlider.getValue();
    updateColHist(startDate,endDate,period,daterange);
    updateColHistView(daterange);
    });
//app.control.composite.showCalendar.onChange(
app.dateSelector.showCalendar.onChange(
  function(value){
    app.control.composite.dateSlider.style().set('height',(55 + 45*value) + 'px');
  });
// actualiza la capa de indice
var updateIndexLayer = function(legend){
  print(eTime() + ': updating index layer...');
  var masked = app.control.operator.mask.getValue();
  if(masked)
    app.map.layer.index = ui.Map.Layer({
      eeObject: app.data.layer.index.masked, 
      visParams: app.data.layer.index.visParams, 
      name: app.data.layer.index.name, 
      shown: app.control.explore.index.getValue(), 
      opacity: app.data.option.iopacity,
      });
  else
    app.map.layer.index = ui.Map.Layer({
      eeObject: app.data.layer.index.image, 
      visParams: app.data.layer.index.visParams, 
      name: app.data.layer.index.name, 
      shown: app.control.explore.index.getValue(), 
      opacity: app.data.option.iopacity,
      });  
  app.map.main.layers().set(1,app.map.layer.index);
  // update legend
  if(legend) {
    app.map.layer.index.visParams = app.data.layer.index.visParams; // para gui:visParams
    ui.util.setTimeout(function(){
      updateLegends(1);
    },app.data.startUpDelayStep);
  }
};
/************** Adavanced Operators ***************/
// valida limite inferior de reescalamiento
app.control.operator.rescaleMin.onChange(function(value){
  if(isNaN(parseFloat(value)))
    app.control.operator.rescaleMin
      .setValue(app.data.layer.index.visParams.min,false);
});
// valida limite inferior de reescalamiento
app.control.operator.rescaleMax.onChange(function(value){
  if(isNaN(parseFloat(value)))
    app.control.operator.rescaleMax
      .setValue(app.data.layer.index.visParams.max,false);
});
app.control.operator.updateRange.onClick(function(button){
  app.control.operator.rescaleMin
      .setValue(app.data.layer.index.visParams.min,false);
  app.control.operator.rescaleMax
      .setValue(app.data.layer.index.visParams.max,false);    
});
// actualiza el selector de umbral
var updateThrSlider = function() {
  var newVal;
  var curVal = app.control.operator.threshold.getValue();
  print(eTime() + ': updating threshold slider...');
  var disabled = app.control.operator.threshold.getDisabled();
  var min = parseFloat(app.control.operator.rescaleMin.getValue());
  var max = parseFloat(app.control.operator.rescaleMax.getValue());
  var step = Math.min((max-min)/100,1);
  // determina el nuevo valror a partir de los siguientes
  // 1- valor por default
  // 2- valor actual
  // 3- valor más cercano dentro del rango válido
  if(app.data.option.threshold !== null) {
    newVal = app.data.option.threshold;
    app.data.option.threshold = null;
  } else
    newVal = curVal;
  newVal = Math.min(Math.max(newVal,min),max);
  // quita el valor para actualizar límites
  app.control.operator.threshold.setValue(null,false);
  // actualiza los limites
  if(max < app.control.operator.threshold.getMax()) {
    if(min < app.control.operator.threshold.getMin())
      app.control.operator.threshold = app.control.operator.threshold
        .setMin(min).setStep(step).setMax(max);
    else 
      app.control.operator.threshold = app.control.operator.threshold
        .setStep(step).setMax(max).setMin(min);
  } else {
    if(min < app.control.operator.threshold.getMin())
      app.control.operator.threshold = app.control.operator.threshold
        .setMin(min).setMax(max).setStep(step);
    else 
      app.control.operator.threshold = app.control.operator.threshold
        .setMax(max).setStep(step).setMin(min);  
  }  
  app.control.operator.thresholdPanel.widgets().reset([
    ui.Label('Threshold:',ROW_STYLE),
    app.control.operator.threshold
    ]);
  app.control.operator.threshold.setValue(newVal,false);
  updateMask(newVal);
};
// habilita máscara
app.control.operator.mask.onChange(
  function(value){
    app.control.operator.maskOptions.style().set({shown: value});
    updateThrSlider();    
    updateIndexLayer(0); // actualiza la capa sin la legenda
});
// actualiza área de la máscara
function updateArea(){
  if(!app.control.operator.mask.getValue())
    return;
  if(!app.data.layer.index.masked)
    return;
  app.control.operator.maskArea.setValue('Mask area: updating...');
  var scale = app.map.scale.max(app.data.layer.index.scale);
  app.data.layer.index.masked
    .reduceRegion({
      reducer: ee.Reducer.count(),
      scale: scale,
      bestEffort: true,
      maxPixels: images.MaxPixels,
      crs: app.data.defaultProj, 
      geometry: ee.Geometry.Rectangle(app.map.bounds),
    }).getNumber(getIndexAcronym(app.control.index.selector.getValue()))
    .multiply(scale.pow(2).divide(1e6)) // covierte a km2
    .evaluate(function(area){
      if(!area)
        area = 0;
      app.control.operator.maskArea.setValue('Mask area: ' + area.toFixed(4) + ' Km2');
    });
}
// actualiza máscara
var updateMask = function(threshold){
  print(eTime() + ': masking/unmasking index...');
  threshold = app.control.operator.threshold.getValue();
  // aplica la mascara y actualiza la capa
  if (app.control.operator.invertMask.getValue()) 
    app.data.layer.index.masked = app.data.layer.index.image
        .updateMask(app.data.layer.index.image.lte(threshold));
  else
    app.data.layer.index.masked = app.data.layer.index.image
        .updateMask(app.data.layer.index.image.gt(threshold));
  // actualiza si está activa
   updateIndexLayer(1); // actualiza la capa sin la leyenda
   updateArea();
};
// cambia el umbral
app.control.operator.threshold.onChange(
  ui.util.debounce(updateMask,100)
  );
// invierte la mascara
app.control.operator.invertMask.onChange(
  updateMask
);
// funcion de actualización de la operaci´ón binaria
var updateComparison = function(compare){
  var index = getIndexAcronym(app.control.index.selector.getValue());
  var texture = app.control.operator.texture.getValue();
  var comparison = app.control.operator.comparison.getValue();
  app.control.operator.compareOptions.style().set({shown: compare});
  app.dialog.queryOpts.timeseries.setDisabled(compare);
  app.dialog.queryOpts.timeseries2.setDisabled(compare);
  if(compare) {
    app.data.layer.index.visParams = images.Comparisons[comparison].visParams;
    app.dialog.queryOpts.timeseries.setValue(false);
    app.dialog.queryOpts.timeseries2.setValue(false);
  } else {
    app.data.layer.index.visParams = images.SI[index].visParams;    
  } 
  app.control.download.videoRow.style().set('shown',!compare); // desabilita generación de animación
  app.control.download.framesPanel.style().set('shown',!compare);
  updateIndex(index,texture,compare);
  updateThrSlider();
};
// abilita el operador binario
app.control.operator.compare.onChange(updateComparison);
// actualiza el operador binario
app.control.operator.comparison.onChange(
  function(value){
    if(app.control.operator.compare.getValue())
      updateComparison(true);
  });
// muestra/oculta herramienta de consulta
app.control.operator.showQueryTool.onChange(
  function(checked) {
    app.toolBar.queryIcon.setDisabled(!checked);
    app.toolBar.configQuery.setDisabled(!checked);
  });
// configura las opciones de consulta
app.toolBar.configQuery.onClick(
  function(widget) {
    app.dialog.queryOpts.panel.style().set({shown: true});
    app.toolBar.panel.style().set({shown: false});
  });
// actualiza textura
function updateTexture(){
    var texture = app.control.operator.texture.getValue();
    var selection = getTextureAcronym(app.control.operator.selector.getValue());
    var index = getIndexAcronym(app.control.index.selector.getValue());
    var compare = app.control.operator.compare.getValue();
    if(texture) {
      print(selection)
      app.data.layer.index.visParams = images.SF[selection].visParams;
      app.dialog.queryOpts.timeseries.setValue(false).setDisabled(true);
      app.dialog.queryOpts.timeseries2.setValue(false).setDisabled(true);    
    } else {
      app.data.layer.index.visParams = images.SI[index].visParams;
      app.dialog.queryOpts.timeseries.setDisabled(false);
      app.dialog.queryOpts.timeseries2.setDisabled(false);
    }  
    updateIndex(index,texture,compare);
    updateThrSlider();
    // actualizar la legenda con retraso
}
// habilita operador espacial
app.control.operator.texture.onChange(
  function(value){
    app.control.operator.textureOptions.style().set({shown: value});
    updateTexture();
});
// actualiza operador espacial
app.control.operator.selector.onChange(
  function(value){
    var selection = getTextureAcronym(app.control.operator.selector.getValue());
    var index = getIndexAcronym(app.control.index.selector.getValue());
    app.control.operator.rescale.setValue(index !== 'DSM' & index !== 'DTM' ,false);
    app.control.operator.name.setValue(images.SF[selection].name + ' (' + selection + ')');
    app.control.operator.descr.setValue(images.SF[selection].notes + 
      ' See: ' + images.SF[selection].reference);
    if(!app.control.operator.texture.getValue())
      return;
    updateTexture();
  });
// actualiza kernel
app.control.operator.kernel.onChange(updateTexture);
// reescala entrada
app.control.operator.rescale.onChange(updateTexture);
// vectoriza la mascara
var vectorizeMask = function(type){
  var region = ee.Geometry.Rectangle(app.map.bounds);
  //print('map & layer scale: ',app.map.scale,app.data.layer.index.scale)
  var scale = app.map.scale.max(app.data.layer.index.scale);
  var mask = app.data.layer.index.masked
    .mask() // mascara
    .selfMask()
    .rename('mask')
    .toInt();
  var geoms;
  // crea vectores
  if(type === 'polygon') 
    geoms = mask.reduceToVectors({
      geometry: region,
      scale: scale,
      maxPixels: images.MaxPixels,
      geometryType: 'polygon',
      bestEffort: true,
      crs: app.data.defaultProj, 
  }).geometry(1);
  if(type === 'contour') {
    geoms = ee.FeatureCollection(mask.reduceToVectors({
      geometry: region,
      scale: scale,
      maxPixels: images.MaxPixels,
      geometryType: 'polygon',
      bestEffort: true,
      crs: app.data.defaultProj, 
    }).map(function(f){
      return ee.Feature(ee.Geometry.LinearRing(f.geometry(1).coordinates().get(0)));
    }))
    .geometry(1);
   } 
   geoms.evaluate(function(geometry){
      app.drawingTools.addLayer({
      geometries: [geometry],
      name: app.data.contourName + ' ' + type + ' ' +app.data.contours++,
      //color: 'black',
    });
  });
};
app.control.operator.maskPolygon.onClick(function(widget){
  vectorizeMask('polygon');
  });
app.control.operator.maskOutline.onClick(function(widget){
  vectorizeMask('contour');
  });  
// Muestra resultado de una consulta de punto
var showValue = function(point,point_gl,drawingTools){
  var shape = drawingTools.getShape();
  drawingTools.unlisten(); // deja de escuchar eventos hasta que termine la consulta
  drawingTools.setSelected(null);
  if(point.length === 0) {
    drawingTools.layers().remove(point_gl);    
    return;
  }
  var color = point_gl.getColor();
  var scale = app.map.scale.max(app.data.layer.index.scale).getInfo();
  var aoi = ee.Geometry.Rectangle(app.map.bounds);
  var index = getIndexAcronym(app.control.index.selector.getValue());
  var reducerName = app.dialog.timeSlice.reducer.getValue();
  var indexBand = app.data.layer.index.visParams.bands[0]; // puede incluir textura o comparacion
  var sensorID = app.control.composite.collections.getValue();
  app.dialog.inspector.info.setValue('Retrieving value...');
  app.dialog.inspector.panel.style().set('shown', true);
  app.dialog.message.widgets().reset([ui.Label('Please wait...')]);   
  // Extrae valore de la capa de indice
  app.data.layer.index.image.reduceRegion({
    reducer: ee.Reducer.first(), 
    geometry: point,
    crs: app.data.defaultProj, 
    scale: scale
  }).evaluate(function(value) {
    // muestra la información
        var coords = point.coordinates().getInfo();
        //var scaleStr = scale.format('%.0f').getInfo();
        var infoStr = sensorID + '\n' +
          'Period: ' + app.data.layer.composite.start + ' - ' + app.data.layer.composite.end + '\n' +
          'Reducer: ' + reducerName + '\n' + 
          'Geometry: ' + point_gl.getName() + '\n' + 
          '\tlon:  ' + coords[0].toFixed(8) + ' deg\n' +
          '\tlat:  ' + coords[1].toFixed(8) + ' deg\n' +
          indexBand + ' value: ' + ((value[indexBand] !== null)? value[indexBand].toFixed(4):null) + '\n' +
          'Map scale: ' + scale.toFixed(1) + ' meters';
        app.dialog.inspector.info.setValue(infoStr);
      // mantiene o borra el marcador
      if(!app.dialog.queryOpts.keepMarker.getValue()) 
        drawingTools.layers().remove(point_gl);
      else
        ++app.data.points;
      startQuery(shape);
    });
  // procesa las gráficas
  app.dialog.inspector.charts.clear();
  if (app.dialog.queryOpts.spectrum.getValue()) {
    // firma espectral del índice
    var wavelengths = images.SensorsList[sensorID].wavelengths;
    app.data.specChart.title = sensorID + ' Spectral Signature';
    app.data.specChart.hAxis.title = images.SensorsList[sensorID].wavelengthUnits;
    app.data.specChart.series[0].labelInLegend = point_gl.getName();
    var composite = app.data.layer.composite.image
      .select(images.SensorsList[sensorID].mappedBandNames); // sin count
    var reflectance = ee.Dictionary(composite
      .reduceRegion({
        reducer: ee.Reducer.first(), 
        geometry: point,
        crs: app.data.defaultProj, 
        scale: scale
      })
    ).values(images.SensorsList[sensorID].mappedBandNames);
    reflectance = reflectance.sort(wavelengths);
    wavelengths = wavelengths.sort(function(a,b){return a-b});
    app.data.specChart.hAxis.viewWindow.min = wavelengths[0];
    app.data.specChart.hAxis.viewWindow.max = wavelengths[wavelengths.length-1];
    var specChart = ui.Chart.array.values(reflectance,0,wavelengths)
      .setChartType('LineChart') // BarChart,ColumnChart,ScatterChart,LineChart
      .setOptions(app.data.specChart);
    app.dialog.inspector.charts.add(specChart);  
  }    
  if (app.dialog.queryOpts.timeseries.getValue()) {
    // serie de tiempo
    app.data.timeSeriesChart.title = sensorID + '-' + reducerName + index + ' Time Series';
    app.data.timeSeriesChart.vAxis.title = index;
    app.data.timeSeriesChart.series[0].labelInLegend = point_gl.getName();
    var bandNames = images.SensorsList[sensorID].mappedBandNames;
    var count = ee.List(bandNames).size().getInfo();
    var bands = ee.List.sequence(0,count-1);
    var reducer = app.data.colReducers[reducerName];
    var period = app.control.composite.dateSlider.getPeriod();
    var daterange = app.control.composite.dateSlider.getValue();
    //var period_ms = daterange[1]-daterange[0];    
    var startDate = app.control.composite.dateSlider.getStart();
    var endDate = app.control.composite.dateSlider.getEnd();
    var dateRange = ee.DateRange(startDate,endDate);
    var grouping = {refDate:startDate,period:period};
    var cloudMask = app.dialog.timeSlice.cloudMask.getValue();
    var applyMask = app.control.operator.mask.getValue();
    var invertMask = app.control.operator.invertMask.getValue();
    var threshold = app.control.operator.threshold.getValue();
    var masking = {applyMask:applyMask,invertMask:invertMask,threshold:threshold};
    var collection = images.collection(sensorID,dateRange,app.data.layer.composite.maxCloud,point)
      //.makeComposites(grouping,reducer,cloudMask).mapIndex(index,masking); // indice de reducciones
      .normalize(cloudMask).mapIndex(index,masking).reduceIndex(grouping,reducer); // reducciones de indices
    var seriesChart = ui.Chart.image.series(collection, point, reducer, scale) 
    .setOptions(app.data.timeSeriesChart);      
    seriesChart.onClick(setDate);
    app.dialog.inspector.charts.add(seriesChart);  
  }
  if (app.dialog.queryOpts.flowline.getValue()){
      terrain.setDEM(app.data.layer.index.image); // usa el indice como MDE
      var line = terrain.FlowLine(point,app.data.maxflowLinePoints,scale * 1.5)
        .evaluate(function(geometry){
          if(geometry !== undefined)
           drawingTools.unlisten();
            app.drawingTools.addLayer({
              geometries: [geometry],
              name: app.data.flowlineName + app.data.flowlines++,
              color: color,
            });
           startQuery(shape);
        });
    }
  if (app.dialog.queryOpts.catchment.getValue()){
      terrain.setDEM(app.data.layer.index.image); // usa el indice como MDE
      var carea = terrain.Catchment(point,app.data.maxCatchAreaIter)
        .reproject('EPSG:3857',null,scale) // WGS 84 / Pseudo-Mercator -- Spherical Mercator
        .addBands([app.data.layer.index.image])
        .reduceToVectors({
          reducer: ee.Reducer.first(),
          geometry: aoi, 
          geometryType: 'polygon', 
          labelProperty: 'value',
          bestEffort: true
        }).geometry(scale)
        .evaluate(function(geometry){
          if(geometry !== undefined) {
            drawingTools.unlisten();
            app.drawingTools.addLayer({
              geometries: [geometry],
              name: app.data.catchmentName + app.data.catchments++,
              color: color,
            });
            startQuery(shape);
          }
        });
    }    
};
// Muestra resultado de una consulta de linea
var plotProfile = function(line,line_gl,drawingTools){
  var shape = drawingTools.getShape();
  drawingTools.unlisten();
  drawingTools.setSelected(null);
  if(line.length === 0) {
    if(!app.dialog.queryOpts.keepLine.getValue()) 
      drawingTools.layers().remove(line_gl);    
    return;
  }
  app.dialog.inspector.info.setValue('Computing statistics...');
  app.dialog.inspector.panel.style().set('shown', true);
  app.dialog.message.widgets().reset([ui.Label('Please wait...')]);   
  var index = app.data.layer.index.visParams.bands[0];
  var reducerName = app.dialog.timeSlice.reducer.getValue();
  var sensorID = app.control.composite.collections.getValue();
  var scale = app.map.scale.max(app.data.layer.index.scale).getInfo();
  //var scaleStr = scale.format('%.0f').getInfo();
  var statsReducer = ee.Reducer.minMax()
    .combine(ee.Reducer.mean(),"",true)
    .combine(ee.Reducer.stdDev(),"",true)
    .combine(ee.Reducer.sum(),"",true)
    .combine(ee.Reducer.count(),"",true)
    .combine(ee.Reducer.toList(),"",true); // datos para histograma
  // calcula estadisticas
  var dict = app.data.layer.index.image
    .reduceRegion({
      reducer: statsReducer, 
      geometry: line, 
      scale: scale,
      bestEffort: true, 
      crs: app.data.defaultProj,
      maxPixels: images.MaxPixels, 
    });
    dict.remove([index + '_list'])
      .evaluate(function(stats) {
        var infoStr = sensorID + '\n' +
          'Period: ' + app.data.layer.composite.start + ' - ' + app.data.layer.composite.end + '\n' +
          'Reducer: ' + reducerName + '\n' + 
          'Geometry: ' + line_gl.getName() + '\n'  +
          '\tlength: ' + (line.length().getInfo()/1e3).toFixed(5) + ' kilometers\n' + 
          index + ' Stats: ' + '\n' +
          '\tmin:   ' + stats[index + '_min'].toFixed(4) +
          '\tmax:   ' + stats[index + '_max'].toFixed(4) + '\n' +
          '\tmean:  ' + stats[index + '_mean'].toFixed(4)  +
          '\tstd:   ' + stats[index + '_stdDev'].toFixed(4) + '\n' +
          '\tsum:   ' + stats[index + '_sum'].toFixed(2) +
          '\tcount: ' + stats[index + '_count'].toFixed(0) + '\n' +
          'Map scale: ' + scale.toFixed(1) + ' meters';
        app.dialog.inspector.info.setValue(infoStr);
          // reinicia trazo
        if(!app.dialog.queryOpts.keepLine.getValue()) 
          drawingTools.layers().remove(line_gl);
        else
          ++app.data.profiles;
        startQuery(shape);
      });
  app.dialog.inspector.charts.clear();
  if(app.dialog.queryOpts.profile.getValue()) {
    terrain.setDEM(app.data.layer.index.image);
    app.data.profileChart.title = sensorID + '-' + index + ' profile';
    app.data.profileChart.vAxis.title = index;
    app.data.profileChart.series[0].labelInLegend = line_gl.getName();
    var profile = terrain.ProfilePlot(line,app.data.maxProfilePoints)
      .setOptions(app.data.profileChart)
      .setChartType('AreaChart');
    app.dialog.inspector.charts.add(profile);
  }
};
// Muestra resultado de una consulta de area
var showStats = function(polygon,polygon_gl,drawingTools){
  var shape = drawingTools.getShape();
  drawingTools.unlisten();
  drawingTools.setSelected(null);
  if(polygon.length === 0) {
    //if(!app.dialog.queryOpts.keepPolygon.getValue())
    app.dialog.queryOpts.keepPolygon.setValue(false);
    drawingTools.layers().remove(polygon_gl);    
    return;
  }
  app.dialog.inspector.info.setValue('Computing statistics...');
  app.dialog.inspector.panel.style().set('shown', true);
  app.dialog.message.widgets().reset([ui.Label('Please wait...')]);   
  var index = app.data.layer.index.visParams.bands[0];
  var reducerName = app.dialog.timeSlice.reducer.getValue();
  var sensorID = app.control.composite.collections.getValue();
  var scale = app.map.scale.max(app.data.layer.index.scale).getInfo();
  //var scaleStr = scale.format('%.0f').getInfo();
  var statsReducer = ee.Reducer.minMax()
    .combine(ee.Reducer.mean(),"",true)
    .combine(ee.Reducer.stdDev(),"",true)
    .combine(ee.Reducer.sum(),"",true)
    .combine(ee.Reducer.count(),"",true)
    .combine(ee.Reducer.toList(),"",true); // datos para histograma
  // calcula estadisticas
  var dict = app.data.layer.index.image
    .reduceRegion({
      reducer: statsReducer, 
      geometry: polygon, 
      scale: scale,
      bestEffort: true, 
      crs: app.data.defaultProj,
      maxPixels: images.MaxPixels, 
    });
    dict.remove([index + '_list'])
      .evaluate(function(stats) {
        var infoStr = sensorID + '\n' +
          'Period:   ' + app.data.layer.composite.start + ' - ' + app.data.layer.composite.end + '\n' +
          'Reducer: ' + reducerName + '\n' + 
          'Geometry: ' + polygon_gl.getName() + '\n'  +
          '\tarea: ' + (stats[index + '_count']*Math.pow(scale,2)/1e4).toFixed(2) + ' hectares\n' +
          index + ' Stats:\n' + 
          '\tmin:   ' + stats[index + '_min'].toFixed(4) + 
          '\tmax:   ' + stats[index + '_max'].toFixed(4) + '\n' +
          '\tmean:  ' + stats[index + '_mean'].toFixed(4) + 
          '\tstd:   ' + stats[index + '_stdDev'].toFixed(4) + '\n' +
          '\tsum:   ' + stats[index + '_sum'].toFixed(2) + 
          '\tcount: ' + stats[index + '_count'].toFixed(0) + '\n' +
          'Map scale: ' + scale.toFixed(1) + ' meters'; 
        app.dialog.inspector.info.setValue(infoStr);
        // reinicia trazo
        if(!app.dialog.queryOpts.keepPolygon.getValue()) 
          drawingTools.layers().remove(polygon_gl);
        else
          ++app.data.areas;
        startQuery(shape);  
      });
  app.dialog.inspector.charts.clear();
   // agrega el histograma
  var min = Number(app.control.operator.rescaleMin.getValue());
  var max = Number(app.control.operator.rescaleMax.getValue());
  if(app.dialog.queryOpts.histogram.getValue()) {
    app.data.histChart.title = sensorID +'-' + index + ' Histogram';
    app.data.histChart.series[0].labelInLegend = polygon_gl.getName();
    app.data.histChart.hAxis.title = index;
    app.data.histChart.hAxis.viewWindow.min = min;
    app.data.histChart.hAxis.viewWindow.max = max;
    // calcula histograma de ancho fijo
  var data = ee.Array(ee.List(dict.get(index + '_list'))
      .reduce(ee.Reducer.fixedHistogram(min,max,app.data.maxHistogramBuckets)));
    var hist = ui.Chart.array.values({
        array: data.slice(1,1),
        axis: 0,
        xLabels: data.slice(1,0,1),
      })
    .setChartType('ColumnChart')
    .setOptions(app.data.histChart);
    app.dialog.inspector.charts.add(hist);
  }
  // agrega el scatterplot
  if(app.dialog.queryOpts.scatterplot.getValue()) {
    var right = app.map.layer.index2.getEeObject();    
    var visParams_right = app.map.layer.index2.getVisParams();
    var visParams_left = app.data.layer.index.visParams;
    var yLabel = index + '_left';  
    var xLabel = right.bandNames().get(0).getInfo() + '_right';  
     var pixelVals = app.data.layer.index.image
      .addBands(right)
      .select([0,1],[yLabel,xLabel])
      .sample({
        region: polygon, 
        scale: scale, 
        projection: app.data.defaultProj,
        numPixels: app.data.maxScatterPoints, 
      });
    var xValues = pixelVals.aggregate_array(xLabel);
    var yValues = pixelVals.aggregate_array(yLabel);
    app.data.scatterplot.hAxis.title = xLabel;
    app.data.scatterplot.vAxis.title = yLabel;
    app.data.scatterplot.series[0].labelInLegend = polygon_gl.getName();
    var scatterplot = ui.Chart.array.values({
      array: yValues, 
      axis: 0,
      xLabels: xValues
    }).setOptions(app.data.scatterplot)
    .setSeriesNames([index]);
    app.dialog.inspector.charts.add(scatterplot);
  }
  // agrega ROCplot
  if(app.dialog.queryOpts.ROCplot.getValue() && polygon.type().getInfo() === 'MultiPoint') {
    var aoi = app.data.layer.composite.clipGeometry || ee.Geometry.Rectangle(app.map.bounds);
    var inc = (max-min)/app.data.maxROCthresholds;
    var ROCplot = images.ROCplot(app.data.layer.index.image,{
      min: min,
      max: max,
      inc: inc,
      points: polygon,
      aoi: aoi,
      scale: scale,
      crs: app.data.defaultProj, 
    });
    //.setOptions(app.data.scatterplot).setSeriesNames([index]);
    app.dialog.inspector.charts.add(ROCplot);
  }
  // agrega serie de tiempo
  if (app.dialog.queryOpts.timeseries2.getValue()) {
    var bandNames = images.SensorsList[sensorID].mappedBandNames;
    var count = ee.List(bandNames).size().getInfo();
    var bands = ee.List.sequence(0,count-1);
    var startDate = new Date(app.dialog.timeSlice.starDate.getValue()).getTime();
    var endDate = new Date(app.dialog.timeSlice.endDate.getValue()).getTime();
    var dateRange = ee.DateRange(startDate,endDate);
    var reducer = app.data.colReducers[reducerName];
    var periodUnits = app.dialog.timeSlice.periodUnit.getValue();
    var period = app.dialog.timeSlice.period.getValue() * app.data.periodFactors[periodUnits];    
    var grouping = {refDate:startDate,period:period,periodUnit:'day'};
    var cloudMask = app.dialog.timeSlice.cloudMask.getValue();
    var applyMask = app.control.operator.mask.getValue();
    var invertMask = app.control.operator.invertMask.getValue();
    var threshold = app.control.operator.threshold.getValue();
    var masking = {applyMask:applyMask,invertMask:invertMask,threshold:threshold};
    var collection = images.collection(sensorID,dateRange,app.data.layer.composite.maxCloud,polygon)    
      //.makeComposites(grouping,reducer,cloudMask).mapIndex(index,masking); // indices de reducciones
      .normalize(cloudMask).mapIndex(index,masking).reduceIndex(grouping,reducer); // reducciones de indices
    app.data.timeSeriesChart.title = sensorID + '-' + redcuerName + index + ' Time Series';
    app.data.timeSeriesChart.vAxis.title = index;
    app.data.timeSeriesChart.series[0].labelInLegend = polygon_gl.getName();
    var seriesChart = ui.Chart.image.series(collection, polygon, ee.Reducer.mean(), scale)     
    .setOptions(app.data.timeSeriesChart);
    seriesChart.onClick(setDate);
    app.dialog.inspector.charts.add(seriesChart);  
  }
};
// Inicia el modo consulta
var startQuery = function(shape){
  //print('startQuery:shape:',shape);
  var name,message,type = null,onDraw,widget;
  var dt = app.drawingTools;
  if(shape === null)
    return;
  shape = shape.toLowerCase();
  if(shape === 'point') {
    name = app.data.pointName + app.data.points;
    message = app.data.text.point;
    type = 'Point';
    onDraw = showValue;
    widget = app.dialog.queryOpts.keepMarker;
  } else {
    if(shape === 'line' || shape === 'linestring' ) {  
      name = app.data.lineName + app.data.profiles;
      message = app.data.text.profile;
      type = 'Line';
      onDraw = plotProfile;
      widget = app.dialog.queryOpts.keepLine;
    } else {
      if(shape === 'rectangle' || shape === 'polygon' || shape == 'multipoint' || shape == 'multipolygon') {
        name = app.data.polygonName + app.data.areas;  
        type = 'Rectangle|Polygon|MultiPoint|MultiPolygon';    
        message = app.data.text.polygon;
        onDraw = showStats;
        widget =  app.dialog.queryOpts.keepPolygon;
      }
    }
  }
  if(type=== null)
    return;
  app.dialog.message.widgets().reset([ui.Label(message)]);
  var onShapeChange = function(newshape,dt){
    //print('onShapeChange:newshape:',newshape);
    var deleted = geometries.stopDraw(type,dt);
    if(type === 'Rectangle|Polygon|MultiPoint|MultiPolygon')
      app.data.areas -= deleted;
    else {
      if (type === 'Line')
        app.data.profiles -= deleted;
      else {
        if (type === 'Point')
          app.data.points -= deleted;
    }}
    if(newshape === null)
      app.toolBar.queryIcon.toggles();
    else
      startQuery(newshape); // reinicia
  };
  // si había una geometría seleccionada
  if(geometries.startDraw(dt,name,shape + '|' + type,onDraw,onShapeChange)) 
    widget.setValue(true); // la mantiene
};
// Detiene modo consulta
var stopQuery = function(shape){
  var count = geometries.stopDraw(shape,app.drawingTools);
  app.drawingTools.reset();
  app.drawingTools.onSelect(showGeomInfo);
  if(shape === 'point') {
    app.data.points -= count;
  } else if(shape === 'line') {
    app.data.profiles -= count;
  } else if(shape === 'rectangle' || shape === 'polygon') {
    app.data.areas -= count;
  }
};
// Habilita el modo consulta
app.toolBar.queryIcon.onChange(
  function(state,but){
    app.dialog.message.style().set({shown: state === 1});
    var shape;
    // optiene la forma de consulta
    var selectedGeom = app.drawingTools.getSelected();
    if(selectedGeom) {
      var prevGeom = selectedGeom.toGeometry();
      shape = prevGeom.type().getInfo().toLowerCase();
    } else 
      shape = app.drawingTools.getShape() || 'point';  
    if(state)
      startQuery(shape);
    else
      stopQuery(shape);
    ui.url.set('inspector',state  > 0);
    resetUrl();
});
// Muestra/oculta opciones de consulta del mapa
app.dialog.queryOpts.queryBar.onClick(
  function(sel,desel,radio){
    var layerName;
    if(desel === 0){
      app.dialog.queryOpts.point.style().set({shown: false});
    } else if(desel === 1) {
      app.dialog.queryOpts.line.style().set({shown: false});
    } else if(desel === 2) {
      app.dialog.queryOpts.polygon.style().set({shown: false});
    }
    //app.toolBar.loadLayer.setState(1);
    if(sel === 0) {
      app.dialog.queryOpts.point.style().set({shown: true});
    } else if (sel === 1) {
      app.dialog.queryOpts.line.style().set({shown: true});
    } else if (sel === 2) {
      app.dialog.queryOpts.polygon.style().set({shown: true});
    }
});
app.dialog.queryOpts.close.onClick(function(widget){
  app.dialog.queryOpts.panel.style().set({shown: false});
  app.toolBar.panel.style().set({shown: true});
});
// Borra todas las geometrias que comienzan por prefix
var deleteGeometries = function(prefix) {
    var toDelete = [];
    app.drawingTools.layers()
      .forEach(function(layer){
        if(layer.getName().startsWith(prefix))
          toDelete[toDelete.length] = layer;
      });
    toDelete.map(function(layer) {
      app.drawingTools.layers().remove(layer);
    });
};
// borra puntos de consulta
app.dialog.queryOpts.deletePoints.onClick(
  function(value) {
    deleteGeometries(app.data.pointName); 
    app.data.points = 0;
    deleteGeometries(app.data.flowlineName);
    app.data.flowlines = 0;    
  });
// borra lineas de consulta
app.dialog.queryOpts.deleteLines.onClick(
  function(value) {
    deleteGeometries(app.data.lineName);
    app.data.profiles = 0;
  });
// borra poliponos de consulta
app.dialog.queryOpts.deletePolygons.onClick(
  function(value) {
    deleteGeometries(app.data.polygonName);
    app.data.areas = 0;
  });
// actualiza la fecha desde histograma
var setDate = function(xValue, yValue, seriesName) {
  if (!xValue) return; 
  var date = new Date(xValue + 1); //app.control.composite.dateSlider.getPeriod()*(3600*1000*24/2)
  app.control.composite.dateSlider.setValue(date); 
};
/*********** Map Appearence ***************/
app.control.explore.showMapTypes.onChange(
  function(checked){
    app.control.explore.mapType.style().set('shown',checked);
    app.map.main.setControlVisibility({mapTypeControl: checked});
    //app.map.copy.setControlVisibility({mapTypeControl: checked});
    });
// actualiza el tipo de mapa
app.control.explore.mapType.onChange(
  function(value){
    app.map.main.setOptions(value);
  });
// muestra/oculta las opciones de navegación de mapa
app.toolBar.showMapTools.onChange(
  function(state,widget){
    var checked = (state === 1);
    app.map.main.setControlVisibility({
      zoomControl: checked, 
      //scaleControl: checked, 
      fullscreenControl: checked,
    });
});
app.toolBar.showDrawingTools.onChange(
  function(state,widget){
    var checked = (state==1);
     app.map.main.setControlVisibility({drawingToolsControl: checked});
     app.control.operator.showQueryTool
      .setValue(checked)
      .setDisabled(!checked);
      app.toolBar.showDrawingTools
    });
// aplica parametros de visualizacion al indice desde los controles
app.map.legends.index.config.applyButton.onClick(
  function(widget){
    app.data.layer.index.visParams = app.map.legends.index.config.visParams;
  });
// aplica parametros de visualizacion al cmpuesto desde los controles
app.map.legends.composite.config.applyButton.onClick(
  function(widget){
    app.data.layer.composite.visParams = app.map.legends.composite.config.visParams;
  });
// actuakiza limites del mapa interior
function updateInsetBounds(center,map) {
  if (app.control.explore.inset.getValue()) {
    app.map.bounds.evaluate(function(rect){
      var bounds = ee.Geometry.Rectangle(rect);
      app.map.inset.centerObject(bounds);
      app.map.inset.layers().set(0, bounds);  
    });
  }
}
// actualiza la posicion del mapa interior
var updateInsetPos = function(pos){
  // si no está visible
  if(!app.control.explore.inset.getValue())
    return;
  //var split = app.control.explore.duplicate.getValue();
  var split = app.toolBar.duplicate.getState();
  // muestra en el panel correspondiente
  if(split) {
    app.map.main.remove(app.map.inset);
    app.map.copy.remove(app.map.inset);
    if (pos === 1) 
      app.map.copy.add(app.map.inset);
    else 
      app.map.main.add(app.map.inset);
  }
  // actualiza posicion
  if (pos === 0) 
    app.map.inset.style().set({position: 'bottom-left'});
  else 
    app.map.inset.style().set({position: 'bottom-right'});
  ui.url.set('insetpos',app.data.positions[pos]);
  resetUrl();
};
app.control.explore.inset.onChange(
  function(value){
    app.toolBar.showInset.setDisabled(!value);
    app.toolBar.insetPos.setDisabled(!value);
    var split = app.toolBar.duplicate.getState();
    if(!value){
      app.map.copy.remove(app.map.inset);
      app.map.main.remove(app.map.inset);
      return;
    }
    app.map.main.add(app.map.inset);      
    updateInsetPos(app.toolBar.insetPos.getState());
    updateInsetBounds();  
  });
// muestra/oculta el mapa interior
app.toolBar.showInset.onChange(
  function(value){
    app.map.inset.style().set({shown: value});
    app.toolBar.insetPos.setDisabled(!value);
  });
app.toolBar.insetPos.onChange(updateInsetPos);
// actualiza la posicion de la leyenda
var updateLegendsPos = function(pos){
  // si no está visible
  if(!app.control.explore.legends.getValue())
    return;
  //var split = app.control.explore.duplicate.getValue();
  var split = app.toolBar.duplicate.getState();
  // muestra en el panel correspondiente
  if (split) {
    //app.map.main.remove(app.map.legends.frame);    
    //app.map.copy.remove(app.map.legends.frame);
    app.map.main.remove(app.map.legends.panel)
    app.map.copy.remove(app.map.legends.panel)
   if(pos === 1) //(pos === 'right') 
    //app.map.copy.add(app.map.legends.frame);
    app.map.copy.add(app.map.legends.panel);
   else 
    //app.map.main.add(app.map.legends.frame);     
    app.map.main.add(app.map.legends.panel);     
  }
  // actualiza posicion
  if(pos === 0) // (pos === 'left') 
    //app.map.legends.frame.style().set({position: 'top-left'});
    app.map.legends.panel.style().set({position: 'top-left'});
  else 
    //app.map.legends.frame.style().set({position: 'top-right'});
    app.map.legends.panel.style().set({position: 'top-right'});
  ui.url.set('legendspos',app.data.positions[pos]);
  resetUrl();
};
// actualiza la leyendas del mapa indicado 0=primer panel, 1=segundo panel
var updateLegends = function(main){
  print(eTime() + ': updating legends...');
  if(main) {   
    app.map.legends.index.config.imageLayer = app.map.layer.index;
    app.map.legends.composite.config.imageLayer = app.map.layer.composite;
    app.map.legends.index.updateFromImage('i','');
    app.map.legends.composite.updateFromImage('c','');
  } else {
    app.map.legends.index2.config.imageLayer = app.map.layer.index2;    
    app.map.legends.composite2.config.imageLayer = app.map.layer.composite2;    
    app.map.legends.index2.updateFromImage('i','_');
    app.map.legends.composite2.updateFromImage('c','_');
  }
};
//muestra/oculta la leyenda
app.control.explore.legends.onChange(
  function(value) {
    app.toolBar.legendsPos.setDisabled(!value);
    app.toolBar.showLegend.setDisabled(!value);
    if (!value) {
      //app.map.main.remove(app.map.legends.frame);     //ui.root.remove(app.map.legends.panel);
      //app.map.copy.remove(app.map.legends.frame);
      app.map.main.remove(app.map.legends.panel);     //ui.root.remove(app.map.legends.panel);
      app.map.copy.remove(app.map.legends.panel);
      return;
    }
    //app.map.main.add(app.map.legends.frame);     //ui.root.add(app.map.legends.panel);
    app.map.main.add(app.map.legends.panel);     //ui.root.add(app.map.legends.panel);
    updateLegendsPos(app.toolBar.legendsPos.getState());
  }
);
// edita opciones del indice del primer panel
app.control.explore.indexEdit.onClick(function(value){
  app.map.legends.index.edit.toggles();
});
// edita opciones del compuesto del primer panel
app.control.explore.compositeEdit.onClick(function(value){
  app.map.legends.composite.edit.toggles();
});
// edita opciones del indice del segundo panel
app.control.explore.index2Edit.onClick(function(value){
  app.map.legends.index2.edit.toggles();
});
// edita opciones del compuesto del segundo panel
app.control.explore.composite2Edit.onClick(function(value){
  app.map.legends.composite2.edit.toggles();
});
// intercambia posiciion de la legenda
app.toolBar.legendsPos.onChange(updateLegendsPos);
// configura indice del primer panel
app.control.explore.index.onChange(
  function(value){
    app.map.legends.index.style().set({shown: value});
    if(!value && app.control.explore.indexEdit.getState())
      app.control.explore.indexEdit.toggles();
    app.control.explore.indexEdit.style().set({shown: value});
  });
// opciones del compuesto del primer panel
app.control.explore.composite.onChange(
  function(value){
    app.map.legends.composite.style().set({shown: value});
    if(!value && app.control.explore.compositeEdit.getState())
      app.control.explore.compositeEdit.toggles();
    app.control.explore.compositeEdit.style().set({shown: value});
  });
  // opciones del indice del segundo panel
app.control.explore.index2.onChange(
  function(value){
    app.map.legends.index2.style().set({shown: value});
    if(!value && app.control.explore.index2Edit.getState())
      app.control.explore.index2Edit.toggles();
    app.control.explore.index2Edit.style().set({shown: value});
  });
// opciones del compuesto del segundo panel
app.control.explore.composite2.onChange(
  function(value){
    app.map.legends.composite2.style().set({shown: value});
    if(!value && app.control.explore.composite2Edit.getState())
      app.control.explore.composite2Edit.toggles();
    app.control.explore.composite2Edit.style().set({shown: value});
    });
// muestra lista de capas a inlcuir
app.control.explore.showLayerList.onChange(
  function(checked){
    app.control.explore.layersOptions.style().set({shown: checked});
    app.map.main.setControlVisibility({layerList: checked});
    //app.map.copy.setControlVisibility({layerList: checked});
    }
  );
// Genera el URL corto 
app.control.explore.genUrl.onClick(  
  function(but) {
    var url = app.data.url + '#'; // url de la app
    var single_opts = updateFromUrl(app.data.singlepars,app.data.defaultopt); 
    var left_opts = updateFromUrl(app.data.dualpars,app.data.defaultopt);
    // objeto que especifica si la opcion se usa o no
    single_opts.tools = false;
    var single_used = {
      tools: true,  layer: true, asset: single_opts.layer, property: single_opts.layer,
      inset:  true, insetPos: single_opts.inset, legends: true, legendsPos: single_opts.legends,
      iitem: true, citem: true, iitem2: single_opts.split, citem2: single_opts.split,
      normalize: single_opts.split, comparison: left_opts.normalize,  
      inspector: true, timeseries: single_opts.inspector, spectrum: single_opts.inspector, 
      marker: single_opts.inspector, histogram: single_opts.inspector, profile: single_opts.inspector,
      lon: true,  lat: true, zoom: true, split: true,
    };
    var left_used = {
      mapType: true,
      index: true, collection: true, date: true, startDate: true, endDate: true, period: true, reducer: true,
      cloudFilter: true, cloudMask: true, maxCloud: left_opts.cloudFilter,
      rescale: left_opts.texture, rescaleMin: left_opts.rescale | left_opts.mask, rescaleMax: left_opts.rescale | left_opts.mask,
      texture: true, descriptor: left_opts.texture,  kernel:  left_opts.texture, 
      mask: true, invert: left_opts.mask, threshold: left_opts.mask, 
      copacity: left_opts.copacity !== 1, iopacity: left_opts.iopacity !== 1, ibands: false, cbands: true, imin: true, cmin: true, imax: true, cmax: true,
      ipalette: true, ireverse: left_opts.ipalette !== undefined, cpalette: true, creverse: left_opts.cpalette !== undefined, igamma: left_opts.igamma !== 1, cgamma: left_opts.cgamma !== 1
    };  
    // incluye en el URL si es diferente del valor por default, esta definido y se usa
    // opciones singulares
    app.data.singlepars.map(function(k){
      if(single_opts[k] !== app.data.defaultopt[k] && single_opts[k] !== undefined && single_opts[k] !== '' && single_used[k] === true)
        url = url + k.toLowerCase() + '=' + single_opts[k] + ';';
      });
    // opciones duales del panel izquierdo
    app.data.dualpars.map(function(k){
      if(left_opts[k] !== app.data.defaultopt[k] && left_opts[k] !== undefined && left_opts[k] !== '' && left_used[k])
        url = url + k.toLowerCase() + '=' + left_opts[k] + ';';
      });
    // opciones duales del panel derecho
    if(single_opts.split) {
       var right_opts = updateFromUrl(app.data.dualpars,app.data.defaultopt,{},'_');
      var right_used = {
        mapType: true,
        index: true, collection: true, date: true, startDate: true, endDate: true, period: true, reducer: true,
        cloudFilter: true, cloudMask: true, maxCloud: right_opts.cloudFilter,
        rescale: right_opts.texture, rescaleMin: right_opts.rescale | right_opts.mask, rescaleMax: right_opts.rescale | right_opts.mask,
        texture: true, descriptor: right_opts.texture,  kernel:  right_opts.texture, 
        mask: true, invert: right_opts.mask, threshold: right_opts.mask, 
        copacity: right_opts.copacity !== 1, iopacity: right_opts.iopacity !== 1, ibands: false, cbands: true, imin: true, cmin: true, imax: true, cmax: true,
        ipalette: true, ireverse: right_opts.ipalette !== undefined, cpalette: true, creverse: right_opts.cpalette !== undefined, igamma: right_opts.igamma !== 1, cgamma: right_opts.cgamma !== 1
      };       
       app.data.dualpars.map(function(k){
         if(right_opts[k] !== app.data.defaultopt[k] && right_opts[k] !== undefined && right_opts[k] !== '' && right_used[k])
           url = url + k.toLowerCase() + '_=' + right_opts[k] + ';';
      });
    }
    app.control.explore.urlText
      .setValue('Right-click & copy URL')
      .setUrl(url);
  });
// habilita panel doble
app.toolBar.duplicate.onChange(
  function(state,widget){
    var mapType =app.control.explore.mapType.getValue();
    print(state)
    var checked = (state === 1);
    // muestra/oculta la opción de legenda del indice y compuesto
    app.toolBar.swap.setDisabled(!checked);
    app.control.explore.iitem2.style().set({shown: checked});
    app.control.explore.citem2.style().set({shown: checked});
    ui.url.set('split',checked);
    // si se habilita el duplicado
    if(checked) {
      // aborta si no hay compuesto
      if(!app.data.layer.composite.image)
        return;
     // actualiza posicion del mapa copia
     print(eTime() + ': duplicating map...');  // para monitoreo
     app.map.main.getCenter().coordinates()
      .evaluate(function(center){
        // refresca el mapa ligado
        app.map.linker.get(0).setCenter(center[0],center[1]);
        app.map.linker.get(0).setOptions(mapType); 
        app.map.linker.get(1).setOptions(mapType); 
        // reemplaza un panel por dos paneles
        app.map.panel.widgets().set(0,app.map.split);
      });
      // copia compuesto del panel principal
      app.map.layer.composite2 = ui.Map.Layer({
        eeObject: app.map.layer.composite.getEeObject(), 
        visParams: app.map.layer.composite.getVisParams(),
        name: app.map.layer.composite.getName(), 
        shown: app.map.layer.composite.getShown(), 
        opacity: app.map.layer.composite.getOpacity()
      });
      app.map.layer.index2 = ui.Map.Layer({
        eeObject: app.map.layer.index.getEeObject(), 
        visParams: app.map.layer.index.getVisParams(),
        name: app.map.layer.index.getName(), 
        shown: app.map.layer.index.getShown(), 
        opacity: app.map.layer.index.getOpacity()
      });
      app.map.copy.layers().reset([
        app.map.layer.composite2,
        app.map.layer.index2
        ]); 
      // actualiza panel de legendas
      app.map.legends.index2.config.title.setValue(app.map.layer.index.getName());
      app.map.legends.composite2.config.title.setValue(app.map.layer.composite.getName());
      // habilita la comparación y scatterplot
      app.control.operator.compare.setDisabled(false);
      app.dialog.queryOpts.scatterplot.setDisabled(false);
      app.control.explore.index2.setLabel(app.map.layer.index.getName());
      app.control.explore.composite2.setLabel(app.map.layer.composite.getName());
      app.control.explore.index2.setValue(app.map.layer.index.getShown());
      app.control.explore.composite2.setValue(app.map.layer.composite.getShown());
      // espera un segundo antes de actualizar la legenda
      ui.util.setTimeout(function(){
        updateLegends(0);
      },app.data.startUpDelayStep*(1+app.data.option.texture));
      var left = updateFromUrl(app.data.dualpars,app.data.defaultopt);
      setUrl(app.data.dualpars,left,'_');     
    } else {
      app.map.linker.get(1).getCenter().coordinates()
        .evaluate(function(center){
          // refresca el mapa no ligado
          app.map.main.setCenter(center[0],center[1]);
          app.map.main.setOptions(app.control.explore.mapType.getValue());
          // reemplaza los dos paneles por un panel
          app.map.panel.widgets().set(0,app.map.main);
        });
      //app.map.main.centerObject(app.map.copy.getCenter(),app.map.copy.getZoom());
      // borra las capas del mapa secundario
      app.map.copy.layers().reset([]);
      // Desabilita la comparación y escatterplot
      app.control.operator.compare.setValue(false).setDisabled(true);
      app.dialog.queryOpts.scatterplot.setValue(false).setDisabled(true);
      // deshabilita la leyenda del panel secundario
      app.control.explore.index2.setValue(false);
      app.control.explore.composite2.setValue(false);
      setUrl(app.data.dualpars,app.data.defaultopt,'_');
    }
    updateInsetPos(app.toolBar.insetPos.getState());
    updateLegendsPos(app.toolBar.legendsPos.getState());
    resetUrl();
  }
);
//intercambia capas entre dos paneles
app.toolBar.swap.onClick(
  function(widget){
    // actualiza el panel derecho
     app.map.layer.composite2 = ui.Map.Layer({
        eeObject: app.map.layer.composite.getEeObject(), 
        visParams: app.map.layer.composite.getVisParams(),
        name: app.map.layer.composite.getName(), 
        shown: app.map.layer.composite.getShown(), 
        opacity: app.map.layer.composite.getOpacity()
      });
      app.map.layer.index2 = ui.Map.Layer({
        eeObject: app.map.layer.index.getEeObject(), 
        visParams: app.map.layer.index.getVisParams(),
        name: app.map.layer.index.getName(), 
        shown: app.map.layer.index.getShown(), 
        opacity: app.map.layer.index.getOpacity()
      });
      app.map.copy.layers().reset([
        app.map.layer.composite2,
        app.map.layer.index2
        ]);
    app.control.explore.index2.setLabel(app.map.layer.index.getName());
    app.control.explore.composite2.setLabel(app.map.layer.composite.getName());
    updateLegends(0);   
    // intercambia los parametros del url
    var left = updateFromUrl(app.data.dualpars,app.data.defaultopt);
    var right = updateFromUrl(app.data.dualpars,app.data.defaultopt,{},'_');
    setUrl(app.data.dualpars,left,'_');
    setUrl(app.data.dualpars,right);
    // actualiza controles
    resetUrl();
    // actualiza opciones
    copyOpts(app.data.dualpars,right,app.data.option);
    updateControls();
    // en este punto ya se debio realizar el intercambio de valores del url
    app.control.index.filterTags
      .setValue(null,false)
      .setValue('All');
      //updateLegends(1);
  });
/********** Download Data **********/
var showDownloadPanel = function(value,widget) {
  // borra los callbacks previos
  app.drawingTools.unlisten();
  app.control.download.panel.style().set('shown',value);
  //app.toolBar.centerArea.setDisabled(!value);
  //app.toolBar.centerView.setDisabled(!value);
  app.toolBar.centerArea.style().set({shown: value});
  app.toolBar.centerView.style().set({shown: value});
  if (!value) {
     // reestablece consulta de propiedad de grometría    
    app.drawingTools.reset();
    app.drawingTools.onSelect(showGeomInfo);
    // oculta el área de descarga
    if (app.data.layer.downloadArea)
      app.data.layer.downloadArea.setShown(false);    
    return;
  }
  print(eTime() +': opening download panel...');  
  // para cualquier consulta en progreso
  app.toolBar.queryIcon.setState(0);
  if (app.data.layer.downloadArea) {
  // muestra área de descarga y centra el mapa en ella
    app.data.layer.downloadArea.setShown(true);
    app.map.main.centerObject(app.data.layer.downloadArea.geometries().get(0));
    app.drawingTools
        .setSelected(app.data.layer.downloadArea)
        .edit();
    return;    
  }
  // Crea área de descarga si no existe
  app.dialog.message.style().set({shown: true});
  app.dialog.message.widgets().reset([ui.Label('Updating geometry layers...')]);
  // usa los limites del mapa
  var bounds = app.map.main.getBounds();
  // crea la geometría asíncronamente
  app.map.main.getCenter()
    .coordinates()
    .evaluate(function(center){
      var rect = [
        (bounds[0]-center[0])*0.5+center[0],
        (bounds[1]-center[1])*0.5+center[1],
        (bounds[2]-center[0])*0.5+center[0],
        (bounds[3]-center[1])*0.5+center[1]
      ];
      // agrega la capa a la herramienta de dibujo
      app.data.layer.downloadArea = app.drawingTools.addLayer({
        name: DOWNLOAD_AREA_ID,
        color: 'cyan',
        geometries: [],
      });
      app.data.layer.downloadArea.geometries()
        .set(0,ee.Geometry.BBox(rect[0],rect[1],rect[2],rect[3]));
      var box = [
        [rect[0],rect[1]],
        [rect[2],rect[1]],
        [rect[2],rect[3]],
        [rect[0],rect[3]],
        [rect[0],rect[1]]
      ];
      // actualiza el selector de escala
      var geom = geometryProps(box);
      var scale = Math.max(geom.width/app.control.download.cols.getValue(),geom.height/app.control.download.rows.getValue());
      scale = Math.min(Math.max(scale,app.control.download.scale.getMin()),app.control.download.scale.getMax());
      app.drawingTools
        .setSelected(app.data.layer.downloadArea)
        .edit();
      app.drawingTools.onEdit(ui.util.debounce(updateDownloadArea, 500));  
      app.drawingTools.onErase(ui.util.debounce(closeDownload,500));
      app.dialog.message.style().set({shown: false});    
            // actualiza la escala y las dimensiones
      app.control.download.scale.setValue(scale,false);
      updateDownloadSize(app.control.download.scale.getValue()); 
    });
};
app.control.download.header.onClick(showDownloadPanel);
function resetDownloadUrls(){
  app.control.download.index
    .setValue('Download Index Image (TIF)')
    .setUrl('')
    .style().set(ROW_STYLE);
  app.control.download.composite
    .setValue('Download Composite image (TIF)')
    .setUrl('')
    .style().set(ROW_STYLE);
  app.control.download.samples
    .setValue('Download Geometry layers (KML)')
    .setUrl('')
    .style().set(ROW_STYLE);
  app.control.download.video
    .setValue('Open Index animation (GIF)')
    .setUrl('')
    .style().set(ROW_STYLE);
}
// construye la colección a partir de las geometrias editadas
var getSampleFeatures = function(scale,index){
    return ee.FeatureCollection(
      geometries.getShownLayers(app.drawingTools,'')
      //app.drawingTools.layers().getJsArray()
        .map(function(geometryLayer){ 
          var name = geometryLayer.getName();
          var geometry = geometryLayer.toGeometry();
          var dict = app.data.layer.index.image.reduceRegion({
            geometry: geometry,
            reducer: ee.Reducer.mean()
              .setOutputs(['mean' + index]),
            scale: scale,
            maxPixels: images.MaxPixels,
            bestEffort: true,
            crs: app.data.defaultProj, 
          }).set('LayerName',name);
          return ee.Feature(geometry,dict);
        })).filterBounds(app.data.layer.downloadArea.geometries().get(0));
  };
// retorna las dimensiones del area de descarga
var geometryProps = function(verts){
  var bounds = verts[0].concat(verts[2]);
  var center = [(bounds[0]+bounds[2])/2,(bounds[1]+bounds[3])/2];
  var height = ee.Geometry.Point(verts[1])
    .distance(ee.Geometry.Point(verts[2]))
    .getInfo();
  var width =  ee.Geometry.Point(verts[0])
    .distance(ee.Geometry.Point(verts[1]))
    .getInfo();
  return {
    bounds: bounds,
    center: center,
    height: height,
    width: width
  };
};
// actualiza tamaño de descarga al cambiar la escala
var updateDownloadSize = function(scale){
  print(eTime() + ': updating download image size...');
  app.control.download.rowsPanel.widgets().reset([
    ui.Label('Rows (pixels):',ROW_STYLE),
    ui.Label('updating...',INFO_STYLE)]);
  app.control.download.colsPanel.widgets().reset([
    ui.Label('Columns (pixels):',ROW_STYLE),
    ui.Label('updating...',INFO_STYLE)]);
  app.drawingTools.unlisten();
  app.data.layer.downloadArea
    .geometries()
    .get(0)
    .bounds()
    .coordinates()
    .get(0)
    .evaluate(function(verts) {
  var geom = geometryProps(verts);
  var maxCols = app.control.download.cols.getMax();
  var minCols = app.control.download.cols.getMin();
  var maxRows = app.control.download.rows.getMax();
  var minRows = app.control.download.rows.getMin();
  var cols = Math.round(geom.width / scale);
  var rows = Math.round(geom.height / scale);
  if(cols < minCols || cols > maxCols || rows < minRows || rows > maxRows) {
    var xscale = Math.max(Math.min(cols,maxCols),minCols) / cols;
    var yscale = Math.max(Math.min(rows,maxRows),minRows) / rows;
    var rect = [
      (geom.bounds[0]-geom.center[0])*xscale+geom.center[0],
      (geom.bounds[1]-geom.center[1])*yscale+geom.center[1],
      (geom.bounds[2]-geom.center[0])*xscale+geom.center[0],
      (geom.bounds[3]-geom.center[1])*yscale+geom.center[1]
      ];
      app.data.layer.downloadArea.geometries()
        .set(0,ee.Geometry.BBox(rect[0],rect[1],rect[2],rect[3]));
    cols = Math.max(Math.min(cols,maxCols),minCols);
    rows = Math.max(Math.min(rows,maxRows),minRows);
  }
  app.control.download.rowsPanel.widgets().reset([
    ui.Label('Rows (pixels):',ROW_STYLE),
    app.control.download.rows]);
  app.control.download.colsPanel.widgets().reset([
    ui.Label('Columns (pixels):',ROW_STYLE),
    app.control.download.cols]);
  app.control.download.cols.setValue(cols,false);
  app.control.download.rows.setValue(rows,false);
  app.drawingTools.onEdit(ui.util.debounce(updateDownloadArea, 500));  
  app.drawingTools.onErase(ui.util.debounce(closeDownload,500));
  resetDownloadUrls();
  });
};
// actualiza area de descarga
var updateDownloadArea = function(geometry,layer,dt){
  if(layer.getName() != DOWNLOAD_AREA_ID)
    return;
  print(eTime() + ': updating download image extent...');
  app.drawingTools.unlisten();
   app.data.layer.downloadArea
    .geometries()
    .get(0)
    .bounds()
    .coordinates()
    .get(0)
    .evaluate(function(box){
  var geom = geometryProps(box);
  // valida que el tamaño no supere el tamaño en pixeles
  var maxWidth = app.control.download.cols.getMax() * app.control.download.scale.getMax();
  var maxHeight = app.control.download.rows.getMax() * app.control.download.scale.getMax();
  var minWidth = app.control.download.cols.getMin() * app.control.download.scale.getMin();
  var minHeight = app.control.download.rows.getMin() * app.control.download.scale.getMin();
  // forza el ajuste del área
  if (geom.width < minWidth || geom.width > maxWidth || geom.height < minHeight || geom.height > maxHeight) {
    var xscale = Math.max(Math.min(geom.width,maxWidth),minWidth) / geom.width;
    var yscale = Math.max(Math.min(geom.width,maxWidth),minWidth) / geom.height;
    var rect = [
      (geom.bounds[0]-geom.center[0])*xscale+geom.center[0],
      (geom.bounds[1]-geom.center[1])*yscale+geom.center[1],
      (geom.bounds[2]-geom.center[0])*xscale+geom.center[0],
      (geom.bounds[3]-geom.center[1])*yscale+geom.center[1]
      ];
      app.data.layer.downloadArea.geometries()
        .set(0,ee.Geometry.BBox(rect[0],rect[1],rect[2],rect[3]));
  }
  updateDownloadSize(app.control.download.scale.getValue());
  app.drawingTools.onEdit(ui.util.debounce(updateDownloadArea, 500));    
  app.drawingTools.onErase(ui.util.debounce(closeDownload,500));
  });
};
// actualiza el slider de resolución
var updateScaleSlider = function(){
  app.control.download.scalePanel.widgets().reset([
    ui.Label('updating...') 
    ]); 
  var minScale = Math.round(100*app.data.layer.index.scale.getInfo()) / 100;
  app.control.download.scale = ui.Slider({
    min: minScale,
    max: 100*minScale,
    step: minScale,
    style: ROW_STYLE,
    onChange: updateDownloadSize
  });
  app.control.download.scalePanel.widgets().reset([
    ui.Label('Pixel size (meters):',ROW_STYLE),
    app.control.download.scale,
    ],ROW_STYLE);
  resetDownloadUrls();
};
// actualiza renglones de imagen de descarga
app.control.download.rows.onChange(
  function(rows){
  print(eTime() + ': updating download image rows...');
  app.dialog.message.style().set({shown: true});
  app.dialog.message.widgets().reset([ui.Label('Updating geometry layers...')]);
  app.drawingTools.unlisten();
   app.data.layer.downloadArea
    .geometries()
    .get(0)
    .bounds()
    .coordinates()
    .get(0)
    .evaluate(function(box){
  var geom = geometryProps(box);
  var yscale = rows * app.control.download.scale.getValue() / geom.height;
  var rect = [
    geom.bounds[0],
    (geom.bounds[1]-geom.center[1])*yscale+geom.center[1],
    geom.bounds[2],
    (geom.bounds[3]-geom.center[1])*yscale+geom.center[1],
  ];
  app.data.layer.downloadArea.geometries()
    .set(0,ee.Geometry.BBox(rect[0],rect[1],rect[2],rect[3]));
  app.drawingTools.onEdit(ui.util.debounce(updateDownloadArea, 500));  
  app.drawingTools.onErase(ui.util.debounce(closeDownload,500));
  app.dialog.message.style().set({shown: false});
    });
  resetDownloadUrls();
});
// actualiza numero columnas de imagen de descarga
app.control.download.cols.onChange(
  function(cols){  
  print(eTime() + 'updating download image cols...');
  app.dialog.message.style().set({shown: true});
  app.dialog.message.widgets().reset([ui.Label('Updating geometry layers...')]);
  app.drawingTools.unlisten();
  app.data.layer.downloadArea
    .geometries()
    .get(0)
    .bounds()
    .coordinates()
    .get(0)
    .evaluate(function(box){
  var geom = geometryProps(box);
  var xscale = cols * app.control.download.scale.getValue() / geom.width;
  var rect = [
    (geom.bounds[0]-geom.center[0])*xscale+geom.center[0],
    geom.bounds[1],
    (geom.bounds[2]-geom.center[0])*xscale+geom.center[0],
    geom.bounds[3]
  ];
  app.data.layer.downloadArea.geometries()
    .set(0,ee.Geometry.BBox(rect[0],rect[1],rect[2],rect[3]));
  app.drawingTools.onEdit(ui.util.debounce(updateDownloadArea, 500));  
  app.drawingTools.onErase(ui.util.debounce(closeDownload,500));
  app.dialog.message.style().set({shown: false});
    });
  resetDownloadUrls();
});
// Centra el área de descarga a la vista del mapa
app.toolBar.centerArea.onClick(
  function(but){
    app.drawingTools.layers().remove(app.data.layer.downloadArea);
    resetDownloadUrls();
    app.data.layer.downloadArea = null;
    app.control.download.setState(0);
    app.control.download.setState(1);
    });
app.toolBar.centerView.onClick(
  function(but){
    app.map.main.centerObject(app.data.layer.downloadArea.toGeometry());
    });
// cierra panel de descarga
var closeDownload = function(geometry,layer,dt){
  if(layer.getName() != DOWNLOAD_AREA_ID)
    return;
  print(eTime() + 'closing download panel...');
  dt.layers().remove(layer);
  app.data.layer.downloadArea = null;
  app.control.download.toggle.click(); // simula un click 
};
// actualiza liga de descarga del indice
app.control.download.indexRefresh
  .onClick(function(){
  if(!app.data.layer.index.image) return;
  var index = getIndexAcronym(app.control.index.selector.getValue());
  var url = null;
  var scale = app.control.download.scale.getValue();
  var region = app.data.layer.downloadArea.geometries().get(0);
  var dimensions = [app.control.download.cols.getValue(),app.control.download.rows.getValue()];
  var totalMbytes = dimensions[0] * dimensions[1] * 4 / Math.pow(2,20);
  if (totalMbytes <= 32) {
    app.control.download.index.setValue('updating...');
      //.style().set('color','black');
    var indexFileName = index + '_' + 
      app.data.layer.composite.name.replace(/ /gi,'_')  + '_' + scale.toFixed(0) + 'm';  
    url = app.data.layer.index.image.float().getDownloadURL({
      name: indexFileName,
      region: region,
      dimensions: dimensions,
      crs: app.data.defaultProj, 
      filePerBand: false,      
    });
    ee.String(url).evaluate(function(url_index){
      app.control.download.index
        .setValue('Download Index image (TIF, ' + totalMbytes.toFixed(2) + ' MB) 🢃')
        .setUrl(url_index)
        .style().set('color','blue');
    });
  } else
      app.control.download.index
        .setValue('Download Index image (TIF, +32 MB!)')
        .setUrl(url).style()
        .set('color','red');
});
// actualiza liga de descarga del compuesto
app.control.download.compositeRefresh
  .onClick(function(){
  if(!app.data.layer.composite.image) return;
  var sensorID = app.control.composite.collections.getValue();
  var scale = app.control.download.scale.getValue();
  var region = app.data.layer.downloadArea.geometries().get(0);
  var dimensions = [app.control.download.cols.getValue(),app.control.download.rows.getValue()];
  var numBands = images.SensorsList[sensorID].mappedBandNames.length;
  var totalMbytes = dimensions[0] * dimensions[1] * 4 * numBands / Math.pow(2,20);
  if (totalMbytes <= 32) {
    app.control.download.composite
        .setValue('updating...');
        //.style().set('color','black');
    var compositeName = app.data.layer.composite.name.replace(/ /gi,'_') + '_' + scale.toFixed(0) + 'm';      
    //app.control.download.index.setValue('Udating...');
    url = app.data.layer.composite.image.getDownloadURL({
      name: compositeName,
      dimensions: dimensions,
      region: region,
      crs: app.data.defaultProj,      
      filePerBand: false,
    });
    ee.String(url).evaluate(function(url_composite){
      app.control.download.composite
        .setValue('Download Composite image (TIF, ' + totalMbytes.toFixed(2) + 'MB) 🢃')
        .setUrl(url_composite).style()
        .set('color','blue');
    });
  } else 
    app.control.download.composite
      .setValue('Download Composite image (TIF, +32 MB!)')
      .setUrl(url).style()
      .set('color','red');
});
// actualiza liga de descarga de geometrías
app.control.download.samplesRefresh
  .onClick(function(){
  var url = null;
  var index = getIndexAcronym(app.control.index.selector.getValue());
  var scale = app.control.download.scale.getValue();
  if (app.drawingTools.layers().getJsArray().length) {
    app.control.download.samples
      .setValue('updating...')
      .setUrl(url);
      //.style().set('color','black');
    var sampFileName = index + '_' + 
      app.data.layer.composite.name.replace(/ /gi,'_');  
    url = getSampleFeatures(scale,index).getDownloadURL({
        format: 'KML',
        filename: sampFileName,
    }); 
    ee.String(url).evaluate(function(url_samples){
      app.control.download.samples
        .setValue('Download Geometry layers (KML) 🢃')
        .setUrl(url_samples)
        .style().set('color','blue');
    });
  } else
    app.control.download.samples
      .setUrl(url)
      .style().set('color','red');
});
// Generación del video a partir de la colección seleccionada
app.control.download.videoRefresh
  .onClick(function(){    
    if(!app.data.layer.composite.image) return;
    app.control.download.videoRefresh.setDisabled(true);
    var url = null;
    // incializa etiqueta
    app.control.download.video
      .setValue('updating...')
      .setUrl(url);
      //.style().set('color','black');
    var sensorID = app.control.composite.collections.getValue();
    var region = app.data.layer.downloadArea.geometries().get(0).bounds();
    var dimensions = [app.control.download.cols.getValue(),app.control.download.rows.getValue()];
    var frames = app.control.download.frames.getValue();
    var reducer = app.data.colReducers[app.dialog.timeSlice.reducer.getValue()];
    var scale = app.control.download.scale.getValue();
    var startDate = new Date(app.dialog.timeSlice.starDate.getValue()).getTime();
    var endDate = new Date(app.dialog.timeSlice.endDate.getValue()).getTime();
    var dateRange = ee.DateRange(startDate,endDate);
    var index = getIndexAcronym(app.control.index.selector.getValue());
    var cloudMask = app.dialog.timeSlice.cloudMask.getValue();
    var periodUnits = app.dialog.timeSlice.periodUnit.getValue();
    var period = app.dialog.timeSlice.period.getValue() * app.data.periodFactors[periodUnits];    
    var grouping = {refDate:startDate,period:period,periodUnit: 'day'};
    var applyMask = app.control.operator.mask.getValue();
    var invertMask = app.control.operator.invertMask.getValue();
    var threshold = app.control.operator.threshold.getValue();
    var masking = {applyMask:applyMask,invertMask:invertMask,threshold:threshold};
    // define anotaciones del video
    var annotations = [{
        position: 'left', offset: '1%', margin: '1%', property: 'label', scale: app.map.main.getScale() * 2
      }];
   var videoArgs = {
        dimensions: dimensions,
        region: region,
        crc: 'EPSG:3857',
        framesPerSecond: frames
      };
    var title = ee.String(sensorID + ' ' + index + ' ');
    // imagen base a partir de capas vectoriales visibles
    var overlayImage = ee.Image(0).selfMask();
    if(app.toolBar.loadLayer.getState())
      overlayImage = ee.FeatureCollection(app.dialog.loadLayer.asset.getValue())
         .filterBounds(app.data.layer.downloadArea.geometries().get(0))
         .style({color: 'white', fillColor: '00000000'});
    var baseImage, cvisParams, ivisParams;
    //if(app.control.explore.duplicate.getValue()) {
    if(app.toolBar.duplicate.getState()) {
      cvisParams = app.map.layer.composite2.getVisParams();
      baseImage = app.map.layer.composite2.getEeObject();
    } else {
      cvisParams = app.map.layer.composite.getVisParams();
      baseImage = app.data.layer.composite.image
    }
    delete cvisParams.name
    delete cvisParams.reverse
    baseImage = baseImage.visualize(cvisParams);
    var ivisParams = app.map.layer.index.getVisParams();
    delete ivisParams.name
    delete ivisParams.reverse
    // crea colección del video
    var videoFrames = images.collection(sensorID,dateRange,app.data.layer.composite.maxCloud,region)
      .makeComposites(grouping,reducer,cloudMask)
      .mapIndex(index,masking)
      .map(function(img){
        var date = ee.Date(img.get('system:time_start')).format(app.data.dateFormatLong);
        var label = title.cat(date);
        var rgbVis = baseImage
          .blend(img.visualize(ivisParams))
          .blend(overlayImage)
          .set('label',label);
        return text.annotateImage(rgbVis,{},region,annotations)
          .copyProperties(img,['system:time_start']);
      })
      .getVideoThumbURL(videoArgs, function(url_video,err){  
        app.control.download.videoRefresh.setDisabled(false);
        if(url_video === "") {
          app.control.download.video
          .setValue(err)
          .style().set('color','red');
          return;
        }
        app.control.download.video
          .setValue('Open Index animation (GIF) 🢅')
          .setUrl(url_video)
          .style().set('color','blue');
      });
  });
/*********************************************
             Inicialización
**********************************************/
var getVisParams = function(prefix){
    var visParams = {};
    var index = app.data.option.index;
    var texture = app.data.option.texture;
    var descriptor = app.data.option.descriptor;
    var split = app.data.option.split;
    var comparison = app.data.option.comparison;
    var bands = app.data.option[prefix+'bands'];
    var min = app.data.option[prefix+'min'];
    var max = app.data.option[prefix+'max'];
    var gamma = app.data.option[prefix+'gamma'];
    var palette = app.data.option[prefix+'palette'];
    var reverse = app.data.option[prefix+'reverse'];
    if(!bands & !min & !max)
      return null;
    if(bands) 
      visParams.bands = bands.match(/[^,]+/g);
    else
      visParams.bands = [0];
    if(min)
      visParams.min = min.match(/[^,]+/g)
        .map(function(n){return Number(n);});
    if(max)
      visParams.max = max.match(/[^,]+/g)
        .map(function(n){return Number(n);});
    if(visParams.bands.length == 3) {
      if(gamma)
        visParams.gamma = gamma;
    } else
       if(palette) {
        if(palette != 'imported') { // specified palette name
          visParams.name = palette;
          visParams.palette = images.Palettes[visParams.name];
        } else {// default comparison palette
          if(split & comparison) {
            visParams.name = images.Comparisons[comparison].visParams.name;
            visParams.palette = images.Comparisons[comparison].visParams.palette;
          } else {
            if(texture){ // default texture palette
              visParams.name = images.SF[descriptor].visParams.name;
              visParams.palette = images.SF[descriptor].visParams.palette;
            }else { // default index palette
              visParams.name = images.SI[index].visParams.name;
              visParams.palette = images.SI[index].visParams.palette;
            }  
          }
        }
        if(reverse) {
          visParams.palette.reverse();
          visParams.reverse = reverse;
        }
      } else // no palette
        if(gamma)
          visParams.gamma = gamma;
    if(visParams.min.length == 1)
      visParams.min = visParams.min[0];
    if(visParams.max.length == 1)
      visParams.max = visParams.max[0];
    return visParams;
};
// copia opciones de un objeto a otro
function copyOpts(list,from,to){
  list.map(function(k){
    to[k] = from[k];
  });
  return to;
}
// Resetea controles al cambio del url
function resetUrl(){
  app.control.explore.urlText.setValue(app.data.text.mapUrl).setUrl('');
}
// escribe lista de parametros al url
function setUrl(list,opts,suffix){
  suffix = suffix || '';
  list.map(function(k){
    ui.url.set(k.toLowerCase()+suffix,opts[k]);
  });
}
// Actualiza loc controles a partir de las opciones de los paneles
function updateControls(opt){
  opt = opt || app.data.option;
  // inicializa Composite
  var period = getPeriod(opt.period);
  app.control.index.selector.setValue(null,false);
  app.control.composite.collection.setValue(null,false).setUrl('');
  app.control.composite.dateSlider.setValue(opt.date,false);
  app.dialog.timeSlice.period.setValue(period.val,false);
  app.dialog.timeSlice.periodUnit.setValue(period.unit,false);
  if(opt.startDate)
    app.dialog.timeSlice.starDate.setValue(dateStr(opt.startDate,app.data.dateFormatLong),false);
  if(opt.endDate)
    app.dialog.timeSlice.endDate.setValue(dateStr(opt.endDate,app.data.dateFormatLong),false);
  app.dialog.timeSlice.reducer.setValue(opt.reducer,false);
  app.dialog.timeSlice.cloudMask.setValue(opt.cloudMask,false);
  app.dialog.timeSlice.cloudFilter.setValue(opt.cloudFilter,false);
  app.dialog.timeSlice.maxCloud.setValue(opt.maxCloud,false);
  // inicializa Advanced Operations
  app.control.operator.maskOptions.style().set({shown: opt.mask});  
  app.control.operator.textureOptions.style().set({shown: opt.texture});
  app.control.operator.mask.setValue(opt.mask,false);
  app.control.operator.invertMask.setValue(opt.invert,false);
  app.control.operator.threshold.setValue(opt.threshold,false);
  app.control.operator.texture.setValue(opt.texture,false);  
  app.control.operator.selector.setValue(images.SF[opt.descriptor].name,false);
  app.control.operator.kernel.setValue(opt.kernel,false);
  app.control.operator.rescale.setValue(opt.rescale,false);
  app.control.operator.rescaleMin.setValue(opt.rescaleMin,false);
  app.control.operator.rescaleMax.setValue(opt.rescaleMax,false);
  app.control.operator.textureOptions.style().set({shown: opt.texture});
  app.control.operator.maskOptions.style().set({shown: opt.mask});  
};
// extrae lista de parametros del url
function updateFromUrl(list,defaultopts,opts,suffix){
  suffix = suffix || '';
  opts = opts || {};
  list.map(function(k){
    opts[k] = ui.url.get(k.toLowerCase()+suffix,defaultopts[k]);
  });
  return opts;
}
function getOptionsFromUrl(){
  app.data.option = updateFromUrl(app.data.singlepars,app.data.defaultopt);
  if(app.data.option.split) {
    app.data.dualopt = updateFromUrl(app.data.dualpars,app.data.defaultopt); // salva las opciones del panel izquierdo
    updateFromUrl(app.data.dualpars,app.data.defaultopt,app.data.option,'_'); // usa opciones del panel derecho
    setUrl(app.data.dualpars,app.data.option); // actualiza opciones 
  } else
    updateFromUrl(app.data.dualpars,app.data.defaultopt,app.data.option); // usa opciones del panel izquierdo
  app.data.option.cvisParams = getVisParams('c');
  app.data.option.ivisParams = getVisParams('i');
}
// inicia controles generales
function initControls(){  
  app.control.index.filterTags.items().reset(app.data.indexTags); // agrega los tags al selector
  app.control.explore.index.setValue(app.data.option.iitem);
  app.control.explore.composite.setValue(app.data.option.citem);
  app.toolBar.swap.setDisabled(!app.data.option.split);
  app.toolBar.showMapTools.setState(app.data.option.tools*1);
  app.control.explore.showMapTypes.setValue(app.data.option.tools);
  app.control.explore.showLayerList.setValue(app.data.option.tools);
  app.toolBar.queryIcon.setState(app.data.option.inspector*1);
  app.control.operator.compare.setDisabled(true)
    .setValue(false,false);
  app.control.operator.compareOptions.style().set({shown: false});
  app.control.operator.comparison.setValue(app.data.option.comparison,false);
  app.dialog.queryOpts.scatterplot.setDisabled(true);
  app.dialog.queryOpts.timeseries.setValue(app.data.option.timeseries,false);
  app.dialog.queryOpts.spectrum.setValue(app.data.option.spectrum,false);
  app.dialog.queryOpts.keepMarker.setValue(app.data.option.marker,false);
  app.control.explore.mapType.setValue(app.data.option.mapType);
  // oculta controles
  if(!app.data.option.tools)
    app.toolBar.showControlPanel.toggles();    
}
/***********************/
t0 = new Date(); // tiempo de referencia
getOptionsFromUrl(); // define las opciones de inicio a partir del URL
initControls(); // inicializa controles
updateControls(app.data.option); // actualiza otros controles desde opciones duales
// configura las capas
app.map.layer.index.setShown(app.data.option.iitem);
app.map.layer.composite.setShown(app.data.option.citem);
app.map.layer.index2.setShown(app.data.option.iitem2);
app.map.layer.composite2.setShown(app.data.option.citem2);
app.map.main.setCenter(app.data.option.lon,app.data.option.lat,app.data.option.zoom);
/*
var baseChange = [{featureType: 'all', stylers: [{invert_lightness: true}]}];
app.map.main.setOptions('baseChange', {'baseChange': baseChange});
*/
/***********/
// desencadena los eventos de actualización del mapa principal
app.control.index.filterTags
  .setValue('All');
// estima el retraso cuando se incia con doble panel
var delay_split = app.data.option.split*app.data.startUpDelayStep*(16+2*app.data.option.texture+2*app.data.option.mask);
//app.control.explore.duplicate.setValue(app.data.option.split,false);
if(app.data.option.split) {
  // espera unos segundos para que termine el mapa principal 
  ui.util.setTimeout(function(){
    // desencadena la copia del mapa principal
    app.toolBar.duplicate.setState(1); 
    // transfiere las opciones para el nuevo mapa principal
    copyOpts(app.data.dualpars,app.data.dualopt,app.data.option); 
    app.control.explore.index2.setValue(app.data.option.iitem2);
    app.control.explore.composite2.setValue(app.data.option.citem2);
    app.data.option.cvisParams = getVisParams('c');
    app.data.option.ivisParams = getVisParams('i');
    setUrl(app.data.dualpars,app.data.option);
    updateControls(app.data.option);
    app.control.operator.compare.setDisabled(false)
      .setValue(app.data.option.normalize,false);
      app.control.operator.compareOptions.style().set({shown: app.data.option.normalize});
      // vuelve a actualizar el mapa principal con las nuevas opciones
    print(eTime() +': selecting index again...');
    app.control.index.selector.setValue(images.SI[app.data.option.index].name);
  },delay_split);
}
var delay_total = delay_split+app.data.startUpDelayStep*(30+app.data.option.texture+2*app.data.option.mask+app.data.option.normalize);
ui.util.setTimeout(function(){
  app.toolBar.queryIcon.setState(app.data.option.inspector * 1); 
  if(app.data.option.inspector){
    var point = ee.Geometry.Point([app.data.option.lon,app.data.option.lat]);
    var point_gl = app.drawingTools.getSelected();    
    point_gl.geometries().reset([point]);
    app.map.main.setCenter(app.data.option.lon,app.data.option.lat,app.data.option.zoom);
  } 
  // agrega legenda
  app.toolBar.legendsPos.setState(app.data.positions.indexOf(app.data.option.legendsPos),false);  
  app.control.explore.legends.setValue(app.data.option.legends);
  // agrega inset
  app.toolBar.insetPos.setState(app.data.positions.indexOf(app.data.option.insetPos),false);
  app.control.explore.inset.setValue(app.data.option.inset);
  // carga la capa solicitada y centra el mapa
  if(app.data.option.layer) {
    app.dialog.loadLayer.asset.setValue(app.data.option.asset);
    app.dialog.loadLayer.property.setValue(app.data.option.property);
    loadLayer();
    ui.util.setTimeout(function(){
      app.map.main.setCenter(app.data.option.lon,app.data.option.lat,app.data.option.zoom);
      },app.data.startUpDelayStep*2);
  } else
    app.map.main.setCenter(app.data.option.lon,app.data.option.lat,app.data.option.zoom);
},delay_total);
/*************************/
// Actualiza el URL bajo eventos
// legend
app.map.legends.index.config.applyButton.onClick(function(){
  app.map.legends.index.config.updateUrl('i');
  resetUrl(); 
});
app.map.legends.composite.config.applyButton.onClick(function(){
  app.map.legends.composite.config.updateUrl('c');
  resetUrl();
});
app.map.legends.index2.config.applyButton.onClick(function(){
  app.map.legends.index2.config.updateUrl('i','_');
  resetUrl();
});
app.map.legends.composite2.config.applyButton.onClick(function(){
  app.map.legends.composite2.config.updateUrl('c','_');
  resetUrl();
});
// aoi
app.control.explore.mapType.onChange(
  function(newValue){
    ui.url.set('maptype',newValue); 
    resetUrl();
  });
app.control.explore.inset.onChange(
  function(newValue){
    ui.url.set('inset',newValue);
    resetUrl();
  });
//index
app.control.index.selector.onChange(
  function(newValue){
    ui.url.set('index',getIndexAcronym(newValue));
    resetUrl();
  });
// composite 
app.control.composite.collections
  .onChange(function(newValue){
    ui.url.set('collection',newValue);
    resetUrl();
  });
/*
app.dialog.timeSlice.periodUnit
  .onChange(function(newValue){
    var period = app.dialog.timeSlice.period.getValue();
    ui.url.set('period',period * app.data.periodFactors[newValue]);
    resetUrl();
  });
app.dialog.timeSlice.period
  .onChange(function(newValue){
    var periodUnits = app.dialog.timeSlice.periodUnit.getValue();
    ui.url.set('period',newValue * app.data.periodFactors[periodUnits]);
    resetUrl();
  });
app.dialog.timeSlice.reducer
  .onChange(function(newValue){
    ui.url.set('reducer',newValue);
    resetUrl();
  });
app.dialog.timeSlice.cloudMask.onChange(
  function(newValue) {
    ui.url.set('cloudmask',newValue); 
    resetUrl();
  });
app.dialog.timeSlice.cloudFilter.onChange(
  function(newValue) {
    ui.url.set('cloudfilter',newValue); 
    resetUrl();
  });
app.dialog.timeSlice.maxCloud.onChange(
  function(newValue) {
    ui.url.set('maxcloud',newValue); 
    resetUrl();
  });
*/
// operator
app.control.operator.rescale.onChange(
  function(newValue){
    ui.url.set('rescale',newValue);
    resetUrl();
  }
);
app.control.operator.rescaleMin.onChange(
  function(newValue){
    ui.url.set('rescalemin',newValue);
    resetUrl();
  }
);
app.control.operator.rescaleMax.onChange(
  function(newValue){
    ui.url.set('rescalemax',newValue);
    resetUrl();
  }
);
app.control.operator.mask.onChange(
  function(newValue){
    ui.url.set('mask',newValue);
    resetUrl();
  });
app.control.operator.threshold.onChange(
  function(newValue){
    ui.url.set('threshold',newValue);
    resetUrl();
  });
app.control.operator.invertMask.onChange(
  function(newValue){
    ui.url.set('invert',newValue);
    resetUrl();
  });
/* app.toolBar.duplicate.onChange(
  function(newValue){
    ui.url.set('split',newValue);
    if(newValue) {
      var left = updateFromUrl(app.data.dualpars,app.data.defaultopt);
      setUrl(app.data.dualpars,left,'_');
    } else {
      setUrl(app.data.dualpars,app.data.defaultopt,'_');
    }
    resetUrl();
  });
*/ 
app.control.operator.compare.onChange(
  function(newValue){
    ui.url.set('normalize',newValue);
    resetUrl();
  });
app.control.operator.comparison.onChange(
  function(newValue){
    ui.url.set('comparison',newValue);
    resetUrl();
  });
app.control.operator.texture.onChange(
  function(newValue){
    ui.url.set('texture',newValue);
    resetUrl();
  });
app.control.operator.selector.onChange(
  function(newValue){
    ui.url.set('descriptor',getTextureAcronym(newValue));
    resetUrl();
  });  
app.control.operator.kernel.onChange(
  function(newValue){
    ui.url.set('kernel',newValue);
    resetUrl();
  }); 
// explore
app.control.explore.index.onChange(function(value){
  app.map.layer.index.setShown(value);
  ui.url.set('iitem',value);
  resetUrl();
  resetDownloadUrls();
});
app.control.explore.composite.onChange(function(value){
  app.map.layer.composite.setShown(value);
  ui.url.set('citem',value);
  resetUrl();
  resetDownloadUrls();
});
app.control.explore.index2.onChange(function(value){
  app.map.layer.index2.setShown(value);
  ui.url.set('iitem2',value);
  resetUrl();
});
app.control.explore.composite2.onChange(function(value){
  app.map.layer.composite2.setShown(value);
  ui.url.set('citem2',value);
  resetUrl();
});
app.dialog.queryOpts.timeseries.onChange(
  function(newValue){
    ui.url.set('timeseries',newValue);
    resetUrl();
  });
app.dialog.queryOpts.spectrum.onChange(
  function(newValue){
    ui.url.set('spectrum',newValue);
    resetUrl();
  });
app.dialog.queryOpts.keepMarker.onChange(
  function(newValue){
    ui.url.set('marker',newValue);
    resetUrl();
  });
app.control.explore.legends.onChange(
  function(newValue){
    ui.url.set('legends',newValue);
    resetUrl();
  });
/*app.toolBar.legendsPos.onChange(
  function(newValue){
    ui.url.set('legendspos',app.data.positions[newValue]);
    resetUrl();
  });  */
// actualiza opacidad de las capas en los parametros del url
function setUrlParamsOpacity(){
  ui.url.set('copacity',app.map.layer.composite.getOpacity());
  ui.url.set('iopacity',app.map.layer.index.getOpacity());
  //if(app.control.explore.duplicate.getValue()){
  if(app.toolBar.duplicate.getState()){
    ui.url.set('copacity_',app.map.layer.composite2.getOpacity());
    ui.url.set('iopacity_',app.map.layer.index2.getOpacity());
  }
  resetUrl();
};
app.map.main.onChangeBounds(ui.util.debounce(
  function(newMapParams,map){
    ui.url.set('lat',newMapParams.lat);
    ui.url.set('lon',newMapParams.lon);
    ui.url.set('zoom',newMapParams.zoom);
    resetUrl();
    // actualiza los valores de la leyenda
    app.control.explore.composite.setValue(app.map.layer.composite.getShown())
    app.control.explore.index.setValue(app.map.layer.index.getShown())
    //if(app.control.explore.duplicate.getValue()) {
    if(app.toolBar.duplicate.getState()) {
      app.control.explore.composite2.setValue(app.map.layer.composite2.getShown())
      app.control.explore.index2.setValue(app.map.layer.index2.getShown())
    }
    app.map.bounds = ee.List(app.map.main.getBounds());
    app.map.scale = ee.Number(app.map.main.getScale());
    updateInsetBounds();
},500));
app.map.main.onIdle(setUrlParamsOpacity); // no encuentro un mejor lugar para hacer esto
ui.root.onResize(function(size){
  app.data.windowSize = size;
  var daterange = app.control.composite.dateSlider.getValue();
  updateColHistView(daterange);
  });
ui.root.setKeyHandler(ui.Key.T,function(k){
  print(k)
  app.control.composite.showDateSlider.setValue(!app.control.composite.showDateSlider.getValue())
  },'Show/hide date selector');