// Define a region in which to generate a sample of the input.
var region = ee.Geometry.Rectangle(16.1, -2.25, 16.9, -2.75);
// Display the sample region.
Map.setCenter(16.5, -2.5,11);
Map.addLayer(ee.Image().paint(region, 0, 2), {}, 'region');
// Définition des propriétés de symbologie de l'image sentinel que l'on va sortir
var rgbVis_2022 = {
  min : 0,
  max : 1500,
  bands: ['B4','B3','B2']
};
// Définition des propriétés de symbologie de l'image sentinel que l'on va sortir
var nir_2022 = {
  min : 500,
  max : 3000,
  bands: ['B11','B8','B4']
};
// Définition des propriétés de symbologie de l'image sentinel que l'on va sortir
var monoNIR_2022 = {
  min : 500,
  max : 3000,
  bands: ['B8']
};
var monoRED_2022 = {
  min : 0,
  max : 1500,
  bands: ['B4']
};
// Load a pre-computed Landsat composite for input.
var input_2022 = ee.ImageCollection("COPERNICUS/S2_SR")
  .filterDate('2016-06-01','2022-08-31') // sélection de la période d'intérêt
  .filterBounds(region) // sélection de la région d'intérêt
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',5)) // application d'un filtre pour retirer les images avec des nuages
  .select(['B2','B3','B4','B8','B11']); 
var input_m_2022 = input_2022.median().clip(region); // appliquer la fonction "médianne" pour calculer la valeur du pixel médian de l'empaquettage de toutes les tuiles Sentinel2 pour la période définie ci-dessus
Map.addLayer (input_m_2022,nir_2022,'ete_2022_composite_faussecouleur') // ajouter l'image produite comme une couche (Layer) à la fenêtre carte ci-dessous
Map.addLayer (input_m_2022,rgbVis_2022,'ete_2022_composite_vraiecouleur') // ajouter l'image produite comme une couche (Layer) à la fenêtre carte ci-dessous
Map.addLayer (input_m_2022,monoNIR_2022,'ete_2022_composite_procheIR') // ajouter l'image produite comme une couche (Layer) à la fenêtre carte ci-dessous
Map.addLayer (input_m_2022,monoRED_2022,'ete_2022_composite_rouge') // ajouter l'image produite comme une couche (Layer) à la fenêtre carte ci-dessous
var leftMap = ui.Map();
var rightMap = ui.Map();
var s2_red_img_22 = ui.Map.Layer(input_m_2022,monoRED_2022);
var s2_nir_img_22 = ui.Map.Layer(input_m_2022,monoNIR_2022);
var s2_red_layer_22 = rightMap.layers();
var s2_nir_layer_22 = leftMap.layers();
s2_red_layer_22.add(s2_red_img_22);
s2_nir_layer_22.add(s2_nir_img_22);
var s2_red_layer_22_label = ui.Label ('Sentinel 2 - Composite été 2022 - Bande ROUGE')
s2_red_layer_22_label.style().set('position','bottom-right')
var s2_nir_layer_22_label = ui.Label ('Sentinel 2 - Composite été 2022 - Bande NIR')
s2_nir_layer_22_label.style().set('position','bottom-left')
leftMap.add(s2_nir_layer_22_label);
rightMap.add(s2_red_layer_22_label);
var splitPanel = ui.SplitPanel({
  firstPanel:leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe : true
})
ui.root.clear();
ui.root.add(splitPanel);
var linkPanel = ui.Map.Linker([leftMap,rightMap])
leftMap.centerObject(region,12)