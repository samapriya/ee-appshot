var diff_TC = ui.import && ui.import("diff_TC", "image", {
      "id": "users/bastinjf_climate/FSC/FSC_diff_TC"
    }) || ee.Image("users/bastinjf_climate/FSC/FSC_diff_TC"),
    diff_Potential = ui.import && ui.import("diff_Potential", "image", {
      "id": "users/bastinjf_climate/FSC/FSC_diff_potential"
    }) || ee.Image("users/bastinjf_climate/FSC/FSC_diff_potential");
var unboundedGeo = ee.Geometry.Polygon([-180, 88, 0, 88, 180, 88, 180, -88, 0, -88, -180, -88], null, false);
var colscale = {min: -50, max: 50, palette: ['CC0000','FDF9C5', '08a35b']};
Map.addLayer(diff_TC, colscale,'TC - Difference Sexton - Hansen', false);
Map.addLayer(diff_Potential, colscale,'Potential TC - Difference ERA5 - Worldclim', true);
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette){
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(colscale.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(colscale.min, {margin: '4px 8px'}),
    ui.Label(
        (colscale.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(colscale.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Difference (in % tree cover)',
  style: {fontWeight: 'bold'}
});
// Add the legendPanel to the map.
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
Map.add(legendPanel);