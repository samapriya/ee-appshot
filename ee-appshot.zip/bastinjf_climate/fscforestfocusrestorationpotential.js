var restor_ERA5_Hansen = ui.import && ui.import("restor_ERA5_Hansen", "image", {
      "id": "users/bastinjf_climate/FSC/FSC_restor_ERA5_Hansen"
    }) || ee.Image("users/bastinjf_climate/FSC/FSC_restor_ERA5_Hansen"),
    restor_ERA5_Sexton = ui.import && ui.import("restor_ERA5_Sexton", "image", {
      "id": "users/bastinjf_climate/FSC/FSC_restor_ERA5_Sexton"
    }) || ee.Image("users/bastinjf_climate/FSC/FSC_restor_ERA5_Sexton"),
    restor_WC_Hansen = ui.import && ui.import("restor_WC_Hansen", "image", {
      "id": "users/bastinjf_climate/FSC/FSC_restor_WC_Hansen"
    }) || ee.Image("users/bastinjf_climate/FSC/FSC_restor_WC_Hansen"),
    restor_WC_Sexton = ui.import && ui.import("restor_WC_Sexton", "image", {
      "id": "users/bastinjf_climate/FSC/FSC_restor_WC_Sexton"
    }) || ee.Image("users/bastinjf_climate/FSC/FSC_restor_WC_Sexton"),
    Potential_ERA5 = ui.import && ui.import("Potential_ERA5", "image", {
      "id": "users/bastinjf_climate/FSC/FC_ERA5_24042021"
    }) || ee.Image("users/bastinjf_climate/FSC/FC_ERA5_24042021"),
    Potential_WC = ui.import && ui.import("Potential_WC", "image", {
      "id": "users/bastinjf_climate/FSC/FC_WC_24042021"
    }) || ee.Image("users/bastinjf_climate/FSC/FC_WC_24042021");
var unboundedGeo = ee.Geometry.Polygon([-180, 88, 0, 88, 180, 88, 180, -88, 0, -88, -180, -88], null, false);
var colscale = {min: 0, max: 100, palette: ['FDF9C5', '08a35b' , '0B1DC3']};
Map.addLayer(Potential_WC, colscale,'FULL Potential TC - WC', true);
Map.addLayer(Potential_ERA5, colscale,'FULL Potential TC - ERA5', true);
Map.addLayer(restor_ERA5_Hansen, colscale,'Potential RESTORATION TC - ERA5 - HANSEN', false);
Map.addLayer(restor_WC_Hansen, colscale,'Potential RESTORATION TC - Worldclim - HANSEN', false);
Map.addLayer(restor_ERA5_Hansen, colscale,'Potential RESTORATION TC - ERA5 - SEXTON', false);
Map.addLayer(restor_WC_Hansen, colscale,'Potential RESTORATION TC - Worldclim - SEXTON', false);
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette){
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(colscale.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(colscale.min, {margin: '4px 8px'}),
    ui.Label(
        (colscale.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(colscale.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Potential (% tree cover)',
  style: {fontWeight: 'bold'}
});
// Add the legendPanel to the map.
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
Map.add(legendPanel);