var classified = ee.Image("users/bastinjf_climate/classified")
Map.centerObject(classified,11)
Map.addLayer(classified,
  {min: 1, max: 5, palette: ['red', 'yellow', 'green', 'blue','violet']}, 'classif');
var legend = ui.Panel({style: {position: 'middle-right', padding: '8px 15px'}});
var makeRow = function(color, name) {
  var colorBox = ui.Label({
    style: {color: '#ffffff',
      backgroundColor: color,
      padding: '10px',
      margin: '0 0 4px 0',
    }
  });
  var description = ui.Label({
    value: name,
    style: {
      margin: '0px 0 4px 6px',
    }
  }); 
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')}
)};
var title = ui.Label({
  value: 'Legend',
  style: {fontWeight: 'bold',
    fontSize: '16px',
    margin: '0px 0 4px 0px'}});
legend.add(title);
legend.add(makeRow('red','Built-up'))
legend.add(makeRow('yellow','Herbaceous'))
legend.add(makeRow('green','Forest'))
legend.add(makeRow('blue','Water'))
legend.add(makeRow('violet','mines'))
Map.add(legend);