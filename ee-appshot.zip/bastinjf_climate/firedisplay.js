var fire = ui.import && ui.import("fire", "image", {
      "id": "users/bastinjf_climate/PotentialEcosystem/firefreq"
    }) || ee.Image("users/bastinjf_climate/PotentialEcosystem/firefreq"),
    forest = ui.import && ui.import("forest", "image", {
      "id": "UMD/hansen/global_forest_change_2020_v1_8"
    }) || ee.Image("UMD/hansen/global_forest_change_2020_v1_8");
var fire= fire.divide(20).multiply(100)
var treeCoverVisParam = {
  bands: ['treecover2000'],
  min: 0,
  max: 100,
  palette: ['black', 'white']
};
Map.setCenter(20, 0, 5.3)
Map.addLayer(forest, treeCoverVisParam, 'tree cover');
Map.addLayer(fire, {min:0, max: 100, opacity: 0.6, palette: ['black','yellow','orange','red','brown','purple']});
var colscale = {min: 0, max: 100, palette: ['black','yellow','orange','red','brown','purple']};
function makeColorBarParams(palette){
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(colscale.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(colscale.min, {margin: '4px 8px'}),
    ui.Label(
        (colscale.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(colscale.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Fire Frequency',
  style: {fontWeight: 'bold'}
});
// Add the legendPanel to the map.
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
Map.add(legendPanel);
//Map.setZoom(5);