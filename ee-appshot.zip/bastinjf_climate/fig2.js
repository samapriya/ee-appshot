// Define a region in which to generate a sample of the input.
var region = ee.Geometry.Rectangle(-1.6, 44.75, -0.15, 44.25);
// Display the sample region.
Map.setCenter(-0.7, 44.5, 10);
Map.addLayer(ee.Image().paint(region, 0, 2), {}, 'region');
// Définition des propriétés de symbologie de l'image sentinel que l'on va sortir
var rgbVis_2022 = {
  min : 1000,
  max : 2500,
  bands: ['B4','B3','B2']
};
var rgbVis_2021 = {
  min : 0,
  max : 1500,
  bands: ['B4','B3','B2']
};
// Load a pre-computed Landsat composite for input.
var input_2021 = ee.ImageCollection("COPERNICUS/S2_SR")
  .filterDate('2021-06-01','2021-08-31') // sélection de la période d'intérêt
  .filterBounds(region) // sélection de la région d'intérêt
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',25)) // application d'un filtre pour retirer les images avec des nuages
  .select(['B2','B3','B4']); 
var input_m_2021 = input_2021.median().clip(region); // appliquer la fonction "médianne" pour calculer la valeur du pixel médian de l'empaquettage de toutes les tuiles Sentinel2 pour la période définie ci-dessus
// Load a pre-computed Landsat composite for input.
var input_2022 = ee.ImageCollection("COPERNICUS/S2_SR")
  .filterDate('2022-06-01','2022-08-31') // sélection de la période d'intérêt
  .filterBounds(region) // sélection de la région d'intérêt
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',25)) // application d'un filtre pour retirer les images avec des nuages
  .select(['B2','B3','B4']); 
var input_m_2022 = input_2022.median().clip(region); // appliquer la fonction "médianne" pour calculer la valeur du pixel médian de l'empaquettage de toutes les tuiles Sentinel2 pour la période définie ci-dessus
Map.addLayer (input_m_2021,rgbVis_2021,'ete_2021_composite') // ajouter l'image produite comme une couche (Layer) à la fenêtre carte ci-dessous
Map.addLayer (input_m_2022,rgbVis_2022,'ete_2022_composite') // ajouter l'image produite comme une couche (Layer) à la fenêtre carte ci-dessous
/*
// Make the training dataset.
var training = input_m_2022.sample({
  region: region,
  scale: 100,
  numPixels: 10e13
});
// Instantiate the clusterer and train it.
var clusterer = ee.Clusterer.wekaKMeans(10).train(training);
// Cluster the input using the trained clusterer.
var result = input_m_2022.cluster(clusterer);
var result_clip = result.clip(region);
Export.image.toAsset({
  image: result_clip,
  description: 'classif_telede_intro_fig2',
  assetId: 'classif_telede_intro_fig2'
});
//2021
// Make the training dataset.
var training = input_m_2021.sample({
  region: region,
  scale: 100,
  numPixels: 10e13
});
// Instantiate the clusterer and train it.
var clusterer_2021 = ee.Clusterer.wekaKMeans(10).train(training);
// Cluster the input using the trained clusterer.
var result_2021 = input_m_2021.cluster(clusterer_2021);
var result_2021_clip = result_2021.clip(region);
*/
// Display the points colored by cluster ID with the S2 image.
//Map.addLayer(clusterVis, null, 'Clusters');
// Display the clusters with random colors.
//Map.addLayer(result_clip.randomVisualizer(), {}, 'clusters');
var image = ee.Image('users/bastinjf_climate/geomMA1/classif_telede_intro_fig2');
var palette = [
  'FAF0DC', // BG (0)  -- yellow
  'FAF0DC', // BG (1)  -- yellow
  '228B22', // BG (2) -- yellow
  'FAF0DC', // Grasslands (3)--khaki
  'FAF0DC', // BG  (4)-- forest green
  'FAF0DC', // BG (5)-- yellow
  '800000', //intact veg (6)-- olive
  'FAF0DC', // BG (7)-- yellow
  'FAF0DC', //mines (8)-- crimson
  '1E90FF', //vegetation  (9)-- forest green
  'FAF0DC', //mines (10)-- crimson
];
Map.addLayer(image, {
  min: 0,
  max: palette.length - 1,
  palette: palette
}, 'Land Use Classification 2022');
/*var palette = [
  'FAF0DC', // water (0)  -- blue
  'FAF0DC', // cultivated (1)  -- yellow
  'FAF0DC', //  Settlement (2) -- gray
  'FAF0DC', // Grasslands (3)--khaki
  'FAF0DC', // forest  (4)-- forest green
  'FAF0DC', //clouds (5)-- black
  'FAF0DC', //intact veg (6)-- olive
  'FAF0DC', //impacted_veg (7)-- orange
  'FAF0DC', //mines (8)-- crimson
  '228B22',  
];
Map.addLayer(result_2021_clip, {
  min: 0,
  max: palette.length - 1,
  palette: palette
}, 'Land Use Classification 2021');
*/
var leftMap = ui.Map();
var rightMap = ui.Map();
var s2_class_22 = ui.Map.Layer(image,{
  min: 0,
  max: palette.length - 1,
  palette: palette
});
var s2_img_22 = ui.Map.Layer(input_m_2022,rgbVis_2022);
var s2_classlayer_22 = rightMap.layers();
var s2_layer_22 = leftMap.layers();
s2_classlayer_22.add(s2_class_22);
s2_layer_22.add(s2_img_22);
var s2_class22_label = ui.Label ('Sentinel 2 - Couvert boisé (vert) et couvert brûlé (marron)')
s2_class22_label.style().set('position','bottom-right')
var s22_label = ui.Label ('Sentinel 2 - Composite RGB été 2022')
s22_label.style().set('position','bottom-left')
leftMap.add(s22_label);
rightMap.add(s2_class22_label);
var splitPanel = ui.SplitPanel({
  firstPanel:leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe : true
})
ui.root.clear();
ui.root.add(splitPanel);
var linkPanel = ui.Map.Linker([leftMap,rightMap])
leftMap.centerObject(region,11)