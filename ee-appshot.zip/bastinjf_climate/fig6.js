var S2_1C = ui.import && ui.import("S2_1C", "imageCollection", {
      "id": "COPERNICUS/S2"
    }) || ee.ImageCollection("COPERNICUS/S2"),
    S2_2A = ui.import && ui.import("S2_2A", "imageCollection", {
      "id": "COPERNICUS/S2_SR"
    }) || ee.ImageCollection("COPERNICUS/S2_SR"),
    world = ui.import && ui.import("world", "table", {
      "id": "FAO/GAUL_SIMPLIFIED_500m/2015/level0"
    }) || ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level0"),
    adm2 = ui.import && ui.import("adm2", "table", {
      "id": "FAO/GAUL_SIMPLIFIED_500m/2015/level2"
    }) || ee.FeatureCollection("FAO/GAUL_SIMPLIFIED_500m/2015/level2"),
    communes_3812 = ui.import && ui.import("communes_3812", "table", {
      "id": "users/bastinjf_climate/geomMA1/communes_3812"
    }) || ee.FeatureCollection("users/bastinjf_climate/geomMA1/communes_3812");
// TP d'introduction à Google Earth Engine Code Editor
// Préparé par JF Bastin pour le cours de Géomatique des MA1 GFEN/STE à Gembloux Agro Bio-Tech (Octobre 2020)
// Le script ci-dessous vous explique comment extraire une image composite de sentinel 2
// Objectifs  
//////  premier contact avec earth engine code editor
//////  comment utiliser GEE dans le cadre des travaux que vous réalisez
// 1. On commence par définir la zone d'intérêt pour charger les images sentinel 2
// rect = ee.Geometry.Rectangle(3.5,50,5.5,51);
//var rect = world.filter(ee.Filter.eq('ADM0_NAME','Belgium')) // Activez cette ligne à la fin du TP (cf. video)
//var rect = adm2.filter(ee.Filter.eq('ADM2_NAME','Namur')) // Activez cette ligne à la fin du TP (cf. video)
var rect = communes_3812.filter(ee.Filter.eq('ADMUNAFR','Gembloux')) // Activez cette ligne à la fin du TP (cf. video)
print(rect); // informations dans la console concernant la variable "rect" que l'on vient de créer
Map.addLayer (rect); // illustration du polygone définit par "rect" dans la partie inférieur de l'écran, i.e. la fenêtre "carte"
Map.centerObject(rect,14); // fonction permettant de centrer la fenêtre "carte"
// Définition des propriétés de symbologie de l'image sentinel que l'on va sortir
var rgbVis = {
  min : 0,
  max : 2000,
  bands: ['B4','B3','B2']
};
// 2 Sélection des raster et définition de leur propriétés
// Sentinel2 1C
var S2_1C_2019 = S2_1C // on attribue la valeur de la collection d'image sentinel 2 que l'on a importée (voir en haut de votre fenêtre)
.filterDate('2019-01-01','2019-03-31') // sélection de la période d'intérêt
.filterBounds(rect) // sélection de la région d'intérêt
.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20)) // application d'un filtre pour retirer les images avec des nuages
.select(['B2','B3','B4','B8']); // sélectionner les bandes d'intérêt (notamment pour dimuinuer la taille de l'image de fin)
print(S2_1C_2019); // Imprimer dans la console les propriétés de l'image
var median_S21C2019 = S2_1C_2019.median().clip(rect); // appliquer la fonction "médianne" pour calculer la valeur du pixel médian de l'empaquettage de toutes les tuiles Sentinel2 pour la période définie ci-dessus
// On a aussi rajouter la fonction "clip" qui permet de découper le raster sur la région définie par "rect"
print(median_S21C2019); // Imprimer dans la console les nouvelles propriétés de l'image
Map.addLayer (median_S21C2019, rgbVis, 'S21c2019_composite') // ajouter l'image produite comme une couche (Layer) à la fenêtre carte ci-dessous
// Sentinel2 2A
var S2_2A_2019 = S2_2A
.filterDate('2019-01-01','2019-12-31')
.filterBounds(rect)
.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',5))
.select(['B2','B3','B4','B8']);
print(S2_2A_2019);
var median_S22A2019 = S2_2A_2019.median().clip(rect);
print(median_S22A2019);
Map.addLayer (median_S22A2019, rgbVis, 'S22a2019_composite')
var leftMap = ui.Map();
var rightMap = ui.Map();
var s2_2A_img_22 = ui.Map.Layer(median_S22A2019 ,rgbVis);
var s2_1C_img_22 = ui.Map.Layer(median_S21C2019 ,rgbVis);
var s2_2A_layer_22 = rightMap.layers();
var s2_1C_layer_22 = leftMap.layers();
s2_2A_layer_22.add(s2_2A_img_22);
s2_1C_layer_22.add(s2_1C_img_22);
var s2_2A_layer_22_label = ui.Label ('Sentinel 2 - 2A - composite Gembloux - hiver 2019')
s2_2A_layer_22_label.style().set('position','bottom-right')
var s2_1C_layer_22_label = ui.Label ('Sentinel 2 - 1C - ToA - composite Gembloux - hiver 2019')
s2_1C_layer_22_label.style().set('position','bottom-left')
leftMap.add(s2_1C_layer_22_label);
rightMap.add(s2_2A_layer_22_label);
var splitPanel = ui.SplitPanel({
  firstPanel:leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe : true
})
ui.root.clear();
ui.root.add(splitPanel);
var linkPanel = ui.Map.Linker([leftMap,rightMap])
leftMap.centerObject(rect,12)