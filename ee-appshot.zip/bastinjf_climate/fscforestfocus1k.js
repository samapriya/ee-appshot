var unboundedGeo = ee.Geometry.Polygon([-180, 88, 0, 88, 180, 88, 180, -88, 0, -88, -180, -88], null, false);
var replacement = ee.Image(0);
var TC_Hansen_2000 = ee.Image("UMD/hansen/global_forest_change_2020_v1_8")
 .select(['treecover2000'])
 ;
var Sexton = ee.ImageCollection('NASA/MEASURES/GFCC/TC/v3')
                  .filter(ee.Filter.date('2000-01-01', '2005-12-31'));
var TC_Sexton = Sexton.select('tree_canopy_cover');
var TC_Sexton_2000 = TC_Sexton.reduce(ee.Reducer.mean());
var PTC_WC = ee.Image("users/bastinjf_climate/FSC/FC_WC_1k_21062021")
var TC_Hansen = TC_Hansen_2000.reproject(PTC_WC.projection())
var TC_Sexton = TC_Sexton_2000.reproject(PTC_WC.projection())
var RTC_Hansen = PTC_WC.subtract(TC_Hansen);
var RTC_Hansen = RTC_Hansen.where(RTC_Hansen.lt(0), replacement);
var RTC_Sexton = PTC_WC.subtract(TC_Sexton);
var RTC_Sexton = RTC_Sexton.where(RTC_Sexton.lt(0), replacement);
var colscale = {min: 0, max: 100, palette: ['FDF9C5', '08a35b' , '0B1DC3']};
Map.addLayer(PTC_WC, colscale,'FULL Potential TC - WC', true);
Map.addLayer(RTC_Hansen, colscale,'Potential RESTORATION TC - Worldclim - HANSEN', true);
Map.addLayer(RTC_Sexton, colscale,'Potential RESTORATION TC - Worldclim - SEXTON', true);
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette){
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(colscale.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(colscale.min, {margin: '4px 8px'}),
    ui.Label(
        (colscale.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(colscale.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Potential (% tree cover)',
  style: {fontWeight: 'bold'}
});
// Add the legendPanel to the map.
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
Map.add(legendPanel);