// Define a region in which to generate a sample of the input.
var region = ee.Geometry.Rectangle(8.5, 0, 10.5, 1);
// Display the sample region.
Map.setCenter(9.5, 0.5, 11);
Map.addLayer(ee.Image().paint(region, 0, 2), {}, 'region');
// Définition des propriétés de symbologie de l'image sentinel que l'on va sortir
var rgbVis_2022 = {
  min : 1000,
  max : 2500,
  bands: ['B4','B3','B2']
};
// Load a pre-computed Landsat composite for input.
var input_2022 = ee.ImageCollection("COPERNICUS/S2_SR")
  .filterDate('2022-06-01','2022-08-31') // sélection de la période d'intérêt
  .filterBounds(region) // sélection de la région d'intérêt
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',25)) // application d'un filtre pour retirer les images avec des nuages
  .select(['B2','B3','B4']); 
var input_m_2022 = input_2022.median().clip(region); // appliquer la fonction "médianne" pour calculer la valeur du pixel médian de l'empaquettage de toutes les tuiles Sentinel2 pour la période définie ci-dessus
Map.addLayer (input_m_2022,rgbVis_2022,'ete_2022_composite') // ajouter l'image produite comme une couche (Layer) à la fenêtre carte ci-dessous
var imgVV = ee.ImageCollection('COPERNICUS/S1_GRD')
        .filterDate('2022-06-01','2022-08-31') // sélection de la période d'intérêt
        .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
        .filter(ee.Filter.eq('instrumentMode', 'IW'))
        .select('VV')
        .map(function(image) {
          var edge = image.lt(-30.0);
          var maskedImage = image.mask().and(edge.not());
          return image.updateMask(maskedImage);
        });
var S1_2022 = imgVV.median().clip(region); // appliquer la fonction "médianne" pour calculer la valeur du pixel médian de l'empaquettage de toutes les tuiles Sentinel2 pour la période définie ci-dessus
// Définition des propriétés de symbologie de l'image sentinel que l'on va sortir
var vis_S1_2022 = {
  min : -20,
  max : 0,
  bands: ['VV']
};
Map.addLayer(S1_2022, vis_S1_2022, 'Sentinel 1', true);
var leftMap = ui.Map();
var rightMap = ui.Map();
var s1_img_22 = ui.Map.Layer(S1_2022,vis_S1_2022);
var s2_img_22 = ui.Map.Layer(input_m_2022,rgbVis_2022);
var s1_layer_22 = rightMap.layers();
var s2_layer_22 = leftMap.layers();
s1_layer_22.add(s1_img_22);
s2_layer_22.add(s2_img_22);
var s1_22_label = ui.Label ('Sentinel 1 - Composite VV été 2022')
s1_22_label.style().set('position','bottom-right')
var s22_label = ui.Label ('Sentinel 2 - Composite RGB été 2022')
s22_label.style().set('position','bottom-left')
leftMap.add(s22_label);
rightMap.add(s1_22_label);
var splitPanel = ui.SplitPanel({
  firstPanel:leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe : true
})
ui.root.clear();
ui.root.add(splitPanel);
var linkPanel = ui.Map.Linker([leftMap,rightMap])
leftMap.centerObject(region,11)