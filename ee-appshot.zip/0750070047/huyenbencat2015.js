var DatTrong = ui.import && ui.import("DatTrong", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            106.63308538911895,
            11.238656670797205
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63428701875762,
            11.238572485995588
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63188375948027,
            11.237267618427925
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60863437173919,
            11.25429357120723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6097179841812,
            11.254009462821761
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60891332147673,
            11.253746399251941
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60274424074248,
            11.255156417177844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6000313014981,
            11.232499163992628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60601799201935,
            11.232583350566918
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6050738544461,
            11.226753372253874
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60333578300445,
            11.226164053812859
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60294954490631,
            11.231867763902448
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6042799205777,
            11.226311383535895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56441156578033,
            11.17006299001783
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59322921943634,
            11.129852436587472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59794990730255,
            11.132757888030413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59717743110626,
            11.121262236729853
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59661953163116,
            11.123915119597791
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59301464271515,
            11.123873010534535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60129730415314,
            11.122399189487414
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61932174873321,
            11.128799729635292
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62824814033478,
            11.128757621278053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6330975742337,
            11.126820630265158
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59730617713898,
            11.119114647198696
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6090006084439,
            11.111619014687939
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60380785179107,
            11.109639798676406
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64831237466164,
            11.103445422577838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65783958108254,
            11.103445422577838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6479261365635,
            11.098434049721728
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64666013390847,
            11.095317690466365
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64348439843484,
            11.097760245132214
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6542132344944,
            11.098391936980413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65180997521706,
            11.098265598720074
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65773229272195,
            11.095359803650856
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65726022393532,
            11.103276974466993
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64342002541848,
            11.102266283760985
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68620662362405,
            11.099339472191145
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68127135903664,
            11.10359281459509
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67513446481057,
            11.104729836226976
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6768510785801,
            11.10279268560695
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68642120034524,
            11.09765496302469
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67916850716897,
            11.091843331839337
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6797693219883,
            11.090369349033733
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67916850716897,
            11.089105929284347
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67290286691018,
            11.105656295022905
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67148666055031,
            11.08620004313973
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6283138242466,
            11.091380080901423
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60822944314309,
            11.092727717954501
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59998969704934,
            11.090453576822874
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landcover": 1
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([106.63308538911895, 11.238656670797205]),
            {
              "landcover": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63428701875762, 11.238572485995588]),
            {
              "landcover": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63188375948027, 11.237267618427925]),
            {
              "landcover": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60863437173919, 11.25429357120723]),
            {
              "landcover": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6097179841812, 11.254009462821761]),
            {
              "landcover": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60891332147673, 11.253746399251941]),
            {
              "landcover": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60274424074248, 11.255156417177844]),
            {
              "landcover": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6000313014981, 11.232499163992628]),
            {
              "landcover": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60601799201935, 11.232583350566918]),
            {
              "landcover": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6050738544461, 11.226753372253874]),
            {
              "landcover": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60333578300445, 11.226164053812859]),
            {
              "landcover": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60294954490631, 11.231867763902448]),
            {
              "landcover": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6042799205777, 11.226311383535895]),
            {
              "landcover": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56441156578033, 11.17006299001783]),
            {
              "landcover": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59322921943634, 11.129852436587472]),
            {
              "landcover": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59794990730255, 11.132757888030413]),
            {
              "landcover": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59717743110626, 11.121262236729853]),
            {
              "landcover": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59661953163116, 11.123915119597791]),
            {
              "landcover": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59301464271515, 11.123873010534535]),
            {
              "landcover": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60129730415314, 11.122399189487414]),
            {
              "landcover": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61932174873321, 11.128799729635292]),
            {
              "landcover": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62824814033478, 11.128757621278053]),
            {
              "landcover": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6330975742337, 11.126820630265158]),
            {
              "landcover": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59730617713898, 11.119114647198696]),
            {
              "landcover": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6090006084439, 11.111619014687939]),
            {
              "landcover": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60380785179107, 11.109639798676406]),
            {
              "landcover": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64831237466164, 11.103445422577838]),
            {
              "landcover": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65783958108254, 11.103445422577838]),
            {
              "landcover": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6479261365635, 11.098434049721728]),
            {
              "landcover": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64666013390847, 11.095317690466365]),
            {
              "landcover": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64348439843484, 11.097760245132214]),
            {
              "landcover": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6542132344944, 11.098391936980413]),
            {
              "landcover": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65180997521706, 11.098265598720074]),
            {
              "landcover": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65773229272195, 11.095359803650856]),
            {
              "landcover": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65726022393532, 11.103276974466993]),
            {
              "landcover": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64342002541848, 11.102266283760985]),
            {
              "landcover": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68620662362405, 11.099339472191145]),
            {
              "landcover": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68127135903664, 11.10359281459509]),
            {
              "landcover": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67513446481057, 11.104729836226976]),
            {
              "landcover": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6768510785801, 11.10279268560695]),
            {
              "landcover": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68642120034524, 11.09765496302469]),
            {
              "landcover": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67916850716897, 11.091843331839337]),
            {
              "landcover": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6797693219883, 11.090369349033733]),
            {
              "landcover": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67916850716897, 11.089105929284347]),
            {
              "landcover": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67290286691018, 11.105656295022905]),
            {
              "landcover": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67148666055031, 11.08620004313973]),
            {
              "landcover": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6283138242466, 11.091380080901423]),
            {
              "landcover": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60822944314309, 11.092727717954501]),
            {
              "landcover": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59998969704934, 11.090453576822874]),
            {
              "landcover": 1,
              "system:index": "48"
            })]),
    Thucvat = ui.import && ui.import("Thucvat", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            106.64373901424591,
            11.150524080458814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52683761654083,
            11.142776618516912
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53679397640411,
            11.125596727903561
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56511810360138,
            11.12677577239884
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56923797664825,
            11.15742925293737
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67480972347443,
            11.132165629315622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68390777645294,
            11.125259857171358
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67910125789825,
            11.150018817494358
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64768722591583,
            11.162818541808624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64030578670685,
            11.199530407966748
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.70313385067169,
            11.208455066761625
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6844227605838,
            11.215695625276647
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5910389715213,
            11.212664715876704
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56477478084747,
            11.211149249257236
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5441754156131,
            11.210644091951826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53782394466583,
            11.195152172815266
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53456237850372,
            11.18521670131505
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54142883358185,
            11.180501443073645
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54984024105255,
            11.174607262415954
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55241516170685,
            11.1877427009544
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56546142635528,
            11.197678085793092
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55413177547638,
            11.197509692280335
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57232788143341,
            11.21502209260162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57661941585724,
            11.193805010215089
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5797093206424,
            11.184879899699224
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58485916195099,
            11.178143785188485
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58434417782013,
            11.164671086757938
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59996536312286,
            11.203235016741964
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6595318609256,
            11.182859081783779
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68373611507599,
            11.20020397672667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66708496151153,
            11.212327946203484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67978790340607,
            11.17410204135654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67103317318146,
            11.167197265364162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66330841121857,
            11.157597669728263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65936019954864,
            11.149345132175633
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66348007259552,
            11.14361874394347
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63292434749786,
            11.154902989358021
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6188481145877,
            11.186395503887415
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59670379696075,
            11.181680264825825
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54623535213653,
            11.245329507427376
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51516464290802,
            11.236911100440352
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61026504574005,
            11.244992775868472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65060546932403,
            11.252569140752554
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66073349056427,
            11.240783598187038
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68528106746857,
            11.2422989092334
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.71206024227325,
            11.249706981882428
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65009048519318,
            11.23152319098827
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65472534237091,
            11.214180174550194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63670089779083,
            11.22142058961734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62571456966583,
            11.218052977275038
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6185047918338,
            11.215190475917558
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56923797664825,
            11.238258062077197
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57404449520294,
            11.254589471063943
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64236572323028,
            11.242804011145369
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51619461116974,
            11.226977064125983
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63721588192169,
            11.189728178118502
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63876083431427,
            11.17760326212384
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59979370174591,
            11.166319898731937
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58743408260528,
            11.161941161942886
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67566803035919,
            11.117981726831987
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66811492977325,
            11.112254721827435
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57473114071075,
            11.113939146738325
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55310180721466,
            11.119666118662321
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54177215633575,
            11.119834557310087
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55602005062286,
            11.101474172134008
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56597641048614,
            11.096926008330959
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68682601986114,
            11.12084518715272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6514637762088,
            11.085471059875218
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64648559627716,
            11.078901107518488
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65129211483185,
            11.055146972674272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63481262264435,
            11.063739116127458
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59601715145294,
            11.080080340601398
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58829238949005,
            11.090356313384383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58794906673614,
            11.10096882409815
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58279922542755,
            11.112254721827435
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61060836849396,
            11.118150166452951
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63223770199005,
            11.092714682410326
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63927581844513,
            11.074015662695675
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63635757503693,
            11.07435259254279
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58599949490885,
            11.039279732261482
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56231022488932,
            11.049894094071101
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53810597073893,
            11.062192794942623
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5396509231315,
            11.07567023056028
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55235386502603,
            11.076175622328792
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56643009793619,
            11.087294020379566
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56042194974283,
            11.086957105436163
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53209782254557,
            11.09807509352199
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52591801297525,
            11.099759600265395
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51922321927408,
            11.098580446565125
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57432652127603,
            11.094706050892468
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57569981229166,
            11.104981509417813
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5997324050651,
            11.08156641355154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58668614041666,
            11.05595927129676
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5997324050651,
            11.051747355973493
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60539723050455,
            11.04568209166903
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60797215115885,
            11.057644020487807
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59853077542643,
            11.068089249336072
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56471348416666,
            11.111045544750464
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56299687039713,
            11.119804484361351
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57346821439127,
            11.119636045696206
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5748415054069,
            11.135300425004631
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5810213149772,
            11.128731594303044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51287174832682,
            11.137826858886081
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51905155789713,
            11.128394727195948
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5205965102897,
            11.125699776314745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5425691665397,
            11.143553361144665
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54840565335611,
            11.15096396141257
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56248188626627,
            11.148942907343827
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5700349868522,
            11.135300425004631
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57363987576822,
            11.12620508150398
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57253874814555,
            11.161574264669154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57717360532328,
            11.151469222734157
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58146513974711,
            11.1536586783111
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5888465789561,
            11.157363873244872
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59948958432719,
            11.157027039294386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61219252622172,
            11.156858622172663
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61871565854594,
            11.157532290073664
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62026061093852,
            11.165953006991822
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6250671294932,
            11.172184180255165
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61802901303813,
            11.173026220432641
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58421172177836,
            11.211252267294112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53082503354594,
            11.21411480766214
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5236152557139,
            11.220008183837352
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52344359433695,
            11.199296645294208
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54678954160258,
            11.208221311301283
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55520094907328,
            11.237014109285807
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53305663144633,
            11.226911700134103
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55811919248148,
            11.226574947071253
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56618727719828,
            11.229268960573105
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56996382749125,
            11.23347830632141
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5752853301768,
            11.229774085305134
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5833534148936,
            11.237519220456484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58747328794047,
            11.241728445801824
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58352507627055,
            11.247284529142915
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59605635678813,
            11.231626201757754
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5840400604014,
            11.21882951822004
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59811629331156,
            11.22169198351839
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64309157407328,
            11.23145782802605
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66334761655375,
            11.202832866647585
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67587889707133,
            11.194750011488477
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66763915097758,
            11.192224072962604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65579451596781,
            11.196770746441494
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6272987273936,
            11.201317348502595
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61545409238383,
            11.190540101703924
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59931792295023,
            11.186498530736397
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64566649472758,
            11.17201577192638
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65321959531352,
            11.180099261407705
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65733946836039,
            11.179088837545754
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66248930966898,
            11.17875202880919
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67313231504008,
            11.181109681747838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66506423032328,
            11.189192917647024
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65751112973734,
            11.191045294109696
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63708342587992,
            11.197781108627947
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.69047011411234,
            11.195255196549152
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.69561995542094,
            11.2035064277192
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66592253720805,
            11.22186036294657
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6774238494639,
            11.23145782802605
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.70250024758074,
            11.22792195696538
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.70919504128192,
            11.22135522436754
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.70610513649676,
            11.241896813537368
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.69134225807879,
            11.245769244309818
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67416548163432,
            11.264299279308844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66077589423197,
            11.275410467493504
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67536711127299,
            11.28046086559004
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61683058173197,
            11.275747163461695
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57700514227885,
            11.281134245294801
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5823266449644,
            11.267329645939752
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58696150214213,
            11.258238450286957
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56275724799174,
            11.255207987912259
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55172817572726,
            11.31446456574185
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5621995197214,
            11.305374862581148
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59172527655734,
            11.309414766257918
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58520214423312,
            11.318840986598968
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61009304389133,
            11.32607876655399
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61867611273898,
            11.315811163899832
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62622921332492,
            11.312612982935278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61867611273898,
            11.299988235763553
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5973901019968,
            11.296284871122946
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60803310736789,
            11.295948199238932
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57164089545383,
            11.313117961251555
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58039562567843,
            11.306553173703671
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57661907538547,
            11.275242119361474
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62382595404758,
            11.287194591586907
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62537090644015,
            11.27945079307313
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63120739325656,
            11.27945079307313
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62107937201633,
            11.271875136013147
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61884777411593,
            11.265814466615144
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61180965766086,
            11.268508113228908
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64768688544406,
            11.325237173640211
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64150707587375,
            11.319514276177305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63687221869601,
            11.313454612967746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6420220600046,
            11.308573124355734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63429729804172,
            11.297968224615278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64734356269015,
            11.294601507751393
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65712826117648,
            11.305206532025297
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66227810248508,
            11.31076138815847
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66759960517062,
            11.312108003728651
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65918819769992,
            11.286184542754313
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63979046210422,
            11.283491061828848
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64940349921359,
            11.286016200936727
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67120449408664,
            11.29056139536085
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6742943988718,
            11.303186557644045
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67738430365695,
            11.308741452933969
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53936855658664,
            11.382964697562224
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53627865180148,
            11.36815525174561
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54537670478,
            11.37656980407491
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55155651435031,
            11.366304016882598
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55498974188937,
            11.350315579287189
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53885357245578,
            11.351830311799652
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54228679999484,
            11.360581942203627
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56168453559054,
            11.350147275178475
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5728425250925,
            11.363106401071962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5676926837839,
            11.36327469753513
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58314220770968,
            11.361591728432998
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59155361518039,
            11.361086835765283
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58863537177218,
            11.374718623889944
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57799236640109,
            11.374718623889944
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53387539252414,
            11.377579533649062
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60957805976047,
            11.374213754478419
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61043636664523,
            11.36765037070281
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59996502265109,
            11.36327469753513
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6006516681589,
            11.35469145127649
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6142129169382,
            11.355364656395833
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60786144599093,
            11.354186546394608
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.600308345405,
            11.346612865973613
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59378521308078,
            11.346949478259248
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58691875800265,
            11.346949478259248
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56975262030734,
            11.353849942643635
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56271450385226,
            11.343078413017535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55550472602023,
            11.332306477151004
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54623501166476,
            11.321870777228888
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54451839789523,
            11.313454612967746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56305782660617,
            11.324732216703561
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56975262030734,
            11.32170245636869
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59430019721164,
            11.331128272035018
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5864037738718,
            11.338702363045916
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57679073676242,
            11.339038984654268
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6090630756296,
            11.347959312735039
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61867611273898,
            11.348295923433222
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6255425678171,
            11.33920729530972
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63343899115695,
            11.337355872646913
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65026180609836,
            11.355364656395833
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64236538275851,
            11.351157098342128
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62725918158664,
            11.327088674782201
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59996502265109,
            11.324563897526614
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60768978461398,
            11.339880536940036
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61781780585422,
            11.32995006206406
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62296764716281,
            11.308573124355734
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landcover": 4
      },
      "color": "#98ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([106.64373901424591, 11.150524080458814]),
            {
              "landcover": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52683761654083, 11.142776618516912]),
            {
              "landcover": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53679397640411, 11.125596727903561]),
            {
              "landcover": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56511810360138, 11.12677577239884]),
            {
              "landcover": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56923797664825, 11.15742925293737]),
            {
              "landcover": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67480972347443, 11.132165629315622]),
            {
              "landcover": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68390777645294, 11.125259857171358]),
            {
              "landcover": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67910125789825, 11.150018817494358]),
            {
              "landcover": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64768722591583, 11.162818541808624]),
            {
              "landcover": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64030578670685, 11.199530407966748]),
            {
              "landcover": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([106.70313385067169, 11.208455066761625]),
            {
              "landcover": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6844227605838, 11.215695625276647]),
            {
              "landcover": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5910389715213, 11.212664715876704]),
            {
              "landcover": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56477478084747, 11.211149249257236]),
            {
              "landcover": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5441754156131, 11.210644091951826]),
            {
              "landcover": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53782394466583, 11.195152172815266]),
            {
              "landcover": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53456237850372, 11.18521670131505]),
            {
              "landcover": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54142883358185, 11.180501443073645]),
            {
              "landcover": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54984024105255, 11.174607262415954]),
            {
              "landcover": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55241516170685, 11.1877427009544]),
            {
              "landcover": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56546142635528, 11.197678085793092]),
            {
              "landcover": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55413177547638, 11.197509692280335]),
            {
              "landcover": 4,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57232788143341, 11.21502209260162]),
            {
              "landcover": 4,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57661941585724, 11.193805010215089]),
            {
              "landcover": 4,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5797093206424, 11.184879899699224]),
            {
              "landcover": 4,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58485916195099, 11.178143785188485]),
            {
              "landcover": 4,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58434417782013, 11.164671086757938]),
            {
              "landcover": 4,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59996536312286, 11.203235016741964]),
            {
              "landcover": 4,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6595318609256, 11.182859081783779]),
            {
              "landcover": 4,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68373611507599, 11.20020397672667]),
            {
              "landcover": 4,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66708496151153, 11.212327946203484]),
            {
              "landcover": 4,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67978790340607, 11.17410204135654]),
            {
              "landcover": 4,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67103317318146, 11.167197265364162]),
            {
              "landcover": 4,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66330841121857, 11.157597669728263]),
            {
              "landcover": 4,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65936019954864, 11.149345132175633]),
            {
              "landcover": 4,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66348007259552, 11.14361874394347]),
            {
              "landcover": 4,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63292434749786, 11.154902989358021]),
            {
              "landcover": 4,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6188481145877, 11.186395503887415]),
            {
              "landcover": 4,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59670379696075, 11.181680264825825]),
            {
              "landcover": 4,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54623535213653, 11.245329507427376]),
            {
              "landcover": 4,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51516464290802, 11.236911100440352]),
            {
              "landcover": 4,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61026504574005, 11.244992775868472]),
            {
              "landcover": 4,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65060546932403, 11.252569140752554]),
            {
              "landcover": 4,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66073349056427, 11.240783598187038]),
            {
              "landcover": 4,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68528106746857, 11.2422989092334]),
            {
              "landcover": 4,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([106.71206024227325, 11.249706981882428]),
            {
              "landcover": 4,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65009048519318, 11.23152319098827]),
            {
              "landcover": 4,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65472534237091, 11.214180174550194]),
            {
              "landcover": 4,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63670089779083, 11.22142058961734]),
            {
              "landcover": 4,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62571456966583, 11.218052977275038]),
            {
              "landcover": 4,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6185047918338, 11.215190475917558]),
            {
              "landcover": 4,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56923797664825, 11.238258062077197]),
            {
              "landcover": 4,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57404449520294, 11.254589471063943]),
            {
              "landcover": 4,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64236572323028, 11.242804011145369]),
            {
              "landcover": 4,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51619461116974, 11.226977064125983]),
            {
              "landcover": 4,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63721588192169, 11.189728178118502]),
            {
              "landcover": 4,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63876083431427, 11.17760326212384]),
            {
              "landcover": 4,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59979370174591, 11.166319898731937]),
            {
              "landcover": 4,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58743408260528, 11.161941161942886]),
            {
              "landcover": 4,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67566803035919, 11.117981726831987]),
            {
              "landcover": 4,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66811492977325, 11.112254721827435]),
            {
              "landcover": 4,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57473114071075, 11.113939146738325]),
            {
              "landcover": 4,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55310180721466, 11.119666118662321]),
            {
              "landcover": 4,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54177215633575, 11.119834557310087]),
            {
              "landcover": 4,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55602005062286, 11.101474172134008]),
            {
              "landcover": 4,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56597641048614, 11.096926008330959]),
            {
              "landcover": 4,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68682601986114, 11.12084518715272]),
            {
              "landcover": 4,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6514637762088, 11.085471059875218]),
            {
              "landcover": 4,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64648559627716, 11.078901107518488]),
            {
              "landcover": 4,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65129211483185, 11.055146972674272]),
            {
              "landcover": 4,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63481262264435, 11.063739116127458]),
            {
              "landcover": 4,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59601715145294, 11.080080340601398]),
            {
              "landcover": 4,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58829238949005, 11.090356313384383]),
            {
              "landcover": 4,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58794906673614, 11.10096882409815]),
            {
              "landcover": 4,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58279922542755, 11.112254721827435]),
            {
              "landcover": 4,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61060836849396, 11.118150166452951]),
            {
              "landcover": 4,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63223770199005, 11.092714682410326]),
            {
              "landcover": 4,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63927581844513, 11.074015662695675]),
            {
              "landcover": 4,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63635757503693, 11.07435259254279]),
            {
              "landcover": 4,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58599949490885, 11.039279732261482]),
            {
              "landcover": 4,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56231022488932, 11.049894094071101]),
            {
              "landcover": 4,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53810597073893, 11.062192794942623]),
            {
              "landcover": 4,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5396509231315, 11.07567023056028]),
            {
              "landcover": 4,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55235386502603, 11.076175622328792]),
            {
              "landcover": 4,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56643009793619, 11.087294020379566]),
            {
              "landcover": 4,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56042194974283, 11.086957105436163]),
            {
              "landcover": 4,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53209782254557, 11.09807509352199]),
            {
              "landcover": 4,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52591801297525, 11.099759600265395]),
            {
              "landcover": 4,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51922321927408, 11.098580446565125]),
            {
              "landcover": 4,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57432652127603, 11.094706050892468]),
            {
              "landcover": 4,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57569981229166, 11.104981509417813]),
            {
              "landcover": 4,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5997324050651, 11.08156641355154]),
            {
              "landcover": 4,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58668614041666, 11.05595927129676]),
            {
              "landcover": 4,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5997324050651, 11.051747355973493]),
            {
              "landcover": 4,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60539723050455, 11.04568209166903]),
            {
              "landcover": 4,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60797215115885, 11.057644020487807]),
            {
              "landcover": 4,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59853077542643, 11.068089249336072]),
            {
              "landcover": 4,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56471348416666, 11.111045544750464]),
            {
              "landcover": 4,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56299687039713, 11.119804484361351]),
            {
              "landcover": 4,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57346821439127, 11.119636045696206]),
            {
              "landcover": 4,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5748415054069, 11.135300425004631]),
            {
              "landcover": 4,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5810213149772, 11.128731594303044]),
            {
              "landcover": 4,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51287174832682, 11.137826858886081]),
            {
              "landcover": 4,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51905155789713, 11.128394727195948]),
            {
              "landcover": 4,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5205965102897, 11.125699776314745]),
            {
              "landcover": 4,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5425691665397, 11.143553361144665]),
            {
              "landcover": 4,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54840565335611, 11.15096396141257]),
            {
              "landcover": 4,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56248188626627, 11.148942907343827]),
            {
              "landcover": 4,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5700349868522, 11.135300425004631]),
            {
              "landcover": 4,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57363987576822, 11.12620508150398]),
            {
              "landcover": 4,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57253874814555, 11.161574264669154]),
            {
              "landcover": 4,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57717360532328, 11.151469222734157]),
            {
              "landcover": 4,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58146513974711, 11.1536586783111]),
            {
              "landcover": 4,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5888465789561, 11.157363873244872]),
            {
              "landcover": 4,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59948958432719, 11.157027039294386]),
            {
              "landcover": 4,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61219252622172, 11.156858622172663]),
            {
              "landcover": 4,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61871565854594, 11.157532290073664]),
            {
              "landcover": 4,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62026061093852, 11.165953006991822]),
            {
              "landcover": 4,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6250671294932, 11.172184180255165]),
            {
              "landcover": 4,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61802901303813, 11.173026220432641]),
            {
              "landcover": 4,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58421172177836, 11.211252267294112]),
            {
              "landcover": 4,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53082503354594, 11.21411480766214]),
            {
              "landcover": 4,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5236152557139, 11.220008183837352]),
            {
              "landcover": 4,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52344359433695, 11.199296645294208]),
            {
              "landcover": 4,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54678954160258, 11.208221311301283]),
            {
              "landcover": 4,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55520094907328, 11.237014109285807]),
            {
              "landcover": 4,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53305663144633, 11.226911700134103]),
            {
              "landcover": 4,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55811919248148, 11.226574947071253]),
            {
              "landcover": 4,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56618727719828, 11.229268960573105]),
            {
              "landcover": 4,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56996382749125, 11.23347830632141]),
            {
              "landcover": 4,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5752853301768, 11.229774085305134]),
            {
              "landcover": 4,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5833534148936, 11.237519220456484]),
            {
              "landcover": 4,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58747328794047, 11.241728445801824]),
            {
              "landcover": 4,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58352507627055, 11.247284529142915]),
            {
              "landcover": 4,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59605635678813, 11.231626201757754]),
            {
              "landcover": 4,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5840400604014, 11.21882951822004]),
            {
              "landcover": 4,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59811629331156, 11.22169198351839]),
            {
              "landcover": 4,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64309157407328, 11.23145782802605]),
            {
              "landcover": 4,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66334761655375, 11.202832866647585]),
            {
              "landcover": 4,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67587889707133, 11.194750011488477]),
            {
              "landcover": 4,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66763915097758, 11.192224072962604]),
            {
              "landcover": 4,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65579451596781, 11.196770746441494]),
            {
              "landcover": 4,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6272987273936, 11.201317348502595]),
            {
              "landcover": 4,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61545409238383, 11.190540101703924]),
            {
              "landcover": 4,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59931792295023, 11.186498530736397]),
            {
              "landcover": 4,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64566649472758, 11.17201577192638]),
            {
              "landcover": 4,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65321959531352, 11.180099261407705]),
            {
              "landcover": 4,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65733946836039, 11.179088837545754]),
            {
              "landcover": 4,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66248930966898, 11.17875202880919]),
            {
              "landcover": 4,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67313231504008, 11.181109681747838]),
            {
              "landcover": 4,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66506423032328, 11.189192917647024]),
            {
              "landcover": 4,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65751112973734, 11.191045294109696]),
            {
              "landcover": 4,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63708342587992, 11.197781108627947]),
            {
              "landcover": 4,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([106.69047011411234, 11.195255196549152]),
            {
              "landcover": 4,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([106.69561995542094, 11.2035064277192]),
            {
              "landcover": 4,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66592253720805, 11.22186036294657]),
            {
              "landcover": 4,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6774238494639, 11.23145782802605]),
            {
              "landcover": 4,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([106.70250024758074, 11.22792195696538]),
            {
              "landcover": 4,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([106.70919504128192, 11.22135522436754]),
            {
              "landcover": 4,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([106.70610513649676, 11.241896813537368]),
            {
              "landcover": 4,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([106.69134225807879, 11.245769244309818]),
            {
              "landcover": 4,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67416548163432, 11.264299279308844]),
            {
              "landcover": 4,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66077589423197, 11.275410467493504]),
            {
              "landcover": 4,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67536711127299, 11.28046086559004]),
            {
              "landcover": 4,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61683058173197, 11.275747163461695]),
            {
              "landcover": 4,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57700514227885, 11.281134245294801]),
            {
              "landcover": 4,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5823266449644, 11.267329645939752]),
            {
              "landcover": 4,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58696150214213, 11.258238450286957]),
            {
              "landcover": 4,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56275724799174, 11.255207987912259]),
            {
              "landcover": 4,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55172817572726, 11.31446456574185]),
            {
              "landcover": 4,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5621995197214, 11.305374862581148]),
            {
              "landcover": 4,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59172527655734, 11.309414766257918]),
            {
              "landcover": 4,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58520214423312, 11.318840986598968]),
            {
              "landcover": 4,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61009304389133, 11.32607876655399]),
            {
              "landcover": 4,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61867611273898, 11.315811163899832]),
            {
              "landcover": 4,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62622921332492, 11.312612982935278]),
            {
              "landcover": 4,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61867611273898, 11.299988235763553]),
            {
              "landcover": 4,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5973901019968, 11.296284871122946]),
            {
              "landcover": 4,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60803310736789, 11.295948199238932]),
            {
              "landcover": 4,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57164089545383, 11.313117961251555]),
            {
              "landcover": 4,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58039562567843, 11.306553173703671]),
            {
              "landcover": 4,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57661907538547, 11.275242119361474]),
            {
              "landcover": 4,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62382595404758, 11.287194591586907]),
            {
              "landcover": 4,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62537090644015, 11.27945079307313]),
            {
              "landcover": 4,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63120739325656, 11.27945079307313]),
            {
              "landcover": 4,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62107937201633, 11.271875136013147]),
            {
              "landcover": 4,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61884777411593, 11.265814466615144]),
            {
              "landcover": 4,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61180965766086, 11.268508113228908]),
            {
              "landcover": 4,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64768688544406, 11.325237173640211]),
            {
              "landcover": 4,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64150707587375, 11.319514276177305]),
            {
              "landcover": 4,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63687221869601, 11.313454612967746]),
            {
              "landcover": 4,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6420220600046, 11.308573124355734]),
            {
              "landcover": 4,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63429729804172, 11.297968224615278]),
            {
              "landcover": 4,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64734356269015, 11.294601507751393]),
            {
              "landcover": 4,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65712826117648, 11.305206532025297]),
            {
              "landcover": 4,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66227810248508, 11.31076138815847]),
            {
              "landcover": 4,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66759960517062, 11.312108003728651]),
            {
              "landcover": 4,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65918819769992, 11.286184542754313]),
            {
              "landcover": 4,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63979046210422, 11.283491061828848]),
            {
              "landcover": 4,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64940349921359, 11.286016200936727]),
            {
              "landcover": 4,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67120449408664, 11.29056139536085]),
            {
              "landcover": 4,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6742943988718, 11.303186557644045]),
            {
              "landcover": 4,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67738430365695, 11.308741452933969]),
            {
              "landcover": 4,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53936855658664, 11.382964697562224]),
            {
              "landcover": 4,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53627865180148, 11.36815525174561]),
            {
              "landcover": 4,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54537670478, 11.37656980407491]),
            {
              "landcover": 4,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55155651435031, 11.366304016882598]),
            {
              "landcover": 4,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55498974188937, 11.350315579287189]),
            {
              "landcover": 4,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53885357245578, 11.351830311799652]),
            {
              "landcover": 4,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54228679999484, 11.360581942203627]),
            {
              "landcover": 4,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56168453559054, 11.350147275178475]),
            {
              "landcover": 4,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5728425250925, 11.363106401071962]),
            {
              "landcover": 4,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5676926837839, 11.36327469753513]),
            {
              "landcover": 4,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58314220770968, 11.361591728432998]),
            {
              "landcover": 4,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59155361518039, 11.361086835765283]),
            {
              "landcover": 4,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58863537177218, 11.374718623889944]),
            {
              "landcover": 4,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57799236640109, 11.374718623889944]),
            {
              "landcover": 4,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53387539252414, 11.377579533649062]),
            {
              "landcover": 4,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60957805976047, 11.374213754478419]),
            {
              "landcover": 4,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61043636664523, 11.36765037070281]),
            {
              "landcover": 4,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59996502265109, 11.36327469753513]),
            {
              "landcover": 4,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6006516681589, 11.35469145127649]),
            {
              "landcover": 4,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6142129169382, 11.355364656395833]),
            {
              "landcover": 4,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60786144599093, 11.354186546394608]),
            {
              "landcover": 4,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([106.600308345405, 11.346612865973613]),
            {
              "landcover": 4,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59378521308078, 11.346949478259248]),
            {
              "landcover": 4,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58691875800265, 11.346949478259248]),
            {
              "landcover": 4,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56975262030734, 11.353849942643635]),
            {
              "landcover": 4,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56271450385226, 11.343078413017535]),
            {
              "landcover": 4,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55550472602023, 11.332306477151004]),
            {
              "landcover": 4,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54623501166476, 11.321870777228888]),
            {
              "landcover": 4,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54451839789523, 11.313454612967746]),
            {
              "landcover": 4,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56305782660617, 11.324732216703561]),
            {
              "landcover": 4,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56975262030734, 11.32170245636869]),
            {
              "landcover": 4,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59430019721164, 11.331128272035018]),
            {
              "landcover": 4,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5864037738718, 11.338702363045916]),
            {
              "landcover": 4,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57679073676242, 11.339038984654268]),
            {
              "landcover": 4,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6090630756296, 11.347959312735039]),
            {
              "landcover": 4,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61867611273898, 11.348295923433222]),
            {
              "landcover": 4,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6255425678171, 11.33920729530972]),
            {
              "landcover": 4,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63343899115695, 11.337355872646913]),
            {
              "landcover": 4,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65026180609836, 11.355364656395833]),
            {
              "landcover": 4,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64236538275851, 11.351157098342128]),
            {
              "landcover": 4,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62725918158664, 11.327088674782201]),
            {
              "landcover": 4,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59996502265109, 11.324563897526614]),
            {
              "landcover": 4,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60768978461398, 11.339880536940036]),
            {
              "landcover": 4,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61781780585422, 11.32995006206406]),
            {
              "landcover": 4,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62296764716281, 11.308573124355734]),
            {
              "landcover": 4,
              "system:index": "247"
            })]),
    Nuoc = ui.import && ui.import("Nuoc", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            106.60338786749826,
            11.111132931975682
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59997609763131,
            11.11043810119446
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60542634634957,
            11.11136454186836
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5971651425837,
            11.109237935038454
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59403232245431,
            11.106500695513683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60763648657785,
            11.111659317829448
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59482625632272,
            11.104942563087523
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5951481214045,
            11.10397399009005
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59705785422311,
            11.09946797781271
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59673598914132,
            11.097710113944974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59594205527291,
            11.09566763393624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59956840186105,
            11.08996124814251
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59531978278146,
            11.090319216578484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59482625632272,
            11.087918713974346
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59128574042306,
            11.083538798788641
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59285215048776,
            11.077558424065924
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59409669547067,
            11.075936963377936
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59688619284616,
            11.074547132781543
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60319474844918,
            11.072357083299128
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6062417378901,
            11.069050919876865
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61261466650949,
            11.063606750605837
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61463168768869,
            11.062258979444177
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6153183331965,
            11.060953320220472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61662725119577,
            11.05821562877191
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61536124854074,
            11.056909951538367
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61435273795114,
            11.05410904366581
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.614867722082,
            11.052698049868471
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61398795752511,
            11.050044520760991
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59965342913931,
            11.045177823552704
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60235709582632,
            11.041976655801701
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59568375979727,
            11.045746448383605
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60304374133413,
            11.040734087863296
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60392350589102,
            11.040291816650294
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60119838153189,
            11.043577244040524
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59737891589468,
            11.04593598974911
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58870292517953,
            11.03658531722207
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58520532462411,
            11.036964411658078
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58282352301889,
            11.038164874144455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5820510468226,
            11.03978654374742
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58106399390512,
            11.042103199074537
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58080650183969,
            11.04349318349716
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58067775580697,
            11.045304365445663
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58007694098764,
            11.04690493553994
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57936806138518,
            11.048148239390368
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57775873597625,
            11.049748793973974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57627815660003,
            11.05097026396621
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57477611955169,
            11.052486564467474
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57331699784758,
            11.054276631359224
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56327480729583,
            11.045147909826136
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5594338839865,
            11.0457797151902
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55524963792327,
            11.045969256534216
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5460872119284,
            11.052245111899392
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54411310609343,
            11.053635048284098
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54134506639006,
            11.054561668881227
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53909201081755,
            11.05550934600906
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53761143144133,
            11.05612006964644
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53355593141082,
            11.05858401071296
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53209680970672,
            11.060647808660645
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53108829911712,
            11.062732651016441
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53038019593718,
            11.064206773023855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53265470918181,
            11.059510615670499
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53134579118255,
            11.061827115249457
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53014416154387,
            11.065133360204104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52819151338103,
            11.067428756733136
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52544493134978,
            11.069260849311899
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52447933610442,
            11.071177163768844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52441496308806,
            11.073240873004957
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52432913239959,
            11.07526245162121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53017124108261,
            11.084227133846818
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52703842095322,
            11.081236968802592
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5316089051146,
            11.085574803872921
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53317531517929,
            11.087554182963515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53374028166944,
            11.090684243239057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5338046546858,
            11.089989363801227
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53015685042554,
            11.092453019808064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52466368636304,
            11.09047367388689
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52367663344556,
            11.090115705640068
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52198147734815,
            11.09100009698288
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5211446281355,
            11.091821315119406
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52020049056226,
            11.093484801196286
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51910614928418,
            11.095148277803561
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51713204344922,
            11.099001611283606
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51764702758008,
            11.102075819022748
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51657414397413,
            11.100328156948692
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51876282653028,
            11.102391660450255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52221751174146,
            11.103128622452374
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52498555144483,
            11.10399191843178
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52581146183702,
            11.10514958228973
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52664831104967,
            11.106560323166347
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52733495655748,
            11.110350339512424
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5274637025902,
            11.112750657735189
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52778556767198,
            11.114666687052798
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52754953327867,
            11.116308987877716
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52684143009874,
            11.117972334413308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52396610203478,
            11.121467436718891
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52289321842882,
            11.12157271023458
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52012517872545,
            11.122814934847934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51821544590685,
            11.12374133619747
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51641300144884,
            11.125215150456386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51358058872911,
            11.129404953124128
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51712110462877,
            11.124478244258754
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52681997242662,
            11.120562082914418
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5123360437462,
            11.133468372509636
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51169231358263,
            11.135089513641049
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.51124170246813,
            11.135636909906305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61467751405603,
            11.148440958963247
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62497719667321,
            11.155093553756368
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59830911095146,
            11.169102567807078
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56457765038017,
            11.16897626022815
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56457765038017,
            11.16741846223473
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landcover": 3
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([106.60338786749826, 11.111132931975682]),
            {
              "landcover": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59997609763131, 11.11043810119446]),
            {
              "landcover": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60542634634957, 11.11136454186836]),
            {
              "landcover": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5971651425837, 11.109237935038454]),
            {
              "landcover": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59403232245431, 11.106500695513683]),
            {
              "landcover": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60763648657785, 11.111659317829448]),
            {
              "landcover": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59482625632272, 11.104942563087523]),
            {
              "landcover": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5951481214045, 11.10397399009005]),
            {
              "landcover": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59705785422311, 11.09946797781271]),
            {
              "landcover": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59673598914132, 11.097710113944974]),
            {
              "landcover": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59594205527291, 11.09566763393624]),
            {
              "landcover": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59956840186105, 11.08996124814251]),
            {
              "landcover": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59531978278146, 11.090319216578484]),
            {
              "landcover": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59482625632272, 11.087918713974346]),
            {
              "landcover": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59128574042306, 11.083538798788641]),
            {
              "landcover": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59285215048776, 11.077558424065924]),
            {
              "landcover": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59409669547067, 11.075936963377936]),
            {
              "landcover": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59688619284616, 11.074547132781543]),
            {
              "landcover": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60319474844918, 11.072357083299128]),
            {
              "landcover": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6062417378901, 11.069050919876865]),
            {
              "landcover": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61261466650949, 11.063606750605837]),
            {
              "landcover": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61463168768869, 11.062258979444177]),
            {
              "landcover": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6153183331965, 11.060953320220472]),
            {
              "landcover": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61662725119577, 11.05821562877191]),
            {
              "landcover": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61536124854074, 11.056909951538367]),
            {
              "landcover": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61435273795114, 11.05410904366581]),
            {
              "landcover": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([106.614867722082, 11.052698049868471]),
            {
              "landcover": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61398795752511, 11.050044520760991]),
            {
              "landcover": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59965342913931, 11.045177823552704]),
            {
              "landcover": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60235709582632, 11.041976655801701]),
            {
              "landcover": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59568375979727, 11.045746448383605]),
            {
              "landcover": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60304374133413, 11.040734087863296]),
            {
              "landcover": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60392350589102, 11.040291816650294]),
            {
              "landcover": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60119838153189, 11.043577244040524]),
            {
              "landcover": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59737891589468, 11.04593598974911]),
            {
              "landcover": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58870292517953, 11.03658531722207]),
            {
              "landcover": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58520532462411, 11.036964411658078]),
            {
              "landcover": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58282352301889, 11.038164874144455]),
            {
              "landcover": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5820510468226, 11.03978654374742]),
            {
              "landcover": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58106399390512, 11.042103199074537]),
            {
              "landcover": 3,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58080650183969, 11.04349318349716]),
            {
              "landcover": 3,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58067775580697, 11.045304365445663]),
            {
              "landcover": 3,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58007694098764, 11.04690493553994]),
            {
              "landcover": 3,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57936806138518, 11.048148239390368]),
            {
              "landcover": 3,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57775873597625, 11.049748793973974]),
            {
              "landcover": 3,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57627815660003, 11.05097026396621]),
            {
              "landcover": 3,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57477611955169, 11.052486564467474]),
            {
              "landcover": 3,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57331699784758, 11.054276631359224]),
            {
              "landcover": 3,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56327480729583, 11.045147909826136]),
            {
              "landcover": 3,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5594338839865, 11.0457797151902]),
            {
              "landcover": 3,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55524963792327, 11.045969256534216]),
            {
              "landcover": 3,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5460872119284, 11.052245111899392]),
            {
              "landcover": 3,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54411310609343, 11.053635048284098]),
            {
              "landcover": 3,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54134506639006, 11.054561668881227]),
            {
              "landcover": 3,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53909201081755, 11.05550934600906]),
            {
              "landcover": 3,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53761143144133, 11.05612006964644]),
            {
              "landcover": 3,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53355593141082, 11.05858401071296]),
            {
              "landcover": 3,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53209680970672, 11.060647808660645]),
            {
              "landcover": 3,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53108829911712, 11.062732651016441]),
            {
              "landcover": 3,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53038019593718, 11.064206773023855]),
            {
              "landcover": 3,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53265470918181, 11.059510615670499]),
            {
              "landcover": 3,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53134579118255, 11.061827115249457]),
            {
              "landcover": 3,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53014416154387, 11.065133360204104]),
            {
              "landcover": 3,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52819151338103, 11.067428756733136]),
            {
              "landcover": 3,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52544493134978, 11.069260849311899]),
            {
              "landcover": 3,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52447933610442, 11.071177163768844]),
            {
              "landcover": 3,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52441496308806, 11.073240873004957]),
            {
              "landcover": 3,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52432913239959, 11.07526245162121]),
            {
              "landcover": 3,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53017124108261, 11.084227133846818]),
            {
              "landcover": 3,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52703842095322, 11.081236968802592]),
            {
              "landcover": 3,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5316089051146, 11.085574803872921]),
            {
              "landcover": 3,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53317531517929, 11.087554182963515]),
            {
              "landcover": 3,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53374028166944, 11.090684243239057]),
            {
              "landcover": 3,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5338046546858, 11.089989363801227]),
            {
              "landcover": 3,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53015685042554, 11.092453019808064]),
            {
              "landcover": 3,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52466368636304, 11.09047367388689]),
            {
              "landcover": 3,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52367663344556, 11.090115705640068]),
            {
              "landcover": 3,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52198147734815, 11.09100009698288]),
            {
              "landcover": 3,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5211446281355, 11.091821315119406]),
            {
              "landcover": 3,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52020049056226, 11.093484801196286]),
            {
              "landcover": 3,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51910614928418, 11.095148277803561]),
            {
              "landcover": 3,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51713204344922, 11.099001611283606]),
            {
              "landcover": 3,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51764702758008, 11.102075819022748]),
            {
              "landcover": 3,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51657414397413, 11.100328156948692]),
            {
              "landcover": 3,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51876282653028, 11.102391660450255]),
            {
              "landcover": 3,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52221751174146, 11.103128622452374]),
            {
              "landcover": 3,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52498555144483, 11.10399191843178]),
            {
              "landcover": 3,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52581146183702, 11.10514958228973]),
            {
              "landcover": 3,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52664831104967, 11.106560323166347]),
            {
              "landcover": 3,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52733495655748, 11.110350339512424]),
            {
              "landcover": 3,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5274637025902, 11.112750657735189]),
            {
              "landcover": 3,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52778556767198, 11.114666687052798]),
            {
              "landcover": 3,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52754953327867, 11.116308987877716]),
            {
              "landcover": 3,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52684143009874, 11.117972334413308]),
            {
              "landcover": 3,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52396610203478, 11.121467436718891]),
            {
              "landcover": 3,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52289321842882, 11.12157271023458]),
            {
              "landcover": 3,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52012517872545, 11.122814934847934]),
            {
              "landcover": 3,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51821544590685, 11.12374133619747]),
            {
              "landcover": 3,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51641300144884, 11.125215150456386]),
            {
              "landcover": 3,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51358058872911, 11.129404953124128]),
            {
              "landcover": 3,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51712110462877, 11.124478244258754]),
            {
              "landcover": 3,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52681997242662, 11.120562082914418]),
            {
              "landcover": 3,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5123360437462, 11.133468372509636]),
            {
              "landcover": 3,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51169231358263, 11.135089513641049]),
            {
              "landcover": 3,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([106.51124170246813, 11.135636909906305]),
            {
              "landcover": 3,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61467751405603, 11.148440958963247]),
            {
              "landcover": 3,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62497719667321, 11.155093553756368]),
            {
              "landcover": 3,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59830911095146, 11.169102567807078]),
            {
              "landcover": 3,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56457765038017, 11.16897626022815]),
            {
              "landcover": 3,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56457765038017, 11.16741846223473]),
            {
              "landcover": 3,
              "system:index": "109"
            })]),
    CTXayDung = ui.import && ui.import("CTXayDung", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            106.54313569328178,
            11.340352992468933
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57849793693413,
            11.343382555161083
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5855360533892,
            11.370983756258221
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6071653868853,
            11.383605366160655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5990973021685,
            11.38124937478759
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62742142936577,
            11.357688389122723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6372061278521,
            11.34759022781016
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60064225456108,
            11.335135336971582
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58107285758842,
            11.334125457162695
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55841355583061,
            11.322174941934861
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54433732292046,
            11.355163882296852
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60450463554253,
            11.375780033925103
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6002131011187,
            11.36980571079402
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60836701652397,
            11.365766660799604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58527856132378,
            11.366860575825436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58802514335503,
            11.364672741575502
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54613976737846,
            11.362316593604568
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56828408500542,
            11.338754043650713
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57463555595268,
            11.34851590747188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57575135490288,
            11.351881990028623
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58313279411186,
            11.352134444620066
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58587937614311,
            11.356257837997612
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62278657218803,
            11.349189127158786
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63986687919487,
            11.344644863465646
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61763673087944,
            11.335471962781648
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60965447685112,
            11.337660020882673
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60098557731499,
            11.340689612132502
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58991341850151,
            11.3344620841621
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60192971488823,
            11.313169646478661
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57085900565971,
            11.317714410432977
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57472138664116,
            11.323942303110677
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57652383109917,
            11.331600742032007
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63154130241264,
            11.31544203747271
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61643510124077,
            11.307867330713705
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6086245085894,
            11.311654709132208
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6002131011187,
            11.307025684266037
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64836411735405,
            11.318892670792993
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64527421256889,
            11.331432426897226
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63797860404839,
            11.338669888201876
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61360268852104,
            11.34346670922163
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60364632865776,
            11.344392402251081
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54922967216362,
            11.349441584132045
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5493155028521,
            11.357099339528268
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55738358756889,
            11.362737335741757
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59592156669487,
            11.360381171776961
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58124451896538,
            11.357856688783428
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57386307975639,
            11.372919106088643
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59961228629936,
            11.374686153145728
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62055497428764,
            11.360801916769981
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65239815971245,
            11.357183489544818
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63145547172417,
            11.35440652589296
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62579064628471,
            11.351713686843594
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63617615959038,
            11.328685904438176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63368706962456,
            11.324730432266001
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62639146110405,
            11.32296307595833
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60450463554253,
            11.302258946717782
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61360268852104,
            11.294683891529873
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61248688957085,
            11.29889228022602
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61918168327202,
            11.28904455388998
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6016722228228,
            11.286266928949024
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60785203239311,
            11.287529489072186
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60690789481987,
            11.291906321169654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58716683647026,
            11.299733950554907
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64467339774956,
            11.278186412705445
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63840775749077,
            11.27827058592129
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67548661491264,
            11.288876213749576
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66716103813042,
            11.303773933740926
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66080956718315,
            11.299565616686763
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65977959892143,
            11.295525574208742
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57360558769096,
            11.29560974234079
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58527856132378,
            11.287507135577199
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58381943961967,
            11.292052306391682
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59317498466362,
            11.270504192038299
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58751015922417,
            11.273534493279124
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62407403251518,
            11.275554676358198
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64896493217339,
            11.273450318675996
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65385728141655,
            11.277069804348029
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66767602226128,
            11.2635175424836
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6309404875933,
            11.2769856307804
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62244324943413,
            11.282204345337998
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6317129637896,
            11.284392810320805
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63368706962456,
            11.288012158110982
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67617326042046,
            11.27311362001704
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67316918632378,
            11.272524396414836
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65531640312065,
            11.25711997961585
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67548661491264,
            11.25147990494757
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67763238212456,
            11.262928299219103
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.70964722892631,
            11.245250440383732
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.69711594840874,
            11.239778502304112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.7045832183062,
            11.23775806814284
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65960793754448,
            11.253921144857047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67548661491264,
            11.244913708732438
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67025094291557,
            11.24390351141784
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68175225517143,
            11.236242733231744
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68621545097221,
            11.248281007537567
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66990762016167,
            11.227824060991955
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65900712272514,
            11.223446254370435
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64621835014214,
            11.224624901145225
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63557534477104,
            11.229928752080076
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62312989494194,
            11.23489576218229
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60699372550835,
            11.238010623187217
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67291169425835,
            11.221678275187376
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.69557099601616,
            11.223951389291651
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.692481091231,
            11.226140297071064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.70432572624077,
            11.216458463979118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.71865945121635,
            11.204166278060809
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.70175080558647,
            11.202313985565262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67763238212456,
            11.204587251973807
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67377000114311,
            11.210396629395083
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66741853019585,
            11.206439529911892
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66973595878471,
            11.202482376282221
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67574410697807,
            11.199198739623945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67952065727104,
            11.196336051623604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68836121818413,
            11.199619720765137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.69728760978569,
            11.199198739623945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6606379058062,
            11.199591828405925
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6496515776812,
            11.201696725127771
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64364342948784,
            11.204643554810707
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63892274162163,
            11.20910583974684
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64201264640678,
            11.213062902735777
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64681916496147,
            11.21668314695009
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63394456168999,
            11.217861821324894
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6291380431353,
            11.210789702958593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62647729179253,
            11.206580026541682
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61609177848686,
            11.197739506625386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6184950377642,
            11.194792606633703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62458901664604,
            11.197655309899107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62973885795464,
            11.19639235606606
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63875108024467,
            11.194203223035451
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64802079460014,
            11.19201407345205
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6470766570269,
            11.194961001727107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6584063079058,
            11.193361244385182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66149621269096,
            11.18889871666591
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66750436088432,
            11.187551524974916
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67085175773491,
            11.186541127095236
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67402749320854,
            11.188814517368778
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68063645622124,
            11.187804123894217
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6606379058062,
            11.17365824535443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65462975761284,
            11.185193924440995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66587357780327,
            11.179299839190454
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60562043449272,
            11.182246896798427
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59738068839897,
            11.170121667890223
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61034112235893,
            11.169027004224196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59205918571342,
            11.165490370314549
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58605103752006,
            11.174584484708317
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57343392631401,
            11.176689563148086
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57300477287163,
            11.183509912314909
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5811586882769,
            11.177447387645673
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55463700553764,
            11.143343326413781
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56665330192436,
            11.144101237930734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5877676512896,
            11.146038113945524
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58313279411186,
            11.139469525599186
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60802369377006,
            11.137364177437615
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60905366203178,
            11.15033287995808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59051423332085,
            11.151932874603876
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54450898429741,
            11.156564388396687
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53918748161186,
            11.148901298336334
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56682496330131,
            11.169700643891998
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57412057182182,
            11.169279619282893
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57806878349174,
            11.173405634108212
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52571206352104,
            11.135427243677539
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52056222221245,
            11.133321866276315
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52442460319389,
            11.123805370527867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52888779899467,
            11.120689282239633
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53661256095756,
            11.114625447390308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54639725944389,
            11.132479711052667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54141907951225,
            11.139553739208827
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5705156829058,
            11.130290096071972
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56390671989311,
            11.13500616941542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55781274101128,
            11.13500616941542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58442025443901,
            11.133153435426454
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56974320670952,
            11.123805370527867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5595293547808,
            11.118415358950392
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55540948173393,
            11.119678651856482
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55120377799858,
            11.112688362461673
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54098992606987,
            11.113025247721188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53987412711967,
            11.105866352259978
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56038766166557,
            11.105361011826753
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56373505851616,
            11.101992053249278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.571631481856,
            11.114962330412443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57721047660698,
            11.110498598791573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5976381804644,
            11.111930369205206
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5947199370562,
            11.120436624972342
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6225290801226,
            11.11883645719401
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6430426146685,
            11.11285680514007
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65480141898979,
            11.117236280632572
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64244179984917,
            11.127342511447091
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60939698478569,
            11.13281657343444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65943627616753,
            11.133153435426454
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65651803275932,
            11.139553739208827
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66630273124565,
            11.131469121569019
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66527276298393,
            11.125237075596775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66278367301811,
            11.107129699515262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66947846671928,
            11.103676537397693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.69273858329643,
            11.098454604907282
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67385583183159,
            11.077060552381067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66492944023003,
            11.078239792881298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65892129203667,
            11.077313247173993
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67068009635796,
            11.07049041119463
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63823609611381,
            11.09062153113207
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63008218070854,
            11.08699971636576
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64424424430717,
            11.075123218386898
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64493088981499,
            11.0719223776088
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64810662528862,
            11.084135924090901
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63806443473686,
            11.105192564821252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.657719662398,
            11.101486706109672
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.67359833976616,
            11.094580207565635
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66364197990288,
            11.094832887219349
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.68278222343315,
            11.084641301236074
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61840920707573,
            11.055412222319436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6141176726519,
            11.065941765552964
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59695153495659,
            11.055833411310475
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59283166190971,
            11.06029797741746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5877676512896,
            11.062740824429893
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58862595817436,
            11.0666156434385
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5811586882769,
            11.076639393907973
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58896928092827,
            11.049683991990596
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60235886833061,
            11.050105189207121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6071653868853,
            11.049262794169422
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61034112235893,
            11.049178554532617
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62999635002006,
            11.051705733115105
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62982468864311,
            11.059624085003442
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62785058280815,
            11.06922690560233
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63918023368706,
            11.06543635612156
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64458756706108,
            11.059539848342768
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64390092155327,
            11.069311139478069
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65385728141655,
            11.06215117356701
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.66922097465385,
            11.06189846569118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54914384147514,
            11.078745180212401
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54768471977104,
            11.06223540947721
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52966027519096,
            11.071416978497545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52579789420952,
            11.073859732786776
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52905946037163,
            11.077987098888423
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53266434928764,
            11.084388612772656
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53995995780815,
            11.089610796641374
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53386597892631,
            11.061224576956949
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53566842338432,
            11.064004357997907
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52605538627495,
            11.095843603648945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52296548148979,
            11.098707281209823
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53661256095756,
            11.099633759115614
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54828553459038,
            11.09525401948994
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55858521720756,
            11.093737940475124
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55712609550346,
            11.098875731956749
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55240540763725,
            11.103002744904567
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57120232841362,
            11.08135633418353
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.57806878349174,
            11.09104266947168
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58965592643608,
            11.09693854250182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58399110099663,
            11.09407484760267
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56665330192436,
            11.07588130712919
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55103211662163,
            11.057975793494128
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54725556632866,
            11.054016622020496
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56794076225151,
            11.062103383422844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58193116447319,
            11.058144267690139
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55017380973686,
            11.08720461652658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52408128043999,
            11.094027062671728
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5320635344683,
            11.101354697769152
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.52425294181694,
            11.131673990504721
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55317788383354,
            11.132553033989126
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55549531242241,
            11.152595661979952
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5851927306353,
            11.15503773651933
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63325791618217,
            11.15840608151441
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62750726005424,
            11.158237665192217
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65608887931694,
            11.173478946719724
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60416131278862,
            11.194276530385729
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61077027580131,
            11.211283970269717
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56648164054741,
            11.191329595144262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55343537589897,
            11.19292936371113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5415907408892,
            11.186446036438339
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54665475150932,
            11.189982414759708
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.54502396842827,
            11.196213071498072
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.53884415885796,
            11.20210681254915
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.55008797904839,
            11.201601639448457
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56038766166557,
            11.203285546353651
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5687132384478,
            11.205642999553108
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58819680473198,
            11.2052220271767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60836701652397,
            11.176341860570378
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5727472808062,
            11.224417744121732
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5533495452105,
            11.227027589586191
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56373505851616,
            11.231573715652562
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58793931266655,
            11.222397202398211
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.58536439201225,
            11.23308907509197
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5782404448687,
            11.244369833992593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5617609526812,
            11.251272767215594
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59077172538628,
            11.244285650859421
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.5910292174517,
            11.25851225114214
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61360268852104,
            11.25918568225209
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60124306938042,
            11.247400410408268
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59549241325249,
            11.239402987067082
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64630418083061,
            11.24588512618459
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62965302726616,
            11.253798189258964
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61566262504448,
            11.266509143806832
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60441880485405,
            11.27273814826022
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63557534477104,
            11.26339459098502
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61574845573296,
            11.307247752325747
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.64939408561577,
            11.300514496982515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.65849213859428,
            11.314065012168777
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63909440299858,
            11.305564453318885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.6221857573687,
            11.329971320532326
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56219010612358,
            11.335357383220511
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56193261405815,
            11.31776814703151
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.56116013786186,
            11.361108091915685
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.63085465690483,
            11.338386998883411
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62441735526909,
            11.29967282894472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.59841065666069,
            11.2747583369367
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.60759454032768,
            11.261879390933439
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.62999635002006,
            11.261626856815724
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.61128525993217,
            11.271896398787845
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landcover": 2
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([106.54313569328178, 11.340352992468933]),
            {
              "landcover": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57849793693413, 11.343382555161083]),
            {
              "landcover": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5855360533892, 11.370983756258221]),
            {
              "landcover": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6071653868853, 11.383605366160655]),
            {
              "landcover": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5990973021685, 11.38124937478759]),
            {
              "landcover": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62742142936577, 11.357688389122723]),
            {
              "landcover": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6372061278521, 11.34759022781016]),
            {
              "landcover": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60064225456108, 11.335135336971582]),
            {
              "landcover": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58107285758842, 11.334125457162695]),
            {
              "landcover": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55841355583061, 11.322174941934861]),
            {
              "landcover": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54433732292046, 11.355163882296852]),
            {
              "landcover": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60450463554253, 11.375780033925103]),
            {
              "landcover": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6002131011187, 11.36980571079402]),
            {
              "landcover": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60836701652397, 11.365766660799604]),
            {
              "landcover": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58527856132378, 11.366860575825436]),
            {
              "landcover": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58802514335503, 11.364672741575502]),
            {
              "landcover": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54613976737846, 11.362316593604568]),
            {
              "landcover": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56828408500542, 11.338754043650713]),
            {
              "landcover": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57463555595268, 11.34851590747188]),
            {
              "landcover": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57575135490288, 11.351881990028623]),
            {
              "landcover": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58313279411186, 11.352134444620066]),
            {
              "landcover": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58587937614311, 11.356257837997612]),
            {
              "landcover": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62278657218803, 11.349189127158786]),
            {
              "landcover": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63986687919487, 11.344644863465646]),
            {
              "landcover": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61763673087944, 11.335471962781648]),
            {
              "landcover": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60965447685112, 11.337660020882673]),
            {
              "landcover": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60098557731499, 11.340689612132502]),
            {
              "landcover": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58991341850151, 11.3344620841621]),
            {
              "landcover": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60192971488823, 11.313169646478661]),
            {
              "landcover": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57085900565971, 11.317714410432977]),
            {
              "landcover": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57472138664116, 11.323942303110677]),
            {
              "landcover": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57652383109917, 11.331600742032007]),
            {
              "landcover": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63154130241264, 11.31544203747271]),
            {
              "landcover": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61643510124077, 11.307867330713705]),
            {
              "landcover": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6086245085894, 11.311654709132208]),
            {
              "landcover": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6002131011187, 11.307025684266037]),
            {
              "landcover": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64836411735405, 11.318892670792993]),
            {
              "landcover": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64527421256889, 11.331432426897226]),
            {
              "landcover": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63797860404839, 11.338669888201876]),
            {
              "landcover": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61360268852104, 11.34346670922163]),
            {
              "landcover": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60364632865776, 11.344392402251081]),
            {
              "landcover": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54922967216362, 11.349441584132045]),
            {
              "landcover": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5493155028521, 11.357099339528268]),
            {
              "landcover": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55738358756889, 11.362737335741757]),
            {
              "landcover": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59592156669487, 11.360381171776961]),
            {
              "landcover": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58124451896538, 11.357856688783428]),
            {
              "landcover": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57386307975639, 11.372919106088643]),
            {
              "landcover": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59961228629936, 11.374686153145728]),
            {
              "landcover": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62055497428764, 11.360801916769981]),
            {
              "landcover": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65239815971245, 11.357183489544818]),
            {
              "landcover": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63145547172417, 11.35440652589296]),
            {
              "landcover": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62579064628471, 11.351713686843594]),
            {
              "landcover": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63617615959038, 11.328685904438176]),
            {
              "landcover": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63368706962456, 11.324730432266001]),
            {
              "landcover": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62639146110405, 11.32296307595833]),
            {
              "landcover": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60450463554253, 11.302258946717782]),
            {
              "landcover": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61360268852104, 11.294683891529873]),
            {
              "landcover": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61248688957085, 11.29889228022602]),
            {
              "landcover": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61918168327202, 11.28904455388998]),
            {
              "landcover": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6016722228228, 11.286266928949024]),
            {
              "landcover": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60785203239311, 11.287529489072186]),
            {
              "landcover": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60690789481987, 11.291906321169654]),
            {
              "landcover": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58716683647026, 11.299733950554907]),
            {
              "landcover": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64467339774956, 11.278186412705445]),
            {
              "landcover": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63840775749077, 11.27827058592129]),
            {
              "landcover": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67548661491264, 11.288876213749576]),
            {
              "landcover": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66716103813042, 11.303773933740926]),
            {
              "landcover": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66080956718315, 11.299565616686763]),
            {
              "landcover": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65977959892143, 11.295525574208742]),
            {
              "landcover": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57360558769096, 11.29560974234079]),
            {
              "landcover": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58527856132378, 11.287507135577199]),
            {
              "landcover": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58381943961967, 11.292052306391682]),
            {
              "landcover": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59317498466362, 11.270504192038299]),
            {
              "landcover": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58751015922417, 11.273534493279124]),
            {
              "landcover": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62407403251518, 11.275554676358198]),
            {
              "landcover": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64896493217339, 11.273450318675996]),
            {
              "landcover": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65385728141655, 11.277069804348029]),
            {
              "landcover": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66767602226128, 11.2635175424836]),
            {
              "landcover": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6309404875933, 11.2769856307804]),
            {
              "landcover": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62244324943413, 11.282204345337998]),
            {
              "landcover": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6317129637896, 11.284392810320805]),
            {
              "landcover": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63368706962456, 11.288012158110982]),
            {
              "landcover": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67617326042046, 11.27311362001704]),
            {
              "landcover": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67316918632378, 11.272524396414836]),
            {
              "landcover": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65531640312065, 11.25711997961585]),
            {
              "landcover": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67548661491264, 11.25147990494757]),
            {
              "landcover": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67763238212456, 11.262928299219103]),
            {
              "landcover": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([106.70964722892631, 11.245250440383732]),
            {
              "landcover": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([106.69711594840874, 11.239778502304112]),
            {
              "landcover": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([106.7045832183062, 11.23775806814284]),
            {
              "landcover": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65960793754448, 11.253921144857047]),
            {
              "landcover": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67548661491264, 11.244913708732438]),
            {
              "landcover": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67025094291557, 11.24390351141784]),
            {
              "landcover": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68175225517143, 11.236242733231744]),
            {
              "landcover": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68621545097221, 11.248281007537567]),
            {
              "landcover": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66990762016167, 11.227824060991955]),
            {
              "landcover": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65900712272514, 11.223446254370435]),
            {
              "landcover": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64621835014214, 11.224624901145225]),
            {
              "landcover": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63557534477104, 11.229928752080076]),
            {
              "landcover": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62312989494194, 11.23489576218229]),
            {
              "landcover": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60699372550835, 11.238010623187217]),
            {
              "landcover": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67291169425835, 11.221678275187376]),
            {
              "landcover": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([106.69557099601616, 11.223951389291651]),
            {
              "landcover": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([106.692481091231, 11.226140297071064]),
            {
              "landcover": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([106.70432572624077, 11.216458463979118]),
            {
              "landcover": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([106.71865945121635, 11.204166278060809]),
            {
              "landcover": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([106.70175080558647, 11.202313985565262]),
            {
              "landcover": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67763238212456, 11.204587251973807]),
            {
              "landcover": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67377000114311, 11.210396629395083]),
            {
              "landcover": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66741853019585, 11.206439529911892]),
            {
              "landcover": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66973595878471, 11.202482376282221]),
            {
              "landcover": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67574410697807, 11.199198739623945]),
            {
              "landcover": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67952065727104, 11.196336051623604]),
            {
              "landcover": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68836121818413, 11.199619720765137]),
            {
              "landcover": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([106.69728760978569, 11.199198739623945]),
            {
              "landcover": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6606379058062, 11.199591828405925]),
            {
              "landcover": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6496515776812, 11.201696725127771]),
            {
              "landcover": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64364342948784, 11.204643554810707]),
            {
              "landcover": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63892274162163, 11.20910583974684]),
            {
              "landcover": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64201264640678, 11.213062902735777]),
            {
              "landcover": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64681916496147, 11.21668314695009]),
            {
              "landcover": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63394456168999, 11.217861821324894]),
            {
              "landcover": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6291380431353, 11.210789702958593]),
            {
              "landcover": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62647729179253, 11.206580026541682]),
            {
              "landcover": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61609177848686, 11.197739506625386]),
            {
              "landcover": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6184950377642, 11.194792606633703]),
            {
              "landcover": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62458901664604, 11.197655309899107]),
            {
              "landcover": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62973885795464, 11.19639235606606]),
            {
              "landcover": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63875108024467, 11.194203223035451]),
            {
              "landcover": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64802079460014, 11.19201407345205]),
            {
              "landcover": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6470766570269, 11.194961001727107]),
            {
              "landcover": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6584063079058, 11.193361244385182]),
            {
              "landcover": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66149621269096, 11.18889871666591]),
            {
              "landcover": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66750436088432, 11.187551524974916]),
            {
              "landcover": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67085175773491, 11.186541127095236]),
            {
              "landcover": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67402749320854, 11.188814517368778]),
            {
              "landcover": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68063645622124, 11.187804123894217]),
            {
              "landcover": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6606379058062, 11.17365824535443]),
            {
              "landcover": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65462975761284, 11.185193924440995]),
            {
              "landcover": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66587357780327, 11.179299839190454]),
            {
              "landcover": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60562043449272, 11.182246896798427]),
            {
              "landcover": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59738068839897, 11.170121667890223]),
            {
              "landcover": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61034112235893, 11.169027004224196]),
            {
              "landcover": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59205918571342, 11.165490370314549]),
            {
              "landcover": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58605103752006, 11.174584484708317]),
            {
              "landcover": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57343392631401, 11.176689563148086]),
            {
              "landcover": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57300477287163, 11.183509912314909]),
            {
              "landcover": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5811586882769, 11.177447387645673]),
            {
              "landcover": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55463700553764, 11.143343326413781]),
            {
              "landcover": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56665330192436, 11.144101237930734]),
            {
              "landcover": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5877676512896, 11.146038113945524]),
            {
              "landcover": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58313279411186, 11.139469525599186]),
            {
              "landcover": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60802369377006, 11.137364177437615]),
            {
              "landcover": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60905366203178, 11.15033287995808]),
            {
              "landcover": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59051423332085, 11.151932874603876]),
            {
              "landcover": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54450898429741, 11.156564388396687]),
            {
              "landcover": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53918748161186, 11.148901298336334]),
            {
              "landcover": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56682496330131, 11.169700643891998]),
            {
              "landcover": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57412057182182, 11.169279619282893]),
            {
              "landcover": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57806878349174, 11.173405634108212]),
            {
              "landcover": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52571206352104, 11.135427243677539]),
            {
              "landcover": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52056222221245, 11.133321866276315]),
            {
              "landcover": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52442460319389, 11.123805370527867]),
            {
              "landcover": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52888779899467, 11.120689282239633]),
            {
              "landcover": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53661256095756, 11.114625447390308]),
            {
              "landcover": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54639725944389, 11.132479711052667]),
            {
              "landcover": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54141907951225, 11.139553739208827]),
            {
              "landcover": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5705156829058, 11.130290096071972]),
            {
              "landcover": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56390671989311, 11.13500616941542]),
            {
              "landcover": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55781274101128, 11.13500616941542]),
            {
              "landcover": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58442025443901, 11.133153435426454]),
            {
              "landcover": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56974320670952, 11.123805370527867]),
            {
              "landcover": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5595293547808, 11.118415358950392]),
            {
              "landcover": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55540948173393, 11.119678651856482]),
            {
              "landcover": 2,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55120377799858, 11.112688362461673]),
            {
              "landcover": 2,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54098992606987, 11.113025247721188]),
            {
              "landcover": 2,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53987412711967, 11.105866352259978]),
            {
              "landcover": 2,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56038766166557, 11.105361011826753]),
            {
              "landcover": 2,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56373505851616, 11.101992053249278]),
            {
              "landcover": 2,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([106.571631481856, 11.114962330412443]),
            {
              "landcover": 2,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57721047660698, 11.110498598791573]),
            {
              "landcover": 2,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5976381804644, 11.111930369205206]),
            {
              "landcover": 2,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5947199370562, 11.120436624972342]),
            {
              "landcover": 2,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6225290801226, 11.11883645719401]),
            {
              "landcover": 2,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6430426146685, 11.11285680514007]),
            {
              "landcover": 2,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65480141898979, 11.117236280632572]),
            {
              "landcover": 2,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64244179984917, 11.127342511447091]),
            {
              "landcover": 2,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60939698478569, 11.13281657343444]),
            {
              "landcover": 2,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65943627616753, 11.133153435426454]),
            {
              "landcover": 2,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65651803275932, 11.139553739208827]),
            {
              "landcover": 2,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66630273124565, 11.131469121569019]),
            {
              "landcover": 2,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66527276298393, 11.125237075596775]),
            {
              "landcover": 2,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66278367301811, 11.107129699515262]),
            {
              "landcover": 2,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66947846671928, 11.103676537397693]),
            {
              "landcover": 2,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([106.69273858329643, 11.098454604907282]),
            {
              "landcover": 2,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67385583183159, 11.077060552381067]),
            {
              "landcover": 2,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66492944023003, 11.078239792881298]),
            {
              "landcover": 2,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65892129203667, 11.077313247173993]),
            {
              "landcover": 2,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67068009635796, 11.07049041119463]),
            {
              "landcover": 2,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63823609611381, 11.09062153113207]),
            {
              "landcover": 2,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63008218070854, 11.08699971636576]),
            {
              "landcover": 2,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64424424430717, 11.075123218386898]),
            {
              "landcover": 2,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64493088981499, 11.0719223776088]),
            {
              "landcover": 2,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64810662528862, 11.084135924090901]),
            {
              "landcover": 2,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63806443473686, 11.105192564821252]),
            {
              "landcover": 2,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([106.657719662398, 11.101486706109672]),
            {
              "landcover": 2,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([106.67359833976616, 11.094580207565635]),
            {
              "landcover": 2,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66364197990288, 11.094832887219349]),
            {
              "landcover": 2,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([106.68278222343315, 11.084641301236074]),
            {
              "landcover": 2,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61840920707573, 11.055412222319436]),
            {
              "landcover": 2,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6141176726519, 11.065941765552964]),
            {
              "landcover": 2,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59695153495659, 11.055833411310475]),
            {
              "landcover": 2,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59283166190971, 11.06029797741746]),
            {
              "landcover": 2,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5877676512896, 11.062740824429893]),
            {
              "landcover": 2,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58862595817436, 11.0666156434385]),
            {
              "landcover": 2,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5811586882769, 11.076639393907973]),
            {
              "landcover": 2,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58896928092827, 11.049683991990596]),
            {
              "landcover": 2,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60235886833061, 11.050105189207121]),
            {
              "landcover": 2,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6071653868853, 11.049262794169422]),
            {
              "landcover": 2,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61034112235893, 11.049178554532617]),
            {
              "landcover": 2,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62999635002006, 11.051705733115105]),
            {
              "landcover": 2,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62982468864311, 11.059624085003442]),
            {
              "landcover": 2,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62785058280815, 11.06922690560233]),
            {
              "landcover": 2,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63918023368706, 11.06543635612156]),
            {
              "landcover": 2,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64458756706108, 11.059539848342768]),
            {
              "landcover": 2,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64390092155327, 11.069311139478069]),
            {
              "landcover": 2,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65385728141655, 11.06215117356701]),
            {
              "landcover": 2,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([106.66922097465385, 11.06189846569118]),
            {
              "landcover": 2,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54914384147514, 11.078745180212401]),
            {
              "landcover": 2,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54768471977104, 11.06223540947721]),
            {
              "landcover": 2,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52966027519096, 11.071416978497545]),
            {
              "landcover": 2,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52579789420952, 11.073859732786776]),
            {
              "landcover": 2,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52905946037163, 11.077987098888423]),
            {
              "landcover": 2,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53266434928764, 11.084388612772656]),
            {
              "landcover": 2,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53995995780815, 11.089610796641374]),
            {
              "landcover": 2,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53386597892631, 11.061224576956949]),
            {
              "landcover": 2,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53566842338432, 11.064004357997907]),
            {
              "landcover": 2,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52605538627495, 11.095843603648945]),
            {
              "landcover": 2,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52296548148979, 11.098707281209823]),
            {
              "landcover": 2,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53661256095756, 11.099633759115614]),
            {
              "landcover": 2,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54828553459038, 11.09525401948994]),
            {
              "landcover": 2,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55858521720756, 11.093737940475124]),
            {
              "landcover": 2,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55712609550346, 11.098875731956749]),
            {
              "landcover": 2,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55240540763725, 11.103002744904567]),
            {
              "landcover": 2,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57120232841362, 11.08135633418353]),
            {
              "landcover": 2,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([106.57806878349174, 11.09104266947168]),
            {
              "landcover": 2,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58965592643608, 11.09693854250182]),
            {
              "landcover": 2,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58399110099663, 11.09407484760267]),
            {
              "landcover": 2,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56665330192436, 11.07588130712919]),
            {
              "landcover": 2,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55103211662163, 11.057975793494128]),
            {
              "landcover": 2,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54725556632866, 11.054016622020496]),
            {
              "landcover": 2,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56794076225151, 11.062103383422844]),
            {
              "landcover": 2,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58193116447319, 11.058144267690139]),
            {
              "landcover": 2,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55017380973686, 11.08720461652658]),
            {
              "landcover": 2,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52408128043999, 11.094027062671728]),
            {
              "landcover": 2,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5320635344683, 11.101354697769152]),
            {
              "landcover": 2,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([106.52425294181694, 11.131673990504721]),
            {
              "landcover": 2,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55317788383354, 11.132553033989126]),
            {
              "landcover": 2,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55549531242241, 11.152595661979952]),
            {
              "landcover": 2,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5851927306353, 11.15503773651933]),
            {
              "landcover": 2,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63325791618217, 11.15840608151441]),
            {
              "landcover": 2,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62750726005424, 11.158237665192217]),
            {
              "landcover": 2,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65608887931694, 11.173478946719724]),
            {
              "landcover": 2,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60416131278862, 11.194276530385729]),
            {
              "landcover": 2,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61077027580131, 11.211283970269717]),
            {
              "landcover": 2,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56648164054741, 11.191329595144262]),
            {
              "landcover": 2,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55343537589897, 11.19292936371113]),
            {
              "landcover": 2,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5415907408892, 11.186446036438339]),
            {
              "landcover": 2,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54665475150932, 11.189982414759708]),
            {
              "landcover": 2,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([106.54502396842827, 11.196213071498072]),
            {
              "landcover": 2,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([106.53884415885796, 11.20210681254915]),
            {
              "landcover": 2,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([106.55008797904839, 11.201601639448457]),
            {
              "landcover": 2,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56038766166557, 11.203285546353651]),
            {
              "landcover": 2,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5687132384478, 11.205642999553108]),
            {
              "landcover": 2,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58819680473198, 11.2052220271767]),
            {
              "landcover": 2,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60836701652397, 11.176341860570378]),
            {
              "landcover": 2,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5727472808062, 11.224417744121732]),
            {
              "landcover": 2,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5533495452105, 11.227027589586191]),
            {
              "landcover": 2,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56373505851616, 11.231573715652562]),
            {
              "landcover": 2,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58793931266655, 11.222397202398211]),
            {
              "landcover": 2,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([106.58536439201225, 11.23308907509197]),
            {
              "landcover": 2,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5782404448687, 11.244369833992593]),
            {
              "landcover": 2,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5617609526812, 11.251272767215594]),
            {
              "landcover": 2,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59077172538628, 11.244285650859421]),
            {
              "landcover": 2,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([106.5910292174517, 11.25851225114214]),
            {
              "landcover": 2,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61360268852104, 11.25918568225209]),
            {
              "landcover": 2,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60124306938042, 11.247400410408268]),
            {
              "landcover": 2,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59549241325249, 11.239402987067082]),
            {
              "landcover": 2,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64630418083061, 11.24588512618459]),
            {
              "landcover": 2,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62965302726616, 11.253798189258964]),
            {
              "landcover": 2,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61566262504448, 11.266509143806832]),
            {
              "landcover": 2,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60441880485405, 11.27273814826022]),
            {
              "landcover": 2,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63557534477104, 11.26339459098502]),
            {
              "landcover": 2,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61574845573296, 11.307247752325747]),
            {
              "landcover": 2,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([106.64939408561577, 11.300514496982515]),
            {
              "landcover": 2,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([106.65849213859428, 11.314065012168777]),
            {
              "landcover": 2,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63909440299858, 11.305564453318885]),
            {
              "landcover": 2,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([106.6221857573687, 11.329971320532326]),
            {
              "landcover": 2,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56219010612358, 11.335357383220511]),
            {
              "landcover": 2,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56193261405815, 11.31776814703151]),
            {
              "landcover": 2,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([106.56116013786186, 11.361108091915685]),
            {
              "landcover": 2,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([106.63085465690483, 11.338386998883411]),
            {
              "landcover": 2,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62441735526909, 11.29967282894472]),
            {
              "landcover": 2,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([106.59841065666069, 11.2747583369367]),
            {
              "landcover": 2,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([106.60759454032768, 11.261879390933439]),
            {
              "landcover": 2,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([106.62999635002006, 11.261626856815724]),
            {
              "landcover": 2,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([106.61128525993217, 11.271896398787845]),
            {
              "landcover": 2,
              "system:index": "306"
            })]),
    anh2015 = ui.import && ui.import("anh2015", "image", {
      "id": "projects/ee-bencat/assets/anh_2015"
    }) || ee.Image("projects/ee-bencat/assets/anh_2015"),
    khuvuc2 = ui.import && ui.import("khuvuc2", "table", {
      "id": "projects/ee-bencat/assets/bencat"
    }) || ee.FeatureCollection("projects/ee-bencat/assets/bencat"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.MultiPoint();
var khuvuc = ee.FeatureCollection("projects/ee-bencat/assets/bencat");
Map.addLayer(khuvuc, {color: 'blue'}, 'Huyện Bến Cát', 1);
Map.centerObject(khuvuc,11);
var panel = ui.Panel ({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    width:'400px',
    border:'5px solid green'
  // backgroundColor: '90EE90'
    }
} );
var imageCollection = ee.ImageCollection("LANDSAT/LC08/C02/T1_TOA")
          .filterDate('2015-01-01','2015-12-30')
        //  .filter(ee.Filter.bounds(vn_huyen))
        // .filter(ee.Filter.lt('CLOUD_COVER',10));
//print(imageCollection)         
// thiết lập màu               
var pallete = { bands: ['B4', 'B3', 'B2'], // tổ hợp màu
min: 0, //xác định biên độ của phổ màu
max: 0.4,
gamma: 1.2 // xác định bảng màu dùng để hiển thị
};
// loc trung binh + cat anh
var image = imageCollection.median().clip(khuvuc)
Map.addLayer(image,pallete, 'Ảnh Landsat 8 khu vực Huyện Bến Cát',1);
//Tải ảnh
Export.image.toAsset({
image: image,// tên ảnh cần xuất
description: 'Ld_9',// đặt tên mô tả khi xuất ảnh
assetId: 'Ld_9',
scale: 10,
region: khuvuc,
});
var NDVI_2015 = image.normalizedDifference(['B5','B4']).rename('NDVI được chọn');
var viz = {
  min: -1 ,
  max: 1 ,
  palette: [
'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
'66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
'012E01', '011D01', '011301'
],
};
Map.addLayer(NDVI_2015, viz,'Ảnh NDVI huyện Vĩnh Cửu 2015',0);
var min = ee.Number(NDVI_2015.reduceRegion({
reducer: ee.Reducer.min(),
geometry: khuvuc,
scale: 30,
maxPixels: 1e9
}).values().get(0));
print(min, 'MIN OF NDVI_2015 ');
var max = ee.Number(NDVI_2015.reduceRegion({
reducer: ee.Reducer.max(),
geometry: khuvuc,
scale: 30,
maxPixels: 1e9
}).values().get(0));
print(max, 'MAX OF NDVI_2015');
var inspector2015 = ui.Panel({ 
  style: {
    position: 'top-left',
    padding: '3px 3px',
    color:'black',
      }
});
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector2015.clear();
  inspector2015.style().set('shown', true);
  inspector2015.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = NDVI_2015.reduce(ee.Reducer.mean());// *************  sua biến VV thành biến khai báo chỉ số ****************
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
print(computedValue,"kết quả chỉ số NDVI 2015");// *************  sua VV****************
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector2015.clear();
    // Add a label with the results from the server.
    inspector2015.add(ui.Label({
      value: 'Kết quả chỉ số NDVI năm 2015: ' + result.toFixed(2),// *************  sua MEAN VV****************
      style: {stretch: 'vertical'}
    }));
    // Add a button to hide the Panel.
    inspector2015.add(ui.Button({
      label: 'Close',
      onClick: function() {
        inspector2015.style().set('shown', false);
      }
    }));
  });
});
function classify(index){
  return NDVI_2015.expression(
    'b(0) < 0.05   ? 1'+//  <0.05// mặt nước,
    ': b(0) < 0.12   ? 2'+ // 0.05 -0.12 // đất trống
    // ': b(0) < 0.31 ? 3'+ // 0.12-0.31// đất khác
    ': b(0) < 0.5 ? 3'+ // 0.31-0.38// CTXayDung
    ': b(0) >= 0.5 ? 4'+ // 0.38// rung trong
                ': 0');  }
var classify_img = classify(NDVI_2015 ).clip(khuvuc);     
var viz = {
  min: 1,
  max:4,
  palette: ['0000FF','FF0000','FFFF00','00FF00']
}
Map.addLayer(classify_img,viz,'ảnh giải đoán có kiểm định năm 2015',1);
var names = ['ID_1 mặt nước', 'ID_2 đất trống','ID_3 Công Trình Xây Dựng','ID_5 thực vật'];// sua ten doi tuong
var count = classify_img.eq([1,2,3,4]).rename(names);// sua ten bien (dung phan loai)
var total = count.multiply(ee.Image.pixelArea()).divide(100*100);
var title = ui.Label(' Bản đồ lớp phủ huyện Bến Cát năm 2015', {
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight: 'bold',
  fontSize: '25px',
  color: 'FF0000',
});
Map.add(title);
var composite1 = imageCollection.median();
var composite = composite1.clip(khuvuc);
Map.addLayer(composite);
var newfc = DatTrong.merge(CTXayDung).merge(Thucvat).merge(Nuoc);
print(newfc, 'newfc');
var bands = ['B4','B3','B2'];
var training = composite.select(bands).sampleRegions({
  collection: newfc,
  properties: ['landcover'],
  scale: 30
});
print(training);
var withRandom = training.randomColumn('random');
var split = 0.7;
var trainingPartition = withRandom.filter(ee.Filter.lt('random', split));
var testingPartition = withRandom.filter(ee.Filter.gte('random', split));
var classifier = ee.Classifier.smileCart().train({
  features: trainingPartition,
  classProperty: 'landcover',
  inputProperties: bands
});
var classified = composite.select(bands).classify(classifier);
var palette = [
  '#d04110',
  '#ffc82d',
  '#98ff00',
  '#00ffff',
];
Map.addLayer(classified, {min: 1, max: 4, palette: palette}, 'Ảnh giải đoán có kiểm định năm 2021',0);
var trainAnccuracy = classifier.confusionMatrix();
print('Matrix', trainAnccuracy);
// print('',trainAnccuracy.accuracy(),0);
// print('Data before classification', testingPartition);
var test = testingPartition.classify(classifier);
// print('The classified set', test);
var confusionMatrix = test.errorMatrix('landcover', 'classification');
print('Confusion Matrix', confusionMatrix);
print('Độ chính xác toàn cục: ', confusionMatrix.accuracy());
// print ('kappa', classifier.confusionMatrix().kappa());
Export.image.toAsset({
image: classify_img,// tên ảnh cần xuất
description: 'anhgiaidoancokiemdinh2015',// đặt tên mô tả khi xuất ảnh
assetId: 'anhgiaidoancokiemdinh2015',
scale: 10,
region: khuvuc,
});
//-------------- chen thumbnail vao panel--------------------
var name_1 = ui.Label('Lớp phủ thị xã An Nhơn, tỉnh Bình Định năm 2015',{
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight:'bold',
  fontSize:'18px',
//  backgroundColor: '90EE90',
  backgroundColor: '006400',
color:'ffffff',
   padding:'5px 10px 5px 15px ',
    margin: '10px 5px'  ,
});
panel.add(name_1);
// tạo mảng
var list = [anh2015];
// Tạo tập ảnh
var collection_img =ee.ImageCollection.fromImages(list);
// Tạo thumbnail
// Khai báo params
var params_thumbnail={
  dimensions:'600',//Kích thước tối đa của hình thu nhỏ để hiển thị
  region:khuvuc2,// sua khu vuc nghien cuu
   framesPerSecond: 0.5//The framerate of the exported video. Must be a value between 0.1 and 100. Defaults to 1
};
var style_thumbnail={
  position:'bottom-right',
  width:'250px',
  margin:'auto'
  };
// 
//ui.Thumbnail(image, params, onClick, style)
var thumbmail =  ui.Thumbnail({
  image: collection_img,
  params: params_thumbnail,
  style: style_thumbnail
}
  );
  // hiển thị thumbnail
 // Map.add(thumbmail);
  panel.add(thumbmail);
// 
var name_2 = ui.Label('Diện tích lớp phủ năm 2015',{
 stretch: 'horizontal',
  textAlign: 'center',
  fontWeight:'bold',
  fontSize:'18px',
backgroundColor: '006400',
color:'ffffff',
   padding:'5px 10px 5px 15px ',
    margin: '15px 5px 5px 5px'   ,
});
panel.add(name_2);    
///////////////////////////////////////////////////////////////////////////////////////////////////
//dong 1
var line1=ui.Label({
  value: '______________________________________________________',
  style: { 
    padding:'1px 20px ',//T-R-B-L
    margin: '1px 1px'  ,
    },});
panel.add(line1)
var kc = ui.Label({
  value: "  ",
    style: {margin:'0px 10px 0px 2px', width:'100px',  }});
var table1=ui.Panel({style:{margin:'1px 2px 1px 10px'}, layout: ui.Panel.Layout.flow('horizontal')});
table1.add(ui.Label({value: 'Đối tượng',style: {  fontWeight: 'bold',margin:'1px 0px 0px 2px',padding:'0px 0px 0px 40px'}}));
table1.add(kc); 
table1.add(ui.Label({value: 'Diện tích (ha)',style: {fontWeight: 'bold',margin:'1px 0px 0px 2px'}}));
panel.add(table1)
// dong 2
var line2=ui.Label({
  value: '______________________________________________________',
  style: { 
    padding:'1px 20px ',
    margin: '1px 1px 1px 1px'  ,
    },});
panel.add(line2)
var kc = ui.Label({
  value: "  ",
    style: {margin:'0px 10px 0px 2px', width:'110px',  }});
var table2=ui.Panel({style:{margin:'1px 2px 1px 10px'}, layout: ui.Panel.Layout.flow('horizontal')});
table2.add(ui.Label({value: 'Thực vật',style: { margin:'0px 0px 0px 2px',padding:'0px 0px 0px 40px'}}));
table2.add(kc); 
table2.add(ui.Label({value: '19215',style: {margin:'0px 0px 0px 2px'}}));
panel.add(table2)
// dong 3
var line3=ui.Label({
  value: '______________________________________________________',
  style: { 
    padding:'1px 20px  ',
    margin: '1px 1px'  ,
    },});
panel.add(line3)
var kc = ui.Label({
  value: "  ",
    style: {margin:'0px 10px 0px 2px', width:'110px',  }});
var table3=ui.Panel({style:{margin:'1px 2px 1px 10px'}, layout: ui.Panel.Layout.flow('horizontal')});
table3.add(ui.Label({value: 'Mặt nước',style: { margin:'0px 0px 0px 2px',padding:'0px 0px 0px 40px'}}));
table3.add(kc); 
table3.add(ui.Label({value: '657',style: {margin:'0px 0px 0px 2px'}}));
panel.add(table3)
//dong 4
var line4=ui.Label({
  value: '______________________________________________________',
  style: { 
    padding:'1px 20px  ',
    margin: '1px 1px'  ,
    },});
panel.add(line4)
var kc = ui.Label({
  value: "  ",
    style: {margin:'0px 10px 0px 2px', width:'110px',  }});
var table4=ui.Panel({style:{margin:'1px 2px 1px 10px'}, layout: ui.Panel.Layout.flow('horizontal')});
table4.add(ui.Label({value: 'Đất trống',style: { margin:'0px 0px 0px 2px',padding:'0px 0px 0px 40px'}}));
table4.add(kc); 
table4.add(ui.Label({value: '1032',style: {margin:'0px 0px 0px 2px'}}));
panel.add(table4)
//dong 5
var line5=ui.Label({
  value: '______________________________________________________',
  style: { 
    padding:'1px 20px ',
    margin: '1px 1px'  ,
    },});
panel.add(line5)
var kc = ui.Label({
  value: "  ",
    style: {margin:'0px 10px 0px 2px', width:'45px',  }});
var table5=ui.Panel({style:{margin:'1px 2px 1px 10px'}, layout: ui.Panel.Layout.flow('horizontal')});
table5.add(ui.Label({value: 'Công trình xây dựng',style: { margin:'0px 0px 0px 2px',padding:'0px 0px 0px 40px'}}));
table5.add(kc); 
table5.add(ui.Label({value: '3366',style: {margin:'0px 0px 0px 2px'}}));
panel.add(table5)
var line6=ui.Label({
  value: '______________________________________________________',
  style: { 
    padding:'1px 20px  ',
    margin: '1px 1px'  ,
    },});
panel.add(line6)
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '20px 40px',
    color:'black',
      }
});
// Create and add the legend title.
var legendTitle = ui.Label({
  value: 'CHÚ THÍCH',
  style: {
    fontWeight: 'bold',
    fontSize: '15px',
    margin: '0 0 4px 0',
    padding: '0', 
  }
});
legend.add(legendTitle);
var loading = ui.Label('Loading legend...', {margin: '2px 0 4px 0'});
legend.add(loading);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      // Use padding to give the box height and width.
      padding: '10px',
      margin: '0 0 4px 0',
         }});
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'},
     });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
// Get the list of palette colors and class names from the image.
anh2015.toDictionary().evaluate(function(result) {
  var palette =['0000FF','FF0000','FFFF00','00FF00'];
  var names = ['Mặt Nước', 'Đất Trống','Công Trình Xây Dựng','Thực Vật'];
  loading.style().set('shown', false);
  for (var i = 0; i < names.length; i++) {
    legend.add(makeRow(palette[i], names[i]));
  }
  });
// Add the legend to the map.
Map.add(legend);