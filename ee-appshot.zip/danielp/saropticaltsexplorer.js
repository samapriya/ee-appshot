var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            23.581853782961375,
            61.833006940813824
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#23cba7",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #23cba7 */ee.Geometry.Point([23.581853782961375, 61.833006940813824]);
/*
Author: Daniel Paluba
email: palubad@natur.cuni.cz
(For more info contact me via email: palubad@natur.cuni.cz
  or on LinkedIn: https://www.linkedin.com/in/daniel-paluba/)
This code is free and open. 
By using this code and any data derived with it, 
you agree to cite the following reference 
in any publications derived from them:
THE PUBLICATION WILL BE ADDED. FOLLOW THE GITHUB REPOSITORY OF THE APP:
###########################################################################################################################################################################
*/
var map = ui.Map();
// Replace the default Map with the newly created map.
// ui.root.widgets().reset([map]);
// App title
var header = ui.Label('SAR & Optical Time Series Explorer', {fontSize: '23px', fontWeight: 'bold', color: '77797e'});
// // App summary1
// var text1 = ui.Label(
//   'Set the input parateres above and click on any area on the map.',
//     {fontSize: '15px'});
// App summary2
var text2 = ui.Label(
  "This application enables to explore SAR and optical time series at any point or polygon on the Earth's surface using Copernicus Sentinel-2 a Sentinel-1 data. It was developed especially for the ESA-NASA Trans-Atlantic Training 2023. Developed by Daniel Paluba",
    {fontSize: '12px'});
// Create a panel to hold text
var panel = ui.Panel({
  widgets:[header, text2],//Adds header and text
  style:{width: '500px',position:'middle-right', padding: '10px'}});
// Create variable for additional text and separators
// // This creates another panel to house a line separator and instructions for the user
// var intro = ui.Panel([
//   ui.Label({
//     value: '__________________________________________________________',
//     style: {fontWeight: 'bold',  color: '77797e'},
//   })]);
// Add panel to the larger panel 
// panel.add(intro)
// Add main panel to the root of GUI
ui.root.insert(1,panel)
var symbol = {
  polygon: '🔺',
  point: '📍',
};
var controlPanel = ui.Panel({
  widgets: [
    ui.Label({value:'Select a drawing mode and draw your geometry.', style: {fontSize: '14px', margin: '10px 5px'}}),
    ui.Panel([ui.Button({
      label: symbol.polygon + ' Polygon',
      onClick: drawPolygon,
      style: {stretch: 'vertical',position: 'top-right', textAlign: 'center'}
    }),
    ui.Button({
      label: symbol.point + ' Point',
      onClick: drawPoint,
      style: {stretch: 'vertical',position: 'top-right', textAlign: 'center'}
    })],ui.Panel.Layout.flow('horizontal'), {position: 'top-right', textAlign: 'center' })
  ],
  style: {position: 'top-center'},
  layout: null,
});
panel.add(controlPanel);
// Defining startDate and endDate in the UI
var dateLabel = ui.Label({
    value:'Select start and end dates for time series generation.',
    style: {fontWeight: 'bold', fontSize: '14px', margin: '10px 5px'}
  })
var startLabel = ui.Label({
    value:'Start date',
    style: {margin: '0 55px 0 10px',fontSize: '12px',color: 'gray'}
  })
var endLabel = ui.Label({
    value:'End date',
    style: {margin: '0 0px 0 10px',fontSize: '12px',color: 'gray'}
  })
var startDate_selected = ui.Textbox({placeholder: 'Start Date',  value: '2020-01-01',
  style: {width: '100px'}});
var endDate_selected = ui.Textbox({placeholder: 'End Date',  value: '2022-12-31',
  style: {width: '100px'}});
var index_label = ui.Label('Select optical vegetation indices',
  {fontWeight: 'bold', fontSize: '14px', margin:'5px 0px 0px 8px'});
var index_label_SAR = ui.Label('Select SAR polarimetric indices',
  {fontWeight: 'bold', fontSize: '14px', margin:'5px 0px 0px 8px'});
var cloudSliderLabel = ui.Label('Set the maximum cloud coverage for Sentinel-2 images (in %)',
  {fontWeight: 'bold', fontSize: '14px', margin:'5px 0px 0px 8px'});
// var bufferLabel = ui.Label('Set the buffer around points for TS extraction',
//   {fontWeight: 'bold', fontSize: '14px', margin:'5px 0px 0px 8px'});
// Define checkboxes
var selectNDVI = ui.Checkbox({
  label:'NDVI',
  value: true
});
var selectEVI = ui.Checkbox({
  label:'EVI',
  value: true
});
var selectNDMI = ui.Checkbox({
  label:'NDMI',
  value: true
});
var selectNDWI = ui.Checkbox({
  label:'NDWI',
  value: true
});
var selectNBR = ui.Checkbox({
  label:'NBR',
  value: true
});
// Define checkboxes
var selectRVI = ui.Checkbox({
  label:'RVI',
  value: true
});
var selectRFDI = ui.Checkbox({
  label:'RFDI',
  value: true
});
// var selectDPSVI = ui.Checkbox({
//   label:'DPSVI',
//   value: false
// });
var selectVH_VV = ui.Checkbox({
  label:'VH/VV',
  value: false
});
// Add a slider bar widget
var cloudSlider = ui.Slider({min:0,max:100, style:{width:'200px'}}).setValue(30);
// var bufferSize = ui.Textbox({placeholder: 'Buffer size',
//   style: {width: '100px'}}).setValue('50');
// The START of the code adopted from a GEE tutorial "Interactive Region Reduction App"
// URL https://developers.google.com/earth-engine/tutorials/community/drawing-tools-region-reduction
// developed by Justin Braaten https://github.com/jdbcode
var drawingTools = Map.drawingTools();
drawingTools.setShown(false);
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
var dummyGeometry =
    ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: '23cba7'});
drawingTools.layers().add(dummyGeometry);
function clearGeometry() {
  var layers = drawingTools.layers();
  layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
}
function drawRectangle() {
  clearGeometry();
  drawingTools.setShape('rectangle');
  drawingTools.draw();
}
function drawPolygon() {
  clearGeometry();
  drawingTools.setShape('polygon');
  drawingTools.draw();
}
function drawPoint() {
  clearGeometry();
  drawingTools.setShape('point');
  drawingTools.draw();
}
drawingTools.onDraw(ui.util.debounce(generateCharts, 500));
drawingTools.onEdit(ui.util.debounce(generateCharts, 500));
// The END of the parts adopted from a GEE tutorial "Interactive Region Reduction App"
// URL https://developers.google.com/earth-engine/tutorials/community/drawing-tools-region-reduction
// developed by Justin Braaten https://github.com/jdbcode
// The END of the code adopted from a GEE tutorial "Interactive Region Reduction App"
// URL https://developers.google.com/earth-engine/tutorials/community/drawing-tools-region-reduction
// developed by Justin Braaten https://github.com/jdbcode
panel
  .add(dateLabel)
  .add((ui.Panel([startLabel, endLabel],ui.Panel.Layout.flow('horizontal'))))
  .add((ui.Panel([startDate_selected, endDate_selected],ui.Panel.Layout.flow('horizontal'))))
  .add(index_label)
  .add((ui.Panel([selectNDVI, selectEVI, selectNDMI,selectNDWI, selectNBR],ui.Panel.Layout.flow('horizontal'))))
  .add(index_label_SAR)
  .add((ui.Panel([selectRVI,selectRFDI,selectVH_VV],ui.Panel.Layout.flow('horizontal'))))
  .add(cloudSliderLabel)
  .add(cloudSlider);
  // .add(bufferLabel)
  // .add(bufferSize);
// ========================================================================================
// ======================= CREATE TIME SERIES CHARTS FOR THE APP  =========================
// ========================================================================================
// Map.style().set('cursor', 'crosshair');
// Create the title label.
// var title = ui.Label('Click to generate time series graphs');
// title.style().set('position', 'top-center');
// Map.add(title);
// Create a panel to hold the chart.
var panel2 = ui.Panel();
panel2.style().set({
  width: '500px',
  position: 'bottom-right'
});
panel.add(panel2);
// Register a function to draw a chart when a user clicks on the map.
// Map.style().set('cursor', 'crosshair');
function generateCharts () {
  // reset the Layer list
  Map.layers().reset();
  // reset the Time series panel
  panel2.clear();
  var point = drawingTools.layers().get(0).toGeometry();
  // Set the drawing mode back to null; turns drawing off.
  drawingTools.setShape(null);
  // Reduction scale is based on map scale to avoid memory/timeout errors.
  // var mapScale = Map.getScale();
  var scale = 20;
  // Map.centerObject(point,16);
// Define the input parameters
var startDate = startDate_selected.getValue(),
    endDate = endDate_selected.getValue(),
    cloud_cover = ee.Number(cloudSlider.getValue());
    // buffer = ee.Number(ee.Number.parse(bufferSize.getValue()));
// set the maximum threshold for single image cloud coverage
var max_clouds = cloud_cover;
// create empty lists to add the indices selected from the ckeckboxes
var listOfOpticalVIs = [];
var listOfSARfeatures = [];
// conditions based on checkboxes
if (selectNDVI.getValue() == true) {
  listOfOpticalVIs = ee.List(listOfOpticalVIs).add(selectNDVI.getLabel());
} else {
  listOfOpticalVIs = listOfOpticalVIs;
}
if (selectEVI.getValue() == true) {
  listOfOpticalVIs = ee.List(listOfOpticalVIs).add(selectEVI.getLabel());
} else {
  listOfOpticalVIs = listOfOpticalVIs;
}
if (selectNDMI.getValue() == true) {
  listOfOpticalVIs = ee.List(listOfOpticalVIs).add(selectNDMI.getLabel());
} else {
  listOfOpticalVIs = listOfOpticalVIs;
}
if (selectNDWI.getValue() == true) {
  listOfOpticalVIs = ee.List(listOfOpticalVIs).add(selectNDWI.getLabel());
} else {
  listOfOpticalVIs = listOfOpticalVIs;
}
if (selectNBR.getValue() == true) {
  listOfOpticalVIs = ee.List(listOfOpticalVIs).add(selectNBR.getLabel());
} else {
  listOfOpticalVIs = listOfOpticalVIs;
}
print(listOfOpticalVIs)
if (selectRVI.getValue() == true) {
  listOfSARfeatures = ee.List(listOfSARfeatures).add(selectRVI.getLabel());
} else {
  listOfSARfeatures = listOfSARfeatures;
}
if (selectRFDI.getValue() == true) {
  listOfSARfeatures = ee.List(listOfSARfeatures).add(selectRFDI.getLabel());
} else {
  listOfSARfeatures = listOfSARfeatures;
}
// if (selectDPSVI.getValue() == true) {
//   listOfSARfeatures = ee.List(listOfSARfeatures).add(selectDPSVI.getLabel());
// } else {
//   listOfSARfeatures = listOfSARfeatures;
// }
if (selectVH_VV.getValue() == true) {
  listOfSARfeatures = ee.List(listOfSARfeatures).add(selectVH_VV.getLabel());
} else {
  listOfSARfeatures = listOfSARfeatures;
}
// Add Sentinel-2 data
var S2 = ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
          .filterBounds(point)
          .filterDate(startDate, endDate)
          .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',max_clouds));
print('Original S-2 collection size:', S2.size());
var leastCloudyS2 = S2.sort('CLOUDY_PIXEL_PERCENTAGE').first();
Map.addLayer(leastCloudyS2, {bands:['B4','B3','B2'], min: 0, max: 3000}, 'The least cloudy Sentinel-2 image');
// Add Sentinel-1 data
var S1Collection = ee.ImageCollection('COPERNICUS/S1_GRD_FLOAT')
                  .filterBounds(point)
                  .filterDate(startDate, endDate)
                  .filter(ee.Filter.listContains('transmitterReceiverPolarisation','VH'))
                  // .filter(ee.Filter.eq('orbitProperties_pass','ASCENDING'))
                  // .filter(ee.Filter.lt('relativeOrbitNumber_start',146));
print('S-1 collection size:', S1Collection.size());
print('Least cloudy S2 image',ee.Date(leastCloudyS2.get('system:time_start')));
var S2date = ee.Date(leastCloudyS2.get('system:time_start'));
Map.addLayer(ee.Image(powerToDb(S1Collection.filterDate(S2date,S2date.advance(30,'day')).first())), 
                    {bands:['VH'], min: -25, max: 5}, 
                    'The closest Sentinel-1 image');
// Add the point
// Map.addLayer(point,{'color':'red'}, 'Selected point');
// Function to add optical vegetation indices (VI)
var addOpticalVI = function(img) {
  var EVI = img.expression(
        '2.5 * ((NIR - RED) / (NIR + 6 * RED - 7.5 * BLUE + 1))', {
            'NIR': img.select('B8').divide(10000),
            'RED': img.select('B4').divide(10000),
            'BLUE': img.select('B2').divide(10000)
        }).rename("EVI");
  var NDVI = img.normalizedDifference(['B8', 'B4']).rename('NDVI');
  var NDWI = img.normalizedDifference(['B3', 'B8']).rename('NDWI'),
      NDMI = img.normalizedDifference(['B8', 'B11']).rename('NDMI'),
      NBR = img.normalizedDifference(['B8', 'B12']).rename('NBR');
  return img
    .addBands([NDVI,EVI,NDWI,NDMI, NBR])
      .copyProperties(img,img.propertyNames());
};
// change linear units to dB
function powerToDb (img){
  return ee.Image(10).multiply(img.log10()).copyProperties(img,img.propertyNames());
}
// Function to add radar indices
var addSARIndices = function(img) {
  var VV = ee.Image(img.select('VV')),
      VH = ee.Image(img.select('VH'));
  var RVI = (ee.Image(4).multiply(VH))
            .divide(VV.add(VH)).rename('RVI');
  var RFDI = (VV.subtract(VH))
              .divide(VV.add(VH)).rename('RFDI'); 
  var VH_VV = VH.divide(VV).rename('VH/VV');
  //   // DPSVI from dos Santos et al. (2021) - https://doi.org/10.1080/01431161.2021.1959955
  // var max =  img.reduceRegion({reducer: ee.Reducer.max(), scale: 20,
  //                             geometry: img.geometry(1000), bestEffort: true});
  // var DPSVIi = img.expression(
  //   '(((VVmax - VV)+VH)/1.414213562) * ((VV+VH)/VV) * VH', {
  //     'VH': VH,
  //     'VV':  VV,
  //     'VVmax': ee.Number(max.get('VV'))
  // }).rename('DPSVI');
  // var DPSVIi = img.expression(
  //     '(VV*VV+VV*VH)/1.414213562',{
  //       'VH': VH,
  //       'VV': VV
  //     }).rename('DPSVI');
  // var max2 = DPSVIi.reduceRegion({reducer: ee.Reducer.max(),
  //                             scale: 20,
  //                             geometry: img.geometry(1000),
  //                             bestEffort: true});
  // var min = DPSVIi.reduceRegion({reducer: ee.Reducer.min(),
  //                               scale: 20,
  //                               geometry: img.geometry(1000),
  //                               bestEffort: true});
  // var DPSVI = img.expression(
  //   '(DPSVI - DPSVImin) /(DPSVImax - DPSVImin)',{
  //     'DPSVI': DPSVIi,
  //     'DPSVImax': ee.Number(max2.get('DPSVI')),
  //     'DPSVImin': ee.Number(min.get('DPSVI'))
  //   });
  return img.select('angle')
            .addBands([
                      RVI,
                      RFDI,
                      ee.Image(powerToDb(VH)).rename('VH'), 
                      ee.Image(powerToDb(VV)).rename('VV'),
                      // DPSVI.rename('DPSVI'),
                      VH_VV,
                      ]);
};
S1Collection = S1Collection.map(addSARIndices);
//////////////////////////////// S2CLOUDLESS ////////////////////////////////
{
//Predefined parameters
var CLOUD_FILTER = max_clouds; //filter out images having higher cloudiness than set
var CLD_PRB_THRESH = max_clouds;
var NIR_DRK_THRESH = 0.15;
var CLD_PRJ_DIST = 1;
var BUFFER = 55;
//Load S2 cloud probability collection
var s2_cloudless_col = ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY')
                      .filterDate(startDate, endDate)
                      .filterBounds(point)      
//Load S2 collection
var filtered = S2.filterDate(startDate, endDate)
              .filterBounds(point)
              .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',CLOUD_FILTER));
//Join the collections 
var joinedColl = ee.ImageCollection(ee.Join.saveFirst('s2cloudless').apply
({'primary': filtered,
    'secondary': s2_cloudless_col,
    'condition': ee.Filter.equals({
    'leftField': 'system:index',
    'rightField': 'system:index'
    })
  }));
// print('Joined collection:',col);
//Define cloud mask functions
function add_cloud_bands(img){
  //Get s2cloudless image, subset the probability band.
  var cld_prb = ee.Image(img.get('s2cloudless')).select('probability');
  var origoCLDMSK = img.select('MSK_CLDPRB').gt(5).rename('origo');
  //Condition s2cloudless by the probability threshold value.
  var is_cloud = cld_prb.gt(CLD_PRB_THRESH).add(origoCLDMSK).rename('clouds');
  //Add the cloud probability layer and cloud mask as image bands.
  return img.addBands(ee.Image([cld_prb, is_cloud,origoCLDMSK]));
}  
function add_shadow_bands(img){
  //Identify water pixels from the SCL band.
  var not_water = img.select('SCL').neq(6);
  //Identify dark NIR pixels that are not water (potential cloud shadow pixels).
  var SR_BAND_SCALE = 1e4;
  var dark_pixels = img.select('B8').lt(NIR_DRK_THRESH*SR_BAND_SCALE).multiply(not_water).rename('dark_pixels');
  //Determine the direction to project cloud shadow from clouds (assumes UTM projection).
  var shadow_azimuth = ee.Number(90).subtract(ee.Number(img.get('MEAN_SOLAR_AZIMUTH_ANGLE')));
  //Project shadows from clouds for the distance specified by the CLD_PRJ_DIST input.
  var cld_proj = img.select('clouds').directionalDistanceTransform(shadow_azimuth, CLD_PRJ_DIST*10)
  .reproject({'crs': img.select(0).projection(), 'scale': 100})
  .select('distance')
  .mask()
  .rename('cloud_transform');
  //Identify the intersection of dark pixels with cloud shadow projection.
  var shadows = cld_proj.multiply(dark_pixels).rename('shadows');
  //Add dark pixels, cloud projection, and identified shadows as image bands.
  return img.addBands(ee.Image([dark_pixels, cld_proj, shadows]));
}
function add_cld_shdw_mask(img){
  //Add cloud component bands.
  var img_cloud = add_cloud_bands(img);
  //Add cloud shadow component bands.
  var img_cloud_shadow = add_shadow_bands(img_cloud);
  //Combine cloud and shadow mask, set cloud and shadow as value 1, else 0.
  var is_cld_shdw0 = img_cloud_shadow.select('clouds').add(img_cloud_shadow.select('shadows')).gt(0);
  //Remove small cloud-shadow patches and dilate remaining pixels by BUFFER input.
  //20 m scale is for speed, and assumes clouds don't require 10 m precision.
  var is_cld_shdw = is_cld_shdw0.focal_min(2).focal_max(BUFFER*2/20)
  .reproject({'crs': img.select([0]).projection(), 'scale': 20})
  .rename('cloudmask');
  //Add the final cloud-shadow mask to the image.
  // return img_cloud_shadow.addBands(is_cld_shdw);
  return img.addBands(is_cld_shdw).updateMask(is_cld_shdw.eq(0));
}
}
// Apply the S2Cloudless function
var S2_cloudMasked = joinedColl.map(add_cld_shdw_mask);
var original = ee.Image(filtered.toList(filtered.size()).get(0));
function snowMask (img) {
  var withSnowMask = img.updateMask(img.select('MSK_SNWPRB').gt(5).eq(0))
                              .updateMask(img.select('SCL').eq(11).eq(0));
  return withSnowMask;
}
function SCL_mask (img) {
  var SCL_masked = img.updateMask(img.select('SCL').eq(1).eq(0))
                        .updateMask(img.select('SCL').eq(2).eq(0))
                        .updateMask(img.select('SCL').eq(3).eq(0))
                        .updateMask(img.select('SCL').eq(7).eq(0))
                        .updateMask(img.select('SCL').eq(8).eq(0))
                        .updateMask(img.select('SCL').eq(9).eq(0))
                        .updateMask(img.select('SCL').eq(10).eq(0));
  return SCL_masked;
}  
function QA60Mask (img) {
  var qa = img.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return img.updateMask(mask)//.copyProperties(img,img.propertyNames());
}
// Mask out clouds, shadows, snow
var S2 = S2_cloudMasked
                      .map(snowMask)//.map(function(img){return img.unmask(-9999999999)})
                      .map(SCL_mask)
                      // .map(QA60Mask)
                      .map(addOpticalVI);
// print(S2, 'S2');
S2 = S2.select(listOfOpticalVIs);
  var IndicesChartSAR = ui.Chart.image.series({
      imageCollection: S1Collection.select(listOfSARfeatures),
      region: point,
      reducer  : ee.Reducer.mean(),
      scale: scale,
  }).setOptions({
      title: 'Time-series of SAR RVI'
  });
  var VVVHChart = ui.Chart.image.series({
      imageCollection: S1Collection.select(['VV','VH']),
      region: point,
      reducer: ee.Reducer.mean(),
      scale: scale,
  }).setOptions({
      title: 'Time-series of SAR VV & VH'
  }); 
  var IndicesChartOriginal = ui.Chart.image.series({
      imageCollection: S2.select(listOfOpticalVIs),
      region: point,
      reducer: ee.Reducer.mean(),
      scale: scale,
  }).setOptions({
      title: 'Time-series of optical VI'
  });
  panel2.add(IndicesChartOriginal);
  panel2.add(IndicesChartSAR);
  panel2.add(VVVHChart);
}