var HRSL = ee.ImageCollection("projects/sat-io/open-datasets/hrslpop")
print('Total images',HRSL.size())
//Create a spatial mosaic so image collection becomes a single image
var image=HRSL.median()
//Zoom to some place in the world
Map.setCenter(-4.968, 7.0094,8)
Map.addLayer(image,{min:0.0001, max:0.01, palette:'red'},'HRSL')