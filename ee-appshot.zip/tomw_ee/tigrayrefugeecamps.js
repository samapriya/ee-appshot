var imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "COPERNICUS/S2_SR"
    }) || ee.ImageCollection("COPERNICUS/S2_SR"),
    tigray_camps = ui.import && ui.import("tigray_camps", "table", {
      "id": "users/tomw_ee/tigray_refugee_camps"
    }) || ee.FeatureCollection("users/tomw_ee/tigray_refugee_camps");
Map.setCenter(37.9519, 14.10497, 16);
var s2c_nov_2019 = ee.ImageCollection("COPERNICUS/S2_SR").filterBounds(tigray_camps).filterDate('2019-11-01', '2019-12-31')
.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)).sort('CLOUDY_PIXEL_PERCENTAGE', false)
var s2c_nov19_img = s2c_nov_2019.mosaic();
Map.addLayer(s2c_nov19_img, {bands:['B4','B3','B2'], min:0, max:2500}, 'sentinel2 Nov /Dec 2019', false);
var s2c_oct = ee.ImageCollection("COPERNICUS/S2_SR").filterBounds(tigray_camps).filterDate('2020-10-15', '2020-10-31')
.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)).sort('CLOUDY_PIXEL_PERCENTAGE', false)
var s2c_oct_img = s2c_oct.mosaic();
Map.addLayer(s2c_oct_img, {bands:['B4','B3','B2'], min:0, max:2500}, 'sentinel2 Oct 2020', false);
var s2c_nov = imageCollection.filterBounds(tigray_camps).filterDate('2020-11-15', '2020-11-23');
print(s2c_nov)
var s2c_nov_img = s2c_nov.mosaic();
Map.addLayer(s2c_nov_img, {bands:['B4','B3','B2'], min:0, max:2500}, 'sentinel2 19-22 Nov 2020');
Map.addLayer(tigray_camps, {color:'red'}, 'refugee camps tigray');