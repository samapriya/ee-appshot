var alos = ee.Image("JAXA/ALOS/AW3D30_V1_1"),
    visParams = {"bands":"AVE","min":0,"max":3000};
var label = ui.Label("Click for elevation");
//All assets need to be public and people can also read the source code for this
//Panel is a widget that holds other widgets
//Default panle layout is vertical
var inspector = ui.Panel([label],ui.Panel.Layout.flow("horizontal"));
Map.add(inspector);
function showElevation(elev){
  inspector.clear();
  var titleLabel = ui.Label({
    value: "Elevation: ",
    style: {
      fontWeight: "bold",
      //Take up all the vertical space
      stretch: "vertical"
    }
  })
  var elevationLabel = ui.Label(elev, {stretch: "vertical"});
  var closeButton = ui.Button("Close", function(){
    inspector.clear();
    inspector.style().set("shown",false);
  })
  inspector.add(titleLabel);
  inspector.add(elevationLabel);
  inspector.add(closeButton);
}
//Creating an inspector and getting the elevation
function inspect(coords){
  inspector.clear();
  inspector.style().set("shown", true);
  var pt = ee.Geometry.Point(coords.lon, coords.lat)
  var elevation = alos.reduceRegion({
    reducer: ee.Reducer.first(),
    geometry: pt,
    scale: 30
  }).get("AVE");
  //Retrieves the object value but lets users do other things at the same time
  elevation.evaluate(showElevation);
  print(coords);
}
//Map is passing the coordinates when the function is run
Map.onClick(inspect);
// Set up the map.
Map.addLayer(alos, visParams, 'Elevation');
Map.setCenter(138.7271, 35.3644, 10);
Map.style().set("cursor", "crosshair");