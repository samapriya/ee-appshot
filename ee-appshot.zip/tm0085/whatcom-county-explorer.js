var NLCD = ee.ImageCollection("USGS/NLCD"),
    hansen = ee.Image("UMD/hansen/global_forest_change_2017_v1_5"),
    whatcom = ee.FeatureCollection("users/tm0085/Whatcom_County/Whatcom_County_shp"),
    tree_height = ee.Image("NASA/JPL/global_forest_canopy_height_2005"),
    DEM = ee.Image("USGS/NED"),
    elev_param = {"opacity":1,"bands":["elevation"],"min":-397.93316703133235,"max":2196.8396024389126,"gamma":1},
    gain_param = {"opacity":1,"bands":["gain"],"palette":["0a17b6"]},
    loss_param = {"opacity":1,"bands":["loss"],"palette":["f11dff"]};
// Grab landcover bands from NLCD
NLCD = NLCD.toList(4);
var NLCD_2001 = ee.Image(NLCD.get(1)).select(['landcover']).clip(whatcom);
var NLCD_2006 = ee.Image(NLCD.get(2)).select(['landcover']).clip(whatcom);
var NLCD_2011 = ee.Image(NLCD.get(3)).select(['landcover']).clip(whatcom);
var loss = hansen.select(['loss']).clip(whatcom);
loss = loss.updateMask(loss).multiply(ee.Image.pixelArea())
var gain = hansen.select(['gain']).clip(whatcom);
gain = gain.updateMask(gain).multiply(ee.Image.pixelArea())
var elev = DEM.clip(whatcom);
//Set title of app
var title = ui.Label( 'Whatcom County and Bellingham Data Explorer', {fontWeight: 'bold', fontSize: '24px' ,color: 'green'});
//Calculate area of loss and gain
function getlossgain(){
  var geometry = ee.Geometry.Polygon({
    coords: coords
  })
  Map.addLayer(geometry)
  var area_loss = loss.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: geometry,
    scale: 30,
  });
  var area_gain = gain.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: geometry,
    scale: 30,
  });
  results.add(ui.Chart.image.histogram({
    image: NLCD_2001,
    region: geometry,
    scale: 30,
    maxBuckets: 17
  }).setOptions({title: 'NLCD 2001 Classes'}))
    results.add(ui.Chart.image.histogram({
    image: NLCD_2006,
    region: geometry,
    scale: 30,
    maxBuckets: 17
  }).setOptions({title:'NLCD 2006 Classes'}))
    results.add(ui.Chart.image.histogram({
    image: NLCD_2011,
    region: geometry,
    scale: 30,
    maxBuckets: 17
  }).setOptions({title:'NLCD 2011 Classes'}))
  var loss_num = (ee.String(ee.Number(area_loss.get('loss')).multiply(0.0002471)));
  var gain_num = (ee.String(ee.Number(area_gain.get('loss')).multiply(0.0002471)));
  results2.add(ui.Label('Loss in acres: '))
  var r2_label = ui.Label()
  r2_label.setValue(loss_num)
  print('Loss in acres: ',ee.Number(area_loss.get('loss')).multiply(0.0002471))
  print('Gain in acres: ',ee.Number(area_gain.get('gain')).multiply(0.0002471))
}
//Show points and fill in polygon when clicking on map
var coords = []
var counter = ee.Number(0)
function handleMapClick(location) {
  coords.push([location.lon, location.lat]);
  Map.addLayer(ee.Geometry.Point([location.lon, location.lat]),{},'clicked point')
  counter.add(1)
}
//Apply it to the app
Map.onClick(handleMapClick)
//Add run button
var button_lg = ui.Button('Run loss/gain');
button_lg.onClick(function(){
  getlossgain();
})
function clearResults(){
  var last = Map.layers().length();
  var coords_len = ee.List(coords).length();
  Map.remove(Map.layers().get(last-1))
  results.clear()
  results2.clear()
  coords = []
}
var button_clear = ui.Button('Clear');
button_clear.onClick(function(){
  clearResults();
  results.add(pan_title)
  results2.add(pan_title2)
})
//Map.addLayer(elev, elev_param, "Elevation")
Map.addLayer(NLCD_2001, {}, "NLCD 2001")
Map.addLayer(NLCD_2006, {}, "NLCD 2006")
Map.addLayer(NLCD_2011, {}, "NLCD 2011")
Map.addLayer(loss, loss_param, "Loss")
Map.addLayer(gain, gain_param, "Gain")
var pan_title = ui.Label( 'Results');
var pan_title2 = ui.Label( 'Loss/Gain Results');
Map.add(ui.Panel([title, button_lg, button_clear],ui.Panel.Layout.flow("horizontal")));
var results = ui.Panel({style: {position: 'bottom-right'}}).setLayout(ui.Panel.Layout.flow('horizontal')).add(pan_title);
Map.add(results)
var results2 = ui.Panel({style: {position: 'bottom-left'}}).setLayout(ui.Panel.Layout.flow('vertical')).add(pan_title2);
Map.add(results2)
Map.setCenter(-122.46654599705846,48.75485966935857,11)