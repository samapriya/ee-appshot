var aoi = ui.import && ui.import("aoi", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -15.811135555325887,
                16.37199075585876
              ],
              [
                -15.821435237943074,
                16.352884523931646
              ],
              [
                -15.859200740872762,
                16.321915281816082
              ],
              [
                -15.850960994779012,
                16.30082703455037
              ],
              [
                -15.877053524075887,
                16.292259285522558
              ],
              [
                -15.878426815091512,
                16.275122664225186
              ],
              [
                -15.870187068997762,
                16.233593109164403
              ],
              [
                -15.903832698880574,
                16.20260503207871
              ],
              [
                -15.925118709622762,
                16.13335876605191
              ],
              [
                -15.9766171227087,
                16.111590647954273
              ],
              [
                -15.9326718102087,
                16.106972861113874
              ],
              [
                -15.927865291654012,
                16.06342844808059
              ],
              [
                -15.955331111966512,
                15.992813476522663
              ],
              [
                -15.975930477200887,
                15.9393406834347
              ],
              [
                -15.947778011380574,
                15.916230741989827
              ],
              [
                -15.870187068997762,
                15.91689106293955
              ],
              [
                -15.941598201810262,
                15.94594303508769
              ],
              [
                -15.874306942044637,
                16.048911524564545
              ],
              [
                -15.905892635404012,
                16.112909995879015
              ],
              [
                -15.8228085289587,
                16.172931032210176
              ],
              [
                -15.827615047513387,
                16.203923772938428
              ],
              [
                -15.798775936185262,
                16.229637455927563
              ],
              [
                -15.769936824857137,
                16.336412133645357
              ],
              [
                -15.775429988919637,
                16.366061435805527
              ],
              [
                -15.79808929067745,
                16.381213784288985
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-15.811135555325887, 16.37199075585876],
          [-15.821435237943074, 16.352884523931646],
          [-15.859200740872762, 16.321915281816082],
          [-15.850960994779012, 16.30082703455037],
          [-15.877053524075887, 16.292259285522558],
          [-15.878426815091512, 16.275122664225186],
          [-15.870187068997762, 16.233593109164403],
          [-15.903832698880574, 16.20260503207871],
          [-15.925118709622762, 16.13335876605191],
          [-15.9766171227087, 16.111590647954273],
          [-15.9326718102087, 16.106972861113874],
          [-15.927865291654012, 16.06342844808059],
          [-15.955331111966512, 15.992813476522663],
          [-15.975930477200887, 15.9393406834347],
          [-15.947778011380574, 15.916230741989827],
          [-15.870187068997762, 15.91689106293955],
          [-15.941598201810262, 15.94594303508769],
          [-15.874306942044637, 16.048911524564545],
          [-15.905892635404012, 16.112909995879015],
          [-15.8228085289587, 16.172931032210176],
          [-15.827615047513387, 16.203923772938428],
          [-15.798775936185262, 16.229637455927563],
          [-15.769936824857137, 16.336412133645357],
          [-15.775429988919637, 16.366061435805527],
          [-15.79808929067745, 16.381213784288985]]]),
    region = ui.import && ui.import("region", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -15.97743649538355,
                16.38796930831541
              ],
              [
                -15.97743649538355,
                15.817326465529106
              ],
              [
                -15.76869626100855,
                15.817326465529106
              ],
              [
                -15.76869626100855,
                16.38796930831541
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-15.97743649538355, 16.38796930831541],
          [-15.97743649538355, 15.817326465529106],
          [-15.76869626100855, 15.817326465529106],
          [-15.76869626100855, 16.38796930831541]]], null, false),
    vix = ui.import && ui.import("vix", "imageVisParam", {
      "params": {
        "opacity": 0.8400000000000001,
        "bands": [
          "NDTI"
        ],
        "min": -0.02,
        "max": 0.2,
        "palette": [
          "4337ff",
          "ecff50",
          "9dffa0",
          "ff3414"
        ]
      }
    }) || {"opacity":0.8400000000000001,"bands":["NDTI"],"min":-0.02,"max":0.2,"palette":["4337ff","ecff50","9dffa0","ff3414"]};
var senegal=ee.FeatureCollection("FAO/GAUL/2015/level0").filter(ee.Filter.eq('ADM0_NAME','Senegal'))
var baseMap = require('users/tl2581/packages:baseMap.js');
Map.setOptions('Dark', {'Dark': baseMap.darkTheme});
Map.style().set('cursor', 'crosshair');
Map.centerObject(aoi,12)
var col = ee.ImageCollection("JRC/GSW1_1/YearlyHistory");
col = col.map(function(img) {
  var year = img.date().get('year');
  return img.clip(aoi).gte(2).multiply(year).set('year', year).toInt();
});
var dem = ee.Image('JAXA/ALOS/AW3D30/V2_2').select('AVE_DSM').clip(aoi);
var demMask = dem.gt(0);
var hillshade = ee.Terrain.hillshade(dem.multiply(15))
  .updateMask(demMask)
  .visualize({min:0, max:800, opacity:0.50});
var visLayer = {
  min: 1984,
  max: 2018,
  palette: ['F9FB0E', 'F9BD3F', 'A3BD6A', '33B7A0', '089BCE', '056EDE']
};
var bgColor = '000000';
var riverColor = '056EDE';
var yearSeq = ee.List.sequence(1984, 2018);
var bgImg = ee.Image(1).visualize({palette: bgColor});
var imgLayer = hillshade.blend(col.max().visualize(visLayer));
Map.addLayer(imgLayer,{},'deselected 2 View NDTI');
/*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/ 
var now = ee.Date(Date.now());
var start = now.advance(-100,'day');
var weeks = now.advance(-15,'day');
var doy = now.getRelative('day', 'year');
/*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/ 
function maskS2clouds(image) {
  var qa = image.select('QA60')
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0))
  return image.updateMask(mask).divide(10000)
      .select("B.*")
      .copyProperties(image, ["system:time_start"])
}
/*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/ 
var s2=ee.ImageCollection("COPERNICUS/S2")
        .filterDate(start,now)
        .filterMetadata('CLOUD_COVERAGE_ASSESSMENT','less_than',5)
        .filterBounds(region)
        .map(maskS2clouds)
        .map(function(image){
  var ndti=image.clip(region).normalizedDifference(['B4','B3']).rename('NDTI')
  var turbidityHigh=ndti.clip(region).gt(0.2).selfMask().rename('Hndti')
  var turbidityLow=ndti.clip(region).lt(0.1).selfMask().rename('Lndti')
  return image.addBands([ndti,turbidityHigh,turbidityLow]); 
})
var bands=['NDTI','Hndti','Lndti']
//
var viridis = {min: -0.02 , max : 0.3,palette : ['aqua','navy','red','green']};
var turbidity=ee.Image(s2.select('NDTI').max())
var turbLayer = ui.Map.Layer(turbidity,vix,'NDTI',false)
Map.add(turbLayer)
/*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/ 
var header = ui.Label('Turbidité de l’eau du Lac de Guiers ', {fontSize: '25px', fontWeight: 'bold', color: '#fb6a4a'});
var text = ui.Label(
  "L’application du NDTI permet d’apprécier la turbidité en considérant le degré élevé et le degré " +
  "faible en passant le niveau moyen sur la base d’une classification des valeurs trouvées dans la zone.",
    {fontSize: '15px'});
var panel = ui.Panel({
  widgets:[header, text],
  style:{width: '310px',position:'middle-right'}});
/*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/ 
var intro = ui.Panel([
  ui.Label({
    value: '____________________________________________',
    style: {fontWeight: 'bold',  color: '#fb6a4a'},
  }),
  ui.Label({
    value:'Select layers to display.',
    style: {fontSize: '15px', fontWeight: 'bold'}
  })]);
//Add this new panel to the larger panel we created 
panel.add(intro)
ui.root.insert(0,panel)
var extCheck = ui.Checkbox('faible turbidité').setValue(false); 
var extCheck2 = ui.Checkbox('forte Turbidité').setValue(false);
var ndtiMap = ui.Label({value:'Le degré de turbidité',
style: {fontWeight: 'bold', fontSize: '16px', margin: '10px 5px'}
});
var ndtiCheck = ui.Checkbox('Mensuellement').setValue(false);
var extentLegend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px', 
    width:'65%'
  }
});
/*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/ 
function makeLegend2 (viridis) {
  var lon = ee.Image.pixelLonLat().select('longitude');
  var gradient = lon.multiply((viridis.max-viridis.min)/100.0).add(viridis.min);
  var legendImage = gradient.visualize(viridis);
  var thumb = ui.Thumbnail({
    image: legendImage, 
    params: {bbox:'0,0,100,8', dimensions:'256x20'},  
    style: {position: 'bottom-center'}
  });
  var panel2 = ui.Panel({
    widgets: [
      ui.Label('(NDTI) faible < 0.1'), 
      ui.Label({style: {stretch: 'horizontal'}}), 
      ui.Label('(NDTI) élevé> 0.2')
    ],
    layout: ui.Panel.Layout.flow('horizontal'),
    style: {stretch: 'horizontal', maxWidth: '270px', padding: '0px 0px 0px 0px'}
  });
  return ui.Panel().add(panel2).add(thumb);
}
panel
    .add(extentLegend)
    .add(ndtiMap)
    .add(makeLegend2(viridis))
    .add(ndtiCheck)
    .add(extCheck)
    .add(extCheck2)
 /*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/ 
var doCheckbox4 = function() {
  ndtiCheck.onChange(function(checked){
  turbLayer.setShown(checked)
  })
}
doCheckbox4();
var turbidityLow=ee.Image(s2.select('Lndti').first())
/*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/ 
//getLOW
//Calculate area in Hectares
var getLow = turbidityLow.multiply(ee.Image.pixelArea()).divide(10000).reduceRegion({
      reducer:ee.Reducer.sum(),
      geometry:aoi,
      scale: 1000,
      maxPixels:1e13,
      tileScale: 16
      }).get('Lndti');
var feature = ee.Feature(aoi)
var featureLow = feature.set('areas', ee.Number(getLow)).set('label', ee.String('Low'))
var chartLow = ui.Chart.feature.byProperty(featureLow, ['areas'])
chartLow.setOptions({
  title: 'Faible turbidité',
  vAxis: {title: 'Superficie [Hectares]'},
  legend: {position: 'none'},
  hAxis: {
    title: '',
    logScale: false
  }
}).setChartType('BarChart');
// getHigh
var turbidityHigh=ee.Image(s2.select('Hndti').first())
var getHigh = turbidityHigh.multiply(ee.Image.pixelArea()).divide(10000).reduceRegion({
      reducer:ee.Reducer.sum(),
      geometry:aoi,
      scale: 1000,
      maxPixels:1e13,
      tileScale: 16
      }).get('Hndti');
var featureH = ee.Feature(aoi)
var featureHigh = featureH.set('areas',ee.Number(getHigh)).set('label', ee.String('High'))
var chartHigh = ui.Chart.feature.byFeature({
  features:featureHigh, 
  xProperty: 'label'})
chartHigh.setOptions({
  title: ' forte Turbidité',
  vAxis: {title: 'Superficie en Hectares'},
  colors:['39a8a7'], 
  legend: {position: 'none'},
  hAxis: {
    title: '',
    logScale: false
  }
}).setChartType('BarChart');
/*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/ 
//Add a panel to hold graphs within main panel
var panelGraph = ui.Panel({
  style:{width: '300px',position:'middle-right'}
})
var y2000 = 'Low NDTI'
var y2010 = 'High NDTI'
// var graphSelect = ui.Select({
//   items:[y2000,y2010],
//   placeholder:'Choose year',
//   onChange: selectLayer,
//   style: {position:'top-right'}
// })
var constraints = []
//Write a function that runs on change of Dropdown
function selectLayer(){
  var graph = graphSelect.getValue() // get value from dropdown selection
  panelGraph.clear() //clear graph panel between selections so only one graph displays
  //We use "if else" statements to write instructions for drawing graphs
  if (graph == y2000){
    panelGraph.widgets().set(1,chartLow)
  }
  else if (graph == y2010){
    panelGraph.widgets().set(2, chartHigh)
  }
  for (var i = 0; i < constraints.length; ++i) {
    var constraint = select[i];
    var mode = constraint.mode.getValue();
    var value = parseFloat(constraint.value.getValue());
    if (mode == GREATER_THAN) {
      image = image.updateMask(constraint.image.gt(value));
    } else {
      image = image.updateMask(constraint.image.lt(value));
    }
}
}
var graphSelect = ui.Select({
  items:[y2000,y2010],
  placeholder:'Choose year',
  onChange: selectLayer,
  style: {position:'top-right'}
})
/*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/ 
var graphLabel = ui.Label({value:'Select year to display',
style: {fontWeight: 'bold', fontSize: '16px', margin: '10px 5px'}
});
var RefreshButton = new ui.Button({
  label:'Refresh',
  onClick:function(){
    panelGraph.widgets().reset()
  }, 
style: {fontWeight: 'bold', fontSize: '16px', margin: '10px 5px'}
});
//Add selecter and graph panel to main panel
panel.add(graphLabel)
      .add(graphSelect)
      .add( RefreshButton)
      .add(panelGraph)
/*******************************************************************************************************
 * paart to comment
 * 
 * 
 * *****************************************************************************************************/