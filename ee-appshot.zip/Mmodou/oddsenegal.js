var aoi = ui.import && ui.import("aoi", "table", {
      "id": "users/Mmodou/GMES/Senegal_Site_RBDS"
    }) || ee.FeatureCollection("users/Mmodou/GMES/Senegal_Site_RBDS");
/***********************************************************************************************************************************************************************************
 * 
 * ********************************************************************************************************************************************************************************/
var extent2020 = ee.Image('users/Mmodou/projectCSE/Mangrove2020')
var col = ee.ImageCollection("JRC/GSW1_1/YearlyHistory");
col = col.map(function(img) {
  var year = img.date().get('year');
  return img.clip(aoi).gte(2).multiply(year).set('year', year).toInt();
});
var dem = ee.Image('JAXA/ALOS/AW3D30/V2_2').select('AVE_DSM').clip(aoi);
var demMask = dem.gt(0);
var hillshade = ee.Terrain.hillshade(dem.multiply(15))
  .updateMask(demMask)
  .visualize({min:0, max:800, opacity:0.50});
var visLayer = {
  min: 1984,
  max: 2018,
  palette: ['F9FB0E', 'F9BD3F', 'A3BD6A', '33B7A0', '089BCE', '056EDE']
};
var bgColor = '000000';
var riverColor = '056EDE';
var yearSeq = ee.List.sequence(1984, 2018);
var bgImg = ee.Image(1).visualize({palette: bgColor});
var imgLayer = hillshade.blend(col.max().visualize(visLayer));
/**************************************************************************************************************************************************************************************
 * 
 * 
 * ***********************************************************************************************************************************************************************************/
var leftMap = ui.Map();
var rightMap = ui.Map();
var baseMap = require('users/tl2581/packages:baseMap.js')
leftMap.setOptions('Dark', {'Dark': baseMap.darkTheme})
rightMap.setOptions('Dark', {'Dark': baseMap.darkTheme})
var linker = new ui.Map.Linker([leftMap, rightMap]);
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe: true
});
ui.root.clear();
ui.root.add(splitPanel);
/**************************************************************************************************************************************************************************************
 * 
 * 
 * *********************************************************************************************************************************************************************************/
var panel = ui.Panel();
panel.style().set({ width: '45%',height: '66%', position: 'top-right',color: '#4874ba', fontWeight: 'bold'});
rightMap.add(panel);
panel.add(ui.Button({label: 'Close', style: {color: 'black'},
  onClick: function() {
    panel.style().set('shown', false);}
}));
var title = ui.Panel([ui.Label({value: "Développement d'une plateforme de données pour soutenir les Objectifs de Développement Durable (ODD) "+
  "au niveau des terres, l'eau et sécurité alimentaire en Afrique de l’Ouest",
   style: {fontSize: '20px', fontWeight: 'bold', textAlign: 'center',color:'#1d91c0'}})]);
panel.add(title);
var intro = ui.Panel([ui.Label({value: ' Cette application participe à un effort de fournir une plateforme commune '+
' utilisant les données d’observation de la terre pour contribuer aux renseignements de certains indicateurs au niveau du Sénégal' +
  'cette plateforme est constituée de liens surlesquels les utilisateurs peuvent cliquer'+
  'pour acceder aux differentes applications de  renseignement des ODDs ',
    style: {color: 'black',fontWeight: 'normal',}})]);
panel.add(intro);
var next = ui.Panel([ui.Label({value: 
'Type de Données Utilisées ici\n ' +
"Sentinel-2\n,"+
"Sentinel-1\n,"+
" Landsat-8\n"+
" Resolution (10 m, 10m et 30 m), Date (2015, 2020,2021)",
    style: {color: 'black',fontSize: '10px', fontWeight: 'bold'}})]);
panel.add(next);
// https://mmodou.users.earthengine.app/view/mangrovesenegalodd
var mangrove = ui.Label({
  value:"Variation spatiale de la mangrove au niveau de la Réserve Biosphère du Delta du Saloum (RBDS)",
  style:{fontWeight: 'bold',fontSize: '15px',color:'#1d91c0', 
  }, 
   targetUrl:'https://mmodou.users.earthengine.app/view/mangrovesenegalodd'
})
// 
var turbidity = ui.Label({
  value:"Turbidité de l’eau du Lac de Guiers",
  style:{fontWeight: 'bold',fontSize: '15px',color:'#1d91c0', 
  }, 
  targetUrl:'https://mmodou.users.earthengine.app/view/oddturbidityapp'
})
var lacdeGuiers = ui.Label({
  value:'Variation de la superficie du Lac de Guiers',
  style:{fontWeight: 'bold',fontSize: '15px',color:'#1d91c0', 
  }, 
  targetUrl:'https://mmodou.users.earthengine.app/view/waterlacdeguiers'
})
var degradations = ui.Label({
  value:'Proportion de la surface émergée totale occupée par des terres dégradées',
  style:{fontWeight: 'bold',fontSize: '15px',color:'#1d91c0', 
  }, 
  targetUrl:'https://coded.readthedocs.io/en/latest/examples.html'
})
// Variation de la superficie du Lac de Guiers 
// Variation spatiale de la mangrove au niveau de la Réserve Biosphère du Delta du Saloum (RBDS)
// Turbidité de l’eau du Lac de Guiers
var sep1 = ui.Panel([
  ui.Label({
    value: '____________________________________________',
    style: {fontWeight: 'bold',  color: '4A997E'},
  })
  ]);
var sep2 = ui.Panel([
  ui.Label({
    value: '____________________________________________',
    style: {fontWeight: 'bold',  color: '4A997E', stretch:'horizontal'},
  })
  ]);
/**************************************************************************************************************************************************************************************
 * 
 * *********************************************************************************************************************************************************************************/
panel
      .add(mangrove)
      .add(sep1)
      .add(turbidity)
      .add(sep2)
      .add(lacdeGuiers)
      .add(degradations);
/**************************************************************************************************************************************************************************************
 * 
 * *********************************************************************************************************************************************************************************/
// extent2020
var layer = ui.Map.Layer(imgLayer)
rightMap.layers().add(layer);
leftMap.layers().add(ui.Map.Layer(extent2020,{palette:['005a32'], min:1, max:1}, 'Extent 2015',1))
layer.setName('JRC DATA BASE');
leftMap.setCenter(-16.572826686242635, 13.925466318187407, 12)