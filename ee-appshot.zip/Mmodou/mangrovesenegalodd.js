// 
/*****************************************************************************************************************************************
 *  ODD 6.6.6 VARATION SPATIAL DE LA MANGROVE
 * 
 **************************************************************************************************************************************/ 
// chargement des donnees de classification  en utilisant RF en 2015 ET 2020
var extent2015 = ee.Image('users/Mmodou/projectCSE/Mangrove2015')
var extent2020 = ee.Image('users/Mmodou/projectCSE/Mangrove2020')
var RBDS = ee.FeatureCollection('users/Mmodou/GMES/Senegal_Site_RBDS')
// importation des package pour une meilleure visualisation
var baseMap = require('users/tl2581/packages:baseMap.js');
Map.setOptions('Dark', {'Dark': baseMap.darkTheme});
// centrer sur le site rbds
Map.centerObject(RBDS,11)
Map.style().set('cursor', 'crosshair');
/*****************************************************************************************************************************************
 *  CREAATION DE LA COUCHE DES CARTES AVEC LEUR COULEURS RESPECTIVE
 * L 4UTILISATEUR FERA L4ACTION DE CHOISIR LA COUCHE A VISUALISER
 * 
 **************************************************************************************************************************************/ 
var ext2015 = ui.Map.Layer(extent2015, {palette:['005a32'], min:1, max:1}, 'Extent 2015',false)
var ext2020 = ui.Map.Layer(extent2020, {palette:['d9f0a3'], min:1, max:1}, 'Extent 2020',false)
Map.add(ext2015)
Map.add(ext2020)
/*****************************************************************************************************************************************
 *  CREATION DES WIDGETS ET PANEL AVEC LES INFORMATIONS
 * 
 **************************************************************************************************************************************/ 
var header = ui.Label(" Variation spatiale de la mangrove au niveau de la Réserve Biosphère du Delta du Saloum (RBDS)", 
{fontSize: '25px', fontWeight: 'bold', color: '#084594'});
//App summary
var text = ui.Label(
  "La variation spatiale de la mangrove est une composante du sous-indicateur :" +
  " variation spatiale des écosystèmes aquatiques qui dépend de l’indicateur 6.6.1 :" +
  "variation de l’étendue des écosystèmes tributaires de l’eau. " + 
  "L’outil montre la couverture spatiale de la mangrove en 2015 et/ou en 2020 par l’approche de la" +
  "classification Random Forest à partir des images Sentinel 2. Il permet d’explorer les changements entre les dates et de générer des histogrammes",
    {fontSize: '15px'});
//3.2) Create a panel to hold text
var panel = ui.Panel({
  widgets:[header, text],//Adds header and text
  style:{width: '350px',position:'middle-left'}});
//3.3) Create variable for additional text and separators
//This creates another panel to house a line separator and instructions for the user
var intro = ui.Panel([
  ui.Label({
    value: '____________________________________________',
    style: {fontWeight: 'bold',  color: 'blue'},
  }),
  ui.Label({
    value:'Choisir la Couche à Visualiser.',
    style: {fontSize: '15px', fontWeight: 'bold'}
  })]);
//Add this new panel to the larger panel we created 
panel.add(intro)
//3.4) Add our main panel to the root of our GUI
Map.add(panel)
var extLabel = ui.Label({value:'Limite de la Mangrove',
style: {fontWeight: 'bold', fontSize: '16px', margin: '10px 5px'}
});
/*****************************************************************************************************************************************
 *  CREATION DE CHECKBOX POUR L INTERACTION UTILISATEUR
 * 
 **************************************************************************************************************************************/ 
var extCheck = ui.Checkbox('2015').setValue(false); //false = unchecked
var extCheck2 = ui.Checkbox('2020').setValue(false);
var extentLegend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
/*****************************************************************************************************************************************
 *   FUNCTION UTILISEE POUR FAIRE UNE LEGENDE
 **************************************************************************************************************************************/ 
var makeRowa = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create a label with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // Return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
var paletteMAPa = [
'005a32',//2015
'd9f0a3',//2020
];
var namesa = ['Couverture spatiale de la mangrove (2015)','Couverture spatiale de la mangrove (2020)']; 
// Add color and names to legend
for (var i = 0; i < 2; i++) {
  extentLegend.add(makeRowa(paletteMAPa[i], namesa[i]));
  }  
//  AJOUTER COMMENTAIRES
panel.add(extLabel)
      .add(extCheck)
      .add(extCheck2)
      .add(extentLegend)
/*****************************************************************************************************************************************
 *  ODD 6.6.6 VARATION SPATIAL DE LA MANGROVE
 * 
 **************************************************************************************************************************************/ 
var doCheckbox = function() {
  extCheck.onChange(function(checked){
  ext2015.setShown(checked)
  })
}
doCheckbox();
var doCheckbox2 = function() {
  extCheck2.onChange(function(checked){
  ext2020.setShown(checked)
  })
}
doCheckbox2();
////////////////////////////////////////////////////////
//  
////////////////////////////////////////////////////////
//2015
//Calculate area in Hectares
var get2015 = extent2015.multiply(ee.Image.pixelArea()).divide(10000).reduceRegion({
      reducer:ee.Reducer.sum(),
      geometry:RBDS,
      scale: 1000,
      maxPixels:1e13,
      tileScale: 16
      }).get('classification');
//Get area for the Guyana region
var feature = ee.Feature(RBDS)
var feature2015 = feature.set('2015', ee.Number(get2015))
//Construct Bar Chart
var chart2015= ui.Chart.feature.byProperty(feature2015, ['2015'], ['Total'])
//Set up title and labels for chart
chart2015.setOptions({
  title: 'Superficie Total',
  vAxis: {title: 'Hectares'},
  legend: {position: 'none'},
  hAxis: {
    title: 'Year',
    logScale: false
  }
});
//2020
//Calculate area in Hectares
var get2020 = extent2020.multiply(ee.Image.pixelArea()).divide(10000).reduceRegion({
      reducer:ee.Reducer.sum(),
      geometry:RBDS,
      scale: 1000,
      maxPixels:1e13,
      tileScale: 16
      }).get('classification');
//Get area for the Guyana region
var feature2020 = feature.set('2020', ee.Number(get2020))
// // GRAPHIQUE POUR 20
var chart2020 = ui.Chart.feature.byProperty(feature2020, ['2020'], ['Total'])
//Set up title and labels for chart
chart2020.setOptions({
  title: 'Superficie Total',
  vAxis: {title: 'Hectares'},
  legend: {position: 'none'},
  hAxis: {
    title: 'Année',
    logScale: false
  }
});
////////////////////////////////////////////////////////
//  8) Create a dropdown menu to display graph results //
////////////////////////////////////////////////////////
//Add a panel to hold graphs within main panel
var panelGraph = ui.Panel({
  style:{width: '300px',position:'middle-right'}
})
//Create key of items for dropdown
var y2015 = '2015'
var y2020 = '2020'
// var y2020 = '2020'
//Construct Dropdown
var graphSelect = ui.Select({
  items:[y2015,y2020],
  placeholder:'Choisir une année',
  onChange: selectLayer,
  style: {position:'top-right',stretch:'horizontal'}
})
var constraints = []
//Write a function that runs on change of Dropdown
function selectLayer(){
  var graph = graphSelect.getValue() 
  panelGraph.clear() 
  if (graph == y2015){
    panelGraph.add(chart2015)
  }
  else if (graph == y2020){
    panelGraph.add(chart2020)
  }
  for (var i = 0; i < constraints.length; ++i) {
    var constraint = select[i];
    var mode = constraint.mode.getValue();
    var value = parseFloat(constraint.value.getValue());
    if (mode == GREATER_THAN) {
      image = image.updateMask(constraint.image.gt(value));
    } else {
      image = image.updateMask(constraint.image.lt(value));
    }
}
}
var graphLabel = ui.Label({value:'Selectionnez une annéé pour visualiser le graphe, cliquer sur la flèche pour exporter',
style: {fontWeight: 'bold', fontSize: '16px', margin: '10px 5px'}
});
panel.add(graphLabel)
      .add(graphSelect)
      .add(panelGraph)