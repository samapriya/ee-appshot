// Configure the map
Map.setCenter(-64.84497, 7.01918, 8);
// Load and display NDVI data.
var functions = require('users/ejvalero/eeapps:Modules/ImageProcessing');
/**
 * Styles setup
 */
var colors = {'cyan': '#24C1E0', 'transparent': '#11ffee00', 'gray': '#F8F9FA'};
var YEARS = [
    '2000', '2001', '2002', '2003', '2004', '2005', '2006', '2007', '2008', 
    '2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017'
];
var STYLES = {
    title: {
      fontWeight: '100', fontSize: '24px', padding: '10px 10px 0 10px', color: '#22602c',
      backgroundColor: colors.transparent
    },
    paragraph: {
      fontSize: '14px', fontWeight: '50', color: '#9E9E9E', padding: '10px', 
      margin: '-10px 8px 10px 8px', backgroundColor: colors.transparent
    },
    labels : { 
      fontSize: '12px', margin: '10px 18px 0 18px',
      fontWeight: 'bold', color: 'gray', backgroundColor: colors.transparent
    },
    slider: { 
      margin: '0 0 10px 18px', stretch: 'horizontal',
      color: '#333', backgroundColor: colors.transparent,
    },
    selects: {
      margin: '10px 18px', stretch: 'horizontal',
      fontWeight: 'normal', color: '#333', backgroundColor: colors.transparent,
    },
    buttonSuccess: {
      margin: '40px 18px 10px 18px', stretch: 'horizontal',
      fontWeight: 'normal', backgroundColor: colors.transparent,
      border: '1px solid #28a745',
    },
    displayMosaic: {
      margin: '40px 18px 10px 18px', stretch: 'horizontal',
      fontWeight: 'normal', backgroundColor: colors.transparent,
    }
};
/***
 * Compute widgets for controls
 */
function makeWidgets() {
    var widgets = {
        /**
         * Labels
         */
        panelTitle : ui.Label({
            value: 'Classification toolkit App',
            style: STYLES.title
        }),
        appTextHelper : ui.Label({
            value: 'This app allows you to visualize spectral index data',
            style: STYLES.paragraph
        }),
        mapLabelTitle : ui.Label({
            value: 'Cobertura de nubes del mosico (%)',
            style: STYLES.labels
        }),
        yearSelectTitle : ui.Label({
            value: 'Seleccionar año',
            style: STYLES.labels
        }),
        indexSelectTitle : ui.Label({
            value: 'Seleccionar índice espectral',
            style: STYLES.labels
        }),
    };
    /**
     * Slider input of cloud cover
     */
    widgets.cloudCoverSlider = ui.Slider({
        min: 0,
        max: 100,
        value: 60,
        style: STYLES.slider,
        onChange: function(value){
          widgets.cloudCoverSlider.setValue( value );
        }
    });
    /**
     * Checkbox of displaying mosaic
     */
    widgets.displayMosaic = ui.Checkbox({
        label: 'Ver mosaico',
        value: true,
        style: STYLES.displayMosaic,
        onChange: function(checked) {
            widgets.displayMosaic.setValue( checked );
            Map.layers().get(0).setShown(checked);
        }
    });
    /**
     * Selectors for year and index
     */
    var data; 
    widgets.yearSelect = ui.Select({
        items: YEARS,
        style: STYLES.selects,
        value: '2017',
        onChange: function( key ){
            widgets.yearSelect.setValue( key);
            Map.clear();
            data = functions.getLandsatData ( key , true );
        }
    });
    data = functions.getLandsatData ( widgets.yearSelect.getValue() , true );
    widgets.indexSelect = ui.Select({
        items: ['ndmi', 'ndvi', 'ndwi', 'npcri', 'evi'],
        style: STYLES.selects,
        value: 'ndmi',
        onChange: function( key ){
            widgets.indexSelect.setValue( key );
            print( key );
        }
    });
    // Display mosaic when textbox is checked
    /**
     * Button for processing 
     */
    widgets.displayLayerButton = ui.Button({
        label: 'MOSTRAR',
        style: STYLES.buttonSuccess,
        onClick: function( year, indexName, cloudCover ) {
            year = widgets.yearSelect.getValue();
            indexName = widgets.indexSelect.getValue();
            cloudCover = parseFloat(widgets.cloudCoverSlider.getValue()).toFixed(0);
            var Index = functions.computeIndex(
                data.collection, data.bands, indexName
            );
            Map.addLayer( 
                Index.data, 
                { palette: Index.palette }, 
                indexName.toUpperCase() + ' ' + year, 
                true
            );
        }
    });
    return widgets;
}
// Create the app structure in which to arrange widgets.
// The layout is vertical flow by default.
var widgets = makeWidgets();
var headerPanel = ui.Panel({
      widgets : [
          widgets.panelTitle,
          widgets.appTextHelper,
          widgets.mapLabelTitle,
          widgets.cloudCoverSlider,
      ],
      layout: ui.Panel.Layout.flow('vertical'), 
      style: {backgroundColor: colors.gray, width: '400px'}
});
var panel2 = ui.Panel({
      widgets : [
          widgets.yearSelectTitle,
          widgets.yearSelect,
          widgets.indexSelectTitle,
          widgets.indexSelect,
      ],
      layout: ui.Panel.Layout.flow('vertical'), 
      style: {backgroundColor: colors.gray, width: '250px'}
});
var panel3 = ui.Panel({
      widgets : [
         widgets.displayMosaic,
          widgets.displayLayerButton,
      ],
      layout: ui.Panel.Layout.flow('vertical'), 
      style: {backgroundColor: colors.gray, width: '150px'}
});
var panel1 = ui.Panel({
      widgets : [
          panel2, panel3
      ],
      layout: ui.Panel.Layout.flow('horizontal'), 
      style: {backgroundColor: colors.gray, width: '400px'}
});
var panel = ui.Panel({
      widgets : [
          headerPanel, panel1
      ],
      layout: ui.Panel.Layout.flow('vertical'), 
      style: {backgroundColor: colors.gray, width: '400px'}
});
// Add the panel to the ui.root.
ui.root.insert(0, panel)