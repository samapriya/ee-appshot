var table = ui.import && ui.import("table", "table", {
      "id": "users/nguyenhong1611209/thuduc"
    }) || ee.FeatureCollection("users/nguyenhong1611209/thuduc");
// Panels are the main container widgets
var mainPanel = ui.Panel({
  style: {width: '250px'}
});
var title = ui.Label({
  value: 'Ảnh viễn thám',
  style: {'fontSize': '24px'}
});
// You can add widgets to the panel
mainPanel.add(title)
// You can even add panels to other panelsd
var dropdownPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal', true),
});
mainPanel.add(dropdownPanel);
var start_date = ui.Label({
  value: 'Chọn ngày bắt đầu',
  style: {'fontSize': '16px'}
});
// You can add widgets to the panel
dropdownPanel.add(start_date)
var yearSelector = ui.Select({
  placeholder: 'please wait..',
  })
var monthSelector = ui.Select({
  placeholder: 'please wait..',
  })
  var daySelector = ui.Select({
  placeholder: 'please wait..',
  })
  var yearSelector_e = ui.Select({
  placeholder: 'please wait..',
  })
var monthSelector_e = ui.Select({
  placeholder: 'please wait..',
  })
  var daySelector_e = ui.Select({
  placeholder: 'please wait..',
  })
var cloudSelector = ui.Select({
  placeholder: 'please wait..',
  })
var button = ui.Button('Load dữ liệu')
var clear = ui.Button('xóa layer')
// var download_button = ui.Button('Download_button')
var download_button = ui.Label({
  value:'Load dữ liệu để tải về',
  style:{border:'2px solid black', padding:'4px'}
  })
dropdownPanel.add(yearSelector)
dropdownPanel.add(monthSelector)
dropdownPanel.add(daySelector)
var end_date = ui.Label({
  value: 'Chọn ngày kết thúc',
  style: {'fontSize': '16px'}
});
// You can add widgets to the panel
dropdownPanel.add(end_date)
dropdownPanel.add(yearSelector_e)
dropdownPanel.add(monthSelector_e)
dropdownPanel.add(daySelector_e)
var cloud_lb = ui.Label({
  value: 'Lọc theo độ phủ của mây',
  style: {'fontSize': '16px'}
});
// You can add widgets to the panel
dropdownPanel.add(cloud_lb)
dropdownPanel.add(cloudSelector)
dropdownPanel.add(button)
dropdownPanel.add(clear)
dropdownPanel.add(download_button)
// Let's add a dropdown with the years
var years = ee.List.sequence(2020, 2023)
var months = ee.List.sequence(1, 12)
var days = ee.List.sequence(1, 30)
var years_e = ee.List.sequence(2020, 2023)
var months_e = ee.List.sequence(1, 12)
var days_e = ee.List.sequence(1, 30)
var clouds = ee.List.sequence(1, 100)
// Dropdown items need to be strings
var yearStrings = years.map(function(year){
  return ee.Number(year).format('%04d')
})
var monthStrings = months.map(function(month){
  return ee.Number(month).format('%02d')
})
var dayStrings = days.map(function(day){
  return ee.Number(day).format('%02d')
})
var yearStrings_e = years_e.map(function(year){
  return ee.Number(year).format('%04d')
})
var monthStrings_e = months_e.map(function(month){
  return ee.Number(month).format('%02d')
})
var dayStrings_e = days_e.map(function(day){
  return ee.Number(day).format('%02d')
})
var cloudStrings = clouds.map(function(cloud){
  return ee.Number(cloud).format('%02d')
})
// Evaluate the results and populate the dropdown
yearStrings.evaluate(function(yearList) {
  yearSelector.items().reset(yearList)
  yearSelector.setPlaceholder('Chọn năm')
})
monthStrings.evaluate(function(monthList) {
  monthSelector.items().reset(monthList)
  monthSelector.setPlaceholder('Chọn tháng')
})
dayStrings.evaluate(function(dayList) {
  daySelector.items().reset(dayList)
  daySelector.setPlaceholder('Chọn ngày')
})
yearStrings_e.evaluate(function(yearList) {
  yearSelector_e.items().reset(yearList)
  yearSelector_e.setPlaceholder('Chọn năm')
})
monthStrings_e.evaluate(function(monthList) {
  monthSelector_e.items().reset(monthList)
  monthSelector_e.setPlaceholder('Chọn tháng')
})
dayStrings_e.evaluate(function(dayList) {
  daySelector_e.items().reset(dayList)
  daySelector_e.setPlaceholder('Chọn ngày')
})
cloudStrings.evaluate(function(cloudList) {
  cloudSelector.items().reset(cloudList)
  cloudSelector.setPlaceholder('% mây')
})
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
// Define a function that triggers when any value is changed
var geometry = table.geometry()
var loadComposite = function() {
  var col = ee.ImageCollection("COPERNICUS/S2");
  var year = yearSelector.getValue()
  var month = monthSelector.getValue()
  var day = daySelector.getValue()
  var year_e = yearSelector_e.getValue()
  var month_e = monthSelector_e.getValue()
  var day_e = daySelector_e.getValue()
  var cloud = ee.Number.parse(cloudSelector.getValue());
  var startDate = ee.Date.fromYMD(
    ee.Number.parse(year), ee.Number.parse(month), ee.Number.parse(day))
  var endDate = ee.Date.fromYMD(
    ee.Number.parse(year_e), ee.Number.parse(month_e), ee.Number.parse(day_e))
  var filtered = col.filterDate(startDate,endDate)
                    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',cloud))
                    .filter(ee.Filter.bounds(geometry))
                    .map(maskS2clouds);
  var image = ee.Image(filtered.median().clip(geometry))
  var vis = {
    min: 0,
    max: 0.3,
    bands: ['B4','B3','B2'],
  };
  var name = startDate.format('yyyy-MM')
  var layerName = 'TP_THUDUC_S2_RGB_' + name.getInfo()
  Map.addLayer(image, vis, layerName)
  Map.centerObject(geometry,11)
  // return [image,cangio]
image.getDownloadURL({
  params:{name:layerName,
    bands:['B4', 'B3', 'B2'],
    region:geometry,
    scale:20,
    filePerBand:false
    }, 
  callback:function(URL) {
    download_button.setUrl(URL)
    download_button.style().set({backgroundColor:'#90EE90'})
    download_button.setValue(layerName)
  }
})
}
button.onClick(function(){loadComposite()})
clear.onClick(function(){Map.clear()})
ui.root.add(mainPanel);