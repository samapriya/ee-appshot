Map.setOptions('SATELLITE')
Map.setCenter(0, 20, 2.5)
var drivers = ee.Image('projects/ee-gfw-drivers-1km/assets/drivers-1km-v0-sample').selfMask()
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'My Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette = ['FFFF00', 'FF007F', '228B22', '8B0000', 'A020F0'];
// name of the legend
var names = ['soft commodity', 'hard commodity', 'forestry', 'wildfire', 'urbanization'];
// Add color and and names
for (var i = 0; i < 5; i++) {
  legend.add(makeRow(palette[i], names[i]));
}  
var viz_params = {
  min: 1,
  max: 5,
  opacity: 0.6,
  palette: palette
}
Map.addLayer(drivers, viz_params, 'drivers-1km')
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend);