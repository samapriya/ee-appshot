// To Inspect the code follow this link : https://code.earthengine.google.com/?accept_repo=users/sanchezpaus/utils
var tool = require("users/sanchezpaus/utils:grid/toolGrid");
tool.initialize();