var sug_extent = ui.import && ui.import("sug_extent", "table", {
      "id": "users/jirawatdaraneesrisuk/Country_cane"
    }) || ee.FeatureCollection("users/jirawatdaraneesrisuk/Country_cane"),
    geom_extent = ui.import && ui.import("geom_extent", "table", {
      "id": "users/jirawatdaraneesrisuk/Country_cane"
    }) || ee.FeatureCollection("users/jirawatdaraneesrisuk/Country_cane");
//**************************************************************************//
// Approximate start and end date
var approxStartDate = ee.Date('2019-9-1');
var approxEndDate = ee.Date('2019-9-6'); //ee.Date(ee.Date(Date.now()).format('Y-M-d'));
var startDate = approxStartDate;
var endDate = approxEndDate;
var emptyList = ee.List([]);
function addFeatureProperties(feature){
  var featureUpdate = feature.set({
                      'Start Date': startDate.format('Y-M-d'), 
                      'End Date': endDate.format('Y-M-d'),
  });
  return featureUpdate;
}
var geom_extent = geom_extent.map(addFeatureProperties);
print('Updated Extent', geom_extent);
var orbitProperties = 'DESCENDING'; // 'ASCENDING'
var s1 = ee.ImageCollection('COPERNICUS/S1_GRD')
        .filterBounds(sug_extent)
        .filterDate(startDate, endDate)
        // filtering to get images collected in interferometric wide swath mode
        .filter(ee.Filter.eq('instrumentMode', 'IW'))
        //filtering orbit properties: ASCENDING or DESCENDING
        .filter(ee.Filter.eq('orbitProperties_pass', orbitProperties))
        // filtering VV and VH dual polarisation
        .select(['VV'])
        // GRD border noise removal
        // removing low intensity noise and invalid data on scene edges
        .map(function(image) {
          var edge = image.gt(-16.0);
          var maskedImage = image.mask().and(edge.not());
          return image.updateMask(maskedImage);
        });
// since the image collection can be very large (> 5000), the Earth Engine can throw error when displaying
// Thus limiting the displaying number of images to 20 only
print('Sentinel 1 Image Collection', s1.limit(100));
Map.addLayer(s1, { palette: ['0000ff']}, 's1');
var cent = geom_extent.first().geometry().centroid().coordinates();
Map.setCenter(100.5245,13.9947, 7);