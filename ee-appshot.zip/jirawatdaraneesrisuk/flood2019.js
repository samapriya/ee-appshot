var geom_extent = ee.FeatureCollection("users/jirawatdaraneesrisuk/Supan_province"),
    sug_extent = ee.FeatureCollection("users/jirawatdaraneesrisuk/Supan_provinceCane"),
    table = ee.FeatureCollection("users/jirawatdaraneesrisuk/Thai_province");
//**************************************************************************//
// Approximate start and end date
var approxStartDate = ee.Date('2019-9-1');
var approxEndDate = ee.Date('2019-9-6'); //ee.Date(ee.Date(Date.now()).format('Y-M-d'));
//var approxEndDate = ee.Date(ee.Date(Date.now()).format('Y-M-d'));
// var n = ee.Number.parse(ee.Number.parse(approxStartDate.format('d')).lte(15));
// var start_day = ee.Algorithms.If(n, 1, 16);
// var start_year = approxStartDate.get('year');
// var start_month = approxStartDate.get('month');
// var n = ee.Number.parse(ee.Number.parse(approxEndDate.format('d')).lte(15));
// var end_year = approxEndDate.get('year');
// // var end_month = approxEndDate.get('month');
// // var dd = ee.Date(approxEndDate.format('Y')).advance(end_month, 'month');
// // var end_day = ee.Algorithms.If(n, 15, dd.advance(-1, 'day').get('day'));
// var end_month = approxEndDate.get('month').subtract(1);
// // var end_month = approxEndDate.get('month');
// var dd = ee.Date(approxEndDate.format('Y')).advance(end_month, 'month');
// var end_day = dd.advance(-1, 'day').get('day');
// var startDate = ee.Date.fromYMD(start_year, start_month, start_day);
// var endDate = ee.Date.fromYMD(end_year, end_month, end_day);
// print(startDate, endDate);
var startDate = approxStartDate;
var endDate = approxEndDate;
// function to add start date and end date
// and add attribute information 
var emptyList = ee.List([]);
function addFeatureProperties(feature){
  var featureUpdate = feature.set({
                      'Start Date': startDate.format('Y-M-d'), 
                      'End Date': endDate.format('Y-M-d'),
  });
  return featureUpdate;
}
var geom_extent = geom_extent.map(addFeatureProperties);
print('Updated Extent', geom_extent);
// IW
// var platform = 'A';
var orbitProperties = 'DESCENDING'; // 'ASCENDING'
var s1 = ee.ImageCollection('COPERNICUS/S1_GRD')
        .filterBounds(sug_extent)
        .filterDate(startDate, endDate)
        // // filtering to get images with VV and VH dual polarisation
        // .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
        // .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
        // filtering to get images collected in interferometric wide swath mode
        .filter(ee.Filter.eq('instrumentMode', 'IW'))
        //.filter(ee.Filter.eq('platform_number', platform))
        //filtering orbit properties: ASCENDING or DESCENDING
        .filter(ee.Filter.eq('orbitProperties_pass', orbitProperties))
        // filtering VV and VH dual polarisation
        .select(['VV'])
        // GRD border noise removal
        // removing low intensity noise and invalid data on scene edges
        .map(function(image) {
          var edge = image.gt(-15.0);
          var maskedImage = image.mask().and(edge.not());
          return image.updateMask(maskedImage);
        });
// since the image collection can be very large (> 5000), the Earth Engine can throw error when displaying
// Thus limiting the displaying number of images to 20 only
print('Sentinel 1 Image Collection', s1.limit(100));
Map.addLayer(s1, {min: [-25], max: [0]}, 's1');
var cent = geom_extent.first().geometry().centroid().coordinates();
Map.setCenter(100.5245,13.9947, 10);