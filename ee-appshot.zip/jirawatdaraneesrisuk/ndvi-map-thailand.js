var table2 = ui.import && ui.import("table2", "table", {
      "id": "users/jirawatdaraneesrisuk/BBKperimeter_bound"
    }) || ee.FeatureCollection("users/jirawatdaraneesrisuk/BBKperimeter_bound"),
    table = ui.import && ui.import("table", "table", {
      "id": "users/jirawatdaraneesrisuk/Country_cane"
    }) || ee.FeatureCollection("users/jirawatdaraneesrisuk/Country_cane");
//Cloud Mask model
var maskL8 = function(image) {
  var qa = image.select('BQA');
  /// Check that the cloud bit is off.
  // See https://www.usgs.gov/land-resources/nli/landsat/landsat-collection-1-level-1-quality-assessment-band
  var mask = qa.bitwiseAnd(1 << 4).eq(0);
  return image.updateMask(mask);
}
//Image Filtering
var composite = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA')
                .filterDate('2018-01-01', '2018-3-31')
                .filter(ee.Filter.lt('CLOUD_COVER', 20))
                .filterBounds(table)
                .map(maskL8);
print('Filtered Collection of Landsat Images', composite.limit(1000));
Map.addLayer(table);
Map.addLayer(composite);
var image = composite.mean()
var ndvi = image.normalizedDifference(['B5', 'B4']);
// Display the result.
Map.setCenter(100.5245,13.9947, 7);
var ndviParams = {min: -1, max: 1, palette: ['blue', 'white', 'green']};
Map.addLayer(ndvi, ndviParams, 'NDVI image');
//export image
Export.image.toDrive({
  image: ndvi,
  description: 'NDVI',
  region: table2, // cutting it to the border may reduce the image weight
  scale: 30,
  maxPixels:1e13,
  skipEmptyTiles: true,
  folder: 'GoogleEarthEngineOutput',
  crs: 'EPSG:32647',
});