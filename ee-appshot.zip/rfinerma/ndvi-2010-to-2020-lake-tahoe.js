//Load in Raw Images to Create the NDVI Manually for 2000 and 2018, to plot change over time
//Using LS8 for 2020 and LS7 for 2010
var LS8_2020 = ee.ImageCollection("LANDSAT/LC08/C01/T1").filterDate('2020-01-01', '2020-03-31');
var LS7_2010 = ee.ImageCollection('LANDSAT/LE07/C01/T1').filterDate('2010-01-01', '2010-03-31');
//Create Image Composites for 2020 and 2010, then calculate the NDVI on these composites
var LS8_2020Comp = ee.Algorithms.Landsat.simpleComposite({
  collection: LS8_2020,
  asFloat: true
});
var LS7_2010Comp = ee.Algorithms.Landsat.simpleComposite({
  collection: LS7_2010,
  asFloat: true
});
//Add Composite Images to Map
Map.addLayer(LS8_2020Comp, {'bands': ['B4','B3','B2'], min: 0.02, max: 0.89}, 'Landsat 8 2020 Composite');
Map.addLayer(LS7_2010Comp, {'bands': ['B3','B2','B1'], min: 0.03, max: 0.73}, 'Landsat 7 2020 Composite');
//Create NDVI from Composites
var ndvi_2020 = LS8_2020Comp.normalizedDifference(['B5', 'B4']);
var ndvi_2010 = LS7_2010Comp.normalizedDifference(['B4', 'B3']);
var leftMap = ui.Map();
var rightMap = ui.Map();
var linker = ui.Map.Linker([leftMap, rightMap]);
leftMap.setCenter(-120.0324,39.0968,10);
leftMap.setControlVisibility(false);
rightMap.setControlVisibility(false);
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe: true,
  style: {stretch: 'both'}
});
ui.root.clear();
ui.root.add(splitPanel);
leftMap.addLayer(ndvi_2010.mask(ndvi_2010), {palette: '000000, 00FF00', min: 0.002, max: 0.68}, 'NDVI 2010 Positive Values');
rightMap.addLayer(ndvi_2020.mask(ndvi_2020), {palette: '000000, 00FF00', min: 0.002, max: 0.72}, 'NDVI 2020 Positive Values');