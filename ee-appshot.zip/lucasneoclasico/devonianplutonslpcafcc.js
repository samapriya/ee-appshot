var sentclip = ui.import && ui.import("sentclip", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -65.95964184693742,
                -32.24228097680671
              ],
              [
                -65.95964184693742,
                -32.77789497452803
              ],
              [
                -65.50027600221085,
                -32.77789497452803
              ],
              [
                -65.50027600221085,
                -32.24228097680671
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-65.95964184693742, -32.24228097680671],
          [-65.95964184693742, -32.77789497452803],
          [-65.50027600221085, -32.77789497452803],
          [-65.50027600221085, -32.24228097680671]]], null, false);
// **** Pricipal Component Analysis and Decorrelation Stretching *****
// Select and Filter Sentinel 2 L2A Image
var sentImages = ee.ImageCollection('COPERNICUS/S2')
.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10))
.filterDate("2017-01-02", "2020-12-30")
.filterBounds(sentclip);
var sentmosaic = sentImages.mosaic();
var sentImage = sentmosaic.clip(sentclip);
print("Sentinel 2 Scene", sentImage);
// PCA Code
var getPrincipalComponents = function(centered, scale, region) {
  // Collapse the bands of the image into a 1D array per pixel.
  var arrays = centered.toArray();
  print('PCA applying on', centered);
  // Compute the covariance of the bands within the region.
  var covar = arrays.reduceRegion({
    reducer: ee.Reducer.centeredCovariance(),
    geometry: region,
    scale: scale,
    maxPixels: 1e9
  });
  // Get the 'array' covariance result and cast to an array.
  // This represents the band-to-band covariance within the region.
  var covarArray = ee.Array(covar.get('array'));
  // Perform an eigen analysis and slice apart the values and vectors.
  var eigens = covarArray.eigen();
  // This is a P-length vector of Eigenvalues.
  var eigenValues = eigens.slice(1, 0, 1);
  // This is a PxP matrix with eigenvectors in rows.
  var eigenVectors = eigens.slice(1, 1);
  // Convert the array image to 2D arrays for matrix computations.
  var arrayImage = arrays.toArray(1);
  // Left multiply the image array by the matrix of eigenvectors.
  var principalComponents = ee.Image(eigenVectors).matrixMultiply(arrayImage);
  // Turn the square roots of the Eigenvalues into a P-band image.
  var sdImage = ee.Image(eigenValues.sqrt())
    .arrayProject([0]).arrayFlatten([getNewBandNames('sd')]);
  // Turn the PCs into a P-band image, normalized by SD.
  return principalComponents
    // Throw out an an unneeded dimension, [[]] -> [].
    .arrayProject([0])
    // Make the one band array image a multi-band image, [] -> image.
    .arrayFlatten([getNewBandNames('pc')])
    // Normalize the PCs by their SDs.
    .divide(sdImage);
};
// Sentinel-2 True Color Map
var trueColor = {
  bands: ["B4", "B3", "B2"],
  min: 0,
  max: 3000,
  gamma:1.5
};   
Map.addLayer(sentImage, trueColor, "Sentinel 2 True Color");
// Sentinel-2 False Color Map
var falseColor = {
  bands: ["B11", "B12", "B8"],
  min: 0,
  max: 3000,
  gamma:1.5
};
Map.addLayer(sentImage, falseColor, "Sentinel 2 False Color");
// Sentinel - 2 PCA              
// Display the input imagery and the region in which to do the PCA.
var sentbands = ['B2','B3','B4','B8','B11','B12'];
var region = sentImage.geometry();
var image =  sentImage.select(sentbands);
// Set some information about the input to be used later.
var scale = 30;
var bandNames = image.bandNames();
// Mean center the data to enable a faster covariance reducer
// and an SD stretch of the principal components.
var meanDict = image.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: region,
    scale: scale,
    maxPixels: 1e9
});
var means = ee.Image.constant(meanDict.values(bandNames));
var centered = image.subtract(means);
// This helper function returns a list of new band names.
var getNewBandNames = function(prefix) {
  var seq = ee.List.sequence(1, bandNames.length());
  return seq.map(function(b) {
    return ee.String(prefix).cat(ee.Number(b).int());
  });
};
var pcImage = getPrincipalComponents(centered, scale, region);
// Plot each PC as a new layer
Map.addLayer(pcImage, {bands: ['pc4', 'pc5', 'pc3'], min: -2, max: 2}, 'Sentinel 2 - PCA');
Map.setCenter(-66.2653928137903,-33.25603836981476, 13);