// Cargar clasificaciones de los años
var clasificaciones = {
  2021: ee.Image('projects/ndvitimelapse-1553424632859/assets/Clasificacion_S1_nv_Marabu_2021'),
  2022: ee.Image('projects/ndvitimelapse-1553424632859/assets/Clasificacion_S1_nv_Marabu_2022'),
  2023: ee.Image('projects/ndvitimelapse-1553424632859/assets/Clasificacion_S1_nv_Marabu_2023'),
  2024: ee.Image('projects/ndvitimelapse-1553424632859/assets/Clasificacion_S1_nv_Marabu_2024')
};
// Cargar las parcelas
var parcelas = ee.FeatureCollection('projects/ee-digdgeografo/assets/parcelas_mrb_2024');
// Crear una nueva instancia de ui.Map y centrarla en las parcelas
var customMap = ui.Map();
customMap.centerObject(parcelas, 12);
customMap.addLayer(parcelas, {}, 'Parcelas');
// Crear encabezado reducido
var encabezado = ui.Panel({
  widgets: [
    ui.Label({
      value: 'App para el Monitoreo del Marabú en el Valle de los Ingenios (Cuba)',
      style: {
        fontSize: '18px',
        fontWeight: 'bold',
        textAlign: 'center',
        color: '#4CAF50'
      }
    }),
    ui.Label({
      value: 'Visualización de la evolución temporal del índice RVI y NDVI en las parcelas seleccionadas.',
      style: {
        fontSize: '10px',
        textAlign: 'center',
        color: '#555'
      }
    })
  ],
  style: {
    stretch: 'horizontal',
    backgroundColor: '#f1f1f1',
    padding: '5px',
    margin: '5px'
  }
});
// Crear selectores de año y parcela
var selectorAnio = ui.Select({
  items: ['2021', '2022', '2023', '2024'],
  placeholder: 'Selecciona un año',
  onChange: function(year) {
    var clasificacion = clasificaciones[year].eq(1).selfMask();
    customMap.layers().set(1, ui.Map.Layer(clasificacion, {min: 1, max: 1, palette: ['34fb04']}, 'Clasificación Marabú ' + year));
  }
});
var ids = ee.List(parcelas.aggregate_array('id')).distinct().sort().map(function(id) {
  return ee.Number(id).format('%d');
}).getInfo();
var selectorParcela = ui.Select({
  items: ids,
  placeholder: 'Selecciona una parcela',
  onChange: function(idString) {
    var id = parseInt(idString);
    var parcelaSeleccionada = parcelas.filter(ee.Filter.eq('id', id));
    customMap.layers().set(2, ui.Map.Layer(parcelaSeleccionada, {color: 'blue'}, 'Parcela: ' + idString));
    customMap.centerObject(parcelaSeleccionada, 16);
    mostrarCurvas(parcelaSeleccionada);
  }
});
// Crear panel para gráficas
var panelGraficas = ui.Panel([], 'flow', {
  padding: '5px',
  backgroundColor: '#f9f9f9',
  border: '1px solid #ddd'
});
// Crear panel lateral con encabezado, selectores y gráficas
var panelLateral = ui.Panel({
  widgets: [
    encabezado,
    ui.Label('Opciones:', {fontWeight: 'bold', fontSize: '14px'}),
    ui.Label('Selecciona un año:'),
    selectorAnio,
    ui.Label('Selecciona una parcela:'),
    selectorParcela,
    ui.Label('Gráficas:', {fontWeight: 'bold', fontSize: '14px'}),
    panelGraficas
  ],
  style: {
    width: '400px',
    padding: '10px',
    backgroundColor: '#ffffff',
    border: '1px solid #ccc'
  }
});
// Función para mostrar las curvas
function mostrarCurvas(parcela) {
  panelGraficas.clear();
  var marabu2024 = clasificaciones['2024'].eq(1).selfMask().clip(parcela);
  // Gráfica de RVI
  procesarIndice(
    "COPERNICUS/S1_GRD",
    ["VH", "VV"],
    function(image) {
      return image.expression('4 * VH / (VV + VH)', {
        'VH': image.select('VH'),
        'VV': image.select('VV')
      }).rename('RVI');
    },
    marabu2024,
    parcela.geometry(),
    "RVI",
    "RVI Armónico (Marabú)",
    5 // Usar 5 armónicos para capturar más detalles
  );
  // Gráfica de NDVI
  procesarIndice(
    "COPERNICUS/S2_SR_HARMONIZED",
    ["B8", "B4"],
    function(image) {
      return image.normalizedDifference(['B8', 'B4']).rename('NDVI');
    },
    marabu2024,
    parcela.geometry(),
    "NDVI",
    "NDVI Armónico (Marabú)",
    1 // Mantener 1 armónico para el NDVI
  );
}
// Función genérica para procesar índices y generar gráficas
function procesarIndice(collectionId, requiredBands, calcFunction, mask, region, indiceName, chartTitle, harmonics) {
  harmonics = harmonics || 1; // Por defecto, 1 armónico
  var collection = ee.ImageCollection(collectionId)
    .filterBounds(region)
    .filterDate('2021-01-01', '2024-12-31')
    .map(function(image) {
      if (image.bandNames().contains(requiredBands[0])) {
        var processedImage = calcFunction(image);
        return processedImage.copyProperties(image, ['system:time_start']);
      } else {
        return ee.Image(); // Imagen vacía si faltan bandas
      }
    });
  if (collection.size().getInfo() > 0) {
    var harmonicTrend = calcularModeloHarmonico(collection, indiceName, harmonics);
    var chart = ui.Chart.image.series({
      imageCollection: harmonicTrend.map(function(image) {
        return image.updateMask(mask).select([indiceName, 'smoothed']);
      }),
      region: region,
      reducer: ee.Reducer.mean(),
      scale: 10
    }).setOptions({
      title: chartTitle,
      hAxis: { title: 'Fecha' },
      vAxis: { title: indiceName },
      lineWidth: 2,
      pointSize: 3
    });
    panelGraficas.add(chart);
  } else {
    panelGraficas.add(ui.Label('No hay datos disponibles para ' + indiceName));
  }
}
// Función para calcular modelo armónico con opción de más armónicos
function calcularModeloHarmonico(collection, bandName, harmonics) {
  harmonics = harmonics || 1; // Permitir ajustar el número de armónicos
  var harmonicFrequencies = ee.List.sequence(1, harmonics);
  var constructBandNames = function(base, list) {
    return ee.List(list).map(function(i) {
      return ee.String(base).cat(ee.Number(i).int());
    });
  };
  var cosNames = constructBandNames('cos_', harmonicFrequencies);
  var sinNames = constructBandNames('sin_', harmonicFrequencies);
  var independents = ee.List(['constant', 't']).cat(cosNames).cat(sinNames);
  var addDependents = function(image) {
    var years = image.date().difference('1970-01-01', 'year');
    var timeRadians = ee.Image(years.multiply(2 * Math.PI)).rename('t');
    return image.addBands(ee.Image(1)).addBands(timeRadians.float());
  };
  var addHarmonics = function(freqs) {
    return function(image) {
      var frequencies = ee.Image.constant(freqs);
      var time = ee.Image(image).select('t');
      var cosines = time.multiply(frequencies).cos().rename(cosNames);
      var sines = time.multiply(frequencies).sin().rename(sinNames);
      return image.addBands(cosines).addBands(sines);
    };
  };
  var collectionWithHarmonics = collection.map(addDependents).map(addHarmonics(harmonicFrequencies));
  var harmonicTrend = collectionWithHarmonics.select(independents.add(bandName))
    .reduce(ee.Reducer.linearRegression(independents.length(), 1));
  var harmonicCoefficients = harmonicTrend.select('coefficients')
    .arrayProject([0])
    .arrayFlatten([independents]);
  return collectionWithHarmonics.map(function(image) {
    var fitted = image.select(independents)
      .multiply(harmonicCoefficients)
      .reduce('sum')
      .rename('fitted');
    var smoothed = fitted
      .convolve(ee.Kernel.gaussian(4, 2)) // Kernel más ancho para suavizar más
      .rename('smoothed');
    return image.addBands(fitted).addBands(smoothed).copyProperties(image, ['system:time_start']);
  });
}
// Ensamblar interfaz
ui.root.clear();
var contenedorPrincipal = ui.SplitPanel({
  firstPanel: panelLateral,
  secondPanel: customMap,
  orientation: 'horizontal',
  style: {stretch: 'both'}
});
ui.root.add(contenedorPrincipal);