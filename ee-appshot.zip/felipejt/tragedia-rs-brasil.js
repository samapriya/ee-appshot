var table = ui.import && ui.import("table", "table", {
      "id": "users/felipejt/Piracicaba"
    }) || ee.FeatureCollection("users/felipejt/Piracicaba"),
    imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "COPERNICUS/S2_SR"
    }) || ee.ImageCollection("COPERNICUS/S2_SR"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "TCI_R",
          "TCI_G",
          "TCI_B"
        ],
        "min": 18,
        "max": 174,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["TCI_R","TCI_G","TCI_B"],"min":18,"max":174,"gamma":1},
    imageCollection2 = ui.import && ui.import("imageCollection2", "imageCollection", {
      "id": "LANDSAT/LE07/C01/T1_RT"
    }) || ee.ImageCollection("LANDSAT/LE07/C01/T1_RT"),
    table2 = ui.import && ui.import("table2", "table", {
      "id": "users/felipejt/municipios_RS_selecionados"
    }) || ee.FeatureCollection("users/felipejt/municipios_RS_selecionados"),
    table3 = ui.import && ui.import("table3", "table", {
      "id": "users/felipejt/municipios_RS_selecionados"
    }) || ee.FeatureCollection("users/felipejt/municipios_RS_selecionados"),
    table4 = ui.import && ui.import("table4", "table", {
      "id": "users/felipejt/area_estudo2"
    }) || ee.FeatureCollection("users/felipejt/area_estudo2"),
    table5 = ui.import && ui.import("table5", "table", {
      "id": "users/felipejt/municipios_RS_selecionados"
    }) || ee.FeatureCollection("users/felipejt/municipios_RS_selecionados"),
    table6 = ui.import && ui.import("table6", "table", {
      "id": "users/felipejt/estado_RS"
    }) || ee.FeatureCollection("users/felipejt/estado_RS"),
    table7 = ui.import && ui.import("table7", "table", {
      "id": "users/felipejt/municipios_RS2"
    }) || ee.FeatureCollection("users/felipejt/municipios_RS2"),
    table8 = ui.import && ui.import("table8", "table", {
      "id": "users/felipejt/municipios_RS_line"
    }) || ee.FeatureCollection("users/felipejt/municipios_RS_line"),
    table9 = ui.import && ui.import("table9", "table", {
      "id": "users/felipejt/RS"
    }) || ee.FeatureCollection("users/felipejt/RS");
var antiga = imageCollection
    .filterBounds(table9)
    .filterDate('2024-03-01', '2024-04-28')
    .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
    .select(['TCI_R', 'TCI_G', 'TCI_B']);
var nova = imageCollection
    .filterBounds(table9)
    .filterDate('2024-04-29', '2024-05-09')
    .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 60)
    .select(['TCI_R', 'TCI_G', 'TCI_B']);         
print(antiga); 
print(nova); 
var mosaico = antiga.mosaic();
var mosaico2 = nova.mosaic();
var leftMap = ui.Map();
var rightMap = ui.Map();
var img1 = ee.Image(mosaico).visualize({opacity: 0.7}); // Adiciona mosaico com 50% de transparência
var img2 = ee.Image(mosaico2).visualize({opacity: 0.7});
var img1_layer = leftMap.layers();
var img2_layer = rightMap.layers();
img1_layer.add(img1);
img2_layer.add(img2);
leftMap.addLayer(table8, {color: 'red'});
rightMap.addLayer(table8, {color: 'red'});
var img1_label = ui.Label('Abril- 2024');
img1_label.style().set('position', 'bottom-left');
var img2_label = ui.Label('Maio - 2024');
img2_label.style().set('position', 'bottom-right');
leftMap.add(img1_label);
rightMap.add(img2_label);
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe: true,
  style: {stretch: 'both'}
});
ui.root.clear();
ui.root.add(splitPanel);
var linkPanel = ui.Map.Linker([leftMap, rightMap]);
leftMap.centerObject(table4,10);