//genero es un diccionario donde cada entrada es un genero, 
//y las definiciones son el mismo genero en formato texto
var genero ={
  "Aburria": "Aburria",
  "Accipiter": "Accipiter",
  "Acropternis": "Acropternis",
  "Actitis": "Actitis",
  "Adelomyia": "Adelomyia",
  "Aegolius": "Aegolius",
  "Aeronautes": "Aeronautes",
  "Agamia": "Agamia",
  "Aglaeactis": "Aglaeactis",
  "Aglaiocercus": "Aglaiocercus",
  "Agriornis": "Agriornis",
  "Akletos": "Akletos",
  "Amaurolimnas": "Amaurolimnas",
  "Amazilia": "Amazilia",
  "Amazona": "Amazona",
  "Amazonetta": "Amazonetta",
  "Amblycercus": "Amblycercus",
  "Ammodramus": "Ammodramus",
  "Ammonastes": "Ammonastes",
  "Ampelioides": "Ampelioides",
  "Ampelion": "Ampelion",
  "Anabacerthia": "Anabacerthia",
  "Anabazenops": "Anabazenops",
  "Anairetes": "Anairetes",
  "Anas": "Anas",
  "Ancistrops": "Ancistrops",
  "Andigena": "Andigena",
  "Androdon": "Androdon",
  "Anhima": "Anhima",
  "Anhinga": "Anhinga",
  "Anisognathus": "Anisognathus",
  "Anous": "Anous",
  "Anthocephala": "Anthocephala",
  "Anthracothorax": "Anthracothorax",
  "Anthus": "Anthus",
  "Aphanotriccus": "Aphanotriccus",
  "Ara": "Ara",
  "Aramides": "Aramides",
  "Aramus": "Aramus",
  "Aratinga": "Aratinga",
  "Ardea": "Ardea",
  "Arenaria": "Arenaria",
  "Arremon": "Arremon",
  "Arremonops": "Arremonops",
  "Arundinicola": "Arundinicola",
  "Asio": "Asio",
  "Asthenes": "Asthenes",
  "Atalotriccus": "Atalotriccus",
  "Athene": "Athene",
  "Atlapetes": "Atlapetes",
  "Atticora": "Atticora",
  "Attila": "Attila",
  "Aulacorhynchus": "Aulacorhynchus",
  "Automolus": "Automolus",
  "Aythya": "Aythya",
  "Bangsia": "Bangsia",
  "Bartramia": "Bartramia",
  "Baryphthengus": "Baryphthengus",
  "Basileuterus": "Basileuterus",
  "Berlepschia": "Berlepschia",
  "Boissonneaua": "Boissonneaua",
  "Bolborhynchus": "Bolborhynchus",
  "Bombycilla": "Bombycilla",
  "Botaurus": "Botaurus",
  "Brachygalba": "Brachygalba",
  "Brotogeris": "Brotogeris",
  "Bubo": "Bubo",
  "Bubulcus": "Bubulcus",
  "Bucco": "Bucco",
  "Burhinus": "Burhinus",
  "Busarellus": "Busarellus",
  "Buteo": "Buteo",
  "Buteogallus": "Buteogallus",
  "Buthraupis": "Buthraupis",
  "Butorides": "Butorides",
  "Cacicus": "Cacicus",
  "Cairina": "Cairina",
  "Calidris": "Calidris",
  "Calliphlox": "Calliphlox",
  "Calochaetes": "Calochaetes",
  "Campephilus": "Campephilus",
  "Camptostoma": "Camptostoma",
  "Campylopterus": "Campylopterus",
  "Campylorhamphus": "Campylorhamphus",
  "Campylorhynchus": "Campylorhynchus",
  "Cantorchilus": "Cantorchilus",
  "Capito": "Capito",
  "Capsiempis": "Capsiempis",
  "Caracara": "Caracara",
  "Cardellina": "Cardellina",
  "Cardinalis": "Cardinalis",
  "Carpodectes": "Carpodectes",
  "Caryothraustes": "Caryothraustes",
  "Catamblyrhynchus": "Catamblyrhynchus",
  "Catamenia": "Catamenia",
  "Cathartes": "Cathartes",
  "Catharus": "Catharus",
  "Celeus": "Celeus",
  "Cephalopterus": "Cephalopterus",
  "Ceratopipra": "Ceratopipra",
  "Cercibis": "Cercibis",
  "Cercomacra": "Cercomacra",
  "Cercomacroides": "Cercomacroides",
  "Certhiaxis": "Certhiaxis",
  "Chaetocercus": "Chaetocercus",
  "Chaetura": "Chaetura",
  "Chalcostigma": "Chalcostigma",
  "Chalybura": "Chalybura",
  "Chamaepetes": "Chamaepetes",
  "Chamaeza": "Chamaeza",
  "Charadrius": "Charadrius",
  "Chauna": "Chauna",
  "Chelidoptera": "Chelidoptera",
  "Chiroxiphia": "Chiroxiphia",
  "Chlidonias": "Chlidonias",
  "Chloroceryle": "Chloroceryle",
  "Chlorochrysa": "Chlorochrysa",
  "Chlorophanes": "Chlorophanes",
  "Chlorophonia": "Chlorophonia",
  "Chlorornis": "Chlorornis",
  "Chlorospingus": "Chlorospingus",
  "Chlorostilbon": "Chlorostilbon",
  "Chondrohierax": "Chondrohierax",
  "Chordeiles": "Chordeiles",
  "Chrysolampis": "Chrysolampis",
  "Chrysomus": "Chrysomus",
  "Chrysothlypis": "Chrysothlypis",
  "Ciccaba": "Ciccaba",
  "Ciconia": "Ciconia",
  "Cinclodes": "Cinclodes",
  "Cinclus": "Cinclus",
  "Cinnycerthia": "Cinnycerthia",
  "Circus": "Circus",
  "Cissopis": "Cissopis",
  "Cistothorus": "Cistothorus",
  "Claravis": "Claravis",
  "Clibanornis": "Clibanornis",
  "Clytoctantes": "Clytoctantes",
  "Cnemarchus": "Cnemarchus",
  "Cnemathraupis": "Cnemathraupis",
  "Cnemoscopus": "Cnemoscopus",
  "Cnemotriccus": "Cnemotriccus",
  "Cnipodectes": "Cnipodectes",
  "Coccycua": "Coccycua",
  "Coccyzus": "Coccyzus",
  "Cochlearius": "Cochlearius",
  "Coeligena": "Coeligena",
  "Coereba": "Coereba",
  "Colaptes": "Colaptes",
  "Colibri": "Colibri",
  "Colinus": "Colinus",
  "Colonia": "Colonia",
  "Columbina": "Columbina",
  "Conirostrum": "Conirostrum",
  "Conopias": "Conopias",
  "Conopophaga": "Conopophaga",
  "Contopus": "Contopus",
  "Coragyps": "Coragyps",
  "Corapipo": "Corapipo",
  "Coryphospingus": "Coryphospingus",
  "Corythopis": "Corythopis",
  "Cotinga": "Cotinga",
  "Cranioleuca": "Cranioleuca",
  "Crax": "Crax",
  "Creurgops": "Creurgops",
  "Crotophaga": "Crotophaga",
  "Cryptoleucopteryx": "Cryptoleucopteryx",
  "Cryptopipo": "Cryptopipo",
  "Crypturellus": "Crypturellus",
  "Cyanerpes": "Cyanerpes",
  "Cyanocorax": "Cyanocorax",
  "Cyanoloxia": "Cyanoloxia",
  "Cyanolyca": "Cyanolyca",
  "Cyclarhis": "Cyclarhis",
  "Cymbilaimus": "Cymbilaimus",
  "Cyphorhinus": "Cyphorhinus",
  "Cypseloides": "Cypseloides",
  "Dacnis": "Dacnis",
  "Daptrius": "Daptrius",
  "Dendrexetastes": "Dendrexetastes",
  "Dendrocincla": "Dendrocincla",
  "Dendrocolaptes": "Dendrocolaptes",
  "Dendrocygna": "Dendrocygna",
  "Dendroplex": "Dendroplex",
  "Deroptyus": "Deroptyus",
  "Dichrozona": "Dichrozona",
  "Diglossa": "Diglossa",
  "Discosura": "Discosura",
  "Dives": "Dives",
  "Dolichonyx": "Dolichonyx",
  "Doliornis": "Doliornis",
  "Donacobius": "Donacobius",
  "Doryfera": "Doryfera",
  "Dromococcyx": "Dromococcyx",
  "Drymophila": "Drymophila",
  "Drymotoxeres": "Drymotoxeres",
  "Dubusia": "Dubusia",
  "Dumetella": "Dumetella",
  "Dysithamnus": "Dysithamnus",
  "Egretta": "Egretta",
  "Elaenia": "Elaenia",
  "Elanoides": "Elanoides",
  "Elanus": "Elanus",
  "Electron": "Electron",
  "Emberizoides": "Emberizoides",
  "Empidonax": "Empidonax",
  "Empidonomus": "Empidonomus",
  "Ensifera": "Ensifera",
  "Epinecrophylla": "Epinecrophylla",
  "Eremophila": "Eremophila",
  "Eriocnemis": "Eriocnemis",
  "Eubucco": "Eubucco",
  "Euchrepomis": "Euchrepomis",
  "Eucometis": "Eucometis",
  "Eudocimus": "Eudocimus",
  "Euphonia": "Euphonia",
  "Eurypyga": "Eurypyga",
  "Euscarthmus": "Euscarthmus",
  "Eutoxeres": "Eutoxeres",
  "Falco": "Falco",
  "Florisuga": "Florisuga",
  "Fluvicola": "Fluvicola",
  "Formicarius": "Formicarius",
  "Formicivora": "Formicivora",
  "Forpus": "Forpus",
  "Frederickena": "Frederickena",
  "Fregata": "Fregata",
  "Fulica": "Fulica",
  "Furnarius": "Furnarius",
  "Galbalcyrhynchus": "Galbalcyrhynchus",
  "Galbula": "Galbula",
  "Gallinago": "Gallinago",
  "Gampsonyx": "Gampsonyx",
  "Geothlypis": "Geothlypis",
  "Geotrygon": "Geotrygon",
  "Geranospiza": "Geranospiza",
  "Glaucidium": "Glaucidium",
  "Glaucis": "Glaucis",
  "Glyphorynchus": "Glyphorynchus",
  "Goethalsia": "Goethalsia",
  "Goldmania": "Goldmania",
  "Grallaria": "Grallaria",
  "Grallaricula": "Grallaricula",
  "Granatellus": "Granatellus",
  "Graydidascalus": "Graydidascalus",
  "Gymnocichla": "Gymnocichla",
  "Gymnoderus": "Gymnoderus",
  "Gymnomystax": "Gymnomystax",
  "Gymnopithys": "Gymnopithys",
  "Habia": "Habia",
  "Haematopus": "Haematopus",
  "Hafferia": "Hafferia",
  "Hapalopsittaca": "Hapalopsittaca",
  "Hapaloptila": "Hapaloptila",
  "Haplophaedia": "Haplophaedia",
  "Harpagus": "Harpagus",
  "Harpia": "Harpia",
  "Heliangelus": "Heliangelus",
  "Helicolestes": "Helicolestes",
  "Heliodoxa": "Heliodoxa",
  "Heliomaster": "Heliomaster",
  "Heliornis": "Heliornis",
  "Heliothryx": "Heliothryx",
  "Hellmayrea": "Hellmayrea",
  "Helmitheros": "Helmitheros",
  "Hemithraupis": "Hemithraupis",
  "Hemitriccus": "Hemitriccus",
  "Henicorhina": "Henicorhina",
  "Herpetotheres": "Herpetotheres",
  "Herpsilochmus": "Herpsilochmus",
  "Heterocercus": "Heterocercus",
  "Heterospingus": "Heterospingus",
  "Hirundinea": "Hirundinea",
  "Hirundo": "Hirundo",
  "Hydroprogne": "Hydroprogne",
  "Hydropsalis": "Hydropsalis",
  "Hylexetastes": "Hylexetastes",
  "Hylocichla": "Hylocichla",
  "Hylomanes": "Hylomanes",
  "Hylopezus": "Hylopezus",
  "Hylophilus": "Hylophilus",
  "Hylophylax": "Hylophylax",
  "Hypnelus": "Hypnelus",
  "Hypocnemis": "Hypocnemis",
  "Hypocnemoides": "Hypocnemoides",
  "Hypopyrrhus": "Hypopyrrhus",
  "Ibycter": "Ibycter",
  "Icterus": "Icterus",
  "Ictinia": "Ictinia",
  "Inezia": "Inezia",
  "Iodopleura": "Iodopleura",
  "Iridophanes": "Iridophanes",
  "Iridosornis": "Iridosornis",
  "Isleria": "Isleria",
  "Ixobrychus": "Ixobrychus",
  "Jabiru": "Jabiru",
  "Jacamerops": "Jacamerops",
  "Jacana": "Jacana",
  "Klais": "Klais",
  "Kleinothraupis": "Kleinothraupis",
  "Knipolegus": "Knipolegus",
  "Lafresnaya": "Lafresnaya",
  "Lampropsar": "Lampropsar",
  "Lanio": "Lanio",
  "Laniocera": "Laniocera",
  "Laterallus": "Laterallus",
  "Lathrotriccus": "Lathrotriccus",
  "Legatus": "Legatus",
  "Leiothlypis": "Leiothlypis",
  "Lepidocolaptes": "Lepidocolaptes",
  "Lepidothrix": "Lepidothrix",
  "Leptasthenura": "Leptasthenura",
  "Leptodon": "Leptodon",
  "Leptopogon": "Leptopogon",
  "Leptosittaca": "Leptosittaca",
  "Leptotila": "Leptotila",
  "Leptotrygon": "Leptotrygon",
  "Lesbia": "Lesbia",
  "Leucippus": "Leucippus",
  "Leucopternis": "Leucopternis",
  "Limnodromus": "Limnodromus",
  "Limosa": "Limosa",
  "Liosceles": "Liosceles",
  "Lipaugus": "Lipaugus",
  "Lochmias": "Lochmias",
  "Lonchura": "Lonchura",
  "Lophornis": "Lophornis",
  "Lophostrix": "Lophostrix",
  "Lophotriccus": "Lophotriccus",
  "Lurocalis": "Lurocalis",
  "Machaeropterus": "Machaeropterus",
  "Machetornis": "Machetornis",
  "Macroagelaius": "Macroagelaius",
  "Malacoptila": "Malacoptila",
  "Manacus": "Manacus",
  "Margarornis": "Margarornis",
  "Masius": "Masius",
  "Mecocerculus": "Mecocerculus",
  "Megaceryle": "Megaceryle",
  "Megarynchus": "Megarynchus",
  "Megascops": "Megascops",
  "Megastictus": "Megastictus",
  "Melanerpes": "Melanerpes",
  "Merganetta": "Merganetta",
  "Mesembrinibis": "Mesembrinibis",
  "Metallura": "Metallura",
  "Metopothrix": "Metopothrix",
  "Micrastur": "Micrastur",
  "Microbates": "Microbates",
  "Microcerculus": "Microcerculus",
  "Micromonacha": "Micromonacha",
  "Micropygia": "Micropygia",
  "Microrhopias": "Microrhopias",
  "Milvago": "Milvago",
  "Mimus": "Mimus",
  "Mionectes": "Mionectes",
  "Mitrephanes": "Mitrephanes",
  "Mitrospingus": "Mitrospingus",
  "Mitu": "Mitu",
  "Mniotilta": "Mniotilta",
  "Molothrus": "Molothrus",
  "Momotus": "Momotus",
  "Monasa": "Monasa",
  "Morphnarchus": "Morphnarchus",
  "Morphnus": "Morphnus",
  "Muscisaxicola": "Muscisaxicola",
  "Myadestes": "Myadestes",
  "Mycteria": "Mycteria",
  "Myiarchus": "Myiarchus",
  "Myiobius": "Myiobius",
  "Myioborus": "Myioborus",
  "Myiodynastes": "Myiodynastes",
  "Myiopagis": "Myiopagis",
  "Myiophobus": "Myiophobus",
  "Myiornis": "Myiornis",
  "Myiotheretes": "Myiotheretes",
  "Myiothlypis": "Myiothlypis",
  "Myiotriccus": "Myiotriccus",
  "Myiozetetes": "Myiozetetes",
  "Myornis": "Myornis",
  "Myrmeciza": "Myrmeciza",
  "Myrmelastes": "Myrmelastes",
  "Myrmoborus": "Myrmoborus",
  "Myrmochanes": "Myrmochanes",
  "Myrmornis": "Myrmornis",
  "Myrmothera": "Myrmothera",
  "Myrmotherula": "Myrmotherula",
  "Nasica": "Nasica",
  "Nemosia": "Nemosia",
  "Neoctantes": "Neoctantes",
  "Neomorphus": "Neomorphus",
  "Neopelma": "Neopelma",
  "Neopipo": "Neopipo",
  "Nephelomyias": "Nephelomyias",
  "Netta": "Netta",
  "Nomonyx": "Nomonyx",
  "Nonnula": "Nonnula",
  "Notharchus": "Notharchus",
  "Nothocercus": "Nothocercus",
  "Nothocrax": "Nothocrax",
  "Numenius": "Numenius",
  "Nyctibius": "Nyctibius",
  "Nycticorax": "Nycticorax",
  "Nyctidromus": "Nyctidromus",
  "Nyctiphrynus": "Nyctiphrynus",
  "Nyctiprogne": "Nyctiprogne",
  "Nystalus": "Nystalus",
  "Ochthoeca": "Ochthoeca",
  "Ochthornis": "Ochthornis",
  "Ocreatus": "Ocreatus",
  "Odontophorus": "Odontophorus",
  "Odontorchilus": "Odontorchilus",
  "Ognorhynchus": "Ognorhynchus",
  "Onychoprion": "Onychoprion",
  "Onychorhynchus": "Onychorhynchus",
  "Opisthocomus": "Opisthocomus",
  "Opisthoprora": "Opisthoprora",
  "Oporornis": "Oporornis",
  "Oreothraupis": "Oreothraupis",
  "Oreotrochilus": "Oreotrochilus",
  "Ornithion": "Ornithion",
  "Orochelidon": "Orochelidon",
  "Ortalis": "Ortalis",
  "Oxypogon": "Oxypogon",
  "Oxyruncus": "Oxyruncus",
  "Pachyramphus": "Pachyramphus",
  "Pachysylvia": "Pachysylvia",
  "Pandion": "Pandion",
  "Panyptila": "Panyptila",
  "Parabuteo": "Parabuteo",
  "Pardirallus": "Pardirallus",
  "Parkerthraustes": "Parkerthraustes",
  "Parkesia": "Parkesia",
  "Paroaria": "Paroaria",
  "Passer": "Passer",
  "Passerina": "Passerina",
  "Patagioenas": "Patagioenas",
  "Patagona": "Patagona",
  "Pauxi": "Pauxi",
  "Pelecanus": "Pelecanus",
  "Penelope": "Penelope",
  "Percnostola": "Percnostola",
  "Perissocephalus": "Perissocephalus",
  "Petrochelidon": "Petrochelidon",
  "Phaenostictus": "Phaenostictus",
  "Phaeomyias": "Phaeomyias",
  "Phaethon": "Phaethon",
  "Phaethornis": "Phaethornis",
  "Phaetusa": "Phaetusa",
  "Phalaropus": "Phalaropus",
  "Phalcoboenus": "Phalcoboenus",
  "Pharomachrus": "Pharomachrus",
  "Phelpsia": "Phelpsia",
  "Pheucticus": "Pheucticus",
  "Pheugopedius": "Pheugopedius",
  "Philydor": "Philydor",
  "Phimosus": "Phimosus",
  "Phlegopsis": "Phlegopsis",
  "Phlogophilus": "Phlogophilus",
  "Phoenicircus": "Phoenicircus",
  "Phoenicopterus": "Phoenicopterus",
  "Phyllomyias": "Phyllomyias",
  "Phylloscartes": "Phylloscartes",
  "Piaya": "Piaya",
  "Piculus": "Piculus",
  "Picumnus": "Picumnus",
  "Pilherodius": "Pilherodius",
  "Pionites": "Pionites",
  "Pionus": "Pionus",
  "Pipra": "Pipra",
  "Pipraeidea": "Pipraeidea",
  "Pipreola": "Pipreola",
  "Piprites": "Piprites",
  "Piranga": "Piranga",
  "Pitangus": "Pitangus",
  "Pithys": "Pithys",
  "Pittasoma": "Pittasoma",
  "Platalea": "Platalea",
  "Platyrinchus": "Platyrinchus",
  "Plegadis": "Plegadis",
  "Pluvialis": "Pluvialis",
  "Podilymbus": "Podilymbus",
  "Poecilotriccus": "Poecilotriccus",
  "Poliocrania": "Poliocrania",
  "Polioptila": "Polioptila",
  "Polystictus": "Polystictus",
  "Polytmus": "Polytmus",
  "Porphyrio": "Porphyrio",
  "Porphyrolaema": "Porphyrolaema",
  "Porzana": "Porzana",
  "Premnoplex": "Premnoplex",
  "Premnornis": "Premnornis",
  "Procnias": "Procnias",
  "Progne": "Progne",
  "Protonotaria": "Protonotaria",
  "Psarocolius": "Psarocolius",
  "Pseudocolopteryx": "Pseudocolopteryx",
  "Pseudospingus": "Pseudospingus",
  "Pseudotriccus": "Pseudotriccus",
  "Psittacara": "Psittacara",
  "Psophia": "Psophia",
  "Pteroglossus": "Pteroglossus",
  "Pterophanes": "Pterophanes",
  "Pulsatrix": "Pulsatrix",
  "Pygiptila": "Pygiptila",
  "Pyriglena": "Pyriglena",
  "Pyrilia": "Pyrilia",
  "Pyrocephalus": "Pyrocephalus",
  "Pyroderus": "Pyroderus",
  "Pyrrhomyias": "Pyrrhomyias",
  "Pyrrhura": "Pyrrhura",
  "Querula": "Querula",
  "Quiscalus": "Quiscalus",
  "Rallus": "Rallus",
  "Ramphastos": "Ramphastos",
  "Ramphocaenus": "Ramphocaenus",
  "Ramphocelus": "Ramphocelus",
  "Ramphomicron": "Ramphomicron",
  "Ramphotrigon": "Ramphotrigon",
  "Rhegmatorhina": "Rhegmatorhina",
  "Rhodinocichla": "Rhodinocichla",
  "Rhynchocyclus": "Rhynchocyclus",
  "Rhynchortyx": "Rhynchortyx",
  "Rhytipterna": "Rhytipterna",
  "Riparia": "Riparia",
  "Rostrhamus": "Rostrhamus",
  "Rupicola": "Rupicola",
  "Rupornis": "Rupornis",
  "Rynchops": "Rynchops",
  "Sakesphorus": "Sakesphorus",
  "Saltator": "Saltator",
  "Sapayoa": "Sapayoa",
  "Sarcoramphus": "Sarcoramphus",
  "Satrapa": "Satrapa",
  "Sayornis": "Sayornis",
  "Schiffornis": "Schiffornis",
  "Schistes": "Schistes",
  "Schistochlamys": "Schistochlamys",
  "Sclerurus": "Sclerurus",
  "Scytalopus": "Scytalopus",
  "Seiurus": "Seiurus",
  "Selenidera": "Selenidera",
  "Semnornis": "Semnornis",
  "Sericossypha": "Sericossypha",
  "Serpophaga": "Serpophaga",
  "Setophaga": "Setophaga",
  "Sicalis": "Sicalis",
  "Sipia": "Sipia",
  "Sirystes": "Sirystes",
  "Sittasomus": "Sittasomus",
  "Snowornis": "Snowornis",
  "Sphenopsis": "Sphenopsis",
  "Sphyrapicus": "Sphyrapicus",
  "Spinus": "Spinus",
  "Spiza": "Spiza",
  "Spizaetus": "Spizaetus",
  "Spodiornis": "Spodiornis",
  "Sporophila": "Sporophila",
  "Steatornis": "Steatornis",
  "Stelgidopteryx": "Stelgidopteryx",
  "Stercorarius": "Stercorarius",
  "Sterna": "Sterna",
  "Sternoclyta": "Sternoclyta",
  "Sternula": "Sternula",
  "Stigmatura": "Stigmatura",
  "Streptoprocne": "Streptoprocne",
  "Sturnella": "Sturnella",
  "Sublegatus": "Sublegatus",
  "Sula": "Sula",
  "Synallaxis": "Synallaxis",
  "Syndactyla": "Syndactyla",
  "Syrigma": "Syrigma",
  "Tachornis": "Tachornis",
  "Tachybaptus": "Tachybaptus",
  "Tachycineta": "Tachycineta",
  "Tachyphonus": "Tachyphonus",
  "Tangara": "Tangara",
  "Tapera": "Tapera",
  "Taphrospilus": "Taphrospilus",
  "Taraba": "Taraba",
  "Terenotriccus": "Terenotriccus",
  "Tersina": "Tersina",
  "Thalasseus": "Thalasseus",
  "Thalurania": "Thalurania",
  "Thamnistes": "Thamnistes",
  "Thamnomanes": "Thamnomanes",
  "Thamnophilus": "Thamnophilus",
  "Theristicus": "Theristicus",
  "Thlypopsis": "Thlypopsis",
  "Threnetes": "Threnetes",
  "Thripadectes": "Thripadectes",
  "Thryophilus": "Thryophilus",
  "Tiaris": "Tiaris",
  "Tigrisoma": "Tigrisoma",
  "Tinamus": "Tinamus",
  "Tityra": "Tityra",
  "Todirostrum": "Todirostrum",
  "Tolmomyias": "Tolmomyias",
  "Topaza": "Topaza",
  "Touit": "Touit",
  "Tringa": "Tringa",
  "Troglodytes": "Troglodytes",
  "Trogon": "Trogon",
  "Turdus": "Turdus",
  "Tyranneutes": "Tyranneutes",
  "Tyrannopsis": "Tyrannopsis",
  "Tyrannulus": "Tyrannulus",
  "Tyrannus": "Tyrannus",
  "Tyto": "Tyto",
  "Urochroa": "Urochroa",
  "Uropsalis": "Uropsalis",
  "Urosticte": "Urosticte",
  "Urothraupis": "Urothraupis",
  "Vanellus": "Vanellus",
  "Veniliornis": "Veniliornis",
  "Vermivora": "Vermivora",
  "Vireo": "Vireo",
  "Vireolanius": "Vireolanius",
  "Volatinia": "Volatinia",
  "Vultur": "Vultur",
  "Willisornis": "Willisornis",
  "Xema": "Xema",
  "Xenerpestes": "Xenerpestes",
  "Xenopipo": "Xenopipo",
  "Xenops": "Xenops",
  "Xenornis": "Xenornis",
  "Xiphocolaptes": "Xiphocolaptes",
  "Xipholena": "Xipholena",
  "Xiphorhynchus": "Xiphorhynchus",
  "Zebrilus": "Zebrilus",
  "Zenaida": "Zenaida",
  "Zentrygon": "Zentrygon",
  "Zimmerius": "Zimmerius",
  "Zonotrichia": "Zonotrichia"
}
//epiteto es un diccionario donde cada entrada es un genero
//y las definiciones son listas con los epitetos especificos de cada genero
var epiteto = {
  "Aburria": [
    "aburri"
  ],
  "Accipiter": [
    "poliogaster",
    "cooperii",
    "bicolor",
    "striatus",
    "superciliosus",
    "collaris"
  ],
  "Acropternis": [
    "orthonyx"
  ],
  "Actitis": [
    "macularius"
  ],
  "Adelomyia": [
    "melanogenys"
  ],
  "Aegolius": [
    "harrisii"
  ],
  "Aeronautes": [
    "montivagus"
  ],
  "Agamia": [
    "agami"
  ],
  "Aglaeactis": [
    "cupripennis"
  ],
  "Aglaiocercus": [
    "kingii",
    "coelestis"
  ],
  "Agriornis": [
    "montanus"
  ],
  "Akletos": [
    "melanoceps"
  ],
  "Amaurolimnas": [
    "concolor"
  ],
  "Amazilia": [
    "tzacatl",
    "fimbriata",
    "viridigaster",
    "franciae",
    "cyanifrons",
    "versicolor",
    "castaneiventris",
    "rosenbergi",
    "amabilis"
  ],
  "Amazona": [
    "autumnalis",
    "ochrocephala",
    "amazonica",
    "farinosa",
    "festiva"
  ],
  "Amazonetta": [
    "brasiliensis"
  ],
  "Amblycercus": [
    "holosericeus"
  ],
  "Ammodramus": [
    "humeralis",
    "aurifrons",
    "savannarum"
  ],
  "Ammonastes": [
    "pelzelni"
  ],
  "Ampelioides": [
    "tschudii"
  ],
  "Ampelion": [
    "rubrocristatus",
    "rufaxilla"
  ],
  "Anabacerthia": [
    "variegaticeps",
    "striaticollis"
  ],
  "Anabazenops": [
    "dorsalis"
  ],
  "Anairetes": [
    "parulus"
  ],
  "Anas": [
    "acuta",
    "bahamensis",
    "georgica"
  ],
  "Ancistrops": [
    "strigilatus"
  ],
  "Andigena": [
    "nigrirostris",
    "laminirostris",
    "hypoglauca"
  ],
  "Androdon": [
    "aequatorialis"
  ],
  "Anhima": [
    "cornuta"
  ],
  "Anhinga": [
    "anhinga"
  ],
  "Anisognathus": [
    "somptuosus",
    "notabilis",
    "melanogenys",
    "lacrymosus"
  ],
  "Anous": [
    "stolidus"
  ],
  "Anthocephala": [
    "berlepschi",
    "floriceps"
  ],
  "Anthracothorax": [
    "nigricollis",
    "prevostii"
  ],
  "Anthus": [
    "lutescens",
    "bogotensis"
  ],
  "Aphanotriccus": [
    "audax"
  ],
  "Ara": [
    "macao",
    "militaris",
    "chloropterus",
    "severus",
    "ambiguus",
    "ararauna"
  ],
  "Aramides": [
    "axillaris",
    "wolfi"
  ],
  "Aramus": [
    "guarauna"
  ],
  "Aratinga": [
    "weddellii"
  ],
  "Ardea": [
    "alba",
    "herodias",
    "cocoi"
  ],
  "Arenaria": [
    "interpres"
  ],
  "Arremon": [
    "assimilis",
    "taciturnus",
    "schlegeli",
    "basilicus",
    "castaneiceps",
    "atricapillus",
    "brunneinucha",
    "perijanus",
    "aurantiirostris",
    "crassirostris"
  ],
  "Arremonops": [
    "conirostris",
    "tocuyensis"
  ],
  "Arundinicola": [
    "leucocephala"
  ],
  "Asio": [
    "flammeus",
    "stygius"
  ],
  "Asthenes": [
    "flammulata",
    "wyatti",
    "perijana",
    "fuliginosa"
  ],
  "Atalotriccus": [
    "pilaris"
  ],
  "Athene": [
    "cunicularia"
  ],
  "Atlapetes": [
    "blancae",
    "latinuchus",
    "flaviceps",
    "albinucha",
    "pallidinucha",
    "schistaceus",
    "melanocephalus",
    "albofrenatus",
    "semirufus",
    "fuscoolivaceus",
    "leucopis"
  ],
  "Atticora": [
    "fasciata"
  ],
  "Attila": [
    "cinnamomeus",
    "citriniventris",
    "torridus",
    "spadiceus",
    "bolivianus"
  ],
  "Aulacorhynchus": [
    "derbianus",
    "haematopygus"
  ],
  "Automolus": [
    "subulatus",
    "infuscatus",
    "melanopezus",
    "ochrolaemus",
    "rufipileatus"
  ],
  "Aythya": [
    "collaris",
    "affinis"
  ],
  "Bangsia": [
    "arcaei",
    "melanochlamys",
    "edwardsi",
    "rothschildi",
    "aureocincta"
  ],
  "Bartramia": [
    "longicauda"
  ],
  "Baryphthengus": [
    "martii"
  ],
  "Basileuterus": [
    "ignotus",
    "rufifrons"
  ],
  "Berlepschia": [
    "rikeri"
  ],
  "Boissonneaua": [
    "jardini",
    "flavescens",
    "matthewsii"
  ],
  "Bolborhynchus": [
    "lineola",
    "ferrugineifrons"
  ],
  "Bombycilla": [
    "cedrorum"
  ],
  "Botaurus": [
    "pinnatus"
  ],
  "Brachygalba": [
    "goeringi",
    "salmoni",
    "lugubris"
  ],
  "Brotogeris": [
    "sanctithomae",
    "cyanoptera",
    "versicolurus",
    "jugularis"
  ],
  "Bubo": [
    "virginianus"
  ],
  "Bubulcus": [
    "ibis"
  ],
  "Bucco": [
    "capensis"
  ],
  "Burhinus": [
    "bistriatus"
  ],
  "Busarellus": [
    "nigricollis"
  ],
  "Buteo": [
    "swainsoni",
    "platypterus",
    "albonotatus",
    "albigula",
    "nitidus",
    "brachyurus"
  ],
  "Buteogallus": [
    "meridionalis",
    "urubitinga",
    "anthracinus"
  ],
  "Buthraupis": [
    "montana"
  ],
  "Butorides": [
    "striata"
  ],
  "Cacicus": [
    "uropygialis",
    "oseryi",
    "solitarius",
    "latirostris",
    "haemorrhous"
  ],
  "Cairina": [
    "moschata"
  ],
  "Calidris": [
    "alba",
    "melanotos",
    "himantopus",
    "minutilla",
    "fuscicollis",
    "canutus",
    "pusilla",
    "mauri",
    "virgata",
    "bairdii"
  ],
  "Calliphlox": [
    "amethystina",
    "mitchellii"
  ],
  "Calochaetes": [
    "coccineus"
  ],
  "Campephilus": [
    "pollens",
    "rubricollis",
    "melanoleucos",
    "gayaquilensis",
    "haematogaster"
  ],
  "Camptostoma": [
    "obsoletum"
  ],
  "Campylopterus": [
    "villaviscensio",
    "largipennis",
    "falcatus",
    "phainopeplus"
  ],
  "Campylorhamphus": [
    "procurvoides",
    "pusillus",
    "trochilirostris"
  ],
  "Campylorhynchus": [
    "zonatus",
    "nuchalis",
    "albobrunneus",
    "griseus",
    "turdinus"
  ],
  "Cantorchilus": [
    "leucopogon",
    "nigricapillus",
    "leucotis"
  ],
  "Capito": [
    "hypoleucus",
    "quinticolor",
    "squamatus",
    "aurovirens",
    "maculicoronatus",
    "auratus"
  ],
  "Capsiempis": [
    "flaveola"
  ],
  "Caracara": [
    "cheriway"
  ],
  "Cardellina": [
    "canadensis"
  ],
  "Cardinalis": [
    "phoeniceus"
  ],
  "Carpodectes": [
    "hopkei"
  ],
  "Caryothraustes": [
    "canadensis"
  ],
  "Catamblyrhynchus": [
    "diadema"
  ],
  "Catamenia": [
    "analis",
    "homochroa",
    "inornata"
  ],
  "Cathartes": [
    "aura",
    "burrovianus",
    "melambrotus"
  ],
  "Catharus": [
    "fuscescens",
    "aurantiirostris",
    "minimus",
    "ustulatus"
  ],
  "Celeus": [
    "elegans",
    "loricatus",
    "flavus"
  ],
  "Cephalopterus": [
    "penduliger",
    "ornatus"
  ],
  "Ceratopipra": [
    "mentalis"
  ],
  "Cercibis": [
    "oxycerca"
  ],
  "Cercomacra": [
    "nigricans",
    "cinerascens"
  ],
  "Cercomacroides": [
    "parkeri",
    "serva",
    "fuscicauda"
  ],
  "Certhiaxis": [
    "cinnamomeus",
    "mustelinus"
  ],
  "Chaetocercus": [
    "mulsant",
    "jourdanii",
    "astreans",
    "heliodor",
    "bombus"
  ],
  "Chaetura": [
    "chapmani",
    "cinereiventris",
    "brachyura",
    "pelagica",
    "spinicaudus"
  ],
  "Chalcostigma": [
    "herrani",
    "heteropogon"
  ],
  "Chalybura": [
    "buffonii",
    "urochrysia"
  ],
  "Chamaepetes": [
    "goudotii"
  ],
  "Chamaeza": [
    "mollissima",
    "campanisona",
    "turdina",
    "nobilis"
  ],
  "Charadrius": [
    "collaris",
    "wilsonia",
    "vociferus",
    "semipalmatus"
  ],
  "Chauna": [
    "chavaria"
  ],
  "Chelidoptera": [
    "tenebrosa"
  ],
  "Chiroxiphia": [
    "lanceolata",
    "pareola"
  ],
  "Chlidonias": [
    "niger"
  ],
  "Chloroceryle": [
    "americana",
    "amazona",
    "aenea",
    "inda"
  ],
  "Chlorochrysa": [
    "phoenicotis",
    "calliparaea",
    "nitidissima"
  ],
  "Chlorophanes": [
    "spiza"
  ],
  "Chlorophonia": [
    "pyrrhophrys",
    "cyanea",
    "flavirostris"
  ],
  "Chlorornis": [
    "riefferii"
  ],
  "Chlorospingus": [
    "semifuscus",
    "canigularis",
    "parvirostris",
    "flavigularis",
    "flavopectus",
    "inornatus",
    "tacarcunae"
  ],
  "Chlorostilbon": [
    "russatus",
    "olivaresi",
    "poortmani",
    "mellisugus",
    "gibsoni",
    "stenurus"
  ],
  "Chondrohierax": [
    "uncinatus"
  ],
  "Chordeiles": [
    "pusillus",
    "acutipennis",
    "minor",
    "rupestris"
  ],
  "Chrysolampis": [
    "mosquitus"
  ],
  "Chrysomus": [
    "icterocephalus"
  ],
  "Chrysothlypis": [
    "salmoni",
    "chrysomelas"
  ],
  "Ciccaba": [
    "virgata",
    "nigrolineata",
    "albitarsis",
    "huhula"
  ],
  "Ciconia": [
    "maguari"
  ],
  "Cinclodes": [
    "albidiventris",
    "excelsior"
  ],
  "Cinclus": [
    "leucocephalus"
  ],
  "Cinnycerthia": [
    "olivascens",
    "unirufa"
  ],
  "Circus": [
    "buffoni",
    "cinereus"
  ],
  "Cissopis": [
    "leverianus"
  ],
  "Cistothorus": [
    "platensis",
    "apolinari"
  ],
  "Claravis": [
    "pretiosa"
  ],
  "Clibanornis": [
    "rufipectus"
  ],
  "Clytoctantes": [
    "alixii"
  ],
  "Cnemarchus": [
    "erythropygius"
  ],
  "Cnemathraupis": [
    "eximia"
  ],
  "Cnemoscopus": [
    "rubrirostris"
  ],
  "Cnemotriccus": [
    "fuscatus"
  ],
  "Cnipodectes": [
    "subbrunneus"
  ],
  "Coccycua": [
    "pumila",
    "cinerea"
  ],
  "Coccyzus": [
    "erythropthalmus",
    "lansbergi",
    "melacoryphus",
    "minor",
    "euleri",
    "americanus"
  ],
  "Cochlearius": [
    "cochlearius"
  ],
  "Coeligena": [
    "lutetiae",
    "phalerata",
    "bonapartei",
    "wilsoni",
    "coeligena",
    "helianthea",
    "prunellei",
    "torquata"
  ],
  "Coereba": [
    "flaveola"
  ],
  "Colaptes": [
    "rivolii",
    "punctigula"
  ],
  "Colibri": [
    "thalassinus",
    "delphinae",
    "coruscans"
  ],
  "Colinus": [
    "cristatus"
  ],
  "Colonia": [
    "colonus"
  ],
  "Columbina": [
    "cruziana",
    "talpacoti",
    "passerina",
    "minuta",
    "squammata",
    "picui"
  ],
  "Conirostrum": [
    "albifrons",
    "leucogenys",
    "rufum",
    "speciosum",
    "bicolor",
    "binghami",
    "sitticolor"
  ],
  "Conopias": [
    "cinchoneti",
    "albovittatus"
  ],
  "Conopophaga": [
    "castaneiceps",
    "aurita"
  ],
  "Contopus": [
    "fumigatus",
    "cooperi",
    "sordidulus",
    "virens"
  ],
  "Coragyps": [
    "atratus"
  ],
  "Corapipo": [
    "leucorrhoa"
  ],
  "Coryphospingus": [
    "pileatus"
  ],
  "Corythopis": [
    "torquatus"
  ],
  "Cotinga": [
    "maynana",
    "cotinga",
    "nattererii"
  ],
  "Cranioleuca": [
    "subcristata",
    "vulpina",
    "curtata",
    "hellmayri",
    "erythrops"
  ],
  "Crax": [
    "rubra",
    "daubentoni",
    "alector",
    "alberti",
    "globulosa"
  ],
  "Creurgops": [
    "verticalis"
  ],
  "Crotophaga": [
    "sulcirostris",
    "ani",
    "major"
  ],
  "Cryptoleucopteryx": [
    "plumbea"
  ],
  "Cryptopipo": [
    "holochlora"
  ],
  "Crypturellus": [
    "cinereus",
    "duidae",
    "undulatus",
    "casiquiare",
    "erythropus",
    "berlepschi",
    "kerriae",
    "variegatus",
    "obsoletus"
  ],
  "Cyanerpes": [
    "nitidus",
    "lucidus",
    "caeruleus",
    "cyaneus"
  ],
  "Cyanocorax": [
    "yncas",
    "affinis",
    "violaceus",
    "heilprini"
  ],
  "Cyanoloxia": [
    "cyanoides",
    "brissonii"
  ],
  "Cyanolyca": [
    "armillata",
    "pulchra"
  ],
  "Cyclarhis": [
    "nigrirostris",
    "gujanensis"
  ],
  "Cymbilaimus": [
    "lineatus"
  ],
  "Cyphorhinus": [
    "arada"
  ],
  "Cypseloides": [
    "cryptus",
    "cherriei",
    "lemosi"
  ],
  "Dacnis": [
    "flaviventer",
    "venusta",
    "viguieri",
    "cayana",
    "lineata",
    "albiventris",
    "hartlaubi"
  ],
  "Daptrius": [
    "ater"
  ],
  "Dendrexetastes": [
    "rufigula"
  ],
  "Dendrocincla": [
    "merula",
    "fuliginosa",
    "homochroa",
    "tyrannina"
  ],
  "Dendrocolaptes": [
    "certhia",
    "picumnus",
    "sanctithomae"
  ],
  "Dendrocygna": [
    "autumnalis",
    "viduata",
    "bicolor"
  ],
  "Dendroplex": [
    "kienerii"
  ],
  "Deroptyus": [
    "accipitrinus"
  ],
  "Dichrozona": [
    "cincta"
  ],
  "Diglossa": [
    "cyanea",
    "humeralis",
    "indigotica",
    "caerulescens",
    "glauca",
    "albilatera",
    "brunneiventris",
    "sittoides",
    "lafresnayii",
    "gloriosissima"
  ],
  "Discosura": [
    "popelairii",
    "longicaudus",
    "langsdorffi",
    "conversii"
  ],
  "Dives": [
    "warczewiczi"
  ],
  "Dolichonyx": [
    "oryzivorus"
  ],
  "Doliornis": [
    "remseni"
  ],
  "Donacobius": [
    "atricapilla"
  ],
  "Doryfera": [
    "johannae",
    "ludovicae"
  ],
  "Dromococcyx": [
    "pavoninus",
    "phasianellus"
  ],
  "Drymophila": [
    "striaticeps",
    "caudata",
    "klagesi",
    "devillei"
  ],
  "Drymotoxeres": [
    "pucheranii"
  ],
  "Dubusia": [
    "taeniata"
  ],
  "Dumetella": [
    "carolinensis"
  ],
  "Dysithamnus": [
    "occidentalis",
    "puncticeps",
    "leucostictus",
    "mentalis"
  ],
  "Egretta": [
    "thula",
    "caerulea",
    "rufescens",
    "tricolor"
  ],
  "Elaenia": [
    "flavogaster",
    "albiceps",
    "pallatangae",
    "pelzelni",
    "cristata",
    "spectabilis",
    "ruficeps",
    "frantzii",
    "chiriquensis",
    "parvirostris",
    "gigas",
    "brachyptera",
    "strepera"
  ],
  "Elanoides": [
    "forficatus"
  ],
  "Elanus": [
    "leucurus"
  ],
  "Electron": [
    "platyrhynchum"
  ],
  "Emberizoides": [
    "herbicola"
  ],
  "Empidonax": [
    "virescens",
    "traillii",
    "alnorum"
  ],
  "Empidonomus": [
    "varius"
  ],
  "Ensifera": [
    "ensifera"
  ],
  "Epinecrophylla": [
    "haematonota",
    "ornata",
    "spodionota",
    "erythrura",
    "fulviventris"
  ],
  "Eremophila": [
    "alpestris"
  ],
  "Eriocnemis": [
    "mosquera",
    "cupreoventris",
    "aline",
    "mirabilis",
    "vestita",
    "luciani",
    "derbyi"
  ],
  "Eubucco": [
    "bourcierii",
    "richardsoni"
  ],
  "Euchrepomis": [
    "humeralis"
  ],
  "Eucometis": [
    "penicillata"
  ],
  "Eudocimus": [
    "ruber",
    "albus"
  ],
  "Euphonia": [
    "cyanocephala",
    "saturata",
    "chlorotica",
    "minuta",
    "xanthogaster",
    "mesochrysa",
    "trinitatis",
    "concinna",
    "laniirostris",
    "fulvicrissa",
    "plumbea",
    "chrysopasta",
    "rufiventris",
    "anneae"
  ],
  "Eurypyga": [
    "helias"
  ],
  "Euscarthmus": [
    "meloryphus"
  ],
  "Eutoxeres": [
    "aquila",
    "condamini"
  ],
  "Falco": [
    "deiroleucus",
    "femoralis",
    "sparverius",
    "columbarius",
    "rufigularis",
    "peregrinus"
  ],
  "Florisuga": [
    "mellivora"
  ],
  "Fluvicola": [
    "nengeta",
    "pica"
  ],
  "Formicarius": [
    "colma",
    "nigricapillus",
    "rufipectus",
    "analis"
  ],
  "Formicivora": [
    "grisea"
  ],
  "Forpus": [
    "passerinus",
    "xanthopterygius",
    "conspicillatus",
    "modestus"
  ],
  "Frederickena": [
    "unduliger"
  ],
  "Fregata": [
    "magnificens"
  ],
  "Fulica": [
    "americana"
  ],
  "Furnarius": [
    "leucopus",
    "minor",
    "torridus"
  ],
  "Galbalcyrhynchus": [
    "leucotis"
  ],
  "Galbula": [
    "ruficauda",
    "albirostris",
    "chalcothorax",
    "cyanescens",
    "dea",
    "tombacea",
    "leucogastra",
    "galbula",
    "pastazae"
  ],
  "Gallinago": [
    "delicata",
    "jamesoni",
    "undulata",
    "nobilis",
    "paraguaiae"
  ],
  "Gampsonyx": [
    "swainsonii"
  ],
  "Geothlypis": [
    "philadelphia",
    "trichas",
    "semiflava",
    "formosa",
    "aequinoctialis"
  ],
  "Geotrygon": [
    "violacea",
    "montana",
    "purpurata",
    "saphirina"
  ],
  "Geranospiza": [
    "caerulescens"
  ],
  "Glaucidium": [
    "nubicola",
    "griseiceps",
    "jardinii",
    "brasilianum"
  ],
  "Glaucis": [
    "hirsutus",
    "aeneus"
  ],
  "Glyphorynchus": [
    "spirurus"
  ],
  "Goethalsia": [
    "bella"
  ],
  "Goldmania": [
    "violiceps"
  ],
  "Grallaria": [
    "kaestneri",
    "nuchalis",
    "ruficapilla",
    "rufula",
    "flavotincta",
    "rufocinerea",
    "milleri",
    "guatimalensis",
    "squamigera",
    "dignissima",
    "gigantea",
    "quitensis",
    "alleni",
    "haplonota",
    "hypoleuca"
  ],
  "Grallaricula": [
    "cucullata",
    "lineifrons",
    "flavirostris",
    "nana",
    "ferrugineipectus"
  ],
  "Granatellus": [
    "pelzelni"
  ],
  "Graydidascalus": [
    "brachyurus"
  ],
  "Gymnocichla": [
    "nudiceps"
  ],
  "Gymnoderus": [
    "foetidus"
  ],
  "Gymnomystax": [
    "mexicanus"
  ],
  "Gymnopithys": [
    "leucaspis"
  ],
  "Habia": [
    "rubica",
    "gutturalis",
    "fuscicauda",
    "cristata"
  ],
  "Haematopus": [
    "palliatus"
  ],
  "Hafferia": [
    "immaculata",
    "fortis",
    "zeledoni"
  ],
  "Hapalopsittaca": [
    "amazonina",
    "fuertesi"
  ],
  "Hapaloptila": [
    "castanea"
  ],
  "Haplophaedia": [
    "aureliae",
    "lugens"
  ],
  "Harpagus": [
    "bidentatus"
  ],
  "Harpia": [
    "harpyja"
  ],
  "Heliangelus": [
    "strophianus",
    "exortis",
    "mavors"
  ],
  "Helicolestes": [
    "hamatus"
  ],
  "Heliodoxa": [
    "schreibersii",
    "rubinoides",
    "leadbeateri",
    "gularis",
    "imperatrix",
    "aurescens",
    "jacula"
  ],
  "Heliomaster": [
    "longirostris"
  ],
  "Heliornis": [
    "fulica"
  ],
  "Heliothryx": [
    "auritus",
    "barroti"
  ],
  "Hellmayrea": [
    "gularis"
  ],
  "Helmitheros": [
    "vermivorum"
  ],
  "Hemithraupis": [
    "guira",
    "flavicollis"
  ],
  "Hemitriccus": [
    "striaticollis",
    "iohannis",
    "granadensis",
    "zosterops",
    "margaritaceiventer"
  ],
  "Henicorhina": [
    "leucosticta",
    "anachoreta",
    "negreti",
    "leucophrys"
  ],
  "Herpetotheres": [
    "cachinnans"
  ],
  "Herpsilochmus": [
    "axillaris",
    "dorsimaculatus",
    "dugandi"
  ],
  "Heterocercus": [
    "flavivertex"
  ],
  "Heterospingus": [
    "xanthopygius"
  ],
  "Hirundinea": [
    "ferruginea"
  ],
  "Hirundo": [
    "rustica"
  ],
  "Hydroprogne": [
    "caspia"
  ],
  "Hydropsalis": [
    "climacocerca"
  ],
  "Hylexetastes": [
    "stresemanni"
  ],
  "Hylocichla": [
    "mustelina"
  ],
  "Hylomanes": [
    "momotula"
  ],
  "Hylopezus": [
    "perspicillatus",
    "dives",
    "fulviventris"
  ],
  "Hylophilus": [
    "flavipes",
    "semicinereus",
    "brunneiceps"
  ],
  "Hylophylax": [
    "punctulatus",
    "naevioides",
    "naevius"
  ],
  "Hypnelus": [
    "ruficollis"
  ],
  "Hypocnemis": [
    "flavescens",
    "peruviana",
    "hypoxantha"
  ],
  "Hypocnemoides": [
    "melanopogon"
  ],
  "Hypopyrrhus": [
    "pyrohypogaster"
  ],
  "Ibycter": [
    "americanus"
  ],
  "Icterus": [
    "mesomelas",
    "galbula",
    "croconotus",
    "icterus",
    "chrysater",
    "nigrogularis",
    "auricapillus",
    "spurius"
  ],
  "Ictinia": [
    "mississippiensis",
    "plumbea"
  ],
  "Inezia": [
    "tenuirostris",
    "caudata",
    "subflava"
  ],
  "Iodopleura": [
    "isabellae"
  ],
  "Iridophanes": [
    "pulcherrimus"
  ],
  "Iridosornis": [
    "analis",
    "porphyrocephalus",
    "rufivertex"
  ],
  "Isleria": [
    "hauxwelli"
  ],
  "Ixobrychus": [
    "exilis",
    "involucris"
  ],
  "Jabiru": [
    "mycteria"
  ],
  "Jacamerops": [
    "aureus"
  ],
  "Jacana": [
    "jacana"
  ],
  "Klais": [
    "guimeti"
  ],
  "Kleinothraupis": [
    "atropileus"
  ],
  "Knipolegus": [
    "poecilurus",
    "orenocensis",
    "poecilocercus"
  ],
  "Lafresnaya": [
    "lafresnayi"
  ],
  "Lampropsar": [
    "tanagrinus"
  ],
  "Lanio": [
    "fulvus"
  ],
  "Laniocera": [
    "rufescens",
    "hypopyrra"
  ],
  "Laterallus": [
    "albigularis",
    "melanophaius",
    "exilis"
  ],
  "Lathrotriccus": [
    "euleri"
  ],
  "Legatus": [
    "leucophaius"
  ],
  "Leiothlypis": [
    "peregrina"
  ],
  "Lepidocolaptes": [
    "duidae",
    "souleyetii",
    "lacrymiger"
  ],
  "Lepidothrix": [
    "coronata",
    "isidorei"
  ],
  "Leptasthenura": [
    "andicola"
  ],
  "Leptodon": [
    "cayanensis"
  ],
  "Leptopogon": [
    "superciliaris",
    "rufipectus",
    "amaurocephalus"
  ],
  "Leptosittaca": [
    "branickii"
  ],
  "Leptotila": [
    "conoveri",
    "plumbeiceps",
    "rufaxilla",
    "pallida"
  ],
  "Leptotrygon": [
    "veraguensis"
  ],
  "Lesbia": [
    "nuna",
    "victoriae"
  ],
  "Leucippus": [
    "fallax",
    "chlorocercus"
  ],
  "Leucopternis": [
    "semiplumbeus",
    "melanops"
  ],
  "Limnodromus": [
    "griseus"
  ],
  "Limosa": [
    "haemastica"
  ],
  "Liosceles": [
    "thoracicus"
  ],
  "Lipaugus": [
    "unirufus",
    "fuscocinereus",
    "weberi",
    "vociferans"
  ],
  "Lochmias": [
    "nematura"
  ],
  "Lonchura": [
    "malacca"
  ],
  "Lophornis": [
    "delattrei",
    "stictolophus"
  ],
  "Lophostrix": [
    "cristata"
  ],
  "Lophotriccus": [
    "vitiosus",
    "pileatus",
    "galeatus"
  ],
  "Lurocalis": [
    "rufiventris",
    "semitorquatus"
  ],
  "Machaeropterus": [
    "deliciosus"
  ],
  "Machetornis": [
    "rixosa"
  ],
  "Macroagelaius": [
    "subalaris"
  ],
  "Malacoptila": [
    "mystacalis",
    "panamensis",
    "fulvogularis",
    "fusca"
  ],
  "Manacus": [
    "manacus"
  ],
  "Margarornis": [
    "bellulus",
    "squamiger",
    "stellatus"
  ],
  "Masius": [
    "chrysopterus"
  ],
  "Mecocerculus": [
    "stictopterus",
    "poecilocercus",
    "minor"
  ],
  "Megaceryle": [
    "alcyon",
    "torquata"
  ],
  "Megarynchus": [
    "pitangua"
  ],
  "Megascops": [
    "ingens",
    "petersoni",
    "albogularis",
    "choliba",
    "watsonii",
    "colombianus"
  ],
  "Megastictus": [
    "margaritatus"
  ],
  "Melanerpes": [
    "pulcher",
    "cruentatus",
    "pucherani",
    "formicivorus",
    "rubricapillus"
  ],
  "Merganetta": [
    "armata"
  ],
  "Mesembrinibis": [
    "cayennensis"
  ],
  "Metallura": [
    "tyrianthina",
    "williami"
  ],
  "Metopothrix": [
    "aurantiaca"
  ],
  "Micrastur": [
    "plumbeus",
    "semitorquatus",
    "mirandollei",
    "ruficollis",
    "gilvicollis",
    "buckleyi"
  ],
  "Microbates": [
    "cinereiventris",
    "collaris"
  ],
  "Microcerculus": [
    "marginatus"
  ],
  "Micromonacha": [
    "lanceolata"
  ],
  "Micropygia": [
    "schomburgkii"
  ],
  "Microrhopias": [
    "quixensis"
  ],
  "Milvago": [
    "chimachima"
  ],
  "Mimus": [
    "gilvus"
  ],
  "Mionectes": [
    "striaticollis",
    "oleagineus"
  ],
  "Mitrephanes": [
    "phaeocercus"
  ],
  "Mitrospingus": [
    "cassinii"
  ],
  "Mitu": [
    "salvini",
    "tomentosum",
    "tuberosum"
  ],
  "Mniotilta": [
    "varia"
  ],
  "Molothrus": [
    "oryzivorus",
    "bonariensis"
  ],
  "Momotus": [
    "aequatorialis",
    "subrufescens",
    "momota"
  ],
  "Monasa": [
    "nigrifrons",
    "morphoeus",
    "atra",
    "flavirostris"
  ],
  "Morphnarchus": [
    "princeps"
  ],
  "Morphnus": [
    "guianensis"
  ],
  "Muscisaxicola": [
    "alpinus",
    "albilora",
    "maculirostris"
  ],
  "Myadestes": [
    "coloratus",
    "ralloides"
  ],
  "Mycteria": [
    "americana"
  ],
  "Myiarchus": [
    "crinitus",
    "venezuelensis",
    "panamensis",
    "tuberculifer",
    "ferox",
    "cephalotes",
    "swainsoni",
    "tyrannulus",
    "apicalis"
  ],
  "Myiobius": [
    "atricaudus",
    "barbatus",
    "villosus"
  ],
  "Myioborus": [
    "miniatus",
    "ornatus",
    "melanocephalus",
    "flavivertex"
  ],
  "Myiodynastes": [
    "maculatus",
    "luteiventris"
  ],
  "Myiopagis": [
    "viridicata",
    "gaimardii"
  ],
  "Myiophobus": [
    "flavicans",
    "phoenicomitra",
    "fasciatus"
  ],
  "Myiornis": [
    "atricapillus",
    "ecaudatus"
  ],
  "Myiotheretes": [
    "striaticollis",
    "fumigatus",
    "pernix"
  ],
  "Myiothlypis": [
    "basilica",
    "luteoviridis",
    "coronata",
    "flaveola",
    "nigrocristata",
    "cinereicollis",
    "fulvicauda"
  ],
  "Myiotriccus": [
    "ornatus"
  ],
  "Myiozetetes": [
    "similis",
    "granadensis",
    "cayanensis",
    "luteiventris"
  ],
  "Myornis": [
    "senilis"
  ],
  "Myrmeciza": [
    "longipes"
  ],
  "Myrmelastes": [
    "hyperythrus",
    "schistaceus"
  ],
  "Myrmoborus": [
    "myotherinus",
    "leucophrys",
    "lugubris"
  ],
  "Myrmochanes": [
    "hemileucus"
  ],
  "Myrmornis": [
    "torquata"
  ],
  "Myrmothera": [
    "campanisona"
  ],
  "Myrmotherula": [
    "multostriata",
    "longicauda",
    "cherriei",
    "behni",
    "ignota",
    "longipennis",
    "ambigua",
    "surinamensis",
    "pacifica",
    "menetriesii",
    "schisticolor",
    "brachyura",
    "axillaris",
    "assimilis",
    "sunensis"
  ],
  "Nasica": [
    "longirostris"
  ],
  "Nemosia": [
    "pileata"
  ],
  "Neoctantes": [
    "niger"
  ],
  "Neomorphus": [
    "radiolosus",
    "geoffroyi",
    "rufipennis"
  ],
  "Neopelma": [
    "chrysocephalum"
  ],
  "Neopipo": [
    "cinnamomea"
  ],
  "Nephelomyias": [
    "pulcher"
  ],
  "Netta": [
    "erythrophthalma"
  ],
  "Nomonyx": [
    "dominicus"
  ],
  "Nonnula": [
    "frontalis",
    "brunnea",
    "rubecula"
  ],
  "Notharchus": [
    "pectoralis",
    "tectus",
    "ordii",
    "hyperrhynchus"
  ],
  "Nothocercus": [
    "bonapartei"
  ],
  "Nothocrax": [
    "urumutum"
  ],
  "Numenius": [
    "phaeopus"
  ],
  "Nyctibius": [
    "grandis",
    "maculosus",
    "aethereus",
    "griseus"
  ],
  "Nycticorax": [
    "nycticorax"
  ],
  "Nyctidromus": [
    "albicollis"
  ],
  "Nyctiphrynus": [
    "rosenbergi",
    "ocellatus"
  ],
  "Nyctiprogne": [
    "leucopyga"
  ],
  "Nystalus": [
    "radiatus"
  ],
  "Ochthoeca": [
    "cinnamomeiventris",
    "rufipectoralis",
    "fumicolor"
  ],
  "Ochthornis": [
    "littoralis"
  ],
  "Ocreatus": [
    "underwoodii"
  ],
  "Odontophorus": [
    "atrifrons",
    "gujanensis",
    "strophium",
    "hyperythrus",
    "melanonotus",
    "erythrops",
    "speciosus"
  ],
  "Odontorchilus": [
    "branickii"
  ],
  "Ognorhynchus": [
    "icterotis"
  ],
  "Onychoprion": [
    "anaethetus"
  ],
  "Onychorhynchus": [
    "coronatus"
  ],
  "Opisthocomus": [
    "hoazin"
  ],
  "Opisthoprora": [
    "euryptera"
  ],
  "Oporornis": [
    "agilis"
  ],
  "Oreothraupis": [
    "arremonops"
  ],
  "Oreotrochilus": [
    "chimborazo"
  ],
  "Ornithion": [
    "brunneicapillus",
    "inerme"
  ],
  "Orochelidon": [
    "murina",
    "flavipes"
  ],
  "Ortalis": [
    "ruficauda",
    "erythroptera",
    "guttata",
    "cinereiceps",
    "motmot",
    "garrula"
  ],
  "Oxypogon": [
    "guerinii",
    "cyanolaemus"
  ],
  "Oxyruncus": [
    "cristatus"
  ],
  "Pachyramphus": [
    "albogriseus",
    "cinnamomeus",
    "polychopterus",
    "homochrous",
    "rufus",
    "versicolor",
    "minor",
    "castaneus",
    "marginatus"
  ],
  "Pachysylvia": [
    "hypoxantha",
    "decurtata",
    "aurantiifrons",
    "semibrunnea"
  ],
  "Pandion": [
    "haliaetus"
  ],
  "Panyptila": [
    "cayennensis"
  ],
  "Parabuteo": [
    "leucorrhous",
    "unicinctus"
  ],
  "Pardirallus": [
    "nigricans",
    "maculatus"
  ],
  "Parkerthraustes": [
    "humeralis"
  ],
  "Parkesia": [
    "motacilla"
  ],
  "Paroaria": [
    "gularis",
    "nigrogenis"
  ],
  "Passer": [
    "domesticus"
  ],
  "Passerina": [
    "cyanea"
  ],
  "Patagioenas": [
    "goodsoni",
    "cayennensis",
    "speciosa",
    "corensis",
    "subvinacea",
    "nigrirostris",
    "plumbea",
    "leucocephala"
  ],
  "Patagona": [
    "gigas"
  ],
  "Pauxi": [
    "pauxi"
  ],
  "Pelecanus": [
    "occidentalis"
  ],
  "Penelope": [
    "jacquacu",
    "ortoni",
    "montagnii",
    "purpurascens",
    "argyrotis",
    "perspicax"
  ],
  "Percnostola": [
    "rufifrons"
  ],
  "Perissocephalus": [
    "tricolor"
  ],
  "Petrochelidon": [
    "pyrrhonota"
  ],
  "Phaenostictus": [
    "mcleannani"
  ],
  "Phaeomyias": [
    "murina"
  ],
  "Phaethon": [
    "aethereus"
  ],
  "Phaethornis": [
    "syrmatophorus",
    "malaris",
    "griseogularis",
    "longirostris",
    "hispidus",
    "atrimentalis",
    "guy",
    "anthophilus",
    "ruber",
    "striigularis",
    "yaruqui",
    "augusti",
    "bourcieri",
    "rupurumii"
  ],
  "Phaetusa": [
    "simplex"
  ],
  "Phalaropus": [
    "lobatus"
  ],
  "Phalcoboenus": [
    "carunculatus"
  ],
  "Pharomachrus": [
    "auriceps",
    "antisianus",
    "pavoninus",
    "fulgidus"
  ],
  "Phelpsia": [
    "inornata"
  ],
  "Pheucticus": [
    "ludovicianus",
    "chrysogaster",
    "aureoventris"
  ],
  "Pheugopedius": [
    "euophrys",
    "spadix",
    "rutilus",
    "mystacalis",
    "fasciatoventris",
    "coraya"
  ],
  "Philydor": [
    "erythropterum",
    "erythrocercum",
    "fuscipenne",
    "rufum",
    "pyrrhodes"
  ],
  "Phimosus": [
    "infuscatus"
  ],
  "Phlegopsis": [
    "erythroptera",
    "nigromaculata"
  ],
  "Phlogophilus": [
    "hemileucurus"
  ],
  "Phoenicircus": [
    "nigricollis"
  ],
  "Phoenicopterus": [
    "ruber"
  ],
  "Phyllomyias": [
    "griseiceps",
    "uropygialis",
    "nigrocapillus",
    "plumbeiceps",
    "cinereiceps"
  ],
  "Phylloscartes": [
    "superciliaris",
    "gualaquizae"
  ],
  "Piaya": [
    "cayana",
    "melanogaster"
  ],
  "Piculus": [
    "leucolaemus",
    "flavigula",
    "chrysochloros"
  ],
  "Picumnus": [
    "rufiventris",
    "pumilus",
    "granadensis",
    "exilis",
    "squamulatus",
    "lafresnayi",
    "castelnau",
    "cinnamomeus"
  ],
  "Pilherodius": [
    "pileatus"
  ],
  "Pionites": [
    "melanocephalus"
  ],
  "Pionus": [
    "chalcopterus",
    "menstruus",
    "sordidus",
    "fuscus"
  ],
  "Pipra": [
    "filicauda"
  ],
  "Pipraeidea": [
    "melanonota"
  ],
  "Pipreola": [
    "jucunda",
    "chlorolepidota",
    "riefferii",
    "aureopectus",
    "lubomirskii",
    "arcuata"
  ],
  "Piprites": [
    "chloris"
  ],
  "Piranga": [
    "rubriceps",
    "rubra",
    "olivacea",
    "leucoptera"
  ],
  "Pitangus": [
    "sulphuratus"
  ],
  "Pithys": [
    "albifrons"
  ],
  "Pittasoma": [
    "rufopileatum",
    "michleri"
  ],
  "Platalea": [
    "ajaja"
  ],
  "Platyrinchus": [
    "platyrhynchos",
    "flavigularis",
    "saturatus",
    "coronatus"
  ],
  "Plegadis": [
    "falcinellus"
  ],
  "Pluvialis": [
    "squatarola",
    "dominica"
  ],
  "Podilymbus": [
    "podiceps"
  ],
  "Poecilotriccus": [
    "ruficeps",
    "sylvia",
    "latirostris",
    "capitalis",
    "calopterus"
  ],
  "Poliocrania": [
    "exsul"
  ],
  "Polioptila": [
    "plumbea",
    "schistaceigula",
    "guianensis"
  ],
  "Polystictus": [
    "pectoralis"
  ],
  "Polytmus": [
    "guainumbi",
    "theresiae"
  ],
  "Porphyrio": [
    "flavirostris"
  ],
  "Porphyrolaema": [
    "porphyrolaema"
  ],
  "Porzana": [
    "carolina"
  ],
  "Premnoplex": [
    "brunnescens"
  ],
  "Premnornis": [
    "guttuliger"
  ],
  "Procnias": [
    "averano"
  ],
  "Progne": [
    "tapera",
    "subis",
    "chalybea",
    "elegans"
  ],
  "Protonotaria": [
    "citrea"
  ],
  "Psarocolius": [
    "guatimozinus",
    "viridis",
    "decumanus",
    "angustifrons",
    "wagleri",
    "cassini"
  ],
  "Pseudocolopteryx": [
    "acutipennis"
  ],
  "Pseudospingus": [
    "verticalis"
  ],
  "Pseudotriccus": [
    "ruficeps",
    "pelzelni"
  ],
  "Psittacara": [
    "wagleri"
  ],
  "Psophia": [
    "crepitans"
  ],
  "Pteroglossus": [
    "azara",
    "torquatus",
    "castanotis",
    "pluricinctus"
  ],
  "Pterophanes": [
    "cyanopterus"
  ],
  "Pulsatrix": [
    "melanota",
    "perspicillata"
  ],
  "Pygiptila": [
    "stellaris"
  ],
  "Pyriglena": [
    "leuconota"
  ],
  "Pyrilia": [
    "pulchra",
    "pyrilia",
    "barrabandi",
    "haematotis"
  ],
  "Pyrocephalus": [
    "rubinus"
  ],
  "Pyroderus": [
    "scutatus"
  ],
  "Pyrrhomyias": [
    "cinnamomeus"
  ],
  "Pyrrhura": [
    "melanura",
    "calliptera"
  ],
  "Querula": [
    "purpurata"
  ],
  "Quiscalus": [
    "mexicanus",
    "lugubris"
  ],
  "Rallus": [
    "semiplumbeus",
    "longirostris"
  ],
  "Ramphastos": [
    "vitellinus",
    "ambiguus",
    "brevis",
    "sulfuratus"
  ],
  "Ramphocaenus": [
    "melanurus"
  ],
  "Ramphocelus": [
    "flammigerus",
    "carbo",
    "nigrogularis",
    "dimidiatus"
  ],
  "Ramphomicron": [
    "microrhynchum",
    "dorsale"
  ],
  "Ramphotrigon": [
    "megacephalum",
    "ruficauda",
    "fuscicauda"
  ],
  "Rhegmatorhina": [
    "melanosticta",
    "cristata"
  ],
  "Rhodinocichla": [
    "rosea"
  ],
  "Rhynchocyclus": [
    "pacificus",
    "brevirostris",
    "fulvipectus"
  ],
  "Rhynchortyx": [
    "cinctus"
  ],
  "Rhytipterna": [
    "immunda",
    "holerythra",
    "simplex"
  ],
  "Riparia": [
    "riparia"
  ],
  "Rostrhamus": [
    "sociabilis"
  ],
  "Rupicola": [
    "peruvianus",
    "rupicola"
  ],
  "Rupornis": [
    "magnirostris"
  ],
  "Rynchops": [
    "niger"
  ],
  "Sakesphorus": [
    "canadensis"
  ],
  "Saltator": [
    "cinctus",
    "maximus",
    "striatipectus",
    "grossus",
    "coerulescens",
    "orenocensis",
    "atripennis"
  ],
  "Sapayoa": [
    "aenigma"
  ],
  "Sarcoramphus": [
    "papa"
  ],
  "Satrapa": [
    "icterophrys"
  ],
  "Sayornis": [
    "nigricans"
  ],
  "Schiffornis": [
    "stenorhyncha",
    "major",
    "turdina",
    "veraepacis"
  ],
  "Schistes": [
    "geoffroyi"
  ],
  "Schistochlamys": [
    "melanopis"
  ],
  "Sclerurus": [
    "rufigularis",
    "mexicanus",
    "albigularis",
    "caudacutus",
    "guatemalensis"
  ],
  "Scytalopus": [
    "spillmanni",
    "panamensis",
    "stilesi",
    "latebricola",
    "rodriguezi",
    "opacus",
    "micropterus",
    "vicinior",
    "griseicollis",
    "atratus",
    "perijanus",
    "canus",
    "chocoensis"
  ],
  "Seiurus": [
    "aurocapilla"
  ],
  "Selenidera": [
    "spectabilis",
    "nattereri",
    "reinwardtii"
  ],
  "Semnornis": [
    "ramphastinus"
  ],
  "Sericossypha": [
    "albocristata"
  ],
  "Serpophaga": [
    "hypoleuca",
    "cinerea"
  ],
  "Setophaga": [
    "fusca",
    "pitiayumi",
    "cerulea",
    "coronata",
    "citrina",
    "palmarum",
    "striata",
    "virens",
    "magnolia",
    "caerulescens",
    "ruticilla",
    "pensylvanica",
    "americana",
    "tigrina",
    "petechia",
    "castanea"
  ],
  "Sicalis": [
    "flaveola",
    "citrina",
    "columbiana",
    "luteola"
  ],
  "Sipia": [
    "laemosticta",
    "palliata",
    "berlepschi",
    "nigricauda"
  ],
  "Sirystes": [
    "albogriseus",
    "albocinereus"
  ],
  "Sittasomus": [
    "griseicapillus"
  ],
  "Snowornis": [
    "cryptolophus"
  ],
  "Sphenopsis": [
    "melanotis",
    "frontalis"
  ],
  "Sphyrapicus": [
    "varius"
  ],
  "Spinus": [
    "spinescens",
    "xanthogastrus",
    "psaltria",
    "magellanicus"
  ],
  "Spiza": [
    "americana"
  ],
  "Spizaetus": [
    "melanoleucus",
    "tyrannus",
    "isidori",
    "ornatus"
  ],
  "Spodiornis": [
    "rusticus"
  ],
  "Sporophila": [
    "minuta",
    "castaneiventris",
    "funerea",
    "bouvronides",
    "fringilloides",
    "schistacea",
    "plumbea",
    "caerulescens",
    "nigricollis",
    "telasco",
    "murallae",
    "lineola",
    "intermedia"
  ],
  "Steatornis": [
    "caripensis"
  ],
  "Stelgidopteryx": [
    "ruficollis"
  ],
  "Stercorarius": [
    "pomarinus"
  ],
  "Sterna": [
    "forsteri",
    "hirundo"
  ],
  "Sternoclyta": [
    "cyanopectus"
  ],
  "Sternula": [
    "antillarum",
    "superciliaris"
  ],
  "Stigmatura": [
    "napensis"
  ],
  "Streptoprocne": [
    "zonaris",
    "rutila"
  ],
  "Sturnella": [
    "magna"
  ],
  "Sublegatus": [
    "arenarum",
    "obscurior"
  ],
  "Sula": [
    "dactylatra",
    "sula",
    "granti",
    "variegata",
    "nebouxii",
    "leucogaster"
  ],
  "Synallaxis": [
    "azarae",
    "brachyura",
    "candei",
    "subpudica",
    "gujanensis",
    "rutilans",
    "beverlyae",
    "fuscorufa",
    "moesta",
    "albescens",
    "albigularis",
    "unirufa",
    "cinnamomea",
    "cherriei"
  ],
  "Syndactyla": [
    "subalaris"
  ],
  "Syrigma": [
    "sibilatrix"
  ],
  "Tachornis": [
    "squamata",
    "furcata"
  ],
  "Tachybaptus": [
    "dominicus"
  ],
  "Tachycineta": [
    "albiventer",
    "bicolor"
  ],
  "Tachyphonus": [
    "phoenicius",
    "rufus"
  ],
  "Tangara": [
    "nigroviridis",
    "schrankii",
    "vitriolina",
    "ruficervix",
    "xanthocephala",
    "chrysotis",
    "johannae",
    "cyanotis",
    "fucosa",
    "vassorii",
    "velia",
    "callophrys",
    "icterocephala",
    "parzudakii",
    "labradorides",
    "cyanicollis",
    "cayana",
    "inornata",
    "chilensis",
    "mexicana",
    "gyrola",
    "heinei",
    "palmeri",
    "nigrocincta",
    "lavinia",
    "florida",
    "larvata"
  ],
  "Tapera": [
    "naevia"
  ],
  "Taphrospilus": [
    "hypostictus"
  ],
  "Taraba": [
    "major"
  ],
  "Terenotriccus": [
    "erythrurus"
  ],
  "Tersina": [
    "viridis"
  ],
  "Thalasseus": [
    "elegans",
    "sandvicensis"
  ],
  "Thalurania": [
    "colombica",
    "furcata"
  ],
  "Thamnistes": [
    "anabatinus"
  ],
  "Thamnomanes": [
    "caesius",
    "ardesiacus"
  ],
  "Thamnophilus": [
    "atrinucha",
    "multistriatus",
    "nigriceps",
    "amazonicus",
    "tenuepunctatus",
    "melanonotus",
    "aethiops",
    "doliatus",
    "murinus",
    "punctatus",
    "nigrocinereus",
    "unicolor",
    "schistaceus",
    "cryptoleucus"
  ],
  "Theristicus": [
    "caudatus"
  ],
  "Thlypopsis": [
    "superciliaris",
    "ornata",
    "fulviceps",
    "sordida"
  ],
  "Threnetes": [
    "ruckeri",
    "leucurus"
  ],
  "Thripadectes": [
    "flammulatus",
    "holostictus",
    "melanorhynchus"
  ],
  "Thryophilus": [
    "nicefori",
    "sernai",
    "rufalbus"
  ],
  "Tiaris": [
    "olivaceus"
  ],
  "Tigrisoma": [
    "fasciatum",
    "mexicanum",
    "lineatum"
  ],
  "Tinamus": [
    "major",
    "osgoodi",
    "guttatus"
  ],
  "Tityra": [
    "semifasciata",
    "cayana",
    "inquisitor"
  ],
  "Todirostrum": [
    "nigriceps",
    "maculatum",
    "pictum",
    "cinereum",
    "chrysocrotaphum"
  ],
  "Tolmomyias": [
    "sulphurescens",
    "flaviventris",
    "traylori",
    "poliocephalus",
    "assimilis"
  ],
  "Topaza": [
    "pyra"
  ],
  "Touit": [
    "dilectissimus",
    "stictopterus",
    "purpuratus",
    "batavicus",
    "huetii"
  ],
  "Tringa": [
    "incana",
    "melanoleuca",
    "flavipes",
    "solitaria"
  ],
  "Troglodytes": [
    "aedon",
    "monticola",
    "solstitialis"
  ],
  "Trogon": [
    "massena",
    "collaris",
    "rufus",
    "curucui",
    "viridis",
    "chionurus",
    "personatus",
    "comptus"
  ],
  "Turdus": [
    "flavipes",
    "leucops",
    "fumigatus",
    "fuscater",
    "grayi",
    "hauxwelli",
    "ignobilis",
    "leucomelas",
    "albicollis",
    "fulviventris",
    "sanchezorum",
    "nudigenis",
    "olivater",
    "obsoletus",
    "serranus",
    "lawrencii"
  ],
  "Tyranneutes": [
    "stolzmanni"
  ],
  "Tyrannopsis": [
    "sulphurea"
  ],
  "Tyrannulus": [
    "elatus"
  ],
  "Tyrannus": [
    "dominicensis",
    "albogularis",
    "melancholicus",
    "tyrannus",
    "savana",
    "niveigularis"
  ],
  "Tyto": [
    "alba"
  ],
  "Urochroa": [
    "bougueri"
  ],
  "Uropsalis": [
    "lyra",
    "segmentata"
  ],
  "Urosticte": [
    "benjamini"
  ],
  "Urothraupis": [
    "stolzmanni"
  ],
  "Vanellus": [
    "chilensis",
    "resplendens"
  ],
  "Veniliornis": [
    "affinis",
    "nigriceps",
    "dignus",
    "passerinus",
    "kirkii"
  ],
  "Vermivora": [
    "chrysoptera"
  ],
  "Vireo": [
    "flavifrons",
    "flavoviridis",
    "masteri",
    "altiloquus",
    "leucophrys",
    "olivaceus"
  ],
  "Vireolanius": [
    "eximius",
    "leucotis"
  ],
  "Volatinia": [
    "jacarina"
  ],
  "Vultur": [
    "gryphus"
  ],
  "Willisornis": [
    "poecilinotus"
  ],
  "Xema": [
    "sabini"
  ],
  "Xenerpestes": [
    "minlosi"
  ],
  "Xenopipo": [
    "atronitens"
  ],
  "Xenops": [
    "tenuirostris"
  ],
  "Xenornis": [
    "setifrons"
  ],
  "Xiphocolaptes": [
    "promeropirhynchus"
  ],
  "Xipholena": [
    "punicea"
  ],
  "Xiphorhynchus": [
    "lachrymosus",
    "elegans",
    "obsoletus",
    "susurrans",
    "triangularis",
    "guttatus",
    "ocellatus"
  ],
  "Zebrilus": [
    "undulatus"
  ],
  "Zenaida": [
    "asiatica",
    "auriculata"
  ],
  "Zentrygon": [
    "frenata",
    "goldmani",
    "linearis"
  ],
  "Zimmerius": [
    "gracilipes",
    "chrysops"
  ],
  "Zonotrichia": [
    "capensis"
  ]
};
//resumen es la FeatureCollection que contiene todas las areas calculadas 
var resumen = ee.FeatureCollection("projects/ee-biomodelos-gee4geo/assets/tabla_areas_por_sp");
//years son los años que se modelaron
var years = ['2000', '2001',
'2002', '2003',
'2004', '2005',
'2006', '2007',
'2008', '2009',
'2010', '2011',
'2012', '2013',
'2014', '2015',
'2016', '2017',
'2018', '2019',
'2020'];
// variables vacias para ejecutar
var timeout = null;
var play = false;
//imagen que se usa para poner los logos de los apoyos en la app, (debe ser una imagen georeferenciada y estar en los assets)
var logo = ee.Image("projects/ee-biomodelos-gee4geo/assets/biomodelos_anuales/inputs/logosv3");
//branding convierte esa imagen de logos en un thumbnail par apoderla desplegar en la APP
//ver imagen app1
var branding = ui.Thumbnail({image:logo,params:{bands:['b1','b2','b3'],min:8,max:255, dimensions:1120},style:{width:'100%'}});
//panel 1 es el panel donde se ubicaran todas las herramientas, y oucpara el 30% de la pantalla
//ver imagen app1
var panel1 = ui.Panel({style: {width: '30%', padding:'15px'}}); //width es el porcentaje de ocupacion de la pantalla
//añadir un label de agradecimientos permanente
//ver imagen app9
var agradecimiento = ui.Label({
  value:'Apoyado por el Group on Earth Observations (GEO), \nGoogle Earth Engine (GEE) y EODataScience.',
  style:{whiteSpace: 'pre',
    fontWeight: '400',
    color: '#1c3337',
    fontSize: '14px',
    margin: '0 0 4px 12px'}
});
//mapPanel es el panel de vizualizacion de mapa, que por default qeremos que muestre el basemap "satellite"
//ver imagen app1
var mapPanel = ui.Map().setOptions('satellite');
//el cursor en el panel de mapa, que sea una cruz y no una flecha
mapPanel.style().set('cursor', 'crosshair');
//creamos labels (que son solo letreros) vacios que llenaremos despues
var algorit = ui.Label();
var presprob = ui.Label();
var presprob1 = ui.Label();
var presprob2 = ui.Label();
var presprob3 = ui.Label();
var presprob4 = ui.Label();
//etiqueta es un label y definimos el estilo de letra y margenes, pero esta vacia 
var etiqueta = ui.Label({style:{
      padding:'4px 4px 4px 10px ',
      fontSize:'17px',
      color:'#424242',
      textAlign:'left',
    }});
//panel2 es un panel vacio con estilo horizontal y centrado    
var panel2 = ui.Panel({
        layout: ui.Panel.Layout.flow('horizontal'),
        style: {
          position: "top-center"}
    });
//panel3 es un panel vacio con estilo horizontal y centrado     
var panel3 = ui.Panel({
        layout: ui.Panel.Layout.flow('horizontal'),
        style: {
          position: "top-center"}
    });
//panel4 es un panel vacio con estilo horizontal y centrado 
var panel4 = ui.Panel({
        layout: ui.Panel.Layout.flow('horizontal'),
        style: {
          position: "top-center"}
    });
//ingles es un checkbox para escoger idioma 
//ver imagen app1
var ingles = ui.Checkbox('English', false);
//cuando ingles se clickea va a hacer varias cosas
ingles.onChange(function(checked) {
  //limpiar el panel2
  panel2.clear();
  //limpiar el label etiqueta
  etiqueta.setValue(' ');
  //en el panel1 (general) crear 2 labels vacios y ponerlos en la poscicion 8 y 9
  panel1.widgets().set(8,ui.Label());
  panel1.widgets().set(9,ui.Label());
  //intro es un panel que contiene dos labels con el titulo de biomodelos,
  //y el segundo con la descripcion de la app
  //ver imagen app2
  var intro = ui.Panel([
      ui.Label({
        value: 'BioModelos: Multitemporal maps of available habitat of birds in Colombia',
        style: {fontSize: '18px', fontWeight: 'bold', color:'#db3f2a', margin: '0 0 10px'}
      }),
      ui.Label({
        value: 'Probabilistic and binary models for 1537 species of birds from the years 2000-2021, with a 250mts pixel.',
        style: {fontSize: '15px', margin: '0 0 7px', color:'#606060'}
      }),
      ui.Label({
        value: '1. Select a type of map (probabilistic/Suitability)(Potential habitat/Presence based on a threshold=10% ).',
        style: {fontSize: '14px',  margin: '0 0 2px'}
      }),
      ui.Label({
        value: '2. Explore a genus and the species.',
        style: {fontSize: '14px', margin: '0 0 2px'}
      }),
      ui.Label({
        value: '3. Choose an algorithm (Boosted Regression Tree -BRT-, Support Vector Machine -SVM-, Random Forest -RF-, Máxima entropía de Phillips -Maxent-).',
        style: {fontSize: '14px', margin: '0 0 2px'}
      })
    ], ui.Panel.Layout.flow('vertical'));
    //dentro del panel1 el panel intro ocupa la poscicion 3
    //ver imagen app2
    panel1.widgets().set(3,intro);
  //proba es otro checkbox para seleccionar el mapa probabilistico
  //ver imagen app2
  var proba = ui.Checkbox('Probabilistic', false);
  //los cambios que ocurran cuando se selccione proba
  proba.onChange(function(checked) {
    //colocar en el panel 2 etiquetas vacias en las posiciones 1 2 3 4 8 y 9 y limpiar eqtiqueta
    panel2.widgets().set(1, ui.Label());
    panel2.widgets().set(2, ui.Label());
    panel2.widgets().set(3, ui.Label());
    panel2.widgets().set(4, ui.Label());
    panel2.widgets().set(5, ui.Label());
    etiqueta.setValue(" ");
    panel1.widgets().set(8, ui.Label());
    panel1.widgets().set(9, ui.Label());
  //selectG es un menu para escoger genero
  // ver imagen app3
  var selectG = ui.Select({
        items: Object.keys(genero),
        style:{width:400, margin:'3px 3px 0 0'},
        placeholder:'Genus',
        //cuando se escoja una opcion de selectG
        onChange: function(keyG) {
          //escribir en etiqueta el genero escogido
          // ver imagen app3
          etiqueta.setValue(keyG+" ");
          //cosas busca la lista de epitetos que corresponde al genero escogido
          var cosas = epiteto[keyG];
          //quitar el menu selectF
          panel2.remove(selectf);  
          //colocar en el panel 2 etiquetas vacias en las posiciones 2 3 4 8 y 9 
          panel2.widgets().set(2,ui.Label());
          panel2.widgets().set(3,ui.Label());
          panel2.widgets().set(4,ui.Label());
          panel2.widgets().set(5,ui.Label());
          panel1.widgets().set(8,ui.Label());
          panel1.widgets().set(9,ui.Label());
          //selectf es un meno para escoger espiteto especifico
          //ver imagen app3
          var selectf = ui.Select({
                items: cosas,
                style:{width:400, margin:'3px 3px 0 0'},
                placeholder:'Specific name',
                onChange: function(keyE){
                  //escribir en etiqueta el epiteto escogido
                  // ver imagen app3
                  etiqueta.setValue(keyG+" "+keyE);
                  panel1.widgets().set(9,ui.Label());
                  //tomar el nombre de especie y modificarlo para buscar el area y los modelos
                  var sp = etiqueta.getValue()   ;
                  var sp_ =  sp.replace(' ', '_');
                  //Rf BRT y Maxent son checkboxes para escoger el algoritmo
                  var RF = ui.Checkbox('RF', false);
                  var BRT = ui.Checkbox('BRT', false);
                  var MaxEnt = ui.Checkbox('MaxEnt', false);
                  //cuando se selecciona alguno de esos checkboxes pasa lo siguiente
                  //ver imagen app4
                  RF.onChange(function(checked) {
                    algorit.setValue("RF");
                    //crear un label y usarlo de leyenda
                    //ver imagen app4
                    var legendTitle = ui.Label({
                      value: "Probability of "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    //crear un label de color para indicar baja probabilidad
                    //ver imagen app4
                    var colorBar = ui.Label({
                        value:'LOW',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f1c786',
                        textAlign:'right',
                        padding:'6px 0 0 0'
                        }});
                    //crear un label de color para indicar alta probabilidad
                    //ver imagen app4
                    var colorBar1 = ui.Label({
                        value:'HIGH',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f4565c',
                        textAlign:'center',
                        padding:'6px 0 0 0'
                        }});
                    //crear un panel que albergue todos los labels creados para leyenda
                    //ver imagen app4
                    var legendPanel = ui.Panel([colorBar,colorBar1, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    //llamar a la imagen correspondiente de la especie seleccionada
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    //funcion para escoger todas las bandas del algortimo seleccionado de la imagen seleccionada
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    //creacion de una image collection con las imagenes para mostrar
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      //limpiar el panel de mapa
                      mapPanel.clear();
                      //centrar el panel de mapa en la imagen a mostrar
                      //ver imagen app4
                      mapPanel.centerObject(modelo, 6);
                      //mostrar una animacion del cambio de area multianual
                      //ver imagen app4
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400});
                    //borrar todas las selcciones y dejar solo el algoritmo escogido
                    RF.setDisabled(true);
                    BRT.setValue(false, false);
                    BRT.setDisabled(false);
                    MaxEnt.setValue(false, false);
                    MaxEnt.setDisabled(false);
                  });
                  //BRT funciona igual que RF
                  BRT.onChange(function(checked) {
                    algorit.setValue("BRT");
                    var legendTitle = ui.Label({
                      value: "Probability of "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'LOW',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f1c786',
                        textAlign:'right',
                        padding:'6px 0 0 0'
                        }});
                    var colorBar1 = ui.Label({
                        value:'HIGH',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f4565c',
                        textAlign:'center',
                        padding:'6px 0 0 0'
                        }});
                    var legendPanel = ui.Panel([colorBar,colorBar1, legendTitle], ui.Panel.Layout.flow('horizontal'));                   
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400}); 
                    BRT.setDisabled(true);
                    RF.setValue(false, false);
                    RF.setDisabled(false);
                    MaxEnt.setValue(false, false);
                    MaxEnt.setDisabled(false);
                  });
                  //MaxEnt funciona igual que RF
                  MaxEnt.onChange(function(checked) {
                    algorit.setValue("MaxEnt");
                    var legendTitle = ui.Label({
                      value: "Probability of "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'LOW',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f1c786',
                        textAlign:'right',
                        padding:'6px 0 0 0'
                        }});
                    var colorBar1 = ui.Label({
                        value:'HIGH',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f4565c',
                        textAlign:'center',
                        padding:'6px 0 0 0'
                        }});
                    var legendPanel = ui.Panel([colorBar,colorBar1, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400});
                    MaxEnt.setDisabled(true);
                    RF.setValue(false, false);
                    RF.setDisabled(false);
                    BRT.setValue(false, false);
                    BRT.setDisabled(false);
                  });
                    //ubicar los checboxes de RF BRT y MaxEnt en las pocicisiones dentro del panel2
                    //ver imagen app5
                    panel2.widgets().set(2,RF);
                    panel2.widgets().set(3,BRT);
                    panel2.widgets().set(4,MaxEnt);
                  //tomar la informacion nescesaria para graficar el cambio de area
                  var grafico = resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(21,42,1))
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(42,63,1))
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(63,84,1))
                    .map(function (l){return ee.List(l).flatten()});
                  //crear el chart grafico que muestre los cambios de area
                  //ver imagen app5
                  var sstChart = ui.Chart.array.values({array: grafico, axis: 0, xLabels: years})
                    .setSeriesNames(['BRT','MaxEnt', 'RF', 'SVM'])
                    .setOptions({
                      title: 'Available habitat for '+sp+'\n',
                      hAxis: {title: 'Year',
                              titleTextStyle: {italic: true, bold: false}},
                      vAxis:  {title: 'Area Km2',
                              titleTextStyle: {italic: true, bold: false}},
                      colors: ['1f2f4b','d0475b', 'ebb340', '7caea8'],
                      lineSize: 3,
                      pointSize: 0,
                      legend: {position: 'bottom'}
                    });
                      //ubicar el grafico en la posicion 8 del panel1
                      // ver imagen app5
                      panel1.widgets().set(8, sstChart);
                }});
                //ubicar selectf en la posicion 1 del panel 2 
                //ver imagen app5
                panel2.widgets().set(1,selectf);
        }});
        //ubicar selectG en la posicion 0 del panel 2 
        //ver imagen app5
        panel2.widgets().set(0, selectG);
  //valores que se nesecitan para que la app funcion y poder llamar los modelos y las bandas
  presprob.setValue("projects/ee-biomodelos-gee4geo/assets/biomodelos_anuales/proba/");
  presprob1.setValue("_MaX_RF_BRT");
  presprob2.setValue('prob_');
  presprob3.setValue("pro_");
  presprob4.setValue(['f1c786','f4565c']);
  //apagar el checkbox de binario
  proba.setDisabled(true);
  binario.setValue(false, false);
  binario.setDisabled(false);
});
    //ubicar el boton de proba en la posicion 0 del panel3
    //ver imagen app2
    panel3.widgets().set(0,proba);
  //binario es otro checkbox para seleccionar el mapa binario
  //ver imagen app2
  var binario = ui.Checkbox('Presence/Absence', false);
  //los cambios que ocurran cuando se selccione proba
  binario.onChange(function(checked) {
    //igual que en proba
    panel2.widgets().set(1, ui.Label());
    panel2.widgets().set(2, ui.Label());
    panel2.widgets().set(3, ui.Label());
    panel2.widgets().set(4, ui.Label());
    panel2.widgets().set(5, ui.Label());
    etiqueta.setValue(" ");
    panel1.widgets().set(8, ui.Label());
    panel1.widgets().set(9, ui.Label());
    //igual que en proba
    var selectG = ui.Select({
        items: Object.keys(genero),
        style:{width:400, margin:'3px 3px 0 0'},
        placeholder:'Genus',
        onChange: function(keyG) {
          etiqueta.setValue(keyG+" ");
          //igual que en proba          
          var cosas = epiteto[keyG];
          panel2.remove(selectf);  
          //igual que en proba
          panel2.widgets().set(2,ui.Label());
          panel2.widgets().set(3,ui.Label());
          panel2.widgets().set(4,ui.Label());
          panel2.widgets().set(5,ui.Label());
          panel1.widgets().set(8,ui.Label());
          panel1.widgets().set(9,ui.Label());
          //igual que en proba
          var selectf = ui.Select({
                items: cosas,
                style:{width:400, margin:'3px 3px 0 0'},
                placeholder :'Specific name',
                onChange: function(keyE){
                  //igual que en proba
                  etiqueta.setValue(keyG+" "+keyE);
                  panel1.widgets().set(9,ui.Label());
                  //igual que en proba
                  var sp = etiqueta.getValue()   ;
                  var sp_ =  sp.replace(' ', '_');
                  //igual que en proba PERO ESTA VEZ SE AÑADE EL BOTON DE SVM
                  //ver imagen app6
                  var RF = ui.Checkbox('RF', false);
                  var BRT = ui.Checkbox('BRT', false);
                  var MaxEnt = ui.Checkbox('MaxEnt', false);
                  var SVM = ui.Checkbox('SVM', false);
                  //igual que en proba
                  RF.onChange(function(checked) {
                    //igual que en proba
                    algorit.setValue("RF");
                    //igual que en proba PERO SE CAMBIA LA LEYENDA A LA LEYENDA DE MAPA BINARIO
                    //ver imagen app6
                    var legendTitle = ui.Label({
                      value: "Presence of "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    //parecido que proba pero solo se pone un solo valor de leyenda la presencia
                    //ver imagen app6
                    var colorBar = ui.Label({
                        value:'■',
                        style: { margin: '0px 8px', maxHeight: '25px',
                        fontSize:'28px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }});
                    //igual que en proba
                    //ver imagen app6
                    var legendPanel = ui.Panel([colorBar, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    //igual que en proba
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    //igual que en proba
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    //igual que en proba PERO CON LOS MODELOS BINARIOS
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      //igual que en proba
                      mapPanel.clear();
                      //igual que en proba
                      mapPanel.centerObject(modelo, 6);
                      //igual que en proba PERO CON LOS MODELOS BINARIOS cambia la visualizacion
                      //ver imagen app7
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400});
                    //igual que en proba PERO CON EL BOTON CHECKBOX DE SVM
                    RF.setDisabled(true);
                    BRT.setValue(false, false);
                    BRT.setDisabled(false);
                    MaxEnt.setValue(false, false);
                    MaxEnt.setDisabled(false);
                    SVM.setValue(false, false);
                    SVM.setDisabled(false);
                  });
                  //igual que RF
                  BRT.onChange(function(checked) {
                    algorit.setValue("BRT");
                    var legendTitle = ui.Label({
                      value: "Presence of "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'■',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'28px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }, 
                      });
                    var legendPanel = ui.Panel([colorBar, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400}); 
                    BRT.setDisabled(true);
                    RF.setValue(false, false);
                    RF.setDisabled(false);
                    MaxEnt.setValue(false, false);
                    MaxEnt.setDisabled(false);
                    SVM.setValue(false, false);
                    SVM.setDisabled(false);
                  });
                  //igual que RF
                  MaxEnt.onChange(function(checked) {
                    algorit.setValue("MaxEnt");
                    var legendTitle = ui.Label({
                      value: "Presence of "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'■',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'28px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }, 
                      });
                    var legendPanel = ui.Panel([colorBar, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400});
                    MaxEnt.setDisabled(true);
                    RF.setValue(false, false);
                    RF.setDisabled(false);
                    BRT.setValue(false, false);
                    BRT.setDisabled(false);
                    SVM.setValue(false, false);
                    SVM.setDisabled(false);
                  });
                  //igual que RF
                  SVM.onChange(function(checked) {
                    algorit.setValue("SVM");
                    var legendTitle = ui.Label({
                      value: "Presence of "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'■',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'28px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }, 
                      });
                    var legendPanel = ui.Panel([colorBar, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400});
                    SVM.setDisabled(true);
                    BRT.setValue(false, false);
                    BRT.setDisabled(false);
                    RF.setValue(false, false);
                    RF.setDisabled(false);
                    MaxEnt.setValue(false, false);
                    MaxEnt.setDisabled(false);
                  });
                    panel2.widgets().set(2,RF);
                    panel2.widgets().set(3,BRT);
                    panel2.widgets().set(4,MaxEnt);
                    panel2.widgets().set(5,SVM);
                  var grafico = resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(21,42,1))
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(42,63,1))
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(63,84,1))
                    .map(function (l){return ee.List(l).flatten()});
                  var sstChart = ui.Chart.array.values({array: grafico, axis: 0, xLabels: years})
                    .setSeriesNames(['BRT','MaxEnt', 'RF', 'SVM'])
                    .setOptions({
                      title: 'Available habitat for '+sp+'\n',
                      hAxis: {title: 'Year',
                              titleTextStyle: {italic: true, bold: false}},
                      vAxis:  {title: 'Area Km2',
                              titleTextStyle: {italic: true, bold: false}},
                      colors: ['1f2f4b','d0475b', 'ebb340', '7caea8'],
                      lineSize: 3,
                      pointSize: 0,
                      legend: {position: 'bottom'}
                    });
                      panel1.widgets().set(8, sstChart);
                }});
                panel2.widgets().set(1,selectf);
        }});
        panel2.widgets().set(0, selectG);
  presprob.setValue("projects/ee-biomodelos-gee4geo/assets/biomodelos_anuales/binario/");
  presprob1.setValue("_MaX_SVM_RF_BRT");
  presprob2.setValue('pres_');
  presprob3.setValue("pre_");
  presprob4.setValue('f4565c');
  binario.setDisabled(true);
  proba.setValue(false, false);
  proba.setDisabled(false);
});
    //ubicar el boton de binario en la posicion 1 del panel3
    //ver imagen app2
    panel3.widgets().set(1,binario);
  //colocar en el panel1 etiquetas vacias en las posiciones 4 5 6 7
  panel1.widgets().set(4, ui.Label());
  panel1.widgets().set(5, ui.Label());
  panel1.widgets().set(6, ui.Label());
  panel1.widgets().set(7, ui.Label());
  //colocar en el panel1 el panel 3 en la poscicion 4
  //ver imagenes app4 y app2
  panel1.widgets().set(4, panel3);
  //colocar en el panel1 un label vacion en la poscicion 5
  //ver imagenes app4 y app5
  panel1.widgets().set(5, ui.Label());
  //colocar en el panel1 un el panel2 en la poscicion 6
  //ver imagenes app4 y app5
  panel1.widgets().set(6, panel2);
  //colocar en el panel1 el label etiqueta en la poscicion 7
  //ver imagenes app4 y app5
  panel1.widgets().set(7, etiqueta);
  //desactivar el checbox de español y activar el de ingles
  ingles.setDisabled(true);
  espanol.setValue(false, false);
  espanol.setDisabled(false);
});
//ver imagen app1
var espanol = ui.Checkbox('Español', false);
//igual que en ingles PERO CON LOS TEXTOS EN ESPAÑOL
espanol.onChange(function(checked) {
  panel2.clear();
  etiqueta.setValue(' ');
  panel1.widgets().set(8,ui.Label());
  panel1.widgets().set(9,ui.Label());
  var intro = ui.Panel([
      ui.Label({
        value: 'BioModelos: Modelos multitemporales de disponibilidad de hábitat para la avifauna colombiana',
        style: {fontSize: '18px', fontWeight: 'bold', color:'#db3f2a', margin: '0 0 10px'}
      }),
      ui.Label({
        value: 'Modelos probabilísticos y binarios para 1537 especies de aves de los años 2000-2021, con un pixel de 250mts.',
        style: {fontSize: '15px', margin: '0 0 7px', color:'#606060'}
      }),
            ui.Label({
        value: '1. Seleccione el tipo de mapa (probabilistico/idoneidad) (presencia/Hábitat potencial según umbral 10%).',
        style: {fontSize: '14px', margin: '0 0 2px'}
      }),
            ui.Label({
        value: '2. Explore el género y la especie.',
        style: {fontSize: '14px', margin: '0 0 2px'}
      }),
      ui.Label({
        value: '3. Seleccione un algoritmo (Árboles de regresión potenciados-BRT, Máquina de vectores de soporte-SVM, Bosques aleatorios-RF, Máxima entropía de Phillips-Maxent).',
        style: {fontSize: '14px', margin: '0 0 2px'}
      })
    ], ui.Panel.Layout.flow('vertical'));
    panel1.widgets().set(3,intro);
  var proba = ui.Checkbox('Probabilístico', false);
  proba.onChange(function(checked) {
    panel2.widgets().set(1, ui.Label());
    panel2.widgets().set(2, ui.Label());
    panel2.widgets().set(3, ui.Label());
    panel2.widgets().set(4, ui.Label());
    panel2.widgets().set(5, ui.Label());
    etiqueta.setValue(" ");
    panel1.widgets().set(8, ui.Label());
    panel1.widgets().set(9, ui.Label());
  var selectG = ui.Select({
        items: Object.keys(genero),
        style:{width:400, margin:'3px 3px 0 0'},
        placeholder :'Género',
        onChange: function(keyG) {
          etiqueta.setValue(keyG+" ");
          var cosas = epiteto[keyG];
          panel2.remove(selectf);  
          panel2.widgets().set(2,ui.Label());
          panel2.widgets().set(3,ui.Label());
          panel2.widgets().set(4,ui.Label());
          panel2.widgets().set(5,ui.Label());
          panel1.widgets().set(8,ui.Label());
          panel1.widgets().set(9,ui.Label());
          var selectf = ui.Select({
                items: cosas,
                placeholder:'Epíteto específico',
                style:{width:400, margin:'3px 3px 0 0'},
                onChange: function(keyE){
                  etiqueta.setValue(keyG+" "+keyE);
                  panel1.widgets().set(9,ui.Label());
                  var sp = etiqueta.getValue()   ;
                  var sp_ =  sp.replace(' ', '_');
                  var RF = ui.Checkbox('RF', false);
                  var BRT = ui.Checkbox('BRT', false);
                  var MaxEnt = ui.Checkbox('MaxEnt', false);
                  RF.onChange(function(checked) {
                    algorit.setValue("RF");
                    var legendTitle = ui.Label({
                      value: "Probabilidad de "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'BAJA',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f1c786',
                        textAlign:'right'
                        }});
                    var colorBar1 = ui.Label({
                        value:'ALTA',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }});
                    var legendPanel = ui.Panel([colorBar,colorBar1, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400});
                    RF.setDisabled(true);
                    BRT.setValue(false, false);
                    BRT.setDisabled(false);
                    MaxEnt.setValue(false, false);
                    MaxEnt.setDisabled(false);
                  });
                  BRT.onChange(function(checked) {
                    algorit.setValue("BRT");
                    var legendTitle = ui.Label({
                      value: "Probabilidad de "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'BAJA',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f1c786',
                        textAlign:'right'
                        }});
                    var colorBar1 = ui.Label({
                        value:'ALTA',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }});
                    var legendPanel = ui.Panel([colorBar,colorBar1, legendTitle], ui.Panel.Layout.flow('horizontal'));                   
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400}); 
                    BRT.setDisabled(true);
                    RF.setValue(false, false);
                    RF.setDisabled(false);
                    MaxEnt.setValue(false, false);
                    MaxEnt.setDisabled(false);
                  });
                  MaxEnt.onChange(function(checked) {
                    algorit.setValue("MaxEnt");
                    var legendTitle = ui.Label({
                      value: "Probabilidad de "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'BAJA',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f1c786',
                        textAlign:'right'
                        }});
                    var colorBar1 = ui.Label({
                        value:'ALTA',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'20px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }});
                    var legendPanel = ui.Panel([colorBar,colorBar1, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400});
                    MaxEnt.setDisabled(true);
                    RF.setValue(false, false);
                    RF.setDisabled(false);
                    BRT.setValue(false, false);
                    BRT.setDisabled(false);
                  });
                    panel2.widgets().set(2,RF);
                    panel2.widgets().set(3,BRT);
                    panel2.widgets().set(4,MaxEnt);
                  var grafico = resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(21,42,1))
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(42,63,1))
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(63,84,1))
                    .map(function (l){return ee.List(l).flatten()});
                  var sstChart = ui.Chart.array.values({array: grafico, axis: 0, xLabels: years})
                    .setSeriesNames(['BRT','MaxEnt', 'RF', 'SVM'])
                    .setOptions({
                      title: 'Hábitat disponible para '+sp+'\n',
                      hAxis: {title: 'Año',
                              titleTextStyle: {italic: true, bold: false}},
                      vAxis:  {title: 'Área Km2',
                              titleTextStyle: {italic: true, bold: false}},
                      colors: ['1f2f4b','d0475b', 'ebb340', '7caea8'],
                      lineSize: 3,
                      pointSize: 0,
                      legend: {position: 'bottom'}
                    });
                      panel1.widgets().set(8, sstChart);
                }});
                panel2.widgets().set(1,selectf);
        }});
        panel2.widgets().set(0, selectG);
  presprob.setValue("projects/ee-biomodelos-gee4geo/assets/biomodelos_anuales/proba/");
  presprob1.setValue("_MaX_RF_BRT");
  presprob2.setValue('prob_');
  presprob3.setValue("pro_");
  presprob4.setValue(['f1c786','f4565c']);
  proba.setDisabled(true);
  binario.setValue(false, false);
  binario.setDisabled(false);
});
    panel3.widgets().set(0,proba);
  var binario = ui.Checkbox('Presencia/Ausencia', false);
  binario.onChange(function(checked) {
    panel2.widgets().set(1, ui.Label());
    panel2.widgets().set(2, ui.Label());
    panel2.widgets().set(3, ui.Label());
    panel2.widgets().set(4, ui.Label());
    panel2.widgets().set(5, ui.Label());
    etiqueta.setValue(" ");
    panel1.widgets().set(8, ui.Label());
    panel1.widgets().set(9, ui.Label());
  var selectG = ui.Select({
        items: Object.keys(genero),
        placeholder:'Género',
        style:{width:400, margin:'3px 3px 0 0'},
        onChange: function(keyG) {
          etiqueta.setValue(keyG+" ");
          var cosas = epiteto[keyG];
          panel2.remove(selectf);  
          panel2.widgets().set(2,ui.Label());
          panel2.widgets().set(3,ui.Label());
          panel2.widgets().set(4,ui.Label());
          panel2.widgets().set(5,ui.Label());
          panel1.widgets().set(8,ui.Label());
          panel1.widgets().set(9,ui.Label());
          var selectf = ui.Select({
                items: cosas,
                placeholder:'Epíteto específico',
                style:{width:400, margin:'3px 3px 0 0'},
                onChange: function(keyE){
                  etiqueta.setValue(keyG+" "+keyE);
                  panel1.widgets().set(9,ui.Label());
                  var sp = etiqueta.getValue()   ;
                  var sp_ =  sp.replace(' ', '_');
                  var RF = ui.Checkbox('RF', false);
                  var BRT = ui.Checkbox('BRT', false);
                  var MaxEnt = ui.Checkbox('MaxEnt', false);
                  var SVM = ui.Checkbox('SVM', false);
                  RF.onChange(function(checked) {
                    algorit.setValue("RF");
                    var legendTitle = ui.Label({
                      value: "Presencia de "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'■',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'28px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }});
                    var legendPanel = ui.Panel([colorBar, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400});
                    RF.setDisabled(true);
                    BRT.setValue(false, false);
                    BRT.setDisabled(false);
                    MaxEnt.setValue(false, false);
                    MaxEnt.setDisabled(false);
                    SVM.setValue(false, false);
                    SVM.setDisabled(false);
                  });
                  BRT.onChange(function(checked) {
                    algorit.setValue("BRT");
                    var legendTitle = ui.Label({
                      value: "Presencia de "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'■',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'28px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }, 
                      });
                    var legendPanel = ui.Panel([colorBar, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400}); 
                    BRT.setDisabled(true);
                    RF.setValue(false, false);
                    RF.setDisabled(false);
                    MaxEnt.setValue(false, false);
                    MaxEnt.setDisabled(false);
                    SVM.setValue(false, false);
                    SVM.setDisabled(false);
                  });
                  MaxEnt.onChange(function(checked) {
                    algorit.setValue("MaxEnt");
                    var legendTitle = ui.Label({
                      value: "Presencia de "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'■',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'28px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }, 
                      });
                    var legendPanel = ui.Panel([colorBar, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400});
                    MaxEnt.setDisabled(true);
                    RF.setValue(false, false);
                    RF.setDisabled(false);
                    BRT.setValue(false, false);
                    BRT.setDisabled(false);
                    SVM.setValue(false, false);
                    SVM.setDisabled(false);
                  });
                  SVM.onChange(function(checked) {
                    algorit.setValue("SVM");
                    var legendTitle = ui.Label({
                      value: "Presencia de "+sp+" "+algorit.getValue(),
                      style: {fontWeight: 'bold'}
                    });
                    var colorBar = ui.Label({
                        value:'■',
                        style: { margin: '0px 8px', maxHeight: '25px',
                          fontSize:'28px' ,
                        color:'f4565c',
                        textAlign:'center'
                        }, 
                      });
                    var legendPanel = ui.Panel([colorBar, legendTitle], ui.Panel.Layout.flow('horizontal'));                    
                    panel1.widgets().set(9,legendPanel);
                    var modelo =ee.Image(presprob.getValue()+sp_+presprob1.getValue());
                    function imagen(num){
                      var i = ee.String(ee.Number.parse(num).subtract(2000));
                      var imag =modelo.select([ee.String(presprob2.getValue()).cat(i).cat(ee.String("_"+algorit.getValue()+"_")).cat(num)],["b1"]);
                      return ee.List([imag.set("system:id",ee.String(presprob3.getValue()).cat(num))]);
                    }
                    var images = ee.ImageCollection(ee.List([years.map(imagen)]).flatten()).sort("system:id");
                      mapPanel.clear();
                      mapPanel.centerObject(modelo, 6);
                      animate(images ,{maxFrames: images.size(), vis:{ 
                                                                    min: 0, 
                                                                    max: 100, 
                                                                    opacity: 1,
                                                                    palette: presprob4.getValue() },
                                                                    label: sp +" system:id", 
                                                                    timeStep: 600, 
                                                                    width: 400});
                    SVM.setDisabled(true);
                    BRT.setValue(false, false);
                    BRT.setDisabled(false);
                    RF.setValue(false, false);
                    RF.setDisabled(false);
                    MaxEnt.setValue(false, false);
                    MaxEnt.setDisabled(false);
                  });
                    panel2.widgets().set(2,RF);
                    panel2.widgets().set(3,BRT);
                    panel2.widgets().set(4,MaxEnt);
                    panel2.widgets().set(5,SVM);
                  var grafico = resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(21,42,1))
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(42,63,1))
                    .zip(ee.List(resumen.filterMetadata('sp','equals',sp_).first().toDictionary().values()).slice(63,84,1))
                    .map(function (l){return ee.List(l).flatten()});
                  var sstChart = ui.Chart.array.values({array: grafico, axis: 0, xLabels: years})
                    .setSeriesNames(['BRT','MaxEnt', 'RF', 'SVM'])
                    .setOptions({
                      title: 'Hábitat disponible para '+sp+'\n',
                      hAxis: {title: 'Año',
                              titleTextStyle: {italic: true, bold: false}},
                      vAxis:  {title: 'Área Km2',
                              titleTextStyle: {italic: true, bold: false}},
                      colors: ['1f2f4b','d0475b', 'ebb340', '7caea8'],
                      lineSize: 3,
                      pointSize: 0,
                      legend: {position: 'bottom'}
                    });
                      panel1.widgets().set(8, sstChart);
                }});
                panel2.widgets().set(1,selectf);
        }});
        panel2.widgets().set(0, selectG);
  presprob.setValue("projects/ee-biomodelos-gee4geo/assets/biomodelos_anuales/binario/");
  presprob1.setValue("_MaX_SVM_RF_BRT");
  presprob2.setValue('pres_');
  presprob3.setValue("pre_");
  presprob4.setValue('f4565c');
  binario.setDisabled(true);
  proba.setValue(false, false);
  proba.setDisabled(false);
});
    panel3.widgets().set(1,binario);
  panel1.widgets().set(4, ui.Label());
  panel1.widgets().set(5, ui.Label());
  panel1.widgets().set(6, ui.Label());
  panel1.widgets().set(7, ui.Label());
  panel1.widgets().set(4, panel3);
  panel1.widgets().set(5, ui.Label());
  panel1.widgets().set(6, panel2);
  panel1.widgets().set(7, etiqueta);
  espanol.setDisabled(true);
  ingles.setValue(false, false);
  ingles.setDisabled(false);
});
//ubicar los checboxes botones de ingles y español en las posiciones 0 y 1 respectivamente del panel4
//ver imagen app1
panel4.widgets().set(0,ingles);
panel4.widgets().set(1,espanol);
//ubicar el thumbnail de branding en la posicion 0, el panel 4 en la poscicion 1 y un label vacio en la posicion 2
//ver imagen app2
panel1.widgets().set(0,branding);
panel1.widgets().set(1,agradecimiento);
panel1.widgets().set(2,panel4);
panel1.widgets().set(3,ui.Label());
//crear 11 labels vacios que permitan que el texto ultimo de agradecimiento siempre este al final
/*panel1.widgets().set(3,ui.Label());
panel1.widgets().set(4,ui.Label());
panel1.widgets().set(5,ui.Label());
panel1.widgets().set(6,ui.Label());
panel1.widgets().set(7,ui.Label());
panel1.widgets().set(8,ui.Label());
panel1.widgets().set(9,ui.Label());
panel1.widgets().set(10,ui.Label());
panel1.widgets().set(11,ui.Label());*/
//ubicar el label de agradecimiento en la posicion 11 del panel1
//ver imagen app9
//añadir y diseñar los botones que manejan la animacion, y las funciones que permiten que la animacion ocurra
//esto es una funcion creada por GENNA
/*  Copyright (c) 2018 Gennadii Donchyts. All rights reserved.
This work is licensed under the terms of the MIT license.  
For a copy, see <https://opensource.org/licenses/MIT>.  */
    function addAnimationControls(layers, position, timeStep, width, compact) {
      var currentIndex = 0;
      //definir una opcadidad de 0 para mantener las capas transparentes
      layers.map(function(l) { 
        l.setOpacity(0);
      });
      //funcion para activar solo el año que se quiere visualizar
      var showLayer = function (index) {
        layers[currentIndex].setOpacity(0);
        //activar la opacidad a 1 de la capa actual
        var l = layers[index];
        l.setOpacity(1);
        currentIndex = index;
        //mostrar la capa
        var shown = l.getShown();
        if(!shown) {
          l.setShown(true);
        }
        //definir el label de la capa
        label.setValue(layers[index].getName());
      };
      //el label de la capa se coloca vacio
      var label = ui.Label('');
      //funcion para pasar a la siguiente capa
      function nextFrame() {
        //añadir 1 al index actual para pasar a la capa siguiente
        var index = currentIndex + 1;
        if(index >= layers.length) {
          index = 0;
        }
        //ubicar el numero del index de la capa en el slider 
        slider.setValue(index);
        //condicional para ejecutar la funcion de la siguiente capa cada Xcantidad de tiempo
        if(play) {
          ui.util.setTimeout(nextFrame, timeStep);
        }
      }
      //funcion para el boton de play
      function onPlayPause() {
        //cuando play ejecutar la animacion de siguiente capa, y si se pausa detener todo 
        if(!play && !timeout) {
          timeout = ui.util.setTimeout(nextFrame, timeStep);
          play = true;
          buttonPlayPause.setLabel(textPause);
        } else {
          ui.util.clearTimeout(timeout);
          timeout = null;
          play = false;
          buttonPlayPause.setLabel(textPlay);
        }
      }
      //textos de los botones de play y pausa
      //ver imagen app7
      var textPlay = '▶';
      var textPause = '⏸';
      var buttonPlayPause = ui.Button(textPlay, onPlayPause);
      //crear un slide horizontal 
      //ver imagen app7
      var slider = ui.Slider({
        min: 0,
        max: layers.length - 1,
        step: 1,
        style: {stretch: 'horizontal'}
      });
      //a medida que se mueva el slider mostrar la capa
      slider.onSlide(showLayer);
      //ordenar los widgets
      var widgets = [label, buttonPlayPause, slider];
      //
      // Create a panel that contains both the slider and the label.
      var panel = ui.Panel({
        widgets: widgets,
        layout: ui.Panel.Layout.flow('horizontal'),
        style: {
          position: position,
          width: width
        }
      });
      //ubicar el panel en la posicion 10 del panel1
      //ver imagen app7
      panel1.widgets().set(10,panel);
      layers[0].setOpacity(1);
      //no estoy seguro pero creo que es un loop para que la funcion siempre se ejecute y no se pause cuando cambia la capa
      // loop
      function delay(millis, callback) {
        var before = Date.now();
        function loop() {
          ee.Number(Date.now()).evaluate(function(now) { 
            if(now < before + millis) {
              loop();
            } else {
              callback();
            }
          });
        }
        loop();
      }
      //no se bien que hace esta funcion
      function setTimeout(interval, action) {
        delay(interval, function() {
          action();
          setTimeout(interval, action);
        });
      }
      //mantener actualizado el panel (el slider y el label)
      return panel;
    }
    /*
     * Animates a maxImageCount images from a given image collection, adds them as layers so that GMap caching can be used
     */
    function animate(imagenes, options) {
      //se definen los parametros por default de la animacion
      var maxFrames = (options && options.maxFrames) || 30;
      var width = (options && options.width) || '200px';
      var vis = (options && options.vis) || {};
      var position = (options && options.position) || 'top-center';
      var timeStep = (options && options.timeStep) || 100;
      var preload = true;
      if(options && options.preload != 'undefined') {
        preload = options.preload;
      }
      //se llaman las imagenes que se mostraran
      imagenes = ee.ImageCollection(imagenes).toList(maxFrames, 0);
      maxFrames = imagenes.size().min(maxFrames);
      //add loading panel
      //añadir panel de espera 
      //ver imagen app8
      var label = ui.Label({
      value: 'Wait a minute for the images \nEspere mientras se cargan las imágenes'  ,
      style: {
        whiteSpace: 'pre',
        fontWeight: 'bold',
        fontSize: '15px',
        textAlign: 'left',
        margin: '0 0 4px 0',
        padding: '0'
      }
    });
    //añadir un panel que contenga label de carga
      var panel = ui.Panel({
        widgets: [label],
        layout: ui.Panel.Layout.flow('horizontal'),
        style: {
          position: position,
          padding: '7px',
          width: width
        }
      });
      //ubicar ese panel en la posicion 10 (se eliminara una vez carge y sera reemplazado)
      panel1.widgets().set(10,panel);
      //no se que pasa aca
      // chaining
      var s = {};
      //se crea un nuevo panel
      s.panel = panel;
      //se vincula la animacion a los controles de animacion
      var lodingPanel = panel;
      ee.List.sequence(1, maxFrames).evaluate(function(indices) {
        var layers = [];
        indices.map(function(i) {
          var image = ee.Image(imagenes.get(i-1));
          var date = ee.String(image.get('system:id')).slice(4,8).getInfo();
          if(options && options.clipArea) {
            image = image.clip(options.clipArea);
          }
          var visible = preload;
          if(options && options.preloadCount && i > options.preloadCount) {
            visible = false;
          }
          var layer = ui.Map.Layer(image, vis, date, visible);
          mapPanel.layers().add(layer);
          layers.push(layer);
        });
        // remove loading panel
        //remover el panel de carga
        panel1.widgets().remove(lodingPanel);
        var panel = addAnimationControls(layers, position, timeStep, width);
        // replace panel
        s.panel = panel;
      });
      return s;
    }
// Animation ends here, the code protected by Copyright (c) 2018 Gennadii Donchyts end h. All rights reserved. 
//licensed under the terms of the MIT license.  
//ends here
//limpiar la interfaz de apps
ui.root.clear();
//ubicar el panel1 y el mapPanel en la interfaz
ui.root.add(ui.SplitPanel(panel1, mapPanel));