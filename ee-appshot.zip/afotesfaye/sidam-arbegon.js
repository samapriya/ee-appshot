var L8 = ui.import && ui.import("L8", "imageCollection", {
      "id": "LANDSAT/LC08/C01/T1_TOA"
    }) || ee.ImageCollection("LANDSAT/LC08/C01/T1_TOA"),
    roi = ui.import && ui.import("roi", "table", {
      "id": "users/afotesfaye/Arbegona"
    }) || ee.FeatureCollection("users/afotesfaye/Arbegona"),
    tForest = ui.import && ui.import("tForest", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.716062220526766,
            6.705902227559674
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.716130886649154,
            6.709414243770701
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.714070950125716,
            6.707095634938716
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71589055914981,
            6.704470133286087
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71661153640915,
            6.704231451798762
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71506658401657,
            6.70474291421542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71664587078001,
            6.70811855322272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.682691285699136,
            6.7195028182105325
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.681798644443504,
            6.72103715571696
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.67455453485995,
            6.718514019843154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.674726196236904,
            6.717866185160658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.65327508588981,
            6.740964878768069
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.6556096869028,
            6.742737816342013
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.65286310487155,
            6.740555740407935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.65519769540716,
            6.742465056737191
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.64326029577409,
            6.69790405914432
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.643603618528,
            6.697460785140925
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.64370661574707,
            6.696881120079729
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.64241057248204,
            6.698730934236636
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.642650898016875,
            6.698185366799735
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.64278822698747,
            6.6978273386100176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.644075687969455,
            6.695798505505075
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.64400702315674,
            6.695235887280094
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.643835361779786,
            6.694980151154157
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.651817615808106,
            6.6984922486393605
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.651525791991155,
            6.69815126938374
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.65157728961844,
            6.698117171965378
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.64163809628575,
            6.699259451093108
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.64189558835118,
            6.699054863760019
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.64196425250906,
            6.698918472373742
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.641603763879395,
            6.695014248791722
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.64177542525635,
            6.694758512549657
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.716062220526766, 6.705902227559674]),
            {
              "landuse": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.716130886649154, 6.709414243770701]),
            {
              "landuse": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.714070950125716, 6.707095634938716]),
            {
              "landuse": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71589055914981, 6.704470133286087]),
            {
              "landuse": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71661153640915, 6.704231451798762]),
            {
              "landuse": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71506658401657, 6.70474291421542]),
            {
              "landuse": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71664587078001, 6.70811855322272]),
            {
              "landuse": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.682691285699136, 6.7195028182105325]),
            {
              "landuse": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([38.681798644443504, 6.72103715571696]),
            {
              "landuse": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([38.67455453485995, 6.718514019843154]),
            {
              "landuse": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([38.674726196236904, 6.717866185160658]),
            {
              "landuse": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([38.65327508588981, 6.740964878768069]),
            {
              "landuse": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([38.6556096869028, 6.742737816342013]),
            {
              "landuse": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([38.65286310487155, 6.740555740407935]),
            {
              "landuse": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([38.65519769540716, 6.742465056737191]),
            {
              "landuse": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([38.64326029577409, 6.69790405914432]),
            {
              "landuse": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([38.643603618528, 6.697460785140925]),
            {
              "landuse": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([38.64370661574707, 6.696881120079729]),
            {
              "landuse": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([38.64241057248204, 6.698730934236636]),
            {
              "landuse": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([38.642650898016875, 6.698185366799735]),
            {
              "landuse": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([38.64278822698747, 6.6978273386100176]),
            {
              "landuse": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([38.644075687969455, 6.695798505505075]),
            {
              "landuse": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([38.64400702315674, 6.695235887280094]),
            {
              "landuse": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([38.643835361779786, 6.694980151154157]),
            {
              "landuse": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([38.651817615808106, 6.6984922486393605]),
            {
              "landuse": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([38.651525791991155, 6.69815126938374]),
            {
              "landuse": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([38.65157728961844, 6.698117171965378]),
            {
              "landuse": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([38.64163809628575, 6.699259451093108]),
            {
              "landuse": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([38.64189558835118, 6.699054863760019]),
            {
              "landuse": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([38.64196425250906, 6.698918472373742]),
            {
              "landuse": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([38.641603763879395, 6.695014248791722]),
            {
              "landuse": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([38.64177542525635, 6.694758512549657]),
            {
              "landuse": 0,
              "system:index": "31"
            })]),
    vForest = ui.import && ui.import("vForest", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.67287364229182,
            6.747321752709414
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.672701980914866,
            6.746503483777826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.671500351276194,
            6.747764977993633
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.645497237124886,
            6.720283262562614
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.645497237124886,
            6.7201468790721535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.645359907499454,
            6.7201468790721535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.680239026613826,
            6.6512335230092114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.68020469355263,
            6.650687901341959
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 0
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.67287364229182, 6.747321752709414]),
            {
              "landuse": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.672701980914866, 6.746503483777826]),
            {
              "landuse": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.671500351276194, 6.747764977993633]),
            {
              "landuse": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.645497237124886, 6.720283262562614]),
            {
              "landuse": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.645497237124886, 6.7201468790721535]),
            {
              "landuse": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.645359907499454, 6.7201468790721535]),
            {
              "landuse": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.680239026613826, 6.6512335230092114]),
            {
              "landuse": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.68020469355263, 6.650687901341959]),
            {
              "landuse": 0,
              "system:index": "7"
            })]),
    tbareland = ui.import && ui.import("tbareland", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.70413616906734,
            6.695390357776951
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70399025650403,
            6.6953477351120885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70626476974866,
            6.694759541826808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.703116472527455,
            6.696241384661079
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.703090723713814,
            6.696104992488315
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.699374254640844,
            6.695329260671132
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.69908243016906,
            6.695678766296281
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.69848161534972,
            6.696249909048665
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.69818979120535,
            6.696616463427382
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.69556715411513,
            6.696384597274028
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.702108909277065,
            6.7051429947318
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.701379348425014,
            6.705526590877186
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70049529207177,
            6.706225587911436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71405746979759,
            6.685688998974137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.714100385141826,
            6.686004412583199
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71428062945666,
            6.685919165611596
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71422913117454,
            6.685654900035203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71582201266537,
            6.688082171560534
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.7156589342263,
            6.687809382619002
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71534994387875,
            6.687834956222901
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71553877113146,
            6.687741185034624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71530702853451,
            6.687323476086039
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71539285922299,
            6.687229704799621
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71246372988067,
            6.689342356764049
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71236931625431,
            6.689197438153566
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.712103241251,
            6.689342356764049
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.7120860747204,
            6.689154814948137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.712540977631264,
            6.6892485858651005
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 1
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.70413616906734, 6.695390357776951]),
            {
              "landuse": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70399025650403, 6.6953477351120885]),
            {
              "landuse": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70626476974866, 6.694759541826808]),
            {
              "landuse": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.703116472527455, 6.696241384661079]),
            {
              "landuse": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.703090723713814, 6.696104992488315]),
            {
              "landuse": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.699374254640844, 6.695329260671132]),
            {
              "landuse": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.69908243016906, 6.695678766296281]),
            {
              "landuse": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.69848161534972, 6.696249909048665]),
            {
              "landuse": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([38.69818979120535, 6.696616463427382]),
            {
              "landuse": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([38.69556715411513, 6.696384597274028]),
            {
              "landuse": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([38.702108909277065, 6.7051429947318]),
            {
              "landuse": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([38.701379348425014, 6.705526590877186]),
            {
              "landuse": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70049529207177, 6.706225587911436]),
            {
              "landuse": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71405746979759, 6.685688998974137]),
            {
              "landuse": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([38.714100385141826, 6.686004412583199]),
            {
              "landuse": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71428062945666, 6.685919165611596]),
            {
              "landuse": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71422913117454, 6.685654900035203]),
            {
              "landuse": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71582201266537, 6.688082171560534]),
            {
              "landuse": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([38.7156589342263, 6.687809382619002]),
            {
              "landuse": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71534994387875, 6.687834956222901]),
            {
              "landuse": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71553877113146, 6.687741185034624]),
            {
              "landuse": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71530702853451, 6.687323476086039]),
            {
              "landuse": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71539285922299, 6.687229704799621]),
            {
              "landuse": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71246372988067, 6.689342356764049]),
            {
              "landuse": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71236931625431, 6.689197438153566]),
            {
              "landuse": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([38.712103241251, 6.689342356764049]),
            {
              "landuse": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([38.7120860747204, 6.689154814948137]),
            {
              "landuse": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([38.712540977631264, 6.6892485858651005]),
            {
              "landuse": 1,
              "system:index": "27"
            })]),
    vbareland = ui.import && ui.import("vbareland", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.71457739752522,
            6.69060151126769
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71422549183343,
            6.690746429461624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71431132252191,
            6.690558888184776
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.714611729931576,
            6.690499215472216
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71855135866362,
            6.690644134346877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71801062506428,
            6.691249381539943
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.718139371096996,
            6.691479545883117
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71829386659819,
            6.691786430638114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71680899542561,
            6.690183804764672
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.716422757327464,
            6.68885396181846
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 1
      },
      "color": "#00ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.71457739752522, 6.69060151126769]),
            {
              "landuse": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71422549183343, 6.690746429461624]),
            {
              "landuse": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71431132252191, 6.690558888184776]),
            {
              "landuse": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.714611729931576, 6.690499215472216]),
            {
              "landuse": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71855135866362, 6.690644134346877]),
            {
              "landuse": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71801062506428, 6.691249381539943]),
            {
              "landuse": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.718139371096996, 6.691479545883117]),
            {
              "landuse": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71829386659819, 6.691786430638114]),
            {
              "landuse": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71680899542561, 6.690183804764672]),
            {
              "landuse": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([38.716422757327464, 6.68885396181846]),
            {
              "landuse": 1,
              "system:index": "9"
            })]),
    tFarmland = ui.import && ui.import("tFarmland", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.70687352704423,
            6.691542234438502
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.7071138532339,
            6.691303545976246
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.705465903949666,
            6.690399937250934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.706255546349134,
            6.6902720679382615
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70587789118887,
            6.691056332268839
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70582639290675,
            6.692249775968746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70439302034371,
            6.6907664953714985
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.7050281675694,
            6.690502232416811
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70429860671735,
            6.689914033294487
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70786057996171,
            6.690016329212501
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.708452811843166,
            6.690306165904608
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70887338234767,
            6.690544855504674
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70873605337707,
            6.690868791110982
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70853005959376,
            6.69097108617867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70835839821681,
            6.6910051847466105
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.7091308744131,
            6.691269447429157
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70929395285217,
            6.691150102820765
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70764600324052,
            6.691874693847263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70713960270238,
            6.692624857802109
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70713101910966,
            6.692215677812903
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70675336460423,
            6.692999939022173
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.706255546349134,
            6.6930340374484265
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.706186881863836,
            6.692889119608171
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.705929389798406,
            6.693042561892027
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70602380342476,
            6.692889119608171
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70607530170688,
            6.692181578679127
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70544873774649,
            6.691439939490454
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.7050281675694,
            6.691601907023623
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70539723946437,
            6.691397316480705
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.706195464801716,
            6.690101575469294
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70590364032993,
            6.690110099964089
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70602380342476,
            6.689675344036545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70686494410635,
            6.689649769878593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70966302441972,
            6.690365838640755
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71048699955296,
            6.69165305448336
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71115647853018,
            6.692650430828713
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.711431137126205,
            6.692531087208187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71034966992753,
            6.692727152827139
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.709937683015745,
            6.692650430828713
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.7405814903087,
            6.733282579374232
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 2
      },
      "color": "#bf04c2",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #bf04c2 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.70687352704423, 6.691542234438502]),
            {
              "landuse": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.7071138532339, 6.691303545976246]),
            {
              "landuse": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.705465903949666, 6.690399937250934]),
            {
              "landuse": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.706255546349134, 6.6902720679382615]),
            {
              "landuse": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70587789118887, 6.691056332268839]),
            {
              "landuse": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70582639290675, 6.692249775968746]),
            {
              "landuse": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70439302034371, 6.6907664953714985]),
            {
              "landuse": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.7050281675694, 6.690502232416811]),
            {
              "landuse": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70429860671735, 6.689914033294487]),
            {
              "landuse": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70786057996171, 6.690016329212501]),
            {
              "landuse": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([38.708452811843166, 6.690306165904608]),
            {
              "landuse": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70887338234767, 6.690544855504674]),
            {
              "landuse": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70873605337707, 6.690868791110982]),
            {
              "landuse": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70853005959376, 6.69097108617867]),
            {
              "landuse": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70835839821681, 6.6910051847466105]),
            {
              "landuse": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([38.7091308744131, 6.691269447429157]),
            {
              "landuse": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70929395285217, 6.691150102820765]),
            {
              "landuse": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70764600324052, 6.691874693847263]),
            {
              "landuse": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70713960270238, 6.692624857802109]),
            {
              "landuse": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70713101910966, 6.692215677812903]),
            {
              "landuse": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70675336460423, 6.692999939022173]),
            {
              "landuse": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([38.706255546349134, 6.6930340374484265]),
            {
              "landuse": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([38.706186881863836, 6.692889119608171]),
            {
              "landuse": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([38.705929389798406, 6.693042561892027]),
            {
              "landuse": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70602380342476, 6.692889119608171]),
            {
              "landuse": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70607530170688, 6.692181578679127]),
            {
              "landuse": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70544873774649, 6.691439939490454]),
            {
              "landuse": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([38.7050281675694, 6.691601907023623]),
            {
              "landuse": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70539723946437, 6.691397316480705]),
            {
              "landuse": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([38.706195464801716, 6.690101575469294]),
            {
              "landuse": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70590364032993, 6.690110099964089]),
            {
              "landuse": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70602380342476, 6.689675344036545]),
            {
              "landuse": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70686494410635, 6.689649769878593]),
            {
              "landuse": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70966302441972, 6.690365838640755]),
            {
              "landuse": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71048699955296, 6.69165305448336]),
            {
              "landuse": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71115647853018, 6.692650430828713]),
            {
              "landuse": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([38.711431137126205, 6.692531087208187]),
            {
              "landuse": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71034966992753, 6.692727152827139]),
            {
              "landuse": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([38.709937683015745, 6.692650430828713]),
            {
              "landuse": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([38.7405814903087, 6.733282579374232]),
            {
              "landuse": 2,
              "system:index": "39"
            })]),
    vFarmland = ui.import && ui.import("vFarmland", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.707087138759306,
            6.700050472228834
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.710056881104464,
            6.699402613638935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.707361796700496,
            6.69834557966362
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70847759565069,
            6.697083954588077
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70422039363322,
            6.69834557966362
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70258961055217,
            6.6981239425876575
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70167980538528,
            6.6987036074730195
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.701336482631376,
            6.6995560542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.707052807007784,
            6.701312089631847
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70789394670712,
            6.696555435374955
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70710430463507,
            6.697049855794381
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70169697126104,
            6.695481345129186
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.70253811227005,
            6.695106266140867
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 2
      },
      "color": "#ff0000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff0000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.707087138759306, 6.700050472228834]),
            {
              "landuse": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.710056881104464, 6.699402613638935]),
            {
              "landuse": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.707361796700496, 6.69834557966362]),
            {
              "landuse": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70847759565069, 6.697083954588077]),
            {
              "landuse": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70422039363322, 6.69834557966362]),
            {
              "landuse": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70258961055217, 6.6981239425876575]),
            {
              "landuse": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70167980538528, 6.6987036074730195]),
            {
              "landuse": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.701336482631376, 6.6995560542]),
            {
              "landuse": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([38.707052807007784, 6.701312089631847]),
            {
              "landuse": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70789394670712, 6.696555435374955]),
            {
              "landuse": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70710430463507, 6.697049855794381]),
            {
              "landuse": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70169697126104, 6.695481345129186]),
            {
              "landuse": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([38.70253811227005, 6.695106266140867]),
            {
              "landuse": 2,
              "system:index": "12"
            })]),
    tbuiltup = ui.import && ui.import("tbuiltup", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.72234828062673,
            6.700500338015238
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72282893300607,
            6.700568533166786
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72239977956369,
            6.699375109809121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72317225575998,
            6.698471516026029
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71982695040545,
            6.692218762087906
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.7198784493424,
            6.692099417711517
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71868540264161,
            6.691434499624022
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71853090714042,
            6.6913833521413855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.7188999793628,
            6.69105941687635
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71914888849035,
            6.691264007560816
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71629930924003,
            6.6918607295215935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71693445646572,
            6.693437776907712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71700312127844,
            6.693497448610802
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.717363609908105,
            6.692338106435137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71738935937658,
            6.692295483503795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71740652525234,
            6.692278434590359
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71677137802665,
            6.692431876740926
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71682287630877,
            6.692363680452317
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71700312127844,
            6.692517122576104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71755243716082,
            6.693011548386735
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.717612519035654,
            6.692934827083362
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71873524704522,
            6.692915646918236
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71886399307793,
            6.692898597376081
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71870949757674,
            6.692855974493655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.720477610283226,
            6.694484166153422
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.7205634409717,
            6.694364822655972
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72063210512958,
            6.694228429633644
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72083809891289,
            6.694433018990253
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72113850632256,
            6.694646132676727
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72325852472083,
            6.694117610498499
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72337010487779,
            6.693913021334874
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72343876838083,
            6.693895972152745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.723567514413546,
            6.693665808298233
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.723687678163216,
            6.693512366860619
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72348168372507,
            6.69358908774804
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72199681386216,
            6.693486792903602
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72093251253925,
            6.692463843930869
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72084668185077,
            6.692429745464782
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.722048311489445,
            6.694330724322653
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72138741545011,
            6.693410071674934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.72046902669051,
            6.693086138404755
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71588566812231,
            6.691432368343515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71585991898125,
            6.6913385978457995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71584275277807,
            6.691295974827208
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71610882778138,
            6.692361549175869
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71691563671145,
            6.693401547237744
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.718254595320715,
            6.69460350994688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.718314676540714,
            6.694671706247816
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 3
      },
      "color": "#00ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.72234828062673, 6.700500338015238]),
            {
              "landuse": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72282893300607, 6.700568533166786]),
            {
              "landuse": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72239977956369, 6.699375109809121]),
            {
              "landuse": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72317225575998, 6.698471516026029]),
            {
              "landuse": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71982695040545, 6.692218762087906]),
            {
              "landuse": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.7198784493424, 6.692099417711517]),
            {
              "landuse": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71868540264161, 6.691434499624022]),
            {
              "landuse": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71853090714042, 6.6913833521413855]),
            {
              "landuse": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([38.7188999793628, 6.69105941687635]),
            {
              "landuse": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71914888849035, 6.691264007560816]),
            {
              "landuse": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71629930924003, 6.6918607295215935]),
            {
              "landuse": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71693445646572, 6.693437776907712]),
            {
              "landuse": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71700312127844, 6.693497448610802]),
            {
              "landuse": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([38.717363609908105, 6.692338106435137]),
            {
              "landuse": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71738935937658, 6.692295483503795]),
            {
              "landuse": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71740652525234, 6.692278434590359]),
            {
              "landuse": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71677137802665, 6.692431876740926]),
            {
              "landuse": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71682287630877, 6.692363680452317]),
            {
              "landuse": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71700312127844, 6.692517122576104]),
            {
              "landuse": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71755243716082, 6.693011548386735]),
            {
              "landuse": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([38.717612519035654, 6.692934827083362]),
            {
              "landuse": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71873524704522, 6.692915646918236]),
            {
              "landuse": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71886399307793, 6.692898597376081]),
            {
              "landuse": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71870949757674, 6.692855974493655]),
            {
              "landuse": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([38.720477610283226, 6.694484166153422]),
            {
              "landuse": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([38.7205634409717, 6.694364822655972]),
            {
              "landuse": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72063210512958, 6.694228429633644]),
            {
              "landuse": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72083809891289, 6.694433018990253]),
            {
              "landuse": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72113850632256, 6.694646132676727]),
            {
              "landuse": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72325852472083, 6.694117610498499]),
            {
              "landuse": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72337010487779, 6.693913021334874]),
            {
              "landuse": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72343876838083, 6.693895972152745]),
            {
              "landuse": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([38.723567514413546, 6.693665808298233]),
            {
              "landuse": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([38.723687678163216, 6.693512366860619]),
            {
              "landuse": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72348168372507, 6.69358908774804]),
            {
              "landuse": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72199681386216, 6.693486792903602]),
            {
              "landuse": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72093251253925, 6.692463843930869]),
            {
              "landuse": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72084668185077, 6.692429745464782]),
            {
              "landuse": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([38.722048311489445, 6.694330724322653]),
            {
              "landuse": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72138741545011, 6.693410071674934]),
            {
              "landuse": 3,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([38.72046902669051, 6.693086138404755]),
            {
              "landuse": 3,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71588566812231, 6.691432368343515]),
            {
              "landuse": 3,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71585991898125, 6.6913385978457995]),
            {
              "landuse": 3,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71584275277807, 6.691295974827208]),
            {
              "landuse": 3,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71610882778138, 6.692361549175869]),
            {
              "landuse": 3,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71691563671145, 6.693401547237744]),
            {
              "landuse": 3,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([38.718254595320715, 6.69460350994688]),
            {
              "landuse": 3,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([38.718314676540714, 6.694671706247816]),
            {
              "landuse": 3,
              "system:index": "47"
            })]),
    vbuiltup = ui.import && ui.import("vbuiltup", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.719293146520315,
            6.692012041175837
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71931889598879,
            6.691747778244737
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71738770549807,
            6.694330724322653
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.716555147426945,
            6.6942028560393245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71657231395754,
            6.694134659022509
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71633198776787,
            6.691858598242956
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71584275277807,
            6.691287450353112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.719782381182696,
            6.69202909009856
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71998837496601,
            6.69139826980542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71961930339846,
            6.691031712159013
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.71894124082853,
            6.691082859678468
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 3
      },
      "color": "#0000ff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0000ff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.719293146520315, 6.692012041175837]),
            {
              "landuse": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71931889598879, 6.691747778244737]),
            {
              "landuse": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71738770549807, 6.694330724322653]),
            {
              "landuse": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.716555147426945, 6.6942028560393245]),
            {
              "landuse": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71657231395754, 6.694134659022509]),
            {
              "landuse": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71633198776787, 6.691858598242956]),
            {
              "landuse": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71584275277807, 6.691287450353112]),
            {
              "landuse": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.719782381182696, 6.69202909009856]),
            {
              "landuse": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71998837496601, 6.69139826980542]),
            {
              "landuse": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71961930339846, 6.691031712159013]),
            {
              "landuse": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([38.71894124082853, 6.691082859678468]),
            {
              "landuse": 3,
              "system:index": "10"
            })]),
    twetland = ui.import && ui.import("twetland", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.66253293337176,
            6.66709092551051
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66267026234235,
            6.666758448935177
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66297066975202,
            6.666570898464031
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.663331159036524,
            6.666374822362596
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66418088298341,
            6.666093496408814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.662301190774805,
            6.667781451335692
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66242135386964,
            6.666749924033574
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66224110889997,
            6.66666467370856
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.662052281647256,
            6.666639098998413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.65771928598746,
            6.663144725163816
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.65715280357448,
            6.66356245474359
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 5
      },
      "color": "#9999ff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #9999ff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.66253293337176, 6.66709092551051]),
            {
              "landuse": 5,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66267026234235, 6.666758448935177]),
            {
              "landuse": 5,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66297066975202, 6.666570898464031]),
            {
              "landuse": 5,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.663331159036524, 6.666374822362596]),
            {
              "landuse": 5,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66418088298341, 6.666093496408814]),
            {
              "landuse": 5,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.662301190774805, 6.667781451335692]),
            {
              "landuse": 5,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66242135386964, 6.666749924033574]),
            {
              "landuse": 5,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66224110889997, 6.66666467370856]),
            {
              "landuse": 5,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([38.662052281647256, 6.666639098998413]),
            {
              "landuse": 5,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([38.65771928598746, 6.663144725163816]),
            {
              "landuse": 5,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([38.65715280357448, 6.66356245474359]),
            {
              "landuse": 5,
              "system:index": "10"
            })]),
    vwetland = ui.import && ui.import("vwetland", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.658036859927726,
            6.662925204193004
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.65822568718044,
            6.662831428233308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66020837595328,
            6.661799889542057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66056028164507,
            6.661782839566303
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66087785558533,
            6.66179136455425
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66106668283805,
            6.6616720127581734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.656637819443624,
            6.663845913550244
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 5
      },
      "color": "#ffff99",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffff99 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.658036859927726, 6.662925204193004]),
            {
              "landuse": 5,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.65822568718044, 6.662831428233308]),
            {
              "landuse": 5,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66020837595328, 6.661799889542057]),
            {
              "landuse": 5,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66056028164507, 6.661782839566303]),
            {
              "landuse": 5,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66087785558533, 6.66179136455425]),
            {
              "landuse": 5,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66106668283805, 6.6616720127581734]),
            {
              "landuse": 5,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.656637819443624, 6.663845913550244]),
            {
              "landuse": 5,
              "system:index": "6"
            })]),
    tgrassland = ui.import && ui.import("tgrassland", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.66032044498226,
            6.661547401863851
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66055218823405,
            6.661470675627958
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.660749598424644,
            6.6613427987582625
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.661161585991266,
            6.661249022496058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66212288944027,
            6.661180821212047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.6638995844298,
            6.6615559268559075
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66453473231033,
            6.661607077455474
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66504113284847,
            6.661590027473015
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66426007436914,
            6.661334273762505
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66109550427445,
            6.661236234674729
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66086376102266,
            6.6612106596814735
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 6
      },
      "color": "#99ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #99ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.66032044498226, 6.661547401863851]),
            {
              "landuse": 6,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66055218823405, 6.661470675627958]),
            {
              "landuse": 6,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.660749598424644, 6.6613427987582625]),
            {
              "landuse": 6,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.661161585991266, 6.661249022496058]),
            {
              "landuse": 6,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66212288944027, 6.661180821212047]),
            {
              "landuse": 6,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.6638995844298, 6.6615559268559075]),
            {
              "landuse": 6,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66453473231033, 6.661607077455474]),
            {
              "landuse": 6,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66504113284847, 6.661590027473015]),
            {
              "landuse": 6,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66426007436914, 6.661334273762505]),
            {
              "landuse": 6,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66109550427445, 6.661236234674729]),
            {
              "landuse": 6,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66086376102266, 6.6612106596814735]),
            {
              "landuse": 6,
              "system:index": "10"
            })]),
    vgrassland = ui.import && ui.import("vgrassland", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            38.66428840562384,
            6.661814877239871
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66451156593775,
            6.66196832959199
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66482913922318,
            6.661635849868645
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.665292624417084,
            6.661533548670172
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.664502982345034,
            6.661516498034745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66407382890265,
            6.661610274896229
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66165340374955,
            6.660911214076959
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66059768601935,
            6.6610476160600305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            38.66017711551485,
            6.661235169293931
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 6
      },
      "color": "#ff99ff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff99ff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([38.66428840562384, 6.661814877239871]),
            {
              "landuse": 6,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66451156593775, 6.66196832959199]),
            {
              "landuse": 6,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66482913922318, 6.661635849868645]),
            {
              "landuse": 6,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([38.665292624417084, 6.661533548670172]),
            {
              "landuse": 6,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([38.664502982345034, 6.661516498034745]),
            {
              "landuse": 6,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66407382890265, 6.661610274896229]),
            {
              "landuse": 6,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66165340374955, 6.660911214076959]),
            {
              "landuse": 6,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66059768601935, 6.6610476160600305]),
            {
              "landuse": 6,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([38.66017711551485, 6.661235169293931]),
            {
              "landuse": 6,
              "system:index": "8"
            })]);
var image = L8.filterBounds(roi)
            .filterDate('2019-01-01','2020-01-01')
            .filterMetadata('CLOUD_COVER','less_than',1)
            .mean()
            .clip(roi)
Map.addLayer(image, {bands:['B4','B3','B2']},'TrueColor')
//Merge into one FeatureCollection and print details to consloe
var classNames = tForest.merge(tbareland).merge(tFarmland).merge(tbuiltup).merge(tgrassland).merge(twetland);
print(classNames);
//Extract training data from select bands of the image, print to console
var bands = ['B2', 'B3', 'B4', 'B5', 'B6', 'B7'];
var training = image.select(bands).sampleRegions({
  collection: classNames,
  properties: ['landuse'],
  scale: 30
});
print(training);
//Train classifier - e.g. cart, randomForest, svm
var classifier = ee.Classifier.smileCart().train({
  features: training,
  classProperty: 'landuse',
  inputProperties: bands
});
//Run the classification
var classified = image.select(bands).classify(classifier);
//Centre the map on your training data coverage
Map.centerObject(classNames, 11);
//Add the classification to the map view, specify colours for classes
Map.addLayer(classified,
{min: 0, max: 6, palette: ['456c37', 'f1c63d', '5cc23f','ff2567','589918','31c1ff']},
'classification');
//Merge into one FeatureCollection
var valNames = vForest.merge(vbareland).merge(vFarmland).merge(vbuiltup).merge(vgrassland).merge(vwetland);
var validation = classified.sampleRegions({
  collection: valNames,
  properties: ['landuse'],
  scale: 30,
});
print(validation);
//Compare the landcover of your validation data against the classification result
var testAccuracy = validation.errorMatrix('landcover', 'classification');
//Print the error matrix to the console
print('Validation error matrix: ', testAccuracy);
//Print the overall accuracy to the console
print('Validation overall accuracy: ', testAccuracy.accuracy());
Export.image.toDrive({
  image:classified,
  description:'Arbegon_LULC',
  scale:30,
  region:roi
})
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Classification',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette =['456c37', 'f1c63d', '5cc23f','ff2567','589918','31c1ff'];
// name of the legend
var names = ['Forest','Bare land','Farm land','Built up','Grass land','Wet land'];
// Add color and and names
for (var i = 0; i < 6; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend);
// Create the title label.
var title = ui.Label('Land use/cover Map of Arbegona woreda, Garamba-Gorante watershed Year of 2020');
title.style().set('position', 'top-center');
Map.add(title);
// Create the title label.
var title = ui.Label('Prepared by: Afework Mekebriaw, National GIS and RS specilaist. MoA-SLMP-RLLP Ethiopia');
title.style().set('position', 'bottom-right');
Map.add(title);