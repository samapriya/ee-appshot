var Madrid = ui.import && ui.import("Madrid", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -3.8869971420460514,
                40.50920193614787
              ],
              [
                -3.8869971420460514,
                40.28696052880801
              ],
              [
                -3.5203284408741764,
                40.28696052880801
              ],
              [
                -3.5203284408741764,
                40.50920193614787
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-3.8869971420460514, 40.50920193614787],
          [-3.8869971420460514, 40.28696052880801],
          [-3.5203284408741764, 40.28696052880801],
          [-3.5203284408741764, 40.50920193614787]]], null, false),
    ethiopia = ui.import && ui.import("ethiopia", "table", {
      "id": "users/afotesfaye/Ethio_Region"
    }) || ee.FeatureCollection("users/afotesfaye/Ethio_Region");
var dateFilter_before = ee.Filter.date('2018-1-6','2018-1-9');
var S2before = ee.ImageCollection("COPERNICUS/S2").filter(dateFilter_before)
                                            .filterBounds(ethiopia)
                                            .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
var img_before = ee.Image(S2before.median()).clip(ethiopia);
var dateFilter_after = ee.Filter.date('2021-1-9','2021-1-12');
var S2after = ee.ImageCollection("COPERNICUS/S2").filter(dateFilter_after)
                                            .filterBounds(ethiopia)
                                            .filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 10)
var img_after = ee.Image(S2after.median()).clip(ethiopia);
// make left and right maps
var leftMap = ui.Map();
var rightMap = ui.Map();
leftMap.addLayer(img_before, {min:0, max: 4000, bands:"B4,B3,B2"}, 'S2 Before');
rightMap.addLayer(img_after, {min:0, max: 4000, bands:"B4,B3,B2"}, 'S2 After')
leftMap.setControlVisibility(false)
rightMap.setControlVisibility(false)
leftMap.centerObject(ethiopia)
rightMap.centerObject(ethiopia)
// link the maps
var linkedMaps = ui.Map.Linker([leftMap, rightMap]);
// Create a SplitPanel which holds the linked maps side-by-side.
var splitPanel = ui.SplitPanel({
  firstPanel: linkedMaps.get(0),
  secondPanel: linkedMaps.get(1),
  orientation: 'horizontal',
  wipe: true,
  style: {stretch: 'both'}
});
// clear the root and add the splitPanel
ui.root.clear();
ui.root.add(splitPanel);