var roi = ui.import && ui.import("roi", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -80.3349414319347,
                -0.60945986668288
              ],
              [
                -80.3349414319347,
                -1.0282699172769443
              ],
              [
                -79.75541262334094,
                -1.0282699172769443
              ],
              [
                -79.75541262334094,
                -0.60945986668288
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-80.3349414319347, -0.60945986668288],
          [-80.3349414319347, -1.0282699172769443],
          [-79.75541262334094, -1.0282699172769443],
          [-79.75541262334094, -0.60945986668288]]], null, false);
/**
Author: Adrian Rodriguez Meza (adr.rod44@gmail.com)
Este código es gratuito y abierto.
Al usar este código y cualquier dato derivado de él,
acepta citar la siguiente referencia en las publicaciones derivadas de ellos:
Rodríguez, Adrián; 2020. 
    Detección de cambios sobre la superficie terrestre utilizando imágenes Radar banda C y
    el procesamiento en la nube.;
    "https://code.earthengine.google.com/8dc7e51a74b71417ef39876e7758828e"
Bibliography:
    -- Appliedsciences.nasa.gov. 2020. Introducción Al Radar De Apertura Sintética | 
        NASA Applied Sciences. [online] Available at:
        https://appliedsciences.nasa.gov/join-mission/training/spanish/introduccion-al-radar-de-apertura-sintetica [Accessed 25 November 2020].
    -- Appliedsciences.nasa.gov. 2020. Mapeo Y Monitoreo De Los Bosques Con Datos SAR |
        NASA Applied Sciences. [online] Available at:
        https://appliedsciences.nasa.gov/join-mission/training/spanish/mapeo-y-monitoreo-de-los-bosques-con-datos-sar [Accessed 25 November 2020].
    -- PhD. Minerva Singh, Bestselling Udemy Instructor & Data Scientist(Cambridge Uni)
        https://www.udemy.com/share/101Z4GCUMcdl5bRHQ=/
**/
//Parametros del Sensor SAR
// Creamos un titulo
{
var title = ui.Label('Parametros del Sensor SAR');
title.style().set({
  position: 'top-center',
  fontWeight: 'bold'
});
Map.add(title);
}
//Centramos el Mapa
Map.centerObject(roi,10);
//Funcion para cortar
var corte = function(img){
  var img_corte = img.clip(roi);
  return img_corte; 
};
//Variables inicializadoras
var fecha_i = '2020-10-01';
var fecha_f = '2020-10-31';
//Carga de Datos
//Órbita desendente
{
//Se Carga Sentinel-1 C-band SAR,  VV, decending
var VV_decending = ee.ImageCollection('COPERNICUS/S1_GRD')
.filter(ee.Filter.eq('instrumentMode', 'IW'))
.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'))
.filterMetadata('resolution_meters', 'equals' , 10)
.filterBounds(roi)
.select('VV');
//print('VV decending', VV_decending);
VV_decending = VV_decending.map(corte);
//Se Carga Sentinel-1 C-band SAR, VH, descending
var VH_decending = ee.ImageCollection('COPERNICUS/S1_GRD')
.filter(ee.Filter.eq('instrumentMode', 'IW'))
.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'))
.filterMetadata('resolution_meters', 'equals' , 10)
.filterBounds(roi)
.select('VH');
//print('VH desending', VH_decending);
var VH_decending = VH_decending.map(corte);
//Filter by date
VV_decending = VV_decending.filterDate(fecha_i, fecha_f).mean();
print ("VV_decending", VV_decending);
VH_decending = VH_decending.filterDate(fecha_i, fecha_f).mean();
print ("VH_decending", VH_decending);
// Display map
Map.addLayer(VV_decending, {min:-15,max:0}, 'Polarizacion VV decending', 1);
Map.addLayer(VH_decending, {min:-25,max:0}, 'Polarizacion VH decending', 1);
}
//Órbita acentende
{
//Se Carga Sentinel-1 C-band SAR,  VV, acending
var VV_acending = ee.ImageCollection('COPERNICUS/S1_GRD')
.filter(ee.Filter.eq('instrumentMode', 'IW'))
.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'))
.filterMetadata('resolution_meters', 'equals' , 10)
.filterBounds(roi)
.select('VV');
//print('VV desending', VV_acending);
VV_acending = VV_acending.map(corte);
//Se Carga Sentinel-1 C-band SAR, VH, acending
var VH_acending = ee.ImageCollection('COPERNICUS/S1_GRD')
.filter(ee.Filter.eq('instrumentMode', 'IW'))
.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'))
.filterMetadata('resolution_meters', 'equals' , 10)
.filterBounds(roi)
.select('VH');
//print('VH acending', VH_acending);
var VH_acending = VH_acending.map(corte);
//Filter by date
VV_acending = VV_acending.filterDate(fecha_i, fecha_f).mean();
print ("VV_acending", VV_acending);
VH_acending = VH_acending.filterDate(fecha_i, fecha_f).mean();
print ("VH_acending", VH_acending);
// Display map
Map.addLayer(VV_acending, {min:-15,max:0}, 'Polarizacion VV acending', 1);
Map.addLayer(VH_acending, {min:-25,max:0}, 'Polarizacion VH acending', 1);
}
//Se aplica el filtro para reducir el spackle
{
var SMOOTHING_RADIUS = 25;
var VV_acending_filtered = VV_acending.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters');
var VH_acending_filtered = VH_acending.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters');
var VV_decending_filtered = VV_decending.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters');
var VH_decending_filtered = VV_decending.focal_mean(SMOOTHING_RADIUS, 'circle', 'meters');
//Display filtered images
Map.addLayer(VV_decending_filtered, {min:-15,max:0}, 'VV decending Filtered',0);
Map.addLayer(VH_decending_filtered, {min:-25,max:0}, 'VH decending Filtered',0);
Map.addLayer(VV_acending_filtered, {min:-15,max:0}, 'VV acending Filtered',0);
Map.addLayer(VH_acending_filtered, {min:-25,max:0}, 'VH acending Filtered',0);
}