var Table = ui.import && ui.import("Table", "table", {
      "id": "projects/ee-ravindra1364/assets/Sone_HBZ_River"
    }) || ee.FeatureCollection("projects/ee-ravindra1364/assets/Sone_HBZ_River");
// // Load Sentinel-2 Surface Reflectance Collection ... total milakar 21 river hai isme
// //var polygon = Table;
var bufferedPolygon = Table.map(function(feature) {
  return feature.buffer(5000);
});
// // Load Sentinel-2 SR image collection
// var s2 = ee.ImageCollection('COPERNICUS/S2_SR')
//   .filterBounds(polygon)
//   .filterDate('2022-03-01', '2022-06-30')
//   .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10))
//   .select(['B2', 'B3', 'B4', 'B7', 'B8', 'B11'])  // Add B3 for NDWI, and B3/B11 for MNDWI
//   .median();
// // Calculate MNDWI = (Green - SWIR1) / (Green + SWIR1)
// var mndwi = s2.expression(
//   '((GREEN - SWIR1) / (GREEN + SWIR1))', {
//     'GREEN': s2.select('B3'),   // Green band
//     'SWIR1': s2.select('B11')   // SWIR1 band
//   }).rename('MNDWI');
// // Add to Map
// Map.centerObject(polygon, 10);
// Map.addLayer(mndwi.clip(polygon), {min: -1, max: 1, palette: ['white', 'orange', 'blue',  'violet']}, 'MNDWI');
// USER INPUT: Define start and end year-month
// ---------- USER INTERFACE ---------- //
// Define year and month options
// ---------- UI WIDGETS ---------- //
// ---------- UI WIDGETS ---------- //
// Use plain JS arrays for dropdowns
// ---------- UI WIDGETS ---------- //
var years = ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'];
var months = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
var startYearSelect = ui.Select({items: years, value: '2017'});
var startMonthSelect = ui.Select({items: months, value: '03'});
var endYearSelect = ui.Select({items: years, value: '2025'});
var endMonthSelect = ui.Select({items: months, value: '04'});
var runButton = ui.Button({label: 'Generate MNDWI', style: {stretch: 'horizontal'}});
var panel = ui.Panel({
  widgets: [
    ui.Label('🔍 Select Time Range for MNDWI - SONE HBZ region', {fontWeight: 'bold', fontSize: '18px'}),
    ui.Label('Start Year:'), startYearSelect,
    ui.Label('Start Month:'), startMonthSelect,
    ui.Label('End Year:'), endYearSelect,
    ui.Label('End Month:'), endMonthSelect,
    runButton
  ],
  style: {width: '300px', padding: '10px'}
});
ui.root.insert(0, panel);
// ---------- FUNCTIONALITY ---------- //
function generateMNDWI() {
  Map.clear();
  var startYear = parseInt(startYearSelect.getValue());
  var startMonth = parseInt(startMonthSelect.getValue());
  var endYear = parseInt(endYearSelect.getValue());
  var endMonth = parseInt(endMonthSelect.getValue());
  var startDate = ee.Date.fromYMD(startYear, startMonth, 1);
  var endDate = ee.Date.fromYMD(endYear, endMonth, 28);
  var buffered = Table.map(function(f) { return f.buffer(5000); });
  var s2col = ee.ImageCollection('COPERNICUS/S2_SR')
    .filterBounds(buffered)
    .filterDate(startDate, endDate)
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10))
    .select(['B3', 'B11']);
  // Debug: print size of image collection
  s2col.size().evaluate(function(size) {
    if (size === 0) {
      ui.alert('⚠️ No Sentinel-2 images found for selected dates and area.\nTry changing the time range or check polygon location.');
      return;
    }
    var s2 = s2col.median();
    var mndwi = s2.expression(
      '((GREEN - SWIR1) / (GREEN + SWIR1))', {
        'GREEN': s2.select('B3'),
        'SWIR1': s2.select('B11')
      }).rename('MNDWI');
    Map.centerObject(buffered, 11);
   // Map.addLayer(buffered, {color: 'red'}, 'Buffered Polygon');
    Map.addLayer(mndwi.clip(buffered), {
      min: -1, max: 1,
      palette: ['white', 'white', 'orange', 'blue',  'violet']
    }, 'MNDWI');
  });
}
runButton.onClick(generateMNDWI);
Map.setOptions('SATELLITE');