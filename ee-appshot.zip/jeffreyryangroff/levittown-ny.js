var zip_11756 = ui.import && ui.import("zip_11756", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -73.52623437143944,
                40.707715708798794
              ],
              [
                -73.5249039964284,
                40.707878367654715
              ],
              [
                -73.51885293589498,
                40.706560819493234
              ],
              [
                -73.51278041770018,
                40.70478778144522
              ],
              [
                -73.50550627046255,
                40.70215253677013
              ],
              [
                -73.50237345188776,
                40.707504251688114
              ],
              [
                -73.50226079708386,
                40.709517063597694
              ],
              [
                -73.50257730228253,
                40.71179012274047
              ],
              [
                -73.50226616358015,
                40.71366876409797
              ],
              [
                -73.50119328050687,
                40.7152463971869
              ],
              [
                -73.5004208046941,
                40.71485605845977
              ],
              [
                -73.49997019380339,
                40.71392899481088
              ],
              [
                -73.4975025627349,
                40.71386393722802
              ],
              [
                -73.49754547805782,
                40.713180828769616
              ],
              [
                -73.49527096594244,
                40.71296938901693
              ],
              [
                -73.49546408489556,
                40.71015554992236
              ],
              [
                -73.49458432077535,
                40.71009048865249
              ],
              [
                -73.49522245789143,
                40.709338429084184
              ],
              [
                -73.49775446194451,
                40.70969626932345
              ],
              [
                -73.49801195388204,
                40.707272677384225
              ],
              [
                -73.4971107321004,
                40.70689855801821
              ],
              [
                -73.49627388330316,
                40.70631297566083
              ],
              [
                -73.49438560909402,
                40.70662203365783
              ],
              [
                -73.49440706675534,
                40.70527192764526
              ],
              [
                -73.49219692762404,
                40.70538579306471
              ],
              [
                -73.49090172084732,
                40.71550412359582
              ],
              [
                -73.48914219260848,
                40.72200940693482
              ],
              [
                -73.48871303937926,
                40.7223021297377
              ],
              [
                -73.48901344663977,
                40.72260298238794
              ],
              [
                -73.48894907365553,
                40.7233591735854
              ],
              [
                -73.4896338011589,
                40.72533729426764
              ],
              [
                -73.49757313589942,
                40.72563000243398
              ],
              [
                -73.49645139453293,
                40.73244819354597
              ],
              [
                -73.4973097009912,
                40.73244819354595
              ],
              [
                -73.49936963649117,
                40.73283842911288
              ],
              [
                -73.50042106190256,
                40.732870948640134
              ],
              [
                -73.50016356996508,
                40.73435057031669
              ],
              [
                -73.50031377359528,
                40.73452942345504
              ],
              [
                -73.49943400947552,
                40.734708276112556
              ],
              [
                -73.49943400947552,
                40.73517979445048
              ],
              [
                -73.50185872522013,
                40.73521231283342
              ],
              [
                -73.5022878784493,
                40.73596023125287
              ],
              [
                -73.5021805901419,
                40.739211952716865
              ],
              [
                -73.50374699942813,
                40.73924446912886
              ],
              [
                -73.50396157604251,
                40.74091904285733
              ],
              [
                -73.50441218693317,
                40.74091904285739
              ],
              [
                -73.50424052564125,
                40.7425412248263
              ],
              [
                -73.50514174742239,
                40.742817599987916
              ],
              [
                -73.50602151154197,
                40.74333783247074
              ],
              [
                -73.50977660229637,
                40.7428663719564
              ],
              [
                -73.50975514463471,
                40.74421571555873
              ],
              [
                -73.51080657004599,
                40.74415068757938
              ],
              [
                -73.51166487650414,
                40.74356543290297
              ],
              [
                -73.51277423906129,
                40.743565432903125
              ],
              [
                -73.5127635102308,
                40.742866371956765
              ],
              [
                -73.51875530366692,
                40.74297204443266
              ],
              [
                -73.51874457486264,
                40.743654847146296
              ],
              [
                -73.52104054463814,
                40.74367110426885
              ],
              [
                -73.52100835813025,
                40.74298830173016
              ],
              [
                -73.53542449161449,
                40.74318338888343
              ],
              [
                -73.54194873472045,
                40.74332375202691
              ],
              [
                -73.54562495328992,
                40.74352357564742
              ],
              [
                -73.54399417102354,
                40.73822353160044
              ],
              [
                -73.54314121822762,
                40.73421159696397
              ],
              [
                -73.54078087547111,
                40.72900837526887
              ],
              [
                -73.5378197181929,
                40.724162509181134
              ],
              [
                -73.53666477104684,
                40.722440124921846
              ],
              [
                -73.53533822552572,
                40.72078277662799
              ],
              [
                -73.53182711571651,
                40.71636214835895
              ],
              [
                -73.52972417514508,
                40.71340202210041
              ],
              [
                -73.52783599068715,
                40.71037680336404
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-73.52623437143944, 40.707715708798794],
          [-73.5249039964284, 40.707878367654715],
          [-73.51885293589498, 40.706560819493234],
          [-73.51278041770018, 40.70478778144522],
          [-73.50550627046255, 40.70215253677013],
          [-73.50237345188776, 40.707504251688114],
          [-73.50226079708386, 40.709517063597694],
          [-73.50257730228253, 40.71179012274047],
          [-73.50226616358015, 40.71366876409797],
          [-73.50119328050687, 40.7152463971869],
          [-73.5004208046941, 40.71485605845977],
          [-73.49997019380339, 40.71392899481088],
          [-73.4975025627349, 40.71386393722802],
          [-73.49754547805782, 40.713180828769616],
          [-73.49527096594244, 40.71296938901693],
          [-73.49546408489556, 40.71015554992236],
          [-73.49458432077535, 40.71009048865249],
          [-73.49522245789143, 40.709338429084184],
          [-73.49775446194451, 40.70969626932345],
          [-73.49801195388204, 40.707272677384225],
          [-73.4971107321004, 40.70689855801821],
          [-73.49627388330316, 40.70631297566083],
          [-73.49438560909402, 40.70662203365783],
          [-73.49440706675534, 40.70527192764526],
          [-73.49219692762404, 40.70538579306471],
          [-73.49090172084732, 40.71550412359582],
          [-73.48914219260848, 40.72200940693482],
          [-73.48871303937926, 40.7223021297377],
          [-73.48901344663977, 40.72260298238794],
          [-73.48894907365553, 40.7233591735854],
          [-73.4896338011589, 40.72533729426764],
          [-73.49757313589942, 40.72563000243398],
          [-73.49645139453293, 40.73244819354597],
          [-73.4973097009912, 40.73244819354595],
          [-73.49936963649117, 40.73283842911288],
          [-73.50042106190256, 40.732870948640134],
          [-73.50016356996508, 40.73435057031669],
          [-73.50031377359528, 40.73452942345504],
          [-73.49943400947552, 40.734708276112556],
          [-73.49943400947552, 40.73517979445048],
          [-73.50185872522013, 40.73521231283342],
          [-73.5022878784493, 40.73596023125287],
          [-73.5021805901419, 40.739211952716865],
          [-73.50374699942813, 40.73924446912886],
          [-73.50396157604251, 40.74091904285733],
          [-73.50441218693317, 40.74091904285739],
          [-73.50424052564125, 40.7425412248263],
          [-73.50514174742239, 40.742817599987916],
          [-73.50602151154197, 40.74333783247074],
          [-73.50977660229637, 40.7428663719564],
          [-73.50975514463471, 40.74421571555873],
          [-73.51080657004599, 40.74415068757938],
          [-73.51166487650414, 40.74356543290297],
          [-73.51277423906129, 40.743565432903125],
          [-73.5127635102308, 40.742866371956765],
          [-73.51875530366692, 40.74297204443266],
          [-73.51874457486264, 40.743654847146296],
          [-73.52104054463814, 40.74367110426885],
          [-73.52100835813025, 40.74298830173016],
          [-73.53542449161449, 40.74318338888343],
          [-73.54194873472045, 40.74332375202691],
          [-73.54562495328992, 40.74352357564742],
          [-73.54399417102354, 40.73822353160044],
          [-73.54314121822762, 40.73421159696397],
          [-73.54078087547111, 40.72900837526887],
          [-73.5378197181929, 40.724162509181134],
          [-73.53666477104684, 40.722440124921846],
          [-73.53533822552572, 40.72078277662799],
          [-73.53182711571651, 40.71636214835895],
          [-73.52972417514508, 40.71340202210041],
          [-73.52783599068715, 40.71037680336404]]]);
// NAIP: National Agriculture Imagery Program
// U. S. Department of Agriculture, Farm Service Agency
// Public Domain
var colors = {'transparent': '#11ffee00', 'gray': '#F8F9FA'};
var TITLE_STYLE = {
  fontWeight: '100',
  fontSize: '32px',
  padding: '10px',
  color: '#616161',
  backgroundColor: colors.transparent,
};
var PARAGRAPH_STYLE = {
  fontSize: '14px',
  fontWeight: '50',
  color: '#9E9E9E',
  padding: '8px',
  backgroundColor: colors.transparent,
};
var LABEL_STYLE = {
  fontWeight: '100',
  textAlign: 'center',
  fontSize: '16px',
  color: '#616161',
  backgroundColor: colors.transparent,
};
var SLIDER_STYLE = {
  fontWeight: '100',
  textAlign: 'center',
  color: '#616161',
  backgroundColor: colors.transparent,
};
var BORDER_STYLE = '4px solid rgba(97, 97, 97, 0.05)';
function makeSidePanel() {
  // Create the base side panel, into which other widgets will be added
  var mainPanel = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical', true),
    style: {
      stretch: 'horizontal',
      height: '100%',
      width: '400px',
      backgroundColor: colors.gray,
      border: BORDER_STYLE
    }
  });
  // Add the app title to the side panel
  var titleLabel = ui.Label('Levittown, NY', TITLE_STYLE);
  mainPanel.add(titleLabel);
  return mainPanel;
}
/** Returns a ui.Map with some UI configuration in place */
function makeMapPanel() {
  var map = ui.Map();
  map.style().set('cursor', 'hand');
  // Don't show the layer list for this app.
  map.setControlVisibility({layerList: false});
  return map;
}
// Clear the default UI since we're adding our own side and map panels.
ui.root.clear();
// Create the app's two panels and add them to the ui.root
var sidePanel = makeSidePanel();
var mapPanel = makeMapPanel();
// Use a SplitPanel so it's possible to resize the two panels.
ui.root.add(ui.SplitPanel(sidePanel, mapPanel));
// add NAIP imagery to the map
var NAIP = ee.ImageCollection('USDA/NAIP/DOQQ')
        .filter(ee.Filter.date('2017-01-01', '2017-12-31'));
var NAIP_rgb = NAIP.select(['R', 'G', 'B']);
var trueColorVis = {
  min: 0.0,
  max: 255.0,
};
var bbox = zip_11756.geometries().get(0);
var NAIP_levitt = NAIP_rgb.filterBounds(bbox);
var NAIP_levitt = NAIP_levitt.reduce(ee.Reducer.median()).clip(bbox);
// print(NAIP_levitt);
mapPanel.addLayer(NAIP_levitt, trueColorVis, 'NAIP, Levittown, NY');
// Center the map on the image.
mapPanel.centerObject(NAIP_levitt,14);
mapPanel.setControlVisibility(false);
mapPanel.setControlVisibility({scaleControl: true, zoomControl: true});
// create custom style
var Style = [
    {
        "featureType": "landscape.natural",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "color": "#e0efef"
            }
        ]
    },
    {
        "featureType": "poi",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "poi",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "hue": "#1900ff"
            },
            {
                "color": "#c0e8c1"
            }
        ]
    },
    {
        "featureType": "poi.park",
        "elementType": "all",
        "stylers": [
            {
                "saturation": "16"
            }
        ]
    },
    {
        "featureType": "road",
        "elementType": "geometry",
        "stylers": [
            {
                "lightness": 100
            },
            {
                "visibility": "simplified"
            }
        ]
    },
    {
        "featureType": "road",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "transit.line",
        "elementType": "geometry",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "lightness": 700
            }
        ]
    },
    {
        "featureType": "transit.station",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "water",
        "elementType": "all",
        "stylers": [
            {
                "color": "#7dcdcd"
            }
        ]
    }
];
mapPanel.setOptions('Style', {Style: Style});
// create an empty image into which to paint the features, cast to byte.
var empty = ee.Image().byte();
// paint polygon edges
var levittown = empty.paint({
  featureCollection: zip_11756,
  width: 3
});
mapPanel.addLayer(levittown, {palette: '#fcab4e'}, 'edges');
var slider = ui.Slider({style: {stretch: 'horizontal'}});
mapPanel.layers().get(0).setOpacity(1)
slider.setValue(0);  // Set a default value.
slider.onChange(function(value) {
  mapPanel.layers().get(0).setOpacity(1-value);
});
var checkbox = ui.Checkbox('Show Boarder', true);
checkbox.onChange(function(checked) {
  // shows or hides a map layer based on the checkbox's value.
  mapPanel.layers().get(1).setShown(checked);
});
var text1 = ui.Label('Transparency');
text1.style().set(LABEL_STYLE);
checkbox.style().set(LABEL_STYLE);
slider.style().set(SLIDER_STYLE);
var controlPanel = ui.Panel({widgets: [checkbox, text1, slider], style: {position: 'bottom-right'}});
mapPanel.add(controlPanel);
// Add text to the side panel
  var p1 ='In 1947, Levitt & Sons Realty Corporation, owned and managed by Abraham and his sons William and Alfred, broke ground on a planned community on Long Island, NY that what would become the architype of future tract housing developments in the United States. Eventually, over 17,000 homes would be built on what was once a 1000-acre potato farm. Many of these homes would be purchased, for as little as $7,000, by GIs returning from war and eager to start families. At the peak of construction, 30 homes were being finished every day. This was possible due to assembly line home building practices pioneered by William Levitt, who was called the Henry Ford of home building. However, unlike an automobile factory where the car moves down the assembly line, Levittown was built by specialized work crews moving from home-to-home. When the framing crew was finished, the electric and plumbing crews would arrive. To save time, the homes were built on concrete slabs using many premanufactured parts and only a few different designs were constructed.';
  var p2 ='The Levitt’s invented modern suburbia. Levittown had green spaces, swimming pools, shopping areas, a grocery store, and community covenants. Roads were built in curvilinear fashion instead of being planned on grids. Homes where sold complete with landscaping and modern appliances. Some homes even included state-of-the-art radiant floor heating. However, the birth of modern American suburbia was not without a darker side. Discriminatory housing practices where adopted by the Levitts. Homes were only sold to and allowed to be occupied by “members of the Caucasian race.”  In 1953, Levittown was the largest community in the United States without any black residents.';
  var p3 ='Levitt & Sons went on to construct six more “Levittowns” in the next two decades in PA, MD, NJ and Puerto Rico.';
  var p4 ='Data: The boarder of Levittown, NY corresponds to the extent of zip code 11756. High resolution (1 meter) satellite imagery provided by the National Agriculture Imagery Program (NAIP, 2017)';
  var label1 = ui.Label(p1, PARAGRAPH_STYLE);
  var label2 = ui.Label(p2, PARAGRAPH_STYLE);
  var label3 = ui.Label(p3, PARAGRAPH_STYLE);
  var label4 = ui.Label(p4, PARAGRAPH_STYLE);
  sidePanel.add(label1);
  sidePanel.add(label2);
  sidePanel.add(label3);
  sidePanel.add(label4);