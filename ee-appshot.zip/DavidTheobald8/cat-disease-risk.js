// display human modification maps
var lse = require('users/DavidTheobald8/modules:lse')
//user variables 
/*
var risk100 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_buf100_30")
var risk100 = risk100.mask(risk100.gt(0.0001))
var risk500 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_buf500_30")
var risk500 = risk500.mask(risk500.gt(0.0001))
var risk1000 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_buf1000_30")
var risk1000 = risk1000.mask(risk1000.gt(0.0001))
*/
//ICLUS
var riskIa100 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_2050buf100_90")
var riskIa100 = riskIa100.mask(riskIa100.gt(0.005))
var riskIa500 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_2050buf500_90")
var riskIa500 = riskIa500.mask(riskIa500.gt(0.005))
var riskIa1000 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_2050buf1000_90")
var riskIa1000 = riskIa1000.mask(riskIa1000.gt(0.005))
var riskIb100 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_2040buf100_90")
var riskIb100 = riskIb100.mask(riskIb100.gt(0.005))
var riskIb500 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_2040buf500_90")
var riskIb500 = riskIb500.mask(riskIb500.gt(0.005))
var riskIb1000 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_2040buf1000_90")
var riskIb1000 = riskIb1000.mask(riskIb1000.gt(0.005))
var riskIc100 = ee.Image("users/DavidTheobald8/CSUcats/risk_US2030buf100_90")
var riskIc100 = riskIc100.mask(riskIc100.gt(0.005))
var riskIc500 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_2030buf500_90")
var riskIc500 = riskIc500.mask(riskIc500.gt(0.005))
var riskIc1000 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_2030buf1000_90")
var riskIc1000 = riskIc1000.mask(riskIc1000.gt(0.005))
var riskId100 = ee.Image("users/DavidTheobald8/CSUcats/risk_US2010buf100_90")
var riskId100 = riskId100.mask(riskId100.gt(0.005))
var riskId500 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_2010buf500_90")
var riskId500 = riskId500.mask(riskId500.gt(0.005))
var riskId1000 = ee.Image("users/DavidTheobald8/CSUcats/risk_US_2010buf1000_90")
var riskId1000 = riskId1000.mask(riskId1000.gt(0.005))
var palette = lse.colorPalette('viridisMagma', 5) // 'colorBrewerRdYlGn',
var visParams = {
          "min": [0.0],
          "max": [1.0],
          "palette": palette //["0c0c0c","071aff","ff0000","ffbd03","fbff05","fffdfd"]
        }
var imageRiskId100 = ee.ImageCollection([riskId100.visualize(visParams)]).mosaic()
var imageRiskId500 = ee.ImageCollection([riskId500.visualize(visParams)]).mosaic()
var imageRiskId1000 = ee.ImageCollection([riskId1000.visualize(visParams)]).mosaic()
var imageRiskIc100 = ee.ImageCollection([riskIc100.visualize(visParams)]).mosaic()
var imageRiskIc500 = ee.ImageCollection([riskIc500.visualize(visParams)]).mosaic()
var imageRiskIc1000 = ee.ImageCollection([riskIc1000.visualize(visParams)]).mosaic()
var imageRiskIb100 = ee.ImageCollection([riskIb100.visualize(visParams)]).mosaic()
var imageRiskIb500 = ee.ImageCollection([riskIb500.visualize(visParams)]).mosaic()
var imageRiskIb1000 = ee.ImageCollection([riskIb1000.visualize(visParams)]).mosaic()
var imageRiskIa100 = ee.ImageCollection([riskIa100.visualize(visParams)]).mosaic()
var imageRiskIa500 = ee.ImageCollection([riskIa500.visualize(visParams)]).mosaic()
var imageRiskIa1000 = ee.ImageCollection([riskIa1000.visualize(visParams)]).mosaic()
// Some pre-set locations of interest that will be loaded into a pulldown menu.
var locationDict = {
  'CA Foothill Ranch WUI': {lat: 33.687, lon: -117.658, zoom: 12},
  'CO Boulder WUI': {lat: 40.024, lon: -105.45, zoom: 12},
  'FL Florida Panther NWR': {lat: 26.193, lon: -81.508, zoom: 11},
  'North America': {lon: -102.58, lat: 40.0, zoom: 5},
};
/*
 * Map panel configuration
 */
// Create a map panel.
var mapPanel = ui.Map();
// Take all tools off the map except the zoom and mapTypeControl tools.
mapPanel.setControlVisibility(
    {all: true, zoomControl: true, mapTypeControl: true});
// Center the map
var defaultLocation = locationDict['North America'];
mapPanel.setCenter(
    defaultLocation.lon, defaultLocation.lat, defaultLocation.zoom);
// Add these to the interface.
ui.root.widgets().reset([mapPanel]);
ui.root.setLayout(ui.Panel.Layout.flow('horizontal'));
/*
mapPanel.add(ui.Map.Layer(imageRisk100, {}, 'Risk buffered by 100 m',true));
mapPanel.add(ui.Map.Layer(imageRisk500, {}, 'Risk buffered by 500 m',true));
mapPanel.add(ui.Map.Layer(imageRisk1000, {}, 'Risk buffered by 1000 m',true));
*/
mapPanel.add(ui.Map.Layer(imageRiskId100, {}, 'Risk 2010 buffered by 100 m',false));
mapPanel.add(ui.Map.Layer(imageRiskId500, {}, 'Risk 2010 buffered by 500 m',true));
mapPanel.add(ui.Map.Layer(imageRiskId1000, {}, 'Risk 2010 buffered by 1000 m',false));
mapPanel.add(ui.Map.Layer(imageRiskIc100, {}, 'Risk 2030 buffered by 100 m',false));
mapPanel.add(ui.Map.Layer(imageRiskIc500, {}, 'Risk 2030 buffered by 500 m',false));
mapPanel.add(ui.Map.Layer(imageRiskIc1000, {}, 'Risk 2030 buffered by 1000 m',false));
mapPanel.add(ui.Map.Layer(imageRiskIb100, {}, 'Risk 2040 buffered by 100 m',false));
mapPanel.add(ui.Map.Layer(imageRiskIb500, {}, 'Risk 2040 buffered by 500 m',true));
mapPanel.add(ui.Map.Layer(imageRiskIb1000, {}, 'Risk 2040 buffered by 1000 m',false));
mapPanel.add(ui.Map.Layer(imageRiskIa100, {}, 'Risk 2050 buffered by 100 m',false));
mapPanel.add(ui.Map.Layer(imageRiskIa500, {}, 'Risk 2050 buffered by 500 m',true));
mapPanel.add(ui.Map.Layer(imageRiskIa1000, {}, 'Risk 2050 buffered by 1000 m',false));
/*
 * Additional component configuration
 */
// Add a title and some explanatory text to a side panel.
var header = ui.Label('Cat disease risk models', {fontSize: '22px', color: '141414'});
var text = ui.Label(
    'The risk model calculates the density (likelihood) of encountering a domestic cat, calculated as the product of the proportions of: residential buildings within the buffer distance, residences that are occupied, households that have a cat, the number of cats per household, and cats that have outdoor access.',
    {fontSize: '12px'});
var toolPanel = ui.Panel([header, text, ], 'flow', {width: '300px'});
ui.root.widgets().add(toolPanel);
// Create the legend.
// Define a panel for the legend and give it a tile.
var legendPanel = ui.Panel({
  style:
      {fontWeight: 'bold', fontSize: '11px', margin: '0 0 0 8px', padding: '0'}
});
toolPanel.add(legendPanel);
function setLegend(legend) {
  // Loop through all the items in a layer's key property,
  // creates the item, and adds it to the key panel.
//  keyPanel.clear();
  for (var i = 0; i < legend.length; i++) {
    var item = legend[i];
    var name = Object.keys(item)[0];
    var color = item[name];
    var colorBox = ui.Label('', {
      backgroundColor: color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0'
    });
    // Create the label with the description text.
    var description = ui.Label(name, {margin: '0 0 4px 6px'});
    keyPanel.add(
        ui.Panel([colorBox, description], ui.Panel.Layout.Flow('horizontal')));
  }
}
// Set the initial legend.
// Define an area for the legend key itself.
// This area will be replaced every time the layer pulldown is changed.
var keyPanel = ui.Panel();
legendPanel.add(keyPanel);
// viridisMagma
setLegend([
  {'1.0 (max)': 'FCFDBF'}, 
  {'0.8': 'FD9567'}, 
  {'0.6': 'CD4071'},
  {'0.4': '721F81'}, 
  {'0.2': '180F3E'},
  {'0.0-0.2 (min)': '000004'}
]);
// Create the location pulldown.
var locations = Object.keys(locationDict);
var locationSelect = ui.Select({
  items: locations,
  value: locations[0],
  onChange: function(value) {
    var location = locationDict[value];
    mapPanel.setCenter(location.lon, location.lat, location.zoom);
  }
});
var locationPanel = ui.Panel([
  ui.Label('Zoom to:', {'font-size': '12px'}), locationSelect
]);
toolPanel.add(locationPanel);