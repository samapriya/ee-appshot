var app={};
app.createConstants = function() {
  app.Countries='USDOS/LSIB_SIMPLE/2017';
  //var countries=ee.FeatureCollection(app.Countries).filter(ee.Filter.eq('wld_rgn', 'Africa'));
  //print(countries)
  app.sa_primary = ee.Image('users/iglushko/PrimaryForestsGLAD/SouthAmerica_2001_primary');
  app.as_primary = ee.Image('users/iglushko/PrimaryForestsGLAD/Asia_2001_primary');
  app.af_primary = ee.Image('users/iglushko/PrimaryForestsGLAD/Africa_2001_primary');
  app.mad_primary = ee.Image('users/iglushko/PrimaryForestsGLAD/Madagaskar_2001_primary');
  app.prim=ee.Image(ee.ImageCollection([app.sa_primary.unmask(),app.as_primary.unmask(),app.af_primary.unmask(),app.mad_primary.unmask()]).max());
  app.COLLECTION_ID = 'projects/glad/alert/UpdResult';
  app.LOSS_ID = 'UMD/hansen/global_forest_change_2018_v1_6';
  app.FIRMSCOLLECTION_ID = 'FIRMS';
  app.SECTION_STYLE = {margin: '0 px 0 0 0'};
  app.SelectedCountry='Brazil';
  app.resscale=3000;
  app.Palette= ['336BFF','E83A18','9e1a1a','F3AF13'];
  app.VIS_OPTIONS = {
    'Landsat': {min: 15, max: 220},
    'Alert': {min: 1, max: 2, palette: ['blue','red']},
    'Alert19': {min: 1, max: 2, palette: ['blue','9e1a1a']},
    'Loss': {min: 0, max: 1, palette: ['orange','orange']},
    'Yearly Loss': {min: 1, max: 18, palette: app.Palette},
    'Primary': {min: 0, max: 1, palette:  ['grey','green']},
    'PrimaryOld': {min: 0, max: 1, palette:  ['fee12e','fee12e']}
  };
  app.HELPER_TEXT_STYLE = {
      margin: '8px 0 -3px 8px',
      fontSize: '14px',
      fontWeight: 'bold',
      width:'140px',
      color: 'gray'};
  app.TEXT_STYLE = {
      margin: '8px 0 -3px 8px',
      fontSize: '12px',
      //fontWeight: 'bold',
      width:'600px',
      color: 'black'};
};
app.createPanels = function() {
  /* The introduction section. */
  app.intro = {
    panel: ui.Panel([
      ui.Label({
        value: 'Alerts in Primary Forest',
        style: {fontWeight: 'bold', fontSize: '16px', margin: '8px 0 -3px 8px',color: 'black'}
      }),
      ui.Label({value:'Create primary forest loss maps and chart for selected tropical country',
        style: {fontSize: '12px', margin: '8px 0 -3px 8px',color: 'gray'}
      })
    ])
  };
  //var features = ee.FeatureCollection(app.Countries).getInfo()['features'];
  var select_items = [
    {label: 'Brazil', value: 'Brazil'},
    {label: 'Argentina', value: 'Argentina'},
    {label: 'Peru', value: 'Peru'},
    {label: 'Ecuador', value: 'Ecuador'},
    {label: 'Chile', value: 'Chile'},
    {label: 'Venezuela', value: 'Venezuela'},
    {label: 'Colombia', value: 'Colombia'},
    {label: 'Uruguay', value: 'Uruguay'},
    {label: 'Paraguay', value: 'Paraguay'},
    {label: 'Suriname', value: 'Suriname'},
    {label: 'French Guiana', value: 'French Guiana'},
    {label: 'Guyana', value: 'Guyana'},
    {label: 'Bolivia', value: 'Bolivia'},
    {label: 'Indonesia', value: 'Indonesia'},
    {label: 'Malaysia', value: 'Malaysia'},
    {label: 'Thailand', value: 'Thailand'},
    {label: 'Burma', value: 'Burma'},
    {label: 'Laos', value: 'Laos'},
    {label: 'Cambodia', value: 'Cambodia'},
    {label: 'Vietnam', value: 'Vietnam'},
    {label: 'Singapore', value: 'Singapore'},
    {label: 'Brunei', value: 'Brunei'},
    {label: 'Philippines', value: 'Philippines'},
    {label: 'India', value: 'India'},
    {label: 'Bangladesh', value: 'Bangladesh'},
    {label: 'Bhutan', value: 'Bhutan'},
    {label: 'Brunei', value: 'Brunei'},
    {label: 'Nepal', value: 'Nepal'},
    {label: 'Sri Lanka', value: 'Sri Lanka'},
    {label: 'South Africa', value: 'South Africa'},
    {label: 'Rwanda', value: 'Rwanda'},
    {label: 'Angola', value: 'Angola'},
    {label: 'Zimbabwe', value: 'Zimbabwe'},
    {label: 'Zambia', value: 'Zambia'},
    {label: 'Madagascar', value: 'Madagascar'},
    {label: 'Mozambique', value: 'Mozambique'},
    {label: 'Tanzania', value: 'Tanzania'},
    {label: 'Uganda', value: 'Uganda'},
    {label: 'Kenya', value: 'Kenya'},
    {label: 'South Sudan', value: 'South Sudan'},
    {label: 'Somalia', value: 'Somalia'},
    {label: 'Ethiopia', value: 'Ethiopia'},
    {label: 'Dem Rep of the Congo', value: 'Dem Rep of the Congo'},
    {label: 'Central African Rep', value: 'Central African Rep'},
    {label: 'Rep of the Congo', value: 'Rep of the Congo'},
    {label: 'Gabon', value: 'Gabon'},
    {label: 'Equatorial Guinea', value: 'Equatorial Guinea'},
    {label: 'Cameroon', value: 'Cameroon'},
    {label: 'Nigeria', value: 'Nigeria'},
    {label: 'Benin', value: 'Benin'},
    {label: 'Liberia', value: 'Liberia'},
    {label: 'Sierra Leone', value: 'Sierra Leone'},
    {label: 'Gambia, The', value: 'Gambia, The'},
    {label: "Cote d'Ivoire", value: "Cote d'Ivoire"},
    {label: 'Ghana', value: 'Ghana'},
  ];
  //for (var i = 0; i < features.length; i++) {
    //select_items.push({
      //label: features[i]['properties']['country_na'],
      //value: features[i]['properties']['country_co']
    //});
  //};
  /* The collection filter controls. */
  app.filters = {
    c1: ui.Select({
      items:select_items, 
      onChange: function(value) {
        var selected_country = ee.FeatureCollection(app.Countries).filter(ee.Filter.eq('country_na', value));
        Map.clear();
        Map.addLayer(selected_country, {color:'red'}, value);
        Map.centerObject(selected_country);
        app.SelectedCountry=value;
    },
      style:{width:'90px'},
      placeholder:'COUNTRY'
        }),
    apply: ui.Button('GET MAP AND CHART', app.refreshPlace,0,{fontWeight: 'bold', fontSize: '18px', color: 'f44a2c', backgroundColor: 'blue',margin: '0px 0 -0px 0px'}),
  };
  app.filters.panel = ui.Panel({
    widgets: [ 
      ui.Label(''),
      ui.Panel([ui.Label('Select country', app.HELPER_TEXT_STYLE ), app.filters.c1], ui.Panel.Layout.flow('horizontal')),
      ui.Label(''),
      ui.Panel([app.filters.apply], ui.Panel.Layout.flow('horizontal')),
      ui.Label(''),
    ],
    style: app.SECTION_STYLE
  });
  app.descr = {
    panel: ui.Panel([
      ui.Label(' '),
      ui.Label({
        value: 'Data provided by Global Land Analysis & Discovery (GLAD) team ',
        style: {fontWeight: 'bold', fontSize: '14px', margin: '5px 5px'}
      }),
      ui.Label({value:'The primary forest layer:',style:app.TEXT_STYLE}), 
      ui.Label({value:'https://glad.umd.edu/dataset/primary-forest-humid-tropics',style: {fontWeight: 'italic', fontSize: '12px', margin: '5px 5px'}}),
      ui.Label({value:'GLAD Alerts in Google Earth Engine',style: app.TEXT_STYLE}),
      ui.Label({value:'Alerts area calculated by default at scale 300 m/pixel due Google Earth Engine user memory limitations',style: {fontWeight: 'italic', fontSize: '12px', margin: '5px 5px'}})
    ])
  };
  app.chart = {
    panel: ui.Panel([
      ui.Label({
        value: '',
        style: {fontWeight: 'bold', fontSize: '14px', margin: '5px 5px'}
      })
    ])
  };
  app.chartalert19 = {
    panel: ui.Panel([
      ui.Label({
        value: '',
        style: {fontWeight: 'bold', fontSize: '14px', margin: '5px 5px'}
      })
    ])
  };
  app.chartLoss = {
    panel: ui.Panel([
      ui.Label({
        value: '',
        style: {fontWeight: 'bold', fontSize: '14px', margin: '5px 5px'}
      })
    ])
  };
};
app.refreshPlace = function() {
    var visOptionLandsat = app.VIS_OPTIONS['Landsat'];
    var visOptionLoss = app.VIS_OPTIONS['Loss'];
    var visOptionAlert = app.VIS_OPTIONS['Alert'];
    var visOptionAlert19 = app.VIS_OPTIONS['Alert19'];
    var visOptionYLoss = app.VIS_OPTIONS['Yearly Loss'];
    var visOptionPrim = app.VIS_OPTIONS['Primary'];
    var visOptionPrimOld = app.VIS_OPTIONS['PrimaryOld'];
    Map.clear();
    Map.setOptions("HYBRID");
    var sc=ee.FeatureCollection(app.Countries).filter(ee.Filter.eq('country_na', app.SelectedCountry));
    //LOSS
    var GFC = ee.Image(app.LOSS_ID).select('lossyear').clipToCollection(sc);
    var GFCloss = ee.Image(app.LOSS_ID).select('loss').clipToCollection(sc);
    var GFCcomposite = ee.Image(app.LOSS_ID).select('last_b50','last_b40','last_b30').clipToCollection(sc);
    //ALERTS
    var alerts = ee.ImageCollection(app.COLLECTION_ID).filterBounds(sc);
    var sorted = alerts.sort('system:index', false);
    var length = sorted.size();
    var list = sorted.toList(length);
    var last = ee.Image(list.get(0));
    var last_1 = ee.Image(list.get(1));
    var add= ee.String(last_1.get('system:index')).replace('SA','CA').getInfo();
    var addlast = ee.Image(app.COLLECTION_ID+'/'+add);
    var merged=ee.Image(ee.ImageCollection([last,addlast]).max());
    print(list,add);
    var conf_prev= merged.select('conf19').updateMask(merged.select('conf19').gt(0)).clipToCollection(sc);
    var conf= merged.select('conf20').updateMask(merged.select('conf20').gt(0)).clipToCollection(sc);
    var composite = merged.select(['swir1','nir','red']).clipToCollection(sc);
    //Display
    Map.addLayer(GFCcomposite, visOptionLandsat,'Last 2018 Landsat-based composite in '+ app.SelectedCountry,false);
    Map.addLayer(composite, visOptionLandsat,'Last 2020 Landsat-based composite in '+ app.SelectedCountry,false);
    var current_prim=app.prim.updateMask(app.prim.gt(0)).updateMask(GFCloss.unmask().eq(0)).clipToCollection(sc);
    Map.addLayer(app.prim.updateMask(app.prim.gt(0)).clipToCollection(sc), visOptionPrimOld,'GLAD Primary Forests 2001 in '+ app.SelectedCountry, false);
    Map.addLayer(current_prim.updateMask(current_prim.gt(0)).clipToCollection(sc), visOptionPrim,'GLAD Primary Forests 2019 in '+ app.SelectedCountry);
    Map.addLayer(GFC.updateMask(GFC.gt(0)).clipToCollection(sc), visOptionLoss,'Loss 2001-2018 in '+ app.SelectedCountry);
    Map.addLayer(conf_prev, visOptionAlert19,'Alerts 2019 in '+ app.SelectedCountry);
    Map.addLayer(conf, visOptionAlert,'Alerts 2020 in '+ app.SelectedCountry);
    //Create prim non prim mask
    var loss_in_prim=app.prim.updateMask(GFCloss.gt(0)).remap([1],[2]);
    //var tmp=current_prim.unmask().add(loss_in_prim.unmask()).clipToCollection(sc);
    var current_mask=current_prim.unmask().remap([0,1],[2,1]).clipToCollection(sc);
    var old_mask=app.prim.unmask().remap([0,1],[2,1]).clipToCollection(sc);
    current_mask=current_mask.add(old_mask).remap([4,3,2],[3,2,1])
    // Alert
    var lossAreaImage = conf.gt(0).updateMask(conf.gt(0)).multiply(ee.Image.pixelArea());
    var lossByClass = lossAreaImage.addBands(current_mask).reduceRegion({
      reducer: ee.Reducer.sum().group({
        groupField: 1
        }),
      geometry: ee.FeatureCollection(app.Countries).filter(ee.Filter.eq('country_na', app.SelectedCountry)),
      scale: app.resscale,
      maxPixels: 1e18
    });
    var totloss = lossAreaImage.reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: ee.FeatureCollection(app.Countries).filter(ee.Filter.eq('country_na', app.SelectedCountry)),
      scale: app.resscale,
      maxPixels: 1e18
    });
    totloss=ee.Number(totloss.get('conf20')).divide(10000000).round();
    //print(totloss);
    ////CHART/////////////////////////////////////////////////
    var statsFormatted = ee.List(lossByClass.get('groups'))
      .map(function(el) {
        var d = ee.Dictionary(el);
        return [ee.String(ee.Number(d.get('group')).format("%01d")), ee.Number(d.get('sum')).divide(10000000).round()];
      });
    var statsDictionary = ee.Dictionary(statsFormatted.flatten());
    print(statsDictionary,'Loss in '+app.SelectedCountry);
    var chartSubTitle = ui.Label({
      value: 'Total loss in 2020 per country - '+totloss.getInfo() +' Kha',
      style: {
        fontWeight: 'bold',
        fontSize: '16px',
        margin: '0 0 8px 0',
        padding: '0'
      }
    });
    //app.chart.panel.add(chartTitle);
    var chart = ui.Chart.array.values({
      array: statsDictionary.values(),
      axis: 0,
      xLabels: statsDictionary.keys()
      }).setChartType('ColumnChart')
      .setOptions({
        title: '',
        hAxis: {title: '1 - inside current primary forest; 2 - inside recently cleared primary forests; 3-outside primary forests', format: '####'},
        vAxis: {title: 'Area Kha'},
        legend: { position: "none" },
        colors:['red'],
        lineWidth: 1,
        pointSize: 3
      });
    //print(chart.getOptions());
    app.chart.panel.widgets().set(1,chartSubTitle);
    app.chart.panel.widgets().set(2, chart);
    // Alert2019
    var lossAreaImage19 = conf_prev.gt(0).updateMask(conf_prev.gt(0)).multiply(ee.Image.pixelArea());
    var lossByClass19 = lossAreaImage19.addBands(current_mask).reduceRegion({
      reducer: ee.Reducer.sum().group({
        groupField: 1
        }),
      geometry: ee.FeatureCollection(app.Countries).filter(ee.Filter.eq('country_na', app.SelectedCountry)),
      scale: app.resscale,
      maxPixels: 1e18
    });
    var totloss19 = lossAreaImage19.reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: ee.FeatureCollection(app.Countries).filter(ee.Filter.eq('country_na', app.SelectedCountry)),
      scale: app.resscale,
      maxPixels: 1e18
    });
    totloss19=ee.Number(totloss19.get('conf19')).divide(10000000).round();
    //print(totloss);
    ////CHART/////////////////////////////////////////////////
    var statsFormatted19 = ee.List(lossByClass19.get('groups'))
      .map(function(el) {
        var d = ee.Dictionary(el);
        return [ee.String(ee.Number(d.get('group')).format("%01d")), ee.Number(d.get('sum')).divide(10000000).round()];
      });
    var statsDictionary19 = ee.Dictionary(statsFormatted19.flatten());
    print(statsDictionary19,'Loss in '+app.SelectedCountry);
    var chartSubTitle19 = ui.Label({
      value: 'Total loss in 2019 per country - '+totloss19.getInfo() +' Kha',
      style: {
        fontWeight: 'bold',
        fontSize: '16px',
        margin: '0 0 8px 0',
        padding: '0'
      }
    });
    //app.chart.panel.add(chartTitle);
    var chart19 = ui.Chart.array.values({
      array: statsDictionary19.values(),
      axis: 0,
      xLabels: statsDictionary19.keys()
      }).setChartType('ColumnChart')
      .setOptions({
        title: '',
        hAxis: {title: '1 - inside current primary forest; 2 - inside recently cleared primary forests; 3-outside primary forests', format: '####'},
        vAxis: {title: 'Area Kha'},
        legend: { position: "none" },
        colors:['red'],
        lineWidth: 1,
        pointSize: 3
      });
    //print(chart.getOptions());
    app.chartalert19.panel.widgets().set(1,chartSubTitle19);
    app.chartalert19.panel.widgets().set(2, chart19);
    //ADD loss 2000-2018
    var lossAreaImage1 = GFCloss.gt(0).updateMask(GFCloss.gt(0)).multiply(ee.Image.pixelArea());
    var lossByClass1 = lossAreaImage1.addBands(old_mask).reduceRegion({
      reducer: ee.Reducer.sum().group({
        groupField: 1
        }),
      geometry: ee.FeatureCollection(app.Countries).filter(ee.Filter.eq('country_na', app.SelectedCountry)),
      scale: app.resscale,
      maxPixels: 1e18
    });
    var totloss1 = lossAreaImage1.reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: ee.FeatureCollection(app.Countries).filter(ee.Filter.eq('country_na', app.SelectedCountry)),
      scale: app.resscale,
      maxPixels: 1e18
    });
    totloss1=ee.Number(totloss1.get('loss')).divide(10000000).round();
    //print(totloss);
    ////CHART/////////////////////////////////////////////////
    var statsFormatted1 = ee.List(lossByClass1.get('groups'))
      .map(function(el) {
        var d = ee.Dictionary(el);
        return [ee.String(ee.Number(d.get('group')).format("%01d")), ee.Number(d.get('sum')).divide(10000000).round()];
      });
    var statsDictionary1 = ee.Dictionary(statsFormatted1.flatten());
    //print(statsDictionary,'Loss in '+app.SelectedCountry);
    var chartSubTitle1 = ui.Label({
      value: 'Total loss in 2001-2018 per country - '+totloss1.getInfo() +' Kha',
      style: {
        fontWeight: 'bold',
        fontSize: '16px',
        margin: '0 0 8px 0',
        padding: '0'
      }
    });
    //app.chart.panel.add(chartTitle);
    var chart1 = ui.Chart.array.values({
      array: statsDictionary1.values(),
      axis: 0,
      xLabels: statsDictionary1.keys()
      }).setChartType('ColumnChart')
      .setOptions({
        title: '',
        hAxis: {title: '1 - inside primary forest extent for 2001; 2 - outside primary forests', format: '####'},
        vAxis: {title: 'Area Kha'},
        legend: { position: "none" },
        colors:['orange'],
        lineWidth: 1,
        pointSize: 3
      });
    //print(chart.getOptions());
    app.chartLoss.panel.widgets().set(1,chartSubTitle1);
    app.chartLoss.panel.widgets().set(2, chart1);
    ////////////////////////ADD legend/////////////////////////////////////
    var nClasses = 2;
    var classNames = ['Unconfirmed - 2020','Confirmed - 2020','Loss 2019','Loss 2001-2018'];
    // Create the panel for the legend items.
    var legend = ui.Panel({
      style: {
        position: 'bottom-left',
        padding: '8px 15px'
      }
    });
    // Create and add the legend title.
    var legendTitle = ui.Label({
      value: 'Alerts & Loss',
      style: {
        fontWeight: 'bold',
        fontSize: '18px',
        margin: '0 0 4px 0',
        padding: '0'
      }
    });
    legend.add(legendTitle);
    // Creates and styles 1 row of the legend.
    var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
    var colorBox = ui.Label({
      style: {
        backgroundColor: '#' + color,
        // Use padding to give the box height and width.
        padding: '8px',
        margin: '0 0 4px 0'
      }
    });
    // Create the label filled with the description text.
    var description = ui.Label({
      value: name,
      style: {margin: '0 0 4px 6px'}
    });
    return ui.Panel({
      widgets: [colorBox, description],
      layout: ui.Panel.Layout.Flow('horizontal')
    });
    };
    for (var i = 0; i < classNames.length; i++){
      legend.add(makeRow(app.Palette[i],classNames[i]));
    }
    // Add the legend to the map.
    Map.add(legend);
    //Map.add(chartleg);
};
/** Creates the application interface. */
app.boot = function() {
  app.createConstants();
  app.createPanels();
  var main = ui.Panel({
    widgets: [
      app.intro.panel,
      app.filters.panel,
      app.descr.panel,
      app.chart.panel,
      app.chartalert19.panel,
      app.chartLoss.panel,
    ],
    style: {width: '275px', padding: '4px'}
  });
  ui.root.insert(0, main);
  var scountry=ee.FeatureCollection(app.Countries).filter(ee.Filter.eq('country_na', app.SelectedCountry))
  Map.centerObject(scountry,5);
  app.refreshPlace();
};
app.boot();