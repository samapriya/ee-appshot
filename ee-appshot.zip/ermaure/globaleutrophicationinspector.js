/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var time = {},
    data = {};
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// 2019-07-29
// Copyright (C): E. R. MAURE | eligiomaure@gmail.com
// ==============================================================================
// FUNCTION CALLS
var geimap = require('users/ermaure/GEI:Modules/gei_map');
var geisenslope = require('users/ermaure/GEI:Modules/gei_senslope');
var geithreshold = require('users/ermaure/GEI:Modules/gei_threshold');
var geitimeseries = require('users/ermaure/GEI:Modules/gei_timeseries');
// ==============================================================================
// USER DEFINED PARAMS                                                          =
// ==============================================================================
// Time series for the computation of monthly means --> yearly max
time.yearStart = 2003; // Start year 
// time.pyearEnd = ;
time.yearEnd = (ee.Date(Date.now() - 365 * 1 * 8.64e+7).get('year')); // End year 
time.thesholdStartDate = ee.Date.fromYMD(time.yearEnd.subtract(2), 1, 1);
time.thesholdEndDate = ee.Date.fromYMD(time.yearEnd, 12, 31);
// print(time.thesholdEndDate);
data.dailyCollection = geitimeseries.timeseriesCollection;
// ==============================================================================
// UpDate Functions on Changes in the App Interface
// Function to update the slope ===================
var senslope = function (startYear, endYear) {
    return geisenslope.senslope(startYear, endYear);
}; // ----------------------------------------------
// =================================================
// Function to update the dates =========
function controllerUpdate(date, str) {
    if (str === 'dst') { // update time start
        time.thesholdStartDate = ee.Date.parse('Y-MM-dd', date);
    }
    else if (str === 'den') { // update time end
        time.thesholdEndDate = ee.Date.parse('Y-MM-dd', date);
    }
    else if (str === 'yst') { // update year start
        time.yearStart = date;
    }
    else if (str === 'yen') { // update year end
        time.yearEnd = date;
    }
    thresholdUpdate(geitimeseries.threshold);
}  // -------------------------------------------------------------
// ================================================================
// This block updates when threshold value is changes. 
// This is a callback for the slider.
var thresholdUpdate = function (threshold) {
    // Update the threshold container to make the new value available to other functions 
    geitimeseries.threshold = ee.Number(threshold);
    // The Global Eutrophication Map
    // Slope and zscore maps
    var slope = senslope(time.yearStart, time.yearEnd);
    // The threshold map
    var thresholdMean = geithreshold.thresholdMean(
        time.thesholdStartDate,
        time.thesholdEndDate);
    data.gem = geimap.GEIT(
        thresholdMean,
        slope,
        geitimeseries.threshold,
        geitimeseries.eps);
    // compile the map based on new threshold
    var layer = ui.Map.Layer(
        data.gem,
        geitimeseries.eutroVis,
        'Potential Eutrophication Map');
    Map.setCenter(131, 37, 4);
    Map.layers().set(0, layer);
};
// ==============================================================================
// Panels ------------
var panel1 = ui.Panel();
var panel2 = ui.Panel();
panel1.style().set('width', '405px');
panel2.style().set('width', '350px');
// Default settings of the chart 
var intro = ui.Panel([
    ui.Label({
        value: 'Global Eutrophication Inspector',
        style: { fontSize: '35px' } // , fontWeight: 'bold' 
    })]);
panel2.add(ui.Panel([
    ui.Label({
        value: 'Click a point on the map to update the chart.',
        style: { fontWeight: 'bold' }
    })]));
// PANELS TO HOLD LON/LAT VALUES. 
var lon = ui.Label();
var lat = ui.Label();
// ===================================
// panel1.add(intro); var pn = 0;// update 
// panel1.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal'))); pn += 1;
// Panels ==================================================================
var string = '- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  - - - - - - - - ';
// var separator = ui.Label({ value: string, style: { stretch: 'vertical', color: 'black' } });
// SET UP TEXT SELECTOR FOR PICKING THE YEAR-RANGE, START-END YEARS
var yearLabel = ui.Label({
    value: 'Year Range for the Trend Analysis',
    style: { stretch: 'vertical', color: 'brown' }
});
// Start year label ===========
var startYearLabel = ui.Label({
    value: 'Start Year:',
    style: { stretch: 'vertical', fontWeight: 'bold' }
});
// On change of Text selector :: START
var startYearSlider = ui.Slider({
    min: 2003, max: time.yearEnd, value: 2003, step: 1,
    style: { stretch: 'vertical', width: '273px' },
    onChange: function (yy) { controllerUpdate(yy, 'yst') }
});
// ==========================================================================
// End year Label ===========
var endYearLabel = ui.Label({
    value: 'End Year:',
    style: { stretch: 'vertical', fontWeight: 'bold' }
});
// On change of Text selector :: END
var mxY = Number(ee.Date(Date.now() - 365 * 1 * 8.64e+7).format('Y').getInfo());
var endYearSlider = ui.Slider({
    min: 2015, max: mxY, value: mxY, step: 1,
    style: { stretch: 'vertical', width: '280px' },
    onChange: function (yy) { controllerUpdate(yy, 'yen') }
});
// ==================================================================
// SLIDER FOR [CHL] THRESHOLD USED TO DISCRIMINATE HIGH/LOW VALUES
var sliderLabel = ui.Label({
    value: 'CHL Threshold Value',
    style: { color: 'green' }
});
var sliderLabelUnit = ui.Label({
    value: '[mg m^-3]',
    style: { stretch: 'vertical' }
});
var thresholdSlider = ui.Slider({
    min: 1, max: 100, step: 1,
    style: { width: '300px' }, onChange: thresholdUpdate
}); // =================================================
// FIRST, THE LABEL NAME
var dateLabel = ui.Label({
    value: 'CHL Threshold Time Range',
    style: { stretch: 'vertical' }
});
// THEN THE START DATE LABEL AND PANEL
var startDateLabel = ui.Label({
    value: 'Start Date:',
    style: { stretch: 'vertical', fontWeight: 'bold' }
});
// On change of Text selector :: START
var startDateTextbox = ui.Textbox({
    placeholder: ee.Date(time.thesholdStartDate).format('Y-MM-dd').getInfo(),
    onChange: function (txt) {
        controllerUpdate(txt, 'dst');
    }, style: { width: '85px' }
});
// AND NOW, THE END DATE WITH THE SAME FANCY SETTINGS
var endDateLabel = ui.Label({
    value: 'End Date:',
    style: { stretch: 'vertical', fontWeight: 'bold' }
});
// On change of Text selector :: END
var endDateTextbox = ui.Textbox({
    placeholder: ee.Date(time.thesholdEndDate).format('Y-MM-dd').getInfo(),
    onChange: function (txt) {
        controllerUpdate(txt, 'den');
    }, style: { width: '85px' }
}); // ====================================================
// ADDING/UPDATING THE PANELS =============================
// update the chart // BASE PANEL ======================= 0
// ========================================================
// Add the Name of the App
panel1.add(intro); var pn = 0;// update
// Default lon/lat point
panel2.add(
    ui.Panel([lon, lat],
        ui.Panel.Layout.flow('horizontal'))); //pn += 1;
// Aestectic line separator
panel2.add(ui.Panel([ui.Label({
    value: string,
    style: { stretch: 'vertical', color: 'black' }
})], ui.Panel.Layout.flow('horizontal'))); //pn += 1;
// PANEL TO HOLD THE STATUS OF A POIN ON MAP, EUTROPHICATION STATUS
panel2.add(ui.Panel([ui.Label()])); //pn += 1;
// Separator ================
panel2.add(ui.Panel([ui.Label({
    value: string,
    style: { stretch: 'vertical', color: 'black' }
})], ui.Panel.Layout.flow('horizontal'))); //pn += 1;
// WIDGET: Label for the year
panel1.add(ui.Panel({
    widgets: [yearLabel],
    layout: ui.Panel.Layout.flow('horizontal')
})); pn += 1;
// Add slider for the year widget
panel1.add(ui.Panel({
    widgets: [startYearLabel, startYearSlider],
    layout: ui.Panel.Layout.flow('horizontal')
})); pn += 1;
panel1.add(ui.Panel({
    widgets: [endYearLabel, endYearSlider],
    layout: ui.Panel.Layout.flow('horizontal')
})); pn += 1; // ============================
// Another line to separate
panel1.add(ui.Panel([ui.Label({
    value: string, style: { stretch: 'vertical', color: 'black' }
})], ui.Panel.Layout.flow('horizontal'))); pn += 1;
// Threshold slider
panel1.add(ui.Panel({
    widgets: [sliderLabel],
    layout: ui.Panel.Layout.flow('horizontal')
})); pn += 1;
// Units for the threshold
panel1.add(ui.Panel({
    widgets: [sliderLabelUnit, thresholdSlider],
    layout: ui.Panel.Layout.flow('horizontal')
})); pn += 1; // =============================
// Label for the threshold date widget
panel1.add(ui.Panel({
    widgets: [dateLabel],
    layout: ui.Panel.Layout.flow('horizontal')
})); pn += 1;
// Text boxes for the threshold time selector
panel1.add(ui.Panel({
    widgets: [startDateLabel, startDateTextbox, endDateLabel, endDateTextbox],
    layout: ui.Panel.Layout.flow('horizontal')
})); pn += 1;
// Another line to separate
panel1.add(ui.Panel([ui.Label({
    value: string, style: { stretch: 'vertical', color: 'black' }
})], ui.Panel.Layout.flow('horizontal'))); pn += 1;
pn += 1; // PLUS ONE FOR THE CHART
// TIME SERIES FOR THE CHART. 
// THE DATA IS THE SAME AS USED IN THE ESTIMATION OF TREND
var timeseriesData = ee.ImageCollection(
    ee.List.sequence(time.yearStart, time.yearEnd).map(
        function (year) {
            // map the time series into monthly means
            return ee.List.sequence(1, 12).map(
                function (month) {
                    var date = ee.Date.fromYMD(year, month, 1);
                    return ee.Image(10).pow(data.dailyCollection
                        // filter by time period of the trend analysis
                        .filterDate(date, date.advance(1, 'month'))
                        .map(function (dayImage) {
                            // Log-Transform 
                            return dayImage.log10();
                        }).mean()).rename('CHL')
                        .set('system:time_start', date);
                });
        }).flatten());
var updateChart = function (coords) {
    // Update the lon/lat panel1 with values from the click event.
    lon.setValue('Latitude: ' + coords.lat.toFixed(2));
    lat.setValue('Longitude: ' + coords.lon.toFixed(2));
    // Add a red dot for the point clicked on.
    var point = ee.Geometry.Point(coords.lon, coords.lat);
    var dot = ui.Map.Layer(point, { color: 'FF0000' });
    Map.layers().set(1, dot);
    // ===================================================
    // Define callback functions to update the status label
    function showStatusName(thisStatusName) {
        var statusLabel = ui.Label({
            value: 'Clicked Point Status :: ' + thisStatusName,
            style: {
                fontWeight: 'bold',
            }
        });
        panel2.widgets().set(3, statusLabel);
    }
    function retrieveStatusName(thisStatusVal) {
        var currentStatusName = function (thisVal) {
            // evaluate the status ------------------------
            return ee.Algorithms.If(ee.Number(thisVal).eq(1),
                'LD', //:: Low [CHL], Decreasing trend
                // The first case is true, update here, false: re-evaluate
                ee.Algorithms.If(ee.Number(thisVal).eq(2),
                    'LN', //:: Low [CHL], Notrend
                    // Second case is true, update, false: re-evaluate
                    ee.Algorithms.If(ee.Number(thisVal).eq(3),
                        'LI', // :: Low [CHL], Increasing trend
                        // Third case is true, update, false: re-evaluate
                        ee.Algorithms.If(ee.Number(thisVal).eq(4),
                            'HD', // :: High [CHL], Decreasing trend
                            // Fourth case is true, update, false: re-evaluate
                            ee.Algorithms.If(ee.Number(thisVal).eq(5),
                                'HN', // :: High [CHL], Notrend
                                // Fifth case is true, update, false: re-evaluate
                                ee.Algorithms.If(ee.Number(thisVal).eq(6),
                                    'HI' /* :: High [CHL], Increasing trend*/, 'Unknown'))))));
            // Sixth case is true, update, false: Unknown(N/A)
        };
        // thisStatusVal is the value from the clicked point on map
        ee.List([thisStatusVal])
            // fetch the status name
            .map(currentStatusName)
            // send to labelling
            .evaluate(showStatusName);
    }
    /////////////////////////////////////////////////////////////
    // Retrieve and update the value of the clicked point
    var thisClass = data.gem.reduceRegion({
        reducer: ee.Reducer.first(),
        geometry: point,
        scale: data.dailyCollection
            .select('chlor_a')
            .first()
            .projection()
            .nominalScale()
    }).get('GESM');
    // value retrieved, send to chart
    thisClass.evaluate(retrieveStatusName);
    // Create a chart, a time series plot at a single location and its current status
    var timeSeriesChart = ui.Chart.image.series(timeseriesData, point, ee.Reducer.mean(), 1)
        .setChartType('ScatterChart')
        .setOptions({
            title: 'MODIS-Aqua Chlorophyll-a (CHL) Concentration',
            vAxis: { title: 'CHL [mg m^-3]', scaleType: 'linear' },
            hAxis: { title: 'Date', format: 'MMM-yy' }, //, gridlines: { count: 7 } 
            trendlines: {
                0: {
                    color: 'CC0000',
                    lineWidth: 1.5,
                }
            },
            series: {
                0: {
                    color: '#008000', // green',
                    lineWidth: 2,
                    pointsVisible: true,
                    pointSize: 6,
                },
            },
        });
    panel2.widgets().set(5, timeSeriesChart);
};
Map.onClick(updateChart);
Map.style().set('cursor', 'crosshair');
// Add the panel1 to the ui.root.
ui.root.insert(0, panel1);
// Add the panel1 to the ui.root.
ui.root.insert(2, panel2);
// Trigger an event to update the composite.
thresholdSlider.setValue(geitimeseries.threshold);
// This step trigger the time series chart after the GEM has been computed
updateChart({
    lon: 134.5,
    lat: 36
});
// separator to explain the meaning of each class
panel2.add(ui.Panel([ui.Label({
    value: string,
    style: { stretch: 'vertical', color: 'black' }
})], ui.Panel.Layout.flow('horizontal'))); //pn += 1;
panel2.add(ui.Panel([
    ui.Label('LD | Current Status: Low CHL, Trend: Decreasing'),
    ui.Label('LN | Current Status: Low CHL, Trend: No-Trend'),
    ui.Label('LI | Current Status: Low CHL, Trend: Increasing'),
    ui.Label('HD | Current Status: High CHL, Trend: Decreasing'),
    ui.Label('HN | Current Status: High CHL, Trend: No-Trend'),
    ui.Label('HI | Current Status: High CHL, Trend: Increasing')]));
// Create a panel to hold title, intro text, chart and legend components.
var inspectorPanel = ui.Panel({style: {width: '30%'}});
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  // print(palette);
    return {
        bbox: [0.5, 0, 6.5, 0.1],
        dimensions: '100x10',
        format: 'png',
        min: 1,
        max: 6,
        palette: palette,
    };
}
print(geitimeseries.eutroVis.palette);
// Create the color bar for the legend.
var colourBar = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0).round(),
    params: makeColorBarParams(geitimeseries.eutroVis.palette),
    style: { stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px' },
});
// Create a panel with six numbers for the legend.
var legendLabels = ui.Panel({
    widgets: [
        ui.Label('LD', { margin: '4px 8px', stretch: 'horizontal' }),
        ui.Label('LN', { margin: '4px 8px', stretch: 'horizontal' }),
        ui.Label('LI', { margin: '4px 8px', stretch: 'horizontal' }),
        ui.Label('HD', { margin: '4px 8px', stretch: 'horizontal' }),
        ui.Label('HN', { margin: '4px 8px', stretch: 'horizontal' }),
        ui.Label('HI', { margin: '4px 8px', stretch: 'horizontal' }) // textAlign: 'center', 
    ],
    layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
    value: 'Map Legend: Eutrophic State',
    style: { fontWeight: 'bold' }
});
var legendPanel = ui.Panel([legendTitle, colourBar, legendLabels]);
panel1.widgets().set(pn, legendPanel);