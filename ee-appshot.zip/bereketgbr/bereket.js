var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                38.38662499999999,
                6.272145860426959
              ],
              [
                38.38662499999999,
                6.272145860426959
              ],
              [
                38.38662499999999,
                6.272145860426959
              ],
              [
                38.38662499999999,
                6.272145860426959
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                37.615426406827105,
                8.733392452291561
              ],
              [
                37.615426406827105,
                6.43844674948408
              ],
              [
                38.628915176358355,
                6.43844674948408
              ],
              [
                38.628915176358355,
                8.733392452291561
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        },
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* displayProperties: [
      {
        "type": "rectangle"
      },
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.MultiPolygon(
        [[[[38.38662499999999, 6.272145860426959],
           [38.38662499999999, 6.272145860426959],
           [38.38662499999999, 6.272145860426959],
           [38.38662499999999, 6.272145860426959]]],
         [[[37.615426406827105, 8.733392452291561],
           [37.615426406827105, 6.43844674948408],
           [38.628915176358355, 6.43844674948408],
           [38.628915176358355, 8.733392452291561]]]], null, false),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI"
        ],
        "min": 0,
        "max": 8000,
        "palette": [
          "ffffff",
          "ce7e45",
          "df923d",
          "f1b555",
          "fcd163",
          "99b718",
          "74a901",
          "66a000",
          "529400",
          "3e8601",
          "207401",
          "056201",
          "004c00",
          "023b01",
          "012e01",
          "011d01",
          "011301"
        ]
      }
    }) || {"opacity":1,"bands":["NDVI"],"min":0,"max":8000,"palette":["ffffff","ce7e45","df923d","f1b555","fcd163","99b718","74a901","66a000","529400","3e8601","207401","056201","004c00","023b01","012e01","011d01","011301"]},
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI",
          "NDVI",
          "NDVI"
        ],
        "min": 0,
        "max": 8000,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["NDVI","NDVI","NDVI"],"min":0,"max":8000,"gamma":1},
    imageVisParam3 = ui.import && ui.import("imageVisParam3", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI",
          "NDVI",
          "NDVI"
        ],
        "min": -21.399999999999977,
        "max": 7703.4,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["NDVI","NDVI","NDVI"],"min":-21.399999999999977,"max":7703.4,"gamma":1},
    imageVisParam4 = ui.import && ui.import("imageVisParam4", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI",
          "NDVI",
          "NDVI"
        ],
        "min": -21.399999999999977,
        "max": 7703.4,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["NDVI","NDVI","NDVI"],"min":-21.399999999999977,"max":7703.4,"gamma":1},
    imageVisParam5 = ui.import && ui.import("imageVisParam5", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI",
          "NDVI",
          "NDVI"
        ],
        "min": -21.399999999999977,
        "max": 7703.4,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["NDVI","NDVI","NDVI"],"min":-21.399999999999977,"max":7703.4,"gamma":1},
    imageVisParam6 = ui.import && ui.import("imageVisParam6", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI",
          "NDVI",
          "NDVI"
        ],
        "min": -21.399999999999977,
        "max": 7703.4,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["NDVI","NDVI","NDVI"],"min":-21.399999999999977,"max":7703.4,"gamma":1},
    imageVisParam7 = ui.import && ui.import("imageVisParam7", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI",
          "NDVI",
          "NDVI"
        ],
        "min": -21.399999999999977,
        "max": 7703.4,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["NDVI","NDVI","NDVI"],"min":-21.399999999999977,"max":7703.4,"gamma":1},
    imageVisParam8 = ui.import && ui.import("imageVisParam8", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI",
          "NDVI",
          "NDVI"
        ],
        "min": -21.399999999999977,
        "max": 7703.4,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["NDVI","NDVI","NDVI"],"min":-21.399999999999977,"max":7703.4,"gamma":1},
    imageVisParam9 = ui.import && ui.import("imageVisParam9", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI",
          "NDVI",
          "NDVI"
        ],
        "min": -669.3,
        "max": 7736.3,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["NDVI","NDVI","NDVI"],"min":-669.3,"max":7736.3,"gamma":1},
    imageVisParam10 = ui.import && ui.import("imageVisParam10", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI",
          "NDVI",
          "NDVI"
        ],
        "min": -669.3,
        "max": 7736.3,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["NDVI","NDVI","NDVI"],"min":-669.3,"max":7736.3,"gamma":1},
    imageVisParam11 = ui.import && ui.import("imageVisParam11", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI",
          "NDVI",
          "NDVI"
        ],
        "min": -246.79999999999995,
        "max": 8002.8,
        "gamma": 0.927
      }
    }) || {"opacity":1,"bands":["NDVI","NDVI","NDVI"],"min":-246.79999999999995,"max":8002.8,"gamma":0.927},
    geometry2 = ui.import && ui.import("geometry2", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.MultiPoint();
var dataset = ee.ImageCollection('MODIS/006/MOD13Q1')
                  .filter(ee.Filter.date('2001-07-15', '2021-07-16'));
var ndvi = dataset.select('NDVI');
var ndviVis = {
  min: 0.0,
  max: 8000.0,
  palette: [
    'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01', '011301'
  ],
};
Map.setCenter(6.746, 46.529, 2);
Map.addLayer(ndvi, ndviVis, 'NDVI')