// Create two maps.
var leftMap = ui.Map({'lat':52, 'lon':0, 'zoom':5});
var rightMap = ui.Map({'lat':52, 'lon':0, 'zoom':5});
// Remove UI controls from both maps, but leave zoom control on the left map.
leftMap.setControlVisibility({layerList: true});
rightMap.setControlVisibility({layerList: true});
leftMap.setControlVisibility({zoomControl: true});
// Create a split panel with the two maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe: true
});
// Remove the default map from the root panel.
ui.root.clear();
// Add our split panel to the root panel.
ui.root.add(splitPanel);
////////////////////////
// Make the UI
////////////////////////
//////////
// Set the flow
/////////
var horizontalFlow = ui.Panel.Layout.flow('horizontal');
var verticalFlow = ui.Panel.Layout.flow('vertical');
// query labelsma
var image1Label = ui.Label("S2cloudless");
var image1Panel = ui.Panel({
  widgets: [image1Label],
  style: {position: 'middle-left'}
});
leftMap.add(image1Panel);
/// Image 2 panel
// query labels
var image2Label = ui.Label("cloud_score+");
var image2Panel = ui.Panel({
  widgets: [image2Label],
  style: {position: 'middle-right'}
});
rightMap.add(image2Panel);
var linker = ui.Map.Linker([leftMap, rightMap]);
var s2Sr = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED');
var s2Clouds = ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY');
var MAX_CLOUD_PROBABILITY = 50;
var region = ee.Geometry.Rectangle({ coords: [-76.5, 2.0, -74, 4.0], geodesic: false });
function maskClouds(img) {
  var clouds = ee.Image(img.get('cloud_mask')).select('probability');
  var MAX_CLOUD_PROBABILITY = probSlider.getValue();
  var isNotCloud = clouds.lt(MAX_CLOUD_PROBABILITY);
  return img.updateMask(isNotCloud);
}
// The masks for the 10m bands sometimes do not exclude bad data at
// scene edges, so we apply masks from the 20m and 60m bands as well.
// Example asset that needs this operation:
// COPERNICUS/S2_CLOUD_PROBABILITY/20190301T000239_20190301T000238_T55GDP
function maskEdges(s2_img) {
  return s2_img.updateMask(
    s2_img.select('B8A').mask().updateMask(s2_img.select('B9').mask())
  );
}
var rgbVis = { min: 0, max: 3000, bands: ['B4', 'B3', 'B2'] };
//////////
// Cloud Score+ image collection. Note Cloud Score+ is produced from Sentinel-2
// Level 1C data and can be applied to either L1C or L2A collections.
var csPlus = ee.ImageCollection('GOOGLE/CLOUD_SCORE_PLUS/V1/S2_HARMONIZED');
var s2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED');
// Masks pixels with low CS+ QA scores.
function maskLowQA(image) {
  var qaBand = 'cs';
  MAX_CLOUD_PROBABILITY = probSlider.getValue();
  var mask = image.select(qaBand).gte(MAX_CLOUD_PROBABILITY / 100);
  return image.updateMask(mask);
}
// Date filters
var label1 = ui.Label('Date:');
var startDate = ui.DateSlider({
  start: ee.Date('2020-01-01'),
  end: ee.Date('2023-10-20')
});
var endDate = startDate.end;
var widget = ui.Label({
  value: 'Comparing cloud masking options for Sentinel 2 imagery',
  style: {fontSize: '20px', color: '484848', fontWeight:'bold'}
});
var label2 = ui.Label('Max Cloud Probability:');
// Cloud probability filter
var probSlider = ui.Slider({
  min: 0,
  max: 100,
  value: 50,
  step: 1
});
var probFilter = probSlider.value;
var select_layer = ui.Panel({
  widgets: [widget, label1, startDate, label2, probSlider],
});
//Map.add(select_layer);
// Create a panel to hold the chart.
var panel = ui.Panel({ style: { width: '10%' } });
ui.root.insert(0, panel);
panel.add(select_layer);
function updateLayers() {
  // leftMap.clear();
  // rightMap.clear();
  var date = startDate.getValue();
  var prob = probSlider.getValue();
  var MAX_CLOUD_PROBABILITY = prob;
  // print(date, prob)
  var START_DATE = ee.Date(date[0]);
  var END_DATE = ee.Date(date[1]).advance(1, 'days')
  // Filter input collections by desired data range and region.
  var criteria = ee.Filter.date(START_DATE, END_DATE);
  s2Sr = s2Sr.map(maskEdges);
  s2Clouds = s2Clouds;
  // Join S2 SR with cloud probability dataset to add cloud mask.
  var s2SrWithCloudMask = ee.Join.saveFirst('cloud_mask').apply({
    primary: s2Sr,
    secondary: s2Clouds,
    condition: ee.Filter.equals({ leftField: 'system:index', rightField: 'system:index' })
  });
  var s2CloudMasked = ee.ImageCollection(s2SrWithCloudMask).filter(criteria).map(maskClouds).median();
  // Link S2 and CS+ results.
  var linkedCollection = s2.map(maskEdges).linkCollection(csPlus, ['cs', 'cs_cdf']).filter(criteria);
  var s2cloudscoreMasked = linkedCollection.map(maskLowQA).median();
  leftMap.layers().reset();
  leftMap.addLayer(s2CloudMasked, rgbVis, 'cloud_prob masked at ' + MAX_CLOUD_PROBABILITY + '%');
  rightMap.layers().reset();
  rightMap.addLayer(s2cloudscoreMasked, rgbVis, 'cloud_score masked at ' + MAX_CLOUD_PROBABILITY + '%');
}
startDate.onChange(updateLayers);
probSlider.onChange(updateLayers);
//leftMap.centerObject(region);
updateLayers();
//leftMap.centerObject(region);
/* Build the progress bar widgets */
var percentBar = ui.Panel({style: {width: "0%", backgroundColor: "4287f5"}});
var percentLabel = ui.Label({value: "0%", style: {color: "#f0f6ff", backgroundColor: "#00000000", padding: "8px", margin: 0}});
var progressBar = ui.Panel({
  widgets: [percentBar, percentLabel],
  layout: ui.Panel.Layout.absolute(),
  style: {height: "32px", width: "320px", backgroundColor: "#ebf2ff", position: "bottom-right", border: "1px solid #0a3e91"}
});
/* Update the progress bar to a given % */
function updateProgress(percentRemaining) {
  var percentLoaded = String(Math.round((1 - percentRemaining) * 100)) + "%";
  percentLabel.setValue(percentLoaded);
  percentBar.style().set("width", percentLoaded);
}
/* Set the progress bar to update whenever a map tile is loaded */
leftMap.onTileLoaded(function(layerProgress) {
  var layers = layerProgress.length;
  var percentRemaining = layers > 0 ? layerProgress.reduce(function(sum, x) {return sum + x}, 0) / layers : 0;
  updateProgress(percentRemaining);
});
/* Add the progress bar to the map */
rightMap.add(progressBar);
//rightMap.setCenter(0, 4, 13)