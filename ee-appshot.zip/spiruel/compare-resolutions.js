// Create two maps.
var leftMap = ui.Map();
var rightMap = ui.Map();
// Remove UI controls from both maps, but leave zoom control on the left map.
leftMap.setControlVisibility(false);
rightMap.setControlVisibility(false);
leftMap.setControlVisibility({zoomControl: true});
// Create a split panel with the two maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  orientation: 'horizontal',
  wipe: true
});
// Remove the default map from the root panel.
ui.root.clear();
// Add our split panel to the root panel.
ui.root.add(splitPanel);
////////////////////////
// Make the UI
////////////////////////
//////////
// Set the flow
/////////
var horizontalFlow = ui.Panel.Layout.flow('horizontal')
var verticalFlow = ui.Panel.Layout.flow('vertical')
// query labels
var image1Label = ui.Label("30 m imagery")
var image1Panel = ui.Panel({ 
                            widgets:[image1Label],
                            //layout:verticalFlow,
                            style: {position: 'top-left'}
                            })
leftMap.add(image1Panel)
/// Image 2 panel
// query labels
var image2Label = ui.Label("90 m imagery")
var image2Panel = ui.Panel({widgets:[image2Label],
                            //layout:verticalFlow,
                            style: {position: 'top-right'}
                            })
// Error begins here.  if you comment the next line, left panel works
rightMap.add(image2Panel)
var linker = ui.Map.Linker([leftMap, rightMap]);
// Reference a Landsat scene.
var image_30m = ee.Image('LANDSAT/LC08/C01/T1/LC08_044034_20170614');
// Define visualization parameters for a true color image.
var vizParams = {'bands': 'B4,B3,B2',
                 'min': 5000,
                 'max': 30000,
                 'gamma': 1.6};
// Get the projection information for a band.
var band2 = image_30m.select('B2');
print('CRS:', band2.projection().crs());
// Display a bilinear resampled image with 10m pixel spacing.
var image_10m = image_30m.resample('bilinear').reproject({
  crs: band2.projection().crs(),
  scale: 90
});
leftMap.addLayer(image_30m, vizParams, 'image_30m');
rightMap.addLayer(image_10m, vizParams, 'image_30m');
leftMap.centerObject(image_30m, 14)
leftMap.centerObject(image_10m, 14)