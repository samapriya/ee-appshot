var imageCollection = ee.ImageCollection("COPERNICUS/S2").filterDate('2022-03-01','2022-08-01');
var table = ee.FeatureCollection("users/spiruel/ukfields");
Map.setOptions('HYBRID');
var addNDVI = function(image) {
  var ndvi = image.normalizedDifference(['B8', 'B4']).rename('NDVI');
  return image.addBands(ndvi);
};
var ndvi = imageCollection.map(addNDVI).select('NDVI');
// var initialField = 1669085; // Initial selected field
// var sel_field = table.filter(ee.Filter.eq("fid", initialField));
// Create a Map
Map.setCenter(0.16, 52.44, 12)
// Map.centerObject(sel_field, 13);
var visParams = {
  min: -1.0,
  max: 1.0,
  palette: [
    'red',' white', 'green'
  ],
};
// Add initial layers
Map.addLayer(ndvi.filterDate('2022-06-01','2022-08-01').median(), visParams, 'median NDVI', false);
var empty = ee.Image().byte();
var outline = empty.paint({
  featureCollection: table,
  color: 'random',
  width: 3
});
Map.addLayer(outline.randomVisualizer(), {opacity:0.5}, 'UK Fields')
// Map.addLayer(table, {}, 'All Fields');
// Map.addLayer(sel_field, { color: 'red' }, 'Selected Field');
// Create a panel for the chart
var chartPanel = ui.Panel({
  style: {
    position: 'bottom-right',
    width: '400px',
    height: '300px'
  }
});
// Add the panel to the map
// Map.add(chartPanel);
// Create an empty chart
var chart = ui.Chart();
// Add the chart to the panel
chartPanel.add(chart);
// Create an onClick function for the map
Map.onClick(function(coords) {
  // Get the clicked point
  var clickedPoint = ee.Geometry.Point(coords.lon, coords.lat);
  // Filter the table to find the clicked field
  var clickedField = table.filterBounds(clickedPoint).first();
  if (clickedField) {
    // Update the selected field
    sel_field = ee.FeatureCollection([clickedField]);
    // Clear previous selected field and add the new one
    Map.layers().forEach(function(layer) {
      if (layer.getName() === 'Selected Field') {
        Map.layers().remove(layer);
      }
    });
    Map.addLayer(sel_field, { color: 'red' }, 'Selected Field');
    // Update the chart with data for the selected field
    updateChart();
  }
});
// // Function to update the chart based on the selected field
// var updateChart = function() {
//   var chartData = {
//     imageCollection: ndvi,
//     region: sel_field,
//     reducer: ee.Reducer.mean(),
//     scale: 1,
//     xProperty: 'system:time_start'
//   };
//   // Create the chart
//   chart = ui.Chart.image.seriesByRegion(ndvi, sel_field, ee.Reducer.mean())
//     .setChartType('LineChart')
//     .setOptions({
//       title: 'NDVI Over Time',
//       hAxis: {title: 'Date'},
//       vAxis: {title: 'NDVI'},
//       lineWidth: 2,
//       colors: ['1d6b99'],
//       legend: { position: 'none' },
//       backgroundColor: '#f4f4f4',
//       chartArea: { width: '80%', height: '70%' }
//     });
//   // Clear the previous chart and add the updated one
//   chartPanel.clear();
//   chartPanel.add(chart);
// };
// // Initialize the chart with the initial selected field
// updateChart();