var Indonesia = ui.import && ui.import("Indonesia", "table", {
      "id": "users/masitamanessa/INDONESIA_KAB"
    }) || ee.FeatureCollection("users/masitamanessa/INDONESIA_KAB"),
    table = ui.import && ui.import("table", "table", {
      "id": "users/masitamanessa/INDONESIA_KAB"
    }) || ee.FeatureCollection("users/masitamanessa/INDONESIA_KAB");
print(Indonesia);
//Set the area
var ids = 'Kota SEMARANG';
var roi = Indonesia.filterMetadata('Kabupaten_', 'equals',ids);
Map.centerObject(roi,11);
// defaults
var extent = roi; // extent of analysis
var profilesOn = false; // status of analysis profiles
// ####################### Sourcing Data #
function getData() {
  //Data
  var S1 = ee.ImageCollection('COPERNICUS/S1_GRD')
    //.filterBounds(roi)
    .filterDate('2019-11-01','2021-09-30')
    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'));
  return S1;
}
// filtered dataset
var dataset = getData();
//print(dataset);
function filterSpeckles(image) {
  var vv = image.select('VV'); //select the VV polarization band
  var vv_smoothed = vv.focal_median(100,'circle','meters').rename('VV_Filtered'); //Apply a focal median filter
  return image.addBands(vv_smoothed); // Add filtered VV band to original image
}
function classifyWater (image) {
  var vv = image.select('VV_Filtered');
  var water = vv.lt(-10).rename('Water');  //Identify all pixels below threshold and set them equal to 1. All other pixels set to 0
  water = water.updateMask(water); //Remove all pixels equal to 0
  return image.addBands(water);  //Return image with added classified water band
}
var waterPallete    = ['#0000FF','#FFFFFF'];
var waterPalleteSum = ['51f1e3', 'ffd761', 'ff6437', 'ff0414'];
function buildChart(collection) {
    // A time series chart from computed surfaces
    var chart = ui.Chart.image.series({
        imageCollection: collection,
        region: extent,
        reducer: ee.Reducer.sum(),
        scale: 30,
    });
    // Custom chart options
    chart.setOptions({
        title: 'Inundated Pixel',
        legend: { position: 'none' },
        vAxis: { title: 'Number of Inundated Pixels' },
        hAxis: { title: 'Date' },
        lineWidth: 2
    });
    // Chart styling
    chart.style().set({
        width: '480px',
        height: '300px'
    });
    // Update the map and label when the chart is clicked.
    chart.onClick(function (xValue, yValue, seriesName) {
        if (!xValue) return;  // Selection was cleared.
        // Show the image for the clicked year.
        var image = ee.Image(collection.filter(ee.Filter.equals('system:time_start', xValue)).first()).clip(extent);
        var layer = ui.Map.Layer(image, {
            min: 0,
            max: 250,
            palette: waterPallete,
            bands: 'Water'
        });
        profilesOn ? Map.layers().reset([layer, profiles]) : Map.layers().reset([layer]);
        // Show a label with the date on the map.
        label.setValue('Inundation Distribution on '+ (new Date(xValue)).toUTCString());
    });
    return chart;
}
// Create the UI
// Scale Picker :: different scales of analysis
var analysisExtent = {
    'Choose An Analysis Scale': 'default',
    'Kota Semarang': 'Kota SEMARANG',
    'Kota Surabaya': 'Kota SURABAYA',
    'Kota Jakarta Utara' : 'Kota JAKARTA UTARA',
    'Kota Jakarta Pusat' : 'Kota JAKARTA PUSAT',
    'Kabupaten Bogor' : 'BOGOR',
    'Kota Gorontalo' : 'Kota GORONTALO', 
    'Kabupaten Gorontalo' : 'GORONTALO',
    'Kota Jakarta Barat' : 'Kota JAKARTA BARAT'
};
var selectScale = ui.Select({
    items: Object.keys(analysisExtent),
    onChange: function (value) {
        // render analysis extent and charts at scale selected
        if (analysisExtent[value] == 'Kota SEMARANG') {
            var roi1 = Indonesia.filterMetadata('Kabupaten_', 'equals', analysisExtent[value]);
            extent = roi1;
            Map.centerObject(extent, 12);
        } else if (analysisExtent[value] == 'Kota SURABAYA') {
            var roi2 = Indonesia.filterMetadata('Kabupaten_', 'equals', analysisExtent[value]);
            extent = roi2;
            Map.centerObject(extent, 11);
        } else if (analysisExtent[value] == 'Kota JAKARTA UTARA')  {
           var roi3 = Indonesia.filterMetadata('Kabupaten_', 'equals', analysisExtent[value]);
           extent = roi3;
           Map.centerObject(extent, 11);
        } else if (analysisExtent[value] == 'Kota JAKARTA PUSAT')  {
           var roi4 = Indonesia.filterMetadata('Kabupaten_', 'equals', analysisExtent[value]);
           extent = roi4;
           Map.centerObject(extent, 12);
        } else if (analysisExtent[value] == 'BOGOR')  {
           var roi5 = Indonesia.filterMetadata('Kabupaten_', 'equals', analysisExtent[value]);
           extent = roi5;
           Map.centerObject(extent, 12);
        } else if (analysisExtent[value] == 'GORONTALO')  {
           var roi6 = Indonesia.filterMetadata('Kabupaten_', 'equals', analysisExtent[value]);
           extent = roi6;
           Map.centerObject(extent, 12);
        } else if (analysisExtent[value] == 'Kota GORONTALO')  {
           var roi7 = Indonesia.filterMetadata('Kabupaten_', 'equals', analysisExtent[value]);
           extent = roi7;
           Map.centerObject(extent, 12);
        } else if (analysisExtent[value] == 'Kota JAKARTA BARAT')  {
           var roi8 = Indonesia.filterMetadata('Kabupaten_', 'equals', analysisExtent[value]);
           extent = roi8;
           Map.centerObject(extent, 12);
        } else {
            return;
        }
        rightPanel.widgets().set(1, buildChart(ci_collection));
        // rightPanel.widgets().set(2, buildChart(ocx_collection));
    },
    style: { width: '450px', color: 'red' }
});
selectScale.setPlaceholder('Choose Scale of Analysis');
var rightPanel = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical'),
    style: {
        position: 'top-right',
        width: '500px'
    }
});
var buttonPanel = ui.Panel({
    layout: ui.Panel.Layout.flow('horizontal'),
    style: {
        width: '400px'
    }
});
buttonPanel.widgets().set(1,
    ui.Button({
        label: 'Sum up pixels',
        style: { width: '45%', color: 'red' },
        onClick: function () {
            Map.layers().reset();
            var images = ee.Image(ci_collection.sum().clip(extent));
            var layers = ui.Map.Layer(images, {
                min: 0,
                max: 100,
                palette: waterPalleteSum,
                bands: 'Water'
            });
            Map.layers().reset([layers]);
            profilesOn = false;
        }
    })
);
// CI ##
var fS = dataset.map(filterSpeckles);
var wI = fS.map(classifyWater);
var ci_collection = wI.select('Water');
// A time series chart from computed surfaces
var ciChart = buildChart(ci_collection);
// Add charts to panel
rightPanel.widgets().set(0, selectScale);
rightPanel.widgets().set(1, ciChart);
rightPanel.widgets().set(2, buttonPanel);
// Display panel
Map.add(rightPanel);
// Create a label on the map.
var label = ui.Label('Click a point on the chart to show the Indundation Areas');
Map.add(label);
//print(ci_collection);