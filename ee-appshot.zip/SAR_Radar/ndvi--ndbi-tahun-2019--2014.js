var geometry2 = ui.import && ui.import("geometry2", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #98ff00 */ee.Geometry.MultiPoint(),
    imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "COPERNICUS/S2_SR"
    }) || ee.ImageCollection("COPERNICUS/S2_SR"),
    boundary = ui.import && ui.import("boundary", "table", {
      "id": "users/SAR_Radar/DENPASAR_BENER"
    }) || ee.FeatureCollection("users/SAR_Radar/DENPASAR_BENER");
// NDVI & NDBI 2019
var S2A = ee.ImageCollection('COPERNICUS/S2_SR')
                   .filterDate('2019-01-01', '2019-12-01')
                .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 30))
                .map(maskS2clouds)
                .median()
                .clip(boundary);
function maskS2clouds(image) {
  var qa = image.select('QA60');
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(1);
}  
var RGBTrue = S2A.select(['B4', 'B3', 'B2']);
var RGBparam = { min: 0, max: 3000,};
Map.addLayer(RGBTrue, RGBparam, 'Sentinel RGB 432');
var nir = S2A.select('B8');
var red = S2A.select('B3');
var ndvi = nir.subtract(red).divide(nir.add(red)).rename('NDVI S2A');
var NDVIparam = {min: -1, max: 1, palette:['blue', 'white', 'green']};
Map.addLayer(ndvi, NDVIparam, 'NDVI Denpasar 2019');
var swir =S2A.select('B11');                                                            
var ndbi = swir.subtract(nir).divide(swir.add(nir)).rename('NDBI S2A');
var NDBIparam = {min: -1, max: 1, palette:['green', 'yellow', 'red']};        
Map.addLayer(ndbi, NDBIparam, 'NDBI Denpasar 2019');
// NDVI & NDBI 2014
// Making NDVI map
// Import Landsat 8 TOA images
// Get the image in certain date. Extract the median values
var image =ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
         .filterDate('2014-01-01', '2014-12-31')
         .median();
// 1. Clip the image in a specified boundary.
var composite = image.clip(boundary);
var composite = composite.toFloat()
// Add map layers
Map.addLayer(composite , {bands: ['B6', 'B5', 'B4']}, "composite", false);
var landsat = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA');
// 2. Compute the NDVI 
var nir = image.select('B5');
var red = image.select('B4');
var ndvi = nir.subtract(red).divide(nir.add(red));
var ndvi = ndvi.clip(boundary);
// Add map layers
Map.addLayer(ndvi, {min: 0, max: 1, palette: ['black', 'yellow', 'green']}, 'continuous NDVI',false);
//Compute the mean and stdev of NDVI
var mean_ndvi = ndvi.reduceRegion({
  reducer: ee.Reducer.mean(),
  geometry: boundary,
  scale: 30
});
var sd_ndvi = ndvi.reduceRegion({
  reducer: ee.Reducer.stdDev(),
  geometry: boundary,
  scale: 30
});
print(mean_ndvi);
print(sd_ndvi);
// 3. Classify NDVI into 5 classes
var ndvi2 = ee.Image(1)
          .where(ndvi.gt(0.0).and(ndvi.lte(0.2)), 2)
          .where(ndvi.gt(0.2).and(ndvi.lte(0.4)), 3)
          .where(ndvi.gt(0.4).and(ndvi.lte(0.6)), 4)
          .where(ndvi.gt(0.6), 5)
var ndvi2 = ndvi2.clip(boundary);
// Add map layers
Map.addLayer(ndvi2, {min: 1, max: 5, palette: ['#654321','#FFA500','#FFFF00', '#00FF00', '#008000']}, 'Classified NDVI',true);
// Making NDVI map
// Import Landsat 8 TOA images
// Get the image in certain date. Extract the median values
var image1 =ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
         .filterDate('2014-01-01', '2014-12-31')
         .median();
// 1. Clip the image in a specified boundary.
var composite1 = image1.clip(boundary);
var composite1 = composite1.toFloat()
var landsat1 = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA');
// 2. Compute the NDVI 
var nir1 = image1.select('B5');
var red1 = image1.select('B6');
var ndbi1 = nir1.subtract(red1).divide(nir1.add(red1));
var ndbi1 = ndbi1.clip(boundary);
// Add map layers
Map.addLayer(ndbi1, {min: 0, max: 1, palette: ['black', 'yellow', 'green']}, 'continuous NDBI',false);
//Compute the mean and stdev of NDBI
var mean_ndbi1 = ndbi1.reduceRegion({
  reducer: ee.Reducer.mean(),
  geometry: boundary,
  scale: 30
});
var sd_ndbi1 = ndbi1.reduceRegion({
  reducer: ee.Reducer.stdDev(),
  geometry: boundary,
  scale: 30
});
print(mean_ndbi1);
print(sd_ndbi1);
// 3. Classify NDVI into 5 classes
var ndbi3 = ee.Image(1)
          .where(ndbi1.gt(0.0).and(ndbi1.lte(0.2)), 2)
          .where(ndbi1.gt(0.2).and(ndbi1.lte(0.4)), 3)
          .where(ndbi1.gt(0.4).and(ndbi1.lte(0.6)), 4)
          .where(ndbi1.gt(0.6), 5)
var ndbi3 = ndbi3.clip(boundary);
// Add map layers
Map.addLayer(ndbi3, {min: 1, max: 5, palette: ['#654321','#FFA500','#FFFF00', '#00FF00', '#008000']}, 'Classified NDBI 2014',true);