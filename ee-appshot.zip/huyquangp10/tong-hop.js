var rgPB = ui.import && ui.import("rgPB", "table", {
      "id": "projects/huyquangpecc1/assets/RG_CACTINHPHIABAC_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_CACTINHPHIABAC_WGS84"),
    rgyb = ui.import && ui.import("rgyb", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TINHYENBAI_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TINHYENBAI_WGS84");
// Model
var m = {};
m.tinhs = ['Tỉnh Yên Bái', 'Tỉnh Lào Cai', 'Tỉnh Phú Thọ', 'Tỉnh Quảng Ninh', 'Tỉnh Thanh Hóa'];
m.col = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
    var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11;
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgyb); 
//Map.addLayer(m.col, visParams, 'S2_TinhYenBai_1_2019-01-01_2019-09-30', true);
m.tinhinfo = {
  tinh: {
    'Tỉnh Yên Bái': {
     layer: 'S2_TinhYenBai_1_2019-01-01_2019-09-30'
    }
  }
};
//components
var c = {};
c.controlPanel = ui.Panel();
c.map = ui.Map();
c.info = {};
c.info.titleLabel = ui.Label('BỘ TÀI NGUYÊN VÀ MÔI TRƯỜNG CỤC VIỄN THÁM QUỐC GIA');
c.info.aboutLabel = ui.Label(
  'Hoạt động khai thác khoáng sản các tỉnh phía bắc.');
c.info.panel = ui.Panel([c.info.titleLabel, c.info.aboutLabel]);
//c.selectYear = {};
//c.selectYear.label = ui.Label('Select a year to display');
//c.selectYear.slider = ui.Slider({
//  min: 0,  // TODO: GET FROM MODEL
//  max: 10, // TODO: GET FROM MODEL
//  step: 1
//});
//c.selectYear.panel = ui.Panel([c.selectYear.label, c.selectYear.slider]);
c.selecttinh = {};
c.selecttinh.label = ui.Label('Select a band to display');
c.selecttinh.selector = ui.Select(Object.keys(m.tinhinfo.tinh)); 
c.selecttinh.panel = ui.Panel([c.selecttinh.label, c.selecttinh.selector]);
c.dividers = {};
c.dividers.divider1 = ui.Panel();
c.dividers.divider2 = ui.Panel();
c.tinhLabel = ui.Label();
c.tinhSelector = ui.Select(m.tinhs, 'Chọn tỉnh thực hiện');
c.selecttinh.panel = ui.Panel([c.tinhSelector]);
c.selecttinh.selector = ui.Select(Object.keys(m.tinhinfo.tinh)); 
//composittion
ui.root.clear();
ui.root.add(c.controlPanel);
ui.root.add(c.map);
c.controlPanel.add(c.info.panel);
c.controlPanel.add(c.dividers.divider1);
c.controlPanel.add(c.selecttinh.panel);
//styling
var s = {};
s.aboutText = {
  fontSize: '20px',
  color: 'green'
};
//s.widgetTitle = {
//  fontSize: '20px',
//  fontWeight: 'bold',
//  margin: '8px 8px 0px 8px',
//  color: 'blue'
//};
s. divider = {
  backgroundColor: 'blue',
  height: '4px',
  margin: '20px 0px'
};
c.controlPanel.style().set({
  width: '300px'
});
c.info.titleLabel.style().set({
    fontSize: '18px',
    fontWeight: 'bold'
});
s.tinhSelector = {
  width: '275px',
  Color: 'red'
};
c.info.aboutLabel.style().set(s.aboutText);
//c.selecttinh.label.style().set(s.widgetTitle);
Object.keys(c.dividers).forEach(function(key){
  c.dividers[key].style().set(s.divider);
});
//Behavior
function updateMap() {
  var tinh = c.selecttinh.selector.getValue(m.tinhs);
  var img = m.col;
  var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
  var layer = ui.Map.Layer({
    eeObject: img,
    visParams: visParams,
    name: 'S2_TinhYenBai_1_2019-01-01_2019-09-30'
});
c.map.layers(rgyb).set(0, layer);
}
c.selecttinh.selector.onChange(updateMap);
updateMap();
c.tinhSelector.style().set(s.tinhSelector);