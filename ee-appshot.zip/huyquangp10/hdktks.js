var Mineral = ui.import && ui.import("Mineral", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            107.15135205784792,
            21.000530340452716
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.14448560276979,
            20.967513309760182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.14963544407838,
            20.992517168779898
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.24870929412843,
            20.992697069760528
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.30122152666496,
            21.031028866990372
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.34103838085642,
            21.026581461936317
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.3370901691865,
            21.033791689000424
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.32970872997751,
            21.0327502333139
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.30679193615427,
            21.044926798559334
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.28258768200388,
            21.038758531354063
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.28782335400095,
            21.02233527614357
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.31168428539743,
            21.028424108702243
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.28284517406931,
            21.063349971198505
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.26653734325876,
            21.057903357605202
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.33983675121775,
            21.049893269588647
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([107.15135205784792, 21.000530340452716]),
            {
              "lc": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([107.14448560276979, 20.967513309760182]),
            {
              "lc": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([107.14963544407838, 20.992517168779898]),
            {
              "lc": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([107.24870929412843, 20.992697069760528]),
            {
              "lc": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([107.30122152666496, 21.031028866990372]),
            {
              "lc": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([107.34103838085642, 21.026581461936317]),
            {
              "lc": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([107.3370901691865, 21.033791689000424]),
            {
              "lc": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([107.32970872997751, 21.0327502333139]),
            {
              "lc": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([107.30679193615427, 21.044926798559334]),
            {
              "lc": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([107.28258768200388, 21.038758531354063]),
            {
              "lc": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([107.28782335400095, 21.02233527614357]),
            {
              "lc": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([107.31168428539743, 21.028424108702243]),
            {
              "lc": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([107.28284517406931, 21.063349971198505]),
            {
              "lc": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([107.26653734325876, 21.057903357605202]),
            {
              "lc": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([107.33983675121775, 21.049893269588647]),
            {
              "lc": 0,
              "system:index": "14"
            })]),
    Forest = ui.import && ui.import("Forest", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            107.18814849221053,
            20.98860183431577
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.20703124367537,
            21.011679209404747
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.19432830178084,
            20.969367963899433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.16308593117537,
            21.013922652750356
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.25887297951522,
            21.020332304935508
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.34882354103866,
            21.02161420231138
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.16583251320662,
            20.970650298943113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.12223052346053,
            20.94916973643356
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.19295501076522,
            21.08024921190502
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.59670749803804,
            21.06221174051565
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.56615177294039,
            21.129157253956564
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.6605655302646,
            21.15285321115185
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.75046934292246,
            21.00595803099448
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.24883804016115,
            20.984082440954506
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.24782952957155,
            20.98640643627127
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 1
      },
      "color": "#2fff02",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #2fff02 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([107.18814849221053, 20.98860183431577]),
            {
              "lc": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([107.20703124367537, 21.011679209404747]),
            {
              "lc": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([107.19432830178084, 20.969367963899433]),
            {
              "lc": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([107.16308593117537, 21.013922652750356]),
            {
              "lc": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([107.25887297951522, 21.020332304935508]),
            {
              "lc": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([107.34882354103866, 21.02161420231138]),
            {
              "lc": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([107.16583251320662, 20.970650298943113]),
            {
              "lc": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([107.12223052346053, 20.94916973643356]),
            {
              "lc": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([107.19295501076522, 21.08024921190502]),
            {
              "lc": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([107.59670749803804, 21.06221174051565]),
            {
              "lc": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([107.56615177294039, 21.129157253956564]),
            {
              "lc": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([107.6605655302646, 21.15285321115185]),
            {
              "lc": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([107.75046934292246, 21.00595803099448]),
            {
              "lc": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([107.24883804016115, 20.984082440954506]),
            {
              "lc": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([107.24782952957155, 20.98640643627127]),
            {
              "lc": 1,
              "system:index": "14"
            })]),
    Uban = ui.import && ui.import("Uban", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            107.27015804449583,
            21.0070785791347
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.2849209229138,
            21.01188606467992
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.23754238287474,
            21.008360590427532
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.10261654058958,
            20.951300433816378
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.03326534430052,
            20.985282702237875
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.02262233892942,
            20.955147870716605
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.08304714361692,
            20.966689587721245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.3343593994763,
            21.01380901551818
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 2
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([107.27015804449583, 21.0070785791347]),
            {
              "lc": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([107.2849209229138, 21.01188606467992]),
            {
              "lc": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([107.23754238287474, 21.008360590427532]),
            {
              "lc": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([107.10261654058958, 20.951300433816378]),
            {
              "lc": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([107.03326534430052, 20.985282702237875]),
            {
              "lc": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([107.02262233892942, 20.955147870716605]),
            {
              "lc": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([107.08304714361692, 20.966689587721245]),
            {
              "lc": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([107.3343593994763, 21.01380901551818]),
            {
              "lc": 2,
              "system:index": "7"
            })]),
    Water = ui.import && ui.import("Water", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            107.2556113178613,
            20.972721821855664
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.38607396434567,
            21.023364549288864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.38126744579098,
            21.09897607817406
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.3709677631738,
            21.05989355993506
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.06266393016598,
            20.982979963970415
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.00498570750973,
            20.94194317233209
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.11622227977536,
            20.931040882568364
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.00979222606442,
            20.923344670838652
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.24050511668942,
            20.932323546086135
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.50005711864254,
            21.10794438609954
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.85299290965817,
            21.425966868762156
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.01663328035943,
            20.991259733957758
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.99994239501954,
            21.358996769587424
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            108.02740821533204,
            21.466390710567033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            108.0026889770508,
            21.227203852150634
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            108.01504859619142,
            21.16702614124948
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.66176948242189,
            21.359073190214147
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.99925574951173,
            21.139566408960604
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 3
      },
      "color": "#4febff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #4febff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([107.2556113178613, 20.972721821855664]),
            {
              "lc": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([107.38607396434567, 21.023364549288864]),
            {
              "lc": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([107.38126744579098, 21.09897607817406]),
            {
              "lc": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([107.3709677631738, 21.05989355993506]),
            {
              "lc": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([107.06266393016598, 20.982979963970415]),
            {
              "lc": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([107.00498570750973, 20.94194317233209]),
            {
              "lc": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([107.11622227977536, 20.931040882568364]),
            {
              "lc": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([107.00979222606442, 20.923344670838652]),
            {
              "lc": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([107.24050511668942, 20.932323546086135]),
            {
              "lc": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([107.50005711864254, 21.10794438609954]),
            {
              "lc": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([107.85299290965817, 21.425966868762156]),
            {
              "lc": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([107.01663328035943, 20.991259733957758]),
            {
              "lc": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([107.99994239501954, 21.358996769587424]),
            {
              "lc": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([108.02740821533204, 21.466390710567033]),
            {
              "lc": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([108.0026889770508, 21.227203852150634]),
            {
              "lc": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([108.01504859619142, 21.16702614124948]),
            {
              "lc": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([107.66176948242189, 21.359073190214147]),
            {
              "lc": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([107.99925574951173, 21.139566408960604]),
            {
              "lc": 3,
              "system:index": "17"
            })]),
    Bare = ui.import && ui.import("Bare", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            107.13095975741021,
            21.033724998161667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.97028470858208,
            21.008567791635468
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.97303129061333,
            21.02347034368342
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.98418928011529,
            20.976834819884463
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.95174527987115,
            20.977475956751707
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.94590879305474,
            21.03204264229701
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.93955732210748,
            21.037810640461792
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.95861173494927,
            21.044219265380857
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.00341535433404,
            21.064164345103848
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.890810415351,
            20.93795734097637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.89493028839787,
            20.933949131783102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.89407198151311,
            20.939480432340748
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.89510194977483,
            20.9438091337326
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.8809398861762,
            20.936794971354516
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            106.89870683869084,
            20.938518481702513
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.3740941415744,
            21.21452398898058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.37246335849335,
            21.20680242415931
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.37396539554169,
            21.200800929104894
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.37422288760712,
            21.211483420985004
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.43205114539128,
            21.242578794257113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.42037817175847,
            21.227378218588168
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 4
      },
      "color": "#ed9f1f",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ed9f1f */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([107.13095975741021, 21.033724998161667]),
            {
              "lc": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([106.97028470858208, 21.008567791635468]),
            {
              "lc": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([106.97303129061333, 21.02347034368342]),
            {
              "lc": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([106.98418928011529, 20.976834819884463]),
            {
              "lc": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([106.95174527987115, 20.977475956751707]),
            {
              "lc": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([106.94590879305474, 21.03204264229701]),
            {
              "lc": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([106.93955732210748, 21.037810640461792]),
            {
              "lc": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([106.95861173494927, 21.044219265380857]),
            {
              "lc": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([107.00341535433404, 21.064164345103848]),
            {
              "lc": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([106.890810415351, 20.93795734097637]),
            {
              "lc": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([106.89493028839787, 20.933949131783102]),
            {
              "lc": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([106.89407198151311, 20.939480432340748]),
            {
              "lc": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([106.89510194977483, 20.9438091337326]),
            {
              "lc": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([106.8809398861762, 20.936794971354516]),
            {
              "lc": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([106.89870683869084, 20.938518481702513]),
            {
              "lc": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([107.3740941415744, 21.21452398898058]),
            {
              "lc": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([107.37246335849335, 21.20680242415931]),
            {
              "lc": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([107.37396539554169, 21.200800929104894]),
            {
              "lc": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([107.37422288760712, 21.211483420985004]),
            {
              "lc": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([107.43205114539128, 21.242578794257113]),
            {
              "lc": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([107.42037817175847, 21.227378218588168]),
            {
              "lc": 4,
              "system:index": "20"
            })]),
    Road = ui.import && ui.import("Road", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            107.19105520935643,
            20.98193979395436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.19839373322118,
            20.986587815099494
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.19644108505834,
            20.98534568567799
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.16202149615198,
            21.05096579110168
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.14544544443994,
            21.046389867847612
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.14161905284828,
            21.03042615537948
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 5
      },
      "color": "#c245b0",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #c245b0 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([107.19105520935643, 20.98193979395436]),
            {
              "lc": 5,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([107.19839373322118, 20.986587815099494]),
            {
              "lc": 5,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([107.19644108505834, 20.98534568567799]),
            {
              "lc": 5,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([107.16202149615198, 21.05096579110168]),
            {
              "lc": 5,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([107.14544544443994, 21.046389867847612]),
            {
              "lc": 5,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([107.14161905284828, 21.03042615537948]),
            {
              "lc": 5,
              "system:index": "5"
            })]),
    Sand = ui.import && ui.import("Sand", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            107.41694637232588,
            21.14446295354153
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.390853843029,
            21.144783161362987
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.00676092822236,
            20.99701343147669
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.60904625968861,
            21.070532120678482
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.59175137596058,
            21.076518871569725
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.59499148445057,
            21.08048320938472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.62058010809656,
            21.101261285420403
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.61037049405549,
            21.09743074608658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            107.58725117455674,
            21.020181579171417
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 6
      },
      "color": "#f95cff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #f95cff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([107.41694637232588, 21.14446295354153]),
            {
              "lc": 6,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([107.390853843029, 21.144783161362987]),
            {
              "lc": 6,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([107.00676092822236, 20.99701343147669]),
            {
              "lc": 6,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([107.60904625968861, 21.070532120678482]),
            {
              "lc": 6,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([107.59175137596058, 21.076518871569725]),
            {
              "lc": 6,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([107.59499148445057, 21.08048320938472]),
            {
              "lc": 6,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([107.62058010809656, 21.101261285420403]),
            {
              "lc": 6,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([107.61037049405549, 21.09743074608658]),
            {
              "lc": 6,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([107.58725117455674, 21.020181579171417]),
            {
              "lc": 6,
              "system:index": "8"
            })]),
    cpqn = ui.import && ui.import("cpqn", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_QuangNinh_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_QuangNinh_WGS84"),
    rgqn = ui.import && ui.import("rgqn", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TINHQUANGNINH_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TINHQUANGNINH_WGS84"),
    QNTK1 = ui.import && ui.import("QNTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_1_2019-01-01_2019-09-30_WGS84"),
    QNTK2 = ui.import && ui.import("QNTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_2_2019-10-01_2019-12-30_WGS84"),
    QNTK3 = ui.import && ui.import("QNTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_3_2020-01-01_2020-09-30_WGS84"),
    QNTK4 = ui.import && ui.import("QNTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_4_2020-10-01_2020-12-30_WGS84");
Map.setCenter(107.5368, 21.2768, 10);
// ẢNH THỜI KỲ 1
var S2_QN1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgqn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK1
 Map.addLayer(S2_QN1, visParams, 'S2_TinhQuangNinh_1_2019-01-01_2019-09-30', true);
 // Tạo tập dữ liệu mẫu 
var samples = Mineral.merge(Forest).merge(Uban).merge(Water).merge(Bare).merge(Road).merge(Sand);
// Tạo nhãn lưu giữ thuộc tính lớp phủ dưới dạng các số nguyên liên tiếp bắt đầu từ số không. 
var label = 'lc';
// Sử dụng các kênh của ảnh để dự đoán. 
// Để có được kết quả tốt, phù hợp với từng bài toán thì cần phải tổ hợp thêm kênh. 
var bands = ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B11', 'B12'];
// Chồng dữ liệu mẫu lên hình ảnh để chuẩn bị huấn luyện. 
var trainSet_1 = S2_QN1.select(bands).sampleRegions({collection: samples, properties: [label], scale: 20 });
// Huấn luyện để tạo công cụ phân loại  
var mlModel_1 = ee.Classifier.smileRandomForest(10).train(trainSet_1, label, bands);
// Phân loại hình ảnh với các kênh như đã được sử dụng để huấn luyện. 
var classified_1 = S2_QN1.select(bands).classify(mlModel_1); 
// Vùng có hoạt động khai thác khoáng sản. 
var regions_1 = classified_1.updateMask(classified_1.eq(0)); 
// Hiển thị kết quả phân loại. 
//Map.addLayer(regions_1, {min: 0, max: 2, palette: ['#d326ed']}, 'VKT-TK1', false);
// Chuyển đổi từ raster sang vector TK1
var resultVector_1 = regions_1.reduceToVectors({ reducer: ee.Reducer.countEvery(), geometry: rgqn,  scale: 20, geometryInNativeProjection: true, maxPixels: 1e13, tileScale: 4 }); 
// Hiển thị kết quả vector TK1 
Map.layers().set(20, ui.Map.Layer(QNTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Quảng Ninh_1_2019-01-01_2019-09-30', true));
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 // ẢNH THỜI KỲ 2
var S2_QN2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgqn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK2
 Map.addLayer(S2_QN2, visParams, 'S2_TinhQuangNinh_2_2019-10-01_2019-12-31', false);
// Chồng dữ liệu mẫu lên hình ảnh để chuẩn bị huấn luyện. 
var trainSet_2 = S2_QN2.select(bands).sampleRegions({collection: samples, properties: [label], scale: 20 });
// Huấn luyện để tạo công cụ phân loại  
var mlModel_2 = ee.Classifier.smileRandomForest(10).train(trainSet_2, label, bands);
// Phân loại hình ảnh với các kênh như đã được sử dụng để huấn luyện. 
var classified_2 = S2_QN2.select(bands).classify(mlModel_2); 
// Vùng có hoạt động khai thác khoáng sản. 
var regions_2 = classified_2.updateMask(classified_2.eq(0)); 
// Hiển thị kết quả phân loại. 
//Map.addLayer(regions_2, {min: 0, max: 2, palette: ['#00fe0e']}, 'VKT-TK2', false);
// Chuyển đổi từ raster sang vector TK2
var resultVector_2 = regions_2.reduceToVectors({ reducer: ee.Reducer.countEvery(), geometry: rgqn,  scale: 20, geometryInNativeProjection: true, maxPixels: 1e13, tileScale: 4 }); 
// Hiển thị kết quả vector TK2 
Map.layers().set(20, ui.Map.Layer(QNTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Quảng Ninh_2_2019-10-01_2019-12-31', false));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ẢNH THỜI KỲ 3
var S2_QN3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgqn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK3
 Map.addLayer(S2_QN3, visParams, 'S2_TinhQuangNinh_3_2020-01-01_2020-09-30', false);
// Chồng dữ liệu mẫu lên hình ảnh để chuẩn bị huấn luyện. 
var trainSet_3 = S2_QN3.select(bands).sampleRegions({collection: samples, properties: [label], scale: 20 });
// Huấn luyện để tạo công cụ phân loại  
var mlModel_3 = ee.Classifier.smileRandomForest(10).train(trainSet_3, label, bands);
// Phân loại hình ảnh với các kênh như đã được sử dụng để huấn luyện. 
var classified_3 = S2_QN3.select(bands).classify(mlModel_3); 
// Vùng có hoạt động khai thác khoáng sản. 
var regions_3 = classified_3.updateMask(classified_3.eq(0)); 
// Hiển thị kết quả phân loại. 
//Map.addLayer(regions_3, {min: 0, max: 2, palette: ['#e5fa01']}, 'VKT-TK3', false);
// Chuyển đổi từ raster sang vector TK3
var resultVector_3 = regions_3.reduceToVectors({ reducer: ee.Reducer.countEvery(), geometry: rgqn,  scale: 20, geometryInNativeProjection: true, maxPixels: 1e13, tileScale: 4 }); 
// Hiển thị kết quả vector TK3 
Map.layers().set(20, ui.Map.Layer(QNTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Quảng Ninh_3_2020-01-01_2020-09-30', false));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 // ẢNH THỜI KỲ 4
var S2_QN4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgqn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK4
 Map.addLayer(S2_QN4, visParams, 'S2_TinhQuangNinh_4_2020-10-01_2020-12-31', false);
// Chồng dữ liệu mẫu lên hình ảnh để chuẩn bị huấn luyện. 
var trainSet_4 = S2_QN4.select(bands).sampleRegions({collection: samples, properties: [label], scale: 20 });
// Huấn luyện để tạo công cụ phân loại  
var mlModel_4 = ee.Classifier.smileRandomForest(10).train(trainSet_4, label, bands);
// Phân loại hình ảnh với các kênh như đã được sử dụng để huấn luyện. 
var classified_4 = S2_QN4.select(bands).classify(mlModel_4); 
// Vùng có hoạt động khai thác khoáng sản. 
var regions_4 = classified_4.updateMask(classified_4.eq(0)); 
// Hiển thị kết quả phân loại. 
//Map.addLayer(regions_4, {min: 0, max: 2, palette: ['#071ff8']}, 'VKT-TK4', false);
// Chuyển đổi từ raster sang vector TK4
var resultVector_4 = regions_4.reduceToVectors({ reducer: ee.Reducer.countEvery(), geometry: rgqn,  scale: 20, geometryInNativeProjection: true, maxPixels: 1e13, tileScale: 4 }); 
// Hiển thị kết quả vector TK4 
Map.layers().set(20, ui.Map.Layer(QNTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Quảng Ninh_4_2020-10-01_2020-12-31', false));
// Hiển thị ranh giới tỉnh.
Map.layers().set(20, ui.Map.Layer(rgqn.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Địa giới tỉnh Quảng Ninh', false));
// Hiện thị ranh giới cấp phép.
Map.layers().set(20, ui.Map.Layer(cpqn.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Quảng Ninh', true));
// Xuất kết quả ra file theo định dạng Shape files. 
//Export.table.toDrive({ collection: resultVector_1, folder: 'HĐKTKS', description: 'Hoạt động KT Tỉnh Quảng Ninh_1_2019-01-01_2019-09-30', fileFormat: 'shp' 
//}); 
// Export a cloud-optimized GeoTIFF.
//Export.image.toDrive({
// image: S2_QN1.select(['B4', 'B3', 'B2']),
// description: 'S2_QUANGNINH',
// scale: 10,
// region: rgqn,
// maxPixels: 1e13,
// fileFormat: 'GeoTIFF',
// formatOptions: {cloudOptimized: true}});