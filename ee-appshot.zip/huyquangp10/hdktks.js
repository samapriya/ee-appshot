var Mineral = ui.import && ui.import("Mineral", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            104.89133019484589,
            21.886938935690033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.89113485166203,
            21.88996723862242
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.91499781882574,
            21.872616754241804
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.90731597220709,
            21.87675860415315
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.89494352340697,
            21.885532709453834
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([104.89133019484589, 21.886938935690033]),
            {
              "lc": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([104.89113485166203, 21.88996723862242]),
            {
              "lc": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([104.91499781882574, 21.872616754241804]),
            {
              "lc": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([104.90731597220709, 21.87675860415315]),
            {
              "lc": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([104.89494352340697, 21.885532709453834]),
            {
              "lc": 0,
              "system:index": "4"
            })]),
    Forest = ui.import && ui.import("Forest", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            104.89300479888917,
            21.875695117056384
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.8985408782959,
            21.87382332043819
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.9048065185547,
            21.869442423879505
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.91510620117188,
            21.877208466585326
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.90944137573243,
            21.881190888650185
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.89485015869141,
            21.880188594431353
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.89566555023194,
            21.86407656379208
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 1
      },
      "color": "#2fff02",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #2fff02 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([104.89300479888917, 21.875695117056384]),
            {
              "lc": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([104.8985408782959, 21.87382332043819]),
            {
              "lc": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([104.9048065185547, 21.869442423879505]),
            {
              "lc": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([104.91510620117188, 21.877208466585326]),
            {
              "lc": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([104.90944137573243, 21.881190888650185]),
            {
              "lc": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([104.89485015869141, 21.880188594431353]),
            {
              "lc": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([104.89566555023194, 21.86407656379208]),
            {
              "lc": 1,
              "system:index": "6"
            })]),
    Uban = ui.import && ui.import("Uban", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            104.90218868255616,
            21.87557564141002
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.90042915344239,
            21.878443029313637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.89678134918213,
            21.876690743552608
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.889013671875,
            21.877088992206026
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.90219173445637,
            21.87740138760331
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.89989576353962,
            21.87708278946699
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 2
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([104.90218868255616, 21.87557564141002]),
            {
              "lc": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([104.90042915344239, 21.878443029313637]),
            {
              "lc": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([104.89678134918213, 21.876690743552608]),
            {
              "lc": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([104.889013671875, 21.877088992206026]),
            {
              "lc": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([104.90219173445637, 21.87740138760331]),
            {
              "lc": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([104.89989576353962, 21.87708278946699]),
            {
              "lc": 2,
              "system:index": "5"
            })]),
    Water = ui.import && ui.import("Water", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            104.91845359802247,
            21.878004959890788
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.91883983612061,
            21.87310645565734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.9150203704834,
            21.88358028853058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.92562046051026,
            21.879558109048165
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 3
      },
      "color": "#4febff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #4febff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([104.91845359802247, 21.878004959890788]),
            {
              "lc": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([104.91883983612061, 21.87310645565734]),
            {
              "lc": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([104.9150203704834, 21.88358028853058]),
            {
              "lc": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([104.92562046051026, 21.879558109048165]),
            {
              "lc": 3,
              "system:index": "3"
            })]),
    Bare = ui.import && ui.import("Bare", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            104.88019456863404,
            21.874002536070773
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.8786925315857,
            21.87065714048883
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.88208284378052,
            21.877785924675
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 4
      },
      "color": "#ed9f1f",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ed9f1f */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([104.88019456863404, 21.874002536070773]),
            {
              "lc": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([104.8786925315857, 21.87065714048883]),
            {
              "lc": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([104.88208284378052, 21.877785924675]),
            {
              "lc": 4,
              "system:index": "2"
            })]),
    Road = ui.import && ui.import("Road", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            104.89358415603638,
            21.87826381925776
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.89778985977173,
            21.877308028491658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.889013671875,
            21.876093368488466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.82025507494997,
            21.901553499079455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.82956770464968,
            21.891797760573223
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 5
      },
      "color": "#c245b0",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #c245b0 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([104.89358415603638, 21.87826381925776]),
            {
              "lc": 5,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([104.89778985977173, 21.877308028491658]),
            {
              "lc": 5,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([104.889013671875, 21.876093368488466]),
            {
              "lc": 5,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([104.82025507494997, 21.901553499079455]),
            {
              "lc": 5,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([104.82956770464968, 21.891797760573223]),
            {
              "lc": 5,
              "system:index": "4"
            })]),
    Sand = ui.import && ui.import("Sand", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            104.75279299625778,
            21.80699267703855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.76111857304001,
            21.799900208278295
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.7787138641777,
            21.800856516685528
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.72181847219146,
            21.85412248686134
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.70748455697225,
            21.866868083973305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            104.66700887030501,
            21.888180339759845
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 6
      },
      "color": "#f95cff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #f95cff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([104.75279299625778, 21.80699267703855]),
            {
              "lc": 6,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([104.76111857304001, 21.799900208278295]),
            {
              "lc": 6,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([104.7787138641777, 21.800856516685528]),
            {
              "lc": 6,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([104.72181847219146, 21.85412248686134]),
            {
              "lc": 6,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([104.70748455697225, 21.866868083973305]),
            {
              "lc": 6,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([104.66700887030501, 21.888180339759845]),
            {
              "lc": 6,
              "system:index": "5"
            })]),
    RGYB = ui.import && ui.import("RGYB", "table", {
      "id": "projects/huyquangpecc1/assets/RanhgioitinhYB"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RanhgioitinhYB"),
    RGTH = ui.import && ui.import("RGTH", "table", {
      "id": "projects/huyquangpecc1/assets/Diaphantinh_THANHHOA"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Diaphantinh_THANHHOA");
Map.setCenter(105.3, 21.7, 10);
// ẢNH THỜI KỲ 1
var imageryYB1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 40)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(RGYB); 
 var visParams = {   min: 0.0,   max: 0.25,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK1
 Map.addLayer(imageryYB1, visParams, 'Ảnh yên bái TK1');
 // Tạo tập dữ liệu mẫu 
var samples = Mineral.merge(Forest).merge(Uban).merge(Water).merge(Bare).merge(Road).merge(Sand);
// Tạo nhãn lưu giữ thuộc tính lớp phủ dưới dạng các số nguyên liên tiếp bắt đầu từ số không. 
var label = 'lc';
// Sử dụng các kênh của ảnh để dự đoán. 
// Để có được kết quả tốt, phù hợp với từng bài toán thì cần phải tổ hợp thêm kênh. 
var bands = ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B11', 'B12'];
// Chồng dữ liệu mẫu lên hình ảnh để chuẩn bị huấn luyện. 
var trainSet = imageryYB1.select(bands).sampleRegions({collection: samples, properties: [label], scale: 30 });
// Huấn luyện để tạo công cụ phân loại  
var mlModel = ee.Classifier.smileRandomForest(10).train(trainSet, label, bands);
// Phân loại hình ảnh với các kênh như đã được sử dụng để huấn luyện. 
var classified = imageryYB1.select(bands).classify(mlModel); 
// Vùng có hoạt động khai thác khoáng sản. 
var regionsYB1 = classified.updateMask(classified.eq(0)); 
// Hiển thị kết quả phân loại. 
Map.addLayer(regionsYB1, {min: 0, max: 2, palette: ['red', 'green', 'blue']}, 'VKS-TK1');
// ẢNH THỜI KỲ 2
var imageryYB2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
    var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(RGYB); 
var visParams = {   min: 0.0,   max: 0.25,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK2
 //Map.addLayer(imageryYB2, visParams, 'Ảnh yên bái TK2');
// Tạo tập dữ liệu mẫu 
var samples = Mineral.merge(Forest).merge(Uban).merge(Water).merge(Bare).merge(Road).merge(Sand);
// Tạo nhãn lưu giữ thuộc tính lớp phủ dưới dạng các số nguyên liên tiếp bắt đầu từ số không. 
var label = 'lc';
// Sử dụng các kênh của ảnh để dự đoán. 
// Để có được kết quả tốt, phù hợp với từng bài toán thì cần phải tổ hợp thêm kênh. 
var bands = ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B11', 'B12'];
// Chồng dữ liệu mẫu lên hình ảnh để chuẩn bị huấn luyện. 
var trainSet = imageryYB2.select(bands).sampleRegions({collection: samples, properties: [label], scale: 30 });
// Huấn luyện để tạo công cụ phân loại  
var mlModel = ee.Classifier.smileRandomForest(10).train(trainSet, label, bands);
// Phân loại hình ảnh với các kênh như đã được sử dụng để huấn luyện. 
var classified2 = imageryYB2.select(bands).classify(mlModel); 
// Vùng có hoạt động khai thác khoáng sản. 
var regionsYB2 = classified2.updateMask(classified2.eq(0)); 
// Hiển thị kết quả phân loại. 
Map.addLayer(regionsYB2, {min: 0, max: 2, palette: ['green', 'red', 'blue']}, 'VKS-TK2');
// Xác định và cập nhật các vùng 
var minArea = 2500; 
var maxSize = 20; 
var pixelCount = classified.connectedPixelCount(maxSize); 
var minPixelCount = ee.Image(minArea).divide(ee.Image.pixelArea()); 
var classifiedFin = classified.updateMask(pixelCount.gte(minPixelCount));
// Chuyển đổi từ raster sang vector TK1
var resultVectorYB1 = regionsYB1.reduceToVectors({ reducer: ee.Reducer.countEvery(), geometry: RGYB,  scale: 20, geometryInNativeProjection: true, maxPixels: 1e13, tileScale: 4 }); 
// Hiển thị kết quả vector TK1 
Map.layers().set(20, ui.Map.Layer(resultVectorYB1.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT-Thời kỳ 1', true));
// Chuyển đổi từ raster sang vector TK2
var resultVectorYB2 = regionsYB2.reduceToVectors({ reducer: ee.Reducer.countEvery(), geometry: RGYB,  scale: 20, geometryInNativeProjection: true, maxPixels: 1e13, tileScale: 4 }); 
// Hiển thị kết quả vector TK2 
Map.layers().set(20, ui.Map.Layer(resultVectorYB2.map(function (feature) { return feature.set('style', { color: '#10ebdc', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT-Thời kỳ 2', true));
// Xuất kết quả ra file theo định dạng Shape files. 
// Export.table.toDrive({ collection: resultVector, folder: 'KSKTKSVN', description: 'HĐKTKS', fileFormat: 'shp' 
//}); 
// Export the image, specifying scale and region.
//Export.image.toDrive({
// image: imagery.select(['B4', 'B3', 'B2']),
//  description: 'YENBAI',
//  scale: 15,
//  region: DGHC
//});
// Export a cloud-optimized GeoTIFF.
//Export.image.toDrive({
  //image: imagery.select(['B4', 'B3', 'B2']),
//  description: 'THANHHOA',
//  scale: 20,
 // region: DGTH,
 // fileFormat: 'GeoTIFF',
 // formatOptions: {
 // cloudOptimized: true,
//  }
//});
var imageryTH1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 40)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(RGTH); 
 var visParams = {   min: 0.0,   max: 0.25,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK1
 Map.addLayer(imageryTH1, visParams, 'Ảnh Thanh Hóa TK1');