var cpyb = ui.import && ui.import("cpyb", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_YenBai_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_YenBai_WGS84"),
    rgyb = ui.import && ui.import("rgyb", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TINHYENBAI_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TINHYENBAI_WGS84"),
    YBTK1 = ui.import && ui.import("YBTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHYENBAI_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHYENBAI_1_2019-01-01_2019-09-30_WGS84"),
    YBTK2 = ui.import && ui.import("YBTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHYENBAI_2_2019-10-01_2019-12-31_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHYENBAI_2_2019-10-01_2019-12-31_WGS84"),
    YBTK3 = ui.import && ui.import("YBTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHYENBAI_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHYENBAI_3_2020-01-01_2020-09-30_WGS84"),
    YBTK4 = ui.import && ui.import("YBTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHYENBAI_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHYENBAI_4_2020-10-01_2020-12-30_WGS84"),
    cplc = ui.import && ui.import("cplc", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_LaoCai_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_LaoCai_WGS84"),
    rglc = ui.import && ui.import("rglc", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TINHLAOCAI_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TINHLAOCAI_WGS84"),
    LCTK1 = ui.import && ui.import("LCTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHLAOCAI_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHLAOCAI_1_2019-01-01_2019-09-30_WGS84"),
    LCTK2 = ui.import && ui.import("LCTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHLAOCAI_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHLAOCAI_2_2019-10-01_2019-12-30_WGS84"),
    LCTK3 = ui.import && ui.import("LCTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHLAOCAI_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHLAOCAI_3_2020-01-01_2020-09-30_WGS84"),
    LCTK4 = ui.import && ui.import("LCTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHLAOCAI_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHLAOCAI_4_2020-10-01_2020-12-30_WGS84"),
    cppt = ui.import && ui.import("cppt", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_PhuTho_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_PhuTho_WGS84"),
    rgpt = ui.import && ui.import("rgpt", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TINHPHUTHO_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TINHPHUTHO_WGS84"),
    PTTK1 = ui.import && ui.import("PTTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHPHUTHO_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHPHUTHO_1_2019-01-01_2019-09-30_WGS84"),
    PTTK2 = ui.import && ui.import("PTTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHPHUTHO_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHPHUTHO_2_2019-10-01_2019-12-30_WGS84"),
    PTTK3 = ui.import && ui.import("PTTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHPHUTHO_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHPHUTHO_3_2020-01-01_2020-09-30_WGS84"),
    PTTK4 = ui.import && ui.import("PTTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHPHUTHO_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHPHUTHO_4_2020-10-01_2020-12-30_WGS84"),
    cpth = ui.import && ui.import("cpth", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_ThanhHoa_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_ThanhHoa_WGS84"),
    rgth = ui.import && ui.import("rgth", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhThanhHoa_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhThanhHoa_WSG84"),
    THTK1 = ui.import && ui.import("THTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTHANHHOA_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTHANHHOA_1_2019-01-01_2019-09-30_WGS84"),
    THTK2 = ui.import && ui.import("THTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTHANHHOA_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTHANHHOA_2_2019-10-01_2019-12-30_WGS84"),
    THTK3 = ui.import && ui.import("THTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTHANHHOA_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTHANHHOA_3_2020-01-01_2020-09-30_WGS84"),
    THTK4 = ui.import && ui.import("THTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTHANHHOA_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTHANHHOA_4_2020-10-01_2020-12-30_WGS84"),
    cpqn = ui.import && ui.import("cpqn", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_QuangNinh_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_QuangNinh_WGS84"),
    rgqn = ui.import && ui.import("rgqn", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TINHQUANGNINH_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TINHQUANGNINH_WGS84"),
    QNTK1 = ui.import && ui.import("QNTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_1_2019-01-01_2019-09-30_WGS84"),
    QNTK2 = ui.import && ui.import("QNTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_2_2019-10-01_2019-12-30_WGS84"),
    QNTK3 = ui.import && ui.import("QNTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_3_2020-01-01_2020-09-30_WGS84"),
    QNTK4 = ui.import && ui.import("QNTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHQUANGNINH_4_2020-10-01_2020-12-30_WGS84"),
    cplch = ui.import && ui.import("cplch", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_LaiChau_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_LaiChau_WGS84"),
    rglch = ui.import && ui.import("rglch", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhLaiChau_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhLaiChau_WSG84"),
    LCHTK1 = ui.import && ui.import("LCHTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TinhLaiChau_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TinhLaiChau_1_2019-01-01_2019-09-30_WGS84"),
    LCHTK2 = ui.import && ui.import("LCHTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TinhLaiChau_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TinhLaiChau_2_2019-10-01_2019-12-30_WGS84"),
    LCHTK3 = ui.import && ui.import("LCHTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TinhLaiChau_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TinhLaiChau_3_2020-01-01_2020-09-30_WGS84"),
    LCHTK4 = ui.import && ui.import("LCHTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TinhLaiChau_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TinhLaiChau_4_2020-10-01_2020-12-30_WGS84"),
    rgdb = ui.import && ui.import("rgdb", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhDienBien_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhDienBien_WSG84"),
    DBTK1 = ui.import && ui.import("DBTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHDIENBIEN_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHDIENBIEN_1_2019-01-01_2019-09-30_WGS84"),
    DBTK2 = ui.import && ui.import("DBTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHDIENBIEN_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHDIENBIEN_2_2019-10-01_2019-12-30_WGS84"),
    DBTK3 = ui.import && ui.import("DBTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHDIENBIEN_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHDIENBIEN_3_2020-01-01_2020-09-30_WGS84"),
    DBTK4 = ui.import && ui.import("DBTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHDIENBIEN_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHDIENBIEN_4_2020-10-01_2020-12-30_WGS84"),
    cpsl = ui.import && ui.import("cpsl", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_SonLa_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_SonLa_WGS84"),
    rgsl = ui.import && ui.import("rgsl", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhSonLa_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhSonLa_WSG84"),
    SLTK1 = ui.import && ui.import("SLTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHSONLA_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHSONLA_1_2019-01-01_2019-09-30_WGS84"),
    SLTK2 = ui.import && ui.import("SLTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHSONLA_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHSONLA_2_2019-10-01_2019-12-30_WGS84"),
    SLTK3 = ui.import && ui.import("SLTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHSONLA_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHSONLA_3_2020-01-01_2020-09-30_WGS84"),
    SLTK4 = ui.import && ui.import("SLTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHSONLA_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHSONLA_4_2020-10-01_2020-12-30_WGS84"),
    cphb = ui.import && ui.import("cphb", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_HoaBinh_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_HoaBinh_WGS84"),
    rghb = ui.import && ui.import("rghb", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhHoaBinh_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhHoaBinh_WSG84"),
    HBTK1 = ui.import && ui.import("HBTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHOABINH_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHOABINH_1_2019-01-01_2019-09-30_WGS84"),
    HBTK2 = ui.import && ui.import("HBTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHOABINH_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHOABINH_2_2019-10-01_2019-12-30_WGS84"),
    HBTK3 = ui.import && ui.import("HBTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHOABINH_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHOABINH_3_2020-01-01_2020-09-30_WGS84"),
    HBTK4 = ui.import && ui.import("HBTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHOABINH_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHOABINH_4_2020-10-01_2020-12-30_WGS84"),
    cpnb = ui.import && ui.import("cpnb", "table", {
      "id": "projects/huyquangpecc1/assets/CapPhep_NinhBinh_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/CapPhep_NinhBinh_WGS84"),
    rgnb = ui.import && ui.import("rgnb", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhNinhBinh_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhNinhBinh_WSG84"),
    NBTK1 = ui.import && ui.import("NBTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHNINHBINH_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHNINHBINH_1_2019-01-01_2019-09-30_WGS84"),
    NBTK2 = ui.import && ui.import("NBTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHNINHBINH_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHNINHBINH_2_2019-10-01_2019-12-30_WGS84"),
    NBTK3 = ui.import && ui.import("NBTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHNINHBINH_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHNINHBINH_3_2020-01-01_2020-09-30_WGS84"),
    NBTK4 = ui.import && ui.import("NBTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHNINHBINH_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHNINHBINH_4_2020-10-01_2020-12-30_WGS84"),
    cpbc = ui.import && ui.import("cpbc", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_BacCan_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_BacCan_WGS84"),
    rgbc = ui.import && ui.import("rgbc", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhBacCan_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhBacCan_WSG84"),
    BCTK1 = ui.import && ui.import("BCTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHBACCAN_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHBACCAN_1_2019-01-01_2019-09-30_WGS84"),
    BCTK2 = ui.import && ui.import("BCTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHBACCAN_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHBACCAN_2_2019-10-01_2019-12-30_WGS84"),
    BCTK3 = ui.import && ui.import("BCTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHBACCAN_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHBACCAN_3_2020-01-01_2020-09-30_WGS84"),
    BCTK4 = ui.import && ui.import("BCTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHBACCAN_4_2020-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHBACCAN_4_2020-10-01_2019-12-30_WGS84"),
    cpcb = ui.import && ui.import("cpcb", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_CaoBang_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_CaoBang_WGS84"),
    rgcb = ui.import && ui.import("rgcb", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhCaoBang_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhCaoBang_WSG84"),
    CBTK1 = ui.import && ui.import("CBTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHCAOBANG_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHCAOBANG_1_2019-01-01_2019-09-30_WGS84"),
    CBTK2 = ui.import && ui.import("CBTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHCAOBANG_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHCAOBANG_2_2019-10-01_2019-12-30_WGS84"),
    CBTK3 = ui.import && ui.import("CBTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHCAOBANG_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHCAOBANG_3_2020-01-01_2020-09-30_WGS84"),
    CBTK4 = ui.import && ui.import("CBTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHCAOBANG_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHCAOBANG_4_2020-10-01_2020-12-30_WGS84"),
    cphg = ui.import && ui.import("cphg", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_HaGiang_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_HaGiang_WGS84"),
    rghg = ui.import && ui.import("rghg", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhHaGiang_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhHaGiang_WSG84"),
    HGTK1 = ui.import && ui.import("HGTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHAGIANG_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHAGIANG_1_2019-01-01_2019-09-30_WGS84"),
    HGTK2 = ui.import && ui.import("HGTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHAGIANG_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHAGIANG_2_2019-10-01_2019-12-30_WGS84"),
    HGTK3 = ui.import && ui.import("HGTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHAGIANG_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHAGIANG_3_2020-01-01_2020-09-30_WGS84"),
    HGTK4 = ui.import && ui.import("HGTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHAGIANG_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHAGIANG_4_2020-10-01_2020-12-30_WGS84"),
    cptq = ui.import && ui.import("cptq", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_TuyenQuang_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_TuyenQuang_WGS84"),
    rgtq = ui.import && ui.import("rgtq", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhTuyenQuang_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhTuyenQuang_WSG84"),
    TQTK1 = ui.import && ui.import("TQTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTUYENQUANG_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTUYENQUANG_1_2019-01-01_2019-09-30_WGS84"),
    TQTK2 = ui.import && ui.import("TQTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTUYENQUANG_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTUYENQUANG_2_2019-10-01_2019-12-30_WGS84"),
    TQTK3 = ui.import && ui.import("TQTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTUYENQUANG_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTUYENQUANG_3_2020-01-01_2020-09-30_WGS84"),
    TQTK4 = ui.import && ui.import("TQTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTUYENQUANG_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTUYENQUANG_4_2020-10-01_2020-12-30_WGS84"),
    cptn = ui.import && ui.import("cptn", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_ThaiNguyen_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_ThaiNguyen_WGS84"),
    rgtn = ui.import && ui.import("rgtn", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhThaiNguyen_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhThaiNguyen_WSG84"),
    TNTK1 = ui.import && ui.import("TNTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTHAINGUYEN_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTHAINGUYEN_1_2019-01-01_2019-09-30_WGS84"),
    TNTK2 = ui.import && ui.import("TNTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTHAINGUYEN_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTHAINGUYEN_2_2019-10-01_2019-12-30_WGS84"),
    TNTK3 = ui.import && ui.import("TNTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTHAINGUYEN_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTHAINGUYEN_3_2020-01-01_2020-09-30_WGS84"),
    TNTK4 = ui.import && ui.import("TNTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHTHAINGUYEN_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHTHAINGUYEN_4_2020-10-01_2020-12-30_WGS84"),
    cpls = ui.import && ui.import("cpls", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_LangSon_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_LangSon_WGS84"),
    rgls = ui.import && ui.import("rgls", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhLangSon_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhLangSon_WSG84"),
    LSTK1 = ui.import && ui.import("LSTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHLANGSON_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHLANGSON_1_2019-01-01_2019-09-30_WGS84"),
    LSTK2 = ui.import && ui.import("LSTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHLANGSON_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHLANGSON_2_2019-10-01_2019-12-30_WGS84"),
    LSTK3 = ui.import && ui.import("LSTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHLANGSON_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHLANGSON_3_2020-01-01_2020-09-30_WGS84"),
    LSTK4 = ui.import && ui.import("LSTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHLANGSON_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHLANGSON_4_2020-10-01_2020-12-30_WGS84"),
    cpbg = ui.import && ui.import("cpbg", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_BacGiang_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_BacGiang_WGS84"),
    rgbg = ui.import && ui.import("rgbg", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhBacGiang_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhBacGiang_WSG84"),
    BGTK1 = ui.import && ui.import("BGTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHBACGIANG_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHBACGIANG_1_2019-01-01_2019-09-30_WGS84"),
    BGTK2 = ui.import && ui.import("BGTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHBACGIANG_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHBACGIANG_2_2019-10-01_2019-12-30_WGS84"),
    BGTK3 = ui.import && ui.import("BGTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHBACGIANG_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHBACGIANG_3_2020-01-01_2020-09-30_WGS84"),
    BGTK4 = ui.import && ui.import("BGTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHBACGIANG_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHBACGIANG_4_2020-10-01_2020-12-30_WGS84"),
    cphn = ui.import && ui.import("cphn", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_HaNam_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_HaNam_WGS84"),
    rghn = ui.import && ui.import("rghn", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhHaNam_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhHaNam_WSG84"),
    HNTK1 = ui.import && ui.import("HNTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_1_2019-01-01_2019-09-30_WGS84"),
    HNTK2 = ui.import && ui.import("HNTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_2_2019-10-01_2019-12-30_WGS84"),
    HNTK3 = ui.import && ui.import("HNTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_3_2020-01-01_2020-09-30_WGS84"),
    HNTK4 = ui.import && ui.import("HNTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_4_2020-10-01_2020-12-30_WGS84"),
    cphd = ui.import && ui.import("cphd", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_HaiDuong_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_HaiDuong_WGS84"),
    rghd = ui.import && ui.import("rghd", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhHaiDuong_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhHaiDuong_WSG84"),
    HDTK1 = ui.import && ui.import("HDTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHAIDUONG_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHAIDUONG_1_2019-01-01_2019-09-30_WGS84"),
    HDTK2 = ui.import && ui.import("HDTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHAIDUONG_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHAIDUONG_2_2019-10-01_2019-12-30_WGS84"),
    HDTK3 = ui.import && ui.import("HDTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHAIDUONG_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHAIDUONG_3_2020-01-01_2020-09-30_WGS84"),
    HDTK4 = ui.import && ui.import("HDTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHAIDUONG_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHAIDUONG_4_2020-10-01_2020-12-30_WGS84"),
    rgvp = ui.import && ui.import("rgvp", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhVinhPhuc_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhVinhPhuc_WSG84"),
    VPTK1 = ui.import && ui.import("VPTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHVINHPHUC_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHVINHPHUC_1_2019-01-01_2019-09-30_WGS84"),
    VPTK2 = ui.import && ui.import("VPTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHVINHPHUC_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHVINHPHUC_2_2019-10-01_2019-12-30_WGS84"),
    VPTK3 = ui.import && ui.import("VPTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHVINHPHUC_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHVINHPHUC_3_2020-01-01_2020-09-30_WGS84"),
    VPTK4 = ui.import && ui.import("VPTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHVINHPHUC_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHVINHPHUC_4_2020-10-01_2020-12-30_WGS84"),
    cptphp = ui.import && ui.import("cptphp", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_HaiPhong_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_HaiPhong_WGS84"),
    rgtphp = ui.import && ui.import("rgtphp", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TPHaiPhong_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TPHaiPhong_WSG84"),
    HPTK1 = ui.import && ui.import("HPTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TPHAIPHONG_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TPHAIPHONG_1_2019-01-01_2019-09-30_WGS84"),
    HPTK2 = ui.import && ui.import("HPTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TPHAIPHONG_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TPHAIPHONG_2_2019-10-01_2019-12-30_WGS84"),
    HPTK3 = ui.import && ui.import("HPTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TPHAIPHONG_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TPHAIPHONG_3_2020-01-01_2020-09-30_WGS84"),
    HPTK4 = ui.import && ui.import("HPTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TPHAIPHONG_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TPHAIPHONG_4_2020-10-01_2020-12-30_WGS84"),
    cptphn = ui.import && ui.import("cptphn", "table", {
      "id": "projects/huyquangpecc1/assets/CapPhep_TPHaNoi_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/CapPhep_TPHaNoi_WGS84"),
    rgtphn = ui.import && ui.import("rgtphn", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TPHaNoi_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TPHaNoi_WSG84"),
    rgpb = ui.import && ui.import("rgpb", "table", {
      "id": "projects/huyquangpecc1/assets/RG_CACTINHPHIABAC_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_CACTINHPHIABAC_WGS84");
// Ảnh các tỉnh phía bắc - Thời kỳ 2.
var imagePB = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
    var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11;
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgpb);  
 var visParams = { min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1 };
// of a full-screen map.
ui.root.clear();
var panel = ui.Panel({style: {width: '300px'}});
var map = ui.Map();
ui.root.add(panel).add(map);
map.setCenter(105.609, 21.531, 7);
map.addLayer(imagePB, visParams, 'S2 - Các tỉnh phía bắc', true);
map.addLayer(rgpb).set(ui.Map.Layer(rgpb.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới các tỉnh phía bắc', true));
map.style().set('cursor', 'crosshair');
// TỈNH YÊN BÁI
// ẢNH THỜI KỲ 1
var S2_YB1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgyb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_YB2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgyb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_YB3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgyb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_YB4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgyb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
//TỈNH LÀO CAI
// ẢNH THỜI KỲ 1
var S2_LC1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rglc); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_LC2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rglc); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_LC3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rglc); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_LC4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rglc); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
//TỈNH PHÚ THỌ
// ẢNH THỜI KỲ 1
var S2_PT1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgpt); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_PT2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgpt); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_PT3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgpt); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_PT4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgpt); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
//TỈNH THANH HÓA
// ẢNH THỜI KỲ 1
var S2_TH1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgth); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_TH2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgth); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_TH3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgth); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_TH4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgth); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
//TỈNH QUẢNG NINH
// ẢNH THỜI KỲ 1
var S2_QN1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgqn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_QN2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgqn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_QN3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgqn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_QN4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgqn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH LAI CHÂU
// ẢNH THỜI KỲ 1
var S2_LCH1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 1)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rglch); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_LCH2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rglch); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_LCH3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rglch); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_LCH4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rglch); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH ĐIỆN BIÊN
// ẢNH THỜI KỲ 1
var S2_DB1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 1)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgdb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_DB2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgdb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_DB3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgdb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_DB4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgdb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH SƠN LA
// ẢNH THỜI KỲ 1
var S2_SL1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60');
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgsl); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 2
var S2_SL2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgsl); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_SL3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgsl); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_SL4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgsl); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH HÒA BÌNH
// ẢNH THỜI KỲ 1
var S2_HB1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
  .map(function(image) { 
    var qa = image.select('QA60');
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_HB2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_HB3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_HB4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH NINH BÌNH
// ẢNH THỜI KỲ 1
var S2_NB1 = ee.ImageCollection('COPERNICUS/S2_SR')
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
  .map(function(image) { 
    var qa = image.select('QA60');
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgnb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_NB2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgnb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_NB3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgnb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_NB4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgnb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH BẮC CẠN
// ẢNH THỜI KỲ 1
var S2_BC1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgbc); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_BC2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgbc); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_BC3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgbc); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_BC4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgbc); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH CAO BẰNG
// ẢNH THỜI KỲ 1
var S2_CB1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image){
    var qa = image.select('QA60'); 
    var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgcb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_CB2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgcb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_CB3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10;
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgcb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_CB4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgcb); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH HÀ GIANG
// ẢNH THỜI KỲ 1
var S2_HG1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image){ 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghg); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 2
var S2_HG2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghg); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_HG3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10;
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghg); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_HG4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghg); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH TUYÊN QUANG
// ẢNH THỜI KỲ 1
var S2_TQ1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image){ 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtq); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_TQ2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtq); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_TQ3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10;
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtq); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_TQ4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtq); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH THÁI NGUYÊN
// ẢNH THỜI KỲ 1
var S2_TN1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_TN2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_TN3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10;
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_TN4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
//TỈNH LẠNG SƠN
// ẢNH THỜI KỲ 1
var S2_LS1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image){
    var qa = image.select('QA60'); 
    var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgls); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_LS2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgls); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_LS3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10;
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000);
  })   .median()   .clip(rgls); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_LS4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgls); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH BẮC GIANG
// ẢNH THỜI KỲ 1
var S2_BG1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgbg); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_BG2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgbg); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_BG3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgbg); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_BG4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgbg); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH HÀ NAM
// ẢNH THỜI KỲ 1
var S2_HN1 = ee.ImageCollection('COPERNICUS/S2_SR')
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
  .map(function(image) { 
    var qa = image.select('QA60');
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_HN2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_HN3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_HN4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH HẢI DƯƠNG
// ẢNH THỜI KỲ 1
var S2_HD1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image){
    var qa = image.select('QA60'); 
    var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghd); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_HD2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghd); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_HD3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10;
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000);
  })   .median()   .clip(rghd); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_HD4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghd); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// TỈNH VĨNH PHÚC
// ẢNH THỜI KỲ 1
var S2_VP1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image){
    var qa = image.select('QA60'); 
    var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgvp); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 2
var S2_VP2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgvp); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_VP3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10;
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000);
  })   .median()   .clip(rgvp); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_VP4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgvp); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// THÀNH PHỐ HẢI PHÒNG
// ẢNH THỜI KỲ 1
var S2_HP1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30')
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image){
    var qa = image.select('QA60'); 
    var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtphp); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_HP2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtphp); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_HP3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10;
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000);
  })   .median()   .clip(rgtphp); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_HP4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtphp); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// THÀNH PHỐ HÀ NỘI
// ẢNH THỜI KỲ 1
var S2_TPHN1 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30')
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image){
    var qa = image.select('QA60'); 
    var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11;
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtphn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 2
var S2_TPHN2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtphn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// ẢNH THỜI KỲ 3
var S2_TPHN3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-01-01', '2020-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10;
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000);
  })   .median()   .clip(rgtphn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
 // ẢNH THỜI KỲ 4
var S2_TPHN4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rgtphn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Define some constants.
var YENBAI = 'Tỉnh Yên Bái';
var LAOCAI = 'Tỉnh Lào Cai';
var PHUTHO = 'Tỉnh Phú Thọ';
var THANHHOA = 'Tỉnh Thanh Hóa';
var QUANGNINH = 'Tỉnh Quảng Ninh';
var LAICHAU = 'Tỉnh Lai Châu';
var DIENBIEN = 'Tỉnh Điện Biên';
var SONLA = 'Tỉnh Sơn La';
var HOABINH = 'Tỉnh Hòa Bình';
var NINHBINH = 'Tỉnh Ninh Bình';
var BACCAN = 'Tỉnh Bắc Cạn';
var CAOBANG = 'Tỉnh Cao Bằng';
var HAGIANG = 'Tỉnh Hà Giang';
var TUYENQUANG = 'Tỉnh Tuyên Quang';
var THAINGUYEN = 'Tỉnh Thái Nguyên';
var LANGSON = 'Tỉnh Lạng Sơn';
var BACGIANG = 'Tỉnh Bắc Giang';
var HANAM = 'Tỉnh Hà Nam';
var HAIDUONG = 'Tỉnh Hải Dương';
var VINHPHUC = 'Tỉnh Vĩnh Phúc';
var HAIPHONG = 'TP Hải Phòng';
var HANOI = 'TP Hà Nội';
// Create an empty list of filter constraints.
var constraints = [];
var c = {};
c.dividers = {};
c.dividers.divider1 = ui.Panel();
c.dividers.divider2 = ui.Panel();
c.info = {};
c.info.titleLabel = ui.Label('BỘ TÀI NGUYÊN VÀ MÔI TRƯỜNG CỤC VIỄN THÁM QUỐC GIA');
c.info.aboutLabel = ui.Label(
  'HOẠT ĐỘNG KHAI THÁC KHOÁNG SẢN CÁC TỈNH PHÍA BẮC');
panel.add(ui.Panel(c.info.titleLabel));
panel.add(c.dividers.divider1);
panel.add(ui.Panel(c.info.aboutLabel));
panel.add(c.dividers.divider2);
c.info.titleLabel.style().set({
    fontSize: '17px',
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'red'
});
c.info.aboutLabel.style().set({
    fontSize: '15px',
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'green'
});
c.info.loading = ui.Label('loading ...');
// Add a label and select to enable adding a new filter.
c.info.tinh = ui.Label('Chọn tỉnh thực hiện:');
var constraint = ui.Select({
  items: [YENBAI, LAOCAI, PHUTHO, THANHHOA, QUANGNINH, LAICHAU, DIENBIEN, SONLA, HOABINH, NINHBINH, 
  BACCAN, CAOBANG, HAGIANG, TUYENQUANG, THAINGUYEN, LANGSON, BACGIANG, HANAM, HAIDUONG, VINHPHUC, HAIPHONG, HANOI],
  placeholder: '[Tỉnh...]',
  onChange: selectConstraint,
});
panel.add(ui.Panel(c.info.tinh));
panel.add(constraint);
panel.add(c.info.loading);
c.info.loading.style().set({
    fontSize: '18px',
    fontWeight: 'bold'
});
c.info.tinh.style().set({
    fontSize: '22px',
    fontWeight: 'bold',
    textAlign: 'center'
});
constraint.style().set({
  width: '275px',
  Color: 'blue'
}); 
var s = {};
s.divider1 = {
  backgroundColor: 'blue',
  height: '2px',
  margin: '20px 0px'
}; 
s.divider2 = {
  backgroundColor: 'blue',
  height: '2px',
  margin: '20px 0px'
}; 
Object.keys(c.dividers).forEach(function(key){
  c.dividers[key].style(s.divider1, s.divider2).set(s.divider1, s.divider2);
});
// Create a function that adds a constraint of the requested type.
function selectConstraint(name) {
  map.layers().reset();
  var layer = constraint.getValue();
  if (name == YENBAI) {
   map.setCenter(104.6448, 21.8095, 9);
   map.addLayer(S2_YB1, visParams, 'S2_TinhYenBai_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_YB2, visParams, 'S2_TinhYenBai_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_YB3, visParams, 'S2_TinhYenBai_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_YB4, visParams, 'S2_TinhYenBai_4_2020-10-01_2020-12-31', false);
   map.addLayer(YBTK1).set(ui.Map.Layer(YBTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Yên Bái_1_2019-01-01_2019-09-30', true));
   map.addLayer(YBTK2).set(ui.Map.Layer(YBTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Yên Bái_2_2019-10-01_2019-12-31', false));
   map.addLayer(YBTK3).set(ui.Map.Layer(YBTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Yên Bái_3_2020-01-01_2020-09-30', false));
   map.addLayer(YBTK4).set(ui.Map.Layer(YBTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Yên Bái_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgyb).set(ui.Map.Layer(rgyb.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Yên Bái', false));
   map.addLayer(cpyb).set(ui.Map.Layer(cpyb.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Yên Bái', true));
  } else if (name == LAOCAI) {
   map.setCenter(104.1806, 22.4317, 9);
   map.addLayer(S2_LC1, visParams, 'S2_TinhLaoCai_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_LC2, visParams, 'S2_TinhLaoCai_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_LC3, visParams, 'S2_TinhLaoCai_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_LC4, visParams, 'S2_TinhLaoCai_4_2020-10-01_2020-12-31', false);
   map.addLayer(LCTK1).set(ui.Map.Layer(LCTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lào Cai_1_2019-01-01_2019-09-30', true));
   map.addLayer(LCTK2).set(ui.Map.Layer(LCTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lào Cai_2_2019-10-01_2019-12-31', false));
   map.addLayer(LCTK3).set(ui.Map.Layer(LCTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lào Cai_3_2020-01-01_2020-09-30', false));
   map.addLayer(LCTK4).set(ui.Map.Layer(LCTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lào Cai_4_2020-10-01_2020-12-31', false));
   map.addLayer(rglc).set(ui.Map.Layer(rglc.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Lào Cai', false));
   map.addLayer(cplc).set(ui.Map.Layer(cplc.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Lào Cai', true));
  } else if (name == PHUTHO) {
   map.setCenter(105.1557, 21.3153, 9);
   map.addLayer(S2_PT1, visParams, 'S2_TinhPhuTho_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_PT2, visParams, 'S2_TinhPhuTho_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_PT3, visParams, 'S2_TinhPhuTho_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_PT4, visParams, 'S2_TinhPhuTho_4_2020-10-01_2020-12-31', false);
   map.addLayer(PTTK1).set(ui.Map.Layer(PTTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Phú Thọ_1_2019-01-01_2019-09-30', true));
   map.addLayer(PTTK2).set(ui.Map.Layer(PTTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Phú Thọ_2_2019-10-01_2019-12-31', false));
   map.addLayer(PTTK3).set(ui.Map.Layer(PTTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Phú Thọ_3_2020-01-01_2020-09-30', false));
   map.addLayer(PTTK4).set(ui.Map.Layer(PTTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Phú Thọ_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgpt).set(ui.Map.Layer(rgpt.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Phú Thọ', false));
   map.addLayer(cppt).set(ui.Map.Layer(cppt.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Phú Thọ', true));
  } else if (name == THANHHOA) {
   map.setCenter(105.4661, 20.095, 9);
   map.addLayer(S2_TH1, visParams, 'S2_TinhThanhHoa_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_TH2, visParams, 'S2_TinhThanhHoa_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_TH3, visParams, 'S2_TinhThanhHoa_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_TH4, visParams, 'S2_TinhThanhHoa_4_2020-10-01_2020-12-31', false);
   map.addLayer(THTK1).set(ui.Map.Layer(THTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Thanh Hóa_1_2019-01-01_2019-09-30', true));
   map.addLayer(THTK2).set(ui.Map.Layer(THTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Thanh Hóa_2_2019-10-01_2019-12-31', false));
   map.addLayer(THTK3).set(ui.Map.Layer(THTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Thanh Hóa_3_2020-01-01_2020-09-30', false));
   map.addLayer(THTK4).set(ui.Map.Layer(THTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Thanh Hóa_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgth).set(ui.Map.Layer(rgth.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Thanh Hóa', false));
   map.addLayer(cpth).set(ui.Map.Layer(cpth.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Thanh Hóa', true));
  } else if (name == QUANGNINH) {
   map.setCenter(107.5901, 21.1929, 9);
   map.addLayer(S2_QN1, visParams, 'S2_TinhQuangNinh_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_QN2, visParams, 'S2_TinhQuangNinh_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_QN3, visParams, 'S2_TinhQuangNinh_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_QN4, visParams, 'S2_TinhQuangNinh_4_2020-10-01_2020-12-31', false);
   map.addLayer(QNTK1).set(ui.Map.Layer(QNTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Quảng Ninh_1_2019-01-01_2019-09-30', true));
   map.addLayer(QNTK2).set(ui.Map.Layer(QNTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Quảng Ninh_2_2019-10-01_2019-12-31', false));
   map.addLayer(QNTK3).set(ui.Map.Layer(QNTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Quảng Ninh_3_2020-01-01_2020-09-30', false));
   map.addLayer(QNTK4).set(ui.Map.Layer(QNTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Quảng Ninh_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgth).set(ui.Map.Layer(rgqn.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Quảng Ninh', false));
   map.addLayer(cpth).set(ui.Map.Layer(cpqn.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Quảng Ninh', true));
  } else if (name == LAICHAU) {
   map.setCenter(103.2733, 22.3342, 9);
   map.addLayer(S2_LCH1, visParams, 'S2_TinhLaiChau_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_LCH2, visParams, 'S2_TinhLaiChau_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_LCH3, visParams, 'S2_TinhLaiChau_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_LCH4, visParams, 'S2_TinhLaiChau_4_2020-10-01_2020-12-31', false);
   map.addLayer(LCHTK1).set(ui.Map.Layer(LCHTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lai Châu_1_2019-01-01_2019-09-30', true));
   map.addLayer(LCHTK2).set(ui.Map.Layer(LCHTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lai Châu_2_2019-10-01_2019-12-31', false));
   map.addLayer(LCHTK3).set(ui.Map.Layer(LCHTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lai Châu_3_2020-01-01_2020-09-30', false));
   map.addLayer(LCHTK4).set(ui.Map.Layer(LCHTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lai Châu_4_2020-10-01_2020-12-31', false));
   map.addLayer(rglch).set(ui.Map.Layer(rglch.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Lai Châu', false));
   map.addLayer(cplch).set(ui.Map.Layer(cplch.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Lai Châu', true));
  } else if (name == DIENBIEN) {
   map.setCenter(103.1382, 21.7924, 8);
   map.addLayer(S2_DB1, visParams, 'S2_TinhDienBien_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_DB2, visParams, 'S2_TinhDienBien_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_DB3, visParams, 'S2_TinhDienBien_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_DB4, visParams, 'S2_TinhDienBien_4_2020-10-01_2020-12-31', false);
   map.addLayer(DBTK1).set(ui.Map.Layer(DBTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Điện Biên_1_2019-01-01_2019-09-30', true));
   map.addLayer(DBTK2).set(ui.Map.Layer(DBTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Điện Biên_2_2019-10-01_2019-12-31', false));
   map.addLayer(DBTK3).set(ui.Map.Layer(DBTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Điện Biên_3_2020-01-01_2020-09-30', false));
   map.addLayer(DBTK4).set(ui.Map.Layer(DBTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Điện Biên_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgdb).set(ui.Map.Layer(rgdb.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Điện Biên', false));
  } else if (name == SONLA) {
   map.setCenter(104.144, 21.2964, 9);
   map.addLayer(S2_SL1, visParams, 'S2_TinhSonLa_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_SL2, visParams, 'S2_TinhSonLa_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_SL3, visParams, 'S2_TinhSonLa_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_SL4, visParams, 'S2_TinhSonLa_4_2020-10-01_2020-12-31', false);
   map.addLayer(SLTK1).set(ui.Map.Layer(SLTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Sơn La_1_2019-01-01_2019-09-30', true));
   map.addLayer(SLTK2).set(ui.Map.Layer(SLTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Sơn La_2_2019-10-01_2019-12-31', false));
   map.addLayer(SLTK3).set(ui.Map.Layer(SLTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Sơn La_3_2020-01-01_2020-09-30', false));
   map.addLayer(SLTK4).set(ui.Map.Layer(SLTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Sơn La_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgsl).set(ui.Map.Layer(rgsl.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Sơn La', false));
   map.addLayer(cpsl).set(ui.Map.Layer(cpsl.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Sơn La', true));
  } else if (name == HOABINH) {
   map.setCenter(105.4725, 20.636, 9);
   map.addLayer(S2_HB1, visParams, 'S2_TinhHoaBinh_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_HB2, visParams, 'S2_TinhHoaBinh_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_HB3, visParams, 'S2_TinhHoaBinh_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_HB4, visParams, 'S2_TinhHoaBinh_4_2020-10-01_2020-12-31', false);
   map.addLayer(HBTK1).set(ui.Map.Layer(HBTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hòa Bình_1_2019-01-01_2019-09-30', true));
   map.addLayer(HBTK2).set(ui.Map.Layer(HBTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hòa Bình_2_2019-10-01_2019-12-31', false));
   map.addLayer(HBTK3).set(ui.Map.Layer(HBTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hòa Bình_3_2020-01-01_2020-09-30', false));
   map.addLayer(HBTK4).set(ui.Map.Layer(HBTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hòa Bình_4_2020-10-01_2020-12-31', false));
   map.addLayer(rghb).set(ui.Map.Layer(rghb.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Hòa Bình', false));
   map.addLayer(cphb).set(ui.Map.Layer(cphb.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Hòa Bình', true));
  } else if (name == NINHBINH) {
   map.setCenter(105.9229, 20.2293, 10);
   map.addLayer(S2_NB1, visParams, 'S2_TinhNinhBinh_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_NB2, visParams, 'S2_TinhNinhBinh_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_NB3, visParams, 'S2_TinhNinhBinh_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_NB4, visParams, 'S2_TinhNinhBinh_4_2020-10-01_2020-12-31', false);
   map.addLayer(NBTK1).set(ui.Map.Layer(NBTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Ninh Bình_1_2019-01-01_2019-09-30', true));
   map.addLayer(NBTK2).set(ui.Map.Layer(NBTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Ninh Bình_2_2019-10-01_2019-12-31', false));
   map.addLayer(NBTK3).set(ui.Map.Layer(NBTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Ninh Bình_3_2020-01-01_2020-09-30', false));
   map.addLayer(NBTK4).set(ui.Map.Layer(NBTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Ninh Bình_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgnb).set(ui.Map.Layer(rgnb.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Ninh Bình', false));
   map.addLayer(cpnb).set(ui.Map.Layer(cpnb.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Ninh Bình', true));
  } else if (name == BACCAN) {
   map.setCenter(105.8768, 22.3162, 9);
   map.addLayer(S2_BC1, visParams, 'S2_TinhBacCan_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_BC2, visParams, 'S2_TinhBacCan_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_BC3, visParams, 'S2_TinhBacCan_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_BC4, visParams, 'S2_TinhBacCan_4_2020-10-01_2020-12-31', false);
   map.addLayer(BCTK1).set(ui.Map.Layer(BCTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Bắc Cạn_1_2019-01-01_2019-09-30', true));
   map.addLayer(BCTK2).set(ui.Map.Layer(BCTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Bắc Cạn_2_2019-10-01_2019-12-31', false));
   map.addLayer(BCTK3).set(ui.Map.Layer(BCTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Bắc Cạn_3_2020-01-01_2020-09-30', false));
   map.addLayer(BCTK4).set(ui.Map.Layer(BCTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Bắc Cạn_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgbc).set(ui.Map.Layer(rgbc.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Bắc Cạn', false));
   map.addLayer(cpbc).set(ui.Map.Layer(cpbc.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Bắc Cạn', true));
  } else if (name == CAOBANG) {
   map.setCenter(106.1762, 22.7411, 9);
   map.addLayer(S2_CB1, visParams, 'S2_TinhCaoBang_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_CB2, visParams, 'S2_TinhCaoBang_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_CB3, visParams, 'S2_TinhCaoBang_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_CB4, visParams, 'S2_TinhCaoBang_4_2020-10-01_2020-12-31', false);
   map.addLayer(CBTK1).set(ui.Map.Layer(CBTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Cao Bằng_1_2019-01-01_2019-09-30', true));
   map.addLayer(CBTK2).set(ui.Map.Layer(CBTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Cao Bằng_2_2019-10-01_2019-12-31', false));
   map.addLayer(CBTK3).set(ui.Map.Layer(CBTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Cao Bằng_3_2020-01-01_2020-09-30', false));
   map.addLayer(CBTK4).set(ui.Map.Layer(CBTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Cao Bằng_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgcb).set(ui.Map.Layer(rgcb.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Cao Bằng', false));
   map.addLayer(cpcb).set(ui.Map.Layer(cpcb.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Cao Bằng', true));
  } else if (name == HAGIANG) {
   map.setCenter(105.0693, 22.8044, 9);
   map.addLayer(S2_HG1, visParams, 'S2_TinhHaGiang_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_HG2, visParams, 'S2_TinhHaGiang_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_HG3, visParams, 'S2_TinhHaGiang_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_HG4, visParams, 'S2_TinhHaGiang_4_2020-10-01_2020-12-31', false);
   map.addLayer(HGTK1).set(ui.Map.Layer(HGTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hà Giang_1_2019-01-01_2019-09-30', true));
   map.addLayer(HGTK2).set(ui.Map.Layer(HGTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hà Giang_2_2019-10-01_2019-12-31', false));
   map.addLayer(HGTK3).set(ui.Map.Layer(HGTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hà Giang_3_2020-01-01_2020-09-30', false));
   map.addLayer(HGTK4).set(ui.Map.Layer(HGTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hà Giang_4_2020-10-01_2020-12-31', false));
   map.addLayer(rghg).set(ui.Map.Layer(rghg.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Hà Giang', false));
   map.addLayer(cphg).set(ui.Map.Layer(cphg.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Hà Giang', true));
  } else if (name == TUYENQUANG) {
   map.setCenter(105.2835, 22.1331, 9);
   map.addLayer(S2_TQ1, visParams, 'S2_TinhTuyenQuang_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_TQ2, visParams, 'S2_TinhTuyenQuang_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_TQ3, visParams, 'S2_TinhTuyenQuang_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_TQ4, visParams, 'S2_TinhTuyenQuang_4_2020-10-01_2020-12-31', false);
   map.addLayer(TQTK1).set(ui.Map.Layer(TQTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Tuyên Quang_1_2019-01-01_2019-09-30', true));
   map.addLayer(TQTK2).set(ui.Map.Layer(TQTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Tuyên Quang_2_2019-10-01_2019-12-31', false));
   map.addLayer(TQTK3).set(ui.Map.Layer(TQTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Tuyên Quang_3_2020-01-01_2020-09-30', false));
   map.addLayer(TQTK4).set(ui.Map.Layer(TQTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Tuyên Quang_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgtq).set(ui.Map.Layer(rgtq.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Tuyên Quang', false));
   map.addLayer(cptq).set(ui.Map.Layer(cptq.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Tuyên Quang', true));
  } else if (name == THAINGUYEN) {
   map.setCenter(105.8877, 21.6884, 9);
   map.addLayer(S2_TN1, visParams, 'S2_TinhThaiNguyen_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_TN2, visParams, 'S2_TinhThaiNguyen_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_TN3, visParams, 'S2_TinhThaiNguyen_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_TN4, visParams, 'S2_TinhThaiNguyen_4_2020-10-01_2020-12-31', false);
   map.addLayer(TNTK1).set(ui.Map.Layer(TNTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Thái Nguyên_1_2019-01-01_2019-09-30', true));
   map.addLayer(TNTK2).set(ui.Map.Layer(TNTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Thái Nguyên_2_2019-10-01_2019-12-31', false));
   map.addLayer(TNTK3).set(ui.Map.Layer(TNTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Thái Nguyên_3_2020-01-01_2020-09-30', false));
   map.addLayer(TNTK4).set(ui.Map.Layer(TNTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Thái Nguyên_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgtn).set(ui.Map.Layer(rgtn.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Thái Nguyên', false));
   map.addLayer(cptn).set(ui.Map.Layer(cptn.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Thái Nguyên', true));
  } else if (name == LANGSON) {
   map.setCenter(106.6567, 21.937, 9);
   map.addLayer(S2_LS1, visParams, 'S2_TinhLangSon_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_LS2, visParams, 'S2_TinhLangSon_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_LS3, visParams, 'S2_TinhLangSon_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_LS4, visParams, 'S2_TinhLangSon_4_2020-10-01_2020-12-31', false);
   map.addLayer(LSTK1).set(ui.Map.Layer(LSTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lạng Sơn_1_2019-01-01_2019-09-30', true));
   map.addLayer(LSTK2).set(ui.Map.Layer(LSTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lạng Sơn_2_2019-10-01_2019-12-31', false));
   map.addLayer(LSTK3).set(ui.Map.Layer(LSTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lạng Sơn_3_2020-01-01_2020-09-30', false));
   map.addLayer(LSTK4).set(ui.Map.Layer(LSTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Lạng Sơn_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgls).set(ui.Map.Layer(rgls.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Lạng Sơn', false));
   map.addLayer(cpls).set(ui.Map.Layer(cpls.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Lạng Sơn', true));
  } else if (name == BACGIANG) {
   map.setCenter(106.4974, 21.3115, 9);
   map.addLayer(S2_BG1, visParams, 'S2_TinhBacGiang_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_BG2, visParams, 'S2_TinhBacGiang_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_BG3, visParams, 'S2_TinhBacGiang_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_BG4, visParams, 'S2_TinhBacGiang_4_2020-10-01_2020-12-31', false);
   map.addLayer(BGTK1).set(ui.Map.Layer(BGTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Bắc Giang_1_2019-01-01_2019-09-30', true));
   map.addLayer(BGTK2).set(ui.Map.Layer(BGTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Bắc Giang_2_2019-10-01_2019-12-31', false));
   map.addLayer(BGTK3).set(ui.Map.Layer(BGTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Bắc Giang_3_2020-01-01_2020-09-30', false));
   map.addLayer(BGTK4).set(ui.Map.Layer(BGTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Bắc Giang_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgbg).set(ui.Map.Layer(rgbg.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Bắc Giang', false));
   map.addLayer(cpbg).set(ui.Map.Layer(cpbg.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Bắc Giang', true));
  } else if (name == HANAM) {
   map.setCenter(105.985, 20.547, 10);
   map.addLayer(S2_HN1, visParams, 'S2_TinhHaNam_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_HN2, visParams, 'S2_TinhHaNam_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_HN3, visParams, 'S2_TinhHaNam_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_HN4, visParams, 'S2_TinhHaNam_4_2020-10-01_2020-12-31', false);
   map.addLayer(HNTK1).set(ui.Map.Layer(HNTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hà Nam_1_2019-01-01_2019-09-30', true));
   map.addLayer(HNTK2).set(ui.Map.Layer(HNTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hà Nam_2_2019-10-01_2019-12-31', false));
   map.addLayer(HNTK3).set(ui.Map.Layer(HNTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hà Nam_3_2020-01-01_2020-09-30', false));
   map.addLayer(HNTK4).set(ui.Map.Layer(HNTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hà Nam_4_2020-10-01_2020-12-31', false));
   map.addLayer(rghn).set(ui.Map.Layer(rghn.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Hà Nam', false));
   map.addLayer(cphn).set(ui.Map.Layer(cphn.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Hà Nam', true));
  } else if (name == HAIDUONG) {
   map.setCenter(106.3874, 20.9618, 10);
   map.addLayer(S2_HD1, visParams, 'S2_TinhHaiDuong_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_HD2, visParams, 'S2_TinhHaiDuong_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_HD3, visParams, 'S2_TinhHaiDuong_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_HD4, visParams, 'S2_TinhHaiDuong_4_2020-10-01_2020-12-31', false);
   map.addLayer(HDTK1).set(ui.Map.Layer(HDTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hải Dương_1_2019-01-01_2019-09-30', true));
   map.addLayer(HDTK2).set(ui.Map.Layer(HDTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hải Dương_2_2019-10-01_2019-12-31', false));
   map.addLayer(HDTK3).set(ui.Map.Layer(HDTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hải Dương_3_2020-01-01_2020-09-30', false));
   map.addLayer(HDTK4).set(ui.Map.Layer(HDTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hải Dương_4_2020-10-01_2020-12-31', false));
   map.addLayer(rghd).set(ui.Map.Layer(rghd.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Hải Dương', false));
   map.addLayer(cphd).set(ui.Map.Layer(cphd.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Hải Dương', true));
  } else if (name == VINHPHUC) {
   map.setCenter(105.617, 21.3575, 10);
   map.addLayer(S2_VP1, visParams, 'S2_TinhVinhPhuc_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_VP2, visParams, 'S2_TinhVinhPhuc_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_VP3, visParams, 'S2_TinhVinhPhuc_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_VP4, visParams, 'S2_TinhVinhPhuc_4_2020-10-01_2020-12-31', false);
   map.addLayer(VPTK1).set(ui.Map.Layer(VPTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Vĩnh Phúc_1_2019-01-01_2019-09-30', true));
   map.addLayer(VPTK2).set(ui.Map.Layer(VPTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Vĩnh Phúc_2_2019-10-01_2019-12-31', false));
   map.addLayer(VPTK3).set(ui.Map.Layer(VPTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Vĩnh Phúc_3_2020-01-01_2020-09-30', false));
   map.addLayer(VPTK4).set(ui.Map.Layer(VPTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Vĩnh Phúc_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgvp).set(ui.Map.Layer(rgvp.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới tỉnh Vĩnh Phúc', false));
  } else if (name == HAIPHONG) {
   map.setCenter(106.7472, 20.8309, 10);
   map.addLayer(S2_HP1, visParams, 'S2_TP_HaiPhong_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_HP2, visParams, 'S2_TP_HaiPhong_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_HP3, visParams, 'S2_TP_HaiPhong_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_HP4, visParams, 'S2_TP_HaiPhong_4_2020-10-01_2020-12-31', false);
   map.addLayer(HPTK1).set(ui.Map.Layer(HPTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT TP Hải Phòng_1_2019-01-01_2019-09-30', true));
   map.addLayer(HPTK2).set(ui.Map.Layer(HPTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT TP Hải Phòng_2_2019-10-01_2019-12-31', false));
   map.addLayer(HPTK3).set(ui.Map.Layer(HPTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT TP Hải Phòng_3_2020-01-01_2020-09-30', false));
   map.addLayer(HPTK4).set(ui.Map.Layer(HPTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT TP Hải Phòng_4_2020-10-01_2020-12-31', false));
   map.addLayer(rgtphp).set(ui.Map.Layer(rgtphp.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới TP Hải Phòng', false));
   map.addLayer(cptphp).set(ui.Map.Layer(cptphp.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép TP Hải Phòng', true));
  } else if (name == HANOI) {
   map.setCenter(105.698, 21.0425, 9);
   map.addLayer(S2_TPHN1, visParams, 'S2_TP_HaNoi_1_2019-01-01_2019-09-30', true);
   map.addLayer(S2_TPHN2, visParams, 'S2_TP_HaNoi_2_2019-10-01_2019-12-31', false);
   map.addLayer(S2_TPHN3, visParams, 'S2_TP_HaNoi_3_2020-01-01_2020-09-30', false);
   map.addLayer(S2_TPHN4, visParams, 'S2_TP_HaNoi_4_2020-10-01_2020-12-31', false);
   map.addLayer(rgtphn).set(ui.Map.Layer(rgtphn.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới TP Hà Nội', false));
   map.addLayer(cptphn).set(ui.Map.Layer(cptphn.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép TP Hà Nội', true));
  }    
  map.addLayer();
 constraint.setValue(null);
}