var Mineral = ui.import && ui.import("Mineral", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            105.64606323391112,
            20.78389996222395
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.64692154079589,
            20.783418489699226
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.64692154079589,
            20.7856252261606
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.64571991115722,
            20.78763132222177
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.6470502868286,
            20.78831338880866
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.6470502868286,
            20.790640416318325
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.64104213863524,
            20.772304072147797
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.64237251430663,
            20.77238432358165
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.65062119745517,
            20.733794054489874
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.64560010217929,
            20.74085781655291
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([105.64606323391112, 20.78389996222395]),
            {
              "lc": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([105.64692154079589, 20.783418489699226]),
            {
              "lc": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([105.64692154079589, 20.7856252261606]),
            {
              "lc": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([105.64571991115722, 20.78763132222177]),
            {
              "lc": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([105.6470502868286, 20.78831338880866]),
            {
              "lc": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([105.6470502868286, 20.790640416318325]),
            {
              "lc": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([105.64104213863524, 20.772304072147797]),
            {
              "lc": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([105.64237251430663, 20.77238432358165]),
            {
              "lc": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([105.65062119745517, 20.733794054489874]),
            {
              "lc": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([105.64560010217929, 20.74085781655291]),
            {
              "lc": 0,
              "system:index": "9"
            })]),
    Forest = ui.import && ui.import("Forest", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            105.69056329799659,
            20.37755946428078
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.69391069484718,
            20.384639717527005
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.6788044936753,
            20.387455636981382
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.65734682155616,
            20.38809926849242
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.70498285366065,
            20.36822590661871
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.57786760402686,
            20.38166283247061
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.61734972072608,
            20.365570567235626
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.59331712795264,
            20.456630627926817
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.57615099025733,
            20.44730186268634
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.80926714015968,
            20.45244883769408
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 1
      },
      "color": "#2fff02",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #2fff02 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([105.69056329799659, 20.37755946428078]),
            {
              "lc": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([105.69391069484718, 20.384639717527005]),
            {
              "lc": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([105.6788044936753, 20.387455636981382]),
            {
              "lc": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([105.65734682155616, 20.38809926849242]),
            {
              "lc": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([105.70498285366065, 20.36822590661871]),
            {
              "lc": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([105.57786760402686, 20.38166283247061]),
            {
              "lc": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([105.61734972072608, 20.365570567235626]),
            {
              "lc": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([105.59331712795264, 20.456630627926817]),
            {
              "lc": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([105.57615099025733, 20.44730186268634]),
            {
              "lc": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([105.80926714015968, 20.45244883769408]),
            {
              "lc": 1,
              "system:index": "9"
            })]),
    Uban = ui.import && ui.import("Uban", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            105.68067371308324,
            20.59361189912354
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.68595230042455,
            20.591040805420597
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.68423568665501,
            20.5926075708052
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.67702590882298,
            20.595861570552145
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.67766963898656,
            20.594535875334177
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.68569480835912,
            20.595379500897444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.68796932160375,
            20.592969129761823
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 2
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([105.68067371308324, 20.59361189912354]),
            {
              "lc": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([105.68595230042455, 20.591040805420597]),
            {
              "lc": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([105.68423568665501, 20.5926075708052]),
            {
              "lc": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([105.67702590882298, 20.595861570552145]),
            {
              "lc": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([105.67766963898656, 20.594535875334177]),
            {
              "lc": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([105.68569480835912, 20.595379500897444]),
            {
              "lc": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([105.68796932160375, 20.592969129761823]),
            {
              "lc": 2,
              "system:index": "6"
            })]),
    Water = ui.import && ui.import("Water", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            105.5957985893088,
            20.780533778559647
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.59674272688204,
            20.781175753851095
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.59348116071993,
            20.782700434228186
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.59476862104708,
            20.78149674047321
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.2638802489074,
            20.80104085489314
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.23229455554802,
            20.78435080678168
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.14509057605584,
            20.765090765825683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.07917260730584,
            20.75995434017956
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.15127038562615,
            20.739406892417588
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.03797387683709,
            20.84083274576269
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.25594953579305,
            20.828479642193244
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 3
      },
      "color": "#4febff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #4febff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([105.5957985893088, 20.780533778559647]),
            {
              "lc": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([105.59674272688204, 20.781175753851095]),
            {
              "lc": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([105.59348116071993, 20.782700434228186]),
            {
              "lc": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([105.59476862104708, 20.78149674047321]),
            {
              "lc": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([105.2638802489074, 20.80104085489314]),
            {
              "lc": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([105.23229455554802, 20.78435080678168]),
            {
              "lc": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([105.14509057605584, 20.765090765825683]),
            {
              "lc": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([105.07917260730584, 20.75995434017956]),
            {
              "lc": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([105.15127038562615, 20.739406892417588]),
            {
              "lc": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([105.03797387683709, 20.84083274576269]),
            {
              "lc": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([105.25594953579305, 20.828479642193244]),
            {
              "lc": 3,
              "system:index": "10"
            })]),
    Bare = ui.import && ui.import("Bare", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            105.68826972901341,
            20.599959101074305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.69359123169896,
            20.598593269804034
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.64818679749486,
            20.59979841567769
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.6473284906101,
            20.595178638091475
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.65020381867406,
            20.60244970306126
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 4
      },
      "color": "#ed9f1f",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ed9f1f */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([105.68826972901341, 20.599959101074305]),
            {
              "lc": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([105.69359123169896, 20.598593269804034]),
            {
              "lc": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([105.64818679749486, 20.59979841567769]),
            {
              "lc": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([105.6473284906101, 20.595178638091475]),
            {
              "lc": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([105.65020381867406, 20.60244970306126]),
            {
              "lc": 4,
              "system:index": "4"
            })]),
    Road = ui.import && ui.import("Road", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            105.66473111167038,
            20.68438710043256
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.66359385504806,
            20.686073350522843
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.67189797415817,
            20.685129855757573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.6735072995671,
            20.685451046123504
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.6677781011113,
            20.68527037662631
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.66028937354172,
            20.689405646784724
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.65743550314987,
            20.692577282471497
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            105.66939636695555,
            20.673522552855406
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "lc": 5
      },
      "color": "#c245b0",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #c245b0 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([105.66473111167038, 20.68438710043256]),
            {
              "lc": 5,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([105.66359385504806, 20.686073350522843]),
            {
              "lc": 5,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([105.67189797415817, 20.685129855757573]),
            {
              "lc": 5,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([105.6735072995671, 20.685451046123504]),
            {
              "lc": 5,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([105.6677781011113, 20.68527037662631]),
            {
              "lc": 5,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([105.66028937354172, 20.689405646784724]),
            {
              "lc": 5,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([105.65743550314987, 20.692577282471497]),
            {
              "lc": 5,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([105.66939636695555, 20.673522552855406]),
            {
              "lc": 5,
              "system:index": "7"
            })]),
    rghn = ui.import && ui.import("rghn", "table", {
      "id": "projects/huyquangpecc1/assets/RG_TinhHaNam_WSG84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/RG_TinhHaNam_WSG84"),
    cphn = ui.import && ui.import("cphn", "table", {
      "id": "projects/huyquangpecc1/assets/Capphep_HaNam_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/Capphep_HaNam_WGS84"),
    HNTK1 = ui.import && ui.import("HNTK1", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_1_2019-01-01_2019-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_1_2019-01-01_2019-09-30_WGS84"),
    HNTK2 = ui.import && ui.import("HNTK2", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_2_2019-10-01_2019-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_2_2019-10-01_2019-12-30_WGS84"),
    HNTK3 = ui.import && ui.import("HNTK3", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_3_2020-01-01_2020-09-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_3_2020-01-01_2020-09-30_WGS84"),
    HNTK4 = ui.import && ui.import("HNTK4", "table", {
      "id": "projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_4_2020-10-01_2020-12-30_WGS84"
    }) || ee.FeatureCollection("projects/huyquangpecc1/assets/HDKTKS_TINHHANAM_4_2020-10-01_2020-12-30_WGS84");
Map.setCenter(105.9965, 20.557, 10);
// ẢNH THỜI KỲ 1
var S2_HN1 = ee.ImageCollection('COPERNICUS/S2_SR')
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
  .map(function(image) { 
    var qa = image.select('QA60');
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK1
 Map.addLayer(S2_HN1, visParams, 'S2_TinhHoaBinh_1_2019-01-01_2019-09-30', true);
 // Tạo tập dữ liệu mẫu 
var samples = Mineral.merge(Forest).merge(Uban).merge(Water).merge(Bare).merge(Road);
// Tạo nhãn lưu giữ thuộc tính lớp phủ dưới dạng các số nguyên liên tiếp bắt đầu từ số không. 
var label = 'lc';
// Sử dụng các kênh của ảnh để dự đoán. 
// Để có được kết quả tốt, phù hợp với từng bài toán thì cần phải tổ hợp thêm kênh. 
var bands = ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B11', 'B12'];
// Chồng dữ liệu mẫu lên hình ảnh để chuẩn bị huấn luyện. 
var trainSet_1 = S2_HN1.select(bands).sampleRegions({collection: samples, properties: [label], scale: 20 });
// Huấn luyện để tạo công cụ phân loại  
var mlModel_1 = ee.Classifier.smileRandomForest(10).train(trainSet_1, label, bands);
// Phân loại hình ảnh với các kênh như đã được sử dụng để huấn luyện. 
var classified_1 = S2_HN1.select(bands).classify(mlModel_1); 
// Vùng có hoạt động khai thác khoáng sản. 
var regions_1 = classified_1.updateMask(classified_1.eq(0)); 
// Hiển thị kết quả phân loại. 
//Map.addLayer(regions_1, {min: 0, max: 2, palette: ['#d326ed']}, 'VKT-TK1', false);
// Chuyển đổi từ raster sang vector TK1
var resultVector_1 = regions_1.reduceToVectors({ reducer: ee.Reducer.countEvery(), geometry: rghn,  scale: 20, geometryInNativeProjection: true, maxPixels: 1e13, tileScale: 4 }); 
// Hiển thị kết quả vector TK1 
Map.layers().set(20, ui.Map.Layer(HNTK1.map(function (feature) { return feature.set('style', { color: '#d326ed', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hòa Bình_1_2019-01-01_2019-09-30', true));
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 // ẢNH THỜI KỲ 2
var S2_HN2 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-10-01', '2019-12-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK2
 Map.addLayer(S2_HN2, visParams, 'S2_TinhHoaBinh_2_2019-10-01_2019-12-31', false);
// Chồng dữ liệu mẫu lên hình ảnh để chuẩn bị huấn luyện. 
var trainSet_2 = S2_HN2.select(bands).sampleRegions({collection: samples, properties: [label], scale: 20 });
// Huấn luyện để tạo công cụ phân loại  
var mlModel_2 = ee.Classifier.smileRandomForest(10).train(trainSet_2, label, bands);
// Phân loại hình ảnh với các kênh như đã được sử dụng để huấn luyện. 
var classified_2 = S2_HN2.select(bands).classify(mlModel_2); 
// Vùng có hoạt động khai thác khoáng sản. 
var regions_2 = classified_2.updateMask(classified_2.eq(0)); 
// Hiển thị kết quả phân loại. 
//Map.addLayer(regions_2, {min: 0, max: 2, palette: ['#00fe0e']}, 'VKT-TK2', false);
// Chuyển đổi từ raster sang vector TK2
var resultVector_2 = regions_2.reduceToVectors({ reducer: ee.Reducer.countEvery(), geometry: rghn,  scale: 20, geometryInNativeProjection: true, maxPixels: 1e13, tileScale: 4 }); 
// Hiển thị kết quả vector TK2 
Map.layers().set(20, ui.Map.Layer(HNTK2.map(function (feature) { return feature.set('style', { color: '#00fe0e', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hòa Bình_2_2019-10-01_2019-12-31', false));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ẢNH THỜI KỲ 3
var S2_HN3 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2019-01-01', '2019-09-30') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK3
 Map.addLayer(S2_HN3, visParams, 'S2_TinhHoaBinh_3_2020-01-01_2020-09-30', false);
// Chồng dữ liệu mẫu lên hình ảnh để chuẩn bị huấn luyện. 
var trainSet_3 = S2_HN3.select(bands).sampleRegions({collection: samples, properties: [label], scale: 20 });
// Huấn luyện để tạo công cụ phân loại  
var mlModel_3 = ee.Classifier.smileRandomForest(10).train(trainSet_3, label, bands);
// Phân loại hình ảnh với các kênh như đã được sử dụng để huấn luyện. 
var classified_3 = S2_HN3.select(bands).classify(mlModel_3); 
// Vùng có hoạt động khai thác khoáng sản. 
var regions_3 = classified_3.updateMask(classified_3.eq(0)); 
// Hiển thị kết quả phân loại. 
//Map.addLayer(regions_3, {min: 0, max: 2, palette: ['#e5fa01']}, 'VKT-TK3', false);
// Chuyển đổi từ raster sang vector TK3
var resultVector_3 = regions_3.reduceToVectors({ reducer: ee.Reducer.countEvery(), geometry: rghn,  scale: 20, geometryInNativeProjection: true, maxPixels: 1e13, tileScale: 4 }); 
// Hiển thị kết quả vector TK3 
Map.layers().set(20, ui.Map.Layer(HNTK3.map(function (feature) { return feature.set('style', { color: '#e5fa01', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hòa Bình_3_2020-01-01_2020-09-30', false));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 // ẢNH THỜI KỲ 4
var S2_HN4 = ee.ImageCollection('COPERNICUS/S2_SR') 
  .filterDate('2020-10-01', '2020-12-31') 
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20)) 
  .map(function(image) { 
    var qa = image.select('QA60'); 
   var cloudBitMask = 1 << 10; 
    var cirrusBitMask = 1 << 11; 
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0) 
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0)); 
    return image.updateMask(mask).divide(10000); 
  })   .median()   .clip(rghn); 
 var visParams = {   min: 0.0,   max: 0.30,   bands: ['B4', 'B3', 'B2'],   gammar: 1.1, }; 
// Hiện thị ảnh TK4
 Map.addLayer(S2_HN4, visParams, 'S2_TinhHoaBinh_4_2020-10-01_2020-12-31', false);
// Chồng dữ liệu mẫu lên hình ảnh để chuẩn bị huấn luyện. 
var trainSet_4 = S2_HN4.select(bands).sampleRegions({collection: samples, properties: [label], scale: 20 });
// Huấn luyện để tạo công cụ phân loại  
var mlModel_4 = ee.Classifier.smileRandomForest(10).train(trainSet_4, label, bands);
// Phân loại hình ảnh với các kênh như đã được sử dụng để huấn luyện. 
var classified_4 = S2_HN4.select(bands).classify(mlModel_4); 
// Vùng có hoạt động khai thác khoáng sản. 
var regions_4 = classified_4.updateMask(classified_4.eq(0)); 
// Hiển thị kết quả phân loại. 
//Map.addLayer(regions_4, {min: 0, max: 2, palette: ['#071ff8']}, 'VKT-TK4', false);
// Chuyển đổi từ raster sang vector TK4
var resultVector_4 = regions_4.reduceToVectors({ reducer: ee.Reducer.countEvery(), geometry: rghn,  scale: 20, geometryInNativeProjection: true, maxPixels: 1e13, tileScale: 4 }); 
// Hiển thị kết quả vector TK4 
Map.layers().set(20, ui.Map.Layer(HNTK4.map(function (feature) { return feature.set('style', { color: '#071ff8', fillColor: '#00FF0000', width: 1 }); }) .style({ styleProperty: 'style', }), {}, 'Hoạt động KT Tỉnh Hòa Bình_4_2020-10-01_2020-12-31', false));
// Hiển thị ranh giới tỉnh
Map.layers().set(20, ui.Map.Layer(rghn.map(function (feature) { return feature.set('style', { color: '#feadb6', fillColor: '#00FF0000', width: 3 }); }) .style({ styleProperty: 'style', }), {}, 'Địa giới tỉnh Hòa Bình', false));
//Hiện thị ranh giới cấp phép
Map.layers().set(20, ui.Map.Layer(cphn.map(function (feature) { return feature.set('style', { color: '#fc2b03', fillColor: '#00FF0000', width: 2 }); }) .style({ styleProperty: 'style', }), {}, 'Ranh giới cấp phép tỉnh Hòa Bình', true));
///////////////////////////////////////////////////////////////////////////////////////////////////////////
// Xuất kết quả ra file theo định dạng Shape files. 
//Export.table.toDrive({ collection: resultVector_2, folder: 'HĐKTKS', description: 'Hoạt động KT Tỉnh Hòa Bình_2_2019-10-01_2019-12-31', fileFormat: 'shp' 
//}); 
// Export a cloud-optimized GeoTIFF.
//Export.image.toDrive({
// image: S2_HN1.select(['B4', 'B3', 'B2']),
// description: 'S2_HANAM',
// scale: 10,
// maxPixels: 1e13,
// region: rghn,
// fileFormat: 'GeoTIFF',
// formatOptions: {cloudOptimized: true}});