var gaul0 = ui.import && ui.import("gaul0", "table", {
      "id": "FAO/GAUL/2015/level0"
    }) || ee.FeatureCollection("FAO/GAUL/2015/level0"),
    soil = ui.import && ui.import("soil", "image", {
      "id": "projects/fa-idn/assets/IDN_PEAT_BIGBRG_20200219"
    }) || ee.Image("projects/fa-idn/assets/IDN_PEAT_BIGBRG_20200219"),
    gaul2 = ui.import && ui.import("gaul2", "table", {
      "id": "FAO/GAUL/2015/level2"
    }) || ee.FeatureCollection("FAO/GAUL/2015/level2"),
    gaul1 = ui.import && ui.import("gaul1", "table", {
      "id": "FAO/GAUL/2015/level1"
    }) || ee.FeatureCollection("FAO/GAUL/2015/level1"),
    climate = ui.import && ui.import("climate", "imageCollection", {
      "id": "WORLDCLIM/V1/MONTHLY"
    }) || ee.ImageCollection("WORLDCLIM/V1/MONTHLY"),
    etopo = ui.import && ui.import("etopo", "image", {
      "id": "NOAA/NGDC/ETOPO1"
    }) || ee.Image("NOAA/NGDC/ETOPO1");
// Module for legend
var legendTool = require('users/ramiqcom/ugm:tools/legend');
var legendCategory = legendTool.legendDiscrete;
var legendColormap = legendTool.legendGradient;
// Module for visualization
var visualizer = require('users/ramiqcom/ugm:tools/visStretch').stretch;
// LULC properties
var lulc = {
  classNames: ['High density dryland forest', 'Medium density dryland forest', 
    'High density swamp forest', 'Medium density swamp forest',
    'High density mangrove forest', 'Medium density mangrove forest',
    'Cropland 1', 'Cropland 2 (palm oil)', 'Grassland', 'Wetlands',
    'Built-up', 'Bareland', 'Other woody vegetation', 'Water bodies'
  ],
  classValues: [11, 12, 21, 22, 31, 32, 40, 50, 60, 70, 80, 90, 100, 110],
  classPalette: ['006400', '228B22', '808000', '6B8E23',
    '4B0082', '7B68EE', 'FFD700', 'D2691E', '7CFC00', '20B2AA',
    'DB7093', 'FFE4B5', '8FBC8F', '87CEFA'
  ]
};
// Basemap
basemap();
// Center to kalimantan
myLocation();
// Set map
resetMap();
// Main panel
var mainPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical', true),
  style: {width: '400px', padding: '10px'}
});
ui.root.add(mainPanel);
// Title panel
var titlePanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal', true),
  style: {margin: '20px 0'}
});
mainPanel.add(titlePanel);
// Minimize button
var minimizeButton1 = ui.Button({
  label: '>',
  style: {padding: '5px 0 0 0'},
  onClick: function(){
    mainPanel.style().set('shown', false);
    maximizeButton1.style().set('shown', true);
  }
});
titlePanel.add(minimizeButton1);
// Maximize button
var maximizeButton1 = ui.Button({
  label: '<',
  style: {shown: false, position: 'top-right', margin: '0', padding: '0', },
  onClick: function(){
    mainPanel.style().set('shown', true);
    maximizeButton1.style().set('shown', false);
  }
});
Map.add(maximizeButton1);
// App title
var titleLabel = ui.Label({
  value: 'Carbon Calculator',
  style: {fontWeight: 'bold', color: 'green', fontSize: '30px', stretch: 'horizontal', }
});
titlePanel.add(titleLabel);
// AOI label
var aoiLabel = ui.Label({
  value: 'Select an AOI option',
  style: {}
});
mainPanel.add(aoiLabel);
// AOI panel
var aoiPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal', true),
});
mainPanel.add(aoiPanel);
// Click option
var clickCheckbox = ui.Checkbox({
  label: 'Click option',
  value: true,
  onChange: function(value){
    if (value === true){
      calculateLabel.setValue('Click map or calculate carbon button!');
    } else {
      calculateLabel.setValue('Click calculate carbon button!');
    }
  },
  style: {padding: '5px 0 0 0', }
});
aoiPanel.add(clickCheckbox);
// AOI select
var aoiSelect = ui.Select({
  items: ['GeoJSON', 'Draw AOI', 'Map bounds'],
  value: 'Draw AOI',
  style: {stretch: 'horizontal', },
  placeholder: 'Select AOI',
  onChange: function(value){
    if (value == 'Draw AOI') {
      drawSelect.style().set({shown: true});
      geojsonTextbox.style().set({shown: false});
    } else if (value == 'GeoJSON') {
      drawSelect.style().set({shown: false});
      geojsonTextbox.style().set({shown: true});
    } else {
      drawSelect.style().set({shown: false});
      geojsonTextbox.style().set({shown: false});
    }
    activateStatisticButton();
  }
});
aoiPanel.add(aoiSelect);
// Select draw AOI
var drawSelect = ui.Select({
  placeholder: 'Select a geometry or draw geometry first!',
  style: {stretch: 'horizontal', },
  onChange: function(){
    showStatistic.setDisabled(false);
  }
});
mainPanel.add(drawSelect);
// Textbox to add geojson string
var geojsonTextbox = ui.Textbox({
  placeholder: 'Paste GeoJSON string here!',
  style: {stretch: 'horizontal', shown: false, },
  onChange: function(){
    activateStatisticButton();
  }
});
mainPanel.add(geojsonTextbox);
// Button remove AOI
var removeAoiButton = ui.Button({
  label: 'Remove AOI',
  style: {stretch: 'horizontal', color: 'red'},
  onClick: function(){
    Map.drawingTools().clear();
    drawSelect.items().reset([]);
    draw();
    drawSelect.setValue(null);
    showStatistic.setDisabled(true);
    if(Map.layers().get(3) !== undefined){
      Map.remove(Map.layers().get(3));
    }
    lcCMButton.setDisabled(true);
  }
});
mainPanel.add(removeAoiButton);
// Command label
var calculateLabel = ui.Label({
  value: 'Click map or calculate carbon! button',
  style: {color: 'blue', margin: '20px auto 10px auto', stretch: 'horizontal', textAlign: 'center', }
});
mainPanel.add(calculateLabel);
// Show image button
var showStatistic = ui.Button({
  label: 'Calculate carbon!',
  style: {stretch: 'horizontal', fontWeight: 'bold', color: 'green'},
  disabled: true,
  onClick: function(){
    calculate('AOI');
    lcCMButton.style().set('shown', true);
    lcCMButtonHide.style().set('shown', false);
    lcCMButton.setDisabled(false);
    Map.remove(lcPanel);
  }
});
mainPanel.add(showStatistic);
// LC confusion matrix button
var lcCMButton = ui.Button({
  label: 'Show land cover confusion matrix',
  style: {stretch: 'horizontal', shown: true},
  disabled: true,
  onClick: function(){
    confusionMatrixInfo();
    lcCMButton.style().set('shown', false);
    lcCMButtonHide.style().set('shown', true);
  }
});
mainPanel.add(lcCMButton);
// LC confusion matrix button hide
var lcCMButtonHide = ui.Button({
  label: 'Hide land cover confusion matrix',
  style: {stretch: 'horizontal', shown: false},
  onClick: function(){
    Map.remove(lcPanel);
    lcCMButton.style().set('shown', true);
    lcCMButtonHide.style().set('shown', false);
  }
});
mainPanel.add(lcCMButtonHide);
// LC panel
var lcPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical', true),
  style: {width: '800px', position: 'bottom-center'}
});
// Confusion matrix info
function confusionMatrixInfo(){
  lcPanel.widgets().reset();
  Map.add(lcPanel);
  var geom = aoi();
  var newLc = lc();
  var baseLc = lc2010();
  var valueList = ee.List(lulc.classValues);
  var lcList = valueList.map(function(valueNew){
    return valueList.map(function(valueBase){
      var area = newLc.eq(ee.Number(valueNew)).and(baseLc.eq(ee.Number(valueBase)))
        .reduceRegion({
          geometry: geom,
          reducer: ee.Reducer.sum(),
          scale: 1000,
          bestEffort: true
        }).get('LULC');
      return ee.Number(area).multiply(0.09).multiply(1111).round();
    });
  });
  var column = ee.List([
    '2022/2010', 'High density dryland forest', 'Medium density dryland forest', 
    'High density swamp forest', 'Medium density swamp forest',
    'High density mangrove forest', 'Medium density mangrove forest',
    'Cropland 1', 'Cropland 2 (palm oil)', 'Grassland', 'Wetlands',
    'Built-up', 'Bareland', 'Other woody vegetation', 'Water bodies'
  ]);
  var listHeader = lcList.map(function(data){
    return ee.List(data).insert(0, ee.List(lulc.classNames).get(lcList.indexOf(data)));
  }).insert(0, column);
  // Loading label
  var loadingLabel = ui.Label({
    value: 'Loading...',
    style: {color: 'blue', fontSize: '25px', fontWeight: 'bold', stretch: 'horizontal', textAlign: 'center'}
  });
  lcPanel.add(loadingLabel);
  // LC confusion matrix
  var confusionMatrixChart = ui.Chart({
    chartType: 'Table',
    downloadable: true
  });
  // Page option
  confusionMatrixChart.setOptions({pageSize: 20});
  // Add table style
  confusionMatrixChart.style().set({stretch: 'vertical', height: '350px', fontSize: '8px'});
  listHeader.evaluate(function(value){
    // Add table value to table
    confusionMatrixChart.setDataTable(value);
    // Add table to panel
    lcPanel.add(confusionMatrixChart);
    // Remove loading label
    lcPanel.remove(loadingLabel);
  });
}
// Function to download data
function cmDownload(tableChart, panel){
  // Download data
  var downloadButton = ui.Button({
    label: 'Generate download link',
    style: {stretch: 'horizontal', },
    onClick: function(){
      var data = ee.List(tableChart.getDataTable());
      var featList = data.remove(data.get(0)).map(function(list){
        return ee.Feature(null).set({
          'Variable': ee.List(list).get(0), 
          'Value': ee.List(list).get(1), 
          'Unit': ee.List(list).get(2)
        });
      });
      var features = ee.FeatureCollection(featList).getDownloadURL({
        format: 'csv',
        selectors: ['Variable', 'Value', 'Unit'],
        callback: function(url){
          downloadLink.setUrl(url);
          downloadLink.style().set('shown', true);
        }
      });
    }
  });
  panel.add(downloadButton);
  // Download link
  var downloadLink = ui.Label({
    value: 'Download link',
    style: {shown: false, stretch: 'horizontal', textAlign: 'center', color: 'dodgerblue'}
  });
  panel.add(downloadLink);
}
// Select option
var selectInfo = ui.Select({
  items: ['Administration', 'Physical', 'Land cover', 'Carbon'],
  value: 'Carbon',
  onChange: function(value){
    tableChartCarbon.style().set('shown', false);
    tableChartAdm.style().set('shown', false);
    tableChartPhy.style().set('shown', false);
    tableChartLC.style().set('shown', false);
    switch (value) {
      case 'Carbon':
        tableChartCarbon.style().set('shown', true);
        break;
      case 'Administration':
        tableChartAdm.style().set('shown', true);
        break;
      case 'Physical':
        tableChartPhy.style().set('shown', true);
        break;
      case 'Land cover':
        tableChartLC.style().set('shown', true);
        break;
    }
  },
  style: {stretch: 'horizontal', }
});
mainPanel.add(selectInfo);
// Table panel
var tablePanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical', true),
  style: {stretch: 'horizontal'}
});
mainPanel.add(tablePanel);
// Table for adm
var tableChartAdm = ui.Chart({
  chartType: 'Table',
  downloadable: true,
});
tablePanel.add(tableChartAdm);
// Page option
tableChartAdm.setOptions({pageSize: 20});
// Add table style
tableChartAdm.style().set({stretch: 'vertical', height: '350px', shown: false, });
// Add column to table
tableChartAdm.setDataTable([ 
  ['Variable', 'Value', 'Unit'], 
  ['Country',  ' ', ' '],
  ['Province', ' ', ' '],
  ['Regency', ' ', ' '],
  ['Area', ' ', 'Ha']
]);
// Table for phy
var tableChartPhy = ui.Chart({
  chartType: 'Table',
  downloadable: true,
});
tablePanel.add(tableChartPhy);
// Page option
tableChartPhy.setOptions({pageSize: 20});
// Add table style
tableChartPhy.style().set({stretch: 'vertical', height: '350px', shown: false, });
// Add column to table
tableChartPhy.setDataTable([
  ['Variable', 'Value', 'Unit'],
  ['Max elevation', ' ', 'm'],
  ['Min elevation', ' ', 'm'],
  ['Max temperature', ' ', 'Celsius'],
  ['Min temperature', ' ', 'Celsius'],
  ['Max precipitation', ' ', 'mm/month'],
  ['Min precipitation', ' ', 'mm/month'],
  ['Peat soil', ' ', 'Ha'],
  ['Mineral soil', ' ', 'Ha']
]);
// Table for carbon
var tableChartCarbon = ui.Chart({
  chartType: 'Table',
  downloadable: true,
});
tablePanel.add(tableChartCarbon);
// Page option
tableChartCarbon.setOptions({pageSize: 20});
// Add table style
tableChartCarbon.style().set({stretch: 'vertical', height: '350px', shown: true, });
// Add column to table
tableChartCarbon.setDataTable([
  ['Variable', 'Value', 'Unit'], 
  ['Above ground biomass', ' ', 'Ton'],
  ['Deforestation', ' ', 'Ha'],
  ['Deforestation rate', ' ', '%/year'],
  ['Emission', ' ', 'Ton']
]);
// Table for land cover
var tableChartLC = ui.Chart({
  chartType: 'Table',
  downloadable: true,
});
tablePanel.add(tableChartLC);
// Page option
tableChartLC.setOptions({pageSize: 20});
// Add table style
tableChartLC.style().set({stretch: 'vertical', height: '350px', shown: false, });
// Add column to table
tableChartLC.setDataTable([
  ['Variable', 'Value', 'Unit'],
  ['High density dryland forest', ' ', 'Ha'],
  ['Medium density dryland forest', ' ', 'Ha'],
  ['High density swamp forest', ' ', 'Ha'],
  ['Medium density swamp forest', ' ', 'Ha'],
  ['High density mangrove forest', ' ', 'Ha'],
  ['Medium density mangrove forest', ' ', 'Ha'],
  ['Cropland 1', ' ', 'Ha'],
  ['Cropland 2 (palm oil)', ' ', 'Ha'],
  ['Grassland', ' ', 'Ha'],
  ['Wetlands', ' ', 'Ha'],
  ['Built-up', ' ', 'Ha'],
  ['Bareland', ' ', 'Ha'],
  ['Other woody vegetation', ' ', 'Ha'],
  ['Water bodies', ' ', 'Ha']
]);
// Table for download
var tableChart = ui.Chart({
  chartType: 'Table',
  downloadable: true,
});
// Download data
var downloadButton = ui.Button({
  label: 'Generate download link',
  style: {stretch: 'horizontal', },
  onClick: function(){
    var data = ee.List(tableChart.getDataTable());
    var featList = data.remove(data.get(0)).map(function(list){
      return ee.Feature(null).set({
        'Variable': ee.List(list).get(0), 
        'Value': ee.List(list).get(1), 
        'Unit': ee.List(list).get(2)
      });
    });
    var features = ee.FeatureCollection(featList).getDownloadURL({
      format: 'csv',
      selectors: ['Variable', 'Value', 'Unit'],
      callback: function(url){
        downloadLink.setUrl(url);
        downloadLink.style().set('shown', true);
      }
    });
  }
});
mainPanel.add(downloadButton);
// Download link
var downloadLink = ui.Label({
  value: 'Download link',
  style: {shown: false, stretch: 'horizontal', textAlign: 'center', color: 'dodgerblue'}
});
mainPanel.add(downloadLink);
// Function set empty table
function empty(){
  var value = 'Please wait...';
  tableChartAdm.setDataTable([ 
    ['Variable', 'Value', 'Unit'], 
    ['Country',  value, ' '],
    ['Province', value, ' '],
    ['Regency', value, ' '],
    ['Area', value, 'Ha']
  ]);
  tableChartPhy.setDataTable([
    ['Variable', 'Value', 'Unit'],
    ['Max elevation', value, 'm'],
    ['Min elevation', value, 'm'],
    ['Max temperature', value, 'Celsius'],
    ['Min temperature', value, 'Celsius'],
    ['Max precipitation', value, 'mm/month'],
    ['Min precipitation', value, 'mm/month'],
    ['Peat soil', value, 'Ha'],
    ['Mineral soil', value, 'Ha']
  ]);
  tableChartCarbon.setDataTable([
    ['Variable', 'Value', 'Unit'], 
    ['Above ground biomass', value, 'Ton'],
    ['Deforestation', value, 'Ha'],
    ['Deforestation rate', value, '%/year'],
    ['Emission', value, 'Ton']
  ]);
  tableChartLC.setDataTable([
    ['Variable', 'Value', 'Unit'],
    ['High density dryland forest', value, 'Ha'],
    ['Medium density dryland forest', value, 'Ha'],
    ['High density swamp forest', value, 'Ha'],
    ['Medium density swamp forest', value, 'Ha'],
    ['High density mangrove forest', value, 'Ha'],
    ['Medium density mangrove forest', value, 'Ha'],
    ['Cropland 1', value, 'Ha'],
    ['Cropland 2 (palm oil)', value, 'Ha'],
    ['Grassland', value, 'Ha'],
    ['Wetlands', value, 'Ha'],
    ['Built-up', value, 'Ha'],
    ['Bareland', value, 'Ha'],
    ['Other woody vegetation', value, 'Ha'],
    ['Water bodies', value, 'Ha']
  ]);
}
// Function to put value to table
function infoLayout(country, province, regency, area, carbonStock, 
  maxElevation, minElevation, maxTemp, minTemp, 
  rainMax, rainMin, peat, mineral, lc, deforested, deforestedRate, emissioned){
  // Set value to empty first
  empty();
  // Dictionary of value
  var dict = ee.Dictionary({
    country: country,
    province: province,
    regency: regency,
    area: area,
    carbonStock: carbonStock,
    maxElevation: maxElevation,
    minElevation: minElevation,
    maxTemp: maxTemp,
    minTemp: minTemp,
    rainMax: rainMax,
    rainMin: rainMin,
    peat: peat,
    mineral: mineral,
    lc: lc,
    deforested: deforested,
    deforestedRate: deforestedRate,
    emissioned: emissioned
  });
  dict.evaluate(input);
  function input(value){
    // List of value
    var country = value.country;
    var province = value.province;
    var regency = value.regency;
    var area = value.area.toLocaleString();
    var carbonStock = value.carbonStock;
    var minElevation = value.minElevation;
    var maxElevation = value.maxElevation;
    var minTemp = value.minTemp;
    var maxTemp = value.maxTemp;
    var rainMin = value.rainMin;
    var rainMax = value.rainMax;
    var peat = value.peat;
    var mineral = value.mineral;
    var hddf = value.lc.hddf;
    var mddf = value.lc.mddf;
    var hdsf = value.lc.hdsf;
    var mdsf = value.lc.mdsf;
    var hdmf = value.lc.hdmf;
    var mdmf = value.lc.mdmf;
    var crop1 = value.lc.crop1;
    var crop2 = value.lc.crop2;
    var grass = value.lc.grass;
    var wet = value.lc.wet;
    var built = value.lc.built;
    var bare = value.lc.bare;
    var other = value.lc.other;
    var water = value.lc.water;
    var deforested = value.deforested;
    var deforestedRate = value.deforestedRate;
    var emissioned = value.emissioned;
    // Set value to the table
    tableChart.setDataTable([ 
      ['Variable', 'Value', 'Unit'], 
      ['Country', country, ' '],
      ['Province', province, ' '],
      ['Regency', regency, ' '],
      ['Area', area, 'Ha'],
      ['Above ground biomass', carbonStock, 'Ton'],
      ['Deforestation', deforested, 'Ha'],
      ['Deforestation rate', deforestedRate, '%/year'],
      ['Emission', emissioned, 'Ton/year'],
      ['Max elevation', maxElevation, 'm'],
      ['Min elevation', minElevation, 'm'],
      ['Max temperature', maxTemp, 'Celsius'],
      ['Min temperature', minTemp, 'Celsius'],
      ['Max precipitation', rainMax, 'mm/month'],
      ['Min precipitation', rainMin, 'mm/month'],
      ['Peat soil', peat, 'Ha'],
      ['Mineral soil', mineral, 'Ha'],
      ['High density dryland forest', hddf, 'Ha'],
      ['Medium density dryland forest', mddf, 'Ha'],
      ['High density swamp forest', hdsf, 'Ha'],
      ['Medium density swamp forest', mdsf, 'Ha'],
      ['High density mangrove forest', hdmf, 'Ha'],
      ['Medium density mangrove forest', mdmf, 'Ha'],
      ['Cropland 1', crop1, 'Ha'],
      ['Cropland 2 (palm oil)', crop2, 'Ha'],
      ['Grassland', grass, 'Ha'],
      ['Wetlands', wet, 'Ha'],
      ['Built-up', built, 'Ha'],
      ['Bareland', bare, 'Ha'],
      ['Other woody vegetation', other, 'Ha'],
      ['Water bodies', water, 'Ha']
    ]);
    tableChartAdm.setDataTable([ 
      ['Variable', 'Value', 'Unit'], 
      ['Country', country, ' '],
      ['Province', province, ' '],
      ['Regency', regency, ' '],
      ['Area', area, 'Ha']
    ]);
    tableChartPhy.setDataTable([
      ['Variable', 'Value', 'Unit'],
      ['Max elevation', maxElevation, 'm'],
      ['Min elevation', minElevation, 'm'],
      ['Max temperature', maxTemp, 'Celsius'],
      ['Min temperature', minTemp, 'Celsius'],
      ['Max precipitation', rainMax, 'mm/month'],
      ['Min precipitation', rainMin, 'mm/month'],
      ['Peat soil', peat, 'Ha'],
      ['Mineral soil', mineral, 'Ha']
    ]);
    tableChartCarbon.setDataTable([
      ['Variable', 'Value', 'Unit'], 
      ['Above ground biomass', carbonStock, 'Ton'],
      ['Deforestation', deforested, 'Ha'],
      ['Deforestation rate', deforestedRate, '%/year'],
      ['Emission', emissioned, 'Ton/year']
    ]);
    tableChartLC.setDataTable([
      ['Variable', 'Value', 'Unit'],
      ['High density dryland forest', hddf, 'Ha'],
      ['Medium density dryland forest', mddf, 'Ha'],
      ['High density swamp forest', hdsf, 'Ha'],
      ['Medium density swamp forest', mdsf, 'Ha'],
      ['High density mangrove forest', hdmf, 'Ha'],
      ['Medium density mangrove forest', mdmf, 'Ha'],
      ['Cropland 1', crop1, 'Ha'],
      ['Cropland 2 (palm oil)', crop2, 'Ha'],
      ['Grassland', grass, 'Ha'],
      ['Wetlands', wet, 'Ha'],
      ['Built-up', built, 'Ha'],
      ['Bareland', bare, 'Ha'],
      ['Other woody vegetation', other, 'Ha'],
      ['Water bodies', water, 'Ha']
    ]);
  }
}
// Indonesia geometry
function indonesia(){
  return gaul0.filter(ee.Filter.eq('ADM0_NAME', 'Indonesia')).first().geometry();
}
// Function to zoom to Kalimantan
function myLocation(){
  // Select Indonesia map for center object
  Map.centerObject(indonesia(), 5);
}
// Function to start map
function resetMap(){
  // Change cursor
  Map.style().set({cursor: 'crosshair'});
  // Change map view
  Map.setControlVisibility({
    all: false,
    mapTypeControl: true,
    scaleControl: true,
    fullscreenControl: true,
    layerList: true,
    drawingToolsControl: true
  });
  // Set drawing tools to only be rectangle and not linked to script
  Map.drawingTools().setDrawModes(['rectangle', 'polygon']).setLinked(false);
}
// Hide geometry
function hideGeom(){
  // Set geometry to hide after each function
  Map.drawingTools().layers().forEach(function(obj){
    obj.setShown(false);
  });
}
// Hillshade SRTM
function hillshadeSRTM(){
  var srtm = ee.Image("USGS/SRTMGL1_003");
  var elevation = srtm.select('elevation').updateMask(srtm.gt(0)).multiply(10);
  var N = ee.Terrain.hillshade(elevation, 0, 36).multiply(0);
  var NE = ee.Terrain.hillshade(elevation, 45, 44).multiply(0);
  var E = ee.Terrain.hillshade(elevation, 90, 56).multiply(0);
  var SE = ee.Terrain.hillshade(elevation, 135, 68).multiply(0);
  var S = ee.Terrain.hillshade(elevation, 180, 80).multiply(0.1);
  var SW = ee.Terrain.hillshade(elevation, 225, 68).multiply(0.2);
  var W = ee.Terrain.hillshade(elevation, 270, 56).multiply(0.2);
  var NW = ee.Terrain.hillshade(elevation, 315, 44).multiply(0.5);
  var MULTI = N.add(NE).add(E).add(SE).add(S).add(SW).add(W).add(NW).visualize({
    min: 0,
    max: 255,
    palette: ['#000000', '#ffffff']
  }).updateMask(0.5);
  var SLOPE = ee.Terrain.slope(elevation).multiply(2).visualize({
    min: 100,
    max: 180,
    palette: ['#ffffff', '#000000']
  }).updateMask(1);
  var SHADED_RELIEF = ee.ImageCollection([SLOPE, MULTI]).mosaic().reduce(ee.Reducer.median()).updateMask(1);
  var reliefVisualized = SHADED_RELIEF.visualize({min: 0, max: 255, gamma: 1});
  var srtmColor = srtm.visualize({min: 0, max: 5000, palette: ['green', 'yellow', 'red', 'white']})
    .updateMask(srtm.gt(0))
    .updateMask(0.4);
  var visualized = reliefVisualized.blend(srtmColor);
  return visualized;
}
// DEM cloud
function demCloud(){
  var demLayer = ui.Map.CloudStorageLayer({
    bucket: 'gee-maptile',
    path: 'map/dem',
    maxZoom: 12,
    suffix: '.png',
    name: 'DEM',
    shown: false
  });
  return demLayer;
}
// Land cover
function lc(){
  var image = ee.ImageCollection([
    ee.Image('projects/fa-landsat-2022/assets/LC2022L89_Kalimantan_0122_0922_LCv4'),
    ee.Image('projects/fa-landsat-2022/assets/LC2022L89_Sumatera_0122_0922_v3'),
    ee.Image('projects/fa-landsat-2022/assets/LC2022L89_Papua_0122_0922_v1'),
    ee.Image('projects/fa-landsat-2022/assets/LC2022L89_JawaBali_0122_0922_v1')
  ]).mosaic().setDefaultProjection('EPSG:4326', null, 30);
  image = image.updateMask(image.neq(0));
  return image.set('LULC_class_names', lulc.classNames, 'LULC_class_values', lulc.classValues, 'LULC_class_palette', lulc.classPalette);
}
// Land cover 2010
function lc2010(){
  var image = ee.ImageCollection([
    ee.Image('projects/fa-landsat-2010/assets/LC2010L57_Kalimantan_0110_1210_v1'),
    ee.Image('projects/fa-landsat-2010/assets/LC2010L57_Sumatera_0110_1210_v1'),
    ee.Image('projects/fa-landsat-2010/assets/LC2010L57_Papua_0110_1210_v1')
  ]).mosaic().setDefaultProjection('EPSG:4326', null, 30);
  image = image.updateMask(image.neq(0));
  return image;
}
// Land cover 2000
function lc2000(){
  var image = ee.ImageCollection([
    ee.Image('projects/fa-landsat-2000/assets/LC2000L57_Sumatera_0100_1200_v1'),
    ee.Image('projects/fa-landsat-2000/assets/LC2000L57_Kalimantan_0100_1200_v2'),
    ee.Image('projects/fa-landsat-2000/assets/LC2000L57_Papua_0100_1200_v1')
  ]).mosaic().setDefaultProjection('EPSG:4326', null, 30);
  image = image.updateMask(image.neq(0));
  return image;
}
// Function to get land cover area
function lcReduce(geom){
  var reducer = ee.Reducer.sum();
  var image = lc();
  var dictShort = ['hddf', 'mddf', 'hdsf', 'mdsf', 'hdmf', 'mdmf', 
    'crop1', 'crop2', 'grass', 'wet', 'built', 'bare', 'other', 'water'];
  var dict = ee.Dictionary({});
  var valueList = lulc.classValues;
  for (var i = 0; i < valueList.length; i++){
    var value = ee.Number(image.eq(valueList[i])
      .reduceRegion({
        geometry: geom,
        reducer: reducer,
        scale: 1000,
        bestEffort: true
    }).get('LULC')).multiply(0.09).multiply(1111).round();
    dict = dict.set(dictShort[i], value);
  }
  return dict;
}
// LULC cloud storage layer
function lulcCloud(){
  var lulcLayer = ui.Map.CloudStorageLayer({
    bucket: 'gee-maptile',
    path: 'map/landCoverV3',
    maxZoom: 12,
    suffix: '.png',
    name: 'LULC 2022'
  });
  return lulcLayer;
}
// Function to add image to GEE
function basemap(){
  Map.add(demCloud());
  Map.add(lulcCloud());
  var palette = ['red', 'orange', 'green'];
  Map.addLayer(agbPx(), {min: 10, max: 23, palette: palette}, 'Above Ground Biomass', false);
}
// Function to generate pixel agb
function agbPx(){
  var image = ee.ImageCollection([
      ee.Image('projects/fa-landsat-2022/assets/AGBPx_L89_Kalimantan_0122_0922_LCv1'),
      ee.Image('projects/fa-landsat-2022/assets/AGBPx_L89_Sumatera_0122_0922_LCv1'),
      ee.Image('projects/fa-landsat-2022/assets/AGBPx_L89_Papua_0122_0922_LCv1'),
      ee.Image('projects/fa-landsat-2022/assets/AGBPx_L89_JawaBali_0122_1122_LCv1')
  ]).mosaic().setDefaultProjection('EPSG:4326', null, 30);
  return image;
}
// Function to generate ha abg
function agbHa(){
  var image = ee.ImageCollection([
      ee.Image('projects/fa-landsat-2022/assets/AGBHa_L89_Kalimantan_0122_0922_LCv1'),
      ee.Image('projects/fa-landsat-2022/assets/AGBHa_L89_Sumatera_0122_0922_LCv1'),
      ee.Image('projects/fa-landsat-2022/assets/AGBHa_L89_Papua_0122_0922_LCv1'),
      ee.Image('projects/fa-landsat-2022/assets/AGBHa_L89_JawaBali_0122_1122_LCv1')
  ]).mosaic().setDefaultProjection('EPSG:4326', null, 100);
  return image;
}
// Function to generate pixel agb 2010
function agbPx2010(){
  var image = ee.ImageCollection([
      ee.Image('projects/fa-landsat-2010/assets/AGBPx_L57_Kalimantan_0110_1210_LCv1'),
      ee.Image('projects/fa-landsat-2010/assets/AGBPx_L57_Papua_0110_1210_LCv1'),
      ee.Image('projects/fa-landsat-2010/assets/AGBPx_L57_Sumatera_0110_1210_LCv1'),
  ]).mosaic().setDefaultProjection('EPSG:4326', null, 30);
  return image;
}
// Function to generate ha abg 2010
function agbHa2010(){
  var image = ee.ImageCollection([
      ee.Image('projects/fa-landsat-2010/assets/AGBHa_L57_Papua_0110_1210_LCv1'),
      ee.Image('projects/fa-landsat-2010/assets/AGBHa_L57_Kalimantan_0110_1210_LCv1'),
      ee.Image('projects/fa-landsat-2010/assets/AGBHa_L57_Sumatera_0110_1210_LCv1')
  ]).mosaic().setDefaultProjection('EPSG:4326', null, 100);
  return image;
}
// Function to generate pixel agb 2000
function agbPx2000(){
  var image = ee.ImageCollection([
      ee.Image('projects/fa-landsat-2000/assets/AGBHa_L57_Kalimantan_0100_1200_LCv1'),
      ee.Image('projects/fa-landsat-2000/assets/AGBHa_L57_Papua_0100_1200_LCv1'),
      ee.Image('projects/fa-landsat-2000/assets/AGBHa_L57_Sumatera_0100_1200_LCv1')
  ]).mosaic().setDefaultProjection('EPSG:4326', null, 30);
  return image;
}
// Function to generate ha abg 2000
function agbHa2000(){
  var image = ee.ImageCollection([
      ee.Image('projects/fa-landsat-2000/assets/AGBPx_L57_Kalimantan_0100_1200_LCv1'),
      ee.Image('projects/fa-landsat-2000/assets/AGBPx_L57_Papua_0100_1200_LCv1'),
      ee.Image('projects/fa-landsat-2000/assets/AGBPx_L57_Sumatera_0100_1200_LCv1')
  ]).mosaic().setDefaultProjection('EPSG:4326', null, 100);
  return image;
}
// Drawing tools function
function draw(){
  // Drawing tools
  var drawingTools = Map.drawingTools();
  // Function when drawing tools change
  function change() {
    var layer = drawingTools.layers();
    var name = layer.getJsArray().map(function(obj){
      var objName = obj.getName();
      return objName;
    });
    drawSelect.items().reset(name);
  }
  change();
  // Applying change function to drawing tools
  drawingTools.onLayerAdd(change);
  drawingTools.onLayerRemove(change);
}
// Make geometry draw to select geometry
draw();
// Function to return draw aoi as geometry
function drawGeometry(){
  var geomName = drawSelect.getValue();
  var layer = ee.FeatureCollection(Map.drawingTools().layers().getJsArray().map(function(obj){
    var name = obj.getName();
    return ee.Feature(obj.getEeObject()).set({'name': name});
  }));
  var geom = layer.filter(ee.Filter.eq('name', geomName)).first().geometry();
  return geom;
}
// Function to have a geometry with geojson
function geojson(){
  var string = geojsonTextbox.getValue();
  var jsonString = JSON.parse(string);
  var geometryJSON = ee.FeatureCollection(jsonString).geometry();
  return geometryJSON;
}
// Function to get Map bounds
function mapBounds(){
  var bounds = ee.Geometry(Map.getBounds(true));
  return bounds;
}
// Function to decide AOI
function aoi(){
  // AOI option
  var aoiFeature;
  var aoiStatus = aoiSelect.getValue();
  switch (aoiStatus) {
    case 'GeoJSON':
      aoiFeature = geojson();
      break;
    case 'Draw AOI':
      aoiFeature = drawGeometry();
      break;
    case 'Map bounds':
      aoiFeature = mapBounds();
      break;
  }
  return aoiFeature;
}
// Function to activate show images
function activateStatisticButton(){
  var aoiStatus = aoiSelect.getValue();
  var geojsonstatus = geojsonTextbox.getValue();
  var drawSelectStatus = drawSelect.getValue();
  if (aoiStatus == 'GeoJSON' && geojsonstatus !== null) {
    showStatistic.setDisabled(false);
  } else if (aoiStatus == 'Draw AOI' && drawSelectStatus !== null) {
    showStatistic.setDisabled(false);
  } else if (aoiStatus == 'Map bounds') {
    showStatistic.setDisabled(false);
  } else {
    showStatistic.setDisabled(true);
  }
}
activateStatisticButton();
// Admin filter
function admin(geom){
  return gaul2.filterBounds(geom);
}
// Country
function country(geom){
  var feature = admin(geom);
  var name = feature.aggregate_array('ADM0_NAME').distinct().remove('Administrative unit not available');
  return name.join(', ');
}
// Province
function province(geom){
  var feature = admin(geom);
  var name = feature.aggregate_array('ADM1_NAME').distinct().remove('Administrative unit not available');
  return name.join(', ');
}
// Regency
function regency(geom){
  var feature = admin(geom);
  var name = feature.aggregate_array('ADM2_NAME').distinct().remove('Administrative unit not available');
  return name.join(', ');
}
// Area
function area(geom){
  return geom.area(1).divide(10000).round();
}
// Carbon stock
function carbonStock(geom){
  var reducer = ee.Reducer.sum();
  var data = agbHa();
  var carbonMass = data.reduceRegion({
    reducer: reducer,
    geometry: geom,
    scale: 100,
    bestEffort: true
  }).get('AGB_100');
  return ee.Number(carbonMass).round();
}
// DEM
var dem = etopo.select('bedrock');
// Min elevation
function minElevation(geom){
  var reducer = ee.Reducer.min();
  var elevation = dem;
  var min = elevation.reduceRegion({
    reducer: reducer,
    geometry: geom,
    scale: 1855,
    bestEffort: true,
  }).get('bedrock');
  return min;
}
// Min elevation
function maxElevation(geom){
  var reducer = ee.Reducer.max();
  var elevation = dem;
  var max = elevation.reduceRegion({
    reducer: reducer,
    geometry: geom,
    scale: 1855,
    bestEffort: true
  }).get('bedrock');
  return max;
}
// Min temperature
function minTemp(geom){
  var reducer = ee.Reducer.min();
  var iklim = climate.min().select('tmin').divide(10);
  var min = iklim.reduceRegion({
    reducer: reducer,
    geometry: geom,
    scale: 927.67,
    bestEffort: true
  }).get('tmin');
  return min;
}
// Max temperature
function maxTemp(geom){
  var reducer = ee.Reducer.max();
  var iklim = climate.max().select('tmax').divide(10);
  var max = iklim.reduceRegion({
    reducer: reducer,
    geometry: geom,
    scale: 927.67,
    bestEffort: true
  }).get('tmax');
  return max;
}
// Max precipitation
function precipMax(geom){
  var reducer = ee.Reducer.max();
  var iklim = climate.max().select('prec');
  var max = iklim.reduceRegion({
    reducer: reducer,
    geometry: geom,
    scale: 927.67,
    bestEffort: true
  }).get('prec');
  return ee.Number(max).round();
}
// Max precipitation
function precipMin(geom){
  var reducer = ee.Reducer.min();
  var iklim = climate.min().select('prec');
  var min = iklim.reduceRegion({
    reducer: reducer,
    geometry: geom,
    scale: 927.67,
    bestEffort: true
  }).get('prec');
  return ee.Number(min).round();
}
// Peat soil
function peat(geom){
  var reducer = ee.Reducer.sum();
  var peatSoil = ee.Image(soil).where(soil.eq(1), 1).where(soil.eq(2), 0);
  var area = peatSoil.reduceRegion({
    reducer: reducer,
    geometry: geom,
    scale: 10,
    bestEffort: true,
  }).get('b1');
  var num = ee.Number(area).pow(2).divide(100000).round();
  return num;
}
// Mineral soil
function mineral(geom){
  var reducer = ee.Reducer.sum();
  var mineralSoil = ee.Image(soil).where(soil.eq(2), 1).where(soil.eq(1), 0);
  var area = mineralSoil.reduceRegion({
    reducer: reducer,
    geometry: geom,
    scale: 10,
    bestEffort: true,
  }).get('b1');
  var num = ee.Number(area).pow(2).divide(100000).round();
  return num;
}
// Base year forest
function baseForest(geom){
  var value = lc2010().gte(10).and(lc2010().lte(40)).multiply(ee.Image.pixelArea()).divide(10000)
    .clip(geom)
    .reduceRegion({
      reducer: ee.Reducer.sum(),
      scale: 30,
      geometry: geom,
      bestEffort: true,
    }).get('LULC');
  return ee.Number(value);
}
// Current forest
function currentForest(geom){
  var value = lc().gte(10).and(lc().lte(40)).multiply(ee.Image.pixelArea()).divide(10000)
    .clip(geom)
    .reduceRegion({
      reducer: ee.Reducer.sum(),
      scale: 30,
      geometry: geom,
      bestEffort: true,
    }).get('LULC');
  return ee.Number(value);
}
// Deforestation
function deforestation(geom){
  return baseForest(geom).subtract(currentForest(geom)).round();
}
// Deforestation rate
function deforestationRate(geom){
  return deforestation(geom).divide(baseForest(geom)).multiply(100).divide(12);
}
// Emission
function emission(geom){
  var agb2022 = agbHa().clip(geom).multiply(0.47).multiply(3.67)
    .reduceRegion({
      reducer: ee.Reducer.sum(),
      scale: 30,
      geometry: geom,
      bestEffort: true,
    }).get('AGB_100');
  var agb2010 = agbHa2010().clip(geom).multiply(0.47).multiply(3.67)
    .reduceRegion({
      reducer: ee.Reducer.sum(),
      scale: 30,
      geometry: geom,
      bestEffort: true,
    }).get('AGB_100');
  var delta = ee.Number(agb2010).subtract(ee.Number(agb2022)).divide(12).round();
  return delta;
}
// AOI to map
function aoiMap(geom){
  Map.addLayer(geom, {color: 'red'}, 'Area of interest');
}
// Function to show statistic
function calculate(mode){
  // Hide geometry
  hideGeom();
  // Delete AOI
  if (Map.layers().get(3) !== undefined){
    Map.remove(Map.layers().get(3));
  }
  // Zoom to aoi if geojson
  if(aoiSelect.getValue() == 'GeoJSON'){
    Map.centerObject(aoi(), 10);
  }
  var geom;
  if(mode == 'AOI'){
    geom = aoi();
  } else {
    geom = ee.Geometry.Point(mode);
  }
  // Add AOI to map
  aoiMap(geom);
  // Variabel
  var countryName = country(geom);
  var provinceName = province(geom);
  var regencyName = regency(geom);
  var areaSize = area(geom);
  var carbonValue = carbonStock(geom);
  var maxElevationName = maxElevation(geom);
  var minElevationName = minElevation(geom);
  var maxTempName = maxTemp(geom);
  var minTempName = minTemp(geom);
  var rainMax = precipMax(geom);
  var rainMin = precipMin(geom);
  var peatArea = peat(geom);
  var mineralArea = mineral(geom);
  var landCover = lcReduce(geom);
  var deforested = deforestation(geom);
  var deforestedRate = deforestationRate(geom);
  var emissioned = emission(geom);
  // Set value to data table
  infoLayout(countryName, provinceName, regencyName, 
    areaSize, carbonValue, maxElevationName, minElevationName, 
    maxTempName, minTempName, rainMax, rainMin,
    peatArea, mineralArea, landCover, deforested, deforestedRate, emissioned);
}
// Function for info for clicking
function click(){
  Map.onClick(clickAction);
  function clickAction(list){
    if (clickCheckbox.getValue() === true){
      var x = list.lon;
      var y = list.lat;
      calculate([x, y]);
    }
  }
}
// Run click function
click();
// Panel for the number
var infoPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical', true),
  style: {position: 'bottom-left', padding: '10px', width: '320px'}
});
ui.root.insert(0, infoPanel);
// Minimize button
var minimizeButton2 = ui.Button({
  label: '<',
  style: {position: 'top-right', stretch: 'horizontal', },
  onClick: function(){
    infoPanel.style().set('shown', false);
    maximizeButton2.style().set('shown', true);
  }
});
infoPanel.add(minimizeButton2);
// Maximize button
var maximizeButton2 = ui.Button({
  label: '>',
  style: {shown: false, position: 'top-left', margin: '0', padding: '0', },
  onClick: function(){
    infoPanel.style().set('shown', true);
    maximizeButton2.style().set('shown', false);
  }
});
Map.add(maximizeButton2);
// Legend label
var legendLabel = ui.Label({
  value: 'Legend',
  style: {fontWeight: 'bold', fontSize: 25, color: 'black', stretch: 'horizontal', textAlign: 'center', }
});
infoPanel.add(legendLabel);
// Legend panel
var legendPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal', true),
  style: {margin: 'auto auto 20px auto', stretch: 'horizontal'}
});
infoPanel.add(legendPanel);
var legend = legendCategory('LULC 2022', lulc.classNames, lulc.classPalette, 14, 'bottom-center');
legend.style().set('stretch', 'horizontal');
legend.style().set('border', '1px solid gray');
legend.style().set('margin', 'auto 5px auto auto');
legend.style().set('fontSize', '11px');
legendPanel.add(legend);
var legendAGB = legendColormap('AGB (Ton)', {palette: ['red', 'orange', 'green'], min: 10, max: 23}, 'bottom-center');
legendAGB.style().set('stretch', 'both');
legendAGB.style().set('fontSize', '11px');
legendAGB.style().set('border', '1px solid gray');
legendAGB.style().set('width', '60px');
legendPanel.add(legendAGB);
// Data source panel
var sourcePanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical', true),
  style: {margin: 'auto auto 20px auto', stretch: 'horizontal'}
});
infoPanel.add(sourcePanel);
// Data source label
var sourceLabel = ui.Label({
  value: 'Sources',
  style: {fontWeight: 'bold', fontSize: 25, color: 'black', stretch: 'horizontal', textAlign: 'center', }
});
sourcePanel.add(sourceLabel);
// Landsat 8 & Landsat 9
var landsatLabel = ui.Label({
  value: 'Landsat 8 & 9 OLI 2022',
  targetUrl: 'https://www.usgs.gov/centers/eros/science/usgs-eros-archive-landsat-archives-landsat-8-9-operational-land-imager-and',
  style: {color: 'dodgerblue'}
});
sourcePanel.add(landsatLabel);
// GAUL
var gaulLabel = ui.Label({
  value: 'FAO GAUL: Global Administrative Unit Layers 2015',
  targetUrl: 'https://www.fao.org/geonetwork/srv/en/metadata.show?id=12691',
  style: {color: 'dodgerblue'}
});
sourcePanel.add(gaulLabel);
// WorldClim
var climLabel = ui.Label({
  value: 'WorldClim Climatology V1',
  targetUrl: 'https://www.worldclim.org/',
  style: {color: 'dodgerblue'}
});
sourcePanel.add(climLabel);
// ETOPO
var etopoLabel = ui.Label({
  value: 'ETOPO1: Global 1 Arc-Minute Elevation',
  targetUrl: 'https://www.ngdc.noaa.gov/mgg/global/global.html',
  style: {color: 'dodgerblue'}
});
sourcePanel.add(etopoLabel);
// Support panel
var supportPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal', true),
  style: {margin: 'auto auto 20px auto', stretch: 'horizontal', shown: false, }
});
infoPanel.add(supportPanel);
// Data source label
var supportLabel = ui.Label({
  value: 'Supported by',
  style: {fontWeight: 'bold', fontSize: 25, color: 'black', stretch: 'horizontal', textAlign: 'center', }
});
supportPanel.add(supportLabel);
// Thumbnail
var thumb = ui.Thumbnail({
  image: ee.Image('projects/ee-ramadhan/assets/logo2'),
  params: {bands: ['b1','b2','b3'], min: 0, max: 255},
  style: {width: '260px'}
});
supportPanel.add(thumb);
// Function to export to cloud storage layer as map
function exportCloud(image, desc, mapsAPI){
  Export.map.toCloudStorage({
    image: image,
    description: desc,
    bucket: 'gee-maptile',
    path: 'map/' + desc,
    maxZoom: 12,
    minZoom: 0,
    fileFormat: 'png',
    writePublicTiles: true,
    region: indonesia().bounds(),
    skipEmptyTiles: true,
    mapsApiKey: mapsAPI
  });
}