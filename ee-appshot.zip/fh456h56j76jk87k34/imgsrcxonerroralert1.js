//\x22\u0022
window.alert()