var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                113.5461923613025,
                -8.067697779885123
              ],
              [
                113.5461923613025,
                -8.235330711996964
              ],
              [
                113.72171611923707,
                -8.235330711996964
              ],
              [
                113.72171611923707,
                -8.067697779885123
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[113.5461923613025, -8.067697779885123],
          [113.5461923613025, -8.235330711996964],
          [113.72171611923707, -8.235330711996964],
          [113.72171611923707, -8.067697779885123]]], null, false);
var S2A = ee.ImageCollection('COPERNICUS/S2_SR')
                   .filterDate('2020-10-01', '2021-12-01')
                .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 90))
                .map(maskS2clouds)
                .median()
                .clip(geometry);
function maskS2clouds(image) {
  var qa = image.select('QA60');
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(1);
}  
var RGBTrue = S2A.select(['B8', 'B11', 'B4']);
var RGBparam = { min: 0, max: 3000,};
Map.addLayer(RGBTrue, RGBparam, 'Sentinel RGB 8114');