var extent2017 = ui.import && ui.import("extent2017", "table", {
      "id": "projects/earthengine-legacy/assets/users/nwobicj/2017mangrovelagos"
    }) || ee.FeatureCollection("projects/earthengine-legacy/assets/users/nwobicj/2017mangrovelagos"),
    extent2007 = ui.import && ui.import("extent2007", "table", {
      "id": "projects/earthengine-legacy/assets/users/nwobicj/2007mangrovelagos"
    }) || ee.FeatureCollection("projects/earthengine-legacy/assets/users/nwobicj/2007mangrovelagos"),
    biomass17 = ui.import && ui.import("biomass17", "image", {
      "id": "projects/earthengine-legacy/assets/users/nwobicj/17lagAGBagain0to200mangrove_ignore"
    }) || ee.Image("projects/earthengine-legacy/assets/users/nwobicj/17lagAGBagain0to200mangrove_ignore"),
    biomass07 = ui.import && ui.import("biomass07", "image", {
      "id": "projects/earthengine-legacy/assets/users/nwobicj/07lagAGBagain0to200mangrove_ignore"
    }) || ee.Image("projects/earthengine-legacy/assets/users/nwobicj/07lagAGBagain0to200mangrove_ignore"),
    lagos = ui.import && ui.import("lagos", "table", {
      "id": "projects/earthengine-legacy/assets/users/nwobicj/lagosshapefile"
    }) || ee.FeatureCollection("projects/earthengine-legacy/assets/users/nwobicj/lagosshapefile");
////////////////Gray background/////////////////////
var GRAYMAP = [
    {   // Dial down the map saturation.
    stylers: [ { saturation: -100 } ],
    //stylers: [{color: '#382e61'}]
  },{ // Dial down the label darkness.
    elementType: 'labels',
    stylers: [ { lightness: 20 } ]
  },{ // Simplify the road geometries.
    featureType: 'road',
    elementType: 'geometry',
    stylers: [ { visibility: 'simplified' } ]
  },{ // Turn off road labels.
    featureType: 'road',
    elementType: 'labels',
    stylers: [ { visibility: 'off' } ]
  },{ // Turn off all icons.
    elementType: 'labels.icon',
    stylers: [ { visibility: 'off' } ]
  },{ // Turn off all POIs.
    featureType: 'poi',
    elementType: 'all',
    stylers: [ { visibility: 'off' }]
  }
];
Map.setOptions('Gray Map', {'Gray Map': GRAYMAP}).setControlVisibility(true, true, true, true, true, false); //retro, dark, GRAYMAP
// =================================================================================================//
///////////////////////////////////////////////////////////////
//                    1) Import Layers of Interest           //
///////////////////////////////////////////////////////////////
//var extent2007 = ee.Image('projects/earthengine-legacy/assets/users/nwobicj/correct17lagAGBagain0to200mangrove')
// Make an image out of the land area attribute.
var mangrovearea17img1 = extent2017.reduceToImage({
    properties: ['Area'],
    reducer: ee.Reducer.first()
});
// Make an image out of the land area attribute.
var mangrovearea07img1 = extent2007.reduceToImage({
    properties: ['Area'],
    reducer: ee.Reducer.first()
});
// // Scale the AGB image to 30m
// var biomass17 =
// biomass171.reproject(ee.Projection('EPSG:4326').atScale(30)).reduceResolution({reducer:
// ee.Reducer.mean(),maxPixels: 6553});
// var biomass07 =
// biomass071.reproject(ee.Projection('EPSG:4326').atScale(30)).reduceResolution({reducer:
// ee.Reducer.mean(),maxPixels: 6553});
// Scale the Mangrove Area image to 30m
var mangrovearea17img =
mangrovearea17img1.reproject(ee.Projection('EPSG:32631').atScale(30)).reduceResolution({reducer:
ee.Reducer.mean(),maxPixels: 6553});
var mangrovearea07img =
mangrovearea07img1.reproject(ee.Projection('EPSG:32631').atScale(30)).reduceResolution({reducer:
ee.Reducer.mean(),maxPixels: 6553});
// print(mangrovearea17img);
// print(biomass17);
// //Mosaic the Simard data to an Image so we can clip it later
// var agb17 = biomass17.mosaic()
// var agb07 = biomass07.mosaic()
///////////////////////////////////////////////////////////////
//      2) Begin setting up map appearance and app layers   //
///////////////////////////////////////////////////////////////
//2.1) Set up general display
// //Set up a satellite background
// Map.setOptions('Satellite')
//Center the map to Guyana
Map.centerObject(lagos,11)
//Change style of cursor to 'crosshair'
Map.style().set('cursor', 'crosshair');
//2.2) We want to set up a Viridis color pallete to display the Simard data
var viridis = {min: 0 , max : 200,palette : ['red','yellow','green' 
]};
//2.3) Create variables for GUI layers for each layer
//We set each layer to "false" so the user can turn them on later
var agbiomass17 = ui.Map.Layer(biomass17,viridis,'Mangrove Aboveground Biomass 2017',false)
var agbiomass07 = ui.Map.Layer(biomass07,viridis,'Mangrove Aboveground Biomass 2007',false)
var ext2017 = ui.Map.Layer(mangrovearea17img, {palette:['6D63EB'], min:1, max:1}, 'Mangrove Extent 2017',false)
var ext2007 = ui.Map.Layer(mangrovearea07img, {palette:['34BFDE'], min:1, max:1}, 'Mangrove Extent 2017',false)
//Add these layers to our map. They will be added but not displayed
Map.add(agbiomass17)
Map.add(agbiomass07)
Map.add(ext2017)
Map.add(ext2007)
///////////////////////////////////////////////////////////////
//      3) Set up panels and widgets for display             //
///////////////////////////////////////////////////////////////
//3.1) Set up title and summary widgets
//App title
var header = ui.Label('Lagos Mangrove Extent, Aboveground Biomass and Loss Explorer', {fontSize: '20px', fontWeight: 'bold', color: '4A997E'});
//App summary
var text = ui.Label(
  'This tool shows research of mangrove extent in Lagos Nigeria in 2007 and 2017 using a Support Vector Machine Classification derived from Landsat imagery and ALOS PALSAR. ' +
  'Use the tools below to explore changes in mangrove extent, AGB in 2007 and 2017, and mangrove loss.',
    {fontSize: '15px'});
//3.2) Create a panel to hold text
var panel = ui.Panel({
  widgets:[header, text],//Adds header and text
  style:{width: '400px',position:'middle-right'}});
//3.3) Create variable for additional text and separators
//This creates another panel to house a line separator and instructions for the user
var intro = ui.Panel([
  ui.Label({
    value: '____________________________________________',
    style: {fontWeight: 'bold',  color: '4A997E'},
  }),
  ui.Label({
    value:'Select layers to display.',
    style: {fontSize: '15px', fontWeight: 'bold'}
  })]);
//Add this new panel to the larger panel we created 
panel.add(intro);
//3.4) Add our main panel to the root of our GUI
ui.root.insert(1,panel);
///////////////////////////////////////////////////////////////
//         4) Add checkbox widgets and legends               //
///////////////////////////////////////////////////////////////
//4.1) Create a new label for this series of checkboxes
var extLabel = ui.Label({value:'Mangrove Extent',
style: {fontWeight: 'bold', fontSize: '16px', margin: '10px 5px'}
});
//4.2) Add checkboxes to our display
//Create checkboxes that will allow the user to view the extent map for different years
//Creating the checkbox will not do anything yet, we add functionality further 
// in the code
var extCheck1 = ui.Checkbox('2007').setValue(false); //false = unchecked
var extCheck2 = ui.Checkbox('2017').setValue(false);
//Now do the same for the Simard Height map
var agbLab = ui.Label({value:'Mangrove AGB',
style: {fontWeight: 'bold', fontSize: '16px', margin: '10px 5px'}
});
var agbCheck1 = ui.Checkbox('2017').setValue(false);
var agbCheck2 = ui.Checkbox('2007').setValue(false);
//4.3) Create legends
//The following code creates legends we can add to the panel
//Extent Legend
///////////////
// Set position of panel
var extentLegend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// The following creates and styles 1 row of the legend.
var makeRowa = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create a label with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // Return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//Create a palette using the same colors we used for each extent layer
var paletteMAPa = [
'6D63EB',//2007
'34BFDE',//2017
];
// Name of each legend value
var namesa = ['2007','2017']; 
// Add color and names to legend
for (var i = 0; i < 2; i++) {
  extentLegend.add(makeRowa(paletteMAPa[i], namesa[i]));
  }  
//Height Legend
///////////////
// This uses function to construct a legend for the given single-band vis
// parameters.  Requires that the vis parameters specify 'min' and 
// 'max' but not 'bands'.
function makeLegend2 (viridis) {
  var lon = ee.Image.pixelLonLat().select('longitude');
  var gradient = lon.multiply((viridis.max-viridis.min)/100.0).add(viridis.min);
  var legendImage = gradient.visualize(viridis);
  var thumb = ui.Thumbnail({
    image: legendImage, 
    params: {bbox:'0,0,100,8', dimensions:'256x20'},  
    style: {position: 'bottom-center'}
  });
  var panel2 = ui.Panel({
    widgets: [
      ui.Label('0 t/ ha'), 
      ui.Label({style: {stretch: 'horizontal'}}), 
      ui.Label('200 t/ ha')
    ],
    layout: ui.Panel.Layout.flow('horizontal'),
    style: {stretch: 'horizontal', maxWidth: '270px', padding: '0px 0px 0px 8px'}
  });
  return ui.Panel().add(panel2).add(thumb);
}
//4.4) Add these new widgets to the panel in the order you want them to appear
panel.add(extLabel)
      .add(extCheck1)
      .add(extCheck2)
      .add(extentLegend)
      .add(agbLab)
      .add(makeLegend2(viridis))
      .add(agbCheck1)
      .add(agbCheck2)
///////////////////////////////////////////////////////////////
//          5) Add functionality to widgets                  //
///////////////////////////////////////////////////////////////
//For each checkbox we create function so that clicking the checkbox
//Turns on layers of interest
//Extent 2017
var doCheckbox = function() {
  extCheck1.onChange(function(checked){
  ext2017.setShown(checked)
  })
}
doCheckbox();
//Extent 2007
var doCheckbox2 = function() {
  extCheck2.onChange(function(checked){
  ext2007.setShown(checked)
  })
}
doCheckbox2();
//AGB Data 2017
var doCheckbox3 = function() {
  agbCheck1.onChange(function(checked){
  agbiomass17.setShown(checked)
  })
}
doCheckbox3();
//AGB Data 2007
var doCheckbox4 = function() {
  agbCheck2.onChange(function(checked){
  agbiomass07.setShown(checked)
  })
}
doCheckbox4();
////////////////////////////////////////////////////////
//       6) Add a clicking feature to get AGB //
////////////////////////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical')
});
// Add a label to the panel.
inspector.add(ui.Label('Click to get AGB 2007'));
// Add the panel to the default map.
Map.add(inspector);
//Create a function to be invoked when the map is clicked
Map.onClick(function(coords){
// Clear the panel and show a loading message.
inspector.clear();
inspector.style().set('shown', true);
inspector.add(ui.Label('Loading...', {color: 'gray'}));
//Compute the AGB value
var point = ee.Geometry.Point(coords.lon, coords.lat);
var reduce1 = biomass07.reduce(ee.Reducer.first());
var sampledPoint1 = reduce1.reduceRegion(ee.Reducer.first(), point, 25);
var computedValue1 = sampledPoint1.get('first');  
// Request the value from the server and use the results in a function.
computedValue1.evaluate(function(result) {
inspector.clear();
// Add a label with the results from the server.
inspector.add(ui.Label({
      value: 'AGB 2007: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
// Add a button to hide the Panel.
    inspector.add(ui.Button({
      label: 'Close',
      onClick: function() {
        inspector.style().set('shown', false);
      }
    }));
  });
});
// Create an inspector panel with a horizontal layout.
var inspector2 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical')
});
// Add a label to the panel.
inspector2.add(ui.Label('Click to get AGB 2017'));
// Add the panel to the default map.
Map.add(inspector2);
//Create a function to be invoked when the map is clicked
Map.onClick(function(coords){
// Clear the panel and show a loading message.
inspector2.clear();
inspector2.style().set('shown', true);
inspector2.add(ui.Label('Loading...', {color: 'gray'}));
//Compute the AGB value
var point = ee.Geometry.Point(coords.lon, coords.lat);
var reduce2 = biomass17.reduce(ee.Reducer.first());
var sampledPoint2 = reduce2.reduceRegion(ee.Reducer.first(), point, 30);
var computedValue2 = sampledPoint2.get('first');  
// Request the value from the server and use the results in a function.
computedValue2.evaluate(function(result) {
inspector2.clear();
// Add a label with the results from the server.
inspector2.add(ui.Label({
      value: 'AGB 2017: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
// Add a button to hide the Panel.
    inspector2.add(ui.Button({
      label: 'Close',
      onClick: function() {
        inspector2.style().set('shown', false);
      }
    }));
  });
});
////////////////////////////////////////////////////////
//  7) Constuct graphs to measure extent for each year //
////////////////////////////////////////////////////////
//2007
//Calculate area in Hectares
var get2007 = mangrovearea07img.divide(10000).reduceRegion({
      reducer:ee.Reducer.sum(),
      geometry:lagos,
      // crs: 'EPSG:32631',
      // crsTransform: [30,0,466938.644,0,-30,744371.618],
      scale: 1000,
      maxPixels:1e13,
      tileScale: 16
      }).get('first');
print(get2007);
//Get area for the Guyana region
var feature = ee.Feature(lagos)
var feature2007 = feature.set('2007', ee.Number(get2007))
//Construct Bar Chart
var chart2007 = ui.Chart.feature.byProperty(feature2007, ['2007'], ['Total'])
//Set up title and labels for chart
chart2007.setOptions({
  title: 'Total Mangrove Area',
  vAxis: {title: 'Area in Hectares'},
  legend: {position: 'none'},
  hAxis: {
    title: 'Year',
    logScale: false
  }
});
//2017
//Calculate area in Hectares
var get2017 = mangrovearea17img.divide(10000).reduceRegion({
      reducer:ee.Reducer.sum(),
      geometry:lagos,
      // crs: 'EPSG:32631',
      scale: 1000,
      maxPixels:1e13,
      tileScale: 16
      }).get('first');
print(get2017);      
//Get area for the Guyana region
var feature2017 = feature.set('2017', ee.Number(get2017));
//Construct Bar Chart
var chart2017 = ui.Chart.feature.byProperty(feature2017, ['2017'], ['Total'])
//Set up title and labels for chart
chart2017.setOptions({
  title: 'Total Mangrove Area',
  vAxis: {title: 'Area in Hectares'},
  legend: {position: 'none'},
  hAxis: {
    title: 'Year',
    logScale: false
  }
});
//2007
//Calculate AGB in tonnes
var getagb2007 = biomass07.multiply(0.09).reduceRegion({
      reducer:ee.Reducer.sum(),
      geometry:lagos,
      // crs: 'EPSG:32631',
      scale: 30,
      maxPixels:1e13,
      tileScale: 16
      }).get('b1');
//Get area for the Guyana region
var featureagb2007 = feature.set('2007', ee.Number(getagb2007));
//Construct Bar Chart
var chartagb07 = ui.Chart.feature.byProperty(featureagb2007, ['2007'], ['Total']);
//Set up title and labels for chart
chartagb07.setOptions({
  title: 'Total Mangrove AGB',
  vAxis: {title: 'AGB in tonnes'},
  legend: {position: 'none'},
  hAxis: {
    title: 'Year',
    logScale: false
  }
});
//2017
//Calculate AGB in tonnes
var getagb2017 = biomass17.multiply(0.09).reduceRegion({
      reducer:ee.Reducer.sum(),
      geometry:lagos,
      // crs: 'EPSG:32631',
      scale: 30,
      maxPixels:1e13,
      tileScale: 16
      }).get('b1');
//Get area for the Guyana region
var featureagb2017 = feature.set('2017', ee.Number(getagb2017));
//Construct Bar Chart
var chartagb17 = ui.Chart.feature.byProperty(featureagb2017, ['2017'], ['Total']);
//Set up title and labels for chart
chartagb17.setOptions({
  title: 'Total Mangrove AGB',
  vAxis: {title: 'AGB in tonnes'},
  legend: {position: 'none'},
  hAxis: {
    title: 'Year',
    logScale: false
  }
});
////////////////////////////////////////////////////////
//  8) Create a dropdown menu to display graph results //
////////////////////////////////////////////////////////
//Add a panel to hold graphs within main panel
var panelGraph = ui.Panel({
  style:{width: '300px',position:'middle-right'}
})
//Create key of items for dropdown
var y2007 = 'Area 2007'
var y2017 = 'Area 2017'
var y07 = 'AGB 2007'
var y17 = 'AGB 2017'
//Construct Dropdown
var graphSelect = ui.Select({
  items:[y2007,y2017,y07,y17],
  placeholder:'Choose year',
  onChange: selectLayer,
  style: {position:'top-right'}
})
var constraints = []
//Write a function that runs on change of Dropdown
function selectLayer(){
  var graph = graphSelect.getValue() // get value from dropdown selection
  panelGraph.clear() //clear graph panel between selections so only one graph displays
  //We use "if else" statements to write instructions for drawing graphs
  if (graph == y2007){
    panelGraph.add(chart2007)
  }
  else if (graph == y2017){
    panelGraph.add(chart2017)
  }
  else if (graph == y07){
    panelGraph.add(chartagb07)
  }
  else if (graph == y17){
    panelGraph.add(chartagb17)
  }
  for (var i = 0; i < constraints.length; ++i) {
    var constraint = select[i];
    var mode = constraint.mode.getValue();
    var value = parseFloat(constraint.value.getValue());
    if (mode == GREATER_THAN) {
      image = image.updateMask(constraint.image.gt(value));
    } else {
      image = image.updateMask(constraint.image.lt(value));
    }
}
}
//Create a new label
var graphLabel = ui.Label({value:'Select year to display mangrove extent',
style: {fontWeight: 'bold', fontSize: '16px', margin: '10px 5px'}
});
//Add selecter and graph panel to main panel
panel.add(graphLabel)
      .add(graphSelect)
      .add(panelGraph)