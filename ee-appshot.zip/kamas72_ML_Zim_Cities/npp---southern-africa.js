var gpp = ui.import && ui.import("gpp", "imageCollection", {
      "id": "MODIS/006/MYD17A2H"
    }) || ee.ImageCollection("MODIS/006/MYD17A2H"),
    npp = ui.import && ui.import("npp", "imageCollection", {
      "id": "MODIS/006/MOD17A3HGF"
    }) || ee.ImageCollection("MODIS/006/MOD17A3HGF");
// Measuring carbon storage from space for Southern Africa
// Code modified from https://mygeoblog.com/2016/10/18/measuring-carbon-storage-from-space/
// About MODIS land products 
// Running, S., M. Zhao.  <i>MOD17A3HGF MODIS/Terra Net Primary Production Gap-Filled Yearly L4 Global 500 m SIN Grid V006</i>. 2019, 
// distributed by NASA EOSDIS Land Processes DAAC, https://doi.org/10.5067/MODIS/MOD17A3HGF.006. Accessed 2022-03-26.
// The MOD17A3HGF Version 6 product provides information about annual Net Primary Production (NPP) at 500 meter (m) pixel resolution. 
// Annual NPP is derived from the sum of all 8-day Net Photosynthesis (PSN) products (MOD17A2H) from the given year. 
// The PSN value is the difference of the Gross Primary Productivity (GPP) and the Maintenance Respiration (MR).
// NPP is the amount of carbon retained in an ecosystem (increase in biomass); 
// NPP is equal to the difference between the amount of carbon produced through photosynthesis (GPP) and the amount of energy that is used for respiration (R).
// Southern Africa: Angola, Botswana, Lesotho, Malawi, Mozambique, Madagascar, Namibia, South Africa, Eswatini (Swaziland), Zambia, Zimbabwe
// Define country names
var country_names = ['Angola','Botswana','Lesotho','Malawi','Mozambique','Madagascar','Namibia','South Africa', 'Swaziland', 'Zambia', 'Zimbabwe']; 
// import the country feasture collection
var countries = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017');
// find the countries in the country list
var country = countries.filter(ee.Filter.inList('country_na', country_names)).geometry();
// set location and zoom level
Map.centerObject(country,5);
// add the countries layer
Map.addLayer(country,false,"Southern Africa");
// Define period 
var startdate = ee.Date.fromYMD(2020,1,1);
var enddate = ee.Date.fromYMD(2021,12,31);
// filter npp
var nppCollection = npp.filterDate(startdate, enddate)
                       .filterBounds(country)
                       .select("Npp");
// filter gpp                       
var gppCollection = gpp.filterDate(startdate, enddate)
                       .filterBounds(country)
                       .select("Gpp");
// calculate the npp
var myNpp = function(myimg){
     // get date
     var d = ee.Date(myimg.get('system:time_start'))
     // get year
     var y = d.get('year').toInt();
     // filter for year for GPP and NPP
     var GPPy = ee.Image(gppCollection.filter(ee.Filter.calendarRange(y, y, 'year')).sum());
     var NPPy = ee.Image(nppCollection.filter(ee.Filter.calendarRange(y, y, 'year')).mean());
     var npp8 = myimg.expression('(GGP8 / GPPy) * NPPy', 
    {
        GGP8: myimg,
        GPPy: GPPy,
        NPPy: NPPy
    });
  return npp8.copyProperties(myimg,['system:time_start'])
}
var npp8Collection = ee.ImageCollection(gppCollection.map(myNpp));
// create vizualtion settings 
var npp_viz = {min:0.0, max:300, palette:"ff0000,f0ff00,004717"};
// Calculate mean NPP between 2020 and 2021
var NPP = npp8Collection.mean().clip(country);
// add the map
Map.addLayer(NPP, npp_viz, "NPP");
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'NPP (kgC/m²/year)',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
 // Add the title to the panel
legend.add(legendTitle); 
// create the legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((npp_viz.max-npp_viz.min)/100.0).add(npp_viz.min);
var legendImage = gradient.visualize(npp_viz);
// create text on top of legend
var panel = ui.Panel({
    widgets: [
      ui.Label(npp_viz['max'])
    ],
  });
legend.add(panel);
// create thumbnail from the image
var thumbnail = ui.Thumbnail({
  image: legendImage, 
  params: {bbox:'0,0,10,100', dimensions:'10x200'},  
  style: {padding: '1px', position: 'bottom-center'}
});
// add the thumbnail to the legend
legend.add(thumbnail);
// create text on top of legend
var panel = ui.Panel({
    widgets: [
      ui.Label(npp_viz['min'])
    ],
  });
legend.add(panel);
Map.add(legend);