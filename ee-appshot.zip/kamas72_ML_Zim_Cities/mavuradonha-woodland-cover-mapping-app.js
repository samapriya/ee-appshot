var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            30.953319337661895,
            -16.494390112760126
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Point([30.953319337661895, -16.494390112760126]);
// Mapping woodland cover using training data derived from NASA's Global Ecosystem Dynamics Investigation (GEDI). 
// The training areas will be derived from GEDI's Level 2A (100 relative height (RH) metrics).
// More information at https://lpdaac.usgs.gov/documents/986/GEDI02_UserGuide_V2.pdf
// Get the boundary for Mavuradona Wilderness Area.
var boundary = ee.FeatureCollection('WCMC/WDPA/current/polygons')
  .filter(ee.Filter.inList('NAME', ['Mavuradona']));
// Load Sentinel-1 for the post-rainy season.
var S1_PRS = ee.ImageCollection('COPERNICUS/S1_GRD')
    .filterDate('2021-04-01', '2021-06-30')
    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
    .filter(ee.Filter.eq('instrumentMode', 'IW'))
    .filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'))
    .filterBounds(boundary);
// Prepare inter-quartile range (IQR) 
var S1_PRS_pc = S1_PRS.reduce(ee.Reducer.percentile([25,50,75]));
// Convert to natural units (linear units, which can be averaged)
var S1_PRS_pc = ee.Image(10).pow(S1_PRS_pc.divide(10));
var S1_PRS_pc_Feats = S1_PRS_pc.select(['VH_p50','VV_p50']).clip(boundary);
// Reproject to WGS 84 UTM zone 36s                
var S1_PRS_pc_Feats = S1_PRS_pc_Feats.reproject({crs: 'EPSG:32736',scale: 30}); 
// Check projection information
print('Projection, crs, and crs_transform:', S1_PRS_pc_Feats.projection());    
// Calculate IQR for the VV polarization
var PRS_VV_iqr = S1_PRS_pc_Feats
	.addBands((S1_PRS_pc.select('VV_p75')
	.subtract(S1_PRS_pc.select('VV_p25')))
	.rename('VV_iqr'));
// Calculate IQR for the VH polarization
var PRS_VH_iqr = S1_PRS_pc_Feats
	.addBands((S1_PRS_pc.select('VH_p75')
	.subtract(S1_PRS_pc.select('VH_p25')))
	.rename('VH_iqr'));
// Print the image to the console
print('Post-rainy Season VV IQR', PRS_VV_iqr);
// Print the image to the console
print('Post-rainy Season VV IQR', PRS_VH_iqr);
// Display S1 inter-quartile range imagery
Map.addLayer(PRS_VV_iqr.clip(boundary), {'bands': 'VV_iqr', min: 0,max: 0.1}, 'Sentinel-1 IW VV');
Map.addLayer( PRS_VH_iqr.clip(boundary), {'bands': 'VH_iqr', min: 0,max: 0.1}, 'Sentinel-1 IW VH');
//////////////////
// Load Sentinel-2 spectral reflectance data.
var s2 = ee.ImageCollection('COPERNICUS/S2_SR');
// Create a function to mask clouds using the Sentinel-2 QA band.
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = ee.Number(2).pow(10).int();
  var cirrusBitMask = ee.Number(2).pow(11).int();
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0));
  // Return the masked and scaled data.
  return image.updateMask(mask).divide(10000);
}
// Filter clouds from Sentinel-2 for the post-rainy season.
var composite = s2.filterDate('2021-04-01', '2021-06-30')
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds)
                  .select('B2', 'B3', 'B4','B5','B6','B7','B8','B11', 'B12'); 
// Clip the S2 imagery                  
var S2_composite = composite.median().clip(boundary);
// Reproject to WGS 84 UTM zone 36s                  
var S2_composite = S2_composite.reproject({crs: 'EPSG:32736', scale: 30});
// Check projection information                 
print('Projection, crs, and crs_transform:', S2_composite.projection());
// Display a composite S2 imagery
Map.addLayer(S2_composite.clip(boundary), {bands: ['B11', 'B8', 'B3'], min: 0, max: 0.3}, 'Sentinel-2 Composite');
///////////////
// Load SRTM
var SRTM = ee.Image("USGS/SRTMGL1_003");
// Clip Elevation
var elevation = SRTM.clip(boundary);
// Reproject 'elevation' to WGS 84 UTM zone 36s                
var elevation = elevation.reproject({crs: 'EPSG:32736',scale: 30}); 
// Check projection information
print('Projection, crs, and crs_transform:', elevation.projection()); 
// Derive slope from the SRTM
var slope = ee.Terrain.slope(SRTM).clip(boundary);
// Reproject 'slope' to WGS 84 UTM zone 36s                
var slope = slope.reproject({crs: 'EPSG:32736',scale: 30}); 
// Check projection information
print('Projection, crs, and crs_transform:', slope.projection()); 
//////////////////
// Merge the predictor variables
var mergedCollection = S2_composite
  .addBands(PRS_VV_iqr
  .addBands(PRS_VH_iqr
  .addBands(elevation
  .addBands(slope))));
// Clip to the output image to Harare study area boundary.
var clippedmergedCollection = mergedCollection.clipToCollection(boundary);
print('clippedmergedCollection: ', clippedmergedCollection);
// Bands to include in the classification
var bands = ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'B11', 'B12', 'VV_iqr', 'VH_iqr', 'elevation', 'slope'];
////////////////
// Prepare training dataset
// GEDI's Level 2A Geolocated Elevation and Height Metrics Product (GEDI02_A) is primarily composed of 
// 100 Relative Height (RH) metrics, which collectively describe the waveform collected by GEDI.
// The original GEDI02_A product is a table of points with a spatial resolution (average footprint) of 25 meters. 
// Define a mask
var qualityMask = function(im) {
  return im.updateMask(im.select('quality_flag').eq(1))
      .updateMask(im.select('degrade_flag').eq(0));
};
// Import the "EDI02_A_002_MONTHLY: dataset
var dataset = ee.ImageCollection('LARSE/GEDI/GEDI02_A_002_MONTHLY')
                  .map(qualityMask)
                  .select('rh98').filterBounds(boundary);
// Create a pallete to visualize the dataset
var gediVis = {
  min: 1,
  max: 60,
  palette: 'darkred,red,orange,green,darkgreen',
};
// Set the map center and visualize the dataset
Map.setCenter(28.873257285666114,-18.455390776432033, 12);
Map.addLayer(dataset, gediVis, 'rh98');
// Define projection and scale parameters
var projection = dataset.first().projection().aside(print);
var scale = projection.nominalScale().aside(print);
var mosaic = dataset.mosaic().setDefaultProjection({crs:projection, scale:scale});
// Sample points from the dataset
var points = mosaic.sample({
   region: boundary,
   scale: scale,
   numPixels: 6000, 
   projection: projection,
   geometries: true});
// Check the number of the training points
print(points.size());
print(points.limit(10));
// Display the training points
Map.addLayer(points);
// Add a random column (named random) and specify the seed value for repeatability.
var datawithColumn = points.randomColumn('random', 27);
// Separate 70% for training, 30% for validation
var split = 0.7; 
var trainingData = datawithColumn.filter(ee.Filter.lt('random', split));
// Print the training data
print('training data', trainingData);
var validationData = datawithColumn.filter(ee.Filter.gte('random', split));
// Print the testing (validation) data
print('validation data', validationData);
//////////////////
// Perform regression modeling using RF classifier
// Collect training data
var training = clippedmergedCollection.select(bands).sampleRegions({
  collection: trainingData,
  properties: ['rh98'],
  scale: 30 // Need to change the scale of training data to avoid the 'out of memory' problem
  });
// Train a random forest classifier for regression 
var classifier = ee.Classifier.smileRandomForest(50)
  .setOutputMode('REGRESSION')
  .train({
    features: training, 
    classProperty: "rh98",
    inputProperties: bands
    });
//Run the classification and clip it to the boundary
var regression = clippedmergedCollection.select(bands).classify(classifier, 'predicted').clip(boundary);
// Load and define a continuous palette
var palettes = require('users/gena/packages:palettes');
// Choose and define a palette
var palette = palettes.colorbrewer.YlGn[5];
// Display the regression output.
  // get dictionaries of min & max predicted value
  var regressionMin = (regression.reduceRegion({
    reducer: ee.Reducer.min(),
    scale: 30, 
    crs: 'EPSG:32736',
    geometry: boundary,
    bestEffort: true,
    tileScale: 5
  }));
  var regressionMax = (regression.reduceRegion({
    reducer: ee.Reducer.max(),
    scale: 30, 
    crs: 'EPSG:32736',
    geometry: boundary,
    bestEffort: true,
    tileScale: 5
  }));
// Add to map
var viz = {palette: palette, min: regressionMin.getNumber('predicted').getInfo(), max: regressionMax.getNumber('predicted').getInfo()};
Map.addLayer(regression, viz, 'Regression');
// Create the panel for the legend items.
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create and add the legend title.
var legendTitle = ui.Label({
  value: 'Canopy Height',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
  }
});
legend.add(legendTitle);
// create the legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// create text on top of legend
var panel = ui.Panel({
widgets: [
ui.Label(viz['max'])
],
});
legend.add(panel);
 // create thumbnail from the image
var thumbnail = ui.Thumbnail({
image: legendImage,
params: {bbox:'0,0,10,100', dimensions:'10x200'},
style: {padding: '1px', position: 'bottom-center'}
});
// add the thumbnail to the legend
legend.add(thumbnail);
// create text on top of legend
var panel = ui.Panel({
widgets: [
ui.Label(viz['min'])
],
});
legend.add(panel);
Map.add(legend);
// Zoom to the regression on the map
Map.centerObject(boundary, 12);
// Check model performance
// Get details of classifier
var classifier_details = classifier.explain();
// Explain the classifier with importance values
var variable_importance = ee.Feature(null, ee.Dictionary(classifier_details).get('importance'));
var chart =
  ui.Chart.feature.byProperty(variable_importance)
  .setChartType('ColumnChart')
  .setOptions({
  title: 'Random Forest Variable Importance',
  legend: {position: 'none'},
  hAxis: {title: 'Bands'},
  vAxis: {title: 'Importance'}
});
// Plot a chart
print("Variable importance:", chart);
// Create model assessment statistics
// Get predicted regression points in same location as training data
var predictedTraining = regression.sampleRegions({collection:trainingData, geometries: true});
// Separate the observed (agb_GEDI) and predicted (regression) properties
var sampleTraining = predictedTraining.select(['rh98', 'predicted']);
// Create chart, print it
var chartTraining = ui.Chart.feature.byFeature(sampleTraining, 'rh98', 'predicted')
.setChartType('ScatterChart').setOptions({
title: 'Predicted vs Observed - Training data ',
hAxis: {'title': 'observed'},
vAxis: {'title': 'predicted'},
pointSize: 3,
trendlines: { 0: {showR2: true, visibleInLegend: true} ,
1: {showR2: true, visibleInLegend: true}}});
print(chartTraining);
// Compute Root Mean Squared Error (RMSE)
// Get array of observation and prediction values 
var observationTraining = ee.Array(sampleTraining.aggregate_array('rh98'));
var predictionTraining = ee.Array(sampleTraining.aggregate_array('predicted'));
// Compute residuals
var residualsTraining = observationTraining.subtract(predictionTraining);
// Compute RMSE with equation and print the result
var rmseTraining = residualsTraining.pow(2).reduce('mean', [0]).sqrt();
print('Training RMSE', rmseTraining);
////////////////
//Perform validation
// Get predicted regression points in same location as validation data
var predictedValidation = regression.sampleRegions({collection:validationData, geometries: true});
// Separate the observed (rh98) and predicted (regression) properties
var sampleValidation = predictedValidation.select(['rh98', 'predicted']);
// Create chart and print it
var chartValidation = ui.Chart.feature.byFeature(sampleValidation, 'predicted', 'rh98')
.setChartType('ScatterChart').setOptions({
title: 'Predicted vs Observed - Validation data',
hAxis: {'title': 'predicted'},
vAxis: {'title': 'observed'},
pointSize: 3,
trendlines: { 0: {showR2: true, visibleInLegend: true} ,
1: {showR2: true, visibleInLegend: true}}});
print(chartValidation);
// Compute RMSE
// Get array of observation and prediction values 
var observationValidation = ee.Array(sampleValidation.aggregate_array('rh98'));
var predictionValidation = ee.Array(sampleValidation.aggregate_array('predicted'));
// Compute residuals
var residualsValidation = observationValidation.subtract(predictionValidation);
// Compute RMSE with equation and print it
var rmseValidation = residualsValidation.pow(2).reduce('mean', [0]).sqrt();
print('Validation RMSE', rmseValidation);
// Export the image, specifying scale and region.
Export.image.toDrive({
  image: regression,
  description: 'Mav_CH_GEDI_2021',
  scale: 20,
  crs: 'EPSG:32736', // EPSG:32736 (WGS 84 UTM Zone 36S)
  maxPixels: 6756353855,
  region: boundary
});
//////////////
// Map woodland cover
// Reclassify canopy height (m) to the following classes
//1 = 0 m - 5 m; 2 = 5 m - 8 m; 3 = 8 m - 10 m; 4 = 10 m - 1 5 m; 5 = 15 m - 25 m
var wd_cover = ee.Image(5).rename('class') // open land (crop cover and grassland) between 0 - 5 m
          .where(regression.gt(5).and(regression.lte(8)), 2) // bushland or open woodlands between 5 and 8 m
          .where(regression.gt(8).and(regression.lte(10)), 3) // low density woodlandareas between 8 and 10 m
          .where(regression.gt(10).and(regression.lte(15)), 4) // medium density woodlandareas between 10 and 15 m
          .where(regression.gt(15).and(regression.lte(25)), 5); // high density woodlandareas between 15 and 25 m
// Split Panels for Map 2
var map2 = ui.Map();
// Display the woodland cover map
var vis2 = {min:1, max:5, palette:['FFA07A','ffff00','F0E68C','ADFF2F', '006400']};
map2.addLayer(wd_cover.clip(boundary),vis2,"Woodland Cover");
// Link the two panels
var linker = ui.Map.Linker([ui.root.widgets().get(0), map2]);
// Create the split panels
var splitPanel = ui.SplitPanel({
  firstPanel: linker.get(0),
  secondPanel: linker.get(1),
  orientation: 'horizontal',
  wipe: true,
  style: {stretch: 'both'}
});
// Set the split panels to ui roots
ui.root.widgets().reset([splitPanel]);
// Set the view center
linker.get(0).setCenter(30.953319337661895,-16.494390112760126, 12);
// Set position of panel
var legend2 = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Class',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend2.add(legendTitle);
// Create and style 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette =['FFA07A','ffff00','F0E68C','ADFF2F', '006400'];
// name of the legend
var names = ['Open land/ grassland','Bushland','Low density woodland','Medium density woodland','High density woodland']
// Add color and and names
for (var i = 0; i < 5; i++) {
  legend2.add(makeRow(palette[i], names[i]));
  }  
// Add a legend to the map (alternatively, you can also print the legend to the console)
//Map.add(legend);
// Add legend
map2.add(legend2);
// Add info
var info = ui.Panel({
  style: {
    position: 'bottom-center',
    padding: '8px 15px'
  }
});
var info2 = ui.Label({
  value: 'Split Panels of "Canopy Height" (left) and "Woodland Cover" (right)',
  style: {
    fontSize: '16px',
    margin: '0 0 3px 0',
    padding: '0'
    }
});
info.add(info2);
map2.add(info);
///////
// Export the image, specifying scale and region.
Export.image.toDrive({
  image: wd_cover,
  description: 'Mav_Wd_2021',
  scale: 20,
  crs: 'EPSG:32736', // EPSG:32736 (WGS 84 UTM Zone 36S)
  maxPixels: 6756353855,
 region: boundary
});
/*
Disclaimer
The data and maps in this tool illustrate the scale of potential woodland cover, which has not been ground-checked. Therefore, users should verify all features through fieldwork. The data and maps in this tool are provided "as is," without warranty to their performance.
The user assumes the entire risk associated with the results and performance of these data. This tool should be used strictly for training purposes, not for permitting or other legal purposes.
*/