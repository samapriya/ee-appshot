var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            28.554495544532738,
            -20.159685791901342
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Point([28.554495544532738, -20.159685791901342]),
    boundary = ui.import && ui.import("boundary", "table", {
      "id": "users/kamas72_ML_Zim_Cities/Bulawayo_Crop_Boundary"
    }) || ee.FeatureCollection("users/kamas72_ML_Zim_Cities/Bulawayo_Crop_Boundary"),
    image = ui.import && ui.import("image", "image", {
      "id": "users/kamas72_ML_Zim_Cities/Bulawayo_RS_S2_RF_LC_Jan_Oct2a"
    }) || ee.Image("users/kamas72_ML_Zim_Cities/Bulawayo_RS_S2_RF_LC_Jan_Oct2a");
// Load Sentinel-2 (S2) surface reflectance (SR) data.
var s2 = ee.ImageCollection('COPERNICUS/S2_SR');
// Create a function to mask clouds using the Sentinel-2 QA band.
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = ee.Number(2).pow(10).int();
  var cirrusBitMask = ee.Number(2).pow(11).int();
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0));
  // Return the masked and scaled data.
  return image.updateMask(mask).divide(10000);
}
// Filter S2 SR image collection for the rainy season by date, cloud cover and cloud mask.
var rs_composite = s2.filterDate('2020-01-01', '2020-03-30')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds)
                  .select('B2', 'B3', 'B4','B5','B6','B7','B8','B11', 'B12'); 
// Create S2 SR median composite image for the rainy season                 
var S2_RS = rs_composite.median();
var rainyComposite = S2_RS.clip(boundary);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Adding data to the map
var vizParams1 = {
  min: 0,
  max: 0.4,
  bands: ['B4', 'B3', 'B2']
};
var vizParams2 = {
  min: 0,
  max: 5,
  palette: ['grey', 'red', 'yellow', 'lime', 'green', 'blue']
};
// Visualizing maps using a screen split display
// Add no2pre to the default Map
Map.addLayer(rainyComposite, vizParams1, 'Split Rainy Season S2');
// Make another Map and add no2post to it
var Map2 = ui.Map();
Map2.addLayer(image, vizParams2, 'Split Rainy Season Land Cover');
////////////////////////////////////////////////////////////////////////
var linker = ui.Map.Linker([ui.root.widgets().get(0), Map2]);
// Create a SplitPanel which holds the linked maps side-by-side
// wipe is set to true to let the user swipe the handle back and forth between the two visualizations
var splitPanel = ui.SplitPanel({
  firstPanel: linker.get(0),
  secondPanel: linker.get(1),
  orientation: 'horizontal',
  wipe: true,
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in root
ui.root.widgets().reset([splitPanel]);
// Center the SplitPanel on coordinates (10, 44) and set zoom level to 6
linker.get(0).setCenter(28.5,-20.16, 12);