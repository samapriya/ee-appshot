var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            28.86902414353293,
            -18.458391033819776
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Point([28.86902414353293, -18.458391033819776]),
    image1 = ui.import && ui.import("image1", "image", {
      "id": "users/kamas72_ML_Zim_Cities/Muf_AGB_KNN_S1_S2_2021"
    }) || ee.Image("users/kamas72_ML_Zim_Cities/Muf_AGB_KNN_S1_S2_2021"),
    image2 = ui.import && ui.import("image2", "image", {
      "id": "users/kamas72_ML_Zim_Cities/Muf_AGB_DT_S1_S2_2021"
    }) || ee.Image("users/kamas72_ML_Zim_Cities/Muf_AGB_DT_S1_S2_2021"),
    image3 = ui.import && ui.import("image3", "image", {
      "id": "users/kamas72_ML_Zim_Cities/Muf_AGB_RF_S1_S2_2021"
    }) || ee.Image("users/kamas72_ML_Zim_Cities/Muf_AGB_RF_S1_S2_2021"),
    image4 = ui.import && ui.import("image4", "image", {
      "id": "users/kamas72_ML_Zim_Cities/Muf_AGB_SVM_S1_S2_2021"
    }) || ee.Image("users/kamas72_ML_Zim_Cities/Muf_AGB_SVM_S1_S2_2021");
/// Map and estimate forest above-ground biomass (AGB)
// Map 1: KNN Model AGB
var map1 = ui.Map();
map1.add(ui.Label('KNN Model AGB',{position: 'bottom-center'}));
var vizParams1 = {min: 0, max: 100, palette:  ['LightGray','Cornsilk','NavajoWhite', 'GreenYellow', 'LawnGreen','Lime', 'ForestGreen', 'Green','DarkGreen']};
map1.addLayer(image1, vizParams1 , 'AGB');
map1.setControlVisibility(true);
// Add map legend
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
var legend1 = ui.Label({
  value: 'AGB (Mg/ ha)',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
legend.add(legend1);
// Creates the content of the legend
var content = function(colour, label) {
      // Create the coloured boxes
      var box = ui.Label({
        style: {
          backgroundColor:  colour,
          // Set box height and width
          padding: '9px',
          margin: '0 0 4px 0'
        }
      });
      // Create the labels
      var labels = ui.Label({
        value: label,
        style: {margin: '0 0 4px 6px'}
      });
      return ui.Panel({
        widgets: [box, labels],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Set legend colours
var classColour = ['LightGray','Cornsilk','NavajoWhite', 'GreenYellow', 'LawnGreen','Lime', 'ForestGreen', 'Green','DarkGreen'];
// Set legend labels
var labelName = ['1.7','11.7','21.7','31.8', '41.8','51.8','61.8','71.1','78.8'];
// Combine legend colour and labels
for (var i = 0; i < 9; i++) {
  legend.add(content(classColour[i], labelName[i]));
  }  
// Add legend
map1.add(legend);
// Add info
var info = ui.Panel({
  style: {
    position: 'bottom-center',
    padding: '8px 15px'
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Map 2: DT Model AGB
var map2 = ui.Map();
map2.add(ui.Label('DT Model AGB',{position: 'bottom-center'}));
var vizParams2 = {min: 0, max: 100, palette:  ['LightGray','Cornsilk','NavajoWhite', 'GreenYellow', 'LawnGreen','Lime', 'ForestGreen', 'Green','DarkGreen']};
map2.addLayer(image2, vizParams2 , 'AGB');
map2.setControlVisibility(true);
// Add map legend
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
var legend2 = ui.Label({
  value: 'AGB (Mg/ ha)',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
legend.add(legend2);
// Creates the content of the legend
var content = function(colour, label) {
      // Create the coloured boxes
      var box = ui.Label({
        style: {
          backgroundColor:  colour,
          // Set box height and width
          padding: '9px',
          margin: '0 0 4px 0'
        }
      });
      // Create the labels
      var labels = ui.Label({
        value: label,
        style: {margin: '0 0 4px 6px'}
      });
      return ui.Panel({
        widgets: [box, labels],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Set legend colours
var classColour = ['LightGray','Cornsilk','NavajoWhite', 'GreenYellow', 'LawnGreen','Lime', 'ForestGreen', 'Green','DarkGreen'];
// Set legend labels
var labelName = ['10.6', '17.6', '24.8', '31.8', '38.9', '46.0', '53.0', '59.6', '65.0', '78.8'];
// Combine legend colour and labels
for (var i = 0; i < 9; i++) {
  legend.add(content(classColour[i], labelName[i]));
  }  
// Add legend
map2.add(legend);
// Add info
var info = ui.Panel({
  style: {
    position: 'bottom-center',
    padding: '8px 15px'
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Map 3: RF Model AGB
var map3 = ui.Map();
map3.add(ui.Label('RF Model AGB',{position: 'bottom-center'}));
var vizParams2 = {min: 0, max: 100, palette:  ['LightGray','Cornsilk','NavajoWhite', 'GreenYellow', 'LawnGreen','Lime', 'ForestGreen', 'Green','DarkGreen']};
map3.addLayer(image3, vizParams2 , 'AGB');
map3.setControlVisibility(true);
// Add map legend
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
var legend2 = ui.Label({
  value: 'AGB (Mg/ ha)',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
legend.add(legend2);
// Creates the content of the legend
var content = function(colour, label) {
      // Create the coloured boxes
      var box = ui.Label({
        style: {
          backgroundColor:  colour,
          // Set box height and width
          padding: '9px',
          margin: '0 0 4px 0'
        }
      });
      // Create the labels
      var labels = ui.Label({
        value: label,
        style: {margin: '0 0 4px 6px'}
      });
      return ui.Panel({
        widgets: [box, labels],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Set legend colours
var classColour = ['LightGray','Cornsilk','NavajoWhite', 'GreenYellow', 'LawnGreen','Lime', 'ForestGreen', 'Green','DarkGreen'];
// Set legend labels
var labelName = ['3.4', '13.0', '22.6', '32.2', '41.8', '51.4', '61.0', '69.9', '77.3'];
// Combine legend colour and labels
for (var i = 0; i < 9; i++) {
  legend.add(content(classColour[i], labelName[i]));
  }  
// Add legend
map3.add(legend);
// Add info
var info = ui.Panel({
  style: {
    position: 'bottom-center',
    padding: '8px 15px'
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Map 4: SVM Model AGB
var map4 = ui.Map();
map4.add(ui.Label('SVM Model AGB',{position: 'bottom-center'}));
var vizParams2 = {min: 0, max: 100, palette:  ['LightGray','Cornsilk','NavajoWhite', 'GreenYellow', 'LawnGreen','Lime', 'ForestGreen', 'Green','DarkGreen']};
map4.addLayer(image4, vizParams2 , 'AGB');
map4.setControlVisibility(true);
// Add map legend
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
var legend2 = ui.Label({
  value: 'AGB (Mg/ ha)',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
legend.add(legend2);
// Creates the content of the legend
var content = function(colour, label) {
      // Create the coloured boxes
      var box = ui.Label({
        style: {
          backgroundColor:  colour,
          // Set box height and width
          padding: '9px',
          margin: '0 0 4px 0'
        }
      });
      // Create the labels
      var labels = ui.Label({
        value: label,
        style: {margin: '0 0 4px 6px'}
      });
      return ui.Panel({
        widgets: [box, labels],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Set legend colours
var classColour = ['LightGray','Cornsilk','NavajoWhite', 'GreenYellow', 'LawnGreen','Lime', 'ForestGreen', 'Green','DarkGreen'];
// Set legend labels
var labelName = ['1.1', '10.4', '19.7', '29.1', '38.4', '47.8', '57.1', '65.7', '72.9'];
// Combine legend colour and labels
for (var i = 0; i < 9; i++) {
  legend.add(content(classColour[i], labelName[i]));
  }  
// Add legend
map4.add(legend);
// Add info
var info = ui.Panel({
  style: {
    position: 'bottom-center',
    padding: '8px 15px'
  }
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Link images
var linker = ui.Map.Linker([map1, map2, map3, map4]);
// Enable zooming 
map1.setControlVisibility({zoomControl: true});
// Show scale 
map3.setControlVisibility({scaleControl: true});
// Create a grid of maps.
var mapPanel = ui.Panel(
    [
      ui.Panel([map1, map2], null, {stretch: 'both'}),
      ui.Panel([map3, map4], null, {stretch: 'both'})
    ],
    ui.Panel.Layout.Flow('horizontal'), {stretch: 'both'});
// map center
map1.setCenter(28.86902414353293,-18.458391033819776, 12);
// Map title.
var title = ui.Label('Estimated AGB 2021', {
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight: 'bold',
  fontSize: '20px'
});
// Add images and title to the ui.root.
ui.root.widgets().reset([title, mapPanel]);
ui.root.setLayout(ui.Panel.Layout.Flow('vertical'));