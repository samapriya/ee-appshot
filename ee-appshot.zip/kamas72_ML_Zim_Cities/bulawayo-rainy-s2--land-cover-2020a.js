var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            28.554495544532738,
            -20.159685791901342
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Point([28.554495544532738, -20.159685791901342]),
    boundary = ui.import && ui.import("boundary", "table", {
      "id": "users/kamas72_ML_Zim_Cities/Bulawayo_Crop_Boundary"
    }) || ee.FeatureCollection("users/kamas72_ML_Zim_Cities/Bulawayo_Crop_Boundary"),
    image = ui.import && ui.import("image", "image", {
      "id": "users/kamas72_ML_Zim_Cities/Bulawayo_RS_S2_RF_LC_Jan_Oct2a"
    }) || ee.Image("users/kamas72_ML_Zim_Cities/Bulawayo_RS_S2_RF_LC_Jan_Oct2a");
// Map 1: Rainy Season S2 Imagery Natural Color
var map1 = ui.Map();
map1.add(ui.Label('Rainy Season S2 Natural Color',{position: 'bottom-center'}));
// Load Sentinel-2 (S2) surface reflectance (SR) data.
var s2 = ee.ImageCollection('COPERNICUS/S2_SR');
// Create a function to mask clouds using the Sentinel-2 QA band.
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = ee.Number(2).pow(10).int();
  var cirrusBitMask = ee.Number(2).pow(11).int();
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0));
  // Return the masked and scaled data.
  return image.updateMask(mask).divide(10000);
}
// Filter S2 SR image collection for the rainy season by date, cloud cover and cloud mask.
var rs_composite = s2.filterDate('2020-01-01', '2020-03-30')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds)
                  .select('B2', 'B3', 'B4','B5','B6','B7','B8','B11', 'B12'); 
// Create S2 SR median composite image for the rainy season                 
var S2_RS = rs_composite.median();
var rainyComposite = S2_RS.clip(boundary);
// Shared visualization parameters for the images.
// Adding data to the map
var vizParams1 = {min: 0, max: 0.4, bands: ['B4', 'B3', 'B2']};
map1.addLayer(rainyComposite, vizParams1, 'Natural Color (B4/B3/B2)');
map1.setControlVisibility(true);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Map 2: Rainy Season S2 Color Infrared
var map2= ui.Map();
map2.add(ui.Label('Rainy Season S2 Color Infrared',{position: 'bottom-center'}));
// Shared visualization parameters for the images.
// Adding data to the map
var vizParams2 = {min: 0, max: 0.4, bands: ['B8', 'B4', 'B3']};
map2.addLayer(rainyComposite, vizParams2, 'Color Infrared (B8/B4/B3)');
map2.setControlVisibility(true);
//////////////////////////////////////////////////////////////////////////////////////////////////////////
// Map 3: Rainy Season S2 Imagery (Vegetation: B12/B11/B4)
var map3= ui.Map();
map3.add(ui.Label('Rainy Season S2 (Vegetation:B12/B11/B4)',{position: 'bottom-center'}));
// Shared visualization parameters for the images.
var vizParams3 = {min: 0, max: 0.4, bands: ['B12', 'B11', 'B4']};
map3.addLayer(rainyComposite, vizParams3, 'Vegetation (B12/B11/B4)');
map3.setControlVisibility(true);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Map 4: Rainy Season Land Cover 2020
var map4 = ui.Map();
map4.add(ui.Label('Rainy Season Land Cover 2020',{position: 'bottom-center'}));
var vizParams2 = {min: 0, max: 5, palette: ['grey', 'red', 'yellow', 'lime', 'green', 'blue']};
map4.addLayer(image, vizParams2 , 'Land Cover');
map4.setControlVisibility(true);
// Map 4: Rainy Season Land Cover 2020
var map4 = ui.Map();
map4.add(ui.Label('Rainy Season Land Cover 2020',{position: 'bottom-center'}));
var vizParams2 = {min: 0, max: 5, palette: ['grey', 'red', 'yellow', 'lime', 'green', 'blue']};
map4.addLayer(image, vizParams2 , 'Land Cover');
map4.setControlVisibility(true);
// Add map legend
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
var legend2 = ui.Label({
  value: 'Land Cover',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
legend.add(legend2);
// Creates the content of the legend
var content = function(colour, label) {
      // Create the coloured boxes
      var box = ui.Label({
        style: {
          backgroundColor:  colour,
          // Set box height and width
          padding: '9px',
          margin: '0 0 4px 0'
        }
      });
      // Create the labels
      var labels = ui.Label({
        value: label,
        style: {margin: '0 0 4px 6px'}
      });
      return ui.Panel({
        widgets: [box, labels],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Set legend colours
var classColour = ['grey','red','yellow','lime','green','blue'];
// Set legend labels
var labelName = ['Bare areas','Built-up','Cropland', 'Grass/ open areas','Woodlands','Water'];
// Combine legend colour and labels
for (var i = 0; i < 6; i++) {
  legend.add(content(classColour[i], labelName[i]));
  }  
// Add legend
map4.add(legend);
// Add info
var info = ui.Panel({
  style: {
    position: 'bottom-center',
    padding: '8px 15px'
  }
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Link images
var linker = ui.Map.Linker([map1, map2, map3, map4]);
// Enable zooming 
map1.setControlVisibility({zoomControl: true});
// Show scale 
map3.setControlVisibility({scaleControl: true});
// Create a grid of maps.
var mapPanel = ui.Panel(
    [
      ui.Panel([map1, map2], null, {stretch: 'both'}),
      ui.Panel([map3, map4], null, {stretch: 'both'})
    ],
    ui.Panel.Layout.Flow('horizontal'), {stretch: 'both'});
// map center
map1.setCenter(28.5,-20.16, 12);
// Map title.
var title = ui.Label('Rainy Season S2 Imagery and Land Cover 2020', {
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight: 'bold',
  fontSize: '20px'
});
// Add images and title to the ui.root.
ui.root.widgets().reset([title, mapPanel]);
ui.root.setLayout(ui.Panel.Layout.Flow('vertical'));