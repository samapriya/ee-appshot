var aoi = ui.import && ui.import("aoi", "table", {
      "id": "users/kamas72_ML_Zim_Cities/Mufungabusi_FractionalCover_Boundary"
    }) || ee.FeatureCollection("users/kamas72_ML_Zim_Cities/Mufungabusi_FractionalCover_Boundary");
/**
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
// Map the function over one year of data and take the median.
// Load Sentinel-2 TOA reflectance data.
var S2a = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2016-04-01', '2016-05-30')
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10))
                  .filterBounds(aoi)
                  .map(maskS2clouds)
                  .select('B2', 'B3', 'B4','B5','B6','B7','B8','B11', 'B12');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Load Sentinel-2 surface reflectance data.
var s2 = ee.ImageCollection('COPERNICUS/S2_SR');
// Function to mask clouds using the Sentinel-2 QA band.
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = ee.Number(2).pow(10).int();
  var cirrusBitMask = ee.Number(2).pow(11).int();
  // Both flags should be set to zero.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0));
  // Return the masked and scaled data.
  return image.updateMask(mask).divide(10000);
}
// Map the cloud masking function over one year of data
var S2b = s2.filterDate('2021-04-01', '2021-05-30')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10))
                  .filterBounds(aoi)
                  .map(maskS2clouds)
                  .select('B2', 'B3', 'B4','B5','B6','B7','B8','B11', 'B12');
//
//var s2Col = ee.ImageCollection('COPERNICUS/S2');
var visParams = {
  bands: ['B11', 'B8', 'B3'],
  min: 0,
  max: 0.6
};
var t1 = '2016-04-01' - '2016-05-30';
var t2 = '2021-04-01' - '2021-05-30';
var mapT1 = ui.Map();
var mapT2 = ui.Map();
var linkedMaps = ui.Map.Linker([mapT1, mapT2]);
var splitMap = ui.SplitPanel(
  linkedMaps.get(0), linkedMaps.get(1), 'horizontal', true);
var t1Date = ui.Label(2016);
var t2Date = ui.Label(2021);
var infoTitle = ui.Label(
  'Deforestation in Mafungautsi Forest Reserve (2016 - 2021)');
var infoLabel = ui.Label(
 'This app shows deforestation in Mafungautsi Forest Reserve, ' +
  'in Midlands Province, Zimbabwe. ' +
  'Mafungautsi Forest Reserve is the third-largest indigenous forest reserve in Zimbabwe. ' +
  'The deforestation extent can be seen by moving the app slider and observing the area ' +
  'in the northern part of the imagery that turns from green to brown. The image map shows ' +
  'Sentinel-2 bands 11,8,3 (RGB). Note that band 11 = SWIR1, band 8 = NIR, and band 3 = Green.');
var infoPanel = ui.Panel([infoTitle, infoLabel]);
mapT1.add(t1Date);
mapT2.add(t2Date);
mapT1.add(infoPanel);
mapT1.setCenter(28.859889325646737,-18.4590085965602, 11);
t1Date.style().set(
  {fontSize: '36px', fontWeight: 'bold', position: 'bottom-left'});
t2Date.style().set(
  {fontSize: '36px', fontWeight: 'bold', position: 'bottom-right'});
infoTitle.style().set(
  {fontSize: '16px', fontWeight: 'bold'});
infoPanel.style().set(
  {width: '320px', position: 'top-left'});
function makeVisComp(imgCol, aoi, startDate, visParams) {
  var endDate = ee.Date(ee.Date(startDate).advance(1, 'day'));
  return imgCol.filterBounds(aoi)
                   .mosaic()
                   .visualize(visParams);
}
var imgT1 = makeVisComp(S2a, aoi, t1, visParams);
var imgT2 = makeVisComp(S2b, aoi, t2, visParams);
mapT1.addLayer(imgT1, null, t1);
mapT2.addLayer(imgT2, null, t2);
ui.root.clear();
ui.root.add(splitMap);