var visParam = ui.import && ui.import("visParam", "imageVisParam", {
      "params": {
        "min": 0,
        "max": 100,
        "palette": "c10000,d742f4,001556,b7d2f7"
      }
    }) || {"min":0,"max":100,"palette":"c10000,d742f4,001556,b7d2f7"},
    jrcDataset = ui.import && ui.import("jrcDataset", "imageCollection", {
      "id": "JRC/GSW1_3/MonthlyHistory"
    }) || ee.ImageCollection("JRC/GSW1_3/MonthlyHistory");
// This script is modified from https://thegeoict.com/blog/2017/11/28/jrc-historical-flood-visualization-and-download-with-google-earth-engine/
// The purpose of the script is to map flood frequency using the Joint Research Centre (JRC) Monthly Water History dataset (RC/GSW1_3/MonthlyHistory)
// 'Source: EC JRC/Google'
// This dataset contains maps of the location and temporal distribution of surface water from 1984 to 2020 and provides statistics on the extent and change of those water surfaces.
// For more information see the associated journal article: Pekel et al. High-resolution mapping of global surface water and its long-term changes. Nature 540, 418–422 (2016). https://doi.org/10.1038/nature20584
// Define layer for the selected countries in Southern Africa
var countriesLayer = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017');
ui.root.clear();
var map = ui.Map();
ui.root.add(map);
// Define map center (In this case in Zimbabwe)
map.setCenter(30.16050530265366,-16.38563388836336, 6);
// Define the variables for the application
var startDate = '2000-01-01';
var endDate = '2020-12-31';
var country = {
  Madagascar:['Madagascar'],
  Malawi:['Malawi'],
  Mozambique:['Mozambique'],
  Zambia:['Zambia'],
  Zimbabwe:['Zimbabwe']
};
// filter the countries layer to include only the _country
var geometry = countriesLayer.filter(ee.Filter.inList('country_na', ['Madagascar', 'Malawi','Mozambique', 'Zambia', 'Zimbabwe'])).geometry();
// Prepare the core functions
var getFilteredData = function (geometry, startDate, endDate) {
  return jrcDataset.filterBounds(geometry).filterDate(startDate, endDate);
};
var getValidData = function (imgColl) {
  return imgColl.map(function (img) {
    return img.gt(0).set('system:time_start', img.get('system:time_start'));
  });
};
var getWaterData = function (imgColl) {
  return imgColl.map(function (img) {
    return img.select('water').eq(2).set('system:time_start', img.get('system:time_start'));
  });
};
var floodFrequencyCalculator = function () {
  var filteredData = getFilteredData(geometry, startDate, endDate);
  var validData = getValidData(filteredData);
  var waterData = getWaterData(filteredData);
  var totalValidData = validData.sum().toFloat();
  var totalWaterData = waterData.sum().toFloat();
  var totalWaterPercent = totalWaterData.divide(totalValidData).multiply(100);
  var waterMask = totalWaterPercent.gt(1);
  var waterPercentData = totalWaterPercent.updateMask(waterMask).clip(geometry);
  return waterPercentData;
};
// Define the user interface (UI) components
// Set the title UI
var titlePanel = ui.Panel({style: {position: 'top-center', width: '550px',stretch: 'horizontal', height: '30px',margin:'-10px'}});
var title = ui.Label({
  value: 'Flood Frequency Mapping using JRC Dataset (2000 - 2020)',
  style: {height: '20px', width: '520px',fontSize: '18px', fontWeight:'bold',textAlign: 'center', padding:'10px', margin: '-5px'},
});
titlePanel.add(title);
map.add(titlePanel);
// Define the date selector using textbox for now until Calendar selector is included
var startDateWidget = ui.Textbox({
  value: startDate,
  style: {width: '100px'},
});
var endDateWidget = ui.Textbox({
  value: endDate,
  style: {width: '100px'},
});
// Define the country selector
var countrySelector = ui.Select({
  items: Object.keys(country),
  onChange: function(key) {
    geometry = countriesLayer.filter(ee.Filter.inList('country_na', [key])).geometry();
  }
});
countrySelector.setPlaceholder('Choose a country...');
// Add the submit button
var submitButton = ui.Button({
  label: 'Display Map',
  onClick: function() {
    startDate = startDateWidget.getValue();
    endDate = endDateWidget.getValue();
    var layer = floodFrequencyCalculator();
    map.centerObject(geometry);
    return map.addLayer(layer, visParam, 'Flood Frequency Map');
  }
});
var widgetPanel = ui.Panel({style: {width: '250px', position: 'bottom-right'}});
widgetPanel.add(countrySelector);
widgetPanel.add(ui.Label('Start Date (YYYY-MM-DD):')).add(startDateWidget);
widgetPanel.add(ui.Label('End Date (YYYY-MM-DD):')).add(endDateWidget);
widgetPanel.add(submitButton);
map.add(widgetPanel);