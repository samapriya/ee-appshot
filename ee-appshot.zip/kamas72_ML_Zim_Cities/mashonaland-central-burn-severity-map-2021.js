var geometry = ui.import && ui.import("geometry", "table", {
      "id": "users/kamas72_ML_Zim_Cities/Mashonaland_Central_province"
    }) || ee.FeatureCollection("users/kamas72_ML_Zim_Cities/Mashonaland_Central_province");
// This script is for computing burn severity is modified from Office for Outer Space Affairs UN-SPIDER Knowledge Portal. Check the website below:
// https://www.un-spider.org/advisory-support/recommended-practices/recommended-practice-burn-severity/burn-severity-earth-engine
// The script shows pre-fire S2 imagery, post-fire S2 imagery, normalized burn ratio, and the Fire Information for Resource Management System (FIRMS) 
// The difference between before and after wildfire S2 imagery is used to calculate (dNBR) burn severity. 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Map 1: Display pre-fire S2 Imagery (Short-Wave Infrared Color)
var Map1 = ui.Map();
Map1.add(ui.Label('Pre-fire "S2" Short-Wave Infrared Color',{position: 'bottom-center'}));
// Load Sentinel-2 (S2) surface reflectance (SR) data.
var s2 = ee.ImageCollection('COPERNICUS/S2_SR');
// Create a function to mask clouds using the Sentinel-2 QA band.
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = ee.Number(2).pow(10).int();
  var cirrusBitMask = ee.Number(2).pow(11).int();
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0));
  // Return the masked and scaled data.
  return image.updateMask(mask).divide(10000);
}
// Filter S2 SR image collection for the pre-fire season by date, cloud cover and cloud mask.
var pre_fireS2 = s2.filterDate('2021-04-01', '2021-05-30')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds)
                  .select('B2', 'B3', 'B4','B5','B6','B7','B8','B11', 'B12'); 
// Create S2 SR median composite image for the pre-fire season                 
var pre_fire_medS2 = pre_fireS2.median();
var pre_fire_S2_comp = pre_fire_medS2.clip(geometry);
// Shared visualization parameters for the images.
// Add data to the map
var vizParams1 = {min: 0, max: 0.4, bands: ['B11', 'B8', 'B4']};
Map1.addLayer(pre_fire_S2_comp, vizParams1, 'Short-Wave Infrared Color (B11/B8/B4)');
Map1.setControlVisibility(true);
// Calculate NBR for the pre-fire images
// Calculate NBR = (NIR-SWIR2) / (NIR+SWIR2)
var preNBR = pre_fire_S2_comp.normalizedDifference(['B8', 'B12']);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Map 2: Display post-fire S2 Imagery (Short-Wave Infrared Color)
var Map2 = ui.Map();
Map2.add(ui.Label('Post-fire "S2" Short-Wave Infrared Color',{position: 'bottom-center'}));
// Filter S2 SR image collection for the post-fire season by date, cloud cover and cloud mask.
var post_fireS2 = s2.filterDate('2021-09-01', '2021-10-30')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds)
                  .select('B2', 'B3', 'B4','B5','B6','B7','B8','B11', 'B12'); 
// Create S2 SR median composite image for the post-fire season                 
var post_fire_medS2 = post_fireS2.median();
var post_fire_S2_comp = post_fire_medS2.clip(geometry);
// Calculate NBR = (NIR-SWIR2) / (NIR+SWIR2)
  var postNBR = post_fire_S2_comp.normalizedDifference(['B8', 'B12']);
// Add data to the map
var vizParams1 = {min: 0, max: 0.4, bands: ['B11', 'B8', 'B4']};
Map2.addLayer(post_fire_S2_comp, vizParams1, 'Short-Wave Infrared Color (B11/B8/B4)');
Map2.setControlVisibility(true);
//////////////////////////////////////////////////////////////////////////////////////////////////////////
// Extract fire incidence in 2021 using FIRMS data
var dataset = ee.ImageCollection('FIRMS').filter(
    ee.Filter.date('2021-07-01', '2021-10-30'));
var fires = dataset.select('T21');
// Calculate the neam fire incidence
var fires_mean = fires.mean();
// Clip the fire data to the boundary
var fires_FIRMS = fires_mean.clip(geometry);
// Map 3: FIRMS Fire Incidence 2021
var Map3 = ui.Map();
Map3.add(ui.Label('FIRMS Fire Incidence 2021',{position: 'bottom-center'}));
var vizParams3 = {min: 325.0,  max: 400.0,  palette: ['red', 'orange', 'yellow']};
Map3.addLayer(fires_FIRMS, vizParams3 , 'FIRMS Fire Incidence');
Map3.setControlVisibility(true);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Compute burn severity
// Map 4:  Display burn severity
var Map4 = ui.Map();
Map4.add(ui.Label('Burnt Area Severity 2021',{position: 'bottom-center'}));
//var vizParams4 = {min: 1, max: 8, palette: ['7a8737', 'acbe4d', '0ae042', 'fff70b', 'ffaf38', 'ff641b', 'a41fd6', 'ffffff']};
// The result is called delta NBR or dNBR
var dNBR_unscaled = preNBR.subtract(postNBR);
// Scale product to USGS standards
var dNBR = dNBR_unscaled.multiply(1000);
// Add the difference image to the console on the right
print("Difference Normalized Burn Ratio: ", dNBR);
//Create the burn ratio product (classification)
// Define an SLD style of discrete intervals to apply to the image.
var sld_intervals =
  '<RasterSymbolizer>' +
    '<ColorMap type="intervals" extended="false" >' +
      '<ColorMapEntry color="#ffffff" quantity="-500" label="-500"/>' +
      '<ColorMapEntry color="#7a8737" quantity="-250" label="-250" />' +
      '<ColorMapEntry color="#acbe4d" quantity="-100" label="-100" />' +
      '<ColorMapEntry color="#0ae042" quantity="100" label="100" />' +
      '<ColorMapEntry color="#fff70b" quantity="270" label="270" />' +
      '<ColorMapEntry color="#ffaf38" quantity="440" label="440" />' +
      '<ColorMapEntry color="#ff641b" quantity="660" label="660" />' +
      '<ColorMapEntry color="#a41fd6" quantity="2000" label="2000" />' +
    '</ColorMap>' +
  '</RasterSymbolizer>';
// Add the image to the map using both the color ramp and interval schemes.
Map4.addLayer(dNBR.sldStyle(sld_intervals), {}, 'dNBR classified');
//map4.addLayer(dNBR, vizParams4 , 'Burned Area Severity');
Map4.setControlVisibility(true);
// Seperate result into 8 burn severity classes
var thresholds = ee.Image([-1000, -251, -101, 99, 269, 439, 659, 2000]);
var classified = dNBR.lt(thresholds).reduce('sum').toInt();
// Add the legend
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }});
// Create legend title
var legendTitle = ui.Label({
  value: 'dNBR Classes',
  style: {fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }});
// Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }});
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      })};
//  Palette with the colors
var palette =['7a8737', 'acbe4d', '0ae042', 'fff70b', 'ffaf38', 'ff641b', 'a41fd6', 'ffffff'];
// name of the legend
var names = ['Enhanced Regrowth, High','Enhanced Regrowth, Low','Unburned', 'Low Severity',
'Moderate-low Severity', 'Moderate-high Severity', 'High Severity', 'NA'];
// Add color and and names
for (var i = 0; i < 8; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)
Map4.add(legend);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Link the maps
var linker = ui.Map.Linker([Map1, Map2, Map3, Map4]);
// Enable zooming 
Map1.setControlVisibility({zoomControl: true});
// Show scale 
Map3.setControlVisibility({scaleControl: true});
// Create a grid of maps.
var mapPanel = ui.Panel(
    [
      ui.Panel([Map1, Map2], null, {stretch: 'both'}),
      ui.Panel([Map3, Map4], null, {stretch: 'both'})
    ],
    ui.Panel.Layout.Flow('horizontal'), {stretch: 'both'});
// map center
Map1.setCenter(31.227621298286476,-16.879639110370608, 8);
// Map title.
var title = ui.Label('Mashonaland Central (Zimbabwe) Burn Severity Map 2021', {
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight: 'bold',
  fontSize: '20px'
});
// Add images and title to the ui.root.
ui.root.widgets().reset([title, mapPanel]);
ui.root.setLayout(ui.Panel.Layout.Flow('vertical'));