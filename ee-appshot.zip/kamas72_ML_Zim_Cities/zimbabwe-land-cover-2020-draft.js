var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            30.905569763282738,
            -19.01078202236505
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Point([30.905569763282738, -19.01078202236505]),
    image = ui.import && ui.import("image", "image", {
      "id": "users/kamas72_ML_Zim_Cities/S1_S2_LC_Mar_Apr20d"
    }) || ee.Image("users/kamas72_ML_Zim_Cities/S1_S2_LC_Mar_Apr20d");
// Import administrative boundary
var worldcountries = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017');
var filterCountry = ee.Filter.eq('country_na', 'Zimbabwe');
var country = worldcountries.filter(filterCountry);
// Zimbabwe land cover 2020
var map1 = ui.Map();
map1.add(ui.Label('Zimbabwe Land Cover 2020',{position: 'bottom-center'}));
var vizParams2 = {min: 0, max: 10, palette: ['#ffffff', '#556b2f', '#20b2aa', '#008000', '#90ee90', '#bdb76b', '#deb887', '#ffffe0', '#d3d3d3', '#e31a1c', '#0000ff']};
map1.addLayer(image.clip(country), vizParams2 , 'Land Cover');
map1.setControlVisibility(true);
// Add map legend
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
var legend2 = ui.Label({
  value: 'Land Cover',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
legend.add(legend2);
// Creates the content of the legend
var content = function(colour, label) {
      // Create the coloured boxes
      var box = ui.Label({
        style: {
          backgroundColor:  colour,
          // Set box height and width
          padding: '9px',
          margin: '0 0 4px 0'
        }
      });
      // Create the labels
      var labels = ui.Label({
        value: label,
        style: {margin: '0 0 4px 6px'}
      });
      return ui.Panel({
        widgets: [box, labels],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Set legend colours
var classColour = ['#ffffff', '#556b2f', '#20b2aa', '#008000', '#90ee90', '#bdb76b', '#deb887', '#ffffe0', '#d3d3d3', '#e31a1c', '#0000ff'];
// Set legend labels
var labelName = ['Riverbed','Natural Moist Forest','Forest Plantation', 'Woodland','Bushland','Wooded Grassland','Grassland','Cultivation', 'Rock Outcrop & Mine Dump','Settlements','Water'];
// Combine legend colour and labels
for (var i = 0; i < 11; i++) {
  legend.add(content(classColour[i], labelName[i]));
  }  
// Add legend
map1.add(legend);
// Add info
var info = ui.Panel({
  style: {
    position: 'bottom-center',
    padding: '8px 15px'
  }
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Link images
var linker = ui.Map.Linker([map1]);
// Enable zooming 
map1.setControlVisibility({zoomControl: true});
// Show scale 
map1.setControlVisibility({scaleControl: true});
// Create a grid of maps.
var mapPanel = ui.Panel(
    [
      ui.Panel([map1], null, {stretch: 'both'})
    ],
    ui.Panel.Layout.Flow('horizontal'), {stretch: 'both'});
// map center
map1.setCenter(30.905569763282738,-19.01078202236505, 7);
// Map title.
var title = ui.Label('Zimbabwe Land Cover 2020 (Draft)', {
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight: 'bold',
  fontSize: '20px'
});
// Add images and title to the ui.root.
ui.root.widgets().reset([title, mapPanel]);
ui.root.setLayout(ui.Panel.Layout.Flow('vertical'));