var landsat8Sr = ui.import && ui.import("landsat8Sr", "imageCollection", {
      "id": "LANDSAT/LC08/C02/T1_L2"
    }) || ee.ImageCollection("LANDSAT/LC08/C02/T1_L2"),
    boundary = ui.import && ui.import("boundary", "table", {
      "id": "users/kamas72_ML_Zim_Cities/Manyame_CA_Boundary"
    }) || ee.FeatureCollection("users/kamas72_ML_Zim_Cities/Manyame_CA_Boundary");
// This script computes normalized difference suspended sediment index (NDSSI) time series for Manyame catchment area in Zimbabwe
// We will use Landsat time-series data to calculate NDSSI, developed by Hossain et al. 2010.
// NDSSI = (blue-NIR)/(blue+NIR)
//////
// Display catchment boundary
Map.addLayer(boundary, {}, 'Boundary');
// Import the global surface water layer that we will use to mask water areas
var gsw = ee.Image("JRC/GSW1_3/GlobalSurfaceWater");
// Select the 'max_extent' band
var water = gsw.select('max_extent').clip(boundary); // max_extent band has values 0 or 1
// Keep the water areas only (1)
var masked = water.updateMask(water);
// finally masking out 0 values and retain only water areas (1)
var masked = water.selfMask();
Map.addLayer(masked, {}, 'Water');
//////
// Function to cloud mask from the pixel_qa band of Landsat 8 SR data.
var maskL8sr = function(image) {
  // Bit 0 - Fill; Bit 1 - Dilated Cloud; Bit 2 - Cirrus; Bit 3 - Cloud; Bit 4 - Cloud Shadow
  var qaMask = image.select('QA_PIXEL').bitwiseAnd(parseInt('11111', 2)).eq(0);
  var saturationMask = image.select('QA_RADSAT').eq(0);
  // Apply the scaling factors to the appropriate bands.
  var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
  // Replace the original bands with the scaled ones and apply the masks.
  return image.addBands(opticalBands, null, true)
    .addBands(thermalBands, null, true)
    .updateMask(qaMask)
    .updateMask(saturationMask)
    .updateMask(masked);
};
// Function to to calculate NDSSI.
var addVariables = function(image) {
  // Compute time in fractional years since the epoch.
  var date = image.date();
  var years = date.difference(ee.Date('1970-01-01'), 'year');
  // Return the image with the added bands.
  return image
  // Add an NDSSI band.
  .addBands(image.normalizedDifference(['SR_B2', 'SR_B5']).rename('NDSSI'))
  // Add a time band.
  .addBands(ee.Image(years).rename('t')).float()
  // Add a constant band.
  .addBands(ee.Image.constant(1));
};
// Remove clouds, add variables and filter to the area of interest.
var filteredLandsat = landsat8Sr
  .filterBounds(boundary)
  .filterDate('2014', '2021')
  .map(maskL8sr)
  .map(addVariables);
// Display RGB parameters
var rgb = landsat8Sr.select('SR_B5', 'SR_B4','SR_B3');
// Plot a time series of NDSSI at a single location.
Map.setCenter(30.7443,-17.8756, 12);
// Load and define a continuous palette
var palettes = require('users/gena/packages:palettes');
// Choose and define NDSSI display palette
var palette = palettes.colorbrewer.RdBu[10];
var viz = {min: -1, max: 1, palette: palette};
// set position of panel
var legend = ui.Panel({
style: {
position: 'bottom-left',
padding: '8px 15px'
}
});
// Create legend title
var legendTitle = ui.Label({
value: 'NDSSI',
style: {
fontWeight: 'bold',
fontSize: '18px',
margin: '0 0 4px 0',
padding: '0'
}
});
// Add the title to the panel
legend.add(legendTitle);
// create the legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// create text on top of legend
var panel = ui.Panel({
widgets: [
ui.Label(viz['max'])
],
});
legend.add(panel);
// create thumbnail from the image
var thumbnail = ui.Thumbnail({
image: legendImage,
params: {bbox:'0,0,10,100', dimensions:'10x200'},
style: {padding: '1px', position: 'bottom-center'}
});
// add the thumbnail to the legend
legend.add(thumbnail);
// create text on top of legend
var panel = ui.Panel({
widgets: [
ui.Label(viz['min'])
],
});
legend.add(panel);
Map.add(legend);
// Display the NDSSI map
var NDSSI = filteredLandsat.select('NDSSI');
Map.addLayer(NDSSI, viz, 'NDSSI Mosaic');
// Create a panel to hold our widgets.
var panel = ui.Panel();
panel.style().set('width', '300px');
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: 'Monitoring Water Quality using NDSSI in Manyame Catchment Area, Zimbabwe',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
  ui.Label('NDSSI & SR Chart Inspector: Click a point on the map to inspect.')
]);
var subtitle = ui.Label('Use Landsat 8 imagery to calculate'+
  ' normalized difference suspended sediment index (NDSSI) between 2014 and 2021.'+
  ' Lower or more negative NDSSI values indicate higher suspended sediment concentrations,'+
   ' while higher or more positive NDSSI values indicate lower suspended sediment concentrations' +
  ' (Hossain et al., 2010).', {});
panel.add(intro).add(subtitle);
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
// Register a callback on the default map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('lon: ' + coords.lon.toFixed(2)),
  lat.setValue('lat: ' + coords.lat.toFixed(2));
  // Add a red dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'FF0000'});
  Map.layers().set(1, dot);
  // Create an NDSSI chart.
  var NDSSIChart = ui.Chart.image.series(NDSSI, point, ee.Reducer.mean(), 500);
  NDSSIChart.setOptions({
    title: 'NDSSI Over Time',
    vAxis: {title: 'NDSSI'},
    hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
  });
  panel.widgets().set(2, NDSSIChart);
  // Create an RGB spectrum chart.
   var rgbChart = ui.Chart.image.series(rgb, point)
      .setOptions({
        title: 'RGB Reflectance Over Time',
        vAxis: {title: 'band value'},
         hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
       });
   panel.widgets().set(3, rgbChart);
 });
Map.style().set('cursor', 'crosshair');
// Add the panel to the ui.root.
ui.root.insert(0, panel);
/*
Disclaimer
The data and maps in this tool illustrate potential normalized difference suspended sediment index (NDSSI), which has not been validated. Therefore, users should verify all features through fieldwork. The data and maps in this tool are provided "as is," without warranty to their performance.
The user assumes the entire risk associated with the results and performance of these data. This tool should be used strictly for training, not for permitting or other legal purposes.
*/