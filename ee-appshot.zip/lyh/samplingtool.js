// import vars required
var global_variables = require('users/lyh/burnt_area:SamplingToolV0/global_variables');
var utils_ui = require('users/lyh/burnt_area:SamplingToolV0/utils_ui');
var MCD43A4 = global_variables.MCD43A4;
var MTBS_RoI = global_variables.MTBS_RoI;
var MTBS_RoI_ORG = global_variables.MTBS_RoI;
var MTBS_PoI = global_variables.MTBS_PoI;
// initilization
var geom = global_variables.GEOM_INI;
// var filter_express = global_variables.FILTER_EXPRESS_INI;
var roi = utils_ui.get_roi(geom);
var doi = utils_ui.get_doi(roi);
var delta_cpm_before = global_variables.DELTA_CPM_BEFORE;
var delta_cpm_after = global_variables.DELTA_CPM_AFTER;
var ImgC_TS = utils_ui.get_ImgC_TS(doi);
var Img_CPM_before = utils_ui.get_Img_CPM(doi, delta_cpm_before);
var Img_CPM_after = utils_ui.get_Img_CPM(doi, delta_cpm_after);
// 
var panel = ui.Panel({style: {width: '600px'}});
var widgets = panel.widgets(ee.List.repeat(null, 10));
Map.addLayer(MTBS_RoI, {}, 'MTBS');
Map.centerObject(geom, 9);
widgets.set(global_variables.IDX_TEXT_BOX_ADD_LAYER, 
  ui.Textbox({
  placeholder: 'add map: user_name/data_path',
  onChange: function(text){
    Map.addLayer(ee.FeatureCollection('users' + '/' + text), {}, text);
    }
  })
  );
widgets.set(global_variables.IDX_TEXT_FILTER, 
  ui.Textbox({
  placeholder: 'expression: Year<2015',
  onChange: function(text){
    var MTBS_RoI_filtered = MTBS_RoI.filter(ee.Filter.expression(text));
    Map.addLayer(MTBS_RoI_filtered, {}, 'MTBS ' + text);
    }
  })
  );
widgets.set(global_variables.IDX_TEXT_BOX_0, 
  ui.Textbox({
    placeholder: 'the gap before doi',
    onChange: function(text){
      delta_cpm_before = ee.Number.expression(text);
      Img_CPM_before = utils_ui.get_Img_CPM(doi, delta_cpm_before.multiply(-1));
      utils_ui.updateCPM(widgets, Img_CPM_before, roi, 'before', global_variables.IDX_MAP_BEFORE);
    }})
);
widgets.set(global_variables.IDX_TEXT_BOX_1, ui.Textbox({
  placeholder: 'the gap after doi',
  onChange: function(text){
    delta_cpm_after = ee.Number.expression(text);
    Img_CPM_after = utils_ui.get_Img_CPM(doi, delta_cpm_after);
    utils_ui.updateCPM(widgets, Img_CPM_after, roi, 'after', global_variables.IDX_MAP_AFTER);
  }
}));
utils_ui.updateTS(widgets, ImgC_TS, geom, global_variables.IDX_CHART_ST);
utils_ui.updateCPM(widgets, Img_CPM_before, roi, 'before', global_variables.IDX_MAP_BEFORE);
utils_ui.updateCPM(widgets, Img_CPM_after, roi, 'after', global_variables.IDX_MAP_AFTER);
Map.onClick(function(coords){
  var geom = ee.Geometry.Point(coords.lon, coords.lat);
  var roi = utils_ui.get_roi(geom);
  var doi = utils_ui.get_doi(roi);
  var ImgC_TS = utils_ui.get_ImgC_TS(doi);
  var Img_CPM_before = utils_ui.get_Img_CPM(doi, delta_cpm_before.multiply(-1));
  var Img_CPM_after = utils_ui.get_Img_CPM(doi, delta_cpm_after);
  utils_ui.updateTS(widgets, ImgC_TS, geom, global_variables.IDX_CHART_ST);
  utils_ui.updateCPM(widgets, Img_CPM_before, roi, 'before doi', global_variables.IDX_MAP_BEFORE);
  utils_ui.updateCPM(widgets, Img_CPM_after, roi, 'after doi', global_variables.IDX_MAP_AFTER);
  utils_ui.show_attributes(roi);
});
ui.root.add(panel);