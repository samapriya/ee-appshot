var fire_data = ee.FeatureCollection('users/lyh/BurnArea/fire_dataset');
var import_data = function(){
    // align the name of bands
    var lc8_bands = ['B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B10']; 
    var lc7_bands = ['B1', 'B2', 'B3', 'B4', 'B5', 'B7',  'B6']; 
    var lc5_bands = ['B1', 'B2', 'B3', 'B4', 'B5', 'B7',  'B6']; 
    var modis_bands = ['sur_refl_b02','sur_refl_b01','sur_refl_b04',  'sur_refl_b03','sur_refl_b05','sur_refl_b06','sur_refl_b07'];
    var lc_std_bands = ee.List(['blue', 'green', 'red', 'nir', 'swir1', 'swir2', 'temp']);
    var modis_std_bands = ee.List(['B2', 'B1','B4', 'B3', 'B5', 'B6', 'B7']);
    // prepare data
    var img_lc8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
                  .filterDate('2014-01-01', '2020-12-31')
                  .map(maskL8sr)
                  .select(lc8_bands, lc_std_bands);
    var img_lc7 = ee.ImageCollection('LANDSAT/LE07/C01/T1_SR')
                  .filterDate('2000-01-01', '2013-12-31')
                  .map(cloudMaskL457)
                  .select(lc7_bands, lc_std_bands);
    var img_lc5 = ee.ImageCollection('LANDSAT/LT05/C01/T1_SR')
                  .filterDate('1984-01-01', '1999-12-31')
                  .map(cloudMaskL457)
                  .select(lc5_bands, lc_std_bands);
    var img_lc = ee.ImageCollection(img_lc5.merge(img_lc7).merge(img_lc8))
                 .map(add_bands_lc);
    var img_modis = ee.ImageCollection('MODIS/006/MOD09GA')
                     .filterDate('2013-01-01', '2020-12-30')
                     .map(maskEmptyPixels)
                     .map(maskClouds)
                     .select(modis_bands, modis_std_bands)                        
                     .map(add_bands_modis);
    // monthly average on MODIS
    var months = ee.List.sequence(1, 12);
    var years = ee.List.sequence(2013, 2020);
    var img_modis_monthly = ee.ImageCollection(
      years.map(function (year){
        return months.map(function(month){
          return img_modis.filter(ee.Filter.calendarRange(year, year, 'year'))
                          .filter(ee.Filter.calendarRange(month, month, 'month')).mean()
                          .set('year', year).set('month', month).set('system:time_start', ee.Date.fromYMD(year, month, 1).millis());
        });
      }).flatten());
    return [img_modis_monthly, img_lc];
};
var add_bands_lc = function(image){
  return image.addBands(image.normalizedDifference(['nir', 'swir1']).rename('nbr1'))
              .addBands(image.normalizedDifference(['nir', 'swir2']).rename('nbr2'))
              .addBands(image.normalizedDifference(['nir', 'red']).rename('NDVI'))
              .addBands(image.normalizedDifference(['nir',  'green']).rename('NDWI'));
};
var add_bands_modis = function(image){
  return image.addBands(image.normalizedDifference(['B2', 'B6']).rename('nbr1'))
              .addBands(image.normalizedDifference(['B2', 'B7']).rename('nbr2'))
              .addBands(image.normalizedDifference(['B2', 'B1']).rename('NDVI'))
              .addBands(image.normalizedDifference(['B2', 'B4']).rename('NDWI'));
};
var maskL8sr = function (image) {
  // Bits 3 and 5 are cloud shadow and cloud, respectively.
  var cloudShadowBitMask = (1 << 3);
  var cloudsBitMask = (1 << 5);
  // Get the pixel QA band.
  var qa = image.select('pixel_qa');
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudShadowBitMask).eq(0)
                .and(qa.bitwiseAnd(cloudsBitMask).eq(0));
  return image.updateMask(mask);
};
var cloudMaskL457 = function(image) {
  var qa = image.select('pixel_qa');
  // If the cloud bit (5) is set and the cloud confidence (7) is high
  // or the cloud shadow bit is set (3), then it's a bad pixel.
  var cloud = qa.bitwiseAnd(1 << 5)
          .and(qa.bitwiseAnd(1 << 7))
          .or(qa.bitwiseAnd(1 << 3));
  // Remove edge pixels that don't occur in all bands
  var mask2 = image.mask().reduce(ee.Reducer.min());
  return image.updateMask(cloud.not()).updateMask(mask2);
};
var maskEmptyPixels = function(image) {
  // Find pixels that had observations.
  var withObs = image.select('num_observations_1km').gt(0)
  return image.updateMask(withObs)
}
var maskClouds = function(image) {
  // Select the QA band.
  var QA = image.select('state_1km')
  // Make a mask to get bit 10, the internal_cloud_algorithm_flag bit.
  var bitMask = 1 << 10;
  // Return an image masking out cloudy areas.
  return image.updateMask(QA.bitwiseAnd(bitMask).eq(0))
}
var imgM_show = ee.ImageCollection(import_data()[0]);
var imgL_show = ee.ImageCollection(import_data()[1]);
// // // // // // // // // // // // // // // // // // // // // // // // // //
var update_ts_MODIS = function(bands_obs){
  print('Here! update_ts_MODIS');
    var chart_MODIS = ui.Chart.image.series({
  imageCollection: imgM.select(bands_obs), 
  region: geom, 
  reducer: ee.Reducer.mean(),
  scale: 30,
  }).setOptions({
  title: 'MODIS(monthly average)',
  hAxis: {title: 'Date'}, 
  vAxis: {title: 'Band Value'},
  lineWidth: 0.5, 
  pointSize: 4,
  colors: ['#FF0000'],
  height: '200px',
  });
  // print(widgets.length());
  widgets.set(8, chart_MODIS);
};
var update_ts_LC = function(bands_obs){
  print('Here! update_ts_LC');
    var chart_LC = ui.Chart.image.series({
    imageCollection: imgL.select(bands_obs), 
    region: geom, 
    reducer: ee.Reducer.mean(),
    scale: 30,
  }).setOptions({
    title: 'LC',
    hAxis: {title: 'Date'}, 
    vAxis: {title: 'Band Value'},
    lineWidth: 0.5, 
    pointSize: 4,
    colors: ['#0000FF'],
    height: '200px',
  });
  // print(widgets.length());
  widgets.set(3, chart_LC);
};
var text2dict = function(text){
  var fire = fire_data.filter(ee.Filter.stringContains('Fire_ID', text.slice(0, 2)))
                    .filter(ee.Filter.stringContains('Fire_ID', text.slice(2, 10)));
  var id_list = fire.iterate(function(v, pList){
    pList = ee.List(pList);
    pList = pList.add(v.get('Fire_ID'));
    return pList;
  }, ee.List([]));
  var cor_list = fire.iterate(function(v, pList){
    pList = ee.List(pList);
    pList = pList.add([ee.Number(v.get('Long')), ee.Number(v.get('Lat'))]);
    return pList;
  }, ee.List([]));
  var fire_dict = ee.Dictionary.fromLists(id_list, cor_list);
  fire_dict = ee.Dictionary(fire_dict).getInfo();
  return fire_dict;
};
var cpm_vis = function(range){
  var average_gap = 1.5;
  var map_bef = ui.Map();
  var img_show = ee.Image(imgL_show.filterDate(range.start().advance(-average_gap, 'month'), range.start().advance(average_gap, 'month')).mean()
                                          .clip(geom.buffer(buffer_range))); 
  map_bef.centerObject(geom.buffer(buffer_range), 16);
  map_bef.addLayer(geom.buffer(buffer_range), {}, 'geom');
  map_bef.addLayer(img_show, VisParam, 'before');
  // print(widgets.length());
  widgets.set(6, map_bef);
  print('Here!map_bef');
  var map_aft = ui.Map();
  var img_show = ee.Image(imgL_show.filterDate(range.end().advance(-average_gap, 'month'), range.end().advance(average_gap, 'month')).mean()
                                          .clip(geom.buffer(buffer_range))); 
  map_aft.centerObject(geom.buffer(buffer_range), 16);
  map_aft.addLayer(geom.buffer(buffer_range), {}, 'geom');
  map_aft.addLayer(img_show, VisParam, 'after');
  // print(widgets.length());
  widgets.set(7, map_aft);
  print('Here!map_aft');
  throw Error();
};
// // // // // // // // // // // // // // // // // // // // // // // // // // 
var panel = ui.Panel({style: {width: '600px'}});
var widgets = panel.widgets(ee.List.repeat(null, 10));
var bands_obs = ['nbr1'];
var geom = ee.Geometry.Point(-122.4668429347373,38.98490969731549);
var imgM = imgM_show.filterDate('2013-01-01', '2018-12-01');
var imgL = imgL_show.filterDate('2015-01-01', '2015-12-01');
var period_modis = 4 * 360;
var period_lc = 3.5 * 360;
var period = 240;
var VisParam = {
  bands: ['red', 'green', 'blue'],
  min: 227.09639543830053,
  max: 918.0673472517581,
  gamma: [0.95, 1.0, 1.0],
};
var text = 'CA201508';
var fire_dict = text2dict(text);
var buffer_range = 100;
var range_vis = null;
// // // // // // // // // // // // // // // // // // // // // // // // // 
Map.addLayer(fire_data, {}, 'fire data');
// // // // // // // // // // // // // // // // // // // // // // // // // 
var start_M = ee.Image(imgM.first()).date().get('year').format();
var start_L = ee.Image(imgL.first()).date().get('year').format();
var now = Date.now();
var end = ee.Date(now).format();
var dateRange_modis = ee.DateRange(start_M, end).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: period_modis,
    onChange: function(range){
      print('Here! dateRange_modis');
      imgM = imgM_show.filterDate(range.start(), range.end());
      update_ts_MODIS(bands_obs);
    },
    style: {width: '600px'},
  });
  // print(widgets.length());
  widgets.set(9, dateSlider.setValue(now));
});
var dateRange_LC = ee.DateRange(start_L, end).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: period_lc,
    onChange: function(range){
      print('Here! dateRange_LC');
      imgL = imgL_show.filterDate(range.start(), range.end());
      update_ts_LC(bands_obs);
    }, 
    style: {width: '600px'},
  });
  // print(widgets.length());
  widgets.set(4, dateSlider.setValue(now));
});
// // // // // // // // // // // // // // // // // // // // // // // // // //
var bands_dict = {
  B1: ['B1'], B2: ['B2'], B3: ['B3'], B4: ['B4'], B5: ['B5'], B6: ['B6'], B7: ['B7'],
  blue: ['blue'], green: ['green'], red: ['red'], nir: ['nir'], swir1: ['swir1'], swir2: ['swir2'],
  NDVI: ['NDVI'], NDWI: ['NDWI'], nbr1: ['nbr1'], nbr2: ['nbr2'],
  comb1: ['nbr1', 'nbr2'],
};
var select_bands = ui.Select({
      items: Object.keys(bands_dict),
      onChange: function(key) {
        print('Here!select_bands');
        bands_obs = bands_dict[key];
        update_ts_LC(bands_obs);
        update_ts_MODIS(bands_obs);
      }
    });
select_bands.setPlaceholder('Choose a band(default nbr)');
widgets.set(0, select_bands);
// // // // // // // // // // // // // // // // // // // // // // // // // // 
var textbox = ui.Textbox({
  placeholder: 'formatt like: CA20150813',
  onChange: function(text){
    print('Here!textbox');
    fire_dict = text2dict(text);
    var select_fire = ui.Select({
  items: Object.keys(fire_dict),
  onChange: function(key){
    geom = ee.Geometry.Point(fire_dict[key][0], fire_dict[key][1]);
    print('Here!select_fire');
    update_ts_MODIS(bands_obs);
    update_ts_LC(bands_obs);
  }
});
    select_fire.setPlaceholder('Choose a location fire date');
    widgets.set(2, select_fire);
  },
});
widgets.set(1, textbox);
// // // // // // // // // // // // // // // // // // // // // // // // // // 
var select_fire = ui.Select({
  items: Object.keys(fire_dict),
  onChange: function(key){
    geom = ee.Geometry.Point(fire_dict[key][0], fire_dict[key][1]);
    print('Here!select_fire');
    update_ts_MODIS(bands_obs);
    update_ts_LC(bands_obs);
    cpm_vis(range_vis);
  }
});
select_fire.setPlaceholder('Choose a location fire date');
widgets.set(2, select_fire);
// // // // // // // // // // // // // // // // // // // // // // // // // //
Map.onClick(function(coords){
  var geom = ee.Geometry.Point(coords.lon, coords.lat);
  print('Here! Map.onClick');
  update_ts_MODIS(bands_obs);
  update_ts_LC(bands_obs);
  cpm_vis(range_vis);
});
// // // // // // // // // // // // // // // // // // // // // // // // // //
Map.drawingTools().setLinked(false);
Map.drawingTools().setDrawModes(['polygon']); 
Map.drawingTools().addLayer([], 'roi', '00ff00');
Map.drawingTools().setShape('polygon');
Map.drawingTools().draw();   
var update_ts_polygon = ui.util.debounce(function(layer){
  print('Here!drawingTools');
  geom = Map.drawingTools().layers().get(0).toGeometry();
  update_ts_MODIS(bands_obs);
  update_ts_LC(bands_obs);
  cmp_vis(range_vis);
}, 500);                      
Map.drawingTools().onEdit(update_ts_polygon);
Map.drawingTools().onDraw(update_ts_polygon);
Map.drawingTools().onErase(update_ts_polygon);
// // // // // // // // // // // // // // // // // // // // // // // // // //
var start = ee.Image(imgL_show.first()).date().get('year').format();
var now = Date.now();
var end = ee.Date(now).format();
var dateRange = ee.DateRange(start, end).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: period,
    onChange: function(range){
      print('Here!dateSlider');
      range_vis = range;
      // cpm_vis_before(range);
      // cpm_vis_after(range);
      cpm_vis(range_vis);
    },
    style: {width: '600px'},
  });
  widgets.set(5, dateSlider);
  dateSlider.setValue(now);
});
ui.root.add(panel);