var aoi = ui.import && ui.import("aoi", "table", {
      "id": "users/datasetbanjir/hutan_jabar"
    }) || ee.FeatureCollection("users/datasetbanjir/hutan_jabar");
///Import citra MODIS 250m/pixel 16-day composite dan fitur hutan
var mod13 = ee.ImageCollection('MODIS/006/MOD13Q1');
var area = aoi
/// Mengumpulkan citra MODIS pada musim kemarau yaitu Apr dan Sept 2000-2020
// Menambahkan pengamatan tahun sebagai sebuah properti citra
var mod13Summer = mod13.filter(ee.Filter.calendarRange(4, 9, 'month'))
  .filter(ee.Filter.calendarRange(2000, 2020, 'year'))
  .map(function(img) {
    return img.set('year', img.date().get('year'));
  });
// Membuat daftar dari citra berdasarkan 'tahun' menggunakan fungsi 'Join'.
var mod13SummerAnnualJoin = ee.Join.saveAll('same_year').apply({
  primary: mod13Summer.distinct('year'),
  secondary: mod13Summer,
  condition: ee.Filter.equals({leftField: 'year', rightField: 'year'})
});
/// Menghitung citra komposit EVI maksimal tahunan dari daftar gabungan "tahun yang sama"
// Menampilkan sebuah citra dengan 2 kanal yang digunakan dalam perhitungan gradien deret waktu
//tahun = kanal 1, EVI maks. = kanal 2
var summerStats = ee.ImageCollection(mod13SummerAnnualJoin.map(function(img) {
  var year = img.get('year');
  var yearCol = ee.ImageCollection.fromImages(img.get('same_year'));
  var max = yearCol.select('EVI').max();
  var yr = ee.Image.constant(ee.Number(year)).toShort();
  return ee.Image.cat(yr, max).rename(['year', 'max']).set('year', year);
}));
///Estimasi trend linier dari tiap piksel dengan menghitung gradien sen's dari EVI kemarau maksimum dari dengan waktu
// Menghitung gradien dari deret waktu menggunakan Sen'S Slope
var sens = summerStats.reduce(ee.Reducer.sensSlope());
//Mendefinisikan sebuah fungsi untuk menghitung sebuah histogram dari nilai gradien yang terhitung
//Mendefinisikan sebuah fungsi histogram khusus sebagai ganti dari
// 'ui.Chart.image.histogram' karena tidak mengikuti garis dasar  sebagai nilai 0
// yang penting ketika evaluasi nilai positif dan negatif
function getHistogram(sensImg, geometry, title) {
  // Menghitung Histogram sebagi sebuah 'ee.Array table'
  var hist = sensImg.select('slope').reduceRegion({
    reducer: ee.Reducer.autoHistogram(),
    geometry: geometry,
    scale: 250,
    maxPixels: 1e13,
  });
  //Membuat himpunan dan ekstrak kolom bin dan jumlah piksel 
  var histArray = ee.Array(hist.get('slope'));
  var binBottom = histArray.slice(1, 0, 1);
  var nPixels = histArray.slice(1, 1, null);
//Membuat himpunan menggunakan fungsi `ui.Chart.array.values`
  var histColumnFromArray =
    ui.Chart.array.values({array: nPixels, axis: 0, xLabels: binBottom})
      .setChartType('LineChart')
      .setOptions({
        title:'Lorentz National Park Condition Trend Histogram',
        hAxis: {title: 'Slope'},
        vAxis: {title: 'Pixel count'},
        pointSize: 0,
        lineSize: 2,
        colors: ['1b7837'],
        legend: {position: 'none'}
      });
  return histColumnFromArray;
}
// Menghitung gradien bagan histogram dan menampilkannya
print(getHistogram(sens, area));
// Menyimpulkan kondisi vegetasi 'pixel-wise' berdasarkan tanda dari gradien
var cond = ee.Image.cat(sens.select('slope').gt(0).rename('greening'),
                        sens.select('slope').lt(0).rename('browning'));
//Menghitung luas dibawah nilai piksel hijau dan coklat
var areaRes = cond.multiply(ee.Image.pixelArea())
                 .reduceRegions(area, ee.Reducer.sum(), 250);
/// Visualisasi hasil
//Format hasil dari penghijauan dan pencoktalan digunakan dalam sebuah tabel
//Mengubah satuan meter menjadi kilometer dan menghitung tiap fraksinya
//Menambahkan sebagai properti fitur
areaRes = areaRes.map(function(feature) {
  var browningSqM = feature.getNumber('browning');
  var greeningSqM = feature.getNumber('greening');
  var forestSqM = feature.area();
  return feature.set({
    'Browning sq km': browningSqM.divide(1e6),
    'Browning fraction': browningSqM.divide(forestSqM),
    'Greening sq km': greeningSqM.divide(1e6),
    'Greening fraction': greeningSqM.divide(forestSqM),
});
});
//Menampilkan area rekapitulasi dari kondisi vegetasi sebagai sebuah tabel
print(ui.Chart.feature.byFeature(areaRes.select(['NAME', 'Browning sq km',
    'Browning fraction', 'Greening sq km', 'Greening fraction']),
    'NAME')
  .setChartType('Table'));
///Memilih parameter visualisasi yang sesuai dan menampilkan nilai gradien pada peta untuk menunjukkan area di bawah penghijauan dan pencoklatan
// Mempersiapkan tampilan kondisi vegetasi ke peta; Aturan peta menempilkan pilihan
Map.setOptions('SATELLITE');
Map.centerObject(area, 10);
//Mengatur parameter visualisasi dari area penghijauan dan pencoklatan; lalu menampilkannya ke peta
var visParams = {
  opacity: 1,
  bands: ['slope'],
  min: -55,
  max: 55,
  palette:
    ['8c510a', 'd8b365', 'f6e8c3', 'f5f5f5', 'd9f0d3', '7fbf7b', '1b7837']
};
var result = sens.clipToCollection(area)
Map.addLayer(result, visParams, 'Sen\'s slope');
//Menampilkan batas taman nasional lorentz ke peta 
var paimg = ee.Image().byte().paint(area, 0, 2);
Map.addLayer(paimg, {palette: '000000'}, 'National Parks');
// Memplot pola dari data EVI berdasarkan taman nasional dan tahun
//Plot trend in EVI data by national park and year.
print(ui.Chart.image
          .seriesByRegion({
            imageCollection: summerStats,
            regions: area,
            reducer: ee.Reducer.median(),
            band: 'max',
            scale: 250,
            xProperty: 'year',
            seriesProperty: 'NAME'
          })
          .setChartType('ScatterChart')
          .setOptions({
            title: 'Greening/browning Trend in Lorentz National Parks',
            vAxis: {title: 'Median of max. summer EVI'},
            hAxis: {title: 'Year', format: '####'},
            lineWidth: 2,
            pointSize: 0,
            series: {0: {color: 'ff0000'}, 1: {color: '0000ff'}}
          }));
// Mengekspor gambar 
Export.image.toDrive({
  image: result,
  description: 'Hutan Jawa Barat',
  scale: 10,
  region: area
});