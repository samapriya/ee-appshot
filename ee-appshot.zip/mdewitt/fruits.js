/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var imageCollection = ee.ImageCollection("LANDSAT/LC08/C01/T1_RT"),
    imageVisParam2 = {"opacity":1,"bands":["B4","B3","B2"],"min":13810.468192512602,"max":23493.262270007337,"gamma":1};
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var day = imageCollection.filterDate('2014-07-21', '2014-07-23');
Map.addLayer(ee.Image(day.select(['B5', 'B7', 'B2']).first()).resample('bicubic'));