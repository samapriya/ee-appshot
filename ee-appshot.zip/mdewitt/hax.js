var child = document.createElement('div');
child.innerHTML = '<a href=https://code.earthengine.google.com style="text-align: center">Click me! </a>';
child = child.firstChild;
document.getElementById('right-spacer').appendChild(child);