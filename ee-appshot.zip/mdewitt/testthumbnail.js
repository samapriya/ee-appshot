var inspectorPanel = ui.Panel({style: {padding: '0px', position:'top-left'}});
Map.add(inspectorPanel)
var FORTHlogo = ui.Thumbnail({image: ee.Image('users/davidparastatidis/rslabLogo'), params: {min: 0, max: 255}, style:{width: '143px', height:'34px'}});
Map.add(ui.Panel([FORTHlogo]))