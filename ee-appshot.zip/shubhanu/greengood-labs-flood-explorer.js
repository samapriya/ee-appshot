var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                83.22045748866037,
                29.032269219594927
              ],
              [
                83.22045748866037,
                19.347548234876257
              ],
              [
                95.43725436366037,
                19.347548234876257
              ],
              [
                95.43725436366037,
                29.032269219594927
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[83.22045748866037, 29.032269219594927],
          [83.22045748866037, 19.347548234876257],
          [95.43725436366037, 19.347548234876257],
          [95.43725436366037, 29.032269219594927]]], null, false),
    image = ui.import && ui.import("image", "image", {
      "id": "users/shubhanu/GangeticPlainFloodJuly2020"
    }) || ee.Image("users/shubhanu/GangeticPlainFloodJuly2020"),
    image2 = ui.import && ui.import("image2", "image", {
      "id": "users/shubhanu/GangeticPlainFloodMay2020"
    }) || ee.Image("users/shubhanu/GangeticPlainFloodMay2020"),
    geometry2 = ui.import && ui.import("geometry2", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            85.16684206766426,
            25.652372855152045
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            85.45248659891426,
            25.496291154996605
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            85.74087771219551,
            25.53099355498002
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            86.00180300516426,
            25.379716966459092
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            86.28470095438301,
            25.342488711785204
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            86.49344118875801,
            25.414452987546877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            86.83951052469551,
            25.327594200518046
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            86.99057253641426,
            25.322628956108108
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            87.13064822000801,
            25.317663508085925
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            87.35312136453926,
            25.476456709862912
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            87.57834109110176,
            25.374753861723242
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            87.78158816141426,
            25.267997835563392
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.MultiPoint(
        [[85.16684206766426, 25.652372855152045],
         [85.45248659891426, 25.496291154996605],
         [85.74087771219551, 25.53099355498002],
         [86.00180300516426, 25.379716966459092],
         [86.28470095438301, 25.342488711785204],
         [86.49344118875801, 25.414452987546877],
         [86.83951052469551, 25.327594200518046],
         [86.99057253641426, 25.322628956108108],
         [87.13064822000801, 25.317663508085925],
         [87.35312136453926, 25.476456709862912],
         [87.57834109110176, 25.374753861723242],
         [87.78158816141426, 25.267997835563392]]);
// Demonstrates before/after imagery comparison with a variety of dates.
var indiaFilter = ee.Filter.eq('country_na', 'India');
var bangladeshFilter = ee.Filter.eq('country_na', 'Bangladesh');
var nepalFilter = ee.Filter.eq('country_na', 'Nepal');
var twoFilter = ee.Filter.or(indiaFilter,bangladeshFilter, nepalFilter);
var india = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017')
  .filter(twoFilter);
/*
 * Configure the imagery
 */
// These Sentinel-1 images track the major flooding in Myanmar during the 2018
// monsoon season: https://www.bbc.com/news/world-asia-44962585
var images = {
  'Before Floods Summer 2020': image2.clipToCollection(india),
  'After Floods Summer 2020': image.clipToCollection(india),
};
// Composite the Sentinel-1 ImageCollection for 7 days (inclusive) after the
// given date.
function getWeeklySentinelComposite(date) {
  var date = ee.Date(date);
  // Only include the VV polarization, for consistent compositing.
  var polarization = 'VV';
  var sentinel1 = ee.ImageCollection('COPERNICUS/S2')
                      .filterDate(date, date.advance(5, 'day'))
                      .mean();
  return sentinel1.visualize({min: 544, max: 3200, bands: ['B11', 'B8', 'B2'], gamma:1.8});
}
/*
 * Set up the maps and control widgets
 */
// Create the left map, and have it display layer 0.
var leftMap = ui.Map();
leftMap.setOptions("TERRAIN");
leftMap.setCenter(85.9751, 25.4792, 10);
leftMap.setControlVisibility(false);
leftMap.setControlVisibility({scaleControl: true, zoomControl: true});
var leftSelector = addLayerSelector(leftMap, 0, 'top-left');
leftMap.add(ui.Label(
    'GreenGood Labs Flood Detector www.greengoodlabs.com', {fontWeight: 'bold', fontSize: '24px'}, 'http://www.greengoodlabs.com'));
// Create the right map, and have it display layer 1.
var rightMap = ui.Map();
rightMap.setOptions("TERRAIN");
rightMap.setCenter(85.9751, 25.4792, 10);
//rightMap.setControlVisibility(false);
rightMap.setControlVisibility({scaleControl: true, zoomControl: true, fullscreenControl:false});
var rightSelector = addLayerSelector(rightMap, 1, 'top-right');
rightMap.add(ui.Label(
    'GreenGood Labs Flood Detector www.greengoodlabs.com', {fontWeight: 'bold', fontSize: '24px'}, 'http://www.greengoodlabs.com'));
// Adds a layer selection widget to the given map, to allow users to change
// which image is displayed in the associated map.
function addLayerSelector(mapToChange, defaultValue, position) {
  var label = ui.Label('Choose an image to visualize');
  // This function changes the given map to show the selected image.
  function updateMap(selection) {
    mapToChange.layers().set(0, ui.Map.Layer(images[selection]));
  }
  // Configure a selection dropdown to allow the user to choose between images,
  // and set the map to update when a user makes a selection.
  var select = ui.Select({items: Object.keys(images), onChange: updateMap});
  select.setValue(Object.keys(images)[defaultValue], true);
  var controlPanel =
      ui.Panel({widgets: [label, select], style: {position: position}});
  mapToChange.add(controlPanel);
}
/*
 * Tie everything together
 */
// Create a SplitPanel to hold the adjacent, linked maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in the UI root.
ui.root.widgets().reset([splitPanel]);
//Map.add(ui.Label(
 //   'GreenGood Labs Flood Explorer', {fontWeight: 'bold', fontSize: '24px'}));
var linker = ui.Map.Linker([leftMap, rightMap]);
leftMap.setCenter(85.9751, 25.4792, 10);