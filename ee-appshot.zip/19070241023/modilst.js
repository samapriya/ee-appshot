var imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "MODIS/006/MYD11A1"
    }) || ee.ImageCollection("MODIS/006/MYD11A1"),
    pune_boundary = ui.import && ui.import("pune_boundary", "table", {
      "id": "users/19070241023/Pune"
    }) || ee.FeatureCollection("users/19070241023/Pune"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "LST_Day_1km"
        ],
        "min": 20,
        "max": 40,
        "palette": [
          "0000ff",
          "32cd32",
          "ffff00",
          "ff8c00",
          "ff0000",
          "ffffff"
        ]
      }
    }) || {"opacity":1,"bands":["LST_Day_1km"],"min":20,"max":40,"palette":["0000ff","32cd32","ffff00","ff8c00","ff0000","ffffff"]},
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "LST_Day_1km"
        ],
        "min": 20,
        "max": 40,
        "palette": [
          "0000ff",
          "32cd32",
          "ffff00",
          "ff8c00",
          "ff0000",
          "ffffff"
        ]
      }
    }) || {"opacity":1,"bands":["LST_Day_1km"],"min":20,"max":40,"palette":["0000ff","32cd32","ffff00","ff8c00","ff0000","ffffff"]},
    imageVisParam3 = ui.import && ui.import("imageVisParam3", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "LST_Day_1km"
        ],
        "min": 20,
        "max": 40,
        "palette": [
          "0000ff",
          "32cd32",
          "ffff00",
          "ff8c00",
          "ff0000",
          "ffffff"
        ]
      }
    }) || {"opacity":1,"bands":["LST_Day_1km"],"min":20,"max":40,"palette":["0000ff","32cd32","ffff00","ff8c00","ff0000","ffffff"]},
    imageVisParam4 = ui.import && ui.import("imageVisParam4", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "LST_Day_1km"
        ],
        "min": 20,
        "max": 40,
        "palette": [
          "0000ff",
          "32cd32",
          "ffff00",
          "ff8c00",
          "ff0000",
          "ffffff"
        ]
      }
    }) || {"opacity":1,"bands":["LST_Day_1km"],"min":20,"max":40,"palette":["0000ff","32cd32","ffff00","ff8c00","ff0000","ffffff"]},
    imageVisParam5 = ui.import && ui.import("imageVisParam5", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "LST_Day_1km"
        ],
        "palette": [
          "ff9556",
          "fff81f",
          "ff4c23"
        ]
      }
    }) || {"opacity":1,"bands":["LST_Day_1km"],"palette":["ff9556","fff81f","ff4c23"]},
    imageVisParam8 = ui.import && ui.import("imageVisParam8", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "LST_Day_1km",
          "QC_Day",
          "Day_view_time"
        ],
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["LST_Day_1km","QC_Day","Day_view_time"],"gamma":1};
//Load the MODIS image & assigned date
var Modis = ee.ImageCollection("MODIS/006/MYD11A1")
            .filterDate('2011-01-01', '2018-12-31')
//filter shapefile of pune
var filter = Modis.filterBounds(pune_boundary);
// Select only the 1km day LST data band.
var modisLSTday = filter.select('LST_Day_1km');
Map.centerObject(pune_boundary,6);
//to get AOI Clip the satellite Image with shapefile of study area
var clip=Modis.mosaic().clip(pune_boundary);
Map.addLayer(clip, {}, 'AOI of pune_boundary');
//set image acquisition time & convert the temparature
var filter = modisLSTday.map(function(img) {
  return img
    .multiply(0.02)
    .subtract(273.15)
    .copyProperties(img, ['system:time_start']);
});
//Landsurface temparature chart
var chart = ui.Chart.image.series({
  imageCollection:filter,
  region: pune_boundary,
  reducer: ee.Reducer.mean(),
  scale: 1000,
  xProperty: 'system:time_start'})
  .setOptions({
     title: 'Land surface Temparature PMC Boundary',
     vAxis: {title: 'LST in Celsius'}});
// Create a panel and Add the panel to the ui.root.
Map.style().set('cursor', 'crosshair');
var panel = ui.Panel({style: {width: '400px'}})
    .add(ui.Label('Click on the Pune city map to open the LST '));
Map.onClick(function(coords) {
     panel.widgets().set(1, chart);
});
ui.root.add(panel);
print(chart);