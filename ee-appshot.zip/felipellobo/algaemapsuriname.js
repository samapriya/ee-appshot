var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#23cba7",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #23cba7 */ee.Geometry.MultiPoint();
Map.setCenter(-49.8339, 1.8259, 6.3) 
///////////////////// Botões FAKE ////////////////////////////////////////////////////////////////////////////////////////////////////////////
var selDateFake = ui.Button({
    label: "Select a date",
    onClick: Mensagem,
  })
var buttonFake = ui.Button({
  label: "Display Image",
  onClick: Mensagem,
})
var panel = ui.Panel();
panel.style().set({
  position: 'top-center'
});
ui.root.setLayout(ui.Panel.Layout.absolute()); 
ui.root.add(panel.add(ui.Panel([selDateFake, buttonFake], ui.Panel.Layout.flow('horizontal'))))
function Mensagem() {
  Map.clear()
    var LABEL_STYLE1 = {
    color: '#ff0000',
    position: 'top-right',
    fontSize: '20px',
  };
  var Warning = ui.Label('Please, select the Region', LABEL_STYLE1)
  var JRC = ee.Image('JRC/GSW1_4/GlobalSurfaceWater');                            //// Get just within Pekel
  var dataset = JRC.select('occurrence').eq(90)
  var visualization = {
    palette: ['00BFFF	']
  };
  var selDateFake = ui.Button({
    label: "Select a date",
    onClick: Mensagem,
  })
  var buttonFake = ui.Button({
    label: "Display Image",
    onClick: Mensagem,
  })
  var panel = ui.Panel();
  panel.style().set({
    position: 'top-center'
  });
  //ui.root.setLayout(ui.Panel.Layout.absolute()); 
  Map.add(panel.add(ui.Panel([selDateFake, buttonFake], ui.Panel.Layout.flow('horizontal'))));
  Map.add(Warning)
  var estados = ee.FeatureCollection("FAO/GAUL/2015/level1").filter(ee.Filter.eq("ADM1_CODE", 683));
  Map.addLayer(estados)
  var snazzy = require("users/aazuspan/snazzy:styles");
  snazzy.addStyle("https://snazzymaps.com/style/64223/minimal", "GRAYMAP");
  Map.addLayer(dataset.clipToCollection(Reservatorios), visualization, 'Water Bodies');
}
////// Reservoirs
var reservatorio1 = ee.FeatureCollection('projects/ee-felipellobo/assets/massa_dagua_ANA_777_BaciasEstados')
//RJ
var Guanabara = reservatorio1.filter(ee.Filter.inList('gid', ee.List([241196])));
var RJ = reservatorio1.filter(ee.Filter.inList('gid', ee.List([13631,13869,19826,20261,33724])));
var Saquarema = reservatorio1.filter(ee.Filter.inList('gid', ee.List([4329,8537,13866,41393,41538])));
var Araruama = reservatorio1.filter(ee.Filter.inList('gid', ee.List([32462])));
var Jaturnaíba = reservatorio1.filter(ee.Filter.inList('gid', ee.List([30460])));
var Feia = reservatorio1.filter(ee.Filter.inList('gid', ee.List([41352])));
var Vitoria = reservatorio1.filter(ee.Filter.inList('gid', ee.List([34790])));
var FunilRJ = reservatorio1.filter(ee.Filter.inList('gid', ee.List([61857])))
var LajesRJ = reservatorio1.filter(ee.Filter.inList('gid', ee.List([42399])))
var Paracambi = reservatorio1.filter(ee.Filter.inList('gid', ee.List([58140])))
var Nilo = reservatorio1.filter(ee.Filter.inList('gid', ee.List([61310])))
var agua = ee.FeatureCollection('users/brenomello178/aguaTDS') // MEXIDO
var RioSuriname = agua.filter(ee.Filter.inList('fid', ee.List([1])));
var LagoBrokopondo = agua.filter(ee.Filter.inList('fid', ee.List([2])));
var RioSuriname2 = agua.filter(ee.Filter.inList('fid', ee.List([3])));
var RioMaroni = agua.filter(ee.Filter.inList('fid', ee.List([4])));
var RioTapanahony = agua.filter(ee.Filter.inList('fid', ee.List([5])));
var RioLawa = agua.filter(ee.Filter.inList('fid', ee.List([6])));
var RioMana = agua.filter(ee.Filter.inList('fid', ee.List([7])));
var LagoSinnamary = agua.filter(ee.Filter.inList('fid', ee.List([8])));
var Reservatorios_RJ = Guanabara.merge(RJ).merge(Saquarema).merge(Araruama).merge(Jaturnaíba).merge(Feia)
                        .merge(Vitoria).merge(FunilRJ).merge(LajesRJ).merge(Paracambi).merge(Nilo).merge(agua)
var aguaMERGE = Guanabara.merge(RJ).merge(Saquarema).merge(Araruama).merge(Jaturnaíba).merge(Feia)
                        .merge(Vitoria).merge(FunilRJ).merge(LajesRJ).merge(Paracambi).merge(Nilo).merge(agua)
var List = {
  'Rio Suriname' : RioSuriname,
  'Lago Brokopondo' : LagoBrokopondo,
  'Braço inferior do Rio Suriname' : RioSuriname2,
  'Rio Maroni' : RioMaroni,
  'Rio Tapanahony' : RioTapanahony,
  'Rio Lawa' : RioLawa,
  'Rio Mana' : RioMana,
  'Lago de Sinnamary' : LagoSinnamary,
  'BRA/RJ/PARAIBAdoSUL/UHE Funil': FunilRJ,
};
var visualization = {palette: 'blue'}
Map.addLayer(agua, visualization , 'Todos corpos de água')
Map.addLayer(RioSuriname, visualization , 'Rio Suriname');
Map.addLayer(LagoBrokopondo, visualization, 'Lago Brokopondo')
Map.addLayer(RioSuriname2, visualization, 'Braço inferior do Rio Suriname')
Map.addLayer(RioMaroni, visualization, 'Rio Maroni')
Map.addLayer(RioTapanahony, visualization, 'Rio Tapanahony')
Map.addLayer(RioLawa, visualization, 'Rio Lawa')
Map.addLayer(RioMana, visualization, 'Rio Mana')
Map.addLayer(LagoSinnamary, visualization, 'Lago de Sinnamary')
////////////////////////////////////////////////////// Get the NDCI ////////////////////////// ///////////////////////////////////////
var reservatoriosAll = Reservatorios_RJ
////////////////////////////////////////////////////// Get the NDCI and the reservoir shapes  ///////////////////////////////////////
var col = ee.ImageCollection('projects/ee-felipellobo/assets/NDCI_daily')     //// NDCI
///// Pre Processing of the NDCI ImageCollection
////////////////////////////////////////// Shows an inicial image //////////////////////////////////////////////////////////////////////
/// Insere um mapaBase
var snazzy = require("users/aazuspan/snazzy:styles");
snazzy.addStyle("https://snazzymaps.com/style/64223/minimal", "My Custom Style");
var estados = ee.FeatureCollection("FAO/GAUL/2015/level1").filter(ee.Filter.eq("ADM1_CODE", 683));
Map.addLayer(estados)
/// Insere corpos d'água  
var Reservatorios = Reservatorios_RJ
var Reservatórios_Raster = ee.Image(1).clip(Reservatorios)
Map.addLayer(Reservatórios_Raster, {palette: '00BFFF'}, 'Water Bodies');
/// Insere um cursor legal
//Map.setControlVisibility(false);
Map.setControlVisibility({scaleControl: true, zoomControl: true, 
                      mapTypeControl: true, fullscreenControl: true, layerList: true});
Map.style().set({cursor: 'crosshair'});  
/////////////////////////////////////// FUNCTION TO PROCESS TIME SERIES /////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updateMap(BB_mask, region3, selection, fromDate, toDate, Month1, Month2) {
  Map.layers().reset()
  Map.clear()
  Map.setControlVisibility({scaleControl: true, zoomControl: true, 
                            mapTypeControl: true, fullscreenControl: true, layerList: true});
  //////////////////// Pega a região de interesse
  region3 = List[select.getValue()] 
  var now = Date.now();       //getting time at UTC
  var eeNow = ee.Date(now)
    function DATA(image) {
        var image_data = image.set('eedate', ee.Date.fromYMD(image.get('year'),image.get('month'),image.get('day')))
         return image_data.select('NDCIn_mean');
      } 
    function FACTOR(image) {
         return image.select('NDCIn_mean').divide(1000).copyProperties(image,['system:asset_size', 'year', 'month', 'day', 'eedate', 'system:index']);
      } 
    var SIAC_data = col.filterBounds(region3)
                      .map(DATA).map(FACTOR).sort('eedate', false);
    var col_data = SIAC_data
  var snazzy = require("users/aazuspan/snazzy:styles");
  snazzy.addStyle("https://snazzymaps.com/style/64223/minimal", "GRAYMAP");
  //Map.setOptions('SATELLITE');
  /////////////////// Faz um zoom no centro da imagem
  var centre = List[select.getValue()].geometry().centroid().coordinates();                     ///// Define the image center
  Map.setCenter(ee.Number(centre.get(0)).getInfo(), ee.Number(centre.get(1)).getInfo(), 12);
  //////////////////// Extract the Year and Month
  var Ano11 = Ano1.getValue()
  fromDate = Anos[Ano11]
  var Ano22 = Ano2.getValue()
  toDate = Anos[Ano22]
  var Mes11 = Mes1.getValue()
  Month1 = Meses[Mes11]
  var Mes22 = Mes2.getValue()
  Month2 = Meses[Mes22]
  ////////////////// Máscaras de água usado
  var JRC = ee.Image('JRC/GSW1_4/GlobalSurfaceWater');                            //// Get just within Pekel
  var JRC = JRC.select('occurrence')
  var JRC = JRC.gte(10).clipToCollection(Reservatorios)
  var BB_mask = JRC
  ////////////////// Aplica as datas na seleção de imagens NDCI
  var collection1 = col_data                                                        //// Filter the Dates
                    .filterMetadata("year","less_than",toDate + 1)
                    .filterMetadata("year","greater_than",fromDate - 1)
                    .filterMetadata("month","less_than",Month2 + 1)
                    .filterMetadata("month","greater_than",Month1 - 1)
  ///////////////// Aplica uma função para calcular o Chla no ImageCollection e para calcular áreas de Bloom
  var decision_tree = function(image){                                              //// Calculate the Chla 
    var NDCI = image.select('NDCIn_mean').updateMask(BB_mask)
    var Bloom = NDCI.gte(0.025).rename('Bloom')
    var chla = image.expression(
      '(24.49 * ((NDCI + 1) ** 7.48))', {    // 18.45 * ((NDCI + 1) ** 9.23
        'NDCI': image.select('NDCIn_mean'),
      });
    var chla = chla.rename('Chla');
    return chla.addBands(NDCI).addBands(Bloom).copyProperties(image); 
  };
  var chla = collection1.map(decision_tree)
  ////////////// Calcula a frequência de Bloom
  var BloomFreq = chla.select('Bloom').sum().divide(chla.select('Bloom').count()).updateMask(BB_mask);                                            //// Calculate the Bloom Frequency
  //////////////// Define as Cores e palettes das imagens
  var vis = {min:0, max:100, palette: ['blue','green','Yellow','red']};                         //// Color Scale for Chla
  var palettesNDCI = require('users/gena/packages:palettes');                                   //// Color Scale for Bloom
  var visNDCI = {min:-0.2, max:0.3, palette: palettesNDCI.matplotlib.viridis[7]};               //// Color Scale for Bloom
  var palettes = require('users/gena/packages:palettes');                                       //// Color Scale for Bloom
  var vis1 = {min:0, max:1, palette: palettes.cmocean.Balance[7]};                              //// Color Scale for Bloom
  /////////////// Insere as imagens no Mapa
  Map.addLayer(chla.select('Chla').mean().clip(region3).updateMask(BB_mask), vis, 'Chl-a Temporal MEAN', false)
  Map.addLayer(chla.select('Chla').min().clip(region3).updateMask(BB_mask), vis, 'Chl-a Temporal MINIMUM', false)
  Map.addLayer(chla.select('Chla').max().clip(region3).updateMask(BB_mask), vis, 'Chl-a Temporal MAXIMUM', false);
  Map.addLayer(BloomFreq.clip(region3), vis1, 'Bloom Frequency', false);//// Add the mean Chla Image; 
  //////////////////////////////////////////// Cria o Inspector (o usuário clica na imagem e obtem valores do pixel clicado)
  var header = ui.Label('Inspector', {fontWeight: 'bold', fontSize: '15px'}) 
  var toolPanel = ui.Panel([header], 'flow', {width: '200px', position: 'bottom-right'});  
  var dataset = ee.Image(chla.mean().clip(region3))
  var dataset1 = ee.Image(BloomFreq.clip(region3))
  Map.onClick(function(coords) {
      var location = 'lon: ' + coords.lon.toFixed(4) + ' ' +
                     'lat: ' + coords.lat.toFixed(4);
      var click_point = ee.Geometry.Point(coords.lon, coords.lat);
      var demValue = dataset.reduceRegion(ee.Reducer.first(), click_point, 90).evaluate(function(val){
        var demText = 'Mean Chla: ' + val.Chla.toFixed(2);
        toolPanel.widgets().set(2, ui.Label(demText));
      });
      var demValue2 = dataset.reduceRegion(ee.Reducer.first(), click_point, 90).evaluate(function(val2){
        var demText2 = 'Mean NDCI: ' + val2.NDCIn_mean.toFixed(2);
        toolPanel.widgets().set(3, ui.Label(demText2));
      });
      var demValue1 = dataset1.reduceRegion(ee.Reducer.first(), click_point, 90).evaluate(function(val1){
        var demText1 = 'Bloom Frequency: ' + val1.Bloom.toFixed(2);
        toolPanel.widgets().set(4, ui.Label(demText1));
      });
      toolPanel.widgets().set(1, ui.Label(location));
    // Edit: To be temporary, the "loading..." panel number has to be the same as the demText panel number (changed from 1 to 2).
      toolPanel.widgets().set(2, ui.Label("loading..."))
      toolPanel.widgets().set(3, ui.Label("loading..."))
      toolPanel.widgets().set(4, ui.Label("loading..."));
      Map.add(toolPanel);
    });
  ////////////////////////////////////////// Códigos para mostrar a legenda no Mapa
  //////// Legend for Chla 
  function makeColorBarParams(palette) {
    return {
      bbox: [0, 0, 1, 0.1],
      dimensions: '100x10',
      format: 'png',
      min: 0,
      max: 1,
      palette: palette,
    };
  }
  ///////// Cria uma barra de corres para a legenda (CHLA)
  var colorBar_CHLA = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: makeColorBarParams(vis.palette),
    style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
  });
  ////////// Cria um panel com três números para a legenda (CHLA)
  var legendLabels_CHLA = ui.Panel({
    widgets: [
      ui.Label(vis.min, {margin: '4px 8px'}),
      ui.Label(
          (vis.max / 2),
          {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(vis.max, {margin: '4px 8px'})
    ],
    layout: ui.Panel.Layout.flow('horizontal')
  });
  ////////// Título da legenda (CHLA)
  var legendTitle_CHLA = ui.Label({
    value: 'Chla Temporal (min, max, mean)',
    style: {fontWeight: 'bold'}
  }); 
  /////// Legend for Algal Bloom
  var palettes = require('users/gena/packages:palettes');
  var vis1 = {min:0, max:1, palette: palettes.cmocean.Balance[7]};
  function makeColorBarParams1(palette) {
    return {
      bbox: [0, 0, 1, 0.1],
      dimensions: '100x10',
      format: 'png',
      min: 0,
      max: 1,
      palette: palette,
    };
  }
  ///////// Cria uma barra de corres para a legenda (BLOOM)
  var colorBar_BLOOM = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: makeColorBarParams1(vis1.palette),
    style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
  });
  ////////// Cria um panel com três números para a legenda (BLOOM)
  var legendLabels_BLOOM = ui.Panel({
    widgets: [
      ui.Label(vis1.min, {margin: '4px 8px'}),
      ui.Label(
          (vis1.max / 2),
          {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(vis1.max, {margin: '4px 8px'})
    ],
    layout: ui.Panel.Layout.flow('horizontal')
  });
  ////////// Título da legenda (BLOOM)
  var legendTitle_BLOOM = ui.Label({
    value: 'Bloom Frequency',
    style: {fontWeight: 'bold'}
  });
  ////////// NDCI Legend
  function makeColorBarParams2(palette) {
    return {
      bbox: [0, 0, 1, 0.1],
      dimensions: '100x10',
      format: 'png',
      min: 0,
      max: 1,
      palette: palette,
    };
  }
  ///////// Cria uma barra de corres para a legenda (BLOOM)
  var colorBar_NDCI = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: makeColorBarParams2(visNDCI.palette),
    style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
  });
  ////////// Cria um panel com três números para a legenda (BLOOM)
  var legendLabels_NDCI = ui.Panel({
    widgets: [
      ui.Label(visNDCI.min, {margin: '4px 8px'}),
      ui.Label(
          (visNDCI.max / 2),
          {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(visNDCI.max, {margin: '4px 8px'})
    ],
    layout: ui.Panel.Layout.flow('horizontal')
  });
  ////////// Título da legenda (BLOOM)
  var legendTitle_NDCI = ui.Label({
    value: 'NDCI',
    style: {fontWeight: 'bold'}
  });
  /////////////////////// Cria um Panel para incluir as barras e legendas. 
  var legend = ui.Panel({
  style: {
    position: 'top-right',
    padding: '8px 15px'
  }
  });
  ////////////////////// Junta as legendas em um únnico lugar
  var legend = legend.add(legendTitle_NDCI).add(colorBar_NDCI).add(legendLabels_NDCI).add(legendTitle_CHLA)
                .add(colorBar_CHLA).add(legendLabels_CHLA).add(legendTitle_BLOOM).add(colorBar_BLOOM).add(legendLabels_BLOOM)
  Map.add(legend);
  /////////////////////////////////////////////////////// Adicionar botões de download
  //////// Cria um Painel e deleta os widgets anteriores (se eles existirem)
  var legendDownload = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
  });
  ////////// Chla download
  var Chla130 = chla.select('Chla').mean().clip(region3)
  function downloadImg130() {
    var downloadArgs130 = {
      name: 'Chla_Temporal_Mean',
      crs: 'EPSG:3857',
      scale: 30,
      maxPixels: 1e13,
      region: region3.geometry()
   };
   var url130 = Chla130.getDownloadURL(downloadArgs130);
   urlLabel130.setUrl(url130);
   urlLabel130.style().set({shown: true});
  }
  var downloadButton130 = ui.Button('Download Mean Chl-a (30m)', downloadImg130);
  var urlLabel130 = ui.Label('Download', {shown: false});
  var panel130 = ui.Panel([downloadButton130, urlLabel130]);
  var Chla190 = chla.select('Chla').mean().clip(region3)
  function downloadImg190() {
    var downloadArgs190 = {
      name: 'Chla_Temporal_Mean',
      crs: 'EPSG:3857',
      scale: 90,
      maxPixels: 1e13,
      region: region3.geometry()
   };
   var url190 = Chla190.getDownloadURL(downloadArgs190);
   urlLabel190.setUrl(url190);
   urlLabel190.style().set({shown: true});
  }
  var downloadButton190 = ui.Button('Mean Chl-a (90m)', downloadImg190);
  var urlLabel190 = ui.Label('Download', {shown: false});
  var panel190 = ui.Panel([downloadButton190, urlLabel190]);
  ////////// NDCI download
  var img1 = chla.select('NDCIn_mean').mean().clip(region3)
  function downloadImg1() {
    var downloadArgs1 = {
      name: 'NDCI_Temporal_Mean',
      crs: 'EPSG:3857',
      scale: 30,
      maxPixels: 1e13,
      region: region3.geometry()
   };
   var url1 = img1.getDownloadURL(downloadArgs1);
   urlLabel1.setUrl(url1);
   urlLabel1.style().set({shown: true});
  }
  var downloadButton1 = ui.Button('Mean NDCI (30m)', downloadImg1);
  var urlLabel1 = ui.Label('Download', {shown: false});
  var panel1 = ui.Panel([downloadButton1, urlLabel1]);
  var NDCI290 = chla.select('NDCIn_mean').mean().clip(region3)
  function downloadImg290() {
    var downloadArgs290 = {
      name: 'NDCI_Temporal_Mean',
      crs: 'EPSG:3857',
      scale: 90,
      maxPixels: 1e13,
      region: region3.geometry()
   };
   var url290 = NDCI290.getDownloadURL(downloadArgs290);
   urlLabel290.setUrl(url290);
   urlLabel290.style().set({shown: true});
  }
  var downloadButton290 = ui.Button('Mean NDCI (90m)', downloadImg290);
  var urlLabel290 = ui.Label('Download', {shown: false});
  var panel290 = ui.Panel([downloadButton290, urlLabel290]);
  ////////// Bloom download
  var img2 = BloomFreq.clip(region3)
  function downloadImg2() {
    var downloadArgs2 = {
      name: 'Bloom_Frequency',
      crs: 'EPSG:3857',
      scale: 30,
      maxPixels: 1e13,
      region: region3.geometry()
   };
   var url2 = img2.getDownloadURL(downloadArgs2);
   urlLabel2.setUrl(url2);
   urlLabel2.style().set({shown: true});
  }
  var downloadButton2 = ui.Button('Bloom Frequency (30m)', downloadImg2);
  var urlLabel2 = ui.Label('Download', {shown: false});
  var panel2 = ui.Panel([downloadButton2, urlLabel2]);
  var img390 = BloomFreq.clip(region3)
  function downloadImg390() {
    var downloadArgs390 = {
      name: 'Bloom_Frequency',
      crs: 'EPSG:3857',
      scale: 90,
      maxPixels: 1e13,
      region: region3.geometry()
   };
   var url390 = img390.getDownloadURL(downloadArgs390);
   urlLabel390.setUrl(url390);
   urlLabel390.style().set({shown: true});
  }
  var downloadButton390 = ui.Button('Bloom Frequency (90m)', downloadImg390);
  var urlLabel390 = ui.Label('Download', {shown: false});
  var panel390 = ui.Panel([downloadButton390, urlLabel390]);
  /////// Adiciona todos os downloads em um único só panel
  var legendDownload = legendDownload.add(panel130).add(panel190).add(panel1).add(panel290).add(panel2).add(panel390)
  //legendDownload.remove(panel130,panel190,panel1,panel290,panel2,panel390)
  Map.add(legendDownload);
}
/////////////////////////////// OME IMAGE ANALYSIS //////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////// FUNÇÃO TESTE PARA CALCULAR A LISTA DE DATAS /////////////////////////////////////
function getDate(BB_mask, region3, region1, selection1, fromDate1Year, fromDate1Month, fromDate1Day, fcGeom, GRAYMAP) {
  //Map.setOptions('SATELLITE');
  //////////// Exclui coisas da imagem
  Map.clear()
  Map.setControlVisibility({scaleControl: true, zoomControl: true, 
                            mapTypeControl: true, fullscreenControl: true, layerList: true});
  ////////////// Zoom para a região escolhida
  var centre1 = List[select.getValue()].geometry().centroid().coordinates();
  Map.setCenter(ee.Number(centre1.get(0)).getInfo(), ee.Number(centre1.get(1)).getInfo(), 12);
  ///////////// Adiciona um mapabase
  var snazzy = require("users/aazuspan/snazzy:styles");
  snazzy.addStyle("https://snazzymaps.com/style/64223/minimal", "GRAYMAP");
  /////////// Seleciona a região escolhida
  region3 = List[select.getValue()]
  var clipe = region3.geometry()
  ////////// Adiciona um layer de água no reservatório desejado
  Map.addLayer(clipe, {color: '00BFFF'}, 'Water Bodies');
  //////////// Pega uma coleção de imagens Sentinel (para identificar as datas disponíveis)
  var collection11 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
        .select(['B2'])
        .filterBounds(region3)
        // Pre-filter to get less cloudy granules.
        .filter(ee.Filter.neq('system:band_names', []))
        .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',30));
  //////////////// Cria uma coleção de datas
  var Meses1 = collection11
    .map(function(image) {
      return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})
    })
    .distinct('date')
    .aggregate_array('date')
  //////////////// Widgets para fornecer as datas disponíveis e para selecioná-las
  var dateList1 = Meses1.reverse()
  var selDate1 = ui.Select({placeholder: "Select a date", items: dateList1.getInfo()})
  ///////////////// Botão para processar o single image analysis
  var button1 = ui.Button({
  label: "Display Image",
  onClick: updateMap1
  })
  /////// Adiciona no mapa os botões para escolher a data e o botão para mostrar a imagem. 
  var panel = ui.Panel();
  panel.style().set({
    position: 'top-center'
  });
  //ui.root.setLayout(ui.Panel.Layout.absolute()); 
  //Map.add(panel.add(ui.Panel([selDate1, button1], ui.Panel.Layout.flow('vertical'))));
  //Map.add(panel.add(selDate1).add(button1));
  ui.root.add(panel.add(ui.Panel([selDate1, button1], ui.Panel.Layout.flow('horizontal'))))
  //Map.add(selDate1)
  //Map.add(button1)
  ////////////////////////////////// Função para processar o Single image analysis
  function updateMap1(region1, selection1, fromDate1Year, fromDate1Month, fromDate1Day, fcGeom, GRAYMAP) {
      Map.clear()
      //Map.setOptions('SATELLITE');
      var snazzy = require("users/aazuspan/snazzy:styles");
      snazzy.addStyle("https://snazzymaps.com/style/64223/minimal", "My Custom Style");
      //// Definir o centro da imagem
      var centre1 = List[select.getValue()].geometry().centroid().coordinates();
      Map.setCenter(ee.Number(centre1.get(0)).getInfo(), ee.Number(centre1.get(1)).getInfo(), 12);
      /// Definir parâmetros do Mapa
      Map.setControlVisibility({scaleControl: true, zoomControl: true, 
                            mapTypeControl: true, fullscreenControl: true, layerList: true});
      /// Máscara de Água
      var JRC = ee.Image('JRC/GSW1_4/GlobalSurfaceWater');                            //// Get just within Pekel
      var JRC = JRC.select('occurrence')
      var JRC = JRC.gte(10).clipToCollection(Reservatorios)
      var BB_mask = JRC
      //////////// Pega a região selecionada (reservatório ou bacia)
      region1 = List[select.getValue()]
      var now = Date.now();       //getting time at UTC
      var eeNow = ee.Date(now)
      ////////// Pega as datas selecionada e cria um intervalo (para adicionar uma image RGB Sentinel como Layer)
      var fromDateSentinel = ee.Date(selDate1.getValue()).advance(-1,"day")//.format("yyyy-MM-dd"); ////// Uma data do dia anterior à selecionada
      var toDateSentinel = ee.Date(selDate1.getValue()).advance(+1,"day")//.format("yyyy-MM-dd");   ////// Uma data três dias posteriores à selecionada (possibilita cobrir uma área maior em locais de diferente passagem do satélite)
      //// Imagens Sentinel com Máscara de Núvens
      var s2Clouds = ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY').filterBounds(region1).filterDate(fromDateSentinel, toDateSentinel);
      var s2_orig = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED').filterBounds(region1).filterDate(fromDateSentinel, toDateSentinel);
      var MAX_CLOUD_PROBABILITY = 10;
      function maskClouds(img) {
        var clouds = ee.Image(img.get('cloud_mask')).select('probability');
        var isNotCloud = clouds.lt(MAX_CLOUD_PROBABILITY);
        return img.updateMask(isNotCloud);
      }
      function maskEdges(s2_img) {
        return s2_img.updateMask(
            s2_img.select('B8A').mask().updateMask(s2_img.select('B9').mask()));
      }
      s2_orig = s2_orig.map(maskEdges);
      s2Clouds = s2Clouds;
      var s2SrWithCloudMask = ee.Join.saveFirst('cloud_mask').apply({
        primary: s2_orig,
        secondary: s2Clouds,
        condition:
            ee.Filter.equals({leftField: 'system:index', rightField: 'system:index'})
      });
      var s2CloudMasked =
          ee.ImageCollection(s2SrWithCloudMask).map(maskClouds);
      function bandcor (img) {
        var band4 = img.select('B4').multiply(0.935).add(101.52).rename('B4');
        var band5 = img.select('B5').multiply(0.9086).add(75.575).rename('B5');
        var band12 = img.select('B12').multiply(0.8943).rename('B12');
        var band44 = img.select('B4').rename('B44');
        var band55 = img.select('B5').rename('B55');
        var band1212 = img.select('B12').rename('B1212');
        //var glint = atmcor.subtract(atmcor.select('B12'))//.updateMask(BB_mask);
        return img.addBands([band4, band5, band12, band44, band55, band1212], ['B4', 'B5', 'B12', 'B44', 'B55', 'B1212'], true).updateMask(BB_mask)//.updateMask(mask_cloud)//.updateMask(mask_agua)//
            .select(['B3', 'B4', 'B5', 'B8', 'B12', 'B44', 'B55', 'B1212'])
            .copyProperties(img, ['system:index', 'system:time_start']);
                  }
      function NDCI2(image) {
          var glint = image.subtract(image.select('B12'))
          var NDCIn = glint.normalizedDifference(['B5', 'B4']);
          var NDCIname = NDCIn.rename(['NDCIn_mean']).updateMask(BB_mask.selfMask());
        return image.addBands(NDCIname).copyProperties(image, ['system:index', 'system:time_start']);
      } 
      function DATA2(img) {
        var date  = ee.Date(img.get('system:time_start'));
        var date_daily = date.format('YYYY-MM-dd');
        return img.set('eedate', ee.Date.fromYMD(date.get('year'), date.get('month'), date.get('day')))
                  .set('year', (date.get('year')))
                  .set('month', (date.get('month')))
                  .set('day', (date.get('day')))
      }
      function DATA(image) {
        var image_data = image.set('eedate', ee.Date.fromYMD(image.get('year'),image.get('month'),image.get('day')))
         return image_data.select(['NDCIn_mean']);
      } 
      function FACTOR(image) {
         return image.select('NDCIn_mean').divide(1000).copyProperties(image,['system:asset_size', 'year', 'month', 'day', 'eedate', 'system:index']);
      } 
      var SIAC_data = col.filterBounds(region1)
                      .map(DATA).map(FACTOR).sort('eedate', false);
      var sen2cor_data = s2CloudMasked.filterBounds(region1)
                      .map(bandcor).map(NDCI2).map(DATA2).sort('eedate', false); //nagel
      var col_data = sen2cor_data.select(['NDCIn_mean', "B4"]) //SIAC_data.merge(sen2cor_data.select(['NDCIn_mean', "B4"]).distinct('eedate'))
      SIAC_data = 0
      s2Clouds = 0
      s2_orig = 0
      s2SrWithCloudMask = 0
      s2CloudMasked = 0
      ///////////// O mapa é clareado novamente 
      //Map.clear()
      ///////////// Adiciona o mapa base cinza
      var snazzy = require("users/aazuspan/snazzy:styles");
      snazzy.addStyle("https://snazzymaps.com/style/64223/minimal", "GRAYMAP");
      //Map.setOptions('SATELLITE');
      ////////// Pega uma imagem Sentinel da data para adicionar como um Layer
      var Sentinel = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
        .filterDate(fromDateSentinel, toDateSentinel)
        .select(['B4', 'B3', 'B2'])
        .filterBounds(region3)
      var rgbVis = {
        min: 300,
        max: 1300,
        bands: ['B4', 'B3', 'B2'],
      };
      //////// Coleção de imagem NDCI (filtrar pela data)
      var col_data = ee.ImageCollection(col_data)                                                        
      ////////// Função para calcular o Chla e Bloom
      var decision_tree = function(image){                                              //// Calculate the Chla 
        var NDCI = image.select('NDCIn_mean').updateMask(BB_mask)
        //var Bloom = NDCI.gte(0.025).rename('Bloom')
        var chla = image.expression(
          '(24.49 * ((NDCI + 1) ** 7.48))', {
            'NDCI': image.select('NDCIn_mean'),
          });
        var chla = chla.rename('Chla').updateMask(BB_mask);
        return chla.addBands(NDCI).copyProperties(image); 
      };
      var chla1 = col_data.map(decision_tree).mean().updateMask(BB_mask)    //// Coloca-se média para formar uma imagem ee.Image (média de uma imagem sem mudar os valores)
      var TSS = function(image) {
            var TSSn = image.expression(
            '((RED/2.64)**(1/0.45)) + 2.27', {
              'RED': image.select('B4').multiply(0.01)
              //'SWIR': image.select('B11') });
            })
            var TSSname = TSSn.rename(['TSSn']);
          return TSSname;
        } 
      var TSS = col_data.map(TSS).mean().updateMask(BB_mask) 
      var slice = chla1.expression(
            "(b('NDCIn_mean') > 0.1265) ? 5" +
            ": (b('NDCIn_mean') > 0.0245) ? 4" +
            ": (b('NDCIn_mean') > -0.0934) ? 3" +
            ": (b('NDCIn_mean') > -0.13) ? 2" +
            ": (b('NDCIn_mean') > -0.30) ? 1" +
            ": -99" );
      var mask2 = slice.neq(-99)
      var slicename = slice.rename(['NDCI_class']).updateMask(mask2);
      ////// Cria as Palettes para os mapas
      var vis = {min:0, max:100, palette: ['blue','green','Yellow','red']};                         //// Color Scale for Chla
      var palettesNDCI = require('users/gena/packages:palettes');                                   //// Color Scale for NDCI
      var visNDCI = {min:-0.2, max:0.3, palette: palettesNDCI.matplotlib.viridis[7]};               //// Color Scale for NDCI
      var vis1 = {min:0, max:100, palette: ['blue','green','Yellow','red']};                        //// Color Scale for Bloom
      var visIET = {min:1, max:5, palette: ['#0000FF', '#00FFFF', '#008000', '#FFBF00', '#FF0000']};///  Color Scale for 
      ////// Adicionar os Layers
      Map.addLayer(Sentinel, rgbVis, 'Sentinel RGB')  
      Map.addLayer(chla1.select('Chla').clip(region1), vis, 'Chl-a Concentration', false)
      Map.addLayer(slicename.select('NDCI_class').clip(region1), visIET, 'TSI Classes', false)
      Map.addLayer(TSS.clip(region1), vis1, 'TSS', true)
      ///////////////////////// Legendas /////////////////////////////////////////////////////////////
      ///////// Chla 
      /// Criar um thumbnail (CHLA)
      var vis = {min:0, max:100, palette: ['blue','green','Yellow','red']};
      function makeColorBarParams(palette) {
        return {
          bbox: [0, 0, 1, 0.1],
          dimensions: '100x10',
          format: 'png',
          min: 0,
          max: 1,
          palette: palette,
        };
      }
    //// Criação de uma barra de cores (CHLA)
      var colorBar_CHLA = ui.Thumbnail({
        image: ee.Image.pixelLonLat().select(0),
        params: makeColorBarParams(vis.palette),
        style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
      });
    ////// Create a panel with three numbers for the legend. (CHLA)
      var legendLabels_CHLA = ui.Panel({
        widgets: [
          ui.Label(vis.min, {margin: '4px 8px'}),
          ui.Label(
              (vis.max / 2),
              {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
          ui.Label(vis.max, {margin: '4px 8px'})
        ],
        layout: ui.Panel.Layout.flow('horizontal')
      });
      ////// Título da legenda (CHLA)
      var legendTitle_CHLA = ui.Label({
        value: 'Chl-a',
        style: {fontWeight: 'bold'}
      });
       /////// Legend for classes IET
      function makeColorBarParamsIET(palette) {
        return {
          bbox: [0, 0, 1, 0.1],
          dimensions: '100x10',
          format: 'png',
          min: 0,
          max: 1,
          palette: palette,
        };
      }
      //// Criação de uma barra de cores (IET)
      var colorBarIET = ui.Thumbnail({
        image: ee.Image.pixelLonLat().select(0),
        params: makeColorBarParamsIET(visIET.palette),
        style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
      });
      ////// Create a panel with three numbers for the legend. (IET)
      var legendIET = ui.Panel({
      style: {
        position: 'top-right',
        padding: '8px 15px'
      }
      });
      ////// Cria e estiliza as classes de IET 
      var makeRow = function(color, name) {
          // Create the label that is actually the colored box.
          var colorBox = ui.Label({
            style: {
              backgroundColor: '#' + color,
              // Use padding to give the box height and width.
              padding: '10px',
              margin: '0 0 4px 0'
            }
          });
          // Create the label filled with the description text.
          var description = ui.Label({
            value: name,
            style: {margin: '0 0 4px 6px'}
          });
          // return the panel
          return ui.Panel({
            widgets: [colorBox, description],
            layout: ui.Panel.Layout.Flow('horizontal')
          });
      };
      var legendTitleIET = ui.Label({
        value: 'TSI Classes',
        style: {fontWeight: 'bold'}
      });
      var paletteIET = ['0000FF', '00FFFF', '008000', 'FFBF00', 'FF0000']; // Arrumado
      // name of the legend
      var namesIET = ['Oligo','Meso', 'Eutrophic','Super', 'Hyper'];
      // Add color and and names
      for (var i = 0; i < 5; i++) {
        legendIET.add(makeRow(paletteIET[i], namesIET[i]));
        }  
      ////////// Turbidity Legend
      function makeColorBarParams2(palette) {
        return {
          bbox: [0, 0, 1, 0.1],
          dimensions: '100x10',
          format: 'png',
          min: 0,
          max: 1,
          palette: palette,
        };
      }
      //// Criação de uma barra de cores (Turbidity)
      var colorBar_NDCI = ui.Thumbnail({
        image: ee.Image.pixelLonLat().select(0),
        params: makeColorBarParams2(vis1.palette),
        style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
      });
      ////// Create a panel with three numbers for the legend. (Turbidity)
      var legendLabels_NDCI = ui.Panel({
        widgets: [
          ui.Label(vis1.min, {margin: '4px 8px'}),
          ui.Label(
              (vis1.max / 2),
              {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
          ui.Label(vis1.max, {margin: '4px 8px'})
        ],
        layout: ui.Panel.Layout.flow('horizontal')
      });
      ////// Título da legenda (Turbidity)
      var legendTitle_NDCI = ui.Label({
        value: 'TSS',
        style: {fontWeight: 'bold'}
      });
      //////// Panel inicial para hospedar todas as legendas 
      var legend = ui.Panel({
      style: {
        position: 'top-right',
        padding: '8px 15px'
      }
      });
      ///////// Adicionar as legendas
      var legend = legend.add(legendTitle_NDCI).add(colorBar_NDCI).add(legendLabels_NDCI).add(legendTitle_CHLA)
                    .add(colorBar_CHLA).add(legendLabels_CHLA).add(legendTitleIET).add(legendIET)
      Map.add(legend);
      ////////////////// Add Chla Download button /////////////////////////////////////////////////////
      var mask = ee.Image.constant(1).clip(region1.geometry()).mask().not()
      var img = TSS.select('TSSn').clip(region1).unmask(0)
      function downloadImg() {
        var downloadArgs = {
          name: 'TSSn',
          crs: 'EPSG:3857',
          scale: 30,
          maxPixels: 1e13,
          region: region1.geometry()
       };
       var url = img.getDownloadURL(downloadArgs);
       urlLabel.setUrl(url);
       urlLabel.style().set({shown: true});
      }
      var downloadButton = ui.Button('TSSn (30m)', downloadImg);
      var urlLabel = ui.Label('Download', {shown: false});
      var panel = ui.Panel([downloadButton, urlLabel]);
      var img999 = chla1.select('Chla').clip(region1).unmask(0)
      function downloadImg999() {
        var downloadArgs999 = {
          name: 'Chla_image',
          crs: 'EPSG:3857',
          scale: 90,
          maxPixels: 1e13,
          region: region1.geometry()
       };
       var url999 = img999.getDownloadURL(downloadArgs999);
       urlLabel999.setUrl(url999);
       urlLabel999.style().set({shown: true});
      }
      var downloadButton999 = ui.Button('Chl-a (90m)', downloadImg999);
      var urlLabel999 = ui.Label('Download', {shown: false});
      var panel999 = ui.Panel([downloadButton999, urlLabel999]);
      /////// Add Chla Download button 
      var img1 = chla1.select('NDCIn_mean').clip(region1)
      function downloadImg1() {
        var downloadArgs1 = {
          name: 'NDCI_image',
          crs: 'EPSG:3857',
          scale: 30,
          maxPixels: 1e13,
          region: region1.geometry()
       };
       var url1 = img1.getDownloadURL(downloadArgs1);
       urlLabel1.setUrl(url1);
       urlLabel1.style().set({shown: true});
      }
      var downloadButton1 = ui.Button('NDCI (30m)', downloadImg1);
      var urlLabel1 = ui.Label('Download', {shown: false});
      var panel1 = ui.Panel([downloadButton1, urlLabel1]);
      var img11 = chla1.select('NDCIn_mean').clip(region1)
      function downloadImg11() {
        var downloadArgs11 = {
          name: 'NDCI_image',
          crs: 'EPSG:3857',
          scale: 90,
          maxPixels: 1e13,
          region: region1.geometry()
       };
       var url11 = img11.getDownloadURL(downloadArgs11);
       urlLabel11.setUrl(url11);
       urlLabel11.style().set({shown: true});
      }
      var downloadButton11 = ui.Button('NDCI (90m)', downloadImg11);
      var urlLabel11 = ui.Label('Download', {shown: false});
      var panel11 = ui.Panel([downloadButton11, urlLabel11]);
      /////// Add Bloom Download button
      var img2 = chla1.select('Bloom').clip(region1)
      function downloadImg2() {
        var downloadArgs2 = {
          name: 'Bloom_image',
          crs: 'EPSG:3857',
          scale: 30,
          maxPixels: 1e13,
          region: region1.geometry()
       };
       var url2 = img2.getDownloadURL(downloadArgs2);
       urlLabel2.setUrl(url2);
       urlLabel2.style().set({shown: true});
      }
      var downloadButton2 = ui.Button('Bloom Class (30m)', downloadImg2);
      var urlLabel2 = ui.Label('Download', {shown: false});
      var panel2 = ui.Panel([downloadButton2, urlLabel2]);
      var img22 = chla1.select('Bloom').clip(region1)
      function downloadImg22() {
        var downloadArgs22 = {
          name: 'Bloom_image',
          crs: 'EPSG:3857',
          scale: 90,
          maxPixels: 1e13,
          region: region1.geometry()
       };
       var url22 = img22.getDownloadURL(downloadArgs22);
       urlLabel22.setUrl(url22);
       urlLabel22.style().set({shown: true});
      }
      var downloadButton22 = ui.Button('Bloom Class (90m)', downloadImg22);
      var urlLabel22 = ui.Label('Download', {shown: false});
      var panel22 = ui.Panel([downloadButton22, urlLabel22]);
      /////// Add IET Download button
      var img3 = slicename.select('NDCI_class').clip(region1)
      function downloadImg3() {
        var downloadArgs3 = {
          name: 'NDCI_image',
          crs: 'EPSG:3857',
          scale: 30,
          maxPixels: 1e13,
          region: region1.geometry()
       };
       var url3 = img3.getDownloadURL(downloadArgs3);
       urlLabel3.setUrl(url3);
       urlLabel3.style().set({shown: true});
      }
      var downloadButton3 = ui.Button('TSI Class (30m)', downloadImg3);
      var urlLabel3 = ui.Label('Download', {shown: false});
      var panel3 = ui.Panel([downloadButton3, urlLabel3]);
      var img33 = slicename.select('NDCI_class').clip(region1)
      function downloadImg33() {
        var downloadArgs33 = {
          name: 'NDCI_image',
          crs: 'EPSG:3857',
          scale: 90,
          maxPixels: 1e13,
          region: region1.geometry()
       };
       var url33 = img33.getDownloadURL(downloadArgs33);
       urlLabel33.setUrl(url33);
       urlLabel33.style().set({shown: true});
      }
      var downloadButton33 = ui.Button('TSI Class (90m)', downloadImg33);
      var urlLabel33 = ui.Label('Download', {shown: false});
      var panel33 = ui.Panel([downloadButton33, urlLabel33]);
      var legendDownload = ui.Panel({
        layout: ui.Panel.Layout.flow('horizontal'),
        style: {
          position: 'bottom-right',
          padding: '8px 15px'
        }
        });
      var legend = legendDownload.add(panel).add(panel999).add(panel1).add(panel11).add(panel3).add(panel33)
      Map.add(legend);
    //////////////////////////////////////////// Cria o Inspector (o usuário clica na imagem e obtem valores do pixel clicado)  
    var header = ui.Label('Inspector', {fontWeight: 'bold', fontSize: '15px'})
    var toolPanel = ui.Panel([header], 'flow', {width: '200px', position: 'bottom-right'});  
    var dataset = ee.Image(chla1.clip(region1))
    Map.onClick(function(coords) {
      var location = 'lon: ' + coords.lon.toFixed(3) + ' ' +
                     'lat: ' + coords.lat.toFixed(3);
      var click_point = ee.Geometry.Point(coords.lon, coords.lat);
      var demValue = dataset.reduceRegion(ee.Reducer.first(), click_point, 90).evaluate(function(val){
        var demText = 'Chla: ' + val.Chla.toFixed(2) + '   ' + 'NDCI: ' + val.NDCIn_mean.toFixed(2);
        toolPanel.widgets().set(2, ui.Label(demText));
      });
      toolPanel.widgets().set(1, ui.Label(location));
    // Edit: To be temporary, the "loading..." panel number has to be the same as the demText panel number (changed from 1 to 2).
      toolPanel.widgets().set(2, ui.Label("loading..."));
      Map.add(toolPanel);
    });
          } 
        }
///////////////////// ADICIONAR GEOMETRIA  /////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function chartNdviTimeSeries(fromDate, toDate, Month1, Month2) {
  var JRC = ee.Image('JRC/GSW1_0/GlobalSurfaceWater');    
  var JRC = JRC.select('occurrence')
  var BB_mask = JRC.updateMask(JRC.gte(50));
  ///////////// Get the Dates
  var Ano11 = Ano1.getValue()
  fromDate = Anos[Ano11]
  var Ano22 = Ano2.getValue()
  toDate = Anos[Ano22]
  var Mes11 = Mes1.getValue()
  Month1 = Meses[Mes11]
  var Mes22 = Mes2.getValue()
  Month2 = Meses[Mes22]
  // Get the drawn geometry; it will define the reduction region.
  var aoi = drawingTools.layers().get(0).getEeObject();
  // Set the drawing mode back to null; turns drawing off.
  drawingTools.setShape(null);
  // Reduction scale is based on map scale to avoid memory/timeout errors.
  var mapScale = Map.getScale();
  var scale = mapScale > 5000 ? mapScale * 2 : 5000;
  //////////////////////////////////////// Sentinel for Turbidity ////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////////////////
  var from_Date = ee.Date.fromYMD(fromDate,Month1,1)
  var to_Date = ee.Date.fromYMD(toDate,Month2,29)
      //// Imagens Sentinel com Máscara de Núvens
      var s2Clouds = ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY').filterBounds(aoi).filterDate(from_Date, to_Date);
      var s2_orig = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED').filterBounds(aoi).filterDate(from_Date, to_Date);
      //print(s2Clouds)
      var MAX_CLOUD_PROBABILITY = 10;
      function maskClouds(img) {
        var clouds = ee.Image(img.get('cloud_mask')).select('probability');
        var isNotCloud = clouds.lt(MAX_CLOUD_PROBABILITY);
        return img.updateMask(isNotCloud);
      }
      function maskEdges(s2_img) {
        return s2_img.updateMask(
            s2_img.select('B8A').mask().updateMask(s2_img.select('B9').mask()));
      }
      s2_orig = s2_orig.map(maskEdges);
      s2Clouds = s2Clouds;
      var s2SrWithCloudMask = ee.Join.saveFirst('cloud_mask').apply({
        primary: s2_orig,
        secondary: s2Clouds,
        condition:
            ee.Filter.equals({leftField: 'system:index', rightField: 'system:index'})
      });
      var s2CloudMasked =
          ee.ImageCollection(s2SrWithCloudMask).map(maskClouds);
      function bandcor (img) {
        var band4 = img.select('B4').multiply(0.935).add(101.52).rename('B4');
        var band5 = img.select('B5').multiply(0.9086).add(75.575).rename('B5');
        var band12 = img.select('B12').multiply(0.8943).rename('B12');
        var band44 = img.select('B4').rename('B44');
        var band55 = img.select('B5').rename('B55');
        var band1212 = img.select('B12').rename('B1212');
        return img.addBands([band4, band5, band12, band44, band55, band1212], ['B4', 'B5', 'B12', 'B44', 'B55', 'B1212'], true).updateMask(BB_mask)//.updateMask(mask_cloud)//.updateMask(mask_agua)//
            .select(['B3', 'B4', 'B5', 'B8', 'B12', 'B44', 'B55', 'B1212'])
            .copyProperties(img, ['system:index', 'system:time_start']);
                  }
      function NDCI2(image) {
          var glint = image.subtract(image.select('B12'))
          var NDCIn = glint.normalizedDifference(['B5', 'B4']);
          var NDCIname = NDCIn.rename(['NDCIn_mean']).updateMask(BB_mask.selfMask());
        return image.addBands(NDCIname).copyProperties(image, ['system:index', 'system:time_start']);
      } 
      function DATA2(img) {
        var date  = ee.Date(img.get('system:time_start'));
        var date_daily = date.format('YYYY-MM-dd');
        return img.set('eedate', ee.Date.fromYMD(date.get('year'), date.get('month'), date.get('day')))
                  .set('year', (date.get('year')))
                  .set('month', (date.get('month')))
                  .set('day', (date.get('day')))
      }
      function DATA(image) {
        var image_data = image.set('eedate', ee.Date.fromYMD(image.get('year'),image.get('month'),image.get('day')))
         return image_data.select(['NDCIn_mean']);
      } 
      function FACTOR(image) {
         return image.select('NDCIn_mean').divide(1000).copyProperties(image,['system:asset_size', 'year', 'month', 'day', 'eedate', 'system:index']);
      } 
      var SIAC_data = col.map(DATA).map(FACTOR).sort('eedate', false);
      var sen2cor_data = s2CloudMasked.map(bandcor).map(NDCI2).map(DATA2).sort('eedate', false); //nagel
      var col_data = sen2cor_data.select(['NDCIn_mean', "B4"]) //SIAC_data.merge(sen2cor_data.select(['NDCIn_mean', "B4"]).distinct('eedate'))
  // Get the NDCI information
  function DATA(image) {
    var image_data = image.set('eedate', ee.Date.fromYMD(image.get('year'),image.get('month'),image.get('day')))
     return image_data.select('NDCIn_mean');
  } 
  function FACTOR(image) {
     return image.select('NDCIn_mean').divide(1000).copyProperties(image,['system:asset_size', 'year', 'month', 'day', 'eedate', 'system:index']  );
  } 
  var collection1 = col.map(DATA).map(FACTOR)
                    .filterMetadata("year","less_than",toDate + 1)
                    .filterMetadata("year","greater_than",fromDate - 1)
                    .filterMetadata("month","less_than",Month2 + 1)
                    .filterMetadata("month","greater_than",Month1 - 1)
                    .filter(ee.Filter.neq('system:band_names', []));
  ////////// Função para calcular o TSS 
  var TSS = function(image) {
      var TSSn = image.expression(
      '((RED/2.64)**(1/0.45)) + 2.27', {
        'RED': image.select('B4').multiply(0.01)
        //'SWIR': image.select('B11') });
      })
      var TSSname = TSSn.rename(['TSSn']);
    return image.addBands(TSSname).copyProperties(image);
  } 
  var TSS = col_data.map(TSS).filter(ee.Filter.neq('system:band_names', [])) 
  print(TSS)
  //Map.addLayer(TSS.select('TSSn').mean().clip(region3).updateMask(BB_mask), vis, 'TSSn MEAN', false) // Mexido
  //Map.addLayer(TSS.select('TSSn').min().clip(region3).updateMask(BB_mask), vis, 'TSSn MINIMUM', false)
  //Map.addLayer(TSS.select('TSSn').max().clip(region3).updateMask(BB_mask), vis, 'TSSn MAXIMUM', false)
  //////////Função para calcular o Chla
  var decision_tree = function(image){                                              //// Calculate the Chla 
    var NDCI = image.select('NDCIn_mean').updateMask(JRC.gte(50))
    var Bloom = NDCI.gte(0.025).rename('Bloom')
    var chla = image.expression(
      '(24.49 * ((NDCI + 1) ** 7.48))', {
        'NDCI': image.select('NDCIn_mean'),
      });
    var chla = chla.rename('Chla');
    return chla.addBands(NDCI).addBands(Bloom).copyProperties(image); 
  };
  var chla = collection1.map(decision_tree).filter(ee.Filter.neq('system:band_names', []))
  // Get the drawn geometry; it will define the reduction region.
  var aoi = drawingTools.layers().get(0).getEeObject();
  // Set the drawing mode back to null; turns drawing off.
  drawingTools.setShape(null);
  // Reduction scale is based on map scale to avoid memory/timeout errors.
  var mapScale = Map.getScale();
  var scale = mapScale > 5000 ? mapScale * 2 : 5000;
  /// Create a monthly TSI Time Series
  var months = ee.List.sequence(Month1, Month2);
  var years = ee.List.sequence(fromDate, toDate);
  var byMonthYear = ee.ImageCollection.fromImages(
  years.map(function(y) {
    return months.map(function (m) {
      return chla
        .filterMetadata("month","equals", m)
        .filterMetadata("year","equals", y)
        .mean()
        .set('month', m).set('year', y)
        .set('Date', ee.Date.fromYMD(y, m, 1, null))
  });
  }).flatten());
  byMonthYear = byMonthYear.filter(ee.Filter.neq('system:band_names', []))
  // Cria uma série de dados mensais
  function NDCI_class(image) {
  var slice = image.select('NDCIn_mean')
  var Hyper = slice.gte(0.1265).rename('E - Hyper')
  var Super = slice.gte(0.0245).and(slice.lt(0.1265)).rename('D - Super')
  var Eutrofico = slice.gte(-0.0934).and(slice.lt(0.0245)).rename('C - Eutrophic')
  var Meso = slice.gte(-0.13).and(slice.lt(-0.0934)).rename('B - Meso')
  var Oligo = slice.gte(-0.30).and(slice.lt(-0.13)).rename('A - Oligo')
  return image.addBands([Oligo, Meso, Eutrofico, Super, Hyper])}
  var classe = byMonthYear.map(NDCI_class)
  var classeDaily = chla.map(NDCI_class).select(['A - Oligo', 'B - Meso', 'C - Eutrophic', 'D - Super', 'E - Hyper'])
  var classes = classe.select(['A - Oligo', 'B - Meso', 'C - Eutrophic', 'D - Super', 'E - Hyper'])
  //// Get Landsat Temperature 
  function prepSrL8(image) {
    // Develop masks for unwanted pgixels (fill, cloud, cloud shadow).
    var qaMask = image.select('QA_PIXEL').bitwiseAnd(parseInt('11111', 2)).eq(0);
    var saturationMask = image.select('QA_RADSAT').eq(0);
    var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
    var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
    return image.addBands(opticalBands, null, true)
                .addBands(thermalBands, null, true)
                .updateMask(qaMask)
                .updateMask(saturationMask)
                .updateMask(BB_mask)
                .select('ST_B10')
                .multiply(0.1)
                .copyProperties(image, ["system:time_start"]);
}
  var Landsat_9 = ee.ImageCollection("LANDSAT/LC09/C02/T1_L2")
                  .filterBounds(aoi)
                  .filter(ee.Filter.calendarRange(fromDate, toDate, 'year'))
                  .filter(ee.Filter.calendarRange(Month1, Month2, 'month'))
                  .filter(ee.Filter.lt('CLOUD_COVER', 80))
                  .map(prepSrL8)
  var Landsat_8 = ee.ImageCollection('LANDSAT/LC08/C02/T1_L2')
                    .filterBounds(aoi)
                    .filter(ee.Filter.calendarRange(fromDate, toDate, 'year'))
                    .filter(ee.Filter.calendarRange(Month1, Month2, 'month'))
                    .filter(ee.Filter.lt('CLOUD_COVER', 80))
                    .map(prepSrL8)
  var LANDSAT = Landsat_8.merge(Landsat_9).sort('system:time_start', true)
  ////// Charts
  var chart =
    ui.Chart.image
        .series({
          imageCollection: chla.select('Chla'),
          region: aoi,
          reducer: ee.Reducer.mean(),
          scale: 20,
          xProperty: 'eedate'
        })
        .setChartType('ScatterChart')
        .setOptions({
          title: 'Chl-a',
          hAxis: {title: 'Date', titleTextStyle: {italic: false, bold: true}},
          vAxis: {
            title: '   ',
            titleTextStyle: {italic: false, bold: true}
          },
          lineWidth: 5,
          colors: ['green'],
          curveType: 'function'
        });
   var chart_Turbidity =
    ui.Chart.image
        .series({
          imageCollection: TSS.select("TSSn"),
          region: aoi,
          reducer: ee.Reducer.mean(),
          scale: 20,
          xProperty: 'system:time_start'
        })
        .setChartType('ScatterChart')
        .setOptions({
          title: 'TSS',
          hAxis: {title: 'Date', titleTextStyle: {italic: false, bold: true}},
          vAxis: {
            title: 'TSS (mg/l)',
            titleTextStyle: {italic: false, bold: true}
          },
          colors: ['orange'],
        });
  var chart_temp = ui.Chart.image.series({
                            imageCollection: LANDSAT,
                            region: aoi,
                            reducer: ee.Reducer.mean(),
                            scale: 30,
                            xProperty: 'system:time_start',
                          })
          .setChartType('ScatterChart')
          .setOptions({
          title: 'Temperature ',
          hAxis: {title: 'Date', titleTextStyle: {italic: false, bold: true}},
          vAxis: {
            title: 'Graus Celsius',
            titleTextStyle: {italic: false, bold: true}
          },
          colors: ['red'],
        });
  var chart1 = ui.Chart.image.series({
                          imageCollection: classes.filter(ee.Filter.neq('system:band_names', [])),
                          region: aoi,
                          reducer: ee.Reducer.first(),
                          scale: 20,
                          xProperty: 'Date',
                        })
                        .setChartType('ColumnChart')
                        .setOptions({
                          title: 'TSI',
                          isStacked: 'relative',
                          hAxis: {title: 'Date', titleTextStyle: {italic: false, bold: true}},
                          vAxis: {
                            title: 'Classes percentage (relative)',
                            titleTextStyle: {italic: false, bold: true}
                          },
                          colors: ['#0000FF', '#00FFFF', '#008000', '#FFBF00', '#FF0000'], // Arrumado
                          curveType: 'function',
                          bar: {groupWidth: '1000%'}
                        });
  //panelChart.clear()
  //panelChart2.clear()
  ///panel3.add(ui.Panel([chart, chart_temp]))
  var LABEL_STYLE1 = {
    color: '#ff0000',
    fontSize: '15px',
  };
  if (Chla_Graph.getInfo()){
  panel3.add(chart)
  }
  if (Temp_Graph.getInfo()){
  panel3.add(chart_temp)
  }
  if (Turb_Graph.getInfo()){
  panel3.add(chart_Turbidity)
  }
  //.add(ui.Panel(select)).add(ui.Panel([lon, lat, buttonCoord], ui.Panel.Layout.flow('horizontal')))
  //panelChart2.clear()
  //panelChart2.add(ui.Panel([chart, chart1], ui.Panel.Layout.flow('horizontal')))
} //////////////////////////////////////
var panel3 = ui.Panel({
style:{position: 'bottom-right', width:"400px",backgroundColor:"white"} })
var panel4 = ui.Panel({
style:{position: 'bottom-center'}})
///////////////////////////////////////////////////////////////////// Create a Panel and widgets //////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////// Panel principal
var panel = ui.Panel({
  style:{position: 'top-left', width:"460px",backgroundColor:"white", border:"2px solid black"} })
////////////////////////// Texto introdutório do Panel
var intro = ui.Panel([
  ui.Label({
    value: 'Algae Bloom Monitoring System - Latin America',
    style: {fontSize: '18px', fontWeight: 'bold'}
  }),
  ui.Label('         ')]);
/////////////////////////// Select the region  
var LABEL_Titulo = {
  fontWeight: 'bold',
  textAlign: 'center',
  fontSize: '30px',
  padding: '2px',
  color: '#3385ff'
};
var Titulo = ui.Label('AlgaeMap Amazônia - Suriname e Guiana Francesa', LABEL_Titulo)
var Region_interest_label = ui.Label('1 - Select the region of interest', LABEL_STYLE)
var select = ui.Select({
  items: Object.keys(List),
  onChange: getDate,
  placeholder: "Select a Region of Interest",
  style: {stretch: 'horizontal', maxHeight: '24px'},})
///////////////////////////// Botão para zoom em uma coordenada 
var lon = ui.Textbox({
  placeholder: 'Longitude, ex. -64.731',
  style: {maxWidth: 10, width: 10, whiteSpace: 'pre'},
  onChange: function(value) {
    // set value with a dedicated method
    lon.setValue(value);
    return(value);
  }
});
var lat = ui.Textbox({
  placeholder: 'Latitude, ex. -30.778',
  style: {maxWidth: 10, width: 10, whiteSpace: 'pre'},
  onChange: function(value) {
    // set value with a dedicated method
    lat.setValue(value);
    return(value);
  }
});
var Lo;
var La;
var buttonCoord = ui.Button({
  label: 'Zoom(opt.)',
  onClick: function() {
    Lo = parseFloat(lon.getValue());
    La = parseFloat(lat.getValue());
    Map.setCenter(Lo, La, 15);
    var point = ee.Geometry.Point([Lo, La]);
    Map.addLayer(point, {},'Point')
  }
});
//////// Label para dizer que se inicia o Temporal Analysis 
var Temporal_analysis = ui.Label('Temporal Analysis', LABEL_STYLE1)
////////////////////////// Select the Months
var season_2_name = ui.Label('3 - Select month interval', LABEL_STYLE)
var Meses = {
  'January' : 1,
  'February' : 2,
  'March' : 3,
  'April': 4, 
  'May': 5, 
  'June': 6,
  'July': 7, 
  'August': 8,
  'September': 9,
  'October': 10,
  'November': 11,
  'December': 12};
var Mes1 = ui.Select({
  placeholder: "Jan - Dec",
  value: Object.keys(Meses)[0],
  items: Object.keys(Meses),})
var Mes2 = ui.Select({
  placeholder: "Jan - Dec",
  value: Object.keys(Meses)[11],
  items: Object.keys(Meses),})
/////////////////// Select the years
var season_1_name = ui.Label('2 - Select year interval', LABEL_STYLE)
var Anos = {
  '2015' : 2015,
  '2016' : 2016,
  '2017' : 2017,
  '2018': 2018, 
  '2019': 2019, 
  '2020': 2020,
  '2021': 2021,
  '2022': 2022,
  '2023': 2023,
  '2024': 2024// Mexido
};
var Ano1 = ui.Select({
  placeholder: "2015 - 2024",
  value: Object.keys(Anos)[5],
  items: Object.keys(Anos),})
var Ano2 = ui.Select({
  placeholder: "2015 - 2024",
  value: Object.keys(Anos)[5],
  items: Object.keys(Anos),})
/////////////////// Botão para calcular a Time-Series
var button = ui.Button({
  label: "Calculate Spatial Stats. (Optional, otherwise go to 5)",
  onClick: updateMap,     ////////////////// Quero colocar getDate junto
  style: {stretch: 'horizontal', maxHeight: '24px'}
})
/////////////////// Gráficos 
/////////// Definir o buffer das geometrias
var Variables = ui.Label('4 - Graph Analysis (enter buffer and scale and then go to 6)', LABEL_STYLE)
//////////////////////// Check the parameters ////////////////
var Chla_Graph = ee.Number(0)
var checkBox_chart_Chla = ui.Checkbox({
label: "Chla",
onChange:(function(checked) {
  if (checked) {
    Chla_Graph = ee.Number(1);
    return Chla_Graph 
        }
  else {
    Chla_Graph = ee.Number(0);
    return Chla_Graph
  }
})}).setValue(true)
var Temp_Graph = ee.Number(0)
var checkBox_chart_Temp = ui.Checkbox({
label: "Temperature",
onChange:(function(checked) {
  if (checked) {
    Temp_Graph = ee.Number(1);
    return Temp_Graph 
        }
  else {
    Temp_Graph = ee.Number(0);
    return Temp_Graph
  }
})}).setValue(false)
var Turb_Graph = ee.Number(0)
var checkBox_chart_Turb = ui.Checkbox({
label: "TSS",
onChange:(function(checked) {
  if (checked) {
    Turb_Graph = ee.Number(1);
    return Turb_Graph
        }
  else {
    Turb_Graph = ee.Number(0);
    return Turb_Graph
  }
})}).setValue(false)
/////// Desenhar as geometrias (Essa função possibilita o usuário desenhar a geometria no mapa, e mostra a geometria desenhada) - Não sei como funciona. 
var drawingTools = Map.drawingTools();
drawingTools.setShown(false);
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
var dummyGeometry =
    ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: '23cba7'});
drawingTools.layers().add(dummyGeometry);
function clearGeometry() {
  var layers = drawingTools.layers();
  layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
}
function drawPolygon() {
  clearGeometry();
  drawingTools.setShape('polygon');
  drawingTools.draw();
}
function drawPoint() {
  clearGeometry();
  drawingTools.setShape('point');
  drawingTools.draw();
}
var chartPanel = ui.Panel({
  style:
      {height: '235px', width: '600px', position: 'bottom-right', shown: false}
});
drawingTools.onDraw(ui.util.debounce(chartNdviTimeSeries, 500));
drawingTools.onEdit(ui.util.debounce(chartNdviTimeSeries, 500));
var symbol = {
  point: '📍',
};
var LABEL_STYLE = {
  fontWeight: '300',
  textAlign: 'center',
  fontSize: '14px',
  padding: '2px',
};
var LABEL_STYLE1 = {
  fontWeight: '300',
  textAlign: 'center',
  fontSize: '20px',
  padding: '2px',
};
var controlPanel = ui.Panel({
  widgets: [
    ui.Label('5 - Draw for Time Series', LABEL_STYLE),
    ui.Button({
      label: symbol.point + ' Point',
      onClick: drawPoint,
      style: {stretch: 'vertical'}
    }),
  ],
  style: {position: 'bottom-left'},
  layout: ui.Panel.Layout.flow('horizontal'),
});
Map.add(chartPanel);
///////////// Panels para os gráficos
var panel1 = ui.Panel({
  style:{width:"450px",backgroundColor:"white"} 
})
var panelChart = ui.Panel({
  style:{width:"450px",backgroundColor:"white"} 
})
var panelChart2 = ui.Panel({
  style:{width:"450px",backgroundColor:"white"} 
})
/////// Escritas em branco para dar espaçamento 
var Nothing = ui.Label('                         ', LABEL_STYLE)
var Nothing1 = ui.Label('                         ', LABEL_STYLE)
/////// Link do tutorial do App
var link = (ui.Label('App Tutorial').setUrl('https://wp.ufpel.edu.br/geotechidrica/algaemap-4/'))
////////// Reset Graph 
var clearMap = ui.Label('6 - Clear the Map', LABEL_STYLE)
var submit = ui.Button({
label: 'Delete Graphs',
onClick: function() {
  panel3.clear()
  panel4.clear()
}
});     
//////// Adicionar todos os widgets dentro do Panel
ui.root.add(panel.add(Titulo).add(link).add(Region_interest_label)
  .add(ui.Panel(select)).add(ui.Panel([lon, lat, buttonCoord], ui.Panel.Layout.flow('horizontal')))
  .add(ui.Panel(Temporal_analysis)).add(ui.Panel([season_1_name, Ano1, Ano2], ui.Panel.Layout.flow('horizontal'))).add(ui.Panel([season_2_name, Mes1, Mes2], ui.Panel.Layout.flow('horizontal'))).add(ui.Panel([button], ui.Panel.Layout.flow('horizontal')))
  .add(Nothing).add(Variables).add(ui.Panel([checkBox_chart_Chla, checkBox_chart_Turb, checkBox_chart_Temp], ui.Panel.Layout.flow('horizontal')))
  .add(controlPanel).add(panelChart2).add(panelChart)
  .add(ui.Panel([clearMap, submit], ui.Panel.Layout.flow('horizontal')))                  )
ui.root.add(panel3)
ui.root.add(panel4)