var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -77.13832635879518,
                45.847280996243114
              ],
              [
                -77.13832635879518,
                44.85909790309917
              ],
              [
                -75.02895135879518,
                44.85909790309917
              ],
              [
                -75.02895135879518,
                45.847280996243114
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-77.13832635879518, 45.847280996243114],
          [-77.13832635879518, 44.85909790309917],
          [-75.02895135879518, 44.85909790309917],
          [-75.02895135879518, 45.847280996243114]]], null, false);
// LEAF-Toolbox-SL2P  
//     
/* GEE Javascript implementation of the   
   Simplified Level 2 Processor of Weiss and Baret (2016). 
 UPDATES:
 April 13,2021 - GEE dropped support for using bind when mapping functions over ee.List.sequence
                 Changed all such calls to use currying.  
                 Updated toolsNets, toolsNetsUtils, utilsNets with curried functions.
                 The old version of code corresponds to April 12, 2021 if GEE decides to allow it again.  RF
 Input: Collection of either Landsat 5 or Landsat 7 or Landsat 8 
        or Sentinel 2a or Sentinel 2b surface reflectance products.
        Imported EE asset with polygon features used to define spatial output region.
        By default only the first polygon is used.  However, you can change the feature number
        in the first line of the script.
        Links toEE assets networks and a land cover map using the
        North American Land Cover 2015 30m legend.
        http://www.cec.org/tools-and-resources/map-files/land-cover-30m-2015-landsat-and-rapideye
        By default the SL2P algorithm is implemented for supported collections.
        To use other algorithms comment out the SL2P algorithm assets below and 
        uncomment the desired algorithm ( e.g. CCRS) and run the code.
 Output: Unsigned int16 geotiff with layers
            1.  Estimate scaled by 1000
            2.  Standard error of estimates caled by 1000
            3.  Network number 
            4.  Quality control flags coded in binary flags
            5.  Land cover class
            6.  Days since January 1, 1970 inclusive
          One of the following quantities are estimated 
          Albedo: Black sky albedo at 10:30 local time.
          D:      Directional canopy scattering factor.
          fAPAR:  Fraction of absorbed photosynthetically active radiation, black sky at 10:30 local time.
          fCover: Fraction of canopy cover.
          LAI:    Leaf area index.
          CCC:    Canopy chlorophyll content.
          CWC:    Canopy water content.
.                                        */
/*--------------------------------------------------------------------------------*/
/*Start of user specification                                                     */
/*--------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------*/
/* Region of interest , optional                                                  */
/*--------------------------------------------------------------------------------*/
//var table = ee.FeatureCollection('users/hemitshah/Envelope_LCC')
//var featureNumber = ee.Number(0);
//var geometry = ee.FeatureCollection(ee.Feature(table.toList(table.size()).get(featureNumber))).geometry();
//returns image with single band named networkid corresponding given 
// input partition image remapped to networkIDs
// applies a set of shallow networks to an image based on a provided partition image band
var wrapperNNets = function(network, partition, netOptions, colOptions, suffixName, imageInput){
  //print('wrappernets')
  // typecast function parameters
  var network = ee.List(network);
  var partition = ee.Image(partition);
  var netOptions = netOptions;
  var colOptions = colOptions;
  var suffixName = suffixName;
  var imageInput = ee.Image(imageInput);
  //print(network)
  //print(partition)
  //print(netVariable)
  //print(colOptions)
  //print(suffixName)et
  //print(imageInput)
  // parse partition  used to identify network to use
  partition = partition.clip(imageInput.geometry()).select(['partition']);
  // determine networks based on collection
  var netList = ee.List(network.get(ee.Number(netOptions.variable).subtract(1))); 
  //print(netList);
  // parse land cover into network index and add to input image
  imageInput = imageInput.addBands(app.Nets.makeIndexLayer(partition,colOptions.legend,colOptions.Network_Ind));
  //print(imageInput);
  // define list of input names
  return(ee.ImageCollection(ee.List.sequence(0, netList.size().subtract(1))
                                                    .map(app.Nets.selectNet2(imageInput,netList,netOptions.inputBands))
                                                    .map(app.Nets.applyNet2(suffixName+app.vis.select.getValue())))
                                .max()
                  .addBands(partition))
                  .addBands(imageInput.select('networkID'));
};
/*--------------------------------------------------------------------------------*/
/* Start of Helper functions                                                      */
/*--------------------------------------------------------------------------------*/
// convert number to string for mapping onto list
var toString = function(number) {
  return(ee.String(number));
};
/*--------------------------------------------------------------------------------*/
/* End  of Helper functions                                                      */
/*--------------------------------------------------------------------------------*/
// The namespace for our application.  All the state is kept in here.
var app = {};
// Applies the selection filters currently selected in the UI. 
app.applyFilters = function() {
  // set message we are loading images
  app.setLoadingMode(true);
  // Refresh the map layer.
  //app.refreshMapLayer();
  // Set filter variables.
  //Change to only take the first in the collection for debugging
  var start = app.filters.startDate.getValue();
  var end = app.filters.endDate.getValue();
  var filtered = ee.ImageCollection(app.filters.selectCollection.getValue())
                   .filterBounds(app.filters.mapBounds)
                   .filterDate(start[1], end[1])
                   .filterMetadata((app.COLLECTION_OPTIONS[app.filters.selectCollection.getValue()]).Cloudcover,'less_than',app.filters.maxCloudcover.getValue())
                   .filterMetadata((app.COLLECTION_OPTIONS[app.filters.selectCollection.getValue()]).Watercover,'less_than',ee.Number(100))
                   .limit(5000);
  // Display how many granules were found 
  print('Found product granules');
  print(filtered);
  // Get the list of computed ids.
  var computedIds = filtered.limit(app.IMAGE_COUNT_LIMIT)
                            .reduceColumns(ee.Reducer.toList(), ['system:index'])
                            .get('list');
  // updathe the UI and proceed only if we get products
  computedIds.evaluate(function(ids) {
    // Update the image picker with the given list of ids.
    app.setLoadingMode(false);
    app.picker.select.items().reset(ids);
    // Default the image picker to the first id.
    app.picker.select.setValue(app.picker.select.items().get(0));
    // Disable the all images checbox
    app.picker.allImages.setValue(false);
  });
    // Refresh the map layer.
  app.refreshMapLayer();
};
var ExportCol = function(col, folder, scale, type, nimg, maxPixels) {
  type = type || "float";
  nimg = nimg || 100;
  scale = scale || 20;
  maxPixels = maxPixels || 1e10;
  print('in exportcol')
  print(col)
  print(scale)
  print(type)
  print(nimg)
  print(maxPixels)
  var colList = col.toList(nimg);
  var n = colList.size().getInfo();
  for (var i = 0; i < n; i++) {
    // restrict image to map bounds
    var img = ee.Image(colList.get(i));
    var imgBounds = app.filters.mapBounds.intersection(img.geometry(),10) ;
    // determine fi there are any valid values by checking for a null return om a reduces
    if ( img.select('timestart').reduceRegion({ reducer: ee.Reducer.max(), geometry: imgBounds, scale: 100}) !== null) {
      print('exporting')
      var id = img.id().getInfo() + "_" + app.vis.select.getValue();
      // set up type conversions
      var imgtype = {"float":img.toFloat(),  
                     "byte":img.toByte(), 
                     "unsigned int8":img.toByte(),
                     "unsigned int16":img.toUint16(),
                     "int":img.toInt(),
                     "double":img.toDouble(),
                     "unsigned int32":img.toUint32()
                    };
        print(imgtype[type])
        print(id)
        print(app.folder[0])
        print(scale)
        print(imgBounds)
        print(app.pixels[0])
      // export image for map bounds only using desired type
      Export.image.toDrive({
        image:imgtype[type],
        description: id,
        folder: app.folder[0],
        fileNamePrefix: id,
        scale: scale,
        region: imgBounds,
        maxPixels: app.pixels[0]});
  }
  }
};
// Refreshes the current map layer based on the UI widget states. 
app.exportMapLayer = function() {
  print('in export')
  // subset collection to one image if required
  var colOptions = app.COLLECTION_OPTIONS[app.collectionName];
  var netOptions = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()];
  var start = app.filters.startDate.getValue();
  var end = app.filters.endDate.getValue();
  var midDate = ee.Number(start[0]).add(ee.Number(end[0])).divide(2);
  if (app.picker.allImages.getValue()) {
    // filter collection for all products 
    var filtered =  ee.ImageCollection(app.filters.selectCollection.getValue())
                      .filterBounds(app.filters.mapBounds)
                      .filterDate(start[0], end[0])
                      .filterMetadata(colOptions.Cloudcover,'less_than',app.filters.maxCloudcover.getValue())
                      .limit(5000)
                      .map(app.Utils.addDate)
                      .map(function(image){return image.clip(app.filters.mapBounds)})
                      .map(app.Utils.deltaTime.bind(null,midDate))
                      .sort('deltaTime');
    }
  else {
    // process selected image only 
    var filtered =  ee.ImageCollection(app.filters.selectCollection.getValue())
                      .filter(ee.Filter.eq('system:index',app.picker.select.getValue()))
                      .map(app.Utils.addDate)
                      .map(function(image){return image.clip(app.filters.mapBounds)})
                      .map(app.Utils.deltaTime.bind(null,midDate))
                      .sort('deltaTime');
    }
    print('filtered')
    print(filtered)
    // mask based on collection, add score fo quality mosaicing and angles
    switch (app.filters.selectCollection.getValue()) {
      case  'COPERNICUS/S2_SR':
        filtered =  filtered.map(app.S2.s2MaskClear).map(app.toolsMosaic.addSpecScore.bind(null,midDate)).map(app.S2.addS2Geometry.bind(null,colOptions));
      break;
      case  'LANDSAT/LC08/C01/T1_SR': 
        filtered = filtered.map(app.L8.l08MaskClear);
      break;
      case  'users/rfernand387/L2avalidation': 
        filtered = filtered.map(app.S2.ccrsSentinel2).map(app.S2.s2MaskClear).map(app.toolsMosaic.addSpecScore.bind(null,midDate)).map(app.S2.addS2Geometry.bind(null,colOptions));
      break;
      default: print('Invalid collection');
      break;
    }
    // process based on parameter value
    var exportRes = 10;
    switch (app.vis.select.getValue()) {
      case 'Surface_Reflectance':
        switch (app.filters.selectCollection.getValue()) {
          case  'COPERNICUS/S2_SR':
            exportRes = 10;
          break;
          case  'LANDSAT/LC08/C01/T1_SR': 
            exportRes = 30;
          break;
          case  'users/rfernand387/L2avalidation': 
            exportRes = 10;
          break;
          default: print('Invalid collection');
          break;
        }
      print('starting exports')
      // Export data
      switch(app.exportID){
        case 'Image by Image':
          var export_image = ExportCol(filtered, 'Image_Export', exportRes,"unsigned int16",100);
        break;
        case 'Full Map Mosaic':
          filtered = filtered.qualityMosaic('spec_score');
          filtered = filtered.clip(app.filters.mapBounds.intersection(filtered.geometry(),10));
          Export.image.toDrive({
               image:  filtered.toUnit16(),
               description:app.collectionName.replace('/','_') + "_" + start[0] + "_" + end[0] + "_" + app.vis.select.getValue(),
               folder: app.folder[0],
               scale:exportRes,
               maxPixels: app.pixels[0]
           });
        break;
        default: print('Invalid choice');
        break;
      }
      break;
      default:
    // mask non land vegetated areas
    switch (app.filters.selectCollection.getValue()) {
      case  'COPERNICUS/S2_SR':
        filtered =  filtered.map(app.S2.s2MaskLand);
        exportRes = 20;
      break;
      case  'LANDSAT/LC08/C01/T1_SR': 
        filtered =  filtered.map(app.L8.l08MaskLand);
        exportRes = 30;
      break;
      case  'users/rfernand387/L2avalidation': 
        filtered =  filtered.map(app.S2.s2MaskLand);
        exportRes = 20;
      break;
      default: print('Invalid collection');
      break;
      }
      //apply regression to estimate parameter
      print('starting sl2p')
      var partition = colOptions.partition.filterBounds(app.filters.mapBounds).mosaic().clip(app.filters.mapBounds).rename('partition');
      var scaledFiltered = filtered.map(app.Utils.scaleBands.bind(null,netOptions.inputBands,netOptions.inputScaling))
                          .map(app.Nets.invalidInput.bind(null,colOptions.sl2pDomain,netOptions.inputBands))
      //print(scaledFiltered)
      var estimateSL2P = scaledFiltered.map(wrapperNNets.bind(null,app.SL2P,partition, netOptions, colOptions,'estimate'))
      //print(estimateSL2P)
      var uncertaintySL2P = scaledFiltered.map(wrapperNNets.bind(null,app.errorsSL2P,partition, netOptions, colOptions,'error'))
      //print(uncertaintySL2P);
      print('done sl2p')
      print('starting exports')
      // Export data
      switch(app.exportID){
        case 'Image by Image':
          var export_image = ExportCol(scaledFiltered.select(['date','QC','spec_score']).combine(estimateSL2P).combine(uncertaintySL2P), 'Image_Export', exportRes,"unsigned int16",100);
        break;
        case 'Full Map Mosaic':
          mosaicBounds = app.filters.mapBounds.intersection(scaledFiltered.qualityMosaic('spec_score').geometry());
          scaledFiltered = scaledFiltered.select(['date','QC','spec_score']).combine(estimateSL2P).combine(uncertaintySL2P).clip(mosaicBounds).qualityMosaic('spec_score').select(['date','QC','estimate'+netOptions.Name,'error'+netOptions.Name,'networkID','partition']);
          Export.image.toDrive({
               image:  scaledFiltered.toUnit16(),
               description:app.collectionName.replace('/','_') + "_" + start[0] + "_" + end[0] + "_" + app.vis.select.getValue(),
               folder: app.folder[0],
               scale:exportRes,
               maxPixels: app.pixels[0],
           });
        break;
        default: print('Invalid choice');
        break;
      }
    break;
    }
};
/** Refreshes the current map layer based on the UI widget states. */
app.refreshMapLayer = function() {
  // clear map
  Map.clear();
  var colOptions = app.COLLECTION_OPTIONS[app.collectionName];
  var netOptions = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()];
  // print("colOptions", colOptions);
  //print("netOptions",netOptions);
  // subset collection to one image if required
  if (app.picker.select.getValue()) {
    var start = app.filters.startDate.getValue();
    var end = app.filters.endDate.getValue();
    var midDate = ee.Number(start[0]).add(ee.Number(end[0])).divide(2);
    if (app.picker.allImages.getValue()) {
      // filter collection for all products 
      var filtered =  ee.ImageCollection(app.filters.selectCollection.getValue())
                    .filterBounds(app.filters.mapBounds)
                    .filterDate(start[0], end[0])
                    .filterMetadata(colOptions.Cloudcover,'less_than',app.filters.maxCloudcover.getValue())
                    .limit(5000)
                    .map(app.Utils.addDate)
                    .map(function(image){return image.clip(app.filters.mapBounds)})
                    .map(app.Utils.deltaTime.bind(null,midDate))
                    .sort('deltaTime');
    }
    else {
      // process selected image only 
      var filtered =  ee.ImageCollection(app.filters.selectCollection.getValue())
                    .filter(ee.Filter.eq('system:index',app.picker.select.getValue()))
                    .map(app.Utils.addDate)
                    .map(function(image){return image.clip(app.filters.mapBounds)})
                    .map(app.Utils.deltaTime.bind(null,midDate))
                    .sort('deltaTime');
    }
    print('filtered')
    print(filtered)
    // mask based on collection, add score fo quality mosaicing and angles
    switch (app.filters.selectCollection.getValue()) {
      case  'COPERNICUS/S2_SR':
        filtered =  filtered.map(app.S2.s2MaskClear).map(app.toolsMosaic.addSpecScore.bind(null,midDate)).map(app.S2.addS2Geometry.bind(null,colOptions));
      break;
      case  'LANDSAT/LC08/C01/T1_SR': 
        filtered = filtered.map(app.L8.l08MaskClear);
      break;
      case  'users/rfernand387/L2avalidation': 
        filtered = filtered.map(app.S2.ccrsSentinel2).map(app.S2.s2MaskClear).map(app.toolsMosaic.addSpecScore.bind(null,midDate)).map(app.S2.addS2Geometry.bind(null,colOptions));
      break;
      default: print('Invalid collection');
      break;
    }
    // display based on parameter value
    switch (app.vis.select.getValue()) {
      case 'Surface_Reflectance':
        switch (app.filters.selectCollection.getValue()) {
          case  'COPERNICUS/S2_SR':
            filtered  = filtered.qualityMosaic('spec_score');
          break;
          case  'LANDSAT/LC08/C01/T1_SR': 
            filtered = filtered.mosaic();
          break;
          case  'users/rfernand387/L2avalidation': 
            filtered  = filtered.qualityMosaic('spec_score');
          break;
          default: print('Invalid collection');
          break;
        }
        // Just show a RgB composite
        Map.addLayer(filtered, { bands:'date'},'Date');
        Map.addLayer(filtered,  colOptions.visParams  , 'Surface_Reflectance');
      break;
      default:
    // mask non land vegetated areas
    switch (app.filters.selectCollection.getValue()) {
      case  'COPERNICUS/S2_SR':
        filtered =  filtered.map(app.S2.s2MaskLand);
      break;
      case  'LANDSAT/LC08/C01/T1_SR': 
        filtered =  filtered.map(app.L8.l08MaskLand);
      break;
      case  'users/rfernand387/L2avalidation': 
        filtered =  filtered.map(app.S2.s2MaskLand);
      break;
      default: print('Invalid collection');
      break;
      }
      //apply regression to estimate parameter
      print('starting sl2p')
      var partition = colOptions.partition.filterBounds(app.filters.mapBounds).mosaic().clip(app.filters.mapBounds).rename('partition');
      print(partition)
      var scaledFiltered = filtered.map(app.Utils.scaleBands.bind(null,netOptions.inputBands,netOptions.inputScaling))
                          .map(app.Nets.invalidInput.bind(null,colOptions.sl2pDomain,netOptions.inputBands))
      //print(scaledFiltered)
      var estimateSL2P = scaledFiltered.map(wrapperNNets.bind(null,app.SL2P,partition, netOptions, colOptions,'estimate'))
      //var estimateSL2P = ee.ImageCollection(wrapperNNets(app.SL2P,partition, netOptions, colOptions,'estimate',scaledFiltered.first()))
      //print(estimateSL2P)
      var uncertaintySL2P = scaledFiltered.map(wrapperNNets.bind(null,app.errorsSL2P,partition, netOptions, colOptions,'error'))
      //var uncertaintySL2P = ee.ImageCollection(wrapperNNets(app.errorsSL2P,partition, netOptions, colOptions,'error',scaledFiltered.first()))
      //print(uncertaintySL2P);
      // Mosaic after processing each product
      var mosaicResult = scaledFiltered.select(['date','QC','spec_score']).combine(estimateSL2P).combine(uncertaintySL2P).qualityMosaic('spec_score').clip(app.filters.mapBounds).select(['date','QC','estimate'+netOptions.Name,'error'+netOptions.Name,'networkID','partition']);
      //print(mosaicResult)
      print('done sl2p')
      //Displays the Collection of filtered images with the vis parameters 
      var visParams = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()]['outputParams'];
      var errorParams = app.VIS_OPTIONS[app.vis.select.getValue()][app.filters.selectCollection.getValue()]['errorParams'];
      Map.addLayer(mosaicResult, {bands:('partition'),min:0, max:20, palette:app.partitionPalettes.partitions.NALCMS[20]},'Partition');
      Map.addLayer(mosaicResult, { bands:'date'},'Date');
      Map.addLayer(mosaicResult, { bands:'QC'},'Quality Code'); 
      Map.addLayer(mosaicResult, {bands:('networkID'),min:0, max:20, palette:app.partitionPalettes.partitions.NALCMS[20]},'Network');
      Map.addLayer(mosaicResult, errorParams , netOptions.errorName);
      Map.addLayer(mosaicResult, visParams , netOptions.Name);
    break;
    }
  }
}
//  Creates the UI panels. 
app.createPanels = function() {
  // The introduction section. 
  app.intro = {
    panel: ui.Panel([
      ui.Label({
        value: 'LEAF Toolbox',
        style: {fontWeight: 'bold', fontSize: '24px', margin: '10px 5px'}
      }),
      ui.Label('This app allows you to display and export maps of  ' +
               'vegetation biophysical variables derived from the Sentinel 2 Multispectral Imager ' + 
               'or Landsat 8 Operational Land Imager .')
    ])
  };
  // The collection filter controls. 
  app.filters = {
    // Create a select with a function that reacts to the "change" event.
    selectCollection: ui.Select({
      items: Object.keys(app.COLLECTION_OPTIONS),
      onChange: function(value) {
        app.collectionName = value;      
        var numNets = ee.Number(ee.Feature(app.COLLECTION_OPTIONS[app.collectionName].Network_Ind.first()).propertyNames().remove('Feature Index').remove('system:index').remove('lon').size());
        // changed from bind to currying RF April 15, 2021
        app.SL2P = ee.List.sequence(1,ee.Number(app.COLLECTION_OPTIONS[value].numVariables),1).map(app.Nets.makeNetVars2(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2P,numNets));
        app.errorsSL2P = ee.List.sequence(1,ee.Number(app.COLLECTION_OPTIONS[value].numVariables),1).map(app.Nets.makeNetVars2(app.COLLECTION_OPTIONS[app.collectionName].Collection_SL2Perrors,numNets));
      }
    }),
    startDate: ui.DateSlider({start: '1985-04-01',value:[(ui.DateSlider()).getEnd()-1000*3600*24*30,(ui.DateSlider()).getEnd()-1000*3600*24*30]}),
    endDate: ui.DateSlider({start:  '1985-04-01'}),
    maxCloudcover: ui.Slider({min: 0,max: 100,step:10}).setValue(90),
    selectminLng: ui.Textbox({
        placeholder:'min Long', 
        onChange:function(value){
          app.filters.selectBoundingBox.setValue(false);
          app.minLng = value; 
          return(value)}
    }),
    selectminLat: ui.Textbox({
        placeholder:'min Lat',
        onChange:function(value){
          app.filters.selectBoundingBox.setValue(false);
          app.minLat = value; 
          return(value)}
    }),
    selectmaxLng: ui.Textbox({
        placeholder:'max Long', 
        onChange:function(value){
          app.filters.selectBoundingBox.setValue(false);
          app.maxLng = value;
          return(value)}
    }),
    selectmaxLat: ui.Textbox({
        placeholder:'max Lat', 
        onChange:function(value){
          app.filters.selectBoundingBox.setValue(false);
          app.maxLat = value; 
          return(value);}
    }),
    selectBoundingBox: ui.Checkbox({
      label: "Use bounding box for ROI",
      onChange: function() {
        app.filters.mapBounds = ee.Geometry(Map.getBounds(true));
        if (app.filters.selectBoundingBox.getValue() === true) {
          app.filters.selectGeometry.setValue(false);
          var geo= ee.Geometry.Rectangle(ee.Number.parse(app.minLng), ee.Number.parse(app.minLat), ee.Number.parse(app.maxLng), ee.Number.parse(app.maxLat));
          app.filters.mapBounds = geo;
          Map.centerObject(geo);
        }
        //app.refreshMapLayer;
      }
    }),
    selectGeometry: ui.Checkbox({
      label: "Use geometry for ROI",
      onChange: function() {
        app.filters.mapBounds = ee.Geometry(Map.getBounds(true));
        if (app.filters.selectGeometry.getValue() === true) {
          app.filters.selectBoundingBox.setValue(false);
          var geo = geometry;
          app.filters.mapBounds = geo;
          Map.centerObject(geo);
        }
        //app.refreshMapLayer;
      }
    }),
    applyButton: ui.Button('Apply filters', app.applyFilters),
    loadingLabel: ui.Label({
      value: 'Loading...',
      style: {stretch: 'vertical', color: 'gray', shown: false}
    })
  };
  // Default the selectCollection to the first value.
  app.filters.selectCollection.setValue(app.filters.selectCollection.items().get(0));
  // Default bounds to current map bounds.
  app.filters.mapBounds = ee.Geometry(Map.getBounds(true));
  // The panel for the filter control widgets.
  app.filters.panel = ui.Panel({
    widgets: [
      ui.Label('1) Select filters', {fontWeight: 'bold'}),
      ui.Label('Collection', app.HELPER_TEXT_STYLE), app.filters.selectCollection,
      ui.Label('Start date', app.HELPER_TEXT_STYLE), app.filters.startDate,
      ui.Label('End date', app.HELPER_TEXT_STYLE), app.filters.endDate,
      ui.Label('Maximum cloud cover', app.HELPER_TEXT_STYLE), app.filters.maxCloudcover,
      app.filters.selectminLng,
      app.filters.selectminLat,
      app.filters.selectmaxLng,
      app.filters.selectmaxLat,
      app.filters.selectBoundingBox,
      app.filters.selectGeometry,
      ui.Panel([
        app.filters.applyButton,
        app.filters.loadingLabel
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    style: app.SECTION_STYLE
  });
  // The product picker section. 
  app.picker = {
    // Create a select with a function that reacts to the "change" event.
    allImages: ui.Checkbox(
      {label: 'Process all products', value: false,
        onChange: app.refreshMapLayer
      }),
    select: ui.Select({
      placeholder: 'Select product',
      onChange: app.refreshMapLayer
    })
  };
  // The panel for the picker section with corresponding widgets. 
  app.picker.panel = ui.Panel({
    widgets: [
      ui.Label('2) Select products', {fontWeight: 'bold'}),
      ui.Panel([
        app.picker.select,
      ], ui.Panel.Layout.flow('horizontal')),
      app.picker.allImages,
    ],
    style: app.SECTION_STYLE
  });
// The visualization section. 
  app.vis = {
    label: ui.Label(),
    // Create a select with a function that reacts to the "change" event.
    select: ui.Select({
      items: Object.keys(app.VIS_OPTIONS),
      //items: Object.keys(app.COLLECTION_OPTIONS[app.filters.selectCollection.getValue()].VIS_OPTIONS),
      onChange: function() {
        // Update the label's value with the select's description.
        var option = app.VIS_OPTIONS[app.vis.select.getValue()];
        app.vis.label.setValue(option.description);
        // Refresh the map layer.
        app.refreshMapLayer();
      }
    })
  }; 
  // The panel for the visualisation section with corresponding widgets. 
  app.vis.panel = ui.Panel({
    widgets: [
      ui.Label('3) Select a variable to display', {fontWeight: 'bold'}),
      app.vis.select,
      app.vis.label
    ],
    style: app.SECTION_STYLE
  }); 
  app.vis.select.setValue(app.vis.select.items().get(0));
  // The export section. 
  app.export = {
    label: ui.Label(),
    // Create a select with a function that reacts to the "change" event.
    select: ui.Select({
      items: Object.keys(app.EXP_OPTIONS),
        // Update the label's value with the select's description.
        onChange: function(value){
        app.exportID = value; 
        } 
    }),
       textbox1: ui.Textbox({
        placeholder:'Enter folder name',
        onChange: function(text){
          app.folder = [''];
          app.folder[0] =  app.export.textbox1.getValue();
          print('Into Folder:', app.folder[0]);
        }
      }),
        textbox2: ui.Textbox({
        placeholder:'Enter Max Pixels',
        onChange: function(text){
          app.pixels = [0];
          app.pixels[0] = app.export.textbox2.getValue();
          print('Max Pixels:', app.pixels[0]);
        }
      }),
    exportButton: ui.Button({
      label:'Apply Export',  
      onClick: function(){
        app.exportMapLayer();
       }
      })
  };
  // The panel for the export section with corresponding widgets. 
  app.export.panel = ui.Panel({
    widgets: [
      ui.Label('4) Exporting Results to Drive', {fontWeight: 'bold'}),
      app.export.select,
      app.export.label,
      app.export.textbox1,
      app.export.textbox2,
      app.export.exportButton
    ],
    style: app.SECTION_STYLE
  });
   app.export.select.setValue(app.export.select.items().get(0));
};
// Creates the app helper functions. 
app.createHelpers = function() {
  /**
   * Enables or disables loading mode.
   * @param {boolean} enabled Whether loading mode is enabled.
   */
  app.setLoadingMode = function(enabled) {
    // Set the loading label visibility to the enabled mode.
    app.filters.loadingLabel.style().set('shown', enabled);
    // Set each of the widgets to the given enabled mode.
    var loadDependentWidgets = [
      app.vis.select,
      app.filters.startDate,
      app.filters.endDate,
      app.filters.maxCloudcover,
      app.filters.selectminLng,
      app.filters.selectminLat,
      app.filters.selectmaxLng,
      app.filters.selectmaxLat,
      app.filters.selectBoundingBox,
      app.filters.selectGeometry,
      app.filters.applyButton,
      app.export.exportButton
    ];
    loadDependentWidgets.forEach(function(widget) {
      widget.setDisabled(enabled);
    });
  };
};
// Creates the app constants. 
app.createConstants = function() {
  // palettes for display
  // generic palette
  app.palettes = require('users/gena/packages:palettes');
  // palettes for parition layer, should be deprecated
  app.partitionPalettes = require('users/rfernand387/exports:partitionPalettes');
  app.partitionMin = ee.Number(0);
  app.partitionMax = ee.Number(20);
    // load modules
  app.toolsMosaic = require('users/rfernand387/LEAFToolboxModules:toolsMosaic');
  app.batch = require('users/fitoprincipe/geetools:batch');
  //app.network = require('users/rfernand387/LEAFToolboxModules:SL2PNetworkOneNet');
  app.network = require('users/rfernand387/LEAFToolboxModules:SL2PNetworkv3');
  app.Utils = require('users/rfernand387/LEAFToolboxModules:toolsUtils');
  app.Nets = require('users/rfernand387/LEAFToolboxModules:toolsNets');
  app.NetsUtils = require('users/rfernand387/LEAFToolboxModules:toolsNetsUtils');
  app.S2 = require('users/rfernand387/LEAFToolboxModules:toolsS2');
  app.L8 = require('users/rfernand387/LEAFToolboxModules:toolsL8');
  app.NOW = Date.Now;
  app.COLLECTION_ID = 'COPERNICUS/S2';
  app.SECTION_STYLE = {margin: '20px 0 0 0'};
  app.HELPER_TEXT_STYLE = {
      margin: '8px 0 -3px 8px',
      fontSize: '12px',
      color: 'gray'
  };
  app.IMAGE_COUNT_LIMIT = 100;
   app.EXP_OPTIONS = {'Image by Image':{Order :1},
                     'Full Map Mosaic':{Order: 2}};
  app.COLLECTION_OPTIONS = {
    'COPERNICUS/S2_SR': {
      name: 'S2',
      description: 'Sentinel 2A',
      visParams: {gamma: 1.3, min: 0, max: 3000, bands: ['B4', 'B3', 'B2']},
      Cloudcover: 'CLOUDY_PIXEL_PERCENTAGE',
      Watercover: 'WATER_PERCENTAGE',
      sza: 'MEAN_SOLAR_ZENITH_ANGLE',
      vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
      saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
      vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
      VIS_OPTIONS: app.VIS_OPTIONS,
      Collection_SL2P: ee.FeatureCollection(app.network.s2_createFeatureCollection_estimates()),
      Collection_SL2Perrors: ee.FeatureCollection(app.network.s2_createFeatureCollection_errors()),  
      sl2pDomain: ee.FeatureCollection(app.network.s2_createFeatureCollection_domains()),
      Network_Ind: ee.FeatureCollection(app.network.s2_createFeatureCollection_Network_Ind()),
      partition: ee.ImageCollection(app.network.s2_createImageCollection_partition()),
      legend:  ee.FeatureCollection(app.network.s2_createFeatureCollection_legend()),
      numVariables: 7,
    },
    'LANDSAT/LC08/C01/T1_SR': {
      name: 'L8',
      description: 'LANDSAT 8',
      visParams: {gamma: 1.3, min: 0, max: 3000, bands: ['B4', 'B3', 'B2']},
      Cloudcover: 'CLOUD_COVER_LAND',
      Watercover: 'CLOUD_COVER',
      sza: 'SOLAR_ZENITH_ANGLE',
      vza: 'SOLAR_ZENITH_ANGLE',
      saa: 'SOLAR_AZIMUTH_ANGLE', 
      vaa: 'SOLAR_AZIMUTH_ANGLE',
      VIS_OPTIONS: app.VIS_OPTIONS,
      Collection_SL2P: ee.FeatureCollection(app.network.l8_createFeatureCollection_estimates()),
      Collection_SL2Perrors: ee.FeatureCollection(app.network.l8_createFeatureCollection_errors()),
      sl2pDomain: ee.FeatureCollection(app.network.l8_createFeatureCollection_domains()),
      Network_Ind: ee.FeatureCollection(app.network.l8_createFeatureCollection_Network_Ind()),
      partition: ee.ImageCollection(app.network.l8_createImageCollection_partition()),
      legend:  ee.FeatureCollection(app.network.l8_createFeatureCollection_legend()),
      numVariables: 7,
    },
    'users/rfernand387/L2avalidation': {
      name: 'S2_CCRS',
      description: 'Sentinel 2A CCRS',
      visParams: {gamma: 1.3, min: 0, max: 3000, bands: ['B4', 'B3', 'B2']},
      Cloudcover: 'CLOUDY_PIXEL_PERCENTAGE',
      Watercover: 'WATER_PERCENTAGE',
      sza: 'MEAN_SOLAR_ZENITH_ANGLE',
      vza: 'MEAN_INCIDENCE_ZENITH_ANGLE_B8A',
      saa: 'MEAN_SOLAR_AZIMUTH_ANGLE', 
      vaa: 'MEAN_INCIDENCE_AZIMUTH_ANGLE_B8A',
      VIS_OPTIONS: app.VIS_OPTIONS,
      Collection_SL2P: ee.FeatureCollection(app.network.s2_createFeatureCollection_estimates()),
      Collection_SL2Perrors: ee.FeatureCollection(app.network.s2_createFeatureCollection_errors()),  
      sl2pDomain: ee.FeatureCollection(app.network.s2_createFeatureCollection_domains()),
      Network_Ind: ee.FeatureCollection(app.network.s2_createFeatureCollection_Network_Ind()),
      partition: ee.ImageCollection(app.network.s2_createImageCollection_partition()),
      legend:  ee.FeatureCollection(app.network.s2_createFeatureCollection_legend()),
      numVariables: 7,
    },  
  }; 
  app.VIS_OPTIONS = {
    'Surface_Reflectance': {
      'COPERNICUS/S2_SR': {
        Name: 'Surface_Reflectance',
        description: 'Surface_Reflectance',
        outputParams: {gamma: 1.3, min: 0, max: 0.3, bands: ['B7', 'B6', 'B4']},
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'Surface_Reflectance',
        description: 'Surface_Reflectance',
        outputParams: {gamma: 1.3, min: 0, max: 0.3, bands: ['B7', 'B6', 'B4']},
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        },
      'users/rfernand387/L2avalidation': {
        Name: 'Surface_Reflectance',
        description: 'Surface_Reflectance',
        outpuParams: {gamma: 1.3, min: 0, max: 0.3, bands: ['B7', 'B6', 'B4']},
        inp:      [ 'B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        }
      },
    'Albedo': {
      'COPERNICUS/S2_SR': {
        Name: 'Albedo',
        errorName: 'errorAlbedo',
        maskName: 'maskAlbedo',
        description: 'Black sky albedo',
        variable: 6,
        outputParams: { min: 0.1, max: 0.3, palette: app.palettes.misc.jet[7], bands: ['estimateAlbedo']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorAlbedo']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'Albedo',
        errorName: 'errorAlbedo',
        maskName: 'maskAlbedo',
        description: 'Black sky albedo',
        variable: 6,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['estimateAlbedo']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorAlbedo']},
        inputBands:      ['cosVZA','cosSZA','cosRAA','B3', 'B4', 'B5', 'B6', 'B7'],
        inputScaling:     [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
      'users/rfernand387/L2avalidation': {
        Name: 'Albedo',
        errorName: 'errorAlbedo',
        maskName: 'maskAlbedo',
        description: 'Black sky albedo',
        variable: 6,
        outputParams: { min: 0.1, max: 0.3, palette: app.palettes.misc.jet[7], bands: ['estimateAlbedo']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorAlbedo']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
    },
    'fAPAR': {
      'COPERNICUS/S2_SR': {
        Name: 'fAPAR',
        errorName: 'errorfAPAR',
        maskName: 'maskfAPAR',
        description: 'Fraction of absorbed photosynthetically active radiation',
        variable: 2,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['estimatefAPAR']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfAPAR']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'fAPAR',
        errorName: 'errorfAPAR',
        maskName: 'maskfAPAR',
        description: 'Fraction of absorbed photosynthetically active radiation',
        variable: 2,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['estimatefAPAR']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfAPAR']},
        inputBands:      ['cosVZA','cosSZA','cosRAA','B3', 'B4', 'B5', 'B6', 'B7'],
        inputScaling:     [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]]))) 
      },
      'users/rfernand387/L2avalidation': {
        Name: 'fAPAR',
        errorName: 'errorfAPAR',
        maskName: 'maskfAPAR',
        description: 'Fraction of absorbed photosynthetically active radiation',
        variable: 2,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['estimatefAPAR']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfAPAR']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
    },
    'fCOVER': {
      'COPERNICUS/S2_SR': {
        Name: 'fCOVER',
        errorName: 'errorfCOVER',
        maskName: 'maskfCOVER',
        description: 'Fraction of canopy cover',
        variable: 3,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['estimatefCOVER']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfCOVER']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]]))) 
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'fCOVER',
        errorName: 'errorfCOVER',
        maskName: 'maskfCOVER',
        description: 'Fraction of canopy cover',
        variable: 3,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['estimatefCOVER']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfCOVER']},
        inputBands:      ['cosVZA','cosSZA','cosRAA','B3', 'B4', 'B5', 'B6', 'B7'],
        inputScaling:     [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))
      },
      'users/rfernand387/L2avalidation': {
        Name: 'fCOVER',
        errorName: 'errorfCOVER',
        maskName: 'maskfCOVER',
        description: 'Fraction of canopy cover',
        variable: 3,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['estimatefCOVER']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorfCOVER']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]])))  
      },
    },
    'LAI': {
      'COPERNICUS/S2_SR': {
        Name: 'LAI',
        errorName: 'errorLAI',
        maskName: 'maskLAI',
        description: 'Leaf area index',
        variable: 1,
        outputParams: { min: 0, max: 10, palette: app.palettes.misc.jet[7], bands: ['estimateLAI']},
        errorParams: { min: -5, max: 5, palette: app.palettes.misc.jet[7], bands: ['errorLAI']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]]))) 
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'LAI',
        errorName: 'errorLAI',
        maskName: 'maskLAI',
        description: 'Leaf area index',
        variable: 1,
        outputParams: { min: 0, max: 10, palette: app.palettes.misc.jet[7], bands: ['estimateLAI']},
        errorParams: { min: -5, max: 5, palette: app.palettes.misc.jet[7], bands: ['errorLAI']},
        inputBands:      ['cosVZA','cosSZA','cosRAA','B3', 'B4', 'B5', 'B6', 'B7'],
        inputScaling:     [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[10]])))
      },
      'users/rfernand387/L2avalidation': {
        Name: 'LAI',
        errorName: 'errorLAI',
        maskName: 'maskLAI',
        description: 'Leaf area index',
        variable: 1,
        outputParams: { min: 0, max: 10, palette: app.palettes.misc.jet[7], bands: ['estimateLAI']},
        errorParams: { min: -5, max: 5, palette: app.palettes.misc.jet[7], bands: ['errorLAI']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1]]))) 
      },
    },
    'CCC': {
      'COPERNICUS/S2_SR': {
        Name: 'CCC',
        errorName: 'errorCCC',
        maskName: 'maskCCC',
        description: 'Canopy chloropyll content',
        variable: 4,
        outputParams: { min: 0, max: 1000, palette: app.palettes.misc.jet[7], bands: ['estimateCCC']},
        errorParams: { min: -500, max: 500, palette: app.palettes.misc.jet[7], bands: ['errorCCC']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1000]])))
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'CCC',
        errorName: 'errorCCC',
        maskName: 'maskCCC',
        description: 'Canopy chloropyll content',
        variable: 4,
        outputParams: { min: 0, max: 1000, palette: app.palettes.misc.jet[7], bands: ['estimateCCC']},
        errorParams: { min: -500, max: 500, palette: app.palettes.misc.jet[7], bands: ['errorCCC']},
        inputBands:      ['cosVZA','cosSZA','cosRAA','B3', 'B4', 'B5', 'B6', 'B7'],
        inputScaling:     [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1000]])))
      },
      'users/rfernand387/L2avalidation': {
        Name: 'CCC', 
        errorName: 'errorCCC',
        maskName: 'maskCCC',
        description: 'Canopy chloropyll content',
        variable: 4,
        outputParams: { min: 0, max: 1000, palette: app.palettes.misc.jet[7], bands: ['estimateCCC']},
        errorParams: { min: -500, max: 500, palette: app.palettes.misc.jet[7], bands: ['errorCCC']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[1000]])))
      },
    },
     'CWC': {
       'COPERNICUS/S2_SR': {
        Name: 'CWC',
        errorName: 'errorCWC',
        maskName: 'maskCWC',
        description: 'Canopy water content',
        variable: 5,
        outputParams: { min: 0, max: 100, palette: app.palettes.misc.jet[7], bands: ['estimateCWC']},
        errorParams: { min: -50, max: 50, palette: app.palettes.misc.jet[7], bands: ['errorCWC']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[100]])))
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'CWC',
        errorName: 'errorCWC',
        maskName: 'maskCWC',
        description: 'Canopy water content',
        variable: 5,
        outputParams: { min: 0, max: 100, palette: app.palettes.misc.jet[7], bands: ['estimateCWC']},
        errorParams: { min: -50, max: 50, palette: app.palettes.misc.jet[7], bands: ['errorCWC']},
        inputBands:      ['cosVZA','cosSZA','cosRAA','B3', 'B4', 'B5', 'B6', 'B7'],
        inputScaling:     [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[100]]))) 
      },   
      'users/rfernand387/L2avalidation': {
        Name: 'CWC',
        errorName: 'errorCWC',
        maskName: 'maskCWC',
        description: 'Canopy water content',
        variable: 5,
        outputParams: { min: 0, max: 100, palette: app.palettes.misc.jet[7], bands: ['estimateCWC']},
        errorParams: { min: -50, max: 50, palette: app.palettes.misc.jet[7], bands: ['errorCWC']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[100]])))
      },
    },
      'DASF' : {
      'COPERNICUS/S2_SR': {
        Name: 'DASF',
        errorname: 'errorDASF',
        maskname: 'maskDASF',
        description: 'Canopy directional scattering factor',
        variable: 7,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['estimateDASF']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorDASF']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[2]])))
      },
      'LANDSAT/LC08/C01/T1_SR': {
        Name: 'DASF',
        errorName: 'errorDASF',
        maskName: 'maskDASF',
        description: 'Canopy directional scattering factor',
        variable: 7,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['estimateDASF']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorDASF']},
        inputBands:      ['cosVZA','cosSZA','cosRAA','B3', 'B4', 'B5', 'B6', 'B7'],
        inputScaling:     [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[2]])))
      },   
      'users/rfernand387/L2avalidation': {
        Name: 'DASF',
        errorname: 'errorDASF',
        maskname: 'maskDASF',
        description: 'Canopy directional scattering factor',
        variable: 7,
        outputParams: { min: 0, max: 1, palette: app.palettes.misc.jet[7], bands: ['estimateDASF']},
        errorParams: { min: -1, max: 1, palette: app.palettes.misc.jet[7], bands: ['errorDASF']},
        inputBands:      [ 'cosVZA','cosSZA','cosRAA','B4', 'B5', 'B6', 'B7', 'B8A','B9','B11','B12'],
        inputScaling:      [0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001],
        outmin: (ee.Image(ee.Array([[0]]))),
        outmax: (ee.Image(ee.Array([[2]])))
      },
    },
    };
};
// Creates the application interface
app.boot = function() {
  app.createConstants();
  app.createHelpers();
  app.createPanels();
  var main = ui.Panel({
    widgets: [
      app.intro.panel,
      app.filters.panel,
      app.picker.panel,
      app.vis.panel,
      app.export.panel
    ],
    style: {width: '320px', padding: '8px'}
  });
  ui.root.insert(0, main);
};
// Start app
app.boot();