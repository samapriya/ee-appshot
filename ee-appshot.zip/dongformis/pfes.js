//load an image from a image library
var first = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
                .filterBounds(ee.Geometry.Point(104.728, 20.797))
                .filterDate('2017-01-01', '2018-05-31')
                .sort('CLOUDY_PIXEL_PERCENTAGE')
                .first();
Map.centerObject(first, 11);
Map.addLayer(first, {bands: ['B4', 'B3', 'B2'], min: 0, max: 2000}, 'first');
// Get information about the bands as a list.
var bandNames = first.bandNames();
print('Band names: ', bandNames); // ee.List of band names
// Compute NDVI.
var ndvi= first.select('B4').subtract(first.select('B3'))
  .divide(first.select('B4').add(first.select('B3')));
//add layer
Map.addLayer (ndvi, {}, 'NDVI')
//Map.addLayer(ndvi, {min: -1, max: 1, palette: ['FF0000', '00FF00']});
// creat a binary layer
var forest = ndvi.lt(-0.2);
Map.addLayer (forest, {}, 'forest');