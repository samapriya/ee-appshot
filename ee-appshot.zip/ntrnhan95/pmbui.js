var geometry = 
    ee.Geometry.Polygon(
        [[[106.50956882667153, 10.936273675844095],
          [106.50956882667153, 10.661083632776931],
          [106.82405246924965, 10.661083632776931],
          [106.82405246924965, 10.936273675844095]]], null, false);
var hcm = ee.FeatureCollection("users/lethienbaohcm/centre_hcm");
//show polygon
Map.addLayer(hcm,{color:'B1FB17'},'hcm');
// show line
//var border = ee.Image().byte().paint({featureCollection:hcm, color: 1, width : 1});
//Map.addLayer(border,{palette:'blue'},'hcm');
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////STEP 1:  CREATE FUNCTION FILTER CLOUD /////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////STEP 2: IMPORT IMAGE////////////////////////////////////////////////////////////
////import SENTINEL 2: Top-of-Atmosphere Reflectance: Level-1C orthorectified top-of-atmosphere reflectance.//////////////////////////////////////////////////////////////////////////////////
var imageTOA031220 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2020-12-3', '2020-12-4')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);
var imageTOA061220 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2020-12-6', '2020-12-7')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);                  
var imageTOA070121 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2021-1-7', '2021-1-8')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);                 
var imageTOA120121 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2021-1-12', '2021-1-13')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);                  
var imageTOA170121 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2021-1-17', '2021-1-18')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);                  
var imageTOA060321 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2021-3-6', '2021-3-7')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);
var imageTOA080321 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2021-03-08', '2021-03-09')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 30))
                  .map(maskS2clouds);                  
var imageTOA110321 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2021-3-11', '2021-3-12')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);                  
var imageTOA070421 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2021-4-7', '2021-4-8')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);                  
// cut region, select band                  
var TOA031220= imageTOA031220.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var TOA061220= imageTOA061220.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var TOA070121= imageTOA070121.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var TOA120121= imageTOA120121.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var TOA170121=imageTOA170121.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var TOA060321= imageTOA060321.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var TOA080321= imageTOA080321.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var TOA110321= imageTOA110321.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var TOA070421= imageTOA070421.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var rgbVis = {  min: 0.0,  max: 0.3,  bands: ['B4', 'B3', 'B2'],};
//display map
Map.setCenter(106.70066, 10.78304, 13);
Map.addLayer(TOA031220, rgbVis, 'SENTINEL 2 TOA Reflectance',0);
//////import SENTINEL 2: Surface Reflectance Level-2A orthorectified atmospherically corrected surface reflectance.
var imageSR031220 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2020-12-3', '2020-12-4')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .map(maskS2clouds);
var imageSR061220= ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2020-12-6', '2020-12-7')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .map(maskS2clouds);
var imageSR070121 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2021-1-7', '2021-1-8')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .map(maskS2clouds);
var imageSR120121 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2021-1-12', '2021-1-13')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .map(maskS2clouds);
var imageSR170121 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2021-1-17', '2021-1-18')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .map(maskS2clouds);                  
var imageSR060321 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2021-3-6', '2021-3-7')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .map(maskS2clouds);                  
var imageSR080321 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2021-03-08', '2021-03-09')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',30))
                  .map(maskS2clouds);                  
var imageSR110321  = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2021-3-11', '2021-3-12')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .map(maskS2clouds);
var imageSR070421 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2021-4-7', '2021-4-8')
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .map(maskS2clouds);                  
// cut region, select band 
var SR031220= imageSR031220.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var SR061220= imageSR061220.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var SR070121= imageSR070121.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var SR120121= imageSR120121.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var SR170121= imageSR170121.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var SR060321= imageSR060321.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var SR080321= imageSR080321.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var SR110321= imageSR110321.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var SR070421= imageSR070421.mean().clip(hcm).select('B1', 'B2', 'B3','B4','B8');
var visualization = {  min: 0.1,  max: 0.3,  bands: ['B4', 'B3', 'B2'],};
Map.addLayer(SR031220, visualization, 'SENTINEL 2 Surface Reflectance',0);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////STEP 3: CALCULATE  atmospheric reflectance////////////////////////////////////////////////////////////
//TOA reflectance measured was subtracted from the surface reflectance image to obtain the atmospheric reflectance
//imageATM (atmospheric reflectance) = TOA (TOA reflectance)  -   SR (surface reflectance image )
var imageATM031220 = TOA031220.subtract(SR031220);
var imageATM061220 = TOA061220.subtract(SR061220);
var imageATM070121 = TOA070121.subtract(SR070121);
var imageATM120121 = TOA120121.subtract(SR120121);
var imageATM170121 = TOA170121.subtract(SR170121);
var imageATM060321 = TOA060321.subtract(SR060321);
var imageATM080321 = TOA080321.subtract(SR080321);
var imageATM110321 = TOA110321.subtract(SR110321);
var imageATM070421 = TOA070421.subtract(SR070421);
Map.addLayer(imageATM031220,{bands: ['B4', 'B3', 'B2'], min: 0, max: 0.09}, 'SENTINEL 2 Reflectance  Atmospheric',0);
/////////////////////////////////STEP 4: CALCULATE PM2.5 BY THE BEST MODEL REGRESSION/////////////////////////////
//SELECT BAND FROM IMAGE atmospheric reflectance
var B1_031220=imageATM031220.select('B1');
var B1_061220=imageATM061220.select('B1');
var B1_070121=imageATM070121.select('B1');
var B1_120121=imageATM120121.select('B1');
var B1_170121=imageATM170121.select('B1');
var B1_060321=imageATM060321.select('B1');
var B1_080321=imageATM080321.select('B1');
var B1_110321=imageATM110321.select('B1');
var B1_070421=imageATM070421.select('B1');
var B2_031220=imageATM031220.select('B2');
var B2_061220=imageATM061220.select('B2');
var B2_070121=imageATM070121.select('B2');
var B2_120121=imageATM120121.select('B2');
var B2_170121=imageATM170121.select('B2');
var B2_060321=imageATM060321.select('B2');
var B2_080321=imageATM080321.select('B2');
var B2_110321=imageATM110321.select('B2');
var B2_070421=imageATM070421.select('B2');
var B3_031220=imageATM031220.select('B3');
var B3_061220=imageATM061220.select('B3');
var B3_070121=imageATM070121.select('B3');
var B3_120121=imageATM120121.select('B3');
var B3_170121=imageATM170121.select('B3');
var B3_060321=imageATM060321.select('B3');
var B3_080321=imageATM080321.select('B3');
var B3_110321=imageATM110321.select('B3');
var B3_070421=imageATM070421.select('B3');
var B4_031220=imageATM031220.select('B4');
var B4_061220=imageATM061220.select('B4');
var B4_070121=imageATM070121.select('B4');
var B4_120121=imageATM120121.select('B4');
var B4_170121=imageATM170121.select('B4');
var B4_060321=imageATM060321.select('B4');
var B4_080321=imageATM080321.select('B4');
var B4_110321=imageATM110321.select('B4');
var B4_070421=imageATM070421.select('B4');
var B8_031220=imageATM031220.select('B8');
var B8_061220=imageATM061220.select('B8');
var B8_070121=imageATM070121.select('B8');
var B8_120121=imageATM120121.select('B8');
var B8_170121=imageATM170121.select('B8');
var B8_060321=imageATM060321.select('B8');
var B8_080321=imageATM080321.select('B8');
var B8_110321=imageATM110321.select('B8');
var B8_070421=imageATM070421.select('B8');
//CALCULATE PM2.5 BY EXPRESSION
 var PM031220=imageATM031220.expression(
    'abs(a*B1 + b*B2 + c*B3 + d*B4 + e*B8 + f) ',{
      'B1':B1_031220,
      'B2':B2_031220,
       'B3':B3_031220,
        'B4':B4_031220,
         'B8':B8_031220,
    'a':-1311.380,
      'b':32.499 ,
         'c':2061.761,
          'd':102.289,
           'e':-462.899,
            'f':57.820,
    });
 var PM061220=imageATM061220.expression(
    'abs(a*B1 + b*B2 + c*B3 + d*B4 + e*B8 + f) ',{
      'B1':B1_061220,
      'B2':B2_061220,
       'B3':B3_061220,
        'B4':B4_061220,
         'B8':B8_061220,
    'a':-1311.380,
      'b':32.499 ,
         'c':2061.761,
          'd':102.289,
           'e':-462.899,
            'f':57.820,
    });
 var PM070121=imageATM070121.expression(
    'abs(a*B1 + b*B2 + c*B3 + d*B4 + e*B8 + f) ',{
      'B1':B1_070121,
      'B2':B2_070121,
       'B3':B3_070121,
        'B4':B4_070121,
         'B8':B8_070121,
    'a':-1311.380,
      'b':32.499 ,
         'c':2061.761,
          'd':102.289,
           'e':-462.899,
            'f':57.820,
    });
 var PM120121=imageATM120121.expression(
    'abs(a*B1 + b*B2 + c*B3 + d*B4 + e*B8 + f) ',{
      'B1':B1_120121,
      'B2':B2_120121,
       'B3':B3_120121,
        'B4':B4_120121,
         'B8':B8_120121,
    'a':-1311.380,
      'b':32.499 ,
         'c':2061.761,
          'd':102.289,
           'e':-462.899,
            'f':57.820,
    });
 var PM170121=imageATM170121.expression(
    'abs(a*B1 + b*B2 + c*B3 + d*B4 + e*B8 + f) ',{
      'B1':B1_170121,
      'B2':B2_170121,
       'B3':B3_170121,
        'B4':B4_170121,
         'B8':B8_170121,
    'a':-1311.380,
      'b':32.499 ,
         'c':2061.761,
          'd':102.289,
           'e':-462.899,
            'f':57.820,
    });
 var PM060321=imageATM060321.expression(
    'abs(a*B1 + b*B2 + c*B3 + d*B4 + e*B8 + f) ',{
      'B1':B1_060321,
      'B2':B2_060321,
       'B3':B3_060321,
        'B4':B4_060321,
         'B8':B8_060321,
    'a':-1311.380,
      'b':32.499 ,
         'c':2061.761,
          'd':102.289,
           'e':-462.899,
            'f':57.820,
    });
 var PM080321=imageATM080321.expression(
    'abs(a*B1 + b*B2 + c*B3 + d*B4 + e*B8 + f) ',{
      'B1':B1_080321,
      'B2':B2_080321,
       'B3':B3_080321,
        'B4':B4_080321,
         'B8':B8_080321,
    'a':-1311.380,
      'b':32.499 ,
         'c':2061.761,
          'd':102.289,
           'e':-462.899,
            'f':57.820,
    });
 var PM110321=imageATM110321.expression(
    'abs(a*B1 + b*B2 + c*B3 + d*B4 + e*B8 + f) ',{
      'B1':B1_110321,
      'B2':B2_110321,
       'B3':B3_110321,
        'B4':B4_110321,
         'B8':B8_110321,
    'a':-1311.380,
      'b':32.499 ,
         'c':2061.761,
          'd':102.289,
           'e':-462.899,
            'f':57.820,
    });
 var PM070421=imageATM070421.expression(
    'abs(a*B1 + b*B2 + c*B3 + d*B4 + e*B8 + f) ',{
      'B1':B1_070421,
      'B2':B2_070421,
       'B3':B3_070421,
        'B4':B4_070421,
         'B8':B8_070421,
    'a':-1311.380,
      'b':32.499 ,
         'c':2061.761,
          'd':102.289,
           'e':-462.899,
            'f':57.820,
    });
//BUILD HISTOGRAM PM2.5
// print('Histogram:', ui.Chart.image.histogram(PM031220, hcm, 400).setOptions({title: 'Histogram of PM25'}));
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////STEP 5: CLASSIFY PM2,5 031220////////////////////////
function reclass_PM031220 (PM031220) {
  return PM031220.expression(
    '(b(0) <0) ? 0'+ //Platinum
     ':(b(0) <10) ? 1'+ // GREEN  0-10
    ':(b(0) <20) ? 2'+ // Green Yellow 10-20
    ' :b(0) <30 ? 3'+ // Yellow 20-30
     ' :b(0) < 40 ? 4'+ // Yellow+Orange 30-40
       ' :b(0) < 50 ? 5'+ // Orange 40-50
         ': b(0) > 50? 6'+ // Red//  >50
        ': 0');}
function reclass_PM061220 (PM061220) {
  return PM061220.expression(
    '(b(0) <0) ? 0'+ //Platinum
     ':(b(0) <10) ? 1'+ // GREEN  0-10
    ':(b(0) <20) ? 2'+ // Green Yellow 10-20
    ' :b(0) <30 ? 3'+ // Yellow 20-30
     ' :b(0) < 40 ? 4'+ // Yellow+Orange 30-40
       ' :b(0) < 50 ? 5'+ // Orange 40-50
         ': b(0) > 50? 6'+ // Red//  >50
        ': 0');}
function reclass_PM070121 (PM070121) {
  return PM070121.expression(
    '(b(0) <0) ? 0'+ //Platinum
     ':(b(0) <10) ? 1'+ // GREEN  0-10
    ':(b(0) <20) ? 2'+ // Green Yellow 10-20
    ' :b(0) <30 ? 3'+ // Yellow 20-30
     ' :b(0) < 40 ? 4'+ // Yellow+Orange 30-40
       ' :b(0) < 50 ? 5'+ // Orange 40-50
         ': b(0) > 50? 6'+ // Red//  >50
        ': 0');}
function reclass_PM120121 (PM120121) {
  return PM120121.expression(
    '(b(0) <0) ? 0'+ //Platinum
     ':(b(0) <10) ? 1'+ // GREEN  0-10
    ':(b(0) <20) ? 2'+ // Green Yellow 10-20
    ' :b(0) <30 ? 3'+ // Yellow 20-30
     ' :b(0) < 40 ? 4'+ // Yellow+Orange 30-40
       ' :b(0) < 50 ? 5'+ // Orange 40-50
         ': b(0) > 50? 6'+ // Red//  >50
        ': 0');}
function reclass_PM170121 (PM170121) {
  return PM170121.expression(
    '(b(0) <0) ? 0'+ //Platinum
     ':(b(0) <10) ? 1'+ // GREEN  0-10
    ':(b(0) <20) ? 2'+ // Green Yellow 10-20
    ' :b(0) <30 ? 3'+ // Yellow 20-30
     ' :b(0) < 40 ? 4'+ // Yellow+Orange 30-40
       ' :b(0) < 50 ? 5'+ // Orange 40-50
         ': b(0) > 50? 6'+ // Red//  >50
        ': 0');}
 function reclass_PM060321 (PM060321) {
  return PM060321.expression(
    '(b(0) <0) ? 0'+ //Platinum
     ':(b(0) <10) ? 1'+ // GREEN  0-10
    ':(b(0) <20) ? 2'+ // Green Yellow 10-20
    ' :b(0) <30 ? 3'+ // Yellow 20-30
     ' :b(0) < 40 ? 4'+ // Yellow+Orange 30-40
       ' :b(0) < 50 ? 5'+ // Orange 40-50
         ': b(0) > 50? 6'+ // Red//  >50
        ': 0');}
 function reclass_PM080321 (PM080321) {
  return PM080321.expression(
    '(b(0) <0) ? 0'+ //Platinum
     ':(b(0) <10) ? 1'+ // GREEN  0-10
    ':(b(0) <20) ? 2'+ // Green Yellow 10-20
    ' :b(0) <30 ? 3'+ // Yellow 20-30
     ' :b(0) < 40 ? 4'+ // Yellow+Orange 30-40
       ' :b(0) < 50 ? 5'+ // Orange 40-50
         ': b(0) > 50? 6'+ // Red//  >50
        ': 0');}
function reclass_PM110321 (PM110321) {
  return PM110321.expression(
    '(b(0) <0) ? 0'+ //Platinum
     ':(b(0) <10) ? 1'+ // GREEN  0-10
    ':(b(0) <20) ? 2'+ // Green Yellow 10-20
    ' :b(0) <30 ? 3'+ // Yellow 20-30
     ' :b(0) < 40 ? 4'+ // Yellow+Orange 30-40
       ' :b(0) < 50 ? 5'+ // Orange 40-50
         ': b(0) > 50? 6'+ // Red//  >50
        ': 0');}
function reclass_PM070421 (PM070421) {
  return PM070421.expression(
    '(b(0) <0) ? 0'+ //Platinum
     ':(b(0) <10) ? 1'+ // GREEN  0-10
    ':(b(0) <20) ? 2'+ // Green Yellow 10-20
    ' :b(0) <30 ? 3'+ // Yellow 20-30
     ' :b(0) < 40 ? 4'+ // Yellow+Orange 30-40
       ' :b(0) < 50 ? 5'+ // Orange 40-50
         ': b(0) > 50? 6'+ // Red//  >50
        ': 0');}
var reclassify_PM031220 = reclass_PM031220(PM031220);
var reclassify_PM061220 = reclass_PM061220(PM061220);
var reclassify_PM070121 = reclass_PM070121(PM070121);
var reclassify_PM120121 = reclass_PM120121(PM120121);
var reclassify_PM170121 = reclass_PM170121(PM170121);
var reclassify_PM060321 = reclass_PM060321(PM060321);
var reclassify_PM080321 = reclass_PM080321(PM080321);
var reclassify_PM110321 = reclass_PM110321(PM110321);
var reclassify_PM070421 = reclass_PM070421(PM070421);
///Map.addLayer(reclassify_PM031220.clip(hcm),{'palette': 'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'},'PM2.5 in HCM 031220',0);
//Map.addLayer(reclassify_PM061220.clip(hcm),{'palette': 'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'},'PM2.5 in HCM 061220',0);
//Map.addLayer(reclassify_PM070121.clip(hcm),{'palette': 'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'},'PM2.5 in HCM 070121',0);
//Map.addLayer(reclassify_PM120121.clip(hcm),{'palette': 'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'},'PM2.5 in HCM 120121',0);
//Map.addLayer(reclassify_PM170121.clip(hcm),{'palette': 'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'},'PM2.5 in HCM 170121',0);
//Map.addLayer(reclassify_PM060321.clip(hcm),{'palette': 'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'},'PM2.5 in HCM 060321',0);
//Map.addLayer(reclassify_PM080321.clip(hcm),{'palette': 'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'},'PM2.5 in HCM 080321',0);
//Map.addLayer(reclassify_PM110321.clip(hcm),{'palette': 'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'},'PM2.5 in HCM 110321',0);
//Map.addLayer(reclassify_PM070421.clip(hcm),{'palette': 'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'},'PM2.5 in HCM 070421',0);
//CALCULATE AREA (m2)
var area_nd031220 = ee.Image.pixelArea().addBands(reclassify_PM031220).divide(100);
var area_nd061220 = ee.Image.pixelArea().addBands(reclassify_PM061220).divide(100);
var area_nd070121 = ee.Image.pixelArea().addBands(reclassify_PM070121).divide(100);
var area_nd120121 = ee.Image.pixelArea().addBands(reclassify_PM120121).divide(100);
var area_nd170121 = ee.Image.pixelArea().addBands(reclassify_PM170121).divide(100);
var area_nd060321 = ee.Image.pixelArea().addBands(reclassify_PM060321).divide(100);
var area_nd080321 = ee.Image.pixelArea().addBands(reclassify_PM080321).divide(100);
var area_nd110321 = ee.Image.pixelArea().addBands(reclassify_PM110321).divide(100);
var area_nd070421 = ee.Image.pixelArea().addBands(reclassify_PM070421).divide(100);
var reduction_results031220 = area_nd031220.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: hcm,
  scale: 30,
  bestEffort: true,
});
var reduction_results061220 = area_nd061220.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: hcm,
  scale: 30,
  bestEffort: true,
});
var reduction_results070121 = area_nd070121.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: hcm,
  scale: 30,
  bestEffort: true,
});
var reduction_results120121 = area_nd120121.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: hcm,
  scale: 30,
  bestEffort: true,
});
var reduction_results170121 = area_nd170121.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: hcm,
  scale: 30,
  bestEffort: true,
});
var reduction_results060321 = area_nd060321.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: hcm,
  scale: 30,
  bestEffort: true,
});
var reduction_results080321 = area_nd080321.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: hcm,
  scale: 30,
  bestEffort: true,
});
var reduction_results110321 = area_nd110321.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: hcm,
  scale: 30,
  bestEffort: true,
});
var reduction_results070421 = area_nd070421.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: hcm,
  scale: 30,
  bestEffort: true,
});
//Print area
//print('PM25_031220 (M2) 1: <10; 2:10-20; 3:20-30; 4:30-40; 5:40-50; 6:>50 ' , reduction_results031220);
//print('PM25_061220 (M2) 1: <10; 2:10-20; 3:20-30; 4:30-40; 5:40-50; 6:>50 ' , reduction_results061220);
//print('PM25_070121 (M2) 1: <10; 2:10-20; 3:20-30; 4:30-40; 5:40-50; 6:>50 ' , reduction_results070121);
//print('PM25_120121 (M2) 1: <10; 2:10-20; 3:20-30; 4:30-40; 5:40-50; 6:>50 ' , reduction_results120121);
//print('PM25_170121 (M2) 1: <10; 2:10-20; 3:20-30; 4:30-40; 5:40-50; 6:>50 ' , reduction_results170121);
//print('PM25_060321 (M2) 1: <10; 2:10-20; 3:20-30; 4:30-40; 5:40-50; 6:>50 ' , reduction_results060321);
//print('PM25_080321 (M2) 1: <10; 2:10-20; 3:20-30; 4:30-40; 5:40-50; 6:>50 ' , reduction_results080321);
//print('PM25_110321 (M2) 1: <10; 2:10-20; 3:20-30; 4:30-40; 5:40-50; 6:>50 ' , reduction_results110321);
//print('PM25_070421 (M2) 1: <10; 2:10-20; 3:20-30; 4:30-40; 5:40-50; 6:>50 ' , reduction_results070421);
///////////////////////////////////////////////////////////////////////////////////////////
// calculate NDVI
var NDVI031220=SR031220.expression(
     ' (NIR-RED)/(NIR+RED)',{
      'RED':SR031220.select('B4'),
      'NIR':SR031220.select('B8') });
var viz = {  min: 0,  max: 1.0, palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901','66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',    '012E01', '011D01', '011301'  ],};
//Map.addLayer(NDVI031220,viz,'NDVI in 03/12/2021',0);
var NDVI061220=SR061220.expression(
     ' (NIR-RED)/(NIR+RED)',{
      'RED':SR061220.select('B4'),
      'NIR':SR061220.select('B8') });
var viz = {  min: 0,  max: 1.0, palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901','66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',    '012E01', '011D01', '011301'  ],};
//Map.addLayer(NDVI061220,viz,'NDVI in 06/12/2021',0);
var NDVI070121=SR070121.expression(
     ' (NIR-RED)/(NIR+RED)',{
      'RED':SR070121.select('B4'),
      'NIR':SR070121.select('B8') });
var viz = {  min: 0,  max: 1.0, palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901','66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',    '012E01', '011D01', '011301'  ],};
//Map.addLayer(NDVI070121,viz,'NDVI in 07/01/2021',0);
var NDVI120121=SR120121.expression(
     ' (NIR-RED)/(NIR+RED)',{
      'RED':SR120121.select('B4'),
      'NIR':SR120121.select('B8') });
var viz = {  min: 0,  max: 1.0, palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901','66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',    '012E01', '011D01', '011301'  ],};
//Map.addLayer(NDVI120121,viz,'NDVI in 12/01/2021',0);
var NDVI170121=SR170121.expression(
     ' (NIR-RED)/(NIR+RED)',{
      'RED':SR170121.select('B4'),
      'NIR':SR170121.select('B8') });
var viz = {  min: 0,  max: 1.0, palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901','66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',    '012E01', '011D01', '011301'  ],};
//Map.addLayer(NDVI170121,viz,'NDVI in 17/01/2021',0);
var NDVI060321=SR060321.expression(
     ' (NIR-RED)/(NIR+RED)',{
      'RED':SR060321.select('B4'),
      'NIR':SR060321.select('B8') });
var viz = {  min: 0,  max: 1.0, palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901','66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',    '012E01', '011D01', '011301'  ],};
//Map.addLayer(NDVI060321,viz,'NDVI in 06/03/2021',0);
var NDVI080321=SR080321.expression(
     ' (NIR-RED)/(NIR+RED)',{
      'RED':SR080321.select('B4'),
      'NIR':SR080321.select('B8') });
var viz = {  min: 0,  max: 1.0, palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901','66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',    '012E01', '011D01', '011301'  ],};
//Map.addLayer(NDVI080321,viz,'NDVI in 08/03/2021',0);
var NDVI110321=SR110321.expression(
     ' (NIR-RED)/(NIR+RED)',{
      'RED':SR110321.select('B4'),
      'NIR':SR110321.select('B8') });
var viz = {  min: 0,  max: 1.0, palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901','66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',    '012E01', '011D01', '011301'  ],};
//Map.addLayer(NDVI110321,viz,'NDVI in 11/03/2021',0);
var NDVI070421=SR070421.expression(
     ' (NIR-RED)/(NIR+RED)',{
      'RED':SR070421.select('B4'),
      'NIR':SR070421.select('B8') });
var viz = {  min: 0,  max: 1.0, palette: ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901','66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',    '012E01', '011D01', '011301'  ],};
//Map.addLayer(NDVI070421,viz,'NDVI in 07/04/2021',0);
/////////////////////////////PANEL.////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//      2) Begin setting up map appearance and app layers   //
///////////////////////////////////////////////////////////////
//2.1) Set up general display
//Set up a satellite background
Map.setOptions('Satellite')
//Center the map to HCM
Map.setCenter(106.65616535852088,10.795687006259966, 11);
//Change style of cursor to 'crosshair'
Map.style().set('cursor', 'crosshair');
//2.2) We want to set up a Viridis color pallete to display the Simard data
var color = {min: 0 , max : 5,palette : ['E5E4E2','008000','B1FB17','FFFF00','FFD801','FFA500','FF0000']};
//2.3) Create variables for GUI layers for each layer
//We set each layer to "false" so the user can turn them on later
var classify_PM031220 = ui.Map.Layer(reclassify_PM031220.clip(hcm), color, 'classify_PM031220',false)
var classify_PM061220 = ui.Map.Layer(reclassify_PM061220.clip(hcm), color, 'classify_PM061220',false)
var classify_PM070121 = ui.Map.Layer(reclassify_PM070121.clip(hcm), color, 'classify_PM070121',false)
var classify_PM120121 = ui.Map.Layer(reclassify_PM120121.clip(hcm), color, 'classify_PM120121',false)
var classify_PM170121 = ui.Map.Layer(reclassify_PM170121.clip(hcm), color, 'classify_PM170121',false)
var classify_PM060321 = ui.Map.Layer(reclassify_PM060321.clip(hcm), color, 'classify_PM060321',false)
var classify_PM080321 = ui.Map.Layer(reclassify_PM080321.clip(hcm), color, 'classify_PM080321',false)
var classify_PM110321 = ui.Map.Layer(reclassify_PM110321.clip(hcm), color, 'classify_PM110321',false)
var classify_PM070421 = ui.Map.Layer(reclassify_PM070421.clip(hcm), color, 'classify_PM070421',false)
var NDVI031220 = ui.Map.Layer(NDVI031220.clip(hcm), viz, 'NDVI in 03/12/2020',true)
var NDVI061220 = ui.Map.Layer(NDVI061220.clip(hcm), viz, 'NDVI in 06/12/2020',true)
var NDVI070121 = ui.Map.Layer(NDVI070121.clip(hcm), viz, 'NDVI in 07/01/2021',true)
var NDVI120121 = ui.Map.Layer(NDVI120121.clip(hcm), viz, 'NDVI in 12/01/2021',true)
var NDVI170121 = ui.Map.Layer(NDVI170121.clip(hcm), viz, 'NDVI in 17/01/2021',true)
var NDVI060321 = ui.Map.Layer(NDVI060321.clip(hcm), viz, 'NDVI in 06/03/2021',true)
var NDVI080321 = ui.Map.Layer(NDVI080321.clip(hcm), viz, 'NDVI in 08/03/2021',true)
var NDVI110321 = ui.Map.Layer(NDVI110321.clip(hcm), viz, 'NDVI in 11/03/2021',true)
var NDVI070421 = ui.Map.Layer(NDVI070421.clip(hcm), viz, 'NDVI in 07/04/2021',true)
Map.add(classify_PM031220);
Map.add(classify_PM061220);
Map.add(classify_PM070121);
Map.add(classify_PM120121);
Map.add(classify_PM170121);
Map.add(classify_PM060321);
Map.add(classify_PM080321);
Map.add(classify_PM110321);
Map.add(classify_PM070421);
/*
Map.add(NDVI031220);
Map.add(NDVI061220);
Map.add(NDVI070121);
Map.add(NDVI120121);
Map.add(NDVI170121);
Map.add(NDVI060321);
Map.add(NDVI080321);
Map.add(NDVI110321);
Map.add(NDVI070421);
*/
///////////////////////////////////////////////////////////////
//      3) Set up panels and widgets for display             //
///////////////////////////////////////////////////////////////
//3.2) Create a panel to hold text
var panel = ui.Panel({
   style: {
       padding: '5px 5px',
    width: '600px',
     }
  });
var header = ui.Label('Particulate Matter 2.5 (PM2.5) ', {margin: '5px 5px',fontSize: '23px', fontWeight: 'bold', color: '437C17', padding:'6px 30px '});
//3.2) Create a panel to hold text
var panel = ui.Panel({
  widgets:[header],//Adds header and text
  style:{width: '430px',
    padding:'1px 6px '
  }});
//3.3) Create variable for additional text and separators
//App summary
var text = ui.Label(
 'Bụi PM2.5 là tổng các hạt bụi lơ lửng có đường kính khí động học <= 2,5 μm. Nồng độ bụi PM2.5 trung bình 24 giờ trong giới hạn cho phép là 50 (μg/m³). "Theo QCVN 05:2013/BTNMT"',
  {fontSize: '13px',
  padding:'1px 15px 0px 15px',
  margin: '1px 1px',
  textAlign:'justify'        });
  //  -Quy chuẩn kỹ thuật quốc gia về chất lượng không khí xung quanh ban hành kèm theo Thông tư số 32/2013/TT-BTNMT ngày 25/10/2013 của Bộ trưởng Bộ Tài nguyên và Môi trường
panel.add( text );
//This creates another panel to house a line separator and instructions for the user
var intro = ui.Panel([
ui.Label({
  value: '___________________________________________________________',
  style: {fontWeight: 'bold',  color: '1b7100',
    padding:'1px 10px 1px 10px ',
    margin: '1px 1px'
  },
  }),
//  ui.Label({
 //   value:'Select layers to display map, histogram and chart',
 //   style: {fontSize: '14px',
 //   fontWeight: 'bold',
 //   padding: '0px 30px',
 //     color:'41A317',
  //  }
 // })
  ]);
//Add this new panel to the larger panel we created 
panel.add(intro);
//3.4) Add our main panel to the root of our GUI
ui.root.insert(1,panel);
///////////////////////////////////
 //////// Add checkbox widgets and legends               //
///////////////////////////////////////////////////////////////
////////////////////Create a new label for this series of checkboxes
var extLabelcheckbox = ui.Label({value:'Concentration PM2.5 of image Sentinel 2',
style: {fontWeight: 'bold', fontSize: '15px', margin: '2px 2px', padding:'2px 60px',color:'208500',}
});
/////////////////////// Add checkboxes to our display
var extCheck031220 = ui.Checkbox({label:'03/12/2020',style: { margin: '1px 1px', padding:'4px 40px 0px 95px ',fontSize: '13px'}});
var extCheck061220 = ui.Checkbox({label:'06/12/2020',style: { margin: '1px 1px', padding:'1px 20px 0px 230px',fontSize: '13px'}});
var extCheck070121 = ui.Checkbox({label: '07/01/2021',style: { margin: '1px 1px', padding:'1px 40px 0px 95px',fontSize: '13px'}});
var extCheck120121 = ui.Checkbox({label: '12/01/2021',style: { margin: '1px 1px', padding:'1px 20px 0px 230px',fontSize: '13px'}});
var extCheck170121 = ui.Checkbox({label: '17/01/2021',style: { margin: '1px 1px', padding:'1px 40px 0px 95px',fontSize: '13px'}});
var extCheck060321 = ui.Checkbox({label: '06/03/2021',style: { margin: '1px 1px', padding:'1px 20px 0px 230px',fontSize: '13px'}});
var extCheck080321 = ui.Checkbox({label: '08/03/2021',style: { margin: '1px 1px', padding:'1px 40px 0px 95px',fontSize: '13px'}});
var extCheck110321 = ui.Checkbox({label: '11/03/2021',style: { margin: '1px 1px', padding:'1px 20px 0px 230px',fontSize: '13px'}});
var extCheck070421 = ui.Checkbox({label: '07/04/2021',style: { margin: '1px 1px', padding:'1px 40px 0px 95px',fontSize: '13px'}});
//Height Legend check box
function makeLegendPM25 (viridis) {
  var lon = ee.Image.pixelLonLat().select('longitude');
  var gradient = lon.multiply((viridis.max-viridis.min)/100.0).add(viridis.min);
  var legendImage = gradient.visualize(viridis);
  var thumb = ui.Thumbnail({
    image: legendImage, 
    params: {bbox:'0,0,100,8', dimensions:'300x10'},  
    style: {position: 'bottom-center',padding: '1px 60px', margin: '1px 1px'}
  });
  var panel2 = ui.Panel({
    widgets: [
      ui.Label('0'), 
      ui.Label({style: {stretch: 'horizontal'}}), 
      ui.Label('More 50')
    ],
    layout: ui.Panel.Layout.flow('horizontal'),
    style: {stretch: 'horizontal', maxWidth: '450px', padding: '1px 60px', margin: '2px 1px',fontSize: '12px',fontWeight: 'bold',}
  });
  return ui.Panel().add(panel2).add(thumb);
}
     //Extent 031220
var doCheckbox031220 = function() {
  extCheck031220.onChange(function(checked){
  classify_PM031220.setShown(checked);
  });
};
doCheckbox031220();
      //Extent 061220
var doCheckbox061220 = function() {
  extCheck061220.onChange(function(checked){
  classify_PM061220.setShown(checked);
  });
};
doCheckbox061220();
      //Extent 070121
var doCheckbox070121 = function() {
  extCheck070121.onChange(function(checked){
  classify_PM070121.setShown(checked);
  });
};
doCheckbox070121();
      //Extent 120121
var doCheckbox120121 = function() {
  extCheck120121.onChange(function(checked){
  classify_PM120121.setShown(checked);
  });
};
doCheckbox120121();
      //Extent 170121
var doCheckbox170121 = function() {
  extCheck170121.onChange(function(checked){
  classify_PM170121.setShown(checked);
  });
};
doCheckbox170121();
      //Extent 060321
var doCheckbox060321 = function() {
  extCheck060321.onChange(function(checked){
  classify_PM060321.setShown(checked);
  });
};
doCheckbox060321();
      //Extent 080321
var doCheckbox080321 = function() {
  extCheck080321.onChange(function(checked){
  classify_PM080321.setShown(checked);
  });
};
doCheckbox080321();
      //Extent 110321
var doCheckbox110321 = function() {
  extCheck110321.onChange(function(checked){
  classify_PM110321.setShown(checked);
  });
};
doCheckbox110321();
      //Extent 070421
var doCheckbox070421 = function() {
  extCheck070421.onChange(function(checked){
  classify_PM070421.setShown(checked);
  });
};
doCheckbox070421();
//////////////////////////
var line=ui.Label({
   value: '___________________________________________________________',
  style: { color: 'afea00',
    padding:'1px 10px 1px 10px ',
    margin: '1px 1px'   },});
///////////////////label NDVI////////////
var extLabelNDVI = ui.Label({value:'Index NDVI of image Sentinel 2',
style: {fontWeight: 'bold', fontSize: '15px', margin: '3px 2px', padding:'2px 60px',color:'208500',}
});
//Create key of items for dropdown
var P=' None select'
var P031220 = '03/12/2020';
var P061220 = '06/12/2020';
var P070121 = '07/01/2021';
var P120121 = '12/01/2021';
var P170121 = '17/01/2021';
var P060321 = '06/03/2021';
var P080321 = '08/03/2021';
var P110321 = '11/03/2021';
var P070421 = '07/04/2021';
//Construct Dropdown
var SelectNDVI = ui.Select({
  items:[P,P031220,P061220,P070121,P120121,P170121,P060321,P080321,P110321,P070421],
  placeholder:'   Choose date ',
  onChange: selectLayerNDVI,
  style: { padding: '1px 140px' ,margin: '1px 1px', }});
var constraints = [];
//Write a function that runs on change of Dropdown
function selectLayerNDVI(){
  var year = SelectNDVI.getValue() ;// get value from dropdown selection
  if (year == P031220){
Map.add(NDVI031220)//mapaddlayer
  Map.remove(NDVI061220)
  Map.remove(NDVI070121)
  Map.remove(NDVI120121)
  Map.remove(NDVI170121)
  Map.remove(NDVI060321)
  Map.remove(NDVI080321)
  Map.remove(NDVI110321)
  Map.remove(NDVI070421)
  }
  else if (year == P061220){
  Map.add(NDVI061220)
Map.remove(NDVI031220)
Map.remove(NDVI070121)
Map.remove(NDVI120121)
Map.remove(NDVI170121)
Map.remove(NDVI060321)
Map.remove(NDVI080321)
Map.remove(NDVI110321)
Map.remove(NDVI070421)
  }
  else if (year == P070121){
  Map.add(NDVI070121)
Map.remove(NDVI031220)
Map.remove(NDVI061220)
Map.remove(NDVI120121)
Map.remove(NDVI170121)
Map.remove(NDVI060321)
Map.remove(NDVI080321)
Map.remove(NDVI110321)
Map.remove(NDVI070421)
  }
  else if (year == P120121){
  Map.add(NDVI120121)
Map.remove(NDVI031220)
Map.remove(NDVI061220)
Map.remove(NDVI070121)
Map.remove(NDVI170121)
Map.remove(NDVI060321)
Map.remove(NDVI080321)
Map.remove(NDVI110321)
Map.remove(NDVI070421)
  }
  else if (year == P170121){
  Map.add(NDVI170121)
Map.remove(NDVI031220)
Map.remove(NDVI061220)
Map.remove(NDVI070121)
Map.remove(NDVI120121)
Map.remove(NDVI060321)
Map.remove(NDVI080321)
Map.remove(NDVI110321)
Map.remove(NDVI070421)
  }
  else if (year == P060321){
  Map.add(NDVI060321)
Map.remove(NDVI031220)
Map.remove(NDVI061220)
Map.remove(NDVI070121)
Map.remove(NDVI120121)
Map.remove(NDVI170121)
Map.remove(NDVI080321)
Map.remove(NDVI110321)
Map.remove(NDVI070421)
  }
  else if (year == P080321){
 Map.add(NDVI080321)
Map.remove(NDVI031220)
Map.remove(NDVI061220)
Map.remove(NDVI070121)
Map.remove(NDVI120121)
Map.remove(NDVI170121)
Map.remove(NDVI060321)
Map.remove(NDVI110321)
Map.remove(NDVI070421)
  }
  else if (year == P110321){
  Map.add(NDVI110321)
Map.remove(NDVI031220)
Map.remove(NDVI061220)
Map.remove(NDVI070121)
Map.remove(NDVI120121)
Map.remove(NDVI170121)
Map.remove(NDVI060321)
Map.remove(NDVI080321)
Map.remove(NDVI070421)
  }
  else if (year == P070421){
  Map.add(NDVI070421);
Map.remove(NDVI031220);
Map.remove(NDVI061220);
Map.remove(NDVI070121);
Map.remove(NDVI120121);
Map.remove(NDVI170121);
Map.remove(NDVI060321);
Map.remove(NDVI080321);
Map.remove(NDVI110321);
  }
   else if (year == P){
  Map.remove(NDVI070421);
Map.remove(NDVI031220);
Map.remove(NDVI061220);
Map.remove(NDVI070121);
Map.remove(NDVI120121);
Map.remove(NDVI170121);
Map.remove(NDVI060321);
Map.remove(NDVI080321);
Map.remove(NDVI110321);
  }
  else{
  }
}
//Add selecter and graph panel ;to main panel
// legend NDVI
function legendNDVI (viridis) {
  var lon = ee.Image.pixelLonLat().select('longitude');
  var gradient = lon.multiply((viridis.max-viridis.min)/100.0).add(viridis.min);
  var legendImage = gradient.visualize(viridis);
  var thumb = ui.Thumbnail({
    image: legendImage, 
  params: {bbox:'0,0,100,8', dimensions:'300x10'},  
    style: {position: 'bottom-center',padding: '1px 60px', margin: '1px 1px'}
  });
  var panel2 = ui.Panel({
    widgets: [
      ui.Label('0'), 
      ui.Label({style: {stretch: 'horizontal'}}), 
      ui.Label('1')
    ],
    layout: ui.Panel.Layout.flow('horizontal'),
     style: {stretch: 'horizontal', maxWidth: '450px', padding: '1px 60px', margin: '2px 1px',fontSize: '12px',fontWeight: 'bold',}
  });
  return ui.Panel().add(panel2).add(thumb);
}
////////////////////////////////////////////////////////////////////////////////
var line1=ui.Label({
  value: '___________________________________________________________',
  style: { color: 'afea00',
    padding:'1px 10px 1px 15px ',
    margin: '1px 1px'   },});
var extLabelSTATISTIC = ui.Label({value:'Statistic concentrations PM 2.5',
style: {fontWeight: 'bold', fontSize: '15px', margin: '3px 2px', padding:'2px 60px',color:'208500',}
});
//4.4) Add these new widgets to the panel in the order you want them to appear
panel.add(extLabelcheckbox)
      .add(extCheck031220)
      .add(extCheck061220)
      .add(extCheck070121)
      .add(extCheck120121)
      .add(extCheck170121)
      .add(extCheck060321)
      .add(extCheck080321)
      .add(extCheck110321)
      .add(extCheck070421)
      .add(makeLegendPM25(color))
      .add(line)
      .add(extLabelNDVI)
      .add(SelectNDVI)
      .add(legendNDVI(viz))
      .add(line1)
      .add(extLabelSTATISTIC)
    ;
//  7) Constuct graphs to measure extent for each year //
////////////////////////////////////////////////////////
//Generate a histogram data. Set the width of each of the histogram, or 2 N times
var option={
  title: 'Histogram of PM2.5 ', height:'200px', width:'10px', hAxis: {  title: 'Concentration of PM2.5 ',viewWindow: {min: 0, max: 100},}, vAxis: {title: 'Frequence'}, series: {    0: {color: 'green'}}}
var chart031220=ui.Chart.image.histogram(PM031220, hcm, 400).setOptions({
  title: 'Histogram of PM2.5 in 03/12/2020 ',  hAxis: {  title: 'Concentration of PM2.5 ',viewWindow: {min: 0, max: 100},}, vAxis: {title: 'Frequence'}, series: {    0: {color: 'green'}}});
var chart061220=ui.Chart.image.histogram(PM061220, hcm, 400).setOptions({
  title: 'Histogram of PM2.5 in 06/12/2020 ', hAxis: {  title: 'Concentration of PM2.5 ',viewWindow: {min: 0, max: 100},}, vAxis: {title: 'Frequence'}, series: {    0: {color: 'green'}}});
var chart070121=ui.Chart.image.histogram(PM070121, hcm, 400).setOptions({
  title: 'Histogram of PM2.5 in 07/01/2021 ', hAxis: {  title: 'Concentration of PM2.5 ',viewWindow: {min: 0, max: 100},}, vAxis: {title: 'Frequence'}, series: {    0: {color: 'green'}}});
var chart120121=ui.Chart.image.histogram(PM120121, hcm, 400).setOptions({
  title: 'Histogram of PM2.5 in 12/01/2021 ', hAxis: {  title: 'Concentration of PM2.5 ',viewWindow: {min: 0, max: 100},}, vAxis: {title: 'Frequence'}, series: {    0: {color: 'green'}}});
var chart170121=ui.Chart.image.histogram(PM170121, hcm, 400).setOptions({
  title: 'Histogram of PM2.5 in 17/01/2021 ', hAxis: {  title: 'Concentration of PM2.5 ',viewWindow: {min: 0, max: 100},}, vAxis: {title: 'Frequence'}, series: {    0: {color: 'green'}}});
var chart060321=ui.Chart.image.histogram(PM060321, hcm, 400).setOptions({
  title: 'Histogram of PM2.5 in 06/03/2021 ', hAxis: {  title: 'Concentration of PM2.5 ',viewWindow: {min: 0, max: 100},}, vAxis: {title: 'Frequence'}, series: {    0: {color: 'green'}}});
var chart080321=ui.Chart.image.histogram(PM080321, hcm, 400).setOptions({
  title: 'Histogram of PM2.5 in 08/03/2021 ', hAxis: {  title: 'Concentration of PM2.5 ',viewWindow: {min: 0, max: 100},}, vAxis: {title: 'Frequence'}, series: {    0: {color: 'green'}}});
var chart110321=ui.Chart.image.histogram(PM110321, hcm, 400).setOptions({
  title: 'Histogram of PM2.5 in 11/03/2021 ', hAxis: {  title: 'Concentration of PM2.5 ',viewWindow: {min: 0, max: 100},}, vAxis: {title: 'Frequence'}, series: {    0: {color: 'green'}}});
var chart070421=ui.Chart.image.histogram(PM070421, hcm, 400).setOptions({
  title: 'Histogram of PM2.5 in 07/04/2021 ', hAxis: {  title: 'Concentration of PM2.5 ',viewWindow: {min: 0, max: 100},}, vAxis: {title: 'Frequence'}, series: {    0: {color: 'green'}}});
////////////////////////////////////////
// Define a DataTable using a JavaScript array with a column property header.
   var dataTable =([
         ['Element', '0-10', '10-20', '20-30', '30-40',  '40-50',  'More 50'],
  ['03/12/2020', 848242.854, 677356.526,422494.842,235854.416,121071.5322 , 163606.238],
  ['06/12/2020', 846152.672, 691920.657,425270.750,223814.860,114897.913,166569.554],
  ['07/01/2021', 967095.950, 742114.484,403425.244,182994.003,80366.424,92630.302],
  ['12/01/2021', 679208.605, 570574.224,417333.008,282946.548,185668.085,332895.937],
  ['17/01/2021', 669370.617, 589232.285,429501.101,286464.415,179438.851,314619.138],
  ['06/03/2021', 675415.300, 607442.272,461189.716,292609.629,167952.517,259184.849],
  ['08/03/2021', 608706.054, 541932.935,443705.802,313963.630,204260.533,343176.516],
  ['11/03/2021', 658502.896, 582857.180,458446.313,307886.633,179982.080,271026.503],
  ['07/04/2021', 597078.639, 558842.467,467793.491,341520.234,211265.443,280948.840]
      ]);
var optionlinechart=({
  title: 'PM2.5 Air Quality 12/2020 - 04/2021',
 // width:'1000px',
  hAxis: {title: 'Date', titleTextStyle: {italic: true, bold: false}},
  vAxis: {title: ' Area (m2)', titleTextStyle: {italic: true, bold: false}},
  fontSize:'15px',
  legend: {position: 'bottom-right'},
  gridlines: {color: 'FFFFFF'},
  series: {
    0: {lineWidth: 2, color: '#008000', pointSize: 3},
    1: {lineWidth: 2, color: '#B1FB17', pointSize: 3},
    2: {lineWidth: 2, color: '#FFFF00', pointSize: 3},
    3: {lineWidth: 2, color: '#FFD801', pointSize: 3},
    4: {lineWidth: 2, color: '#FFA500', pointSize: 3},
    5: {lineWidth: 2, color: '#FF0000', pointSize: 3}
  }
 });
// Define the chart and print it to the console.
var linechart031220 = ui.Chart(dataTable).setChartType('LineChart').setOptions(optionlinechart);
 var linechart061220 = ui.Chart(dataTable).setChartType('LineChart').setOptions(optionlinechart);
 var linechart070121 = ui.Chart(dataTable).setChartType('LineChart').setOptions(optionlinechart);
  var linechart120121 = ui.Chart(dataTable).setChartType('LineChart').setOptions(optionlinechart);
  var linechart170121 = ui.Chart(dataTable).setChartType('LineChart').setOptions(optionlinechart);
  var linechart060321 = ui.Chart(dataTable).setChartType('LineChart').setOptions(optionlinechart);
  var linechart080321 = ui.Chart(dataTable).setChartType('LineChart').setOptions(optionlinechart);
  var linechart110321 = ui.Chart(dataTable).setChartType('LineChart').setOptions(optionlinechart);
  var linechart070421 = ui.Chart(dataTable).setChartType('LineChart').setOptions(optionlinechart);
 //////////////////////////////////////////////////////////////////////////////
///// bar chart
/////////////////////////////////////////
 var dataTable031220 =([
         ['Element', 'Area (m2)', { role: 'style' }],
  ['0-10', 848242.854, 'color: #008000'],
  ['10-20', 677356.526, 'color: #B1FB17'],
  ['20-30', 422494.842, 'color: #FFFF00'],
  ['30-40',235854.416, 'color: #FFD801'],
  ['40-50',121071.5322, 'color: #FFA500'],
  ['>50',  163606.238, 'color: #FF0000']
      ]);
// Define the chart and print it to the console.
var bar031220 = ui.Chart(dataTable031220).setChartType('ColumnChart').setOptions({
  title: 'Area PM2.5 in 03/12/2020 ',
  legend: {position: 'none'},
  hAxis: {title: 'Concentrations of PM2.5', titleTextStyle: {italic: true, bold: false}},
  vAxis: {title: ' Area (m2)', titleTextStyle: {italic:true, bold: false}},
  fontSize:'12px'
 });
/////////////////////////////////////////////
var dataTable061220 = [
   ['Element', 'Area (m2)', { role: 'style' }],
  ['0-10', 846152.672 , 'color: #008000'],
  ['10-20', 691920.657 , 'color: #B1FB17'],
  ['20-30', 425270.750 , 'color: #FFFF00'],
  ['30-40',223814.860 , 'color: #FFD801'],
  ['40-50',114897.913 , 'color: #FFA500'],
  ['>50',  166569.554 , 'color: #FF0000']
];
// Define the chart and print it to the console.
var bar061220 = ui.Chart(dataTable061220).setChartType('ColumnChart').setOptions({
  title: 'Area PM2.5 in 06/12/2020',
  legend: {position: 'none'},
  hAxis: {title: 'Concentrations of PM2.5', titleTextStyle: {italic: true, bold: false}},
  vAxis: {title: ' Area (m2)', titleTextStyle: {italic: true, bold: false}},
  //colors: ['1d6b99']
});
/////
    /////////////////////////////////////////////
var dataTable070121 = [
  ['Element', 'Area (m2)', { role: 'style' }],
  ['0-10', 967095.950 , 'color: #008000'],
  ['10-20', 742114.484  , 'color: #B1FB17'],
  ['20-30', 403425.244 , 'color: #FFFF00'],
  ['30-40',182994.003, 'color: #FFD801'],
  ['40-50',80366.424 , 'color: #FFA500'],
  ['>50',  92630.302, 'color: #FF0000']
];
// Define the chart and print it to the console.
var bar070121 = ui.Chart(dataTable070121).setChartType('ColumnChart').setOptions({
  title: 'Area PM2.5 in 07/01/2021 ',
  legend: {position: 'none'},
  hAxis: {title: 'Concentrations of PM2.5', titleTextStyle: {italic: true, bold: false}},
  vAxis: {title: ' Area (m2)', titleTextStyle: {italic: true, bold: false}},
//  colors: ['1d6b99']
});
/////
    /////////////////////////////////////////////
var dataTable120121 = [
   ['Element', 'Area (m2)', { role: 'style' }],
  ['0-10', 679208.605, 'color: #008000' ],
  ['10-20', 570574.224 , 'color: #B1FB17'],
  ['20-30', 417333.008, 'color: #FFFF00'],
  ['30-40',282946.548, 'color: #FFD801'],
  ['40-50',185668.085, 'color: #FFA500'],
  ['>50', 332895.937, 'color: #FF0000']
];
// Define the chart and print it to the console.
var bar120121 = ui.Chart(dataTable120121).setChartType('ColumnChart').setOptions({
  title: 'Area PM2.5 in 12/01/2021 ',
  legend: {position: 'none'},
  hAxis: {title: 'Concentrations of PM2.5', titleTextStyle: {italic: true, bold: false}},
  vAxis: {title: ' Area (m2)', titleTextStyle: {italic: true, bold: false}},
  colors: ['1d6b99']
});
/////
    /////////////////////////////////////////////
var dataTable170121 = [
  ['Element', 'Area (m2)', { role: 'style' }],
  ['0-10', 669370.617 , 'color: #008000'],
  ['10-20',589232.285 , 'color: #B1FB17'],
  ['20-30', 429501.101, 'color: #FFFF00'],
  ['30-40',286464.415, 'color: #FFD801'],
  ['40-50',179438.851, 'color: #FFA500'],
  ['>50', 314619.138, 'color: #FF0000']
];
// Define the chart and print it to the console.
var bar170121 = ui.Chart(dataTable170121).setChartType('ColumnChart').setOptions({
  title: 'Area PM2.5 in 17/01/2021 ',
  legend: {position: 'none'},
  hAxis: {title: 'Concentrations of PM2.5', titleTextStyle: {italic: true, bold: false}},
  vAxis: {title: ' Area (m2)', titleTextStyle: {italic: true, bold: false}},
  colors: ['1d6b99']
});
/////
    /////////////////////////////////////////////
var dataTable060321 = [
   ['Element', 'Area (m2)', { role: 'style' }],
  ['0-10', 675415.300, 'color: #008000' ],
  ['10-20',607442.272 , 'color: #B1FB17'],
  ['20-30', 461189.716, 'color: #FFFF00'],
  ['30-40',292609.629, 'color: #FFD801'],
  ['40-50',167952.517, 'color: #FFA500'],
  ['>50',259184.849, 'color: #FF0000']
];
// Define the chart and print it to the console.
var bar060321 = ui.Chart(dataTable060321).setChartType('ColumnChart').setOptions({
  title: 'Area PM2.5 in 06/03/2021 ',
  legend: {position: 'none'},
  hAxis: {title: 'Concentrations of PM2.5', titleTextStyle: {italic: true, bold: false}},
  vAxis: {title: ' Area (m2)', titleTextStyle: {italic: true, bold: false}},
 //colors: ['1d6b99']
});
/////
    /////////////////////////////////////////////
var dataTable080321 = [
   ['Element', 'Area (m2)', { role: 'style' }],
  ['0-10', 608706.054 , 'color: #008000'],
  ['10-20',541932.935 , 'color: #B1FB17'],
  ['20-30', 443705.802, 'color: #FFFF00'],
  ['30-40',313963.630, 'color: #FFD801'],
  ['40-50',204260.533, 'color: #FFA500'],
  ['>50',343176.516, 'color: #FF0000']
];
// Define the chart and print it to the console.
var bar080321 = ui.Chart(dataTable080321).setChartType('ColumnChart').setOptions({
  title: 'Area PM2.5 in 08/03/2021 ',
  legend: {position: 'none'},
  hAxis: {title: 'Concentrations of PM2.5', titleTextStyle: {italic: true, bold: false}},
  vAxis: {title: ' Area (m2)', titleTextStyle: {italic: true, bold: false}},
  //colors: ['1d6b99']
});
/////
 /////////////////////////////////////////////
var dataTable110321 = [
   ['Element', 'Area (m2)', { role: 'style' }],
  ['0-10', 658502.896 , 'color: #008000'],
  ['10-20',582857.180 , 'color: #B1FB17'],
  ['20-30',458446.313, 'color: #FFFF00'],
  ['30-40',307886.633, 'color: #FFD801'],
  ['40-50',179982.080, 'color: #FFA500'],
  ['>50',271026.503, 'color: #FF0000']
];
// Define the chart and print it to the console.
var bar110321 = ui.Chart(dataTable110321).setChartType('ColumnChart').setOptions({
  title: 'Area PM2.5 in 11/03/2021 ',
  legend: {position: 'none'},
  hAxis: {title: 'Concentrations of PM2.5', titleTextStyle: {italic: true, bold: false}},
  vAxis: {title: ' Area (m2)', titleTextStyle: {italic: true, bold: false}},
  //colors: ['1d6b99']
});
/////
 /////////////////////////////////////////////
var dataTable070421 = [
  ['Element', 'Area (m2)', { role: 'style' }],
  ['0-10',  597078.639, 'color: #008000' ],
  ['10-20',558842.467 , 'color: #B1FB17'],
  ['20-30',467793.491, 'color: #FFFF00'],
  ['30-40',341520.234, 'color: #FFD801'],
  ['40-50',211265.443, 'color: #FFA500'],
  ['>50',280948.840, 'color: #FF0000']
];
// Define the chart and print it to the console.
var bar070421= ui.Chart(dataTable070421).setChartType('ColumnChart').setOptions({
  title:  'Area PM2.5 in 07/04/2021', 
  fontSize: '15px',
  legend: {position: 'none'},
  hAxis: {title: 'Concentrations of PM2.5', titleTextStyle: {italic: true, bold: false}},
  vAxis: {title: ' Area (m2)', titleTextStyle: {italic: true, bold: false}},
  colors: ['1d6b99']
});
/////
//  8) Create a dropdown menu to display graph results //
////////////////////////////////////////////////////////
//Add a panel to hold graphs within main panel
var panelyear = ui.Panel({
  style:{width: '400px',position:'bottom-left'}
});
//Create key of items for dropdown
var P031220 = '03/12/2020';
var P061220 = '06/12/2020';
var P070121 = '07/01/2021';
var P120121 = '12/01/2021';
var P170121 = '17/01/2021';
var P060321 = '06/03/2021';
var P080321 = '08/03/2021';
var P110321 = '11/03/2021';
var P070421 = '07/04/2021';
//Construct Dropdown
var yearSelect = ui.Select({
  items:[P031220,P061220,P070121,P120121,P170121,P060321,P080321,P110321,P070421],
  placeholder:'   Choose date  ',
  onChange: selectLayer,
  style: { padding: '0px 140px',
  }
});
var constraints = [];
//Write a function that runs on change of Dropdown
function selectLayer(){
  var year = yearSelect.getValue() ;// get value from dropdown selection
  panelyear.clear(); //clear graph panel between selections so only one graph displays
  if (year == P031220){
panel.add(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);
    panelyear.add(chart031220);///histogram
panel.add(linechart031220);
panel.remove(linechart061220);
panel.remove(linechart070121);
panel.remove(linechart120121);
panel.remove(linechart170121);
panel.remove(linechart060321);
panel.remove(linechart080321);
panel.remove(linechart110321); 
panel.remove(linechart070421);
  }
  else if (year == P061220){
panel.add(bar061220);
panel.remove(bar031220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);
panelyear.add(chart061220);
panel.remove(linechart031220);
panel.add(linechart061220);
panel.remove(linechart070121);
panel.remove(linechart120121);
panel.remove(linechart170121);
panel.remove(linechart060321);
panel.remove(linechart080321);
panel.remove(linechart110321); 
panel.remove(linechart070421);
  }
  else if (year == P070121){
panel.add(bar070121);
panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);
panelyear.add(chart070121);
panel.remove(linechart031220);
panel.remove(linechart061220);
panel.add(linechart070121);
panel.remove(linechart120121);
panel.remove(linechart170121);
panel.remove(linechart060321);
panel.remove(linechart080321);
panel.remove(linechart110321); 
panel.remove(linechart070421);
  }
  else if (year == P120121){
panel.add(bar120121);
panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);
panelyear.add(chart120121);
panel.remove(linechart031220);
panel.remove(linechart061220);
panel.remove(linechart070121);
panel.add(linechart120121);
panel.remove(linechart170121);
panel.remove(linechart060321);
panel.remove(linechart080321);
panel.remove(linechart110321); 
panel.remove(linechart070421);
   }
  else if (year == P170121){
panel.add(bar170121);
panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);
panelyear.add(chart170121);
panel.remove(linechart031220);
panel.remove(linechart061220);
panel.remove(linechart070121);
panel.remove(linechart120121);
panel.add(linechart170121);
panel.remove(linechart060321);
panel.remove(linechart080321);
panel.remove(linechart110321); 
panel.remove(linechart070421);
  }
  else if (year == P060321){
panel.add(bar060321);
panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);     
panelyear.add(chart060321);
panel.remove(linechart031220);
panel.remove(linechart061220);
panel.remove(linechart070121);
panel.remove(linechart120121);
panel.remove(linechart170121);
panel.add(linechart060321);
panel.remove(linechart080321);
panel.remove(linechart110321); 
panel.remove(linechart070421);
  }
  else if (year == P080321){
panel.add(bar080321);
panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar110321); 
panel.remove(bar070421);     
panelyear.add(chart080321);
panel.remove(linechart031220);
panel.remove(linechart061220);
panel.remove(linechart070121);
panel.remove(linechart120121);
panel.remove(linechart170121);
panel.remove(linechart060321);
panel.add(linechart080321);
panel.remove(linechart110321); 
panel.remove(linechart070421);
  }
  else if (year == P110321){
panel.add(bar110321);        
panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar070421);
panelyear.add(chart110321);
panel.remove(linechart031220);
panel.remove(linechart061220);
panel.remove(linechart070121);
panel.remove(linechart120121);
panel.remove(linechart170121);
panel.remove(linechart060321);
panel.remove(linechart080321);
panel.add(linechart110321); 
panel.remove(linechart070421);
  }
  else if (year == P070421){
panel.add(bar070421);   
panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panelyear.add(chart070421);
panel.remove(linechart031220);
panel.remove(linechart061220);
panel.remove(linechart070121);
panel.remove(linechart120121);
panel.remove(linechart170121);
panel.remove(linechart060321);
panel.remove(linechart080321);
panel.remove(linechart110321); 
panel.add(linechart070421);
  }
  else{}
}
//Add selecter and graph panel ;to main panel
panel.add(yearSelect)
      .add(panelyear);
///////      //////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////create thumbnails/////////////////////////////////////////
var sample   = TOA031220.visualize({'forceRgbOutput':true,min: 0.0, max: 0.3, bands:  ['B4', 'B3', 'B2']});
var PM25_031220 = reclassify_PM031220.clip(hcm).visualize({'forceRgbOutput':true,'palette':'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'});
var PM25_061220 = reclassify_PM061220.clip(hcm).visualize({'forceRgbOutput':true,'palette':'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'});
var PM25_070121 = reclassify_PM070121.clip(hcm).visualize({'forceRgbOutput':true,'palette':'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'});
var PM25_120121 = reclassify_PM120121.clip(hcm).visualize({'forceRgbOutput':true,'palette':'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'});
var PM25_170121 = reclassify_PM170121.clip(hcm).visualize({'forceRgbOutput':true,'palette':'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'});
var PM25_060321 = reclassify_PM060321.clip(hcm).visualize({'forceRgbOutput':true,'palette':'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'});
var PM25_080321 = reclassify_PM080321.clip(hcm).visualize({'forceRgbOutput':true,'palette':'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'});
var PM25_110321 = reclassify_PM110321.clip(hcm).visualize({'forceRgbOutput':true,'palette':'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'});
var PM25_070421 = reclassify_PM070421.clip(hcm).visualize({'forceRgbOutput':true,'palette':'E5E4E2,008000,B1FB17,FFFF00,FFD801,FFA500,FF0000'});
var list1 = [sample,PM25_031220,PM25_061220,PM25_070121,PM25_120121,PM25_170121,PM25_060321,PM25_080321,PM25_110321,PM25_070421];
var PM25 = ee.ImageCollection.fromImages(list1);
var polygon = geometry;
var param= ({
  collection: PM25,
  description: 'video_3',
  dimensions: 750,
  framesPerSecond: 0.7,
  region: JSON.stringify(polygon.getInfo())
});
// //////////////////////////Print the GIF URL to the console.////////////////////////////////
//print(PM25.getVideoThumbURL(param));
/////////////////////////add panel///////////////////////////////////
//panel.add(ui.Thumbnail(PM25,param));
var nameThumb = ui.Label('Timelapse: 12/2020-04/2021',{
  stretch:'horizontal',
  textAlign:'center',
  fontWeight:'bold',
  fontSize:'13px',
  color:'black',
  padding: '10px ',
  position:'bottom-right'
});
/////////////// Add a thumbnail and select data set parameters
var thumb = ui.Thumbnail({
  image: PM25,
  params: param,
  style: {
    position: 'bottom-right',
    width: '200px',
    height: '200px'
  }});
Map.add(thumb);
Map.add(nameThumb);
//////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////  ////
  ///////////  // Create the panel for the legend items..////////////////////////////
var legend = ui.Panel({
  style: {
    position: 'top-right',
    padding: '10px 20px',
    color:'black',
    textAlign:'justify'
      }
});
// Create and add the legend title.
var legendTitle = ui.Label({
  value: ' Concentrations',
  style: {
    fontWeight: 'bold',
    fontSize: '13px',
    margin: '0 0 4px 0',
    padding: '0',
     }
});
legend.add(legendTitle);
var loading = ui.Label('Loading legend...', {margin: '2px 0 4px 0'});
legend.add(loading);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      // Use padding to give the box height and width.
      padding: '10px',
      margin: '0 0 4px 0',
    }
  });
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'},
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
}; 
// Get the list of palette colors and class names from the image.
PM031220.toDictionary().evaluate(function(result) {
  var palette =['008000','B1FB17','FFFF00','FFD801','FFA500','FF0000'];
  var names = ['0 - 10', '10 - 20', '20 - 30', '30 - 40', '40 - 50',' > 50'];
  loading.style().set('shown', false);
  for (var i = 0; i < names.length; i++) {
    legend.add(makeRow(palette[i], names[i]));
  }
  });
// Add the legend to the map.
Map.add(legend);
//panel.add(legend)
///////////////////////////////////////// Tên bản đồ/////////////////////////////////
var ten = ui.Label('Distribution PM2.5 in Ho Chi Minh city',{
  stretch:'horizontal',
  textAlign:'center',
  fontWeight:'bold',
  fontSize:'20px',
  color:'41A317',
  margin:'10px 10px',
  padding: '12px ',
});
Map.add(ten);
/////////////////////// Create an inspector panel./////////////////////////////////
 ///////////////////////////////////////////////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector1 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'black',
      }
});
// Add a label to the panel.
inspector1.add(ui.Label(' PM2.5 in 03/12/2020', {fontSize:'13px',}));
// Add the panel to the default map.
Map.add(inspector1);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector1.clear();
  inspector1.style().set('shown', true);
  inspector1.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM031220.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector1.clear();
    // Add a label with the results from the server.
    inspector1.add(ui.Label({
      value: '03/12/2020: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
 ///////////////////////////////////////////////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector2 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'black',
      }
});
// Add a label to the panel.
inspector2.add(ui.Label('PM2.5 in 06/12/2020', {fontSize:'13px',}));
// Add the panel to the default map.
Map.add(inspector2);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector2.clear();
  inspector2.style().set('shown', true);
  inspector2.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM061220.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector2.clear();
    // Add a label with the results from the server.
    inspector2.add(ui.Label({
      value: '06/12/2020: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector3 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'black',
      }
});
// Add a label to the panel.
inspector3.add(ui.Label('PM2.5 in 07/01/2021', {fontSize:'13px',}));
// Add the panel to the default map.
Map.add(inspector3);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector3.clear();
  inspector3.style().set('shown', true);
  inspector3.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM070121.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector3.clear();
    // Add a label with the results from the server.
    inspector3.add(ui.Label({
      value: '07/01/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector4 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'black',
      }
});
// Add a label to the panel.
inspector4.add(ui.Label('PM2.5 in 12/01/2021', {fontSize:'13px',}));
// Add the panel to the default map.
Map.add(inspector4);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector4.clear();
  inspector4.style().set('shown', true);
  inspector4.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM120121.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector4.clear();
    // Add a label with the results from the server.
    inspector4.add(ui.Label({
      value: '12/01/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector5 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'black',
      }
});
// Add a label to the panel.
inspector5.add(ui.Label('PM2.5 in 17/01/2021', {fontSize:'13px',}));
// Add the panel to the default map.
Map.add(inspector5);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector5.clear();
  inspector5.style().set('shown', true);
  inspector5.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM170121.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector5.clear();
    // Add a label with the results from the server.
    inspector5.add(ui.Label({
      value: '17/01/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector6 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'black',
      }
});
// Add a label to the panel.
inspector6.add(ui.Label('PM2.5 in 06/03/2021', {fontSize:'13px',}));
// Add the panel to the default map.
Map.add(inspector6);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector6.clear();
  inspector6.style().set('shown', true);
  inspector6.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM060321.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector6.clear();
    // Add a label with the results from the server.
    inspector6.add(ui.Label({
      value: '06/03/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector7 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'black',
      }
});
// Add a label to the panel.
inspector7.add(ui.Label('PM2.5 in 08/03/2021', {fontSize:'13px',}));
// Add the panel to the default map.
Map.add(inspector7);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector7.clear();
  inspector7.style().set('shown', true);
  inspector7.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM080321.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector7.clear();
    // Add a label with the results from the server.
    inspector7.add(ui.Label({
      value: '08/03/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector8 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'black',
      }
});
// Add a label to the panel.
inspector8.add(ui.Label('PM2.5 in 11/03/2021', {fontSize:'13px',}));
// Add the panel to the default map.
Map.add(inspector8);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector8.clear();
  inspector8.style().set('shown', true);
  inspector8.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM110321.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector8.clear();
    // Add a label with the results from the server.
    inspector8.add(ui.Label({
      value: '11/03/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector9 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'black',
      }
});
// Add a label to the panel.
inspector9.add(ui.Label('PM2.5 in 07/04/2021', {fontSize:'13px',}));
// Add the panel to the default map.
Map.add(inspector9);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector9.clear();
  inspector9.style().set('shown', true);
  inspector9.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM070421.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector9.clear();
    // Add a label with the results from the server.
    inspector9.add(ui.Label({
      value: '07/04/2021: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
  });
});
// Create an inspector panel with a horizontal layout.jj
var inspector = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'208500',
    fontWeight:'bold',
  fontSize:'25px',
 // backgroundColor: ''
      }
});
// Add a label to the panel.
inspector.add(ui.Label('Click map to get PM2.5', {fontSize:'15px',}));
// Add the panel to the default map.
Map.add(inspector);