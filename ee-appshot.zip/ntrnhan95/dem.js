var bt = ui.import && ui.import("bt", "table", {
      "id": "users/ntrnhan95/bentreNORIVER"
    }) || ee.FeatureCollection("users/ntrnhan95/bentreNORIVER");
 ////////////////////////////////////loc may/////////////////////////////////////////////////////////
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
// Load Sentinel-2 TOA reflectance data.
var image2018 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2018-1-01', '2018-4-30')
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);
var image2019 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2019-1-01', '2019-4-30')
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);
var image2020 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2020-1-01', '2020-4-30')
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);
var image2021 = ee.ImageCollection('COPERNICUS/S2')
                  .filterDate('2021-1-01', '2021-4-30')
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
                  .map(maskS2clouds);
 //cat ranh gioi                 
var Sentinel_2018=image2018.median().clip(bt);
var Sentinel_2019=image2019.median().clip(bt);
var Sentinel_2020=image2020.median().clip(bt);
var Sentinel_2021=image2021.median().clip(bt);
// Display the study area
Map.setCenter(106.49689397454034,10.171810557425372, 10);
//hien thi map
var rgbVis = {
  min: 0.0,
  max: 0.3,
  bands: ['B11', 'B6', 'B5'],
};
Map.addLayer(Sentinel_2018, rgbVis, 'RGB',0);
/////////////////////////////////// calculate evi/////////////////////////////
//color
 var viz={min:0, max:1,palette:['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01', '011301']};
var evi_2018=Sentinel_2018.expression(
    '2.5*((NIR-RED)/(NIR+6*RED-7.5*BLUE+1))',{
      'NIR':Sentinel_2018.select('B8'),
      'RED':Sentinel_2018.select('B4'),
      'BLUE':Sentinel_2018.select('B2'),
    });      
var evi_2019=Sentinel_2019.expression(
    '2.5*((NIR-RED)/(NIR+6*RED-7.5*BLUE+1))',{
      'NIR':Sentinel_2019.select('B8'),
      'RED':Sentinel_2019.select('B4'),
      'BLUE':Sentinel_2019.select('B2'),
    }); 
var evi_2020=Sentinel_2020.expression(
    '2.5*((NIR-RED)/(NIR+6*RED-7.5*BLUE+1))',{
      'NIR':Sentinel_2020.select('B8'),
      'RED':Sentinel_2020.select('B4'),
      'BLUE':Sentinel_2020.select('B2'),
    });
var evi_2021=Sentinel_2021.expression(
    '2.5*((NIR-RED)/(NIR+6*RED-7.5*BLUE+1))',{
      'NIR':Sentinel_2021.select('B8'),
      'RED':Sentinel_2021.select('B4'),
      'BLUE':Sentinel_2021.select('B2'),
    });
//phan loai
function reclass_evi (evi_2018) {
  return evi_2018.expression(
    '(b(0) <0.241) ? 0'+ //Очень сильная почва
     ':(b(0) < 0.430) ? 1'+ // Сильная почва            
     ':(b(0) <0.525) ? 2'+ // Средняя почва 
        ' :b(0) < 0.572 ? 3'+ // Слабая почва
         ': b(0) > 0.572 ? 4'+ // Незасоленная почва
        ': 0');  
}
function reclass_evi (evi_2019) {
  return evi_2019.expression(
    '(b(0) <0.241) ? 0'+ //Очень сильная почва
     ':(b(0) < 0.430) ? 1'+ // Сильная почва            
     ':(b(0) <0.525) ? 2'+ // Средняя почва 
        ' :b(0) < 0.572 ? 3'+ // Слабая почва
         ': b(0) > 0.572 ? 4'+ // Незасоленная почва
        ': 0');  
}
function reclass_evi (evi_2020) {
  return evi_2020.expression(
    '(b(0) <0.241) ? 0'+ //Очень сильная почва
     ':(b(0) < 0.430) ? 1'+ // Сильная почва            
     ':(b(0) <0.525) ? 2'+ // Средняя почва 
        ' :b(0) < 0.572 ? 3'+ // Слабая почва
         ': b(0) > 0.572 ? 4'+ // Незасоленная почва
        ': 0');  
}
function reclass_evi (evi_2021) {
  return evi_2021.expression(
    '(b(0) <0.241) ? 0'+ //Очень сильная почва
     ':(b(0) < 0.430) ? 1'+ // Сильная почва            
     ':(b(0) <0.525) ? 2'+ // Средняя почва 
        ' :b(0) < 0.572 ? 3'+ // Слабая почва
         ': b(0) > 0.572 ? 4'+ // Незасоленная почва
        ': 0');  
}
var reclass_2018 = reclass_evi(evi_2018);
var reclass_2019 = reclass_evi(evi_2019);
var reclass_2020 = reclass_evi(evi_2020);
var reclass_2021 = reclass_evi(evi_2021);
// tinh dien tich tung doi tuong
// add band + chuyen doi don vi ve hecta
var area_nd2018 = ee.Image.pixelArea().addBands(reclass_2018).divide(10000);
var area_nd2019 = ee.Image.pixelArea().addBands(reclass_2019).divide(10000);
var area_nd2020 = ee.Image.pixelArea().addBands(reclass_2020).divide(10000);
var area_nd2021 = ee.Image.pixelArea().addBands(reclass_2021).divide(10000);
var reduction_results2018 = area_nd2018.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: bt,
  scale: 30,
  bestEffort: true,
});
var reduction_results2019 = area_nd2019.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: bt,
  scale: 30,
  bestEffort: true,
});
var reduction_results2020 = area_nd2020.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: bt,
  scale: 30,
  bestEffort: true,
});
var reduction_results2021 = area_nd2021.reduceRegion({
  reducer: ee.Reducer.sum().group({
    groupField: 1,
    groupName: 'nd_reclass_value',
  }),
  geometry: bt,
  scale: 30,
  bestEffort: true,
});
// hien thi dien tich
//print('2018: Очень сильная почва(0), Сильная почва (1), Средняя почва(2), Слабая почва(3),Незасоленная почва(4)', reduction_results2018);
//print('2019: Очень сильная почва(0), Сильная почва (1), Средняя почва(2), Слабая почва(3),Незасоленная почва(4)', reduction_results2019);
//print('2020: Очень сильная почва(0), Сильная почва (1), Средняя почва(2), Слабая почва(3),Незасоленная почва(4)', reduction_results2020);
//print('2021: Очень сильная почва(0), Сильная почва (1), Средняя почва(2), Слабая почва(3),Незасоленная почва(4)', reduction_results2021);
//hien thi ban do man
var reclass_2018=reclass_2018.clip(bt);
var reclass_2019=reclass_2019.clip(bt);
var reclass_2020=reclass_2020.clip(bt);
var reclass_2021=reclass_2021.clip(bt);
//Map.addLayer(reclass_2018,{'palette': 'FF0000,FFA500,FFFF00, 00FFFF,008000'},'Засоленная почва 2018');
//Map.addLayer(reclass_2019,{'palette': 'FF0000,FFA500,FFFF00, 00FFFF,008000'},'Засоленная почва 2019',0);
//Map.addLayer(reclass_2020,{'palette': 'FF0000,FFA500,FFFF00, 00FFFF,008000'},'Засоленная почва 2020',0);
//Map.addLayer(reclass_2021,{'palette': 'FF0000,FFA500,FFFF00, 00FFFF,008000'},'Засоленная почва 2021',0);
//////////////////////DEM
var dataset = ee.Image('USGS/SRTMGL1_003');
var DEM = dataset.select('elevation');
//var slope = ee.Terrain.slope(elevation);
var viz = {
  min: -1,
  max: 10,
  palette: ['0000FF','008000','FFA500','FF0000']
};
Map.setCenter(106.49689397454034,10.171810557425372, 10);
Map.addLayer(DEM.clip(bt),viz, 'elevation');
/*Export.image.toDrive({
  image:elevation,
  description: 'DEM_BT',
  scale: 30,
  region: bt,
  fileFormat: 'GeoTIFF',
  formatOptions: {
    cloudOptimized: true
  }
});
*/
{
var min = ee.Number(DEM.reduceRegion({
reducer: ee.Reducer.min(),
geometry: bt,
scale: 30,
maxPixels: 1e9
}).values().get(0));
print(min, 'min elevation');
var max = ee.Number(DEM.reduceRegion({
reducer: ee.Reducer.max(),
geometry: bt,
scale: 30,
maxPixels: 1e9
}).values().get(0));
print(max, 'max elevation')
}
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'DEM',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
 // Add the title to the panel
legend.add(legendTitle); 
// create the legend image
// create the legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// create text on top of legend
var panel = ui.Panel({
    widgets: [
      ui.Label(viz['max'])
    ],
  });
legend.add(panel);
// create thumbnail from the image
var thumbnail = ui.Thumbnail({
  image: legendImage, 
  params: {bbox:'0,0,10,100', dimensions:'10x200'},  
  style: {padding: '1px', position: 'bottom-center'}
});
// add the thumbnail to the legend
legend.add(thumbnail);
// create text on top of legend
var panel = ui.Panel({
    widgets: [
      ui.Label(viz['min'])
    ],
  });
legend.add(panel);
Map.add(legend);
  ///////////////////////////////////////////////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector = ui.Panel({
 style: {
    position: 'top-left',
    padding: '10px 10px',
    color:'green',
     fontWeight:'bold',
  fontSize:'20px',
      }
});
// Add a label to the panel.
inspector.add(ui.Label('Click map to get elevation'));
// Add the panel to the default map.
Map.add(inspector);
// Set the default map's cursor to a "crosshair".
Map.style().set('cursor', 'crosshair');
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector.clear();
  inspector.style().set('shown', true);
  inspector.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = DEM.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
print(computedValue,"ELEVATION");
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector.clear();
    // Add a label with the results from the server.
    inspector.add(ui.Label({
      value: 'ELEVATION: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
    // Add a button to hide the Panel.
    inspector.add(ui.Button({
      label: 'Close',
      onClick: function() {
        inspector.style().set('shown', false);
      }
    }));
  });
});
///////////////////////////
// Show the composite image for November 2019
Map.addLayer(DEM.clip(bt), viz, "Elevation");
// Split Panels
// Map 2
var map2 = ui.Map();
// Show the composite image for June 2020
//Map.addLayer(DEM, viz, "Elevation");
// Show the classification result for November 2019
map2.addLayer(reclass_2018,{'palette': 'FF0000,FFA500,FFFF00, 00FFFF,008000'},'Засоленная почва 2018');
map2.addLayer(reclass_2019,{'palette': 'FF0000,FFA500,FFFF00, 00FFFF,008000'},'Засоленная почва 2019',0);
map2.addLayer(reclass_2020,{'palette': 'FF0000,FFA500,FFFF00, 00FFFF,008000'},'Засоленная почва 2020',0);
map2.addLayer(reclass_2021,{'palette': 'FF0000,FFA500,FFFF00, 00FFFF,008000'},'Засоленная почва 2021',0);
// Link the two panels
var linker = ui.Map.Linker([ui.root.widgets().get(0), map2]);
// Create the split panels
var splitPanel = ui.SplitPanel({
  firstPanel: linker.get(0),
  secondPanel: linker.get(1),
  orientation: 'horizontal',
  wipe: true,
  style: {stretch: 'both'}
});
// Set the split panels to ui roots
ui.root.widgets().reset([splitPanel]);
// Set the view center
linker.get(0).setCenter(106.49689397454034,10.171810557425372, 11);
// Add map legend
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
var legend2 = ui.Label({
  value: 'SALT',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
legend.add(legend2);
// Creates the content of the legend
var content = function(colour, label) {
      // Create the coloured boxes
      var box = ui.Label({
        style: {
          backgroundColor:  colour,
          // Set box height and width
          padding: '9px',
          margin: '0 0 4px 0'
        }
      });
      // Create the labels
      var labels = ui.Label({
        value: label,
        style: {margin: '0 0 4px 6px'}
      });
      return ui.Panel({
        widgets: [box, labels],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Set legend colours
var classColour =['008000','00FF00','FFFF00','FFA500' ,'FF0000'];
//var classColour = ['green','brown','blue'];
// Set legend labels
var labelName = ['nonsaline', 'slightly saline', 'moderately saline', '(strongly saline',' extremely saline'];
// Combine legend colour and labels
for (var i = 0; i < 5; i++) {
  legend.add(content(classColour[i], labelName[i]));
  }  
// Add legend
map2.add(legend);
var ten = ui.Label('BẢN ĐỒ MẶN ',{
  stretch:'horizontal',
  position:'top-right',
  fontWeight:'bold',
  fontSize:'20px',
  color:'000000',
  padding: '5px',
});
map2.add(ten);