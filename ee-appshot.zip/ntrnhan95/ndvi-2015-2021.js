var geometryGradientBar = ui.import && ui.import("geometryGradientBar", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                103.90111004112039,
                13.43726178702893
              ],
              [
                103.90111004112039,
                13.180671623324509
              ],
              [
                105.06016765830789,
                13.180671623324509
              ],
              [
                105.06016765830789,
                13.43726178702893
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[103.90111004112039, 13.43726178702893],
          [103.90111004112039, 13.180671623324509],
          [105.06016765830789, 13.180671623324509],
          [105.06016765830789, 13.43726178702893]]], null, false),
    geometryLabel = ui.import && ui.import("geometryLabel", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            103.92110487355095,
            14.606075411754135
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Point([103.92110487355095, 14.606075411754135]);
Map.setCenter(108.11195796966325,15.235066846098855, 5);
// Define a mask to clip the NDVI data by.
var mask = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017')
     .filter(ee.Filter.inList("country_na",["Vietnam"])).geometry();
var region = mask;
// make a list with years
var years = ee.List.sequence(2015,2021,1);
var months = ee.List.sequence(1,12,1);
// Fetch a MODIS NDVI collection and select NDVI.
var col =ee.ImageCollection("NOAA/VIIRS/001/VNP13A1").select('NDVI');
var col =  ee.ImageCollection.fromImages(
  years.map(function (y) {
    return months.map(function(m){
      var start = ee.Date.fromYMD(y,m,1).advance(-1,"month");
      var end = ee.Date.fromYMD(y,m,1).advance(1,"month");
      var w = col.filterDate(start,end).max();    
      return w.set('year', y)
              .set('month', m)
              .set('system:time_start',start);
  })}).flatten()
);
// Define RGB visualization parameters.
var visParams = {
  min: 3000.0,
  max: 10000.0,
  palette: [
    'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01', '011301'
  ],
};
var vn=col.mean().clip(mask);
//Map.getCenter(geometry,7);
Map.addLayer(vn,visParams,'NDVI')
// Add a color gradient bar with a label.
geometryGradientBar = geometryGradientBar; // <-- this is a drawn geometry;
var style = require('users/gena/packages:style');
var utils = require('users/gena/packages:utils');
var txt = require('users/gena/packages:text');
var min = 0;
var max = 1;
var textProperties = {
  fontSize: 14,
  textColor: 'ffffff',
  outlineColor: '000000',
  outlineWidth: 0,
  outlineOpacity: 0.6
};
var labels = ee.List.sequence(min, max);
var gradientBar = style.GradientBar.draw(geometryGradientBar, {
  min: min, max: max, palette: visParams.palette, labels: labels,
  format: '%.0f', text: textProperties
});
var label = 'NDVI';
var scale = Map.getScale() * 1; // scale text font relative to the current map scale
geometryLabel = geometryLabel;  // <-- this comes from drawn point geometry
//var text = text.draw(label, geometryLabel, scale, {fontSize: 32});
// Create RGB visualization images for use as animation frames.
// Blend the gradient bar and label images to the NDVI images.
var rgbVis =col.map(function(img) {
  var y = ee.Number(img.get("year")).toInt()
 var m = ee.Number(img.get("month")).toInt()
 var label = ee.String(y).cat("-").cat(m)
  var text = txt.draw(label, geometryLabel, scale, {fontSize: 14});
  return img.visualize(visParams).clip(mask).blend(gradientBar).blend(text);
});
print(rgbVis)
// Define GIF visualization arguments.//
var gifParams = {
  'region': region,
  'dimensions': 600,
  'crs': 'EPSG:32648',
  'framesPerSecond': 3,
  'format': 'gif'
};
// Print the GIF URL to the console.
print(rgbVis.getVideoThumbURL(gifParams));
// Render the GIF animation in the console.
//print(ui.Thumbnail(rgbVis, gifParams));
var pnl_main = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: {width: '300px'}});
pnl_main.add(ui.Thumbnail(rgbVis, gifParams));
ui.root.insert(0, pnl_main);
  var title = ui.Label('NDVI 2015-2021', {
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight: 'bold',
  fontSize: '25px',
  color: '437C17'
 });
Map.add(title);