var hcm = ui.import && ui.import("hcm", "table", {
      "id": "users/ntrnhan95/centre_hcm"
    }) || ee.FeatureCollection("users/ntrnhan95/centre_hcm");
///////////////////////////////////////////////////////////////
//                    1) Import Layers of Interest           //
///////////////////////////////////////////////////////////////
///layer bui pm2,5
var PM031220 = ee.Image('users/ntrnhan95/PM25_031220');
var PM061220 = ee.Image('users/ntrnhan95/PM25_061220');
var PM070121 = ee.Image('users/ntrnhan95/PM25_070121');
var PM120121 = ee.Image('users/ntrnhan95/PM25_120121');
var PM170121 = ee.Image('users/ntrnhan95/PM25_170121');
var PM060321 = ee.Image('users/ntrnhan95/PM25_060321');
var PM080321 = ee.Image('users/ntrnhan95/PM25_080321');
var PM110321 = ee.Image('users/ntrnhan95/PM25_110321');
var PM070421 = ee.Image('users/ntrnhan95/PM25_070421');
/// layer classify pm2.5
var reclassify_PM031220 = ee.Image('users/ntrnhan95/classify031220');
var reclassify_PM061220 = ee.Image('users/ntrnhan95/classify061220');
var reclassify_PM070121 = ee.Image('users/ntrnhan95/classify070121');
var reclassify_PM120121 = ee.Image('users/ntrnhan95/classify120121');
var reclassify_PM170121 = ee.Image('users/ntrnhan95/classify170121');
var reclassify_PM060321 = ee.Image('users/ntrnhan95/classify060321');
var reclassify_PM080321 = ee.Image('users/ntrnhan95/classify080321');
var reclassify_PM110321 = ee.Image('users/ntrnhan95/classify110321');
var reclassify_PM070421 = ee.Image('users/ntrnhan95/classify070421');
var border = ee.Image().byte().paint({featureCollection:hcm, color: 1, width : 2});
Map.addLayer(border,{palette:'FFFF00'},'hcm');
//////////////////////////////////////////////////////////////
//      2) Begin setting up map appearance and app layers   //
///////////////////////////////////////////////////////////////
//2.1) Set up general display
//Set up a satellite background
Map.setOptions('Satellite')
//Center the map to HCM
Map.setCenter(106.65616535852088,10.795687006259966, 11);
//Change style of cursor to 'crosshair'
Map.style().set('cursor', 'crosshair');
//2.2) We want to set up a Viridis color pallete to display the Simard data
var color = {min: 0 , max : 5,palette : ['E5E4E2','008000','B1FB17','FFFF00','FFD801','FFA500','FF0000']};
//2.3) Create variables for GUI layers for each layer
//We set each layer to "false" so the user can turn them on later
var classify_PM031220 = ui.Map.Layer(reclassify_PM031220.clip(hcm), color, 'classify_PM031220')
var classify_PM061220 = ui.Map.Layer(reclassify_PM061220.clip(hcm), color, 'classify_PM061220')
var classify_PM070121 = ui.Map.Layer(reclassify_PM070121.clip(hcm), color, 'classify_PM070121')
var classify_PM120121 = ui.Map.Layer(reclassify_PM120121.clip(hcm), color, 'classify_PM120121')
var classify_PM170121 = ui.Map.Layer(reclassify_PM170121.clip(hcm), color, 'classify_PM170121')
var classify_PM060321 = ui.Map.Layer(reclassify_PM060321.clip(hcm), color, 'classify_PM060321')
var classify_PM080321 = ui.Map.Layer(reclassify_PM080321.clip(hcm), color, 'classify_PM080321')
var classify_PM110321 = ui.Map.Layer(reclassify_PM110321.clip(hcm), color, 'classify_PM110321')
var classify_PM070421 = ui.Map.Layer(reclassify_PM070421.clip(hcm), color, 'classify_PM070421')
///////////////////////////////////////////////////////////////
//      3) Set up panels and widgets for display             //
///////////////////////////////////////////////////////////////
//3.2) Create a panel to hold text
var panel = ui.Panel({
   style: {
       padding: '10px 10px',
    width: '30%',
     }
  });
//3.3) Create variable for additional text and separators
//This creates another panel to house a line separator and instructions for the user
var intro = ui.Panel([
 // ui.Label({
  //  value: '____________________________________________',
   // style: {fontWeight: 'bold',  color: '4A997E'},
  //}),
  ui.Label({
    value:'Select layers to display map, histogram and chart',
    style: {fontSize: '15px',
    fontWeight: 'bold',
    padding: '10px 8px',
      color:'41A317',
    }
  })]);
//Add this new panel to the larger panel we created 
panel.add(intro)
//3.4) Add our main panel to the root of our GUI
ui.root.insert(1,panel);
//  7) Constuct graphs to measure extent for each year //
////////////////////////////////////////////////////////
var chart031220=ui.Chart.image.histogram(PM031220, hcm, 400).setOptions({title: 'Histogram of PM2.5'});
var chart061220=ui.Chart.image.histogram(PM061220, hcm, 400).setOptions({title: 'Histogram of PM2.5'});
var chart070121=ui.Chart.image.histogram(PM070121, hcm, 400).setOptions({title: 'Histogram of PM2.5'});
var chart120121=ui.Chart.image.histogram(PM120121, hcm, 400).setOptions({title: 'Histogram of PM2.5 '});
var chart170121=ui.Chart.image.histogram(PM170121, hcm, 400).setOptions({title: 'Histogram of PM2.5 '});
var chart060321=ui.Chart.image.histogram(PM060321, hcm, 400).setOptions({title: 'Histogram of PM2.5 '});
var chart080321=ui.Chart.image.histogram(PM080321, hcm, 400).setOptions({title: 'Histogram of PM2.5 '});
var chart110321=ui.Chart.image.histogram(PM110321, hcm, 400).setOptions({title: 'Histogram of PM2.5 '});
var chart070421=ui.Chart.image.histogram(PM070421, hcm, 400).setOptions({title: 'Histogram of PM2.5 '});
//
///// bar chart
/////////////////////////////////////////
// Define a DataTable using a JavaScript array with a column property header.
var dataTable031220 = [
  [
    {label: 'State', role: 'domain', type: 'string'},
    {label: 'Population', role: 'data', type: 'number'},
  ],
  ['0-10', 848242.854 ],
  ['10-20', 677356.526],
  ['20-30', 422494.842],
  ['30-40',235854.416],
  ['40-50',121071.5322],
  ['>50',  163606.238]
];
// Define the chart and print it to the console.
var bar031220 = ui.Chart(dataTable031220).setChartType('ColumnChart').setOptions({
  title: 'Diện tích ....',
  legend: {position: 'none'},
  hAxis: {title: 'Nồng độ', titleTextStyle: {italic: false, bold: true}},
  vAxis: {title: ' Diện tích (m2)', titleTextStyle: {italic: false, bold: true}},
  colors: ['1d6b99']
});
/////////////////////////////////////////////
var dataTable061220 = [
  [
    {label: 'State', role: 'domain', type: 'string'},
    {label: 'Population', role: 'data', type: 'number'},
  ],
  ['0-10', 846152.672 ],
  ['10-20', 691920.657],
  ['20-30', 425270.750],
  ['30-40',223814.860],
  ['40-50',114897.913],
  ['>50',  166569.554]
];
// Define the chart and print it to the console.
var bar061220 = ui.Chart(dataTable061220).setChartType('ColumnChart').setOptions({
  title: 'Diện tích ....',
  legend: {position: 'none'},
  hAxis: {title: 'Nồng độ', titleTextStyle: {italic: false, bold: true}},
  vAxis: {title: ' Diện tích (m2)', titleTextStyle: {italic: false, bold: true}},
  colors: ['1d6b99']
});
/////
    /////////////////////////////////////////////
var dataTable070121 = [
  [
    {label: 'State', role: 'domain', type: 'string'},
    {label: 'Population', role: 'data', type: 'number'},
  ],
  ['0-10', 967095.950 ],
  ['10-20', 742114.484],
  ['20-30', 403425.244],
  ['30-40',182994.003],
  ['40-50',80366.424],
  ['>50',  92630.302]
];
// Define the chart and print it to the console.
var bar070121 = ui.Chart(dataTable070121).setChartType('ColumnChart').setOptions({
  title: 'Diện tích ....',
  legend: {position: 'none'},
  hAxis: {title: 'Nồng độ', titleTextStyle: {italic: false, bold: true}},
  vAxis: {title: ' Diện tích (m2)', titleTextStyle: {italic: false, bold: true}},
  colors: ['1d6b99']
});
/////
    /////////////////////////////////////////////
var dataTable120121 = [
  [
    {label: 'State', role: 'domain', type: 'string'},
    {label: 'Population', role: 'data', type: 'number'},
  ],
  ['0-10', 679208.605 ],
  ['10-20', 570574.224],
  ['20-30', 417333.008],
  ['30-40',282946.548],
  ['40-50',185668.085],
  ['>50', 332895.937]
];
// Define the chart and print it to the console.
var bar120121 = ui.Chart(dataTable120121).setChartType('ColumnChart').setOptions({
  title: 'Diện tích ....',
  legend: {position: 'none'},
  hAxis: {title: 'Nồng độ', titleTextStyle: {italic: false, bold: true}},
  vAxis: {title: ' Diện tích (m2)', titleTextStyle: {italic: false, bold: true}},
  colors: ['1d6b99']
});
/////
    /////////////////////////////////////////////
var dataTable170121 = [
  [
    {label: 'State', role: 'domain', type: 'string'},
    {label: 'Population', role: 'data', type: 'number'},
  ],
  ['0-10', 669370.617 ],
  ['10-20',589232.285],
  ['20-30', 429501.101],
  ['30-40',286464.415],
  ['40-50',179438.851],
  ['>50', 314619.138]
];
// Define the chart and print it to the console.
var bar170121 = ui.Chart(dataTable170121).setChartType('ColumnChart').setOptions({
  title: 'Diện tích ....',
  legend: {position: 'none'},
  hAxis: {title: 'Nồng độ', titleTextStyle: {italic: false, bold: true}},
  vAxis: {title: ' Diện tích (m2)', titleTextStyle: {italic: false, bold: true}},
  colors: ['1d6b99']
});
/////
    /////////////////////////////////////////////
var dataTable060321 = [
  [
    {label: 'State', role: 'domain', type: 'string'},
    {label: 'Population', role: 'data', type: 'number'},
  ],
  ['0-10', 675415.300 ],
  ['10-20',607442.272],
  ['20-30', 461189.716],
  ['30-40',292609.629],
  ['40-50',167952.517],
  ['>50',259184.849]
];
// Define the chart and print it to the console.
var bar060321 = ui.Chart(dataTable060321).setChartType('ColumnChart').setOptions({
  title: 'Diện tích ....',
  legend: {position: 'none'},
  hAxis: {title: 'Nồng độ', titleTextStyle: {italic: false, bold: true}},
  vAxis: {title: ' Diện tích (m2)', titleTextStyle: {italic: false, bold: true}},
  colors: ['1d6b99']
});
/////
    /////////////////////////////////////////////
var dataTable080321 = [
  [
    {label: 'State', role: 'domain', type: 'string'},
    {label: 'Population', role: 'data', type: 'number'},
  ],
  ['0-10', 608706.054 ],
  ['10-20',541932.935],
  ['20-30', 443705.802],
  ['30-40',313963.630],
  ['40-50',204260.533],
  ['>50',343176.516]
];
// Define the chart and print it to the console.
var bar080321 = ui.Chart(dataTable080321).setChartType('ColumnChart').setOptions({
  title: 'Diện tích ....',
  legend: {position: 'none'},
  hAxis: {title: 'Nồng độ', titleTextStyle: {italic: false, bold: true}},
  vAxis: {title: ' Diện tích (m2)', titleTextStyle: {italic: false, bold: true}},
  colors: ['1d6b99']
});
/////
 /////////////////////////////////////////////
var dataTable110321 = [
  [
    {label: 'State', role: 'domain', type: 'string'},
    {label: 'Population', role: 'data', type: 'number'},
  ],
  ['0-10', 658502.896 ],
  ['10-20',582857.180],
  ['20-30',458446.313],
  ['30-40',307886.633],
  ['40-50',179982.080],
  ['>50',271026.503]
];
// Define the chart and print it to the console.
var bar110321 = ui.Chart(dataTable110321).setChartType('ColumnChart').setOptions({
  title: 'Diện tích ....',
  legend: {position: 'none'},
  hAxis: {title: 'Nồng độ', titleTextStyle: {italic: false, bold: true}},
  vAxis: {title: ' Diện tích (m2)', titleTextStyle: {italic: false, bold: true}},
  colors: ['1d6b99']
});
/////
 /////////////////////////////////////////////
var dataTable070421 = [
  [
    {label: 'State', role: 'domain', type: 'string'},
    {label: 'Population', role: 'data', type: 'number'},
  ],
  ['0-10',  597078.639 ],
  ['10-20',558842.467],
  ['20-30',467793.491],
  ['30-40',341520.234],
  ['40-50',211265.443],
  ['>50',280948.840]
];
// Define the chart and print it to the console.
var bar070421= ui.Chart(dataTable070421).setChartType('ColumnChart').setOptions({
  title: 'Diện tích ....',
  legend: {position: 'none'},
  hAxis: {title: 'Nồng độ', titleTextStyle: {italic: false, bold: true}},
  vAxis: {title: ' Diện tích (m2)', titleTextStyle: {italic: false, bold: true}},
  colors: ['1d6b99']
});
/////
//  8) Create a dropdown menu to display graph results //
////////////////////////////////////////////////////////
//Add a panel to hold graphs within main panel
var panelyear = ui.Panel({
  style:{width: '500px',position:'bottom-left'}
});
//Create key of items for dropdown
var P031220 = '03/12/2020';
var P061220 = '06/12/2020';
var P070121 = '07/01/2021';
var P120121 = '12/01/2021';
var P170121 = '17/01/2021';
var P060321 = '06/03/2021';
var P080321 = '08/03/2021';
var P110321 = '11/03/2021';
var P070421 = '07/04/2021';
//Construct Dropdown
var yearSelect = ui.Select({
  items:[P031220,P061220,P070121,P120121,P170121,P060321,P080321,P110321,P070421],
  placeholder:'   Choose year  ',
  onChange: selectLayer,
  style: { padding: '0px 150px',
  }
});
var constraints = []
//Write a function that runs on change of Dropdown
function selectLayer(){
  var year = yearSelect.getValue() // get value from dropdown selection
  panelyear.clear() //clear graph panel between selections so only one graph displays
  //We use "if else" statements to write instructions for drawing graphs
  if (year == P031220){
    panelyear.add(chart031220);///histogram
    panel.add(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);
/*panelyear.remove(chart061220);
panelyear.remove(chart070121);
panelyear.remove(chart120121);
panelyear.remove(chart170121);
panelyear.remove(chart060321);
panelyear.remove(chart080321);
panelyear.remove(chart110321);
panelyear.remove(chart070421);
*/
Map.add(classify_PM031220)//mapaddlayer
  Map.remove(classify_PM061220)
  Map.remove(classify_PM070121)
  Map.remove(classify_PM120121)
  Map.remove(classify_PM170121)
  Map.remove(classify_PM060321)
  Map.remove(classify_PM080321)
  Map.remove(classify_PM110321)
  Map.remove(classify_PM070421)
  }
  else if (year == P061220){
panel.add(bar061220);
panel.remove(bar031220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);
panelyear.add(chart061220);
/* panelyear.remove(chart070121);
panelyear.remove(chart031220);
panelyear.remove(chart120121);
panelyear.remove(chart170121);
panelyear.remove(chart060321);
panelyear.remove(chart080321);
panelyear.remove(chart110321);
panelyear.remove(chart070421);
*/
  Map.add(classify_PM061220)
Map.remove(classify_PM031220)
Map.remove(classify_PM070121)
Map.remove(classify_PM120121)
Map.remove(classify_PM170121)
Map.remove(classify_PM060321)
Map.remove(classify_PM080321)
Map.remove(classify_PM110321)
Map.remove(classify_PM070421)
  }
 else if (year == P070121){
   panel.add(bar070121);
   panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);
   panelyear.add(chart070121);
panelyear.remove(chart031220);
panelyear.remove(chart061220);
panelyear.remove(chart120121);
panelyear.remove(chart170121);
panelyear.remove(chart060321);
panelyear.remove(chart080321);
panelyear.remove(chart110321);
panelyear.remove(chart070421);
  Map.add(classify_PM070121)
Map.remove(classify_PM031220)
Map.remove(classify_PM061220)
Map.remove(classify_PM120121)
Map.remove(classify_PM170121)
Map.remove(classify_PM060321)
Map.remove(classify_PM080321)
Map.remove(classify_PM110321)
Map.remove(classify_PM070421)
  }
 else if (year == P120121){
   panel.add(bar120121);
   panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);
   panelyear.add(chart120121);
panelyear.remove(chart031220);
panelyear.remove(chart061220);
panelyear.remove(chart070121);
panelyear.remove(chart170121);
panelyear.remove(chart060321);
panelyear.remove(chart080321);
panelyear.remove(chart110321);
panelyear.remove(chart070421);  
  Map.add(classify_PM120121)
Map.remove(classify_PM031220)
Map.remove(classify_PM061220)
Map.remove(classify_PM070121)
Map.remove(classify_PM170121)
Map.remove(classify_PM060321)
Map.remove(classify_PM080321)
Map.remove(classify_PM110321)
Map.remove(classify_PM070421)
  }
   else if (year == P170121){
     panel.add(bar170121);
     panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);
     panelyear.add(chart170121);
panelyear.remove(chart031220);
panelyear.remove(chart061220);
panelyear.remove(chart070121);
panelyear.remove(chart120121);
panelyear.remove(chart060321);
panelyear.remove(chart080321);
panelyear.remove(chart110321);
panelyear.remove(chart070421);    
  Map.add(classify_PM170121)
Map.remove(classify_PM031220)
Map.remove(classify_PM061220)
Map.remove(classify_PM070121)
Map.remove(classify_PM120121)
Map.remove(classify_PM060321)
Map.remove(classify_PM080321)
Map.remove(classify_PM110321)
Map.remove(classify_PM070421)
  }
     else if (year == P060321){
       panel.add(bar060321);
  panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar080321);
panel.remove(bar110321); 
panel.remove(bar070421);     
       panelyear.add(chart060321);
panelyear.remove(chart031220);
panelyear.remove(chart061220);
panelyear.remove(chart070121);
panelyear.remove(chart120121);
panelyear.remove(chart170121);
panelyear.remove(chart080321);
panelyear.remove(chart110321);
panelyear.remove(chart070421);
  Map.add(classify_PM060321)
Map.remove(classify_PM031220)
Map.remove(classify_PM061220)
Map.remove(classify_PM070121)
Map.remove(classify_PM120121)
Map.remove(classify_PM170121)
Map.remove(classify_PM080321)
Map.remove(classify_PM110321)
Map.remove(classify_PM070421)
  }
       else if (year == P080321){
         panel.add(bar080321);
    panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar110321); 
panel.remove(bar070421);     
         panelyear.add(chart080321);
panelyear.remove(chart031220);
panelyear.remove(chart061220);
panelyear.remove(chart070121);
panelyear.remove(chart120121);
panelyear.remove(chart170121);
panelyear.remove(chart060321);
panelyear.remove(chart110321);
panelyear.remove(chart070421);
 Map.add(classify_PM080321)
Map.remove(classify_PM031220)
Map.remove(classify_PM061220)
Map.remove(classify_PM070121)
Map.remove(classify_PM120121)
Map.remove(classify_PM170121)
Map.remove(classify_PM060321)
Map.remove(classify_PM110321)
Map.remove(classify_PM070421)
  }
         else if (year == P110321){
   panel.add(bar110321);        
   panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar070421);
   panelyear.add(chart110321);
panelyear.remove(chart031220);
panelyear.remove(chart061220);
panelyear.remove(chart070121);
panelyear.remove(chart120121);
panelyear.remove(chart170121);
panelyear.remove(chart060321);
panelyear.remove(chart080321);
panelyear.remove(chart070421);
  Map.add(classify_PM110321)
Map.remove(classify_PM031220)
Map.remove(classify_PM061220)
Map.remove(classify_PM070121)
Map.remove(classify_PM120121)
Map.remove(classify_PM170121)
Map.remove(classify_PM060321)
Map.remove(classify_PM080321)
Map.remove(classify_PM070421)
  }
           else if (year == P070421){
  panel.add(bar070421);   
  panel.remove(bar031220);
panel.remove(bar061220);
panel.remove(bar070121);
panel.remove(bar120121);
panel.remove(bar170121);
panel.remove(bar060321);
panel.remove(bar080321);
panel.remove(bar110321); 
 panelyear.add(chart070421);
panelyear.remove(chart031220);
panelyear.remove(chart061220);
panelyear.remove(chart070121);
panelyear.remove(chart120121);
panelyear.remove(chart170121);
panelyear.remove(chart060321);
panelyear.remove(chart080321);
panelyear.remove(chart110321);
  Map.add(classify_PM070421);
Map.remove(classify_PM031220);
Map.remove(classify_PM061220);
Map.remove(classify_PM070121);
Map.remove(classify_PM120121);
Map.remove(classify_PM170121);
Map.remove(classify_PM060321);
Map.remove(classify_PM080321);
Map.remove(classify_PM110321);
  }
}
////
//Add selecter and graph panel ;to main panel
panel.add(yearSelect)
      .add(panelyear);
    ////
    // Create the panel for the legend items.
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '10px 20px',
    color:'black',
      }
});
// Create and add the legend title.
var legendTitle = ui.Label({
  value: ' Nồng độ PM2.5',
  style: {
    fontWeight: 'bold',
    fontSize: '15px',
    margin: '0 0 4px 0',
    padding: '0',
     }
});
legend.add(legendTitle);
var loading = ui.Label('Loading legend...', {margin: '2px 0 4px 0'});
legend.add(loading);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      // Use padding to give the box height and width.
      padding: '10px',
      margin: '0 0 4px 0',
    }
  });
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'},
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
// Get the list of palette colors and class names from the image.
PM031220.toDictionary().evaluate(function(result) {
  var palette =['008000','B1FB17','FFFF00','FFD801','FFA500','FF0000'];
  var names = ['0-10', '10-20', '20-30', '30-40', '40-50','>50'];
  loading.style().set('shown', false);
  for (var i = 0; i < names.length; i++) {
    legend.add(makeRow(palette[i], names[i]));
  }
  });
// Add the legend to the map.
Map.add(legend);
  //panel.add(legend)
// Tên bản đồ
var ten = ui.Label('Phân bố bụi PM2.5 trung tâm TP Hồ Chí Minh',{
  stretch:'horizontal',
  textAlign:'center',
  fontWeight:'bold',
  fontSize:'20px',
  color:'437C17',
  padding: '10px ',
});
Map.add(ten);
 ///////////////////////////////////////////////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector1 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '3px 3px',
    color:'black',
      }
});
// Add a label to the panel.
inspector1.add(ui.Label(' PM2.5 in 03/12/2020'));
// Add the panel to the default map.
Map.add(inspector1);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector1.clear();
  inspector1.style().set('shown', true);
  inspector1.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM031220.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector1.clear();
    // Add a label with the results from the server.
    inspector1.add(ui.Label({
      value: '03/12/2020: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
 ///////////////////////////////////////////////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector2 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '3px 3px',
    color:'black',
      }
});
// Add a label to the panel.
inspector2.add(ui.Label('PM2.5 in 06/12/2020'));
// Add the panel to the default map.
Map.add(inspector2);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector2.clear();
  inspector2.style().set('shown', true);
  inspector2.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM061220.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector2.clear();
    // Add a label with the results from the server.
    inspector2.add(ui.Label({
      value: '06/12/2020: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector3 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '3px 3px',
    color:'black',
      }
});
// Add a label to the panel.
inspector3.add(ui.Label('PM2.5 in 07/01/2021'));
// Add the panel to the default map.
Map.add(inspector3);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector3.clear();
  inspector3.style().set('shown', true);
  inspector3.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM070121.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector3.clear();
    // Add a label with the results from the server.
    inspector3.add(ui.Label({
      value: '07/01/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector4 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '3px 3px',
    color:'black',
      }
});
// Add a label to the panel.
inspector4.add(ui.Label('PM2.5 in 12/01/2021'));
// Add the panel to the default map.
Map.add(inspector4);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector4.clear();
  inspector4.style().set('shown', true);
  inspector4.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM120121.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector4.clear();
    // Add a label with the results from the server.
    inspector4.add(ui.Label({
      value: '12/01/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector5 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '3px 3px',
    color:'black',
      }
});
// Add a label to the panel.
inspector5.add(ui.Label('PM2.5 in 17/01/2021'));
// Add the panel to the default map.
Map.add(inspector5);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector5.clear();
  inspector5.style().set('shown', true);
  inspector5.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM170121.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector5.clear();
    // Add a label with the results from the server.
    inspector5.add(ui.Label({
      value: '17/01/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector6 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '3px 3px',
    color:'black',
      }
});
// Add a label to the panel.
inspector6.add(ui.Label('PM2.5 in 06/03/2021'));
// Add the panel to the default map.
Map.add(inspector6);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector6.clear();
  inspector6.style().set('shown', true);
  inspector6.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM060321.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector6.clear();
    // Add a label with the results from the server.
    inspector6.add(ui.Label({
      value: '06/03/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector7 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '3px 3px',
    color:'black',
      }
});
// Add a label to the panel.
inspector7.add(ui.Label('PM2.5 in 08/03/2021'));
// Add the panel to the default map.
Map.add(inspector7);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector7.clear();
  inspector7.style().set('shown', true);
  inspector7.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM080321.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector7.clear();
    // Add a label with the results from the server.
    inspector7.add(ui.Label({
      value: '08/03/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector8 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '3px 3px',
    color:'black',
      }
});
// Add a label to the panel.
inspector8.add(ui.Label('PM2.5 in 11/03/2021'));
// Add the panel to the default map.
Map.add(inspector8);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector8.clear();
  inspector8.style().set('shown', true);
  inspector8.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM110321.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector8.clear();
    // Add a label with the results from the server.
    inspector8.add(ui.Label({
      value: '11/03/2021: ' + result.toFixed(1),
      style: {stretch: 'vertical'}
    }));
  });
});
///////////////////////////////////////
// Create an inspector panel with a horizontal layout.
var inspector9 = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '3px 3px',
    color:'black',
      }
});
// Add a label to the panel.
inspector9.add(ui.Label('PM2.5 in 07/04/2021'));
// Add the panel to the default map.
Map.add(inspector9);
// Register a callback on the map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Clear the panel and show a loading message.
  inspector9.clear();
  inspector9.style().set('shown', true);
  inspector9.add(ui.Label('Loading...', {color: 'gray'}));
  // Compute the mean NDVI; a potentially long-running server operation.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var temporalMean = PM070421.reduce(ee.Reducer.mean());
  var sampledPoint = temporalMean.reduceRegion(ee.Reducer.mean(), point, 30);
  var computedValue = sampledPoint.get('mean');
  // Request the value from the server and use the results in a function.
  computedValue.evaluate(function(result) {
    inspector9.clear();
    // Add a label with the results from the server.
    inspector9.add(ui.Label({
      value: '07/04/2021: ' + result.toFixed(2),
      style: {stretch: 'vertical'}
    }));
  });
});
// Create an inspector panel with a horizontal layout.
var inspector = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '2px 2px',
    color:'black',
    fontWeight:'bold',
  fontSize:'20px',
      }
});
// Add a label to the panel.
inspector.add(ui.Label('Click map to get PM2.5'));
// Add the panel to the default map.
Map.add(inspector);
/////
////////////