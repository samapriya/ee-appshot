var ROI = ui.import && ui.import("ROI", "table", {
      "id": "projects/gleaming-medium-276810/assets/UFSC/ROI"
    }) || ee.FeatureCollection("projects/gleaming-medium-276810/assets/UFSC/ROI");
/**
 * @name
 *  Biodiversidade toolkit*
 * @author
 *  Luiz Cortinhas
 *  Solved Solutions in Geoinformation LTDA
 *  solved@solved.eco.br
 * 
 * @version
 *  1.0
 * 
 * @Missing Features
 *  - Region: UC merged with Municipalities
 *  - Apresentação do Projeto
 *  - Instrução de Uso
 *  - Fixar satelite como basemap
 *  - Criar menu (painel) lateral direito
 *  - No menu, adicionar checkbox para seleção dos graficos
 *  - Trocar valores numericos da color ramp por qualitativos de prioridade
 */
var ROIHaze = ee.Image(1).toByte().paint(ROI,0)
ROIHaze = ROIHaze.updateMask(ROIHaze.neq(0))
Map.setOptions('HYBRID');
var Palettes = require('users/mapbiomas/modules:Palettes.js');
var palette = Palettes.get('classification8');
var graphs = []
Map.addLayer(ROIHaze,{max:1,min:0,pallete:'#FFFFFF',opacity:0.4},'ROI')
Map.setCenter(-51.878,-6.206,5)
var counties = ee.FeatureCollection('projects/solvedltda/assets/layers/municipios_2010').cache()
var climateModels = ['CESM2','CMCC-ESM2','GFDL','TaiESM1']
var sspScenarios = ['ssp245','ssp585']
var selectedFeature = null
var vis = {
            imageVisParam_vegSecondaria:  {"opacity":1,"bands":["secondary_vegetation_age_2022"],"max":1,"palette":["ffffff","9fff99","00c045"]},
            imageVisParamNPP :{"opacity":1,"bands":["Npp_max"],"min":0,"max":0.9846896551724138,palette:["ffffff","e9ff37","ff3f3f","ff0cd5"]},
}
var loadMapbiomas = function(){
  var MB8 = ee.Image('projects/mapbiomas-workspace/public/collection8/mapbiomas_collection80_integration_v1')
  var mapbiomas2001 = MB8.select('classification_2001')
  mapbiomas2001 = mapbiomas2001.eq(3).or(mapbiomas2001.eq(1)).or(mapbiomas2001.eq(5)).or(mapbiomas2001.eq(4))
  var mapbiomas2022 = MB8.select('classification_2022')
  mapbiomas2022 = mapbiomas2022.eq(3).or(mapbiomas2022.eq(1)).or(mapbiomas2022.eq(5)).or(mapbiomas2022.eq(4))
  var MB8_transicao = ee.Image(0).toByte().where(mapbiomas2001.eq(1).and(mapbiomas2022.eq(0)),1)
  return MB8_transicao
}
var loadSecondVeg = function(){
  var vegSecondMB8 = ee.Image('projects/mapbiomas-workspace/public/collection8/mapbiomas_collection80_secondary_vegetation_age_v2')
  vegSecondMB8 = vegSecondMB8.select('secondary_vegetation_age_2022').divide(37)
  return vegSecondMB8
}
var loadNPP = function(){
  var MB8_transicao = loadMapbiomas()
  var NPP = ee.ImageCollection('MODIS/061/MOD17A3HGF').select('Npp').reduce(ee.Reducer.minMax()).mask(MB8_transicao).unmask(0)
  var NPPmax = NPP.select('Npp_max')
  var NPPmin = NPP.select('Npp_min')
  var NppDelta = NPPmax.subtract(NPPmin)
  NppDelta = NppDelta.divide(14500).rename('Npp_max')
  return  NppDelta.unmask(0).add(loadSecondVeg().unmask(0))
}
var loadPR = function(nomeModelo,sspNumber){
  var pr_h = ee.Image('projects/gleaming-medium-276810/assets/UFSC/pr_'+nomeModelo+'_historical_annual')
  var pr = ee.Image('projects/gleaming-medium-276810/assets/UFSC/pr_'+nomeModelo+'_'+sspNumber+'_annual')
  var pr_h_mean = pr_h.reduce(ee.Reducer.mean())
  var pr_h_stDev = pr_h.reduce(ee.Reducer.stdDev())
  var pr_mean = pr.reduce(ee.Reducer.mean())
  var pr_stDev = pr.reduce(ee.Reducer.stdDev())
  var pr_anomalia = pr_mean.subtract(pr_h_mean)
  return [pr_anomalia,pr_stDev,pr_mean,pr,pr_h]
}
var loadTAS = function(nomeModelo,sspNumber){
  var tas_h = ee.Image('projects/gleaming-medium-276810/assets/UFSC/tas_'+nomeModelo+'_historical_annual')
  var tas = ee.Image('projects/gleaming-medium-276810/assets/UFSC/tas_'+nomeModelo+'_'+sspNumber+'_annual')
  var tas_h_mean = tas_h.reduce(ee.Reducer.mean())
  var tas_h_stdDev = tas_h.reduce(ee.Reducer.stdDev())
  var tas_mean = tas.reduce(ee.Reducer.mean())
  var tas_stDev = tas.reduce(ee.Reducer.stdDev())
  var tas_anomalia = tas_mean.subtract(tas_h_mean)
  return [tas_anomalia,tas_stDev,tas_mean,tas,tas_h]
}
var fromBands2CollectionTAS = function(image,mean){
  var bands = image.bandNames()
  var list = bands.map(function(n) {
    var meanImage = mean.select(0)
    var year = ee.Number.parse(ee.String(n).slice(1)).add(2014)
    image = image.set({'system:time_start':ee.Date.fromYMD(year,01,01)})
    return image.select([n]).rename('TAS')
  })
  var collection = ee.ImageCollection.fromImages(list)
  return collection
}
var fromBands2CollectionPR = function(image){
  var bands = image.bandNames()
  var list = bands.map(function(n) {
    var year = ee.Number.parse(ee.String(n).slice(1)).add(2014)
    image = image.set({'system:time_start':ee.Date.fromYMD(year,01,01)})
    return image.select([n]).rename('PR')})
  return ee.ImageCollection.fromImages(list)
}
var listener_MarkOnMapEvent= function(coord){
  var featSelected = null
    if(coord != null){
      coord = ee.Dictionary(coord)
      var point = ee.Geometry.Point([coord.get('lon'),coord.get('lat')]);
      featSelected = ee.Feature(counties.filterBounds(point).first());
      selectedFeature = featSelected
    }else{
      featSelected = selectedFeature
    }
    Map.centerObject(featSelected)
    print(featSelected)
    var name = featSelected.get('nome').getInfo();
    labelMunicipio =labelMunicipio.setValue("Municipio: "+name)
    var widgetsOnMap = toolPanel.widgets().getJsArray()
    for(var i =9; i< widgetsOnMap.length;i++){
      toolPanel.remove(widgetsOnMap[i])
    }
    var layers = Map.layers()
    for(var i = 0; i < layers.length();i++){
      if(layers.get(i).getName() == 'Active'){
        Map.remove(layers.get(i))
      }
    }
     Map.addLayer(ee.Image().paint(featSelected,0,2),{palette:['#00ff09']},'Active')
      //Load Graph
      //Require TAS
      var tasAnomaly = loadTAS(seletorModelo.getValue(),seletorCenario.getValue())
      var tas_mean = tasAnomaly[2]
      var tas = fromBands2CollectionTAS(tasAnomaly[3],tas_mean)
      var graphtas = graph1TAS(tas,featSelected,seletorModelo.getValue(),seletorCenario.getValue())
      var prAnomaly = loadPR(seletorModelo.getValue(),seletorCenario.getValue())
      var pr = fromBands2CollectionPR(prAnomaly[3])
      var graphpr = graph2PR(pr,featSelected,seletorModelo.getValue(),seletorCenario.getValue())
      // graphs = graphs.push(graphtas)
      print('Graph', widgetsOnMap)
      if(checkboxNPP.getValue() == true){
        toolPanel.add(graph3NPP(npp,featSelected))
      }
      if(checkboxTAS.getValue() == true){
        toolPanel.add(graphtas)
      }
      if(checkboxPR.getValue() == true){
         toolPanel.add(graphpr)
      }
}
Map.onClick(listener_MarkOnMapEvent)
var npp = loadNPP()
Map.addLayer(npp.updateMask(npp.neq(0)).updateMask(ROIHaze.unmask(0).not()),vis.imageVisParamNPP,'Indicador de Áreas Prioritárias')
// Map.addLayer(ee.Image().paint(counties,0,1.3),{'palette': '#000000'},'Municipios')
Map.style().set('cursor', 'crosshair');
//Default Listener
var listenerUpdate = function(e){
  if(selectedFeature != null){
    listener_MarkOnMapEvent(null)
  }
}
var controlMunicipiosLayer = false
var listener_MunicipiosLayer = function(){
  if(!controlMunicipiosLayer){
    addLayerMunicipios()
  }else{
    removeLayerMunicipios()
  }
  controlMunicipiosLayer = !controlMunicipiosLayer
}
var removeLayerMunicipios = function(){
  var layers = Map.layers()
    for(var i = 0; i < layers.length();i++){
      if(layers.get(i).getName() == 'Municipios'){
        Map.remove(layers.get(i))
      }
    }
}
var addLayerMunicipios  = function(){
  Map.addLayer(ee.Image().paint(counties,0,1.3),{'palette': '#000000'},'Municipios')
}
// Ui Panels
var labelMunicipio = ui.Label("Selecione um município no mapa")
var panelMunicipios = ui.Panel([labelMunicipio],ui.Panel.Layout.flow('horizontal'))
//
Map.add(panelMunicipios)
var header = ui.Label('Centro de Ecologia Serrapilheira', {fontSize: '24px', color: 'green'});
var municipio = ui.Checkbox('Camada de Municipios',false,listener_MunicipiosLayer)
var checkboxTAS = ui.Checkbox('Gráfico de Temperatura do Ar',false,listenerUpdate)
var checkboxPR = ui.Checkbox('Gráfico de Precipitação',false,listenerUpdate)
var checkboxNPP = ui.Checkbox('Histograma de Npp',false,listenerUpdate)
var text = ui.Label(
    'Onde e como restaurar o arco do desmatamento?',
    {fontSize: '16px'});
var text2 = ui.Label('',
    // 'Clique no Mapa para obter estatisticas de Precipitação e Temperatura do Ar por Municipio',
    {fontSize: '12px',color:'red'});
var textModelo = ui.Label('Modelo Climatico:',{fontSize: '14px',color:'black'});
var seletorModelo =  ui.Select(climateModels,'Escolha o Modelo de Previsao Climatica',climateModels[0],listenerUpdate)
var painelModelo = ui.Panel([textModelo,seletorModelo],ui.Panel.Layout.flow('horizontal'))
var textCenario = ui.Label('Cenário:',{fontSize: '14px',color:'black'});
var seletorCenario =  ui.Select(sspScenarios,'Escolha o Cenário de Previsao Climatica',sspScenarios[0],listenerUpdate)
var painelCenario = ui.Panel([textCenario,seletorCenario],ui.Panel.Layout.flow('horizontal'))
var toolPanel = ui.Panel([header, text,text2,painelModelo,painelCenario,municipio,checkboxTAS,checkboxPR,checkboxNPP], 'flow', {width: '450px'});
ui.root.widgets().add(toolPanel);
var colorRampNPP = function(){
  var legend = ui.Panel({
    style: {
      position: 'bottom-left',
      padding: '8px 15px',
      width: '450px'
    }
  });
  var legendTitle = ui.Label({
    value: 'Indicador de Áreas Prioritárias',
    style: {
      fontWeight: 'bold',
      fontSize: '18px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  legend.add(legendTitle);
  var colorBarParams = {bbox: [0, 0, 1, 0.1],
                  dimensions: '100x10',
                  format: 'png',
                  min: 0,
                  max: 1,
                  palette: vis.imageVisParamNPP.palette,
                };
  var colorBar = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: colorBarParams,
    style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
  });
  var legendLabels = ui.Panel({
    widgets: [
      ui.Label('Baixa Prioridade', {margin: '4px 8px'}),
      ui.Label(
          "",// (1 / 2),
          {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label('Alta Prioridade', {margin: '4px 8px'})
    ],
    layout: ui.Panel.Layout.flow('horizontal')
  });
  var legendTitle = ui.Label({
    // value: 'Delta NPP Normalizado + Idade da Vegetação Secundaria Normalizada',
    style: {fontWeight: 'bold'}
  });
  var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
  legend.widgets().set(3, legendPanel)
  return legend
}
var graph1TAS = function(tas,feat,modelName,ssp){
   var panel = ui.Panel({
    style: {
      position: 'bottom-right',
      padding: '8px 15px'
    }
  });
  var chart = ui.Chart.image.series(tas, feat, ee.Reducer.mean(), 500);
  chart.setOptions({
    title: 'TAS Over Time ['+modelName+','+ssp+']',
    // colors:['#ff3f3f'],
    vAxis: {title: 'Temperature in Celsius'},
    hAxis: {title: 'date', format: 'yyyy', gridlines: {count: 7}},
    trendlines: { 0: {
        title:'Trend Line',
        type: 'linear',//'polynomial',
        degree: 2,
        color: 'red',
        visibleInLegend: true,} },
  });
  panel.widgets().set(2, chart);
  return panel
}
var graph2PR = function(pr,feat,modelName,ssp){
   var panel = ui.Panel({
    style: {
      position: 'bottom-right',
      padding: '8px 15px'
    }
  });
  var chart = ui.Chart.image.series(pr, feat, ee.Reducer.mean(), 500);
  chart.setOptions({
    title: 'Precipitation Over Time ['+modelName+','+ssp+']',
    vAxis: {title: 'Precipitation in mm/m²'},
    hAxis: {title: 'date', format: 'yyyy', gridlines: {count: 7}},
     trendlines: { 0: { 
        title:'Trend Line',
        type: 'linear',//'polynomial',
        degree: 2,
        color: 'red',
        visibleInLegend: true,} },
  });
  panel.widgets().set(2, chart);
  return panel
}
var graph3NPP = function(nppImage,feat){
   var panel = ui.Panel({
    style: {
      position: 'bottom-right',
      padding: '8px 15px'
    }
  });
  print('NPP feat',feat)
  var chart = ui.Chart.image.histogram(nppImage.updateMask(nppImage.neq(0)), feat, 500,5,0.01);
  chart.setOptions({
    title: 'D-NPP Histogram',
    vAxis: {title: 'Count of Pixels'},
  });
  panel.widgets().set(2, chart);
  return panel
}
// Map.add(graph1TAS())
Map.add(colorRampNPP());