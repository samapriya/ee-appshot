// Last modification:2021-12-08 by Pegah: Changing LS8 collection1 to collection 2.
Map.style().set('cursor', 'crosshair');
// ----------------------Cloud Masking Functions----------------------
var applyScaleFactors=function (image) {
  var opticalBands = (image.select('SR_B.').multiply(0.0000275).add(-0.2)).multiply(10000 );
  var thermalBands = (image.select('ST_B.*').multiply(0.00341802).add(149.0)).subtract(273.15);
  return image.addBands(opticalBands, null, true)
              .addBands(thermalBands, null, true);
};
var maskL8sr=function (image) {
  var qaMask = image.select('QA_PIXEL').bitwiseAnd(parseInt('11111', 2)).eq(0);
  var saturationMask = image.select('QA_RADSAT').eq(0);
  return ((image)
      .updateMask(qaMask)
      .updateMask(saturationMask))
};
var maskS2= function (image) {
          var qa = image.select('QA60');
          var cloudBitMask = 1 << 10;
          var cirrusBitMask = 1 << 11;
          var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
                        .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
          return image.updateMask(mask);
        };
var maskL8=function (image) {
  var qa = image.select('BQA');
  var mask = qa.bitwiseAnd(ee.Number(2).pow(12).int()).eq(1).and(  // cirrus
             qa.bitwiseAnd(ee.Number(2).pow(13).int()).eq(1)).or(  // cirrus
             qa.bitwiseAnd(ee.Number(2).pow(4).int()).neq(0)).and( // cloud
             qa.bitwiseAnd(ee.Number(2).pow(7).int()).neq(0))      // cloud
             .not();
  return image.updateMask(mask);
}
function rename(img){
  return img.rename(['B1','B2','B3','B4','B5','B6','B7','SR_QA_AEROSOL','B10',
                              'ST_ATRAN','ST_CDIST','ST_DRAD','ST_EMIS','ST_EMSD','ST_QA',
                              'ST_TRAD','ST_URAD','QA_PIXEL','QA_RADSAT'])
}
// ---------------------- Intro. and Panel --------------------------
// // App Logos
// var logo = ee.Image('users/geerestec/TrainingApp_VEGA/LOGO-VEGA6').select(['b1','b2','b3'])
// var thumb = ui.Thumbnail({image: logo,
//                           params: {
//                                   // dimensions: '120x150',
//                                   // format: 'jpg'
//                                   },
//                               style: {padding :'0px 70px 0px 90px'}
//                               });
var RESTEClogo = ee.Image('users/phashemvand/TrainingLogo_modified2')
var thumb1 = ui.Thumbnail({image: RESTEClogo,
                          params: {
                                  dimensions: '500x100',
                                  format: 'jpeg'
                                  },
                              style: {padding :'0px 60px 0px 60px'}
                              });                              
//App title
var EnVer= ui.Label({value:'English', 
                        style:{fontSize: '15px', color: '#399EE2',textAlign:'center',margin:'0px 0px 0px 0px'}})
                        .setUrl('https://geerestec.users.earthengine.app/view/vega-restec-en')
var header1 = ui.Label({value:'VEGA',
                        style:{fontSize: '45px', fontFamily:'serif',fontWeight: 'bold', color: '#357EC7',textAlign:'center',margin:'10px 10px 10px 125px'}})
                                            .setUrl('https://rs-training.jp/');
var header2 = ui.Label({value:'Visualizing Earth tool by Google Earth Engine Apps', 
                        style:{fontSize: '15px', fontWeight: 'bold', color: '#399EE2',textAlign:'center',margin:'0px 0px 0px 20px'}})
var header3 = ui.Label({value:'Google Earth Engine Appsを用いた地球可視化ツール', 
                        style:{fontSize: '15px', fontWeight: 'bold', color: '#399EE2',textAlign:'center',margin:'0px 0px 0px 20px'}})
//App summary
var AppDescription = ui.Label({value:'このツールは、指定した時期のLandsat-8及びSentinel-2データ'+
                                      'をお好きな色の組み合わせ、合成方法、フィルタリング方法で表示・閲覧するためのものです。',
                              style:{fontSize: '13px',textAlign:'center'}});
var sidePanel = ui.Panel({
    widgets:EnVer,
    style: {width: '400px',stretch:'both'}
    });     
var intro = ui.Panel([
  ui.Label({
    value: '___________________________________________________________',
    style: {fontSize: '14px',fontWeight: 'bold'},
  })]);
sidePanel.widgets().set(1,header1)
//Add this new panel to the larger panel we created 
sidePanel.widgets().set(2,header2)
// sidePanel.widgets().set(1,header2)
sidePanel.widgets().set(3,header3)
// sidePanel.widgets().set(3,thumb)   
sidePanel.widgets().set(4,AppDescription)     
sidePanel.widgets().set(5,intro)     
// ---------------------- LABELS --------------------------
var DataSelectorLabel=ui.Label('1: データセットを選択してください。',{fontSize: '14px', fontWeight: 'bold', color: '#191970'});
var VisSelectorLabel=ui.Label('2: 次の中から表示方法を選んで指示の通りに表示するバンドを指定してください。',{fontSize: '14px', fontWeight: 'bold', color: '#191970'});
var ResetLabel=ui.Label('単バンド表示から3バンド表示、あるいは3バンド表示から単バンド表示に切り替える際には、以下のボタンを押してください。',{fontSize: '14px', fontWeight: 'bold', color: 'red'});
var GreyScaleLabel=ui.Label('2-1:単バンド（グレースケール）画像を表示するには、下のドロップボックスメニューからバンドを選択してください。',{fontSize: '13px', color: '#191970'});
var ComLabel=(ui.Label('2-2: 3バンド（赤緑青）カラー合成画像を表示するには、下のテキストボックスに赤、緑、青の色を割り当てるバンドの組み合わせを例のように入力してください。',{fontSize: '13px',  color: '#191970'}))
var MinMaxLabel= ui.Label('3: 表示させる最小・最大の画素値（反射率×10000）をテキストボックスに入力してください。',{fontSize: '14px', fontWeight: 'bold', color: '#191970'});
var PeriodSelectorLabel=ui.Label('4:表示させたいデータの観測時期（検索開始・終了日）を例のようにテキストボックスに入力してください。',{fontSize: '14px', fontWeight: 'bold', color: '#191970'});
var ReducerSelectorLabel=ui.Label('5: データの合成方法を選択してください。',{fontSize: '14px', fontWeight: 'bold', color: '#191970'});
var CloudMaskLabel=ui.Label('6: 雲マスクを適用する場合は、チェックを入れてください。',{fontSize: '14px', fontWeight: 'bold', color: '#191970'})
var LoadLabel=ui.Label('7: 表示ボタンを押して、画像を表示してください。',{fontSize: '14px', fontWeight: 'bold', color: '#191970'});
var inspectorLabel= ui.Label('** 地図上をクリックすると、その点の経度、緯度とその位置における表示されたバンド画像の画素値を確認できます。',{fontSize: '14px', fontWeight: 'bold', color: '#191970',textAlign:'center'});
var Loading=ui.Label('Loading...', {color: 'gray'})
// ---------------------- DatasetSelector & BandSelector --------------------------
var datasetSelector = ui.Select({
  items: [{label:'LANDSAT/LC08/C02/T1_L2', value:'LANDSAT/LC08/C02/T1_L2'},
          {label:'LANDSAT/LC08/C01/T2', value:'LANDSAT/LC08/C01/T2'} ,
          {label:'COPERNICUS/S2', value:'COPERNICUS/S2'}],
  placeholder:'Select a dataset',
  style:{stretch: 'horizontal'},
  onChange: function() {
    if (datasetSelector.getValue() === 'LANDSAT/LC08/C02/T1_L2'){
      GreyBandSelector = ui.Select({
        items: [
        {label:'Choose a band',value:'Choose a band'},
        {label:'B1: Ultra blue (0.435-0.451μm)',value:'B1'},
        {label:'B2: Blue (0.452-0.512 μm)',value:'B2'},
        {label:'B3: Green (0.533-0.590 μm)',value:'B3'},
        {label:'B4: Red (0.636-0.673 μm)',value:'B4'},
        {label:'B5: Near infrared (0.851-0.879 μm)',value:'B5'},
        {label:'B6: Shortwave infrared 1 (1.566-1.651 μm)',value:'B6'},
        {label:'B7: Shortwave infrared 2 (2.107-2.294 μm)',value:'B7'},
        {label:'B10: Surface temperature (10.60-11.19 μm)',value:'B10'},
        ],
        // placeholder:'Please choose a band from LS8_SR',
        value:'Choose a band',
        onChange: function() {
        }
      });
    }
    if (datasetSelector.getValue() === 'LANDSAT/LC08/C01/T2'){
      GreyBandSelector = ui.Select({
        items: [
        {label:'Choose a band',value:'Choose a band'},
        {label:'B1: Coastal aerosol (0.43 - 0.45 µm)',value:'B1'},
        {label:'B2: Blue (0.45 - 0.51 µm)',value:'B2'},
        {label:'B3: Green (0.53 - 0.59 µm)',value:'B3'},
        {label:'B4: Red (0.64 - 0.67 µm)',value:'B4'},
        {label:'B5: Near infrared (0.85 - 0.88 µm)',value:'B5'},
        {label:'B6: Shortwave infrared 1 (1.57 - 1.65 µm) ',value:'B6'},
        {label:'B7: Shortwave infrared 2 (2.11 - 2.29 µm)',value:'B7'},
        {label:'B8: Panchromatic (0.52 - 0.90 µm)',value:'B8'},
        {label:'B9: B9: Cirrus (1.36 - 1.38 µm)',value:'B9'},
        {label:'B10: Thermal infrared 1 (60 - 11.19 µm)',value:'B10'},
        {label:'B11: Thermal infrared 2 (11.50 - 12.51 µm)',value:'B11'}
        ],
        // placeholder:'Please choose a band from LS8_RowData',
        value:'Choose a band',
        onChange: function() {
        }
      });
    }  
    if (datasetSelector.getValue() === 'COPERNICUS/S2'){
      GreyBandSelector = ui.Select({
        items: [
        {label:'Choose a band',value:'Choose a band'},
        {label:'B1: Aerosols (443.9nm (S2A) / 442.3nm (S2B))',value:'B1'},
        {label:'B2: Blue (496.6nm (S2A) / 492.1nm (S2B))',value:'B2'},
        {label:'B3: Green (560nm (S2A) / 559nm (S2B))',value:'B3'},
        {label:'B4: Red (664.5nm (S2A) / 665nm (S2B))',value:'B4'},
        {label:'B5: Red Edge 1 (703.9nm (S2A) / 703.8nm (S2B))',value:'B5'},
        {label:'B6: Red Edge 2 (740.2nm (S2A) / 739.1nm (S2B))',value:'B6'},
        {label:'B7: Red Edge 3 (782.5nm (S2A) / 779.7nm (S2B))',value:'B7'},
        {label:'B8: Near infrared (835.1nm (S2A) / 833nm (S2B))',value:'B8'},
        {label:'B8A: Red Edge 4 (864.8nm (S2A) / 864nm (S2B))',value:'B8A'},
        {label:'B9: Water vapor (945nm (S2A) / 943.2nm (S2B))',value:'B9'},
        {label:'B11: Shortwave infrared 1 (1613.7nm (S2A) / 1610.4nm (S2B))',value:'B11'},
        {label:'B12: Shortwave infrared 2 (2202.4nm (S2A) / 2185.7nm (S2B))',value:'B12'}        
        ],
        value:'Choose a band',
        // placeholder:'Please choose a band from Sent.2',
        onChange: function() {
        }
      });
    }
    sidePanel.widgets().set(10,GreyBandSelector);
  }
  });
var GreyBandSelector = ui.Select({style:{stretch: 'horizontal'},});
var ComBandSelector=ui.Textbox({
    style:{stretch: 'horizontal'},
    placeholder: 'ex: B4-B3-B2',
  });
var Reset=ui.Button({
  label: 'Reset visualization method',
  style:{stretch: 'horizontal'},
  onClick: function(){
    GreyBandSelector.setValue('Choose a band')
    ComBandSelector.setValue('')
  }
})
sidePanel.widgets().set(5,DataSelectorLabel)
sidePanel.widgets().set(6,datasetSelector)
sidePanel.widgets().set(7,ui.Label({
    value: '---------------------------------------------------------------------------------------------',
    style: {fontSize: '10px',fontWeight: 'bold',  color: 'gray',textAlign:'center'},
  }))
sidePanel.widgets().set(8,VisSelectorLabel)
sidePanel.widgets().set(9,GreyScaleLabel) 
sidePanel.widgets().set(10,GreyBandSelector)
sidePanel.widgets().set(11,ComLabel)    
sidePanel.widgets().set(12,ComBandSelector)
sidePanel.widgets().set(13,ResetLabel)
sidePanel.widgets().set(14,Reset)
sidePanel.widgets().set(15,ui.Label({
    value: '---------------------------------------------------------------------------------------------',
    style: {fontSize: '10px',fontWeight: 'bold',  color: 'gray',textAlign:'center'},
  }))
// ---------------------- Min&Max Value --------------------------
var minTextBox=ui.Textbox({
    style:{stretch: 'horizontal'},
    placeholder: 'Min value(s) ex: 1band: 0, 3bands: 0-0-0'});
var maxTextBox=ui.Textbox({    
    style:{stretch: 'horizontal'},
    placeholder: 'Max value(s) ex: 1band: 3000, 3bands: 3000-4000-5000'});
sidePanel.widgets().set(16,MinMaxLabel)    
sidePanel.widgets().set(17,minTextBox)    
sidePanel.widgets().set(18,maxTextBox)
sidePanel.widgets().set(19,ui.Label({
    value: '---------------------------------------------------------------------------------------------',
    style: {fontSize: '10px',fontWeight: 'bold',  color: 'gray',textAlign:'center'},
  }))
// ---------------------- PeriodSelector --------------------------
var StartDateTextBox= ui.Textbox({
          placeholder: 'ex: 2018-01-01',
          style:{stretch: 'horizontal'},
          });
var EndDateTextBox = ui.Textbox({
          placeholder: 'ex: 2020-01-01',
          style:{stretch: 'horizontal'},
          });
sidePanel.widgets().set(20,PeriodSelectorLabel)    
sidePanel.widgets().set(21,StartDateTextBox)    
sidePanel.widgets().set(22,EndDateTextBox)    
sidePanel.widgets().set(23,ui.Label({
    value: '---------------------------------------------------------------------------------------------',
    style: {fontSize: '10px',fontWeight: 'bold',  color: 'gray',textAlign:'center'},
  }))
//---------------------- ReducerSelector --------------------------
var ReducerSelector=ui.Select({
  placeholder:'Select a reducer',
  style:{stretch: 'horizontal'},
  items:[{label:'中間値',value:'中間値'},{label:'平均値',value:'平均値'},{label:'最小値',value:'最小値'},
        {label:'最大値',value:'最大値'},{label:'最新（合成しない）',value:'最新（合成しない）'},
        {label:'最古（合成しない）',value:'最古（合成しない）'}],  
      });
sidePanel.widgets().set(24,ReducerSelectorLabel)    
sidePanel.widgets().set(25,ReducerSelector)    
sidePanel.widgets().set(26,ui.Label({
    value: '---------------------------------------------------------------------------------------------',
    style: {stretch: 'horizontal',fontSize: '10px',fontWeight: 'bold',  color: 'gray',textAlign:'center'},
  }))
// ---------------------- CloudMasking --------------------------
var CloudMask = ui.Checkbox('Cloud Masking', false);   
sidePanel.widgets().set(27,CloudMaskLabel)    
sidePanel.widgets().set(28,CloudMask)    
sidePanel.widgets().set(29,ui.Label({
    value: '---------------------------------------------------------------------------------------------',
    style: {fontSize: '10px',fontWeight: 'bold',  color: 'gray',textAlign:'center'},
  }))
//---------------------- Loading --------------------------
var Loadbutton = ui.Button({
  style:{stretch: 'horizontal'},
  label: 'Load image',
  onClick: function(){
    var Dataset=(ee.ImageCollection(datasetSelector.getValue()));
    var DatasetForName=function(string){
      if(datasetSelector.getValue()==='LANDSAT/LC08/C02/T1_L2'){
        return 'Landsat8SR_'} 
      if(datasetSelector.getValue()==='LANDSAT/LC08/C01/T2'){
        return 'Landsat8_RowData_'}
        else {return 'Sentinal 2_'}}
    var CloudMaskForName=function(string){
      if(CloudMask.getValue()===true){
        return 'CloudMasked_'} 
      else{return 'Cloudy_'}
    };
    var RGBBands=ComBandSelector.getValue();
      if (GreyBandSelector.getValue()=== 'Choose a band'){
        var SelectedBand=ee.String(ComBandSelector.getValue()).split('-');
      }
      else {
       var SelectedBand=ee.String(GreyBandSelector.getValue());
      };
    var SelectedReducer =  function(ImageCollection){
      var SelectedRuducerObj = {
        '中間値': ee.Reducer.median(),
        '平均値': ee.Reducer.mean(),
        '最大値': ee.Reducer.max(),
        '最小値': ee.Reducer.min(),
        '最古（合成しない）': ee.Reducer.firstNonNull(),
        '最新（合成しない）': ee.Reducer.lastNonNull()
      };
      return ImageCollection.reduce(SelectedRuducerObj[ReducerSelector.getValue()]) ;
    };
    var CloudMaskImgColl=function(ImageCollection){
          if (CloudMask.getValue() === true){
              if(datasetSelector.getValue()=== 'LANDSAT/LC08/C02/T1_L2'){
                return ((ImageCollection.filter(ee.Filter.eq('PROCESSING_LEVEL','L2SP'))).map(applyScaleFactors).map(rename)).map(maskL8sr)}
              if(datasetSelector.getValue()=== 'LANDSAT/LC08/C01/T2'){
                return ImageCollection.map(maskL8)}                
              else {
                return ImageCollection.map(maskS2)}
          }
          else {
            if(datasetSelector.getValue()=== 'LANDSAT/LC08/C02/T1_L2'){
                return ((ImageCollection.filter(ee.Filter.eq('PROCESSING_LEVEL','L2SP'))).map(applyScaleFactors).map(rename))}
              if(datasetSelector.getValue()=== 'LANDSAT/LC08/C01/T2'){
                return ImageCollection}                
              else {
                return ImageCollection}
            // return ImageCollection
          }
          };    
    var startDate=ee.Date(StartDateTextBox.getValue());
    var endDate=ee.Date(EndDateTextBox.getValue());
    var DateFilteredDataset=Dataset.filterDate(startDate,endDate)
    var ImgtoLoad=SelectedReducer((CloudMaskImgColl(Dataset.filterDate(startDate,endDate))).select(SelectedBand))
    print(ImgtoLoad)
    var ImgName=(DatasetForName(datasetSelector.getValue()))+(CloudMaskForName(CloudMask.getValue()))+
                (StartDateTextBox.getValue())+'_'+(EndDateTextBox.getValue());
    var NewMinValue=(minTextBox.getValue().split('-')).map(function(String){return ee.Number.parse(String)});
     if (GreyBandSelector.getValue()=== 'Choose a band'){
        var NewMin=ee.String(minTextBox.getValue()).split('-');
      }
      else {
       var NewMin=minTextBox.getValue();
      };
    print('NewMinValue',NewMinValue)
    var NewMaxValue=(maxTextBox.getValue().split('-')).map(function(String){return ee.Number.parse(String)});
     if (GreyBandSelector.getValue()=== 'Choose a band'){
        var NewMax=ee.String(maxTextBox.getValue()).split('-');
      }
      else {
       var NewMax=maxTextBox.getValue();
      }; 
    print('NewMaxValue',NewMaxValue)
   var create_myAddLayerFunc = function (maxLayerNum){
    return(function (img,layername){
      while ((Map.layers().length()) > maxLayerNum-1){
        Map.remove(Map.layers().get(0));
      }
      return (Map.addLayer(img,layername));
        });
      };
    var myAddLayer_3 = create_myAddLayerFunc(5);
    Map.onClick(function(coords) {
      var location = '経度: ' + coords.lon.toFixed(4) + ' ' +
                     '緯度: ' + coords.lat.toFixed(4);
      var click_point = ee.Geometry.Point(coords.lon, coords.lat);
      var demValue = (ImgtoLoad.reduceRegion(ee.Reducer.first(), click_point, 30)).values().evaluate(function(val){
        var demText = '画素値（最上層レイヤ）: ' + val;
        sidePanel.widgets().set(34,ui.Label(demText));
      });
      sidePanel.widgets().set(33,ui.Label(location));
    // Edit: To be temporary, the "loading..." panel number has to be the same as the demText panel number (changed from 1 to 2).
      sidePanel.widgets().set(34,ui.Label("loading..."));
      sidePanel.widgets().set(35,ui.Label("Date of observation (in the given period):", {fontWeight:'bold'}));      
        var times = DateFilteredDataset
          .filterBounds(click_point)
          .sort('system:time_start')
          .aggregate_array('system:time_start')
          .reduce(ee.Reducer.minMax())
        times = ee.Dictionary(times)
        // print(times)
        ee.Date(times.get('min')).format('YYYY-MM-dd').evaluate(function(t) {
          var str = 'First observation:  ' + t; 
          sidePanel.widgets().set(36, ui.Label(str));
        })
        ee.Date(times.get('max')).format('YYYY-MM-dd').evaluate(function(t) {
          var str = 'Last observation:  ' + t; 
          sidePanel.widgets().set(37, ui.Label(str));
        });
       sidePanel.widgets().set(36,ui.Label("loading the Date..."));
       sidePanel.widgets().set(37,ui.Label("loading the Date..."));
    });
      // sidePanel.widgets().set(38,thumb);    
      var dic= ee.Dictionary({
        min:NewMinValue,
        max:NewMaxValue,
      })
      print(dic)
      dic.evaluate(function(dic) {
            var vizParams = {
              min: dic.min, 
              max: dic.max, 
              // bands: ['B4','B3','B2']
            }
      myAddLayer_3(Map.addLayer(ImgtoLoad,vizParams,ImgName))
      });
  }
  });
sidePanel.widgets().set(30,LoadLabel)    
sidePanel.widgets().set(31,Loadbutton)    
sidePanel.widgets().set(32,ui.Label({
    value: '---------------------------------------------------------------------------------------------',
    style: {fontSize: '10px',fontWeight: 'bold',  color: 'gray',textAlign:'center'},
  }))
sidePanel.add(inspectorLabel) 
// sidePanel.widgets().set(38,thumb)    
sidePanel.add(thumb1) 
var ToU = ui.Label({value:'利用許諾',
                        style:{fontSize: '12px', fontFamily:'serif',fontWeight: 'bold', color: '#357EC7',textAlign:'center',margin:'0px 0px 0px 330px'}})
                                            .setUrl('https://rs-training.jp/square/vega/#tou');  
var Contact = ui.Label({value:'VEGAに関するご意見やご質問はこちらにご連絡下さい。',
                        style:{fontSize: '12px', fontFamily:'serif',fontWeight: 'bold', color: '#357EC7',textAlign:'center',margin:'0px 0px 0px 10px'}})
                                            .setUrl('https://rs-training.jp/contact/');  
var MoreInfo = ui.Label({value:'衛星データの研修や利用に関する情報は「リモセン研修ラボ」をご覧下さい。',
                        style:{fontSize: '12px', fontFamily:'serif',fontWeight: 'bold', color: '#357EC7',textAlign:'left',margin:'5px 0px 0px 10px'}})
                                            .setUrl('https://rs-training.jp/');                                           
sidePanel.add(ToU) 
sidePanel.add(Contact) 
sidePanel.add(MoreInfo) 
// sidePanel.add(inspector_value)    
//---------------------- Adding TO PANEL --------------------------
Map.setCenter(139.7711, 35.681,10)
ui.root.add(sidePanel)