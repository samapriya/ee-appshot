var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.MultiPoint(),
    table = ui.import && ui.import("table", "table", {
      "id": "users/wilberthpeniche/cuxtal"
    }) || ee.FeatureCollection("users/wilberthpeniche/cuxtal"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 0.99,
        "bands": [
          "B4",
          "B3",
          "B2"
        ],
        "max": 3000,
        "gamma": 1
      }
    }) || {"opacity":0.99,"bands":["B4","B3","B2"],"max":3000,"gamma":1},
    geometry2 = ui.import && ui.import("geometry2", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.MultiPoint();
Map.setControlVisibility({
  drawingToolsControl:false,
  zoomControl: false,
  mapTypeControl: false,
  fullscreenControl: false,
});
Map.setOptions('HYBRID');
Map.setZoom(4)
var shown = true;
var opacity = 0.2;
var visParams = {color:"red"};
var cuxtal = 
ee.FeatureCollection('users/wilberthpeniche/cuxtal');
cuxtal = cuxtal.geometry();
Map.centerObject(cuxtal)
Map.addLayer(cuxtal, visParams, 'cuxtal', shown, opacity);
var chartNotes = ui.Label({
  value: 'Chart notes:',
  style: {fontSize: '12px', margin: '4px', fontWeight: 'bold'}
});
var chartNote1 = ui.Label({
  value: '• Lines represent 9-day statistics around 5-day increments.',
  style: {fontSize: '12px', width: '250px'}
});
var chartNote2 = ui.Label({
  value: '• Y-axis is interactive: scroll to zoom, left click + drag to pan, reset with right click.',
  style: {fontSize: '12px', width: '250px'},
});
var chartNote3 = ui.Label({
  value: '• Scale for area reduction varies from 1 km to 10 km. 1 km for area <= 1e5 km2, 5 km for area > 1e5 km2, and 10 km for area > 10e5 km2. Maximum area is 8e5 km2.',
  style: {fontSize: '12px', width: '250px'},
});
var notesShow = false;
function notesButtonHandler() {
  if(notesShow){
    notesShow = false;
    notesPanel.style().set('shown', false);
    notesButton.setLabel('VER INSTRUCCIONES');
  } else {
    notesShow = true;
    notesPanel.style().set('shown', true);
    notesButton.setLabel('Esconder instrucciones');    
  }
}
var notesButton = ui.Button({label: 'VER INSTRUCCIONES', onClick: notesButtonHandler});
var notesPanel = ui.Panel({
  widgets: [
    chartNotes,
    chartNote1,
    chartNote2,
    chartNote3
  ],
  style: {shown: false}
});
var panelContainer = ui.Panel({widgets: [notesButton, notesPanel],
  style: {position: 'top-center',
    backgroundColor: 'rgba(255, 255, 255, 1)'}});
Map.add(panelContainer);
var panelContainer2 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'), 
  style: {width: '300px', height:'370px', backgroundColor: "rgba(255, 255, 255, 1)", position: 'top-left', textAlign: "center", whiteSpace: "nowrap", shown: false}
});
Map.add(panelContainer2);
var notesShow2 = false;
function notesButtonHandler2() {
  if(notesShow2){
    notesShow2 = false;
    panelContainer2.style().set('shown', false);
    notesButton2.setLabel('Ver panel de descargas');
  } else {
    notesShow2 = true;
    panelContainer2.style().set('shown', true);
    notesButton2.setLabel('Esconder panel de descargas');    
  }
}
var notesButton2 = ui.Button({label: 'Ver panel de descargas', onClick: notesButtonHandler2});
var calculateComposite = function(year, startDate, endDate, cloudsTh, MaxCloudsProbability, B1, B2, B3, b1Col, b2Col, b3Col){
var startDateWithYear = year+"-"+startDate;
var endDateWithYear = year+"-"+endDate;
// load and filter the S2 dataset
var S2 = ee.ImageCollection('COPERNICUS/S2')
         .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloudsTh))
         .filterDate(startDateWithYear, endDateWithYear);
// add cloud mask to each S2 image
var S2_CLOUD_PROBABILITY = ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY');
S2 = ee.Join.saveFirst('cloud_mask').apply({
primary: S2,
secondary: S2_CLOUD_PROBABILITY,
condition: ee.Filter.equals({leftField: 'system:index', rightField: 'system:index'})
});
S2 = ee.ImageCollection(S2);
// define a function to remova clouds from each image
var maskClouds = function(img) {
var clouds = ee.Image(img.get('cloud_mask')).select('probability');
var isNotCloud = clouds.lt(MaxCloudsProbability);
return img.mask(isNotCloud);
};
// use the maskClouds function
S2 = S2.map(maskClouds);
// calculate median composite
S2 = S2.median();
Map.addLayer(S2, {min:0, max:[b1Col, b2Col, b3Col], bands:[B1, B2, B3]}, startDateWithYear+"/"+endDateWithYear);
function downloadImg() {
  var viewBounds = ee.Geometry.Rectangle(Map.getBounds());
  var downloadArgs = {
    name: 'img',
    crs: 'EPSG:32616',
    scale: 10,
    region: viewBounds.toGeoJSONString()
 };
 var url = S2.getDownloadURL(downloadArgs);
 urlLabel.setUrl(url);
 urlLabel.style().set({shown: true});
}
var downloadButton = ui.Button('Descargar bandas'+" "+startDateWithYear+"/"+endDateWithYear, downloadImg);
var urlLabel = ui.Label('Link de descarga', {shown: false});
var panel = ui.Panel([downloadButton, urlLabel]);
//Map.add(panel);
function downloadImg2() {
  var viewBounds = ee.Geometry.Rectangle(Map.getBounds());
  var downloadArgs = {
    name: 'img',
    crs: 'EPSG:32616',
    scale: 10,
    region: viewBounds.toGeoJSONString(),
    bands: [B1, B2, B3],
    format: 'GEO_TIFF'
 };
 var url2 = S2.getDownloadURL(downloadArgs);
 urlLabel2.setUrl(url2);
 urlLabel2.style().set({shown: true});
}
var downloadButton2 = ui.Button('Descargar GeoTIFF'+" "+startDateWithYear+"/"+endDateWithYear, downloadImg2);
var urlLabel2 = ui.Label('Link de descarga', {shown: false});
var panel2 = ui.Panel([downloadButton2, urlLabel2]);
//Map.add(panel2);
//var panelContainer = ui.Panel({widgets: [panel, panel2],
//  style: {position: 'top-left',
//    backgroundColor: 'rgba(255, 255, 255, 0)'}});
//Map.add(panelContainer);
panelContainer2.add(panel);
panelContainer2.add(panel2)
return S2;
};
// var composite2017 = calculateComposite(2017, "06-01", "08-31", 70, 20, "B4", "B3", "B2", 0, 3000);
var loadInputs = function(){
var year             = yearTexbox             .getValue();
var startDate        = startDateTexbox        .getValue();
var endDate          = endDateTexbox          .getValue();
var B1               = B1selectorbox          .getValue();
var B2               = B2selectorbox          .getValue();
var B3               = B3selectorbox          .getValue();
var cloudThreshold   = cloudThresholdSlider   .getValue();
var cloudProbability = cloudProbabilitySlider .getValue();
var b1Col            = b1ColSlider            .getValue();
var b2Col            = b2ColSlider            .getValue();
var b3Col            = b3ColSlider            .getValue();
return {
  year             : year,
  startDate        : startDate,
  endDate          : endDate,
  B1               : B1,
  B2               : B2,
  B3               : B3,
  cloudThreshold   : cloudThreshold,
  cloudProbability : cloudProbability,
  b1Col            : b1Col,
  b2Col            : b2Col,
  b3Col            : b3Col
};
};
var run = function(){
// load user inputs
var Inputs = loadInputs();
print(Inputs);
// run the function
calculateComposite(
  Inputs.year,
  Inputs.startDate,
  Inputs.endDate,
  Inputs.cloudThreshold,
  Inputs.cloudProbability,
  Inputs.B1,
  Inputs.B2,
  Inputs.B3,
  Inputs.b1Col,
  Inputs.b2Col,
  Inputs.b3Col
  );
};
var removeLayers = function(){
  Map.clear();
 //Map.remove(panelContainer2);
  Map.setControlVisibility({
  drawingToolsControl:false
});
  Map.remove(panelContainer2);
  Map.setOptions('HYBRID');
  Map.add(panelContainer);
  Map.add(panelContainer2);
 //var widgets = ui.root.widgets();
//if (widgets.length()>2){
//ui.root.remove(ui.root.widgets().get(2));
  //}
};
// # input parameters
// run boxes
var runcalculateCompositeButton = ui.Button('Aplicar parámetros');
runcalculateCompositeButton.onClick(run);
var removeLayersButton = ui.Button('Borrar todo');
removeLayersButton.onClick(removeLayers);
// Text boxes
var Title = ui.Label({value: "Explorador satelital", style:{
backgroundColor : "rgba(255, 255, 255, 0.5)", textAlign: 'center',fontWeight: 'bold', fontSize: "18px"}});
var coordinatesLabel = ui.Label({value: "¿Tienes un punto de interés? Ingresa las coordenadas", style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
var yearTexbox = ui.Select({
  items: [
    {label: '2015',       value: "2015"},
    {label: '2016',       value: "2016"},    
    {label: '2015',       value: "2015"},
    {label: '2016',       value: "2016"},
    {label: '2017',       value: "2017"},
    {label: '2018',       value: "2018"},
    {label: '2019',       value: "2019"},
    {label: '2020',       value: "2020"},
    {label: '2021',       value: "2021"},
    {label: '2022',       value: "2022"}
    ]}).setValue("2021");
var startDateTexbox = ui.Textbox({
placeholder: 'startDate (e.g. 05-20)',
value: '07-01',
style: {width: '155px'}});
var endDateTexbox = ui.Textbox({
placeholder: 'endDate (e.g. 09-20)',
value: '08-31',
style: {width: '155px'}});
var B1selectorbox   = ui.Select({
  items: [
    {label: "blue",       value: "B2" },
    {label: "green",      value: "B3" },
    {label: "red",        value: "B4" },
    {label: "Red Edge 1", value: "B5" },
    {label: "Red Edge 2", value: "B6" },
    {label: "Red Edge 3", value: "B7" },
    {label: "NIR",        value: "B8" },
    {label: "Red Edge 4", value: "B8A" },
    {label: "SWIR 1",     value: "B11" },
    {label: "SWIR 2",     value: "B12" }
    ]}).setValue('B4');
var B2selectorbox   = ui.Select({
  items: [
    {label: "blue",       value: "B2" },
    {label: "green",      value: "B3" },
    {label: "red",        value: "B4" },
    {label: "Red Edge 1", value: "B5" },
    {label: "Red Edge 2", value: "B6" },
    {label: "Red Edge 3", value: "B7" },
    {label: "NIR",        value: "B8" },
    {label: "Red Edge 4", value: "B8A" },
    {label: "SWIR 1",     value: "B11" },
    {label: "SWIR 2",     value: "B12" }
    ]}).setValue('B3');
var B3selectorbox   = ui.Select({
  items: [
    {label: "blue",       value: "B2" },
    {label: "green",      value: "B3" },
    {label: "red",        value: "B4" },
    {label: "Red Edge 1", value: "B5" },
    {label: "Red Edge 2", value: "B6" },
    {label: "Red Edge 3", value: "B7" },
    {label: "NIR",        value: "B8" },
    {label: "Red Edge 4", value: "B8A" },
    {label: "SWIR 1",     value: "B11" },
    {label: "SWIR 2",     value: "B12" }
    ]}).setValue('B2');
var cloudThresholdSlider = ui.Slider({min: 0, max: 100, value:50, step: 1,
                             style: { width: '165px', backgroundColor : "rgba(255, 255, 255, 0.5)", color: "blue"}});
var cloudThresholdLabel = ui.Label({value: "Porcentaje máximo de nubes en la imagen",
                  style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
var cloudProbabilitySlider = ui.Slider({min: 0, max: 100, value:50, step: 1,
                             style: { width: '165px', backgroundColor : "rgba(255, 255, 255, 0.5)", color: "blue"}});
var cloudProbabilityLabel = ui.Label({value: "Probabilidad máxima de que el pixel contenga nubes",
                  style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
var minColSlider = ui.Slider({min: 0, max: 10000, step: 10, value:0,
style: { width: '195px', backgroundColor : "rgba(255, 255, 255, 0.5)", color: "darkgreen", shown: true}});
// var minColLabel = ui.Label({value: "Value (or one per band) to map onto 00",
//                   style:{backgroundColor : "#F7E7CE", shown: true}});
var b1ColSlider = ui.Slider({min: 0, max: 10000, step: 10, value:3000,
style: { width: '195px', backgroundColor : "rgba(255, 255, 255, 0.5)", color: "darkgreen", shown: true}});
var b2ColSlider = ui.Slider({min: 0, max: 10000, step: 10, value:3000,
style: { width: '195px', backgroundColor : "rgba(255, 255, 255, 0.5)", color: "darkgreen", shown: true}});
var b3ColSlider = ui.Slider({min: 0, max: 10000, step: 10, value:3000,
style: { width: '195px', backgroundColor : "rgba(255, 255, 255, 0.5)", color: "darkgreen", shown: true}});
var b1ColLabel = ui.Label({value: "Stretch de la primera banda", style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
var b2ColLabel = ui.Label({value: "Stretch de la segunda banda", style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
var b3ColLabel = ui.Label({value: "Stretch de la tercera banda", style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
var lon = ui.Textbox({
  value: "",
  placeholder: 'Ingresa la longitud...',
  onChange: function(value) {
    // set value with a dedicated method
    lon.setValue(value);
    return(value);
  }
});
//print(lon);
var lat = ui.Textbox({
   value: "",
  placeholder: 'Ingresa la latitud...',
  onChange: function(value) {
    // set value with a dedicated method
    lat.setValue(value);
    return(value);
  }
});
//print(lat);
var Lo;
var La;
var button = ui.Button({
  label: 'Ir al punto descrito',
  onClick: function() {
    // you don't have to convert it into EE objects since you are
    // working on the client side
    Lo = parseFloat(lon.getValue());
    La = parseFloat(lat.getValue());
    Map.setCenter(Lo, La, 17);
  }
});
var yearselectLabel = ui.Label({value: "Selecciona un año de interés:", style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
var dividerLabel = ui.Label({value: "__________________________________________________________", style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
var dividerLabel2 = ui.Label({value: "__________________________________________________________", style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
var dividerLabel3 = ui.Label({value: "__________________________________________________________", style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
var dividerLabel4 = ui.Label({value: "__________________________________________________________", style:{backgroundColor : "rgba(255, 255, 255, 0.5)", shown: true}});
//function getDownloadURL(label){
//  S2.getDownloadURL(
//    {
//      dimensions : 1024 , 
//      region : geometry, 
//      format:"geotiff",
//      name: "SARworld_S1backscatter_composite"
//    }, 
//    function(url){
//      if( url.length > 0){
//        label.setUrl( url );
//      }
//    });
//}
//print("PRUEBA", getDownloadUrl);
//var TIFFdownload = new ui.Label({ 
//    value : "Download GeoTIFF" , 
//    targetUrl : "https://reservacuxtal.com/staticurl/",
//    style: {textAlign: 'center',
//            backgroundColor: "GhostWhite",
//            stretch: 'horizontal'
//    },
//  });
// global  panel
var panel = ui.Panel({style: {width: '400px', backgroundColor: "rgba(255, 255, 255, 0.5)",
border: '2px solid black', textAlign: "center", whiteSpace: "nowrap", shown: true}});
var buttonsPanel = ui.Panel({
  widgets: [runcalculateCompositeButton, notesButton2, removeLayersButton],
  layout: ui.Panel.Layout.flow('horizontal'), style: {stretch: 'horizontal'}
});
var coordinatesPanel = ui.Panel({
  widgets: [lon, lat],
  layout: ui.Panel.Layout.flow('horizontal'), style: {stretch: 'horizontal'}
});
var datesPanel = ui.Panel({
  widgets: [startDateTexbox, endDateTexbox],
  layout: ui.Panel.Layout.flow('horizontal'), style: {stretch: 'horizontal'}
});
var bandsPanel = ui.Panel({
  widgets: [B1selectorbox, B2selectorbox, B3selectorbox],
  layout: ui.Panel.Layout.flow('horizontal'), style: {stretch: 'horizontal'}
});
var yearPanel = ui.Panel({
  widgets: [yearselectLabel, yearTexbox],
  layout: ui.Panel.Layout.flow('horizontal'), style: {stretch: 'horizontal'}
});
// adding boxes
panel.add(Title);
panel.add(dividerLabel);
panel.add(coordinatesLabel);
//panel.add(lon);
//panel.add(lat);
panel.add(coordinatesPanel);
panel.add(button);
panel.add(dividerLabel2);
panel.add(yearPanel);
//panel.add(yearTexbox);
panel.add(datesPanel);
panel.add(dividerLabel3);
panel.add(bandsPanel);
//panel.add(startDateTexbox);
//panel.add(endDateTexbox);
//panel.add(B1selectorbox);
//panel.add(B2selectorbox);
//panel.add(B3selectorbox);
panel.add(cloudThresholdLabel);
panel.add(cloudThresholdSlider);
panel.add(cloudProbabilityLabel);
panel.add(cloudProbabilitySlider);
panel.add(b1ColLabel);
panel.add(b1ColSlider);
panel.add(b2ColLabel);
panel.add(b2ColSlider);
panel.add(b3ColLabel);
panel.add(b3ColSlider);
panel.add(dividerLabel4);
//panel.add(runcalculateCompositeButton);
//panel.add(notesButton2);
//panel.add(removeLayersButton);
panel.add(buttonsPanel);
ui.root.add(panel);