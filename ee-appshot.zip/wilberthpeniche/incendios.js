var S2 = ee.ImageCollection("COPERNICUS/S2");
var SRTM = ee.Image("USGS/SRTMGL1_003");
var shade = ee.Terrain.hillshade(SRTM);
// A simple natural color band combination
var NaturalColors = function(img){
  var RED   = img.expression("2.9 * B4", {B4: img.select("B4")}).rename("RED");
  var GREEN = img.expression("3.1 * B3", {B3: img.select("B3")}).rename("GREEN");
  var BLUE  = img.expression("3.0 * B2", {B2: img.select("B2")}).rename("BLUE");
  return img.addBands(RED).addBands(GREEN).addBands(BLUE).select(["RED","GREEN","BLUE"]);
};
var NIRSWIRColors = function(img){
  //var RED   = img.expression("2.5 * B12", {B12: img.select("B12")}).rename("RED");
  //var GREEN = img.expression("1.2 * B8 + 0.8 * B11", {B8: img.select("B8"), B11: img.select("B11")}).rename("GREEN");
  //var BLUE  = img.expression("3.5 * B2", {B2: img.select("B2")}).rename("BLUE");
  var RED   = img.expression("B12", {B12: img.select("B12")}).rename("RED");
  var GREEN = img.expression("B7+(B12>1)", {B7: img.select("B7"), B12: img.select("B12")}).rename("GREEN");
  var BLUE  = img.expression("B2", {B2: img.select("B2")}).rename("BLUE");
  return img.addBands(RED).addBands(GREEN).addBands(BLUE).select(["RED","GREEN","BLUE"]);
};
var burnScars = function(img){
  // needs more research and improvements (e.g. use temporal drop of NDVI before and after the wildfire to detect the scars)
  var isBurnScars = img.expression("(((B8A - B12)/(B8A + B12)) + B11) < 0.15", {B8A: img.select("B8A"), B11: img.select("B11"), B12: img.select("B12")});
  return isBurnScars;
};
var activeFire = function(img){
  var isActiveFire = img.expression("B12 > 0.6", {B12: img.select("B12")});
  return isActiveFire;
};
var visParams = {min: 0, max: 1, gamma: 1.5};
var leftMap = ui.Map();
var leftLabel = ui.Label("True Color");
leftMap.setControlVisibility(false);
leftMap.setControlVisibility({zoomControl: true});
leftMap.add(leftLabel);
var rightMap = ui.Map();
var rightLabel = ui.Label("NIR/SWIR");
rightMap.setControlVisibility(false);
rightMap.setControlVisibility({scaleControl: true});
rightMap.add(rightLabel);
var thumbMap = ui.Map().setControlVisibility(false);
var thumbMapStyle = {
  width: "300px",
  height: "200px",
  position: "top-right",
  margin:"0px",
  padding:"0px",
};
var thumbMapPanel = ui.Panel([thumbMap], ui.Panel.Layout.flow("horizontal"), thumbMapStyle);
rightMap.add(thumbMapPanel);
var normalMode = ui.Button({label: "Normal Mode", style: {margin:"0px", padding:"0px"}});
normalMode.onClick(function() {
  textPanel.style().set("shown", true);
  thumbMapPanel.style().set("shown", true);
  normalModePanel.style().set("shown", false);
});
var normalModePanel = ui.Panel({widgets: [normalMode], style:{position:"top-right", shown: false, margin:"0px", padding:"0px",}});
rightMap.add(normalModePanel);
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: "both"}
});
var linker = ui.Map.Linker([leftMap, rightMap]);
var image;
var getMap = function() {
  var to = ee.Date(end.getValue()).advance(1, "day");
  var from = to.advance(-60, "day");
  var coord = loc.getValue().split(/,/);
  var ROI = ee.Geometry.Point([parseFloat(coord[1]), parseFloat(coord[0])]);
  image = S2.filterBounds(ROI).filterDate(from, to).sort("system:index", false).first();
  var date = ee.Date(image.get("system:time_start")).format("MMM d, YYYY");
  image = image.multiply(0.0001);
  leftMap.layers().set(0, ui.Map.Layer(NaturalColors(image), visParams));
  rightMap.layers().set(0, ui.Map.Layer(NIRSWIRColors(image), visParams));
  var hsv = NIRSWIRColors(image).visualize({min: 0, max: 1}).divide(255).rgbToHsv();
  var hs = hsv.select(0, 1);
  var v = shade.divide(255);
  var rgb = hs.addBands(v).hsvToRgb().multiply(200).byte();
  rightMap.layers().set(1, ui.Map.Layer(rgb, {}));
  if(get3D.getValue() === false) rightMap.layers().get(1).setShown(false);
  leftLabel.setValue("True Color (" + date.getInfo() + ")");
  rightLabel.setValue("NIR/SWIR (" + date.getInfo() + ")");
  shareLink.setValue("Link de descarga");
  shareLink.setUrl(getSentinelHubLink());
  ui.url.set('end', end.getValue());
  ui.url.set('loc', loc.getValue());
  //ui.url.set('zoom', leftMap.getZoom());
  leftMap.centerObject(ROI, leftMap.getZoom());
  //leftMap.layers().set(1, ui.Map.Layer(activeFire(image), {}));
  thumbMap.layers().set(1, ui.Map.Layer(ROI, {color: "red"}));
  thumbMap.centerObject(ROI, leftMap.getZoom()-6);
};
var getSentinelHubLink = function(){
  var date = end.getValue();
  var coord = loc.getValue().split(/,/);
  var lat = parseFloat(coord[0]);
  var lng = parseFloat(coord[1]);
  var evalScript = "cmV0dXJuIFtCMTIqMi41LEIwOCoxLjIrQjExKjAuOCxCMDIqMy41XQ%3D%3D";
  var link = "https://apps.sentinel-hub.com/sentinel-playground/?source=S2&lat=" + lat + "&lng=" + lng +
             "&zoom=13&preset=CUSTOM&layers=B02,B08,B11,B12&maxcc=100&gain=1.0&gamma=1.5&time=" + date +
             "%7C" + date + "&atmFilter=&showDates=false&evalscript=" + evalScript + "&showImage";
  return link;
};
var getExample = function(lat, long, date){
  return ui.Thumbnail({
    image: NIRSWIRColors(S2.filterBounds(ee.Geometry.Point(long,lat)).filterDate(date, ee.Date(date).advance(1, "day")).first().multiply(0.0001)).visualize(visParams),
    params: {
      dimensions: "64x64",
      region: ee.Geometry.Rectangle(long - 0.05, lat - 0.05, long + 0.05, lat + 0.05).toGeoJSON(),
      format: "png"
    },
    onClick: function() {
      leftMap.setZoom(13);
      end.setValue(date);
      loc.setValue(lat + ", " + long);
    },
    style: {height: "64px", width: "64px"}
  });
};
leftMap.onClick(function(coords){loc.setValue(coords.lat.toFixed(4) + ", " + coords.lon.toFixed(4))});
rightMap.onClick(function(coords){loc.setValue(coords.lat.toFixed(4) + ", " + coords.lon.toFixed(4))});
var textPanel = ui.Panel({style: {width: "500px"}});
textPanel.add(ui.Label({
    value: "Áreas quemadas",
    style: {fontSize: "20px", fontWeight: "bold"}
}));
var addText = function(url, title, margin, str){
  var css = "";
  if(title) {
    css = {fontSize: "16px", fontWeight: "bold"};
  }else if(margin){
    css = {"text-align": "justify", margin: "-8px 8px 8px 8px"};
  }else{
    css = {"text-align": "justify"};
  }
  textPanel.add(ui.Label({
    targetUrl: url,
    value: str,
    style: css
  }));
};
addText("", false, true, "Descripción de la aplicación");
var end = ui.Textbox({style: {"width": "130px"}});
var loc = ui.Textbox({style: {"margin": "0px 8px 8px 8px", "width": "130px"}});
end.setValue(ui.url.get('end','2022-03-30').toString());
loc.setValue(ui.url.get('loc','25.223287, -100.192030').toString());
//leftMap.setZoom(Number(ui.url.get('zoom', '13').toString()));
end.onChange(function(x){end.setValue(x); getMap();});
loc.onChange(function(x){loc.setValue(x); getMap();});
var back = ui.Button({
  label: "Antes",
  onClick: function() {
    end.setValue(ee.Date(end.getValue()).advance(-5, "day").format("YYYY-MM-dd").getInfo());
  }
});
var next = ui.Button({
  label: "Despúes",
  onClick: function() {
    end.setValue(ee.Date(end.getValue()).advance(5, "day").format("YYYY-MM-dd").getInfo());
  }
});
var today = ui.Button({
  label: "Hoy",
  onClick: function() {
    end.setValue(ee.Date(Date.now()).format("YYYY-MM-dd").getInfo());
  }
});
textPanel.add(ui.Panel([end, ui.Label({value: "Fecha (aaaa-mm-dd)", style: {"height": "30px"}}), back, next, today], ui.Panel.Layout.flow("horizontal")));
textPanel.add(ui.Panel([loc, ui.Label({value: "Coordenadas (latitud, longitud in DD)", style: {"height": "30px", margin: "-2px 8px 8px 8px"}})], ui.Panel.Layout.flow("horizontal")));
var scarsArea = ui.Checkbox("Calcular área quemada", false);
scarsArea.onChange(function(checked) {
  if(checked === true){
    // area is expressed in hectares (dividing pixel area by 10000)
    var areaLayer = ee.Image.pixelArea().divide(10000);
    var screenBounds = ee.Geometry.Rectangle(rightMap.getBounds());
    var scars = burnScars(image);
    var areaImage = scars.multiply(areaLayer);
    var area = areaImage.reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: screenBounds,
      scale: 20,
      maxPixels: 1e13
    });
    leftMap.layers().set(1, ui.Map.Layer(scars.updateMask(scars.gt(0)), {palette: ["FF0000"]}));
    alert("La estimación total de hectáreas incendiadas es de: " + Math.round(area.values().get(0).getInfo()) + " (ha)");
  }else{
    leftMap.layers().set(1, null);
  }
});
var get3D = ui.Checkbox("3D", false);
get3D.onChange(function(checked){
  if(checked === true){
    rightMap.layers().get(1).setShown(true);
  } else {
    rightMap.layers().get(1).setShown(false);
  }
});
var fullScreen = ui.Button("Pantalla completa");
fullScreen.onClick(function() {
  textPanel.style().set("shown", false);
  thumbMapPanel.style().set("shown", false);
  normalModePanel.style().set("shown", true);
});
var shareLink = ui.Label();
shareLink.setUrl("https://apps.sentinel-hub.com/eo-browser/");
scarsArea.style().set("height", "30px");
get3D.style().set("height", "30px");
shareLink.style().set("height", "30px");
textPanel.add(ui.Panel([scarsArea, get3D, fullScreen, shareLink], ui.Panel.Layout.flow("horizontal")));
var eg1 = getExample(19.918560, -89.325441, "2019-03-19");
var eg2 = getExample(20.9976997, -89.4218979, "2017-02-23");
var eg3 = getExample(21.091722222, -89.804166667, "2020-03-25");
var eg4 = getExample(21.229827778, -89.31855, "2021-03-26");
var eg5 = getExample(25.223287, -100.192030, "2022-03-30");
textPanel.add(ui.Panel([eg1, eg2, eg3, eg4, eg5], ui.Panel.Layout.flow("horizontal")));
addText("", true, false, "Background");
addText("", false, true, "Background del manejo del fuego");
addText("", true, false, "Datos");
addText("https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2", false, true,
        "Sentinel-2 MSI: MultiSpectral Instrument, Level-1C.");
//addText("", true, false, "Acknowledge");
//addText("https://pierre-markuse.net/2018/04/30/visualizing-wildfires-burn-scars-sentinel-hub-eo-browser/", false, true,
//        "This work is derivative and inspired by @Pierre_Markuse work on the wildfire visualization.");
//addText("", true, false, "Disclaimer");
//addText("", false, true, "The products elaborated in the framework of this project are realized to \
//        the best of our ability, optimizing the available data and information. All geographic information \
//        has limitations due to scale, resolution, date and interpretation of the original data sources.");
var pageGrid = ui.Panel([splitPanel,textPanel], ui.Panel.Layout.Flow("horizontal"), {stretch: "both"});
ui.root.widgets().reset([pageGrid]);
ui.root.setLayout(ui.Panel.Layout.Flow("vertical"));
leftMap.setZoom(13);
getMap();