// Importing Sentinel 5P image collections for the weeks prior to the COVID-19 first infected case// Reference date: first case 15.03.2020
var image_prior = ee.ImageCollection('COPERNICUS/S5P/NRTI/L3_NO2')
  .select('tropospheric_NO2_column_number_density')
  .filterDate('2020-01-21','2020-02-22');
// Importing Sentinel 5P image collections for the weeks prior to the COVID-19 first semi lockdown
var image_during = ee.ImageCollection('COPERNICUS/S5P/NRTI/L3_NO2')
  .select('tropospheric_NO2_column_number_density')
  .filterDate('2020-02-22','2020-03-26');
// Importing color palette for visualization
var palettes = require('users/gena/packages:palettes');
var palette = palettes.matplotlib.magma[7];
// Setting first map controls and removing some unnecessary control panels while keeping zoom and scale
Map.addLayer(image_prior.mean(), {min: 0, max: 0.0003, palette: palette, opacity:0.75});
Map.setCenter(4.55, 52.01, 7);
Map.setControlVisibility({all: false, zoomControl: true, mapTypeControl: true});
// Creating the linked map and adding it to the split widget through a linker
var linkedMap = ui.Map();
linkedMap.addLayer(image_during.mean(), {min: 0, max: 0.0003, palette: palette, opacity:0.75});
linkedMap.setCenter(4.55, 52.01, 7);
linkedMap.setControlVisibility({all: false, zoomControl: true, mapTypeControl: true})
var linker = ui.Map.Linker([ui.root.widgets().get(0), linkedMap]);
// Add title labels to the maps
var title_prior= Map.add(ui.Label('Mean NO2 prior to pandemics', {fontWeight: 'bold', fontSize: '10px', position: 'bottom-left', color: 'slateGrey'}));
var title_during= linkedMap.add(ui.Label('Mean NO2 during the pandemics', {fontWeight: 'bold', fontSize: '10px', position: 'bottom-right', color: 'slateGrey'}));
// Creating the split panel comprising the two maps
var splitPanel = ui.SplitPanel({
  firstPanel: linker.get(0),
  secondPanel: linker.get(1),
  orientation: 'horizontal',
  wipe: true,
  style: {stretch: 'both'}
  });
ui.root.widgets().reset([splitPanel]);
// Create side panel and add a header and text
var header = ui.Label('Comparison of mean NO2 emissions prior to and during the COVID-19 pandemics in the Netherlands', {fontSize: '15px', color: 'darkSlateGrey'});
var text_1 = ui.Label(
  'The map presents a comparison of the mean NO2 emissions in the period preceeding the COVID-19 outbreak and during the pandemics. The right side of the map shows the period from the first case confirmation in the Netherlands on the 27th of February 2020 to present, whereas the left map indicates for an equal period before 27 February 2020',
  {fontSize: '11px'});
var text_2 = ui.Label(
  'Data source: Sentinel-5P Near Real Time Data (European Comission/ESA/Copernicus)',
  {fontSize: '11px'});
// Create a copyright text for author
var text_3 = ui.Label({
  value: 'Last update: 26 March 2020. Email: milad.mahour@cgi.com. Twitter: @milad',
  style:{
  fontSize: '8px'
  }
  });
var toolPanel = ui.Panel([header, text_1, text_2, text_3], 'flow', {width: '300px'});
//Create external reference with link
var link = ui.Label(
  'Nitrogen dioxide description and sensing information', {},
  'http://www.tropomi.eu/data-products/nitrogen-dioxide');
var linkPanel = ui.Panel(
  [ui.Label('For more information', {fontWeight: 'bold'}), link]);
  toolPanel.add(linkPanel);
// Create legend for the data
var viz = {min:0.0, max:300.0, palette:palette};
var legend = ui.Panel({
  style: {
  position: 'bottom-left',
  padding: '8px 15px'
  }
  });
// Create legend title
var legendTitle = ui.Label({
  value: 'NO2 Concentration (μmol/m²)',
  style: {
  fontWeight:'bold',
  fontSize: '8 px',
  margin: '0 0 4px 0',
  padding: '0'
  }
  });
// Add the title to the panel
legend.add(legendTitle);
// Create and and style the legend
var makeRow = function(color, name) {
// Create the colored box.
var colorBox = ui.Label({
  style: {
  backgroundColor: '#' + color,
// Use padding to give the box height and width.
  padding: '8px',
  margin: '0 0 4px 0'
  }
  });
// Create the label filled with the description text.
var description = ui.Label({
  value: name,
  style: {margin: '0 0 4px 6px'}
  });
// Return the panel
return ui.Panel({
  widgets: [colorBox, description],
  layout: ui.Panel.Layout.Flow('horizontal')
  });
  };
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// Create text label on top of legend
var panel_max = ui.Panel({
  widgets: [
  ui.Label(viz['max'])
  ],
  });
legend.add(panel_max);
// Create thumbnail from the image
var thumbnail = ui.Thumbnail({
  image: legendImage,
  params: {bbox:'0,0,10,100', dimensions:'10x100'},
  style: {padding: '1px', position: 'bottom-center'}
  });
// Add the thumbnail to the legend
legend.add(thumbnail);
// Create text label on bottom of legend
var panel_min = ui.Panel({
  widgets: [
  ui.Label(viz['min'])
  ],
  });
legend.add(panel_min);
toolPanel.add(legend);
ui.root.widgets().add(toolPanel);