//<-- This application has been developed as an easy to use tool for land cover mapping particularly with a goal of 
//<-- tracking land cover changes over a community of interest and track changes in green space over time
//<-- This app has possible application in urban environmental planning
print("Hello World")