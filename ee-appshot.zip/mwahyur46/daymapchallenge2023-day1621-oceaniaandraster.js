var nov1523 = ui.import && ui.import("nov1523", "image", {
      "id": "users/Data_GIS/30DayMapChallenge2023/Whakari_12112023"
    }) || ee.Image("users/Data_GIS/30DayMapChallenge2023/Whakari_12112023"),
    jan0520 = ui.import && ui.import("jan0520", "image", {
      "id": "users/Data_GIS/30DayMapChallenge2023/Whakari_05012020"
    }) || ee.Image("users/Data_GIS/30DayMapChallenge2023/Whakari_05012020");
//Day 16 & 21 - Oceania and Raster
// Planetscope image true color visualization
var vis1 = { min: 0, max: 1500, bands: [ 'b8', 'b6', 'b4' ] };
var vis2 = { min: 0, max: 1500, bands: [ 'b4', 'b3', 'b2' ] };
// Show the image
Map.addLayer(nov1523, vis1, '12 November 2023')
Map.addLayer(jan0520, vis2, '5 January 2020');
Map.setCenter(177.184882, -37.521775, 15);
// //Zoom
// Map.setCenter(112.30460861297274,-7.938111282873776, 14);
// //Landsat 8
// var landsat8_2021 = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA');
// var landsat8_2014 = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA');
// var med_2021 = landsat8_2021.filterDate('2021-08-01', '2021-08-30').median();
// var med_2014 = landsat8_2014.filterDate('2014-06-01', '2014-10-31').median();
// var vis = {bands: ['B4', 'B3', 'B2'], max: 0.3};//Visualization Parameters
// Map.addLayer(med_2021, vis, '2021');//2021
// Map.addLayer(med_2014, vis, '2014');//2014
//Layer Position
var leftMap = ui.Map()
var rightMap = ui.Map()
var pscope2023 = ui.Map.Layer(nov1523, vis1)
var pscope2020 = ui.Map.Layer(jan0520, vis2)
var pscope2023_layer = rightMap.layers()
var pscope2020_layer = leftMap.layers()
pscope2023_layer.add(pscope2023)
pscope2020_layer.add(pscope2020)
//Label
var label_2020 = ui.Label('5 January 2020');
label_2020.style().set({
  position: 'bottom-left',
  fontWeight: 'bold' // Setting the font weight to bold
});
var label_2023 = ui.Label('12 November 2023');
label_2023.style().set({
  position: 'bottom-right',
  fontWeight: 'bold' // Setting the font weight to bold
});
leftMap.add(label_2020)
rightMap.add(label_2023)
//---------------------------------------------------Display legend on the map----------------------------------------------------------------
// //Add Panel
// var results = ui.Panel({
//   style: {
//     position: 'bottom-left',
//     padding: '8px 15px',
//     width: '350px',
//   }
// });
// //Label Parameters
// var titleTextVis = {
//   'margin':'0px 0px 15px 0px',
//   'fontSize': '20px', 
//   'font-weight':'Bold', 
//   'color': '2a9d8f'
//   };
// var textVis1 = {
//   'margin':'0px 8px 2px 0px',
//   'fontSize': '15px',
//   'fontWeight':'bold'
//   };
// var textVis2 = {
//   'margin':'0px 8px 2px 0px',
//   'fontSize': '12px',
//   'fontWeight':''
//   };
// var subTextVis = {
//   'margin':'0px 0px 2px 0px',
//   'fontSize':'10px',
//   'color':'grey'
//   };
// //Labels
// var tittle = ui.Label('Tragic Night in Kelud',titleTextVis);
// var challenge = ui.Label('#30DayMapChallenge Day 10 - Raster',textVis1);
// var description1 = ui.Label('This map compares the condition of Mount Kelud after February 13, 2014 eruption with the current conditions in 2021',subTextVis);
// var description2 = ui.Label('Mount Kelud is located on the border between Kediri, Blitar and Malang. The eruption on February 13, 2014 at 22.50 local time was incredible. Volcanic ash covered the sky in several cities across the four provinces. Pitch black. Activity was paralyzed. The sound of the eruption of Mount Kelud was also heard as far away as Yogyakarta. The eruption of Mount Kelud in 2014 was the largest in the modern era. Apart from East Java and Central Java, the eruption of Mount Kelud caused ash rain that flew to West Java. The impact of the damage caused by the eruption of Mount Kelud was extraordinary. East Java Provincial Government data recorded 12,304 houses damaged. Most of the damage occurred on the galvalume roof of the house, which collapsed due to the inability to hold the sand. The tiles were also broken because of the throwing stones.',textVis2);
// var linkedin = ui.Label('wahyu-ramadhan.medium.com',textVis1);
// //Add Labels to the panel
// results.add(ui.Panel([
//         challenge,
//         tittle,
//         linkedin,
//         description2,
//         description1,
//         ]
//       ));
// //Add the panel to the map
// leftMap.add(results);
var splitPanel = ui.SplitPanel({
  firstPanel : leftMap,
  secondPanel : rightMap,
  orientation : 'horizontal',
  wipe: true
})
ui.root.clear()
ui.root.add(splitPanel)
var linkPanel = ui.Map.Linker([leftMap, rightMap])
leftMap.centerObject(jan0520, 15);
rightMap.centerObject(nov1523, 15);
// Create the title label.
var title = ui.Label('Click to inspect')
title.style().set('position', 'middle-left')
Map.add(title)
// -------------------------Create a panel to hold our widgets-------------------------------//
var panel = ui.Panel();
panel.style().set('width', '300px');
// Create an intro panel with labels.
var intro = ui.Panel([
ui.Label({
value: '#30DayMapChallenge2023 Day 16 & 21 - Oceania & Raster',
style: {fontWeight: 'bold',color: '585858'}}),
ui.Label({
value: 'Whakaari Post-Eruption Landscape Examination',
style: {fontSize: '25px', color: '585858', fontWeight: 'bold'}
}),
ui.Label({
value: 'linkedin.com/in/mwahyur',
style: {fontWeight: 'bold',color: '585858'}}),
//**************************Caption******************************//
ui.Label({
  value:"On December 9, 2019, Whakaari, a popular volcanic island in New Zealand, erupted, killing 22 and injuring 25, most of whom were tourists. The eruption, triggered by a buildup of pressure in the volcano's hydrothermal system, led to challenging rescue efforts due to seismic activity, poor visibility, and toxic gases. The event sparked debate over New Zealand's adventure tourism industry's safety and regulation, leading to charges against the island's owners, tour operators, and government and scientific agencies for failing to ensure safety.",
  style: {color: '585858'}}),
  ui.Label({
  value:"This is a false-color composite display, Near-Infrared (NIR), Red, and Green from PlanetScope satellite data taken on 5 January 2020, and 12 November 2023, to compare the post-eruption and current conditions of Whakaari Island. This false-color display is a composite option that accommodates the human eye's inability to see or differentiate objects in the visible wavelength. Visually, for almost 4 years, there's been no significant difference in the island’s landscape and vegetation, depicted in red. The only visible change is the disappearance of the island in the middle of the crater, although this might also be due to the increased water level in the crater. So, what’s your thought?",
  style: {color: '585858'}}),
ui.Label({
//Data Sources
value : 'Data source: PlanetScope Dove Classic (PS2) 5 January 2020; PlanetScope Super Dove (PSB.SD) 12 November 2023',
style: {fontSize: '10px',color: '585858'}}),
// ui.Label('Click a point on the map to inspect.')
]);
panel.add(intro);
ui.root.insert(0, panel);
//---------------Legend---------------//
// // Vis parameter:  
//   var vis_wff = {
//     min: 0,
//     max: 120,
//     opacity: 0.6,
//     palette: ['d9f0a3', 'addd8e', '78c679', '41ab5d', '238443', '005a32']
//   };
// // Create color bar
//   function makeColorBarParams(palette) {
//     return {
//       bbox: [0, 0, 1, 0.1],
//       dimensions: '100x10',
//       format: 'png',
//       position: 'bottom-left',
//       min: 0,
//       max: 1,
//       palette: palette,
//     };
//   }
//   // Thumbnail for the color bar
//   var colorBar = ui.Thumbnail({
//     image: ee.Image.pixelLonLat().select(0),
//     params: makeColorBarParams(vis_wff.palette),
//     style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '15px',position: 'bottom-left' },
//   });
// // Title  
//   var legendTitle = ui.Label({
//     value: 'Above Ground Carbon Density',
//     style: {fontWeight: 'bold',
//             color: '585858',
//             fontSize: '15px',
//             fontWeight: 'bold',
//             stretch: 'horizontal',
//             textAlign: 'center',
//             margin: '4px',
//     },
//   })
//   ;
// //Legend Description
// var legendDesc= ui.Label({
//     value : '(Mg/ha)',
//     style: {fontSize: '10px',color: '415a77'}})
// // Labels
//   var legendLabels = ui.Panel({
//     widgets: [
//       ui.Label(vis_wff.min, {margin: '4px 8px'}),
//       ui.Label(
//           ((vis_wff.max-vis_wff.min) / 2+vis_wff.min),
//           {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
//       ui.Label(vis_wff.max, {margin: '4px 8px'})
//     ],
//     layout: ui.Panel.Layout.flow('horizontal')
//   });
// // Add the legend to the map
//   var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels, legendDesc]);
//   legendPanel.style().set({
//     position: 'bottom-left'
//   });
// panel.add(legendPanel);
//--------------Basemap-------------//
var Light = [
{   // Dial down the map saturation.
stylers: [ { saturation: -100 } ]
},{ // Dial down the label darkness.
elementType: 'labels',
stylers: [ { lightness: 20 } ]
},{ // Simplify the road geometries.
featureType: 'road',
elementType: 'geometry',
stylers: [ { visibility: 'simplified' } ]
},{ // Turn off road labels.
featureType: 'road',
elementType: 'labels',
stylers: [ { visibility: 'off' } ]
},{ // Turn off all icons.
elementType: 'labels.icon',
stylers: [ { visibility: 'off' } ]
},{ // Turn off all POIs.
featureType: 'poi',
elementType: 'all',
stylers: [ { visibility: 'off' }]
}
];
leftMap.setOptions('Light', {'Light': Light});
rightMap.setOptions('Light', {'Light': Light});