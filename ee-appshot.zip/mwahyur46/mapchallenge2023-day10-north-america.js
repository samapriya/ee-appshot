var us = ui.import && ui.import("us", "table", {
      "id": "TIGER/2018/States"
    }) || ee.FeatureCollection("TIGER/2018/States");
Map.setCenter(-95.637, 31.761, 12);
// Adds two charts next to the map to interactively display a
// time-series of NDVI and reflectance for each click on the map.
// Filter collection to dates of interest.
var l8 = ee.ImageCollection('LANDSAT/LC08/C02/T1_TOA')
    .filterDate('2022-01-01', '2022-12-31');
// Clipping region or geometry (you need to define the 'us' variable with your area of interest)
var clippedL8 = l8.map(function(image) {
  var cloudScore = ee.Algorithms.Landsat.simpleCloudScore(image);
  var mask = cloudScore.select('cloud').lte(20); // Adjust the cloud score threshold as needed
  return image.updateMask(mask).clip(us);
});
// Create two collections to sample from, one for each plot.
var rgb = clippedL8.select(['B4', 'B3', 'B2']);
var ndvi = l8.map(function(image) {
  return image.select().addBands(image.normalizedDifference(['B5', 'B4']));
});
//Visualization Parameters
var rgbvis = {
  bands: ['B4','B3','B2'],
  min: 0.0,
  max: 0.3,
};
var falsecolorvis = {
  bands: ['B5','B4','B3'],
  min: 0.0,
  max: 0.3,
};
var vis = {min: 0, max: 1, palette: [
  'ef476f', 'ffd166', '06d6a0', '118ab2', '073b4c'
]};
//Layers
Map.addLayer(clippedL8, rgbvis, 'True Color');
Map.addLayer(clippedL8, falsecolorvis, 'False Color');
Map.addLayer(ndvi, vis, 'NDVI');
// -------------------------Create a panel to hold our widgets-------------------------------//
var panel = ui.Panel();
panel.style().set('width', '300px');
// Create an intro panel with labels.
var intro = ui.Panel([
ui.Label({
value: '#30DayMapChallenge 2023 Day 10 - North America',
style: {fontWeight: 'bold',color: '585858'}}),
ui.Label({
value: 'Spatio-Temporal Vegetation Dynamics in the United States',
style: {fontSize: '25px', color: '118ab2', fontWeight: 'bold'}
}),
ui.Label({
value: 'linkedin.com/in/mwahyur',
style: {fontWeight: 'bold',color: '585858'}}),
ui.Label("The Normalized Difference Vegetation Index (NDVI), is derived from two bands of remote sensing imagery data. It delineates vegetation density and conditions within a region, ranging from -1 to 1, with values closer to 1 indicating denser vegetation. With the inclusion of a temporal dimension, NDVI enables deeper information extraction, revealing vegetation dynamics, agricultural cycles, and even predictions of future harvest yields. This map depicts the vegetation levels in the United States throughout 2022. Clicking on a point on the map displays a vegetation level chart on the left side. In agriculture, high NDVI suggests potentially being recognized as harvest seasons. Varied climatic influences across regions might result in different annual harvest cycles."),
ui.Label({
//Data Sources
value : 'Landsat 8 Collection 2 Tier 1 TOA Reflectance, 2022.',
style: {fontSize: '10px',color: '585858'}}),
ui.Label('Click a point on the map to inspect.')
]);
panel.add(intro);
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
var lonLatPanel = ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal'));
panel.add(lonLatPanel);
// Create a panel for the legend.
var legendPanel = ui.Panel({
style: {
position: 'bottom-left',
padding: '8px'
}
});
// Add the legend panel to the main panel.
panel.add(legendPanel);
// Register a callback on the default map to be invoked when the map is clicked.
Map.onClick(function(coords) {
// Update the lon/lat panel with values from the click event.
lon.setValue('lon: ' + coords.lon.toFixed(2)),
lat.setValue('lat: ' + coords.lat.toFixed(2));
// Add a red dot for the point clicked on.
var point = ee.Geometry.Point(coords.lon, coords.lat);
var dot = ui.Map.Layer(point, {color: 'FF0000'});
Map.layers().set(1, dot);
// Create an NDVI chart.
var ndviChart = ui.Chart.image.series(ndvi, point, ee.Reducer.mean(), 500);
ndviChart.setOptions({
title: 'NDVI 2022',
vAxis: {title: 'NDVI'},
hAxis: {title: 'Date', format: 'MM-yy', gridlines: {count: 12}},
});
panel.widgets().set(2, ndviChart);
});
Map.style().set('cursor', 'crosshair');
// Add the panel to the ui.root.
ui.root.insert(0, panel);
//---------------Legend---------------//
// Vis parameter:  
  var vis_wff = {
    min: -1,
    max: 1,
    opacity: 0.6,
    palette: [
 'ef476f', 'ffd166', '06d6a0', '118ab2', '073b4c'
]
  };
// Create color bar
  function makeColorBarParams(palette) {
    return {
      bbox: [0, 0, 1, 0.1],
      dimensions: '100x10',
      format: 'png',
      position: 'bottom-left',
      min: 0,
      max: 1,
      palette: palette,
    };
  }
  // Thumbnail for the color bar
  var colorBar = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: makeColorBarParams(vis_wff.palette),
    style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '15px',position: 'bottom-left' },
  });
// Title  
  var legendTitle = ui.Label({
    value: 'NDVI',
    style: {fontWeight: 'bold',
            color: '585858',
            fontSize: '20px',
            fontWeight: 'bold',
            stretch: 'horizontal',
            textAlign: 'center',
            margin: '4px',
    },
  })
  ;
//Legend Description
var legendDesc= ui.Label({
    value : 'The higher value indicates dense vegetation',
    style: {fontSize: '10px',color: '415a77'}})
// Labels
  var legendLabels = ui.Panel({
    widgets: [
      ui.Label(vis_wff.min, {margin: '4px 8px'}),
      ui.Label(
          ((vis_wff.max-vis_wff.min) / 2+vis_wff.min),
          {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(vis_wff.max, {margin: '4px 8px'})
    ],
    layout: ui.Panel.Layout.flow('horizontal')
  });
// Add the legend to the map
  var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels, legendDesc]);
  legendPanel.style().set({
    position: 'bottom-left'
  });
panel.add(legendPanel);
//--------------Basemap-------------//
var Light = [
{   // Dial down the map saturation.
stylers: [ { saturation: -100 } ]
},{ // Dial down the label darkness.
elementType: 'labels',
stylers: [ { lightness: 20 } ]
},{ // Simplify the road geometries.
featureType: 'road',
elementType: 'geometry',
stylers: [ { visibility: 'simplified' } ]
},{ // Turn off road labels.
featureType: 'road',
elementType: 'labels',
stylers: [ { visibility: 'off' } ]
},{ // Turn off all icons.
elementType: 'labels.icon',
stylers: [ { visibility: 'off' } ]
},{ // Turn off all POIs.
featureType: 'poi',
elementType: 'all',
stylers: [ { visibility: 'off' }]
}
];
Map.setOptions('Light', {'Light': Light});