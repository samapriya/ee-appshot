var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -22.205586872118968,
                26.205590739581062
              ],
              [
                -22.381368122118968,
                9.113887098827448
              ],
              [
                -6.2973837471189675,
                -7.350624242174469
              ],
              [
                6.521244327531042,
                -21.119892085196213
              ],
              [
                18.38647870253104,
                -37.64427589321311
              ],
              [
                51.257572452531036,
                -36.52246574062215
              ],
              [
                53.806400577531036,
                -27.05377413879145
              ],
              [
                59.079838077531036,
                -22.66930240249921
              ],
              [
                59.695072452531036,
                -9.962931971470903
              ],
              [
                52.488041202531036,
                -1.4879640292815977
              ],
              [
                54.245853702531036,
                10.49372074384842
              ],
              [
                51.334653702987545,
                12.743179671661977
              ],
              [
                49.642759171737545,
                12.807465816589813
              ],
              [
                45.797544327987545,
                11.626360839928589
              ],
              [
                43.907895890487545,
                11.927502199306536
              ],
              [
                43.468442765487545,
                12.485872697931581
              ],
              [
                42.908140031112545,
                13.353228455749276
              ],
              [
                42.446714249862545,
                13.791088264136807
              ],
              [
                41.13148811345101,
                16.69209950798697
              ],
              [
                38.143776675038005,
                21.40298376499936
              ],
              [
                35.01908116980012,
                26.47745682006389
              ],
              [
                34.47260656250128,
                27.891798255968347
              ],
              [
                34.45475377929815,
                27.982791905355253
              ],
              [
                34.693327257274504,
                28.63749776700277
              ],
              [
                34.85535328546932,
                29.35632638133719
              ],
              [
                34.917151381172445,
                29.484318764604456
              ],
              [
                34.928137709297445,
                29.508716816799808
              ],
              [
                34.1472663070656,
                31.51536741002609
              ],
              [
                32.166569218367854,
                32.06367136620016
              ],
              [
                27.00315077997079,
                32.39393650639693
              ],
              [
                22.992493171645986,
                33.65938933694287
              ],
              [
                19.696594734145986,
                33.68681828080321
              ],
              [
                13.445374031020986,
                34.124489021539794
              ],
              [
                11.610422455482476,
                36.275458165968736
              ],
              [
                11.247873627357476,
                37.23487907684597
              ],
              [
                10.072336517982476,
                37.75786294611455
              ],
              [
                6.831369721107476,
                37.71442094009206
              ],
              [
                1.1294654242324764,
                37.610056163764185
              ],
              [
                -1.0458275445175236,
                36.52305929173351
              ],
              [
                -3.5287377007675236,
                35.768981150782466
              ],
              [
                -4.693288482017524,
                35.911478654834625
              ],
              [
                -5.209645903892524,
                36.00929710476637
              ],
              [
                -6.077565825767524,
                35.87142710779622
              ],
              [
                -9.534039494258732,
                34.93498250007863
              ],
              [
                -13.098111592252595,
                31.869703564157806
              ],
              [
                -12.346495888931083,
                29.099729095887103
              ],
              [
                -14.060363076431083,
                27.58168624644163
              ],
              [
                -21.386543153485963,
                26.43221822947794
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-22.205586872118968, 26.205590739581062],
          [-22.381368122118968, 9.113887098827448],
          [-6.2973837471189675, -7.350624242174469],
          [6.521244327531042, -21.119892085196213],
          [18.38647870253104, -37.64427589321311],
          [51.257572452531036, -36.52246574062215],
          [53.806400577531036, -27.05377413879145],
          [59.079838077531036, -22.66930240249921],
          [59.695072452531036, -9.962931971470903],
          [52.488041202531036, -1.4879640292815977],
          [54.245853702531036, 10.49372074384842],
          [51.334653702987545, 12.743179671661977],
          [49.642759171737545, 12.807465816589813],
          [45.797544327987545, 11.626360839928589],
          [43.907895890487545, 11.927502199306536],
          [43.468442765487545, 12.485872697931581],
          [42.908140031112545, 13.353228455749276],
          [42.446714249862545, 13.791088264136807],
          [41.13148811345101, 16.69209950798697],
          [38.143776675038005, 21.40298376499936],
          [35.01908116980012, 26.47745682006389],
          [34.47260656250128, 27.891798255968347],
          [34.45475377929815, 27.982791905355253],
          [34.693327257274504, 28.63749776700277],
          [34.85535328546932, 29.35632638133719],
          [34.917151381172445, 29.484318764604456],
          [34.928137709297445, 29.508716816799808],
          [34.1472663070656, 31.51536741002609],
          [32.166569218367854, 32.06367136620016],
          [27.00315077997079, 32.39393650639693],
          [22.992493171645986, 33.65938933694287],
          [19.696594734145986, 33.68681828080321],
          [13.445374031020986, 34.124489021539794],
          [11.610422455482476, 36.275458165968736],
          [11.247873627357476, 37.23487907684597],
          [10.072336517982476, 37.75786294611455],
          [6.831369721107476, 37.71442094009206],
          [1.1294654242324764, 37.610056163764185],
          [-1.0458275445175236, 36.52305929173351],
          [-3.5287377007675236, 35.768981150782466],
          [-4.693288482017524, 35.911478654834625],
          [-5.209645903892524, 36.00929710476637],
          [-6.077565825767524, 35.87142710779622],
          [-9.534039494258732, 34.93498250007863],
          [-13.098111592252595, 31.869703564157806],
          [-12.346495888931083, 29.099729095887103],
          [-14.060363076431083, 27.58168624644163],
          [-21.386543153485963, 26.43221822947794]]]);
// Displays global population density and population totals by country in
// chart or table form.
/*
 * Data sources
 */
// The GHSL global population density dataset for 2015.
var ghslPop = ee.Image('JRC/GHSL/P2016/POP_GPW_GLOBE_V1/2015');
// Country boundary data with associated precomputed population totals.
var countries = ee.FeatureCollection(
    'projects/google/examples/population-explorer/LSIB_SIMPLE-with-GHSL_POP');
// Constants used to visualize the data on the map.
var POPULATION_STYLE = {
  min: 0,
  max: 1,
  palette: ['073b4c', '118ab2', '06d6a0', 'ffd166', 'ef476f']
};
var COUNTRIES_STYLE = {color: '26458d', fillColor: '00000000'};
var POPULATION_VIS_MAX_VALUE = 2000;
var POPULATION_VIS_NONLINEARITY = 4;
var COUNTRIES_STYLE = {color: 'ffffff', fillColor: '00000000', width : 0.5};
var HIGHLIGHT_STYLE = {color: '8856a7', fillColor: '8856a7C0'};
// Apply a non-linear stretch to the population data for visualization.
function colorStretch(image) {
  return image.divide(1).pow(1 / 4); // Adjust these values accordingly
}
// Inverts the nonlinear stretch we apply to the population data for
// visualization, so that we can back out values to display in the legend.
// This uses ordinary JavaScript math functions, rather than Earth Engine
// functions, since we're going to call it from JS to compute label values.
function undoColorStretch(val) {
  return Math.pow(val, POPULATION_VIS_NONLINEARITY) * POPULATION_VIS_MAX_VALUE;
}
// Configure our map and controls...
Map.setControlVisibility(false);
Map.setControlVisibility({scaleControl: true, zoomControl: true});
Map.style().set({cursor: 'crosshair'});
Map.setCenter(21.92, 4.97, 4);
// Clip population layer with geometry
var clippedPopulation = colorStretch(ghslPop.unmask(0).updateMask(1)).clip(geometry);
// Add clipped layer to the map.
Map.addLayer(clippedPopulation, POPULATION_STYLE);
// Add countries layer to the map with the specified style.
Map.addLayer(countries.style(COUNTRIES_STYLE));
/*
 * The chart panel in the bottom-right
 */
// A list of points the user has clicked on, as [lon,lat] tuples.
var selectedPoints = [];
// Returns the list of countries the user has selected.
function getSelectedCountries() {
  return countries.filterBounds(ee.Geometry.MultiPoint(selectedPoints));
}
// Makes a bar chart of the given FeatureCollection of countries by name.
function makeResultsBarChart(countries) {
  var chart = ui.Chart.feature.byFeature(countries, 'Name');
  chart.setChartType('BarChart');
  chart.setOptions({
    title: 'Population Comparison',
    vAxis: {title: null},
    hAxis: {title: 'Approximate 2016 Population', minValue: 0}
  });
  chart.style().set({stretch: 'both'});
  return chart;
}
// Makes a table of the given FeatureCollection of countries by name.
function makeResultsTable(countries) {
  var table = ui.Chart.feature.byFeature(countries, 'Name');
  table.setChartType('Table');
  table.setOptions({allowHtml: true, pageSize: 5});
  table.style().set({stretch: 'both'});
  return table;
}
// Updates the map overlay using the currently-selected countries.
function updateOverlay() {
  var overlay = getSelectedCountries().style(HIGHLIGHT_STYLE);
  Map.layers().set(2, ui.Map.Layer(overlay));
}
// Updates the chart using the currently-selected charting function,
function updateChart() {
  var chartBuilder = chartTypeToggleButton.value;
  var chart = chartBuilder(getSelectedCountries());
  resultsPanel.clear().add(chart).add(buttonPanel);
}
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  selectedPoints = [];
  Map.layers().remove(Map.layers().get(2));
  var instructionsLabel = ui.Label('Select regions to compare population.');
  resultsPanel.widgets().reset([instructionsLabel]);
}
// Register a click handler for the map that adds the clicked point to the
// list and updates the map overlay and chart accordingly.
function handleMapClick(location) {
  selectedPoints.push([location.lon, location.lat]);
  updateOverlay();
  updateChart();
}
Map.onClick(handleMapClick);
// A button widget that toggles (or cycles) between states.
// To construct a ToggleButton, supply an array of objects describing
// the desired states, each with 'label' and 'value' properties.
function ToggleButton(states, onClick) {
  var index = 0;
  var button = ui.Button(states[index].label);
  button.value = states[index].value;
  button.onClick(function() {
    index = ++index % states.length;
    button.setLabel(states[index].label);
    button.value = states[index].value;
    onClick();
  });
  return button;
}
// Our chart type toggle button: the button text is the opposite of the
// current state, since you click the button to switch states.
var chartTypeToggleButton = ToggleButton(
    [
      {
        label: 'Display results as table',
        value: makeResultsBarChart,
      },
      {
        label: 'Display results as chart',
        value: makeResultsTable,
      }
    ],
    updateChart);
// A panel containing the two buttons .
var buttonPanel = ui.Panel(
    [ui.Button('Clear results', clearResults), chartTypeToggleButton],
    ui.Panel.Layout.Flow('horizontal'), {margin: '0 0 0 auto', width: '500px'});
var resultsPanel = ui.Panel({style: {position: 'bottom-right'}});
Map.add(resultsPanel);
clearResults();
//-------------Create User Interface portion-------------//
//-------------Create a panel to hold widgets-------------//
var panel = ui.Panel();
panel.style().set('width', '300px');
//-------------Create an intro panel with labels-------------//
var intro = ui.Panel([
   ui.Label({
    value: '#30DayMapChallenge 2023 Day 8 - Africa',
    style: {fontWeight: 'bold',color: '585858'}}),
  ui.Label({
    value: 'Population Portraits: Africa',
    style: {fontSize: '25px', color: 'ef476f', fontWeight: 'bold'}
  }), 
  ui.Label({
    value: 'linkedin.com/in/mwahyur',
    style: {fontWeight: 'bold',color: '585858'}}),
  ui.Label("This map visualizes the population by countries in the African continent. It's derived from the Global Human Settlement Layer (GHSL) data, displaying the population count per square kilometer. The red color could indicate areas where more than 1,000 people reside. You can compare various countries by clicking at one point on the map, then another point within different national administrative borders. This action generates a chart showing the statistical differences. Moreover, we observe that in the central to upper part of the African landmass, very few people seem to reside. In my opinion, this relates to the extreme geographic conditions. Yes, that's correct, the Sahara desert."),
  ui.Label({
    //Data Sources
    value : 'Data source : Global Human Settlement Layer (GHSL), 2016; Country boundaries: USDOS LSIB, 2017.',
    style: {fontSize: '10px',color: '585858'}})
]);
panel.add(intro);
//Add the panel to the ui.root
ui.root.insert(0, panel)
//---------------Legend---------------//
// Vis parameter:  
  var vis_wff = {
    min: 0,
    max: 1000,
    opacity: 0.6,
    palette: ['073b4c', '118ab2', '06d6a0', 'ffd166', 'ef476f']
  };
// Create color bar
  function makeColorBarParams(palette) {
    return {
      bbox: [0, 0, 1, 0.1],
      dimensions: '100x10',
      format: 'png',
      position: 'bottom-left',
      min: 0,
      max: 1,
      palette: palette,
    };
  }
  // Thumbnail for the color bar
  var colorBar = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: makeColorBarParams(vis_wff.palette),
    style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '15px',position: 'bottom-left' },
  });
// Title  
  var legendTitle = ui.Label({
    value: 'Population Density',
    style: {fontWeight: 'bold',
            color: '585858',
            fontSize: '20px',
            fontWeight: 'bold',
            stretch: 'horizontal',
            textAlign: 'left',
            margin: '4px',
    },
  })
  ;
//Legend Description
var legendDesc= ui.Label({
    value : '(thousands of people per square kilometer)',
    style: {fontSize: '10px',color: '415a77'}})
// Labels
  var legendLabels = ui.Panel({
    widgets: [
      ui.Label(vis_wff.min, {margin: '4px 8px'}),
      ui.Label(
          ((vis_wff.max-vis_wff.min) / 2+vis_wff.min),
          {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(vis_wff.max, {margin: '4px 8px'})
    ],
    layout: ui.Panel.Layout.flow('horizontal')
  });
// Add the legend to the map
  var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels, legendDesc]);
  legendPanel.style().set({
    position: 'bottom-left'
  });
panel.add(legendPanel);
//--------------Basemap-------------//
var Light = [
{   // Dial down the map saturation.
stylers: [ { saturation: -100 } ]
},{ // Dial down the label darkness.
elementType: 'labels',
stylers: [ { lightness: 20 } ]
},{ // Simplify the road geometries.
featureType: 'road',
elementType: 'geometry',
stylers: [ { visibility: 'simplified' } ]
},{ // Turn off road labels.
featureType: 'road',
elementType: 'labels',
stylers: [ { visibility: 'off' } ]
},{ // Turn off all icons.
elementType: 'labels.icon',
stylers: [ { visibility: 'off' } ]
},{ // Turn off all POIs.
featureType: 'poi',
elementType: 'all',
stylers: [ { visibility: 'off' }]
}
];
Map.setOptions('Light', {'Light': Light});