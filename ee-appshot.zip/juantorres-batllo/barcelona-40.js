var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            2.149285790003832,
            41.39916207176821
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([2.149285790003832, 41.39916207176821]);
//////// Create a button and provide a functionality to it
var button = ui.Button({
  label: "Bring me to Barcelona",
  onClick: Barcelona,
  style:{position: "top-left"}
})
//Map.add(button)
///// Create button function
function Barcelona(){
  Map.centerObject(geometry, 12)
}
///// Create a panel to work as a button layout
var panel = ui.Panel({
  style: {backgroundColor: "yellow", border: "4px solid black", width: "200px"}
})
Map.add(panel.add(button))