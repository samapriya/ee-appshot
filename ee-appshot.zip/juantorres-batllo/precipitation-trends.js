var imageCollection = ui.import && ui.import("imageCollection", "imageCollection", {
      "id": "UCSB-CHG/CHIRPS/DAILY"
    }) || ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY"),
    point = ui.import && ui.import("point", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            9.401940805000821,
            40.36582831667849
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#00ff00",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #00ff00 */ee.Geometry.Point([9.401940805000821, 40.36582831667849]);
// Task 11: Add the legend into the map
// Initialize the map.
// ===================
///// ui.Map
var map = ui.Map()
map.centerObject(point,6)
///////////////////////////////////////////////// DATASET /////////////////////////////////////////////////////
var chirps = imageCollection
/////// Convert collection into an annual collection
/////// For each year of the century, produce an image of average temperature and rainfall
function fromDailyToAnnual( Year ){
  var yearStart = ee.Date.fromYMD( Year, 1, 1);
  var yearEnd = ee.Date.fromYMD( Year, 12, 31);
  var ic = chirps.filterDate( yearStart, yearEnd ); ///// filter by date
  var im = ic.sum().set( 'Year', Year );   ///// Apply mean to get mean annual images
  return im.set('system:time_start',yearStart.millis());
}
//////// create a list of imagery by aggregating data annually
var ET_Annual = ee.List.sequence(1981,2019).map( fromDailyToAnnual );  ///////// Create list starting at 2019
//////// Convert list of imagery to image collection and sort by year
var ET_Annual_sorted = ee.ImageCollection.fromImages( ET_Annual ).sort( 'Year' );
////////////// Prepare independent and dependent variables for the regression
function PreparePredictors( thisImage ){
  var year = ee.Number( thisImage.get('Year') );
  var bandYear = ee.Image(year).int16();//from float to integer as an independent variable
  var bandPrecip = thisImage.select('precipitation');// dependent
  var stackedImage = bandYear.addBands(bandPrecip)
  return stackedImage.rename("year","precipitation");
}
var ET_regression = ET_Annual_sorted.map(PreparePredictors)
//////////// The regression produces two bands as an output: offset (intercept) and scale (slope)
var linearFit_regr = ET_regression.reduce(ee.Reducer.linearFit()).select("scale")
var visible = {min:-2, max:3, palette:["red","orange","white","green","blue"]}
// Show point on the map
// ======================
function showPointOnMap(point){
var loc = ui.Map.Layer(point, {color: 'FF0000'});
map.layers().set(1, loc);
}
// Display precipitation chart 
// ======================
function linearFitChart(point){
var chart = ui.Chart.image.series(ET_Annual_sorted, point, ee.Reducer.mean(), 5000);
chart.setOptions({
  title: 'Temporal evolution of annual precipitation',
  vAxis: {title: 'Precipitation'},
  hAxis: {title: 'date', format: 'yyyy', gridlines: {count: 7}},
  trendlines:{0:{color:"red"},
  visibleInLegend: false,pointSize: 2,opacity:0.25}});
return chart
}
// Display precipitation chart everytime we click on the map
map.onClick(function(coordinates){
  var point = ee.Geometry.Point([coordinates.lon, coordinates.lat]);
  showPointOnMap(point);
  linearFitChart(point); 
});
function maskTrend(value) {
  map.layers().reset();
  var threshold = Number(value);
  var masked = linearFit_regr.mask(linearFit_regr.gt(threshold));
  map.addLayer(masked, visible, 'Trends');
}
// Initialize Widgets and App
// ===================
function App(){
var panel = ui.Panel({
  style:{backgroundColor:"grey", border:"2px solid black"}
});
var title = ui.Label({
    value: 'Precipitation trend explorer',
    style: {fontSize: '31px', textAlign: 'right', color: 'blue', fontFamily: 'monospace',  fontWeight: 'bold', backgroundColor: "grey"}
  })
var instructions = ui.Label({value: 'Click on the map to show the temporal evolution of precipitation and set up a trend treshold to display a precipitation trend map', 
  style: {fontSize: '14px', textAlign: 'left', fontFamily: 'monospace', fontWeight: 'bold', backgroundColor: "grey"}})
var textBoxPanel = ui.Textbox({placeholder: "Trend higher than",
  onChange:maskTrend})
var chartPanel = ui.Panel();
panel.add(title);
panel.add(instructions);
panel.add(textBoxPanel)
panel.add(chartPanel)
  ////////////// Legend ////////////////
// Create a panel with three numbers for the legend.
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(visible.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(visible.min),
    ui.Label((visible.min+visible.max)/2,{margin: '4px 8px',textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(visible.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Precipitation annual change (mm yr-1)',
  style: {fontWeight: 'bold'}
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
panel.add(legendPanel)
var splitPanel = ui.SplitPanel({
  firstPanel: panel,
  secondPanel: map,
});
ui.root.clear();
ui.root.add(splitPanel);
showPointOnMap(point);
  chartPanel.clear();
  chartPanel.add(linearFitChart(point));
  // Bind the click handler to the new map.
  map.onClick(function(coordinates){
    var point = ee.Geometry.Point([coordinates.lon, coordinates.lat]);
    showPointOnMap(point);
    chartPanel.clear();
    chartPanel.add(linearFitChart(point));
  });
}
App()