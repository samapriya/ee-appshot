var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            2.161901411650451,
            41.38933712059912
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([2.161901411650451, 41.38933712059912]);
var button = ui.Button({
  label: "Bring me to BCN",
  onClick: Barcelona
})
var panel = ui.Panel({
  widgets: [button],
  style:{width: "300px", backgroundColor: "yellow", border: "2px solid black"}
})
ui.root.add(panel)
function Barcelona (){
  Map.centerObject(geometry,7)
}