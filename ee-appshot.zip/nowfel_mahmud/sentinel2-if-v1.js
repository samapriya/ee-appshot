var tstart = ee.Date('2018-01-01');
var tend = ee.Date('2020-12-31');
// Zoom to a location.
Map.setCenter(-89, 36, 10);
/////////////////////////////
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
// function to detect WB and vegetation
var index = function(image) {
  var blue  = image.select('B2');//.divide(10000); // Blue
  var green = image.select('B3');//.divide(10000); // Green
  var red   = image.select('B4');//.divide(10000); // Red
  var swir1 = image.select('B11');//.divide(10000); // SWIR1
  var nir   = image.select('B8');//.divide(10000) // NIR
  var SCL   = image.select('SCL');// SCL
  var vegSCL = SCL.multiply(10000).eq(4)// Band 4 in SCL is vegetation
            .rename('Vegetation');
  var bsSCL =  SCL.multiply(10000).eq(5)// Band 5 in SCL is Bare Soil
            .rename('Bare_Soil'); 
  var waterSCL = SCL.multiply(10000).round().eq(6)
                .rename('Water');// Band 6 in SCL is Water            
  var iceSCL = SCL.multiply(10000).eq(11)// Band 11 in SCL is Snow/Ice
            .rename('Snow_Ice'); 
  var fpSCL = vegSCL.multiply(10000).add(bsSCL).add(waterSCL).add(iceSCL) //SCL footprint
              .gt(0)
              .rename('SCLfootprint');
  //Waterbody
  var ndwi = (green.subtract(nir)).divide((green.add(nir))).rename('NDWI');
  var mndwi = (green.subtract(swir1)).divide((green.add(swir1))).rename('MNDWI');
  var water = ndwi.gt(0.1).rename('Water10m');
  //Vegetation
  var ndvi = (nir.subtract(red)).divide((nir.add(red).add(0.00))).rename('NDVI');
  var savi = (nir.subtract(red)).divide((nir.add(red).add(0.16))).multiply(1.16).rename('SAVI');
  var veg0 = (nir.subtract(red)).divide((nir.add(red).add(0.00))).multiply(1.00).gt(0.5).rename('Vegetation0');
  var veg1 = (nir.subtract(red)).divide((nir.add(red).add(0.16))).multiply(1.16).gt(0.5).rename('Vegetation1');
  var veg2 = (nir.subtract(red)).divide((nir.add(red).add(0.50))).multiply(1.50).gt(0.5).rename('Vegetation2');
  var veg3 = (nir.subtract(red)).divide((nir.add(red).add(1.00))).multiply(2.00).gt(0.5).rename('Vegetation3');
  //Soil
  var ndsi1 = (swir1.subtract(nir)).divide((swir1.add(nir))).rename('NDSI1');
  var soil = ndsi1.gt(0.5).rename('Soil');
  //Snow
  var ndsi2 = (green.subtract(swir1)).divide((green.add(swir1))).rename('NDSI2');
  var snow = ndsi2.gt(0.5).rename('Ice');
  return image.addBands([vegSCL,bsSCL,waterSCL,iceSCL,fpSCL, ndwi,mndwi,water,savi,ndvi,
                        veg0,veg1,veg2,veg3,ndsi1, soil, ndsi2, snow]);                      
};
var sentinel2 = ee.ImageCollection('COPERNICUS/S2_SR')
                  //.filterBounds(frame)
                  .filterDate (tstart,tend)
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',90))
                  .select('B2','B3','B4','B8','B11','B12','QA60','SCL')
                  .map(maskS2clouds)
                  .map(index);
                  //.mean();
var vis = {min: 0, max: 1, palette: '0000FF, #000020'};
var composite = (sentinel2.select('Water').sum())
                .divide((sentinel2.select('SCLfootprint').sum()));
//                .multiply(100);
//composite  = composite.floor().int();
Map.addLayer(composite.updateMask(composite), vis,'Composite',1);
/*
 * Legend setup
 */
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(vis.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '12px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(vis.min, {margin: '4px 8px'}),
    ui.Label(
        (vis.max / 2),
        {margin: '4px 200px', textAlign: 'left', stretch: 'horizontal'}),
    ui.Label(vis.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Inundation frequency (2018 - 2020).........TRIAL VERSION',
  style: {fontWeight: 'bold'}
});
// Add the legendPanel to the map.
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
Map.add(legendPanel);
/////////////////////////Slider//////////
var label = ui.Label('Min');
var slider = ui.Slider({
  min: 0, max: 1, step: 0.05, value: 0,
  style: {stretch: 'horizontal', width:'180px', height: '20px'},
  onChange: updateLayer
});
var label1 = ui.Label('Max');
var slider1 = ui.Slider({
  min: 0, max: 1, step: 0.05, value: 1,
  style: {stretch: 'horizontal', width:'180px', height: '20px'},
  onChange: updateLayer
});
var panel = ui.Panel({
      widgets: [label, slider, label1, slider1],
      layout: ui.Panel.Layout.flow('horizontal'),
      style: {position: 'bottom-center',width: '500px'
      }
    });
Map.add(panel);
function updateLayer(value){
  // Get min stretch value from user.
  var min1 = slider.getValue();
  // Get max stretch value from user.
  var max1 = slider1.getValue();
  // Remove all the current animation layers
  Map.layers().reset();
  var mask = composite.gte(min1)
            .multiply(composite.lte(max1))
            .multiply(composite.gt(0));
  var animate = composite.updateMask(mask);
  Map.addLayer(composite.updateMask(mask),vis,'Composite',1);
}