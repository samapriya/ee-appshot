var AB = ee.FeatureCollection("users/Alberta_Sentinel_analysis_v20/grassland_input/SA"),
    Pilot = ee.FeatureCollection("users/Alberta_Sentinel_analysis_v20/grassland_input/Index11"),
    aci_binary = ee.Image("users/Alberta_Sentinel_analysis_v20/HTV_Pilot/Cultivation"),
    amwi = ee.Image("users/Alberta_Sentinel_analysis_v20/HTV_Pilot/amwi_reclass"),
    hr = ee.FeatureCollection("users/Alberta_Sentinel_analysis_v20/HTV_Pilot/HR_Boundary"),
    RF = ee.Image("users/Alberta_Sentinel_analysis_v20/HTV_Pilot/Dataset42_5x5_majority_filter_HFI_v3");
var dataset = ee.ImageCollection('AAFC/ACI');
var crop2017 = dataset
    .filter(ee.Filter.date('2017-01-01', '2017-12-31'))
    .first();
//Map.setCenter(-103.8881, 53.0371, 5);
//Map.addLayer(crop2017);
//var Apal = ['#08306b', '#006d2c', '#8c510a', '#b8e186', '#fdae61'];
//var Apal =['#08306b', '#b8e186', '#fdae61'];
var Apal =['#0057e7', '#ffa700', '#a1a0a0'];
var Apal2 =['AADAFF'];
var aci_ab = crop2017.clip(AB);
var pilot = crop2017.clip(Pilot); 
//Add layers to Map
Map.setCenter(-111.691615, 50.790210, 10);
//Map.addLayer(aci_ab,{},'ACI2017 Parkland Grassland NR');
//Map.addLayer(pilot,{},'ACI2017_Pilot');
Map.addLayer(amwi, {min:1, max:3, palette:Apal}, 'AMWI (Ref.)');
Map.addLayer(RF, {min:1, max:3, palette:Apal}, 'RF Prediction');
//Map.addLayer(aci_binary,{min:0, max:1, palette:Apal2},'Cultivation'); 
//Map.addLayer(hr,{},'High resolution area - AMWI');
//--------------------------------------------------------------------------------------------------
// Add a title and some explanatory text to a side panel.
var header = ui.Label('Wetland Mapping: Southern Alberta, pilot site', {fontSize: '36px', color: 'red'});
var text = ui.Label(
    'The results presented are based on a pilot site situated in the parkland and grassland natural region. The Random Forest supervised classification was performed with Sentinel 1 radar, Sentinel-2 optical, and LiDAR derived input variables.',
    {fontSize: '12px'});
var toolPanel = ui.Panel([header, text], 'flow', {width: '300px'});
ui.root.widgets().add(toolPanel);
var link = ui.Label(
    'VVdiff, NDWIdiff, Sentinel-2 PCA layers (1,2,3,4), SWI - saga wetness index LiDAR derived.',{fontSize: '12px'});
var linkPanel = ui.Panel(
    [ui.Label('Input variables used for RF model', {fontWeight: 'bold'}), link]);
toolPanel.add(linkPanel);
var link = ui.Label(
    'Overall Accuracy (%) = 81.1, Overall Kappa=0.73, F-Scores(%): Open Water=0.92. Wetland=0.7. Upland=0.81.',{fontSize: '12px'});
var linkPanel = ui.Panel(
    [ui.Label('Accuracy assessment results (summary)', {fontWeight: 'bold'}), link]);
toolPanel.add(linkPanel);
//----------------------------------------------------------------------------------------------------
//Add legend of Prediction to Map Layout
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
//var palette =['FF0000', '22ff00', '1500ff'];
//var palette =['0057e7', 'ffa700', 'a1a0a0','AADAFF']; 
var palette =['0057e7', 'ffa700', 'a1a0a0']; 
// name of the legend
//var names = ['Open Water','Wetland','Upland','Cultivation - Annual Crop Inventory 2017'];
var names = ['Open Water','Wetland','Upland'];
// Add color and and names
for (var i = 0; i < 3; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)  
Map.add(legend);