var point = ui.import && ui.import("point", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.74734446320541,
            -1.3931374162103138
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([36.74734446320541, -1.3931374162103138]),
    L7 = ui.import && ui.import("L7", "imageCollection", {
      "id": "LANDSAT/LE07/C01/T1_TOA"
    }) || ee.ImageCollection("LANDSAT/LE07/C01/T1_TOA"),
    KajiadoNorth = ui.import && ui.import("KajiadoNorth", "table", {
      "id": "users/vctrchirchir/Kajiado_North"
    }) || ee.FeatureCollection("users/vctrchirchir/Kajiado_North"),
    ForestedAreas = ui.import && ui.import("ForestedAreas", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.69835569566401,
            -1.3543565886822788
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69947149461421,
            -1.3534985214257522
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70247556871089,
            -1.3537988450000835
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70513632005366,
            -1.3556865923294126
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71208860582026,
            -1.3611782125471628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70985700791987,
            -1.3600627282010171
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.715049764572704,
            -1.3636665988437884
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71062948411616,
            -1.3628943413026868
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70586588090571,
            -1.36418143706686
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70796873277339,
            -1.3642672434266725
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69101717179927,
            -1.366197885712819
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69384958451899,
            -1.3690723946857284
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69749738877925,
            -1.367055948453225
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.697325727402294,
            -1.360792083408806
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.707024595200146,
            -1.3671417547103948
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69938566392573,
            -1.3555149789966274
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69814111894282,
            -1.3586469204038183
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69964315599116,
            -1.3616072448506105
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71311857408198,
            -1.3628085348939445
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64538336888618,
            -1.4035247891702756
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64830161229438,
            -1.4025809346621745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65130568639106,
            -1.40198029977698
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.643495093739695,
            -1.3972610203221654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64632750645942,
            -1.395802332025513
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63920355931587,
            -1.3982048769726625
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64066268101997,
            -1.4052408872997169
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.649245749867625,
            -1.4061847407335664
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.684766082199395,
            -1.3407064397023196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68596771183807,
            -1.344310339083616
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.690774230392755,
            -1.3542639382674264
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC": 1
      },
      "color": "#065402",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #065402 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.69835569566401, -1.3543565886822788]),
            {
              "LC": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69947149461421, -1.3534985214257522]),
            {
              "LC": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70247556871089, -1.3537988450000835]),
            {
              "LC": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70513632005366, -1.3556865923294126]),
            {
              "LC": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71208860582026, -1.3611782125471628]),
            {
              "LC": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70985700791987, -1.3600627282010171]),
            {
              "LC": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.715049764572704, -1.3636665988437884]),
            {
              "LC": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71062948411616, -1.3628943413026868]),
            {
              "LC": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70586588090571, -1.36418143706686]),
            {
              "LC": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70796873277339, -1.3642672434266725]),
            {
              "LC": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69101717179927, -1.366197885712819]),
            {
              "LC": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69384958451899, -1.3690723946857284]),
            {
              "LC": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69749738877925, -1.367055948453225]),
            {
              "LC": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.697325727402294, -1.360792083408806]),
            {
              "LC": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.707024595200146, -1.3671417547103948]),
            {
              "LC": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69938566392573, -1.3555149789966274]),
            {
              "LC": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69814111894282, -1.3586469204038183]),
            {
              "LC": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69964315599116, -1.3616072448506105]),
            {
              "LC": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71311857408198, -1.3628085348939445]),
            {
              "LC": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64538336888618, -1.4035247891702756]),
            {
              "LC": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64830161229438, -1.4025809346621745]),
            {
              "LC": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65130568639106, -1.40198029977698]),
            {
              "LC": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.643495093739695, -1.3972610203221654]),
            {
              "LC": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64632750645942, -1.395802332025513]),
            {
              "LC": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63920355931587, -1.3982048769726625]),
            {
              "LC": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64066268101997, -1.4052408872997169]),
            {
              "LC": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.649245749867625, -1.4061847407335664]),
            {
              "LC": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.684766082199395, -1.3407064397023196]),
            {
              "LC": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68596771183807, -1.344310339083616]),
            {
              "LC": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.690774230392755, -1.3542639382674264]),
            {
              "LC": 1,
              "system:index": "29"
            })]),
    Vegetation = ui.import && ui.import("Vegetation", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.66313740000239,
            -1.3629470802070278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66742893442622,
            -1.3582277232944986
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66871639475337,
            -1.358785465955952
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.669274294228465,
            -1.3678380403384962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.677673451396636,
            -1.3751463178159553
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.714666478130034,
            -1.382268202575356
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71676932999771,
            -1.3827830367916285
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71749889084976,
            -1.3860007481117016
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70614097498562,
            -1.4047323355329957
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70476768397,
            -1.4064913351902553
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69515464686062,
            -1.4041746036577576
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69472549341824,
            -1.4020294798209316
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65878567043753,
            -1.3878716133403215
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66505131069632,
            -1.3846539045611046
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69526371304007,
            -1.383195208475032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.708394696428975,
            -1.4004618707548877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70783679695388,
            -1.3990889895491938
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7594219414364,
            -1.3912513137933342
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.763820764220824,
            -1.3917017920286205
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76392805258142,
            -1.3907579327702848
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7644644943844,
            -1.3921737215161392
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73879923064801,
            -1.4027633413509941
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73970045287702,
            -1.4033639760351906
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74485029418561,
            -1.4017336815336814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74414219100568,
            -1.3994383965617545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.758003847194644,
            -1.4044579888135906
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79658474166486,
            -1.388541125174645
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78109230239484,
            -1.386825014855562
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.780448572231265,
            -1.3872540425520528
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.764226572109195,
            -1.3987948583158007
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75512851913068,
            -1.4013261077308865
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75937713821027,
            -1.4014977177617598
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.741009370876284,
            -1.3909865802262324
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72920765121076,
            -1.386653403755183
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75383680428755,
            -1.3928563497736366
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.753750973599075,
            -1.3934140843391662
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73323743905318,
            -1.4032816739976384
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72212236489546,
            -1.4161094782730064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72268026437056,
            -1.416281087214934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73164957131636,
            -1.4161952827455542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.732765370266556,
            -1.4091164030981997
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75984495248091,
            -1.4107037901063406
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC": 2
      },
      "color": "#a2ff60",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #a2ff60 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.66313740000239, -1.3629470802070278]),
            {
              "LC": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66742893442622, -1.3582277232944986]),
            {
              "LC": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66871639475337, -1.358785465955952]),
            {
              "LC": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.669274294228465, -1.3678380403384962]),
            {
              "LC": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.677673451396636, -1.3751463178159553]),
            {
              "LC": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.714666478130034, -1.382268202575356]),
            {
              "LC": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71676932999771, -1.3827830367916285]),
            {
              "LC": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71749889084976, -1.3860007481117016]),
            {
              "LC": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70614097498562, -1.4047323355329957]),
            {
              "LC": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70476768397, -1.4064913351902553]),
            {
              "LC": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69515464686062, -1.4041746036577576]),
            {
              "LC": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69472549341824, -1.4020294798209316]),
            {
              "LC": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65878567043753, -1.3878716133403215]),
            {
              "LC": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66505131069632, -1.3846539045611046]),
            {
              "LC": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69526371304007, -1.383195208475032]),
            {
              "LC": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.708394696428975, -1.4004618707548877]),
            {
              "LC": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70783679695388, -1.3990889895491938]),
            {
              "LC": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7594219414364, -1.3912513137933342]),
            {
              "LC": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.763820764220824, -1.3917017920286205]),
            {
              "LC": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76392805258142, -1.3907579327702848]),
            {
              "LC": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7644644943844, -1.3921737215161392]),
            {
              "LC": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73879923064801, -1.4027633413509941]),
            {
              "LC": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73970045287702, -1.4033639760351906]),
            {
              "LC": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74485029418561, -1.4017336815336814]),
            {
              "LC": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74414219100568, -1.3994383965617545]),
            {
              "LC": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.758003847194644, -1.4044579888135906]),
            {
              "LC": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79658474166486, -1.388541125174645]),
            {
              "LC": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78109230239484, -1.386825014855562]),
            {
              "LC": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.780448572231265, -1.3872540425520528]),
            {
              "LC": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.764226572109195, -1.3987948583158007]),
            {
              "LC": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75512851913068, -1.4013261077308865]),
            {
              "LC": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75937713821027, -1.4014977177617598]),
            {
              "LC": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.741009370876284, -1.3909865802262324]),
            {
              "LC": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72920765121076, -1.386653403755183]),
            {
              "LC": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75383680428755, -1.3928563497736366]),
            {
              "LC": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.753750973599075, -1.3934140843391662]),
            {
              "LC": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73323743905318, -1.4032816739976384]),
            {
              "LC": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72212236489546, -1.4161094782730064]),
            {
              "LC": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72268026437056, -1.416281087214934]),
            {
              "LC": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73164957131636, -1.4161952827455542]),
            {
              "LC": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.732765370266556, -1.4091164030981997]),
            {
              "LC": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75984495248091, -1.4107037901063406]),
            {
              "LC": 2,
              "system:index": "41"
            })]),
    NonBuilt_Up = ui.import && ui.import("NonBuilt_Up", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.784505960143676,
            -1.403135329783859
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77738201300012,
            -1.4007327898875448
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78381931463586,
            -1.3954128713567095
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81180011907922,
            -1.3897497190546524
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.817722436584106,
            -1.3865749156080491
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77858364263879,
            -1.403735964372537
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.775322076476684,
            -1.4021914751186513
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69592868963586,
            -1.4094848876200499
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69919025579797,
            -1.3990166884531507
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69807445684778,
            -1.3920664648227277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.715583917296996,
            -1.3994457139294871
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71790134588586,
            -1.3979870269898629
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.688589240277715,
            -1.3992741037483771
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69073500748963,
            -1.4015050351230804
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73742187893221,
            -1.385287831916104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.734074482081624,
            -1.3834001079033322
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72986877834627,
            -1.3803969075156228
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71047104275057,
            -1.3872613599576469
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71373260891268,
            -1.3851162207043288
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71004188930819,
            -1.3817697995926053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6595851034068,
            -1.367579079162923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66044341029156,
            -1.3652194064032925
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.683617696180235,
            -1.3640610207462047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68576346339215,
            -1.359513279074997
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66147337855328,
            -1.3281078873048113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.663619145765196,
            -1.3305963073458755
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.666365727796446,
            -1.3305104998000088
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6919043125873,
            -1.3589340129370213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67963052413515,
            -1.3376109920980768
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73757739560607,
            -1.3915531439736455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78718753354552,
            -1.3963582400937276
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.793539004492786,
            -1.390523479244615
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71781694932504,
            -1.4243232957476761
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.728717446761564,
            -1.4221781905204411
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.722194314437345,
            -1.4107661972650007
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71292460008188,
            -1.4070765934639262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67189753099008,
            -1.4140267724984563
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67112505479379,
            -1.422263994767831
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.669236779647306,
            -1.425352945547654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.707946420150236,
            -1.422092386269858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682283044295744,
            -1.4080204461552053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.711465478377775,
            -1.4303295797510271
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.699706674056486,
            -1.4355636144225934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.702968240218595,
            -1.4368506702948758
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66322863145395,
            -1.4502360082569523
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65018236680551,
            -1.4558990120665702
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68108141465707,
            -1.4207195178268268
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.718482938621314,
            -1.4000167306233848
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73453327736643,
            -1.3885188235904444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71787800033185,
            -1.3930877739711838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7231995030174,
            -1.4029553650013147
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78431095321271,
            -1.3978070618119631
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.786714212490054,
            -1.3995231641313528
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682344095302554,
            -1.3841640038790732
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.687064783168765,
            -1.3821046675422357
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71083988387677,
            -1.3901703913031214
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73410000045392,
            -1.384593032057558
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71964792085427,
            -1.4005437859224397
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69853357148904,
            -1.4056062782344716
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63819459749001,
            -1.3888742705250967
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63802293611306,
            -1.3840691591730203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64119867158669,
            -1.387072354911204
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6964736349656,
            -1.399342514953401
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.711837328202904,
            -1.3923064869395618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73269418550271,
            -1.3890458814642983
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74419549775857,
            -1.3872439659812026
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7536651429106,
            -1.411518934365389
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75521009530318,
            -1.411776348282583
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76018827523482,
            -1.4035390888241401
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.739245587246536,
            -1.411776348282583
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73958891000044,
            -1.4133208311869618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74739950265181,
            -1.40611323552982
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74619787301314,
            -1.409974450264053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7756377991606,
            -1.4072286982209936
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77254789437544,
            -1.4035390888241401
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73495405282271,
            -1.4134924403351676
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72319524850142,
            -1.411776348282583
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71469801034224,
            -1.404740357639727
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71572797860396,
            -1.400535914086561
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75941579903853,
            -1.4040539183921208
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76336401070845,
            -1.402938454184904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.737786465542435,
            -1.3965030733864305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73409574593794,
            -1.3912689506724671
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75186269845259,
            -1.4042255282229246
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC": 3
      },
      "color": "#fffaab",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #fffaab */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.784505960143676, -1.403135329783859]),
            {
              "LC": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77738201300012, -1.4007327898875448]),
            {
              "LC": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78381931463586, -1.3954128713567095]),
            {
              "LC": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81180011907922, -1.3897497190546524]),
            {
              "LC": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.817722436584106, -1.3865749156080491]),
            {
              "LC": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77858364263879, -1.403735964372537]),
            {
              "LC": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.775322076476684, -1.4021914751186513]),
            {
              "LC": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69592868963586, -1.4094848876200499]),
            {
              "LC": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69919025579797, -1.3990166884531507]),
            {
              "LC": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69807445684778, -1.3920664648227277]),
            {
              "LC": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.715583917296996, -1.3994457139294871]),
            {
              "LC": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71790134588586, -1.3979870269898629]),
            {
              "LC": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.688589240277715, -1.3992741037483771]),
            {
              "LC": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69073500748963, -1.4015050351230804]),
            {
              "LC": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73742187893221, -1.385287831916104]),
            {
              "LC": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.734074482081624, -1.3834001079033322]),
            {
              "LC": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72986877834627, -1.3803969075156228]),
            {
              "LC": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71047104275057, -1.3872613599576469]),
            {
              "LC": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71373260891268, -1.3851162207043288]),
            {
              "LC": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71004188930819, -1.3817697995926053]),
            {
              "LC": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6595851034068, -1.367579079162923]),
            {
              "LC": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66044341029156, -1.3652194064032925]),
            {
              "LC": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.683617696180235, -1.3640610207462047]),
            {
              "LC": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68576346339215, -1.359513279074997]),
            {
              "LC": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66147337855328, -1.3281078873048113]),
            {
              "LC": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.663619145765196, -1.3305963073458755]),
            {
              "LC": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.666365727796446, -1.3305104998000088]),
            {
              "LC": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6919043125873, -1.3589340129370213]),
            {
              "LC": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67963052413515, -1.3376109920980768]),
            {
              "LC": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73757739560607, -1.3915531439736455]),
            {
              "LC": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78718753354552, -1.3963582400937276]),
            {
              "LC": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.793539004492786, -1.390523479244615]),
            {
              "LC": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71781694932504, -1.4243232957476761]),
            {
              "LC": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.728717446761564, -1.4221781905204411]),
            {
              "LC": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.722194314437345, -1.4107661972650007]),
            {
              "LC": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71292460008188, -1.4070765934639262]),
            {
              "LC": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67189753099008, -1.4140267724984563]),
            {
              "LC": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67112505479379, -1.422263994767831]),
            {
              "LC": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.669236779647306, -1.425352945547654]),
            {
              "LC": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.707946420150236, -1.422092386269858]),
            {
              "LC": 3,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682283044295744, -1.4080204461552053]),
            {
              "LC": 3,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.711465478377775, -1.4303295797510271]),
            {
              "LC": 3,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.699706674056486, -1.4355636144225934]),
            {
              "LC": 3,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.702968240218595, -1.4368506702948758]),
            {
              "LC": 3,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66322863145395, -1.4502360082569523]),
            {
              "LC": 3,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65018236680551, -1.4558990120665702]),
            {
              "LC": 3,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68108141465707, -1.4207195178268268]),
            {
              "LC": 3,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.718482938621314, -1.4000167306233848]),
            {
              "LC": 3,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73453327736643, -1.3885188235904444]),
            {
              "LC": 3,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71787800033185, -1.3930877739711838]),
            {
              "LC": 3,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7231995030174, -1.4029553650013147]),
            {
              "LC": 3,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78431095321271, -1.3978070618119631]),
            {
              "LC": 3,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.786714212490054, -1.3995231641313528]),
            {
              "LC": 3,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682344095302554, -1.3841640038790732]),
            {
              "LC": 3,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.687064783168765, -1.3821046675422357]),
            {
              "LC": 3,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71083988387677, -1.3901703913031214]),
            {
              "LC": 3,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73410000045392, -1.384593032057558]),
            {
              "LC": 3,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71964792085427, -1.4005437859224397]),
            {
              "LC": 3,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69853357148904, -1.4056062782344716]),
            {
              "LC": 3,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63819459749001, -1.3888742705250967]),
            {
              "LC": 3,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63802293611306, -1.3840691591730203]),
            {
              "LC": 3,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64119867158669, -1.387072354911204]),
            {
              "LC": 3,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6964736349656, -1.399342514953401]),
            {
              "LC": 3,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.711837328202904, -1.3923064869395618]),
            {
              "LC": 3,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73269418550271, -1.3890458814642983]),
            {
              "LC": 3,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74419549775857, -1.3872439659812026]),
            {
              "LC": 3,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7536651429106, -1.411518934365389]),
            {
              "LC": 3,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75521009530318, -1.411776348282583]),
            {
              "LC": 3,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76018827523482, -1.4035390888241401]),
            {
              "LC": 3,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([36.739245587246536, -1.411776348282583]),
            {
              "LC": 3,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73958891000044, -1.4133208311869618]),
            {
              "LC": 3,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74739950265181, -1.40611323552982]),
            {
              "LC": 3,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74619787301314, -1.409974450264053]),
            {
              "LC": 3,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7756377991606, -1.4072286982209936]),
            {
              "LC": 3,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77254789437544, -1.4035390888241401]),
            {
              "LC": 3,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73495405282271, -1.4134924403351676]),
            {
              "LC": 3,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72319524850142, -1.411776348282583]),
            {
              "LC": 3,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71469801034224, -1.404740357639727]),
            {
              "LC": 3,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71572797860396, -1.400535914086561]),
            {
              "LC": 3,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75941579903853, -1.4040539183921208]),
            {
              "LC": 3,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76336401070845, -1.402938454184904]),
            {
              "LC": 3,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([36.737786465542435, -1.3965030733864305]),
            {
              "LC": 3,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73409574593794, -1.3912689506724671]),
            {
              "LC": 3,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75186269845259, -1.4042255282229246]),
            {
              "LC": 3,
              "system:index": "83"
            })]),
    Water = ui.import && ui.import("Water", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.69786288739034,
            -1.4198747090554045
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69842078686544,
            -1.4216336972443726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6994936704714,
            -1.4213333822825507
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74107007438159,
            -1.4046001738629583
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74124173575854,
            -1.4045894482506267
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37293886222659,
            -0.7419413732480996
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.403494587324246,
            -0.7385084322254182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.41860078849612,
            -0.7494938341045333
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.38323854484378,
            -0.7560164034593035
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.36126588859378,
            -0.7831364542297953
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.360579243085965,
            -0.8061368663463933
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.38735841789065,
            -0.7889723917878583
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37499879875003,
            -0.7663151771948074
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.367789020917996,
            -0.757732867453904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.405554523847684,
            -0.7467474862021364
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.408987751386746,
            -0.7683749289813079
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.41894411125003,
            -0.7542999387861382
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.840062291928795,
            -0.8217125721075922
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84615627081063,
            -0.8223991469425624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.843066366025475,
            -0.8164774351179468
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83714404852059,
            -0.816563257090886
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.831307561704186,
            -0.8148468172841749
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.843323858090905,
            -0.8236006526195272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84495464117196,
            -0.8181938742284599
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83971896917489,
            -0.815104283301844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83319583685067,
            -0.8168207229987116
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83396831304696,
            -0.8227424343157743
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83139339239266,
            -0.8211976409039179
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.837830694028405,
            -0.8223991469425624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83577075750497,
            -0.8224849687886358
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69795561188362,
            -1.4201771749503296
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69821310394905,
            -1.420563294373071
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69722605103157,
            -1.4195121913488538
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69840622299812,
            -1.4196838000385252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69896412247322,
            -1.421571494783731
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC": 4
      },
      "color": "#193bc2",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #193bc2 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.69786288739034, -1.4198747090554045]),
            {
              "LC": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69842078686544, -1.4216336972443726]),
            {
              "LC": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6994936704714, -1.4213333822825507]),
            {
              "LC": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74107007438159, -1.4046001738629583]),
            {
              "LC": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74124173575854, -1.4045894482506267]),
            {
              "LC": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37293886222659, -0.7419413732480996]),
            {
              "LC": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.403494587324246, -0.7385084322254182]),
            {
              "LC": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.41860078849612, -0.7494938341045333]),
            {
              "LC": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.38323854484378, -0.7560164034593035]),
            {
              "LC": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.36126588859378, -0.7831364542297953]),
            {
              "LC": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.360579243085965, -0.8061368663463933]),
            {
              "LC": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.38735841789065, -0.7889723917878583]),
            {
              "LC": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37499879875003, -0.7663151771948074]),
            {
              "LC": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.367789020917996, -0.757732867453904]),
            {
              "LC": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.405554523847684, -0.7467474862021364]),
            {
              "LC": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.408987751386746, -0.7683749289813079]),
            {
              "LC": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.41894411125003, -0.7542999387861382]),
            {
              "LC": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.840062291928795, -0.8217125721075922]),
            {
              "LC": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84615627081063, -0.8223991469425624]),
            {
              "LC": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.843066366025475, -0.8164774351179468]),
            {
              "LC": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83714404852059, -0.816563257090886]),
            {
              "LC": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.831307561704186, -0.8148468172841749]),
            {
              "LC": 4,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.843323858090905, -0.8236006526195272]),
            {
              "LC": 4,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84495464117196, -0.8181938742284599]),
            {
              "LC": 4,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83971896917489, -0.815104283301844]),
            {
              "LC": 4,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83319583685067, -0.8168207229987116]),
            {
              "LC": 4,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83396831304696, -0.8227424343157743]),
            {
              "LC": 4,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83139339239266, -0.8211976409039179]),
            {
              "LC": 4,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.837830694028405, -0.8223991469425624]),
            {
              "LC": 4,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83577075750497, -0.8224849687886358]),
            {
              "LC": 4,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69795561188362, -1.4201771749503296]),
            {
              "LC": 4,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69821310394905, -1.420563294373071]),
            {
              "LC": 4,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69722605103157, -1.4195121913488538]),
            {
              "LC": 4,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69840622299812, -1.4196838000385252]),
            {
              "LC": 4,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69896412247322, -1.421571494783731]),
            {
              "LC": 4,
              "system:index": "34"
            })]),
    BuiltUp = ui.import && ui.import("BuiltUp", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.74930030301456,
            -1.3927418980185853
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76440650418643,
            -1.3964315244079084
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75839835599307,
            -1.3971179658882895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75599509671573,
            -1.396517329603918
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75376349881534,
            -1.3966889399865476
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74955779507999,
            -1.396259914006488
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68279161560493,
            -1.3911954469739547
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.782971416652394,
            -1.3150634101871064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79198363894243,
            -1.3103439612455712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79533103579302,
            -1.3130898235317066
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79653266543169,
            -1.314805985929204
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78580382937212,
            -1.3077697126184693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82700255984087,
            -1.3023637819133775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.86991790407915,
            -1.3028786329570743
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.831379924953175,
            -1.2959281350062397
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.851893459499074,
            -1.3031360584394647
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83180907839556,
            -1.3013340795104988
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83198073977251,
            -1.3038654304966875
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83725932711382,
            -1.2971723613526354
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.80747607821245,
            -1.3006476110083414
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.840392147243215,
            -1.296099752469675
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82650393972408,
            -1.2818820082581914
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83096713552486,
            -1.2827401001936722
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.851995654201616,
            -1.2765618318470793
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.85165233144771,
            -1.2789644935276718
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82418651113521,
            -1.2803374420497675
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.827791400051225,
            -1.2770766881106388
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76502382798715,
            -1.3964367731315535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.749402642684416,
            -1.3930045627321155
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75601160569711,
            -1.3966941887096076
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76330721421762,
            -1.3960935523169318
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.654383118871024,
            -1.3619215824721334
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.655584748509696,
            -1.3627367435319402
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65644305539446,
            -1.3609348081887487
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.686312134984306,
            -1.3559151240676846
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71980326341025,
            -1.3725570373695202
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72151987717978,
            -1.3750883148494515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70469873513472,
            -1.3598210687881298
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC": 0
      },
      "color": "#ff0000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ff0000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.74930030301456, -1.3927418980185853]),
            {
              "LC": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76440650418643, -1.3964315244079084]),
            {
              "LC": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75839835599307, -1.3971179658882895]),
            {
              "LC": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75599509671573, -1.396517329603918]),
            {
              "LC": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75376349881534, -1.3966889399865476]),
            {
              "LC": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74955779507999, -1.396259914006488]),
            {
              "LC": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68279161560493, -1.3911954469739547]),
            {
              "LC": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.782971416652394, -1.3150634101871064]),
            {
              "LC": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79198363894243, -1.3103439612455712]),
            {
              "LC": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79533103579302, -1.3130898235317066]),
            {
              "LC": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79653266543169, -1.314805985929204]),
            {
              "LC": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78580382937212, -1.3077697126184693]),
            {
              "LC": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82700255984087, -1.3023637819133775]),
            {
              "LC": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.86991790407915, -1.3028786329570743]),
            {
              "LC": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.831379924953175, -1.2959281350062397]),
            {
              "LC": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.851893459499074, -1.3031360584394647]),
            {
              "LC": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83180907839556, -1.3013340795104988]),
            {
              "LC": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83198073977251, -1.3038654304966875]),
            {
              "LC": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83725932711382, -1.2971723613526354]),
            {
              "LC": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.80747607821245, -1.3006476110083414]),
            {
              "LC": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.840392147243215, -1.296099752469675]),
            {
              "LC": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82650393972408, -1.2818820082581914]),
            {
              "LC": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83096713552486, -1.2827401001936722]),
            {
              "LC": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.851995654201616, -1.2765618318470793]),
            {
              "LC": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.85165233144771, -1.2789644935276718]),
            {
              "LC": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82418651113521, -1.2803374420497675]),
            {
              "LC": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.827791400051225, -1.2770766881106388]),
            {
              "LC": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76502382798715, -1.3964367731315535]),
            {
              "LC": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.749402642684416, -1.3930045627321155]),
            {
              "LC": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75601160569711, -1.3966941887096076]),
            {
              "LC": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76330721421762, -1.3960935523169318]),
            {
              "LC": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.654383118871024, -1.3619215824721334]),
            {
              "LC": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.655584748509696, -1.3627367435319402]),
            {
              "LC": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65644305539446, -1.3609348081887487]),
            {
              "LC": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.686312134984306, -1.3559151240676846]),
            {
              "LC": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71980326341025, -1.3725570373695202]),
            {
              "LC": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72151987717978, -1.3750883148494515]),
            {
              "LC": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70469873513472, -1.3598210687881298]),
            {
              "LC": 0,
              "system:index": "37"
            })]),
    BuiltUp02 = ui.import && ui.import("BuiltUp02", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.76410821748517,
            -1.3962118106275971
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76513818574689,
            -1.3973272780356731
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75320772004865,
            -1.3967266418048112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.756040132768376,
            -1.3967695443978225
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75891546083234,
            -1.3971127651136945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74964574647687,
            -1.396383421032529
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7510190374925,
            -1.3964692262303067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7499032385423,
            -1.3927795999000783
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74852994752668,
            -1.3923505732074088
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.760589159257634,
            -1.3962976158316343
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7629065878465,
            -1.3953966610331046
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.745568788774236,
            -1.3962547132299972
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6545024283006,
            -1.362189802412544
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65639070344709,
            -1.3605165764017182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65540365052961,
            -1.362275608843321
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.656691110856755,
            -1.3611172217699703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67656087977197,
            -1.3346457668885021
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.677676678722165,
            -1.333916403852401
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67686128718164,
            -1.3355467444579712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67428636652734,
            -1.334903189084896
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.662672301160114,
            -1.3463733196922851
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.666148444043415,
            -1.3423403877217999
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69151118650337,
            -1.4265163888572387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75863078489204,
            -1.3398227629451738
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78818714014102,
            -1.3093610110719178
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7952252565961,
            -1.3130507642720044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79865848413516,
            -1.314595310506952
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7926503359418,
            -1.3156250074661717
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7831231295209,
            -1.3149385428738956
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84671358860742,
            -1.312307637457578
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84894518650781,
            -1.3123934456322914
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82585673130762,
            -1.3014099754063593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.837873027694336,
            -1.2955749873678213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.869630382430664,
            -1.3028687203090352
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.85503916538965,
            -1.3014099754063593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.87443690098535,
            -1.3020106351744072
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.851605937850586,
            -1.3032977627667728
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.85950236119043,
            -1.3111921309184507
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.851090953719726,
            -1.310505665108811
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83778719700586,
            -1.2994363780187754
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.88499407566797,
            -1.304155847462917
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.8841357687832,
            -1.3170270826898869
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.88241915501367,
            -1.3120502129157667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.754240135838785,
            -1.3976015769478556
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76604185550431,
            -1.3985454334614489
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76805887668351,
            -1.3967435252426765
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC02": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.76410821748517, -1.3962118106275971]),
            {
              "LC02": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76513818574689, -1.3973272780356731]),
            {
              "LC02": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75320772004865, -1.3967266418048112]),
            {
              "LC02": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.756040132768376, -1.3967695443978225]),
            {
              "LC02": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75891546083234, -1.3971127651136945]),
            {
              "LC02": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74964574647687, -1.396383421032529]),
            {
              "LC02": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7510190374925, -1.3964692262303067]),
            {
              "LC02": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7499032385423, -1.3927795999000783]),
            {
              "LC02": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74852994752668, -1.3923505732074088]),
            {
              "LC02": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.760589159257634, -1.3962976158316343]),
            {
              "LC02": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7629065878465, -1.3953966610331046]),
            {
              "LC02": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.745568788774236, -1.3962547132299972]),
            {
              "LC02": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6545024283006, -1.362189802412544]),
            {
              "LC02": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65639070344709, -1.3605165764017182]),
            {
              "LC02": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65540365052961, -1.362275608843321]),
            {
              "LC02": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.656691110856755, -1.3611172217699703]),
            {
              "LC02": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67656087977197, -1.3346457668885021]),
            {
              "LC02": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.677676678722165, -1.333916403852401]),
            {
              "LC02": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67686128718164, -1.3355467444579712]),
            {
              "LC02": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67428636652734, -1.334903189084896]),
            {
              "LC02": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.662672301160114, -1.3463733196922851]),
            {
              "LC02": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.666148444043415, -1.3423403877217999]),
            {
              "LC02": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69151118650337, -1.4265163888572387]),
            {
              "LC02": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75863078489204, -1.3398227629451738]),
            {
              "LC02": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78818714014102, -1.3093610110719178]),
            {
              "LC02": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7952252565961, -1.3130507642720044]),
            {
              "LC02": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79865848413516, -1.314595310506952]),
            {
              "LC02": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7926503359418, -1.3156250074661717]),
            {
              "LC02": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7831231295209, -1.3149385428738956]),
            {
              "LC02": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84671358860742, -1.312307637457578]),
            {
              "LC02": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84894518650781, -1.3123934456322914]),
            {
              "LC02": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82585673130762, -1.3014099754063593]),
            {
              "LC02": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.837873027694336, -1.2955749873678213]),
            {
              "LC02": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.869630382430664, -1.3028687203090352]),
            {
              "LC02": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.85503916538965, -1.3014099754063593]),
            {
              "LC02": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.87443690098535, -1.3020106351744072]),
            {
              "LC02": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.851605937850586, -1.3032977627667728]),
            {
              "LC02": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.85950236119043, -1.3111921309184507]),
            {
              "LC02": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.851090953719726, -1.310505665108811]),
            {
              "LC02": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83778719700586, -1.2994363780187754]),
            {
              "LC02": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.88499407566797, -1.304155847462917]),
            {
              "LC02": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.8841357687832, -1.3170270826898869]),
            {
              "LC02": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.88241915501367, -1.3120502129157667]),
            {
              "LC02": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.754240135838785, -1.3976015769478556]),
            {
              "LC02": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76604185550431, -1.3985454334614489]),
            {
              "LC02": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76805887668351, -1.3967435252426765]),
            {
              "LC02": 0,
              "system:index": "45"
            })]),
    ForestedAreas02 = ui.import && ui.import("ForestedAreas02", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.69795268221016,
            -1.3534230514140386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70284503145332,
            -1.3547101522249887
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70971148653145,
            -1.3599443551383688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71468966646309,
            -1.3632050003980203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71657794160957,
            -1.3662082223887186
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7113422696125,
            -1.3695546653269988
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.706535751057814,
            -1.3705843391376706
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70619242830391,
            -1.364406289644282
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69915431184883,
            -1.3586572571121214
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69683688325996,
            -1.3645779023447855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6974376980793,
            -1.3668088663366114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70018428011055,
            -1.3602875811628028
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.699240142537306,
            -1.3539378918204337
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7124580685627,
            -1.3608024201079112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.709968978596876,
            -1.3626043555500815
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70456164522285,
            -1.3565978988440108
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63913967435158,
            -1.4051545690218934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.643345378086934,
            -1.4016365663713288
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65046932523049,
            -1.4018081763794545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63939716641701,
            -1.3985475840760258
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.639311335728536,
            -1.3943431294203448
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63853885953225,
            -1.3858483920211855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64952518765725,
            -1.406784861137274
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64102794949807,
            -1.4044681298959751
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.640083811924825,
            -1.3994914402091485
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64265873257912,
            -1.3965740654804122
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73534533429141,
            -1.3204641377535222
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.744958371400784,
            -1.321665447999918
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75285479474063,
            -1.3208073693117526
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75525805401797,
            -1.3151440425477725
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76075121808047,
            -1.3153156586994197
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76881930279727,
            -1.3148008102090978
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76710268902774,
            -1.3208073693117526
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74907824444766,
            -1.3230383732842066
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73414370465274,
            -1.3135994966521394
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73929354596133,
            -1.3201209061478762
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70154197784739,
            -1.3628953879399273
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71081169220286,
            -1.3607502268055636
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71475990387278,
            -1.3641395805225214
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69956787201243,
            -1.3660273197638397
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.697465020144755,
            -1.3680008637484855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69699295135813,
            -1.3604070008469415
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC02": 1
      },
      "color": "#3a6200",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #3a6200 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.69795268221016, -1.3534230514140386]),
            {
              "LC02": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70284503145332, -1.3547101522249887]),
            {
              "LC02": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70971148653145, -1.3599443551383688]),
            {
              "LC02": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71468966646309, -1.3632050003980203]),
            {
              "LC02": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71657794160957, -1.3662082223887186]),
            {
              "LC02": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7113422696125, -1.3695546653269988]),
            {
              "LC02": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.706535751057814, -1.3705843391376706]),
            {
              "LC02": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70619242830391, -1.364406289644282]),
            {
              "LC02": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69915431184883, -1.3586572571121214]),
            {
              "LC02": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69683688325996, -1.3645779023447855]),
            {
              "LC02": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6974376980793, -1.3668088663366114]),
            {
              "LC02": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70018428011055, -1.3602875811628028]),
            {
              "LC02": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.699240142537306, -1.3539378918204337]),
            {
              "LC02": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7124580685627, -1.3608024201079112]),
            {
              "LC02": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.709968978596876, -1.3626043555500815]),
            {
              "LC02": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70456164522285, -1.3565978988440108]),
            {
              "LC02": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63913967435158, -1.4051545690218934]),
            {
              "LC02": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.643345378086934, -1.4016365663713288]),
            {
              "LC02": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65046932523049, -1.4018081763794545]),
            {
              "LC02": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63939716641701, -1.3985475840760258]),
            {
              "LC02": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.639311335728536, -1.3943431294203448]),
            {
              "LC02": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63853885953225, -1.3858483920211855]),
            {
              "LC02": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64952518765725, -1.406784861137274]),
            {
              "LC02": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64102794949807, -1.4044681298959751]),
            {
              "LC02": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.640083811924825, -1.3994914402091485]),
            {
              "LC02": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64265873257912, -1.3965740654804122]),
            {
              "LC02": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73534533429141, -1.3204641377535222]),
            {
              "LC02": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.744958371400784, -1.321665447999918]),
            {
              "LC02": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75285479474063, -1.3208073693117526]),
            {
              "LC02": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75525805401797, -1.3151440425477725]),
            {
              "LC02": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76075121808047, -1.3153156586994197]),
            {
              "LC02": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76881930279727, -1.3148008102090978]),
            {
              "LC02": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76710268902774, -1.3208073693117526]),
            {
              "LC02": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74907824444766, -1.3230383732842066]),
            {
              "LC02": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73414370465274, -1.3135994966521394]),
            {
              "LC02": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73929354596133, -1.3201209061478762]),
            {
              "LC02": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70154197784739, -1.3628953879399273]),
            {
              "LC02": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71081169220286, -1.3607502268055636]),
            {
              "LC02": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71475990387278, -1.3641395805225214]),
            {
              "LC02": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69956787201243, -1.3660273197638397]),
            {
              "LC02": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.697465020144755, -1.3680008637484855]),
            {
              "LC02": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69699295135813, -1.3604070008469415]),
            {
              "LC02": 1,
              "system:index": "41"
            })]),
    Vegetation02 = ui.import && ui.import("Vegetation02", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.7056530866596,
            -1.4045943477248393
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.725050822255305,
            -1.3990170226615113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7261666212055,
            -1.4002182937973255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.727539912221125,
            -1.3993602430488192
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.689602747914485,
            -1.3830572194047552
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71715439891546,
            -1.3857171941013908
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67947472667425,
            -1.3935254896441256
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.666600123402766,
            -1.3975583354554328
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66368187999456,
            -1.3967860889206534
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.676485797047455,
            -1.3730330733737928
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6748550139664,
            -1.3731188794168856
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67442586052402,
            -1.3758646711682543
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65760304558261,
            -1.3780956246394158
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.655285616993744,
            -1.3771517599641503
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6554572783707,
            -1.3702014722251818
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.670992632984955,
            -1.3687427672964168
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.663267871022065,
            -1.361363422901066
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66841771233066,
            -1.3589608407761458
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6774299346207,
            -1.3632511643197922
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.659239567460304,
            -1.3806640619940185
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66456107014585,
            -1.3794627809112865
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67159918660093,
            -1.3792053634574941
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66873776946413,
            -1.3893848740639154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6713985208069,
            -1.3823488163604762
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6950240958292,
            -1.418429840502792
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69051798468418,
            -1.4207036556713928
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69137629156894,
            -1.4209610685683918
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692320429142185,
            -1.411436772317496
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69051798468418,
            -1.4045723904549574
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71111734991855,
            -1.413238669202769
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.712061487491795,
            -1.4243074336170123
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70176180487461,
            -1.425594495803917
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73240336066074,
            -1.4186014492727534
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69470369341348,
            -1.4020082365626374
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692300434136136,
            -1.3905103392638483
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69393121721719,
            -1.3886226194170816
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70096933367227,
            -1.3834742849054367
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68079912188028,
            -1.3738044595842047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68097078325723,
            -1.3663393244694826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.666637058281644,
            -1.3709728593486548
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66449129106973,
            -1.3721741447064975
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66148721697305,
            -1.3688277054250029
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67024194719766,
            -1.3623922321513169
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.676656214317426,
            -1.3883119378055964
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71425005587016,
            -1.3986085745039551
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70446535738383,
            -1.3989517949510193
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71347757967387,
            -1.4225480796335828
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72206064852153,
            -1.4161985575023495
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70721193941508,
            -1.3899422416128742
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69219156893168,
            -1.379559761339109
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75522217572592,
            -1.3988596853361717
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74818405927084,
            -1.4000609565525812
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74676785291098,
            -1.3974868031929266
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.744836662420255,
            -1.3975726083504003
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74397835553549,
            -1.399202905746494
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74445042432211,
            -1.4002325666761104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74071678937338,
            -1.3969719721822718
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.751316879400235,
            -1.4007902994908208
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7576683503475,
            -1.398688075112175
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76230822055558,
            -1.3988886539177494
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75389681308488,
            -1.4013770007235904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75630007236222,
            -1.402921490515028
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.764968971898355,
            -1.3988028488083784
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75406847446183,
            -1.3926677753675802
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC02": 2
      },
      "color": "#31d20d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #31d20d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.7056530866596, -1.4045943477248393]),
            {
              "LC02": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.725050822255305, -1.3990170226615113]),
            {
              "LC02": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7261666212055, -1.4002182937973255]),
            {
              "LC02": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.727539912221125, -1.3993602430488192]),
            {
              "LC02": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.689602747914485, -1.3830572194047552]),
            {
              "LC02": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71715439891546, -1.3857171941013908]),
            {
              "LC02": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67947472667425, -1.3935254896441256]),
            {
              "LC02": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.666600123402766, -1.3975583354554328]),
            {
              "LC02": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66368187999456, -1.3967860889206534]),
            {
              "LC02": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.676485797047455, -1.3730330733737928]),
            {
              "LC02": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6748550139664, -1.3731188794168856]),
            {
              "LC02": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67442586052402, -1.3758646711682543]),
            {
              "LC02": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65760304558261, -1.3780956246394158]),
            {
              "LC02": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.655285616993744, -1.3771517599641503]),
            {
              "LC02": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6554572783707, -1.3702014722251818]),
            {
              "LC02": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.670992632984955, -1.3687427672964168]),
            {
              "LC02": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.663267871022065, -1.361363422901066]),
            {
              "LC02": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66841771233066, -1.3589608407761458]),
            {
              "LC02": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6774299346207, -1.3632511643197922]),
            {
              "LC02": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.659239567460304, -1.3806640619940185]),
            {
              "LC02": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66456107014585, -1.3794627809112865]),
            {
              "LC02": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67159918660093, -1.3792053634574941]),
            {
              "LC02": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66873776946413, -1.3893848740639154]),
            {
              "LC02": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6713985208069, -1.3823488163604762]),
            {
              "LC02": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6950240958292, -1.418429840502792]),
            {
              "LC02": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69051798468418, -1.4207036556713928]),
            {
              "LC02": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69137629156894, -1.4209610685683918]),
            {
              "LC02": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692320429142185, -1.411436772317496]),
            {
              "LC02": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69051798468418, -1.4045723904549574]),
            {
              "LC02": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71111734991855, -1.413238669202769]),
            {
              "LC02": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.712061487491795, -1.4243074336170123]),
            {
              "LC02": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70176180487461, -1.425594495803917]),
            {
              "LC02": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73240336066074, -1.4186014492727534]),
            {
              "LC02": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69470369341348, -1.4020082365626374]),
            {
              "LC02": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692300434136136, -1.3905103392638483]),
            {
              "LC02": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69393121721719, -1.3886226194170816]),
            {
              "LC02": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70096933367227, -1.3834742849054367]),
            {
              "LC02": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68079912188028, -1.3738044595842047]),
            {
              "LC02": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68097078325723, -1.3663393244694826]),
            {
              "LC02": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.666637058281644, -1.3709728593486548]),
            {
              "LC02": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66449129106973, -1.3721741447064975]),
            {
              "LC02": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66148721697305, -1.3688277054250029]),
            {
              "LC02": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67024194719766, -1.3623922321513169]),
            {
              "LC02": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.676656214317426, -1.3883119378055964]),
            {
              "LC02": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71425005587016, -1.3986085745039551]),
            {
              "LC02": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70446535738383, -1.3989517949510193]),
            {
              "LC02": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71347757967387, -1.4225480796335828]),
            {
              "LC02": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72206064852153, -1.4161985575023495]),
            {
              "LC02": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70721193941508, -1.3899422416128742]),
            {
              "LC02": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69219156893168, -1.379559761339109]),
            {
              "LC02": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75522217572592, -1.3988596853361717]),
            {
              "LC02": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74818405927084, -1.4000609565525812]),
            {
              "LC02": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74676785291098, -1.3974868031929266]),
            {
              "LC02": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.744836662420255, -1.3975726083504003]),
            {
              "LC02": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74397835553549, -1.399202905746494]),
            {
              "LC02": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74445042432211, -1.4002325666761104]),
            {
              "LC02": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74071678937338, -1.3969719721822718]),
            {
              "LC02": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.751316879400235, -1.4007902994908208]),
            {
              "LC02": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7576683503475, -1.398688075112175]),
            {
              "LC02": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76230822055558, -1.3988886539177494]),
            {
              "LC02": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75389681308488, -1.4013770007235904]),
            {
              "LC02": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75630007236222, -1.402921490515028]),
            {
              "LC02": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.764968971898355, -1.3988028488083784]),
            {
              "LC02": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75406847446183, -1.3926677753675802]),
            {
              "LC02": 2,
              "system:index": "63"
            })]),
    NonBuilt_Up02 = ui.import && ui.import("NonBuilt_Up02", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.81734832705055,
            -1.3843180765702798
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81794914186989,
            -1.3891231874170553
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81245597780739,
            -1.390067047329033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.809280242333756,
            -1.3896380201430723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.801812972436295,
            -1.3914399338001098
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.80018218935524,
            -1.389208992879188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.797349776635514,
            -1.3902386581815835
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79297241152321,
            -1.3913541284190685
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78850921572243,
            -1.3915257391780216
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78387435854469,
            -1.394014093779084
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78095611513649,
            -1.3972746923782937
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78172859133278,
            -1.402937826550464
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78499015749489,
            -1.39976304089638
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78344520510231,
            -1.3964166405537293
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79048332155739,
            -1.3946147307027472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.783101882348404,
            -1.4042249005888408
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77529128969704,
            -1.401050116680194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77778037966286,
            -1.400878506616523
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.712205733666764,
            -1.40671324171944
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71452316225563,
            -1.4052545593092691
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69709953249489,
            -1.3991624052887794
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69864448488747,
            -1.3925554034695349
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.720187987695084,
            -1.4006210914974613
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.687486495385514,
            -1.397789523322602
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69452461184059,
            -1.408515142261091
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72971519411598,
            -1.380199402378017
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73297676027809,
            -1.383030991652765
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73675331057106,
            -1.3845754934699561
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74542221010719,
            -1.3840606596426528
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7105371892285,
            -1.3875786885661003
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71834778187987,
            -1.392812819472142
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68315719960448,
            -1.361322054715823
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68315719960448,
            -1.3660414055678813
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69208359120604,
            -1.3581472134885684
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69337105153319,
            -1.3594343117866514
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65912460683104,
            -1.367414305894803
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66118454335448,
            -1.3650975361380173
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65071319936034,
            -1.3478504024805085
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65217232106444,
            -1.3435600516912127
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65946792958495,
            -1.3348511004209656
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66461777089354,
            -1.3316762247162819
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66187118886229,
            -1.329101998169227
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66092705128905,
            -1.3224948044283666
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6636736333203,
            -1.334078833734586
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66169952748534,
            -1.324963216911387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66015457509276,
            -1.3294252153635098
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66161369679686,
            -1.3350027020853996
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69875477515522,
            -1.3963001546578073
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.710170256722606,
            -1.389778950245661
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72826034302878,
            -1.4214574270088405
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72868949647116,
            -1.4227444907866968
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74448234315085,
            -1.386706435945672
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74551231141257,
            -1.3874786857820325
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC02": 3
      },
      "color": "#fdc62d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #fdc62d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.81734832705055, -1.3843180765702798]),
            {
              "LC02": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81794914186989, -1.3891231874170553]),
            {
              "LC02": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81245597780739, -1.390067047329033]),
            {
              "LC02": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.809280242333756, -1.3896380201430723]),
            {
              "LC02": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.801812972436295, -1.3914399338001098]),
            {
              "LC02": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.80018218935524, -1.389208992879188]),
            {
              "LC02": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.797349776635514, -1.3902386581815835]),
            {
              "LC02": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79297241152321, -1.3913541284190685]),
            {
              "LC02": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78850921572243, -1.3915257391780216]),
            {
              "LC02": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78387435854469, -1.394014093779084]),
            {
              "LC02": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78095611513649, -1.3972746923782937]),
            {
              "LC02": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78172859133278, -1.402937826550464]),
            {
              "LC02": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78499015749489, -1.39976304089638]),
            {
              "LC02": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78344520510231, -1.3964166405537293]),
            {
              "LC02": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79048332155739, -1.3946147307027472]),
            {
              "LC02": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.783101882348404, -1.4042249005888408]),
            {
              "LC02": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77529128969704, -1.401050116680194]),
            {
              "LC02": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77778037966286, -1.400878506616523]),
            {
              "LC02": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.712205733666764, -1.40671324171944]),
            {
              "LC02": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71452316225563, -1.4052545593092691]),
            {
              "LC02": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69709953249489, -1.3991624052887794]),
            {
              "LC02": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69864448488747, -1.3925554034695349]),
            {
              "LC02": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.720187987695084, -1.4006210914974613]),
            {
              "LC02": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.687486495385514, -1.397789523322602]),
            {
              "LC02": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69452461184059, -1.408515142261091]),
            {
              "LC02": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72971519411598, -1.380199402378017]),
            {
              "LC02": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73297676027809, -1.383030991652765]),
            {
              "LC02": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73675331057106, -1.3845754934699561]),
            {
              "LC02": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74542221010719, -1.3840606596426528]),
            {
              "LC02": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7105371892285, -1.3875786885661003]),
            {
              "LC02": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71834778187987, -1.392812819472142]),
            {
              "LC02": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68315719960448, -1.361322054715823]),
            {
              "LC02": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68315719960448, -1.3660414055678813]),
            {
              "LC02": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69208359120604, -1.3581472134885684]),
            {
              "LC02": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69337105153319, -1.3594343117866514]),
            {
              "LC02": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65912460683104, -1.367414305894803]),
            {
              "LC02": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66118454335448, -1.3650975361380173]),
            {
              "LC02": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65071319936034, -1.3478504024805085]),
            {
              "LC02": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65217232106444, -1.3435600516912127]),
            {
              "LC02": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65946792958495, -1.3348511004209656]),
            {
              "LC02": 3,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66461777089354, -1.3316762247162819]),
            {
              "LC02": 3,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66187118886229, -1.329101998169227]),
            {
              "LC02": 3,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66092705128905, -1.3224948044283666]),
            {
              "LC02": 3,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6636736333203, -1.334078833734586]),
            {
              "LC02": 3,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66169952748534, -1.324963216911387]),
            {
              "LC02": 3,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66015457509276, -1.3294252153635098]),
            {
              "LC02": 3,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66161369679686, -1.3350027020853996]),
            {
              "LC02": 3,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69875477515522, -1.3963001546578073]),
            {
              "LC02": 3,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.710170256722606, -1.389778950245661]),
            {
              "LC02": 3,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72826034302878, -1.4214574270088405]),
            {
              "LC02": 3,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72868949647116, -1.4227444907866968]),
            {
              "LC02": 3,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74448234315085, -1.386706435945672]),
            {
              "LC02": 3,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74551231141257, -1.3874786857820325]),
            {
              "LC02": 3,
              "system:index": "52"
            })]),
    Water02 = ui.import && ui.import("Water02", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.695763221664976,
            -1.415895963251942
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.697981733709284,
            -1.3719386982093025
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69879712524981,
            -1.3717885375577856
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.654512444179765,
            -1.3489097538564487
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65699055465671,
            -1.348909265400639
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.741269968763994,
            -1.4046366088940776
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.33535165619607,
            -0.7382316878986561
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.32436532807107,
            -0.7746207277352246
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.32436532807107,
            -0.7938450009262302
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.36007089447732,
            -0.789725521264054
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.35595102143044,
            -0.7547097814471568
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37723703217263,
            -0.7457841551039731
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.40813608002419,
            -0.7409780411007858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.38204355072732,
            -0.7842328753673667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.36144418549294,
            -0.8110094551021934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.33535165619607,
            -0.8041436820802782
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.34702462982888,
            -0.7663817266870329
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.32985849213357,
            -0.7485305036089451
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67971554298546,
            -0.7592743168924747
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.669600021472846,
            -0.7538261207488608
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67290450297919,
            -0.7562720829693824
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.675393592945014,
            -0.7585463974817349
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67869807445136,
            -0.7600053910681013
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66882754527656,
            -0.7493203972757572
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.680586349597846,
            -0.7573448729824003
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.839673530689154,
            -0.8146314644701953
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84422255717841,
            -0.8168628361955057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84834243022529,
            -0.8198666038685383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.846368324390326,
            -0.8233853002759516
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.841132652393256,
            -0.8224412600806945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.836926948657904,
            -0.8228703692880589
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83375121318427,
            -0.8228703692880589
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83727027141181,
            -0.8177210557601322
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.831691276660834,
            -0.8143739984223107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83332205974189,
            -0.8168628361955057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83151961528388,
            -0.8214113977948432
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82911635600654,
            -0.818922562842304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82405234538642,
            -0.8184076312797233
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84319258891669,
            -0.8230420129580814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84551001750556,
            -0.818579275141266
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.838901054492865,
            -0.8166911922605812
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.57172876994752,
            -0.8790044016295314
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.53945643108033,
            -0.8899894206723657
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.534649912525644,
            -0.9174518242590566
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.51611048381471,
            -0.9153921512234208
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.482464853931894,
            -0.8989147245727224
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.46117884318971,
            -0.8721387482929703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.46186548869752,
            -0.9009744069980935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.556622568775644,
            -0.8838103514606283
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.67335230510377,
            -0.8295714218868335
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC02": 4
      },
      "color": "#0a2fff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0a2fff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.695763221664976, -1.415895963251942]),
            {
              "LC02": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.697981733709284, -1.3719386982093025]),
            {
              "LC02": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69879712524981, -1.3717885375577856]),
            {
              "LC02": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.654512444179765, -1.3489097538564487]),
            {
              "LC02": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65699055465671, -1.348909265400639]),
            {
              "LC02": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.741269968763994, -1.4046366088940776]),
            {
              "LC02": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.33535165619607, -0.7382316878986561]),
            {
              "LC02": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.32436532807107, -0.7746207277352246]),
            {
              "LC02": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.32436532807107, -0.7938450009262302]),
            {
              "LC02": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.36007089447732, -0.789725521264054]),
            {
              "LC02": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.35595102143044, -0.7547097814471568]),
            {
              "LC02": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37723703217263, -0.7457841551039731]),
            {
              "LC02": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.40813608002419, -0.7409780411007858]),
            {
              "LC02": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.38204355072732, -0.7842328753673667]),
            {
              "LC02": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.36144418549294, -0.8110094551021934]),
            {
              "LC02": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.33535165619607, -0.8041436820802782]),
            {
              "LC02": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.34702462982888, -0.7663817266870329]),
            {
              "LC02": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.32985849213357, -0.7485305036089451]),
            {
              "LC02": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67971554298546, -0.7592743168924747]),
            {
              "LC02": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.669600021472846, -0.7538261207488608]),
            {
              "LC02": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67290450297919, -0.7562720829693824]),
            {
              "LC02": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.675393592945014, -0.7585463974817349]),
            {
              "LC02": 4,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67869807445136, -0.7600053910681013]),
            {
              "LC02": 4,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66882754527656, -0.7493203972757572]),
            {
              "LC02": 4,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.680586349597846, -0.7573448729824003]),
            {
              "LC02": 4,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.839673530689154, -0.8146314644701953]),
            {
              "LC02": 4,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84422255717841, -0.8168628361955057]),
            {
              "LC02": 4,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84834243022529, -0.8198666038685383]),
            {
              "LC02": 4,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.846368324390326, -0.8233853002759516]),
            {
              "LC02": 4,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.841132652393256, -0.8224412600806945]),
            {
              "LC02": 4,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.836926948657904, -0.8228703692880589]),
            {
              "LC02": 4,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83375121318427, -0.8228703692880589]),
            {
              "LC02": 4,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83727027141181, -0.8177210557601322]),
            {
              "LC02": 4,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.831691276660834, -0.8143739984223107]),
            {
              "LC02": 4,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83332205974189, -0.8168628361955057]),
            {
              "LC02": 4,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83151961528388, -0.8214113977948432]),
            {
              "LC02": 4,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82911635600654, -0.818922562842304]),
            {
              "LC02": 4,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82405234538642, -0.8184076312797233]),
            {
              "LC02": 4,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84319258891669, -0.8230420129580814]),
            {
              "LC02": 4,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84551001750556, -0.818579275141266]),
            {
              "LC02": 4,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.838901054492865, -0.8166911922605812]),
            {
              "LC02": 4,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([37.57172876994752, -0.8790044016295314]),
            {
              "LC02": 4,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([37.53945643108033, -0.8899894206723657]),
            {
              "LC02": 4,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([37.534649912525644, -0.9174518242590566]),
            {
              "LC02": 4,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([37.51611048381471, -0.9153921512234208]),
            {
              "LC02": 4,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([37.482464853931894, -0.8989147245727224]),
            {
              "LC02": 4,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([37.46117884318971, -0.8721387482929703]),
            {
              "LC02": 4,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([37.46186548869752, -0.9009744069980935]),
            {
              "LC02": 4,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([37.556622568775644, -0.8838103514606283]),
            {
              "LC02": 4,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([37.67335230510377, -0.8295714218868335]),
            {
              "LC02": 4,
              "system:index": "49"
            })]),
    BuiltUp04 = ui.import && ui.import("BuiltUp04", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.748212888115035,
            -1.3923608073436633
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.749672009819136,
            -1.3933475686157548
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.761902882927046,
            -1.3958359212918439
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76413448082744,
            -1.3959217265095956
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76456363426982,
            -1.396479460348661
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75632388817607,
            -1.391931780574775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75460727440654,
            -1.3942485241988511
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75555141197978,
            -1.396908486288633
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.764649464958296,
            -1.3973375121502871
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72928722130595,
            -1.3809057659001813
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682509496086226,
            -1.3590251966062334
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65495784508525,
            -1.3622858431087441
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.674183919304,
            -1.335256667397099
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67761714684306,
            -1.336715392457592
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67632968651591,
            -1.3343985934276683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65718944298564,
            -1.361129264696603
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7487789731243,
            -1.3925288498349095
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.762941036722935,
            -1.3957036452696956
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.748435650370396,
            -1.3931723897959456
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.747191105387486,
            -1.391413380152915
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78721360631783,
            -1.3112493899582778
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.795281691034624,
            -1.3124507046446259
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79511002965767,
            -1.3158830291383337
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82755402990181,
            -1.2819028105462935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82635240026314,
            -1.2851635583431096
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84952668615181,
            -1.2807014813633077
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84454850622017,
            -1.284820321928783
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83081559606392,
            -1.282589284112123
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83802537389595,
            -1.296833568902945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74918911484884,
            -1.3939075426635106
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75888798264669,
            -1.3969107258843032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.747043347636925,
            -1.393135294930158
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.750819897929894,
            -1.3934500961003764
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69194004563497,
            -1.426504446423679
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.687648511211144,
            -1.429850803416107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7343253943856,
            -1.3951291196168738
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73951386834483,
            -1.4014211175826232
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72303437615733,
            -1.3764517258744746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72080277825694,
            -1.3729105904819574
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72038643160835,
            -1.397947815693197
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7447705142103,
            -1.398613490110628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.748032097072574,
            -1.3983453868960143
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75234508916852,
            -1.3986564304631717
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73102669275387,
            -1.3978294718480782
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73376254594906,
            -1.4000067764309787
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73500709093197,
            -1.398902035934529
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC04": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.748212888115035, -1.3923608073436633]),
            {
              "LC04": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.749672009819136, -1.3933475686157548]),
            {
              "LC04": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.761902882927046, -1.3958359212918439]),
            {
              "LC04": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76413448082744, -1.3959217265095956]),
            {
              "LC04": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76456363426982, -1.396479460348661]),
            {
              "LC04": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75632388817607, -1.391931780574775]),
            {
              "LC04": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75460727440654, -1.3942485241988511]),
            {
              "LC04": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75555141197978, -1.396908486288633]),
            {
              "LC04": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.764649464958296, -1.3973375121502871]),
            {
              "LC04": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72928722130595, -1.3809057659001813]),
            {
              "LC04": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682509496086226, -1.3590251966062334]),
            {
              "LC04": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65495784508525, -1.3622858431087441]),
            {
              "LC04": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.674183919304, -1.335256667397099]),
            {
              "LC04": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67761714684306, -1.336715392457592]),
            {
              "LC04": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67632968651591, -1.3343985934276683]),
            {
              "LC04": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65718944298564, -1.361129264696603]),
            {
              "LC04": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7487789731243, -1.3925288498349095]),
            {
              "LC04": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.762941036722935, -1.3957036452696956]),
            {
              "LC04": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.748435650370396, -1.3931723897959456]),
            {
              "LC04": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.747191105387486, -1.391413380152915]),
            {
              "LC04": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78721360631783, -1.3112493899582778]),
            {
              "LC04": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.795281691034624, -1.3124507046446259]),
            {
              "LC04": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79511002965767, -1.3158830291383337]),
            {
              "LC04": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82755402990181, -1.2819028105462935]),
            {
              "LC04": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82635240026314, -1.2851635583431096]),
            {
              "LC04": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84952668615181, -1.2807014813633077]),
            {
              "LC04": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84454850622017, -1.284820321928783]),
            {
              "LC04": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83081559606392, -1.282589284112123]),
            {
              "LC04": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83802537389595, -1.296833568902945]),
            {
              "LC04": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74918911484884, -1.3939075426635106]),
            {
              "LC04": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75888798264669, -1.3969107258843032]),
            {
              "LC04": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.747043347636925, -1.393135294930158]),
            {
              "LC04": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.750819897929894, -1.3934500961003764]),
            {
              "LC04": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69194004563497, -1.426504446423679]),
            {
              "LC04": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.687648511211144, -1.429850803416107]),
            {
              "LC04": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7343253943856, -1.3951291196168738]),
            {
              "LC04": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73951386834483, -1.4014211175826232]),
            {
              "LC04": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72303437615733, -1.3764517258744746]),
            {
              "LC04": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72080277825694, -1.3729105904819574]),
            {
              "LC04": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72038643160835, -1.397947815693197]),
            {
              "LC04": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7447705142103, -1.398613490110628]),
            {
              "LC04": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.748032097072574, -1.3983453868960143]),
            {
              "LC04": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75234508916852, -1.3986564304631717]),
            {
              "LC04": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73102669275387, -1.3978294718480782]),
            {
              "LC04": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73376254594906, -1.4000067764309787]),
            {
              "LC04": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73500709093197, -1.398902035934529]),
            {
              "LC04": 0,
              "system:index": "45"
            })]),
    ForestedAreas04 = ui.import && ui.import("ForestedAreas04", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.701833871828576,
            -1.3535430074744121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.703636316286584,
            -1.3562888215751696
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70947280310299,
            -1.359292052180324
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71290603064205,
            -1.3610939887509934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.705352930056115,
            -1.3642688260982638
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70801368139889,
            -1.3640972133757125
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69865813635494,
            -1.3576617274576168
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.699859765993615,
            -1.359292052180324
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70080390356686,
            -1.3614372146118452
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69719901465084,
            -1.3648694705307967
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69891562842037,
            -1.3653843084964215
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70655455969479,
            -1.3701036513713942
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70955863379147,
            -1.3696746205846386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69170585058834,
            -1.3666714029279932
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69428077124264,
            -1.368902364974935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71101775549557,
            -1.361008182278144
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.702091363894006,
            -1.3544010747151887
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70955863379147,
            -1.3755094326931225
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71118941687252,
            -1.375766850546202
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70655455969479,
            -1.3717339676600846
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64486172235209,
            -1.4013519587513907
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64760830438334,
            -1.403497083209379
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6426301244517,
            -1.398777806808686
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64477589166361,
            -1.396804288406552
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64889576471049,
            -1.4064144493139015
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64010884293585,
            -1.391484360985901
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64319874772101,
            -1.392084998554466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74688646390472,
            -1.3211311896291873
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75461122586761,
            -1.3221608838851644
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75701448514496,
            -1.317012408340893
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76216432645355,
            -1.3158110958486313
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76662752225433,
            -1.3190717998372505
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.770060749793394,
            -1.3156394797310798
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76765749051605,
            -1.3225041152089367
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76868745877777,
            -1.3271377334287813
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC04": 1
      },
      "color": "#98ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.701833871828576, -1.3535430074744121]),
            {
              "LC04": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.703636316286584, -1.3562888215751696]),
            {
              "LC04": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70947280310299, -1.359292052180324]),
            {
              "LC04": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71290603064205, -1.3610939887509934]),
            {
              "LC04": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.705352930056115, -1.3642688260982638]),
            {
              "LC04": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70801368139889, -1.3640972133757125]),
            {
              "LC04": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69865813635494, -1.3576617274576168]),
            {
              "LC04": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.699859765993615, -1.359292052180324]),
            {
              "LC04": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70080390356686, -1.3614372146118452]),
            {
              "LC04": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69719901465084, -1.3648694705307967]),
            {
              "LC04": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69891562842037, -1.3653843084964215]),
            {
              "LC04": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70655455969479, -1.3701036513713942]),
            {
              "LC04": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70955863379147, -1.3696746205846386]),
            {
              "LC04": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69170585058834, -1.3666714029279932]),
            {
              "LC04": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69428077124264, -1.368902364974935]),
            {
              "LC04": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71101775549557, -1.361008182278144]),
            {
              "LC04": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.702091363894006, -1.3544010747151887]),
            {
              "LC04": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70955863379147, -1.3755094326931225]),
            {
              "LC04": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71118941687252, -1.375766850546202]),
            {
              "LC04": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70655455969479, -1.3717339676600846]),
            {
              "LC04": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64486172235209, -1.4013519587513907]),
            {
              "LC04": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64760830438334, -1.403497083209379]),
            {
              "LC04": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6426301244517, -1.398777806808686]),
            {
              "LC04": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64477589166361, -1.396804288406552]),
            {
              "LC04": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64889576471049, -1.4064144493139015]),
            {
              "LC04": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64010884293585, -1.391484360985901]),
            {
              "LC04": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64319874772101, -1.392084998554466]),
            {
              "LC04": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74688646390472, -1.3211311896291873]),
            {
              "LC04": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75461122586761, -1.3221608838851644]),
            {
              "LC04": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75701448514496, -1.317012408340893]),
            {
              "LC04": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76216432645355, -1.3158110958486313]),
            {
              "LC04": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76662752225433, -1.3190717998372505]),
            {
              "LC04": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.770060749793394, -1.3156394797310798]),
            {
              "LC04": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76765749051605, -1.3225041152089367]),
            {
              "LC04": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76868745877777, -1.3271377334287813]),
            {
              "LC04": 1,
              "system:index": "34"
            })]),
    Vegetation04 = ui.import && ui.import("Vegetation04", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.72555483846156,
            -1.3999324363908552
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.725983991903945,
            -1.4011337070575758
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.694741621298476,
            -1.4018201471620109
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.705985441488906,
            -1.4046517104644254
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.725726499838515,
            -1.4168359739229337
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72461070088832,
            -1.413403793492959
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.732507124228164,
            -1.4194101059089683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73207797078578,
            -1.4092851702819345
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.739201917929336,
            -1.4035362465424026
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73293627767055,
            -1.4022491721250945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76010169057338,
            -1.391094497598037
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.761947050375625,
            -1.3891209727560176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75259150533168,
            -1.3875764739036252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74222214502307,
            -1.3928239820346482
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71707375329944,
            -1.3861740596606933
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.708752053200946,
            -1.3912794856047188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.688474517777856,
            -1.388748225380696
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6903198775801,
            -1.3798673418299734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69242272944778,
            -1.379996050524536
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69504056544631,
            -1.3793525069820682
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67956343078299,
            -1.3811871312311514
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.670250801083284,
            -1.376811033901674
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66656008147879,
            -1.3745800792287588
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.681237129208284,
            -1.3875367483139007
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66484346770926,
            -1.3792135981375135
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77351611109248,
            -1.3948694461470723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.769224576668655,
            -1.4022486864490769
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77527564020625,
            -1.3930675351113844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.754385756915745,
            -1.3978664000898855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74361400551194,
            -1.4042588746898201
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72499985968602,
            -1.3929477338685556
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC04": 2
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.72555483846156, -1.3999324363908552]),
            {
              "LC04": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.725983991903945, -1.4011337070575758]),
            {
              "LC04": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.694741621298476, -1.4018201471620109]),
            {
              "LC04": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.705985441488906, -1.4046517104644254]),
            {
              "LC04": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.725726499838515, -1.4168359739229337]),
            {
              "LC04": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72461070088832, -1.413403793492959]),
            {
              "LC04": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.732507124228164, -1.4194101059089683]),
            {
              "LC04": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73207797078578, -1.4092851702819345]),
            {
              "LC04": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.739201917929336, -1.4035362465424026]),
            {
              "LC04": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73293627767055, -1.4022491721250945]),
            {
              "LC04": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76010169057338, -1.391094497598037]),
            {
              "LC04": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.761947050375625, -1.3891209727560176]),
            {
              "LC04": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75259150533168, -1.3875764739036252]),
            {
              "LC04": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74222214502307, -1.3928239820346482]),
            {
              "LC04": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71707375329944, -1.3861740596606933]),
            {
              "LC04": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.708752053200946, -1.3912794856047188]),
            {
              "LC04": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.688474517777856, -1.388748225380696]),
            {
              "LC04": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6903198775801, -1.3798673418299734]),
            {
              "LC04": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69242272944778, -1.379996050524536]),
            {
              "LC04": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69504056544631, -1.3793525069820682]),
            {
              "LC04": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67956343078299, -1.3811871312311514]),
            {
              "LC04": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.670250801083284, -1.376811033901674]),
            {
              "LC04": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66656008147879, -1.3745800792287588]),
            {
              "LC04": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.681237129208284, -1.3875367483139007]),
            {
              "LC04": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66484346770926, -1.3792135981375135]),
            {
              "LC04": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77351611109248, -1.3948694461470723]),
            {
              "LC04": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.769224576668655, -1.4022486864490769]),
            {
              "LC04": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77527564020625, -1.3930675351113844]),
            {
              "LC04": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.754385756915745, -1.3978664000898855]),
            {
              "LC04": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74361400551194, -1.4042588746898201]),
            {
              "LC04": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72499985968602, -1.3929477338685556]),
            {
              "LC04": 2,
              "system:index": "30"
            })]),
    NonBuilt_Up04 = ui.import && ui.import("NonBuilt_Up04", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.7833911380167,
            -1.399815712491113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78424944490146,
            -1.401960838356433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.787768503129,
            -1.402647278218357
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.778412958085056,
            -1.4000731276986325
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77326311677646,
            -1.4004163479313527
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.817122598587986,
            -1.3842849428725308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.818410058915134,
            -1.3898623028443422
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81549181550693,
            -1.388317804476399
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81154360383701,
            -1.3896048865197992
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.80931200593662,
            -1.3900339137117776
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.792145868241306,
            -1.3894332756211945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79257502168369,
            -1.3905487462392518
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79652323335361,
            -1.3964693122235488
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.787768503129,
            -1.3957828705537212
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78605188935947,
            -1.3937235443423321
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.783219476639744,
            -1.3943241813401277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78459276765537,
            -1.4033337178789012
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7808162173624,
            -1.4023040583125597
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7449389895792,
            -1.3871165272703434
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74511065095615,
            -1.3880603879836046
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73644175142002,
            -1.384370748510052
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73755755037021,
            -1.385657832700263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73154940217685,
            -1.3814533550931016
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.731463571488376,
            -1.3837701089821381
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71266665071201,
            -1.381110132102497
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.713782449662204,
            -1.3835984976605067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.710005899369236,
            -1.3879745824797811
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7123233279581,
            -1.3913209948198912
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71833147615146,
            -1.3920074377904512
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69845035977484,
            -1.3948390129305468
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69759205289007,
            -1.3987002462653635
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69973782010199,
            -1.3997299074156593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68815067715765,
            -1.3976705846632633
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6908972591889,
            -1.3996441023370632
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68317249722601,
            -1.3951822339282414
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.685833248568784,
            -1.3794798222204234
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68763569302679,
            -1.3792224047684756
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68317249722601,
            -1.3611173077644974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68317249722601,
            -1.3647211768297007
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.683773312045346,
            -1.3618037594306938
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69184139676214,
            -1.358972145048571
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69269970364691,
            -1.3583714991465454
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69149807400824,
            -1.3597444038459536
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65879658169867,
            -1.366265690491023
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66016987271429,
            -1.365922465318736
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65974071927191,
            -1.368153428061787
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67338779873968,
            -1.3660940779110118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682829174472104,
            -1.366351496776436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.734241756869565,
            -1.3842849428725308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71194530730041,
            -1.4032156743298345
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.713318598316036,
            -1.4010705496139286
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.716837656543575,
            -1.4002124991774094
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71864010100158,
            -1.4003841092898446
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72396160368713,
            -1.4030440644249114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71426273588928,
            -1.4051033824525676
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69572330717834,
            -1.4080207465499945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.719069254443966,
            -1.4241519877956452
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71589351897033,
            -1.426468699370455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.698384058521114,
            -1.4167728169050102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70379139189514,
            -1.417201839113161
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.705078852222286,
            -1.4115387395753738
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69855571989807,
            -1.4256964624378337
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.703619730518184,
            -1.4362503447024666
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72868229155334,
            -1.4220926866628154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71651124383311,
            -1.39241157370486
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC04": 3
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.7833911380167, -1.399815712491113]),
            {
              "LC04": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78424944490146, -1.401960838356433]),
            {
              "LC04": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.787768503129, -1.402647278218357]),
            {
              "LC04": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.778412958085056, -1.4000731276986325]),
            {
              "LC04": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77326311677646, -1.4004163479313527]),
            {
              "LC04": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.817122598587986, -1.3842849428725308]),
            {
              "LC04": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.818410058915134, -1.3898623028443422]),
            {
              "LC04": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81549181550693, -1.388317804476399]),
            {
              "LC04": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81154360383701, -1.3896048865197992]),
            {
              "LC04": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.80931200593662, -1.3900339137117776]),
            {
              "LC04": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.792145868241306, -1.3894332756211945]),
            {
              "LC04": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79257502168369, -1.3905487462392518]),
            {
              "LC04": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79652323335361, -1.3964693122235488]),
            {
              "LC04": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.787768503129, -1.3957828705537212]),
            {
              "LC04": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78605188935947, -1.3937235443423321]),
            {
              "LC04": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.783219476639744, -1.3943241813401277]),
            {
              "LC04": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78459276765537, -1.4033337178789012]),
            {
              "LC04": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7808162173624, -1.4023040583125597]),
            {
              "LC04": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7449389895792, -1.3871165272703434]),
            {
              "LC04": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74511065095615, -1.3880603879836046]),
            {
              "LC04": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73644175142002, -1.384370748510052]),
            {
              "LC04": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73755755037021, -1.385657832700263]),
            {
              "LC04": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73154940217685, -1.3814533550931016]),
            {
              "LC04": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.731463571488376, -1.3837701089821381]),
            {
              "LC04": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71266665071201, -1.381110132102497]),
            {
              "LC04": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.713782449662204, -1.3835984976605067]),
            {
              "LC04": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.710005899369236, -1.3879745824797811]),
            {
              "LC04": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7123233279581, -1.3913209948198912]),
            {
              "LC04": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71833147615146, -1.3920074377904512]),
            {
              "LC04": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69845035977484, -1.3948390129305468]),
            {
              "LC04": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69759205289007, -1.3987002462653635]),
            {
              "LC04": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69973782010199, -1.3997299074156593]),
            {
              "LC04": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68815067715765, -1.3976705846632633]),
            {
              "LC04": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6908972591889, -1.3996441023370632]),
            {
              "LC04": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68317249722601, -1.3951822339282414]),
            {
              "LC04": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.685833248568784, -1.3794798222204234]),
            {
              "LC04": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68763569302679, -1.3792224047684756]),
            {
              "LC04": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68317249722601, -1.3611173077644974]),
            {
              "LC04": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68317249722601, -1.3647211768297007]),
            {
              "LC04": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.683773312045346, -1.3618037594306938]),
            {
              "LC04": 3,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69184139676214, -1.358972145048571]),
            {
              "LC04": 3,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69269970364691, -1.3583714991465454]),
            {
              "LC04": 3,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69149807400824, -1.3597444038459536]),
            {
              "LC04": 3,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65879658169867, -1.366265690491023]),
            {
              "LC04": 3,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66016987271429, -1.365922465318736]),
            {
              "LC04": 3,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65974071927191, -1.368153428061787]),
            {
              "LC04": 3,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67338779873968, -1.3660940779110118]),
            {
              "LC04": 3,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682829174472104, -1.366351496776436]),
            {
              "LC04": 3,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.734241756869565, -1.3842849428725308]),
            {
              "LC04": 3,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71194530730041, -1.4032156743298345]),
            {
              "LC04": 3,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.713318598316036, -1.4010705496139286]),
            {
              "LC04": 3,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.716837656543575, -1.4002124991774094]),
            {
              "LC04": 3,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71864010100158, -1.4003841092898446]),
            {
              "LC04": 3,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72396160368713, -1.4030440644249114]),
            {
              "LC04": 3,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71426273588928, -1.4051033824525676]),
            {
              "LC04": 3,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69572330717834, -1.4080207465499945]),
            {
              "LC04": 3,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.719069254443966, -1.4241519877956452]),
            {
              "LC04": 3,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71589351897033, -1.426468699370455]),
            {
              "LC04": 3,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.698384058521114, -1.4167728169050102]),
            {
              "LC04": 3,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70379139189514, -1.417201839113161]),
            {
              "LC04": 3,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.705078852222286, -1.4115387395753738]),
            {
              "LC04": 3,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69855571989807, -1.4256964624378337]),
            {
              "LC04": 3,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.703619730518184, -1.4362503447024666]),
            {
              "LC04": 3,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72868229155334, -1.4220926866628154]),
            {
              "LC04": 3,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71651124383311, -1.39241157370486]),
            {
              "LC04": 3,
              "system:index": "64"
            })]),
    Water04 = ui.import && ui.import("Water04", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.714568583065144,
            -1.3673524114490128
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.350345702945155,
            -0.7425500714034514
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37163171368734,
            -0.7442665406801644
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.34828576642172,
            -0.7676104558817575
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.34897241192953,
            -0.7851183088698714
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.370601745425624,
            -0.7765360370525027
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.369571777163905,
            -0.7576549779928194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.40661107081932,
            -0.7454372267723806
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.39253483790916,
            -0.7499000425726945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.38463841456932,
            -0.7900651767822053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.36506901759666,
            -0.8037967585274309
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.34927617091697,
            -0.8110058205108378
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.34103642482322,
            -0.7921249169563989
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.33689799518988,
            -0.8075791203608225
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37912669392035,
            -0.7993401844132799
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.57052158025915,
            -0.882401752230315
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.5458023419779,
            -0.8875509792473834
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.5351593366068,
            -0.8999090947591475
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.53447269109899,
            -0.9177596319867874
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.511126743833366,
            -0.9198193036593266
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.50048373846227,
            -0.9029986171175207
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.478167759458366,
            -0.8971628504657112
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.46752475408727,
            -0.8741629741950097
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.457225071470084,
            -0.8604316373842237
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.409503208677116,
            -0.8511629570491064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.3865005841654,
            -0.8556256577838601
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.35045169500524,
            -0.8453271098389229
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.340838657895866,
            -0.8415509687315081
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC04": 4
      },
      "color": "#00ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.714568583065144, -1.3673524114490128]),
            {
              "LC04": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.350345702945155, -0.7425500714034514]),
            {
              "LC04": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37163171368734, -0.7442665406801644]),
            {
              "LC04": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.34828576642172, -0.7676104558817575]),
            {
              "LC04": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.34897241192953, -0.7851183088698714]),
            {
              "LC04": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.370601745425624, -0.7765360370525027]),
            {
              "LC04": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.369571777163905, -0.7576549779928194]),
            {
              "LC04": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.40661107081932, -0.7454372267723806]),
            {
              "LC04": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.39253483790916, -0.7499000425726945]),
            {
              "LC04": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.38463841456932, -0.7900651767822053]),
            {
              "LC04": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.36506901759666, -0.8037967585274309]),
            {
              "LC04": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.34927617091697, -0.8110058205108378]),
            {
              "LC04": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.34103642482322, -0.7921249169563989]),
            {
              "LC04": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.33689799518988, -0.8075791203608225]),
            {
              "LC04": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37912669392035, -0.7993401844132799]),
            {
              "LC04": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([37.57052158025915, -0.882401752230315]),
            {
              "LC04": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([37.5458023419779, -0.8875509792473834]),
            {
              "LC04": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([37.5351593366068, -0.8999090947591475]),
            {
              "LC04": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([37.53447269109899, -0.9177596319867874]),
            {
              "LC04": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([37.511126743833366, -0.9198193036593266]),
            {
              "LC04": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([37.50048373846227, -0.9029986171175207]),
            {
              "LC04": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([37.478167759458366, -0.8971628504657112]),
            {
              "LC04": 4,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([37.46752475408727, -0.8741629741950097]),
            {
              "LC04": 4,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([37.457225071470084, -0.8604316373842237]),
            {
              "LC04": 4,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([37.409503208677116, -0.8511629570491064]),
            {
              "LC04": 4,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([37.3865005841654, -0.8556256577838601]),
            {
              "LC04": 4,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([37.35045169500524, -0.8453271098389229]),
            {
              "LC04": 4,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([37.340838657895866, -0.8415509687315081]),
            {
              "LC04": 4,
              "system:index": "27"
            })]),
    BuiltUp06 = ui.import && ui.import("BuiltUp06", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.74680944365487,
            -1.392251567761348
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74904104155526,
            -1.3939676741354232
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.750414332570884,
            -1.3937960635542759
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.752903422536704,
            -1.3966276365428283
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76261987339344,
            -1.3955121688027148
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76364984165516,
            -1.3955121688027148
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73142041813221,
            -1.3953405583341973
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73378901526584,
            -1.3950680137107263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74713568732395,
            -1.3931373948539834
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.748423147651096,
            -1.3966125076555613
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74833731696262,
            -1.396698312844968
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.739968824836154,
            -1.3957973581999954
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76305728003635,
            -1.3974276568283885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75430254981174,
            -1.3997443950375703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.744553277924425,
            -1.3857152232027203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72824544711388,
            -1.3798804360899102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72987623019493,
            -1.3793226983360527
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7226664523629,
            -1.37627658983665
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72245187564171,
            -1.3715143560798115
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65434522433556,
            -1.3624188923277047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65631933017052,
            -1.361131795621693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67751951022423,
            -1.3349606811698804
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67648954196251,
            -1.3345316441709416
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67425794406212,
            -1.3348748737760823
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682321124043256,
            -1.3899960229769626
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.689008164376524,
            -1.4258624188034172
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75565491432547,
            -1.396860278072286
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75917397255301,
            -1.3973751091074311
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.765010459369414,
            -1.3957877130535001
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75186834970897,
            -1.3939840960230503
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79807408421123,
            -1.3127312287747204
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79464085667217,
            -1.3154770884387683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78640111057842,
            -1.3077543504518927
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.786229449201464,
            -1.313760926502451
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.783482867170214,
            -1.3153054722982278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.751725512433886,
            -1.2817809306578174
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82926812153232,
            -1.3029382299466452
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83287301044834,
            -1.3037963147653169
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78995766621006,
            -1.3092880506706546
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82703652363193,
            -1.2821724886632302
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82325997333896,
            -1.2826873438006061
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83053239421291,
            -1.3044848136707987
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78899034099025,
            -1.3119501371830693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.85997232036037,
            -1.30439900522556
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.860830627245136,
            -1.3046564305524977
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.86117394999904,
            -1.3127224107599043
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84452279643459,
            -1.3111778633678328
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.86692460612697,
            -1.3151250381395632
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83719667127259,
            -1.3084342860830172
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82595285108216,
            -1.300539909269353
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68637074090483,
            -1.4305466997012253
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.685941587462445,
            -1.4284874042911166
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.731315646967104,
            -1.3987840790281865
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.733032260736636,
            -1.3992989096414374
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73440555175226,
            -1.3992131045470786
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.745048557123354,
            -1.398440858556594
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.720459713600135,
            -1.3980396501066579
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.710321851635946,
            -1.4085452707914574
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.711952634717,
            -1.4089742945190866
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.713583417798056,
            -1.409060099255137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71118015852071,
            -1.4088455874090888
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71229595747091,
            -1.410990704980184
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71122307386495,
            -1.4125351884066317
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.709120221997274,
            -1.4125780907093857
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.706330724621786,
            -1.4010373427926195
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70667404737569,
            -1.3962751588395272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.715128370190634,
            -1.398892216082048
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71753162946798,
            -1.4045553463443752
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71766037550069,
            -1.405113078128726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70839066114522,
            -1.4111623143004448
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71002144422628,
            -1.4145944980447611
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71375507917501,
            -1.4145944980447611
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70070881452657,
            -1.4168254147567383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70049423780538,
            -1.4176405568657573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70379871931173,
            -1.4200001771418589
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70165295209981,
            -1.4222310886421536
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.689979978467,
            -1.4259635703664708
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71229595747091,
            -1.4169112192027729
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71650166120626,
            -1.4139938662556581
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73263783063985,
            -1.4149377161401486
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70976395216085,
            -1.4054992000552766
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70714611616231,
            -1.406099834036316
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70542950239278,
            -1.405542102487606
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71324009504415,
            -1.4072152967339016
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71122307386495,
            -1.4054133951882255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72173733320333,
            -1.4062714437168191
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72598595228292,
            -1.4067862726825555
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71796078291036,
            -1.4067004678628185
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC06": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.74680944365487, -1.392251567761348]),
            {
              "LC06": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74904104155526, -1.3939676741354232]),
            {
              "LC06": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.750414332570884, -1.3937960635542759]),
            {
              "LC06": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.752903422536704, -1.3966276365428283]),
            {
              "LC06": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76261987339344, -1.3955121688027148]),
            {
              "LC06": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76364984165516, -1.3955121688027148]),
            {
              "LC06": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73142041813221, -1.3953405583341973]),
            {
              "LC06": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73378901526584, -1.3950680137107263]),
            {
              "LC06": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74713568732395, -1.3931373948539834]),
            {
              "LC06": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.748423147651096, -1.3966125076555613]),
            {
              "LC06": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74833731696262, -1.396698312844968]),
            {
              "LC06": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.739968824836154, -1.3957973581999954]),
            {
              "LC06": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76305728003635, -1.3974276568283885]),
            {
              "LC06": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75430254981174, -1.3997443950375703]),
            {
              "LC06": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.744553277924425, -1.3857152232027203]),
            {
              "LC06": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72824544711388, -1.3798804360899102]),
            {
              "LC06": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72987623019493, -1.3793226983360527]),
            {
              "LC06": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7226664523629, -1.37627658983665]),
            {
              "LC06": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72245187564171, -1.3715143560798115]),
            {
              "LC06": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65434522433556, -1.3624188923277047]),
            {
              "LC06": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65631933017052, -1.361131795621693]),
            {
              "LC06": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67751951022423, -1.3349606811698804]),
            {
              "LC06": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67648954196251, -1.3345316441709416]),
            {
              "LC06": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67425794406212, -1.3348748737760823]),
            {
              "LC06": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682321124043256, -1.3899960229769626]),
            {
              "LC06": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.689008164376524, -1.4258624188034172]),
            {
              "LC06": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75565491432547, -1.396860278072286]),
            {
              "LC06": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75917397255301, -1.3973751091074311]),
            {
              "LC06": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.765010459369414, -1.3957877130535001]),
            {
              "LC06": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75186834970897, -1.3939840960230503]),
            {
              "LC06": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79807408421123, -1.3127312287747204]),
            {
              "LC06": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79464085667217, -1.3154770884387683]),
            {
              "LC06": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78640111057842, -1.3077543504518927]),
            {
              "LC06": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.786229449201464, -1.313760926502451]),
            {
              "LC06": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.783482867170214, -1.3153054722982278]),
            {
              "LC06": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.751725512433886, -1.2817809306578174]),
            {
              "LC06": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82926812153232, -1.3029382299466452]),
            {
              "LC06": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83287301044834, -1.3037963147653169]),
            {
              "LC06": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78995766621006, -1.3092880506706546]),
            {
              "LC06": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82703652363193, -1.2821724886632302]),
            {
              "LC06": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82325997333896, -1.2826873438006061]),
            {
              "LC06": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83053239421291, -1.3044848136707987]),
            {
              "LC06": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78899034099025, -1.3119501371830693]),
            {
              "LC06": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.85997232036037, -1.30439900522556]),
            {
              "LC06": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.860830627245136, -1.3046564305524977]),
            {
              "LC06": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.86117394999904, -1.3127224107599043]),
            {
              "LC06": 0,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84452279643459, -1.3111778633678328]),
            {
              "LC06": 0,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.86692460612697, -1.3151250381395632]),
            {
              "LC06": 0,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83719667127259, -1.3084342860830172]),
            {
              "LC06": 0,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82595285108216, -1.300539909269353]),
            {
              "LC06": 0,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68637074090483, -1.4305466997012253]),
            {
              "LC06": 0,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.685941587462445, -1.4284874042911166]),
            {
              "LC06": 0,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.731315646967104, -1.3987840790281865]),
            {
              "LC06": 0,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.733032260736636, -1.3992989096414374]),
            {
              "LC06": 0,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73440555175226, -1.3992131045470786]),
            {
              "LC06": 0,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.745048557123354, -1.398440858556594]),
            {
              "LC06": 0,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.720459713600135, -1.3980396501066579]),
            {
              "LC06": 0,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.710321851635946, -1.4085452707914574]),
            {
              "LC06": 0,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.711952634717, -1.4089742945190866]),
            {
              "LC06": 0,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.713583417798056, -1.409060099255137]),
            {
              "LC06": 0,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71118015852071, -1.4088455874090888]),
            {
              "LC06": 0,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71229595747091, -1.410990704980184]),
            {
              "LC06": 0,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71122307386495, -1.4125351884066317]),
            {
              "LC06": 0,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.709120221997274, -1.4125780907093857]),
            {
              "LC06": 0,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.706330724621786, -1.4010373427926195]),
            {
              "LC06": 0,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70667404737569, -1.3962751588395272]),
            {
              "LC06": 0,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([36.715128370190634, -1.398892216082048]),
            {
              "LC06": 0,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71753162946798, -1.4045553463443752]),
            {
              "LC06": 0,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71766037550069, -1.405113078128726]),
            {
              "LC06": 0,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70839066114522, -1.4111623143004448]),
            {
              "LC06": 0,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71002144422628, -1.4145944980447611]),
            {
              "LC06": 0,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71375507917501, -1.4145944980447611]),
            {
              "LC06": 0,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70070881452657, -1.4168254147567383]),
            {
              "LC06": 0,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70049423780538, -1.4176405568657573]),
            {
              "LC06": 0,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70379871931173, -1.4200001771418589]),
            {
              "LC06": 0,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70165295209981, -1.4222310886421536]),
            {
              "LC06": 0,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([36.689979978467, -1.4259635703664708]),
            {
              "LC06": 0,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71229595747091, -1.4169112192027729]),
            {
              "LC06": 0,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71650166120626, -1.4139938662556581]),
            {
              "LC06": 0,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73263783063985, -1.4149377161401486]),
            {
              "LC06": 0,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70976395216085, -1.4054992000552766]),
            {
              "LC06": 0,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70714611616231, -1.406099834036316]),
            {
              "LC06": 0,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70542950239278, -1.405542102487606]),
            {
              "LC06": 0,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71324009504415, -1.4072152967339016]),
            {
              "LC06": 0,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71122307386495, -1.4054133951882255]),
            {
              "LC06": 0,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72173733320333, -1.4062714437168191]),
            {
              "LC06": 0,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72598595228292, -1.4067862726825555]),
            {
              "LC06": 0,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71796078291036, -1.4067004678628185]),
            {
              "LC06": 0,
              "system:index": "87"
            })]),
    ForestedAreas06 = ui.import && ui.import("ForestedAreas06", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.69770834320717,
            -1.3540547315855693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70217153900795,
            -1.3540547315855693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.703680210343734,
            -1.3541635443602063
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70410936378612,
            -1.356222904700092
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.706426792374984,
            -1.3572525842130532
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71028917335643,
            -1.3604274266165786
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71209161781444,
            -1.3604274266165786
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71269243263377,
            -1.3624009751947594
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7155248453535,
            -1.3641171030790789
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71397989296092,
            -1.3631732328940747
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71621149086131,
            -1.365490004505327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.699903660050765,
            -1.359998394103265
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70084779762401,
            -1.3616287172478827
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7045385172285,
            -1.363945490345701
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.707113437882796,
            -1.3648035538901768
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71123331092967,
            -1.364031296713923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70951669716014,
            -1.3627442008694726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70848672889842,
            -1.3702093471724317
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.706426792374984,
            -1.3680641925653678
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.710375004044906,
            -1.3698661225643114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70960252784862,
            -1.3753577103857075
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71269243263377,
            -1.3701235410250039
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69784372352733,
            -1.3649751665623353
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69853036903514,
            -1.367635161413688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6950113108076,
            -1.3698661225643114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6920930673994,
            -1.367291936437132
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68883150123729,
            -1.366948711411494
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.691663913957015,
            -1.3634306520721478
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.696899585954085,
            -1.3617145236986463
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69732873939647,
            -1.3590545223055543
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69183557533397,
            -1.3551074180666696
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64016030860802,
            -1.4070881450105726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64333604408165,
            -1.4056315445909746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64702676368614,
            -1.4039154467484192
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64934419227501,
            -1.404001251670481
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.639473663100205,
            -1.401856127674691
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.643679366835556,
            -1.3993677813775351
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64187692237755,
            -1.3968794324404172
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.640246139296494,
            -1.3916453105631432
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.642992721327744,
            -1.3869260103863408
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64213441444298,
            -1.3836653974920898
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.640932784804306,
            -1.3832363691457992
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.647713409193955,
            -1.3983381200682878
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64446162781423,
            -1.3321531235271797
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64240169129079,
            -1.323229128423128
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63999843201345,
            -1.3306085882199818
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.646864887091574,
            -1.3196251982101577
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.650126453253684,
            -1.3139618687590033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6456632574529,
            -1.311559240261087
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64240169129079,
            -1.3058958925396433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64720820984548,
            -1.3040081071273195
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.745741840216574,
            -1.3213413561065726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.749003406378684,
            -1.3204832773064772
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.749003406378684,
            -1.3218562032443573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7520548201989,
            -1.3215129718310203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.755659709114916,
            -1.3218562032443573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75960792078484,
            -1.3187671188178047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76407111658562,
            -1.3146483336198453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76836265100945,
            -1.314476717422322
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC06": 1
      },
      "color": "#98ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.69770834320717, -1.3540547315855693]),
            {
              "LC06": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70217153900795, -1.3540547315855693]),
            {
              "LC06": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.703680210343734, -1.3541635443602063]),
            {
              "LC06": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70410936378612, -1.356222904700092]),
            {
              "LC06": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.706426792374984, -1.3572525842130532]),
            {
              "LC06": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71028917335643, -1.3604274266165786]),
            {
              "LC06": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71209161781444, -1.3604274266165786]),
            {
              "LC06": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71269243263377, -1.3624009751947594]),
            {
              "LC06": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7155248453535, -1.3641171030790789]),
            {
              "LC06": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71397989296092, -1.3631732328940747]),
            {
              "LC06": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71621149086131, -1.365490004505327]),
            {
              "LC06": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.699903660050765, -1.359998394103265]),
            {
              "LC06": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70084779762401, -1.3616287172478827]),
            {
              "LC06": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7045385172285, -1.363945490345701]),
            {
              "LC06": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.707113437882796, -1.3648035538901768]),
            {
              "LC06": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71123331092967, -1.364031296713923]),
            {
              "LC06": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70951669716014, -1.3627442008694726]),
            {
              "LC06": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70848672889842, -1.3702093471724317]),
            {
              "LC06": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.706426792374984, -1.3680641925653678]),
            {
              "LC06": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.710375004044906, -1.3698661225643114]),
            {
              "LC06": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70960252784862, -1.3753577103857075]),
            {
              "LC06": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71269243263377, -1.3701235410250039]),
            {
              "LC06": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69784372352733, -1.3649751665623353]),
            {
              "LC06": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69853036903514, -1.367635161413688]),
            {
              "LC06": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6950113108076, -1.3698661225643114]),
            {
              "LC06": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6920930673994, -1.367291936437132]),
            {
              "LC06": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68883150123729, -1.366948711411494]),
            {
              "LC06": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.691663913957015, -1.3634306520721478]),
            {
              "LC06": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.696899585954085, -1.3617145236986463]),
            {
              "LC06": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69732873939647, -1.3590545223055543]),
            {
              "LC06": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69183557533397, -1.3551074180666696]),
            {
              "LC06": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64016030860802, -1.4070881450105726]),
            {
              "LC06": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64333604408165, -1.4056315445909746]),
            {
              "LC06": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64702676368614, -1.4039154467484192]),
            {
              "LC06": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64934419227501, -1.404001251670481]),
            {
              "LC06": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.639473663100205, -1.401856127674691]),
            {
              "LC06": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.643679366835556, -1.3993677813775351]),
            {
              "LC06": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64187692237755, -1.3968794324404172]),
            {
              "LC06": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.640246139296494, -1.3916453105631432]),
            {
              "LC06": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.642992721327744, -1.3869260103863408]),
            {
              "LC06": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64213441444298, -1.3836653974920898]),
            {
              "LC06": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.640932784804306, -1.3832363691457992]),
            {
              "LC06": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.647713409193955, -1.3983381200682878]),
            {
              "LC06": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64446162781423, -1.3321531235271797]),
            {
              "LC06": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64240169129079, -1.323229128423128]),
            {
              "LC06": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63999843201345, -1.3306085882199818]),
            {
              "LC06": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.646864887091574, -1.3196251982101577]),
            {
              "LC06": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.650126453253684, -1.3139618687590033]),
            {
              "LC06": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6456632574529, -1.311559240261087]),
            {
              "LC06": 1,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64240169129079, -1.3058958925396433]),
            {
              "LC06": 1,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64720820984548, -1.3040081071273195]),
            {
              "LC06": 1,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.745741840216574, -1.3213413561065726]),
            {
              "LC06": 1,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.749003406378684, -1.3204832773064772]),
            {
              "LC06": 1,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.749003406378684, -1.3218562032443573]),
            {
              "LC06": 1,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7520548201989, -1.3215129718310203]),
            {
              "LC06": 1,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.755659709114916, -1.3218562032443573]),
            {
              "LC06": 1,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75960792078484, -1.3187671188178047]),
            {
              "LC06": 1,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76407111658562, -1.3146483336198453]),
            {
              "LC06": 1,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76836265100945, -1.314476717422322]),
            {
              "LC06": 1,
              "system:index": "58"
            })]),
    Vegetation06 = ui.import && ui.import("Vegetation06", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.7171395122596,
            -1.375518626257365
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.717740327078936,
            -1.3786076386481705
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71731941274011,
            -1.3863520332928176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73002235463464,
            -1.3869955749370033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.724142952474,
            -1.3863949360745376
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72242644883397,
            -1.381546945225493
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71444812040345,
            -1.3821187040364207
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71706595640199,
            -1.3827622468298297
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71552100400941,
            -1.389669595142572
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72019877653138,
            -1.3906134548361475
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.732129242229625,
            -1.3925869784300027
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72386863609974,
            -1.3988066622781365
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70060910232644,
            -1.401478127968123
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.730392351227806,
            -1.4076989831369278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72996319778542,
            -1.4046958137438637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72429837234597,
            -1.4141343330858656
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71237207156737,
            -1.41397139947916
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70499063235839,
            -1.4037606352405552
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7192385266455,
            -1.4067638058364795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71202874881347,
            -1.403503220438442
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.670662818795634,
            -1.4167578155511034
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67169278705735,
            -1.4159855753712374
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.671606956368876,
            -1.4162429887931298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.665943488917264,
            -1.4267388066498128
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.748383413329144,
            -1.4153164505241367
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73954285241606,
            -1.41101784667362
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74954212762358,
            -1.4099452881476695
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72497109773932,
            -1.4204134381776194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71667139365995,
            -1.4162519251777335
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72469656303251,
            -1.41161847923215
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72074835136259,
            -1.423673999828656
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71225111320341,
            -1.427234871100104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.701565192488076,
            -1.4256903974900055
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69220964744413,
            -1.4230733703970186
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.699076102522255,
            -1.4214859918606284
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71366731956327,
            -1.4224298386895473
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6950600182191,
            -1.4169937378768354
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.693600896515,
            -1.416006986590693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68733525625621,
            -1.4155779641613282
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71047200205325,
            -1.4135990863474244
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69280257318372,
            -1.4112573557850496
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.707908774355595,
            -1.396927934661921
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71048369500989,
            -1.3973140579377266
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.697694922426884,
            -1.3964989087254858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.672646271699115,
            -1.3792425057878694
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66672395419423,
            -1.3804437869818444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66071580600087,
            -1.3807012043016085
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67281793307607,
            -1.3711767449494259
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66329072665517,
            -1.3624245056388293
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66955636691396,
            -1.3638832144042465
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67135881137197,
            -1.3625961184806257
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.667668091767474,
            -1.3622528927848065
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6840617532665,
            -1.363797408030745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67172493120973,
            -1.3554688238583772
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66726173540895,
            -1.351779134193916
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6674333967859,
            -1.344828773330497
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.660137788265395,
            -1.3460300716875975
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC06": 2
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.7171395122596, -1.375518626257365]),
            {
              "LC06": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.717740327078936, -1.3786076386481705]),
            {
              "LC06": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71731941274011, -1.3863520332928176]),
            {
              "LC06": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73002235463464, -1.3869955749370033]),
            {
              "LC06": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.724142952474, -1.3863949360745376]),
            {
              "LC06": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72242644883397, -1.381546945225493]),
            {
              "LC06": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71444812040345, -1.3821187040364207]),
            {
              "LC06": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71706595640199, -1.3827622468298297]),
            {
              "LC06": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71552100400941, -1.389669595142572]),
            {
              "LC06": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72019877653138, -1.3906134548361475]),
            {
              "LC06": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.732129242229625, -1.3925869784300027]),
            {
              "LC06": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72386863609974, -1.3988066622781365]),
            {
              "LC06": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70060910232644, -1.401478127968123]),
            {
              "LC06": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.730392351227806, -1.4076989831369278]),
            {
              "LC06": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72996319778542, -1.4046958137438637]),
            {
              "LC06": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72429837234597, -1.4141343330858656]),
            {
              "LC06": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71237207156737, -1.41397139947916]),
            {
              "LC06": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70499063235839, -1.4037606352405552]),
            {
              "LC06": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7192385266455, -1.4067638058364795]),
            {
              "LC06": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71202874881347, -1.403503220438442]),
            {
              "LC06": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.670662818795634, -1.4167578155511034]),
            {
              "LC06": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67169278705735, -1.4159855753712374]),
            {
              "LC06": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.671606956368876, -1.4162429887931298]),
            {
              "LC06": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.665943488917264, -1.4267388066498128]),
            {
              "LC06": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.748383413329144, -1.4153164505241367]),
            {
              "LC06": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73954285241606, -1.41101784667362]),
            {
              "LC06": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74954212762358, -1.4099452881476695]),
            {
              "LC06": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72497109773932, -1.4204134381776194]),
            {
              "LC06": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71667139365995, -1.4162519251777335]),
            {
              "LC06": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72469656303251, -1.41161847923215]),
            {
              "LC06": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72074835136259, -1.423673999828656]),
            {
              "LC06": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71225111320341, -1.427234871100104]),
            {
              "LC06": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.701565192488076, -1.4256903974900055]),
            {
              "LC06": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69220964744413, -1.4230733703970186]),
            {
              "LC06": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.699076102522255, -1.4214859918606284]),
            {
              "LC06": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71366731956327, -1.4224298386895473]),
            {
              "LC06": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6950600182191, -1.4169937378768354]),
            {
              "LC06": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.693600896515, -1.416006986590693]),
            {
              "LC06": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68733525625621, -1.4155779641613282]),
            {
              "LC06": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71047200205325, -1.4135990863474244]),
            {
              "LC06": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69280257318372, -1.4112573557850496]),
            {
              "LC06": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.707908774355595, -1.396927934661921]),
            {
              "LC06": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71048369500989, -1.3973140579377266]),
            {
              "LC06": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.697694922426884, -1.3964989087254858]),
            {
              "LC06": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.672646271699115, -1.3792425057878694]),
            {
              "LC06": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66672395419423, -1.3804437869818444]),
            {
              "LC06": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66071580600087, -1.3807012043016085]),
            {
              "LC06": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67281793307607, -1.3711767449494259]),
            {
              "LC06": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66329072665517, -1.3624245056388293]),
            {
              "LC06": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66955636691396, -1.3638832144042465]),
            {
              "LC06": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67135881137197, -1.3625961184806257]),
            {
              "LC06": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.667668091767474, -1.3622528927848065]),
            {
              "LC06": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6840617532665, -1.363797408030745]),
            {
              "LC06": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67172493120973, -1.3554688238583772]),
            {
              "LC06": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66726173540895, -1.351779134193916]),
            {
              "LC06": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6674333967859, -1.344828773330497]),
            {
              "LC06": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.660137788265395, -1.3460300716875975]),
            {
              "LC06": 2,
              "system:index": "56"
            })]),
    NonBuilt_Up06 = ui.import && ui.import("NonBuilt_Up06", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.81785466401823,
            -1.3858006104931442
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81579472749479,
            -1.3883747766194818
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.811932346513345,
            -1.3891470259110261
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.80909993379362,
            -1.3895760531861823
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.793478748490884,
            -1.3911205507312652
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.789187214067056,
            -1.396354673775103
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78652646272428,
            -1.3948101796609353
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78515317170866,
            -1.3994436589577262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.775711795976235,
            -1.396440478973924
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.745171148175984,
            -1.388188092759275
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74611528574923,
            -1.3869010099445773
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7427249735544,
            -1.3866864960740555
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.759064058387644,
            -1.4039029795501046
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76344142349995,
            -1.4032594425308653
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.771767000282175,
            -1.4048039310794183
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77232489975727,
            -1.4021010754500995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78212313037218,
            -1.405077192059271
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78654341082872,
            -1.4025459466998504
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.781436484864365,
            -1.39675410380593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.795426887086045,
            -1.3964537856364294
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.799932998231064,
            -1.3917773977656707
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7915645061046,
            -1.3888171107404579
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73387123910522,
            -1.383361491098378
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73537327615356,
            -1.383146976907447
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73211170999145,
            -1.382288919949849
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65251601100994,
            -1.3317716914536553
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.667193058739436,
            -1.3304845785657065
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.679209355126154,
            -1.3381214385170996
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.686781230644506,
            -1.3906103453226788
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73231441088132,
            -1.3831023600583228
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.785443607048315,
            -1.4027517794682194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.795142474846166,
            -1.3911680804195008
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79188090868406,
            -1.389966804662595
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81677180834226,
            -1.3861055570217835
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73439323429665,
            -1.3912784392756103
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.734509005435164,
            -1.3842423872016512
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7356677197296,
            -1.3841994843809375
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74592448700255,
            -1.38784622136673
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.759743227847274,
            -1.4040205044841203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7730040692169,
            -1.4042350167737159
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC06": 3
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.81785466401823, -1.3858006104931442]),
            {
              "LC06": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81579472749479, -1.3883747766194818]),
            {
              "LC06": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.811932346513345, -1.3891470259110261]),
            {
              "LC06": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.80909993379362, -1.3895760531861823]),
            {
              "LC06": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.793478748490884, -1.3911205507312652]),
            {
              "LC06": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.789187214067056, -1.396354673775103]),
            {
              "LC06": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78652646272428, -1.3948101796609353]),
            {
              "LC06": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78515317170866, -1.3994436589577262]),
            {
              "LC06": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.775711795976235, -1.396440478973924]),
            {
              "LC06": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.745171148175984, -1.388188092759275]),
            {
              "LC06": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74611528574923, -1.3869010099445773]),
            {
              "LC06": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7427249735544, -1.3866864960740555]),
            {
              "LC06": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.759064058387644, -1.4039029795501046]),
            {
              "LC06": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76344142349995, -1.4032594425308653]),
            {
              "LC06": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.771767000282175, -1.4048039310794183]),
            {
              "LC06": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77232489975727, -1.4021010754500995]),
            {
              "LC06": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78212313037218, -1.405077192059271]),
            {
              "LC06": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78654341082872, -1.4025459466998504]),
            {
              "LC06": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.781436484864365, -1.39675410380593]),
            {
              "LC06": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.795426887086045, -1.3964537856364294]),
            {
              "LC06": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.799932998231064, -1.3917773977656707]),
            {
              "LC06": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7915645061046, -1.3888171107404579]),
            {
              "LC06": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73387123910522, -1.383361491098378]),
            {
              "LC06": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73537327615356, -1.383146976907447]),
            {
              "LC06": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73211170999145, -1.382288919949849]),
            {
              "LC06": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65251601100994, -1.3317716914536553]),
            {
              "LC06": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.667193058739436, -1.3304845785657065]),
            {
              "LC06": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.679209355126154, -1.3381214385170996]),
            {
              "LC06": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.686781230644506, -1.3906103453226788]),
            {
              "LC06": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73231441088132, -1.3831023600583228]),
            {
              "LC06": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.785443607048315, -1.4027517794682194]),
            {
              "LC06": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.795142474846166, -1.3911680804195008]),
            {
              "LC06": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79188090868406, -1.389966804662595]),
            {
              "LC06": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81677180834226, -1.3861055570217835]),
            {
              "LC06": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73439323429665, -1.3912784392756103]),
            {
              "LC06": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.734509005435164, -1.3842423872016512]),
            {
              "LC06": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7356677197296, -1.3841994843809375]),
            {
              "LC06": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74592448700255, -1.38784622136673]),
            {
              "LC06": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.759743227847274, -1.4040205044841203]),
            {
              "LC06": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7730040692169, -1.4042350167737159]),
            {
              "LC06": 3,
              "system:index": "39"
            })]),
    Water06 = ui.import && ui.import("Water06", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.74095793400252,
            -1.4046851816220667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67471647098651,
            -1.387906421996242
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67475938633075,
            -1.3880565816302104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71478227856244,
            -1.3674430011897132
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.361327872365536,
            -0.7869146621393494
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.36544774541241,
            -0.795840202278064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37849401006085,
            -0.7738696076433779
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.36544774541241,
            -0.7601379280035925
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37368749150616,
            -0.7436598548690622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.38536046513897,
            -0.7402269151782443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.38398717412335,
            -0.7800488490258682
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37712071904522,
            -0.7930938842824609
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.60362382146131,
            -0.7062977461025151
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.606542064869515,
            -0.7033797235054259
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.846292981763106,
            -0.8213939151898382
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.844576367993575,
            -0.8232819958525188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83873988117717,
            -0.8167595316037451
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.839598188061935,
            -0.8220804900795777
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.833075055737716,
            -0.8215655589233318
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84200144733928,
            -0.8162445997637438
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.47349393569963,
            -0.9011009495645296
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.48791349136369,
            -0.9014442298436923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.47246396743791,
            -0.8794742272744634
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.53735196792619,
            -0.8887428380656966
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.55486142837541,
            -0.8818772026624387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.576490761871504,
            -0.8825637667742581
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.45804441177385,
            -0.8623100726205584
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.41879500313977,
            -0.8644803773956767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.40986861153821,
            -0.8541818532002721
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.51114882394055,
            -0.9073905904473867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.5358680622218,
            -0.9087637089889334
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC06": 4
      },
      "color": "#00ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.74095793400252, -1.4046851816220667]),
            {
              "LC06": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67471647098651, -1.387906421996242]),
            {
              "LC06": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67475938633075, -1.3880565816302104]),
            {
              "LC06": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71478227856244, -1.3674430011897132]),
            {
              "LC06": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.361327872365536, -0.7869146621393494]),
            {
              "LC06": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.36544774541241, -0.795840202278064]),
            {
              "LC06": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37849401006085, -0.7738696076433779]),
            {
              "LC06": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.36544774541241, -0.7601379280035925]),
            {
              "LC06": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37368749150616, -0.7436598548690622]),
            {
              "LC06": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.38536046513897, -0.7402269151782443]),
            {
              "LC06": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.38398717412335, -0.7800488490258682]),
            {
              "LC06": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37712071904522, -0.7930938842824609]),
            {
              "LC06": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.60362382146131, -0.7062977461025151]),
            {
              "LC06": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.606542064869515, -0.7033797235054259]),
            {
              "LC06": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.846292981763106, -0.8213939151898382]),
            {
              "LC06": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.844576367993575, -0.8232819958525188]),
            {
              "LC06": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83873988117717, -0.8167595316037451]),
            {
              "LC06": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.839598188061935, -0.8220804900795777]),
            {
              "LC06": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.833075055737716, -0.8215655589233318]),
            {
              "LC06": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84200144733928, -0.8162445997637438]),
            {
              "LC06": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([37.47349393569963, -0.9011009495645296]),
            {
              "LC06": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([37.48791349136369, -0.9014442298436923]),
            {
              "LC06": 4,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([37.47246396743791, -0.8794742272744634]),
            {
              "LC06": 4,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([37.53735196792619, -0.8887428380656966]),
            {
              "LC06": 4,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([37.55486142837541, -0.8818772026624387]),
            {
              "LC06": 4,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([37.576490761871504, -0.8825637667742581]),
            {
              "LC06": 4,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([37.45804441177385, -0.8623100726205584]),
            {
              "LC06": 4,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([37.41879500313977, -0.8644803773956767]),
            {
              "LC06": 4,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([37.40986861153821, -0.8541818532002721]),
            {
              "LC06": 4,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([37.51114882394055, -0.9073905904473867]),
            {
              "LC06": 4,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([37.5358680622218, -0.9087637089889334]),
            {
              "LC06": 4,
              "system:index": "30"
            })]),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.68556162354015,
            -1.3964756951222559
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([36.68556162354015, -1.3964756951222559]),
    BuiltUp08 = ui.import && ui.import("BuiltUp08", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.747680590543894,
            -1.392928209515391
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74974052706733,
            -1.3934430414110162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7645034054853,
            -1.3956739783245664
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76295845309272,
            -1.396961056350659
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75995437899604,
            -1.3965320304202666
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.754117892179636,
            -1.3970468615273306
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74896805087104,
            -1.396617835612612
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74029915133491,
            -1.3961030044115563
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7344626645185,
            -1.395159146916851
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75180046359077,
            -1.3934430414110162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.659420606731196,
            -1.387937911527927
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66251051151635,
            -1.3898256319217746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74652295111046,
            -1.3933239025747666
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.728354776373486,
            -1.3802664795478894
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.729384744635205,
            -1.3795800331744412
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72706731604634,
            -1.381639371700213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.724149072638134,
            -1.3830980687426782
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72577985571919,
            -1.3839561254077033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74820904773934,
            -1.3934768508817654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73645024341805,
            -1.3959652034211543
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75413136524422,
            -1.393734266783689
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.756277132456134,
            -1.3921897709502535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76383023304207,
            -1.3969090605922572
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.764516878549884,
            -1.397423891616703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.687631230749446,
            -1.429687446102459
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69020615140374,
            -1.4277139539662613
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68831787625726,
            -1.4254830477723786
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.691407781042415,
            -1.426169480677806
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.673604556563895,
            -1.3349101896781097
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67678029203753,
            -1.3354250339885723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67823941374163,
            -1.3374844101515648
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65566060690146,
            -1.3615779254862421
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65703389791709,
            -1.3590895370338618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65806386617881,
            -1.3609772802327444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65600392965537,
            -1.3629508283607115
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65471646932822,
            -1.3622643770212726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67682555034407,
            -1.3366202035465935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82517758678895,
            -1.282509834029533
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83084241222841,
            -1.2830246890990484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.8385671741913,
            -1.2984702928156564
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84972516369325,
            -1.2799355571291449
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82929745983583,
            -1.3036188064705045
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.838395512814344,
            -1.3079092264757946
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84646359753114,
            -1.3127144881723471
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79221860241395,
            -1.3127144881723471
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79530850719911,
            -1.3163184283861646
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7975401050995,
            -1.3137441859069734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.782433903927625,
            -1.3154603478548041
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74587003063661,
            -1.2880016160894516
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74964658092958,
            -1.289889413441705
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84217206310731,
            -1.2670641339681474
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84200040173036,
            -1.2716978537077097
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.85144177746278,
            -1.265347939366961
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84903851818544,
            -1.2727275680767385
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.8605398304413,
            -1.3048201248099742
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84303036999208,
            -1.3007013166893628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78681126903993,
            -1.3006155081152864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.825606740231336,
            -1.301301976626171
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82732335400087,
            -1.2841402080608117
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84431783031923,
            -1.3110841325587064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.86165562939149,
            -1.3047343163761729
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83118573498231,
            -1.3037904234112472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82929745983583,
            -1.2838827806512851
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC08": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.747680590543894, -1.392928209515391]),
            {
              "LC08": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74974052706733, -1.3934430414110162]),
            {
              "LC08": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7645034054853, -1.3956739783245664]),
            {
              "LC08": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76295845309272, -1.396961056350659]),
            {
              "LC08": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75995437899604, -1.3965320304202666]),
            {
              "LC08": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.754117892179636, -1.3970468615273306]),
            {
              "LC08": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74896805087104, -1.396617835612612]),
            {
              "LC08": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74029915133491, -1.3961030044115563]),
            {
              "LC08": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7344626645185, -1.395159146916851]),
            {
              "LC08": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75180046359077, -1.3934430414110162]),
            {
              "LC08": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.659420606731196, -1.387937911527927]),
            {
              "LC08": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66251051151635, -1.3898256319217746]),
            {
              "LC08": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74652295111046, -1.3933239025747666]),
            {
              "LC08": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.728354776373486, -1.3802664795478894]),
            {
              "LC08": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.729384744635205, -1.3795800331744412]),
            {
              "LC08": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72706731604634, -1.381639371700213]),
            {
              "LC08": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.724149072638134, -1.3830980687426782]),
            {
              "LC08": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72577985571919, -1.3839561254077033]),
            {
              "LC08": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74820904773934, -1.3934768508817654]),
            {
              "LC08": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73645024341805, -1.3959652034211543]),
            {
              "LC08": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75413136524422, -1.393734266783689]),
            {
              "LC08": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.756277132456134, -1.3921897709502535]),
            {
              "LC08": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76383023304207, -1.3969090605922572]),
            {
              "LC08": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.764516878549884, -1.397423891616703]),
            {
              "LC08": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.687631230749446, -1.429687446102459]),
            {
              "LC08": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69020615140374, -1.4277139539662613]),
            {
              "LC08": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68831787625726, -1.4254830477723786]),
            {
              "LC08": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.691407781042415, -1.426169480677806]),
            {
              "LC08": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.673604556563895, -1.3349101896781097]),
            {
              "LC08": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67678029203753, -1.3354250339885723]),
            {
              "LC08": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67823941374163, -1.3374844101515648]),
            {
              "LC08": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65566060690146, -1.3615779254862421]),
            {
              "LC08": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65703389791709, -1.3590895370338618]),
            {
              "LC08": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65806386617881, -1.3609772802327444]),
            {
              "LC08": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65600392965537, -1.3629508283607115]),
            {
              "LC08": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65471646932822, -1.3622643770212726]),
            {
              "LC08": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67682555034407, -1.3366202035465935]),
            {
              "LC08": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82517758678895, -1.282509834029533]),
            {
              "LC08": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83084241222841, -1.2830246890990484]),
            {
              "LC08": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.8385671741913, -1.2984702928156564]),
            {
              "LC08": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84972516369325, -1.2799355571291449]),
            {
              "LC08": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82929745983583, -1.3036188064705045]),
            {
              "LC08": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.838395512814344, -1.3079092264757946]),
            {
              "LC08": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84646359753114, -1.3127144881723471]),
            {
              "LC08": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79221860241395, -1.3127144881723471]),
            {
              "LC08": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79530850719911, -1.3163184283861646]),
            {
              "LC08": 0,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7975401050995, -1.3137441859069734]),
            {
              "LC08": 0,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.782433903927625, -1.3154603478548041]),
            {
              "LC08": 0,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74587003063661, -1.2880016160894516]),
            {
              "LC08": 0,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74964658092958, -1.289889413441705]),
            {
              "LC08": 0,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84217206310731, -1.2670641339681474]),
            {
              "LC08": 0,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84200040173036, -1.2716978537077097]),
            {
              "LC08": 0,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.85144177746278, -1.265347939366961]),
            {
              "LC08": 0,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84903851818544, -1.2727275680767385]),
            {
              "LC08": 0,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.8605398304413, -1.3048201248099742]),
            {
              "LC08": 0,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84303036999208, -1.3007013166893628]),
            {
              "LC08": 0,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78681126903993, -1.3006155081152864]),
            {
              "LC08": 0,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.825606740231336, -1.301301976626171]),
            {
              "LC08": 0,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82732335400087, -1.2841402080608117]),
            {
              "LC08": 0,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84431783031923, -1.3110841325587064]),
            {
              "LC08": 0,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.86165562939149, -1.3047343163761729]),
            {
              "LC08": 0,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83118573498231, -1.3037904234112472]),
            {
              "LC08": 0,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82929745983583, -1.2838827806512851]),
            {
              "LC08": 0,
              "system:index": "62"
            })]),
    ForestedAreas08 = ui.import && ui.import("ForestedAreas08", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.70243970226747,
            -1.3542452901347999
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70424214672548,
            -1.356390457045102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.711280263180555,
            -1.361024011077231
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71608678173524,
            -1.363769816674928
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.707503712887586,
            -1.3670304567528453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71067944836122,
            -1.3627401399425603
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.699263966793836,
            -1.367802712965213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69617406200868,
            -1.3628259463537453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.697032368893446,
            -1.3581923957802278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.698577321286024,
            -1.3547601303665444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69514409374696,
            -1.3705485108176616
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68999425243837,
            -1.3665156191399315
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69548741650087,
            -1.364027235789199
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70647374462587,
            -1.3590504613724466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71445599865419,
            -1.3639414294208243
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70724622082216,
            -1.3690039999126333
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.640185118212706,
            -1.4003045872349917
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.646193266406065,
            -1.4020206877263004
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64078593303204,
            -1.406053518926343
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64885401774884,
            -1.4069115672196137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.642931700243956,
            -1.4008194175143862
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63932681132794,
            -1.4018490777337465
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64765238811017,
            -1.4023639076736485
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64336085368634,
            -1.4051096654394546
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63941264201642,
            -1.4093141007611925
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68224215556622,
            -1.3458177515927592
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68370127727032,
            -1.3463325936094945
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73502802897931,
            -1.314927033190715
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74687266398907,
            -1.3190458179281428
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.762837172045714,
            -1.3178445064163573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75562739421368,
            -1.320418744659991
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.748074293627745,
            -1.3217916706335315
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73863291789532,
            -1.3171580424351548
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73365473796368,
            -1.3219632863268733
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72747492839337,
            -1.3150986493572854
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.750820875658995,
            -1.3216200549283326
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75785899211407,
            -1.3154418816550073
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.757344007983214,
            -1.3219632863268733
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7647254471922,
            -1.318187738336013
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76592707683087,
            -1.311837940176436
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC08": 1
      },
      "color": "#98ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.70243970226747, -1.3542452901347999]),
            {
              "LC08": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70424214672548, -1.356390457045102]),
            {
              "LC08": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.711280263180555, -1.361024011077231]),
            {
              "LC08": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71608678173524, -1.363769816674928]),
            {
              "LC08": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.707503712887586, -1.3670304567528453]),
            {
              "LC08": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71067944836122, -1.3627401399425603]),
            {
              "LC08": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.699263966793836, -1.367802712965213]),
            {
              "LC08": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69617406200868, -1.3628259463537453]),
            {
              "LC08": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.697032368893446, -1.3581923957802278]),
            {
              "LC08": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.698577321286024, -1.3547601303665444]),
            {
              "LC08": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69514409374696, -1.3705485108176616]),
            {
              "LC08": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68999425243837, -1.3665156191399315]),
            {
              "LC08": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69548741650087, -1.364027235789199]),
            {
              "LC08": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70647374462587, -1.3590504613724466]),
            {
              "LC08": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71445599865419, -1.3639414294208243]),
            {
              "LC08": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70724622082216, -1.3690039999126333]),
            {
              "LC08": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.640185118212706, -1.4003045872349917]),
            {
              "LC08": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.646193266406065, -1.4020206877263004]),
            {
              "LC08": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64078593303204, -1.406053518926343]),
            {
              "LC08": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64885401774884, -1.4069115672196137]),
            {
              "LC08": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.642931700243956, -1.4008194175143862]),
            {
              "LC08": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63932681132794, -1.4018490777337465]),
            {
              "LC08": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64765238811017, -1.4023639076736485]),
            {
              "LC08": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64336085368634, -1.4051096654394546]),
            {
              "LC08": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63941264201642, -1.4093141007611925]),
            {
              "LC08": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68224215556622, -1.3458177515927592]),
            {
              "LC08": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68370127727032, -1.3463325936094945]),
            {
              "LC08": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73502802897931, -1.314927033190715]),
            {
              "LC08": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74687266398907, -1.3190458179281428]),
            {
              "LC08": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.762837172045714, -1.3178445064163573]),
            {
              "LC08": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75562739421368, -1.320418744659991]),
            {
              "LC08": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.748074293627745, -1.3217916706335315]),
            {
              "LC08": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73863291789532, -1.3171580424351548]),
            {
              "LC08": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73365473796368, -1.3219632863268733]),
            {
              "LC08": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72747492839337, -1.3150986493572854]),
            {
              "LC08": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.750820875658995, -1.3216200549283326]),
            {
              "LC08": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75785899211407, -1.3154418816550073]),
            {
              "LC08": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.757344007983214, -1.3219632863268733]),
            {
              "LC08": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7647254471922, -1.318187738336013]),
            {
              "LC08": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76592707683087, -1.311837940176436]),
            {
              "LC08": 1,
              "system:index": "39"
            })]),
    Vegetation08 = ui.import && ui.import("Vegetation08", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.66594607028986,
            -1.3588586112232668
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.674166310927916,
            -1.3532257643837717
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67330800404315,
            -1.3560573854958082
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65983258595233,
            -1.3528825373575393
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.678457845351744,
            -1.3620638435464776
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70428697048454,
            -1.3769305278054556
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70497361599235,
            -1.378904062792236
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.710895933497234,
            -1.37744536317702
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7091793197277,
            -1.375300215062117
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6839292137917,
            -1.387976154840307
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68186927726826,
            -1.3883193768366828
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.740874850127945,
            -1.4047688372819618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.748599612090835,
            -1.405455276319524
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74009870569302,
            -1.3906967927090257
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74121450464322,
            -1.3915119439300285
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.729541531010405,
            -1.3859774906380886
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74288820306851,
            -1.3846475038089263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73859666864468,
            -1.3872216711891658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7416436580856,
            -1.387736504329304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.760998478337065,
            -1.3905032845077603
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.762028446598784,
            -1.3914042411779572
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74816675152592,
            -1.4004569246763126
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77335805859379,
            -1.3950082976496612
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77245683636479,
            -1.395952155204899
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79009504284672,
            -1.3998991917822792
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71705311044941,
            -1.4043170115270027
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70581729588986,
            -1.4043818661821572
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.706203533988,
            -1.4051112077736865
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69062526402951,
            -1.4085434004391533
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69075401006222,
            -1.4094014478161063
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69496280946194,
            -1.4163182622859267
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69397575654446,
            -1.4163182622859267
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68758137025296,
            -1.4155460219596026
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.686369830488324,
            -1.4253878550566987
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68830102097905,
            -1.4278761734674255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68971722733891,
            -1.4296351555467515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72547167393869,
            -1.4163849521943743
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.734870134326876,
            -1.4236354180349424
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.733411012622774,
            -1.4187874759385215
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73203772160715,
            -1.4188732803118231
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75812882031182,
            -1.407132353208011
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76263493145684,
            -1.398937979923564
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.763407407653126,
            -1.3994528105030375
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC08": 2
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.66594607028986, -1.3588586112232668]),
            {
              "LC08": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.674166310927916, -1.3532257643837717]),
            {
              "LC08": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67330800404315, -1.3560573854958082]),
            {
              "LC08": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65983258595233, -1.3528825373575393]),
            {
              "LC08": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.678457845351744, -1.3620638435464776]),
            {
              "LC08": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70428697048454, -1.3769305278054556]),
            {
              "LC08": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70497361599235, -1.378904062792236]),
            {
              "LC08": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.710895933497234, -1.37744536317702]),
            {
              "LC08": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7091793197277, -1.375300215062117]),
            {
              "LC08": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6839292137917, -1.387976154840307]),
            {
              "LC08": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68186927726826, -1.3883193768366828]),
            {
              "LC08": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.740874850127945, -1.4047688372819618]),
            {
              "LC08": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.748599612090835, -1.405455276319524]),
            {
              "LC08": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74009870569302, -1.3906967927090257]),
            {
              "LC08": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74121450464322, -1.3915119439300285]),
            {
              "LC08": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.729541531010405, -1.3859774906380886]),
            {
              "LC08": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74288820306851, -1.3846475038089263]),
            {
              "LC08": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73859666864468, -1.3872216711891658]),
            {
              "LC08": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7416436580856, -1.387736504329304]),
            {
              "LC08": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.760998478337065, -1.3905032845077603]),
            {
              "LC08": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.762028446598784, -1.3914042411779572]),
            {
              "LC08": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74816675152592, -1.4004569246763126]),
            {
              "LC08": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77335805859379, -1.3950082976496612]),
            {
              "LC08": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77245683636479, -1.395952155204899]),
            {
              "LC08": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79009504284672, -1.3998991917822792]),
            {
              "LC08": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71705311044941, -1.4043170115270027]),
            {
              "LC08": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70581729588986, -1.4043818661821572]),
            {
              "LC08": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.706203533988, -1.4051112077736865]),
            {
              "LC08": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69062526402951, -1.4085434004391533]),
            {
              "LC08": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69075401006222, -1.4094014478161063]),
            {
              "LC08": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69496280946194, -1.4163182622859267]),
            {
              "LC08": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69397575654446, -1.4163182622859267]),
            {
              "LC08": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68758137025296, -1.4155460219596026]),
            {
              "LC08": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.686369830488324, -1.4253878550566987]),
            {
              "LC08": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68830102097905, -1.4278761734674255]),
            {
              "LC08": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68971722733891, -1.4296351555467515]),
            {
              "LC08": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72547167393869, -1.4163849521943743]),
            {
              "LC08": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.734870134326876, -1.4236354180349424]),
            {
              "LC08": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.733411012622774, -1.4187874759385215]),
            {
              "LC08": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73203772160715, -1.4188732803118231]),
            {
              "LC08": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75812882031182, -1.407132353208011]),
            {
              "LC08": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76263493145684, -1.398937979923564]),
            {
              "LC08": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.763407407653126, -1.3994528105030375]),
            {
              "LC08": 2,
              "system:index": "42"
            })]),
    NonBuilt_Up08 = ui.import && ui.import("NonBuilt_Up08", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.77628201092461,
            -1.4013405216605797
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78023022259453,
            -1.4027134015469158
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78572338665703,
            -1.3994528105030375
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78349178875664,
            -1.402198571683894
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81748074139336,
            -1.384865900480833
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81748074139336,
            -1.3884697336967962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81198757733086,
            -1.3894993993214073
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77628201092461,
            -1.4028850114760876
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.723594892251434,
            -1.4035601220345446
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71243690274948,
            -1.4032169022626613
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71338104032272,
            -1.4015008026480915
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.714697975508265,
            -1.3837976601341917
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.715727943769984,
            -1.3860286061590132
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70911898075729,
            -1.381738323479477
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71315302311569,
            -1.3806228487125514
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7098056262651,
            -1.390318881065681
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71160807072311,
            -1.3928930422686854
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73229326664596,
            -1.3820815463793086
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73538317143112,
            -1.3843124940185922
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73255075871139,
            -1.3836260488145578
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74379457890182,
            -1.3873156894482623
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.746197838179164,
            -1.3866292451144275
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65916552006393,
            -1.3658642103770116
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65959467350631,
            -1.3680951731741955
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.683713096968226,
            -1.3612306656455115
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68354143559127,
            -1.3637190518879405
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692210335127406,
            -1.3572835649609347
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69212450443893,
            -1.359342922644841
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.722175127487674,
            -1.3713607470015095
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.710673815231814,
            -1.3823439031246396
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69340918671137,
            -1.4074309729263892
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69589827667719,
            -1.408460630232336
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68714354645258,
            -1.3899267294386037
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682852012028754,
            -1.390012534871539
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66817496429926,
            -1.3876099815713878
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.703654953971736,
            -1.409655806059167
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70537156774127,
            -1.4105138530261974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.717645356193415,
            -1.420896196194316
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71850366307818,
            -1.4251864070376663
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.728116700187556,
            -1.4226122814892017
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.718651140974636,
            -1.4006088413166238
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.718908633040066,
            -1.3927147639190798
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73555978660452,
            -1.3854212993405255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.690946505460886,
            -1.3895817994537922
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.697212145719675,
            -1.3919843507479421
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.698928759489206,
            -1.3980765234029582
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69661133090034,
            -1.3991061848269726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70030205050483,
            -1.3830605764915187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6945513943769,
            -1.3811728507068473
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.688199923429636,
            -1.3811728507068473
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69317810336128,
            -1.388895355777836
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692748949918894,
            -1.3908688808084115
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69412224093452,
            -1.389152772179692
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69300644198432,
            -1.392070156106058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69498079523661,
            -1.3997060784184685
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68923013910868,
            -1.3992770529897516
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692835028024696,
            -1.4084581799964677
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69952982172587,
            -1.408715594252149
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69214838251688,
            -1.3814295259113878
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.706310446115516,
            -1.382630805999993
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.700817282053016,
            -1.374050220633323
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69592493280985,
            -1.374050220633323
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70322054133036,
            -1.3692450793521378
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70425050959208,
            -1.3694166917068133
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70373552546122,
            -1.3738786086109518
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70176141962626,
            -1.3745650566264567
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70802705988505,
            -1.3831456401376292
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71377771601298,
            -1.3957385440680825
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69772737726786,
            -1.3989991402749171
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.690603430124305,
            -1.3993423606648332
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69403665766337,
            -1.4091241206172673
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.701074774118446,
            -1.4002004114198787
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70141809687235,
            -1.4094673395204014
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71197527155497,
            -1.3965107909470997
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC08": 3
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.77628201092461, -1.4013405216605797]),
            {
              "LC08": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78023022259453, -1.4027134015469158]),
            {
              "LC08": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78572338665703, -1.3994528105030375]),
            {
              "LC08": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78349178875664, -1.402198571683894]),
            {
              "LC08": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81748074139336, -1.384865900480833]),
            {
              "LC08": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81748074139336, -1.3884697336967962]),
            {
              "LC08": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81198757733086, -1.3894993993214073]),
            {
              "LC08": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77628201092461, -1.4028850114760876]),
            {
              "LC08": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.723594892251434, -1.4035601220345446]),
            {
              "LC08": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71243690274948, -1.4032169022626613]),
            {
              "LC08": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71338104032272, -1.4015008026480915]),
            {
              "LC08": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.714697975508265, -1.3837976601341917]),
            {
              "LC08": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.715727943769984, -1.3860286061590132]),
            {
              "LC08": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70911898075729, -1.381738323479477]),
            {
              "LC08": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71315302311569, -1.3806228487125514]),
            {
              "LC08": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7098056262651, -1.390318881065681]),
            {
              "LC08": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71160807072311, -1.3928930422686854]),
            {
              "LC08": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73229326664596, -1.3820815463793086]),
            {
              "LC08": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73538317143112, -1.3843124940185922]),
            {
              "LC08": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73255075871139, -1.3836260488145578]),
            {
              "LC08": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74379457890182, -1.3873156894482623]),
            {
              "LC08": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.746197838179164, -1.3866292451144275]),
            {
              "LC08": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65916552006393, -1.3658642103770116]),
            {
              "LC08": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65959467350631, -1.3680951731741955]),
            {
              "LC08": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.683713096968226, -1.3612306656455115]),
            {
              "LC08": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68354143559127, -1.3637190518879405]),
            {
              "LC08": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692210335127406, -1.3572835649609347]),
            {
              "LC08": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69212450443893, -1.359342922644841]),
            {
              "LC08": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.722175127487674, -1.3713607470015095]),
            {
              "LC08": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.710673815231814, -1.3823439031246396]),
            {
              "LC08": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69340918671137, -1.4074309729263892]),
            {
              "LC08": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69589827667719, -1.408460630232336]),
            {
              "LC08": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68714354645258, -1.3899267294386037]),
            {
              "LC08": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682852012028754, -1.390012534871539]),
            {
              "LC08": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66817496429926, -1.3876099815713878]),
            {
              "LC08": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.703654953971736, -1.409655806059167]),
            {
              "LC08": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70537156774127, -1.4105138530261974]),
            {
              "LC08": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.717645356193415, -1.420896196194316]),
            {
              "LC08": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71850366307818, -1.4251864070376663]),
            {
              "LC08": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.728116700187556, -1.4226122814892017]),
            {
              "LC08": 3,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.718651140974636, -1.4006088413166238]),
            {
              "LC08": 3,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.718908633040066, -1.3927147639190798]),
            {
              "LC08": 3,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73555978660452, -1.3854212993405255]),
            {
              "LC08": 3,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.690946505460886, -1.3895817994537922]),
            {
              "LC08": 3,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.697212145719675, -1.3919843507479421]),
            {
              "LC08": 3,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.698928759489206, -1.3980765234029582]),
            {
              "LC08": 3,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69661133090034, -1.3991061848269726]),
            {
              "LC08": 3,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70030205050483, -1.3830605764915187]),
            {
              "LC08": 3,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6945513943769, -1.3811728507068473]),
            {
              "LC08": 3,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.688199923429636, -1.3811728507068473]),
            {
              "LC08": 3,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69317810336128, -1.388895355777836]),
            {
              "LC08": 3,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692748949918894, -1.3908688808084115]),
            {
              "LC08": 3,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69412224093452, -1.389152772179692]),
            {
              "LC08": 3,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69300644198432, -1.392070156106058]),
            {
              "LC08": 3,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69498079523661, -1.3997060784184685]),
            {
              "LC08": 3,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68923013910868, -1.3992770529897516]),
            {
              "LC08": 3,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692835028024696, -1.4084581799964677]),
            {
              "LC08": 3,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69952982172587, -1.408715594252149]),
            {
              "LC08": 3,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69214838251688, -1.3814295259113878]),
            {
              "LC08": 3,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.706310446115516, -1.382630805999993]),
            {
              "LC08": 3,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.700817282053016, -1.374050220633323]),
            {
              "LC08": 3,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69592493280985, -1.374050220633323]),
            {
              "LC08": 3,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70322054133036, -1.3692450793521378]),
            {
              "LC08": 3,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70425050959208, -1.3694166917068133]),
            {
              "LC08": 3,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70373552546122, -1.3738786086109518]),
            {
              "LC08": 3,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70176141962626, -1.3745650566264567]),
            {
              "LC08": 3,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70802705988505, -1.3831456401376292]),
            {
              "LC08": 3,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71377771601298, -1.3957385440680825]),
            {
              "LC08": 3,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69772737726786, -1.3989991402749171]),
            {
              "LC08": 3,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([36.690603430124305, -1.3993423606648332]),
            {
              "LC08": 3,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69403665766337, -1.4091241206172673]),
            {
              "LC08": 3,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([36.701074774118446, -1.4002004114198787]),
            {
              "LC08": 3,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70141809687235, -1.4094673395204014]),
            {
              "LC08": 3,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71197527155497, -1.3965107909470997]),
            {
              "LC08": 3,
              "system:index": "73"
            })]),
    Water08 = ui.import && ui.import("Water08", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.328508048620556,
            -0.7458753727894085
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.34018102225337,
            -0.7747119448114567
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.364213615026806,
            -0.7455320791127825
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.377946525183056,
            -0.7826076389495487
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.33194127615962,
            -0.7980556930506078
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.32438817557368,
            -0.7784881482006332
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.31923833426509,
            -0.7561741705809614
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.343270927038525,
            -0.7506814814448366
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.35666051444087,
            -0.7640698990255593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.353227286901806,
            -0.7757328153828082
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.34464421805415,
            -0.8052557618270458
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.36009374197993,
            -0.805942339463258
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.3748566203979,
            -0.7949570834626115
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.384469657507275,
            -0.7420901373917684
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.41159215506587,
            -0.7444931944425589
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83827052273142,
            -0.8171345994684306
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.840416289943335,
            -0.8221122700481044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.844364501613256,
            -0.8227130229750061
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84693942226755,
            -0.8212540514242987
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84496531643259,
            -0.8184219286594276
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84230456508982,
            -0.8161047358185792
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83526644863474,
            -0.8167913116144715
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83698306240427,
            -0.8229704884874252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.842647887843725,
            -0.8229704884874252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.088381148952124,
            -1.0060239499093468
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.09001193203318,
            -1.0057664975249598
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.08726535000193,
            -1.005938132450149
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.0858920589863,
            -1.0028487024169552
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.08949694790232,
            -1.0062814022734419
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.51307826994084,
            -0.9124350023750009
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.539170799237716,
            -0.8938978770299361
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            37.55908351896428,
            -0.8849725609626219
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.781205309246474,
            -1.3913668800069725
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC08": 4
      },
      "color": "#00ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.328508048620556, -0.7458753727894085]),
            {
              "LC08": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.34018102225337, -0.7747119448114567]),
            {
              "LC08": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.364213615026806, -0.7455320791127825]),
            {
              "LC08": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.377946525183056, -0.7826076389495487]),
            {
              "LC08": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.33194127615962, -0.7980556930506078]),
            {
              "LC08": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.32438817557368, -0.7784881482006332]),
            {
              "LC08": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.31923833426509, -0.7561741705809614]),
            {
              "LC08": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.343270927038525, -0.7506814814448366]),
            {
              "LC08": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.35666051444087, -0.7640698990255593]),
            {
              "LC08": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.353227286901806, -0.7757328153828082]),
            {
              "LC08": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.34464421805415, -0.8052557618270458]),
            {
              "LC08": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.36009374197993, -0.805942339463258]),
            {
              "LC08": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.3748566203979, -0.7949570834626115]),
            {
              "LC08": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.384469657507275, -0.7420901373917684]),
            {
              "LC08": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.41159215506587, -0.7444931944425589]),
            {
              "LC08": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83827052273142, -0.8171345994684306]),
            {
              "LC08": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.840416289943335, -0.8221122700481044]),
            {
              "LC08": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.844364501613256, -0.8227130229750061]),
            {
              "LC08": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84693942226755, -0.8212540514242987]),
            {
              "LC08": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84496531643259, -0.8184219286594276]),
            {
              "LC08": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84230456508982, -0.8161047358185792]),
            {
              "LC08": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83526644863474, -0.8167913116144715]),
            {
              "LC08": 4,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83698306240427, -0.8229704884874252]),
            {
              "LC08": 4,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.842647887843725, -0.8229704884874252]),
            {
              "LC08": 4,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([37.088381148952124, -1.0060239499093468]),
            {
              "LC08": 4,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([37.09001193203318, -1.0057664975249598]),
            {
              "LC08": 4,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([37.08726535000193, -1.005938132450149]),
            {
              "LC08": 4,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([37.0858920589863, -1.0028487024169552]),
            {
              "LC08": 4,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([37.08949694790232, -1.0062814022734419]),
            {
              "LC08": 4,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([37.51307826994084, -0.9124350023750009]),
            {
              "LC08": 4,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([37.539170799237716, -0.8938978770299361]),
            {
              "LC08": 4,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([37.55908351896428, -0.8849725609626219]),
            {
              "LC08": 4,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.781205309246474, -1.3913668800069725]),
            {
              "LC08": 4,
              "system:index": "32"
            })]),
    BuiltUp10 = ui.import && ui.import("BuiltUp10", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.73823921481147,
            -1.3955929441282324
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74879638949409,
            -1.3926755645617581
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75008384982124,
            -1.393705228350922
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74819557467475,
            -1.3932762018267966
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76330177584663,
            -1.3953355284295974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.763645098600534,
            -1.3973090480655321
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75222961703315,
            -1.3937910336463684
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76424591341987,
            -1.3949923074542556
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74931137362495,
            -1.3942200600767056
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.740427330903344,
            -1.3958928515653923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.744890526704125,
            -1.3954638254400575
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.752615288667016,
            -1.3966650983937114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75484688656741,
            -1.3964934880093516
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.757850960664086,
            -1.3988960322495272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.731672600678735,
            -1.3982095912889125
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73064999493258,
            -1.3911866636127448
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74262337597506,
            -1.391508433798396
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7420011034836,
            -1.39127246899988
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74738697918551,
            -1.39189455796323
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74631409557955,
            -1.3920447173436066
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74732260616915,
            -1.3906718312244137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72889046581881,
            -1.3956270882944122
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.731980370603964,
            -1.3953267699809473
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73043092570002,
            -1.3954400879236344
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.735022867533516,
            -1.3950539643400148
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73536619028742,
            -1.3952470261397443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7343362220257,
            -1.3953971853063618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73036655268366,
            -1.4000306634451254
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73249086222346,
            -1.398464720467513
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73324188074763,
            -1.398336012779036
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73339208445246,
            -1.399623089346119
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73639615854914,
            -1.400717103872743
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.738820875498604,
            -1.4008887139482329
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74332698664362,
            -1.402047081628915
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74545129618342,
            -1.40159660537673
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.752054717301974,
            -1.3984686982268515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73604171330786,
            -1.4050935512398324
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72557036931372,
            -1.3920940758029232
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72045945393149,
            -1.3979420510461538
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72801255451743,
            -1.3792130131024942
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72818421589438,
            -1.3800710711707418
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72887086140219,
            -1.3823878264081044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.718099109998384,
            -1.3704608031677932
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.722562305799165,
            -1.3712759613293388
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.722304813733736,
            -1.373292404009506
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71947240101401,
            -1.3717049918291704
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72221898304526,
            -1.374450785205497
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72118901478354,
            -1.3791701101909568
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.719858639112154,
            -1.377368187208342
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.723077289930025,
            -1.3773252842635615
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7242789195687,
            -1.376467225205958
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6888820517941,
            -1.3745222711055285
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67253372425627,
            -1.3667486600325827
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69010707631289,
            -1.3556065938810542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68285438313662,
            -1.3589530515477326
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65590354695498,
            -1.3626856334745852
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6543585945624,
            -1.3619133756189394
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65667602315127,
            -1.3594678907775133
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65762016072451,
            -1.3610982142806303
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.657534330036036,
            -1.3541907834751772
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6495629546772,
            -1.3719372672325874
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.651923298610306,
            -1.3718943641902273
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.658231854213334,
            -1.3693845348741334
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67149269558296,
            -1.372838230944329
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.673423886073685,
            -1.3618550311761262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66329381584591,
            -1.3463013859143804
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66629788994259,
            -1.3438987888760046
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.666469551319544,
            -1.3406381176871354
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.676683403248255,
            -1.3350177400551497
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.678185440296595,
            -1.3376348640657063
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.679429985279505,
            -1.337463249461946
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67432305931515,
            -1.3349319326633362
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67179105400509,
            -1.335875813808468
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67749879478878,
            -1.3349748363596181
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.671222838534696,
            -1.351984033803139
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67317548669754,
            -1.3526919397536796
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71436948209643,
            -1.406793548585257
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.681667175654056,
            -1.3909578881884392
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6826113132273,
            -1.3912153043654298
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC10": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.73823921481147, -1.3955929441282324]),
            {
              "LC10": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74879638949409, -1.3926755645617581]),
            {
              "LC10": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75008384982124, -1.393705228350922]),
            {
              "LC10": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74819557467475, -1.3932762018267966]),
            {
              "LC10": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76330177584663, -1.3953355284295974]),
            {
              "LC10": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.763645098600534, -1.3973090480655321]),
            {
              "LC10": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75222961703315, -1.3937910336463684]),
            {
              "LC10": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76424591341987, -1.3949923074542556]),
            {
              "LC10": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74931137362495, -1.3942200600767056]),
            {
              "LC10": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.740427330903344, -1.3958928515653923]),
            {
              "LC10": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.744890526704125, -1.3954638254400575]),
            {
              "LC10": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.752615288667016, -1.3966650983937114]),
            {
              "LC10": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75484688656741, -1.3964934880093516]),
            {
              "LC10": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.757850960664086, -1.3988960322495272]),
            {
              "LC10": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.731672600678735, -1.3982095912889125]),
            {
              "LC10": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73064999493258, -1.3911866636127448]),
            {
              "LC10": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74262337597506, -1.391508433798396]),
            {
              "LC10": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7420011034836, -1.39127246899988]),
            {
              "LC10": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74738697918551, -1.39189455796323]),
            {
              "LC10": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74631409557955, -1.3920447173436066]),
            {
              "LC10": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74732260616915, -1.3906718312244137]),
            {
              "LC10": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72889046581881, -1.3956270882944122]),
            {
              "LC10": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.731980370603964, -1.3953267699809473]),
            {
              "LC10": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73043092570002, -1.3954400879236344]),
            {
              "LC10": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.735022867533516, -1.3950539643400148]),
            {
              "LC10": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73536619028742, -1.3952470261397443]),
            {
              "LC10": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7343362220257, -1.3953971853063618]),
            {
              "LC10": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73036655268366, -1.4000306634451254]),
            {
              "LC10": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73249086222346, -1.398464720467513]),
            {
              "LC10": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73324188074763, -1.398336012779036]),
            {
              "LC10": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73339208445246, -1.399623089346119]),
            {
              "LC10": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73639615854914, -1.400717103872743]),
            {
              "LC10": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.738820875498604, -1.4008887139482329]),
            {
              "LC10": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74332698664362, -1.402047081628915]),
            {
              "LC10": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74545129618342, -1.40159660537673]),
            {
              "LC10": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.752054717301974, -1.3984686982268515]),
            {
              "LC10": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73604171330786, -1.4050935512398324]),
            {
              "LC10": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72557036931372, -1.3920940758029232]),
            {
              "LC10": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72045945393149, -1.3979420510461538]),
            {
              "LC10": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72801255451743, -1.3792130131024942]),
            {
              "LC10": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72818421589438, -1.3800710711707418]),
            {
              "LC10": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72887086140219, -1.3823878264081044]),
            {
              "LC10": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.718099109998384, -1.3704608031677932]),
            {
              "LC10": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.722562305799165, -1.3712759613293388]),
            {
              "LC10": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.722304813733736, -1.373292404009506]),
            {
              "LC10": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71947240101401, -1.3717049918291704]),
            {
              "LC10": 0,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72221898304526, -1.374450785205497]),
            {
              "LC10": 0,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72118901478354, -1.3791701101909568]),
            {
              "LC10": 0,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.719858639112154, -1.377368187208342]),
            {
              "LC10": 0,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.723077289930025, -1.3773252842635615]),
            {
              "LC10": 0,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7242789195687, -1.376467225205958]),
            {
              "LC10": 0,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6888820517941, -1.3745222711055285]),
            {
              "LC10": 0,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67253372425627, -1.3667486600325827]),
            {
              "LC10": 0,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69010707631289, -1.3556065938810542]),
            {
              "LC10": 0,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68285438313662, -1.3589530515477326]),
            {
              "LC10": 0,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65590354695498, -1.3626856334745852]),
            {
              "LC10": 0,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6543585945624, -1.3619133756189394]),
            {
              "LC10": 0,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65667602315127, -1.3594678907775133]),
            {
              "LC10": 0,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65762016072451, -1.3610982142806303]),
            {
              "LC10": 0,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.657534330036036, -1.3541907834751772]),
            {
              "LC10": 0,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6495629546772, -1.3719372672325874]),
            {
              "LC10": 0,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.651923298610306, -1.3718943641902273]),
            {
              "LC10": 0,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.658231854213334, -1.3693845348741334]),
            {
              "LC10": 0,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67149269558296, -1.372838230944329]),
            {
              "LC10": 0,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.673423886073685, -1.3618550311761262]),
            {
              "LC10": 0,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66329381584591, -1.3463013859143804]),
            {
              "LC10": 0,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66629788994259, -1.3438987888760046]),
            {
              "LC10": 0,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([36.666469551319544, -1.3406381176871354]),
            {
              "LC10": 0,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([36.676683403248255, -1.3350177400551497]),
            {
              "LC10": 0,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([36.678185440296595, -1.3376348640657063]),
            {
              "LC10": 0,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([36.679429985279505, -1.337463249461946]),
            {
              "LC10": 0,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67432305931515, -1.3349319326633362]),
            {
              "LC10": 0,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67179105400509, -1.335875813808468]),
            {
              "LC10": 0,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67749879478878, -1.3349748363596181]),
            {
              "LC10": 0,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([36.671222838534696, -1.351984033803139]),
            {
              "LC10": 0,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67317548669754, -1.3526919397536796]),
            {
              "LC10": 0,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71436948209643, -1.406793548585257]),
            {
              "LC10": 0,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([36.681667175654056, -1.3909578881884392]),
            {
              "LC10": 0,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6826113132273, -1.3912153043654298]),
            {
              "LC10": 0,
              "system:index": "78"
            })]),
    ForestedAreas10 = ui.import && ui.import("ForestedAreas10", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.70807034143663,
            -1.3706924195682444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.709701124517686,
            -1.3693195211176212
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70686871179796,
            -1.367260171967512
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69727927736799,
            -1.365887271552489
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69719344667951,
            -1.3600095327927313
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71126967958967,
            -1.3613395333294736
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70448905520002,
            -1.3570921096942465
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7019999652342,
            -1.3557621068192496
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69976836733381,
            -1.3669598500687856
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69436103395979,
            -1.3642998544698501
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69122821383039,
            -1.3641282417495126
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69808147365491,
            -1.3541449712862277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.703445891684694,
            -1.354831424932663
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71031234676282,
            -1.359550788481216
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70979736263196,
            -1.3623824021840867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70799491817395,
            -1.3645275618648607
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.705677489585085,
            -1.364184336444414
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70683620387952,
            -1.3624682086080067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69657943660657,
            -1.3575343342737771
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69812438899915,
            -1.3619533700186242
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70057056362073,
            -1.3632833694828326
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.694376507757035,
            -1.370214393646093
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64577763094242,
            -1.399704799853781
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.646893429892614,
            -1.397473866766591
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65071289552982,
            -1.4030511955038032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6487817050391,
            -1.4036518301140708
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6453055621558,
            -1.394599392165109
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64393227114017,
            -1.394041657880308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6421727420264,
            -1.4081136823845672
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64818089021976,
            -1.4078562680623998
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69162647942142,
            -1.367317675620301
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69969456413822,
            -1.3595092942532752
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69789211968021,
            -1.3569350970515062
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70896427849369,
            -1.3659447752381397
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70922177055912,
            -1.3704925047453287
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70664684990482,
            -1.3709215353855753
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.708792617116735,
            -1.3668028380689625
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.706303527150915,
            -1.363971229564721
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70690434197025,
            -1.3576215499067212
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70870678642826,
            -1.3589086484848456
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.708020140920446,
            -1.3604531658731673
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70235531548099,
            -1.3572783235034704
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC10": 1
      },
      "color": "#98ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.70807034143663, -1.3706924195682444]),
            {
              "LC10": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.709701124517686, -1.3693195211176212]),
            {
              "LC10": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70686871179796, -1.367260171967512]),
            {
              "LC10": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69727927736799, -1.365887271552489]),
            {
              "LC10": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69719344667951, -1.3600095327927313]),
            {
              "LC10": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71126967958967, -1.3613395333294736]),
            {
              "LC10": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70448905520002, -1.3570921096942465]),
            {
              "LC10": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7019999652342, -1.3557621068192496]),
            {
              "LC10": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69976836733381, -1.3669598500687856]),
            {
              "LC10": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69436103395979, -1.3642998544698501]),
            {
              "LC10": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69122821383039, -1.3641282417495126]),
            {
              "LC10": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69808147365491, -1.3541449712862277]),
            {
              "LC10": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.703445891684694, -1.354831424932663]),
            {
              "LC10": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71031234676282, -1.359550788481216]),
            {
              "LC10": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70979736263196, -1.3623824021840867]),
            {
              "LC10": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70799491817395, -1.3645275618648607]),
            {
              "LC10": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.705677489585085, -1.364184336444414]),
            {
              "LC10": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70683620387952, -1.3624682086080067]),
            {
              "LC10": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69657943660657, -1.3575343342737771]),
            {
              "LC10": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69812438899915, -1.3619533700186242]),
            {
              "LC10": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70057056362073, -1.3632833694828326]),
            {
              "LC10": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.694376507757035, -1.370214393646093]),
            {
              "LC10": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64577763094242, -1.399704799853781]),
            {
              "LC10": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.646893429892614, -1.397473866766591]),
            {
              "LC10": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65071289552982, -1.4030511955038032]),
            {
              "LC10": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6487817050391, -1.4036518301140708]),
            {
              "LC10": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6453055621558, -1.394599392165109]),
            {
              "LC10": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64393227114017, -1.394041657880308]),
            {
              "LC10": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6421727420264, -1.4081136823845672]),
            {
              "LC10": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64818089021976, -1.4078562680623998]),
            {
              "LC10": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69162647942142, -1.367317675620301]),
            {
              "LC10": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69969456413822, -1.3595092942532752]),
            {
              "LC10": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69789211968021, -1.3569350970515062]),
            {
              "LC10": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70896427849369, -1.3659447752381397]),
            {
              "LC10": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70922177055912, -1.3704925047453287]),
            {
              "LC10": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70664684990482, -1.3709215353855753]),
            {
              "LC10": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.708792617116735, -1.3668028380689625]),
            {
              "LC10": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.706303527150915, -1.363971229564721]),
            {
              "LC10": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70690434197025, -1.3576215499067212]),
            {
              "LC10": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70870678642826, -1.3589086484848456]),
            {
              "LC10": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.708020140920446, -1.3604531658731673]),
            {
              "LC10": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70235531548099, -1.3572783235034704]),
            {
              "LC10": 1,
              "system:index": "41"
            })]),
    Vegetation10 = ui.import && ui.import("Vegetation10", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.72970630618815,
            -1.3803736339521306
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.740263480870766,
            -1.3868090587621276
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73022129031901,
            -1.3860368087072628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.721037406652016,
            -1.383548445706928
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.717432517736,
            -1.3829478059707894
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.720779914586586,
            -1.3844923078421516
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71794750186686,
            -1.383548445706928
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68095447513346,
            -1.3875813085650033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68327190372233,
            -1.3870664753910877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65949680301432,
            -1.3880961416268616
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65801478697263,
            -1.3860414238948342
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69470063351958,
            -1.3875452673771358
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6928123583731,
            -1.386773017562492
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69195405148833,
            -1.3847994891139652
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68191186093657,
            -1.3719286112062201
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.675646220677784,
            -1.3733015081602524
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66045418881743,
            -1.3739021503297062
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65822259091704,
            -1.3734731202240724
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72404422541235,
            -1.3945973803457783
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.740867040353756,
            -1.3917658049152344
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.749364278512935,
            -1.4063526721408872
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75228252192114,
            -1.408326182490455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76069392939184,
            -1.391165167265387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.764127156930904,
            -1.3899638915070054
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.768075368600826,
            -1.3998314956523064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76292552729223,
            -1.3987160294340628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77348270197485,
            -1.3950264066291358
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77614345331762,
            -1.3929670797559497
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71750340218511,
            -1.40131634694483
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71449932808843,
            -1.4009731268439374
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69772417407247,
            -1.395570300303359
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69051439624044,
            -1.4092990967426804
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.672833274414266,
            -1.3760066270999025
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68364794116231,
            -1.382613675143446
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68115885119649,
            -1.3820130351707758
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69678003649923,
            -1.3753201794989511
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.683819602539266,
            -1.3681124677866765
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66776926379415,
            -1.3587595715146932
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66879923205587,
            -1.3572150530434308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.663649390747274,
            -1.3384233329662816
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66442186694356,
            -1.3379942965722715
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.673863242675985,
            -1.3424562713977202
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67592317919942,
            -1.3419414285636968
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66433603625509,
            -1.3219482817630361
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66416437487813,
            -1.322377320947067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67882643613784,
            -1.3479551850889298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.675221547221824,
            -1.350529391824882
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.659708913614885,
            -1.353277728963094
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65241330509438,
            -1.386162704795223
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.652499135782854,
            -1.3883936485918114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6985854367353,
            -1.41551098976935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68768493929878,
            -1.4161116211655909
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.693693087492136,
            -1.4153393807704142
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69377891818061,
            -1.417999318825826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.725192950163034,
            -1.4113923702930475
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72879783907905,
            -1.4075311579087355
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72484962740913,
            -1.4041847686699611
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71257583895698,
            -1.404098963754642
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72047226229682,
            -1.4265797433025218
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72982780734077,
            -1.4242630318394385
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73334686556831,
            -1.4230617731266035
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.730686114225534,
            -1.4214314924442484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.704679415617136,
            -1.438163265549714
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69034569064155,
            -1.4308699435527037
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69257728854194,
            -1.4104485189682492
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69652550021186,
            -1.409847886107681
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.694208071622995,
            -1.4073595483209136
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.698242113981394,
            -1.3980068067277138
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71849815646186,
            -1.388997249773596
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67232124606147,
            -1.394660403883188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.674209521207956,
            -1.3945745986194327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7165240506269,
            -1.3903701368667638
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70084147663799,
            -1.4151313632307412
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69530539723125,
            -1.4122998126623005
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71229987354961,
            -1.411484668676996
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71036868305889,
            -1.4088676255304138
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70616297932354,
            -1.409039235007209
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6986098787376,
            -1.4080953827284477
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69182925434795,
            -1.4150455587188182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69088511677471,
            -1.4252991753646274
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68809561939922,
            -1.4235401899702345
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.725431968886525,
            -1.41633262606429
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72487406941143,
            -1.4153887767474778
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72676234455791,
            -1.4084815041614271
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72804980488506,
            -1.4079237731821512
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.728908111769826,
            -1.4085244065389113
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC10": 2
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.72970630618815, -1.3803736339521306]),
            {
              "LC10": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.740263480870766, -1.3868090587621276]),
            {
              "LC10": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73022129031901, -1.3860368087072628]),
            {
              "LC10": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.721037406652016, -1.383548445706928]),
            {
              "LC10": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.717432517736, -1.3829478059707894]),
            {
              "LC10": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.720779914586586, -1.3844923078421516]),
            {
              "LC10": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71794750186686, -1.383548445706928]),
            {
              "LC10": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68095447513346, -1.3875813085650033]),
            {
              "LC10": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68327190372233, -1.3870664753910877]),
            {
              "LC10": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65949680301432, -1.3880961416268616]),
            {
              "LC10": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65801478697263, -1.3860414238948342]),
            {
              "LC10": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69470063351958, -1.3875452673771358]),
            {
              "LC10": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6928123583731, -1.386773017562492]),
            {
              "LC10": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69195405148833, -1.3847994891139652]),
            {
              "LC10": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68191186093657, -1.3719286112062201]),
            {
              "LC10": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.675646220677784, -1.3733015081602524]),
            {
              "LC10": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66045418881743, -1.3739021503297062]),
            {
              "LC10": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65822259091704, -1.3734731202240724]),
            {
              "LC10": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72404422541235, -1.3945973803457783]),
            {
              "LC10": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.740867040353756, -1.3917658049152344]),
            {
              "LC10": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.749364278512935, -1.4063526721408872]),
            {
              "LC10": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75228252192114, -1.408326182490455]),
            {
              "LC10": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76069392939184, -1.391165167265387]),
            {
              "LC10": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.764127156930904, -1.3899638915070054]),
            {
              "LC10": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.768075368600826, -1.3998314956523064]),
            {
              "LC10": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76292552729223, -1.3987160294340628]),
            {
              "LC10": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77348270197485, -1.3950264066291358]),
            {
              "LC10": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77614345331762, -1.3929670797559497]),
            {
              "LC10": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71750340218511, -1.40131634694483]),
            {
              "LC10": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71449932808843, -1.4009731268439374]),
            {
              "LC10": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69772417407247, -1.395570300303359]),
            {
              "LC10": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69051439624044, -1.4092990967426804]),
            {
              "LC10": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.672833274414266, -1.3760066270999025]),
            {
              "LC10": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68364794116231, -1.382613675143446]),
            {
              "LC10": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68115885119649, -1.3820130351707758]),
            {
              "LC10": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69678003649923, -1.3753201794989511]),
            {
              "LC10": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.683819602539266, -1.3681124677866765]),
            {
              "LC10": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66776926379415, -1.3587595715146932]),
            {
              "LC10": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66879923205587, -1.3572150530434308]),
            {
              "LC10": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.663649390747274, -1.3384233329662816]),
            {
              "LC10": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66442186694356, -1.3379942965722715]),
            {
              "LC10": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.673863242675985, -1.3424562713977202]),
            {
              "LC10": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67592317919942, -1.3419414285636968]),
            {
              "LC10": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66433603625509, -1.3219482817630361]),
            {
              "LC10": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66416437487813, -1.322377320947067]),
            {
              "LC10": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67882643613784, -1.3479551850889298]),
            {
              "LC10": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.675221547221824, -1.350529391824882]),
            {
              "LC10": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.659708913614885, -1.353277728963094]),
            {
              "LC10": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65241330509438, -1.386162704795223]),
            {
              "LC10": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.652499135782854, -1.3883936485918114]),
            {
              "LC10": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6985854367353, -1.41551098976935]),
            {
              "LC10": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68768493929878, -1.4161116211655909]),
            {
              "LC10": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.693693087492136, -1.4153393807704142]),
            {
              "LC10": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69377891818061, -1.417999318825826]),
            {
              "LC10": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.725192950163034, -1.4113923702930475]),
            {
              "LC10": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72879783907905, -1.4075311579087355]),
            {
              "LC10": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72484962740913, -1.4041847686699611]),
            {
              "LC10": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71257583895698, -1.404098963754642]),
            {
              "LC10": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72047226229682, -1.4265797433025218]),
            {
              "LC10": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72982780734077, -1.4242630318394385]),
            {
              "LC10": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73334686556831, -1.4230617731266035]),
            {
              "LC10": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.730686114225534, -1.4214314924442484]),
            {
              "LC10": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.704679415617136, -1.438163265549714]),
            {
              "LC10": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69034569064155, -1.4308699435527037]),
            {
              "LC10": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69257728854194, -1.4104485189682492]),
            {
              "LC10": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69652550021186, -1.409847886107681]),
            {
              "LC10": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([36.694208071622995, -1.4073595483209136]),
            {
              "LC10": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([36.698242113981394, -1.3980068067277138]),
            {
              "LC10": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71849815646186, -1.388997249773596]),
            {
              "LC10": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67232124606147, -1.394660403883188]),
            {
              "LC10": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([36.674209521207956, -1.3945745986194327]),
            {
              "LC10": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7165240506269, -1.3903701368667638]),
            {
              "LC10": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70084147663799, -1.4151313632307412]),
            {
              "LC10": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69530539723125, -1.4122998126623005]),
            {
              "LC10": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71229987354961, -1.411484668676996]),
            {
              "LC10": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71036868305889, -1.4088676255304138]),
            {
              "LC10": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70616297932354, -1.409039235007209]),
            {
              "LC10": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6986098787376, -1.4080953827284477]),
            {
              "LC10": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69182925434795, -1.4150455587188182]),
            {
              "LC10": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69088511677471, -1.4252991753646274]),
            {
              "LC10": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68809561939922, -1.4235401899702345]),
            {
              "LC10": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([36.725431968886525, -1.41633262606429]),
            {
              "LC10": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72487406941143, -1.4153887767474778]),
            {
              "LC10": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72676234455791, -1.4084815041614271]),
            {
              "LC10": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72804980488506, -1.4079237731821512]),
            {
              "LC10": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([36.728908111769826, -1.4085244065389113]),
            {
              "LC10": 2,
              "system:index": "85"
            })]),
    NonBuilt_Up10 = ui.import && ui.import("NonBuilt_Up10", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.780883270842054,
            -1.4017544844681613
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78002496395729,
            -1.403556388835104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77830835018776,
            -1.4005532141197123
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7821707311692,
            -1.3974642303974343
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78671975765846,
            -1.4022693144288643
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78345819149635,
            -1.3992661380630702
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.783887344938734,
            -1.4001241888460156
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79092546139381,
            -1.3938604109206278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81796212826393,
            -1.3878540328762645
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.817790466886976,
            -1.3900849750770414
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74520744375645,
            -1.3876614784134407
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71027435354649,
            -1.389291782669431
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7124201207584,
            -1.3914369181340722
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.691938295188585,
            -1.3589181785972935
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68910588246886,
            -1.3558291408709273
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.722074136463775,
            -1.373876272617898
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.691163399971956,
            -1.3986458568607312
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66258178070926,
            -1.3649242056653614
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.659393290195965,
            -1.322192673277751
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68254441831661,
            -1.3590846234450982
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68657846067501,
            -1.3510187949821844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68996812209632,
            -1.3554777098689232
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68833733901526,
            -1.3559925498387047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77432501653043,
            -1.400016788319232
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78719961980192,
            -1.3960697519395677
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7876287732443,
            -1.3916936821210741
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79286444524137,
            -1.3886904922515864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79492438176481,
            -1.3929807623235058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81166136601774,
            -1.3887762977294311
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77621329167692,
            -1.4025051339270727
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7916628156027,
            -1.3977858555286604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79741347173063,
            -1.3947826734255908
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73263140260279,
            -1.3811395980247896
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7318589264065,
            -1.3837137692132215
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79861575629733,
            -1.39367525014273
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79502235209226,
            -1.396889396785243
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7780278757739,
            -1.4034963864076326
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC10": 3
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.780883270842054, -1.4017544844681613]),
            {
              "LC10": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78002496395729, -1.403556388835104]),
            {
              "LC10": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77830835018776, -1.4005532141197123]),
            {
              "LC10": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7821707311692, -1.3974642303974343]),
            {
              "LC10": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78671975765846, -1.4022693144288643]),
            {
              "LC10": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78345819149635, -1.3992661380630702]),
            {
              "LC10": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.783887344938734, -1.4001241888460156]),
            {
              "LC10": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79092546139381, -1.3938604109206278]),
            {
              "LC10": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81796212826393, -1.3878540328762645]),
            {
              "LC10": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.817790466886976, -1.3900849750770414]),
            {
              "LC10": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74520744375645, -1.3876614784134407]),
            {
              "LC10": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71027435354649, -1.389291782669431]),
            {
              "LC10": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7124201207584, -1.3914369181340722]),
            {
              "LC10": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.691938295188585, -1.3589181785972935]),
            {
              "LC10": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68910588246886, -1.3558291408709273]),
            {
              "LC10": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.722074136463775, -1.373876272617898]),
            {
              "LC10": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.691163399971956, -1.3986458568607312]),
            {
              "LC10": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66258178070926, -1.3649242056653614]),
            {
              "LC10": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.659393290195965, -1.322192673277751]),
            {
              "LC10": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68254441831661, -1.3590846234450982]),
            {
              "LC10": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68657846067501, -1.3510187949821844]),
            {
              "LC10": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68996812209632, -1.3554777098689232]),
            {
              "LC10": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68833733901526, -1.3559925498387047]),
            {
              "LC10": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77432501653043, -1.400016788319232]),
            {
              "LC10": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78719961980192, -1.3960697519395677]),
            {
              "LC10": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7876287732443, -1.3916936821210741]),
            {
              "LC10": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79286444524137, -1.3886904922515864]),
            {
              "LC10": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79492438176481, -1.3929807623235058]),
            {
              "LC10": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81166136601774, -1.3887762977294311]),
            {
              "LC10": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77621329167692, -1.4025051339270727]),
            {
              "LC10": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7916628156027, -1.3977858555286604]),
            {
              "LC10": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79741347173063, -1.3947826734255908]),
            {
              "LC10": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73263140260279, -1.3811395980247896]),
            {
              "LC10": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7318589264065, -1.3837137692132215]),
            {
              "LC10": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79861575629733, -1.39367525014273]),
            {
              "LC10": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79502235209226, -1.396889396785243]),
            {
              "LC10": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7780278757739, -1.4034963864076326]),
            {
              "LC10": 3,
              "system:index": "36"
            })]),
    Water10 = ui.import && ui.import("Water10", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.73429227562362,
            -1.389111915612801
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.734742886738125,
            -1.38979835922582
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.734013325886075,
            -1.389283526534751
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.714882862820645,
            -1.3674224876863201
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.714861405148525,
            -1.3676799064093448
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC10": 4
      },
      "color": "#00ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.73429227562362, -1.389111915612801]),
            {
              "LC10": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.734742886738125, -1.38979835922582]),
            {
              "LC10": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.734013325886075, -1.389283526534751]),
            {
              "LC10": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.714882862820645, -1.3674224876863201]),
            {
              "LC10": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.714861405148525, -1.3676799064093448]),
            {
              "LC10": 4,
              "system:index": "4"
            })]),
    BuiltUp12 = ui.import && ui.import("BuiltUp12", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.7470285481459,
            -1.39271350995111
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75003262224258,
            -1.3933141472064796
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.747886855030664,
            -1.3926277046164286
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76290722551406,
            -1.3959741103527148
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75449581804336,
            -1.3965747467759113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75003262224258,
            -1.3941722001627617
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.751835066700586,
            -1.3939147843086992
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76299305620254,
            -1.3970037726985047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74574108781875,
            -1.3964031363849483
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72784111863338,
            -1.3791714561734039
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72835610276424,
            -1.3803727374032682
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73848412400447,
            -1.3958177275368853
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.747925499736894,
            -1.39332937484156
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682569943716686,
            -1.391377005564408
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.643263717785096,
            -1.4076476679709444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6461819611933,
            -1.4063176934014847
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65685137355946,
            -1.3592953532044807
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.653761468774306,
            -1.361955354332022
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65762384975575,
            -1.3604108379053854
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67736490810536,
            -1.3364707075477635
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.673245035058486,
            -1.3350119823419955
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69017579075283,
            -1.3553672587127608
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72756423814728,
            -1.3841809770628408
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72687759263947,
            -1.383580337486862
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72215690477326,
            -1.3733265384640656
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72091235979035,
            -1.3746565316223025
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.723444365100406,
            -1.3744420166468687
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.725718878345035,
            -1.374356210651306
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74872150285675,
            -1.3902712045406247
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74232711656525,
            -1.3912579666870888
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75451507432892,
            -1.3943469585628332
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.769406698779605,
            -1.3913008693797406
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.758162878589175,
            -1.402755860328024
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7589782701297,
            -1.4043861541171652
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75944058435785,
            -1.390615605814338
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.764998121436705,
            -1.3903152868621413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75740210550653,
            -1.388255955875391
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76210133570062,
            -1.3869259703262877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.773259325202574,
            -1.3910875355191776
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77559821146356,
            -1.391967040626275
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75014963550158,
            -1.386625650905277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72088665699454,
            -1.3886777219114117
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.747150847668365,
            -1.3934184699137548
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67565700585797,
            -1.3339154062730536
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.658173692568155,
            -1.3692752611153587
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.666413438661905,
            -1.366314946101799
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.665426385744425,
            -1.3758394248318417
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7046245471277,
            -1.42037160837041
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.703058137063,
            -1.4203501572912764
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.703744782570816,
            -1.420028391080479
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69595564759157,
            -1.4244473097879746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.701259852451585,
            -1.4212555218647265
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC12": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.7470285481459, -1.39271350995111]),
            {
              "LC12": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75003262224258, -1.3933141472064796]),
            {
              "LC12": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.747886855030664, -1.3926277046164286]),
            {
              "LC12": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76290722551406, -1.3959741103527148]),
            {
              "LC12": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75449581804336, -1.3965747467759113]),
            {
              "LC12": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75003262224258, -1.3941722001627617]),
            {
              "LC12": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.751835066700586, -1.3939147843086992]),
            {
              "LC12": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76299305620254, -1.3970037726985047]),
            {
              "LC12": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74574108781875, -1.3964031363849483]),
            {
              "LC12": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72784111863338, -1.3791714561734039]),
            {
              "LC12": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72835610276424, -1.3803727374032682]),
            {
              "LC12": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73848412400447, -1.3958177275368853]),
            {
              "LC12": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.747925499736894, -1.39332937484156]),
            {
              "LC12": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682569943716686, -1.391377005564408]),
            {
              "LC12": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.643263717785096, -1.4076476679709444]),
            {
              "LC12": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6461819611933, -1.4063176934014847]),
            {
              "LC12": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65685137355946, -1.3592953532044807]),
            {
              "LC12": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.653761468774306, -1.361955354332022]),
            {
              "LC12": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65762384975575, -1.3604108379053854]),
            {
              "LC12": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67736490810536, -1.3364707075477635]),
            {
              "LC12": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.673245035058486, -1.3350119823419955]),
            {
              "LC12": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69017579075283, -1.3553672587127608]),
            {
              "LC12": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72756423814728, -1.3841809770628408]),
            {
              "LC12": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72687759263947, -1.383580337486862]),
            {
              "LC12": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72215690477326, -1.3733265384640656]),
            {
              "LC12": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72091235979035, -1.3746565316223025]),
            {
              "LC12": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.723444365100406, -1.3744420166468687]),
            {
              "LC12": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.725718878345035, -1.374356210651306]),
            {
              "LC12": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74872150285675, -1.3902712045406247]),
            {
              "LC12": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74232711656525, -1.3912579666870888]),
            {
              "LC12": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75451507432892, -1.3943469585628332]),
            {
              "LC12": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.769406698779605, -1.3913008693797406]),
            {
              "LC12": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.758162878589175, -1.402755860328024]),
            {
              "LC12": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7589782701297, -1.4043861541171652]),
            {
              "LC12": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75944058435785, -1.390615605814338]),
            {
              "LC12": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.764998121436705, -1.3903152868621413]),
            {
              "LC12": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75740210550653, -1.388255955875391]),
            {
              "LC12": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76210133570062, -1.3869259703262877]),
            {
              "LC12": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.773259325202574, -1.3910875355191776]),
            {
              "LC12": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77559821146356, -1.391967040626275]),
            {
              "LC12": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75014963550158, -1.386625650905277]),
            {
              "LC12": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72088665699454, -1.3886777219114117]),
            {
              "LC12": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.747150847668365, -1.3934184699137548]),
            {
              "LC12": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67565700585797, -1.3339154062730536]),
            {
              "LC12": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.658173692568155, -1.3692752611153587]),
            {
              "LC12": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.666413438661905, -1.366314946101799]),
            {
              "LC12": 0,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.665426385744425, -1.3758394248318417]),
            {
              "LC12": 0,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7046245471277, -1.42037160837041]),
            {
              "LC12": 0,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.703058137063, -1.4203501572912764]),
            {
              "LC12": 0,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.703744782570816, -1.420028391080479]),
            {
              "LC12": 0,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69595564759157, -1.4244473097879746]),
            {
              "LC12": 0,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.701259852451585, -1.4212555218647265]),
            {
              "LC12": 0,
              "system:index": "51"
            })]),
    ForestedAreas12 = ui.import && ui.import("ForestedAreas12", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.6959368153076,
            -1.363810371858208
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69937004284666,
            -1.366225945241934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69181694226072,
            -1.36614013895203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68967117504881,
            -1.3648530442359388
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692761079833964,
            -1.368199489063303
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69645179943846,
            -1.3648530442359388
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6973959370117,
            -1.3659685263630494
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.703747407958964,
            -1.3636517552127103
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.706751482055644,
            -1.3651962695609434
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70786728100584,
            -1.367942070396027
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69816841320799,
            -1.3559562391843467
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69919838146971,
            -1.3590452767483392
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.711214677856425,
            -1.3603323745677358
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7124163074951,
            -1.3608472135032772
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71439041333006,
            -1.3642794702630783
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71602119641111,
            -1.3646226956699503
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70254577832029,
            -1.3560420458366176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70460571484373,
            -1.3548407524280912
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.707865168143314,
            -1.3699849283770464
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70992510466675,
            -1.3682688046842657
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66507723156086,
            -1.3673791369098731
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64831567405681,
            -1.4025310853085677
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.650718933334154,
            -1.4012440103384667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64127755760173,
            -1.4025310853085677
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.639475113143725,
            -1.408966449527802
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63904595970134,
            -1.4022736703711538
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69465763827566,
            -1.3558026329232016
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.706673934662376,
            -1.3711619760180382
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70778973361257,
            -1.3590632837765837
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68435795565847,
            -1.3461064610577504
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68658955355886,
            -1.3483374420804415
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC12": 1
      },
      "color": "#98ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.6959368153076, -1.363810371858208]),
            {
              "LC12": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69937004284666, -1.366225945241934]),
            {
              "LC12": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69181694226072, -1.36614013895203]),
            {
              "LC12": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68967117504881, -1.3648530442359388]),
            {
              "LC12": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692761079833964, -1.368199489063303]),
            {
              "LC12": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69645179943846, -1.3648530442359388]),
            {
              "LC12": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6973959370117, -1.3659685263630494]),
            {
              "LC12": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.703747407958964, -1.3636517552127103]),
            {
              "LC12": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.706751482055644, -1.3651962695609434]),
            {
              "LC12": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70786728100584, -1.367942070396027]),
            {
              "LC12": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69816841320799, -1.3559562391843467]),
            {
              "LC12": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69919838146971, -1.3590452767483392]),
            {
              "LC12": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.711214677856425, -1.3603323745677358]),
            {
              "LC12": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7124163074951, -1.3608472135032772]),
            {
              "LC12": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71439041333006, -1.3642794702630783]),
            {
              "LC12": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71602119641111, -1.3646226956699503]),
            {
              "LC12": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70254577832029, -1.3560420458366176]),
            {
              "LC12": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70460571484373, -1.3548407524280912]),
            {
              "LC12": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.707865168143314, -1.3699849283770464]),
            {
              "LC12": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70992510466675, -1.3682688046842657]),
            {
              "LC12": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66507723156086, -1.3673791369098731]),
            {
              "LC12": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64831567405681, -1.4025310853085677]),
            {
              "LC12": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.650718933334154, -1.4012440103384667]),
            {
              "LC12": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64127755760173, -1.4025310853085677]),
            {
              "LC12": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.639475113143725, -1.408966449527802]),
            {
              "LC12": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63904595970134, -1.4022736703711538]),
            {
              "LC12": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69465763827566, -1.3558026329232016]),
            {
              "LC12": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.706673934662376, -1.3711619760180382]),
            {
              "LC12": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70778973361257, -1.3590632837765837]),
            {
              "LC12": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68435795565847, -1.3461064610577504]),
            {
              "LC12": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68658955355886, -1.3483374420804415]),
            {
              "LC12": 1,
              "system:index": "30"
            })]),
    Vegetation12 = ui.import && ui.import("Vegetation12", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.66007393681039,
            -1.3880742712178515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64033287846078,
            -1.3835265752559347
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64419525944223,
            -1.3879884657145243
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64016121708383,
            -1.3891897424775923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64919660045296,
            -1.36709132759099
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68115849510322,
            -1.3875387319112793
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70313115135322,
            -1.3923438362120024
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71729321495185,
            -1.3858226208651727
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72973866478095,
            -1.3859084264470216
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.704504442368844,
            -1.378614940910622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6980671407331,
            -1.3717504635223245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65017361656318,
            -1.3738956148263444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65240521446357,
            -1.3746678688244098
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67034382835517,
            -1.37149304523655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67532200828681,
            -1.3729517484897096
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67746777549873,
            -1.3625691942474127
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66047329918037,
            -1.349784004022858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65935750023017,
            -1.3527872426901715
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67396754758965,
            -1.353473696721034
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67339836432809,
            -1.3557272322345018
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6758767434206,
            -1.342604131447322
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.674331791028024,
            -1.34208928864443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74059138572895,
            -1.404561618278262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70237195467421,
            -1.396373647048939
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.689583182091205,
            -1.409072782193987
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.698080420250385,
            -1.4083005394600085
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65433501284219,
            -1.400334910760789
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65811156313516,
            -1.3864344507874182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66377638857461,
            -1.3876786310982745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67227362673379,
            -1.3943714518709667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69523333590127,
            -1.3980610757041163
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69394587557412,
            -1.3940711333972526
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68905352633096,
            -1.3965165827112596
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68974017183877,
            -1.3936421069397789
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.705824826062546,
            -1.4047838734418616
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.708167388433026,
            -1.3993241179341795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70786698102336,
            -1.3882981377812247
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74876530408244,
            -1.4054290002725793
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7492802882133,
            -1.4063728536303628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72537644147258,
            -1.4062870487954353
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72902424573283,
            -1.4077457305602081
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.740042213443104,
            -1.390724691637737
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75789499664623,
            -1.3905530808205162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75747658233995,
            -1.3946824729412974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.729923774421685,
            -1.38635934789731
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC12": 2
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.66007393681039, -1.3880742712178515]),
            {
              "LC12": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64033287846078, -1.3835265752559347]),
            {
              "LC12": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64419525944223, -1.3879884657145243]),
            {
              "LC12": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64016121708383, -1.3891897424775923]),
            {
              "LC12": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64919660045296, -1.36709132759099]),
            {
              "LC12": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68115849510322, -1.3875387319112793]),
            {
              "LC12": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70313115135322, -1.3923438362120024]),
            {
              "LC12": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71729321495185, -1.3858226208651727]),
            {
              "LC12": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72973866478095, -1.3859084264470216]),
            {
              "LC12": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.704504442368844, -1.378614940910622]),
            {
              "LC12": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6980671407331, -1.3717504635223245]),
            {
              "LC12": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65017361656318, -1.3738956148263444]),
            {
              "LC12": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65240521446357, -1.3746678688244098]),
            {
              "LC12": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67034382835517, -1.37149304523655]),
            {
              "LC12": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67532200828681, -1.3729517484897096]),
            {
              "LC12": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67746777549873, -1.3625691942474127]),
            {
              "LC12": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66047329918037, -1.349784004022858]),
            {
              "LC12": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65935750023017, -1.3527872426901715]),
            {
              "LC12": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67396754758965, -1.353473696721034]),
            {
              "LC12": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67339836432809, -1.3557272322345018]),
            {
              "LC12": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6758767434206, -1.342604131447322]),
            {
              "LC12": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.674331791028024, -1.34208928864443]),
            {
              "LC12": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74059138572895, -1.404561618278262]),
            {
              "LC12": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70237195467421, -1.396373647048939]),
            {
              "LC12": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.689583182091205, -1.409072782193987]),
            {
              "LC12": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.698080420250385, -1.4083005394600085]),
            {
              "LC12": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65433501284219, -1.400334910760789]),
            {
              "LC12": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65811156313516, -1.3864344507874182]),
            {
              "LC12": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66377638857461, -1.3876786310982745]),
            {
              "LC12": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67227362673379, -1.3943714518709667]),
            {
              "LC12": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69523333590127, -1.3980610757041163]),
            {
              "LC12": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69394587557412, -1.3940711333972526]),
            {
              "LC12": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68905352633096, -1.3965165827112596]),
            {
              "LC12": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68974017183877, -1.3936421069397789]),
            {
              "LC12": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.705824826062546, -1.4047838734418616]),
            {
              "LC12": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.708167388433026, -1.3993241179341795]),
            {
              "LC12": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70786698102336, -1.3882981377812247]),
            {
              "LC12": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74876530408244, -1.4054290002725793]),
            {
              "LC12": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7492802882133, -1.4063728536303628]),
            {
              "LC12": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72537644147258, -1.4062870487954353]),
            {
              "LC12": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72902424573283, -1.4077457305602081]),
            {
              "LC12": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.740042213443104, -1.390724691637737]),
            {
              "LC12": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75789499664623, -1.3905530808205162]),
            {
              "LC12": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75747658233995, -1.3946824729412974]),
            {
              "LC12": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.729923774421685, -1.38635934789731]),
            {
              "LC12": 2,
              "system:index": "44"
            })]),
    NonBuilt_Up12 = ui.import && ui.import("NonBuilt_Up12", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.775540340566565,
            -1.4006678269180788
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77644156279557,
            -1.4022552196699833
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77837275328629,
            -1.4042716359374887
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78172015013688,
            -1.4015687796930887
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78412340941422,
            -1.39920914073848
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7871274835109,
            -1.4012255596291796
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78841494383805,
            -1.4031990743094795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.781763065481115,
            -1.3971498175291401
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78800246653186,
            -1.3964800472413277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.790534471841916,
            -1.3947639426989085
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79491183695422,
            -1.39665165762668
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79817340311633,
            -1.3938200846670328
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.80160663065539,
            -1.3913746325524583
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79169318613635,
            -1.3884143450222752
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7938818686925,
            -1.3866982346112111
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79315230784045,
            -1.3887575669550403
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.790534471841916,
            -1.3905594812840145
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79512641367541,
            -1.3931336422244067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.797787165018185,
            -1.3897443297340533
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79933211741076,
            -1.388886275166973
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.800061678262814,
            -1.3931765448829248
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.791564440103635,
            -1.3972951964601077
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79014823374377,
            -1.3962655342420107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73957613030494,
            -1.3868722632258865
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.745155125055916,
            -1.3882022488051797
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.731937199030526,
            -1.3830968162211486
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73425462761939,
            -1.383182621901658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73562791863502,
            -1.3857996936658665
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72961977044166,
            -1.3800507125543313
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73429754296363,
            -1.3918060769352196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73305299798072,
            -1.3934363783284944
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.712778598518476,
            -1.401759478354188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.712778598518476,
            -1.4032181629455833
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69926026508342,
            -1.3992282294071146
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69814446613322,
            -1.39274993577404
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6976723973466,
            -1.3971689062145172
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69848778888713,
            -1.3945089444192926
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.711791545600995,
            -1.3922780064018738
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.710994527959514,
            -1.3877976911764331
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71335487189262,
            -1.3816625891370162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.714470670842815,
            -1.3839364399963767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71455650153129,
            -1.3859957747425171
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66196560274029,
            -1.3298152945009418
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66488384614849,
            -1.3325611352614393
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65398334871197,
            -1.3353927803396168
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6556999624815,
            -1.341570903722596
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65595745454693,
            -1.3460328720229204
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66333889375591,
            -1.334363091597373
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65887569795513,
            -1.3308449851444448
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.665055507525445,
            -1.329729486927913
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.667544597491265,
            -1.3329043651414052
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC12": 3
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.775540340566565, -1.4006678269180788]),
            {
              "LC12": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77644156279557, -1.4022552196699833]),
            {
              "LC12": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77837275328629, -1.4042716359374887]),
            {
              "LC12": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78172015013688, -1.4015687796930887]),
            {
              "LC12": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78412340941422, -1.39920914073848]),
            {
              "LC12": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7871274835109, -1.4012255596291796]),
            {
              "LC12": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78841494383805, -1.4031990743094795]),
            {
              "LC12": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.781763065481115, -1.3971498175291401]),
            {
              "LC12": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78800246653186, -1.3964800472413277]),
            {
              "LC12": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.790534471841916, -1.3947639426989085]),
            {
              "LC12": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79491183695422, -1.39665165762668]),
            {
              "LC12": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79817340311633, -1.3938200846670328]),
            {
              "LC12": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.80160663065539, -1.3913746325524583]),
            {
              "LC12": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79169318613635, -1.3884143450222752]),
            {
              "LC12": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7938818686925, -1.3866982346112111]),
            {
              "LC12": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79315230784045, -1.3887575669550403]),
            {
              "LC12": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.790534471841916, -1.3905594812840145]),
            {
              "LC12": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79512641367541, -1.3931336422244067]),
            {
              "LC12": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.797787165018185, -1.3897443297340533]),
            {
              "LC12": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79933211741076, -1.388886275166973]),
            {
              "LC12": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.800061678262814, -1.3931765448829248]),
            {
              "LC12": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.791564440103635, -1.3972951964601077]),
            {
              "LC12": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79014823374377, -1.3962655342420107]),
            {
              "LC12": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73957613030494, -1.3868722632258865]),
            {
              "LC12": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.745155125055916, -1.3882022488051797]),
            {
              "LC12": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.731937199030526, -1.3830968162211486]),
            {
              "LC12": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73425462761939, -1.383182621901658]),
            {
              "LC12": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73562791863502, -1.3857996936658665]),
            {
              "LC12": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72961977044166, -1.3800507125543313]),
            {
              "LC12": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73429754296363, -1.3918060769352196]),
            {
              "LC12": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73305299798072, -1.3934363783284944]),
            {
              "LC12": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.712778598518476, -1.401759478354188]),
            {
              "LC12": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.712778598518476, -1.4032181629455833]),
            {
              "LC12": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69926026508342, -1.3992282294071146]),
            {
              "LC12": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69814446613322, -1.39274993577404]),
            {
              "LC12": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6976723973466, -1.3971689062145172]),
            {
              "LC12": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69848778888713, -1.3945089444192926]),
            {
              "LC12": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.711791545600995, -1.3922780064018738]),
            {
              "LC12": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.710994527959514, -1.3877976911764331]),
            {
              "LC12": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71335487189262, -1.3816625891370162]),
            {
              "LC12": 3,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.714470670842815, -1.3839364399963767]),
            {
              "LC12": 3,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71455650153129, -1.3859957747425171]),
            {
              "LC12": 3,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66196560274029, -1.3298152945009418]),
            {
              "LC12": 3,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66488384614849, -1.3325611352614393]),
            {
              "LC12": 3,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65398334871197, -1.3353927803396168]),
            {
              "LC12": 3,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6556999624815, -1.341570903722596]),
            {
              "LC12": 3,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65595745454693, -1.3460328720229204]),
            {
              "LC12": 3,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66333889375591, -1.334363091597373]),
            {
              "LC12": 3,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65887569795513, -1.3308449851444448]),
            {
              "LC12": 3,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.665055507525445, -1.329729486927913]),
            {
              "LC12": 3,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.667544597491265, -1.3329043651414052]),
            {
              "LC12": 3,
              "system:index": "50"
            })]),
    Water12 = ui.import && ui.import("Water12", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.3562618371809,
            -0.7401658349400637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.38578759401684,
            -0.7425688930365569
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37754784792309,
            -0.7779280231981671
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.38098107546215,
            -0.7957791228346149
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.364158260520746,
            -0.8081375312797271
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.33257256716137,
            -0.8033314879873948
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.330512630637934,
            -0.7830773866890203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.36587487429028,
            -0.7501213528159022
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.404670345481684,
            -0.7425688930365569
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.417373287376215,
            -0.7487481792762166
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.41153680055981,
            -0.7676292774063807
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.678813564475824,
            -0.759905201767465
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66817055910473,
            -0.754069224339597
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.832611540928305,
            -0.821360805709227
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83827636636776,
            -0.8165547781441015
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.848061064854086,
            -0.8206742306958402
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.842567900791586,
            -0.8225623116987892
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.351442308781095,
            -0.7616291465589746
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.34663579022641,
            -0.7987045660185121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.35830876385922,
            -0.7678084057028782
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37822148358578,
            -0.7492706017652262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.34663579022641,
            -0.8117495422690855
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC12": 4
      },
      "color": "#00ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.3562618371809, -0.7401658349400637]),
            {
              "LC12": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.38578759401684, -0.7425688930365569]),
            {
              "LC12": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37754784792309, -0.7779280231981671]),
            {
              "LC12": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.38098107546215, -0.7957791228346149]),
            {
              "LC12": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.364158260520746, -0.8081375312797271]),
            {
              "LC12": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.33257256716137, -0.8033314879873948]),
            {
              "LC12": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.330512630637934, -0.7830773866890203]),
            {
              "LC12": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.36587487429028, -0.7501213528159022]),
            {
              "LC12": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.404670345481684, -0.7425688930365569]),
            {
              "LC12": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.417373287376215, -0.7487481792762166]),
            {
              "LC12": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.41153680055981, -0.7676292774063807]),
            {
              "LC12": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.678813564475824, -0.759905201767465]),
            {
              "LC12": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66817055910473, -0.754069224339597]),
            {
              "LC12": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.832611540928305, -0.821360805709227]),
            {
              "LC12": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83827636636776, -0.8165547781441015]),
            {
              "LC12": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.848061064854086, -0.8206742306958402]),
            {
              "LC12": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.842567900791586, -0.8225623116987892]),
            {
              "LC12": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.351442308781095, -0.7616291465589746]),
            {
              "LC12": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.34663579022641, -0.7987045660185121]),
            {
              "LC12": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.35830876385922, -0.7678084057028782]),
            {
              "LC12": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37822148358578, -0.7492706017652262]),
            {
              "LC12": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.34663579022641, -0.8117495422690855]),
            {
              "LC12": 4,
              "system:index": "21"
            })]),
    L8 = ui.import && ui.import("L8", "imageCollection", {
      "id": "LANDSAT/LC08/C01/T1_TOA"
    }) || ee.ImageCollection("LANDSAT/LC08/C01/T1_TOA"),
    BuiltUp14 = ui.import && ui.import("BuiltUp14", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.74849701708566,
            -1.3927573566943359
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.748411186397185,
            -1.39352960455159
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.750900276363005,
            -1.3933579939385226
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74875450915109,
            -1.3962753726591222
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.762916572749724,
            -1.3963611778608438
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.750127800166716,
            -1.3940444363157691
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68849262742963,
            -1.425796543813522
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68978008775678,
            -1.425796543813522
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68806347398725,
            -1.4294003137902875
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70128140001264,
            -1.4211631169840009
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70368465928998,
            -1.4199618566576835
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68687710814085,
            -1.4285599736428
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.687735415025614,
            -1.4299328374113955
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.691426134630106,
            -1.426929696852159
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.686190462633036,
            -1.4238407481863617
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70232663206663,
            -1.4238836502795298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.707176065965555,
            -1.4191644152492147
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7090214257678,
            -1.417748642860826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71152354008782,
            -1.4115446760596442
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.709077365466236,
            -1.4079837806565774
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7453844958209,
            -1.401589818424707
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.746843617525,
            -1.4064806988196443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.728776257600686,
            -1.395583460108523
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73199490841856,
            -1.3953260444088447
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73824952870529,
            -1.3958137238729085
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74567388325851,
            -1.3965001655337161
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7464463594548,
            -1.3923386098919681
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.742583978473355,
            -1.3913518481975244
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75069497853439,
            -1.3966288733228003
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75168203145187,
            -1.3971008018224642
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.754600274860074,
            -1.3969291914699224
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.759449708759,
            -1.3961569447283686
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75563024312179,
            -1.393239565860942
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76464246541183,
            -1.3963714577375836
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76614450246017,
            -1.3957708212624425
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76502870350998,
            -1.397486925069861
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.762797105609586,
            -1.3977872431072793
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78034948140304,
            -1.3943891778385558
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.773826349078824,
            -1.4000094164413213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77322553425949,
            -1.3911714779377808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76829246126887,
            -1.3945043924312894
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76223001866714,
            -1.386610294572563
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.761730918921245,
            -1.3961893651071655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68199871802466,
            -1.3906660732046032
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682814109565186,
            -1.3914812244362291
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65800282547488,
            -1.3874054654643775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65800282547488,
            -1.388435131552561
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65495583603396,
            -1.3619131005292282
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65710160324588,
            -1.3617414876387819
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.656157465672635,
            -1.3626853583849503
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67727181503787,
            -1.3343690762542102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67401024887576,
            -1.3349697280714568
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.657748600390576,
            -1.3332448700419
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6596797908813,
            -1.3339313295633286
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66667499199214,
            -1.3411820465446673
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66637458458247,
            -1.3431556107658722
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67590179100337,
            -1.3335880998265512
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72024540459144,
            -1.374518457611
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72217659508216,
            -1.3732313673950247
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72573856865394,
            -1.374604263600736
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75206848567685,
            -1.3908239938416103
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.757218326985445,
            -1.3918965611213252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75631710475644,
            -1.3919394638023614
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.749493565022554,
            -1.3888933715099332
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75030895656308,
            -1.3869198448295403
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.759449924885836,
            -1.3905665776219367
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75181099361142,
            -1.3943849153307724
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.751253094136324,
            -1.3899230369499194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.753355946004,
            -1.3894511070123012
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74653240627011,
            -1.405582476652428
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74751945918759,
            -1.3991042005676826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75155350154599,
            -1.3993616158533035
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75657459682187,
            -1.4015496446398936
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7548150677081,
            -1.3995332260280142
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74854942744931,
            -1.3976455134157755
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75159641689023,
            -1.4020215721494889
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74211212581357,
            -1.4003054716588292
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74206921046933,
            -1.396315533164051
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.730782474934664,
            -1.4001767640713538
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74636074489316,
            -1.393698473052772
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.747219051777925,
            -1.3934410571469427
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76640221065244,
            -1.3964871435614132
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76708885616025,
            -1.397688415992006
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76816173976621,
            -1.396444240963237
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75910660213193,
            -1.404595720526245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74567409938535,
            -1.4122323440056748
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74713322108945,
            -1.4101301299271538
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC14": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.74849701708566, -1.3927573566943359]),
            {
              "LC14": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.748411186397185, -1.39352960455159]),
            {
              "LC14": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.750900276363005, -1.3933579939385226]),
            {
              "LC14": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74875450915109, -1.3962753726591222]),
            {
              "LC14": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.762916572749724, -1.3963611778608438]),
            {
              "LC14": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.750127800166716, -1.3940444363157691]),
            {
              "LC14": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68849262742963, -1.425796543813522]),
            {
              "LC14": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68978008775678, -1.425796543813522]),
            {
              "LC14": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68806347398725, -1.4294003137902875]),
            {
              "LC14": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70128140001264, -1.4211631169840009]),
            {
              "LC14": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70368465928998, -1.4199618566576835]),
            {
              "LC14": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68687710814085, -1.4285599736428]),
            {
              "LC14": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.687735415025614, -1.4299328374113955]),
            {
              "LC14": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.691426134630106, -1.426929696852159]),
            {
              "LC14": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.686190462633036, -1.4238407481863617]),
            {
              "LC14": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70232663206663, -1.4238836502795298]),
            {
              "LC14": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.707176065965555, -1.4191644152492147]),
            {
              "LC14": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7090214257678, -1.417748642860826]),
            {
              "LC14": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71152354008782, -1.4115446760596442]),
            {
              "LC14": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.709077365466236, -1.4079837806565774]),
            {
              "LC14": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7453844958209, -1.401589818424707]),
            {
              "LC14": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.746843617525, -1.4064806988196443]),
            {
              "LC14": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.728776257600686, -1.395583460108523]),
            {
              "LC14": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73199490841856, -1.3953260444088447]),
            {
              "LC14": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73824952870529, -1.3958137238729085]),
            {
              "LC14": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74567388325851, -1.3965001655337161]),
            {
              "LC14": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7464463594548, -1.3923386098919681]),
            {
              "LC14": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.742583978473355, -1.3913518481975244]),
            {
              "LC14": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75069497853439, -1.3966288733228003]),
            {
              "LC14": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75168203145187, -1.3971008018224642]),
            {
              "LC14": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.754600274860074, -1.3969291914699224]),
            {
              "LC14": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.759449708759, -1.3961569447283686]),
            {
              "LC14": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75563024312179, -1.393239565860942]),
            {
              "LC14": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76464246541183, -1.3963714577375836]),
            {
              "LC14": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76614450246017, -1.3957708212624425]),
            {
              "LC14": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76502870350998, -1.397486925069861]),
            {
              "LC14": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.762797105609586, -1.3977872431072793]),
            {
              "LC14": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78034948140304, -1.3943891778385558]),
            {
              "LC14": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.773826349078824, -1.4000094164413213]),
            {
              "LC14": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77322553425949, -1.3911714779377808]),
            {
              "LC14": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76829246126887, -1.3945043924312894]),
            {
              "LC14": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76223001866714, -1.386610294572563]),
            {
              "LC14": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.761730918921245, -1.3961893651071655]),
            {
              "LC14": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68199871802466, -1.3906660732046032]),
            {
              "LC14": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682814109565186, -1.3914812244362291]),
            {
              "LC14": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65800282547488, -1.3874054654643775]),
            {
              "LC14": 0,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65800282547488, -1.388435131552561]),
            {
              "LC14": 0,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65495583603396, -1.3619131005292282]),
            {
              "LC14": 0,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65710160324588, -1.3617414876387819]),
            {
              "LC14": 0,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.656157465672635, -1.3626853583849503]),
            {
              "LC14": 0,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67727181503787, -1.3343690762542102]),
            {
              "LC14": 0,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67401024887576, -1.3349697280714568]),
            {
              "LC14": 0,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.657748600390576, -1.3332448700419]),
            {
              "LC14": 0,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6596797908813, -1.3339313295633286]),
            {
              "LC14": 0,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66667499199214, -1.3411820465446673]),
            {
              "LC14": 0,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66637458458247, -1.3431556107658722]),
            {
              "LC14": 0,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67590179100337, -1.3335880998265512]),
            {
              "LC14": 0,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72024540459144, -1.374518457611]),
            {
              "LC14": 0,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72217659508216, -1.3732313673950247]),
            {
              "LC14": 0,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72573856865394, -1.374604263600736]),
            {
              "LC14": 0,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75206848567685, -1.3908239938416103]),
            {
              "LC14": 0,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.757218326985445, -1.3918965611213252]),
            {
              "LC14": 0,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75631710475644, -1.3919394638023614]),
            {
              "LC14": 0,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.749493565022554, -1.3888933715099332]),
            {
              "LC14": 0,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75030895656308, -1.3869198448295403]),
            {
              "LC14": 0,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([36.759449924885836, -1.3905665776219367]),
            {
              "LC14": 0,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75181099361142, -1.3943849153307724]),
            {
              "LC14": 0,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([36.751253094136324, -1.3899230369499194]),
            {
              "LC14": 0,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([36.753355946004, -1.3894511070123012]),
            {
              "LC14": 0,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74653240627011, -1.405582476652428]),
            {
              "LC14": 0,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74751945918759, -1.3991042005676826]),
            {
              "LC14": 0,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75155350154599, -1.3993616158533035]),
            {
              "LC14": 0,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75657459682187, -1.4015496446398936]),
            {
              "LC14": 0,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7548150677081, -1.3995332260280142]),
            {
              "LC14": 0,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74854942744931, -1.3976455134157755]),
            {
              "LC14": 0,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75159641689023, -1.4020215721494889]),
            {
              "LC14": 0,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74211212581357, -1.4003054716588292]),
            {
              "LC14": 0,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74206921046933, -1.396315533164051]),
            {
              "LC14": 0,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([36.730782474934664, -1.4001767640713538]),
            {
              "LC14": 0,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74636074489316, -1.393698473052772]),
            {
              "LC14": 0,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([36.747219051777925, -1.3934410571469427]),
            {
              "LC14": 0,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76640221065244, -1.3964871435614132]),
            {
              "LC14": 0,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76708885616025, -1.397688415992006]),
            {
              "LC14": 0,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76816173976621, -1.396444240963237]),
            {
              "LC14": 0,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75910660213193, -1.404595720526245]),
            {
              "LC14": 0,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74567409938535, -1.4122323440056748]),
            {
              "LC14": 0,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74713322108945, -1.4101301299271538]),
            {
              "LC14": 0,
              "system:index": "86"
            })]),
    ForestedAreas14 = ui.import && ui.import("ForestedAreas14", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.6987451786691,
            -1.3578719554124397
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70097677656949,
            -1.3620764744578013
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.703380035846834,
            -1.355469369815715
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70990316817105,
            -1.3608751840495814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71342222639859,
            -1.3626771194373644
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71599714705289,
            -1.364993891526298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70852987715543,
            -1.3693700104897937
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.707585739582186,
            -1.3652513105095683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7042383427316,
            -1.3641358280497207
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6987451786691,
            -1.3673106613830293
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69668524214566,
            -1.3614758293285107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.711877274006014,
            -1.3693700104897937
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.707328247516756,
            -1.3706571027831675
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69668524214566,
            -1.3653371168312014
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69144957014859,
            -1.3542680761231396
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70174925276578,
            -1.3550403364224692
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68604223677457,
            -1.3438854415950297
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64300011885022,
            -1.3977956938360045
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64068269026135,
            -1.4046600956061566
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64651917707776,
            -1.4020001423079365
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.638794415114866,
            -1.4074058506732745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.650038235305296,
            -1.4026007771880424
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64377259504651,
            -1.4030298020080267
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63965272199963,
            -1.3982247195355775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64969491255139,
            -1.4058613638454016
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64961425430183,
            -1.3308667399714234
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64961425430183,
            -1.334470653804168
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64944259292488,
            -1.331724815171716
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69261542922859,
            -1.3673231856597818
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69364539749031,
            -1.368524472847334
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70986739761238,
            -1.3746167057382264
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71072570449714,
            -1.3754747654615074
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70883742935066,
            -1.3656070600634262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71398727065925,
            -1.3630328693718203
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC14": 1
      },
      "color": "#98ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.6987451786691, -1.3578719554124397]),
            {
              "LC14": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70097677656949, -1.3620764744578013]),
            {
              "LC14": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.703380035846834, -1.355469369815715]),
            {
              "LC14": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70990316817105, -1.3608751840495814]),
            {
              "LC14": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71342222639859, -1.3626771194373644]),
            {
              "LC14": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71599714705289, -1.364993891526298]),
            {
              "LC14": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70852987715543, -1.3693700104897937]),
            {
              "LC14": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.707585739582186, -1.3652513105095683]),
            {
              "LC14": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7042383427316, -1.3641358280497207]),
            {
              "LC14": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6987451786691, -1.3673106613830293]),
            {
              "LC14": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69668524214566, -1.3614758293285107]),
            {
              "LC14": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.711877274006014, -1.3693700104897937]),
            {
              "LC14": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.707328247516756, -1.3706571027831675]),
            {
              "LC14": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69668524214566, -1.3653371168312014]),
            {
              "LC14": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69144957014859, -1.3542680761231396]),
            {
              "LC14": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70174925276578, -1.3550403364224692]),
            {
              "LC14": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68604223677457, -1.3438854415950297]),
            {
              "LC14": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64300011885022, -1.3977956938360045]),
            {
              "LC14": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64068269026135, -1.4046600956061566]),
            {
              "LC14": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64651917707776, -1.4020001423079365]),
            {
              "LC14": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.638794415114866, -1.4074058506732745]),
            {
              "LC14": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.650038235305296, -1.4026007771880424]),
            {
              "LC14": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64377259504651, -1.4030298020080267]),
            {
              "LC14": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63965272199963, -1.3982247195355775]),
            {
              "LC14": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64969491255139, -1.4058613638454016]),
            {
              "LC14": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64961425430183, -1.3308667399714234]),
            {
              "LC14": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64961425430183, -1.334470653804168]),
            {
              "LC14": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64944259292488, -1.331724815171716]),
            {
              "LC14": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69261542922859, -1.3673231856597818]),
            {
              "LC14": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69364539749031, -1.368524472847334]),
            {
              "LC14": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70986739761238, -1.3746167057382264]),
            {
              "LC14": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71072570449714, -1.3754747654615074]),
            {
              "LC14": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70883742935066, -1.3656070600634262]),
            {
              "LC14": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71398727065925, -1.3630328693718203]),
            {
              "LC14": 1,
              "system:index": "33"
            })]),
    Vegetation14 = ui.import && ui.import("Vegetation14", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.65701125118828,
            -1.3404466671258488
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65606711361504,
            -1.3444796022222598
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.664650182462694,
            -1.3380440643353255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67497830481297,
            -1.3732242851713865
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67798237890965,
            -1.3727094488893692
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.681501437137186,
            -1.3715081638002962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68321805090672,
            -1.3754552411114727
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65386395544773,
            -1.3878112669210019
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71789364905125,
            -1.3851107539024408
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.717207003543436,
            -1.3885429757822818
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73042492956883,
            -1.3864836432516268
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.728708315799295,
            -1.383223029748694
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.729738284061014,
            -1.380048217558937
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72135610251867,
            -1.4266439942354607
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.718695351175896,
            -1.4073379949907252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72504682212316,
            -1.4068231661467279
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7325999227091,
            -1.4021897014433522
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77982829922683,
            -1.3893510750862106
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6440510044964,
            -1.38761673312787
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64817087754327,
            -1.3810096990008562
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66671030625421,
            -1.3845277324512382
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67417757615167,
            -1.3530368585587778
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67366259202081,
            -1.3539807327039795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67340509995538,
            -1.3558684798915703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6773533116253,
            -1.3538091192503587
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68413393601495,
            -1.3492613583079414
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68164484604913,
            -1.3476310268417075
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67774722845654,
            -1.363162034721086
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66428991003932,
            -1.3777914571981797
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.657509285649674,
            -1.3780488748048552
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64892621680202,
            -1.367837955124808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66154332800807,
            -1.3108934955088825
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65579267188014,
            -1.307632780849693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71641523889775,
            -1.391136017378974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77075215506907,
            -1.397552958749995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.769378864053444,
            -1.4002987221557515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72553398162042,
            -1.42440184858345
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.687768478690735,
            -1.4156498070389802
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.721242447196595,
            -1.3905089556282522
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67291976958429,
            -1.3939411696642348
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66596623307806,
            -1.4038100074706303
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.738475700269085,
            -1.3817305137389542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.737445732007366,
            -1.3809582620304681
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.730193038831096,
            -1.3844333927406045
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.727961440930706,
            -1.3857633796899662
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.742209335217815,
            -1.3848195180608704
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.751178642163616,
            -1.3873078797261231
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.746457954297405,
            -1.3861066020072983
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75375356281791,
            -1.3880801293661544
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72105207050834,
            -1.3940007015503066
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70542458660033,
            -1.3967520481727154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.704308787650135,
            -1.396323022204182
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71832643274869,
            -1.379369971784351
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71557985071744,
            -1.382201562047437
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73901162867154,
            -1.3906105071417694
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74622140650357,
            -1.3903769459153086
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74544893030728,
            -1.3907201675628922
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72502962571606,
            -1.4255497058541604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.731896080794186,
            -1.4254639017290693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72185389024243,
            -1.4161112329670096
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69464556199536,
            -1.4018676466503455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.690697350325436,
            -1.4091610601632623
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.694988884749264,
            -1.4165402552976627
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68117014390454,
            -1.4218601255904881
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6652056358479,
            -1.4158538195304866
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66260082996055,
            -1.4103680986142744
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68732544489349,
            -1.4268654857765064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69037243433441,
            -1.4308982737360938
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692689862923274,
            -1.4235191244416159
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.683935132698664,
            -1.435016858376519
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC14": 2
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.65701125118828, -1.3404466671258488]),
            {
              "LC14": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65606711361504, -1.3444796022222598]),
            {
              "LC14": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.664650182462694, -1.3380440643353255]),
            {
              "LC14": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67497830481297, -1.3732242851713865]),
            {
              "LC14": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67798237890965, -1.3727094488893692]),
            {
              "LC14": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.681501437137186, -1.3715081638002962]),
            {
              "LC14": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68321805090672, -1.3754552411114727]),
            {
              "LC14": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65386395544773, -1.3878112669210019]),
            {
              "LC14": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71789364905125, -1.3851107539024408]),
            {
              "LC14": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.717207003543436, -1.3885429757822818]),
            {
              "LC14": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73042492956883, -1.3864836432516268]),
            {
              "LC14": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.728708315799295, -1.383223029748694]),
            {
              "LC14": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.729738284061014, -1.380048217558937]),
            {
              "LC14": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72135610251867, -1.4266439942354607]),
            {
              "LC14": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.718695351175896, -1.4073379949907252]),
            {
              "LC14": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72504682212316, -1.4068231661467279]),
            {
              "LC14": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7325999227091, -1.4021897014433522]),
            {
              "LC14": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77982829922683, -1.3893510750862106]),
            {
              "LC14": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6440510044964, -1.38761673312787]),
            {
              "LC14": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64817087754327, -1.3810096990008562]),
            {
              "LC14": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66671030625421, -1.3845277324512382]),
            {
              "LC14": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67417757615167, -1.3530368585587778]),
            {
              "LC14": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67366259202081, -1.3539807327039795]),
            {
              "LC14": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67340509995538, -1.3558684798915703]),
            {
              "LC14": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6773533116253, -1.3538091192503587]),
            {
              "LC14": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68413393601495, -1.3492613583079414]),
            {
              "LC14": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68164484604913, -1.3476310268417075]),
            {
              "LC14": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67774722845654, -1.363162034721086]),
            {
              "LC14": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66428991003932, -1.3777914571981797]),
            {
              "LC14": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.657509285649674, -1.3780488748048552]),
            {
              "LC14": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64892621680202, -1.367837955124808]),
            {
              "LC14": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66154332800807, -1.3108934955088825]),
            {
              "LC14": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65579267188014, -1.307632780849693]),
            {
              "LC14": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71641523889775, -1.391136017378974]),
            {
              "LC14": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77075215506907, -1.397552958749995]),
            {
              "LC14": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.769378864053444, -1.4002987221557515]),
            {
              "LC14": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72553398162042, -1.42440184858345]),
            {
              "LC14": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.687768478690735, -1.4156498070389802]),
            {
              "LC14": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.721242447196595, -1.3905089556282522]),
            {
              "LC14": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67291976958429, -1.3939411696642348]),
            {
              "LC14": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66596623307806, -1.4038100074706303]),
            {
              "LC14": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.738475700269085, -1.3817305137389542]),
            {
              "LC14": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.737445732007366, -1.3809582620304681]),
            {
              "LC14": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.730193038831096, -1.3844333927406045]),
            {
              "LC14": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.727961440930706, -1.3857633796899662]),
            {
              "LC14": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.742209335217815, -1.3848195180608704]),
            {
              "LC14": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.751178642163616, -1.3873078797261231]),
            {
              "LC14": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.746457954297405, -1.3861066020072983]),
            {
              "LC14": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75375356281791, -1.3880801293661544]),
            {
              "LC14": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72105207050834, -1.3940007015503066]),
            {
              "LC14": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70542458660033, -1.3967520481727154]),
            {
              "LC14": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.704308787650135, -1.396323022204182]),
            {
              "LC14": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71832643274869, -1.379369971784351]),
            {
              "LC14": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71557985071744, -1.382201562047437]),
            {
              "LC14": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73901162867154, -1.3906105071417694]),
            {
              "LC14": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74622140650357, -1.3903769459153086]),
            {
              "LC14": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74544893030728, -1.3907201675628922]),
            {
              "LC14": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72502962571606, -1.4255497058541604]),
            {
              "LC14": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.731896080794186, -1.4254639017290693]),
            {
              "LC14": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72185389024243, -1.4161112329670096]),
            {
              "LC14": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69464556199536, -1.4018676466503455]),
            {
              "LC14": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.690697350325436, -1.4091610601632623]),
            {
              "LC14": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.694988884749264, -1.4165402552976627]),
            {
              "LC14": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68117014390454, -1.4218601255904881]),
            {
              "LC14": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6652056358479, -1.4158538195304866]),
            {
              "LC14": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66260082996055, -1.4103680986142744]),
            {
              "LC14": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68732544489349, -1.4268654857765064]),
            {
              "LC14": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69037243433441, -1.4308982737360938]),
            {
              "LC14": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692689862923274, -1.4235191244416159]),
            {
              "LC14": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([36.683935132698664, -1.435016858376519]),
            {
              "LC14": 2,
              "system:index": "69"
            })]),
    NonBuilt_Up14 = ui.import && ui.import("NonBuilt_Up14", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.81821637753804,
            -1.385249853720488
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.817443901341754,
            -1.3889394918236795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81461148862203,
            -1.3891969082207263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.80989080075582,
            -1.3893685191365188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78182416562398,
            -1.4018102772174474
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77942090634664,
            -1.4039554012552717
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.775472694676715,
            -1.4013812521739466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.777704292577106,
            -1.3998367613667926
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78800397519429,
            -1.3958039194655447
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7868881762441,
            -1.402839937001059
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7843132555898,
            -1.3997509562921022
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.80928998593648,
            -1.390312378950434
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81649976376851,
            -1.3897117409306752
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81598477963765,
            -1.3858504928734146
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69195943478902,
            -1.359593840032974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68354802731832,
            -1.361481582837315
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.685607963841754,
            -1.3595080335067675
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69878036825706,
            -1.394468807775101
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69886619894554,
            -1.3989306775388646
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68350250570823,
            -1.3948120288268016
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66007072775413,
            -1.3664103186326695
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66032821981956,
            -1.3671825750445088
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.650286029267804,
            -1.3396386105026232
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65268928854515,
            -1.3387805380648459
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.652002643037335,
            -1.3407541042224231
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65260345785667,
            -1.3442721964687678
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.651401828218,
            -1.3283120301997087
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65260345785667,
            -1.3321733702490175
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6598132356887,
            -1.3274539538131327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66358978598167,
            -1.3285694530575816
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65904075949241,
            -1.3298565669445044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.665735553193585,
            -1.329341721470239
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.652517627168194,
            -1.3341469417161365
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.685766698810085,
            -1.360549883633266
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68362093159817,
            -1.3626092385300903
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64112798052945,
            -1.386600521224931
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64078465777554,
            -1.3871368058842646
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63863889056363,
            -1.3800363871638255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.637694752990384,
            -1.380336707418968
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64584866839566,
            -1.3857853683100667
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC14": 3
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.81821637753804, -1.385249853720488]),
            {
              "LC14": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.817443901341754, -1.3889394918236795]),
            {
              "LC14": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81461148862203, -1.3891969082207263]),
            {
              "LC14": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.80989080075582, -1.3893685191365188]),
            {
              "LC14": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78182416562398, -1.4018102772174474]),
            {
              "LC14": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77942090634664, -1.4039554012552717]),
            {
              "LC14": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.775472694676715, -1.4013812521739466]),
            {
              "LC14": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.777704292577106, -1.3998367613667926]),
            {
              "LC14": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78800397519429, -1.3958039194655447]),
            {
              "LC14": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7868881762441, -1.402839937001059]),
            {
              "LC14": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7843132555898, -1.3997509562921022]),
            {
              "LC14": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.80928998593648, -1.390312378950434]),
            {
              "LC14": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81649976376851, -1.3897117409306752]),
            {
              "LC14": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81598477963765, -1.3858504928734146]),
            {
              "LC14": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69195943478902, -1.359593840032974]),
            {
              "LC14": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68354802731832, -1.361481582837315]),
            {
              "LC14": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.685607963841754, -1.3595080335067675]),
            {
              "LC14": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69878036825706, -1.394468807775101]),
            {
              "LC14": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69886619894554, -1.3989306775388646]),
            {
              "LC14": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68350250570823, -1.3948120288268016]),
            {
              "LC14": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66007072775413, -1.3664103186326695]),
            {
              "LC14": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66032821981956, -1.3671825750445088]),
            {
              "LC14": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.650286029267804, -1.3396386105026232]),
            {
              "LC14": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65268928854515, -1.3387805380648459]),
            {
              "LC14": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.652002643037335, -1.3407541042224231]),
            {
              "LC14": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65260345785667, -1.3442721964687678]),
            {
              "LC14": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.651401828218, -1.3283120301997087]),
            {
              "LC14": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65260345785667, -1.3321733702490175]),
            {
              "LC14": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6598132356887, -1.3274539538131327]),
            {
              "LC14": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66358978598167, -1.3285694530575816]),
            {
              "LC14": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65904075949241, -1.3298565669445044]),
            {
              "LC14": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.665735553193585, -1.329341721470239]),
            {
              "LC14": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.652517627168194, -1.3341469417161365]),
            {
              "LC14": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.685766698810085, -1.360549883633266]),
            {
              "LC14": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68362093159817, -1.3626092385300903]),
            {
              "LC14": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64112798052945, -1.386600521224931]),
            {
              "LC14": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64078465777554, -1.3871368058842646]),
            {
              "LC14": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63863889056363, -1.3800363871638255]),
            {
              "LC14": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.637694752990384, -1.380336707418968]),
            {
              "LC14": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64584866839566, -1.3857853683100667]),
            {
              "LC14": 3,
              "system:index": "39"
            })]),
    Water14 = ui.import && ui.import("Water14", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.694473977004144,
            -1.4408047322408077
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69490313044653,
            -1.442520802632619
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69310068598852,
            -1.4426066061182408
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69430231562719,
            -1.4432930338867542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.693958992873284,
            -1.4451807091814688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69404482356176,
            -1.4484412355392386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69550394526586,
            -1.4384022315207723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.391757421535125,
            -0.7335069802611136
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.404460363429656,
            -0.7403728673780745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.420939855617156,
            -0.7517015578297505
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.399997167628875,
            -0.7468954502926435
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.372531347316375,
            -0.7506716780873611
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.36394827846872,
            -0.7747021415087249
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.356051855128875,
            -0.8011354937040538
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.370814733546844,
            -0.8100610029676102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.3793978023945,
            -0.7623436342183342
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.383517675441375,
            -0.735910041955285
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.37115805630075,
            -0.7355667475067129
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.60586325553561,
            -0.7011067285241194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.604747456585415,
            -0.7053979396852491
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.606464070354946,
            -0.7020507953178591
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.60654990104342,
            -0.704797170360349
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66826520949318,
            -0.7540603400529878
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67152677565529,
            -0.7554335119213937
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.673844204244155,
            -0.7577507384649644
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67976652174904,
            -0.7598963174928021
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68045316725685,
            -0.7571499761466098
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.681053982076186,
            -0.7586947933683149
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67727743178322,
            -0.7593813786232022
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83735304113616,
            -0.8164474084501875
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.83984213110198,
            -0.8225407640107905
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.844991972410575,
            -0.8224549421659132
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.847223570310966,
            -0.8193653545230547
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84009962316741,
            -0.815760832595595
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.842760374510185,
            -0.8233989823579387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.84833936926116,
            -0.8213392580147398
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6947656985095,
            -1.4369924960568914
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692641388969705,
            -1.4358341458763337
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692888152199075,
            -1.435737616668117
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69356406887083,
            -1.4359628514809495
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.694315087395,
            -1.436606379395291
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69492663105039,
            -1.4372177307460257
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC14": 4
      },
      "color": "#00ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.694473977004144, -1.4408047322408077]),
            {
              "LC14": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69490313044653, -1.442520802632619]),
            {
              "LC14": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69310068598852, -1.4426066061182408]),
            {
              "LC14": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69430231562719, -1.4432930338867542]),
            {
              "LC14": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.693958992873284, -1.4451807091814688]),
            {
              "LC14": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69404482356176, -1.4484412355392386]),
            {
              "LC14": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69550394526586, -1.4384022315207723]),
            {
              "LC14": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.391757421535125, -0.7335069802611136]),
            {
              "LC14": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.404460363429656, -0.7403728673780745]),
            {
              "LC14": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.420939855617156, -0.7517015578297505]),
            {
              "LC14": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.399997167628875, -0.7468954502926435]),
            {
              "LC14": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.372531347316375, -0.7506716780873611]),
            {
              "LC14": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.36394827846872, -0.7747021415087249]),
            {
              "LC14": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.356051855128875, -0.8011354937040538]),
            {
              "LC14": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.370814733546844, -0.8100610029676102]),
            {
              "LC14": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.3793978023945, -0.7623436342183342]),
            {
              "LC14": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.383517675441375, -0.735910041955285]),
            {
              "LC14": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.37115805630075, -0.7355667475067129]),
            {
              "LC14": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.60586325553561, -0.7011067285241194]),
            {
              "LC14": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.604747456585415, -0.7053979396852491]),
            {
              "LC14": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.606464070354946, -0.7020507953178591]),
            {
              "LC14": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.60654990104342, -0.704797170360349]),
            {
              "LC14": 4,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66826520949318, -0.7540603400529878]),
            {
              "LC14": 4,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67152677565529, -0.7554335119213937]),
            {
              "LC14": 4,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.673844204244155, -0.7577507384649644]),
            {
              "LC14": 4,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67976652174904, -0.7598963174928021]),
            {
              "LC14": 4,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68045316725685, -0.7571499761466098]),
            {
              "LC14": 4,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.681053982076186, -0.7586947933683149]),
            {
              "LC14": 4,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67727743178322, -0.7593813786232022]),
            {
              "LC14": 4,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83735304113616, -0.8164474084501875]),
            {
              "LC14": 4,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.83984213110198, -0.8225407640107905]),
            {
              "LC14": 4,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.844991972410575, -0.8224549421659132]),
            {
              "LC14": 4,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.847223570310966, -0.8193653545230547]),
            {
              "LC14": 4,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84009962316741, -0.815760832595595]),
            {
              "LC14": 4,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.842760374510185, -0.8233989823579387]),
            {
              "LC14": 4,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.84833936926116, -0.8213392580147398]),
            {
              "LC14": 4,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6947656985095, -1.4369924960568914]),
            {
              "LC14": 4,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692641388969705, -1.4358341458763337]),
            {
              "LC14": 4,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692888152199075, -1.435737616668117]),
            {
              "LC14": 4,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69356406887083, -1.4359628514809495]),
            {
              "LC14": 4,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.694315087395, -1.436606379395291]),
            {
              "LC14": 4,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69492663105039, -1.4372177307460257]),
            {
              "LC14": 4,
              "system:index": "41"
            })]),
    S2 = ui.import && ui.import("S2", "imageCollection", {
      "id": "COPERNICUS/S2"
    }) || ee.ImageCollection("COPERNICUS/S2"),
    BuiltUp16 = ui.import && ui.import("BuiltUp16", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.753422265472636,
            -1.395842480213795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7567482046511,
            -1.3938475080243231
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75164127868675,
            -1.3923459149387662
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.757735257568584,
            -1.3913162505557801
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75007486862205,
            -1.3944052423551276
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74840117019676,
            -1.3928607469616137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74876595062278,
            -1.3926676849662294
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7499032072451,
            -1.3908443208966896
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74610519928001,
            -1.3947484634161025
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.742693429413066,
            -1.398523891780131
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7503538183596,
            -1.3975371326796713
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.750225072326884,
            -1.386961623303831
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75934458297752,
            -1.3882916088328843
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75850773376487,
            -1.3877553244353487
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.762176995697246,
            -1.3866184011104514
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.715180851500094,
            -1.3714079196963873
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7235922589708,
            -1.3723303351250655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.721897102873385,
            -1.3728666230014537
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72183272985703,
            -1.3717082410377912
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72206876425034,
            -1.370828728431544
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.719171978514254,
            -1.3732742017070738
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.717927433531344,
            -1.3699277639633392
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72028777746445,
            -1.370142279343645
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71578166631943,
            -1.3704211493093348
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.723141647856295,
            -1.378379655387597
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.721360661070406,
            -1.379087553564124
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71981570867783,
            -1.3781007863511763
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68348786978012,
            -1.3908776123454345
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682672478239596,
            -1.3896334337185292
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68769181515318,
            -1.4254329848256195
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6896230056439,
            -1.4244891392260104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68885052944761,
            -1.4267200463833343
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69022382046324,
            -1.4258620054248297
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.686533100858746,
            -1.423416586938985
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69571698452574,
            -1.42534718069619
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70138180996519,
            -1.4206708508116757
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.699707097576585,
            -1.4182959203920327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.688801424301744,
            -1.4289309918848627
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68822206715453,
            -1.4295530707812099
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68669857243407,
            -1.4273865194139626
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.689788477219224,
            -1.4260994582290472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69092573384154,
            -1.4268073419698635
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.695796625412584,
            -1.4255417314920202
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69712700108397,
            -1.421895053345739
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69556059101927,
            -1.422753095781357
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69322170475829,
            -1.421315874521381
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69493831852782,
            -1.420886853076334
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70461895950382,
            -1.4204363804732885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70292380340641,
            -1.4212729723804538
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68942692764347,
            -1.412413663240216
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68908360488956,
            -1.4125852724554424
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68966296203678,
            -1.4106975703911315
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68846291173177,
            -1.418918095091496
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70572542223769,
            -1.4136248739796264
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7094375995143,
            -1.4121876470537595
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.712591877315816,
            -1.4074898394138962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70970424184004,
            -1.4113542080604617
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70912488469283,
            -1.4092305420065265
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70182927617232,
            -1.4047472406482542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.706738227115416,
            -1.404760149035965
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.712016814456724,
            -1.402035842108003
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71918367694452,
            -1.4002982903638388
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71830391238763,
            -1.3984963834908861
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71920513461664,
            -1.3989254090623846
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.719999068485045,
            -1.396093838841882
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71980594943597,
            -1.3972093063059485
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72918672257593,
            -1.3987643134222907
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73028106385401,
            -1.390845658792691
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73249120408228,
            -1.3942564210192843
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.728628823100834,
            -1.3937415893014522
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.724337288677006,
            -1.3872632805802334
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72723407441309,
            -1.3874992457792192
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.727126786052494,
            -1.3905238885166484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73022572928916,
            -1.3886425661544088
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66275919652626,
            -1.3572668197004103
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66702927327797,
            -1.3441598250276283
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.667587172753066,
            -1.34379514495229
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66825236058876,
            -1.3449106367759325
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.677607905632705,
            -1.3344636068964166
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67672814107582,
            -1.3335197252092545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67951763845131,
            -1.3336055326503158
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.679324519402236,
            -1.3348068365110481
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67893828130409,
            -1.3380675154588169
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.670789803647224,
            -1.3270118943855451
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65486821225984,
            -1.3248094961291799
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66428720699741,
            -1.3201186327995236
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65842926250888,
            -1.3179090782024565
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65712341009184,
            -1.315291679184756
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.656286560879195,
            -1.3137900374434681
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65464498320021,
            -1.319560462839747
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.653021266231846,
            -1.3652041518746505
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65960877157242,
            -1.3650325392188272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65772049642594,
            -1.3698376889462425
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66220514989884,
            -1.3696875281629488
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65086240833316,
            -1.360828025328954
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65665597980533,
            -1.3570954405293225
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.669745159798005,
            -1.3527407509834493
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66337572070261,
            -1.3607566933877049
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66691623660227,
            -1.362914920189582
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.671744212829076,
            -1.367236339060478
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.653564444880466,
            -1.379454293135015
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.658306590418796,
            -1.375721737318468
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65854262481211,
            -1.3765368936853921
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65948676238535,
            -1.3745848082363599
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682038775782566,
            -1.3900982344117356
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67922782073496,
            -1.386301341160984
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68195294509409,
            -1.3849928059170962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68354251974084,
            -1.3970862472341143
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68470123403527,
            -1.3985449347335288
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68459394567468,
            -1.3970218933529814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6846154033468,
            -1.3954988509851007
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68671825521447,
            -1.3954344970605088
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68583849065759,
            -1.3933537192169383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67948701971032,
            -1.3972578575751933
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69759729497888,
            -1.4026206744083443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69804790609338,
            -1.4007758668021144
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69575193517663,
            -1.40107618441844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.699854237131326,
            -1.4088707485298158
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.703652245096414,
            -1.4078410914050463
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70431743293211,
            -1.4044088977066245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69181299716203,
            -1.413572807369395
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.702456002533125,
            -1.413701514217773
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.702241425811934,
            -1.4161898452165753
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.769431313515774,
            -1.391562858976915
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7632944192897,
            -1.3977837404489832
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76471062564956,
            -1.394780558343204
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76771469974624,
            -1.39615344206763
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76453896427261,
            -1.3971831043348477
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.770675858498684,
            -1.3955099029215794
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.774624070168606,
            -1.397226006919513
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77398034000503,
            -1.3950379741025751
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78870030307876,
            -1.4007869187137594
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.781956783016284,
            -1.4052024373234178
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.784209838588794,
            -1.402145636603729
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78537928171929,
            -1.403218198714801
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77652799197014,
            -1.4060926627461292
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.768953433712085,
            -1.4070365158355373
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77307330675896,
            -1.4025961127502562
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7684556417205,
            -1.39770095997545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.773948805783,
            -1.4003609181556433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77620186135551,
            -1.396392431054963
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7709232740142,
            -1.3900213864073405
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77622331902763,
            -1.389120429209413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77976383492729,
            -1.3907721838097018
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73846001113917,
            -1.3876409068306637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73519581208927,
            -1.3855046731328582
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73577516923649,
            -1.3860624094341947
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73622578035099,
            -1.3856119301240843
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC16": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.753422265472636, -1.395842480213795]),
            {
              "LC16": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7567482046511, -1.3938475080243231]),
            {
              "LC16": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75164127868675, -1.3923459149387662]),
            {
              "LC16": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.757735257568584, -1.3913162505557801]),
            {
              "LC16": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75007486862205, -1.3944052423551276]),
            {
              "LC16": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74840117019676, -1.3928607469616137]),
            {
              "LC16": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74876595062278, -1.3926676849662294]),
            {
              "LC16": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7499032072451, -1.3908443208966896]),
            {
              "LC16": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74610519928001, -1.3947484634161025]),
            {
              "LC16": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.742693429413066, -1.398523891780131]),
            {
              "LC16": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7503538183596, -1.3975371326796713]),
            {
              "LC16": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.750225072326884, -1.386961623303831]),
            {
              "LC16": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75934458297752, -1.3882916088328843]),
            {
              "LC16": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75850773376487, -1.3877553244353487]),
            {
              "LC16": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.762176995697246, -1.3866184011104514]),
            {
              "LC16": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.715180851500094, -1.3714079196963873]),
            {
              "LC16": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7235922589708, -1.3723303351250655]),
            {
              "LC16": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.721897102873385, -1.3728666230014537]),
            {
              "LC16": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72183272985703, -1.3717082410377912]),
            {
              "LC16": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72206876425034, -1.370828728431544]),
            {
              "LC16": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.719171978514254, -1.3732742017070738]),
            {
              "LC16": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.717927433531344, -1.3699277639633392]),
            {
              "LC16": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72028777746445, -1.370142279343645]),
            {
              "LC16": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71578166631943, -1.3704211493093348]),
            {
              "LC16": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.723141647856295, -1.378379655387597]),
            {
              "LC16": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.721360661070406, -1.379087553564124]),
            {
              "LC16": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71981570867783, -1.3781007863511763]),
            {
              "LC16": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68348786978012, -1.3908776123454345]),
            {
              "LC16": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682672478239596, -1.3896334337185292]),
            {
              "LC16": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68769181515318, -1.4254329848256195]),
            {
              "LC16": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6896230056439, -1.4244891392260104]),
            {
              "LC16": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68885052944761, -1.4267200463833343]),
            {
              "LC16": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69022382046324, -1.4258620054248297]),
            {
              "LC16": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.686533100858746, -1.423416586938985]),
            {
              "LC16": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69571698452574, -1.42534718069619]),
            {
              "LC16": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70138180996519, -1.4206708508116757]),
            {
              "LC16": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.699707097576585, -1.4182959203920327]),
            {
              "LC16": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.688801424301744, -1.4289309918848627]),
            {
              "LC16": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68822206715453, -1.4295530707812099]),
            {
              "LC16": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68669857243407, -1.4273865194139626]),
            {
              "LC16": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.689788477219224, -1.4260994582290472]),
            {
              "LC16": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69092573384154, -1.4268073419698635]),
            {
              "LC16": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.695796625412584, -1.4255417314920202]),
            {
              "LC16": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69712700108397, -1.421895053345739]),
            {
              "LC16": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69556059101927, -1.422753095781357]),
            {
              "LC16": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69322170475829, -1.421315874521381]),
            {
              "LC16": 0,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69493831852782, -1.420886853076334]),
            {
              "LC16": 0,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70461895950382, -1.4204363804732885]),
            {
              "LC16": 0,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70292380340641, -1.4212729723804538]),
            {
              "LC16": 0,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68942692764347, -1.412413663240216]),
            {
              "LC16": 0,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68908360488956, -1.4125852724554424]),
            {
              "LC16": 0,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68966296203678, -1.4106975703911315]),
            {
              "LC16": 0,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68846291173177, -1.418918095091496]),
            {
              "LC16": 0,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70572542223769, -1.4136248739796264]),
            {
              "LC16": 0,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7094375995143, -1.4121876470537595]),
            {
              "LC16": 0,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.712591877315816, -1.4074898394138962]),
            {
              "LC16": 0,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70970424184004, -1.4113542080604617]),
            {
              "LC16": 0,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70912488469283, -1.4092305420065265]),
            {
              "LC16": 0,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70182927617232, -1.4047472406482542]),
            {
              "LC16": 0,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.706738227115416, -1.404760149035965]),
            {
              "LC16": 0,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.712016814456724, -1.402035842108003]),
            {
              "LC16": 0,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71918367694452, -1.4002982903638388]),
            {
              "LC16": 0,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71830391238763, -1.3984963834908861]),
            {
              "LC16": 0,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71920513461664, -1.3989254090623846]),
            {
              "LC16": 0,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.719999068485045, -1.396093838841882]),
            {
              "LC16": 0,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71980594943597, -1.3972093063059485]),
            {
              "LC16": 0,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72918672257593, -1.3987643134222907]),
            {
              "LC16": 0,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73028106385401, -1.390845658792691]),
            {
              "LC16": 0,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73249120408228, -1.3942564210192843]),
            {
              "LC16": 0,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([36.728628823100834, -1.3937415893014522]),
            {
              "LC16": 0,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([36.724337288677006, -1.3872632805802334]),
            {
              "LC16": 0,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72723407441309, -1.3874992457792192]),
            {
              "LC16": 0,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([36.727126786052494, -1.3905238885166484]),
            {
              "LC16": 0,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73022572928916, -1.3886425661544088]),
            {
              "LC16": 0,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66275919652626, -1.3572668197004103]),
            {
              "LC16": 0,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66702927327797, -1.3441598250276283]),
            {
              "LC16": 0,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([36.667587172753066, -1.34379514495229]),
            {
              "LC16": 0,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66825236058876, -1.3449106367759325]),
            {
              "LC16": 0,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([36.677607905632705, -1.3344636068964166]),
            {
              "LC16": 0,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67672814107582, -1.3335197252092545]),
            {
              "LC16": 0,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67951763845131, -1.3336055326503158]),
            {
              "LC16": 0,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([36.679324519402236, -1.3348068365110481]),
            {
              "LC16": 0,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67893828130409, -1.3380675154588169]),
            {
              "LC16": 0,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([36.670789803647224, -1.3270118943855451]),
            {
              "LC16": 0,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65486821225984, -1.3248094961291799]),
            {
              "LC16": 0,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66428720699741, -1.3201186327995236]),
            {
              "LC16": 0,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65842926250888, -1.3179090782024565]),
            {
              "LC16": 0,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65712341009184, -1.315291679184756]),
            {
              "LC16": 0,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([36.656286560879195, -1.3137900374434681]),
            {
              "LC16": 0,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65464498320021, -1.319560462839747]),
            {
              "LC16": 0,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([36.653021266231846, -1.3652041518746505]),
            {
              "LC16": 0,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65960877157242, -1.3650325392188272]),
            {
              "LC16": 0,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65772049642594, -1.3698376889462425]),
            {
              "LC16": 0,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66220514989884, -1.3696875281629488]),
            {
              "LC16": 0,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65086240833316, -1.360828025328954]),
            {
              "LC16": 0,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65665597980533, -1.3570954405293225]),
            {
              "LC16": 0,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([36.669745159798005, -1.3527407509834493]),
            {
              "LC16": 0,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66337572070261, -1.3607566933877049]),
            {
              "LC16": 0,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66691623660227, -1.362914920189582]),
            {
              "LC16": 0,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([36.671744212829076, -1.367236339060478]),
            {
              "LC16": 0,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([36.653564444880466, -1.379454293135015]),
            {
              "LC16": 0,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([36.658306590418796, -1.375721737318468]),
            {
              "LC16": 0,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65854262481211, -1.3765368936853921]),
            {
              "LC16": 0,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65948676238535, -1.3745848082363599]),
            {
              "LC16": 0,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682038775782566, -1.3900982344117356]),
            {
              "LC16": 0,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67922782073496, -1.386301341160984]),
            {
              "LC16": 0,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68195294509409, -1.3849928059170962]),
            {
              "LC16": 0,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68354251974084, -1.3970862472341143]),
            {
              "LC16": 0,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68470123403527, -1.3985449347335288]),
            {
              "LC16": 0,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68459394567468, -1.3970218933529814]),
            {
              "LC16": 0,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6846154033468, -1.3954988509851007]),
            {
              "LC16": 0,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68671825521447, -1.3954344970605088]),
            {
              "LC16": 0,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68583849065759, -1.3933537192169383]),
            {
              "LC16": 0,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67948701971032, -1.3972578575751933]),
            {
              "LC16": 0,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69759729497888, -1.4026206744083443]),
            {
              "LC16": 0,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69804790609338, -1.4007758668021144]),
            {
              "LC16": 0,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69575193517663, -1.40107618441844]),
            {
              "LC16": 0,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([36.699854237131326, -1.4088707485298158]),
            {
              "LC16": 0,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([36.703652245096414, -1.4078410914050463]),
            {
              "LC16": 0,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70431743293211, -1.4044088977066245]),
            {
              "LC16": 0,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69181299716203, -1.413572807369395]),
            {
              "LC16": 0,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([36.702456002533125, -1.413701514217773]),
            {
              "LC16": 0,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([36.702241425811934, -1.4161898452165753]),
            {
              "LC16": 0,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([36.769431313515774, -1.391562858976915]),
            {
              "LC16": 0,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7632944192897, -1.3977837404489832]),
            {
              "LC16": 0,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76471062564956, -1.394780558343204]),
            {
              "LC16": 0,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76771469974624, -1.39615344206763]),
            {
              "LC16": 0,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76453896427261, -1.3971831043348477]),
            {
              "LC16": 0,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([36.770675858498684, -1.3955099029215794]),
            {
              "LC16": 0,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([36.774624070168606, -1.397226006919513]),
            {
              "LC16": 0,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77398034000503, -1.3950379741025751]),
            {
              "LC16": 0,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78870030307876, -1.4007869187137594]),
            {
              "LC16": 0,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([36.781956783016284, -1.4052024373234178]),
            {
              "LC16": 0,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([36.784209838588794, -1.402145636603729]),
            {
              "LC16": 0,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78537928171929, -1.403218198714801]),
            {
              "LC16": 0,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77652799197014, -1.4060926627461292]),
            {
              "LC16": 0,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([36.768953433712085, -1.4070365158355373]),
            {
              "LC16": 0,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77307330675896, -1.4025961127502562]),
            {
              "LC16": 0,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7684556417205, -1.39770095997545]),
            {
              "LC16": 0,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([36.773948805783, -1.4003609181556433]),
            {
              "LC16": 0,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77620186135551, -1.396392431054963]),
            {
              "LC16": 0,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7709232740142, -1.3900213864073405]),
            {
              "LC16": 0,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77622331902763, -1.389120429209413]),
            {
              "LC16": 0,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77976383492729, -1.3907721838097018]),
            {
              "LC16": 0,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73846001113917, -1.3876409068306637]),
            {
              "LC16": 0,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73519581208927, -1.3855046731328582]),
            {
              "LC16": 0,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73577516923649, -1.3860624094341947]),
            {
              "LC16": 0,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73622578035099, -1.3856119301240843]),
            {
              "LC16": 0,
              "system:index": "147"
            })]),
    ForestedAreas16 = ui.import && ui.import("ForestedAreas16", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.70684680519027,
            -1.3710684924881453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70873508033675,
            -1.3697814004158202
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70633182105941,
            -1.3671214079428609
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6880498844139,
            -1.3678078578956798
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.691397281264486,
            -1.3670356016849534
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69422969398421,
            -1.3693523695713692
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69723376808089,
            -1.3672072141977023
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.696632953261556,
            -1.3555375354656582
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69860705909652,
            -1.3574252814393712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69920787391585,
            -1.3593130259392787
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70384273109359,
            -1.3642039934549137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71328410682601,
            -1.3739000926104803
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.710623355483236,
            -1.3750155705254172
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70555934486312,
            -1.37381428659544
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70796260414046,
            -1.3671214079428609
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.695688815688314,
            -1.3656627011415632
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64976939735335,
            -1.4035747584510603
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6481386142723,
            -1.4036605633856154
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64616450843734,
            -1.4035747584510603
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.695299768939016,
            -1.398083236098698
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70542779017925,
            -1.3785649474236406
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70388283778667,
            -1.3773636652814405
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.685858393206594,
            -1.3447572061665303
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64963599072713,
            -1.3351467977867346
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64929266797322,
            -1.3305131945914743
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65152426587361,
            -1.3202875211362095
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69248491202186,
            -1.367771706724855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69531732474159,
            -1.370774923003506
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC16": 1
      },
      "color": "#98ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.70684680519027, -1.3710684924881453]),
            {
              "LC16": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70873508033675, -1.3697814004158202]),
            {
              "LC16": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70633182105941, -1.3671214079428609]),
            {
              "LC16": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6880498844139, -1.3678078578956798]),
            {
              "LC16": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.691397281264486, -1.3670356016849534]),
            {
              "LC16": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69422969398421, -1.3693523695713692]),
            {
              "LC16": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69723376808089, -1.3672072141977023]),
            {
              "LC16": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.696632953261556, -1.3555375354656582]),
            {
              "LC16": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69860705909652, -1.3574252814393712]),
            {
              "LC16": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69920787391585, -1.3593130259392787]),
            {
              "LC16": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70384273109359, -1.3642039934549137]),
            {
              "LC16": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71328410682601, -1.3739000926104803]),
            {
              "LC16": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.710623355483236, -1.3750155705254172]),
            {
              "LC16": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70555934486312, -1.37381428659544]),
            {
              "LC16": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70796260414046, -1.3671214079428609]),
            {
              "LC16": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.695688815688314, -1.3656627011415632]),
            {
              "LC16": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64976939735335, -1.4035747584510603]),
            {
              "LC16": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6481386142723, -1.4036605633856154]),
            {
              "LC16": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64616450843734, -1.4035747584510603]),
            {
              "LC16": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.695299768939016, -1.398083236098698]),
            {
              "LC16": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70542779017925, -1.3785649474236406]),
            {
              "LC16": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70388283778667, -1.3773636652814405]),
            {
              "LC16": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.685858393206594, -1.3447572061665303]),
            {
              "LC16": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64963599072713, -1.3351467977867346]),
            {
              "LC16": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64929266797322, -1.3305131945914743]),
            {
              "LC16": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65152426587361, -1.3202875211362095]),
            {
              "LC16": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69248491202186, -1.367771706724855]),
            {
              "LC16": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69531732474159, -1.370774923003506]),
            {
              "LC16": 1,
              "system:index": "27"
            })]),
    Vegetation16 = ui.import && ui.import("Vegetation16", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.66745086210941,
            -1.3581184861279674
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67440314787601,
            -1.3525410521904868
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67466063994144,
            -1.3531416995390795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67779346007084,
            -1.3539568635599573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67706389921879,
            -1.354814930654212
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.677106814563025,
            -1.3556300941122719
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6673221160767,
            -1.3587620353703962
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66153811933454,
            -1.3657647825832624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67488479139264,
            -1.3608738182366558
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.684283251780826,
            -1.3617318828755223
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68514155866559,
            -1.3625899472089156
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68462657453473,
            -1.3640057526906832
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68338202955182,
            -1.364778009875143
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68879525981154,
            -1.3871512324531894
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69566171488967,
            -1.3877518711236767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6973783286592,
            -1.3812735459986583
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67795141699969,
            -1.3746298352832877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67825182440936,
            -1.3757453128572563
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72134262288738,
            -1.3940141027922417
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71844126553517,
            -1.432272072878901
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74612660449253,
            -1.38593751842061
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79578970577865,
            -1.3878731656936187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7961759438768,
            -1.3885596096664732
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81325625088363,
            -1.3867147910376878
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.82029436733871,
            -1.386757693812843
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.715658914480855,
            -1.3820966724278287
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.717375528250386,
            -1.3881888705950916
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.681428553409255,
            -1.3865011324531913
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68172896081892,
            -1.3876595072137243
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71783944313717,
            -1.4017217993597249
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7661945662295,
            -1.387908156978643
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76987354070644,
            -1.3891424017051446
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.730134702466756,
            -1.379762757914327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66173346837924,
            -1.352468746568718
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.662613232936124,
            -1.3537772995690573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65975936254428,
            -1.3549785935049579
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66072495778964,
            -1.353627137785212
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67528001118669,
            -1.3663822904821181
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67055932332048,
            -1.3653955180275015
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.672705090532396,
            -1.365824549579295
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65554892201417,
            -1.386684012257471
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.670424305790725,
            -1.3579224033362471
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.715985584725594,
            -1.4173992002808982
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72508363770411,
            -1.4155758555029747
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.726692963113045,
            -1.4086724339832177
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72881727265284,
            -1.3987405131974409
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72898893402979,
            -1.3993411489130783
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67856310878232,
            -1.3456184639930504
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67328452144101,
            -1.3409245517196458
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67720311857591,
            -1.3753125108039295
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC16": 2
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.66745086210941, -1.3581184861279674]),
            {
              "LC16": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67440314787601, -1.3525410521904868]),
            {
              "LC16": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67466063994144, -1.3531416995390795]),
            {
              "LC16": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67779346007084, -1.3539568635599573]),
            {
              "LC16": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67706389921879, -1.354814930654212]),
            {
              "LC16": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.677106814563025, -1.3556300941122719]),
            {
              "LC16": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6673221160767, -1.3587620353703962]),
            {
              "LC16": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66153811933454, -1.3657647825832624]),
            {
              "LC16": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67488479139264, -1.3608738182366558]),
            {
              "LC16": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.684283251780826, -1.3617318828755223]),
            {
              "LC16": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68514155866559, -1.3625899472089156]),
            {
              "LC16": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68462657453473, -1.3640057526906832]),
            {
              "LC16": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68338202955182, -1.364778009875143]),
            {
              "LC16": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68879525981154, -1.3871512324531894]),
            {
              "LC16": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69566171488967, -1.3877518711236767]),
            {
              "LC16": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6973783286592, -1.3812735459986583]),
            {
              "LC16": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67795141699969, -1.3746298352832877]),
            {
              "LC16": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67825182440936, -1.3757453128572563]),
            {
              "LC16": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72134262288738, -1.3940141027922417]),
            {
              "LC16": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71844126553517, -1.432272072878901]),
            {
              "LC16": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74612660449253, -1.38593751842061]),
            {
              "LC16": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79578970577865, -1.3878731656936187]),
            {
              "LC16": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7961759438768, -1.3885596096664732]),
            {
              "LC16": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81325625088363, -1.3867147910376878]),
            {
              "LC16": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.82029436733871, -1.386757693812843]),
            {
              "LC16": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.715658914480855, -1.3820966724278287]),
            {
              "LC16": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.717375528250386, -1.3881888705950916]),
            {
              "LC16": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.681428553409255, -1.3865011324531913]),
            {
              "LC16": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68172896081892, -1.3876595072137243]),
            {
              "LC16": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71783944313717, -1.4017217993597249]),
            {
              "LC16": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7661945662295, -1.387908156978643]),
            {
              "LC16": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76987354070644, -1.3891424017051446]),
            {
              "LC16": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.730134702466756, -1.379762757914327]),
            {
              "LC16": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66173346837924, -1.352468746568718]),
            {
              "LC16": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.662613232936124, -1.3537772995690573]),
            {
              "LC16": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65975936254428, -1.3549785935049579]),
            {
              "LC16": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66072495778964, -1.353627137785212]),
            {
              "LC16": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67528001118669, -1.3663822904821181]),
            {
              "LC16": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67055932332048, -1.3653955180275015]),
            {
              "LC16": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.672705090532396, -1.365824549579295]),
            {
              "LC16": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65554892201417, -1.386684012257471]),
            {
              "LC16": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.670424305790725, -1.3579224033362471]),
            {
              "LC16": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.715985584725594, -1.4173992002808982]),
            {
              "LC16": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72508363770411, -1.4155758555029747]),
            {
              "LC16": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.726692963113045, -1.4086724339832177]),
            {
              "LC16": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72881727265284, -1.3987405131974409]),
            {
              "LC16": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72898893402979, -1.3993411489130783]),
            {
              "LC16": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67856310878232, -1.3456184639930504]),
            {
              "LC16": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67328452144101, -1.3409245517196458]),
            {
              "LC16": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67720311857591, -1.3753125108039295]),
            {
              "LC16": 2,
              "system:index": "49"
            })]),
    NonBuilt_Up16 = ui.import && ui.import("NonBuilt_Up16", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.81805127836595,
            -1.3855663012681716
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81805127836595,
            -1.3890843279539207
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.8138455746306,
            -1.389255938877881
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81727880216966,
            -1.3862527459102274
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.816935479415754,
            -1.3898565770135645
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81138681747008,
            -1.3890787473425752
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81018518783141,
            -1.3903229262617351
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.725925542559935,
            -1.3855867068860175
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72480974360974,
            -1.3852863872951526
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72725591823132,
            -1.3835273717844694
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72759924098523,
            -1.384471233928077
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66282415782616,
            -1.355586668822375
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.663167480580064,
            -1.3563803803609984
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66280270015404,
            -1.3561015087689765
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66509867107079,
            -1.3386250731161062
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66527033244774,
            -1.3394187901818213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66572094356224,
            -1.3388181394530496
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66529179011986,
            -1.3399979889594147
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71944916227879,
            -1.368617073952864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.719469326841214,
            -1.368938847192102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71492356425994,
            -1.375866281853726
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC16": 3
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.81805127836595, -1.3855663012681716]),
            {
              "LC16": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81805127836595, -1.3890843279539207]),
            {
              "LC16": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.8138455746306, -1.389255938877881]),
            {
              "LC16": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81727880216966, -1.3862527459102274]),
            {
              "LC16": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.816935479415754, -1.3898565770135645]),
            {
              "LC16": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81138681747008, -1.3890787473425752]),
            {
              "LC16": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81018518783141, -1.3903229262617351]),
            {
              "LC16": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.725925542559935, -1.3855867068860175]),
            {
              "LC16": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72480974360974, -1.3852863872951526]),
            {
              "LC16": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72725591823132, -1.3835273717844694]),
            {
              "LC16": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72759924098523, -1.384471233928077]),
            {
              "LC16": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66282415782616, -1.355586668822375]),
            {
              "LC16": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.663167480580064, -1.3563803803609984]),
            {
              "LC16": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66280270015404, -1.3561015087689765]),
            {
              "LC16": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66509867107079, -1.3386250731161062]),
            {
              "LC16": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66527033244774, -1.3394187901818213]),
            {
              "LC16": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66572094356224, -1.3388181394530496]),
            {
              "LC16": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66529179011986, -1.3399979889594147]),
            {
              "LC16": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71944916227879, -1.368617073952864]),
            {
              "LC16": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.719469326841214, -1.368938847192102]),
            {
              "LC16": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71492356425994, -1.375866281853726]),
            {
              "LC16": 3,
              "system:index": "20"
            })]),
    Water16 = ui.import && ui.import("Water16", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.6934971318754,
            -1.435901856005378
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69260663848245,
            -1.4357838758649437
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6929928765806,
            -1.4359983852066611
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.693776081612945,
            -1.4362557963901428
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.694280336907745,
            -1.4367062658914604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.694629714330304,
            -1.437414987192117
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69523052914964,
            -1.4383802783818584
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69604592069017,
            -1.438315925648575
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.695380732854474,
            -1.4391739619430888
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.694629714330304,
            -1.439860390746275
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.693621203740705,
            -1.4417266180096922
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692355201085675,
            -1.4426061038909472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69151835187303,
            -1.4430351212706345
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69344954236375,
            -1.4423057916770226
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.694329306920636,
            -1.4428849651969406
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69475846036302,
            -1.4403323104285635
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69490866406785,
            -1.4412117968483753
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69424347623216,
            -1.4405468193427506
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.695595309575666,
            -1.4393884709662927
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69555239423143,
            -1.4409329353374014
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69501595242845,
            -1.442799161721815
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74129550334276,
            -1.404626263911625
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74203579303087,
            -1.404347397977988
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74005632277788,
            -1.4035429768291667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73955206748308,
            -1.4030817752456965
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73913900729479,
            -1.4030871380553294
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.98523003467488,
            -1.1222539871977337
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.98385674365925,
            -1.1216103804434718
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.981582230414624,
            -1.1191217663292867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.979522293891186,
            -1.1179632728314466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.977333611335034,
            -1.1170622220170598
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.976089066352124,
            -1.1181349015266415
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.97149712451863,
            -1.1183065302118116
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.96969468006062,
            -1.1170622220170598
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.968535965766186,
            -1.1175771082305541
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.978063172187085,
            -1.1171909435788874
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.98269802936482,
            -1.119679559331758
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.90318796957474,
            -1.1217681367889143
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.904260853180695,
            -1.122926628782123
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.90507624472122,
            -1.1241280274012226
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.90619204367142,
            -1.1248145406759464
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.90267298544388,
            -1.1223688363982314
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC16": 4
      },
      "color": "#00ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.6934971318754, -1.435901856005378]),
            {
              "LC16": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69260663848245, -1.4357838758649437]),
            {
              "LC16": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6929928765806, -1.4359983852066611]),
            {
              "LC16": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.693776081612945, -1.4362557963901428]),
            {
              "LC16": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.694280336907745, -1.4367062658914604]),
            {
              "LC16": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.694629714330304, -1.437414987192117]),
            {
              "LC16": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69523052914964, -1.4383802783818584]),
            {
              "LC16": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69604592069017, -1.438315925648575]),
            {
              "LC16": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.695380732854474, -1.4391739619430888]),
            {
              "LC16": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.694629714330304, -1.439860390746275]),
            {
              "LC16": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.693621203740705, -1.4417266180096922]),
            {
              "LC16": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692355201085675, -1.4426061038909472]),
            {
              "LC16": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69151835187303, -1.4430351212706345]),
            {
              "LC16": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69344954236375, -1.4423057916770226]),
            {
              "LC16": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.694329306920636, -1.4428849651969406]),
            {
              "LC16": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69475846036302, -1.4403323104285635]),
            {
              "LC16": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69490866406785, -1.4412117968483753]),
            {
              "LC16": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69424347623216, -1.4405468193427506]),
            {
              "LC16": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.695595309575666, -1.4393884709662927]),
            {
              "LC16": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69555239423143, -1.4409329353374014]),
            {
              "LC16": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69501595242845, -1.442799161721815]),
            {
              "LC16": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74129550334276, -1.404626263911625]),
            {
              "LC16": 4,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74203579303087, -1.404347397977988]),
            {
              "LC16": 4,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74005632277788, -1.4035429768291667]),
            {
              "LC16": 4,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73955206748308, -1.4030817752456965]),
            {
              "LC16": 4,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73913900729479, -1.4030871380553294]),
            {
              "LC16": 4,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.98523003467488, -1.1222539871977337]),
            {
              "LC16": 4,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.98385674365925, -1.1216103804434718]),
            {
              "LC16": 4,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.981582230414624, -1.1191217663292867]),
            {
              "LC16": 4,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.979522293891186, -1.1179632728314466]),
            {
              "LC16": 4,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.977333611335034, -1.1170622220170598]),
            {
              "LC16": 4,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.976089066352124, -1.1181349015266415]),
            {
              "LC16": 4,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.97149712451863, -1.1183065302118116]),
            {
              "LC16": 4,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.96969468006062, -1.1170622220170598]),
            {
              "LC16": 4,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.968535965766186, -1.1175771082305541]),
            {
              "LC16": 4,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.978063172187085, -1.1171909435788874]),
            {
              "LC16": 4,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.98269802936482, -1.119679559331758]),
            {
              "LC16": 4,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.90318796957474, -1.1217681367889143]),
            {
              "LC16": 4,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.904260853180695, -1.122926628782123]),
            {
              "LC16": 4,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.90507624472122, -1.1241280274012226]),
            {
              "LC16": 4,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.90619204367142, -1.1248145406759464]),
            {
              "LC16": 4,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.90267298544388, -1.1223688363982314]),
            {
              "LC16": 4,
              "system:index": "41"
            })]),
    Vegetation18 = ui.import && ui.import("Vegetation18", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.64862148915338,
            -1.3809079437535756
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65797703419732,
            -1.386227894983261
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64437287007379,
            -1.3877723947162854
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64338581715631,
            -1.3884159359740844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.640467573748104,
            -1.3897459206849718
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63905136738824,
            -1.3881585194919897
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63982384358453,
            -1.3860133810517359
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.639695097551815,
            -1.3840827547939947
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64038174305963,
            -1.384168560438844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64934911023469,
            -1.3675807044167216
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.660635845769356,
            -1.3729435884141292
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66123666058869,
            -1.372857782364739
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67867322028,
            -1.3621232922988296
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67835135519821,
            -1.3625094212239617
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67738575995285,
            -1.3542616081094563
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67830843985397,
            -1.3536395093543745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.678694677952116,
            -1.3555487084750015
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.678501558903044,
            -1.355827580130711
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68229956686813,
            -1.3530388621290472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68931622565109,
            -1.3522666011922455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69105429709274,
            -1.353081765507223
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69229884207565,
            -1.353339185760298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69283528387863,
            -1.3535322509321788
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69339318335373,
            -1.3541114463555972
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68281455099899,
            -1.3567929048446692
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68515343725998,
            -1.3521807944063278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6866340166362,
            -1.3527814418440904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68815751135666,
            -1.350614820030572
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68788133824208,
            -1.4159700403115911
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.686486589554335,
            -1.4260394747156349
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68682991230824,
            -1.4265972013320423
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68740926945546,
            -1.427176378829053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70240818226674,
            -1.4256533562097071
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.688439237717176,
            -1.4278413602198272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68879328930714,
            -1.4282221156069723
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70425564565749,
            -1.424463171621282
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68518646604876,
            -1.4226267946322524
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68147428877215,
            -1.4179504592374779
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68256863005023,
            -1.418250774638789
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68394192106585,
            -1.4184438345190409
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69469221479754,
            -1.4162343704827978
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.685100635360286,
            -1.4217258500171717
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69367229021459,
            -1.4158251570971054
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68023978746801,
            -1.4177128549907805
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6949168351975,
            -1.4169513406846879
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.690842671113884,
            -1.4092195257509224
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.690842671113884,
            -1.4094769399224716
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69039205999938,
            -1.4093482328402465
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69068015420319,
            -1.4082236294587531
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC18": 2
      },
      "color": "#ffc82d",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.64862148915338, -1.3809079437535756]),
            {
              "LC18": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65797703419732, -1.386227894983261]),
            {
              "LC18": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64437287007379, -1.3877723947162854]),
            {
              "LC18": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64338581715631, -1.3884159359740844]),
            {
              "LC18": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.640467573748104, -1.3897459206849718]),
            {
              "LC18": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63905136738824, -1.3881585194919897]),
            {
              "LC18": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63982384358453, -1.3860133810517359]),
            {
              "LC18": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.639695097551815, -1.3840827547939947]),
            {
              "LC18": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64038174305963, -1.384168560438844]),
            {
              "LC18": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64934911023469, -1.3675807044167216]),
            {
              "LC18": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.660635845769356, -1.3729435884141292]),
            {
              "LC18": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66123666058869, -1.372857782364739]),
            {
              "LC18": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67867322028, -1.3621232922988296]),
            {
              "LC18": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67835135519821, -1.3625094212239617]),
            {
              "LC18": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67738575995285, -1.3542616081094563]),
            {
              "LC18": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67830843985397, -1.3536395093543745]),
            {
              "LC18": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.678694677952116, -1.3555487084750015]),
            {
              "LC18": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.678501558903044, -1.355827580130711]),
            {
              "LC18": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68229956686813, -1.3530388621290472]),
            {
              "LC18": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68931622565109, -1.3522666011922455]),
            {
              "LC18": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69105429709274, -1.353081765507223]),
            {
              "LC18": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69229884207565, -1.353339185760298]),
            {
              "LC18": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69283528387863, -1.3535322509321788]),
            {
              "LC18": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69339318335373, -1.3541114463555972]),
            {
              "LC18": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68281455099899, -1.3567929048446692]),
            {
              "LC18": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68515343725998, -1.3521807944063278]),
            {
              "LC18": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6866340166362, -1.3527814418440904]),
            {
              "LC18": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68815751135666, -1.350614820030572]),
            {
              "LC18": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68788133824208, -1.4159700403115911]),
            {
              "LC18": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.686486589554335, -1.4260394747156349]),
            {
              "LC18": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68682991230824, -1.4265972013320423]),
            {
              "LC18": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68740926945546, -1.427176378829053]),
            {
              "LC18": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70240818226674, -1.4256533562097071]),
            {
              "LC18": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.688439237717176, -1.4278413602198272]),
            {
              "LC18": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68879328930714, -1.4282221156069723]),
            {
              "LC18": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70425564565749, -1.424463171621282]),
            {
              "LC18": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68518646604876, -1.4226267946322524]),
            {
              "LC18": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68147428877215, -1.4179504592374779]),
            {
              "LC18": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68256863005023, -1.418250774638789]),
            {
              "LC18": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68394192106585, -1.4184438345190409]),
            {
              "LC18": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69469221479754, -1.4162343704827978]),
            {
              "LC18": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.685100635360286, -1.4217258500171717]),
            {
              "LC18": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69367229021459, -1.4158251570971054]),
            {
              "LC18": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68023978746801, -1.4177128549907805]),
            {
              "LC18": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6949168351975, -1.4169513406846879]),
            {
              "LC18": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.690842671113884, -1.4092195257509224]),
            {
              "LC18": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.690842671113884, -1.4094769399224716]),
            {
              "LC18": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69039205999938, -1.4093482328402465]),
            {
              "LC18": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69068015420319, -1.4082236294587531]),
            {
              "LC18": 2,
              "system:index": "48"
            })]),
    NonBuilt_Up18 = ui.import && ui.import("NonBuilt_Up18", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.78485139166198,
            -1.4003285603329754
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.780516941893914,
            -1.3965960374662498
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77631123815856,
            -1.4009291956417946
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78086026464782,
            -1.4024736857286548
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78841336523376,
            -1.397926017559188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.78768380438171,
            -1.3964673296753718
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.795236904967645,
            -1.3972395763149315
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79085953985534,
            -1.3949657382611074
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.794721920836786,
            -1.3930351193204995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79583771978698,
            -1.3918767471966589
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.795966465819696,
            -1.393292535270704
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.796996434081414,
            -1.3933354379263339
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.789357502807,
            -1.3952660566206652
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79386361395202,
            -1.3972824788985663
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79781182562194,
            -1.393893172378432
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.80184586798034,
            -1.3919625525586805
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.80107339178405,
            -1.3896029039658588
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.811082524772445,
            -1.389126177817415
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.810052556510726,
            -1.3899413295807534
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.810310048576156,
            -1.3887829559381852
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81700484227733,
            -1.388439734009097
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81249873113231,
            -1.3890832750852355
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81593195867137,
            -1.3866378180641594
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79996745061473,
            -1.3903274540020165
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.79151312779979,
            -1.3895552050963371
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.81687609624461,
            -1.389812621426287
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.695459812420246,
            -1.4073383401756887
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69485899760091,
            -1.4096979709222146
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.690224140423176,
            -1.3989294548568918
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6910395319637,
            -1.398672039523855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70048618087346,
            -1.3996911574786528
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69602298507268,
            -1.3999485726998486
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.652811168899156,
            -1.337481662650484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.653583645095445,
            -1.3310461064079324
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66542828010521,
            -1.3335345234844398
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66868984626732,
            -1.3324190264851061
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66611492561302,
            -1.3287293020447781
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71343287120946,
            -1.4020337226652284
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.716909014092764,
            -1.4010469650418436
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71978434215673,
            -1.4013901851319224
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71278914104589,
            -1.404264651410567
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71472033153661,
            -1.4044791636777585
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.717595659600576,
            -1.4010040625270486
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71802481304296,
            -1.4019908201685116
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.693090605551234,
            -1.3579666588671333
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69266145210885,
            -1.359082144181796
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69272582512521,
            -1.3590177892738018
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.692039179617396,
            -1.3588676278151366
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69218938332223,
            -1.36011182247649
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6924897907319,
            -1.3595755317528058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72726436356544,
            -1.3835661234746994
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72743602494239,
            -1.3841882144650295
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72765060166358,
            -1.3845528884179652
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7287878582859,
            -1.3815282380539096
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72902389267921,
            -1.3820859752902908
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.726384599008554,
            -1.3836304777226391
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7256550381565,
            -1.3838878946969695
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.698325576782224,
            -1.3937362217435185
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69875473022461,
            -1.395838450553822
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71072811126709,
            -1.3883304819066302
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71021312713623,
            -1.390046591132798
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.710492643118464,
            -1.381358209301252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.710492643118464,
            -1.3820017523007482
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71555665373858,
            -1.3836320604521801
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.714226278067194,
            -1.384919145043472
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68691173983456,
            -1.3910031894250958
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68465868426205,
            -1.3910031894250958
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6813542027557,
            -1.3924618806952613
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6826415289511,
            -1.3980967850936188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66889849442171,
            -1.385966447892637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66107262087092,
            -1.3815903593656882
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67279339861029,
            -1.378351190606097
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.67206383775824,
            -1.3782653847511912
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.677149306050474,
            -1.3769353936048714
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.664303202297255,
            -1.3779213227209488
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65968167966219,
            -1.368643545123696
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65916669553133,
            -1.3679141922963358
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66118371671053,
            -1.3664125828361386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66023957913729,
            -1.3625727486639057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65483224576327,
            -1.3599556514736053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64856660550448,
            -1.3594193607152147
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.662601078085075,
            -1.3561372586803486
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66275128178991,
            -1.3540564465874585
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65518676568628,
            -1.3484954353514833
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65192519952417,
            -1.34079425234184
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65226852227808,
            -1.3442908927641266
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.651627228802,
            -1.3387519196150246
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65527503306225,
            -1.3344099251359272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65278594309643,
            -1.3324149020094775
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC18": 3
      },
      "color": "#00ffff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #00ffff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.78485139166198, -1.4003285603329754]),
            {
              "LC18": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.780516941893914, -1.3965960374662498]),
            {
              "LC18": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77631123815856, -1.4009291956417946]),
            {
              "LC18": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78086026464782, -1.4024736857286548]),
            {
              "LC18": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78841336523376, -1.397926017559188]),
            {
              "LC18": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.78768380438171, -1.3964673296753718]),
            {
              "LC18": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.795236904967645, -1.3972395763149315]),
            {
              "LC18": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79085953985534, -1.3949657382611074]),
            {
              "LC18": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.794721920836786, -1.3930351193204995]),
            {
              "LC18": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79583771978698, -1.3918767471966589]),
            {
              "LC18": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.795966465819696, -1.393292535270704]),
            {
              "LC18": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.796996434081414, -1.3933354379263339]),
            {
              "LC18": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.789357502807, -1.3952660566206652]),
            {
              "LC18": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79386361395202, -1.3972824788985663]),
            {
              "LC18": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79781182562194, -1.393893172378432]),
            {
              "LC18": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.80184586798034, -1.3919625525586805]),
            {
              "LC18": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.80107339178405, -1.3896029039658588]),
            {
              "LC18": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.811082524772445, -1.389126177817415]),
            {
              "LC18": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.810052556510726, -1.3899413295807534]),
            {
              "LC18": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.810310048576156, -1.3887829559381852]),
            {
              "LC18": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81700484227733, -1.388439734009097]),
            {
              "LC18": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81249873113231, -1.3890832750852355]),
            {
              "LC18": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81593195867137, -1.3866378180641594]),
            {
              "LC18": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79996745061473, -1.3903274540020165]),
            {
              "LC18": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.79151312779979, -1.3895552050963371]),
            {
              "LC18": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.81687609624461, -1.389812621426287]),
            {
              "LC18": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.695459812420246, -1.4073383401756887]),
            {
              "LC18": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69485899760091, -1.4096979709222146]),
            {
              "LC18": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.690224140423176, -1.3989294548568918]),
            {
              "LC18": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6910395319637, -1.398672039523855]),
            {
              "LC18": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70048618087346, -1.3996911574786528]),
            {
              "LC18": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69602298507268, -1.3999485726998486]),
            {
              "LC18": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.652811168899156, -1.337481662650484]),
            {
              "LC18": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.653583645095445, -1.3310461064079324]),
            {
              "LC18": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66542828010521, -1.3335345234844398]),
            {
              "LC18": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66868984626732, -1.3324190264851061]),
            {
              "LC18": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66611492561302, -1.3287293020447781]),
            {
              "LC18": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71343287120946, -1.4020337226652284]),
            {
              "LC18": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.716909014092764, -1.4010469650418436]),
            {
              "LC18": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71978434215673, -1.4013901851319224]),
            {
              "LC18": 3,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71278914104589, -1.404264651410567]),
            {
              "LC18": 3,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71472033153661, -1.4044791636777585]),
            {
              "LC18": 3,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.717595659600576, -1.4010040625270486]),
            {
              "LC18": 3,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71802481304296, -1.4019908201685116]),
            {
              "LC18": 3,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.693090605551234, -1.3579666588671333]),
            {
              "LC18": 3,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69266145210885, -1.359082144181796]),
            {
              "LC18": 3,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69272582512521, -1.3590177892738018]),
            {
              "LC18": 3,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.692039179617396, -1.3588676278151366]),
            {
              "LC18": 3,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69218938332223, -1.36011182247649]),
            {
              "LC18": 3,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6924897907319, -1.3595755317528058]),
            {
              "LC18": 3,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72726436356544, -1.3835661234746994]),
            {
              "LC18": 3,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72743602494239, -1.3841882144650295]),
            {
              "LC18": 3,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72765060166358, -1.3845528884179652]),
            {
              "LC18": 3,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7287878582859, -1.3815282380539096]),
            {
              "LC18": 3,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72902389267921, -1.3820859752902908]),
            {
              "LC18": 3,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.726384599008554, -1.3836304777226391]),
            {
              "LC18": 3,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7256550381565, -1.3838878946969695]),
            {
              "LC18": 3,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.698325576782224, -1.3937362217435185]),
            {
              "LC18": 3,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69875473022461, -1.395838450553822]),
            {
              "LC18": 3,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71072811126709, -1.3883304819066302]),
            {
              "LC18": 3,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71021312713623, -1.390046591132798]),
            {
              "LC18": 3,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.710492643118464, -1.381358209301252]),
            {
              "LC18": 3,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.710492643118464, -1.3820017523007482]),
            {
              "LC18": 3,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71555665373858, -1.3836320604521801]),
            {
              "LC18": 3,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.714226278067194, -1.384919145043472]),
            {
              "LC18": 3,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68691173983456, -1.3910031894250958]),
            {
              "LC18": 3,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68465868426205, -1.3910031894250958]),
            {
              "LC18": 3,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6813542027557, -1.3924618806952613]),
            {
              "LC18": 3,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6826415289511, -1.3980967850936188]),
            {
              "LC18": 3,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66889849442171, -1.385966447892637]),
            {
              "LC18": 3,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66107262087092, -1.3815903593656882]),
            {
              "LC18": 3,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67279339861029, -1.378351190606097]),
            {
              "LC18": 3,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([36.67206383775824, -1.3782653847511912]),
            {
              "LC18": 3,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([36.677149306050474, -1.3769353936048714]),
            {
              "LC18": 3,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([36.664303202297255, -1.3779213227209488]),
            {
              "LC18": 3,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65968167966219, -1.368643545123696]),
            {
              "LC18": 3,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65916669553133, -1.3679141922963358]),
            {
              "LC18": 3,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66118371671053, -1.3664125828361386]),
            {
              "LC18": 3,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66023957913729, -1.3625727486639057]),
            {
              "LC18": 3,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65483224576327, -1.3599556514736053]),
            {
              "LC18": 3,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64856660550448, -1.3594193607152147]),
            {
              "LC18": 3,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([36.662601078085075, -1.3561372586803486]),
            {
              "LC18": 3,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66275128178991, -1.3540564465874585]),
            {
              "LC18": 3,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65518676568628, -1.3484954353514833]),
            {
              "LC18": 3,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65192519952417, -1.34079425234184]),
            {
              "LC18": 3,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65226852227808, -1.3442908927641266]),
            {
              "LC18": 3,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([36.651627228802, -1.3387519196150246]),
            {
              "LC18": 3,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65527503306225, -1.3344099251359272]),
            {
              "LC18": 3,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65278594309643, -1.3324149020094775]),
            {
              "LC18": 3,
              "system:index": "88"
            })]),
    Water18 = ui.import && ui.import("Water18", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.69546255910065,
            -1.4390235927497768
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69494757496979,
            -1.4401390395235592
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69460425221588,
            -1.4414689945787384
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69486174428131,
            -1.4420267174352468
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.695033405658265,
            -1.4420696191877773
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69541964375641,
            -1.4403964502399955
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69541964375641,
            -1.4410828786749752
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.732408049502176,
            -1.299935669762559
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73279428760032,
            -1.2994637224259202
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73236513415794,
            -1.3000643826572478
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72331357329163,
            -1.3088485750527283
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.722637656619874,
            -1.3087520407193276
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72181153624329,
            -1.3089987395639628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74981692613196,
            -1.3326197878304105
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75037482560706,
            -1.3324267210065115
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.748786957870244,
            -1.3317831648175604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75017097772193,
            -1.3327699509052047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71933977271727,
            -1.3463975338377274
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71931831504515,
            -1.3455394637723002
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71837417747191,
            -1.3455394637723002
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.718481465832504,
            -1.3457968848236308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71688471025154,
            -1.3412512849132265
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71684715932533,
            -1.3415355211547684
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC18": 4
      },
      "color": "#bf04c2",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #bf04c2 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.69546255910065, -1.4390235927497768]),
            {
              "LC18": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69494757496979, -1.4401390395235592]),
            {
              "LC18": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69460425221588, -1.4414689945787384]),
            {
              "LC18": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69486174428131, -1.4420267174352468]),
            {
              "LC18": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.695033405658265, -1.4420696191877773]),
            {
              "LC18": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69541964375641, -1.4403964502399955]),
            {
              "LC18": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69541964375641, -1.4410828786749752]),
            {
              "LC18": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.732408049502176, -1.299935669762559]),
            {
              "LC18": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73279428760032, -1.2994637224259202]),
            {
              "LC18": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73236513415794, -1.3000643826572478]),
            {
              "LC18": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72331357329163, -1.3088485750527283]),
            {
              "LC18": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.722637656619874, -1.3087520407193276]),
            {
              "LC18": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72181153624329, -1.3089987395639628]),
            {
              "LC18": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74981692613196, -1.3326197878304105]),
            {
              "LC18": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75037482560706, -1.3324267210065115]),
            {
              "LC18": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.748786957870244, -1.3317831648175604]),
            {
              "LC18": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75017097772193, -1.3327699509052047]),
            {
              "LC18": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71933977271727, -1.3463975338377274]),
            {
              "LC18": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71931831504515, -1.3455394637723002]),
            {
              "LC18": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71837417747191, -1.3455394637723002]),
            {
              "LC18": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.718481465832504, -1.3457968848236308]),
            {
              "LC18": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71688471025154, -1.3412512849132265]),
            {
              "LC18": 4,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71684715932533, -1.3415355211547684]),
            {
              "LC18": 4,
              "system:index": "22"
            })]),
    BuiltUp18 = ui.import && ui.import("BuiltUp18", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.74909442901611,
            -1.3927153234657828
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.751497688293455,
            -1.3941311110359387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74634784698486,
            -1.3932301554079203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76462978363037,
            -1.3973488068912516
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76179737091064,
            -1.3936162792907028
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.752742233276365,
            -1.3928869341256551
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77188247680664,
            -1.3908276053826336
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76454395294189,
            -1.3949033584426735
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76312774658203,
            -1.3965336576910587
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.759265365600584,
            -1.3971771965568263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75671128194233,
            -1.3939352822229725
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.754823006795846,
            -1.3947182553514883
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.755595482992135,
            -1.3933775477808485
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.758052386449776,
            -1.3924336891933553
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75971535603901,
            -1.392315706843339
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76252771119189,
            -1.3929471215055107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76514554719043,
            -1.3927111568509722
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76355767945361,
            -1.394877740518279
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76310706833911,
            -1.3955320054911198
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.741794193133465,
            -1.3909256831544021
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.742545211657635,
            -1.3915692235530062
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73760627427908,
            -1.3912260020289298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.736715780886136,
            -1.3907004439734214
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.730911212729445,
            -1.3896375780834767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.731908994482986,
            -1.3898091889672475
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72161569668907,
            -1.3998064165254394
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72185173108238,
            -1.3998922215980814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72317137791771,
            -1.400053106100844
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72315690114521,
            -1.3783641493321794
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72212693288349,
            -1.3806809062326921
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72720167233967,
            -1.3802411516241426
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72169777944111,
            -1.3764013396386194
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72356459691547,
            -1.3750177187197063
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72358423543968,
            -1.3723493775304076
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71533376050987,
            -1.3714250466750877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71554833723106,
            -1.3708780327103405
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71578437162437,
            -1.3704704535965155
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71758681608238,
            -1.3691082807918995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.662773193961904,
            -1.357331055458821
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.663985552436635,
            -1.3589506545862189
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66693598235302,
            -1.3570414581494965
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66989714110546,
            -1.3587254123884565
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66949824615223,
            -1.358733646403053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66644052787525,
            -1.3580364680411645
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.668371718365975,
            -1.3567708206549562
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.653126042325326,
            -1.365239515487021
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.653158228833504,
            -1.3641562104077505
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6542203836034,
            -1.3644994358322047
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6597135476659,
            -1.365100080207157
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.659124981493584,
            -1.3791124290901622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.66200567397558,
            -1.379557546770511
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.658824574083916,
            -1.380217178842446
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.658368598551384,
            -1.3802868960426091
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65866900596105,
            -1.377401674821181
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65842224273168,
            -1.3763398267260238
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6584437004038,
            -1.3777234468778252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64998937758886,
            -1.3724034766348476
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6505365482279,
            -1.3714488839465295
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.652081500620476,
            -1.372446379668073
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.65241409453832,
            -1.3712665459739883
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.648841392130485,
            -1.3721996872165054
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.649624597162834,
            -1.3712021913921282
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.6834162275194,
            -1.3909213569381873
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68043361109484,
            -1.3904601528770397
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68203220766772,
            -1.3901920109395927
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68165669840563,
            -1.3914361892720548
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.684564212977776,
            -1.3921655348860316
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.682579378306755,
            -1.3921226322090918
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68314121092207,
            -1.3984370633977088
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.683935144790475,
            -1.39808311723324
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68407461965925,
            -1.3971714374729802
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68580196226484,
            -1.39826545314281
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.686660269149606,
            -1.3977613479465028
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.68448231542951,
            -1.398072391591062
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70886494224422,
            -1.4105655283314251
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70757748191707,
            -1.4115415563500806
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.709455028227495,
            -1.4122601701239452
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71165443961971,
            -1.4112626912436932
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70913316314571,
            -1.4093535369252626
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70707322662227,
            -1.4136652202934634
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.702481284788774,
            -1.4138153782765712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.762698593139646,
            -1.3979406774846466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.770230236053465,
            -1.3977047133310327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76587432861328,
            -1.3967394051830444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.767741146087644,
            -1.396224574008629
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.770723762512205,
            -1.3956561144558868
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76519104284315,
            -1.3973321749602388
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76821657461195,
            -1.3972785467317033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76983662885694,
            -1.3974555198812444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76755585574565,
            -1.398243854658096
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7682317724174,
            -1.3983403854289065
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76399388217387,
            -1.3992842416453852
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.765892886156415,
            -1.398511995678322
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76076450251994,
            -1.3995416569112487
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76424901926093,
            -1.3989564554380096
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76593344652228,
            -1.397712281081088
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76825087511115,
            -1.3986025093518717
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76652353250556,
            -1.3974977681942864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75781196184827,
            -1.3987531566045914
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75783341952039,
            -1.3991178283054528
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75576275416089,
            -1.4021960842258927
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75209349222852,
            -1.4016061748680069
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75372427530957,
            -1.4008446552953866
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75198620386792,
            -1.396972699839775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75436800547315,
            -1.3970906819563134
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75496882029248,
            -1.3963613378682904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75486153193189,
            -1.3966402047522009
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74981897898389,
            -1.3969512485452158
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7475873810835,
            -1.3958143296537446
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.752930341441164,
            -1.397680592450115
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75276940890027,
            -1.3980774412443877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7515677792616,
            -1.3979272822490365
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.750655828196535,
            -1.3979594591774278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75597733088208,
            -1.3986995284085104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75621336527539,
            -1.3976055129409513
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75626700945569,
            -1.3982383258716118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75474351473523,
            -1.3974660795604252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75330585070325,
            -1.3977771232440928
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75779760951147,
            -1.397312368914735
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75814093226538,
            -1.3973338202059993
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75231517428503,
            -1.3985243665634106
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.757633029674516,
            -1.3885250966458202
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.759396121100565,
            -1.3866552653328839
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75323776920237,
            -1.3894653955319092
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7520361395637,
            -1.3889934655028693
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.748130843238016,
            -1.3888647572967634
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74746565540232,
            -1.3908382823529233
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75029806812205,
            -1.3870413902909229
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75458960254588,
            -1.386934133364453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.757872626380106,
            -1.386440751440098
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.763644740180155,
            -1.3843599656716923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76224999149241,
            -1.38678397365924
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76359740045662,
            -1.3892508818940383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76550713327522,
            -1.3890363682366644
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.767910392552565,
            -1.3893581387154101
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76653710153694,
            -1.3909240877527171
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7650350644886,
            -1.3874918693290066
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76754561212654,
            -1.3908811850532081
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75930586603279,
            -1.3906881228957555
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76947680261726,
            -1.390537963429046
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.773167522221755,
            -1.3913316633591664
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77623596933479,
            -1.3891865277988669
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.780184181004714,
            -1.3943992038204829
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77958336618538,
            -1.39547176947253
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.776665122777175,
            -1.3959651495082588
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77419749048347,
            -1.3995260632153923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7751201703846,
            -1.3948711327676127
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74681991577148,
            -1.3939507349734512
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7339453125,
            -1.3954952296518621
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72634929656982,
            -1.3933286465528185
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.728752555847166,
            -1.395409424418551
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.73171371459961,
            -1.3952163626321545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74559682846069,
            -1.3942725047817104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74503892898559,
            -1.3952163626321545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74085468292236,
            -1.3953665218007187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.741476955413816,
            -1.3931355845957663
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.743898176467106,
            -1.3910153729447259
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74634435108869,
            -1.3916803646616542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.750478872461194,
            -1.389283591072938
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.750221380395764,
            -1.3898198751236788
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.749427446527356,
            -1.3890261746853312
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7513800946902,
            -1.3900987427819398
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75601495186793,
            -1.3909353455590832
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75350440422999,
            -1.39076373475718
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75213111321437,
            -1.3911498590439184
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74974931160914,
            -1.3908924428597778
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74850476662623,
            -1.3917075940131876
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.750693449182386,
            -1.3921795234995484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75161612908351,
            -1.391879204746429
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75133717934596,
            -1.391192761738542
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74882663170802,
            -1.3895111094247858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.749706396264905,
            -1.3900044907084244
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.741466650171155,
            -1.3884599924334295
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75232423226344,
            -1.3877091942962838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74989951531398,
            -1.386700979280097
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75459874550807,
            -1.3877091942962838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75852549950587,
            -1.387752097053399
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75931943337428,
            -1.387323069447236
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76048550838487,
            -1.3917205987179535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76223459457935,
            -1.3870656528461756
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76248161373568,
            -1.390160140974027
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.766580029110436,
            -1.3897311138049868
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76398365078402,
            -1.3883153235943089
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76797477779818,
            -1.3908894869824688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76745979366732,
            -1.3894951488287925
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76966993389559,
            -1.3898169192450338
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76977722225619,
            -1.3915973814221367
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7694553571744,
            -1.3916402841086308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77243797359896,
            -1.3909752923804053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77542059002352,
            -1.3900743355464478
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77340356884432,
            -1.3912541599021568
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7649707037015,
            -1.3956087792305427
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.764090939144616,
            -1.3959305488120537
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7649707037015,
            -1.3962094157470695
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.77554933605624,
            -1.3963595748522262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72067431455978,
            -1.3732704921838346
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72108201033004,
            -1.3733777497265562
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.718271055282436,
            -1.370631955118146
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.718571462692104,
            -1.3709322765569005
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7221012497557,
            -1.3709322765569005
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72188021614145,
            -1.371768886080484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.722523946305024,
            -1.3709108250268023
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.722234267731416,
            -1.3714042101702602
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71971299125742,
            -1.3729058165025727
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.722770709534394,
            -1.372787833182029
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72307111694406,
            -1.3728843649901838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7166123576362,
            -1.370009860589487
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.716794747849214,
            -1.369076718493627
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.717009324570405,
            -1.3694842978445563
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC18": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.74909442901611, -1.3927153234657828]),
            {
              "LC18": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.751497688293455, -1.3941311110359387]),
            {
              "LC18": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74634784698486, -1.3932301554079203]),
            {
              "LC18": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76462978363037, -1.3973488068912516]),
            {
              "LC18": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76179737091064, -1.3936162792907028]),
            {
              "LC18": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.752742233276365, -1.3928869341256551]),
            {
              "LC18": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77188247680664, -1.3908276053826336]),
            {
              "LC18": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76454395294189, -1.3949033584426735]),
            {
              "LC18": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76312774658203, -1.3965336576910587]),
            {
              "LC18": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.759265365600584, -1.3971771965568263]),
            {
              "LC18": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75671128194233, -1.3939352822229725]),
            {
              "LC18": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.754823006795846, -1.3947182553514883]),
            {
              "LC18": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.755595482992135, -1.3933775477808485]),
            {
              "LC18": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.758052386449776, -1.3924336891933553]),
            {
              "LC18": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75971535603901, -1.392315706843339]),
            {
              "LC18": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76252771119189, -1.3929471215055107]),
            {
              "LC18": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76514554719043, -1.3927111568509722]),
            {
              "LC18": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76355767945361, -1.394877740518279]),
            {
              "LC18": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76310706833911, -1.3955320054911198]),
            {
              "LC18": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.741794193133465, -1.3909256831544021]),
            {
              "LC18": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.742545211657635, -1.3915692235530062]),
            {
              "LC18": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73760627427908, -1.3912260020289298]),
            {
              "LC18": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.736715780886136, -1.3907004439734214]),
            {
              "LC18": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.730911212729445, -1.3896375780834767]),
            {
              "LC18": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.731908994482986, -1.3898091889672475]),
            {
              "LC18": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72161569668907, -1.3998064165254394]),
            {
              "LC18": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72185173108238, -1.3998922215980814]),
            {
              "LC18": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72317137791771, -1.400053106100844]),
            {
              "LC18": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72315690114521, -1.3783641493321794]),
            {
              "LC18": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72212693288349, -1.3806809062326921]),
            {
              "LC18": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72720167233967, -1.3802411516241426]),
            {
              "LC18": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72169777944111, -1.3764013396386194]),
            {
              "LC18": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72356459691547, -1.3750177187197063]),
            {
              "LC18": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72358423543968, -1.3723493775304076]),
            {
              "LC18": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71533376050987, -1.3714250466750877]),
            {
              "LC18": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71554833723106, -1.3708780327103405]),
            {
              "LC18": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71578437162437, -1.3704704535965155]),
            {
              "LC18": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71758681608238, -1.3691082807918995]),
            {
              "LC18": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([36.662773193961904, -1.357331055458821]),
            {
              "LC18": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([36.663985552436635, -1.3589506545862189]),
            {
              "LC18": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66693598235302, -1.3570414581494965]),
            {
              "LC18": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66989714110546, -1.3587254123884565]),
            {
              "LC18": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66949824615223, -1.358733646403053]),
            {
              "LC18": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66644052787525, -1.3580364680411645]),
            {
              "LC18": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([36.668371718365975, -1.3567708206549562]),
            {
              "LC18": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([36.653126042325326, -1.365239515487021]),
            {
              "LC18": 0,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([36.653158228833504, -1.3641562104077505]),
            {
              "LC18": 0,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6542203836034, -1.3644994358322047]),
            {
              "LC18": 0,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6597135476659, -1.365100080207157]),
            {
              "LC18": 0,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([36.659124981493584, -1.3791124290901622]),
            {
              "LC18": 0,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([36.66200567397558, -1.379557546770511]),
            {
              "LC18": 0,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([36.658824574083916, -1.380217178842446]),
            {
              "LC18": 0,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([36.658368598551384, -1.3802868960426091]),
            {
              "LC18": 0,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65866900596105, -1.377401674821181]),
            {
              "LC18": 0,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65842224273168, -1.3763398267260238]),
            {
              "LC18": 0,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6584437004038, -1.3777234468778252]),
            {
              "LC18": 0,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64998937758886, -1.3724034766348476]),
            {
              "LC18": 0,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6505365482279, -1.3714488839465295]),
            {
              "LC18": 0,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([36.652081500620476, -1.372446379668073]),
            {
              "LC18": 0,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([36.65241409453832, -1.3712665459739883]),
            {
              "LC18": 0,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([36.648841392130485, -1.3721996872165054]),
            {
              "LC18": 0,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([36.649624597162834, -1.3712021913921282]),
            {
              "LC18": 0,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([36.6834162275194, -1.3909213569381873]),
            {
              "LC18": 0,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68043361109484, -1.3904601528770397]),
            {
              "LC18": 0,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68203220766772, -1.3901920109395927]),
            {
              "LC18": 0,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68165669840563, -1.3914361892720548]),
            {
              "LC18": 0,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([36.684564212977776, -1.3921655348860316]),
            {
              "LC18": 0,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([36.682579378306755, -1.3921226322090918]),
            {
              "LC18": 0,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68314121092207, -1.3984370633977088]),
            {
              "LC18": 0,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([36.683935144790475, -1.39808311723324]),
            {
              "LC18": 0,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68407461965925, -1.3971714374729802]),
            {
              "LC18": 0,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68580196226484, -1.39826545314281]),
            {
              "LC18": 0,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([36.686660269149606, -1.3977613479465028]),
            {
              "LC18": 0,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([36.68448231542951, -1.398072391591062]),
            {
              "LC18": 0,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70886494224422, -1.4105655283314251]),
            {
              "LC18": 0,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70757748191707, -1.4115415563500806]),
            {
              "LC18": 0,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([36.709455028227495, -1.4122601701239452]),
            {
              "LC18": 0,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71165443961971, -1.4112626912436932]),
            {
              "LC18": 0,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70913316314571, -1.4093535369252626]),
            {
              "LC18": 0,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70707322662227, -1.4136652202934634]),
            {
              "LC18": 0,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([36.702481284788774, -1.4138153782765712]),
            {
              "LC18": 0,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([36.762698593139646, -1.3979406774846466]),
            {
              "LC18": 0,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([36.770230236053465, -1.3977047133310327]),
            {
              "LC18": 0,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76587432861328, -1.3967394051830444]),
            {
              "LC18": 0,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([36.767741146087644, -1.396224574008629]),
            {
              "LC18": 0,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([36.770723762512205, -1.3956561144558868]),
            {
              "LC18": 0,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76519104284315, -1.3973321749602388]),
            {
              "LC18": 0,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76821657461195, -1.3972785467317033]),
            {
              "LC18": 0,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76983662885694, -1.3974555198812444]),
            {
              "LC18": 0,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76755585574565, -1.398243854658096]),
            {
              "LC18": 0,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7682317724174, -1.3983403854289065]),
            {
              "LC18": 0,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76399388217387, -1.3992842416453852]),
            {
              "LC18": 0,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([36.765892886156415, -1.398511995678322]),
            {
              "LC18": 0,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76076450251994, -1.3995416569112487]),
            {
              "LC18": 0,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76424901926093, -1.3989564554380096]),
            {
              "LC18": 0,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76593344652228, -1.397712281081088]),
            {
              "LC18": 0,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76825087511115, -1.3986025093518717]),
            {
              "LC18": 0,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76652353250556, -1.3974977681942864]),
            {
              "LC18": 0,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75781196184827, -1.3987531566045914]),
            {
              "LC18": 0,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75783341952039, -1.3991178283054528]),
            {
              "LC18": 0,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75576275416089, -1.4021960842258927]),
            {
              "LC18": 0,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75209349222852, -1.4016061748680069]),
            {
              "LC18": 0,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75372427530957, -1.4008446552953866]),
            {
              "LC18": 0,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75198620386792, -1.396972699839775]),
            {
              "LC18": 0,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75436800547315, -1.3970906819563134]),
            {
              "LC18": 0,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75496882029248, -1.3963613378682904]),
            {
              "LC18": 0,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75486153193189, -1.3966402047522009]),
            {
              "LC18": 0,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74981897898389, -1.3969512485452158]),
            {
              "LC18": 0,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7475873810835, -1.3958143296537446]),
            {
              "LC18": 0,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([36.752930341441164, -1.397680592450115]),
            {
              "LC18": 0,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75276940890027, -1.3980774412443877]),
            {
              "LC18": 0,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7515677792616, -1.3979272822490365]),
            {
              "LC18": 0,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([36.750655828196535, -1.3979594591774278]),
            {
              "LC18": 0,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75597733088208, -1.3986995284085104]),
            {
              "LC18": 0,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75621336527539, -1.3976055129409513]),
            {
              "LC18": 0,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75626700945569, -1.3982383258716118]),
            {
              "LC18": 0,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75474351473523, -1.3974660795604252]),
            {
              "LC18": 0,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75330585070325, -1.3977771232440928]),
            {
              "LC18": 0,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75779760951147, -1.397312368914735]),
            {
              "LC18": 0,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75814093226538, -1.3973338202059993]),
            {
              "LC18": 0,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75231517428503, -1.3985243665634106]),
            {
              "LC18": 0,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([36.757633029674516, -1.3885250966458202]),
            {
              "LC18": 0,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([36.759396121100565, -1.3866552653328839]),
            {
              "LC18": 0,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75323776920237, -1.3894653955319092]),
            {
              "LC18": 0,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7520361395637, -1.3889934655028693]),
            {
              "LC18": 0,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([36.748130843238016, -1.3888647572967634]),
            {
              "LC18": 0,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74746565540232, -1.3908382823529233]),
            {
              "LC18": 0,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75029806812205, -1.3870413902909229]),
            {
              "LC18": 0,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75458960254588, -1.386934133364453]),
            {
              "LC18": 0,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([36.757872626380106, -1.386440751440098]),
            {
              "LC18": 0,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([36.763644740180155, -1.3843599656716923]),
            {
              "LC18": 0,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76224999149241, -1.38678397365924]),
            {
              "LC18": 0,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76359740045662, -1.3892508818940383]),
            {
              "LC18": 0,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76550713327522, -1.3890363682366644]),
            {
              "LC18": 0,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([36.767910392552565, -1.3893581387154101]),
            {
              "LC18": 0,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76653710153694, -1.3909240877527171]),
            {
              "LC18": 0,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7650350644886, -1.3874918693290066]),
            {
              "LC18": 0,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76754561212654, -1.3908811850532081]),
            {
              "LC18": 0,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75930586603279, -1.3906881228957555]),
            {
              "LC18": 0,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76947680261726, -1.390537963429046]),
            {
              "LC18": 0,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([36.773167522221755, -1.3913316633591664]),
            {
              "LC18": 0,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77623596933479, -1.3891865277988669]),
            {
              "LC18": 0,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([36.780184181004714, -1.3943992038204829]),
            {
              "LC18": 0,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77958336618538, -1.39547176947253]),
            {
              "LC18": 0,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([36.776665122777175, -1.3959651495082588]),
            {
              "LC18": 0,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77419749048347, -1.3995260632153923]),
            {
              "LC18": 0,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7751201703846, -1.3948711327676127]),
            {
              "LC18": 0,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74681991577148, -1.3939507349734512]),
            {
              "LC18": 0,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7339453125, -1.3954952296518621]),
            {
              "LC18": 0,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72634929656982, -1.3933286465528185]),
            {
              "LC18": 0,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([36.728752555847166, -1.395409424418551]),
            {
              "LC18": 0,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([36.73171371459961, -1.3952163626321545]),
            {
              "LC18": 0,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74559682846069, -1.3942725047817104]),
            {
              "LC18": 0,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74503892898559, -1.3952163626321545]),
            {
              "LC18": 0,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74085468292236, -1.3953665218007187]),
            {
              "LC18": 0,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([36.741476955413816, -1.3931355845957663]),
            {
              "LC18": 0,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([36.743898176467106, -1.3910153729447259]),
            {
              "LC18": 0,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74634435108869, -1.3916803646616542]),
            {
              "LC18": 0,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([36.750478872461194, -1.389283591072938]),
            {
              "LC18": 0,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([36.750221380395764, -1.3898198751236788]),
            {
              "LC18": 0,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([36.749427446527356, -1.3890261746853312]),
            {
              "LC18": 0,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7513800946902, -1.3900987427819398]),
            {
              "LC18": 0,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75601495186793, -1.3909353455590832]),
            {
              "LC18": 0,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75350440422999, -1.39076373475718]),
            {
              "LC18": 0,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75213111321437, -1.3911498590439184]),
            {
              "LC18": 0,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74974931160914, -1.3908924428597778]),
            {
              "LC18": 0,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74850476662623, -1.3917075940131876]),
            {
              "LC18": 0,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([36.750693449182386, -1.3921795234995484]),
            {
              "LC18": 0,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75161612908351, -1.391879204746429]),
            {
              "LC18": 0,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75133717934596, -1.391192761738542]),
            {
              "LC18": 0,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74882663170802, -1.3895111094247858]),
            {
              "LC18": 0,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([36.749706396264905, -1.3900044907084244]),
            {
              "LC18": 0,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([36.741466650171155, -1.3884599924334295]),
            {
              "LC18": 0,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75232423226344, -1.3877091942962838]),
            {
              "LC18": 0,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74989951531398, -1.386700979280097]),
            {
              "LC18": 0,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75459874550807, -1.3877091942962838]),
            {
              "LC18": 0,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75852549950587, -1.387752097053399]),
            {
              "LC18": 0,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75931943337428, -1.387323069447236]),
            {
              "LC18": 0,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76048550838487, -1.3917205987179535]),
            {
              "LC18": 0,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76223459457935, -1.3870656528461756]),
            {
              "LC18": 0,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76248161373568, -1.390160140974027]),
            {
              "LC18": 0,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([36.766580029110436, -1.3897311138049868]),
            {
              "LC18": 0,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76398365078402, -1.3883153235943089]),
            {
              "LC18": 0,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76797477779818, -1.3908894869824688]),
            {
              "LC18": 0,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76745979366732, -1.3894951488287925]),
            {
              "LC18": 0,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76966993389559, -1.3898169192450338]),
            {
              "LC18": 0,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76977722225619, -1.3915973814221367]),
            {
              "LC18": 0,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7694553571744, -1.3916402841086308]),
            {
              "LC18": 0,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77243797359896, -1.3909752923804053]),
            {
              "LC18": 0,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77542059002352, -1.3900743355464478]),
            {
              "LC18": 0,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77340356884432, -1.3912541599021568]),
            {
              "LC18": 0,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7649707037015, -1.3956087792305427]),
            {
              "LC18": 0,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([36.764090939144616, -1.3959305488120537]),
            {
              "LC18": 0,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7649707037015, -1.3962094157470695]),
            {
              "LC18": 0,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([36.77554933605624, -1.3963595748522262]),
            {
              "LC18": 0,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72067431455978, -1.3732704921838346]),
            {
              "LC18": 0,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72108201033004, -1.3733777497265562]),
            {
              "LC18": 0,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([36.718271055282436, -1.370631955118146]),
            {
              "LC18": 0,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([36.718571462692104, -1.3709322765569005]),
            {
              "LC18": 0,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7221012497557, -1.3709322765569005]),
            {
              "LC18": 0,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72188021614145, -1.371768886080484]),
            {
              "LC18": 0,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([36.722523946305024, -1.3709108250268023]),
            {
              "LC18": 0,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([36.722234267731416, -1.3714042101702602]),
            {
              "LC18": 0,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71971299125742, -1.3729058165025727]),
            {
              "LC18": 0,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([36.722770709534394, -1.372787833182029]),
            {
              "LC18": 0,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72307111694406, -1.3728843649901838]),
            {
              "LC18": 0,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7166123576362, -1.370009860589487]),
            {
              "LC18": 0,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([36.716794747849214, -1.369076718493627]),
            {
              "LC18": 0,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([36.717009324570405, -1.3694842978445563]),
            {
              "LC18": 0,
              "system:index": "208"
            })]),
    ForestedAreas18 = ui.import && ui.import("ForestedAreas18", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            36.69137329101562,
            -1.3667824799188215
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69377655029297,
            -1.3694853758538976
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70772403717041,
            -1.3676405424503033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70888275146484,
            -1.3608189368651995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.71446174621582,
            -1.363264420336239
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7108568572998,
            -1.3624063562430795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.699527206420896,
            -1.3656669981695224
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.697038116455076,
            -1.3664392548203614
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70291751861572,
            -1.3553702191686183
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69823974609375,
            -1.3572579652728611
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.70011137949433,
            -1.3603567564162566
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.69740771280732,
            -1.3610003050620263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64025210172085,
            -1.4061906673745799
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.648456082852206,
            -1.403473516875294
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.645494924099765,
            -1.3969094297788949
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.63931511452945,
            -1.407163126375732
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.64961479714664,
            -1.403216102041579
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74718817349767,
            -1.322175621747647
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75620039578771,
            -1.3217894864539885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.742295824254505,
            -1.3200304249121677
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.72864874478673,
            -1.3197730011674798
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74508532162999,
            -1.3150964651718646
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.74984892484044,
            -1.3184429780622213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7518230306754,
            -1.3200733288670288
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.75461252805089,
            -1.3179281302177683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.76019152280187,
            -1.316683914154335
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.7628093588004,
            -1.3191723456595938
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            36.749033533299915,
            -1.323848873992604
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "LC18": 1
      },
      "color": "#98ff00",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([36.69137329101562, -1.3667824799188215]),
            {
              "LC18": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69377655029297, -1.3694853758538976]),
            {
              "LC18": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70772403717041, -1.3676405424503033]),
            {
              "LC18": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70888275146484, -1.3608189368651995]),
            {
              "LC18": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([36.71446174621582, -1.363264420336239]),
            {
              "LC18": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7108568572998, -1.3624063562430795]),
            {
              "LC18": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([36.699527206420896, -1.3656669981695224]),
            {
              "LC18": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([36.697038116455076, -1.3664392548203614]),
            {
              "LC18": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70291751861572, -1.3553702191686183]),
            {
              "LC18": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69823974609375, -1.3572579652728611]),
            {
              "LC18": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([36.70011137949433, -1.3603567564162566]),
            {
              "LC18": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([36.69740771280732, -1.3610003050620263]),
            {
              "LC18": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64025210172085, -1.4061906673745799]),
            {
              "LC18": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([36.648456082852206, -1.403473516875294]),
            {
              "LC18": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([36.645494924099765, -1.3969094297788949]),
            {
              "LC18": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([36.63931511452945, -1.407163126375732]),
            {
              "LC18": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([36.64961479714664, -1.403216102041579]),
            {
              "LC18": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74718817349767, -1.322175621747647]),
            {
              "LC18": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75620039578771, -1.3217894864539885]),
            {
              "LC18": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([36.742295824254505, -1.3200304249121677]),
            {
              "LC18": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([36.72864874478673, -1.3197730011674798]),
            {
              "LC18": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74508532162999, -1.3150964651718646]),
            {
              "LC18": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([36.74984892484044, -1.3184429780622213]),
            {
              "LC18": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7518230306754, -1.3200733288670288]),
            {
              "LC18": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([36.75461252805089, -1.3179281302177683]),
            {
              "LC18": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([36.76019152280187, -1.316683914154335]),
            {
              "LC18": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([36.7628093588004, -1.3191723456595938]),
            {
              "LC18": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([36.749033533299915, -1.323848873992604]),
            {
              "LC18": 1,
              "system:index": "27"
            })]);
//obtain image with the lowest amount of cloud cover
var filtered2000=ee.Image(L7.filterBounds(point).filterDate('2000-01-01','2000-12-31').sort('CLOUD_COVER').first());
var bands=['B1','B2','B3','B4','B5'];
var bands2=['B2','B3','B4','B8']
print(filtered2000);
//define parameters
var vizParamsFalse = {
  bands: ['B4', 'B3', 'B2'],
  min: 0,
  max: 0.5,
  gamma: [0.95, 1.1, 1]
};
var vizParamsTrue = {
  bands: ['B3', 'B2', 'B1'],
  min: 0,
  max: 0.5,
  gamma: [0.95, 1.1, 1]
};
//landsat 8 viz parameters
var vizParamsFalseL8 = {
  bands: ['B5', 'B4', 'B3'],
  min: 0,
  max: 0.5,
  gamma: [0.95, 1.1, 1]
};
var vizParamsTrueL8 = {
  bands: ['B4', 'B3', 'B2'],
  min: 0,
  max: 0.5,
  gamma: [0.95, 1.1, 1]
};
//center map to area of interest
Map.setCenter(36.69,-1.40,12);
//display image
// Map.addLayer(filtered2000,vizParamsFalse,'false2000');
// Map.addLayer(filtered2000,vizParamsTrue,'True2000');
var KNClip2000=filtered2000.clip(KajiadoNorth);
//display cliped image
// Map.addLayer(KNClip2000,vizParamsFalse,'KNfalse2000');
// Map.addLayer(KNClip2000,vizParamsTrue,'KNTrue2000');
//merge training data
var merged_fc=BuiltUp.merge(ForestedAreas).merge(Vegetation).merge(NonBuilt_Up).merge(Water);
//define training feature classes, property and the resolution of image
var training=KNClip2000.sampleRegions({
  collection:merged_fc,
  properties:['LC'],
  scale:30
});
//define classifier
var classifier=ee.Classifier.smileCart();
//define training parameters
var classifier=classifier.train({
  features:training,
  classProperty:'LC',
  inputProperties:bands
});
//classify image
var classified2000=KNClip2000.classify(classifier);
print(classified2000);
//display image
Map.addLayer(classified2000,{min:0,max:4,palette:'red,green,#87ff8a,#feffa1,blue'},'classified2000');
//add a panel
var legend=ui.Panel({
  style:{
    position:'bottom-left',
    padding:'5px'
  }
});
//add a title
var title=ui.Label({
  value:'Kajiado North Land Cover Map in 2000',
  style:{
    fontSize:'14px',
    fontWeight:'bold',
    margin:'0px'
  }
});
//add title to panel
legend.add(title);
//construct a legend
var colours=['red','green','#87ff8a','#feffa1','blue'];
var lc_classes=['Built Up Areas','Forested Areas','Vegetation','Non-Built Up area','Water'];
//function for making a legend
var list_legend=function(color,description){
  var c=ui.Label({
    style:{
      backgroundColor:color,
      padding:'10px',
      margin:'4px'
    }
  })
  var lc=ui.Label({
    value:description,
    style:{
      padding:'10px',
      margin:'4px'
    }
  })
  return ui.Panel({
    widgets:[c,lc],
    layout:ui.Panel.Layout.Flow('horizontal')
  });
};
for (var a=0;a<5;a++){
  legend.add(list_legend(colours[a],lc_classes[a]));
}
Map.add(legend);
/////////////////////////////////////////////////////////////////
//obtain 2002 image with the least cloud cover
var filtered2002=L7.filterBounds(point).filterDate('2002-01-01','2002-12-31').sort('CLOUD_COVER').first();
print(filtered2002);
//display image
// Map.addLayer(filtered2002,vizParamsFalse,'false2002');
// Map.addLayer(filtered2002,vizParamsTrue,'True2002');
var KNClip2002=filtered2002.clip(KajiadoNorth);
//display cliped image
// Map.addLayer(KNClip2002,vizParamsFalse,'KNfalse2002');
// Map.addLayer(KNClip2002,vizParamsTrue,'KNTrue2002');
//2002 classification
//merge training data
var merged_fc02=BuiltUp02.merge(ForestedAreas02).merge(Vegetation02).merge(NonBuilt_Up02).merge(Water02);
//define training feature classes, property and the resolution of image
var training02=KNClip2002.sampleRegions({
  collection:merged_fc02,
  properties:['LC02'],
  scale:30
});
//define classifier
var classifier02=ee.Classifier.smileCart();
//define training parameters
var classifier02=classifier02.train({
  features:training02,
  classProperty:'LC02',
  inputProperties:bands
});
//classify image
var classified2002=KNClip2002.classify(classifier02);
print(classified2002);
//display image
Map.addLayer(classified2002,{min:0,max:4,palette:'red,green,#87ff8a,#feffa1,blue'},'classified2002');
///////////////////////////////////////////////////////////////////////
/////2004 land cover detection
//obtain a landsat 7 2004 image with the least land cover
var filtered2004=L7.filterBounds(point).filterDate('2004-01-01','2004-12-31').sort('CLOUD_COVER').first();
//rectify scan line error
var fill2004=filtered2004.focalMean(1,'square','pixels',20);
var final2004=fill2004.blend(filtered2004);
print(filtered2004);
//display L7 2004 image
// Map.addLayer(filtered2004,vizParamsFalse,'false2004');
// Map.addLayer(filtered2004,vizParamsTrue,'True2004');
// //display scan line rectified image
// Map.addLayer(fill2004,vizParamsFalse,'false_fill2004');
// Map.addLayer(fill2004,vizParamsTrue,'True_fill2004');
// Map.addLayer(final2004,vizParamsFalse,'final_false2004');
// Map.addLayer(final2004,vizParamsTrue,'final_True2004');
var KNClip2004=final2004.clip(KajiadoNorth);
//display cliped image
// Map.addLayer(KNClip2004,vizParamsFalse,'KNfalse2004');
// Map.addLayer(KNClip2004,vizParamsTrue,'KNTrue2004');
//2004 classification
//merge training data
var merged_fc04=BuiltUp04.merge(ForestedAreas04).merge(Vegetation04).merge(NonBuilt_Up04).merge(Water04);
//define training feature classes, property and the resolution of image
var training04=KNClip2004.sampleRegions({
  collection:merged_fc04,
  properties:['LC04'],
  scale:30
});
//define classifier
var classifier04=ee.Classifier.smileCart();
//define training parameters
var classifier04=classifier02.train({
  features:training04,
  classProperty:'LC04',
  inputProperties:bands
});
//classify image
var classified2004=KNClip2004.classify(classifier04);
print(classified2004);
//display image
Map.addLayer(classified2004,{min:0,max:4,palette:'red,green,#87ff8a,#feffa1,blue'},'classified2004');
/////2006 land cover detection
//obtain a landsat 7 2004 image with the least land cover
var filtered2006=L7.filterBounds(point).filterDate('2006-01-01','2006-12-31').sort('CLOUD_COVER').first();
//rectify scan line error
var fill2006=filtered2006.focalMean(1,'square','pixels',20);
var final2006=fill2006.blend(filtered2006);
print(filtered2006);
//display L7 2006 image
// Map.addLayer(filtered2006,vizParamsFalse,'false2006');
// Map.addLayer(filtered2006,vizParamsTrue,'True2006');
// //display scan line rectified image
// Map.addLayer(fill2006,vizParamsFalse,'false_fill2006');
// Map.addLayer(fill2006,vizParamsTrue,'True_fill2006');
// Map.addLayer(final2006,vizParamsFalse,'final_false2006');
// Map.addLayer(final2006,vizParamsTrue,'final_True2006');
var KNClip2006=final2006.clip(KajiadoNorth);
//display cliped image
// Map.addLayer(KNClip2006,vizParamsFalse,'KNfalse2006');
// Map.addLayer(KNClip2006,vizParamsTrue,'KNTrue2006');
//2006 classification
//merge training data
var merged_fc06=BuiltUp06.merge(ForestedAreas06).merge(Vegetation06).merge(NonBuilt_Up06).merge(Water06);
//define training feature classes, property and the resolution of image
var training06=KNClip2006.sampleRegions({
  collection:merged_fc06,
  properties:['LC06'],
  scale:30
});
//define classifier
var classifier06=ee.Classifier.smileCart();
//define training parameters
var classifier06=classifier06.train({
  features:training06,
  classProperty:'LC06',
  inputProperties:bands
});
//classify image
var classified2006=KNClip2006.classify(classifier04);
print(classified2006);
//display image
Map.addLayer(classified2006,{min:0,max:4,palette:'red,green,#87ff8a,#feffa1,blue'},'classified2006');
/////2008 land cover detection
//obtain a landsat 7 2008 image with the least land cover
var filtered2008=L7.filterBounds(point).filterDate('2008-01-01','2008-12-30').sort('CLOUD_COVER').first();
//rectify scan line error
var fill2008=filtered2008.focalMean(1,'square','pixels',20);
var final2008=fill2008.blend(filtered2008);
print(filtered2008);
//display L7 2008 image
// Map.addLayer(filtered2008,vizParamsFalse,'false2008');
// Map.addLayer(filtered2008,vizParamsTrue,'True2008');
// //display scan line rectified image
// Map.addLayer(fill2008,vizParamsFalse,'false_fill2008');
// Map.addLayer(fill2008,vizParamsTrue,'True_fill2008');
// Map.addLayer(final2008,vizParamsFalse,'final_false2008');
// Map.addLayer(final2008,vizParamsTrue,'final_True2008');
var KNClip2008=final2008.clip(KajiadoNorth);
//display cliped image
// Map.addLayer(KNClip2008,vizParamsFalse,'KNfalse2008');
// Map.addLayer(KNClip2008,vizParamsTrue,'KNTrue2008');
//2008 classification
//merge training data
var merged_fc08=BuiltUp08.merge(ForestedAreas08).merge(Vegetation08).merge(NonBuilt_Up08).merge(Water08);
//define training feature classes, property and the resolution of image
var training08=KNClip2008.sampleRegions({
  collection:merged_fc08,
  properties:['LC08'],
  scale:30
});
//define classifier
var classifier08=ee.Classifier.smileCart();
//define training parameters
var classifier08=classifier08.train({
  features:training08,
  classProperty:'LC08',
  inputProperties:bands
});
//classify image
var classified2008=KNClip2008.classify(classifier08);
print(classified2008);
//display image
Map.addLayer(classified2008,{min:0,max:4,palette:'red,green,#87ff8a,#feffa1,blue'},'classified2008');
/////2010 land cover detection
//obtain a landsat 7 2010 image with the least land cover
var filtered2010=L7.filterBounds(point).filterDate('2010-01-01','2010-12-30').sort('CLOUD_COVER').first();
//rectify scan line error
var fill2010=filtered2010.focalMean(1,'square','pixels',20);
var final2010=fill2010.blend(filtered2010);
print(filtered2010);
//display L7 2010 image
// Map.addLayer(filtered2010,vizParamsFalse,'false2010');
// Map.addLayer(filtered2010,vizParamsTrue,'True2010');
// //display scan line rectified image
// Map.addLayer(fill2010,vizParamsFalse,'false_fill2010');
// Map.addLayer(fill2010,vizParamsTrue,'True_fill2010');
// Map.addLayer(final2010,vizParamsFalse,'final_false2010');
// Map.addLayer(final2010,vizParamsTrue,'final_True2010');
var KNClip2010=final2010.clip(KajiadoNorth);
//display cliped image
// Map.addLayer(KNClip2010,vizParamsFalse,'KNfalse2010');
// Map.addLayer(KNClip2010,vizParamsTrue,'KNTrue2010');
//2010 classification
//merge training data
var merged_fc10=BuiltUp10.merge(ForestedAreas10).merge(Vegetation10).merge(NonBuilt_Up10).merge(Water10);
//define training feature classes, property and the resolution of image
var training10=KNClip2010.sampleRegions({
  collection:merged_fc10,
  properties:['LC10'],
  scale:30
});
//define classifier
var classifier10=ee.Classifier.smileCart();
//define training parameters
var classifier10=classifier10.train({
  features:training10,
  classProperty:'LC10',
  inputProperties:bands
});
//classify image
var classified2010=KNClip2010.classify(classifier10);
print(classified2010);
//display image
Map.addLayer(classified2010,{min:0,max:4,palette:'red,green,#87ff8a,#feffa1,blue'},'classified2010');
/////2012 land cover detection
//obtain a landsat 7 2012 image with the least land cover
var filtered2012=L7.filterBounds(point).filterDate('2012-01-01','2012-12-30').sort('CLOUD_COVER').first();
//rectify scan line error
var fill2012=filtered2012.focalMean(1,'square','pixels',20);
var final2012=fill2012.blend(filtered2012);
print(filtered2012);
//display L7 2012 image
// Map.addLayer(filtered2012,vizParamsFalse,'false2012');
// Map.addLayer(filtered2012,vizParamsTrue,'True2012');
// //display scan line rectified image
// Map.addLayer(fill2012,vizParamsFalse,'false_fill2012');
// Map.addLayer(fill2012,vizParamsTrue,'True_fill2012');
// Map.addLayer(final2012,vizParamsFalse,'final_false2012');
// Map.addLayer(final2012,vizParamsTrue,'final_True2012');
var KNClip2012=final2012.clip(KajiadoNorth);
//display cliped image
// Map.addLayer(KNClip2012,vizParamsFalse,'KNfalse2012');
// Map.addLayer(KNClip2012,vizParamsTrue,'KNTrue2012');
//2012 classification
//merge training data
var merged_fc12=BuiltUp12.merge(ForestedAreas12).merge(Vegetation12).merge(NonBuilt_Up12).merge(Water12);
//define training feature classes, property and the resolution of image
var training12=KNClip2012.sampleRegions({
  collection:merged_fc12,
  properties:['LC12'],
  scale:30
});
//define classifier
var classifier12=ee.Classifier.smileCart();
//define training parameters
var classifier12=classifier12.train({
  features:training12,
  classProperty:'LC12',
  inputProperties:bands
});
//classify image
var classified2012=KNClip2012.classify(classifier12);
print(classified2012);
//display image
Map.addLayer(classified2012,{min:0,max:4,palette:'red,green,#87ff8a,#feffa1,blue'},'classified2012');
// 2014 Land cover detection
var filtered2014=ee.Image(L8.filterBounds(point).filterDate('2014-01-01','2014-12-31').sort('CLOUD_COVER').first());
//display image
// Map.addLayer(filtered2014,vizParamsFalseL8,'false2014');
// Map.addLayer(filtered2014,vizParamsTrueL8,'True2014');
var KNClip2014=filtered2014.clip(KajiadoNorth);
//display cliped image
// Map.addLayer(KNClip2014,vizParamsFalseL8,'KNfalse2014');
// Map.addLayer(KNClip2014,vizParamsTrueL8,'KNTrue2014');
//2014 classification
//merge training data
var merged_fc14=BuiltUp14.merge(ForestedAreas14).merge(Vegetation14).merge(NonBuilt_Up14).merge(Water14);
//define training feature classes, property and the resolution of image
var training14=filtered2014.sampleRegions({
  collection:merged_fc14,
  properties:['LC14'],
  scale:30
});
//define classifier
var classifier14=ee.Classifier.smileCart();
//define training parameters
var classifier14=classifier14.train({
  features:training14,
  classProperty:'LC14',
  inputProperties:bands
});
//classify image
var classified2014=KNClip2014.classify(classifier14);
print(classified2014);
//display image
Map.addLayer(classified2014,{min:0,max:4,palette:'red,green,#87ff8a,#feffa1,blue'},'classified2014');
//2016 land detection using sentinel 2 imagery
//Obtain image with the least cloud cover
var filtered2016=S2.filterBounds(point).filterDate('2016-01-01','2016-12-31').filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 3).first();
print(filtered2016);
var RGB_VIS = {min: 0, max: 3000, gamma: 1.5, bands: ['B4', 'B3', 'B2']};
var FC_VIS = {min: 0, max: 3000, gamma: 1.5, bands: ['B8', 'B4', 'B3']};
// Map.addLayer(filtered2016,RGB_VIS,'True2016');
// Map.addLayer(filtered2016,FC_VIS,'False2016');
//clip to study Area
var KNClip2016=filtered2016.clip(KajiadoNorth);
//display cliped image
// Map.addLayer(KNClip2016,FC_VIS,'KNfalse2016');
// Map.addLayer(KNClip2016,RGB_VIS,'KNTrue2016');
//2016 classification
var merged_fc16=BuiltUp16.merge(ForestedAreas16).merge(Vegetation16).merge(NonBuilt_Up16).merge(Water16);
//define training feature classes, property and the resolution of image
var training16=filtered2016.sampleRegions({
  collection:merged_fc16,
  properties:['LC16'],
  scale:10
});
//define classifier
var classifier16=ee.Classifier.smileCart();
//define training parameters
var classifier16=classifier16.train({
  features:training16,
  classProperty:'LC16',
  inputProperties:bands2
});
//classify image
var classified2016=KNClip2016.classify(classifier16);
print(classified2016);
//display image
Map.addLayer(classified2016,{min:0,max:4,palette:'red,green,#87ff8a,#feffa1,blue'},'classified2016');
//2018 land detection using sentinel 2 imagery
//Obtain image with the least cloud cover
var filtered2018=S2.filterBounds(point).filterDate('2018-01-01','2018-12-31').filterMetadata('CLOUDY_PIXEL_PERCENTAGE', 'less_than', 5).first();
print(filtered2018);
var RGB_VIS = {min: 0, max: 3000, gamma: 1.5, bands: ['B4', 'B3', 'B2']};
var FC_VIS = {min: 0, max: 3000, gamma: 1.5, bands: ['B8', 'B4', 'B3']};
// Map.addLayer(filtered2018,RGB_VIS,'True2018');
// Map.addLayer(filtered2018,FC_VIS,'False2018');
//clip to study Area
var KNClip2018=filtered2018.clip(KajiadoNorth);
// //display cliped image
// Map.addLayer(KNClip2018,FC_VIS,'KNfalse2018');
// Map.addLayer(KNClip2018,RGB_VIS,'KNTrue2018');
//2018 classification
var merged_fc18=BuiltUp18.merge(ForestedAreas18).merge(Vegetation18).merge(NonBuilt_Up18).merge(Water18);
//define training feature classes, property and the resolution of image
var training18=filtered2018.sampleRegions({
  collection:merged_fc18,
  properties:['LC18'],
  scale:10
});
//define classifier
var classifier18=ee.Classifier.smileCart();
//define training parameters
var classifier18=classifier18.train({
  features:training18,
  classProperty:'LC18',
  inputProperties:bands2
});
//classify image
var classified2018=KNClip2018.classify(classifier18);
print(classified2018);
//display image
Map.addLayer(classified2018,{min:0,max:4,palette:'red,green,#87ff8a,#feffa1,blue'},'classified2018');