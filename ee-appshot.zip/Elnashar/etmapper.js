var GAUL = ui.import && ui.import("GAUL", "table", {
      "id": "FAO/GAUL/2015/level0"
    }) || ee.FeatureCollection("FAO/GAUL/2015/level0"),
    WRS2 = ui.import && ui.import("WRS2", "table", {
      "id": "users/Elnashar/Vector/WRS2_descending"
    }) || ee.FeatureCollection("users/Elnashar/Vector/WRS2_descending");
/**
 * @ Abdelrazek Elnashar (https://orcid.org/0000-0001-8008-5670)
 * Reference: https://doi.org/10.1016/j.jhydrol.2025.133062
*/
var map = ui.Map({center:{lon:30, lat:30, zoom:2}});
map.style().set('cursor', 'crosshair');
map.setGestureHandling('none');
map.setOptions('HYBRID'); 
////////////////////////////////////////////////
var Aksu = ee.FeatureCollection("users/Elnashar/Vector/Aksu");
var Manasi = ee.FeatureCollection("users/Elnashar/Vector/Manasi");
var BayanNur = ee.FeatureCollection("users/Elnashar/Vector/BayanNur");
var customers = {
  'Germany'     :['1234567'     , GAUL.filterMetadata('ADM0_NAME', 'equals', 'Germany'), 6],
  'Ebinur'      :['DrHongwei01' , ee.FeatureCollection("users/Elnashar/Vector/Ebinur") , 6],
  'Manasi'      :['DrHongwei02' , Manasi                                               , 5],
  'AksuBayanNur':['AksuBayanNur', Aksu.merge(BayanNur)                                 , 5],
};
// var testAOI = GAUL.filterMetadata('ADM0_NAME', 'equals', 'Germany');
// map.centerObject(testAOI, 6);
// map.addLayer(testAOI.style({color:'#FF0000', fillColor:'00000000', width:2}), {}, 'AOI', 1, 1);
// map.addLayer(WRS2.filterBounds(testAOI).style({color:'#000000', fillColor:'00000000', width:1}), {}, 'WRS2', 1, 1);
////////////////////////////////////////////////
var search       = true;
var activate     = null;
var imagesList   = null;
var imageSearch  = null;
var domainOfAOI  = null;
var activeLayers = null;
var footprint    = null;
////////////////////////////////////////////////
var style01 = {backgroundColor:"#FFFFFF", fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'center', margin:'auto', whiteSpace:'pre'};
var style02 = {fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'center', margin:'auto', whiteSpace:'pre'};
var style03 = {fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'center', margin:'auto'};
var style04 = {color:'#FF0000', width:'100%', margin:'auto', position:'top-center'};
var style05 = {backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid black'};
var style06 = {fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'left', whiteSpace:'pre'};
var style07 = {fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'center', margin:'auto', whiteSpace:'pre'};
var style08 = {fontSize:'20px', fontWeight:'normal', color:"blue", textAlign:'left', margin:'auto', whiteSpace:'pre'};
var style09 = {fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'justify', margin:'auto'};
////////////////////////////////////////////////
var Alt = ['0000FF','00FFFF','FFFF00', 'FF0000','FFFFFF'];
var VIs = ['FFFFFF','CE7E45','DF923D','F1B555','FCD163','99B718','74A901','66A000','529400','3E8601','023B01','012E01','011D01','011301'];
var ALB = ['000080','0000D9','4000FF','8000FF','0080FF','00FFFF','00FF80','80FF00','DAFF00','FFFF00','FFF500','FFDA00','FFB000','FFA400','FF4F00','FF2500','FF0A00','FF00FF'];
var LST = ['040274','040281','0502A3','0502B8','0502CE','0502E6','0602FF','235CB1','307EF3','269DB1','30C8E2','32D3EF','3BE285','3FF38F','86E26F','3AE237','B5E22E','D6E21F','FFF705','FFD611','FFB613','FF8B13','FF6E08','FF500D','FF0000','DE0101','C21301','A71001','911003'];
var ENR = LST;
var ETs = VIs;
var layersProp = {
  'Ele'            :['; m)'       , Alt],
  'NDVI'           :['; unitless)', VIs],
  'SAVI'           :['; unitless)', VIs],
  'LAI'            :['; m2/m2)'   , VIs],
  'As'             :['; unitless)', ALB],
  'Ts'             :['; °K)'      , LST],
  'TsDEM'          :['; °K)'      , LST],
  'Rn'             :['; W/m2)'    , ENR],
  'G'              :['; W/m2)'    , ENR],
  'LESEBAL'        :['; W/m2)'    , ENR],
  'LEMETRIC'       :['; W/m2)'    , ENR],
  'LETriAng'       :['; W/m2)'    , ENR],
  'Rn24'           :['; W/m2)'    , ENR],
  'ETo24'          :['; mm/day)'  , ETs],
  'ETr24'          :['; mm/day)'  , ETs],
  'ETa24SEBAL4EF'  :['; mm/day)'  , ETs],
  'ETa24SEBAL4ETF' :['; mm/day)'  , ETs],
  'ETa24METRIC4EF' :['; mm/day)'  , ETs],
  'ETa24METRIC4ETF':['; mm/day)'  , ETs],
  'ETa24TriAng4EF' :['; mm/day)'  , ETs],
  'ETa24TriAng4ETF':['; mm/day)'  , ETs],
  'ETa24SSEBop'    :['; mm/day)'  , ETs],
};
var layers = Object.keys(layersProp);
////////////////////////////////////////////////
function modelling(point){
  var st = ee.Date(startDate.getValue()[0]);
  var en = ee.Date(endDate.getValue()[1]);
  var CC = Number(cloudCover.getValue());
  add2Console(['Filtering satellite images...']);
  var ETMapper = require('users/Elnashar/Published:ETMapper');
  var LSS2 = ETMapper.sensors_f(point, st, en, ['L05','L07','L08','L09'], CC, 'BOA');
      LSS2 = LSS2.sort({property:'CC', ascending:true});
  LSS2.evaluate(function(col){
    add2Console(['Adding the filtered satellite images to the images list...']);
    var items = []; 
    col.features.forEach(function(feature){ 
      var label = feature.properties.LANDSAT_SCENE_ID + "/ "  + feature.properties.DATE_ACQUIRED + "/ Cloud " + feature.properties.CLOUD_COVER + "%";
      items.push(label);
    }); 
    imagesList  = buildImagesList(items);
    imageSearch = buildImageSearch(imagesList);
    rightPanel.remove(imageSearch);
    rightPanel.add(imageSearch);
    add2Console(['Select a satellite image.']);
    imagesList.onChange(function(ID){
      // ui.root.widgets().reset([title, mapGrid]);
      rightPanel.remove(outputsPanel);
      rightPanel.remove(downloadingPanel);
      var image = LSS2.filter(ee.Filter.eq('LANDSAT_SCENE_ID', ID.split("/")[0])).first();
      var geom  = image.geometry();
      var proj  = image.select('inR').projection();
      var crs   = ee.String(proj.crs());
      var scale = ee.Number(proj.nominalScale());
      var sysID = image.get('system:id');
      var FoPr  = ee.Geometry(image.get('system:footprint'));
      var Grid  = geom.coveringGrid({proj:proj, scale:scale});
      footprint = ee.Geometry.Polygon(FoPr.coordinates());
      map.layers().reset();
      map.addLayer(domainOfAOI.style({color:'#FF0000', fillColor:'00000000', width:2}), {}, 'DomainOfAOI', 0, 1);
      map.addLayer(FoPr, {color:'red'}, 'Footprint', 0, 1);
      map.addLayer(image, {min:0, max:0.5, bands:['inSWIR1','inNIR','inR']}, 'Image', 1, 1);
      map.addLayer(Grid.style({color:'#000000', fillColor:'00000000', width:1}), {}, 'Grid', 0, 1);
      add2Console(['Processing the selected satellite image...']);
      var setSAVI   = methodsSAVI.getValue();
      var setLAI    = methodsLAI.getValue();
      var setRn24   = methodsRn24.getValue();
      var setG      = methodsG.getValue();
      var setRefETt = methodsRefETt.getValue();
      var setRefETs = methodsRefETs.getValue();
      image = ETMapper.main_f(image, setSAVI, setLAI, setRn24, setG, setRefETt, setRefETs); print('Active image', image);
      var YNHP = image.get('YNHP');
      YNHP.evaluate(function(YNHP){
        if (YNHP == 1){
          rightPanel.add(outputsPanel);
          rightPanel.add(downloadingPanel);
          add2Console(['Click on the map to get a location value(s).',
                       'Under Outputs, you can add additional layers.',
                       'Under Downloading, you can download a specific layer.']);
          var CP = ee.Geometry.Point([image.getNumber('LonCP'), image.getNumber('LatCP')]);
          var HP = ee.Geometry.Point([image.getNumber('LonHP'), image.getNumber('LatHP')]);
          map.addLayer(CP, {color:'green'}, 'Cold (wet) pixel', 0, 1);
          map.addLayer(HP, {color:'red'  }, 'Hot (dry) pixel' , 0, 1);
          map.onClick(function(coords){
            var point = ee.Geometry.Point([coords.lon, coords.lat]);
            var contains = footprint.contains({'right':point, 'maxError':1});
            contains.evaluate(function(contain){
              if (contain){
                activeLayers = getLayersName(); print('Active layers', activeLayers);
                if (activeLayers.length > 0){
                  var sample = image.select(activeLayers).unmask(-999.0).sample({region:point, scale:30, numPixels:1}).first().toDictionary(); print('Active sample', point, sample);
                  consolePanel.clear();
                  map.remove(consolePanel);
                  map.add(consolePanel);
                  consolePanel.add(ui.Label({value:'Extracting value(s)...', style:style09}));
                  sample = sample.map(function scale(key, value){
                    var list = [];
                    var line = ee.String(key).cat(ee.String(': ')).cat(ee.String(value)).replace('-999.0', 'masked');
                    list.push(line);
                    return list;
                  });
                  sample = sample.values().flatten().sort().join('\n');
                  sample.evaluate(function(line){
                    consolePanel.add(ui.Label({value:line, style:style06}));
                  });
                  consolePanel.add(closeConsolePanel);
                }
                else{
                  add2Console(['From the outputs, would you please add at least one layer?']);
                }
              }
              else{
                add2Console(["The chosen location falls outside the user's designated satellite scene."]);
              }
            });
          });
          outputs.onChange(function(output){
            activeLayers = new Set(getLayersName());
            if (!activeLayers.has(output)){
              var band = image.select(output);
              var unit = layersProp[output][0];
              var plat = layersProp[output][1];
              var reducer = ee.Reducer.percentile([0, 50, 100])
                              .combine({reducer2:ee.Reducer.mean(), sharedInputs:true})
                              .combine({reducer2:ee.Reducer.stdDev(), sharedInputs:true}).setOutputs(['min', 'med', 'max', 'mean', 'std']);
              var MMVs = band.reduceRegion({reducer:reducer, geometry:geom, scale:1000, bestEffort:true});
              MMVs = ee.Dictionary({minV:MMVs.getNumber(output+'_min' ),
                                    menV:MMVs.getNumber(output+'_mean'),
                                    medV:MMVs.getNumber(output+'_med' ),
                                    maxV:MMVs.getNumber(output+'_max' ),
                                    stdV:MMVs.getNumber(output+'_std' ),
                                  });
              MMVs.evaluate(function(values){
                  var min = values.minV;
                  var men = values.menV;
                  var med = values.medV;
                  var max = values.maxV;
                  var std = values.stdV;
                  var CV  = Number((std / men) * 100).toFixed(2);
                  var name = output + ' (std:' + std.toFixed(2) + ', CV%:' + CV + unit;
                  if (output == 'NDVI' || output == 'SAVI'){
                    min = 0;
                  }
                  map.addLayer(band, {min:min, max:max, palette:plat}, output, 1, 1);
                  rightPanel.add(getLegend(name, 'min', 'mean', 'med', 'max', min.toFixed(2), men.toFixed(2), med.toFixed(2), max.toFixed(2), plat));
              });
            }
            else{
              add2Console(['The selected layer has already been added!']);
            }
          });
          submitButton.onClick(function(){
            var fill = nodata.getValue();
            var name = selectlayer.getValue();
            var AOI  = drawingTools.layers().get(0).getEeObject();
            try{
              add2Console(['Preparing the selected AOI of ' + name + ' for downloading.']);
              var band = image.select(name);
              if (fill === 'Default'){
                band = band;
              }
              else{
                band = band.unmask(Number(fill));
              }
              var bandAOI = band.clip(AOI);
              var urlAOI  = bandAOI.getDownloadURL({name:name, scale:30});
              downloadLabel.setUrl(urlAOI);
              downloadLabel.setValue('Download the selected AOI of ' + name);
              downloadLabel.style().set({shown: true});
              add2Console(['The selected AOI of ' + name + ' is now ready for downloading.',
                           'The nodata value has been set to: ' + fill]);
            }
            catch(err){
              downloadLabel.setValue('');
              add2Console(['The total request size must be less than or equal to 50331648 bytes!']);
            }                   
          });
          disabledAll();
        }
        else{
          sysID.evaluate(function(sysID){
            add2Console(['Something went wrong; please try again. If you require help, please send an email containing the image ID to abdelrazek.elnashar@uni-kassel.de. The image ID is: ',
                         sysID]);
          });
        }
      });
    });
  });
}
function getLegend(name, minText, menText, midText, maxText, minNum, menNum, midNum, maxNum, palette){
  var  title = ui.Label(name, {margin:'10px 0px 0px 0px', textAlign:'center', stretch:'horizontal', fontWeight:'bold'});
  var colorbar = ui.Thumbnail({
    image :ee.Image.pixelLonLat().select(0),
    params:{bbox:[0, 0, 1, 0.1], dimensions:'470x30', format:'png', min:0, max:1, palette:palette},
    style :{stretch:'horizontal', margin:'auto'},
  });
  var label = ui.Panel({
    widgets:[ui.Label(minText + ':' + minNum, {margin:'02px 00px 00px 15px', textAlign:'left'  , stretch:'horizontal', fontWeight:'bold'}),
             ui.Label(menText + ':' + menNum, {margin:'02px 00px 00px 00px', textAlign:'center', stretch:'horizontal', fontWeight:'bold'}),
             ui.Label(midText + ':' + midNum, {margin:'02px 00px 00px 00px', textAlign:'center', stretch:'horizontal', fontWeight:'bold'}),
             ui.Label(maxText + ':' + maxNum, {margin:'02px 00px 00px 00px', textAlign:'right' , stretch:'horizontal', fontWeight:'bold'})],
    layout:ui.Panel.Layout.flow('horizontal')
  });
  var legend = ui.Panel({
    style  :{position:'top-center'},
    widgets:[title, colorbar, label]
  });
  return legend;
}
function addDraw(point){
  drawingTools.clear();
  drawingTools.addLayer([point], 'Point', 'green');
}
function str2(num, width) {
  var str = num.toString();
  return str.length >= width ? str:new Array(width - str.length + 1).join('0') + str;
}
function removeAll(){
  map.remove(FAQPanel);
  map.remove(consolePanel);
  map.remove(aboutPanel);
}
function disabledAll(){
  startDate.setDisabled(true);
  endDate.setDisabled(true);
  cloudCover.setDisabled(true);
  methodsSAVI.setDisabled(true);
  methodsLAI.setDisabled(true);
  methodsRn24.setDisabled(true);
  methodsG.setDisabled(true);
  methodsRefETt.setDisabled(true);
  methodsRefETs.setDisabled(true);
  imagesList.setDisabled(true);
  enterButton.setDisabled(true);
  searchButton.setDisabled(true);
}
function buildImagesList(items){
  imagesList = ui.Select({
    items      :items,
    placeholder:'List of images',
    style      :style04,
  }); 
  return imagesList;
}
function buildImageSearch(imagesList){
  imageSearch = ui.Panel({
    layout:ui.Panel.Layout.flow('vertical'),
    style :style05,
    widgets:[
      ui.Label({value:'Search for images', style:style01}),
      ui.Panel({
        layout :ui.Panel.Layout.flow("vertical"),
        style  :{position:'top-center'},
        widgets:[ui.Label({value:"Select image", style:style02})]
      }),
      ui.Panel({
        layout :ui.Panel.Layout.flow("horizontal"),
        style  :{position:'top-center', margin:'auto', width:'100%'},
        widgets:[ui.Panel({layout:ui.Panel.Layout.flow("horizontal"), style:{position:'top-center', margin:'auto'}, widgets:[imagesList]})]
      }),
    ]
  });
  return imageSearch;
}
function getLayersName(){
  function layersName(layers){
    var names = [];
    layers.forEach(function(lay){
      var lay_name = lay.getName();
      if (names.indexOf(lay_name)){
        names.push(lay_name)}
    });
    return names;
  }
  var layers = map.layers();
  var names  = layersName(layers);
  var No  = [];
  var Yes = [];
  var listB = new Set(['DomainOfAOI', 'Grid', 'Footprint', 'Image', 'Cold (wet) pixel', 'Hot (dry) pixel']);
  for (var i=0; i<names.length; i++){
    var prop = names[i];
    if (listB.has(prop)){
      No.push(prop);
    }
    else{
      Yes.push(prop);
    }
  }
  return Yes;
}
function zoomLevel_f(name){
  var zoomLabel = ui.Label({value:'', style:{fontWeight:'bold', fontSize:'15px'}});
  map.add(zoomLabel);
  function changeZoom(){
    var getZoom = map.getZoom();
    var percent = (Number(getZoom)/Number(20))*100;
    zoomLabel.setValue(name + ' @ Zoom level ' + getZoom + ': ' + percent + '%');
  }
  map.onChangeZoom(changeZoom);
}
zoomLevel_f('ETMapper');
////////////////////////////////////////////////
var mapPanel = ui.Panel({
  layout:ui.Panel.Layout.flow('horizontal'),
  style :{stretch:'both'}
});
var leftPanel = ui.Panel({
  layout:ui.Panel.Layout.flow('vertical'),
  style :{backgroundColor:"#F2F0EF", minWidth:'480px', maxWidth:'480px', stretch:'vertical'},
});
var rightPanel = ui.Panel({
  layout:ui.Panel.Layout.flow('vertical'),
  style :{backgroundColor:"#F2F0EF", minWidth:'480px', maxWidth:'480px', stretch:'vertical'},
});
var mainPanel = ui.Panel({
  layout:ui.Panel.Layout.flow('horizontal'),
  style :{stretch:'both'}
});
mapPanel.add(map);
mainPanel.add(leftPanel);
mainPanel.add(mapPanel);
mainPanel.add(rightPanel);
////////////////////////////////////////////////
var drawingTools = map.drawingTools();
drawingTools.setShown(false);
drawingTools.setDrawModes([]);
//////////////////////////////////////////////// 
var styleCloseButton = style03;
var consolePanel = ui.Panel({
    layout:ui.Panel.Layout.flow('vertical'),
    style :{position:'bottom-center', width:'100', height:'auto'},
});
var closeConsolePanel = ui.Button({
  label  :'Close',
  style  :styleCloseButton, 
  onClick:function(){
    consolePanel.clear();
    map.remove(consolePanel);
  },
});
////////////////////////////////////////////////
var AppURL = 'https://elnashar.users.earthengine.app/view/etmapper';
var MyURL  = 'https://orcid.org/0000-0001-8008-5670';
var RefURL = 'https://doi.org/10.1016/j.jhydrol.2025.133062';
var RefURL = 'https://www.researchgate.net/publication/389820401_A_Multi-Model_Approach_for_Remote_Sensing-Based_Actual_Evapotranspiration_Mapping_using_Google_Earth_Engine_ETMapper-GEE';
var titlePanel = ui.Panel({
  layout :ui.Panel.Layout.flow('vertical'),
  style  :{margin:'2px 5px', border:'0.5px solid #000000'},
  widgets:[
    ui.Label({value:'EvapoTranspiration (ET) Mapper (ETMapper)', style:style07, targetUrl:AppURL}),
    // ui.Label({value:'Developed by Abdelrazek Elnashar', style:style08, targetUrl:MyURL}),
    ui.Label({value:'Reference @ Journal of Hydrology', style:style08, targetUrl:RefURL}),
    ]
});
leftPanel.add(titlePanel);
////////////////////////////////////////////////
var about = 'Accurate estimation of actual evapotranspiration (ETa) through remote sensing (RS) is essential for effective large-scale water management. '+
            'We developed an EvapoTranspiration Mapper in the Google Earth Engine environment (ETMapper-GEE) to estimate RS-ETa using Landsat satellite data employing four models: '+
            'Surface Energy Balance Algorithm for Land (SEBAL), '+
            'Mapping EvapoTranspiration at high Resolution with Internalized Calibration (METRIC), '+
            'surface temperature-vegetation-based triangle (TriAng), and '+
            'Operational Simplified Surface Energy Balance (SSEBop). '+
            'The estimation integrates '+
            'extrapolation approaches (Evaporative Fraction (EF) and EvapoTranspiration Fraction (ETF)), '+
            'reference ET types (grass (ETo) and alfalfa (ETr)), and '+
            'climate forcing datasets (the fifth generation of the European ReAnalysis (ERA5-Land) and the Climate Forecast System version 2 (CFSv2)).'; 
var aboutPanel = ui.Panel({
    layout :ui.Panel.Layout.flow('vertical'),
    style  :{position:'bottom-center', width:'100', height:'auto'},
    widgets:[
      ui.Label({value:'About', style:{fontSize:'20px', fontWeight:'bold', textAlign:'center', margin:'auto'}}),
      ui.Label({value:'..................', style:{fontSize:'20px', fontWeight:'bold', textAlign:'center', margin:'auto'}}),
      ui.Label({value:about, style:{fontSize:'18px', fontWeight:'normal', color:"#000000", textAlign:'justify', margin:'auto'}}),
      ]
});
var aboutButton = ui.Button({
  label  :'About',
  style  :{fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'center', margin:'auto'}, 
  onClick: function(){
    map.remove(FAQPanel);
    map.remove(aboutPanel);
    map.remove(consolePanel);
    map.add(aboutPanel);
  },
});
var closeAbout = ui.Button({
  label:'Close',
  style:{fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'center', margin:'auto'},
  onClick:function(){
    map.remove(aboutPanel);
  },
});
aboutPanel.add(closeAbout);
var FAQPanel = ui.Panel({
    layout:ui.Panel.Layout.flow('vertical'),
    style  :{position:'bottom-center', width:'100', height:'auto'},
    widgets:[
      ui.Label({value:'Frequently Asked Questions (FAQ)', style:{fontSize:'20px', fontWeight:'bold', textAlign:'center', margin:'auto'}}),
      ui.Label({value:'....................................................', style:{fontSize:'20px', fontWeight:'bold', textAlign:'center', margin:'auto'}}),
      ui.Label({value:'How can I contact the developer?', style:{fontSize:'18px', fontWeight:'bold', textAlign:'left'}}),
      ui.Panel({
        layout : ui.Panel.Layout.Flow('horizontal'),
        widgets:[
          ui.Label({value:'Answer: For any questions/requests, the best way to reach me is via ', style:{fontSize:'18px', textAlign:'left', color:'#000000', margin:'auto', whiteSpace:'pre'}}),
          ui.Label({value:'abdelrazek.elnashar@uni-kassel.de', style:{fontSize:'18px', textAlign:'left', color:'#FF0000', margin:'auto'}})
        ]
      }),
      ],
});  
var FAQButton = ui.Button({
  label  :'FAQ',
  style  :{fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'center', margin:'auto'},
  onClick: function(){
    map.remove(FAQPanel);
    map.remove(consolePanel);
    map.remove(aboutPanel);
    map.add(FAQPanel);
  },
});
var closeFAQ = ui.Button({
  label  :'Close',
  style  :{fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'center', margin:'auto'}, 
  onClick:function(){
    map.remove(FAQPanel);
  },
});
FAQPanel.add(closeFAQ);
var panelButtons = ui.Panel({
  layout :ui.Panel.Layout.flow('horizontal'),
  style  :{margin:'2px 5px', border:'0.5px solid #000000'},
  widgets:[aboutButton, FAQButton],
});
leftPanel.add(panelButtons);
////////////////////////////////////////////////
var UserName = ui.Textbox({
  style:{fontSize:'20px', fontWeight:'normal', color:"#FF0000", textAlign:'center', margin:'auto'},
});
var Password = ui.Textbox({
  style:{fontSize:'20px', fontWeight:'normal', color:"#FFFFFF", textAlign:'center', margin:'auto'},
});
var searchButton = ui.Button({
  label   :'Search',
  disabled:true,
  style   :{fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'center', margin:'auto'}, 
  onClick :function(){
    removeAll();
    var locLon = LonText.getValue();
    var locLat = LatText.getValue();
    if ((locLon !== 'Longitude') & (locLat !== 'Latitude')){
      var point = ee.Geometry.Point([Number(locLon), Number(locLat)]);
      var contains = domainOfAOI.geometry().contains({'right':point, 'maxError':1});
      contains.evaluate(function(contain){
        if (contain){
          map.layers().reset();
          rightPanel.remove(imagesList);
          rightPanel.remove(imageSearch);
          rightPanel.remove(outputsPanel);
          rightPanel.remove(downloadingPanel);
          addDraw(point);
          modelling(point);
        }
        else{
          add2Console(["The chosen location falls outside the user's designated study area (DomainOfAOI)."]);
        }
      });
    }
    else{
      add2Console(['Click on the map to select a location or fill location information (decimal degrees).']);
    }
  }
}); 
function add2Console(listOfLines){
  removeAll();
  consolePanel.clear();
  map.remove(consolePanel);
  map.add(consolePanel);
  listOfLines.forEach(function(line){
    var lineLabel = ui.Label({value:line, style:{fontSize:'20px', fontWeight:'normal', color:"#000000", textAlign:'justify', margin:'auto'}});
    consolePanel.add(lineLabel);
  });
  consolePanel.add(closeConsolePanel);
}
var enterButton = ui.Button({
  label   :'Enter',
  disabled:false,
  onClick :function(){
    removeAll();
    drawingTools.clear();
    map.layers().reset();
    rightPanel.remove(imagesList);
    rightPanel.remove(imageSearch);
    search = true;
    LonText.setValue('Longitude');
    LatText.setValue('Latitude');
    var username = String(UserName.getValue());
    var password = String(Password.getValue());
    try{
      var customerInfo     = customers[username];
      var customerPassword = String(customerInfo[0]);
      var customerFeatures = customerInfo[1];
      var customerzoom     = Number(customerInfo[2]);
      if (password === customerPassword){
        domainOfAOI = customerFeatures;
        map.setGestureHandling('auto');
        map.centerObject(customerFeatures, customerzoom);
        map.addLayer(customerFeatures.style({color:'#FF0000', fillColor:'00000000', width:2}), {}, 'DomainOfAOI', 1, 1);
        map.addLayer(WRS2.filterBounds(customerFeatures).style({color:'#000000', fillColor:'00000000', width:1}), {}, 'WRS2', 1, 1);
        activate = true;
        LonText.setDisabled(false);
        LatText.setDisabled(false);
        searchButton.setDisabled(false);
        add2Console(["Click on the map to select a location within the user's designated study area (DomainOfAOI)."]);
      }
      else{
        add2Console(['The password is incorrect!']);
      }
    }
    catch (err){
      add2Console(['The username is incorrect!']);
    }
  }
});
var signIn = ui.Panel({
  layout :ui.Panel.Layout.flow('vertical'),
  style  :{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid black'},
  widgets:[
    ui.Label({value:'Sign in', style:style01, }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("vertical"),
      style  :{position: 'top-center'},
      widgets:[ui.Label({value:"Enter your username and password", style:style03})]
    }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position: 'top-center', margin:'auto', width:'100%'},
      widgets:[ui.Panel({layout:ui.Panel.Layout.flow("horizontal"), style:{position:'top-center', margin:'auto'}, widgets:[UserName, Password, enterButton]})]
      })
  ]
});
leftPanel.add(signIn);
////////////////////////////////////////////////
var today    = new Date();
var curYear  = today.getFullYear();
var lasYear  = curYear - 1;
var curMonth = today.getMonth() + 1;
var curDay   = today.getDate();
var startDate = ui.DateSlider({start   :'2020-01-01',
                               value   :lasYear + '-' + str2(curMonth, 2) + '-' + str2(curDay, 2),
                               style   :{width:'120px'},
                               onChange:function(selected){
                                 removeAll();
                                 return selected;
                                 }
                });
var endDate = ui.DateSlider({start   :'2020-01-01',
                              value   :curYear + '-' + str2(curMonth, 2) + '-' + str2(curDay, 2),
                              style   :{width:'120px'},
                              onChange:function(selected){
                                removeAll();
                                return selected;
                              }
              });
var cloudCover = ui.Slider({min     :0,
                            max     :30,
                            value   :30,
                            step    :0.1,
                            style   :{width:'400px', backgroundColor:'#D3D3D3', margin:'10px'},
                            onChange:function(selected){
                              removeAll();
                              return selected;
                            }
                  });
var dataSearch = ui.Panel({
  layout :ui.Panel.Layout.flow('vertical'),
  style  :{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid black'},
  widgets:[
    ui.Label({value:'Data search', style:style01}),
    ui.Panel({
      layout :ui.Panel.Layout.flow("vertical"),
      style  :{position: 'top-center'},
      widgets:[ui.Label({value:"Select the date range", style:style03})]
    }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position: 'top-center', margin:'auto', width:'100%'},
      widgets:[ui.Panel({layout :ui.Panel.Layout.flow("horizontal"), style:{position:'top-center', margin:'auto'}, widgets:[startDate, endDate]})]
      }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("vertical"),
      style  :{position: 'top-center'},
      widgets:[ui.Label({value:"Select the maximum cloud cover (%)", style:style03})]
    }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position: 'top-center', margin:'auto', width:'100%'},
      widgets:[ui.Panel({layout :ui.Panel.Layout.flow("horizontal"), style:{position:'top-center', margin:'auto'}, widgets:[cloudCover]})]
      }),    
  ]
});
leftPanel.add(dataSearch);
////////////////////////////////////////////////
var methodsSAVI = ui.Select({
  items      :['SAVI01', 'SAVI02', 'SAVI03'],
  value      :'SAVI03',
  placeholder:'SAVI03',
  onChange   :function(selected){
    removeAll();
    return selected;
  }
});
var methodsLAI = ui.Select({
  items      :['LAISAVI01', 'LAISAVI02', 'LAISAVI03', 'LAIEVI2', 'LAINDVI', 'LAIVC'],
  value      :'LAISAVI03',
  placeholder:'LAISAVI03',
  onChange   :function(selected){
    removeAll();
    return selected;
  }
});
var methodsRn24 = ui.Select({
  items      :['Rn2401', 'Rn2402', 'Rn2403'],
  value      :'Rn2402',
  placeholder:'Rn2402',
  onChange   :function(selected){
    removeAll();
    return selected;
  }
});
var methodsG = ui.Select({
  items      :['G0100', 'G0201'],
  value      :'G0100',
  placeholder:'G0100',
  onChange   :function(selected){
    removeAll();
    return selected;
  }
});
var methodsRefETt = ui.Select({
  items      :['ETo', 'ETr'],
  value      :'ETo',
  placeholder:'ETo',
  onChange   :function(selected){
    removeAll();
    return selected;
  }
});
var methodsRefETs = ui.Select({
  items      :['ERA5', 'CFSV2'],
  value      :'ERA5',
  placeholder:'ERA5',
  onChange   :function(selected){
    removeAll();
    return selected;
  }
});
var methodsPanel = ui.Panel({
  layout :ui.Panel.Layout.flow('vertical'),
  style  :{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid #000000'},
  widgets:[
    ui.Label({value:'Global assumptions', style:style01,}),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position:'top-center'},
      widgets:[ui.Label({value:'Soil Adjusted Vegetation Index (unitless)', style:style06,}), methodsSAVI,]
    }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position:'top-center'},
      widgets:[ui.Label({value:'Leaf Area Index (m2/m2)', style:style06,}), methodsLAI,]
    }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position:'top-center'},
      widgets:[ui.Label({value:'24-hour net radiation (W/m2)', style:style06,}), methodsRn24,]
    }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position:'top-center'},
      widgets:[ui.Label({value:'Soil heat flux (W/m2)', style:style06,}), methodsG,]
    }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position:'top-center'},
      widgets:[ui.Label({value:'Reference ET type', style:style06,}), methodsRefETt,]
    }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position:'top-center'},
      widgets:[ui.Label({value:'Reference ET source', style:style06,}), methodsRefETs,]
    }),
    ]
});
leftPanel.add(methodsPanel);
////////////////////////////////////////////////
var LonText = ui.Textbox({
  value   :"Longitude",
  style   :{fontSize:'20px', fontWeight:'normal', color:"red", textAlign:'center', margin:'auto'},
  disabled:true,
}); 
var LatText = ui.Textbox({
  value   :"Latitude",
  style   :{fontSize:'20px', fontWeight:'normal', color:"red", textAlign:'center', margin:'auto'},
  disabled:true,
}); 
var locationSearch = ui.Panel({
  layout :ui.Panel.Layout.flow('vertical'),
  style  :{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid black'},
  widgets:[
    ui.Label({value:'Location information', style:style01,}),
    ui.Panel({
      layout :ui.Panel.Layout.flow("vertical"),
      style  :{position: 'top-center'},
      widgets:[ui.Label({value:"Click on the map to select a location", style:style02})]}),
    ui.Panel({
      layout :ui.Panel.Layout.flow("vertical"),
      style  :{position:'top-center', margin:'auto'},
      widgets:[ui.Panel({layout:ui.Panel.Layout.flow("horizontal"), style:{position:'top-center', margin:'auto'}, widgets:[LonText, LatText]}), searchButton]
    }),
  ]
});
leftPanel.add(locationSearch);
////////////////////////////////////////////////
var outputs = ui.Select({
  items   :layers,
  onChange:function(selected){
    return selected;
  }
});
var outputsPanel = ui.Panel({
  layout :ui.Panel.Layout.flow('vertical'),
  style  :{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid #000000'},
  widgets:[
    ui.Label({value:'Outputs', style:style01,}),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"), 
      style  :{position:'top-center'},
      widgets:[ui.Label({value:'Add layer', style:style06,}), outputs]
    }),
    ]
});
////////////////////////////////////////////////
var drawRectangle = ui.Button({
  label   :'By rectangle',
  disabled:true,
  onClick :function(){
    drawingTools.clear();
    drawingTools.layers().add(ui.Map.GeometryLayer({geometries:null, name:'AOI4Downloading', color:'23cba7'}));
    drawingTools.setShape('rectangle');
    drawingTools.draw();
    drawingTools.onDraw(function(){
      drawingTools.stop();
      var AOI  = drawingTools.layers().get(0).getEeObject();
      var contains = footprint.contains({'right':AOI, 'maxError':1});
      contains.evaluate(function(contain){
        if (contain){
          submitButton.setDisabled(false);
          add2Console(['Click on the Submit button.']);
        }
        else{
          add2Console(["The chosen AOI falls outside the user's designated satellite scene."]);
        }
      });
    });
  }
});
var drawPolygon = ui.Button({
  label   :'By polygon',
  disabled:true,
  onClick :function(){
    drawingTools.clear();
    drawingTools.layers().add(ui.Map.GeometryLayer({geometries:null, name:'AOI4Downloading', color:'23cba7'}));
    drawingTools.setShape('polygon');
    drawingTools.draw();
    drawingTools.onDraw(function(){
      drawingTools.stop();
      var AOI = drawingTools.layers().get(0).getEeObject();
      var contains = footprint.contains({'right':AOI, 'maxError':1});
      contains.evaluate(function(contain){
        if (contain){
          submitButton.setDisabled(false);
          add2Console(['Click on the Submit button.']);
        }
        else{
          add2Console(["The chosen AOI falls outside the user's designated scene."]);
        }
      });
    });
  }
});
var submitButton = ui.Button({
  label   :'Submit',
  disabled:true,
});
var downloadLabel = ui.Label({
  style:style07
});
downloadLabel.style().set({shown: false});
var selectlayer = ui.Select({
  items   :layers,
  onChange:function(selected){
    drawRectangle.setDisabled(false);
    drawPolygon.setDisabled(false);
    return selected;
  }
});
var nodata = ui.Select({
  items      :['-99', '-999', '-9999','Default'],
  value      :'Default',
  placeholder:'Default',
  onChange   :function(selected){
    return selected;
  }
});
var downloadingPanel = ui.Panel({
  layout :ui.Panel.Layout.flow('vertical'),
  style  :{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid #000000'},
  widgets:[
    ui.Label({value:'Downloading', style:style01,}),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position:'top-center'},
      widgets:[ui.Label({value:'Select layer', style:style06,}), selectlayer, ui.Label({value:'Select nodata', style:style06}), nodata]
    }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position:'top-center'},
      widgets:[ui.Label({value:'Draw AOI', style:style06,}), drawRectangle, drawPolygon, submitButton]
    }),
    ui.Panel({
      layout :ui.Panel.Layout.flow("horizontal"),
      style  :{position:'top-center'},
      widgets:[downloadLabel]
    }),
    ]
});
////////////////////////////////////////////////
map.onClick(function(coords){
  if (activate){
    removeAll();
    var point = ee.Geometry.Point([coords.lon, coords.lat]);
    var contains = domainOfAOI.geometry().contains({'right':point, 'maxError':1});
    contains.evaluate(function(contain){
      if (contain){
        LonText.setValue(coords.lon);
        LatText.setValue(coords.lat);        
        addDraw(point);
        if (search){
          search = false;
          add2Console(['Click on the Search button.']);
        }
      }
      else{
        add2Console(["The chosen location falls outside the user's designated study area (DomainOfAOI)."]);
      }
    });
  }
  else{
    add2Console(["Write your username and password, then press the Enter button."]);
  }
});
add2Console(["This version is available only in Germany.",
             "Username: Germany",
             "Password: 1234567",
             "To start, please press the Enter button."]);
////////////////////////////////////////////////
ui.root.clear();
ui.root.add(mainPanel);