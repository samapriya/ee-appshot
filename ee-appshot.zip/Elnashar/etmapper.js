//////////////////////////////////////////////// General
// General constants
var L = 0.5;     // constant; unitless, for SAVI calculation
var R = 287.1;   // Gas constant; J/kgK
var k = 0.41;    // Von Karman constant; unitless
var g = 9.80665; // Gravitational constant; m/s2
var Z1 = 0.1;     // Heights above zero plane displacement height (d); m
var Z2 = 2;       // Heights above zero plane displacement height (d); m
var Z3 = 200;     // Blending layer height; m, (typically 100-200 m); zBlend 
var Tv = 1.01;    // Virtual temperature
var Cp = 1004.16; // Specific heat of moist air; J/Kg*K
var C0 = 273.15;  // Zero Celsius; K
var P0 = 101.3;   // Pressure at sea level; KPa
var PI = Math.PI; // The ratio of the circumference of a circle to its diameter; 
var Kt = 1;       // Air turbidity coefficient(1.0 clean, 0.5 turbid, dusty/polluted); unitless
var Rp = 0;       // Path radiance (10.4-12.5 micro m); W/m2*sr*micro m
var Ry = 0;       // Narrow band downward thermal radiation for a clear sky; W/m2*sr*micro m
var PTc = 1.26;     // Priestly-Taylor coefficient
var Tlr = 6.5/1000; // Temperature lapse rate; C/m >> (Kongo and Jewitt, 2006); 10/1000
var NBT = 1;        // Narrow band transmissivity of air (10.4-12.5 micro m); unitless
var G24 = 0;        // 24-Hour soil heate flux; W/m2, (Morse et al., 2000; Jiang et al., 2009; Tang et al., 2011)
var Tas = 293.15;   // Standard air temperature; K
var hTOs   = 3600;     // Conversion factor between hour to second=3600; s/h; 1*60*60.0
var dTOs   = 86400;    // Conversion factor between day to second =86400; s/d; 24*60*60.0
var CpMA   = 0.001013; // Specific heat of moist air; MJ/Kg*C
var MWWr   = 0.622;    // Ratio molecular weight of water vapor/dry air; unitless
var Gsc_W  = 1367; // Solar constant; W/m2
var Gsc_MJ = 4.92; // Solar constant; MJ/m2*h
var rhoH20 = 1000; // Density of water; Kg/m3
var alpha  = 0.23; // Albedo or canopy reflection coefficient >> (ASCE, 2005): Page (44); RET-ET for Windows ver. 4.1: Page (63)
var sigma    = 4.901000E-09; // Stefan-Boltzmann constant; MJ/K4*m2*d
var sigma_MJ = 2.042000E-10; // Stefan-Boltzmann constant; MJ/K*m*h
var sigma_W  = 5.670373E-08; // Stefan-Boltzmann constant; W/m2*K4*day 5.67e-8
var NDVI_Full = 0.80;
var NDVI_Bare = 0.15;
var EVI_Full  = 0.70;
var EVI_Bare  = 0.05;
var ETrF_Bare = 0.00;
var BeEf = true;  // bestEffort
var MxPx = 10e13; // maxPixels
var exp = ee.Image(0).rename('exp');
// Constants for Surface Albedo calculation
var optBands  = ['B','G','R','NIR','SWIR1','SWIR2'];
var Weight457 = ee.Image([0.254, 0.149, 0.147, 0.311, 0.103, 0.036]).float().rename(optBands);
var Weight008 = ee.Image([0.246, 0.146, 0.191, 0.304, 0.105, 0.008]).float().rename(optBands);
var Weight008 = ee.Image([0.115, 0.143, 0.180, 0.281, 0.108, 0.042]).float().rename(optBands); // geeSEBAL
// Topographic and geoloactions
var Elevation   = ee.Image("USGS/SRTMGL1_003").select(['elevation'],['Elevation']); // 30.922080775909325
var SlopeDegree  = ee.Terrain.slope(Elevation).clamp(0, 90).rename('SlopeDegree');
var AspectDegree  = ee.Terrain.aspect(Elevation).clamp(0, 360).rename('AspectDegree');
var SlopeInRadians  = exp.expression('Slope*(PI/180)', {'Slope':SlopeDegree, 'PI':PI}).rename('SlopeInRadians');
var AspectInRadians  = exp.expression('(Aspect-180)*(PI/180)', {'Aspect':AspectDegree, 'PI':PI}).rename('AspectInRadians');
var ESAv = ee.Image.cat([Elevation, SlopeDegree, AspectDegree, SlopeInRadians, AspectInRadians]);
// Visualization parameters
var True_viz  = {min:0, max:0.12, bands:['R','G','B']};
var False_viz = {min:0, max:0.50, bands:['SWIR1','NIR','R']};
var ETf_viz  = {min:0.0, max:1.05, palette:['Red','SandyBrown','Yellow','LimeGreen','DarkBlue']};
var ETa_viz  = {min:0.0, max:10.0, palette:['DarkRed','SandyBrown','Yellow','LimeGreen','DarkBlue']};
var NDVI_viz = {min:0.0, max:1.00, palette:['FFFFFF','CE7E45','DF923D','F1B555','FCD163','99B718','74A901','66A000','529400','3E8601','023B01','012E01','011D01','011301']};
//////////////////////////////////////////////// Functions
var image = ee.Image('LANDSAT/LC08/C01/T1_SR/LC08_177040_20211104');
function getgeeSEBAL(image){
  // https://etbrasil.users.earthengine.app/view/geesebal
  // https://github.com/gee-hydro/geeSEBAL
  function f_cloudMaskL457_SR(image){
    var quality = image.select('pixel_qa');
      var c01 = quality.eq(66); //CLEAR, LOW CONFIDENCE CLOUD 
      var c02 = quality.eq(68); //WATER, LOW CONFIDENCE CLOUD 
    var mask = c01.or(c02);
    return image.updateMask(mask);
    }
  function f_cloudMaskL8_SR(image){
    var quality = image.select('pixel_qa');
      var c01 = quality.eq(322); 
      var c02 = quality.eq(324); 
      var c03 = quality.eq(1346); 
    var mask = c01.or(c02).or(c03);
    return image.updateMask(mask);
    }
  function f_albedoL5L7(image){
      var alfa = image.expression(
        '(0.254*B1) + (0.149*B2) + (0.147*B3) + (0.311*B4) + (0.103*B5) + (0.036*B7)',{
          'B1' : image.select(['B']).divide(10000),
          'B2' : image.select(['GR']).divide(10000),
          'B3' : image.select(['R']).divide(10000),
          'B4' : image.select(['NIR']).divide(10000),
          'B5' : image.select(['SWIR_1']).divide(10000),
          'B7' : image.select(['SWIR_2']).divide(10000)
        }).rename('ALFA');
      return image.addBands(alfa);
  }
  function f_albedoL8(image){
      var alfa = image.expression(
        '(0.115*B2) + (0.143*B3) + (0.180*B4) + (0.281*B5) + (0.108*B6) + (0.042*B7)',{
          'B2' : image.select(['B']).divide(10000),
          'B3' : image.select(['GR']).divide(10000),
          'B4' : image.select(['R']).divide(10000),
          'B5' : image.select(['NIR']).divide(10000),
          'B6' : image.select(['SWIR_1']).divide(10000),
          'B7' : image.select(['SWIR_2']).divide(10000)
        }).rename('ALFA');
      return image.addBands(alfa);
  }
  function getRn24(sts, As, Rs24){
    sts        = ee.Date(sts);
    var DOY    = sts.getRelative('day', 'year').add(1);
    var DA     = Rs24.expression('DOY*((2*PI)/365)', {'DOY':DOY, 'PI':PI}).rename('DA');
    var dr     = Rs24.expression('(cos(DA)*0.033)+1', {'DA':DA}).rename('dr');
    var delta  = Rs24.expression('0.409*sin(DA-1.39)', {'DA':DA}).rename('delta');
    var Lat    = As.addBands([ee.Image.pixelLonLat()]).select('latitude');
    var phi    = Rs24.expression('Lat*(PI/180)', {'Lat':Lat, 'PI':PI}).rename('phi');
    var omegas = Rs24.expression('acos(-tan(phi)*tan(delta))', {'phi':phi, 'delta':delta}).rename('omegas');
    var Ra24   = Rs24.expression('(24/PI)*Gcs*dr*((omega*sin(phi)*sin(delta))+(cos(phi)*cos(delta)*sin(omega)))*11.5740',
                                {'PI':PI,'Gcs':Gsc_MJ,'dr':dr, 'omega':omegas, 'delta':delta, 'phi':phi}).rename('Ra24');
    var Rns24 = Rs24.expression('(1-As)*Rs', {'As':As, 'Rs':Rs24}).rename('Rns24');
    var Rnl24 = Rs24.expression('Cs*(Rs/Ra)', {'Cs':110, 'Rs':Rs24, 'Ra':Ra24}).rename('Rnl24');
    var Rn24  = Rs24.expression('Rns-Rnl',{'Rns':Rns24, 'Rnl':Rnl24}).rename('Rn24');    
    return Rn24;
  }
  function era5(As, time_start){
    var DATASET = ee.ImageCollection('ECMWF/ERA5_LAND/HOURLY'); // 1-hour ; 11,131.949079327358; 1981-01-01-ongoing >> geeSEBAL
    var TIME_START_NUM = ee.Number(time_start);
    var PREVIOUS_TIME  = TIME_START_NUM.subtract(1*60*60*1000);
    var NEXT_TIME      = TIME_START_NUM.add(1*60*60*1000);    
    var PREVIOUS_IMAGE = (DATASET.filter(ee.Filter.date(PREVIOUS_TIME, TIME_START_NUM)).limit(1, 'system:time_start', false).first());
    var NEXT_IMAGE     = (DATASET.filter(ee.Filter.date(TIME_START_NUM, NEXT_TIME)).limit(1, 'system:time_start', false).first());
    var IMAGE_PREVIOUS_TIME = ee.Number(PREVIOUS_IMAGE.get('system:time_start'));
    var IMAGE_NEXT_TIME     = ee.Number(NEXT_IMAGE.get('system:time_start'));
    var DELTA_TIME          = (TIME_START_NUM.subtract(IMAGE_PREVIOUS_TIME)).divide(IMAGE_NEXT_TIME.subtract(IMAGE_PREVIOUS_TIME));
    var Td = NEXT_IMAGE.select('dewpoint_temperature_2m').subtract(PREVIOUS_IMAGE.select('dewpoint_temperature_2m')).multiply(DELTA_TIME).add(PREVIOUS_IMAGE.select('dewpoint_temperature_2m'));
        Td = Td.subtract(C0).rename('Td');
    var ea = Td.multiply(17.27).divide(Td.add(237.3)).exp().multiply(0.6108).rename('ea');
    var Ta = NEXT_IMAGE.select('temperature_2m').subtract(PREVIOUS_IMAGE.select('temperature_2m')).multiply(DELTA_TIME).add(PREVIOUS_IMAGE.select('temperature_2m'));
        Ta = Ta.subtract(C0).rename('Ta');
    var es = Ta.expression('0.6108*(exp((17.27*T)/(T+237.3)))', {'T':Ta}).rename('es');
    var RH = ea.divide(es).multiply(100).rename('RH');
    var u  = NEXT_IMAGE.select('u_component_of_wind_10m').subtract(PREVIOUS_IMAGE.select('u_component_of_wind_10m')).multiply(DELTA_TIME).add(PREVIOUS_IMAGE.select('u_component_of_wind_10m')).rename('u_wind');
    var v  = NEXT_IMAGE.select('v_component_of_wind_10m').subtract(PREVIOUS_IMAGE.select('v_component_of_wind_10m')).multiply(DELTA_TIME).add(PREVIOUS_IMAGE.select('v_component_of_wind_10m')).rename('v_wind');
    var uz = exp.expression('sqrt((ux_u)**2 + (ux_v) ** 2)',{'ux_u':u,'ux_v':v}).rename('ux');
    var P  = NEXT_IMAGE.select('surface_pressure').subtract(PREVIOUS_IMAGE.select('surface_pressure')).multiply(DELTA_TIME).add(PREVIOUS_IMAGE.select('surface_pressure')).divide(ee.Number(1000)).rename('P');
    var dataset = DATASET.filter(ee.Filter.date(ee.Date(time_start), ee.Date(time_start).advance(1, 'day')));
    var Ta24Max = dataset.select('temperature_2m').max().subtract(C0).rename('Ta24Max');
    var Ta24    = dataset.select('temperature_2m').mean().subtract(C0).rename('Ta24');
    var Rs24    = dataset.select("surface_solar_radiation_downwards_hourly").sum().divide(86400).rename('Rs24');
    var Rn24    = getRn24(time_start, As, Rs24);
    // Map.addLayer(ee.Image.cat([Ta, ea, uz, Ta24Max, Ta24, Rn24]), {}, 'Climate1', 0, 1);
    return ee.Image.cat(Rn24, Ta, uz, ea, es, RH);
  }
  function fexp_cold_pixel(image, p_top_NDVI, p_coldest_Ts){
    var geom = image.geometry().dissolve(0.001); 
    var d_perc_top_NDVI = image.select('negNDVI').reduceRegion({
      reducer: ee.Reducer.percentile([p_top_NDVI]), 
      geometry:geom, 
      scale: 30,
      maxPixels:10e13
    });
    var n_perc_top_NDVI = ee.Number(d_perc_top_NDVI.get('negNDVI'));
    var i_top_NDVI = image.updateMask(image.select('negNDVI').lte(n_perc_top_NDVI));
    var d_perc_low_LST = i_top_NDVI.select('terLST').reduceRegion({
      reducer: ee.Reducer.percentile([p_coldest_Ts]), 
      geometry:geom, 
      scale: 30,
      maxPixels:10e13
      }); 
    var n_perc_low_LST = ee.Number(d_perc_low_LST.get('terLST'));
    var i_cold_lst = i_top_NDVI.updateMask(i_top_NDVI.select('terLST').lte(n_perc_low_LST));
    var c_lst_cold20 =  i_cold_lst.updateMask(image.select('terLST').gte(200));
    //Creates a reducer that outputs the minimum value of its (first) input.
    var med_lst_cold20 = c_lst_cold20.select('terLST')
      .reduceRegion({reducer:  ee.Reducer.median(), geometry:geom, scale: 30, maxPixels:10e13});
     var n_med_lst_cold20 = ee.Number(med_lst_cold20.get('terLST'));  
      var sum_final_cold_pix = c_lst_cold20.select('int')
     .reduceRegion({reducer:  ee.Reducer.sum(), geometry:geom, scale: 30, maxPixels:10e13}); 
      var n_sum_final_cold_pix = ee.Number(sum_final_cold_pix.get('int'));  
     var dif_temp = c_lst_cold20.expression( 
        'abs(LST - LST_med_20cold)', {
          'LST' : c_lst_cold20.select('terLST'),
          'LST_med_20cold': n_med_lst_cold20,
        }).rename('dif_temp'); 
     c_lst_cold20 = c_lst_cold20.addBands(dif_temp);
     var d_red_min = c_lst_cold20.select('dif_temp', 'terLST', 'longitude','latitude', 'NDVI').reduceRegion({
      reducer: ee.Reducer.min(5), 
      geometry:geom, 
      scale: 30,
      maxPixels:10e13
      });
    var n_Ts_cold = ee.Number(d_red_min.get('min1'));  
    var n_long_cold = ee.Number(d_red_min.get('min2'));
    var n_lat_cold = ee.Number(d_red_min.get('min3'));
    var n_ndvi_cold = ee.Number(d_red_min.get('min4'));
    // Make a Dictionary on the server.
    var d_cold_pixel = ee.Dictionary({
    temp: n_Ts_cold,
    ndvi: n_ndvi_cold,
    x: n_long_cold,
    y: n_lat_cold,
    sum: n_sum_final_cold_pix
    });
  return d_cold_pixel;
  }
  function fexp_hot_pixel(image, p_lowest_NDVI, p_hottest_Ts){
     var geom = image.geometry().dissolve(0.001);
    // 1 - Identify the down xx% NDVI pixels ****************************************************************************************
     // Calculate percentile from  ndvi
     var d_perc_down_ndvi = image.select('posNDVI').reduceRegion({
        reducer: ee.Reducer.percentile([p_lowest_NDVI]), 
        geometry:geom, 
        scale: 30,
        maxPixels:10e13,
      });
      var n_perc_low_NDVI = ee.Number(d_perc_down_ndvi.get('posNDVI'));
    var i_low_NDVI = image.updateMask(image.select('posNDVI').lte(n_perc_low_NDVI));
    // 2 - Identify the hottest pixels  *********************************************************************************************
     var d_perc_top_lst = i_low_NDVI.select('negLST').reduceRegion({
        reducer: ee.Reducer.percentile([p_hottest_Ts]), 
        geometry:geom, 
        scale: 30,
        maxPixels:10e13,
      });
    var n_perc_top_lst = ee.Number(d_perc_top_lst.get('negLST'));
    var i_top_LST = i_low_NDVI.updateMask(i_low_NDVI.select('negLST').lte(n_perc_top_lst));
    var c_lst_hotpix =  i_top_LST;
    var med_lst_hotpix = c_lst_hotpix.select('terLST')
      .reduceRegion({reducer: ee.Reducer.median(), geometry:geom, scale: 30, maxPixels:10e13});
    var n_med_lst_hotpix = ee.Number(med_lst_hotpix.get('terLST'));  //transforma de objeto para numero
    var sum_final_hot_pix = c_lst_hotpix.select('int')
      .reduceRegion({reducer:  ee.Reducer.sum(), geometry:geom, scale: 30, maxPixels:10e13});
     var n_sum_final_hot_pix = ee.Number(sum_final_hot_pix.get('int'));  //transforma de objeto para numero
     var dif_temp = c_lst_hotpix.expression( 
        'abs(LST - LST_med_hotpix)', {
          'LST' : c_lst_hotpix.select('terLST'),
          'LST_med_hotpix': ee.Number(n_med_lst_hotpix),
        }).rename('dif_temp'); 
    c_lst_hotpix = c_lst_hotpix.addBands(dif_temp);
      var d_min_diftemp_hot = c_lst_hotpix.select('dif_temp', 'terLST', 'Rn', 'G','SAVI','NDVI','longitude','latitude').reduceRegion({
      reducer: ee.Reducer.min(8), 
      geometry:geom, 
      scale: 30,
      maxPixels:10e13,
      });
    var n_Ts_hot = d_min_diftemp_hot.get('min1');  
    var n_Rn_hot = d_min_diftemp_hot.get('min2');
    var n_G_hot = d_min_diftemp_hot.get('min3');
    var n_savi_hot = d_min_diftemp_hot.get('min4');
    var n_ndvi_hot = d_min_diftemp_hot.get('min5');
    var n_long_hot = d_min_diftemp_hot.get('min6');
    var n_lat_hot = d_min_diftemp_hot.get('min7');
    // Make a Dictionary on the server.
    var d_hot_pixel = ee.Dictionary({
      temp: n_Ts_hot,
      x: n_long_hot,
      y: n_lat_hot,
      Rn: n_Rn_hot,
      G: n_G_hot,
      ndvi: n_ndvi_hot,
      sum: n_sum_final_hot_pix,
    });
    return d_hot_pixel;
  }
  function spec_ind(image){
    //NORMALIZED DIFFERENCE VEGETATION INDEX (NDVI)
    var ndvi =  image.normalizedDifference(['NIR', 'R']).rename('NDVI');
    //ENHANCED VEGETATION INDEX (EVI)
    var evi = image.expression('2.5*((N-R)/(N+(6*R)-(7.5*B)+1))', {'N':image.select('NIR').divide(10000),'R':image.select('R').divide(10000),'B':image.select('B').divide(10000),}).rename('EVI');
    //SOIL ADHUSTED VEGETATION INDEX (SAVI)
    var savi = image.expression('((1+0.5)*(B5-B4))/(0.5+(B5 + B4))', {'B4':image.select('R').multiply(0.0001),'B5':image.select('NIR').multiply(0.0001)}).rename('SAVI');
    //NORMALIZED DIFFERENCE WATER INDEX (NDWI)
    var ndwi =  image.normalizedDifference(['GR', 'NIR']).rename('NDWI');
     //LEAF AREA INDEX (LAI)
     // var savi1 = savi.where(savi.gt(0.689), 0.689); 
     // var lai = image.expression('-(log((0.69-SAVI)/0.59)/0.91)',{'SAVI':savi1}).rename('LAI');
    var lai = savi.where(savi.lte(0.10), 0).where(savi.gt(0.688), 6) 
                  .where(savi.gt(0.10).and(savi.lte(0.688)), image.expression('-(log((0.69-SAVI)/0.59)/0.91)', {'SAVI':savi})).rename('LAI');
    //BROAD-BAND SURFACE EMISSIVITY (e_0)
    var e_0 = image.expression('0.950+(0.0100*LAI)',{'LAI':lai});
        e_0 = e_0.where(lai.gt(3), 0.980).rename('e_0');
    //NARROW BAND TRANSMISSIVITY (e_NB)
    var e_NB = image.expression('0.970+(0.0033*LAI)',{'LAI':lai});
        e_NB = e_NB.where(lai.gt(3), 0.98).rename('e_NB');
    var log_eNB = e_NB.log();
    //LAND SURFACE TEMPERATURE (LST) [K]
    var comp_onda = ee.Number(1.122e-05); 
    var lst = image.expression('Tb/(1+((comp_onda*Tb/fator)*log_eNB))',{'Tb':image.select('BRT').multiply(0.1),'comp_onda':ee.Number(1.122e-05),'log_eNB':log_eNB,'fator':ee.Number(1.438e-02),}).rename('T_LST');
    //GET COORDINATES
    var proj = image.select('B').projection();
    var latlon = image.select('B').addBands(ee.Image.pixelLonLat()).reproject({crs:proj});
    //var latlon = ee.Image.pixelLonLat().reproject(proj);
    var coords = latlon.select(['longitude', 'latitude']);
    //FOR FUTHER USE
    var posNDVI = ndvi.updateMask(ndvi.gt(0)).rename('posNDVI');  
    var negNDVI =  posNDVI.multiply(-1).rename('negNDVI');
    var int = ee.Image(1).rename('int');
    // Map.addLayer(ee.Image.cat([ndvi, evi, savi, lai, lst, e_0, e_NB, ndwi]), {}, 'A', 0, 1);
    return image.addBands([ndvi, evi, savi, lai, lst, e_0, e_NB, coords, negNDVI, posNDVI, int, ndwi]);
  }
  function LST_correction(image, Ta, RH, SUN_ELEVATION, hour, min, Ele, s, gamma, phi, Lon){
    var geom = image.geometry().dissolve(0.001);
    //SOLAR CONSTANT [W M-2]
    var gsc = ee.Number(1367);
    //DAY OF YEAR
    var dateStr = image.date();
    var doy = dateStr.getRelative('day', 'year').add(1);
    var Pi = ee.Number(3.14);
    //INVERSE RELATIVE  DISTANCE EARTH-SUN
    var d1 =  ee.Number(2).multiply(Pi).divide(ee.Number(365));
    var d2 = d1.multiply(doy);
    var d3 = d2.cos();
    var dr = ee.Number(1).add(ee.Number(0.033).multiply(d3));
    //ATMOSPHERIC PRESSURE [KPA] 
    //SHUTTLEWORTH (2012)
    var pres = exp.expression('P0*pow(((Tas-(Tlr*Z))/Tas),5.26)', {'P0':P0, 'Tas':Tas, 'Tlr':Tlr, 'Z':Ele}).rename('P');
    //SATURATION VAPOR PRESSURE (es) [KPA]
    var es = image.expression('0.6108*(exp((17.27*Ta)/(Ta+237.3)))', {'Ta':Ta}).rename('ES');
    //ACTUAL VAPOR PRESSURE (ea) [KPA]
    var ea = es.multiply(RH).divide(100).rename('EA');
    //WATER IN THE ATMOSPHERE [mm]
    //Garrison and Adler (1990)
    var W = image.expression('(0.14*EA*PATM)+2.1', {'PATM':pres, 'EA':ea}).rename('W_ATM');
    // SOLAR ZENITH ANGLE OVER A HORZONTAL SURFACE
    var solar_zenith = ee.Number(90).subtract(SUN_ELEVATION);
    var solar_zenith_radians = solar_zenith.multiply(Math.PI/180);
    var cos_theta = solar_zenith_radians.cos();  
    // Broad-band atmospheric transmissivity >> (ASCE, 2005)    
    var tao_sw = image.expression('0.35+0.627*exp(((-0.00146*P)/(Kt*cos_theta))-(0.075*(W/cos_theta)**0.4))', {'P':pres, 'W':W, 'Kt':ee.Number(1), 'cos_theta':cos_theta}).rename('Tao_sw');
    //AIR DENSITY [KG M-3]    
    var air_dens = image.expression('(1000*P)/(1.01*Ts*287)', {'P':pres, 'Ts':image.select('T_LST')});
    //TEMPERATURE LAPSE RATE (0.0065)
    var Temp_lapse_rate= ee.Number(0.0065) ;
    //LAND SURFACE TEMPERATURE CORRECTION DEM [K]
    var Tdiff = image.expression('Tlr*Ele', {'Ele':Ele, 'Tlr':Temp_lapse_rate});
    var Ts_dem = image.select('T_LST').add(Tdiff).rename('Ts_dem');
    //COS ZENITH ANGLE SUN ELEVATION #ALLEN ET AL. (2006)
    var B = (ee.Number(360).divide(ee.Number(365))).multiply(doy.subtract(ee.Number(81)));
    var delta = ee.Image(ee.Number(23.45).multiply(PI/180).sin().asin().multiply(B.multiply(PI/180).sin()));
    //CONSTANTS ALLEN ET AL. (2006)
    var a = delta.sin().multiply(phi.cos()).multiply(s.sin()).multiply(gamma.cos()).subtract(delta.sin().multiply(phi.sin().multiply(s.cos()))).rename('a');
    var b = delta.cos().multiply(phi.cos()).multiply(s.cos()).add(delta.cos().multiply(phi.sin().multiply(s.sin()).multiply(gamma.cos()))).rename('b');
    var c = delta.cos().multiply(s.sin()).multiply(gamma.sin()).rename('c');
    var cenLon = ee.Number(geom.centroid().coordinates().get(0));
    var w = ee.Image(hour).add(Lon.divide(15).int()).add(min.divide(60)).subtract(12).multiply(15).multiply(PI/180);
    var cos_zn =image.expression('-a+b*w_cos +c*w_sin',{'a':a, 'b':b, 'c':c, 'w_cos':w.cos(), 'w_sin':w.sin()}) ;
    var TsSA = image.expression('(Gsc*dr*Tao*cos_zn-Gsc*dr*Tao*cos_theta)/(air_dens*1004.16*0.050)',{'Gsc':gsc, 'dr':dr, 'Tao':tao_sw, 'cos_theta':cos_theta, 'cos_zn':cos_zn, 'air_dens':air_dens}).rename('TsSA');
    var TS_DEM = image.expression('Ts+TsSA', {'Ts':Ts_dem, 'TsSA':TsSA}).clamp(C0, 350).rename('T_LST_DEM');
    //MASKS FOR SELECT PRE-CANDIDATES PIXELS   
    var ndwi = image.select('NDWI');
    var terLST = image.select('T_LST').updateMask(ndwi.lte(0).and(cos_zn.gt(0.6))).rename('terLST'); 
    var negLST = image.select('T_LST').multiply(-1).updateMask(cos_zn.gt(0.6)).rename('negLST');
    return image.addBands([TS_DEM, terLST, negLST, cos_zn.rename('Solar_angle_cos')]);
  }
  function fexp_radlong_up(image){
    //BROAD-BAND SURFACE THERMAL EMISSIVITY
    //TASUMI ET AL. (2003)
    //ALLEN ET AL. (2007)
    var emi = image.expression('0.95+(0.01*LAI)', {'LAI':image.select('LAI')});
    //LAI
    var lai = image.select('LAI');
    emi = emi.where(lai.gt(3), 0.98);
    var Rl_up = image.expression('emi*stefBol*(LST**4)', {'emi':emi, 'stefBol':sigma_W, 'LST':image.select('T_LST')}).rename('Rl_up');
    // Map.addLayer(ee.Image.cat([Rl_up]), {}, 'A', 0, 1);
    image = image.addBands([Rl_up]);
  return image;
  }
  function fexp_radshort_down(image, Ele, Ta, RH,sun_elevation){
    //DAY OF THE YEAR 
    var dateStr = image.date();
    var doy = dateStr.getRelative('day', 'year').add(1);
   //INVERSE RELATIVE  DISTANCE EARTH-SUN
    var d1 =  ee.Number(2).multiply(Math.PI).divide(ee.Number(365));
    var d2 = d1.multiply(doy);
    var d3 = d2.cos();
    var dr = ee.Number(1).add(ee.Number(0.033).multiply(d3));
    //ATMOSPHERIC PRESSURE [KPA]
    //SHUTTLEWORTH (2012)
    // var P = image.expression('101.3*((293-(0.0065*Z))/293)** 5.26 ', {'Z' : Ele,}).rename('P_ATM');
    var P = exp.expression('P0*pow(((Tas-(Tlr*Z))/Tas),5.26)', {'P0':P0, 'Tas':Tas, 'Tlr':Tlr, 'Z':Ele}).rename('P_ATM');
    //SATURATION VAPOR PRESSURE (es) [KPA]
    var es = image.expression('0.6108 *(exp((17.27*Ta)/(Ta+237.3)))', {'Ta':Ta}).rename('es');
    //ACTUAL VAPOR PRESSURE (ea) [KPA]
    var ea = es.multiply(RH).divide(100).rename('ea');
    //WATER IN THE ATMOSPHERE [mm]
    //GARRISON AND ADLER (1990)
    var W = image.expression('(0.14*ea*P)+2.1', {'ea':ea, 'P':P}).rename('W_ATM');
    //SOLAR ZENITH ANGLE OVER A HORIZONTAL SURFACE
    var solar_zenith = ee.Number(90).subtract(sun_elevation);
    var solar_zenith_radians = solar_zenith.multiply(Math.PI/180);
    var cos_theta = solar_zenith_radians.cos();
    cos_theta = image.select('Solar_angle_cos');
    //BROAD-BAND ATMOSPHERIC TRANSMISSIVITY (tao_sw) 
    //ASCE-EWRI (2005)
    var tao_sw = image.expression('0.35+0.627*exp(((-0.00146*P)/(Kt*cos_theta))-(0.075*(W/cos_theta)**0.4))', {'P':P,'W': W,'Kt':Kt,'cos_theta':cos_theta}).rename('Tao_sw');
    //INSTANTANEOUS SHORT-WAVE RADIATION (Rs_down) [W M-2]   
    var Ra = image.expression('Gsc*dr*SIA', {'Gsc':Gsc_W,'dr':dr, 'SIA':cos_theta}).rename('Ra');
    var Rs_down = image.expression('Ra*Tao', {'Ra':Ra, 'Tao':tao_sw}).rename('Rs_down');
    // Map.addLayer(ee.Image.cat([Rs_down]), {}, 'A', 0, 1);
    image =  image.addBands([tao_sw, Rs_down]);
  return image; 
  }
  function fexp_radlong_down(image, n_Ts_cold){
    var Ea      = image.expression('0.85*pow(-log(Tau),0.090)', {'Tau':image.select('Tao_sw')}).rename('Ea');
    var SBL     = image.expression('sigma*pow(T, 4)', {'sigma':sigma_W, 'T':n_Ts_cold}).rename('SBL');
    var Rl_down = image.expression('Ea*SBL', {'Ea':Ea,'SBL':SBL}).rename('Rl_down');
    // Map.addLayer(ee.Image.cat([Rl_down]), {}, 'A', 0, 1);
  return image.addBands([Rl_down]);
  }
  function fexp_radbalance(image){
    var alfa    = image.select('ALFA');
    var Rs_down = image.select('Rs_down');
    var Rl_down = image.select('Rl_down');
    var Rl_up   = image.select('Rl_up');
    var e_0     = image.select('e_0'); 
    var Rn = image.expression('((1-alfa)*Rs_down)+Rl_down-Rl_up-((1-e_0)*Rl_down)',{'alfa':alfa, 'Rs_down':Rs_down, 'Rl_down':Rl_down, 'Rl_up':Rl_up, 'e_0':e_0}).rename('Rn');
    // Map.addLayer(ee.Image.cat([alfa, Rs_down, Rl_down, Rl_up, e_0, Rn]), {}, 'A', 0, 1);
    return image.addBands([Rn]);
  }
  function fexp_soil_heat(image){
    var G = image.expression('Rn*(T_LST-273.15)*(0.0038+(0.0074*ALFA))*(1-0.98*(NDVI**4))',
                            {'Rn':image.select('Rn'), 'NDVI':image.select('NDVI'), 'ALFA':image.select('ALFA'), 'T_LST':image.select('T_LST_DEM')}).rename('G');
    // var G = image.expression('Rn*(0.05+0.18*exp(-0.521*LAI))', {'Rn':image.select('Rn'), 'LAI':image.select('LAI')}).rename('G');     
    // var G1 = image.expression('(0.084*Rn)+(1.80*(T_LST-273.15))', {'Rn':image.select('Rn'), 'T_LST':image.select('T_LST')}).rename('G1');
    // var lai = image.select('LAI');
    // G = G.where(lai.lt(0.5), G1).rename('G');
    // var G = image.expression('(0.3*Rn)*(1-0.98*(NDVI**4))', {'Rn':image.select('Rn'), 'NDVI':image.select('NDVI')}).rename('G');
    // var G1 = image.expression('(0.5*Rn)', {'Rn':image.select('Rn')});      
    // var ndvi = image.select('NDVI');
    // G = G.where(ndvi.lt(0), G1).rename('G');
  // Map.addLayer(ee.Image.cat([image.select('Rn'), image.select('T_LST_DEM'), G]), {}, 'A', 0, 1);
  return image.addBands([G]);
  }
  function fexp_sensible_heat_flux(image, n_Ts_cold, d_hot_pixel, ux, RH){
      var geom = image.geometry().dissolve(0.001);
      //SENSIBLE HEAT FLUX (H) [W M-2]
      var h  = ee.Number(3);        // Vegetation heights; m
      var Z1 = ee.Number(0.1);      // Heights above zero plane displacement height (d) (m)
      var Z2 = ee.Number(2);        // Heights above zero plane displacement height (d) (m)
      var Z3 = ee.Number(200);      // Blending layer height (m), (typically 100-200 m); zBlend 
      var Cp = ee.Number(1004.16);  // Specific heat of moist air (J/Kg*K)
      var k  = ee.Number(0.41);     // Von Karman constant (-)
      var CP_Ts  = n_Ts_cold;
      var HP_Ts  = ee.Number(d_hot_pixel.get('temp'));
      var HP_G   = ee.Number(d_hot_pixel.get('G'));
      var HP_Rn  = ee.Number(d_hot_pixel.get('Rn'));
      var HP     =  ee.Geometry.Point([ee.Number(d_hot_pixel.get('x')), ee.Number(d_hot_pixel.get('y'))]);
      var SAVI   = image.select('SAVI');
      var Ts_dem = image.select('T_LST_DEM');
      // Momentum roughness length (zom) at the weather station; m
      var n_zom = h.multiply(0.12); 
      // Friction velocity at weather station; m/s
      var i_ufric_ws = SAVI.expression('(k*ux)/log(Z2 /n_zom)', {'k':k, 'Z2':Z2, 'n_zom':n_zom, 'ux':ux }); 
      // Wind speed at blending height at the weather station; m/s
      var i_u200 = SAVI.expression('i_ufric_ws*(log(Z3/n_zom)/k)', {'i_ufric_ws':i_ufric_ws, 'Z3':Z3, 'n_zom':n_zom, 'k':k});
      // Momentum roughness length (zom) for each pixel; m
      var i_zom = SAVI.expression('exp((5.62*(SAVI))-5.809)', {'SAVI':SAVI,}); 
      // Friction velocity for each pixel; m/s
      var i_ufric = i_zom.expression('(k*u200)/(log(Z3/i_zom))', {'u200':i_u200,'Z3':Z3, 'i_zom':n_zom, 'k':k }).rename('u_fr');
      // Aerodynamic resistance to heat transport (rah); m/s
      var i_rah = i_ufric.expression('(log(Z2/Z1))/(i_ufric*0.41)', {'Z2':Z2,'Z1':Z1, 'i_ufric':i_ufric }).rename('rah'); 
      var i_rah_first = i_rah.rename('rah_first');
      // Air density hot pixel
      var n_ro_hot= (ee.Number(-0.0046).multiply(HP_Ts)).add(ee.Number(2.5538));
      // Sensible heat flux at the hot pixel
      var n_H_hot = HP_Rn.subtract(HP_G);
      // Iterative variables
      var n            = ee.Number(1);
      var n_dif        = ee.Number(1);
      var n_dif_min    = ee.Number(0.1);
      var list_dif     = ee.List([]);
      var list_dT_hot  = ee.List([]);
      var list_rah_hot = ee.List([]);
      var list_coef_a  = ee.List([]);
      var list_coef_b  = ee.List([]);
      // Iterative steps
      for (n = 1; n<16; n++){
        // Aerodynamic resistance to heat transport at the hot pixel
        var n_rah_hot = ee.Number(i_rah.select('rah').reduceRegion({reducer:ee.Reducer.first(), geometry:HP, scale:30, maxPixels:10e13}).get('rah'));
        // Near surface temperature difference in hot pixel (dT= Tz1-Tz2); k
        var n_dT_hot = (n_H_hot.multiply(n_rah_hot)).divide(n_ro_hot.multiply(Cp));
        // Near surface temperature difference in cold pixel (dT= Tz1-Tz2); k
        var n_dT_cold = ee.Number(0);
        // Angular coefficient
        var n_coef_a = (n_dT_cold.subtract(n_dT_hot)).divide(CP_Ts.subtract(HP_Ts));
        // Linear coefficient
        var n_coef_b = n_dT_hot.subtract(n_coef_a.multiply(HP_Ts));
        // dT for each pixel; k
        var i_dT_int = ee.Image(0).clip(geom).expression('(n_coef_a*i_lst_med)+n_coef_b', {'n_coef_a':n_coef_a, 'n_coef_b':n_coef_b, 'i_lst_med':Ts_dem }).rename('dT'); 
        // Air temperature (ta) for each pixel; k
        var i_Ta = i_dT_int.expression('i_lst_med-i_dT_int', {'i_lst_med':Ts_dem,'i_dT_int':i_dT_int});   
        // Air density (roh) [km m-3]
        var i_ro = i_Ta.expression('(-0.0046*i_Ta)+2.5538', {'i_Ta':i_Ta}).rename('ro');  
        // Sensible heat flux (h) for each pixel; W/m
        var i_H_int = i_dT_int.expression('(i_ro*Cp*i_dT_int)/i_rah', {'i_ro':i_ro, 'Cp':Cp, 'i_dT_int':i_dT_int, 'i_rah':i_rah }).rename('H');
        // Monin-obukhov length (L) for stability conditions of the atmosphere in the iterative process
        var i_L_int = i_dT_int.expression('-(i_ro*Cp*(i_ufric**3)*i_lst_med)/(0.41*9.81*i_H_int)',{'i_ro':i_ro, 'Cp':Cp, 'i_ufric':i_ufric, 'i_lst_med':Ts_dem, 'i_H_int':i_H_int }).rename('L');
        // Stability corrections for momentum and heat transport >> (PAULSON 1970), (WEBB 1970)    
        var img = ee.Image(0).clip(geom);
        // Stability corrections for stable conditions
        var i_psim_200 = img.expression('-5*(hight/i_L_int)', {'hight':ee.Number(200), 'i_L_int':i_L_int}).rename('psim_200');
        var i_psih_2   = img.expression('-5*(hight/i_L_int)', {'hight':ee.Number(2.0), 'i_L_int':i_L_int}).rename('psih_2');
      var i_psih_01   = img.expression('-5*(hight/i_L_int)', {'hight':ee.Number(0.1), 'i_L_int':i_L_int}).rename('psih_01');
        // For different height
        var i_x200 = i_L_int.expression( '(1-(16*(hight/i_L_int)))**0.25',{'hight' : ee.Number(200),'i_L_int': i_L_int}).rename('i_x200');
        var i_x2   = i_L_int.expression( '(1-(16*(hight/i_L_int)))**0.25',{'hight' : ee.Number(2),'i_L_int': i_L_int}).rename('i_x2');
        var i_x01  = i_L_int.expression( '(1-(16*(hight/i_L_int)))**0.25',{'hight' : ee.Number(0.1),'i_L_int': i_L_int}); 
        // Stability corrections for unstable conditions
        var i_psimu_200 = i_x200.expression('2*log((1+i_x200)/2)+log((1+i_x200**2)/2)-2*atan(i_x200)+0.5*pi', {'i_x200':i_x200, 'pi':Math.PI});
        var i_psihu_2   = i_x2.expression('2*log((1+i_x2**2)/2)', {'i_x2' : i_x2});
        var i_psihu_01  = i_x01.expression('2*log((1+i_x01**2)/2)', {'i_x01' : i_x01});
        // For each pixel
        i_psim_200 = i_psim_200.where(i_L_int.lt(0), i_psimu_200);
        i_psih_2   = i_psih_2.where(i_L_int.lt(0), i_psihu_2);
        i_psih_01  = i_psih_01.where(i_L_int.lt(0), i_psihu_01);
        i_psim_200 = i_psim_200.where(i_L_int.eq(0), 0);
        i_psih_2   = i_psih_2.where(i_L_int.eq(0), 0);
        i_psih_01  = i_psih_01.where(i_L_int.eq(0), 0);
        if (n === 1){
          var i_psim_200_exp = i_psim_200;
          var i_psih_2_exp   = i_psih_2;
          var i_psih_01_exp  = i_psih_01;
          var i_L_int_exp    = i_L_int;
          var i_H_int_exp    = i_H_int;
          var i_dT_int_exp   = i_dT_int;
          var i_rah_exp      = i_rah;      
        }
        // Corrected value for the friction velocity (i_ufric), m/s
        i_ufric = i_ufric.expression('(u200*0.41)/(log(Z3/i_zom)-i_psim_200)',{'u200':i_u200, 'Z3':Z3, 'i_zom':i_zom, 'i_psim_200':i_psim_200});
        // Corrected value for the aerodynamic resistance to the heat transport (rah); m/s
        i_rah = i_rah.expression('(log(Z2/Z1)-psi_h2+psi_h01)/(i_ufric*0.41)', {'Z2':Z2, 'Z1':Z1, 'i_ufric':i_ufric, 'psi_h2':i_psih_2, 'psi_h01':i_psih_01}).rename('rah');
        if (n === 1){
          var n_dT_hot_old = n_dT_hot;
          var n_rah_hot_old = n_rah_hot;
          n_dif = ee.Number(1);      
        }
        if (n > 1){
          var n_dT_hot_abs      = n_dT_hot.abs();
          var n_dT_hot_old_abs  = n_dT_hot_old.abs();
          var n_rah_hot_abs     = n_rah_hot.abs();
          var n_rah_hot_old_abs = n_rah_hot_old.abs();
          n_dif                 = n_dT_hot_abs.subtract(n_dT_hot_old_abs).add(n_rah_hot_abs).subtract(n_rah_hot_old_abs).abs();
          n_dT_hot_old          = n_dT_hot;
          n_rah_hot_old         = n_rah_hot; 
        }
        // Insert each iteration value into a list
        list_dif     = list_dif.add(n_dif);
        list_coef_a  = list_coef_a.add(n_coef_a);
        list_coef_b  = list_coef_b.add(n_coef_b);
        list_dT_hot  = list_dT_hot.add(n_dT_hot);
        list_rah_hot = list_rah_hot.add(n_rah_hot);
      } 
      var i_rah_final = i_rah.rename('rah');
      var i_dT_final  = i_dT_int.rename('dT'); 
      var i_H_final   = i_H_int.expression('(i_ro*Cp*i_dT_int)/i_rah', {'i_ro':i_ro, 'Cp':Cp, 'i_dT_int':i_dT_final, 'i_rah':i_rah_final}).max(0).rename('H');
      // Map.addLayer(ee.Image.cat([i_H_final]), {}, 'A', 0, 1);
      return image.addBands([i_H_final, i_rah_final, i_dT_final, i_rah_first]);
    }
  function fexp_inst_et(image, Rn24){
    var geom = image.geometry().dissolve(0.001);
    //GET ENERGY FLUXES VARIABLES AND LST
    var i_Rn = image.select('Rn'); 
    var i_G = image.select('G');
    var i_lst = image.select('T_LST_DEM');
    var i_H_final = image.select('H');
    //FILTER VALUES
    i_H_final=i_H_final.where(i_H_final.lt(0), 0);
    //var d_Rn_24h_med = Rn24.reduceRegion({reducer:ee.Reducer.mean(), geometry:image.geometry().bounds(), scale:11131.949079327358, maxPixels:10e13});
    //var n_Rn_24h_med = ee.Number(d_Rn_24h_med.get('Rn24'));
    //var Rn24 =Rn24.where(Rn24, n_Rn_24h_med);
    //INSTANTANEOUS LATENT HEAT FLUX (LE) [W M-2]
    //BASTIAANSSEN ET AL. (1998)  
    var i_lambda_ET = i_H_final.expression('(i_Rn-i_G-i_H_fim)', {'i_Rn':i_Rn, 'i_G':i_G, 'i_H_fim':i_H_final}).rename('LE');
    //FILTER
    i_lambda_ET = i_lambda_ET.where(i_lambda_ET.lt(0), 0);
    //LATENT HEAT OF VAPORIZATION (LAMBDA) [J KG-1]
    //BISHT ET AL.(2005)
    //LAGOUARDE AND BURNET (1983)  
    var i_lambda = i_H_final.expression('(2.501-0.002361*(Ts-273.15))', {'Ts':i_lst});
    //INSTANTANEOUS ET (ET_inst) [MM H-1]
    var i_ET_inst = i_H_final.expression('0.0036*(i_lambda_ET/i_lambda)', {'i_lambda_ET':i_lambda_ET,'i_lambda':i_lambda}).rename('ET_inst');
    //EVAPORATIVE FRACTION (EF)
    //CRAGO (1996)  
    var i_FE = i_H_final.expression('i_lambda_ET/(i_Rn-i_G)', {'i_lambda_ET':i_lambda_ET,'i_Rn':i_Rn,'i_G':i_G }).rename('EF');
     //FILTER  
    i_FE = i_FE.where(i_lambda_ET.lt(0), 0);
    //DAILY EVAPOTRANSPIRATION (ET_24h) [MM DAY-1]
    var i_ET24h_calc = i_H_final.expression('(86.4*i_FE*Rn24)/(i_lambda*dens)', {'i_FE':i_FE, 'i_lambda':i_lambda, 'Rn24':Rn24, 'dens':ee.Number(1000)}).rename('ETa24');
    i_ET24h_calc = i_ET24h_calc.where(i_ET24h_calc.lt(0), 0);
    return image.addBands([i_ET_inst, i_ET24h_calc, i_lambda_ET,i_FE, Rn24]);
  }
  function ET_estimation(image){
    var mask = image.select(1).gt(-9999).selfMask().rename('Mask');
    var EleSloAsp = ESAv.updateMask(mask);
    var Ele   = EleSloAsp.select('Elevation');
    var Slo_r = EleSloAsp.select('SlopeInRadians');
    var Asp_r = EleSloAsp.select('AspectInRadians');
    var Loa  = image.addBands(ee.Image.pixelLonLat()).updateMask(mask);
    var Lon  = Loa.select('longitude').rename('Lon');
    var Lat  = Loa.select('latitude').rename('Lat');
    var phi  = exp.expression('Lat*(PI/180)', {'Lat':Lat, 'PI':PI}).rename('phi');
    // Map.addLayer(Ele, {}, 'EleA', 0, 1);
    // Map.addLayer(phi, {}, 'phiA', 0, 1);
    var geom = image.geometry().dissolve(0.001);
    var index =image.get('system:index'); //LANDSAT ID
    var zenith_angle  = ee.Number(image.get("SOLAR_ZENITH_ANGLE"));
    var sun_elevation = ee.Number(image.get("SUN_ELEVATION"));
        zenith_angle  = ee.Number(ee.Algorithms.If(zenith_angle, zenith_angle, ee.Number(90).subtract(sun_elevation)));
        sun_elevation = ee.Number(ee.Algorithms.If(sun_elevation, sun_elevation, ee.Number(90).subtract(zenith_angle)));
    var time_start = image.get('system:time_start'); //TIME START FROM LS
    var date  = ee.Date(time_start); //GET EE.DATE
    var year  = ee.Number(date.get('year')); //YEAR
    var month = ee.Number(date.get('month')); //MONTH
    var day   = ee.Number(date.get('day')); //DAY
    var hour  = ee.Number(date.get('hour')); //HOUR
    var min   = ee.Number(date.get('minutes')); //MINUTES
    var crs = image.projection().crs(); //PROJECTION
    var transform = ee.List(ee.Dictionary(ee.Algorithms.Describe(image.projection())).get('transform'));
    //ENDMEMBERS
    var p_top_NDVI    = ee.Number(5);  // TOP NDVI PERCENTILE (FOR COLD PIXEL)
    var p_coldest_Ts  = ee.Number(20); // COLDEST TS (FOR COLD PIXEL)
    var p_lowest_NDVI = ee.Number(10); // LOWEST NDVI (FOR HOT PIXEL)
    var p_hottest_Ts  = ee.Number(20); // HOTTEST TS (FOR HOT PIXEL)
    var col_ERA5 = era5(image.select('ALFA'), time_start);
    var Ta   = col_ERA5.select('Ta'); 
    var ux   = col_ERA5.select('ux'); 
    var RH   = col_ERA5.select('RH'); 
    var Rn24 = col_ERA5.select('Rn24');
    //SPECTRAL IMAGES (NDVI, EVI, SAVI, LAI, T_LST, e_0, e_NB, long, lat)
    image = spec_ind(image); 
    //LAND SURFACE TEMPERATURE 
    image = LST_correction(image,Ta, RH, sun_elevation, hour, min, Ele, Slo_r, Asp_r, phi, Lon);
    //COLD PIXEL
    var d_cold_pixel = fexp_cold_pixel(image, p_top_NDVI, p_coldest_Ts); 
    //COLD PIXEL NUMBER
    var n_Ts_cold = ee.Number(d_cold_pixel.get('temp'));   
    //INSTANTANEOUS OUTGOING LONG-WAVE RADIATION [W M-2]
    image = fexp_radlong_up(image); 
    //INSTANTANEOUS INCOMING SHORT-WAVE RADIATION [W M-2]
    image = fexp_radshort_down(image, Ele, Ta, RH,sun_elevation); 
    //INSTANTANEOUS INCOMING LONGWAVE RADIATION [W M-2]
    image = fexp_radlong_down(image, n_Ts_cold);  
    //INSTANTANEOUS NET RADIATON BALANCE [W M-2]
    image = fexp_radbalance(image); 
    //SOIL HEAT FLUX (G) [W M-2]
    image = fexp_soil_heat(image); 
    //HOT PIXEL 
    var d_hot_pixel = fexp_hot_pixel(image,  p_lowest_NDVI, p_hottest_Ts); 
    image = fexp_sensible_heat_flux(image, n_Ts_cold, d_hot_pixel, ux, RH); 
    //DAILY EVAPOTRANSPIRATION (ET_24H) [MM DAY-1]
    image = fexp_inst_et(image, Rn24);
    return image;
  }
  image = ee.ImageCollection.fromImages([image])
            .select([0,1,2,3,4,5,6,7,10], ["UB","B","GR","R","NIR","SWIR_1","SWIR_2","BRT","pixel_qa"])
            .map(f_cloudMaskL8_SR)
            .map(f_albedoL8).first();
  return ET_estimation(image);
}
var gSEBAL1 = getgeeSEBAL(image);
// var gSEBAL2 = require('users/Elnashar/Stock:geeSEBAL').gSEBAL(image);
//////////////////////////////////////////////// GUI
function GUI(){
  function buildImagesList(items){
      ImagesList = ui.Select({
        items:items,      
        placeholder:'List of images',
        style:{color:'red', width:'100%', margin:'auto', position:'top-center'},
      }); 
    return ImagesList;
  }
  function buildImageSearch(ImagesList){
    ImageSearch = ui.Panel({
      layout:ui.Panel.Layout.flow('vertical'),
      style:{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid black'},
      widgets:[
        ui.Label({
          value:'Search for images',
          style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'},
        }),
        ui.Panel({
          layout:ui.Panel.Layout.flow("vertical"),
          style:{position: 'top-center'},
          widgets:[
            ui.Label({value:"Select your Landsat image.",
            style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}})        
            ]
        }),
        ui.Panel({
          layout:ui.Panel.Layout.flow("horizontal"),
          style:{position: 'top-center', margin: 'auto', width:'100%'},
          widgets:[
            ui.Panel({
              layout:ui.Panel.Layout.flow("horizontal"),
              style:{position:'top-center', margin:'auto'},
              widgets:[
                ImagesList,
              ]          
            })
            ]
          })
      ]
    });
    return ImageSearch;
  }
  function addDraw(Point){
    drawingTools.clear();
    drawingTools.addLayer([Point], 'Point', 'green');
  }
  var pointClick = null;
  var ImagesList = null;
  var ImageSearch = null;
  var panel = ui.Panel({
    layout:ui.Panel.Layout.flow('vertical'),
    style:{maxWidth:'550px'},
  });
  var map = ui.Map({
    center:{lon:30, lat:29.5, zoom:2},
  });
  map.style().set('cursor', 'crosshair');
  var drawingTools = map.drawingTools();
  drawingTools.getShown();
  drawingTools.setDrawModes([]);
  var Title = ui.Label({
    value:'ETMapper (experimental)', 
    style:{fontSize:'20px', fontWeight:'normal', color:"green", textAlign:'center',  margin:'auto', whiteSpace:'pre'},
  });
  panel.add(Title); 
  var Subtitle = ui.Label({
    value:'EvapoTranspiration (ET) Mapper',
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'},
  });
  panel.add(Subtitle);
  var WritingBy = ui.Label({
    value:'By Abdelrazek Elnashar',
    style:{fontSize:'20px', fontWeight:'normal', color:"blue", textAlign:'center', margin:'auto', whiteSpace:'pre'},
    targetUrl:'https://orcid.org/0000-0001-8008-5670',
  });
  panel.add(WritingBy);
  var InstructionsPanel = ui.Panel({
      layout:ui.Panel.Layout.flow('vertical'),
      style:{position:'top-center', width:'40%', height:'auto',},
      widgets:[
        ui.Label({value:'Instructions', style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'}, }),
        // ui.Label({value:'1 – Select data range to', style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'}}), 
        ]
  });
  var InstructionsButton = ui.Button({
    label:'Instructions',
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'}, 
    onClick: function(){
      map.remove(FAQPanel);
      map.remove(Inspector);
      map.add(InstructionsPanel);
    },
  });
  var CloseInstruction = ui.Button({
    label:'Close',
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'},
    onClick:function(){
      map.remove(InstructionsPanel);
    },
  });
  InstructionsPanel.add(CloseInstruction);
  var FAQPanel = ui.Panel({
      layout:ui.Panel.Layout.flow('vertical'),
      style:{position:'top-center', width:'40%', height:'auto',},
      widgets:[
        ui.Label({value:'Frequently Asked Questions (FAQ)', style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}, }),
        ],
  });  
  var FAQButton = ui.Button({
    label:'FAQ',
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'},
    onClick: function(){
      map.remove(InstructionsPanel);
      map.remove(Inspector);
      map.add(FAQPanel);
    },
  });
  var CloseFAQ = ui.Button({
    label:'Close',
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'}, 
    onClick:function(){
      map.remove(FAQPanel);
    },
  });
  FAQPanel.add(CloseFAQ);
  var PanelButtons = ui.Panel({
    layout:ui.Panel.Layout.flow('horizontal'),
    widgets:[InstructionsButton, FAQButton],
  });
  panel.add(PanelButtons);
  var startDate = ui.Textbox({
    value:"2020-01-01",
    style:{fontSize:'20px', fontWeight:'normal', color:"red", textAlign:'center', margin:'auto'},
  }); 
  var endDate = ui.Textbox({
    value:"2020-12-31",
    style:{fontSize:'20px', fontWeight:'normal', color:"red", textAlign:'center', margin:'auto'},
  }); 
  var DataSearch = ui.Panel({
    layout:ui.Panel.Layout.flow('vertical'),
    style:{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid black'},
    widgets:[
      ui.Label({
        value:'Data search',
        style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'},
      }),
      ui.Panel({
        layout:ui.Panel.Layout.flow("vertical"),
        style:{position: 'top-center'},
        widgets:[
          ui.Label({value:"Change the date range: YYYY-MM-DD.",
          style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'}})        
          ]
      }),
      ui.Panel({
        layout:ui.Panel.Layout.flow("horizontal"),
        style:{position: 'top-center', margin:'auto', width:'100%'},
        widgets:[
          ui.Panel({
            layout:ui.Panel.Layout.flow("horizontal"),
            style:{position:'top-center', margin:'auto'},
            widgets:[
              startDate,
              endDate
            ]          
          })
          ]
        })
    ]
  });
  panel.add(DataSearch);
  var lonText = ui.Textbox({
    value:"Longitude",
    style:{fontSize:'20px', fontWeight:'normal', color:"red", textAlign:'center', margin:'auto'},
  }); 
  var LatText = ui.Textbox({
    value:"Latitude" ,
    style:{fontSize:'20px', fontWeight:'normal', color:"red", textAlign:'center', margin:'auto'},
  }); 
  var LocText = ui.Button({
    label:'Search'    ,
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'},
  }); 
  var LocationSearch = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical'),
    style:{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid black'},
    widgets:[
      ui.Label({
        value:'Location information',
        style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'},     
      }),
      ui.Panel({
        layout:ui.Panel.Layout.flow("vertical"),
        style:{position: 'top-center'},
        widgets:[
          ui.Label({value:"Click on the map to select a location.",
          style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}})        
          ]
      }),
      ui.Panel({
        layout:ui.Panel.Layout.flow("vertical"),
        style:{position:'top-center', margin:'auto'},
        widgets:[
          ui.Panel({
            layout:ui.Panel.Layout.flow("horizontal"), 
            style:{position:'top-center', margin:'auto'},
            widgets:[
              lonText,
              LatText        
              ]
          }),
          LocText,
          ]
      }),    
      ]
  });
  panel.add(LocationSearch);
  var Inspector = ui.Panel([ui.Label('Click on the map to get a location ETa value(s).')]);
  map.onClick(function(coords){
    lonText.setValue(coords.lon);
    LatText.setValue(coords.lat);
    pointClick = ee.Geometry.Point([coords.lon, coords.lat]);
    addDraw(pointClick);
  });
  LocText.onClick(function(){
    var locLon = lonText.getValue();
    var locLat = LatText.getValue();
    if ((locLon !== 'Longitude') & (locLat !== 'Latitude')){
      map.layers().reset();
      map.remove(Inspector);
      panel.remove(ImagesList);
      panel.remove(ImageSearch);
      var Point = ee.Geometry.Point([Number(locLon), Number(locLat)]);
      addDraw(Point);
      map.centerObject(Point, 9);
      var st = ee.Date(startDate.getValue());
      var en = ee.Date(endDate.getValue());
      var satellites = ['LANDSAT_8', 'LANDSAT_7', 'LANDSAT_8'];
      var target     = 'SR';
      var cloudCover = 'N';
      var cloudMask  = 'Y';
      var OTBs  = getLANDSAT(Point, st, en, satellites, target, cloudCover, cloudMask).sort("system:time_start", true);
      OTBs.evaluate(function(col){
        var items = []; 
        col.features.forEach(function(feature){ 
        var label = feature.properties.LANDSAT_ID + "/ "  + feature.properties.Date + "/ Cloud " + feature.properties.CLOUD_COVER + "%";
        items.push(label);
        }); 
        ImagesList = buildImagesList(items);
        ImageSearch = buildImageSearch(ImagesList);
        panel.add(ImageSearch);
        ImagesList.onChange(function(ID){
          map.layers().reset();
          map.remove(Inspector);
          map.add(Inspector);
          var image = OTBs.filter(ee.Filter.eq('LANDSAT_ID', ID.split("/")[0])).first();
          var ETMapper = getETMapper(image);
          var ETa24 = ['ETa24_SEBAL', 'ETa24_SSEBop','ETa24_EnMean'];
          map.addLayer(image.select(optBands), False_viz, 'Image', 0, 1);
          map.addLayer(image.select('NDVI'), NDVI_viz, 'NDVI', 1, 1);
          function getShownValue(){
            map.onClick(function(){
              Inspector.widgets().set(0, ui.Label({value:'Loading value(s)...', style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}}));
              try{
                var sample = ETMapper.select(ETa24).sample(pointClick, 30);
                print(sample);
                sample = sample.first().toDictionary().map(function scale(key, value){
                  var list = [];
                  var trueCase  = ee.String(ee.String(key).split('_').get(1)).cat(ee.String(':')).cat(ee.String(value).slice(0, 4));
                  var falseCase = ee.String(ee.String(key).split('_').get(1)).cat(ee.String(':None'));
                  list.push(ee.String(ee.Algorithms.If(ee.Number(value).gte(0), trueCase, falseCase)));
                  return list;
                });
                var value = ee.String(sample.values().flatten().join('; ')).getInfo();
                Inspector.widgets().set(0, ui.Label({value:value, style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}}));
              }
              catch (err){Inspector.widgets().set(0, ui.Label({value:'Try again, please', style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}}));}
            });
          }
          getShownValue();
        });
      });
    }
    else{
      map.remove(Inspector);
      map.add(Inspector);
      Inspector.widgets().set(0, ui.Label({value:'Click on the map to select a location or fill location information (Longitude and Latitude).', style:{color:'red'}}));
    }
  });
  ui.root.clear();
  ui.root.add(panel);
  ui.root.add(map);
}
////////////////////////////////////////////////
function Try(){
  var AOI        = ee.Geometry.Point([30.8234, 29.385]);
  var st         = ee.Date('2021-11-04');
  var en         = ee.Date('2021-11-05');
  var satellites = ['LANDSAT_8'];
  var target     = 'SR';
  var cloudCover = 'N';
  var cloudMask  = 'Y';
  var image = getLANDSAT(AOI, st, en, satellites, target, cloudCover, cloudMask).sort('CLOUD_COVER', true).first();
  var ETMapper = getETMapper(image);
  var list = [
    ETMapper.select('ETa24_SSEBop').rename('SSEBop'),
    ETMapper.select('ETa24_SEBAL').rename('SEBAL0'),
    gSEBAL1.select('ETa24').rename('gSEBAL1'),
    gSEBAL2.select('ETa24').rename('gSEBAL2'),
    ETMapper.select('ETa24_METRIC').rename('METRIC'),
    ETMapper.select('ETa24_TriAng').rename('TriAng'),
    ETMapper.select('ETa24_EnMean').rename('EnMean'),
    eeETa.rename('ETa24_EEFlux').rename('EEFlux'),
    ];
  var ETs = ee.Image.cat(list);
  Map.addLayer(ETs, {}, 'ETa', 0, 1);
  Map.addLayer(image.select('NDVI'), NDVI_viz, 'NDVI', 1, 1);
  Map.onClick(function(coords){
    var Lon = coords.lon;
    var Lat = coords.lat;
    var sLon = Lon.toString();
    var sLat = Lat.toString();
    var sLonLat = ee.String('Location: ').cat(ee.String(sLon)).cat(ee.String('-')).cat(ee.String(sLat)).getInfo();
    var regions = ee.Geometry.Point([Lon, Lat]);
    var chart = ui.Chart.image.regions({image:ETs, reducer:ee.Reducer.first(), regions:regions, scale:30})
                        .setSeriesNames(['ETa'])
                        .setChartType('ColumnChart')
                        .setOptions({title:sLonLat, hAxis:{title:'Method'}, vAxis:{title:'ETa (mm/day)'},});
    chart.style().set({position:'bottom-right', width:'800px', height:'300px'});
    Map.add(chart);    
  });
}
// GUI();
// Try();