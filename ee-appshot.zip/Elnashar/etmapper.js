//////////////////////////////////////////////// General
// var gSEBAL = require('users/Elnashar/Stock:geeSEBAL').gSEBAL(ee.Image('LANDSAT/LC08/C01/T1_SR/LC08_177040_20211104'));
// General constants
var L = 0.5;     // constant; unitless, for SAVI calculation
var R = 287.1;   // Gas constant; J/kgK
var k = 0.41;    // Von Karman constant; unitless
var g = 9.80665; // Gravitational constant; m/s2
var Z1 = 0.1;     // Heights above zero plane displacement height (d); m
var Z2 = 2.0;     // Heights above zero plane displacement height (d); m
var Z3 = 200.0;   // Blending layer height; m, (typically 100-200 m); zBlend 
var Tv = 1.01;    // Virtual temperature
var Cp = 1004.16; // Specific heat of moist air; J/Kg*K
var C0 = 273.15;  // Zero Celsius; K
var P0 = 101.3;   // Pressure at sea level; KPa
var PI = Math.PI; // The ratio of the circumference of a circle to its diameter; 
var Kt = 1.0;     // Air turbidity coefficient(1.0 clean, 0.5 turbid, dusty/polluted); unitless
var Rp = 0;       // Path radiance (10.4-12.5 micro m); W/m2*sr*micro m
var Ry = 0;       // Narrow band downward thermal radiation for a clear sky; W/m2*sr*micro m
var PTc = 1.26;     // Priestly-Taylor coefficient
var Tlr = 6.5/1000; // Temperature lapse rate; C/m >> (Kongo and Jewitt, 2006); 10/1000
var NBT = 1;        // Narrow band transmissivity of air (10.4-12.5 micro m); unitless
var G24 = 0;        // 24-Hour soil heate flux; W/m2, (Morse et al., 2000; Jiang et al., 2009; Tang et al., 2011)
var Tas = 293.15;   // Standard air temperature; K
var hTOs   = 3600.0;   // Conversion factor between hour to second=3600; s/h; 1*60*60.0
var dTOs   = 86400.0;  // Conversion factor between day to second =86400; s/d; 24*60*60.0
var CpMA   = 0.001013; // Specific heat of moist air; MJ/Kg*C
var MWWr   = 0.622;    // Ratio molecular weight of water vapor/dry air; unitless
var Gsc_W  = 1367.0; // Solar constant; W/m2
var Gsc_MJ = 4.92;   // Solar constant; MJ/m2*h
var rhoH20 = 1000.0; // Density of water; Kg/m3
var alpha  = 0.23;   // Albedo or canopy reflection coefficient >> (ASCE, 2005): Page (44); RET-ET for Windows ver. 4.1: Page (63)
var sigma_MJ = 2.042000E-10; // Stefan-Boltzmann constant; MJ/K*m*h
var sigma_W  = 5.670373e-08; // Stefan-Boltzmann constant; W/m2*K4*day
var NDVI_Full = 0.80;
var NDVI_Bare = 0.15;
var EVI_Full  = 0.70;
var EVI_Bare  = 0.05;
var ETrF_Bare = 0.00;
var BeEf = true;  // bestEffort
var MxPx = 10e13; // maxPixels
var exp  = ee.Image(0).rename('expression');
// Constants for Surface Albedo calculation
var optBands  = ['B','G','R','NIR','SWIR1','SWIR2'];
var Weight457 = ee.Image([0.254, 0.149, 0.147, 0.311, 0.103, 0.036]).float().rename(optBands);
var Weight008 = ee.Image([0.246, 0.146, 0.191, 0.304, 0.105, 0.008]).float().rename(optBands);
var Weight008 = ee.Image([0.115, 0.143, 0.180, 0.281, 0.108, 0.042]).float().rename(optBands); // geeSEBAL
// Climate forcing data
// https://developers.google.com/earth-engine/datasets/catalog/NOAA_CFSV2_FOR6H#bands
// https://developers.google.com/earth-engine/datasets/catalog/ECMWF_ERA5_LAND_HOURLY
var CFSV = ee.ImageCollection('NOAA/CFSV2/FOR6H');       // 6-hours; 22,763.015040269130; 1979-01-01-ongoing >> EEFlux
var ERA5 = ee.ImageCollection('ECMWF/ERA5_LAND/HOURLY'); // 1-hour ; 11,131.949079327358; 1981-01-01-ongoing >> geeSEBAL
// Topographic and geoloactions
var Elevation = ee.Image("USGS/SRTMGL1_003").select(['elevation'],['Elevation']); // 30.922080775909325
var Slope  = ee.Terrain.slope(Elevation).clamp(0, 90).rename('Slope');
var Aspect = ee.Terrain.aspect(Elevation).clamp(0, 360).rename('Aspect');
var pLL = ee.Image.pixelLonLat();
var Longitude = pLL.select('longitude');
var Latitude  = pLL.select('latitude');
// Visualization parameters
var True_viz  = {min:0, max:0.12, bands:['R','G','B']};
var False_viz = {min:0, max:0.50, bands:['SWIR1','NIR','R']};
var ETf_viz  = {min:0.0, max:1.05, palette:['Red','SandyBrown','Yellow','LimeGreen','DarkBlue']};
var ETa_viz  = {min:0.0, max:10.0, palette:['DarkRed','SandyBrown','Yellow','LimeGreen','DarkBlue']};
var NDVI_viz = {min:0.0, max:1.00, palette:['FFFFFF','CE7E45','DF923D','F1B555','FCD163','99B718','74A901','66A000','529400','3E8601','023B01','012E01','011D01','011301']};
//////////////////////////////////////////////// Functions
// Set time function
function setTimes(image){
  var sts    = ee.Date(ee.Number(image.get('system:time_start')));
  var ss     = ee.Number(sts.get('second'));
  var mm     = ee.Number(sts.get('minute'));
  var hh     = ee.Number(sts.get('hour'));
  var DD     = ee.Number(sts.get('day'));
  var MM     = ee.Number(sts.get('month'));
  var YY     = ee.Number(sts.get('year'));
  var Date   = sts.format('yyyy-MM-dd');
  var Millis = ee.Date(Date).millis();
  var SF     = ee.Number(sts.getFraction('second'));
  var DOY    = ee.Number(sts.getRelative('day', 'year').add(1));
  var UTC    = hh.add(mm.divide(60)).add((ss.add(SF)).divide(3600));
  var Dic    = {'ss':ss,'mm':mm,'hh':hh,'DD':DD,'MM':MM, 'YY':YY,'Date':Date,'Millis':Millis,'DOY':DOY,'UTC':UTC};
  return image.setMulti(Dic).copyProperties(image, image.propertyNames());
  }
// Instantaneous and daily claimate variables
function getClimate(sts, forcingData, itsName){
  // https://doi.org/10.1038/s41597-021-01003-9
  var cproj = forcingData.first().projection();
  // Caurse topographic and geoloactions
  var cDEM = ee.Image('NOAA/NGDC/ETOPO1').select(['bedrock'],['Elevation']); // 1,855.3248465545594
  var cEle = cDEM.reduceResolution({reducer:ee.Reducer.mean(), bestEffort:BeEf}).reproject({crs:cproj});
  // Longitude, Latitude; degree
  var cLon = Longitude.reproject({crs:cproj});
  var cLat = Latitude.reproject({crs:cproj});
  function setHourlyERA5(image){
    var prj = image.projection(); 
    var Ta = image.select('temperature_2m').subtract(C0).rename('Ta'); // °C
    var Td = image.select('dewpoint_temperature_2m').subtract(C0).rename('Td'); // °C
    // Saturation Vapor Pressure; kPa >> (ASCE, 2005): Eq. (7); RET-ET for Windows ver. 4.1: Eq. (15) 
    var es = exp.expression('0.6108*(exp((17.27*T)/(T+237.3)))',{'T':Ta}).rename('es');
    // Actual Vapor Pressure; kPa >> (ASCE, 2005): Eq. (8); RET-ET for Windows ver. 4.1: Eq. (17)
    var ea = exp.expression('0.6108*(exp((17.27*T)/(T+237.3)))',{'T':Td}).rename('ea');
    var Rs = image.select('surface_solar_radiation_downwards_hourly').multiply(0.000001).rename('Rs'); // J/m2 to MJ/m2
    var u = image.select('u_component_of_wind_10m');
    var v = image.select('v_component_of_wind_10m');
    var uz = exp.expression('sqrt(pow(u,2)+pow(v,2))',{'u':u,'v':v}).rename('uz'); // m/s
    var zw = ee.Image(10).rename('zw'); // m
    // >> (Singer et al. 2021)
    var P   = image.select('surface_pressure').multiply(0.001).rename('P_');
    var Rns = image.select('surface_net_solar_radiation_hourly').multiply(0.000001).rename('Rns_');
    var Rnl = image.select('surface_net_thermal_radiation_hourly').multiply(0.000001).multiply(-1).rename('Rnl_');
    var Rn  = exp.expression('Rns-Rnl', {'Rns':Rns, 'Rnl':Rnl}).rename('Rn_');
    return ee.Image.cat([Ta, es, ea, Rs, uz, zw, P, Rn]).reproject({crs:prj}).copyProperties(image, image.propertyNames());
  }
  function set6HoursCFSv(image){
    var from = ['Minimum_temperature_height_above_ground_6_Hour_Interval',   // K
                'Maximum_temperature_height_above_ground_6_Hour_Interval',   // K
                'Temperature_height_above_ground',                           // K
                'Downward_Short-Wave_Radiation_Flux_surface_6_Hour_Average', // W/m^2
                'Specific_humidity_height_above_ground',                     // kg/kg
                'u-component_of_wind_height_above_ground',                   // m/s
                'v-component_of_wind_height_above_ground',                   // m/s
                ];                 
    var to = ['TaMin','TaMax','TaMean','Rs','Hs','Wind_U','Wind_V'];
    var imageNew = image.select(from, to);
    var Ux = imageNew.expression('sqrt(u**2 + v**2)',{'u':imageNew.select('Wind_U'),'v':imageNew.select('Wind_V')}).rename('Ux');
    var Zx = ee.Image(10).reproject({crs:image.projection()}).rename('Zx');
    var TaMean = imageNew.select('TaMean').subtract(C0);
    var es = TaMean.add(237.3).pow(-1).multiply(TaMean).multiply(17.27).exp().multiply(0.6108).reproject({crs:image.projection()}).rename('es');
    var Hs = imageNew.select('Hs');
    var ea = Hs.multiply(0.378).add(0.622).pow(-1).multiply(Hs).multiply(Pa).reproject({crs:image.projection()}).rename('ea');
    var Rs = imageNew.select('Rs').multiply(0.0036).reproject({crs:image.projection()}).rename('ea');
    return imageNew.addBands([Ux, Zx, es, ea]).select(ClimateBs);
  }
  function setClimate(image){
    var Ta = image.select('Ta'); // air temperature; °C
    var es = image.select('es'); // saturation Vapor Pressure; kPa
    var ea = image.select('ea'); // actual Vapor Pressure; kPa
    var Rs = image.select('Rs'); // solar radiation; MJ/m2
    var uz = image.select('uz'); // measured wind speed at zw above ground surface; m/s
    var zw = image.select('zw'); // height of wind measurement above ground surface; m
    var Rns_ = image.select('Rns_');
    var Rnl_ = image.select('Rnl_');
    var Rn_  = image.select('Rn_');
    var P_   = image.select('P_');
    // start time
    var ts = ee.Date(ee.Number(image.get('system:time_start'))); 
    // Day Of the Year
    var DOY = ee.Image(ts.getRelative('day', 'year')).add(1).rename('DOY');
    // hour
    var hh = ee.Image(ts.get('hour')).rename('hour');
    // DOY Fraction >> (ASCE, 2005): Page (50)
    var DA = exp.expression('DOY*((2*PI)/365)', {'DOY':DOY, 'PI':PI}).rename('DA');
    // Inverse relative distance factor (squared) for the earth-sun; unitless >> (ASCE, 2005): Eq. (50)
    var dr = exp.expression('(cos(DA)*0.033)+1', {'DA':DA}).rename('dr');
    // Solar declination; unitless >> (ASCE, 2005): Eq. (51)
    var delta = exp.expression('0.409*sin(DA-1.39)', {'DA':DA}).rename('delta');
    // >> (ASCE, 2005): Page (58)
    var b = exp.expression('((2*PI)*(DOY-81))/364', {'PI':PI, 'DOY':DOY}).rename('b');
    // Seasonal correction for solar time >> (ASCE, 2005): Eq. (57)
    var Sc = exp.expression('(0.1645*sin(b*2))-(0.1255*cos(b))-(0.025*sin(b))', {'b':b}).rename('Sc');
    // Solar time (i.e. noon is 0) >> (ASCE, 2005): Eq. (55) ??
    var ST = exp.expression('Lon*(24/(2*PI))+(hh+0.5)+Sc-12', {'Lon':cLon, 'PI':PI, 'hh':hh, 'Sc':Sc}).rename('ST');
    // Solar time angle at the midpoint of the period >> (ASCE, 2005): Eq. (55) ??
    var omega = exp.expression('((2*PI)/24)*ST', {'PI':PI, 'ST':ST});
    var x_min = -PI;
    var x_max = +PI;
    var x_range = x_max - x_min;
    omega = omega.subtract(x_min).mod(x_range).add(x_range).mod(x_range).add(x_min).rename('omega');
    // Longitude, Latitude; radians
    var phi = exp.expression('Lat*(PI/180)', {'Lat':cLat, 'PI':PI}).rename('phi');
    // Sunset hour angle >> (ASCE, 2005): Eq. (59)
    var omegas = exp.expression('acos(-tan(phi)*tan(delta))', {'phi':phi, 'delta':delta}).rename('omegas');
    // length of the calculation period; hour >> (ASCE, 2005): Page (51)
    // // 1 for hourly periods or 0.5 for 30-minute periods.
    var tl = 1;
    // Solar time angle at beginning of period; radians >> (ASCE, 2005): Eq. (53)
    var omega1 = omega.subtract(PI * tl / 24).max(omegas.multiply(-1)).min(omegas);
    // Solar time angle at at end of period; radians >> (ASCE, 2005): Eq. (54)
    var omega2 = omega.add(PI * tl / 24).max(omegas.multiply(-1)).min(omegas).rename('omega2');
    omega1 = omega1.min(omega2).rename('omega1');
    // Extraterrestrial radiation for hourly periods >> (ASCE, 2005): Eq. (48)
    var RaEq = '(12/PI)*Gsc*dr*(((omega2-omega1)*sin(phi)*sin(delta))+(cos(phi)*cos(delta)*(sin(omega2)-sin(omega1))))';
    var Ra = exp.expression(RaEq, {'PI':PI, 'Gsc':Gsc_MJ, 'dr':dr, 'omega1':omega1, 'omega2':omega2, 'phi':phi, 'delta':delta}).rename('Ra');
    // Broad-band atmospheric transmissivity [-], clear-sky one-way transmittance
    var Tau = exp.expression('0.75+(2E-5*z)', {'z':cEle}).rename('Tau');
    // Clear-sky solar radiation
    // // simple >> (ASCE, 2005): Page (47); RET-ET for Windows ver. 4.1: Eq. (35)
    var Rso = exp.expression('Tau*Ra', {'Tau':Tau, 'Ra': Ra}).rename('Rso');
    // Atmospheric Pressure, kPa >> (ASCE, 2005): Eq. (3); RET-ET for Windows ver. 4.1: Eq. (10)
    var P = exp.expression('P0*pow(((Tas-(Tlr*z))/Tas),5.26)', {'P0':P0, 'Tas':Tas, 'Tlr':Tlr, 'z':cEle}).rename('P');
    // Precipitable water in the atmosphere (Eq. D.3)
    var W = exp.expression('(0.14*ea*P)+2.1', {'ea':ea, 'P':P}).rename('W');
    // Sin of sun angle above the horizon (D.6 and Eq. 62)
    var sin_beta = exp.expression('(sin(phi)*sin(delta))+(cos(phi)*cos(delta)*cos(omega))', {'phi':phi, 'delta': delta, 'omega': omega}).rename('sin_beta');
    // Clearness index for direct beam radiation (Eq. D.2)
    var kb = W.divide(sin_beta.max(0.01)).pow(0.4).multiply(-0.075).add(P.multiply(-0.00146).divide(sin_beta.max(0.01).multiply(Kt))).exp().multiply(0.98).rename('kb');
    var kd = kb.multiply(-0.36).add(0.35).min(kb.multiply(0.82).add(0.18)).rename('kd');
    // // full >> (Appendix D)
    Rso = exp.expression('(kb+kd)*Ra', {'kb':kb, 'kd': kd, 'Ra': Ra}).rename('Rso');
    // Relative solar radiation or relative cloudiness (limited to 0.3 ≤ Rs/Rso ≤ 1.0) >> (ASCE, 2005): Page (46)
    var RsRso = exp.expression('Rs/Rso', {'Rs':Rs, 'Rso': Rso}).clamp(0.3, 1).rename('RsRso'); // .clamp(0.3, 1) = .max(0.3).min(1)
    // Sun angle above the horizon; >> (ASCE, 2005): Eq. (62)
    var beta = exp.expression('asin((sin(phi)*sin(delta))+(cos(phi)*cos(delta)*cos(omega)))', {'phi':phi, 'delta':delta,'omega':omega}).rename('beta');
    // Cloudiness fraction >> (ASCE, 2005): Page (45); RET-ET for Windows ver. 4.1: Eq. (28)
    var fcd = exp.expression('(1.35*RsRso)-0.35', {'RsRso':RsRso}).clamp(0.05, 1).rename('fcd');
        fcd = fcd.max(beta.lt(0.3)); // >> (ASCE, 2005): Eq. (46); RET-ET for Windows ver. 4.1: Eq. (29)
    // Net longwave radiation >> (Eq. 44); RET-ET for Windows ver. 4.1: Eq. (27) 
    var Rnl = exp.expression('sigma*fcd*(0.34-(0.14*sqrt(ea)))*pow((Ta+C0),4)', {'sigma':sigma_MJ, 'fcd':fcd, 'ea':ea, 'Ta':Ta, 'C0':C0}).rename('Rnl');
    // Net shortwave radiation >> (ASCE, 2005): Eq. (43); RET-ET for Windows ver. 4.1: Eq. (25) 
    var Rns = exp.expression('(1-alpha)*Rs', {'alpha':alpha, 'Rs':Rs}).rename('Rns');
    // Net radiation >> (ASCE, 2005): Eq. (42); RET-ET for Windows ver. 4.1: Eq. (24)
    var Rn = exp.expression('Rns-Rnl', {'Rns':Rns, 'Rnl':Rnl}).rename('Rn');
    // Slope of the Saturation Vapor Pressure-Temperature Curve; kPa/°C >> (ASCE, 2005): Eq. (5); RET-ET for Windows ver. 4.1: Eq. (14) 2503==>2504
    // var SSPVC = exp.expression('(4099*es)/pow((Ta+237.3),2) ', {'es':es, 'Ta':Ta}).rename('SSPVC');  
    var SSPVC = exp.expression('(2503*exp((17.27*Ta)/(Ta+237.3)))/pow((Ta+237.3),2)', {'Ta':Ta}).rename('delta');
    // Psychrometric Constant; kPa/°C >> (ASCE, 2005): Eq. (4) ; RET-ET for Windows ver. 4.1: Eq. (13)  
    var gamma = exp.expression('0.000665*P', {'P':P}).rename('gamma');
    // Wind speed at 2 m above ground surface >> (ASCE, 2005): Eq. (33); RET-ET for Windows ver. 4.1: Eq. (2-28)
    var u2 = exp.expression('(uz*4.87)/log((zw*67.8)-5.42)', {'uz':uz, 'zw':zw}).rename('u2');
    // Hourly reference ET >> (ASCE, 2005): Eq. (1) 
    function ET(delta, gamma, Rn, Ta, u2, es, ea, cn, cd_day, cd_night, g_rn_day, g_rn_night, name){
      var Eq = '((0.408*delta*(Rn-G))+(gamma*(cn/(T+273))*u2*(es-ea)))/(delta+(gamma*(1+(cd*u2))))';
      var cd = Rn.multiply(0).add(cd_day).where(Rn.lt(0), cd_night);
      var g_rn = Rn.multiply(0).add(g_rn_day).where(Rn.lt(0), g_rn_night);
      // Soil Heat Flux Density >> (ASCE, 2005): Eqs. (65, 66); RET-ET for Windows ver. 4.1: Eqs. (33, 34)
      var G = Rn.multiply(g_rn);
      return exp.expression(Eq,{'cd':cd,'cn':cn,'delta':delta,'G':G,'gamma':gamma,'Rn':Rn,'T':Ta,'u2':u2,'es':es,'ea':ea}).rename(name);
    }
    // Short (grass) reference surface: ETo 
    var ETo = ET(SSPVC, gamma, Rn, Ta, u2, es, ea, ee.Number(37.00), ee.Number(0.24), ee.Number(0.96), ee.Number(0.10), ee.Number(0.50), 'ETo');
    // Tall (alfalfa) reference surface: ETr
    var ETr = ET(SSPVC, gamma, Rn, Ta, u2, es, ea, ee.Number(66.00), ee.Number(0.25), ee.Number(1.70), ee.Number(0.04), ee.Number(0.20), 'ETr');
   return image.addBands([uz, zw, u2, Ra, Rso, Rn, ETo, ETr, Rn]).copyProperties(image, image.propertyNames());
  }
  function setDistance(image){
    var stsImageDate = ee.Date(image.get('system:time_start'));
    var delImageDate = stsImageDate.millis().subtract(sts.millis()).abs(); 
    return image.set('dateDistance', delImageDate);
  }
  var st = sts.format('yyyy-MM-dd');
  var en = sts.advance(1, 'day').format('yyyy-MM-dd');
  var hhClimate = null;
  if (itsName === 'ERA5'){
    hhClimate = forcingData.filter(ee.Filter.date(st, en)).map(setHourlyERA5).map(setClimate);
  }
  if (itsName === 'CFSv'){
    hhClimate = forcingData.filter(ee.Filter.date(st, en)).map(set6HoursCFSv).map(setClimate);
  }
  // Daily (dd) climate data for satellite overpass
  var ddTaMin = hhClimate.select('Ta').min().reproject({crs:cproj}).rename('ddTaMin');
  var ddTaMax = hhClimate.select('Ta').max().reproject({crs:cproj}).rename('ddTaMax');
  var ddTa    = hhClimate.select('Ta').mean().reproject({crs:cproj}).rename('ddTa');
  var ddea    = hhClimate.select('ea').mean().reproject({crs:cproj}).rename('ddea');
  var ddes    = hhClimate.select('es').mean().reproject({crs:cproj}).rename('ddes');
  // MJ/m2/day into W/m2
  var ddRs    = hhClimate.select('Rs').sum().divide(0.0864).reproject({crs:cproj}).rename('ddRs'); 
  var ddRa    = hhClimate.select('Ra').sum().divide(0.0864).reproject({crs:cproj}).rename('ddRa'); 
  var ddRso   = hhClimate.select('Rso').sum().divide(0.0864).reproject({crs:cproj}).rename('ddRso');
  var ddRn    = hhClimate.select('Rn').sum().divide(0.0864).reproject({crs:cproj}).rename('ddRn');
  var ddETo   = hhClimate.select('ETo').sum().reproject({crs:cproj}).rename('ddETo');
  var ddETr   = hhClimate.select('ETr').sum().reproject({crs:cproj}).rename('ddETr');
  var ddClimate = [ddTaMin, ddTaMax, ddTa, ddea, ddes, ddRs, ddRa, ddRso, ddRn, ddETo, ddETr];
  // Instantaneous (ii) climate data at satellite overpass
  hhClimate = hhClimate.map(setDistance).sort('dateDistance', true).toList(hhClimate.size());
  var VT11 = ee.Image(hhClimate.get(0));
  var VT21 = ee.Image(hhClimate.get(1));
  var T11  = ee.Number(ee.Date(VT11.get('system:time_start')).millis());
  var T21  = ee.Number(ee.Date(VT21.get('system:time_start')).millis());
  var LT1  = ee.Number(sts.millis());
  var iiCl = exp.expression('VT1+((VT2-VT1)*(LT-T1))/(T2-T1)', {'VT1':VT11,'VT2':VT21,'LT':LT1,'T1':T11,'T2':T21});
  var iiTa  = iiCl.select('Ta').reproject({crs:cproj}).rename('iiTa');
  var iies  = iiCl.select('es').reproject({crs:cproj}).rename('iies');
  var iiea  = iiCl.select('ea').reproject({crs:cproj}).rename('iiea');
  var iiRs  = iiCl.select('Rs').reproject({crs:cproj}).rename('iiRs');
  var iiuz  = iiCl.select('uz').reproject({crs:cproj}).rename('iiuz');
  var iizw  = iiCl.select('zw').reproject({crs:cproj}).rename('iizw');
  var iiu2  = iiCl.select('u2').reproject({crs:cproj}).rename('iiu2');
  var iiETo = iiCl.select('ETo').reproject({crs:cproj}).rename('iiETo');
  var iiETr = iiCl.select('ETr').reproject({crs:cproj}).rename('iiETr');
  var iiClimate = [iiTa, iiea, iies, iiRs, iiuz, iizw, iiu2, iiETo, iiETr];
  return ee.Image.cat(ddClimate).addBands(iiClimate).resample('bilinear');
}
// Contigous Landsat scenes
function getLANDSAT(AOI, st, en, satellites, target, cloudCover, cloudMask){
  var La_TA = null;
  var La_SR = null;
  function setIndices(image){
    var B     = image.select('B');
    var G     = image.select('G');
    var R     = image.select('R');
    var NIR   = image.select('NIR');
    var SWIR1 = image.select('SWIR1');
    var SWIR2 = image.select('SWIR2');
    var mask  = image.select(1).gt(-9999).selfMask().rename('Mask');
    // Normalized Difference Vegetation Index
    var NDVI = image.normalizedDifference(['NIR', 'R']).clamp(-1, 1).rename('NDVI');
    // Normalized Difference Water Index
    var NDWI =  image.normalizedDifference(['G', 'NIR']).clamp(-1, 1).rename('NDWI');
    // Modified Normalized Difference Water Index
    var MNDWI =  image.normalizedDifference(['G', 'SWIR1']).clamp(-1, 1).rename('MNDWI');
    // Soil Adjusted Vegetation Index
    var SAVI = mask.expression('((1+L)*(NIR-R))/(L+(NIR+R))', {'NIR':NIR,'R':R,'L':L}).clamp(-1, 1).rename('SAVI');
    // Leaf Area Index
    var LAI = mask.where(SAVI.lte(0.10), 0).where(SAVI.gt(0.688), 6)
                  .where(SAVI.gt(0.10).and(SAVI.lte(0.688)), mask.expression('-(log((0.69-SAVI)/0.59)/0.91)', {'SAVI':SAVI})).rename('LAI');
    // Enhanced Vegetation Index
    var EVI = mask.expression('2.5*((NIR-R)/(NIR+(6*R)-(7.5*B)+1))', {'NIR':NIR,'R':R,'B':B}).clamp(-1, 1).rename('EVI');
    // Vegetation cover fraction = f(vegetation Condetion Index) >> (Minacapilli et al., 2016)
    var Fc = mask.expression('pow((EVI-EVI_Bare)/(EVI_Full-EVI_Bare), 0.46)', {'EVI':EVI,'EVI_Bare':EVI_Bare,'EVI_Full':EVI_Full});
    // var Fc = mask.expression('1-pow(((NDVI-NDVI_Full)/(NDVI_Bare-NDVI_Full)),0.46)', {'NDVI':NDVI,'NDVI_Bare':NDVI_Bare,'NDVI_Full':NDVI_Full});
    // var Fc = mask.expression('1-pow(((NDVI_Full-NDVI)/(NDVI_Full-NDVI_Bare)),0.70)', {'NDVI':NDVI,'NDVI_Bare':NDVI_Bare,'NDVI_Full':NDVI_Full});
    // var Fc = mask.expression('pow((NDVI-NDVI_Bare)/(NDVI_Full-NDVI_Bare), 2)', {'NDVI':NDVI,'NDVI_Bare':NDVI_Bare,'NDVI_Full':NDVI_Full});
        Fc = Fc.selfMask().unmask(0).clamp(0, 1).rename('Fc'); 
    // Surface Emissivity
    var SE = mask.expression('1.009+0.047*log(NDVI)', {'NDVI':NDVI});
        SE = SE.where(NDVI.lt(0.16), 0.920).clamp(0, 1).clamp(0, 1).rename('SE');
    var BBSE = LAI.multiply(0.0100).add(0.950); // Broad-band SE; unitless >> (Owe, 1992; Jiang and Islam, 2001)
        BBSE = BBSE.where(MNDWI.gt(0), 0.985).where(LAI.lte(3), BBSE).where(LAI.gt(3), 0.980).clamp(0, 1).rename('BBSE');
    var NBSE = LAI.multiply(0.0033).add(0.970); // Narrow-band SE; unitless >> (Bastiaanssen, 1995; Tasumi, 2003; Morse, 2000)
        NBSE = NBSE.where(MNDWI.gt(0), 0.990).where(LAI.lte(3), NBSE).where(LAI.gt(3), 0.980).clamp(0, 1).rename('NBSE');
    return image.addBands([mask, NDVI, NDWI, MNDWI, SAVI, LAI, EVI, Fc, SE, BBSE, NBSE]);
  }
  function removeEdges(image){
    var mask = image.mask().reduce(ee.Reducer.min());
    return image.updateMask(mask);
  }
  function rescaleSR(image){
    var opticalBands = image.select(['B','G','R','NIR','SWIR1','SWIR2']).multiply(0.0001);
    var thermalBands = image.select(['Tb']).multiply(0.1);
    return image.addBands(opticalBands, null, true).addBands(thermalBands, null, true);
  }
  function cloudMaskTA(image){
    var qa = image.select('QA');
    var mask = qa.bitwiseAnd(1 << 4).eq(0);
    return image.updateMask(mask);
  }
  function cloudMaskSR(image){
    var qa = image.select('QA');
    var mask = qa.bitwiseAnd(1 << 3).eq(0).and(qa.bitwiseAnd(1 << 5).eq(0));
    return image.updateMask(mask);
  }
  function setTIRKK45(image){
    var mask = image.select(1).gt(-9999).selfMask().rename('Mask');
    var imageRad = ee.Algorithms.Landsat.calibratedRadiance(image);
    var TIR = imageRad.select('B6').rename('TIR');
    var K1  = ee.Image(ee.Number(image.get('K1_CONSTANT_BAND_6'))).float().updateMask(mask).rename('K1');
    var K2  = ee.Image(ee.Number(image.get('K2_CONSTANT_BAND_6'))).float().updateMask(mask).rename('K2');
    return TIR.addBands([K1, K2]).copyProperties(image, image.propertyNames());
  }
  function setTIRKK07(image){
    var mask = image.select(1).gt(-9999).selfMask().rename('Mask');
    var imageRad = ee.Algorithms.Landsat.calibratedRadiance(image);
    var TIR = imageRad.select('B6_VCID_1').rename('TIR');
    var K1  = ee.Image(ee.Number(image.get('K1_CONSTANT_BAND_6_VCID_2'))).float().updateMask(mask).rename('K1');
    var K2  = ee.Image(ee.Number(image.get('K2_CONSTANT_BAND_6_VCID_2'))).float().updateMask(mask).rename('K2');
    return TIR.addBands([K1, K2]).copyProperties(image, image.propertyNames());
  }
  function setTIRKK08(image){
    var mask = image.select(1).gt(-9999).selfMask().rename('Mask');
    var imageRad = ee.Algorithms.Landsat.calibratedRadiance(image);
    var TIR = imageRad.select('B10').rename('TIR');
    var K1  = ee.Image(ee.Number(image.get('K1_CONSTANT_BAND_10'))).float().updateMask(mask).rename('K1');
    var K2  = ee.Image(ee.Number(image.get('K2_CONSTANT_BAND_10'))).float().updateMask(mask).rename('K2');
    return TIR.addBands([K1, K2]).copyProperties(image, image.propertyNames());
  }
  function setAs457(image){
    var As = image.select(optBands).multiply(Weight457).reduce(ee.Reducer.sum()).rename('As');
    return image.addBands(As);  
  }
  function setAs008(image){
    var As = image.select(optBands).multiply(Weight008).reduce(ee.Reducer.sum()).rename('As');
    return image.addBands(As);  
  }
  var L4Bs4TA = ['BQA','B1','B2','B3','B4','B5','B7','B6'];
  var L7Bs4TA = ['BQA','B1','B2','B3','B4','B5','B7','B6_VCID_1'];
  var L8Bs4TA = ['BQA','B2','B3','B4','B5','B6','B7','B10'];
  var L4Bs4SR = ['pixel_qa','B1','B2','B3','B4','B5','B7','B6'];
  var L8Bs4SR = ['pixel_qa','B2','B3','B4','B5','B6','B7','B10'];
  var LaBs2TA = ['QA','B','G','R','NIR','SWIR1','SWIR2','Tb'];
  var L5Bs4TA = L4Bs4TA;
  var L5Bs4SR = L4Bs4SR;
  var L7Bs4SR = L4Bs4SR;
  var LaBs2SR = LaBs2TA;
  var L4_DN = ee.ImageCollection('LANDSAT/LT04/C01/T1').filter(ee.Filter.date(st, en)).filterBounds(AOI);
  var L5_DN = ee.ImageCollection('LANDSAT/LT05/C01/T1').filter(ee.Filter.date(st, en)).filterBounds(AOI);
  var L7_DN = ee.ImageCollection('LANDSAT/LE07/C01/T1').filter(ee.Filter.date(st, en)).filterBounds(AOI);
  var L8_DN = ee.ImageCollection('LANDSAT/LC08/C01/T1').filter(ee.Filter.date(st, en)).filterBounds(AOI);
  var L4_CR = L4_DN.map(setTIRKK45);
  var L5_CR = L5_DN.map(setTIRKK45);
  var L7_CR = L7_DN.map(setTIRKK07);
  var L8_CR = L8_DN.map(setTIRKK08);
  var L4_TA = ee.ImageCollection('LANDSAT/LT05/C01/T1_TOA').filter(ee.Filter.date(st, en)).filterBounds(AOI).select(L4Bs4TA, LaBs2TA);
  var L5_TA = ee.ImageCollection('LANDSAT/LT05/C01/T1_TOA').filter(ee.Filter.date(st, en)).filterBounds(AOI).select(L5Bs4TA, LaBs2TA);
  var L7_TA = ee.ImageCollection('LANDSAT/LE07/C01/T1_TOA').filter(ee.Filter.date(st, en)).filterBounds(AOI).select(L7Bs4TA, LaBs2TA);
  var L8_TA = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA').filter(ee.Filter.date(st, en)).filterBounds(AOI).select(L8Bs4TA, LaBs2TA);
  var L4_SR = ee.ImageCollection('LANDSAT/LT04/C01/T1_SR').filter(ee.Filter.date(st, en)).filterBounds(AOI).select(L4Bs4SR, LaBs2SR).map(rescaleSR);
  var L5_SR = ee.ImageCollection('LANDSAT/LT05/C01/T1_SR').filter(ee.Filter.date(st, en)).filterBounds(AOI).select(L5Bs4SR, LaBs2SR).map(rescaleSR);
  var L7_SR = ee.ImageCollection('LANDSAT/LE07/C01/T1_SR').filter(ee.Filter.date(st, en)).filterBounds(AOI).select(L7Bs4SR, LaBs2SR).map(rescaleSR);
  var L8_SR = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR').filter(ee.Filter.date(st, en)).filterBounds(AOI).select(L8Bs4SR, LaBs2SR).map(rescaleSR);
  L4_TA = L4_TA.combine(L4_CR, true).map(removeEdges).map(setAs457);
  L5_TA = L5_TA.combine(L5_CR, true).map(removeEdges).map(setAs457);
  L7_TA = L7_TA.combine(L7_CR, true).map(removeEdges).map(setAs457);
  L8_TA = L8_TA.combine(L8_CR, true).map(removeEdges).map(setAs008);
  L4_SR = L4_SR.combine(L4_CR, true).map(removeEdges).map(setAs457);
  L5_SR = L5_SR.combine(L5_CR, true).map(removeEdges).map(setAs457);
  L7_SR = L7_SR.combine(L7_CR, true).map(removeEdges).map(setAs457);
  L8_SR = L8_SR.combine(L8_CR, true).map(removeEdges).map(setAs008);
  La_TA = L4_TA.merge(L5_TA).merge(L7_TA).merge(L8_TA).sort('system:time_start', true).map(setTimes);
  La_SR = L4_SR.merge(L5_SR).merge(L7_SR).merge(L8_SR).sort('system:time_start', true).map(setTimes);
  La_TA = La_TA.filter(ee.Filter.inList("SPACECRAFT_ID", satellites));
  La_SR = La_SR.filter(ee.Filter.inList("SATELLITE", satellites));
  if ((cloudCover.toUpperCase() === 'Y') & (cloudCover > 0)){
    La_TA = La_TA.filter(ee.Filter.lt("CLOUD_COVER", cloudCover));
    La_SR = La_SR.filter(ee.Filter.lt("CLOUD_COVER", cloudCover));
  }
  if (cloudMask.toUpperCase() === 'Y'){
    La_TA = La_TA.map(cloudMaskTA);
    La_SR = La_SR.map(cloudMaskSR);
  }  
  if(target.toUpperCase() === 'SR'){
    return La_SR.map(setIndices);
  }
  else{
    return La_TA.map(setIndices);
  }
}
// EvapoTranspiration (ET) Mapper
function getETMapper(image){
  // Image variables 
  var ss  = ee.Number(image.get('ss'));
  var mm  = ee.Number(image.get('mm'));
  var hh  = ee.Number(image.get('hh'));
  var YY  = ee.Number(image.get('YY'));
  var MM  = ee.Number(image.get('MM'));
  var DD  = ee.Number(image.get('DD'));
  var DOY = ee.Number(image.get('DOY'));
  var sts = ee.Date(image.get('system:time_start'));
  var SZA = ee.Number(image.get("SOLAR_ZENITH_ANGLE"));
  var SEA = ee.Number(image.get('SUN_ELEVATION'));
      SZA = ee.Number(ee.Algorithms.If(SZA, SZA, ee.Number(90).subtract(SEA)));
  var mask = image.select('Mask');
  var NDVI = image.select('NDVI');
  var NDWI = image.select('NDWI');
  var SAVI = image.select('SAVI');
  var BBSE = image.select('BBSE');
  var NBSE = image.select('NBSE');
  var LAI  = image.select('LAI');
  var TIR  = image.select('TIR');
  var ES = image.select('ES');
  var Tb = image.select('Tb');
  var K1 = image.select('K1');
  var K2 = image.select('K2');
  var As = image.select('As');
  var Fc = image.select('Fc');
  var geom = image.geometry().dissolve(0.001);
  var proj = mask.projection();
  var cent = geom.centroid();
  exp      = exp.updateMask(mask);
  // 24-Hour surface albedo; unitless
  var As241 = exp.expression('(1.10*As)+0.00', {'As':As}).rename('As24'); // (Menenti et al., 1989)
  var As242 = exp.expression('(1.02*As)+0.01', {'As':As}).rename('As24'); // (Teixeira et al.,2009)
  var As24  = ee.ImageCollection.fromImages([As241, As242]).mean().reproject({crs:proj}).rename('As24');
  var Ele = Elevation.clip(geom).reproject({crs:proj}).rename('Ele');
  var Slo = Slope.clip(geom).reproject({crs:proj}).rename('Slo');
  var Asp = Aspect.clip(geom).reproject({crs:proj}).rename('Asp');
  var Lon = Longitude.clip(geom).reproject({crs:proj}).rename('Lon');
  var Lat = Latitude.clip(geom).reproject({crs:proj}).rename('Lat');
  // Climate variables
  var climate = getClimate(sts, ERA5, 'ERA5');
  var iiTa = climate.select('iiTa');
  var iiRs = climate.select('iiRs');
  var iies = climate.select('iies');
  var iiea = climate.select('iiea');
  var iiRH = climate.select('iiRH');
  var iiuz = climate.select('iiuz');
  var iizw = climate.select('iizw');
  var iiu2 = climate.select('iiu2');
  var iiETo = climate.select('iiETo');
  var iiETr = climate.select('iiETr');
  var ddTaMin = climate.select('ddTaMin');
  var ddTaMax = climate.select('ddTaMax');
  var ddTa    = climate.select('ddTa');
  var ddea    = climate.select('ddea');
  var ddes    = climate.select('ddes');
  var ddRs    = climate.select('ddRs');
  var ddRa    = climate.select('ddRa');
  var ddRso   = climate.select('ddRso');
  var ddRn    = climate.select('ddRn'); 
  var ddETo   = climate.select('ddETo');
  var ddETr   = climate.select('ddETr');
  // Functions
  function PV(image, P, scale){
    return ee.Number(image.rename('b').sample(P, scale).first().get('b'));
  }
  function getSIA24h(delta, phi, omegas){
    var first4SIA = ee.List([]);
    function iters4SIA(n, first){
      var omega = ee.Image(ee.Number(-PI).add(ee.Number(n).multiply(0.5).multiply(PI / 12))).rename('omega');
      var iiSIA = exp.expression("(sin(delta)*sin(phi))+((cos(delta)*cos(phi))*cos(omega))", {'delta':delta, 'phi':phi, 'omega':omega});
          iiSIA = iiSIA.where(iiSIA.lt(0).or(omega.lte(omegas.multiply(-1))).or(omega.gt(omegas)), 0);
      return ee.List(first).add(iiSIA.rename('b'));
    }
    var SIA24 = ee.List(ee.List.sequence(1, 48).iterate(iters4SIA, first4SIA));
        SIA24 = ee.ImageCollection.fromImages(SIA24).sum().rename('SIA24');
    return SIA24;
  }
  function getOmega(DOY, hh, mm, ss, Lon){
    var b = exp.expression('((2*PI)*(DOY-81))/364', {'PI':PI, 'DOY':DOY}).rename('b');
    var Sc = exp.expression('(0.1645*sin(b*2))-(0.1255*cos(b))-(0.025*sin(b))', {'b':b}).rename('Sc');
    // Local standard time; second
    var t = exp.expression('(hh*60*60)+(mm*60)+ss', {'hh':hh, 'mm':mm, 'ss':ss}).rename('t');
    // Solar time; minutes >> (Tasumi et al., 2000)
    var ST = exp.expression('(((t+Lon/15*60*60)/60)+(Sc*60))/60', {'t':t, 'Lon':Lon, 'Sc':Sc}).rename('ST');
    // Equation time; minutes
    // var Et = exp.expression('0.000075+(0.001868*cos(DA))-(0.032077*sin(DA))-(0.014615*cos(2*DA))-(0.04089*sin(2*DA))', {'DA':DA}).rename('Et');
    // Local standard time; minutes
    // var t = exp.expression('hh+(mm/60)+(ss/(60*60))', {'hh':hh, 'mm':mm, 'ss':ss}).rename('t');
    // var ST = exp.expression('t+(4*(Lon/60))+(Et/60)', {'t':t, 'Lon':Lon, 'Et':Et}).rename('ST');
    var omega = exp.expression('(PI/12)*(ST-12)', {'PI':PI, 'ST':ST}).rename('omega'); // PI/12 = 15*(PI/180)
    return omega;
 }
  function getSIA24(delta, phi, Slope, Aspect, omegas, eqSIA){
    var first4SIA = ee.List([]);
    function iters4SIA(n, first){
      var omega = ee.Image(ee.Number(-PI).add(ee.Number(n).multiply(0.5).multiply(PI / 12))).rename('omega');
      var iiSIA = exp.expression(eqSIA, {'delta':delta, 'phi':phi, 'Slope':Slope, 'Aspect':Aspect, 'omega':omega});
          iiSIA = iiSIA.where(iiSIA.lt(0).or(omega.lte(omegas.multiply(-1))).or(omega.gt(omegas)), 0);
      return ee.List(first).add(iiSIA.rename('b'));
    }
    var SIA24 = ee.List(ee.List.sequence(1, 48).iterate(iters4SIA, first4SIA));
        SIA24 = ee.ImageCollection.fromImages(SIA24).sum().rename('SIA24');
    return SIA24;
  }
  function getColdPixel(image, highestNDVI, coldestTs){
    var topNDVI = ee.Number(image.select('negNDVI').reduceRegion({reducer: ee.Reducer.percentile([highestNDVI]), geometry:geom, scale:30, bestEffort:BeEf, maxPixels:MxPx}).get('negNDVI'));
    image = image.updateMask(image.select('negNDVI').lte(topNDVI));
    var lowLST = ee.Number(image.select('terLST').reduceRegion({reducer:ee.Reducer.percentile([coldestTs]), geometry:geom, scale:30, bestEffort:BeEf, maxPixels:MxPx}).get('terLST'));
    image = image.updateMask(image.select('terLST').lte(lowLST));
    image = image.updateMask(image.select('terLST').gte(200)); 
    var median = ee.Number(image.select('terLST').reduceRegion({reducer:ee.Reducer.median(), geometry:geom, scale:30, bestEffort:BeEf, maxPixels:MxPx}).get('terLST'));
    var dif = exp.expression('abs(Ts - median)', {'Ts':image.select('terLST'), 'median': median,}).rename('dif'); 
    image = image.addBands(dif);
    var coldPixel = image.select('dif', 'Lon', 'Lat').reduceRegion({reducer:ee.Reducer.min(3), geometry:geom, scale:30, bestEffort:BeEf, maxPixels:MxPx});
    return ee.Geometry.Point(ee.Number(coldPixel.get('min1')), ee.Number(coldPixel.get('min2')));
  }
  function getHotPixel(image, lowestNDVI, hottestTs){
    var lowNDVI = ee.Number(image.select('posNDVI').reduceRegion({reducer:ee.Reducer.percentile([lowestNDVI]), geometry:geom, scale:30, bestEffort:BeEf, maxPixels:MxPx}).get('posNDVI'));
    image = image.updateMask(image.select('posNDVI').lte(lowNDVI));
    var topLST = ee.Number(image.select('negLST').reduceRegion({reducer:ee.Reducer.percentile([hottestTs]), geometry:geom, scale:30, bestEffort:BeEf, maxPixels:MxPx}).get('negLST'));
    image = image.updateMask(image.select('negLST').lte(topLST));
    var median = ee.Number(image.select('terLST').reduceRegion({reducer:ee.Reducer.median(), geometry:geom, scale:30, bestEffort:BeEf, maxPixels:MxPx}).get('terLST'));
    var dif = exp.expression('abs(Ts - median)', {'Ts':image.select('terLST'), 'median':median}).rename('dif'); 
    image = image.addBands(dif);
    var hotPixel = image.select('dif', 'Lon', 'Lat').reduceRegion({reducer:ee.Reducer.min(3), geometry:geom, scale:30, bestEffort:BeEf, maxPixels:MxPx});
    return ee.Geometry.Point(ee.Number(hotPixel.get('min1')), ee.Number(hotPixel.get('min2')));
  }
  // Datum reference elevation
  var Z = ee.Number(Ele.rename('b').reduceRegion({reducer:ee.Reducer.mean(), geometry:geom, scale:30, bestEffort:BeEf, maxPixels:MxPx}).get('b'));
  // Slope, Aspect, Latitude;; radians
  var Slo_r = exp.expression('Slope*(PI/180)', {'Slope':Slo, 'PI':PI}).rename('SlopeInRadians');
  var Asp_r = exp.expression('(Aspect*(PI/180))-PI', {'Aspect':Asp, 'PI':PI}).rename('AspectInRadians');
  var phi   = exp.expression('Lat*(PI/180)', {'Lat':Lat, 'PI':PI}).rename('phi');
  var DA = exp.expression('DOY*((2*PI)/365)', {'DOY':DOY, 'PI':PI}).rename('DA');
  var dr = exp.expression('(cos(DA)*0.033)+1', {'DA':DA}).rename('dr');
  var delta = exp.expression('0.409*sin(DA-1.39)', {'DA':DA}).rename('delta');
  // var delta  = exp.expression('sin(((DOY-81)*(360/365))*(PI/180))*asin(sin(23.45*(PI/180)))', {'DOY':DOY, 'PI':PI});
  // var delta = exp.expression('((23.5*PI)/180)*cos((((2*PI)*(DOY-173)/365)))', {'PI':PI, 'DOY':DOY}).rename('delta');
  // var delta = exp.expression('0.006918-(0.399912*cos(DA))+(0.070257*sin(DA))-(0.006758*cos(2*DA))+(0.000907*sin(2*DA))-(0.002697*cos(3*DA))+(0.00148*sin(3*DA))', {'DA':DA}).rename('delta');
   // Sunset hour angle >> (ASCE, 2005): Eq. (59)
  var omegas = exp.expression('acos(-tan(phi)*tan(delta))', {'phi':phi, 'delta':delta}).rename('omegas');
  // Hour angle
  var omega = getOmega(DOY, hh, mm, ss, Lon);
  var eqSIA = "((sin(delta)*sin(phi)*cos(Slope))-\
                (sin(delta)*cos(phi)*sin(Slope)*cos(Aspect))+\
                (cos(delta)*cos(phi)*cos(Slope)*cos(omega))+\
                (cos(delta)*sin(phi)*sin(Slope)*cos(Aspect)*cos(omega))+\
                (cos(delta)*sin(Slope)*sin(Aspect)*sin(omega))) / cos(Slope)";
  // Solar incidence angle; radians, (Waters, et al., 2002; Morse et al., 2000; Allen, at al., 2007)
  var SIA  = exp.expression(eqSIA, {'delta':delta, 'phi':phi, 'Slope':Slo_r, 'Aspect':Asp_r, 'omega':omega}).max(0.1).rename('SIA');                        // cosθrel
  var SIAh = exp.expression('(sin(delta)*sin(phi))+((cos(delta)*cos(phi))*cos(omega))', {'delta':delta, 'phi':phi, 'omega':omega}).max(0.1).rename('SIAh'); // cosθhor
  // 24-Hour solar incidence angle; radians, (Waters, et al., 2002; Morse et al., 2000; Allen, at al., 2007)
  var SIA24h = getSIA24h(delta, phi, omegas);
  var SIA24  = getSIA24(delta, phi, Slo_r, Asp_r, omegas, eqSIA);
  // Surface temperature; Kelvin
  var Ry = exp.expression('1.807E-09*(pow(Ta,4))*(1-(0.26*exp(-7.77*0.001*pow((C0-Ta),2))))', {'Ta':iiTa, 'C0':C0});
  var Rc = exp.expression('((L-Rp)/NBT)-(1-NBSE)*Rsky', {'L':TIR, 'Rp':Rp, 'NBT':NBT, 'NBSE':NBSE, 'Rsky':Ry});
  var Ts1 = exp.expression('K2/(log((NBSE*K1/Rc)+1))', {'K1':K1, 'K2':K2, 'NBSE':NBSE, 'Rc':Rc}).rename('Ts');
  var Ts2 = exp.expression('Tb/(1+((1.122e-05*Tb/1.438e-02)*log(NBSE)))',{'Tb':Tb,'NBSE':NBSE}).rename('Ts');
  var Ts  = ee.ImageCollection.fromImages([Ts1, Ts2]).mean().clamp(230, 360).reproject({crs:proj}).rename('Ts');
      Ts  = Ts2; // geeSEBAL
  // Surface temperature correction factor to elevation relative to datum
  var TsEZ = exp.expression('Tlr*Ele', {'Tlr':Tlr, 'Ele':Ele}).rename('TsEZ');
  // Corrected Surface temperature to elevation, (Morse et al., 2000) (Waters et al., 2000; Eq: (12-7))
  var Ts_dem = exp.expression('Ts+TsEZ', {'Ts':Ts, 'TsEZ':TsEZ}).rename('Ts_dem');
  // Surface temperature correction factor to slope and aspect
  var P = exp.expression('P0*pow(((Tas-(Tlr*z))/Tas),5.26)', {'P0':P0, 'Tas':Tas, 'Tlr':Tlr, 'z':Ele}).rename('P');
  var W = exp.expression('(0.14*ea*P)+2.1', {'ea':iiea, 'P':P}).rename('W');
  var rho  = exp.expression('(1000*P)/(1.01*Ts*287)',{'P':P, 'Ts':Ts}).rename('rho');
  var Tau  = exp.expression('0.35+0.627*exp(((-0.00146*P)/(Kt*SIA))-(0.075*(W/SIA)**0.4))', {'P':P, 'Kt':Kt, 'SIA':SIA, 'W':W}).rename('Tau');
  var TsSA = exp.expression('((Gsc*dr*Tau*SIA)-(Gsc*dr*Tau*cos(SZA*(PI/180))))/(rho*Cp*0.050)',{'Gsc':Gsc_W, 'dr':dr, 'Tau':Tau, 'SZA':SZA, 'SIA':SIA, 'PI':PI, 'rho':rho, 'Cp':Cp}).rename('TsSA');
  // Corrected Surface temperature to slope and aspect; geeSEBAL
  Ts_dem = exp.expression('Ts+TsSA', {'Ts':Ts, 'TsSA':TsSA}).clamp(C0, 350).rename('Ts_dem');
  // Latent heat of vaporization; J/kg, (Harrison, 1963; Allen et al.,2007)
  var lamda   = exp.expression('(2.501-(0.002361*(Ts-C0)))*1000000', {'Ts':Ts, 'C0':C0}).rename('lamda');
  var lamda24 = exp.expression('(2.501-(0.002361*(T)))*1000000', {'T':ddTa}).rename('lamda24');
  //////////////////////////////////////////////////
  // Calibration using Inverse Modeling of Extreme Conditions (CIMEC)
  // // Surface Energy Balance Algorithm for Land (SEBAL)
  // // Mapping EvapoTranspiration at High Resolution with Internalized Calibration (METRIC)
  var posNDVI = NDVI.updateMask(NDVI.gt(0)).rename('posNDVI');  
  var negNDVI = posNDVI.multiply(-1).rename('negNDVI');
  var terLST  = Ts.updateMask(NDWI.lte(0)).updateMask(SIA.gt(0.6)).rename('terLST');
  var negLST  = Ts.multiply(-1).updateMask(SIA.gt(0.6)).rename('negLST');
  var CP = getColdPixel(ee.Image.cat([negNDVI, terLST, Lon, Lat]), 5, 20);
  var HP = getHotPixel(ee.Image.cat([posNDVI, terLST, negLST, Lon, Lat]), 10, 20);
  // Map.addLayer(ee.FeatureCollection(HP).style({color:'red'}),   {}, 'Hot pixel',  1, 1);
  // Map.addLayer(ee.FeatureCollection(CP).style({color:'green'}), {}, 'Cold pixel', 1, 1);
  //////////////////////////////////////////////////
  // Incoming shortwave radiation at TOA; W/m2, extra-terrestrial or exo-atmospheric
  // (Bastiaanssen, 1995; Waters et al., 2002; ASCE-EWRI, 2005; Tasumi et al., 2005; Allen et al., 2007; Shilpakar et al., 2011)
  var Ra = exp.expression('Gsc*dr*SIA', {'Gsc':Gsc_W, 'dr':dr, 'SIA':SIA}).rename('Ra');
  // Incoming shortwave radiation; W/m2, clear-sky solar radiation, global solar radiation, (ASCE, 2005)
  var Rs = exp.expression('Ra*Tau', {'Tau':Tau, 'Ra': Ra}).rename('Rs');
  // Net shortwave (solar) radiation; W/m2
  var Rns = exp.expression('(1-As)*Rs', {'As':As, 'Rs': Rs}).rename('Rns');
  // Atmospheric emissivity; unitless, (Bastiaanssen, 1995; Allen et al., 2000) >> (Mekonnen, 2005, Zahira et al., 2009, Paul, 2013)
  var Ea1 = exp.expression('0.85*pow(-log(Tau),0.090)', {'Tau':Tau}).rename('Ea');
  var Ea2 = exp.expression('1.08*pow(-log(Tau),0.265)', {'Tau':Tau}).rename('Ea');
  var Ea  = ee.ImageCollection.fromImages([Ea1, Ea2]).mean().reproject({crs:proj}).rename('Ea');
      Ea  = Ea1;// geeSEBAL
  //  Stefan-Boltzman's law / Energy emitted; W/m2
  var Tc = PV(Ts, CP, 30);
  var SBL4ILR = exp.expression('sigma*pow(Ts,4)', {'sigma':sigma_W, 'Ts':Tc}).rename('SBL');
  var SBL4OLR = exp.expression('sigma*pow(Ts,4)', {'sigma':sigma_W, 'Ts':Ts}).rename('SBL');
  // Incoming longwave radiation from the atmosphere; W/m2
  var ILR = exp.expression('Ea*SBL', {'Ea':Ea, 'SBL':SBL4ILR}).rename('ILR');
  // Outgoing longwave radiation lost from the earth; W/m2 >> (Tasumi et al. 2003); (Allen et al. 2007)
  var OLR = exp.expression('BBSE*SBL', {'BBSE':BBSE, 'SBL':SBL4OLR}).rename('OLR');
  // Net longwave radiation; W/m2
  var Rnl = exp.expression('ILR-OLR-((1-BBSE)*ILR)', {'ILR':ILR, 'OLR':OLR, 'BBSE':BBSE}).rename('Rnl');
  // Net radiation; W/m2
  var Rn = exp.expression('Rns+Rnl', {'Rns':Rns, 'Rnl': Rnl}).max(0).rename('Rn');
  //////////////////////////////////////////////////
  // Soil heat flux, W/m2 >> (van den Hurk et al., 1997; Morse, et al., 2000; Allen, 2011; Mutiga et al., 2015)
  var GRn1 = exp.expression('((Ts-C0)/As)*((0.0032*As24+(0.0062*pow(As24,2))))*(1-(0.978*pow(NDVI,4)))', {'Ts':Ts, 'C0': C0, 'As': As, 'As24': As24, 'NDVI': NDVI}).rename('GRn'); // (Bastiaanssen, 1995)
  var GRn2 = exp.expression('(Ts-C0)*(0.0038+(0.0074*As))*(1-(0.98*pow(NDVI,4)))', {'Ts':Ts, 'C0': C0, 'As': As, 'NDVI': NDVI}).rename('GRn'); // (Bastiaanssen, 2000)
  var GRn3 = exp.where(LAI.lt(0.5), exp.expression('((1.80*(Ts-C0))/Rn)+0.084', {'Ts':Ts, 'C0': C0, 'Rn':Rn}))
                .where(LAI.gte(0.5), exp.expression('0.05+(0.18*exp(-0.521*LAI))', {'LAI':LAI})).rename('GRn'); // (Tasumi, 2003)
  var GRn  = ee.ImageCollection.fromImages([GRn1, GRn2, GRn3]).mean().reproject({crs:proj}).rename('GRn');
  var G    = NDVI.where(NDVI.lt(0), Rn.multiply(0.5)).where(NDVI.gte(0), Rn.multiply(GRn2)).rename('G'); // geeSEBAL
  //////////////////////////////////////////////////
  // Sensible heat flux; W/m2
  function getH(hMax){
    var CP_Ts = PV(Ts, CP, 30); 
    var HP_Ts = PV(Ts, HP, 30);
    var HP_G  = PV(G,  HP, 30);
    var HP_Rn = PV(Rn, HP, 30);
    var h     = ee.Image(3).rename('h');
    var Z0mWS = h.multiply(0.12).rename('Z0mWS');
    var Z0m   = exp.expression('exp((5.62*(SAVI))-5.809)', {'SAVI':SAVI}).max(0.0005).rename('Z0m');
    var uStarWS = exp.expression('(k*ux)/log(Z2/Z0m)', {'k':k, 'ux':iiuz, 'Z2':Z2, 'Z0m':Z0mWS}).rename('uStarWS'); 
    var uBlend  = exp.expression('uStar*(log(Z3/Z0m)/k)', {'uStar':uStarWS, 'Z3':Z3, 'Z0m':Z0mWS, 'k':k}).rename('uBlend');
    var uStar   = exp.expression('(k*uBlend)/(log(Z3/Z0m))', {'uBlend':uBlend,'Z3':Z3, 'Z0m':Z0mWS, 'k':k}).rename('uStar');
    var rah     = exp.expression('(log(Z2/Z1))/(uStar*0.41)', {'Z2':Z2,'Z1':Z1, 'uStar':uStar}).rename('rah'); 
    var HP_rho  = ee.Number(-0.0046).multiply(HP_Ts).add(ee.Number(2.5538));
    var HP_H    = HP_Rn.subtract(HP_G);
    for (var n=1; n<hMax; n++){
      var CP_dT  = ee.Number(0);
      var HP_rah = PV(rah, HP, 30);
      var HP_dT  = HP_H.multiply(HP_rah).divide(HP_rho.multiply(Cp));
      var a = CP_dT.subtract(HP_dT).divide(CP_Ts.subtract(HP_Ts));
      var b = HP_dT.subtract(a.multiply(HP_Ts));
      var dT  = exp.expression('(a*Ts)+b', {'a':a, 'b':b, 'Ts':Ts_dem}).rename('dT'); 
      var Ta  = exp.expression('Ts-dT', {'Ts':Ts_dem, 'dT':dT}).rename('Ta');   
      var rho = exp.expression('(-0.0046*Ta)+2.5538', {'Ta':Ta}).rename('ro');  
      var H = exp.expression('(rho*Cp*dT)/rah', {'rho':rho, 'Cp':Cp, 'dT':dT, 'rah':rah}).rename('H');
      var L = exp.expression('-(rho*Cp*(uStar**3)*Ts)/(0.41*9.81*H)',{'rho':rho, 'Cp':Cp, 'uStar':uStar, 'Ts':Ts_dem, 'H':H}).rename('L');
      // Stability corrections for stable conditions
      var psi_Z1 = exp.expression('-5*(h/L)', {'h':Z1, 'L':L}).rename('psi_Z1');
      var psi_Z2 = exp.expression('-5*(h/L)', {'h':Z2, 'L':L}).rename('psi_Z2');
      var psi_Z3 = exp.expression('-5*(h/L)', {'h':Z3, 'L':L}).rename('psi_Z3');
      // For different height
      var xX1 = exp.expression('(1-(16*(h/L)))**0.25',{'h':Z1, 'L':L}).rename('xX1'); 
      var xX2 = exp.expression('(1-(16*(h/L)))**0.25',{'h':Z2, 'L':L}).rename('xX2');
      var xX3 = exp.expression('(1-(16*(h/L)))**0.25',{'h':Z3, 'L':L}).rename('xX3');
      // Stability corrections for unstable conditions
      var psi_Z1U = exp.expression('2*log((1+xX1**2)/2)', {'xX1':xX1}).rename('psi_Z1U');
      var psi_Z2U = exp.expression('2*log((1+xX2**2)/2)', {'xX2':xX2}).rename('psi_Z2U');
      var psi_Z3U = exp.expression('2*log((1+xX3)/2)+log((1+xX3**2)/2)-2*atan(xX3)+0.5*PI', {'xX3':xX3, 'PI':PI}).rename('psi_Z3U');
      // For each pixel
      psi_Z1 = psi_Z1.where(L.lt(0), psi_Z1U);
      psi_Z2 = psi_Z2.where(L.lt(0), psi_Z2U);
      psi_Z3 = psi_Z3.where(L.lt(0), psi_Z3U);
      psi_Z1 = psi_Z1.where(L.eq(0), 0);
      psi_Z2 = psi_Z2.where(L.eq(0), 0);
      psi_Z3 = psi_Z3.where(L.eq(0), 0);
      uStar = exp.expression('(uBlend*0.41)/(log(Z3/Z0m)-psi_Z3)', {'uBlend':uBlend, 'Z3':Z3, 'Z0m':Z0m, 'psi_Z3':psi_Z3}).rename('uStar');
      rah   = exp.expression('(log(Z2/Z1)-psi_Z2+psi_Z1)/(uStar*0.41)', {'Z2':Z2, 'Z1':Z1, 'uStar':uStar, 'psi_Z2':psi_Z2, 'psi_Z1':psi_Z1}).rename('rah');
    } 
    return exp.expression('(rho*Cp*dT)/rah', {'rho':rho, 'Cp':Cp, 'dT':dT, 'rah':rah}).max(0).rename('H');
  }  
  var H = getH(16); //geeSEBAL
  //////////////////////////////////////////////////
  // Adjusted soil heat flux, (Allen et al., 2008) >> (Brutsaert, 1982; Stull, 1988; Allen, et al., 2011)
  // var HP_Ts = PV(Ts, HP, 30);
  // var Gadj = exp.expression('G-(5*(Ts-HP_Ts))', {'G':G, 'Ts':Ts, 'HP_Ts':HP_Ts}).rename('Gadj');
  // G = G.where(Ts.gt(HP_Ts), Gadj);
  // Gadj = H.multiply(0.40).max(Rn.multiply(0.15)).rename('Gadj');
  // G = G.where(LAI.lt(0.5), Gadj);
  //////////////////////////////////////////////////
  // 24-Hour atmospheric transmissivity; unitless
  var Tau24 = exp.expression('Rs/Ra', {'Rs':ddRs, 'Ra':ddRa}).rename('Tau24');
  // 24-Hour net shortwave (solar) radiation; W/m2
  var Rns24 = exp.expression('(1-As)*Rs', {'As':As, 'Rs':ddRs}).rename('Rns24'); // As24
  // 24-Hour net longwave radiation; W/m2
  var Rnl241 = exp.expression('Cs*Tau', {'Cs':110, 'Tau':Tau24}).rename('Rnl24');
  var Rnl242 = exp.expression('sigma*(1.35*Tau/0.8-0.35)*(0.34-(0.14*sqrt(ea)))*pow(Ta+C0,4)', {'sigma':sigma_W, 'Tau':Tau24, 'ea':ddea, 'Ta':ddTa, 'C0':C0}).rename('Rnl24');
  var Rnl24  = ee.ImageCollection.fromImages([Rnl241, Rnl242]).mean().reproject({crs:proj}).rename('Rnl24');
      Rnl24  = Rnl241; // geeSEBAL
  // 24-Hour net radiation; W/m2
  var Rn24 = exp.expression('Rns-Rnl', {'Rns':Rns24, 'Rnl':Rnl24}).max(0).rename('Rn24');
  //////////////////////////////////////////////////
  // Map.addLayer(ee.Image.cat([Rn, G, H, Rn24]), {}, 'ETMapper', 0, 1);
  // Map.addLayer(ee.Image.cat([gSEBAL.select('Rn'), gSEBAL.select('G'), gSEBAL.select('H'), gSEBAL.select('Rn24')]), {}, 'geeSEBAL', 0, 1);
  //////////////////////////////////////////////////
  // Available eneregy / potential evaporationtraspiration; W/m2, (Bastiaanssen et al., 1996)
  var AE = exp.expression('Rn-G', {'Rn':Rn, 'G':G}).rename('AE');
  // Latent heat flux; W/m2, (Bastiaanssen, 2000; Farah and Bastiaanssen, 2001; Mohamed et al., 2006)
  var LE = exp.expression('AE-H', {'AE':AE, 'H':H}).max(0).rename('LE');
  // Potential latent heat flux; W/m2, (Crago and Brutsaert, 1992; Brutsaert and Chen, 1995)
  var LEp = AE.rename('LEp');
  // Potential EvapoTranspiration; mm, (Van Oevelen et al., 1993; Bastiaanssen et al., 1996; Bastiaanssen et al., 2013)
  var ETp = exp.expression('(LEp/lamda)*hTOs', {'LEp':LEp, 'lamda':lamda, 'hTOs':hTOs}).rename('ETp');
   // 24-Hour available eneregy / potential evaporationtraspiration; W/m2, (Bastiaanssen et al., 1996)
  var AE24 = exp.expression('Rn-G', {'Rn':Rn24, 'G':G24}).rename('AE24');
   // 24-Hour potential latent heat flux [W/m2], (Crago and Brutsaert, 1992; Brutsaert and Chen, 1995)
  var LEp24 = AE24.rename('LEp24');
  // 24-Hour potential EvapoTranspiration; mm, (Van Oevelen et al., 1993; Bastiaanssen et al., 1996; Bastiaanssen et al., 2013)
  var ETp24 = exp.expression('(LEp/lamda)*dTOs', {'LEp':LEp24, 'lamda':lamda24, 'dTOs':dTOs}).rename('ETp24');
  //////////////////////////////////////////////////
  // Vegetation correction factor for instantaneous evaporative/EvapoTranspiration fraction, unitless >> (Senay et al. 2011)
  var Cveg = exp.expression('0.35*(NDVI/0.70)+0.65', {'NDVI':NDVI.where(NDVI.lt(0), 0)}).rename('Cveg');
  //////////////////////////////////////////////////
  // Evaporative fraction, Relative evaporation, Actual/Potential evaporation [-], (Bastiaanssen et al., 1996; Bastiaanssen, 2000; Farah and Bastiaanssen, 2001; Farah et al., 2004; Mohamed et al., 2006)
  var EF_SEBAL = exp.expression('(LE/AE)', {'LE':LE, 'AE':AE}).rename('EF_SEBAL');
  // 24-Hour evaporative fraction; unitless; C=1.00:(Bastiaanssen et al., 2005); 1.10:(Anderson et al., 1997); 1.18:(Teixeira, 2008; Teixeira et al., 2008,2009)
  var EF24_SEBAL = exp.expression('EF*C', {'EF':EF_SEBAL, 'C':1.00}).rename('EF24_SEBAL'); 
  // 24-Hour atual EvapoTranspiration; mm: 
  var ETa24_SEBAL = exp.expression('EF*ETp', {'EF':EF24_SEBAL, 'ETp':ETp24}).max(0).rename('ETa24_SEBAL');
  //////////////////////////////////////////////////
  // Operational Simplified Surface Energy Balance (SSEBop)
  // // (Senay et al., 2007; Senay, 2018; Senay et al. 2011; Senay et al. 2013; ; Singh et al., 2014; Chen et al., 2016; Senay et al. 2022)
  var NDVI_per = ee.Number(NDVI.rename('b').reduceRegion({reducer:ee.Reducer.percentile([99]), geometry:geom, scale:30, bestEffort:BeEf}).get('b'));
  var NDVI_max = ee.Number(NDVI.rename('b').reduceRegion({reducer:ee.Reducer.max(), geometry:geom, scale:30, bestEffort:BeEf}).get('b'));
  var NDVI_thr = ee.Number(ee.Algorithms.If(NDVI_max.lt(NDVI_Full), NDVI_per, NDVI_Full));
  var NDVI_lim = NDVI.gte(NDVI_thr).updateMask(NDVI.gte(NDVI_thr));
  var Ts_cor = Ts_dem;
  var Ts_limits_min = Ts_cor.gte(270).updateMask(Ts_cor.gte(270));
  var Ts_limits_max = Ts_cor.lt(330).updateMask(Ts_cor.lt(330));
  var Ts_limits     = Ts_limits_min.multiply(Ts_limits_max);
  var Tdiff_ini     = ddTaMax.add(C0).subtract(Ts_cor);
  var Tdiff_limits  = Tdiff_ini.gte(0).bitwiseAnd(Tdiff_ini.lte(30)).updateMask((Tdiff_ini.gte(0)).bitwiseAnd(Tdiff_ini.lte(30)));
  var vege_pixels   = NDVI_lim.multiply(Ts_limits).multiply(Tdiff_limits);
  var Ta_forest = ddTaMax.add(C0).mask(vege_pixels).rename('Ta_forest');
  var Ts_forest = Ts_cor.mask(vege_pixels).rename('Ts_forest');
  var Tcorr     = Ts_forest.divide(Ta_forest).rename('Tcorr');
  var c_factor  = ee.Number(Tcorr.rename('b').reduceRegion({reducer:ee.Reducer.mean(), geometry:geom, scale:30, bestEffort:BeEf}).get('b'));
  var rah = ee.Image(110).rename('rah');
  var rho_= exp.expression('3.486*(P/(1.01*(Ta+C0)))', {'P':P, 'Ta':ddTa, 'C0':C0}).rename('rho');
  var dT_ = Rn24.multiply(rah).divide(rho_.multiply(Cp)).rename('dT-SSEBop');
  var T_cold = ddTaMax.add(C0).multiply(c_factor).rename('T_cold');
  var T_hot  = T_cold.add(dT_).rename('T_hot');
  // EvapoTranspiration fraction; unitless; Kc
  var ETf_SSEBop = exp.expression('((T_hot-Ts_dem)/(T_hot-T_cold))*Cveg', {'T_hot':T_hot, 'Ts_dem':Ts_dem, 'T_cold':T_cold, 'Cveg':Cveg}).clamp(0, 1.05).rename('ETf_SSEBop');
  // 24-Hour atual EvapoTranspiration; mm: 
  var ETa24_SSEBop = exp.expression('ETf*ETr', {'ETf':ETf_SSEBop, 'ETr':ddETr}).max(0).rename('ETa24_SSEBop');
  //////////////////////////////////////////////////
  var productsETa24 = [ETa24_SEBAL, ETa24_SSEBop];
  var imagesETa24 = []; 
  for (var ETa24ID in productsETa24){imagesETa24.push(productsETa24[ETa24ID].rename('b')); } 
  var ETa24_EnMean = ee.ImageCollection.fromImages(imagesETa24).mean().reproject({crs:proj}).rename('ETa24_EnMean');
  productsETa24.push(ETa24_EnMean);
  return ee.Image.cat(productsETa24).addBands([EF_SEBAL, ETf_SSEBop]);
}
//////////////////////////////////////////////// GUI
function GUI(){
  function buildImagesList(items){
      ImagesList = ui.Select({
        items:items,      
        placeholder:'List of images',
        style:{color:'red', width:'100%', margin:'auto', position:'top-center'},
      }); 
    return ImagesList;
  }
  function buildImageSearch(ImagesList){
    ImageSearch = ui.Panel({
      layout:ui.Panel.Layout.flow('vertical'),
      style:{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid black'},
      widgets:[
        ui.Label({
          value:'Search for images',
          style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'},
        }),
        ui.Panel({
          layout:ui.Panel.Layout.flow("vertical"),
          style:{position: 'top-center'},
          widgets:[
            ui.Label({value:"Select your Landsat image.",
            style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}})        
            ]
        }),
        ui.Panel({
          layout:ui.Panel.Layout.flow("horizontal"),
          style:{position: 'top-center', margin: 'auto', width:'100%'},
          widgets:[
            ui.Panel({
              layout:ui.Panel.Layout.flow("horizontal"),
              style:{position:'top-center', margin:'auto'},
              widgets:[
                ImagesList,
              ]          
            })
            ]
          })
      ]
    });
    return ImageSearch;
  }
  function addDraw(Point){
    drawingTools.clear();
    drawingTools.addLayer([Point], 'Point', 'green');
  }
  var pointClick = null;
  var ImagesList = null;
  var ImageSearch = null;
  var panel = ui.Panel({
    layout:ui.Panel.Layout.flow('vertical'),
    style:{maxWidth:'550px'},
  });
  var map = ui.Map({
    center:{lon:30, lat:29.5, zoom:2},
  });
  map.style().set('cursor', 'crosshair');
  var drawingTools = map.drawingTools();
  drawingTools.getShown();
  drawingTools.setDrawModes([]);
  var Title = ui.Label({
    value:'ETMapper (experimental)', 
    style:{fontSize:'20px', fontWeight:'normal', color:"green", textAlign:'center',  margin:'auto', whiteSpace:'pre'},
  });
  panel.add(Title); 
  var Subtitle = ui.Label({
    value:'EvapoTranspiration (ET) Mapper',
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'},
  });
  panel.add(Subtitle);
  var WritingBy = ui.Label({
    value:'By Abdelrazek Elnashar',
    style:{fontSize:'20px', fontWeight:'normal', color:"blue", textAlign:'center', margin:'auto', whiteSpace:'pre'},
    targetUrl:'https://orcid.org/0000-0001-8008-5670',
  });
  panel.add(WritingBy);
  var InstructionsPanel = ui.Panel({
      layout:ui.Panel.Layout.flow('vertical'),
      style:{position:'top-center', width:'40%', height:'auto',},
      widgets:[
        ui.Label({value:'Instructions', style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'}, }),
        // ui.Label({value:'1 – Select data range to', style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'}}), 
        ]
  });
  var InstructionsButton = ui.Button({
    label:'Instructions',
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'}, 
    onClick: function(){
      map.remove(FAQPanel);
      map.remove(Inspector);
      map.add(InstructionsPanel);
    },
  });
  var CloseInstruction = ui.Button({
    label:'Close',
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'},
    onClick:function(){
      map.remove(InstructionsPanel);
    },
  });
  InstructionsPanel.add(CloseInstruction);
  var FAQPanel = ui.Panel({
      layout:ui.Panel.Layout.flow('vertical'),
      style:{position:'top-center', width:'40%', height:'auto',},
      widgets:[
        ui.Label({value:'Frequently Asked Questions (FAQ)', style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}, }),
        ],
  });  
  var FAQButton = ui.Button({
    label:'FAQ',
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'},
    onClick: function(){
      map.remove(InstructionsPanel);
      map.remove(Inspector);
      map.add(FAQPanel);
    },
  });
  var CloseFAQ = ui.Button({
    label:'Close',
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'}, 
    onClick:function(){
      map.remove(FAQPanel);
    },
  });
  FAQPanel.add(CloseFAQ);
  var PanelButtons = ui.Panel({
    layout:ui.Panel.Layout.flow('horizontal'),
    widgets:[InstructionsButton, FAQButton],
  });
  panel.add(PanelButtons);
  var startDate = ui.Textbox({
    value:"2020-01-01",
    style:{fontSize:'20px', fontWeight:'normal', color:"red", textAlign:'center', margin:'auto'},
  }); 
  var endDate = ui.Textbox({
    value:"2020-12-31",
    style:{fontSize:'20px', fontWeight:'normal', color:"red", textAlign:'center', margin:'auto'},
  }); 
  var DataSearch = ui.Panel({
    layout:ui.Panel.Layout.flow('vertical'),
    style:{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid black'},
    widgets:[
      ui.Label({
        value:'Data search',
        style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'},
      }),
      ui.Panel({
        layout:ui.Panel.Layout.flow("vertical"),
        style:{position: 'top-center'},
        widgets:[
          ui.Label({value:"Change the date range: YYYY-MM-DD.",
          style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'}})        
          ]
      }),
      ui.Panel({
        layout:ui.Panel.Layout.flow("horizontal"),
        style:{position: 'top-center', margin: 'auto', width:'100%'},
        widgets:[
          ui.Panel({
            layout:ui.Panel.Layout.flow("horizontal"),
            style:{position:'top-center', margin:'auto'},
            widgets:[
              startDate,
              endDate
            ]          
          })
          ]
        })
    ]
  });
  panel.add(DataSearch);
  var lonText = ui.Textbox({
    value:"Longitude",
    style:{fontSize:'20px', fontWeight:'normal', color:"red", textAlign:'center', margin:'auto'},
  }); 
  var LatText = ui.Textbox({
    value:"Latitude" ,
    style:{fontSize:'20px', fontWeight:'normal', color:"red", textAlign:'center', margin:'auto'},
  }); 
  var LocText = ui.Button({
    label:'Search'    ,
    style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto'},
  }); 
  var LocationSearch = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical'),
    style:{backgroundColor:"#367bf0", margin:'2px 5px', border:'0.5px solid black'},
    widgets:[
      ui.Label({
        value:'Location information',
        style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'},     
      }),
      ui.Panel({
        layout:ui.Panel.Layout.flow("vertical"),
        style:{position: 'top-center'},
        widgets:[
          ui.Label({value:"Click on the map to select a location.",
          style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}})        
          ]
      }),
      ui.Panel({
        layout:ui.Panel.Layout.flow("vertical"),
        style:{position:'top-center', margin:'auto'},
        widgets:[
          ui.Panel({
            layout:ui.Panel.Layout.flow("horizontal"), 
            style:{position:'top-center', margin:'auto'},
            widgets:[
              lonText,
              LatText        
              ]
          }),
          LocText,
          ]
      }),    
      ]
  });
  panel.add(LocationSearch);
  var Inspector = ui.Panel([ui.Label('Click on the map to get a location ETa value(s).')]);
  map.onClick(function(coords){
    lonText.setValue(coords.lon);
    LatText.setValue(coords.lat);
    pointClick = ee.Geometry.Point([coords.lon, coords.lat]);
    addDraw(pointClick);
  });
  LocText.onClick(function(){
    var locLon = lonText.getValue();
    var locLat = LatText.getValue();
    if ((locLon !== 'Longitude') & (locLat !== 'Latitude')){
      map.layers().reset();
      map.remove(Inspector);
      panel.remove(ImagesList);
      panel.remove(ImageSearch);
      var Point = ee.Geometry.Point([Number(locLon), Number(locLat)]);
      addDraw(Point);
      map.centerObject(Point, 9);
      var st = ee.Date(startDate.getValue());
      var en = ee.Date(endDate.getValue());
      var satellites = ['LANDSAT_8', 'LANDSAT_7', 'LANDSAT_8'];
      var target     = 'SR';
      var cloudCover = 'N';
      var cloudMask  = 'Y';
      var OTBs  = getLANDSAT(Point, st, en, satellites, target, cloudCover, cloudMask).sort("system:time_start", true);
      OTBs.evaluate(function(col){
        var items = []; 
        col.features.forEach(function(feature){ 
        var label = feature.properties.LANDSAT_ID + "/ "  + feature.properties.Date + "/ Cloud " + feature.properties.CLOUD_COVER + "%";
        items.push(label);
        }); 
        ImagesList = buildImagesList(items);
        ImageSearch = buildImageSearch(ImagesList);
        panel.add(ImageSearch);
        ImagesList.onChange(function(ID){
          map.layers().reset();
          map.remove(Inspector);
          map.add(Inspector);
          var image = OTBs.filter(ee.Filter.eq('LANDSAT_ID', ID.split("/")[0])).first();
          var ETMapper = getETMapper(image);
          var ETa24 = ['ETa24_SEBAL', 'ETa24_SSEBop','ETa24_EnMean'];
          map.addLayer(image.select(optBands), False_viz, 'Image', 0, 1);
          map.addLayer(image.select('NDVI'), NDVI_viz, 'NDVI', 1, 1);
          function getShownValue(){
            map.onClick(function(){
              Inspector.widgets().set(0, ui.Label({value:'Loading value(s)...', style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}}));
              try{
                var sample = ETMapper.select(ETa24).sample(pointClick, 30);
                print(sample);
                sample = sample.first().toDictionary().map(function scale(key, value){
                  var list = [];
                  var trueCase  = ee.String(ee.String(key).split('_').get(1)).cat(ee.String(':')).cat(ee.String(value).slice(0, 4));
                  var falseCase = ee.String(ee.String(key).split('_').get(1)).cat(ee.String(':None'));
                  list.push(ee.String(ee.Algorithms.If(ee.Number(value).gte(0), trueCase, falseCase)));
                  return list;
                });
                var value = ee.String(sample.values().flatten().join('; ')).getInfo();
                Inspector.widgets().set(0, ui.Label({value:value, style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}}));
              }
              catch (err){Inspector.widgets().set(0, ui.Label({value:'Try again, please', style:{fontSize:'20px', fontWeight:'normal', color:"black", textAlign:'center', margin:'auto', whiteSpace:'pre'}}));}
            });
          }
          getShownValue();
        });
      });
    }
    else{
      map.remove(Inspector);
      map.add(Inspector);
      Inspector.widgets().set(0, ui.Label({value:'Click on the map to select a location or fill location information (Longitude and Latitude).', style:{color:'red'}}));
    }
  });
  ui.root.clear();
  ui.root.add(panel);
  ui.root.add(map);
}
////////////////////////////////////////////////
function Try(){
  var AOI        = ee.Geometry.Point([30.8234, 29.385]);
  var st         = ee.Date('2021-11-04');
  var en         = ee.Date('2021-11-05');
  var satellites = ['LANDSAT_8'];
  var target     = 'SR';
  var cloudCover = 'N';
  var cloudMask  = 'Y';
  var image = getLANDSAT(AOI, st, en, satellites, target, cloudCover, cloudMask).sort('CLOUD_COVER', true).first();
  // print(image);
  var ETMapper = getETMapper(image);
  // var gSSEBo = require('users/Elnashar/Stock:geeSSEBop').gSSEBo(AOI).filter(ee.Filter.date(st, en)).first();
  // print(gSSEBo.reduceRegion({reducer:ee.Reducer.first(), geometry:AOI, scale:30, bestEffort:true}).get('2021-11-04'));
  // print(gSEBAL.select('ETa24').rename('b').reduceRegion({reducer:ee.Reducer.first(), geometry:AOI, scale:30, bestEffort:true}).get('b'));
  // print(ETMapper.select('ETa24_SEBAL').rename('b').reduceRegion({reducer:ee.Reducer.first(), geometry:AOI, scale:30, bestEffort:true}).get('b'));
  // print(ETMapper.select('ETa24_SSEBop').rename('b').reduceRegion({reducer:ee.Reducer.first(), geometry:AOI, scale:30, bestEffort:true}).get('b'));
  Map.addLayer(image.select('NDVI'), NDVI_viz, 'NDVI', 1, 1);
  Map.addLayer(ETMapper.select(['EF_SEBAL','ETa24_SEBAL','ETf_SSEBop','ETa24_SSEBop']), {}, 'ETMapper', 0, 1);
  Map.addLayer(gSEBAL.select(['EF', 'ETa24']), {}, 'gSEBAL', 0, 1);
}
GUI();
// Try();