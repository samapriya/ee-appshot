/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var geometry_bound = 
    /* color: #bf04c2 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[83.05596617812648, 28.887033591488652],
          [83.05596617812648, 27.92552975102524],
          [84.14361266250148, 27.92552975102524],
          [84.14361266250148, 28.887033591488652]]], null, false);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
ui.root.clear();
var aoi;
var year=2018;
var exp_eos;
var geom;
var panel = ui.Panel({style: {width: '20%'}});
var map = ui.Map();
ui.root.add(panel).add(map);
panel.add(ui.Label('Provide the Study Area dataset name '));
var aoi_box=ui.Textbox({
    value: 'e.g. users/ashok_dahal/mechi',
    style: {width: '80%'},
    onChange: function(text) { aoi_box.setValue(text);return(text);
    }
  });
   panel.add(aoi_box);
panel.add(ui.Label('Provide the year that you want to compute Crop Calendar'));
var year_box=ui.Textbox({
    value: 'e.g. 2015',
    style: {width: '80%'},
    onChange: function(text) { year_box.setValue(text);return(text);
    }
  });
  panel.add(year_box);
  //print(year_box);
var button = ui.Button({
  label: 'Compute Crop Calendar',
  onClick: exp_eos=function runall(aoi,year){
    year=year_box.getValue();
    aoi=aoi_box.getValue();
    var year_prev= year-1;
    print(year_prev,aoi);
function maskS2clouds(image) {
  //var meta=image
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
 //print(image.metadata('system:time_start'));
  return image.updateMask(mask).divide(10000);
}
var s2 = ee.ImageCollection("COPERNICUS/S2"),
    bound = ee.FeatureCollection(aoi),
    point=ee.Geometry.Point([83.58,28.8]); 
var filteredIC_Sseason1 = s2.filterBounds(point)
    .filterDate(year_prev+'-10-01', year+'-02-01');//.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10));
    //.sort('CLOUD_COVER')
var filteredIC_Eseason1 = s2.filterBounds(point)
    .filterDate(year+'-02-02', year+'-05-30');//.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10));
    //Define Season 4
//var filteredIC_Sseason4 = s2.filterBounds(bound)
 //   .filterDate('2017-10-01', '2018-02-28');
    //.sort('CLOUD_COVER')
//var filteredIC_Eseason4 = s2.filterBounds(bound)
  //  .filterDate('2017-10-01', '2018-02-28');
    //.sort('CLOUD_COVER')
function get_smooth(filteredIC){
var addDataBands = function(image) {
  var image_no_cloud=maskS2clouds(image);
  var ndvi = image_no_cloud.normalizedDifference(['B8', 'B4']).rename('NDVI');
 // var ndvi = image.normalizedDifference(['B8', 'B4']).rename('NDVI');
  return image.addBands(ndvi)
              .addBands(image.metadata('system:time_start').divide(1e18).rename('time'))
              .addBands(ee.Image.constant(ee.Number.parse(image.date().format("YYYYMMdd"))).rename('times').float());
};
// Function to smooth time series
// stacks windows of linear regression results
// requires that a variable 'data' exists with NDVI and time bands
function smoother(t){
  // helper function to apply linear regression equation
  function applyFit(img){
      return img.select('time').multiply(fit.select('scale')).add(fit.select('offset'))
              .set('system:time_start',img.get('system:time_start')).rename('NDVI');
  }
  t = ee.Date(t);
  var window = data.filterDate(t.advance(-windowSize,'day'),t.advance(windowSize,'day'));
  var fit = window.select(['time','NDVI'])
    .reduce(ee.Reducer.linearFit());
  return window.map(applyFit).toList(5);
}
// function to reduce time stacked linear regression results
// requires that a variable 'fitIC' exists from the smooter function
function reduceFits(t){
  t = ee.Date(t);
  var dates=t.format('DD');
  return fitIC.filterDate(t.advance(-windowSize,'day'),t.advance(windowSize,'day'))
              .mean().set('system:time_start',t.millis()).rename('ndvi');
}
var data = filteredIC.map(addDataBands);
var dates = ee.List(data.aggregate_array('system:time_start'));
//print(ee.date(1507006975670));
var windowSize = 10; //days on either side
var fitIC = ee.ImageCollection(dates.map(smoother).flatten());
var smoothed = ee.ImageCollection(dates.map(reduceFits));
print("here")
fitIC=null;
data=null;
dates=null;
s2=null;
return smoothed;
}
function get_sos(filteredIC_in){
var smoothed=get_smooth(filteredIC_in);
var dates2=ee.List(smoothed.aggregate_array('system:time_start'));
//print('smoothed',smoothed);
function getmin(t){
  t = ee.Date(t);
  var dates=t.format('DD');
  var images_prev=ee.Image(smoothed.filterDate(t.advance(-5,'day'),t.advance(1,'day')).first()).rename('prev');
  var images_next_col=smoothed.filterDate(t.advance(-1,'day'),t.advance(10,'day'));
  var listOfImages = images_next_col.toList(images_next_col.size());
  var images_next= ee.Image(listOfImages.get(listOfImages.length().subtract(1))).rename('next');
  var image_now=smoothed.filterMetadata("system:time_start",'equals',t.millis());
  var image0=ee.Image(image_now.first());
  //var time=ee.Image.constant(dates).float().rename('times');
  var time=ee.Image.constant(ee.Number.parse(image0.date().format("YYMMdd"))).rename('times').float();
  //print('image',image);
  var image1=image0.addBands(time);
  var image2=image1.addBands(images_prev);
  var image=image2.addBands(images_next);
  var image_time=image.expression(
    "(b('prev') > b('ndvi')&&b('next') > b('ndvi') ) ? b('times')"+": 0");
  return image_time}
var time_min=ee.ImageCollection(dates2.map(getmin));
var chk = time_min.max();
return chk
//print('min',time_min);
}
function get_eos(filteredIC_in){
    //var dates = ee.List(smoothed.aggregate_array('system:time_start'));
    //print(ee.date(1507006975670));
    //var windowSize = 30; //days on either side
    //var fitIC = ee.ImageCollection(dates.map(smoother).flatten());
    var smoothed = get_smooth(filteredIC_in);
    var dates2=ee.List(smoothed.aggregate_array('system:time_start'));
    //print('smoothed',smoothed);
    function getmax(t){
  t = ee.Date(t);
  var dates=t.advance(18,'day').format('YYMMdd');
  //print(dates);
  print('ere');
  var images_prev=ee.Image(smoothed.filterDate(t.advance(-5,'day'),t.advance(1,'day')).first()).rename('prev');
  var images_next_col=smoothed.filterDate(t.advance(-1,'day'),t.advance(10,'day'));
  var listOfImages = images_next_col.toList(images_next_col.size());
  var images_next= ee.Image(listOfImages.get(listOfImages.length().subtract(1))).rename('next');
  var image_now=smoothed.filterMetadata("system:time_start",'equals',t.millis());
  var image0=ee.Image(image_now.first());
  var time=ee.Image.constant(ee.Number.parse(dates)).float().rename('times');
  //var time=ee.Image.constant(ee.Number.parse(image0.date().format("YYMMdd"))).rename('times').float();
  //print('image',image);
  var image1=image0.addBands(time);
  var image2=image1.addBands(images_prev);
  var image=image2.addBands(images_next);
  var image_time=image.expression(
    "(b('prev') < b('ndvi')&&b('next') < b('ndvi') ) ? b('times')"+": 0");
  return image_time}
    var time_min=ee.ImageCollection(dates2.map(getmax));
    var chk = time_min.max();
    return chk
    //print('min',time_min);
    }
var eos1=get_eos(filteredIC_Eseason1).rename('EOS');
//var eos2=get_eos(filteredIC_Eseason2).rename('EOS');
//var eos3=get_eos(filteredIC_Eseason3).rename('EOS');
//var eos4=get_eos(filteredIC_Eseason4).rename('EOS4');
var sos1=get_sos(filteredIC_Sseason1).rename('SOS');
//var sos2=get_sos(filteredIC_Sseason2).rename('SOS');
//var sos3=get_sos(filteredIC_Sseason3).rename('SOS');
//var sos4=get_sos(filteredIC_Sseason4).rename('SOS4');
var season_unfiltered=sos1.addBands(eos1);
var eos_filtered=season_unfiltered.expression(
    "(b('EOS')==0 || b('SOS')==0  ) ? 0"+": b('EOS')");
var sos_filtered=season_unfiltered.expression(
    "(b('EOS')==0 || b('SOS')==0  ) ? 0"+": b('SOS')");
var sos_mask=sos_filtered.gte(1);
var sosn=sos_filtered.updateMask(sos_mask);
var eos_mask=eos_filtered.gte(1);
var eosn=eos_filtered.updateMask(eos_mask);
var seasonn=sosn.addBands(eosn);//.addBands(eos2).addBands(eos3);//.addBands(eos4);
//var sos=sos1//.addBands(sos2).addBands(sos3);//.addBands(sos4);
var geometry=ee.FeatureCollection('users/ashok_dahal/nepal');
var exp_eos=seasonn.clip(geometry_bound)
var hansenImage = ee.Image('UMD/hansen/global_forest_change_2015');
// Select the land/water mask.
var datamask = hansenImage.select('datamask');
// Create a binary mask.
var mask_water = datamask.eq(1);
// Load or import the Hansen et al. forest change dataset.
var ag_land = ee.Image('users/ashok_dahal/lcover');
// Select the land/water mask.
//var datamask = hansenImage.select('datamask');
// Create a binary mask.
//var ag_land = ee.Image('users/ashok_dahal/lcover');
var mask_ag = ag_land.eq(8);
 exp_eos=exp_eos.updateMask(mask_ag);
 exp_eos=exp_eos.updateMask(mask_water);
exp_eos=exp_eos.clip(bound);
//show in map
var palette = ["a50026","d73027","f46d43","fdae61","fee08b","d9ef8b","a6d96a","66bd63","1a9850","006837"];
//Map.addLayer(timeMin.clip(geometry), {min: 20170500, max: 20181200, palette: palette}, 'NDVI time for min');
map.setCenter(83.58,28.8,7)
//Map.addLayer(mask_ag,{},'Agricultural Land');
map.addLayer(exp_eos.select("EOS"),{min: 180500, max: 180830, palette: palette},'EOS');
map.addLayer(exp_eos.select("SOS"),{min: 180900, max: 181230, palette: palette},'SOS');
//download
function downloadImg() {
  var viewBounds = ee.Geometry.Rectangle(map.getBounds());
  var downloadArgs = {
    name: 'ee_image',
    crs: 'EPSG:5070',
    scale: 10,
    region: viewBounds.toGeoJSONString()
 };
 var url = exp_eos.getDownloadURL(downloadArgs);
 urlLabel.setUrl(url);
 urlLabel.style().set({shown: true});
}
// Add UI elements to the Map.
var downloadButton = ui.Button('Download Calendar', downloadImg);
var urlLabel = ui.Label('Click Here to Download', {shown: false});
//var panel2 = ui.Panel([downloadButton, urlLabel]);
//Map.add(panel2);
panel.add(downloadButton);
panel.add(urlLabel);
//var exp_sos=sos.clip(geometry)
function exportimgdrive(){
Export.image.toDrive({
  image: exp_eos,
  description: 'Season1',
  scale: 10,
  maxPixels: 507303336000,
  region: exp_eos.geometry()
});
}
var exportimgdrivebutton=ui.Button('Export to Google Drive', exportimgdrive);
panel.add(exportimgdrivebutton);
function exportimgcloud(){
  Export.image.toCloudStorage({
  image: exp_eos,
  description: 'CropCalendar',
  bucket: 'shpgee',
  maxPixels: 507303336000,
  fileNamePrefix: 'season1',
  scale: 10,
  region: exp_eos.geometry()
});
}
var exportimgcloudbutton=ui.Button('Export to Google Cloud ', exportimgcloud);
panel.add(exportimgcloudbutton);
//Confirm all the task to be done
  }
  }
);
panel.add(button);