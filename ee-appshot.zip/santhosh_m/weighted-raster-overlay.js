var roads = ee.FeatureCollection("TIGER/2016/Roads")
var jrc = ee.Image("JRC/GSW1_2/GlobalSurfaceWater")
var ghsl = ee.ImageCollection("JRC/GHSL/P2016/POP_GPW_GLOBE_V1")
var blues = ['#0868ac', '#43a2ca', '#7bccc4', '#bae4bc', '#f0f9e8']
var purples = ['#810f7c', '#8856a7', '#8c96c6', '#b3cde3', '#edf8fb']
var RdGrBl = ['#d7191c','#fdae61','#ffffbf','#a6d96a','#1a9641']
var c = {}
c.controlPanel = ui.Panel()
c.dividers = {}
c.dividers.divider1 = ui.Panel()
c.dividers.divider2 = ui.Panel()
c.map = ui.Map();
var roadsDistance = roads.distance(1000, 100).unmask(1000).rename('roads') 
// Higher important to places close to roads
var roadsReclass = roadsDistance
  .where(roadsDistance.gte(1000), 10)
  .where(roadsDistance.lt(1000), 50)
  .where(roadsDistance.lt(100), 100)
var water = jrc.select('occurrence').gt(50).unmask(0).rename('water')
Map.setCenter(-89.42, 43.05, 10)
var euclidian = ee.Kernel.euclidean({
  radius: 5000,
  units: 'meters'})
var waterDistance = water.distance(euclidian).unmask(5000)
// Lower importance to places near water
var waterReclass = waterDistance
  .where(waterDistance.lt(100), 10)
  .where(waterDistance.gte(100), 50)
  .where(waterDistance.gte(1000), 100)
var dataset = ee.ImageCollection('JRC/GHSL/P2016/POP_GPW_GLOBE_V1')
                  .filter(ee.Filter.date('2015-01-01', '2015-12-31'));
var pop = dataset.select('population_count').first();
var popReclass = pop
  .where(pop.lt(25), 10)
  .where(pop.gte(50), 50)
  .where(pop.gte(75), 100)
var image = roadsReclass.addBands(waterReclass).addBands(popReclass)
// Default run //
  var roadsWeightdef = 34
  var waterWeightdef = 33
  var populationWeightdef = 33
  var resultdef = image.expression('(roads*roads_weight + water*water_weight + population*population_weight)/100', {
        'roads': image.select('roads'),
        'roads_weight': roadsWeightdef,
        'water': image.select('water'),
        'water_weight': waterWeightdef,
        'population' : image.select('population_count'),
        'population_weight':populationWeightdef
      }).rename('overlay')
  //Map.addLayer(result, {min:0, max:100, palette: RdGrBl}, 'Overlay Result')
  c.map.setCenter(-89.42,43.05, 10)
  c.map.layers().set(0, ui.Map.Layer(resultdef, {min:0, max:100, palette: RdGrBl}, 'Overlay Result')) 
  c.map.layers().set(1, ui.Map.Layer(roadsReclass, {min:0, max:100, palette: RdGrBl}, 'Roads Reclass', false)) 
  c.map.layers().set(2, ui.Map.Layer(waterReclass, {min:0, max:100, palette: RdGrBl}, 'Water Reclass', false)) 
  c.map.layers().set(3, ui.Map.Layer(popReclass, {min:0, max:100, palette: RdGrBl}, 'Population Reclass', false)) 
  c.map.layers().set(4, ui.Map.Layer(roadsDistance, {min:0, max: 1000, palette: purples}, 'Roads', false)) 
  c.map.layers().set(5, ui.Map.Layer(waterDistance, {min:0, max: 5000, palette: blues}, 'Water', false)) 
  c.map.layers().set(6, ui.Map.Layer(pop, {min:0, max: 1000, palette: purples}, 'population', false))
// Default run end //
var multicriteria = function() {
  var roadsWeight = c.roadWeight.slider.getValue()
  var waterWeight = c.waterWeight.slider.getValue()
  var populationWeight = c.populationWeight.slider.getValue()
  var result = image.expression('(roads*roads_weight + water*water_weight + population*population_weight)/100', {
        'roads': image.select('roads'),
        'roads_weight': roadsWeight,
        'water': image.select('water'),
        'water_weight': waterWeight,
        'population' : image.select('population_count'),
        'population_weight':populationWeight
      }).rename('overlay')
  c.map.clear()
  //ui.Map.clear()
  c.map.setCenter(-89.42,43.05, 10)
  c.map.layers().set(0, ui.Map.Layer(result, {min:0, max:100, palette: RdGrBl}, 'Overlay Result')) 
  c.map.layers().set(1, ui.Map.Layer(roadsReclass, {min:0, max:100, palette: RdGrBl}, 'Roads Reclass', false)) 
  c.map.layers().set(2, ui.Map.Layer(waterReclass, {min:0, max:100, palette: RdGrBl}, 'Water Reclass', false)) 
  c.map.layers().set(3, ui.Map.Layer(popReclass, {min:0, max:100, palette: RdGrBl}, 'Population Reclass', false)) 
  c.map.layers().set(4, ui.Map.Layer(roadsDistance, {min:0, max: 1000, palette: purples}, 'Roads', false)) 
  c.map.layers().set(5, ui.Map.Layer(waterDistance, {min:0, max: 5000, palette: blues}, 'Water', false)) 
  c.map.layers().set(6, ui.Map.Layer(pop, {min:0, max: 1000, palette: purples}, 'population', false))}
c.info = {};
c.info.titleLabel = ui.Label('Multi Criteria Overlay');
c.info.aboutLabel = ui.Label('Tools to create and configure raster data for web-based weighted overlay to support suitability modeling ');
c.info.panel = ui.Panel([c.info.titleLabel, c.info.aboutLabel])
c.roadWeight = {}
c.roadWeight.label = ui.Panel(ui.Label("Enter the road weights in %", {fontWeight: 'bold'}))
c.roadWeight.slider = ui.Slider({
  min:0,
  max:100,
  value:33,
  step:1,
  onChange:function(value) {
    c.roadWeight.textbox.setValue(value)
    control()
  }
})
c.roadWeight.textbox = ui.Textbox({
  placeholder:"Enter value between 1 - 100",
  value:33,
  onChange:function(value) {c.roadWeight.slider.setValue(value)}
})
c.roadWeight.tickbox = ui.Checkbox({
  label:"lock",
  value:false,
  onChange:function(){
    if (c.roadWeight.tickbox.getValue()) {
    c.roadWeight.slider.setDisabled(true)
    c.roadWeight.textbox.setDisabled(true)} else {
    c.roadWeight.slider.setDisabled(false)
    c.roadWeight.textbox.setDisabled(false)}
  },
  disabled:false
})
c.roadWeight.panel = ui.Panel([c.roadWeight.slider, c.roadWeight.textbox, c.roadWeight.tickbox], ui.Panel.Layout.flow('horizontal'))
c.waterWeight = {}
c.waterWeight.label = ui.Panel(ui.Label("Enter the water weights in %", {fontWeight: 'bold'}))
c.waterWeight.slider = ui.Slider({
  min:0,
  max:100,
  value:34,
  step:1,
  onChange:function(value) {
    c.waterWeight.textbox.setValue(value)
    control()
  }
})
c.waterWeight.textbox = ui.Textbox({
  placeholder:"Enter value between 1 - 100",
  value:34,
  onChange:function(value) {
    c.waterWeight.slider.setValue(value)
    control()
  }
})
c.waterWeight.tickbox = ui.Checkbox({
  label:"lock",
  value:false,
  onChange:function(){
    if (c.waterWeight.tickbox.getValue()) {
    c.waterWeight.slider.setDisabled(true)
    c.waterWeight.textbox.setDisabled(true)} else {
    c.waterWeight.slider.setDisabled(false)
    c.waterWeight.textbox.setDisabled(false)}
  },
  disabled:false
})
c.waterWeight.panel = ui.Panel([c.waterWeight.slider, c.waterWeight.textbox, c.waterWeight.tickbox], ui.Panel.Layout.flow('horizontal'))
c.populationWeight = {}
c.populationWeight.label = ui.Panel(ui.Label("Enter the population weights in %", {fontWeight: 'bold'}))
c.populationWeight.slider = ui.Slider({
  min:0,
  max:100,
  value:33,
  step:1,
  onChange:function(value) {
    c.populationWeight.textbox.setValue(value)
    control()
  }
})
c.populationWeight.textbox = ui.Textbox({
  placeholder:"Enter value between 1 - 100",
  value:33,
  onChange:function(value) {
    c.populationWeight.slider.setValue(value)
    control()
  }
})
c.populationWeight.tickbox = ui.Checkbox({
  label:"lock",
  value:false,
  onChange:function(){
    if (c.populationWeight.tickbox.getValue()) {
    c.populationWeight.slider.setDisabled(true)
    c.populationWeight.textbox.setDisabled(true)} else {
    c.populationWeight.slider.setDisabled(false)
    c.populationWeight.textbox.setDisabled(false)}
  },
  disabled:false
})
c.populationWeight.panel = ui.Panel([c.populationWeight.slider, c.populationWeight.textbox, c.populationWeight.tickbox], ui.Panel.Layout.flow('horizontal'))
c.compute = {}
c.compute.label = ui.Label("Compute...")
c.compute.button = ui.Button({
  label:"Compute", onClick:function(){multicriteria()}, disabled:true, style:{color:'red', position:'bottom-right'}})
c.compute.panel = ui.Panel([c.compute.button])
var control = function(){
  var num1 = c.waterWeight.slider.getValue() 
  var num2 = c.roadWeight.slider.getValue() 
  var num3 = c.populationWeight.slider.getValue() 
  var sum = num1 + num2 +num3
  if (sum == 100){
    c.compute.button.style().set({color:'green'})
    c.compute.button.setDisabled(false)
    } else {
      c.compute.button.style().set({color:'red'})
      c.compute.button.setDisabled(true)
    }
};
c.controlPanel.add(c.info.panel)
c.controlPanel.add(c.dividers.divider1)
c.controlPanel.add(c.waterWeight.label)
c.controlPanel.add(c.waterWeight.panel)
c.controlPanel.add(c.roadWeight.label)
c.controlPanel.add(c.roadWeight.panel)
c.controlPanel.add(c.populationWeight.label)
c.controlPanel.add(c.populationWeight.panel)
c.controlPanel.add(c.dividers.divider2)
c.controlPanel.add(c.compute.panel)
ui.root.clear()
ui.root.add(c.controlPanel)
ui.root.add(c.map);
var s = {}
// Style Margin // 
s.noTopMargin = {
  margin: '0px 8px 8px 8px'
};
s.smallBottomMargin = {
  margin: '8px 8px 4px 8px'
};
s.bigTopMargin = {
  margin: '24px 8px 8px 8px'
};
s.opacityWhiteMed = {
  backgroundColor: 'rgba(255, 255, 255, 0.5)'
};
s.opacityWhiteNone = {
  backgroundColor: 'rgba(255, 255, 255, 0)'
};
s.aboutText = {
  fontSize: '13px',
  color: '505050'
};
s.widgetTitle = {
  fontSize: '15px',
  fontWeight: 'bold',
  margin: '8px 8px 0px 8px',
  color: '383838'
};
s.stretchHorizontal = {
  stretch: 'horizontal'
};
s.divider = {
  backgroundColor: 'F0F0F0',
  height: '4px',
  margin: '20px 0px'
};
s.slider = {
  width: '225px'
}
s.textbox = {
  width: '35px'
}
Object.keys(c.dividers).forEach(function(key) {
  c.dividers[key].style().set(s.divider);
});
c.info.titleLabel.style().set({
  fontSize: '24px',
  fontWeight: 'bold'
});
c.info.titleLabel.style().set(s.bigTopMargin);
c.info.aboutLabel.style().set(s.aboutText);
c.controlPanel.style().set({
  width: '400px'
});
c.waterWeight.slider.style().set(s.slider)
c.roadWeight.slider.style().set(s.slider)
c.populationWeight.slider.style().set(s.slider)
c.waterWeight.textbox.style().set(s.textbox)
c.roadWeight.textbox.style().set(s.textbox)
c.populationWeight.textbox.style().set(s.textbox)