var optparam = ui.import && ui.import("optparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "swir1",
          "nir",
          "red"
        ],
        "min": 190,
        "max": 3719,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["swir1","nir","red"],"min":190,"max":3719,"gamma":1},
    fnfparam = ui.import && ui.import("fnfparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "fnf_2015"
        ],
        "min": 1,
        "max": 3,
        "palette": [
          "06800f",
          "ffe7b1",
          "1b18ff"
        ]
      }
    }) || {"opacity":1,"bands":["fnf_2015"],"min":1,"max":3,"palette":["06800f","ffe7b1","1b18ff"]},
    tmfDEF = ui.import && ui.import("tmfDEF", "image", {
      "id": "projects/cafi_fao_congo/regional/tmf_DEF_cafi_2016_2019"
    }) || ee.Image("projects/cafi_fao_congo/regional/tmf_DEF_cafi_2016_2019"),
    tmfDEG = ui.import && ui.import("tmfDEG", "image", {
      "id": "projects/cafi_fao_congo/regional/tmf_DEG_cafi_2016_2019"
    }) || ee.Image("projects/cafi_fao_congo/regional/tmf_DEG_cafi_2016_2019"),
    tmfdefparam = ui.import && ui.import("tmfdefparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "DeforestationYear"
        ],
        "min": 2016.134762373203,
        "max": 2018.9755102040817,
        "palette": [
          "fcff1f",
          "ff7939",
          "ff510e"
        ]
      }
    }) || {"opacity":1,"bands":["DeforestationYear"],"min":2016.134762373203,"max":2018.9755102040817,"palette":["fcff1f","ff7939","ff510e"]},
    tmfdegparam = ui.import && ui.import("tmfdegparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "DegradationYear"
        ],
        "min": 2016,
        "max": 2019,
        "palette": [
          "ffdcc8",
          "ff936a",
          "ffb204"
        ]
      }
    }) || {"opacity":1,"bands":["DegradationYear"],"min":2016,"max":2019,"palette":["ffdcc8","ff936a","ffb204"]},
    tpi = ui.import && ui.import("tpi", "image", {
      "id": "CSP/ERGo/1_0/Global/SRTM_mTPI"
    }) || ee.Image("CSP/ERGo/1_0/Global/SRTM_mTPI"),
    treecover = ui.import && ui.import("treecover", "image", {
      "id": "projects/cafi_fao_congo/regional/treecover_2015_30m"
    }) || ee.Image("projects/cafi_fao_congo/regional/treecover_2015_30m"),
    fnf2015 = ui.import && ui.import("fnf2015", "image", {
      "id": "projects/cafi_fao_congo/classification/FNF_2015"
    }) || ee.Image("projects/cafi_fao_congo/classification/FNF_2015"),
    cafifnfparam = ui.import && ui.import("cafifnfparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "remapped"
        ],
        "min": 1,
        "max": 3,
        "palette": [
          "166c1d",
          "fbffba",
          "2132ff"
        ]
      }
    }) || {"opacity":1,"bands":["remapped"],"min":1,"max":3,"palette":["166c1d","fbffba","2132ff"]},
    palmoil2019 = ui.import && ui.import("palmoil2019", "image", {
      "id": "projects/cafi_fao_congo/regional/palm_oil_2019"
    }) || ee.Image("projects/cafi_fao_congo/regional/palm_oil_2019"),
    histo = ui.import && ui.import("histo", "image", {
      "id": "projects/cafi_fao_congo/regional/histosols_cifor"
    }) || ee.Image("projects/cafi_fao_congo/regional/histosols_cifor"),
    waterparam = ui.import && ui.import("waterparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "waterClass"
        ],
        "max": 3,
        "palette": [
          "fffde7",
          "27ffff",
          "1d24ff"
        ]
      }
    }) || {"opacity":1,"bands":["waterClass"],"max":3,"palette":["fffde7","27ffff","1d24ff"]},
    pas = ui.import && ui.import("pas", "table", {
      "id": "projects/cafi_fao_congo/regional/PAs_Congo_Basin"
    }) || ee.FeatureCollection("projects/cafi_fao_congo/regional/PAs_Congo_Basin"),
    raddparam = ui.import && ui.import("raddparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "Date"
        ],
        "min": 19000,
        "max": 20366,
        "palette": [
          "ffb76c",
          "ff0404"
        ]
      }
    }) || {"opacity":1,"bands":["Date"],"min":19000,"max":20366,"palette":["ffb76c","ff0404"]},
    canopy = ui.import && ui.import("canopy", "image", {
      "id": "projects/cafi_fao_congo/regional/canopy_height_2019"
    }) || ee.Image("projects/cafi_fao_congo/regional/canopy_height_2019"),
    aoi = ui.import && ui.import("aoi", "table", {
      "id": "projects/cafi_fao_congo/regional/aoi_cafi"
    }) || ee.FeatureCollection("projects/cafi_fao_congo/regional/aoi_cafi"),
    planet = ui.import && ui.import("planet", "imageCollection", {
      "id": "projects/planet-nicfi/assets/basemaps/africa"
    }) || ee.ImageCollection("projects/planet-nicfi/assets/basemaps/africa"),
    JRCparam = ui.import && ui.import("JRCparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "b1",
          "b2",
          "b3"
        ],
        "min": 9,
        "max": 203,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["b1","b2","b3"],"min":9,"max":203,"gamma":1},
    tiling = ui.import && ui.import("tiling", "table", {
      "id": "projects/cafi_fao_congo/regional/cafi_tiling_100km"
    }) || ee.FeatureCollection("projects/cafi_fao_congo/regional/cafi_tiling_100km"),
    validation = ui.import && ui.import("validation", "table", {
      "id": "projects/cafi_fao_congo/change/ceo_cafi_dd_map_validation_points"
    }) || ee.FeatureCollection("projects/cafi_fao_congo/change/ceo_cafi_dd_map_validation_points"),
    burned = ui.import && ui.import("burned", "image", {
      "id": "projects/cafi_fao_congo/regional/burned_forest_2016_2020"
    }) || ee.Image("projects/cafi_fao_congo/regional/burned_forest_2016_2020"),
    access = ui.import && ui.import("access", "image", {
      "id": "projects/cafi_fao_congo/regional/accessibility_2015"
    }) || ee.Image("projects/cafi_fao_congo/regional/accessibility_2015"),
    burnedparam = ui.import && ui.import("burnedparam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "BurnDate"
        ],
        "min": 16,
        "max": 19,
        "palette": [
          "a5ffea",
          "85c1ff",
          "d085ff",
          "d427ff"
        ]
      }
    }) || {"opacity":1,"bands":["BurnDate"],"min":16,"max":19,"palette":["a5ffea","85c1ff","d085ff","d427ff"]},
    routes = ui.import && ui.import("routes", "table", {
      "id": "projects/cafi_fao_congo/regional/roads_Kleinschroth_etal_2019"
    }) || ee.FeatureCollection("projects/cafi_fao_congo/regional/roads_Kleinschroth_etal_2019"),
    dd_change = ui.import && ui.import("dd_change", "image", {
      "id": "projects/cafi_fao_congo/change/dd_change_mask"
    }) || ee.Image("projects/cafi_fao_congo/change/dd_change_mask"),
    crops2015 = ui.import && ui.import("crops2015", "image", {
      "id": "projects/cafi_fao_congo/regional/croplands2015"
    }) || ee.Image("projects/cafi_fao_congo/regional/croplands2015"),
    crops2019 = ui.import && ui.import("crops2019", "image", {
      "id": "projects/cafi_fao_congo/regional/croplands2019"
    }) || ee.Image("projects/cafi_fao_congo/regional/croplands2019"),
    S2_2020 = ui.import && ui.import("S2_2020", "image", {
      "id": "projects/cafi_fao_congo/imagery/S2_2020_JRC"
    }) || ee.Image("projects/cafi_fao_congo/imagery/S2_2020_JRC"),
    frag2015 = ui.import && ui.import("frag2015", "image", {
      "id": "projects/cafi_fao_congo/classification/fragmentation_2015"
    }) || ee.Image("projects/cafi_fao_congo/classification/fragmentation_2015"),
    lc2015 = ui.import && ui.import("lc2015", "image", {
      "id": "projects/cafi_fao_congo/classification/LC_2015"
    }) || ee.Image("projects/cafi_fao_congo/classification/LC_2015"),
    worldcover = ui.import && ui.import("worldcover", "imageCollection", {
      "id": "ESA/WorldCover/v100"
    }) || ee.ImageCollection("ESA/WorldCover/v100");
var cafi = ee.FeatureCollection('projects/cafi_fao_congo/regional/congo_basin_lsib')
var JAXAfnf = ee.Image('projects/cafi_fao_congo/regional/kc_fnf_2015')
var ucl = ee.Image('projects/cafi_fao_congo/regional/congo_basin_vegetation_UCL')
var radd = ee.Image('projects/cafi_fao_congo/regional/radd_alerts_2019_2020')
var NASAdem = ee.Image("NASA/NASADEM_HGT/001")
var optical2015 = ee.Image('projects/cafi_fao_congo/imagery/cafi_optical_mosaic_2013_2015')
var palettes = require('users/gena/packages:palettes');
//GUI PANEL
Map.style().set('cursor', 'crosshair');
// Add a title and some explanatory text to a side panel.
var header = ui.Label('Évaluation de la déforestation et de la dégradation des forêts et des moteurs directs associés à laide de SEPAL', {fontSize: '26px', color: 'grey'});
var text = ui.Label(
    'Inventaire de données régionales qui viennent du projet et nos partenaires',
    {fontSize: '14px'});
var panel = ui.Panel([header, text], 'flow', {width: '300px'});
ui.root.widgets().add(panel);
// Create a hyperlink to an external reference.
var link = ui.Label(
    'Projet CAFI/FAO Déforestation, dégradation et moteurs directs associes', {},
    'http://www.fao.org/redd/news/deforestation-et-degradation-en-afrique-centrale/fr/');
var linkPanel = ui.Panel(
    [ui.Label('pour en savoir plus:', {fontWeight: 'bold'}), link]);
panel.add(linkPanel);
var background = ee.Image('users/gena/NE1_HR_LC_SR_W').visualize({})
var black = ee.Image(1).visualize({opacity: 0.95, palette: ['000000'], forceRgbOutput: true})  
var white = ee.Image(1).visualize({opacity: 1, palette: ['FFFFFF'], forceRgbOutput: true})  
Map.addLayer(black,{}, 'fond de carte noire')
Map.addLayer(white,{}, 'fond de carte blanc',false)
Map.centerObject(cafi, 6)
Map.addLayer(tiling,{}, 'Tuiles 100km',false)
var uclpalette = palettes.colorbrewer.Set1[9]
Map.addLayer(optical2015.clip(cafi), optparam, 'Mosaique Optique Landsat (2015)')
Map.addLayer(S2_2020,JRCparam,'Sentinel-2 2020 (JRC)', false)
var alos = ee.Image('projects/cafi_fao_congo/imagery/alos_mosaic_2015_quegan_rfdi_masked_texture')
Map.addLayer(alos, {min: [0, 0, 1], max: [0.5, 0.15, 15]}, 'Mosaique ALOS (2015)',false)
var tscan= ee.Image('projects/cafi_fao_congo/imagery/S1_2020_timescan') 
Map.addLayer(tscan.select(['VV_p95', 'VH_p5', 'NDCV']), {min: [-20, -30, -0.5], max: [0, -12, 0.2]}, 'Sentinel-1 (2020)',false)
//var planet2020 = planet.filterDate('2020-01-01','2020-12-31').filterBounds(aoi)
//Map.addLayer(planet2020.median(), {gain: 0.15, bands:["R", "G", "B"]}, 'Planet Mosaic 2020',false)
var elevpalette = palettes.crameri.batlow[25]
Map.addLayer(NASAdem.select('elevation').clip(cafi), {min:0, max:3300, palette: elevpalette}, 'NASA DEM', false)
Map.addLayer(tpi.clip(cafi), {min:-7, max:11, palette: uclpalette}, 'Index Topographique (NASA)', false)
var canopypalette = palettes.cmocean.Speed[7]
Map.addLayer(canopy,{min:0, max:60, palette:canopypalette}, 'Hauteur de canopée 2019', false)
var classpalette = [
  'darkgreen', // 1- foret dense
  'green', // 2 - forest dense seche
  'limegreen',  // 3 - foret secondaire
   'seagreen', // 4 - foret claire seche
  'mediumaquamarine', //5 submontane
  'darkcyan', //6 montane
  'darkmagenta', // 7 -mangrove
  'teal', //8- foret marecageuse
  'darkseagreen', // 9- foret galeries
  'saddlebrown', //10 plantations
  'DarkOliveGreen',//  10 savanne arboree
  'gold', // 11 - savanne arbustive
  'khaki',  // 12 - savanne herbacee
  'steelblue', //13 -prairie aquatique
  'grey', // 14 - sols nus
  'tan', // 15- terres cultivées
  'maroon', //16- zone baties
  'blue', //17 - eau
];
var ddpalette = [
                    'black',        // 0- no data
                    'darkgreen',    // 1- foret dense
                    'green',        // 2- forest dense seche
                    'limegreen',    // 3- foret secondaire
                    'seagreen',     // 4- foret claire seche
                    'cadetblue',    // 5- submontane
                    'turquoise',    // 6- montane
                    'darkmagenta',  // 7- mangrove
                    'purple',       // 8- foret marecageuse
                    'darkseagreen', // 9- foret galeries
                    'saddlebrown',  // 10 plantations
                    'olivedrab',    // 11 savanne arboree
                    'gold',         // 12 savanne arbustive
                    'khaki',        // 13 savanne herbacee
                    'steelblue',    // 14 prairie aquatique
                    'grey',         // 15 sols nus
                    'tan',          // 16 terres cultivées
                    'maroon',       // 17 zone baties
                    'blue'  ,       // 18 eau
                    'orange','orange','orange','orange','orange','orange',
                    'orange','orange','orange','orange','orange','orange', //100-154 degradation 
                    'orange','orange','orange','orange','orange','orange',
                    'orange','orange','orange','orange','orange','orange',
                    'orange','orange','orange','orange','orange','orange',
                    'orange','orange','orange','orange','orange','orange',
                    'orange','orange','orange','orange','orange','orange',
                    'orange','orange','orange','orange','orange','orange',
                    'orange','orange','orange','orange','orange','orange',
                    'red','red','red','red','red','red','red','red','red','red','red','red',          //200-254 deforestation
                    'red','red','red','red','red','red','red','red','red','red','red','red',
                    'red','red','red','red','red','red','red','red','red','red','red','red',          //200-254 deforestation
                    'red','red','red','red','red','red','red','red','red','red','red','red',
                    'red','red','red','red','red','red'
];
var treecoverpalette =  palettes.colorbrewer.Greens[9]
var worldcoverpalette =
['#006400',
'#ffbb22',
'#ffff4c',
'#f096ff',
'#fa0000',
'#b4b4b4',
'#f0f0f0',
'#0064c8',
'#0096a0',
'#00cf75',
'#fae6a0'
]
Map.addLayer(ucl.selfMask(), {min:0, max: 20, palette: uclpalette}, 'Carte de Végétation de UCL (2010)', false)
var worldcover_cafi = worldcover.mosaic()
Map.addLayer(worldcover_cafi.clip(aoi),{min:10,max:100, palette: worldcoverpalette},'ESA World Cover 2020',false)
Map.addLayer(treecover,{min:0, max:100, palette:treecoverpalette}, '% treecover',false)
Map.addLayer(histo, {}, 'Histosols', false)
Map.addLayer(lc2015, {min:1, max:18, palette: classpalette}, 'Classification CAFI (2015)')
Map.addLayer(fnf2015, cafifnfparam, 'CAFI Foret/Non-Foret (2015)',false)
Map.addLayer(frag2015,{min:1,max:5,palette:['darkred','orange','yellow','green','grey']}, 'Fragmentation 2015',false)
Map.addLayer(JAXAfnf, fnfparam, 'JAXA Foret/Non-Foret (2015)', false)
Map.addLayer(burned,burnedparam,'Détections de foret brulée MODIS (2015-2020',false)
Map.addLayer(access.clip(aoi),{min:0, max:1000, opacity:0.7, palette:['FFFACD', 'CD8500', '8A360F','68228B']}, 'Accessibilité au villes (2015)',false)
Map.addLayer(crops2015.selfMask(),{palette:['#89584E']},'terres cultivées (2015)',false)
Map.addLayer(crops2019.selfMask(),{palette:['#995244']},'terres cultivées (2019)',false)
Map.addLayer(radd, raddparam, 'Alertes RADD - 2019-2020',false)
Map.addLayer(tmfDEF,tmfdefparam,'TMF Déforestation (2016-2020)',false)
Map.addLayer(tmfDEG,tmfdegparam,'TMF Dégradation (2016-2020)',false)
Map.addLayer(dd_change.selfMask(), {min:1,max:5,palette:['green','grey','blue','red','orange']},'CAFI/FAO Stratification Déforestation/Dégradation')
var flipalette= palettes.crameri.bamako[10].reverse()
Map.addLayer(palmoil2019, {}, 'Plantations huile de palme (2019) de Descals et al., 2021', false)
var water = ee.ImageCollection("JRC/GSW1_3/YearlyHistory")
var water_area = water.mosaic().clip(cafi)//.selfMask()
Map.addLayer(water_area, waterparam, 'Eau surfacique (JRC)', false)
// routes
var emptyroads = ee.Image().byte();
var roads = emptyroads.paint({
  featureCollection: routes,
  color: 1,
  width: 1
});
Map.addLayer(roads,{color: '#505050', opacity:0.6}, 'Routes (Kleinschroth et al., 2019',false)
//pays
var emptycafi = ee.Image().byte();
var pays = emptycafi.paint({
  featureCollection: cafi,
  color: 0,
  width: 1
});
Map.addLayer(pays, {}, 'Région de létude CAFI/FAO')
Map.addLayer(pas,{color: '#0b9e70'}, 'Aires Protégées', false)
Map.addLayer(validation,{color: 'blue'}, 'points de validation moteurs',false )