var dataset = ee.Image('CGIAR/SRTM90_V4');
var elevation = dataset.select('elevation');
var exaggeration = 3;
var hillshade = ee.Terrain.hillshade(elevation.multiply(exaggeration), 350);
var hillshadeS = hillshade.convolve(ee.Kernel.gaussian({radius: 100, sigma: 50, units: 'meters'}))
Map.addLayer(hillshadeS, {min:130, max:250}, 'ETOPO1 Hillshade')
var table = ee.FeatureCollection("projects/ee-gerardosoto/assets/parcelasArturo"),
    geometry = /* color: #d63000 */ee.Geometry.MultiPoint(
        [[-72.63891593834963, -40.205617320528326],
         [-72.63567582985964, -40.20399489635961]]);
Map.centerObject(table)
Map.setOptions('SATELLITE')
Map.addLayer(table, {color: 'red'}, 'Parcelas')
Map.addLayer(table.filterBounds(geometry), {color: 'white'}, '7 y 20')