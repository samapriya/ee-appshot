var image = ui.import && ui.import("image", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2000_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2000_int16"),
    image2 = ui.import && ui.import("image2", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2001_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2001_int16"),
    image3 = ui.import && ui.import("image3", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2002_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2002_int16"),
    image4 = ui.import && ui.import("image4", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2003_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2003_int16"),
    image5 = ui.import && ui.import("image5", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2004_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2004_int16"),
    image6 = ui.import && ui.import("image6", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2005_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2005_int16"),
    image7 = ui.import && ui.import("image7", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2006_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2006_int16"),
    image8 = ui.import && ui.import("image8", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2007_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2007_int16"),
    image9 = ui.import && ui.import("image9", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2008_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2008_int16"),
    image10 = ui.import && ui.import("image10", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2009_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2009_int16"),
    image11 = ui.import && ui.import("image11", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2010_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2010_int16"),
    image12 = ui.import && ui.import("image12", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2011_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2011_int16"),
    image13 = ui.import && ui.import("image13", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2012_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2012_int16"),
    image14 = ui.import && ui.import("image14", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2013_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2013_int16"),
    image15 = ui.import && ui.import("image15", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2014_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2014_int16"),
    image16 = ui.import && ui.import("image16", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2015_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2015_int16"),
    image17 = ui.import && ui.import("image17", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2016_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2016_int16"),
    image18 = ui.import && ui.import("image18", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2017_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2017_int16"),
    image19 = ui.import && ui.import("image19", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2018_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2018_int16"),
    image20 = ui.import && ui.import("image20", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2019_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2019_int16"),
    image21 = ui.import && ui.import("image21", "image", {
      "id": "projects/ee-gerardosoto/assets/fracCov2020_int16"
    }) || ee.Image("projects/ee-gerardosoto/assets/fracCov2020_int16");
Map.centerObject(image)
Map.addLayer(image.divide(10000), {min:0, max:1}, '00')
Map.addLayer(image2.divide(10000), {min:0, max:1}, '01')
Map.addLayer(image3.divide(10000), {min:0, max:1}, '02')
Map.addLayer(image4.divide(10000), {min:0, max:1}, '03')
Map.addLayer(image5.divide(10000), {min:0, max:1}, '04')
Map.addLayer(image6.divide(10000), {min:0, max:1}, '05')
Map.addLayer(image7.divide(10000), {min:0, max:1}, '06')
Map.addLayer(image8.divide(10000), {min:0, max:1}, '07')
Map.addLayer(image9.divide(10000), {min:0, max:1}, '08')
Map.addLayer(image10.divide(10000), {min:0, max:1}, '09')
Map.addLayer(image11.divide(10000), {min:0, max:1}, '10')
Map.addLayer(image12.divide(10000), {min:0, max:1}, '11')
Map.addLayer(image13.divide(10000), {min:0, max:1}, '12')
Map.addLayer(image14.divide(10000), {min:0, max:1}, '13')
Map.addLayer(image15.divide(10000), {min:0, max:1}, '14')
Map.addLayer(image16.divide(10000), {min:0, max:1}, '15')
Map.addLayer(image17.divide(10000), {min:0, max:1}, '16')
Map.addLayer(image18.divide(10000), {min:0, max:1}, '17')
Map.addLayer(image19.divide(10000), {min:0, max:1}, '18')
Map.addLayer(image20.divide(10000), {min:0, max:1}, '19')
Map.addLayer(image21.divide(10000), {min:0, max:1}, '20')