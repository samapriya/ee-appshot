var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                33.5509666069789,
                44.625964465556486
              ],
              [
                33.552447186355124,
                44.62368895371772
              ],
              [
                33.552940712813864,
                44.62380349503611
              ],
              [
                33.55148159110976,
                44.62612481705332
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#000000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #000000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[33.5509666069789, 44.625964465556486],
          [33.552447186355124, 44.62368895371772],
          [33.552940712813864, 44.62380349503611],
          [33.55148159110976, 44.62612481705332]]]);
Map.setOptions("Hybrid");
Map.setControlVisibility({ all: false });
var boxcar = ee.Kernel.circle({
    radius: 10, units: 'meters', normalize: true
  });  
var water = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1').filterDate('2022-06-01','2022-08-01').max().select('water').convolve(boxcar)
var suez = ee.Geometry.Polygon([
  [
    [32.17388584692775, 31.59541178442045],
    [32.17388584692775, 31.327159861902278],
    [32.4787564523965, 31.327159861902278],
    [32.4787564523965, 31.59541178442045],
  ],
]);
var sevastopol = 
    ee.Geometry.Polygon(
        [[[33.5509666069789, 44.625964465556486],
          [33.552447186355124, 44.62368895371772],
          [33.552940712813864, 44.62380349503611],
          [33.55148159110976, 44.62612481705332]]]);
var drawingTools = Map.drawingTools();
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
var dummyGeometry = ui.Map.GeometryLayer({
  geometries: null,
})
  .fromGeometry(sevastopol)
  .setShown(false);
drawingTools.layers().add(dummyGeometry);
function drawPolygon() {
  var layers = drawingTools.layers();
  layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
  drawingTools.setShape("polygon");
  drawingTools.draw();
}
function getVectors(img) {
  var aoi = drawingTools.layers().get(0).getEeObject();
  var processed = img.clip(aoi)
  var vv = processed.select("VV").gt(-1);
  //var vh = processed.select("VH").gt(-10);
  var cutoff=vv.updateMask(water.gt(0.3))
  var points = cutoff.reduceToVectors({
    geometry: aoi,
    //scale: 20,
    geometryType: "polygon",
    eightConnected: true,
    maxPixels: 1653602926,
  });
  points=points.map(function(feature){
    var box=ee.List(feature.geometry().bounds().coordinates().get(0))
    var pt1=ee.Geometry.Point(box.get(0))
    var pt2=ee.Geometry.Point(box.get(2))
    var length=pt1.distance(pt2,10)
    return feature.set('area',feature.area(10))
                  .set('length',length)
    })
  points=points.filter(ee.Filter.eq('label',1))
                .set('platform',img.get('platform_number'))
                .filter(ee.Filter.gt('length', scaleSlider.getValue()))
  var count = points.size();
  var date = ee.Date(img.get("system:time_start")).millis()
  return points.set("count", count).set("system:time_start", date).set("length", points.aggregate_max('length')).set("area", points.aggregate_max('area'));
}
// Run this function on a change of the dateSlider.
var daterangeVectors = function () {
  if (!chartPanel.style().get("shown")) {
    chartPanel.style().set("shown", true);
  }
  var range = ee.DateRange(
    ee.Date(dateSlider.getValue()[0]),
    ee.Date(dateSlider.getValue()[1])
  );
  var aoi = drawingTools.layers().get(0).getEeObject();
  var centroid=aoi.centroid().coordinates()
  var platform=ee.Algorithms.If(checkbox.getValue(),'B','')
  var s1 = ee.ImageCollection("COPERNICUS/S1_GRD")
    .filter(ee.Filter.listContains("transmitterReceiverPolarisation", "VV"))
    .filter(ee.Filter.neq('platform_number',platform))
    .select('VV')
    .filter(ee.Filter.eq("instrumentMode", "IW"))
    .sort("system:time_start")
  ui.url.set("lon", centroid.get(0).getInfo().toFixed(4));
  ui.url.set("lat", centroid.get(1).getInfo().toFixed(4));
  ui.url.set("zoom", Map.getZoom());
  drawingTools.layers().get(0).setShown(false);
  var boxcar = ee.Kernel.circle({
    radius: 10, units: 'meters', normalize: true
  });  
  var s1Filtered = s1.filterDate(range.start(), range.end()).map(function(img){return img.convolve(boxcar)})
  var vectors = s1Filtered.filterBounds(aoi).map(getVectors);
  var max= s1Filtered.max().updateMask(water.gt(0.3))
  print(s1Filtered.filterBounds(aoi))
  viz(aoi, vectors, max);
  var total=vectors.aggregate_sum('count')
    var chartInfo=items[dropdown.getValue()]
  function monthly(vectors){
  var months = ee.List.sequence(1, 12);
  // Map filtering and reducing acro ss year-month combinations and convert to ImageCollection
  var monthly = months.map(function (m) {
                var monthVec=vectors.filter(ee.Filter.calendarRange(m, m, 'month'))
                var y= ee.Date(monthVec.first().get('system:time_start')).get('year')
                var count= monthVec.aggregate_sum('count')
                return monthVec.set('monthly',count).set('system:time_start',ee.Date.fromYMD(y,m,1))
      }).flatten()
      return ee.FeatureCollection(monthly)
  }
  var vectors=ee.FeatureCollection(ee.Algorithms.If(chartInfo.property=='monthly',monthly(vectors),vectors))
  var chart = ui.Chart.feature
    .byFeature({
      features: vectors,
      xProperty: "system:time_start",
      yProperties: chartInfo.property,
    })
    .setChartType('ScatterChart')
    .setOptions({
      backgroundColor:'rgba(255, 255, 255, 0.5)',
      color:'red',
      title: chartInfo.title,
      vAxis: { title: chartInfo.ylab },
      explorer: { axis: "horizontal" },
      lineWidth: 2,
      //series: "platform",
    })
  var sumLabel2 = ui.Label(
      'Calculating...',{
      fontWeight: "bold",
      fontSize: "20px",
    })
  total.evaluate(function(val){sumLabel2.setValue(val)});
  // Add the chart at a fixed position, so that new charts overwrite older ones.
  var sumLabel1=ui.Label("Total number of detections:", {
      fontWeight: "bold",
      fontSize: "20px",
    })
  var sumPanel=ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
    widgets:[sumLabel1,sumLabel2]})
  chartPanel.widgets().set(1, chart);
  homePanel.widgets().set(11, sumPanel);
  //monthly(vectors)
  var filterDay = function (callback) {
    var date = ee.Date(callback);
    var vectorDay = vectors.filterDate(date);
    var s1Day = s1Filtered.filterDate(date).max().updateMask(water.gt(0.3)).convolve(boxcar);
    viz(aoi, vectorDay, s1Day);
  };
  chart.onClick(filterDay);
};
function viz(aoi, vectors, s1Filtered) {
  // Create an empty image into which to paint the features, cast to byte.
  var empty = ee.Image().byte();
  // Paint all the polygon edges with the same number and width, display.
  var outline = empty.paint({
    featureCollection: aoi,
    color: 1,
    width: 3,
  });
  var aoi_layer = ui.Map.Layer(outline, { palette: "red" }, "AOI");
  var vectorLayer = ui.Map.Layer(
    vectors.flatten(),
    { color: "#39ff14" },
    "Vectors"
  );
  var sarLayer = ui.Map.Layer(
    s1Filtered,
    { min: -5, max: 0, opacity: 0.8 },
    "SAR"
  );
  Map.layers().set(0, sarLayer);
  Map.layers().set(1, vectorLayer);
  Map.layers().set(2, aoi_layer);
}
// UI
var checkbox = ui.Checkbox('Filter Sentinel 1-B', true);
checkbox.onChange(function(checked) {daterangeVectors()});
var items= {"Daily Count": 
              {title: "Daily number of ships in the Area of Interest",
                ylab: "Ship Count",
                property:'count'}, 
            "Monthly Count": 
              {title: "Monthly number of ships in the Area of Interest",
                ylab: "Ship Count",
                property:'monthly'}, 
            "Ship Length":{title: "Max ship length in Area of Interest",
              ylab: "Ship Length (meters)",
              property:'length'},
            "Ship Area":{title: "Max ship area in Area of Interest",
              ylab: "Ship Area (meters^2)",
              //property:['area','length']}
              property:['area']}
}
var dropdown= ui.Select({
  items: Object.keys(items),
  value:'Daily Count',
  onChange: daterangeVectors
})
var dropdownLabel=ui.Label("Chart Type:")
var optionPanel = ui.Panel({
  widgets: [dropdownLabel, dropdown, checkbox],
  style: { stretch: "horizontal" },
  layout: ui.Panel.Layout.Flow("horizontal"),
});
var drawButton = ui.Button({
  label: "🔺" + " Draw a Polygon",
  onClick: drawPolygon,
  style: { stretch: "horizontal" },
});
var scaleLabel = ui.Label("Minimum Ship Length: ");
var scaleSlider = ui.Slider({
  min: -10,
  max: 400,
  value: 100,
  step: 10,
  onChange: daterangeVectors,
  style: { width: "50%" },
});
var scalePanel = ui.Panel({
  widgets: [scaleLabel, scaleSlider],
  style: { stretch: "horizontal" },
  layout: ui.Panel.Layout.Flow("horizontal"),
});
var chartPanel = ui.Panel({
  widgets:[
    ui.Label(),
    ui.Label()
    ],
  style: {
    backgroundColor:'#00000000',
    position: "bottom-center",
    width: "600px",
    maxHeight: "300px",
    shown: false
  },
});
var homePanel = ui.Panel({
  widgets: [
    ui.Label("SAR Ship Detection", {
      fontWeight: "bold",
      fontSize: "20px",
    }),
    ui.Label(
      "Though merchant vessels are required by law to broadcast their location and identity, such transponders can be turned off. This tool identifies ships using Synthetic Aperture Radar imagery from the Sentinel-1 satellite. Follow the steps below to monitor shipping activity in an area of interest.",
      { whiteSpace: "wrap" }
    ),
    ui.Label("1. Draw an Area of Interest", {
      fontWeight: "bold",
      fontSize: "15px",
    }),
    ui.Label(
      "Click the button below and draw a polygon on the map to count ships in a given area."
    ), 
    drawButton,
    ui.Label("2. Select a Date Range", {
      fontWeight: "bold",
      fontSize: "15px",
    }),
    ui.Label("Use the date slider below to analyze imagery from a given year."),
    ui.Label(), 
    ui.Label("3. Set Chart Options", {
      fontWeight: "bold",
      fontSize: "15px",
    }),
    scalePanel,
    optionPanel,
  ],
  style: {maxWidth: "400px"},
  layout: ui.Panel.Layout.flow("vertical", true),
});
var start = "2015-01-01";
var now = Date.now();
var end = ee.Date(now).format();
var dateSlider = ui.DateSlider({
  value: "2022-01-01",
  //period: 10000,
  start: start,
  end: now,
  //value:"2022-01-01",
  period:365,
  onChange: daterangeVectors,
  style: { width: "95%" },
});
ui.root.insert(0,homePanel);
Map.add(chartPanel)
homePanel.widgets().set(7, dateSlider);
drawingTools.onDraw(ui.util.debounce(daterangeVectors, 500));
// boxes=ee.FeatureCollection(boxes.geometry().dissolve();)
var lon = ui.url.get("lon", -9999);
var lat = ui.url.get("lat", -9999);
var zoom = ui.url.get("zoom", -9999);
if (lon != -9999 && lat != -9999) {
  Map.setCenter(lon, lat, zoom);
  var initialPoint = ee.Geometry.Point(lon, lat);
  daterangeVectors();
} else {
  // defauilt location
  Map.setCenter(32.327, 31.4532, 10);
  daterangeVectors();
}