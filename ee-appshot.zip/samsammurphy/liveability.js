var precipitation = ui.import && ui.import("precipitation", "image", {
      "id": "OpenLandMap/CLM/CLM_PRECIPITATION_SM2RAIN_M/v01"
    }) || ee.Image("OpenLandMap/CLM/CLM_PRECIPITATION_SM2RAIN_M/v01"),
    temperature = ui.import && ui.import("temperature", "image", {
      "id": "OpenLandMap/CLM/CLM_LST_MOD11A2-DAY_M/v01"
    }) || ee.Image("OpenLandMap/CLM/CLM_LST_MOD11A2-DAY_M/v01"),
    price = ui.import && ui.import("price", "table", {
      "id": "users/samsammurphy/England-annual-price-change-by-local-authority-2019-07"
    }) || ee.FeatureCollection("users/samsammurphy/England-annual-price-change-by-local-authority-2019-07"),
    authorities = ui.import && ui.import("authorities", "table", {
      "id": "users/samsammurphy/uk_local_authorities"
    }) || ee.FeatureCollection("users/samsammurphy/uk_local_authorities");
// global variables
var min_temp = 15   // min. temperature in celsius (avg / year)
var max_temp = 25   // max. temperature in celsius (avg / year)
var min_precip = 40 // min. precipitation in mm (avg / year)
var max_precip = 70 // max. precipitation in mm (avg / year)
// tools
// Remove map layers by name
var removeLayer = function(name) {
  var layers = Map.layers()
  // list of layers names
  var names = []
  layers.forEach(function(lay) {
    var lay_name = lay.getName()
    names.push(lay_name)
  })
  // get index
  var index = names.indexOf(name)
  if (index > -1) {
    // if name in names
    var layer = layers.get(index)
    Map.remove(layer)
  } else {
    //print('Layer '+name+' not found')
  }
}
// UI panel
var panel = ui.Panel({style:{position: 'bottom-right', width:'200px'}});
var min_temp_textbox = ui.Textbox('min. temperature', min_temp, update_layers)
var max_temp_textbox = ui.Textbox('max. temperature', max_temp, update_layers)
var min_precip_textbox = ui.Textbox('min. precipitation', min_precip, update_layers)
var max_precip_textbox = ui.Textbox('max. precipitation', max_precip, update_layers)
Map.add(panel)
panel.add(ui.Label('Min. temperature (oC)'))
panel.add(min_temp_textbox)
panel.add(ui.Label('Max. temperature (oC)'))
panel.add(max_temp_textbox)
panel.add(ui.Label('Min. precipitation (mm)'))
panel.add(min_precip_textbox)
panel.add(ui.Label('Max. precipitation (mm)'))
panel.add(max_precip_textbox)
panel.add(ui.Label(' '))
panel.add(ui.Label('These ranges ^ relate to monthly mean averages from the last decade or two.'))
// Event handler
function update_layers(){
  removeLayer('precipitation')
  removeLayer('temperature')
  removeLayer('liveable')
  min_temp = parseFloat(min_temp_textbox.getValue())
  max_temp = parseFloat(max_temp_textbox.getValue())
  min_precip = parseFloat(min_precip_textbox.getValue())
  max_precip = parseFloat(max_precip_textbox.getValue())
  // temperature (monthly mean in oC)
  var temperature_average = temperature.reduce(ee.Reducer.mean()).multiply(0.02).subtract(273.15)
  var t = temperature_average.updateMask(temperature_average.gt(min_temp)).updateMask(temperature_average.lt(max_temp))
  // precipitation range (monthly total in mm)
  var precipitation_average = precipitation.reduce(ee.Reducer.mean())
  var p = precipitation_average.updateMask(precipitation_average.gt(min_precip)).updateMask(precipitation_average.lt(max_precip))
  // combined masks
  var liveable = p.and(t)
  // add layers
  Map.addLayer(precipitation_average.select('mean'), {min:0, max:200, palette: ['030000', 'A0754C','97F07D','1BF5F0','0D6292', 'FFFFFF']}, 'precipitation')
  Map.addLayer(temperature_average.select('mean'), {min:0, max:40, palette: ['blue', 'green', 'yellow', 'red']}, 'temperature')
  // add masked layers
  // Map.addLayer(p.select('mean'), {min:0, max:200, palette: ['030000', 'A0754C','97F07D','1BF5F0','0D6292', 'FFFFFF']}, 'precipitation masked')
  // Map.addLayer(t.select('mean'), {min:0, max:40, palette: ['blue', 'green', 'yellow', 'red']}, 'temperature masked')
  Map.addLayer(liveable.select('mean'), {min:0, max:1, opacity:0.8, palette: ['white']}, 'liveable')
}
// init
update_layers()