// Tasks:
// 2. Set things up so that if the feature collection is only one fire, 'All Fires' is not added to fire list
// 4. Subset fires by state?
// 5. Add ability to select fire by selecting the polygon on the map?
// 9. Work on descriptive document
ui.root.clear();
//Set map style
var map = ui.Map();
// Get date
var currentdate = new Date();
var today = new Date().toISOString().slice(0, 10);
//print(today);
//////////////////// Parameters for Input Defaults /////////////////////////////////////////////
// Make changes to default settings on lines marked with '***'
// Maximum cloud percent
var max_cloud_percent_initial = '20';     // *** default
var max_cloud_percent = ee.Number.parse(max_cloud_percent_initial);
// Display setting options
var display_clipped = 'Clip to fire perimeter';
var display_buffered = 'Clip to bounds buffer';
var selected_display_preference = display_clipped;  // *** default
// Buffer bounds distance
var buffer_meters_initial = '60';   // *** default
var bounds_buffer_meters = ee.Number.parse(buffer_meters_initial);
// preNBR dates
var preNBR_start_date = '2018-06-01';   // *** default
var preNBR_stop_date = '2018-09-30';    // *** default
// postNBR dates
var postNBR_start_date = '2019-06-01';   // *** default
var postNBR_stop_date = '2019-10-31';    // *** default
// RGB true-color imagery dates
var RGB_start_date = postNBR_start_date;   // *** default
var RGB_stop_date = postNBR_stop_date;     // *** default
// postNBR statistic settings
var percentile_text = 'Percentile (current fires)';
var median_text = 'Median (historic fires)';
var selected_statistic = percentile_text;       // *** default
// PostNBR percentile for assessing current year fires
var s2_postNBR_percentile = '17.5';    // *** default
var l8_postNBR_percentile = '6.0';     // *** default
var l457_postNBR_percentile = '6.0';   // *** default
// Fire Perimeter Feature Collection ID
var fire_fc_id = 'projects/USFS/R6-FirePerimeters/perimeters-dd83-GeoMAC-2019'; // *** default
// Fire name field and title
var fire_name_field = 'INCIDENTNA';         // *** default
/////////////////// Other parameters ///////////////////////////////////////////
// Preferred imagery checkboxes defaults
// (left panel - sets which preferred imagery checkboxes are initially turned on)
var S2_preferred_default = true;
var L8_preferred_default = true;
var L457_preferred_default = false;
// Settings checkboxes defaults 
// (left panel - sets which settings panel checkboxes are initially turned on)
var ckbx_settings_default = false;
var ckbx_imagery_dates_default = true;
var ckbx_other_settings_default = false;
var ckbx_RGB_dates_to_postNBR_default = true;
// Raster display checkbox defaults
// (right panel - sets which imagery product check boxes are initially turned on)
// L457 RGB
var ckbx_RGB_L457_default = false;
// L8 RGB
var ckbx_RGB_L8_default = false;
// S2 RGB
var ckbx_RGB_s2_default = true;
// L457 products
var ckbx_pre_nbr_L457_default = false;
var ckbx_post_nbr_L457_default = false;
var ckbx_ba7_L457_default = false;
// L8 products
var ckbx_pre_nbr_L8_default = false;
var ckbx_post_nbr_L8_default = false;
var ckbx_ba7_L8_default = false;
// S2 products
var ckbx_pre_nbr_s2_default = false;
var ckbx_post_nbr_s2_default = false;
var ckbx_ba7_s2_default = true;
// Checkbox and slider map layer references (sync to drawing order)
var RGB_L457_mapLayer = 0;
var RGB_L8_mapLayer = 1;
var RGB_S2_mapLayer = 2;
var L457_preNBR_mapLayer = 3;
var L457_postNBR_mapLayer = 4;
var L457_BA7_mapLayer = 5;
var L8_preNBR_mapLayer = 6;
var L8_postNBR_mapLayer = 7;
var L8_BA7_mapLayer = 8;
var S2_preNBR_mapLayer = 9;
var S2_postNBR_mapLayer = 10;
var S2_BA7_mapLayer = 11;
var allFires_mapLayer = 12;
var selectedFire_mapLayer = 13;
// Set default NBR opacity
var nbr_opacity = 0.5;
// Variables for date lists
var post_date_items_s2;
var post_date_items_l8;
var post_date_items_l457;
// All fires text
var all_fires_text = 'All fires';
// Current fire
var current_fire = all_fires_text;
// Set colors for palettes
// Button color
var button_color = '66ff33';
// pre and post NBR
var brown = '96572a';
var tan = 'ffefd5';
var drkgreen = '008b45';
var pal_nbr = [brown, tan, drkgreen];
var pal_nbr_classified = [tan, drkgreen];
// rdNBR
var blue = '00afff';
var yellow = 'ffff00';
var red = 'ff0000';
var pal_dnbr_rdnbr = [blue, yellow, red];
// NSO and LSR
var nso_color = 'ffb400';
var lsr_color = '00b200';
// 7 class 
var class_blue = '0000ff';
var class_cyan = '00ffff';
var class_green1 = '006400';
var class_green2 = '00ff00';
var class_yellow = 'ffff00';
var class_orange = 'ffa500';
var class_red = 'ff0000';
var class_4color = [class_blue, class_cyan, class_yellow, class_red];
var class_7color = [class_blue, class_cyan, class_green1, class_green2, class_yellow, class_orange, class_red];
// Settings panels
var set_pnl_clr_0 = '00264d'; // dark blue
var set_pnl_clr = 'cce6ff';
///////////////////////////////////////// Panels //////////////////////////////////////////////////////
// Left panel style
var left_panel_style = {
  width: '250px'
};
// Right panel style
var right_panel_style = {
  width: '300px'
};
// Setting sub panel style
var set_sub_panel_style = {
  width: '225px',
  margin: '1px solid grey',
  backgroundColor: set_pnl_clr,
  color: set_pnl_clr_0
};
// // Loading panel to show when layers are loading
// var panel_loading = ui.Panel({style: {position: 'top-center', shown: false}});
// var loading = ui.Label('Loading...', {
//   margin: '2px 0px 4px 0px',
//   fontSize: '14px',
//   color: 'grey'
// });
// panel_loading.add(loading);
// // Add loading panel to map
// map.add(panel_loading);
// Left main panel
var panel = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: left_panel_style});
// Left sub panels
var panel_warning = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    width: '250px',
    backgroundColor: 'ff9966',
  }
});
var panel_imageryType = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: left_panel_style});
var panel_fire_checkbox = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: left_panel_style});
// Right main panel
var panel_raster = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: right_panel_style});
// Right sub panels
var panel_s2_products = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: right_panel_style});
var panel_l8_products = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: right_panel_style});
var panel_l457_products = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: right_panel_style});
var raster_imagery = ui.Panel({layout: ui.Panel.Layout.flow('vertical'),style: right_panel_style});
// Settings panel
var panel_settings = ui.Panel({
  layout: ui.Panel.Layout.flow('horizontal'),
  style: {
    position: 'top-left',
    padding: '4px', 
    backgroundColor: set_pnl_clr_0
  }
});
// Settings sub panels
var panel_dates = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: set_sub_panel_style});
var panel_other_settings = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: set_sub_panel_style});
// Panel for panel_dates
var panel_NBR_date = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: set_sub_panel_style});
var panel_RGB_date = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: set_sub_panel_style});
var panel_statistic = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: set_sub_panel_style});
// Panels for panel_other_settings
var panel_buffer_distance = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: set_sub_panel_style});
var panel_display_preference = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: set_sub_panel_style});
var panel_params_fc = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: set_sub_panel_style});
var panel_max_cloud = ui.Panel({layout: ui.Panel.Layout.flow('vertical'), style: set_sub_panel_style});
// Legend panel
var legend = ui.Panel({style: {position: 'bottom-right', padding: '4px 8px'}});
// Add panel and map to root
ui.root.add(panel).add(map);
// Add legend to map
map.add(legend);
// Create visualization for NBR products
//var vis_continuous = {palette: class_color};
var vis_nbr_classified = {min: 1, max: 2, palette: pal_nbr_classified};
//var vis_rdnbr = {min: 0, max: 1.30, palette: class_color};
var vis_ba4_class = {min: 1, max: 4, palette: class_4color};
var vis_ba7_class = {min: 1, max: 7, palette: class_7color};
// Water mask
var jrc = ee.Image('JRC/GSW1_0/GlobalSurfaceWater');
var jrc_unmask = jrc.unmask();
var jrc_max_extent = jrc_unmask.select('max_extent');
var jrc_land = jrc_max_extent.eq(0);
////////////////////////////// Layers ////////////////////////////////////
// Layer 1a: Load fire perimeter layer
// Global variables
var selectedFire = { 'label': '', 'fc': ''};
var allFires = {'label': '', 'fc': ''};
//var fires2017 = {'label': '', 'fc': ''};
var fire_buff = {'label': '', 'fc': ''};
var selectedFire_pal = 'ffa500';
var allFires_pal = '000000';
//var fires2017_pal = 'FFFF00';
var selectedFire_on = true;
var allFires_on = true;
// Function for drawing fire perimeters
var drawFirePerim = function(fire, pallette, off_on) {
  // Paint all the polygon edges with the same number and width, display.
  var empty = ee.Image().byte();
  var painted = empty.paint({
    featureCollection: fire.fc,
    color: 1,
    width: 1.25
  });
  map.addLayer(painted, {palette: pallette}, fire.label, off_on);
};
//drawFirePerim(selectedFire, selectedFire_pal, selectedFire_on)
//drawFirePerim(allFires, allFires_pal, allFires_on)
//drawFirePerim(fires2017, fires2017_pal, fires2017_on)
// Add fire perimeter layer feature collection
var fire_perim = ee.FeatureCollection(fire_fc_id);
selectedFire.label = all_fires_text;
selectedFire.fc = fire_perim;
allFires.label = all_fires_text;
allFires.fc = fire_perim;
print(fire_perim);
var fireCount = fire_perim.size();
print('Number of Fires: ', fireCount);
/////////////////////// Sentinel imagery functions ////////////////////////
// Sentinel2 cloud mask function using the Sentinel-2 QA band.
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = ee.Number(2).pow(10).int();
  var cirrusBitMask = ee.Number(2).pow(11).int();
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0).and(
             qa.bitwiseAnd(cirrusBitMask).eq(0));
  // Return the masked and scaled data, without the QA bands.
  return image.updateMask(mask).divide(10000)
      .select("B.*")
      .copyProperties(image, ["system:time_start"]);
}
// Function to get Sentinel imagery for background map
var getRGB_sentinel2 = function(start_date, stop_date) {
  var RGB_col_sentinel2 = ee.ImageCollection('COPERNICUS/S2')
    .filterDate(start_date, stop_date)
    // Pre-filter to get less cloudy imagery
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', max_cloud_percent))
    // Cloud mask
    .map(maskS2clouds);
  var RGB_col_sentinel2_median = RGB_col_sentinel2.median();
  return RGB_col_sentinel2_median;
};
/////////////////////// Landsat 8 imagery functions //////////////////////////
// Landsat 8 cloud mask function using the Landsat 8 QA band to mask clouds.
var maskL8 = function(image) {
  var qa = image.select('BQA');
  /// Check that the cloud bit is off.
  // See https://landsat.usgs.gov/collectionqualityband
  var mask = qa.bitwiseAnd(1 << 4).eq(0);
  return image.updateMask(mask);
};
// Function to get landsat 8 imagery for background map
var getRGB_landsat8 = function(start_date, stop_date) {
  var RGB_col_L8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA')
    .filterDate(start_date, stop_date)
    // Pre-filter to get less cloudy imagery
    .filter(ee.Filter.lt('CLOUD_COVER_LAND', max_cloud_percent))
    // Cloud mask
    .map(maskL8);
  var RGB_col_L8_median = RGB_col_L8.median();
  return RGB_col_L8_median;
};
///////////////////////// Landsat 457 imagery functions /////////////////////////////
//Landsat 4, 5 or 7 cloud mask function using the surface reflectance QA band to mask clouds.
var cloudMaskL457 = function(image) {
  var qa = image.select('pixel_qa');
  // If the cloud bit (5) is set and the cloud confidence (7) is high
  // or the cloud shadow bit is set (3), then it's a bad pixel.
  var cloud = qa.bitwiseAnd(1 << 5)
          .and(qa.bitwiseAnd(1 << 7))
          .or(qa.bitwiseAnd(1 << 3))
  // Remove edge pixels that don't occur in all bands
  var mask2 = image.mask().reduce(ee.Reducer.min());
  return image.updateMask(cloud.not()).updateMask(mask2);
};
// Function to get landsat 4, 5, 7 imagery for background map
var getRGB_landsat457 = function(start_date, stop_date) {
  var L4coll = ee.ImageCollection('LANDSAT/LT04/C01/T1_SR')
    .filterDate(start_date, stop_date)
    // Pre-filter to get less cloudy imagery
    .filter(ee.Filter.lt('CLOUD_COVER', max_cloud_percent))
    // Cloud mask
    .map(cloudMaskL457);
  var L5coll = ee.ImageCollection('LANDSAT/LT05/C01/T1_SR')
    .filterDate(start_date, stop_date)
    // Pre-filter to get less cloudy imagery
    .filter(ee.Filter.lt('CLOUD_COVER', max_cloud_percent))
    // Cloud mask
    .map(cloudMaskL457);
  var L7coll = ee.ImageCollection('LANDSAT/LE07/C01/T1_SR')
    .filterDate(start_date, stop_date)
    // Pre-filter to get less cloudy imagery
    .filter(ee.Filter.lt('CLOUD_COVER', max_cloud_percent))
    // Cloud mask
    .map(cloudMaskL457);
  // Merge collections into a single collection
  var L457coll = ee.ImageCollection(L4coll.merge(L5coll.merge(L7coll)));
  var L457_median = L457coll.median();
  return L457_median;
};
 ///////////////////////////////////////////////////////////////////////////
// Projection for export NBR products
var wkt = 'PROJCS["NAD_1983_Oregon_Washington_Albers",GEOGCS["GCS_North_American_1983",DATUM["D_North_American_1983",SPHEROID["GRS_1980",6378137.0,298.257222101]],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]],PROJECTION["Albers"],PARAMETER["false_easting",600000.0],PARAMETER["false_northing",0.0],PARAMETER["central_meridian",-120.0],PARAMETER["standard_parallel_1",43.0],PARAMETER["standard_parallel_2",48.0],PARAMETER["latitude_of_origin",34.0],UNIT["Meter",1.0]]';
var waor_albers = ee.Projection(wkt);
/////////////////////////// Build unique list function
var build_unique_list = function(collection,  attribute) {
  var list = ee.Dictionary(collection.aggregate_histogram(attribute)).keys();
  return attribute.map(function(name) {
    return ee.Dictionary({'label': name, 'value': name});
  }).getInfo();
};
//////////////////////////// Buffer function //////////////////////////////////////
var bufferBy = function(size) {
  return function(feature){
    return feature.buffer(size);
  };
};
//////////////////////////// Threshold function /////////////////////////////////////
var classifyByThreshold = function(image, thresholds) {
  var classes = [];
  var N = thresholds.length;
  var img = image.clamp(thresholds[0], thresholds[N-1]);
  for (var i = 0; i < thresholds.length-1; i++) {
    var c = image.gte(thresholds[i]).and(image.lt(thresholds[i+1])).multiply(i+1).byte();
    classes.push(c);
  }
  return ee.ImageCollection(classes).sum().rename('magnitudeCls').byte();
};
///////////////////////////// Legend function to create legend rows ////////////////////
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '5px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {
          margin: '0 0 4px 6px',
          fontSize: '10px'
        }
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//////////////////////// Function to create checkboxes ///////////////////
// Make checkbox function
var make_ckbx = function(name, visible, buff) {
  var checkbox = ui.Checkbox({
    label: name,
    value: visible, 
    style: {
      padding: buff,
    }
  });
  return checkbox;
};
// Variable for checkbox padding
var ckbx_buff = '6px';
/////////////////////////// Function to create labels ///////////////////////
var make_label = function(name, fntSize, mrgin, pad, weight, align) {
  var label = ui.Label(name);
  label.style().set({
    fontSize: fntSize,
    margin: mrgin,
    padding: pad,
    stretch: 'both',
    fontWeight: weight,
    textAlign: align
  });
  return label;
};
// Checkbox styles
var style_enabled = {
  //border: '1px solid black',
  color: 'black',
  //padding: ckbx_buff,
  margin: '3px 3px 3px 20px'        // top, right, bottom, left
};
////////////////////////////// Imagery type checkboxes //////////////////////
var style_preferred = {
  color: 'black',
  margin: '3px 0px 3px 20px'        // top, right, bottom, left
};
// Style for text (small grey text)
var date_availability_style = {
  color: 'grey',
  fontSize: '12px',
  margin: '1px 0px 1px 20px',
};
// Select imagery type label
var imageryType_label = make_label('Preferred imagery:', '14px', '', '15px 3px 3px 10px', 'bold', '');    // top, right, bottom, left
// Imagery type check boxes
// Sentinel 2 checkbox
var ckbx_s2 = ui.Checkbox({  
  label: 'Sentinel - 2',
  value: S2_preferred_default,
  style: style_preferred
});
// Landsat 8 checkbox
var ckbx_l8 = ui.Checkbox({
  label: 'Landsat - 8',
  value: L8_preferred_default,
  style: style_preferred,
});
// Landsat 457 checkbox
var ckbx_l457 = ui.Checkbox({
  label: 'Landsat - 4, 5, 7',
  value: L457_preferred_default,
  style: style_preferred,
});
// Imagery availability dates
var S2_date_text = ui.Label('S2: 6-29-2015 to present', date_availability_style);
var L8_date_text = ui.Label('L8: 4-11-2013 to present', date_availability_style);
var L7_date_text = ui.Label('L7: 4-15-1999 to present', date_availability_style);
var L5_date_text = ui.Label('L5: 3-1-1984 to 11-30-2011', date_availability_style);
var L4_date_text = ui.Label('L4: 7-16-1982 to 12-14-1993', date_availability_style);
// Add widgets to imagery type panel
panel_imageryType.widgets().add(imageryType_label);
panel_imageryType.widgets().add(ckbx_s2);
panel_imageryType.widgets().add(ckbx_l8);
panel_imageryType.widgets().add(ckbx_l457);
panel_imageryType.widgets().add(S2_date_text);
panel_imageryType.widgets().add(L8_date_text);
panel_imageryType.widgets().add(L7_date_text);
panel_imageryType.widgets().add(L5_date_text);
panel_imageryType.widgets().add(L4_date_text);
// Imagery type check box bahavior function
var imagery_type_function = function(s2_check, l8_check, l457_check) {
  // Initial setup
  panel_raster.remove(panel_s2_products);
  panel_raster.remove(panel_l8_products);
  panel_raster.remove(panel_l457_products);
  panel_raster.remove(raster_imagery);
  raster_imagery.remove(ckbx_RGB_s2);
  raster_imagery.remove(ckbx_RGB_L8);
  raster_imagery.remove(ckbx_RGB_L457);
  if (s2_check === true ) {
    panel_raster.widgets().add(panel_s2_products);
    raster_imagery.widgets().add(ckbx_RGB_s2);
  }
  if (l8_check === true) {
    panel_raster.widgets().add(panel_l8_products);
    raster_imagery.widgets().add(ckbx_RGB_L8);
  }
  if (l457_check === true) {
    panel_raster.widgets().add(panel_l457_products);
    raster_imagery.widgets().add(ckbx_RGB_L457);
  }  
  panel_raster.widgets().add(raster_imagery);
  if (s2_check === false && l8_check === false && l457_check === false) {
    panel_raster.remove(raster_imagery);
  }
};
ckbx_s2.onChange(function(checked){
  var s2_check = ckbx_s2.getValue();
  var l8_check = ckbx_l8.getValue();
  var l457_check = ckbx_l457.getValue();
  imagery_type_function(s2_check, l8_check, l457_check);
});
ckbx_l8.onChange(function(checked){
  var s2_check = ckbx_s2.getValue();
  var l8_check = ckbx_l8.getValue();
  var l457_check = ckbx_l457.getValue();
  imagery_type_function(s2_check, l8_check, l457_check);
});
ckbx_l457.onChange(function(checked){
  var s2_check = ckbx_s2.getValue();
  var l8_check = ckbx_l8.getValue();
  var l457_check = ckbx_l457.getValue();
  imagery_type_function(s2_check, l8_check, l457_check);
});
//////////////////////// Fire perimeter check boxes /////////////////////////////////
// Fire perimeter checkboxes label
var label_ckbx = make_label('Fire perimeter layers: ', '14px', '', '15px 3px 3px 10px', 'bold', '');
// Polygon check boxes
// Fire perimeter selected fire (initially all fires)
var ckbx_fireperim = ui.Checkbox({  
  label: current_fire,
  value: true,
  style: style_enabled
});
// All fire perimeters
var ckbx_allFires = ui.Checkbox({
  label: all_fires_text,
  value: true,
  style: style_enabled,
});
// Add fire perimeter checkboxes to fire checkboxes panel
panel_fire_checkbox.widgets().add(label_ckbx);
panel_fire_checkbox.widgets().add(ckbx_fireperim);
// Function to set vector layer checkbox locations on panel
var allfire_set = '';
var fireperim_set = '';
var boxes_set = function(set_ckbx) {
  if (set_ckbx == 'all_fires'){
    fireperim_set = 0;
  }
  else if (set_ckbx == 'selected_fire') {
    fireperim_set = selectedFire_mapLayer;
    allfire_set = allFires_mapLayer;
  }
};
var set_ckbx = 'all_fires';
// Set drawn map layer for fire perim, nso, and lsr checkboxes
boxes_set(set_ckbx);
ckbx_fireperim.onChange(function(checked) {
  map.layers().get(fireperim_set).setShown(checked);
});
ckbx_allFires.onChange(function(checked) {
  map.layers().get(allfire_set).setShown(checked);
});
// Settings panel checkbox
var ckbx_settings = ui.Checkbox({  
  label: 'View Settings Panel',
  value: ckbx_settings_default,
  onChange: function(checked){
    var settings_check = ckbx_settings.getValue();
    if (settings_check === true) {
      map.add(panel_settings);
    }
    else if (settings_check === false) {
      map.remove(panel_settings);
    }
  },
  style: {
    color: 'black',
    fontWeight: 'bold',
    margin: '25px 3px 3px 10px'
  }
});
// Sub-settings checkbox behavior
// Imagery type check box bahavior function
var setting_checkbox_show = function(checked) {
  var dates_check = ckbx_imagery_dates.getValue();
  var other_settings_check = ckbx_other_settings.getValue();
  // Initial setup (remove panels)
  panel_settings.remove(panel_dates);
  panel_settings.remove(panel_other_settings);
  // Add back panels that are checked
  if (dates_check === true) {
    panel_settings.widgets().add(panel_dates);
  }
  if (other_settings_check === true) {
    panel_settings.widgets().add(panel_other_settings);
  }
};
// Imagery dates checkbox
var ckbx_imagery_dates = ui.Checkbox({  
  label: 'Imagery dates',
  value: ckbx_imagery_dates_default,
  onChange: setting_checkbox_show,
  style: style_preferred
});
// Other settings checkbox
var ckbx_other_settings = ui.Checkbox({
  label: 'Other settings',
  value: ckbx_other_settings_default,
  onChange: setting_checkbox_show,
  style: style_preferred
});
var style_enabled = {
  //border: '1px solid black',
  color: 'black',
  //padding: ckbx_buff,
  margin: '3px 3px 3px 20px'        // top, right, bottom, left
};
//////////////////////// Function to add/remove widget(s) to legend //////////////////////////////
var add_widgets = function(widget_items) {
  var items_length = widget_items.length;
  for (var i = 0; i < items_length; i++) {
    legend.add(widget_items[i]);
  }
};
var remove_widgets = function(widget_items) {
  var items_length = widget_items.length;
  for (var i = 0; i < items_length; i++) {
    legend.remove(widget_items[i]);
  }
};
//////////////////////////// Raster check boxes ///////////////////////////////////////////////
// Sentinel checkboxes label
var label_raster_s2 = make_label('Sentinel products:', '14px', '', '15px 3px 0px 3px', 'bold', '');
// Make Sentinel checkboxes
var ckbx_ba7_s2 = make_ckbx('S2 - BA 7', ckbx_ba7_s2_default, ckbx_buff);             // BA loss 7 class
var ckbx_post_nbr_s2 = make_ckbx('S2 - post NBR', ckbx_post_nbr_s2_default, ckbx_buff);       // post-NBR
var ckbx_pre_nbr_s2 = make_ckbx('S2 - pre NBR', ckbx_pre_nbr_s2_default, ckbx_buff);         // pre-NBR
// List of Sentinel checkboxes with sliders
var ckbx_list_s2 = [ckbx_ba7_s2, ckbx_post_nbr_s2, ckbx_pre_nbr_s2];
// Landsat 8 checkboxes label
var label_raster_L8 = make_label('Landsat 8 products:', '14px', '', '15px 3px 0px 3px', 'bold', '');
// Make Landsat 8 checkboxes
var ckbx_ba7_L8 = make_ckbx('L8 - BA 7', ckbx_ba7_L8_default, ckbx_buff);          // BA loss 7 class
var ckbx_post_nbr_L8 = make_ckbx('L8 - post NBR', ckbx_post_nbr_L8_default, ckbx_buff);       // post-NBR
var ckbx_pre_nbr_L8 = make_ckbx('L8 - pre NBR', ckbx_pre_nbr_L8_default, ckbx_buff);         // pre-NBR
// List of Landsat 8 checkboxes with sliders
var ckbx_list_L8 = [ckbx_ba7_L8, ckbx_post_nbr_L8, ckbx_pre_nbr_L8];
// Landsat 457 checkboxes label
var label_raster_L457 = make_label('Landsat 4, 5, 7 products:', '14px', '', '15px 3px 0px 3px', 'bold', '');
// Make Landsat 457 checkboxes
var ckbx_ba7_L457 = make_ckbx('L457 - BA 7', ckbx_ba7_L457_default, ckbx_buff);          // BA loss 7 class
var ckbx_post_nbr_L457 = make_ckbx('L457 - post NBR', ckbx_post_nbr_L457_default, ckbx_buff);       // post-NBR
var ckbx_pre_nbr_L457 = make_ckbx('L457 - pre NBR', ckbx_pre_nbr_L457_default, ckbx_buff);         // pre-NBR
// List of Landsat 457 checkboxes with sliders
var ckbx_list_L457 = [ckbx_ba7_L457, ckbx_post_nbr_L457, ckbx_pre_nbr_L457];
// Imagery checkboxes label
var label_imagery = make_label('Imagery:', '14px', '', '15px 3px 0px 3px', 'bold', '');
// Make imagery checkboxes
var ckbx_RGB_s2 = make_ckbx('Sentinel 2 true-color image', ckbx_RGB_s2_default, ckbx_buff); // RGB
var ckbx_RGB_L8 = make_ckbx('Landsat 8 true-color image', ckbx_RGB_L8_default, ckbx_buff); // RGB
var ckbx_RGB_L457 = make_ckbx('Landsat 4, 5, 7 true-color image', ckbx_RGB_L457_default, ckbx_buff); // RGB
///////////////////// Raster checkbox behavior /////////////////////////////////
// BA 7 classes
var legendTitle_ba_7class = make_label('...BA loss - 7 classes', '10px', '0 0 4px 0', '4px', 'bold', 'left');
// BA 7 classes legend rows
var ba7_1 = makeRow(class_blue, '0% BA mortality');
var ba7_2 = makeRow(class_cyan, '1 - 10% BA mortality');
var ba7_3 = makeRow(class_green1, '11 - 25% BA mortality');
var ba7_4 = makeRow(class_green2, '25 - 50% BA mortality');
var ba7_5 = makeRow(class_yellow, '50 - 75% BA mortality');
var ba7_6 = makeRow(class_orange, '75 - 90% BA mortality');
var ba7_7 = makeRow(class_red, 'BA mortality > 90%');
var ba7_legend_items = [legendTitle_ba_7class, ba7_1, ba7_2, ba7_3, ba7_4, ba7_5, ba7_6, ba7_7];
// Make legend item appear/disappear from legend with checkbox setting
ckbx_ba7_s2.onChange(function(checked) {map.layers().get(S2_BA7_mapLayer).setShown(checked);
  var ba7_check = ckbx_ba7_s2.getValue();
  var ba7_L8_check = ckbx_ba7_L8.getValue();
  var ba7_L457_check = ckbx_ba7_L457.getValue();
    if (ba7_check === true || ba7_L8_check === true || ba7_L457_check === true) {
    remove_widgets(ba7_legend_items);
    add_widgets(ba7_legend_items);
  }
  else if (ba7_check === false && ba7_L8_check === false || ba7_L457_check === false) {
    remove_widgets(ba7_legend_items);
  }
});
ckbx_ba7_L8.onChange(function(checked) {map.layers().get(L8_BA7_mapLayer).setShown(checked);
  var ba7_check = ckbx_ba7_s2.getValue();
  var ba7_L8_check = ckbx_ba7_L8.getValue();
  var ba7_L457_check = ckbx_ba7_L457.getValue();
    if (ba7_check === true || ba7_L8_check === true || ba7_L457_check === true) {
    remove_widgets(ba7_legend_items);
    add_widgets(ba7_legend_items);
  }
  else if (ba7_check === false && ba7_L8_check === false || ba7_L457_check === false) {
    remove_widgets(ba7_legend_items);
  }
});
ckbx_ba7_L457.onChange(function(checked) {map.layers().get(L457_BA7_mapLayer).setShown(checked);
  var ba7_check = ckbx_ba7_s2.getValue();
  var ba7_L8_check = ckbx_ba7_L8.getValue();
  var ba7_L457_check = ckbx_ba7_L457.getValue();
    if (ba7_check === true || ba7_L8_check === true || ba7_L457_check === true) {
    remove_widgets(ba7_legend_items);
    add_widgets(ba7_legend_items);
  }
  else if (ba7_check === false && ba7_L8_check === false || ba7_L457_check === false) {
    remove_widgets(ba7_legend_items);
  }
});
// pre and post-nbr legend label
var legendTitle_nbr = make_label('...pre-NBR / post-NBR', '10px', '0 0 4px 6px', '4px', 'bold', 'left');
// pre and post-nbr legend rows
var nbr_low = makeRow(tan, 'Sparse canopy / burned');
var nbr_high = makeRow(drkgreen, 'High canopy / healthy vegetation');
// pre and post-nbr legend items list
var nbr_legend_items = [legendTitle_nbr, nbr_low, nbr_high];
// post-NBR make legend item appear/disappear from legend with checkbox setting
ckbx_post_nbr_s2.onChange(function(checked) {map.layers().get(S2_postNBR_mapLayer).setShown(checked);
// Make legend item appear/disappear from legend with checkbox setting
  var prenbr_s2_check = ckbx_pre_nbr_s2.getValue();
  var postnbr_s2_check = ckbx_post_nbr_s2.getValue();
  var prenbr_L8_check = ckbx_pre_nbr_L8.getValue();
  var postnbr_L8_check = ckbx_post_nbr_L8.getValue();
  var prenbr_L457_check = ckbx_pre_nbr_L457.getValue();
  var postnbr_L457_check = ckbx_post_nbr_L457.getValue();
  if (prenbr_s2_check === true || postnbr_s2_check === true || prenbr_L8_check === true || postnbr_L8_check === true || prenbr_L457_check === true || postnbr_L457_check === true) {
    remove_widgets(nbr_legend_items);
    add_widgets(nbr_legend_items);
  }
  else if (prenbr_s2_check === false && postnbr_s2_check === false && prenbr_L8_check === false && postnbr_L8_check === false && prenbr_L457_check === false && postnbr_L457_check === false) {
    remove_widgets(nbr_legend_items);
  }
});
ckbx_post_nbr_L8.onChange(function(checked) {map.layers().get(L8_postNBR_mapLayer).setShown(checked);
// Make legend item appear/disappear from legend with checkbox setting
  var prenbr_s2_check = ckbx_pre_nbr_s2.getValue();
  var postnbr_s2_check = ckbx_post_nbr_s2.getValue();
  var prenbr_L8_check = ckbx_pre_nbr_L8.getValue();
  var postnbr_L8_check = ckbx_post_nbr_L8.getValue();
  var prenbr_L457_check = ckbx_pre_nbr_L457.getValue();
  var postnbr_L457_check = ckbx_post_nbr_L457.getValue();
  if (prenbr_s2_check === true || postnbr_s2_check === true || prenbr_L8_check === true || postnbr_L8_check === true || prenbr_L457_check === true || postnbr_L457_check === true) {
    remove_widgets(nbr_legend_items);
    add_widgets(nbr_legend_items);
  }
  else if (prenbr_s2_check === false && postnbr_s2_check === false && prenbr_L8_check === false && postnbr_L8_check === false && prenbr_L457_check === false && postnbr_L457_check === false) {
    remove_widgets(nbr_legend_items);
  }
});
ckbx_post_nbr_L457.onChange(function(checked) {map.layers().get(L457_postNBR_mapLayer).setShown(checked);
// Make legend item appear/disappear from legend with checkbox setting
  var prenbr_s2_check = ckbx_pre_nbr_s2.getValue();
  var postnbr_s2_check = ckbx_post_nbr_s2.getValue();
  var prenbr_L8_check = ckbx_pre_nbr_L8.getValue();
  var postnbr_L8_check = ckbx_post_nbr_L8.getValue();
  var prenbr_L457_check = ckbx_pre_nbr_L457.getValue();
  var postnbr_L457_check = ckbx_post_nbr_L457.getValue();
  if (prenbr_s2_check === true || postnbr_s2_check === true || prenbr_L8_check === true || postnbr_L8_check === true || prenbr_L457_check === true || postnbr_L457_check === true) {
    remove_widgets(nbr_legend_items);
    add_widgets(nbr_legend_items);
  }
  else if (prenbr_s2_check === false && postnbr_s2_check === false && prenbr_L8_check === false && postnbr_L8_check === false && prenbr_L457_check === false && postnbr_L457_check === false) {
    remove_widgets(nbr_legend_items);
  }
});
// pre nbr make legend item appear/disappear from legend with checkbox setting
ckbx_pre_nbr_s2.onChange(function(checked) {map.layers().get(S2_preNBR_mapLayer).setShown(checked);
// Make legend item appear/disappear from legend with checkbox setting
  var prenbr_s2_check = ckbx_pre_nbr_s2.getValue();
  var postnbr_s2_check = ckbx_post_nbr_s2.getValue();
  var prenbr_L8_check = ckbx_pre_nbr_L8.getValue();
  var postnbr_L8_check = ckbx_post_nbr_L8.getValue();
  var prenbr_L457_check = ckbx_pre_nbr_L457.getValue();
  var postnbr_L457_check = ckbx_post_nbr_L457.getValue();
  if (prenbr_s2_check === true || postnbr_s2_check === true || prenbr_L8_check === true || postnbr_L8_check === true || prenbr_L457_check === true || postnbr_L457_check === true) {
    remove_widgets(nbr_legend_items);
    add_widgets(nbr_legend_items);
  }
  else if (prenbr_s2_check === false && postnbr_s2_check === false && prenbr_L8_check === false && postnbr_L8_check === false && prenbr_L457_check === false && postnbr_L457_check === false) {
    remove_widgets(nbr_legend_items);
  }
});
ckbx_pre_nbr_L8.onChange(function(checked) {map.layers().get(L8_preNBR_mapLayer).setShown(checked);
// Make legend item appear/disappear from legend with checkbox setting
  var prenbr_s2_check = ckbx_pre_nbr_s2.getValue();
  var postnbr_s2_check = ckbx_post_nbr_s2.getValue();
  var prenbr_L8_check = ckbx_pre_nbr_L8.getValue();
  var postnbr_L8_check = ckbx_post_nbr_L8.getValue();
  var prenbr_L457_check = ckbx_pre_nbr_L457.getValue();
  var postnbr_L457_check = ckbx_post_nbr_L457.getValue();
  if (prenbr_s2_check === true || postnbr_s2_check === true || prenbr_L8_check === true || postnbr_L8_check === true || prenbr_L457_check === true || postnbr_L457_check === true) {
    remove_widgets(nbr_legend_items);
    add_widgets(nbr_legend_items);
  }
  else if (prenbr_s2_check === false && postnbr_s2_check === false && prenbr_L8_check === false && postnbr_L8_check === false && prenbr_L457_check === false && postnbr_L457_check === false) {
    remove_widgets(nbr_legend_items);
  }
});
ckbx_pre_nbr_L457.onChange(function(checked) {map.layers().get(L457_preNBR_mapLayer).setShown(checked);
// Make legend item appear/disappear from legend with checkbox setting
  var prenbr_s2_check = ckbx_pre_nbr_s2.getValue();
  var postnbr_s2_check = ckbx_post_nbr_s2.getValue();
  var prenbr_L8_check = ckbx_pre_nbr_L8.getValue();
  var postnbr_L8_check = ckbx_post_nbr_L8.getValue();
  var prenbr_L457_check = ckbx_pre_nbr_L457.getValue();
  var postnbr_L457_check = ckbx_post_nbr_L457.getValue();
  if (prenbr_s2_check === true || postnbr_s2_check === true || prenbr_L8_check === true || postnbr_L8_check === true || prenbr_L457_check === true || postnbr_L457_check === true) {
    remove_widgets(nbr_legend_items);
    add_widgets(nbr_legend_items);
  }
  else if (prenbr_s2_check === false && postnbr_s2_check === false && prenbr_L8_check === false && postnbr_L8_check === false && prenbr_L457_check === false && postnbr_L457_check === false) {
    remove_widgets(nbr_legend_items);
  }
});
// RGB (no legend)
ckbx_RGB_s2.onChange(function(checked) {map.layers().get(RGB_S2_mapLayer).setShown(checked);});
// RGB Landsat 8 (no legend)
ckbx_RGB_L8.onChange(function(checked) {map.layers().get(RGB_L8_mapLayer).setShown(checked);});
// RGB Landsat 457 (no legend)
ckbx_RGB_L457.onChange(function(checked) {map.layers().get(RGB_L457_mapLayer).setShown(checked);});
/////////////////////////// Raster sliders ///////////////////////////////////////
// Sentinel sliders
var slider_ba7_s2 = ui.Slider();
slider_ba7_s2.setValue(nbr_opacity);
var slider_post_nbr_s2 = ui.Slider();
slider_post_nbr_s2.setValue(nbr_opacity);
var slider_pre_nbr_s2 = ui.Slider();
slider_pre_nbr_s2.setValue(nbr_opacity);
// Slider properties
slider_ba7_s2.onSlide(function(value) {map.layers().get(S2_BA7_mapLayer).setOpacity(value)});
slider_post_nbr_s2.onSlide(function(value) {map.layers().get(S2_postNBR_mapLayer).setOpacity(value)});
slider_pre_nbr_s2.onSlide(function(value) {map.layers().get(S2_preNBR_mapLayer).setOpacity(value)});
var slider_list_s2 = [slider_ba7_s2, slider_post_nbr_s2, slider_pre_nbr_s2];
// Landsat 8 sliders
var slider_ba7_L8 = ui.Slider();
slider_ba7_L8.setValue(nbr_opacity);
var slider_post_nbr_L8 = ui.Slider();
slider_post_nbr_L8.setValue(nbr_opacity);
var slider_pre_nbr_L8 = ui.Slider();
slider_pre_nbr_L8.setValue(nbr_opacity);
// L8 slider properties
slider_ba7_L8.onSlide(function(value) {map.layers().get(L8_BA7_mapLayer).setOpacity(value)});
slider_post_nbr_L8.onSlide(function(value) {map.layers().get(L8_postNBR_mapLayer).setOpacity(value)});
slider_pre_nbr_L8.onSlide(function(value) {map.layers().get(L8_preNBR_mapLayer).setOpacity(value)});
var slider_list_L8 = [slider_ba7_L8, slider_post_nbr_L8, slider_pre_nbr_L8];
// Landsat 457 sliders
var slider_ba7_L457 = ui.Slider();
slider_ba7_L457.setValue(nbr_opacity);
var slider_post_nbr_L457 = ui.Slider();
slider_post_nbr_L457.setValue(nbr_opacity);
var slider_pre_nbr_L457 = ui.Slider();
slider_pre_nbr_L457.setValue(nbr_opacity);
// L8 slider properties
slider_ba7_L457.onSlide(function(value) {map.layers().get(L457_BA7_mapLayer).setOpacity(value)});
slider_post_nbr_L457.onSlide(function(value) {map.layers().get(L457_postNBR_mapLayer).setOpacity(value)});
slider_pre_nbr_L457.onSlide(function(value) {map.layers().get(L457_preNBR_mapLayer).setOpacity(value)});
var slider_list_L457 = [slider_ba7_L457, slider_post_nbr_L457, slider_pre_nbr_L457];
///////////////////////// Get fire information ////////////////////////////////
// Create a list of all fires
var fires = fire_perim.toList(fire_perim.size()).map(function(f) {
  return ee.Feature(f).get(fire_name_field);
}).sort().insert(0, all_fires_text);
print('Fires: ', fires);
// MJG: Map over fire names and create the needed dictionary
// for the ui.Select menu.
var items = fires.map(function(name) {
  return ee.Dictionary({'label': name, 'value': name});
}).getInfo();
////////////////////////////// NBR Sentinel //////////////////////////////////////////
// Function to get list of dates from image collection
var ymdList = function(image_collection) {
  var iter_func = function(image, newlist){
    var date = ee.Number.parse(image.date().format('YYYYMMdd'));
    newlist = ee.List(newlist);
    return ee.List(newlist.add(date).sort());
  };
  return image_collection.iterate(iter_func, ee.List([]));
};
// Define on change actions for fire_select
var fire_select_onChange = function(value) {
    // Reset map layers
    map.layers().reset();
    // Set current fire value
    current_fire = value;
    // Initially show rdnbr on legend
    remove_widgets(ba7_legend_items);
    add_widgets(ba7_legend_items);
    // Change the selected forest
    if (value == all_fires_text) {
      selectedFire.fc = fire_perim;
      selectedFire.label = value;
    } else {
      // Show loading panel
      //panel_loading.style().set({shown: true});
      var f = fire_perim.filter(ee.Filter.eq(fire_name_field, value));
      selectedFire.fc = ee.Feature(f.first());
      selectedFire.label = value + ' fire perimeter';  
      var export_fc = ee.FeatureCollection([selectedFire.fc]);
      // Fire perimeter buffer
      fire_buff.label = 'Fire polygon bounds buffer';
      fire_buff.fc = ee.Feature(f.first()).geometry().bounds().buffer(bounds_buffer_meters);
    }
    // Get Sentinel 2 RGB imagery
    var RGB_sentinel2_median = getRGB_sentinel2(RGB_start_date, RGB_stop_date); 
    // Get Landsat 8 RGB imagery
    var RGB_landsat8_median = getRGB_landsat8(RGB_start_date, RGB_stop_date);
    // Get Landsat 457 RGB imagery
    var RGB_landsat457_median = getRGB_landsat457(RGB_start_date, RGB_stop_date);
    // Function to get Sentinel collection, filter for clouds, and create NBR
    var getSentinelNBRCollection = function(start_date, end_date, box) {
      var collectionS2 = ee.ImageCollection('COPERNICUS/S2').filterDate(start_date,end_date)
                .filterMetadata('CLOUDY_PIXEL_PERCENTAGE','less_than', max_cloud_percent)
                .filterBounds(box)
                .map(maskS2clouds);
      print(collectionS2);
      var post_image_dates_s2 = ee.Dictionary(ee.List(ymdList(collectionS2)).reduce(ee.Reducer.frequencyHistogram()));
      post_date_items_s2 = post_image_dates_s2.keys().getInfo();
      return collectionS2.map(function(img) {
        return img.normalizedDifference(['B8A', 'B12']).clip(box);
      });
    };
    // Function to get Landsat 8 collection, filter for clouds, and create NBR
    var getLandsat8NBRCollection = function(start_date, end_date, box) {
      var collectionL8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA').filterDate(start_date, end_date)
                .filterMetadata('CLOUD_COVER_LAND', 'less_than', max_cloud_percent)
                .filterBounds(box)
                .map(maskL8);
      print(collectionL8);
      var post_image_dates_l8 = ee.Dictionary(ee.List(ymdList(collectionL8)).reduce(ee.Reducer.frequencyHistogram()));
      post_date_items_l8 = post_image_dates_l8.keys().getInfo();
      return collectionL8.map(function(imgL8) {
        return imgL8.normalizedDifference(['B5', 'B7']).clip(box);
      });
    };
    var getLandsat457NBRCollection = function(start_date, end_date, box) {
      var L4coll = ee.ImageCollection('LANDSAT/LT04/C01/T1_SR')
        .filterDate(start_date, end_date)
        .filter(ee.Filter.lt('CLOUD_COVER', max_cloud_percent))
        .filterBounds(box)
        .map(cloudMaskL457);
      var L5coll = ee.ImageCollection('LANDSAT/LT05/C01/T1_SR')
        .filterDate(start_date, end_date)
        .filter(ee.Filter.lt('CLOUD_COVER', max_cloud_percent))
        .filterBounds(box)
        .map(cloudMaskL457);
      var L7coll = ee.ImageCollection('LANDSAT/LE07/C01/T1_SR')
        .filterDate(start_date, end_date)
        .filter(ee.Filter.lt('CLOUD_COVER', max_cloud_percent))
        .filterBounds(box)
        .map(cloudMaskL457);
      // Merge collections into a single collection
      var L457coll = ee.ImageCollection(L4coll.merge(L5coll.merge(L7coll)));
      print(L457coll);
      var post_image_dates_l457 = ee.Dictionary(ee.List(ymdList(L457coll)).reduce(ee.Reducer.frequencyHistogram()));
      post_date_items_l457 = post_image_dates_l457.keys().getInfo();
      return L457coll.map(function(imgL457) {
        return imgL457.normalizedDifference(['B4', 'B7']).clip(box);
      });
    };
    // Function to create the pre-fire and post-fire NBR products
    var getFireNBR = function(box, box_buff, name) {      // box is for clip for map display products, 
                                                          // box_buff is for export products
      // Print metadata
      print('Current fire: ', current_fire);
      print('Maximum cloud percent: ' + max_cloud_percent_initial);
      print('Buffer distance (m): ' + buffer_meters_initial);
      print('preNBR start/stop: ' + preNBR_start_date + ' to ' + preNBR_stop_date);
      print('postNBR start/stop: ' + postNBR_start_date + ' to ' + postNBR_stop_date);
      print('True-color start/stop: ' + RGB_start_date + ' to ' + RGB_stop_date);
      print(selected_statistic);
      print('S2 percentile: ' + s2_postNBR_percentile);
      print('L8 percentile: ' + l8_postNBR_percentile);
      print('L456 percentile: ' + l457_postNBR_percentile);
      // Thresholds
      var pre_post_nbr_thresholds = [-1, 0.4, 1];
      var ba4_thresholds = [-10, 0.134870, 0.235195, 0.648725, 10];
      var ba7_thresholds = [-10, 0.134870, 0.166485, 0.235195, 0.406480, 0.648725, 0.828133, 10];
      // Set display option to clipped or buffered
      var display_preference = selected_display_preference;
      var display_choice;
      if (display_preference == display_clipped) {
        display_choice = box;
      }
      else if (display_preference == display_buffered) {
        display_choice = box_buff;
      }
      // Sentinel 2
      // preFire S2 calculations
      var preFire_nbr_S2 = getSentinelNBRCollection(preNBR_start_date, preNBR_stop_date, box_buff).median();          // calculation
      var preFire_nbr_S2_export = preFire_nbr_S2.multiply(1000).int();                                                   // for export
      var preFire_nbr_S2_classified = classifyByThreshold(preFire_nbr_S2, pre_post_nbr_thresholds).updateMask(jrc_land).clip(display_choice); // for map display (buffered)
      // postFire S2 calculations
      var postFire_nbr_S2 = getSentinelNBRCollection(postNBR_start_date, postNBR_stop_date, box_buff).reduce(ee.Reducer.percentile([ee.Number.parse(s2_postNBR_percentile)]));
      var postFire_nbr_S2_export = postFire_nbr_S2.multiply(1000).int();                                                                                    // for export
      var postFire_nbr_S2_classified = classifyByThreshold(postFire_nbr_S2, pre_post_nbr_thresholds).updateMask(jrc_land).clip(display_choice);    // for map display (buffered)
      // dnbr S2 calculations
      var dnbr_S2 = (preFire_nbr_S2.subtract(postFire_nbr_S2));                          // calculation
      var dnbr_S2_export = (preFire_nbr_S2.subtract(postFire_nbr_S2)).multiply(1000);    // for export and for BA formula
      // rdnbr S2 calculations
      var rdnbr_S2 = dnbr_S2.divide(preFire_nbr_S2.abs().add(0.0001).sqrt());                              // calculation
      var rdnbr_S2_export = rdnbr_S2.multiply(1000);                                                    // for export 
      // ba classes S2 calculations
      var ba4_S2_export = classifyByThreshold(rdnbr_S2, ba4_thresholds).updateMask(jrc_land);   // BA 4 class for export
      var ba4_S2_display = ba4_S2_export.clip(display_choice);                                  // BA 4 class for display
      var ba7_S2_export = classifyByThreshold(rdnbr_S2, ba7_thresholds).updateMask(jrc_land);   // BA 7 class for export
      var ba7_S2_display = ba7_S2_export.clip(display_choice);                                  // BA 7 class for display
      // S2 exports
      var final_s2 = preFire_nbr_S2_export.addBands(postFire_nbr_S2_export)
                             .addBands(dnbr_S2_export)
                             .addBands(rdnbr_S2_export)
                             .addBands(ba4_S2_export)
                             .addBands(ba7_S2_export)
                             .int()
                             .clip(box_buff);
      // Landsat 8
      // preFire L8 calculations
      var preFire_nbr_L8 = getLandsat8NBRCollection(preNBR_start_date, preNBR_stop_date, box_buff).median();      // calculation
      var preFire_nbr_L8_export = preFire_nbr_L8.multiply(1000).int();                                            // for export
      var preFire_nbr_L8_classified = classifyByThreshold(preFire_nbr_L8, pre_post_nbr_thresholds).updateMask(jrc_land).clip(display_choice); // for map display
      // postFire L8 Calculations
      var postFire_nbr_L8 = getLandsat8NBRCollection(postNBR_start_date, postNBR_stop_date, box_buff).reduce(ee.Reducer.percentile([ee.Number.parse(l8_postNBR_percentile)])); // calculation
      var postFire_nbr_L8_export = postFire_nbr_L8.multiply(1000).int();                                          // for export
      var postFire_nbr_L8_classified = classifyByThreshold(postFire_nbr_L8, pre_post_nbr_thresholds).updateMask(jrc_land).clip(display_choice);    // for map display
      // dnbr L8 calculations
      var dnbr_L8 = (preFire_nbr_L8.subtract(postFire_nbr_L8));                 // calculation
      var dnbr_L8_export = (preFire_nbr_L8.subtract(postFire_nbr_L8)).multiply(1000);    // for export
      // rdnbr L8 calculations
      var rdnbr_L8 = dnbr_L8.divide(preFire_nbr_L8.abs().add(0.0001).sqrt());      // calculation
      var rdnbr_L8_export = rdnbr_L8.multiply(1000);                               // for export
      // ba classes L8 calculations
      var ba4_L8_export = classifyByThreshold(rdnbr_L8, ba4_thresholds).updateMask(jrc_land);   // BA 4 class for export
      var ba4_L8_display = ba4_L8_export.clip(display_choice);                                  // BA 4 class for display
      var ba7_L8_export = classifyByThreshold(rdnbr_L8, ba7_thresholds).updateMask(jrc_land);   // BA 7 class for export
      var ba7_L8_display = ba7_L8_export.clip(display_choice);                                  // BA 7 class for display
      // L8 exports
      var final_L8 = preFire_nbr_L8_export.addBands(postFire_nbr_L8_export)
                            .addBands(dnbr_L8_export)
                            .addBands(rdnbr_L8_export)
                            .addBands(ba4_L8_export)
                            .addBands(ba7_L8_export)
                            .int()
                            .clip(box_buff);
      // Landsat 457
      // preFire L457 calculations
      var preFire_nbr_L457 = getLandsat457NBRCollection(preNBR_start_date, preNBR_stop_date, box_buff).median();      // calculation
      var preFire_nbr_L457_export = preFire_nbr_L457.multiply(1000).int();                                            // for export
      var preFire_nbr_L457_classified = classifyByThreshold(preFire_nbr_L457, pre_post_nbr_thresholds).updateMask(jrc_land).clip(display_choice); // for map display
      // postFire L457 Calculations
      var postFire_nbr_L457 = getLandsat457NBRCollection(postNBR_start_date, postNBR_stop_date, box_buff).reduce(ee.Reducer.percentile([ee.Number.parse(l457_postNBR_percentile)])); // calculation
      var postFire_nbr_L457_export = postFire_nbr_L457.multiply(1000).int();                                          // for export
      var postFire_nbr_L457_classified = classifyByThreshold(postFire_nbr_L457, pre_post_nbr_thresholds).updateMask(jrc_land).clip(display_choice);    // for map display
      // dnbr L457 calculations
      var dnbr_L457 = (preFire_nbr_L457.subtract(postFire_nbr_L457));                 // calculation
      var dnbr_L457_export = (preFire_nbr_L457.subtract(postFire_nbr_L457)).multiply(1000);    // for export
      // rdnbr L457 calculations
      var rdnbr_L457 = dnbr_L457.divide(preFire_nbr_L457.abs().add(0.0001).sqrt());      // calculation
      var rdnbr_L457_export = rdnbr_L457.multiply(1000);                               // for export
      // ba classes L457 calculations
      var ba4_L457_export = classifyByThreshold(rdnbr_L457, ba4_thresholds).updateMask(jrc_land);   // BA 4 class for export
      var ba4_L457_display = ba4_L457_export.clip(display_choice);                                  // BA 4 class for display
      var ba7_L457_export = classifyByThreshold(rdnbr_L457, ba7_thresholds).updateMask(jrc_land);   // BA 7 class for export
      var ba7_L457_display = ba7_L457_export.clip(display_choice);                                  // BA 7 class for display
      // L457 exports
      var final_L457 = preFire_nbr_L457_export.addBands(postFire_nbr_L457_export)
                            .addBands(dnbr_L457_export)
                            .addBands(rdnbr_L457_export)
                            .addBands(ba4_L457_export)
                            .addBands(ba7_L457_export)
                            .int()
                            .clip(box_buff);
      // Redraw all layers
      // Imagery layers
      map.addLayer(RGB_landsat457_median, {bands: ['B3', 'B2', 'B1'], min: 0, max: 3000, gamma: [1.4, 1.2, 1.0]}, 'Landsat 4, 5, 7 true-color image', ckbx_RGB_L457_default);
      map.addLayer(RGB_landsat8_median, {bands: ['B4', 'B3', 'B2'], min: 0, max: 0.3, gamma: [1.0, 1.1, 1]}, 'Landsat8 true-color image', ckbx_RGB_L8_default);
      map.addLayer(RGB_sentinel2_median, {bands: ['B4', 'B3', 'B2'], min: 0, max: 0.3, gamma: [1.33, 1.1, 1]}, 'Sentinel2 true-color image', ckbx_RGB_s2_default);
      // Landsat 457 outputs
      map.addLayer(preFire_nbr_L457_classified, vis_nbr_classified, 'L457 - preFire NBR ' + value, ckbx_pre_nbr_L457_default, nbr_opacity);
      map.addLayer(postFire_nbr_L457_classified, vis_nbr_classified, 'L457 - postFire NBR ' + value, ckbx_post_nbr_L457_default, nbr_opacity);
      map.addLayer(ba7_L457_display, vis_ba7_class, 'L457 - BA 7 class ' + value, ckbx_ba7_L457_default, nbr_opacity);       
      // Landsat 8 outputs
      map.addLayer(preFire_nbr_L8_classified, vis_nbr_classified, 'L8 - preFire NBR ' + value, ckbx_pre_nbr_L8_default, nbr_opacity);
      map.addLayer(postFire_nbr_L8_classified, vis_nbr_classified, 'L8 - postFire NBR ' + value, ckbx_post_nbr_L8_default, nbr_opacity);
      map.addLayer(ba7_L8_display, vis_ba7_class, 'L8 - BA 7 class ' + value, ckbx_ba7_L8_default, nbr_opacity);
      // Sentinel outputs
      map.addLayer(preFire_nbr_S2_classified, vis_nbr_classified, 'S2 - preFire NBR ' + value, ckbx_pre_nbr_s2_default, nbr_opacity);
      map.addLayer(postFire_nbr_S2_classified, vis_nbr_classified, 'S2 - postFire NBR ' + value, ckbx_post_nbr_s2_default, nbr_opacity);
      map.addLayer(ba7_S2_display, vis_ba7_class, 'S2 - BA 7 class ' + value, ckbx_ba7_s2_default, nbr_opacity);
      // Vector layers
      drawFirePerim(allFires, allFires_pal, allFires_on);
      drawFirePerim(selectedFire, selectedFire_pal, selectedFire_on);
      // Center map
      map.centerObject(selectedFire.fc);
      // Use function to set vector layer checkboxes to correct layers
      boxes_set(set_ckbx);
      var export_button = ui.Button({
        label: 'Export ' + value + ' NBR products to Drive'
        });
      export_button.unlisten();
      // Export function  
      var task = 'S2_' + value.split(' ').join('') + '_' + today;
      var task2 = 'firePerim_' + value.split(' ').join('') + '_' + today;
      var task3 = 'L8_' + value.split(' ').join('') + '_' + today;
      var task4 = 'L457_' + value.split(' ').join('') + '_' + today;
      var folder_name = 'GEE_NBR_Outputs_' + value.split(' ').join('') + '_' + today;
      export_button.onClick(function() {
        // Export Sentinel 2 products
        Export.image.toDrive({
          image: final_s2,
          description: task,
          folder: folder_name,
          region: box_buff,
          scale: 20,
          crs: 'EPSG:4326',  // WGS84
          maxPixels: 1e13
        });
        // Export Landsat 8 products
        Export.image.toDrive({
          image: final_L8,
          description: task3,
          folder: folder_name,
          region: box_buff,
          scale: 30,
          crs: 'EPSG:4326', // WGS84
          maxPixels: 1e13
        });
        // Export Landsat 457 products
        Export.image.toDrive({
          image: final_L457,
          description: task4,
          folder: folder_name,
          region: box_buff,
          scale: 30,
          crs: 'EPSG:4326', // WGS84
          maxPixels: 1e13
        });
        // Export fire perimeter
        Export.table.toDrive({
          collection: export_fc,
          description: task2,
          folder: folder_name,
          fileFormat: 'KML'
        });
      });
      //panel.widgets().add(export_button);
      print(export_button);
    };
    // Define behavior for all fires vs. one fire (only want dNBR for selected fires)
    if (value == all_fires_text) {
      set_ckbx = 'all_fires';
      ui.root.remove(panel_raster);
      // Remove fire checkboxes from panel
      panel_fire_checkbox.widgets().remove(ckbx_fireperim);
      panel_fire_checkbox.widgets().remove(ckbx_allFires);
      // Rebuild selected fire checkbox
      ckbx_fireperim = ui.Checkbox(current_fire, true, '', '', style_enabled);
      ckbx_fireperim.onChange(function(checked) {map.layers().get(fireperim_set).setShown(checked);});      
      // add selected fire checkbox back to panel
      panel_fire_checkbox.widgets().add(ckbx_fireperim);
      // Remove legend item
      remove_widgets(ba7_legend_items);
      // Set drawn map layer for fire perim, nso, and lsr layers
      boxes_set(set_ckbx);
      // Add map layer
      drawFirePerim(allFires, allFires_pal, allFires_on);
      map.centerObject(allFires.fc);
    }
    else {
      ui.root.remove(panel_raster);
      set_ckbx = 'selected_fire';
      ui.root.add(panel_raster);
      // Remove fire checkboxes from panel
      panel_fire_checkbox.widgets().remove(ckbx_fireperim);
      panel_fire_checkbox.widgets().remove(ckbx_allFires);
      // Rebuild selected fire checkbox
      ckbx_fireperim = ui.Checkbox(current_fire, true, '', '', style_enabled);
      ckbx_fireperim.onChange(function(checked) {map.layers().get(fireperim_set).setShown(checked);});
      // Add fire perimeter check boxes back to panel
      panel_fire_checkbox.widgets().add(ckbx_fireperim);
      panel_fire_checkbox.widgets().add(ckbx_allFires);
      // Generate NBR products
      getFireNBR(selectedFire.fc.geometry(), fire_buff.fc, value);
      // Reset slider opacity
      slider_ba7_s2.setValue(nbr_opacity);
      slider_post_nbr_s2.setValue(nbr_opacity);
      slider_pre_nbr_s2.setValue(nbr_opacity);
      slider_ba7_L8.setValue(nbr_opacity);
      slider_post_nbr_L8.setValue(nbr_opacity);
      slider_pre_nbr_L8.setValue(nbr_opacity);
      slider_ba7_L457.setValue(nbr_opacity);
      slider_post_nbr_L457.setValue(nbr_opacity);
      slider_pre_nbr_L457.setValue(nbr_opacity);
      // Reset raster checkboxes
      ckbx_ba7_s2.setValue(ckbx_ba7_s2_default);
      ckbx_post_nbr_s2.setValue(ckbx_post_nbr_s2_default);
      ckbx_pre_nbr_s2.setValue(ckbx_pre_nbr_s2_default);
      ckbx_ba7_L8.setValue(ckbx_ba7_L8_default);
      ckbx_post_nbr_L8.setValue(ckbx_post_nbr_L8_default);
      ckbx_pre_nbr_L8.setValue(ckbx_pre_nbr_L8_default);
      ckbx_ba7_L457.setValue(ckbx_ba7_L457_default);
      ckbx_post_nbr_L457.setValue(ckbx_post_nbr_L457_default);
      ckbx_pre_nbr_L457.setValue(ckbx_pre_nbr_L457_default);
      ckbx_RGB_s2.setValue(ckbx_RGB_s2_default);
      ckbx_RGB_L8.setValue(ckbx_RGB_L8_default);
      ckbx_RGB_L457.setValue(ckbx_RGB_L457_default);
      // Post-fire date range reset
      post_imagery_dates_s2.items().reset(post_date_items_s2);
      post_imagery_dates_s2.setValue(null);
      post_imagery_dates_s2.setPlaceholder('Post-fire image dates Sentinel 2');
      post_imagery_dates_l8.items().reset(post_date_items_l8);
      post_imagery_dates_l8.setValue(null);
      post_imagery_dates_l8.setPlaceholder('Post-fire image dates Landsat 8');
      post_imagery_dates_l457.items().reset(post_date_items_l457);
      post_imagery_dates_l457.setValue(null);
      post_imagery_dates_l457.setPlaceholder('Post-fire image dates Landsat 457');
    }
    // Hide loading panel
    //panel_loading.style().set({shown: false});
  };
// Create select fire interface and assign actions when fire is selected 
var fire_select = ui.Select({
  items: items,
  onChange: fire_select_onChange,
  // Set style for forest selection dropdown
  style: {
    margin: '3px 3px 3px 20px',
    //border: '1px solid black',
    color: 'black',
  }
});
fire_select.setPlaceholder('Choose a fire...'); 
// Panel styles
// Style for text (small grey text)
var small_grey_text_style = {
  color: 'grey',
  fontSize: '12px',
  margin: '0px 0px 0px 20px',
  //stretch: 'both'
};
var textbox_style = {
  margin: '0px 0px 0px 20px', 
  fontSize: '12px',
};
var textbox_style_hidden = {
  margin: '0px 0px 0px 20px', 
  fontSize: '12px',
  shown: false
};
//////////////////////////// Build left side panel ///////////////////////////////////////
// Introduction
var introduction = ui.Label('Satellite Imagery normalized burn ratio (NBR) data for post-fire assessment');
introduction.style().set({
  fontSize: '15px',
  margin: '15px 3px 10px 8px',
  stretch: 'both',
  fontWeight: 'bold',
});
panel.widgets().add(introduction);
var notice = ui.Label('Warning!');
notice.style().set({
  fontSize: '12px',  
  margin: '3px 3px 3px 8px',       // top, right, bottom, left
  stretch: 'both',
  fontWeight: 'bold',
  backgroundColor: 'ff9966'
});
var notice_text = ui.Label('Sentinel-2 temporal resolution is ~5 days. Landsat-8 temporal resolution is ~15 days. Smoke and cloud-filled images will result in inaccurate fire severity outputs.');
notice_text.style().set({
  fontSize: '12px',  
  margin: '0px 20px 3px 8px',
  stretch: 'both',
  backgroundColor: 'ff9966'
});
panel_warning.widgets().add(notice).add(notice_text);
panel.widgets().add(panel_warning);
// Add imagery type panel to left panel
panel.widgets().add(panel_imageryType);
// Add fire checkboxes panel ////
panel.widgets().add(panel_fire_checkbox);
// Select fire label
var selectFire_label = ui.Label('Select fire:');
selectFire_label.style().set({
  fontSize: '14px',
  fontWeight: 'bold',
  stretch: 'both',
  margin: '15px 3px 3px 10px'
});
// Add select fire label and select widget to panel
panel.widgets().add(selectFire_label);
panel.widgets().add(fire_select);
// Add view settings checkbox
panel.widgets().add(ckbx_settings);
panel.widgets().add(ckbx_imagery_dates);
panel.widgets().add(ckbx_other_settings);
/////////////////////////////////////// Create settings panel /////////////////////////////////////////////
var settings_label_style = {
  color: 'black',
  fontSize: '12px',
  fontWeight: 'bold',
  margin: '8px 3px 1px 10px', // top, right, bottom, left
  stretch: 'both',
  backgroundColor: set_pnl_clr
};
var setting_grey_text_style = {
  color: 'grey',
  fontSize: '12px',
  margin: '2px 0px 0px 20px',
  backgroundColor: set_pnl_clr
};
var setting_grey_text_style_hidden = {
  color: 'grey',
  fontSize: '12px',
  margin: '2px 0px 0px 20px',
  backgroundColor: set_pnl_clr,
  shown: false
};
var settings_panel_label = ui.Label('Settings:');
settings_panel_label.style().set({
  color: 'white',
  fontSize: '12px',
  fontWeight: 'bold',
  margin: '3px 6px 3px 3px',
  stretch: 'both',
  textAlign: 'top',
  backgroundColor: set_pnl_clr_0
});
panel_settings.widgets().add(settings_panel_label);
////////////////////////// Change imagery dates ///////////////////////////
var refresh_NBR_date_label = ui.Label('NBR Imagery Dates:', settings_label_style);
var preNBR_date_start_label = ui.Label('Pre NBR start date:', setting_grey_text_style);
var preNBR_start_date_textbox = ui.Textbox('YYYY-MM-DD', preNBR_start_date, '', '', textbox_style);
var preNBR_date_stop_label = ui.Label('Pre NBR stop date:', setting_grey_text_style);
var preNBR_stop_date_textbox = ui.Textbox('YYYY-MM_DD', preNBR_stop_date, '', '', textbox_style);
var postNBR_date_start_label = ui.Label('Post NBR start date:', setting_grey_text_style);
var postNBR_start_date_textbox = ui.Textbox('YYYY-MM-DD', postNBR_start_date, '', '', textbox_style);
var postNBR_date_stop_label = ui.Label('Post NBR stop date:', setting_grey_text_style);
var postNBR_stop_date_textbox = ui.Textbox('YYYY-MM-DD', postNBR_stop_date, '', '', textbox_style);
// Create action button
var NBR_dates_button = ui.Button({
  label: 'Refresh dates...',
  onClick: function() {
    // Print current fire
    print('Dates button refresh: ');
    // Set date variables equal to text boxes
    preNBR_start_date = preNBR_start_date_textbox.getValue();
    preNBR_stop_date = preNBR_stop_date_textbox.getValue();
    postNBR_start_date = postNBR_start_date_textbox.getValue();
    postNBR_stop_date = postNBR_stop_date_textbox.getValue();
    // Reset the fire_select parameters
    fire_select_onChange(current_fire);
  },
  style: {
    margin: '3px 3px 3px 20px',
    //border: '1px solid black',
    color: 'black',
    //backgroundColor: button_color
  }
});
// Add widgets to date parameters panel
panel_NBR_date.widgets().add(refresh_NBR_date_label);
panel_NBR_date.widgets().add(preNBR_date_start_label);
panel_NBR_date.widgets().add(preNBR_start_date_textbox);
panel_NBR_date.widgets().add(preNBR_date_stop_label);
panel_NBR_date.widgets().add(preNBR_stop_date_textbox);
panel_NBR_date.widgets().add(postNBR_date_start_label);
panel_NBR_date.widgets().add(postNBR_start_date_textbox);
panel_NBR_date.widgets().add(postNBR_date_stop_label);
panel_NBR_date.widgets().add(postNBR_stop_date_textbox);
panel_NBR_date.widgets().add(NBR_dates_button);
///// Change RGB imagery dates /////
var refresh_RGB_date_label = ui.Label('True-color Imagery Dates:', settings_label_style);
var ckbx_RGB_dates_to_postNBR = ui.Checkbox({
  label: 'Use Post NBR dates',
  value: ckbx_RGB_dates_to_postNBR_default,
  style: {
    color: 'black',
    fontSize: '12px',
    margin: '3px 3px 3px 20px', // top, right, bottom, left
    stretch: 'both',
    backgroundColor: set_pnl_clr
  }
});
var RGB_date_start_label = ui.Label('True-color start date:', setting_grey_text_style_hidden);
var RGB_start_date_textbox = ui.Textbox('YYYY-MM-DD', RGB_start_date, '', '', textbox_style_hidden);
var RGB_date_stop_label = ui.Label('True-color stop date:', setting_grey_text_style_hidden);
var RGB_stop_date_textbox = ui.Textbox('YYYY-MM_DD', RGB_stop_date, '', '', textbox_style_hidden);
// Create action button
var RGB_dates_button = ui.Button({
  label: 'Refresh dates...',
  onClick: function() {
    // Set date variables equal to text boxes
    RGB_start_date = RGB_start_date_textbox.getValue();
    RGB_stop_date = RGB_stop_date_textbox.getValue();
    // Reset the fire_select parameters
    fire_select_onChange(current_fire);
  },
  style: {
    margin: '3px 3px 3px 20px',
    //border: '1px solid black',
    color: 'black',
    shown: false
    //backgroundColor: button_color
  }
});
// Set action for checkbox
ckbx_RGB_dates_to_postNBR.onChange(function(checked) {
  var ckbx_check = ckbx_RGB_dates_to_postNBR.getValue();
  if (ckbx_check === true) {
    RGB_date_start_label.style().set({shown: false});
    RGB_start_date_textbox.style().set({shown: false});
    RGB_date_stop_label.style().set({shown: false});
    RGB_stop_date_textbox.style().set({shown: false});
    RGB_dates_button.style().set({shown: false});
    RGB_start_date = postNBR_start_date;
    RGB_stop_date = postNBR_stop_date;
    fire_select_onChange(current_fire);
  }
  else if (ckbx_check === false) {
    RGB_date_start_label.style().set({shown: true});
    RGB_start_date_textbox.style().set({shown: true});
    RGB_date_stop_label.style().set({shown: true});
    RGB_stop_date_textbox.style().set({shown: true});
    RGB_dates_button.style().set({shown: true});
    RGB_start_date_textbox.setValue(postNBR_start_date);
    RGB_stop_date_textbox.setValue(postNBR_stop_date);
  }
}); 
// Add widgets to date parameters panel
panel_RGB_date.widgets().add(refresh_RGB_date_label);
panel_RGB_date.widgets().add(ckbx_RGB_dates_to_postNBR);
panel_RGB_date.widgets().add(RGB_date_start_label);
panel_RGB_date.widgets().add(RGB_start_date_textbox);
panel_RGB_date.widgets().add(RGB_date_stop_label);
panel_RGB_date.widgets().add(RGB_stop_date_textbox);
panel_RGB_date.widgets().add(RGB_dates_button);
///// post-fire NBR statistic setting (median or percentile) panel /////
var postNBR_stat_label = ui.Label('Post-fire NBR statistic:', settings_label_style);
// Select median or percentile statistic options
var statistic_options = [
  {'label': percentile_text, 'value': percentile_text},
  {'label': median_text, 'value': median_text}
];
var select_postNBR_statistic = ui.Select({
  items: statistic_options,
  value: selected_statistic,
  onChange: function(value) {
    if (value == percentile_text) {
      S2_postNBR_pctile_label.style().set({shown: true});
      S2_postNBR_pctile_textbox.style().set({shown: true});
      L8_postNBR_pctile_label.style().set({shown: true});
      L8_postNBR_pctile_textbox.style().set({shown: true});
      L457_postNBR_pctile_label.style().set({shown: true});
      L457_postNBR_pctile_textbox.style().set({shown: true});
      statistics_button.style().set({shown: true});
      statistics_button_onClick();
    } 
    else if (value == median_text) {
      S2_postNBR_pctile_label.style().set({shown: false});
      S2_postNBR_pctile_textbox.style().set({shown: false});
      L8_postNBR_pctile_label.style().set({shown: false});
      L8_postNBR_pctile_textbox.style().set({shown: false});
      L457_postNBR_pctile_label.style().set({shown: false});
      L457_postNBR_pctile_textbox.style().set({shown: false});
      statistics_button.style().set({shown: false});
      statistics_button_onClick();
    }
  },
  style: {
    margin: '3px 3px 3px 20px',
    //border: '1px solid black',
    color: 'black',
  }
});
// Text boxes for percentile parameters
var S2_postNBR_pctile_label = ui.Label('S2 post NBR percentile:', setting_grey_text_style);
var S2_postNBR_pctile_textbox = ui.Textbox('S2 post NBR percentile', s2_postNBR_percentile, '', false, textbox_style);
var L8_postNBR_pctile_label = ui.Label('L8 post NBR percentile:', setting_grey_text_style);
var L8_postNBR_pctile_textbox = ui.Textbox('L8 post NBR percentile', l8_postNBR_percentile, '', false, textbox_style);
var L457_postNBR_pctile_label = ui.Label('L457 post NBR percentile:', setting_grey_text_style);
var L457_postNBR_pctile_textbox = ui.Textbox('L457 post NBR percentile', l457_postNBR_percentile, '', false, textbox_style);
// Statistics button on click actions
var statistics_button_onClick = function() {
  selected_statistic = select_postNBR_statistic.getValue();
  if (selected_statistic == percentile_text) {
    s2_postNBR_percentile = S2_postNBR_pctile_textbox.getValue();
    l8_postNBR_percentile = L8_postNBR_pctile_textbox.getValue();
    l457_postNBR_percentile = L457_postNBR_pctile_textbox.getValue();
    // Rerun fire select for current parameters
    fire_select_onChange(current_fire);
  }
  else if (selected_statistic == median_text) {
    s2_postNBR_percentile = '50';
    l8_postNBR_percentile = '50';
    l457_postNBR_percentile = '50'; 
    // Rerun fire select for current parameters
    fire_select_onChange(current_fire);
  }
};
// Create action button
var statistics_button = ui.Button({
  label: 'Refresh postNBR percentiles...',
  onClick: statistics_button_onClick,
  style: {
    margin: '3px 3px 3px 20px',
    //border: '1px solid black',
    color: 'black'
  }
});
// Add statistic widgets to statistic panel
panel_statistic.widgets().add(postNBR_stat_label);
panel_statistic.widgets().add(select_postNBR_statistic);
if (selected_statistic == percentile_text) {
  panel_statistic.widgets().add(S2_postNBR_pctile_label);       //
  panel_statistic.widgets().add(S2_postNBR_pctile_textbox);     //
  panel_statistic.widgets().add(L8_postNBR_pctile_label);       //
  panel_statistic.widgets().add(L8_postNBR_pctile_textbox);     //
  panel_statistic.widgets().add(L457_postNBR_pctile_label);     //
  panel_statistic.widgets().add(L457_postNBR_pctile_textbox);   //
  panel_statistic.widgets().add(statistics_button);             //
}
// Add NBR dates, RGB dates, and statistic panels to panel_dates
panel_dates.widgets().add(panel_NBR_date);
panel_dates.widgets().add(panel_RGB_date);
panel_dates.widgets().add(panel_statistic);
/////////////////// Buffer and display products preference /////////////////////////
///// Buffer distance /////
var buffer_distance_label = ui.Label('Buffer distance (meters):', settings_label_style);
// Buffer distance text box
var buffer_distance_textbox_label = ui.Label('Buffer distance (m):', setting_grey_text_style);
var buffer_distance_textbox = ui.Textbox('Buffer distance (m)', buffer_meters_initial, '', '', textbox_style);
// Create max cloud percent action button
var buffer_distance_button = ui.Button({
  label: 'Refresh buffer distance...',
  onClick: function() {
    buffer_meters_initial = buffer_distance_textbox.getValue();
    bounds_buffer_meters = ee.Number.parse(buffer_meters_initial);
    fire_select_onChange(current_fire);
  },
  style: {
    margin: '3px 3px 3px 20px',
    color: 'black',
  }
});
// Add widgets to buffer distance panel
panel_buffer_distance.widgets().add(buffer_distance_label);
panel_buffer_distance.widgets().add(buffer_distance_textbox_label);
panel_buffer_distance.widgets().add(buffer_distance_textbox);
panel_buffer_distance.widgets().add(buffer_distance_button);
// Display preference
var display_preference_label = ui.Label('Display preference (select):', settings_label_style);
// Select median or percentile statistic options
var display_options = [
  {'label': display_clipped, 'value': display_clipped},
  {'label': display_buffered, 'value': display_buffered}
];
var select_display_preference = ui.Select({
  items: display_options,
  value: selected_display_preference,
  onChange: function(value) {
    if (value == display_clipped) {
      selected_display_preference = display_clipped;
      fire_select_onChange(current_fire);
    } 
    else if (value == display_buffered) {
      selected_display_preference = display_buffered;
      fire_select_onChange(current_fire);
    }
  },
  style: {
    margin: '3px 3px 3px 20px',
    //border: '1px solid black',
    color: 'black',
  }
});
// Add widgets to display preference panel
panel_display_preference.widgets().add(display_preference_label);
panel_display_preference.widgets().add(select_display_preference);
/////////////////////////// Feature collection and max cloud percent
///// Fire perimeter feature collection parameters /////
// Fire perimeter feature collection label
var label_firePerim_fc = ui.Label('Fire perimeter feature collection: ', settings_label_style);
var firePerim_col_label = ui.Label('Fire perimeter feature collection:', setting_grey_text_style);
var firePerim_col_textbox = ui.Textbox('Feature collection...', fire_fc_id, '', '', textbox_style);
var firePerim_nameField_label = ui.Label('Fire perimeter name field:', setting_grey_text_style);
var firePerim_nameField_textbox = ui.Textbox('Fire name field...', fire_name_field, '', '', textbox_style);
// Create action button
var fc_button = ui.Button({
  label: 'Refresh feature collection...',
  onClick: function() {
    map.layers().reset();
    // Set date variables equal to text boxes
    fire_fc_id = firePerim_col_textbox.getValue();
    fire_name_field = firePerim_nameField_textbox.getValue();
    fire_perim = ee.FeatureCollection(fire_fc_id);
    selectedFire.label = all_fires_text;
    selectedFire.fc = fire_perim;
    allFires.label = all_fires_text;
    allFires.fc = fire_perim;
    print('New feature collection: ', fire_perim);
    // Create a list of all fires
    var fires = fire_perim.toList(fire_perim.size()).map(function(f) {
      return ee.Feature(f).get(fire_name_field);
    }).sort().insert(0, all_fires_text);
    print('New fires list: ', fires);
    // Map over fire names and create the needed dictionary for the ui.Select menu.
    var items = fires.map(function(name) {
      return ee.Dictionary({'label': name, 'value': name});
    }).getInfo();
    // Reset selection dropdown for new list
    //fire_select_onChange(all_fires_text);    
    fire_select.items().reset(items);
    fire_select.setValue(all_fires_text);
    //fire_select.setPlaceholder('Choose a fire...');
    // Add initial layers to map
    drawFirePerim(allFires, allFires_pal, allFires_on);
    map.centerObject(allFires.fc);
  },
  style: {
    margin: '3px 3px 3px 20px',
    //border: '1px solid black',
    color: 'black'
  }
});
// Add to feature collection parameters panel
panel_params_fc.widgets().add(label_firePerim_fc);
panel_params_fc.widgets().add(firePerim_col_label);
panel_params_fc.widgets().add(firePerim_col_textbox);
panel_params_fc.widgets().add(firePerim_nameField_label);
panel_params_fc.widgets().add(firePerim_nameField_textbox);
panel_params_fc.widgets().add(fc_button);
///// Maximum cloud percent /////
var max_cloud_pct_label = ui.Label('Maximum cloud percent:', settings_label_style);
// Max cloud percent text box
var max_cloud_textbox_label = ui.Label('Maximum cloud percent (0-100):', setting_grey_text_style);
var max_cloud_textbox = ui.Textbox('0-100', max_cloud_percent_initial, '', '', textbox_style);
// Create max cloud percent action button
var max_cloud_button = ui.Button({
  label: 'Refresh maximum cloud percent...',
  onClick: function() {
    max_cloud_percent_initial = max_cloud_textbox.getValue();
    max_cloud_percent = ee.Number.parse(max_cloud_textbox.getValue());
    fire_select_onChange(current_fire);
  },
  style: {
    margin: '3px 3px 3px 20px',
    color: 'black',
    //backgroundColor: button_color
  }
});
// Add widgets to max cloud panel
panel_max_cloud.widgets().add(max_cloud_pct_label);
panel_max_cloud.widgets().add(max_cloud_textbox_label);
panel_max_cloud.widgets().add(max_cloud_textbox);
panel_max_cloud.widgets().add(max_cloud_button);
// Add widgets to other settings panel
panel_other_settings.widgets().add(panel_buffer_distance);
panel_other_settings.widgets().add(panel_display_preference);
panel_other_settings.widgets().add(panel_params_fc);
panel_other_settings.widgets().add(panel_max_cloud);
// Adding individual setting panels to master settings panel
// Add dates panel to settings panel
if (ckbx_imagery_dates_default === true) {panel_settings.widgets().add(panel_dates)}
// Add buffer and display panel to settings panel
if (ckbx_other_settings === true) {panel_settings.widgets().add(panel_other_settings)}
// Add settings panel to map
if (ckbx_settings_default === true) {map.add(panel_settings)}
///////////////////////////////////////// Build right side panel /////////////////////////////////////////
// Funtion to create checkbox/slider rows
var ckbx_slider_row = function(ckbx, slider) {
  // return the panel
  return ui.Panel({
    widgets: [ckbx, slider],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
// Add Sentinel label, check boxes, and dates to S2 products panel
panel_s2_products.widgets().add(label_raster_s2);
var list_length_s2 = ckbx_list_s2.length;
for (var i = 0; i < list_length_s2; i++) {panel_s2_products.add(ckbx_slider_row(ckbx_list_s2[i], slider_list_s2[i]));}
var post_imagery_dates_s2 = ui.Select({
  items: post_date_items_s2,
  style: {
    padding: '3px',
  }
});
panel_s2_products.widgets().add(post_imagery_dates_s2);
// Add Landsat 8 label, check boxes, and dates to L8 products panel
panel_l8_products.widgets().add(label_raster_L8);
var list_length_L8 = ckbx_list_L8.length;
for (var i = 0; i < list_length_L8; i++) {panel_l8_products.add(ckbx_slider_row(ckbx_list_L8[i], slider_list_L8[i]));}
var post_imagery_dates_l8 = ui.Select({
  items: post_date_items_l8,
  style: {
    padding: '3px',
  }
});
panel_l8_products.widgets().add(post_imagery_dates_l8);
// Add Landsat 457 label, checkboxes, and dates to L457 products panel
panel_l457_products.widgets().add(label_raster_L457);
var list_length_L457 = ckbx_list_L457.length;
for (var i = 0; i < list_length_L457; i++) {panel_l457_products.add(ckbx_slider_row(ckbx_list_L457[i], slider_list_L457[i]));}
var post_imagery_dates_l457 = ui.Select({
  items: post_date_items_l457,
  style: {
    padding: '3px'
  }
});
panel_l457_products.widgets().add(post_imagery_dates_l457);
// Add Imagery label to panel
raster_imagery.widgets().add(label_imagery);
// Add NBR product panels with checkboxes to imagery panel based on default checkbox value
if (S2_preferred_default === true) {
  raster_imagery.widgets().add(ckbx_RGB_s2);
  panel_raster.widgets().add(panel_s2_products);
}
if (L8_preferred_default === true) {
  raster_imagery.widgets().add(ckbx_RGB_L8);
  panel_raster.widgets().add(panel_l8_products);
}
if (L457_preferred_default === true) {
  raster_imagery.widgets().add(ckbx_RGB_L457);
  panel_raster.widgets().add(panel_l457_products);
}
// Add RGB imagery panel
panel_raster.widgets().add(raster_imagery);
// Add all fires layer to initial map
drawFirePerim(allFires, allFires_pal, allFires_on);
map.centerObject(allFires.fc);