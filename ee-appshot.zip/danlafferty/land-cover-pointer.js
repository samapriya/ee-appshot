// Define a point location
var geometry = ee.Geometry.Point([-0.5, 52]);
Map.centerObject(geometry, 8);
//set dates
var eeNow = ee.Date(Date.now());
var start = eeNow.advance(-24,'month');
var formattedStart = start.format('YYYY-MM-dd');
var formattedEnd = eeNow.format('YYYY-MM-dd');
var panel = ui.Panel();
panel.style().set('width', '400px');
var intro = ui.Panel([
  ui.Label({
    value: 'Land Cover Inspector',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
  ui.Label('Click a point on the map to inspect land cover over the last 24 months.')
]);
panel.add(intro);
var lon = ui.Label();
var lat = ui.Label();
panel.add(lon)
panel.add(lat);
Map.onClick(function(coords) {
  lon.setValue('lon: ' + coords.lon);
  lat.setValue('lat: ' + coords.lat);
  // Add a red dot to the map.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'FF0000'});
  Map.layers().set(0, dot);
  var dw = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1')
  .filterDate(formattedStart, formattedEnd)
  .filterBounds(point);
var probabilityBands = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
    ];
// Select all probability bands.
var dwTimeSeries = dw.select(probabilityBands);
// Refine the chart.
// A helper function  to set the label, color, and style properties
// for each of the 9 series in the chart.
function lineStyle(label, color) {
  var style_dict = {
      labelInLegend: label,
      color: color,
      lineWidth: 2, 
      pointSize: 3
  };
  return style_dict;
}
// We now create the chart and call setOptions with a dictionary of
// configuration options.
var chart = ui.Chart.image.series({
  imageCollection: dwTimeSeries,
  region: point,
  scale: 10
}).setOptions({
  title: 'Land Cover Over Time',
  vAxis: {
    title: 'Class probabilities',
    viewWindow: {min: 0, max: 1}},
  interpolateNulls: true,
  series: {
              0: lineStyle('Bare', '#A59B8F'),
              1: lineStyle('Built', '#C4281B'),
              2: lineStyle('Crops', '#E49635'),
              3: lineStyle('Flooded_vegetation', '#7A87C6'),
              4: lineStyle('Grass', '#88B053'),
              5: lineStyle('Shrub and scrub', '#DFC35A'),
              6: lineStyle('Snow and ice', '#B39FE1'),
              7: lineStyle('Trees', '#397D49'),
              8: lineStyle('Water', '#419BDF')}
});
panel.widgets().set(3, chart);
});
Map.style().set('cursor', 'crosshair');
// Add the panel to the ui.root.
ui.root.insert(0, panel);