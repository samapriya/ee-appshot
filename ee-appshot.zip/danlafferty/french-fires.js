//import shapefile
var table = ee.FeatureCollection('projects/ee-demos-356707/assets/Nouvelle-Aquitaine');
//coords for centring maps
var louchats = ee.Geometry.Point([-0.5386, 44.5129]);
var testeDeBouch = ee.Geometry.Point([-1.2162, 44.5605]);
//dates
var beforeStartDate = '2022-05-01';
var beforeEndDate = '2022-06-01';
var afterStartDate = '2022-08-01';
var afterEndDate = '2022-08-24';
//date labels
var beforeLabel = 'May 2022';
var afterLabel = 'August 2022';
//Map Labels
var sentinalLabel = 'Sentinal';
var dwLabel = 'Dynamic World';
//build UI elements
var title = ui.Label('French Forest Fires 2022');
var labelPanel = ui.Panel(); // Label container
var testeDeBuchPanel = ui.Panel();
var louchatsPanel = ui.Panel();
var testeDeBuchTitle = ui.Label('La Teste-de-Buch');
var louchatsTitle = ui.Label('Louchats');
var mapPanel = ui.Panel();  // Maps container
//create upper map
var testeDeBuchUpperMap = ui.Map(); //left map
var testeDeBuchLowerMap = ui.Map(); //right map
var testeDeBuchSplitMap = ui.SplitPanel(testeDeBuchUpperMap, testeDeBuchLowerMap, 'vertical', true); //combine maps
//create lower map
var louchatsUpperMap = ui.Map(); //left map
var louchatsLowerMap = ui.Map(); //right map
var louchatsSplitMap = ui.SplitPanel(louchatsUpperMap, louchatsLowerMap, 'vertical', true); //combine maps
//CSS styling
title.style().set({
  height: '4%',
  width: '100%',
  margin: 0,
  textAlign: 'center',
  fontSize: '24px',
  backgroundColor: '444444',
  color: 'white'
});
testeDeBuchTitle.style().set({
  height: '100%',
  width: '100%',
  margin: 0,
  textAlign: 'center',
  fontSize: '18px',
  backgroundColor: '444444',
  color: 'white'
})
louchatsTitle.style().set({
  height: '100%',
  width: '100%',
  margin: 0,
  textAlign: 'center',
  fontSize: '18px',
  backgroundColor: '444444',
  color: 'white'
})
labelPanel.style().set({
  height: '3%',
  width: '100%'
});
testeDeBuchPanel.style().set({
  height: '100%',
  width: '50%'
});
louchatsPanel.style().set({
  height: '100%',
  width: '50%'
});
mapPanel.style().set({
  height: '93%',
  width: '100%'
});
testeDeBuchSplitMap.style().set({
  height: '100%',
});
louchatsSplitMap.style().set({
  height: '100%',
});
var lowerLabelStyle = {position: 'bottom-center'};
// Configure the layouts for how the panels flow together.
ui.root.setLayout(ui.Panel.Layout.flow('vertical'));
labelPanel.setLayout(ui.Panel.Layout.flow('horizontal'));
testeDeBuchPanel.setLayout(ui.Panel.Layout.flow('vertical'));
louchatsPanel.setLayout(ui.Panel.Layout.flow('vertical'));
mapPanel.setLayout(ui.Panel.Layout.flow('horizontal'));
//clear UI, add elements and centre maps
ui.root.clear();
ui.root.add(title);
ui.root.add(labelPanel);
labelPanel.add(testeDeBuchPanel);
labelPanel.add(louchatsPanel);
testeDeBuchPanel.add(testeDeBuchTitle);
louchatsPanel.add(louchatsTitle);
ui.root.add(mapPanel);
mapPanel.add(testeDeBuchSplitMap);//add combined map to container
mapPanel.add(louchatsSplitMap);//add combined map to container
testeDeBuchUpperMap.add(ui.Label(beforeLabel));
testeDeBuchLowerMap.add(ui.Label(afterLabel, lowerLabelStyle));
louchatsUpperMap.add(ui.Label(beforeLabel));
louchatsLowerMap.add(ui.Label(afterLabel, lowerLabelStyle));
testeDeBuchUpperMap.centerObject(testeDeBouch, 12);
louchatsUpperMap.centerObject(louchats, 12);
// Link our maps together.
ui.Map.Linker([testeDeBuchUpperMap, testeDeBuchLowerMap]);
ui.Map.Linker([louchatsUpperMap, louchatsLowerMap]);
/**
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
//create dataset for 'before'
var beforeDataset = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate(beforeStartDate, beforeEndDate)
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .filterBounds(table)
                  .map(maskS2clouds);
var beforeDw = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1')
             .filterDate(beforeStartDate, beforeEndDate)
             .filterBounds(table);
//create dataset for 'after'
var afterDataset = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate(afterStartDate, afterEndDate)
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .filterBounds(table)
                  .map(maskS2clouds);
var afterDw = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1')
             .filterDate(afterStartDate, afterEndDate)
             .filterBounds(table);
//visualisation params for satellite
var visualization = {
  min: 0.0,
  max: 0.3,
  bands: ['B4', 'B3', 'B2'],
};
//
var beforeClassification = beforeDw.select('label');
var beforeDwComposite = beforeClassification.reduce(ee.Reducer.mode());
var afterClassification = afterDw.select('label');
var afterDwComposite = afterClassification.reduce(ee.Reducer.mode());
var dwVisParams = {
  min: 0,
  max: 8,
  palette: [
    '#419BDF', '#397D49', '#88B053', '#7A87C6', '#E49635', '#DFC35A',
    '#C4281B', '#A59B8F', '#B39FE1'
  ]
};
//add layers to maps
testeDeBuchUpperMap.addLayer(beforeDataset.mean().clip(table), visualization, sentinalLabel);
testeDeBuchUpperMap.addLayer(beforeDwComposite.clip(table), dwVisParams, dwLabel, 1, 0.4);
testeDeBuchLowerMap.addLayer(afterDataset.mean().clip(table), visualization, sentinalLabel);
testeDeBuchLowerMap.addLayer(afterDwComposite.clip(table), dwVisParams, dwLabel, 1, 0.4);
louchatsUpperMap.addLayer(beforeDataset.mean().clip(table), visualization, sentinalLabel);
louchatsUpperMap.addLayer(beforeDwComposite.clip(table), dwVisParams, dwLabel, 1, 0.4);
louchatsLowerMap.addLayer(afterDataset.mean().clip(table), visualization, sentinalLabel);
louchatsLowerMap.addLayer(afterDwComposite.clip(table), dwVisParams, dwLabel, 1, 0.4);