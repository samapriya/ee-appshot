//import UK shapefile
var table = ee.FeatureCollection('projects/ee-demos-356707/assets/gb_10km');
//create coords for centring map
var geometry = ee.Geometry.Point([-2, 53]);
//build UI elements
var rootPanel = ui.Panel();  // Highest-level container
var mapPanel = ui.Panel();  // Maps container
var leftMap = ui.Map(); //left map
var rightMap = ui.Map(); //right map
var splitMap = ui.SplitPanel(leftMap, rightMap, 'horizontal', true); //combine maps
mapPanel.add(splitMap);//add combined map to container
//CSS styling
rootPanel.style().set({
  height: '100%',
  width: '100%'
});
mapPanel.style().set({
  height: '100%',
  width: '100%',
});
//clear UI, add elements and centre map
ui.root.clear();
ui.root.add(rootPanel);
rootPanel.add(mapPanel);
leftMap.centerObject(geometry, 8);
// Link our maps together.
ui.Map.Linker([leftMap, rightMap]);
/**
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
//create dataset for 'before'
var beforeDataset = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2021-05-01', '2021-08-01')
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .filterBounds(table)
                  .map(maskS2clouds);
//create dataset for 'after'
var afterDataset = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2022-07-01', '2022-08-21')
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',20))
                  .filterBounds(table)
                  .map(maskS2clouds);
//visualisation params
var visualization = {
  min: 0.0,
  max: 0.3,
  bands: ['B4', 'B3', 'B2'],
};
//add layers to maps
leftMap.addLayer(beforeDataset.mean().clip(table), visualization, 'RGB');
rightMap.addLayer(afterDataset.mean().clip(table), visualization, 'RGB');