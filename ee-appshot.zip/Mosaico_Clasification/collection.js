var image = ee.Image('users/Mosaico_Clasification/RaisgCollection2/clasification-ft/VENEZUELA-91386-13');
var image = ee.Image('users/Mosaico_Clasification/RaisgCollection2/clasification-ft/VENEZUELA-91386-13');
var palettes = require('users/mapbiomas/modules:Palettes.js');
/**
 * Config object for control panel
 */
var controls = {
    // panel settings
    left_panel: {
        style: {
          'width': '400px',
          'height': '100%',
          'position': 'top-left',
          'background-color': '#f2f2f2',          
        }
    },
    // panel title
    title: {
        text: 'Collection 2 visualizator',
        style: { 
          'font-size': '20px',
          'background-color': '#f2f2f2',
          'padding': '10px 10px 0 10px',
          'width': '368px',
          'font-weight': 'bold',
        }
    },
    // panel help text
    help: {
      text: 'Select region and year for display in map',
      style: {
        'background-color': '#f2f2f2',
        'color': '#757575',
        'padding': '0 10px',
        'width': '368px',
      }
    },
    // Regions selector
    regions: {
        style: {
          'width': '368px',
        }
    },
    varsion: {
        style: {
          'width': '368px',
        }
    }
};
var data = {
    classification_dir: 'users/Mosaico_Clasification/RaisgCollection2/clasification-ft/',
    mosaic_dir:'',
    country: 'VENEZUELA',
    regions: {
        '90278': {
            center: [-62.39242, 7.99831],
            year: 2015,
        },
        '91386': {
            center: [-62.1221, 9.1628],
            year: 2017,
        },
    },
    versions: [3, 13]
};
/**
 * Panel creation and set-up
 */
// widgets
var title = ui.Label({
        value: controls.title.text, 
        style: controls.title.style
    }),
    // help text
    help = ui.Label({
        value: controls.help.text, 
        style: controls.help.style 
    }),
    version = ui.Checkbox({
        label: 'Version 13', 
        value: true
    }),
    // regions select input
    region = ui.Select({
        items: Object.keys(data.regions),
        placeholder: 'Select region to display...',
        style: controls.regions.style,
        onChange: function( key ) {
            map.setCenter(
                data.regions[ key ].center[ 0 ], 
                data.regions[ key ].center[ 1 ],
                12
            );
            var dataVersion = data.versions[1];
            if(version.getValue() === false){
                dataVersion = data.versions[0];
            }
            //print(version.getValue())
            var image = ee.Image(
                data.classification_dir + data.country + '-' +
                key + '-' + dataVersion
            );
            map.addLayer(image.select('classification_2019'), visClassification);
        }
    });
// Put witgets into the interface
var leftPanel = ui.Panel([ 
    title,    /* Title panel */
    help,     /* Title help text */
    region,   /* Regions */
    version
]);
leftPanel.style().set( controls.left_panel.style );
/**
 * Display map and panels
 */
// Defining map interfaces
var map = ui.Map()
      .setOptions({'mapTypeId': 'SATELLITE'})
      .setControlVisibility({
          all: false,
          fullscreenControl: true
      });
// Data
var visClassification = {
  min: 0, max: 34, 
  palette: palettes.get('classification2')
};
ui.root.clear();
ui.root.add(leftPanel);
ui.root.add(map);