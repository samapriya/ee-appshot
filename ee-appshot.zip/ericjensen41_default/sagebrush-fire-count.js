var FireN = ui.import && ui.import("FireN", "image", {
      "id": "users/ericjensen41_default/NTSG/MTBS_Counts_Sagebrush_30"
    }) || ee.Image("users/ericjensen41_default/NTSG/MTBS_Counts_Sagebrush_30"),
    AnnH = ui.import && ui.import("AnnH", "image", {
      "id": "users/ericjensen41_default/NTSG/WGA_AnnualHerbaceousCover_2016_2018"
    }) || ee.Image("users/ericjensen41_default/NTSG/WGA_AnnualHerbaceousCover_2016_2018"),
    RR = ui.import && ui.import("RR", "image", {
      "id": "users/ericjensen41_default/NTSG/ResilienceAndResistance"
    }) || ee.Image("users/ericjensen41_default/NTSG/ResilienceAndResistance");
Map.setOptions('hybrid')
// Pre-process data
var mask = ee.Image('users/chohnz/wga_Reeves_NLCD_range_mask_union').neq(1)
var FireN = FireN.updateMask(mask)
// Visualization parameters
var palettes = require('users/gena/packages:palettes');
// var fire_palette = palettes.crameri.lajolla[10]
var fireParams = {
  min: 0,
  max: 7,
  palette: ['fff7bc', 'feb24c', 'f03b20', '781D10'] }
var annParams = {
  min: 0,
  max: 60,
  palette: ['91ee89', 'fdea00', 'ec7c00', 'b60900'] }
var rrParams = {
  min: 1,
  max: 3,
  palette: ['5695d2', 'fafb09', 'e60000'] }
Map.addLayer(RR, rrParams, 'RandR', false)
Map.addLayer(AnnH, annParams, 'AnnHerb')
Map.addLayer(FireN, fireParams, 'FireN')