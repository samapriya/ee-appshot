var sr = ui.import && ui.import("sr", "imageCollection", {
      "id": "users/ericjensen41_default/Thesis/Outputs/SpeciesRichness_GB"
    }) || ee.ImageCollection("users/ericjensen41_default/Thesis/Outputs/SpeciesRichness_GB"),
    gb = ui.import && ui.import("gb", "table", {
      "id": "users/ericjensen41_default/Thesis/Project_Boundaries/GBbounds"
    }) || ee.FeatureCollection("users/ericjensen41_default/Thesis/Project_Boundaries/GBbounds"),
    rap = ui.import && ui.import("rap", "imageCollection", {
      "id": "projects/rangeland-analysis-platform/vegetation-cover-v2"
    }) || ee.ImageCollection("projects/rangeland-analysis-platform/vegetation-cover-v2"),
    nlcd = ui.import && ui.import("nlcd", "image", {
      "id": "USGS/NLCD_RELEASES/2016_REL/2016"
    }) || ee.Image("USGS/NLCD_RELEASES/2016_REL/2016");
var palettes = require('users/gena/packages:palettes')
// -------------------------------- Model ----------------------------------
// Ag, wetland and Urban masks
// Create NLCD if-ever masks of agriculture and developed
var agWetMask = nlcd.select('landcover').lte(80)
var urbanMask = nlcd.select('landcover').gte(30)
// Tree Mask
var treeMask = rap.select('TREE').reduce(ee.Reducer.max()).lte(20)
// Agressive Range Mask
var rangeMask = ee.Image('users/chohnz/wga_Reeves_NLCD_range_mask_union').neq(1)
// Define the image collection.
sr = sr.map(function(img){
  return img.updateMask(treeMask).updateMask(urbanMask).updateMask(agWetMask)
            .set('year', ee.Number(ee.String(img.get('system:index')).slice(10,14)))
})
print(sr)
sr.imgInfo = {startYear: 1994,
  endYear: 2017,
}
var srParams = {
  min: 0,
  max: 40,
  palette: palettes.matplotlib.viridis[7]}
// -------------------------------- Components ----------------------------------
// Define a JSON object for storing UI components.
var c = {};
// Define a control panel for user input.
c.controlPanel = ui.Panel();
// Define a series of panel widgets to be used as horizontal dividers.
c.dividers = {};
c.dividers.divider1 = ui.Panel();
c.dividers.divider2 = ui.Panel();
// Define the main interactive map.
c.map = ui.Map();
// Define an app info widget group.
c.info = {};
c.info.titleLabel = ui.Label('Plant Species Richness in the Great Basin (1994-2017)'); 
c.info.aboutLabel1 = ui.Label( 
 "These annual maps of plant species richness depict spatial patterns of plant biodiversity in the Great Basin over almost a quarter of a century. " +
 "The dataset was developed based on 10,471 field inventories of plant species from the Bureau of Land Management's Assessment, Inventory, and Monitoring " +
 "program and the Natural Resources Conservation Service's National Resources Inventory program and a suite of 220 remote sensing, climate, fire, " +
 "topography, and soils variables.")
c.info.aboutLabel2 = ui.Label( 
 "Explore the data by using the year slider below to evaluate time-series patterns and by zooming/panning on the interative map. Enjoy!" )
c.info.paperLabel = ui.Label({
  value: 'Read the supporting thesis',
  targetUrl: 'https://mountainscholar.org/handle/10217/219564'
});
c.info.panel = ui.Panel([
  c.info.titleLabel, c.info.aboutLabel1,
  c.info.aboutLabel2, c.info.paperLabel
]);
// Define a data year selector widget group.
c.selectYear = {};
c.selectYear.label = ui.Label('Select a year to display');
c.selectYear.slider = ui.Slider({
  min: sr.imgInfo.startYear,
  max: sr.imgInfo.endYear,
  step: 1
});
c.selectYear.panel = ui.Panel([c.selectYear.label, c.selectYear.slider]);
c.selectYear.slider.setValue(ui.url.get('year', 2017), false); 
// Legend components
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x20',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(srParams.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(srParams.min, {margin: '4px 8px'}),
    ui.Label(
        (srParams.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(srParams.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Plant species richness (counts)',
  style: {fontWeight: 'bold'}
});
// Add the legendPanel to the map.
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels])
// -------------------------------- Compostition --------------------------------
c.controlPanel.add(c.info.panel);
c.controlPanel.add(c.dividers.divider1);
c.controlPanel.add(c.selectYear.panel);
c.controlPanel.add(c.dividers.divider2);
c.controlPanel.add(legendPanel);
ui.root.clear();
ui.root.add(c.controlPanel);
ui.root.add(c.map);
// -------------------------------- Styles --------------------------------
var s = {};
c.controlPanel.style().set({
  width: '275px',
  padding: '0px'
});
s.widgetTitle = {
  fontSize: '15px',
  fontWeight: 'bold',
  margin: '8px 8px 0px 8px',
  color: '383838'
};
s.stretchHorizontal = {
  stretch: 'horizontal'
};
s.opacityWhiteMed = {
  backgroundColor: 'rgba(255, 255, 255, 0.5)'
};
s.opacityWhiteNone = {
  backgroundColor: 'rgba(255, 255, 255, 0)'
};
s.aboutText = {
  fontSize: '13px',
  color: '505050'
};
s.divider = {
  backgroundColor: 'F0F0F0',
  height: '4px',
  margin: '20px 0px'
};
s.bigTopMargin = {
  margin: '24px 8px 8px 8px'
};
s.smallBottomMargin = {
  margin: '8px 8px 4px 8px'
};
// Set widget style.
c.info.titleLabel.style().set({
  fontSize: '20px',
  fontWeight: 'bold'
});
c.info.titleLabel.style().set(s.bigTopMargin);
c.info.aboutLabel1.style().set(s.aboutText);
c.info.aboutLabel2.style().set(s.aboutText);
c.info.paperLabel.style().set(s.aboutText);
c.info.paperLabel.style().set(s.smallBottomMargin);
c.selectYear.slider.style().set(s.stretchHorizontal);
c.selectYear.label.style().set(s.widgetTitle);
// Loop through setting divider style.
Object.keys(c.dividers).forEach(function(key) {
  c.dividers[key].style().set(s.divider);
});
c.map.setOptions('HYBRID');
// -------------------------------- Behaviors --------------------------------
// Handles year and band selection for new map layer display.
function updateMap() {
  var year = c.selectYear.slider.getValue().toString();
  var img = sr.filterMetadata('year', 'equals', year)
    .select('b1');
  var palette = palettes.matplotlib.viridis[7]
  var layer = ui.Map.Layer(
    img, {min:0, max:40, palette: palette}, 'Species richness');
  c.map.layers().set(0, layer);
}
c.map.setCenter({
  lon: -116.2,
  lat: 40.7,
  zoom: 7
});
c.selectYear.slider.onChange(updateMap);
// Render the map and legend.
updateMap();
var legendStyle = legendPanel.style()
legendStyle.set({position: 'bottom-right'})
// ui.root.add(legendPanel);