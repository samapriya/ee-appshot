var ndpdi = ui.import && ui.import("ndpdi", "imageCollection", {
      "id": "users/ericjensen41_default/NDPDI_app/NDPDI_all"
    }) || ee.ImageCollection("users/ericjensen41_default/NDPDI_app/NDPDI_all");
//  -------------------------------------------------------------------------------------------------
// NDPDI application to accompany JFSP report and future publications -------------------------------
// Author: Eric Jensen ------------------------------------------------------------------------------
// Adapted from code by Justin Braaten and Tyler Erickson -------------------------------------------
// June 26, 2021 ------------------------------------------------------------------------------------
//  -------------------------------------------------------------------------------------------------
/*******************************************************************************
 * Model *
 * 
 * A section to define information about the data being presented in your
 * app.
 * 
 * Guidelines: Use this section to import assets and define information that
 * are used to parameterize data-dependant widgets and control style and
 * behavior on UI interactions.
 ******************************************************************************/
// Define a JSON object for storing model info (app data).
var rangeMask = ee.Image('users/chohnz/wga_Reeves_NLCD_range_mask_union').neq(1)
var m = {};
// Define the image collection.
m.col = ndpdi.map(function(img){
  return img.updateMask(rangeMask)
})
// Separate image collection for charting
m.colChart = m.col.select('NDPDI')
// Define info about the bands in this collection that the app will present.
var palettes = require('users/gena/packages:palettes');
m.imgInfo = {
  bands: {
    'NDPDI (1984-2020)': {
      bname: 'NDPDI',
      color: '000000',
      vis: {
        min: 0,
        max: 2,
        palette: palettes.colorbrewer.RdYlGn[9]
      }
    },
    // 'Fire Severity (1984-2017)': {
    //   bname: 'FireSeverity',
    //   color: 'b30000',
    //   vis: {
    //     min: 0,
    //     max: 4,
    //     palette: ['006400', 'ffffffff', '7fffd4', 'ffff00', 'ff0000']
    //   }
    // },
    'Number of times burned (Static)': {
      bname: 'FireCount',
      color: '31a354',
      vis: {
        min: 1,
        max: 7,
        palette: palettes.matplotlib.inferno[7]
      }
    },
  },
  startYear: 1984,
  endYear: 2020,
};
// Separate chart bands
m.chartInfo = {
  bands: {
    'NDPDI': {
      bname: 'NDPDI',
      color: '000000',
      vis: {
        min: 0,
        max: 2,
      }
    },
  },
  startYear: 1984,
  endYear: 2020,
};
// Define information for example locations.
m.exLocInfo = {
  'West Basin Fire': {
    urlSlug: 'ex1',
    lon: -114.228248, lat: 41.983415, zoom: 15,
    desc: 'A highly resilient location that has maintained high NDPDI even after burning in 1992, 1996, 2000, and 2017.'
  },
  'Tuana Complex Fire': {
    urlSlug: 'ex2',
    lon: -115.51487, lat: 42.41613, zoom: 15,
    desc: 'A moderately resilient location that has been somewhat invaded but has maintained a perennial plant component after burning in 1985 and 1995.'
  },
  'Sombrero Fire': {
    urlSlug: 'ex3',
    lon: -118.07140, lat: 41.23485, zoom: 15,
    desc: 'A low resilience location that has had severe annual herbaceous invasion following fires in 1985 and 1999.'
  }
};
/*******************************************************************************
 * Components *
 * 
 * A section to define the widgets that will compose your app.
 * 
 * Guidelines:
 * 1. Except for static text and constraints, accept default values;
 *    initialize them in the initialization section.
 * 2. Limit composition of widgets to those belonging to an inseparable unit
 *    (i.e. a group of widgets that would make no sense out of order). 
 ******************************************************************************/
// Define a JSON object for storing UI components.
var c = {};
// Define a control panel for user input.
c.controlPanel = ui.Panel();
// Define a series of panel widgets to be used as horizontal dividers.
c.dividers = {};
c.dividers.divider1 = ui.Panel();
c.dividers.divider2 = ui.Panel();
c.dividers.divider3 = ui.Panel();
c.dividers.divider4 = ui.Panel();
// Define the main interactive map.
c.map = ui.Map();
// Define an app info widget group.
c.info = {};
c.info.titleLabel = ui.Label('Normalized difference perennial dominance index (NDPDI)');
c.info.sectionLabel1 = ui.Label('About NDPDI')
c.info.aboutLabel1 = ui.Label(
 'NDPDI is an indicator of rangeland plant functional group dominanced intended ' +
 'for use in the Great Basin. When analyzed through time, NDPDI can help to assess ' +
 'ecological resilience to fire and disturbance and resistance to invasive plants (R&R). ' +
 'For example, locations that maintain high values of NDPDI following fire likely have high R&R.')
c.info.sectionLabel2 = ui.Label('How to use the app')
c.info.aboutLabel2 = ui.Label( 
 'This application allows you to explore NDPDI time-series data in the context of fire frequency. ' +
 'Use the layer selector to switch between NDPDI and fire frequency data. The year slider allows you to ' +
 'evaluate spatial patterns and vegetation change through time. The example locations demonstrate ' +
 'high, moderate, and low R&R locations. Click any location on the map to see fire information and NDPDI ' +
 'data for any location.' )
c.info.sectionLabel3 = ui.Label('More information')
c.info.onePagerLabel = ui.Label({
  value: 'Learn more about NDPDI in this infographic',
  targetUrl: 'https://pdfhost.io/v/xfr6AEF5R_NDPDI_one_pagerpdf.pdf'
});
c.info.paperLabel = ui.Label({
  value: 'Read the supporting thesis',
  targetUrl: 'https://mountainscholar.org/handle/10217/219564'
});
c.info.contactLabel = ui.Label('Contact Eric Jensen at eric.jensen@umt.edu for more information.')
c.info.panel = ui.Panel([
  c.info.titleLabel, c.info.sectionLabel1, c.info.aboutLabel1, c.info.sectionLabel2, c.info.aboutLabel2, c.info.sectionLabel3, c.info.onePagerLabel,
  c.info.paperLabel, c.info.contactLabel
]);
// Define a data year selector widget group.
c.selectYear = {};
c.selectYear.label = ui.Label('Select a year to display');
c.selectYear.slider = ui.Slider({
  min: m.imgInfo.startYear,
  max: m.imgInfo.endYear,
  step: 1
});
c.selectYear.panel = ui.Panel([c.selectYear.label, c.selectYear.slider]);
// Define a data band selector widget group.
c.selectBand = {};
c.selectBand.label = ui.Label('Select a layer to display');
c.selectBand.selector = ui.Select(Object.keys(m.imgInfo.bands));
c.selectBand.panel = ui.Panel([c.selectBand.label, c.selectBand.selector]);
// Define an example location selector widget group.
c.selectExample = {};
c.selectExample.label = ui.Label('Example locations');
c.selectExample.selector = ui.Select({
  items: Object.keys(m.exLocInfo),
  placeholder: 'Select a location...',
});
c.selectExample.descLabel = ui.Label();
c.selectExample.panel = ui.Panel([
  c.selectExample.label,
  c.selectExample.selector,
  c.selectExample.descLabel
]);
// Define a legend widget group.
c.legend = {};
c.legend.title = ui.Label();
c.legend.colorbar = ui.Thumbnail(ee.Image.pixelLonLat().select(0));
c.legend.leftLabel = ui.Label('[min]');
c.legend.centerLabel = ui.Label();
c.legend.rightLabel = ui.Label('[max]');
c.legend.labelPanel = ui.Panel({
  widgets: [
    c.legend.leftLabel,
    c.legend.centerLabel,
    c.legend.rightLabel,
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
c.legend.panel = ui.Panel([
  c.legend.title,
  c.legend.colorbar,
  c.legend.labelPanel
]);
// Define a panel for displaying a chart.
c.chart = {};
c.chart.shownButton = ui.Button('Hide chart');
c.chart.container = ui.Panel();  // will hold the dynamically generated chart. 
c.chart.chartPanel = ui.Panel([c.chart.shownButton, c.chart.container]);
/*******************************************************************************
 * Composition *
 * 
 * A section to compose the app i.e. add child widgets and widget groups to
 * first-level parent components like control panels and maps.
 * 
 * Guidelines: There is a gradient between components and composition. There
 * are no hard guidelines here; use this section to help conceptually break up
 * the composition of complicated apps with many widgets and widget groups.
 ******************************************************************************/
c.controlPanel.add(c.info.panel);
c.controlPanel.add(c.dividers.divider1);
c.controlPanel.add(c.selectBand.panel);
c.controlPanel.add(c.dividers.divider2);
c.controlPanel.add(c.selectYear.panel);
c.controlPanel.add(c.dividers.divider3);
c.controlPanel.add(c.selectExample.panel);
c.controlPanel.add(c.dividers.divider4);
c.map.add(c.legend.panel);
c.map.add(c.chart.chartPanel);
ui.root.clear();
ui.root.add(c.controlPanel);
ui.root.add(c.map);
/*******************************************************************************
 * Styling *
 * 
 * A section to define and set widget style properties.
 * 
 * Guidelines:
 * 1. At the top, define styles for widget "classes" i.e. styles that might be
 *    applied to several widgets, like text styles or margin styles.
 * 2. Set "inline" style properties for single-use styles.
 * 3. You can add multiple styles to widgets, add "inline" style followed by
 *    "class" styles. If multiple styles need to be set on the same widget, do
 *    it consecutively to maintain order.
 ******************************************************************************/
// Define CSS-like class style properties for widgets; reusable styles.
var s = {};
s.opacityWhiteMed = {
  backgroundColor: 'rgba(255, 255, 255, 0.5)'
};
s.opacityWhiteNone = {
  backgroundColor: 'rgba(255, 255, 255, 0)'
};
s.aboutText = {
  fontSize: '13px',
  color: '505050',
  margin: '0px 8px 6px 8px',
};
s.sectionText1 = {
  fontSize: '14px',
  fontWeight: 'bold',
  color: '505050'
};
s.sectionText2 = {
  fontSize: '14px',
  fontWeight: 'bold',
  margin: '16px 8px 8px 8px',
  color: '505050'
};
s.widgetTitle = {
  fontSize: '15px',
  fontWeight: 'bold',
  margin: '8px 8px 0px 8px',
  color: '383838'
};
s.stretchHorizontal = {
  stretch: 'horizontal'
};
s.noTopMargin = {
  margin: '0px 8px 8px 8px'
};
s.smallBottomMargin = {
  margin: '8px 8px 4px 8px'
};
s.bigTopMargin = {
  margin: '24px 8px 8px 8px'
};
s.divider = {
  backgroundColor: 'F0F0F0',
  height: '4px',
  margin: '20px 0px'
};
// Set widget style.
c.info.titleLabel.style().set({
  fontSize: '20px',
  fontWeight: 'bold'
});
c.info.titleLabel.style().set(s.bigTopMargin);
c.info.sectionLabel1.style().set(s.sectionText1)
c.info.sectionLabel2.style().set(s.sectionText2)
c.info.sectionLabel3.style().set(s.sectionText2)
c.info.aboutLabel1.style().set(s.aboutText);
c.info.aboutLabel2.style().set(s.aboutText);
c.info.paperLabel.style().set(s.aboutText);
c.info.onePagerLabel.style().set(s.aboutText);
c.info.contactLabel.style().set(s.smallBottomMargin);
c.info.contactLabel.style().set(s.aboutText);
c.selectYear.slider.style().set(s.stretchHorizontal);
c.selectYear.label.style().set(s.widgetTitle);
c.selectBand.selector.style().set(s.stretchHorizontal);
c.selectBand.label.style().set(s.widgetTitle);
c.selectExample.selector.style().set(s.stretchHorizontal);
c.selectExample.label.style().set(s.widgetTitle);
c.selectExample.descLabel.style().set(s.aboutText);
c.selectExample.descLabel.style().set(s.noTopMargin);
c.controlPanel.style().set({
  width: '275px',
  padding: '0px'
});
c.map.style().set({
  cursor: 'crosshair'
});
c.map.setOptions('HYBRID');
c.chart.chartPanel.style().set({
  position: 'bottom-right',
  shown: false
});
c.chart.chartPanel.style().set(s.opacityWhiteMed);
c.chart.shownButton.style().set({
  margin: '0px 0px',
});
c.legend.title.style().set({
  fontWeight: 'bold',
  fontSize: '12px',
  color: '383838'
});
c.legend.title.style().set(s.opacityWhiteNone);
c.legend.colorbar.style().set({
  stretch: 'horizontal',
  margin: '0px 8px',
  maxHeight: '20px'
});
c.legend.leftLabel.style().set({
  margin: '4px 8px',
  fontSize: '12px'
});
c.legend.leftLabel.style().set(s.opacityWhiteNone);
c.legend.centerLabel.style().set({
  margin: '4px 8px',
  fontSize: '12px',
  textAlign: 'center',
  stretch: 'horizontal'
});
c.legend.centerLabel.style().set(s.opacityWhiteNone);
c.legend.rightLabel.style().set({
  margin: '4px 8px',
  fontSize: '12px'
});
c.legend.rightLabel.style().set(s.opacityWhiteNone);
c.legend.panel.style().set({
  position: 'bottom-left',
  width: '200px',
  padding: '0px'});
c.legend.panel.style().set(s.opacityWhiteMed);
c.legend.labelPanel.style().set(s.opacityWhiteNone);
// Loop through setting divider style.
Object.keys(c.dividers).forEach(function(key) {
  c.dividers[key].style().set(s.divider);
});
/*******************************************************************************
 * Behaviors *
 * 
 * A section to define app behavior on UI activity.
 * 
 * Guidelines:
 * 1. At the top, define helper functions and functions that will be used as
 *    callbacks for multiple events.
 * 2. For single-use callbacks, define them just prior to assignment. If multiple
 *    callbacks are required for a widget, add them consecutively to maintain
 *    order; single-use followed by multi-use.
 * 3. As much as possible, include callbacks that update URL parameters.
 ******************************************************************************/
function getPropertyValueList(dataModelDict, propertyName){
  // Get a list of values for a specified property name.
  var result = [];
  for (var key in dataModelDict) {
    result.push(dataModelDict[key][propertyName]);
  }
  return result;
}
// Handles drawing the legend when band selector changes.
function updateLegend() {
  c.legend.title.setValue(c.selectBand.selector.getValue());
  c.legend.colorbar.setParams({
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: m.imgInfo.bands[c.selectBand.selector.getValue()].vis.palette
  });
  c.legend.leftLabel.setValue(
    m.imgInfo.bands[c.selectBand.selector.getValue()].vis.min);
  c.legend.centerLabel.setValue(
    m.imgInfo.bands[c.selectBand.selector.getValue()].vis.max / 2);
  c.legend.rightLabel.setValue(
    m.imgInfo.bands[c.selectBand.selector.getValue()].vis.max);
}
// Handles year and band selection for new map layer display.
function updateMap() {
  var year = c.selectYear.slider.getValue();
  var band = c.selectBand.selector.getValue();
  var img = m.col.filter(ee.Filter.eq('year', parseInt(year, 10)))
    .select(m.imgInfo.bands[band].bname);
  var layer = ui.Map.Layer(
    img, m.imgInfo.bands[band].vis, band + ', ' + year);
  c.map.layers().set(0, layer);
}
// Handles map clicks for charting.
function drawChart(coords) {
  // Get out if call to drawChart did not come from map click and the chart
  // has not been drawn previously.
  if (!coords.lon) {
    return null;
  }
  // Get out if the clicked point intersects invalid data.
  var point = ee.Geometry.Point([coords.lon, coords.lat]);
  var validDataTest = m.colChart.first().select(0).reduceRegion({
    reducer: ee.Reducer.first(),
    geometry: point,
    scale: m.colChart.first().projection().nominalScale()
  });
  if (!validDataTest.get(validDataTest.keys().get(0)).getInfo()) {
    return null;
  }
  // Show the chart panel if this is the first time a point is clicked.
  if (!c.chart.chartPanel.style().get('shown')) {
    c.chart.chartPanel.style().set('shown', true);
  }
  // Show chart if hidden; assuming user wants to see updates to chart.
  if (c.chart.shownButton.getLabel() == 'Show chart') {
    c.chart.container.style().set({shown: true});
    c.chart.shownButton.setLabel('Hide chart');
  }
  var layer = ui.Map.Layer(
    point.buffer(30), {color: 'FF0000'}, 'Chart region');
  c.map.layers().set(1, layer);
  var styleChartAxis = {
    italic: false,
    bold: true
  };
  var styleChartArea = {
    width: '600px',
    height: '255px',
    margin: '0px',
    padding: '0px'
  }; 
  var yearsBurned = ee.List(m.col.select('FireYear').toBands().reduceRegion(ee.Reducer.mean(), point)
                              .values())
                              .distinct()
                              .filter(ee.Filter.gte('item', 1984))
                              .flatten()
  var chart = ui.Chart.image.series({
    imageCollection: m.colChart.select(
      getPropertyValueList(m.chartInfo.bands, 'bname')),
    region: point.buffer(30),
    reducer: ee.Reducer.mean(),
    scale: m.col.first().projection().nominalScale()
  })
  .setSeriesNames(Object.keys(m.chartInfo.bands))
  .setChartType('LineChart')
  .setOptions({
    title: 'This location has burned ' + yearsBurned.length().getInfo().toString() +' time(s): ' + yearsBurned.getInfo().toString(), 
    colors: getPropertyValueList(m.chartInfo.bands, 'color'),
    hAxis: {
      title: 'Year',
      titleTextStyle: styleChartAxis
    },
    vAxis: {
      title: 'NDPDI',
      titleTextStyle: styleChartAxis,
      viewWindow: {min: 0, max: 2}
    },
    legend: {maxLines: 2},
    isStacked: 'percent'
  });
  chart.style().set(styleChartArea);
  c.chart.container.widgets().reset([chart]);
}
// Handles example location selection.
function zoomToLoc(loc) {
  c.selectExample.descLabel.setValue(m.exLocInfo[loc].desc);
  c.map.setCenter(
    m.exLocInfo[loc].lon + 0.01,  // shift map left to avoid chart.
    m.exLocInfo[loc].lat,
    m.exLocInfo[loc].zoom);
  var coords = {lon: m.exLocInfo[loc].lon, lat: m.exLocInfo[loc].lat};
  drawChart(coords);
  updateUrlParamChart(coords);
}
function showHideChart() {
  var shown = true;
  var label = 'Hide chart';
  if (c.chart.shownButton.getLabel() == 'Hide chart') {
    shown = false;
    label = 'Show chart';
  }
  c.chart.container.style().set({shown: shown});
  c.chart.shownButton.setLabel(label);
}
c.chart.shownButton.onClick(showHideChart);
function updateUrlParamYear(newValue) {
  ui.url.set('year', newValue);
}
c.selectYear.slider.onChange(updateUrlParamYear);
c.selectYear.slider.onChange(updateMap);
function updateUrlParamBand(newValue) {
  var bands = getPropertyValueList(m.imgInfo.bands, 'bname');
  ui.url.set('band', m.imgInfo.bands[newValue].bname);
}
c.selectBand.selector.onChange(updateUrlParamBand);
c.selectBand.selector.onChange(updateMap);
c.selectBand.selector.onChange(updateLegend);
function updateUrlParamExample(newValue) {
  ui.url.set('example', m.exLocInfo[newValue].urlSlug);
}
c.selectExample.selector.onChange(updateUrlParamExample);
c.selectExample.selector.onChange(zoomToLoc);
function updateUrlParamMap(newMapParams) {
  ui.url.set('lat', newMapParams.lat);
  ui.url.set('lon', newMapParams.lon);
  ui.url.set('zoom', newMapParams.zoom);
}
c.map.onChangeBounds(ui.util.debounce(updateUrlParamMap, 100));
function updateUrlParamChart(newChartParams) {
  ui.url.set('chart_lat', newChartParams.lat);
  ui.url.set('chart_lon', newChartParams.lon);
}
c.map.onClick(drawChart);
c.map.onClick(updateUrlParamChart);
/*******************************************************************************
 * Initialize *
 * 
 * A section to initialize the app state on load.
 * 
 * Guidelines:
 * 1. At the top, define any helper functions.
 * 2. As much as possible, use URL params to initialize the state of the app.
 ******************************************************************************/
function findKey(dataModelDict, propertyName, propertyValue){
  // Find the first dictionary key for a specified property value.
  for (var key in dataModelDict) {
    if (dataModelDict[key][propertyName] == propertyValue) {
      return key;
    }
  }
  return null;
}
// Set model state based on URL parameters or default values.  
c.map.setCenter({
  lon: ui.url.get('lon', -116.2),
  lat: ui.url.get('lat', 40.7),
  zoom: ui.url.get('zoom', 7)
});
c.selectYear.slider.setValue(ui.url.get('year', 2020), false); 
c.selectBand.selector.setValue(
  findKey(m.imgInfo.bands, 'bname', ui.url.get('band', 'NDPDI')), 
  false);
c.selectExample.selector.setValue(
  findKey(m.exLocInfo, 'urlSlug', ui.url.get('example')),
  false);
if (ui.url.get('example')) {
  c.selectExample.descLabel.setValue(
    m.exLocInfo[c.selectExample.selector.getValue()].desc);
}
// Render the map and legend.
updateMap();
updateLegend();
// Render the chart if applicable (chart_lon exists as URL param).
drawChart({lon: ui.url.get('chart_lon'), lat: ui.url.get('chart_lat')});