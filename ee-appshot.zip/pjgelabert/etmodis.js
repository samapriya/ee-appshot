var title = ui.Label('APP PARA CALCULAR ET CON MODIS DESDE SU LANZAMIENTO HASTA LA ACTUALIDAD');
title.style().set('position', 'top-center');
Map.add(title);
// Center the map
Map.setCenter(1.661389, 42.098889, 8);
var dataset = ee.ImageCollection('MODIS/006/MOD16A2')
                  .filter(ee.Filter.date('2002-01-01', '2018-12-31'));
var evapotranspiration = dataset.select('ET');
var evapotranspirationVis = {
  min: 0.0,
  max: 300.0,
  palette: [
    'ffffff', 'fcd163', '99b718', '66a000', '3e8601', '207401', '056201',
    '004c00', '011301'
  ],
};
// Ubication of eddy covariance Towers
var torre1 = ee.Geometry.Point([1.661389, 42.098889]);
var torre2 = ee.Geometry.Point([1.513333, 42.063333]);
var torre3 = ee.Geometry.Point([2.033568, 42.305014]);
Map.addLayer(evapotranspiration, evapotranspirationVis, 'Evapotranspiration');
//Representacion Torres EDDY COVARIANCE
Map.addLayer(torre1,{'color':'FF0000'} ,'Bertolina');
Map.addLayer(torre2,{'color':'FF0000'} ,'Pla de Riart');
Map.addLayer(torre3,{'color':'FF0000'} ,'Castellar');
// Create a panel with vertical flow layout.
var panel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {width: '500px'}
});
//BUTTONS and CHARTS
var p1= panel.add( ui.Button({
  label: 'ET a La Bertolina',
  onClick: function(t1) {
  var chart = ui.Chart.image.series(dataset.select('ET'), torre1, null, 30);
  chart.setOptions({title: 'ET MODIS a La Bertolina'});
  panel.add(chart);}
  }));
var p2 = panel.add( ui.Button({
  label: 'ET a Pla de Riart',
  onClick: function(t2) {
  var chart2 = ui.Chart.image.series(dataset.select('ET'), torre2, null, 30);
  chart2.setOptions({title: 'ET MODIS a Pla de Riart'});
  panel.add(chart2);}
}));
var p3 = panel.add( ui.Button({
  label: 'ET a Castellar',
  onClick: function(t3) {
  var chart3 = ui.Chart.image.series(dataset.select('ET'), torre3, null, 30);
  chart3.setOptions({title: 'ET MODIS a Castellar'});
  panel.add(chart3);}
}));
ui.root.add(panel);
// Register a function to draw a chart when a user clicks on the map.
Map.onClick(function(coords) {
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chart4 = ui.Chart.image.series(dataset.select('ET'), point, null, 30);
  chart4.setOptions({title: 'ET MODIS onClick'});
  panel.add(chart4);
});