var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -29.61638577743385,
                46.54918537729621
              ],
              [
                -29.61638577743385,
                24.993221649011122
              ],
              [
                7.1218954725661465,
                24.993221649011122
              ],
              [
                7.1218954725661465,
                46.54918537729621
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-29.61638577743385, 46.54918537729621],
          [-29.61638577743385, 24.993221649011122],
          [7.1218954725661465, 24.993221649011122],
          [7.1218954725661465, 46.54918537729621]]], null, false),
    geometry2 = ui.import && ui.import("geometry2", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -17.38938986293039,
            28.189053783179276
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    ee.Geometry.Point([-17.38938986293039, 28.189053783179276]),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "SO2_column_number_density"
        ],
        "min": -0.001271945760625273,
        "max": 0.0019477324577516434,
        "palette": [
          "000000",
          "0000ff",
          "800080",
          "00ffff",
          "008000",
          "ffff00",
          "ff0000"
        ]
      }
    }) || {"opacity":1,"bands":["SO2_column_number_density"],"min":-0.001271945760625273,"max":0.0019477324577516434,"palette":["000000","0000ff","800080","00ffff","008000","ffff00","ff0000"]};
Map.setOptions('TERRAIN');
var label = ui.Label({
  value:'Sentinel-5P Sulphur Dioxide SO₂ - Cumbre Vieja volcano (La Palma)',
  style:{fontWeight: 'bold'}
});
Map.add(label);
var start = "2021-09-20";
var now = Date.now();
var end = ee.Date(now).advance(-1,"day").format();
print(end)
var dataset = ee.FeatureCollection("FAO/GAUL/2015/level0");
var styleParams = {
  fillColor: "#00000000",
  color: '#ffff00',
  width: 2.0,
  };
    var dataset = dataset.style(styleParams);
var band_viz = {
    min:0,
    max: 0.04,
    palette: ['black', 'blue', 'purple', 'cyan', 'green', 'yellow', 'red']
    };
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(imageVisParam.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label("0", {margin: '4px 8px'}),
    ui.Label(
        ("1000"),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(">2000", {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'SO₂ Column µmol/m²',
  style: {fontWeight: 'bold'}
});
// Add the legendPanel to the map.
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
legendPanel.style().set({
  width: '400px',
  position: 'bottom-left'
});
Map.add(legendPanel);
var collection = ee.ImageCollection('COPERNICUS/S5P/NRTI/L3_SO2')
  .select('SO2_column_number_density')
  .filterDate(start, end)
  .filterBounds(geometry)
var showMosaic = function(range) {
  var mosaic =  collection.filterDate(range.start(), range.end())
  // Asynchronously compute the name of the composite.  Display it.
  range.start().get('year').evaluate(function(name) {
    var band_viz = {
    min:-0.014351547972374132,
    max: 0.037446921210556594,
    palette: ['black', 'blue', 'purple', 'cyan', 'green', 'yellow', 'red']
    };
    var layer = ui.Map.Layer(mosaic, imageVisParam,  'S02');
    var count= ui.Map.Layer(dataset, {}, 'Country Boundaries');
    Map.layers().set(0, layer);
    Map.layers().set(1, count);
  });
};
// Asynchronously compute the date range and show the slider.
var dateRange = ee.DateRange(start, end).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: 1,
    onChange: showMosaic,
  });
  dateSlider.style().set({
  width: '500px',
  position: 'bottom-center'
});
  Map.add(dateSlider.setValue(now));
});
Map.centerObject(geometry2,4)