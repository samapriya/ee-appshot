// NDVI_MODIS.
// 2000-02-18 - Present
// Compute Normalized Difference Vegetation Index over MCD43A4.006 MODIS Nadir BRDF-Adjusted Reflectance, daily 500m.
// NDVI = (NIR - RED) / (NIR + RED), where
// RED is Nadir_Reflectance_Band1, 620-670nm
// NIR is Nadir_Reflectance_Band2, 841-876nm
// Create a geometry representing an export region.
var geometry = /* color: #d63000 */ee.Geometry.Polygon(
        [[[1.5844847031249856, 42.037721533294345],
          [1.6174436874999856, 41.951988077607886],
          [1.4663816757812356, 41.9356448026395],
          [1.4416624374999856, 41.82317140008059],
          [1.6916014023437356, 41.80474781623859],
          [2.2216917343749856, 41.82112459691016],
          [2.3892332382812356, 42.2190130514193],
          [1.5982176132812356, 42.15185312528914]]]);
var title = ui.Label('APP PARA CALCULAR NDVI CON MODIS DESDE SU LANZAMIENTO HASTA LA ACTUALIDAD');
title.style().set('position', 'top-center');
Map.add(title);
//DATE VARIABLES
var start = '2000-05-31'
var now = Date.now();
var end = ee.Date(now).format();
// Load a MODIS image.
var dataset = ee.ImageCollection("MODIS/006/MCD43A4")
                  .filter(ee.Filter.date(start, '2018-03-04'))
                  .filterBounds(geometry);
var image= ee.Image (dataset.median())
var ndvi_st = image.normalizedDifference(['Nadir_Reflectance_Band2', 'Nadir_Reflectance_Band1']);
print(image)
//Palette for represent NDVI.
var palette = ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
              '74A901', '66A000', '529400', '3E8601', '207401', '056201',
              '004C00', '023B01', '012E01', '011D01', '011301'];
// Export the image, specifying scale and region.
Export.image.toDrive({
  image: ndvi_st,
  description: 'imageToDriveExample',
  scale: 30,
  region: geometry
});
//Representation NDVI map.
Map.addLayer(ndvi_st, {min: -1, max: 1, palette: palette}, 'NDVI');
//NDVI para toda la serie temporal
var addNDVI = function(image) {
  var ndvi = image.normalizedDifference([ 'Nadir_Reflectance_Band2', 'Nadir_Reflectance_Band1']).rename('NDVI');
  return image.addBands(ndvi);
};
var withNDVI = dataset.map(addNDVI)
// Create a panel with vertical flow layout.
var panel = ui.Panel({
  style: {width: '500px',
    position:'bottom-right'
  }
});
Map.add(panel)
// Register a function to draw a chart when a user clicks on the map.
Map.onClick(function(coords) {
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chart4 = ui.Chart.image.series(withNDVI.select('NDVI'), point, null, 30);
  chart4.setOptions({title: 'NDVI MODIS onClick'});
  panel.add(chart4);
});