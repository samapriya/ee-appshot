var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -4.407423566302426,
                41.19193389306667
              ],
              [
                -4.407423566302426,
                39.5515468832505
              ],
              [
                -2.8253923163024264,
                39.5515468832505
              ],
              [
                -2.8253923163024264,
                41.19193389306667
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#23cba7",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || 
    /* color: #23cba7 */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[-4.407423566302426, 41.19193389306667],
          [-4.407423566302426, 39.5515468832505],
          [-2.8253923163024264, 39.5515468832505],
          [-2.8253923163024264, 41.19193389306667]]], null, false);
var SP = ee.FeatureCollection('USDOS/LSIB_SIMPLE/2017')
.filter(ee.Filter.eq("country_co", "SP"));
var end =ee.Date('2020-08-31');
var end1 = ee.Date('2019-08-31');
var multiply = function(img) {
    var rescaled_NDVI = img.select('NO2_column_number_density')
                           .multiply(46.0055)
                           .multiply(1000)
                           .rename('NO2_rescaled');
    return img.addBands(rescaled_NDVI);
  }
var collection = ee.ImageCollection('COPERNICUS/S5P/NRTI/L3_NO2')
  .select('NO2_column_number_density')
  .filterBounds(SP)
  .filterDate('2019-03-13', end1)
  .map(multiply);
print(collection)
var collection2 = ee.ImageCollection('COPERNICUS/S5P/NRTI/L3_NO2')
  .select('NO2_column_number_density')
  .filterBounds(SP)
  .filterDate('2020-03-13', end)
  .map(multiply);
var collection3 = collection.merge(collection2)
var band_viz = {
  min: 0,
  max: 9.021,
  palette: ['black', 'blue', 'purple', 'cyan', 'green', 'yellow', 'red'],
  opacity: 0.5
};
Map.addLayer(collection2.mean().select("NO2_rescaled"), band_viz, '2020');
Map.addLayer(collection.mean().select("NO2_rescaled"), band_viz, '2019');
Map.centerObject(SP, 5);
var image= collection.mean().select("NO2_rescaled")
// Define a chart with a a different series for each year in the forest region.
var drawingTools = Map.drawingTools();
drawingTools.setShown(false);
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
var dummyGeometry =
  ui.Map.GeometryLayer({
    geometries: null,
    name: 'geometry',
    color: '23cba7'
  });
drawingTools.layers().add(dummyGeometry);
function clearGeometry() {
  var layers = drawingTools.layers();
  layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
}
function drawRectangle() {
  clearGeometry();
  drawingTools.setShape('rectangle');
  drawingTools.draw();
}
function drawPolygon() {
  clearGeometry();
  drawingTools.setShape('polygon');
  drawingTools.draw();
}
var chartPanel = ui.Panel({
  style: {
    height: '300px',
    width: '750px',
    position: 'bottom-right',
    shown: false
  }
});
Map.add(chartPanel);
function chartAreaByClass() {
  // Make the chart panel visible the first time a geometry is drawn.
  if (!chartPanel.style().get('shown')) {
    chartPanel.style().set('shown', true);
  }
  // Get the drawn geometry; it will define the reduction region.
  var aoi = drawingTools.layers().get(0).getEeObject();
  // Set the drawing mode back to null; turns drawing off.
  drawingTools.setShape(null);
  // Reduction scale is based on map scale to avoid memory/timeout errors.
  var mapScale = Map.getScale();
  var scale = mapScale > 5000 ? mapScale * 2 : 5000;
  // The original tutorial charts NDVI time series.
  // Here, I created a chart showing area size by class for the polygon.
  var chart =ui.Chart.image.doySeriesByYear(
    collection3,"NO2_rescaled", aoi, ee.Reducer.mean(), 1000,ee.Reducer.mean(),1,365)
    .setOptions({
      title: 'NO2 (mg/m2)',
      hAxis: {title: 'Day of year'},
      vAxis: {title: 'NO2 (mg/m2)'}
    });
  // Replace the existing chart in the chart panel with the new chart.
  chartPanel.widgets().reset([chart]);
}
drawingTools.onDraw(ui.util.debounce(chartAreaByClass, 500));
drawingTools.onEdit(ui.util.debounce(chartAreaByClass, 500));
var symbol = {
  rectangle: '⬛',
  polygon: '🔺',
};
var controlPanel = ui.Panel({
  widgets: [
    ui.Label('1. Select a drawing mode.'),
    ui.Button({
      label: symbol.rectangle + ' Rectangle',
      onClick: drawRectangle,
      style: {
        stretch: 'horizontal'
      }
    }),
    ui.Button({
      label: symbol.polygon + ' Polygon',
      onClick: drawPolygon,
      style: {
        stretch: 'horizontal'
      }
    }),
    ui.Label('2. Draw a geometry.'),
    ui.Label('3. Wait for chart to render.'),
    ui.Label(
      '4. Repeat 1-3 or edit/move\ngeometry for a new chart.', {
        whiteSpace: 'pre'
      })
  ],
  style: {
    position: 'bottom-left'
  },
  layout: null,
});
Map.add(controlPanel);