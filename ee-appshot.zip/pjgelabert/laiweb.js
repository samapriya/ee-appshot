var title = ui.Label('CLICK ON MAP');
title.style().set('position', 'top-center');
Map.add(title);
// Center the map
Map.setCenter(1.661389, 42.098889, 8);
var dataset = ee.ImageCollection("MODIS/006/MCD15A3H")
                  .filter(ee.Filter.date('2002-01-01', '2018-12-31'));
var LAI = dataset.select('Lai');
var LAIVis = {
  min: 0.0,
  max: 100.0,
  palette: ['e1e4b4', '999d60', '2ec409', '0a4b06'],
};
// Ubication of eddy covariance Towers
var torre1 = ee.Geometry.Point([1.661389, 42.098889]);
var torre2 = ee.Geometry.Point([1.513333, 42.063333]);
var torre3 = ee.Geometry.Point([2.033568, 42.305014]);
Map.addLayer(LAI, LAIVis, 'LAI');
//Representacion Torres EDDY COVARIANCE
//Map.addLayer(torre1,{'color':'FF0000'} ,'Bertolina');
//Map.addLayer(torre2,{'color':'FF0000'} ,'Pla de Riart');
//Map.addLayer(torre3,{'color':'FF0000'} ,'Castellar');
// Create a panel with vertical flow layout.
// Create a panel with vertical flow layout.
var panel = ui.Panel()
  panel.style().set({
  width: '400px',
  position: 'bottom-right'
});
Map.add(panel)
// Register a function to draw a chart when a user clicks on the map.
Map.onClick(function(coords) {
  panel.clear();
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chart4 = ui.Chart.image.series(dataset.select('Lai'), point, null, 30);
  chart4.setOptions({title: 'NDVI (L7) onClick'});
  panel.add(chart4);
});