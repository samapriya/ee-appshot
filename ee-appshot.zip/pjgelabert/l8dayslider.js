//Title
var label = ui.Label('Day slider LANDSAT 8 imagery');
Map.add(label);
var WRS= ee.FeatureCollection("users/pjgelabert/WRS2_descending");
// Use a DateSlider to create annual composites of this collection.
var now = Date.now();
var end1 = (ee.Date(now).format());
var d = new Date();
d.setDate(d.getDate() - 31);
print(d)
var redCollection = ee.ImageCollection('LANDSAT/LC08/C01/T1')
    .filterDate(d, end1)
    .sort('DATE_ACQUIRED');
var listOfImages = redCollection.toList(redCollection.size());
var sizecol = ee.Number(redCollection.size())
var size = sizecol.subtract(1);
var last_img = ee.Image(listOfImages.get(size));
var collection = ee.ImageCollection('LANDSAT/LC08/C01/T1');
// Use the start of the collection and now to bound the slider.
var start = ee.Image(collection.first()).date().get('year').format();
var end = ee.Date(last_img.get('system:time_end'));
// Run this function on a change of the dateSlider.
var showMosaic = function(range) {
  var mosaic = ee.Algorithms.Landsat.simpleComposite({
    collection: collection.filterDate(range.start(), range.end())
  });
  var empty = ee.Image().byte();
    var outline = empty.paint({
    featureCollection: WRS,
    color: '0000ff',
    width: 1
});
  // Asynchronously compute the name of the composite.  Display it.
  range.start().get('year').evaluate(function(name) {
    var visParams = {bands: ['B4', 'B3', 'B2'], max: 100};
    var visParams2 = {palette: '0000ff'}
    var layer = ui.Map.Layer(mosaic, visParams, name + ' composite');
    var wrs_l= ui.Map.Layer(outline, visParams2, 'WRS');
    Map.layers().set(0, layer);
    Map.layers().set(1, wrs_l);
  });
};
// Asynchronously compute the date range and show the slider.
var dateRange = ee.DateRange(start, end).evaluate(function(range) {
  var dateSlider = ui.DateSlider({
    start: range['dates'][0],
    end: range['dates'][1],
    value: null,
    period: 1,
    onChange: showMosaic,
  });
  dateSlider.style().set({
  width: '1000px',
  position: 'bottom-center'
});
  Map.add(dateSlider.setValue(now));
});
Map.setCenter(-3.6945016945504676, 40.538000800608465,5)