// NDVI_LANDSAT_7.
// 1999 - Present
// Compute Normalized Difference Vegetation Index over USGS Landsat 8 Surface Reflectance (30m).
// NDVI = (NIR - RED) / (NIR + RED), where
// RED is B4, 0.636-0.673 μm
// NIR is B5, 0.851-0.879 μm
var title = ui.Label('CLICK ON MAP');
title.style().set('position', 'top-center');
Map.add(title);
//DATE VARIABLES
var start = '1999-07-14'
var now = Date.now();
var end = ee.Date(now).format();
// Load a MODIS image.
var dataset = ee.ImageCollection("LANDSAT/LE07/C01/T1_SR")
                  .filter(ee.Filter.date(start, end))
                  //.filter(ee.Filter.eq('WRS_PATH', 198))
                  //.filter(ee.Filter.eq('WRS_ROW', 31))
                  .filter(ee.Filter.lt('CLOUD_COVER', 10));
//Palette for represent NDVI.
var palette_1 = ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
              '74A901', '66A000', '529400', '3E8601', '207401', '056201',
              '004C00', '023B01', '012E01', '011D01', '011301'];
// Ubication of eddy covariance Towers
var torre1 = ee.Geometry.Point([1.661389, 42.098889]);
var torre2 = ee.Geometry.Point([1.513333, 42.063333]);
var torre3 = ee.Geometry.Point([2.033568, 42.305014]);
// Center the map
Map.setCenter(1.661389, 42.098889, 9);
// Representation RGB map.
//Map.addLayer(dataset.select(['B3', 'B2', 'B1']),
         //{gain: [0.1, 0.1, 0.1]}, 'LANDSAT RGB');
//Representacion Torres EDDY COVARIANCE
//Map.addLayer(torre1,{'color':'FF0000'} ,'Bertolina');
//Map.addLayer(torre2,{'color':'FF0000'} ,'Pla de Riart');
//Map.addLayer(torre3,{'color':'FF0000'} ,'Castellar');
//NDVI para toda la serie temporal
var addNDVI = function(image) {
  var ndvi = image.normalizedDifference(['B4', 'B3']).rename('NDVI');
  return image.addBands(ndvi);
};
var withNDVI = dataset.map(addNDVI)
var mpndvi= withNDVI.select('NDVI').mean();
Map.addLayer(mpndvi,{palette:palette_1, min:-0.1, max: 1},'NDVI');
// Create a panel with vertical flow layout.
var panel = ui.Panel()
  panel.style().set({
  width: '400px',
  position: 'bottom-right'
});
//BUTTONS and CHARTS
//var p1= panel.add( ui.Button({
  //label: 'NDVI a La Bertolina',
 // onClick: function(t1) {
  //var chart = ui.Chart.image.series(withNDVI.select('NDVI'), torre1, null, 30);
  //chart.setOptions({title: 'NDVI (L8) a La Bertolina'});
 // panel.add(chart);}
 // }));
//var p2 = panel.add( ui.Button({
 // label: 'NDVI a Pla de Riart',
 // onClick: function(t2) {
 // var chart2 = ui.Chart.image.series(withNDVI.select('NDVI'), torre2, null, 30);
 // chart2.setOptions({title: 'NDVI (L8) a Pla de Riart'});
 // panel.add(chart2);}
//
//var p3 = panel.add( ui.Button({
  //label: 'NDVI a Castellar',
  //onClick: function(t3) {
  //var chart3 = ui.Chart.image.series(withNDVI.select('NDVI'), torre3, null, 30);
  //chart3.setOptions({title: 'NDVI (L8) a Castellar'});
  //panel.add(chart3);}
//}));
Map.add(panel);
// Register a function to draw a chart when a user clicks on the map.
Map.onClick(function(coords) {
  panel.clear();
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chart4 = ui.Chart.image.series(withNDVI.select('NDVI'), point, null, 30);
  chart4.setOptions({title: 'NDVI (L7) onClick'});
  panel.add(chart4);
});