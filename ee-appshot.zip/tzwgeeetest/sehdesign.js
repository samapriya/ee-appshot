var tzwapp={
  data:{
    startyear:"2020",
    startmonth:"4",
    endmonth:"9",
    proviencename:" ",
    cloud_cover:"50",
    dataisok:false,
    ndwi:false,
    ndvi:false
  },
  config:{
  }
};
var main=require("users/tzwgeeetest/train0122:example01/main");
var proviencelistname=["北京市","安徽省","澳门特别行政区","安徽省","福建省","甘肃省",
"广东省","广西壮族自治区","贵州省","海南省","河北省","河南省","黑龙江省",
"湖北省","湖南省","吉林省","江苏省","江西省","辽宁省","内蒙古自治区",
"宁夏回族自治区","青海省","山东省","山西省","陕西省","上海市","四川省",
"台湾省","天津市","西藏自治区","香港特别行政区","新疆维吾尔自治区","云南省","浙江省","重庆市"
];
var Label=ui.Label({
  value:"中国各省份的NDVI月合成数据",
  style: {fontSize: '20px', fontWeight: 'bold'}
});
var select=ui.Select({
  items:proviencelistname,
  placeholder:"选择省份",
  onChange:function(key){
    tzwapp.data.proviencename=key;
  }
});
//*/
var startLabel = ui.Label("年份 : yyyy");
var starttextbox=ui.Textbox({
  placeholder:"start date:yyyy",
  value:tzwapp.data.startyear,
  onChange:function(value){
   tzwapp.data.startyear=value;
  }
});
var startLabel1 = ui.Label("起始月份: mm");
var starttextbox1=ui.Textbox({
  placeholder:"start date:mm",
  value:tzwapp.data.startmonth,
  onChange:function(value){
   tzwapp.data.startmonth=value;
  }
});
var endLabel = ui.Label("结束月份 : mm");
var endtextbox=ui.Textbox({
  placeholder:"end date:mm",
  value:tzwapp.data.endmonth,
  onChange:function(value){
    tzwapp.data.endmonth=value;
  }
});
//ok button  and ndvi .ndwi button
var button=ui.Button({
  label:"ok",
  style:{
    color:"#ff0000",
    textAlign:"center"
  },
  onClick:function(){
  print("start date is",tzwapp.data.startyear);
  print("start month is ",tzwapp.data.startmonth);
  print("end month is",tzwapp.data.endmonth);
  print("cloudScore is",tzwapp.data.cloud_cover);
  print("the provience  is",tzwapp.data.proviencename);
  print("ndvi is",tzwapp.data.ndvi);
  var provience=main.getedge2(tzwapp.data.proviencename);
  var provienceedgetoimage=provience.reduceToImage({
  properties:["Shape_Area"],
  reducer:ee.Reducer.mean()
    });
  provienceedgetoimage=ee.Image(provienceedgetoimage);
  var imgCol=main.getedge1(tzwapp.data.startyear,tzwapp.data.startmonth,tzwapp.data.endmonth,"50",provience);
  main.showEveryDayFire(imgCol,provience);
  var panel=main.showTheNdviAttribute(imgCol,provience);
  Map.centerObject(provience,5);
  Map.addLayer(provienceedgetoimage,{min:0,max:3000},tzwapp.data.proviencename);
}
});
var ndvibutton=ui.Button({
  label:"NDVI",
  style:{
    color:"#ff0000",
    textAlign:"center"
  },
  onClick:function(){
    tzwapp.data.ndvi=true;
  }
});
//cloudScore label
var cloudScorelabel=ui.Label({
  value:"cloud_cover",
  style:{fontSize:'16px'}
});
//ui.Slider
var cloudScore=ui.Slider({
  min:0,
  max:100,
  value:50,
  step:1,
  direction:"horizontal",
  onChange:function(value){
    var cloud_cover=" ";
    cloud_cover=cloud_cover+value;
    tzwapp.data.cloud_cover=cloud_cover;
  }
});
//ui.Panel
var panel=ui.Panel([Label,select,startLabel,starttextbox,startLabel1,starttextbox1, endLabel,endtextbox,ndvibutton,cloudScorelabel,cloudScore,button]);
ui.root.insert(0, panel);