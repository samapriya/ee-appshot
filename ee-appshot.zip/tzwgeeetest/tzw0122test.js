//var point=ee.Geometry.Point([116.387928,40.00649]);
//Map.addLayer(point,{color:"green"},"point");
//var line=ee.Geometry.LineString([[116.3782558270866,40.2023566292988],
//[116.3782558270866,39.9984096033757],[116.41069982733075,39.9984096033757],
//[116.41069982733075,40.02023566292988]]);
//Map.addLayer(line,{color:"green"},"line");
//var polygon=ee.Geometry.Polygon([[[116.3782558270866,40.2023566292988],
//[116.3782558270866,39.9984096033757],[116.41069982733075,39.9984096033757],
//[116.41069982733075,40.02023566292988]]]);
//Map.addLayer(polygon,{color:"red"},"polygon");
//var f1=ee.Feature(point,{time:100});
//Map.addLayer(f1,{color:"blue"},'point');
//print("feature 1",f1);
//var fcol=ee.FeatureCollection("users/tzwgeeetest/xianjie");
//var f2=ee.Feature(fcol.first());
//Map.addLayer(f2,{color:"blue"});
//Map.centerObject(f2,7);
//var l8=ee.ImageCollection("LANDSAT/LC08/C01/T1_TOA");
//var sco1=l8.filterBounds(point).filterDate("2017-4-1","2017-6-1").filter(ee.Filter.lt("CLOUD_COVER",5));
//print(sco1);
//Map.centerObject(point,7);
/*计算roi中的NDVI，
var roi=ee.Geometry.Polygon([[[116.3782558270866,40.02023566292988],
[116.3782558270866,39.9984096033757],
[116.41069982733075,39.9984096033757],
[116.41069982733075,40.02023566292988]
]]);
Map.addLayer(roi,{color:"red"},"roi");
Map.centerObject(roi,10);
var l8col=ee.ImageCollection("LANDSAT/LC08/C01/T1_TOA").filterBounds(roi).filterDate("2018-1-1","2018-6-1").
  map(function(image){
  var ndvi=image.normalizedDifference(["B5","B4"])
  .rename("NDVI");
  return  image.addBands(ndvi);
}).select("NDVI").
  map(function(image){
  var dict=image.reduceRegion({
    reducer:ee.Reducer.mean(),
    geometry:roi,
    scale:30
  });
  var ndvi =ee.Number(dict.get("NDVI"));
  image=image.set("ndvi",ndvi);
  return image;
});
print("18co1",l8col);
var visParam={
  min :-0.2,
  max:0.8,
  palette:["FFFFFF","CE7E45","DF923D","F1B555","FCD163","99B718","74A901","66A000","529400","3E8601",
  "207401","056201","004C00","023B01","012E01","011D01","011301"]
};
Map.addLayer(l8col.first().clip(roi),visParam,"l8col");*/
//*color:#d63000/
var center=ee.Geometry.Point([116.387928,40.00649]);
var zoom=9;
var leftMap=ui.Map();
leftMap.centerObject(center,zoom);
var rightMap=ui.Map();
rightMap=ui.Map();
rightMap.centerObject(center,zoom);
leftMap.setControlVisibility(false);
rightMap.setControlVisibility(false);
leftMap.setControlVisibility({zoomControl:true});
var linker =new ui.Map.Linker([leftMap,rightMap]);
var splitPanel=ui.SplitPanel({
  firstPanel:leftMap,
  secondPanel:rightMap,
  orientation:'horizontal',
  wipe:true
});
ui.root.clear();
ui.root.add(splitPanel);
var landsat=ee.ImageCollection("LANDSAT/LC08/C01/T1_SR").filterDate('2017-01-01','2018-01-01')
.median();
landsat=landsat.addBands(landsat.normalizedDifference(['B5','B4']).rename("NDVI"));
var vis={bands:['B4','B3','B2'],min:0,max:3000};
leftMap.addLayer(landsat,vis,'rgb');
var visNDVI={
  min:0,
  max:1,
  palette:'FFFFFF,CE7E45,DF923D,F1B555,FCD163,99B718,74A901,66A000,529400,'
   + '3E8601,207401,056201,004C00,023B01,012E01,011D01,011301'
};
rightMap.addLayer(landsat.select("NDVI"),visNDVI,'NDVI');