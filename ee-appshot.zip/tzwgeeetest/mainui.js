var mainUI_2_function=require("users/tzwgeeetest/Fire:firedection/mainUI_2");
var mainUI_1_function=require("users/tzwgeeetest/Fire:firedection/mainUI_1");
var FireLabel=ui.Label("火灾");
var function1=ui.Button(
  {
    label:"中国各省每日火灾情况",
    onClick:function(){
      mainUI_1_function.mainUI_1();
    }
}
);
var function2=ui.Button(
  {
    label:"中国各省历史火灾情况",
    onClick:function(){
      mainUI_2_function.mainUI_2();
    }
}
);
var startPanel=ui.Panel([FireLabel,function1,function2]);
ui.root.insert(0,startPanel);