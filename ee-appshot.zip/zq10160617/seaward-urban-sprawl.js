var reclamation = ui.import && ui.import("reclamation", "image", {
      "id": "users/zq10160617/1reclaimed"
    }) || ee.Image("users/zq10160617/1reclaimed"),
    urban1 = ui.import && ui.import("urban1", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_1"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_1"),
    urban2 = ui.import && ui.import("urban2", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_2"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_2"),
    urban3 = ui.import && ui.import("urban3", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_3"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_3"),
    urban4 = ui.import && ui.import("urban4", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_6"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_6"),
    urban5 = ui.import && ui.import("urban5", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_7"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_7"),
    urban6 = ui.import && ui.import("urban6", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban8"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban8"),
    urban7 = ui.import && ui.import("urban7", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban9"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban9"),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#0000ff",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #0000ff */ee.Geometry.MultiPoint();
Map.setCenter(113.5,22.5,9)
var drawingTools = Map.drawingTools(); 
drawingTools.setLinked(true); 
drawingTools.setShown(true);
// drawingTools.setDrawModes(["polygon"]); 
// drawingTools.addLayer([], "roi", "00ff00"); 
// drawingTools.setShape("polygon"); 
// drawingTools.draw(); 
// for convenience in recalling it later.
// var drawingTools = Map.drawingTools();
// // Hide the default drawing tools
// drawingTools.setShown(true);
// Setup a while loop to clear all existing geometries
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
// Initialize a dummy GeometryLayer with null geometry 
// to act as a placeholder for drawn geometries.
var dummyGeometry =
    ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: '0000ff'});
drawingTools.layers().add(dummyGeometry);
// Define the geometry clearing function.
function clearGeometry() {
  var layers = drawingTools.layers();
  layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
}
// Define functions that will be called when 
// each respective drawing button is clicked.
function drawRectangle() {
  clearGeometry();
  drawingTools.setShape('rectangle');
  drawingTools.draw();
}
function drawPolygon() {
  clearGeometry();
  drawingTools.setShape('polygon');
  drawingTools.draw();
}
// function drawPoint() {
//   clearGeometry();
//   drawingTools.setShape('point');
//   drawingTools.draw();
// }
// Define a panel to hold the time series chart.
var chartPanel = ui.Panel({
  style:
      {height: '235px', width: '400px', position: 'bottom-right', shown: false}
});
// Add the panel to the Map.
Map.add(chartPanel);
// Define a function that gets called on geometry drawing completion and 
// editing events to generate a time series chart for the drawn region.
function chartNdviTimeSeries() {
  // Make the chart panel visible the first time a geometry is drawn.
  if (!chartPanel.style().get('shown')) {
    chartPanel.style().set('shown', true);
  }
  // Get the drawn geometry; it will define the reduction region.
  var aoi = drawingTools.layers().get(0).getEeObject();
  // Set the drawing mode back to null; turns drawing off.
  drawingTools.setShape(null);
  // Reduction scale is based on map scale to avoid memory/timeout errors.
  var mapScale = Map.getScale();
  var scale = mapScale > 5000 ? mapScale * 2 : 5000;
// Image collection.
// var Modis = ee.ImageCollection('MODIS/006/MOD13Q1')
//             .select(['NDVI', 'EVI'])
//             .map(function(image){
//                 return image.multiply(0.0001).set(image.toDictionary(image.propertyNames()))
//             });
//var modis = Modis.median().clip(aoi)
var urbancollection = ee.ImageCollection([urban1,urban2,urban3,urban4,urban5,urban6,urban7]);
var urban = urbancollection.mosaic()
var urban = urban.select('b1').rename('urban');
var reclamation1 = reclamation.select('b1').rename('land');
var zhang = reclamation1.addBands(urban)
var zhang1 = zhang.add(1985);
var zhang1 = zhang.clip(aoi)
Map.centerObject(aoi)
Map.addLayer (zhang1.select('land'),{min:1,max:35,palette:['FDFFA5','F4F788','F3EB69','F6DD4E','F9CE38','FCBF25','FDB114',
             'FDA208','FB9407','F9870E','F57A18','F06D22','EA622B','E25735',
             'DA4D3D','D14546','C63D4E','BC3755','B0315C','A52C61','992866',
             '8D236A','811F6C','751B6E','69166F','5D126F','510E6D','450A69',
             '380962','2B0B56','1E0C46','130B33','0A0722','030311','000004']},'seaward land expansion')
Map.addLayer (zhang1.select('urban'),{min:1,max:35,palette:['FDFFA5','F4F788','F3EB69','F6DD4E','F9CE38','FCBF25','FDB114',
             'FDA208','FB9407','F9870E','F57A18','F06D22','EA622B','E25735',
             'DA4D3D','D14546','C63D4E','BC3755','B0315C','A52C61','992866',
             '8D236A','811F6C','751B6E','69166F','5D126F','510E6D','450A69',
             '380962','2B0B56','1E0C46','130B33','0A0722','030311','000004']},'seaward urban sprawl')
// // Chart NDVI time series for the selected area of interest.
var chart = ui.Chart.image.histogram({ 
    image: zhang.select(['land','urban']), 
    region: aoi, 
   // reducer: ee.Reducer.count(), 
    scale: 500
  }).setOptions({ 
    title: "seaward  sprawl time series analysis", 
    hAxis: {title: "Year"}, 
    vAxis: {title: "Pixel Count"}, 
    width: 200,
    height: 240,
    lineWidth:1, 
    pointSize:2, 
    colors: ['0000CD', 'DC143C']
  }); 
  chartPanel.widgets().reset([chart]);
// }
}
// Set the drawing tools widget to listen for geometry drawing and 
// editing events and respond with the chartNdviTimeSeries function.
drawingTools.onDraw(ui.util.debounce(chartNdviTimeSeries, 500));
drawingTools.onEdit(ui.util.debounce(chartNdviTimeSeries, 500));
// User interface
var symbol = {
  rectangle: '⬛',
  polygon: '🔺',
 // point: '📍',
};
// Define a ui.Panel to hold app instructions and 
// the geometry drawing buttons. 
var controlPanel = ui.Panel({
  widgets: [
    ui.Label('Seaward land/urban sprawl'),
    //ui.Label(1986, {color: 'CBF7B2'}),
    ui.Button({
      label: symbol.rectangle + ' Rectangle',
      onClick: drawRectangle,
      style: {stretch: 'horizontal'}
    }),
    ui.Button({
      label: symbol.polygon + ' Polygon',
      onClick: drawPolygon,
      style: {stretch: 'horizontal'}
    }),
    // ui.Button({
    //   label: symbol.point + ' Point',
    //   onClick: drawPoint,
    //   style: {stretch: 'horizontal'}
    // }),
    ui.Label('2. Draw a geometry.'),
    ui.Label('3. Wait for chart to render.'),
    ui.Label(
        '4. Repeat 1-3 or edit/move\ngeometry for a new chart.',
        {whiteSpace: 'pre'})
  ],
  style: {position: 'top-right'},
  layout: null,
});
var locationDict = {
   'Seaward land expansion': {lon: 113.5, lat: 22.5, zoom: 9},
   'Coastal urban sprawl': {lon: 113.5, lat: 22.5, zoom: 9}
 };
//var mapPanel = ui.Map();
//Map.add(controlPanel);
function addLegend(palette, names) {
 //图例的底层Panel
 var legend = ui.Panel({
   style: {
     position: 'bottom-left',
     padding: '5px 10px'
   }
 });
 //图例标题
 var title = ui.Label({
   value: 'Seaward land/urban sprawl',
   style: {
     fontWeight: 'bold',
     color: "red",
     fontSize: '16px'
   }
 });
 legend.add(title);
 //添加每一列图例颜色以及说明
 var addLegendLabel = function(color, name) {
       var showColor = ui.Label({
         style: {
           backgroundColor: '#' + color,
           padding: '8px',
           margin: '0 0 4px 0'
         }
       });
       var desc = ui.Label({
         value: name,
         style: {margin: '0 0 4px 8px'}
       });
    // //颜色和说明是水平放置
       return ui.Panel({
         widgets: [showColor, desc],
         layout: ui.Panel.Layout.Flow('horizontal')
       });
 };
 //添加所有的图例列表
 for (var i = 0; i < palette.length; i++) {
   var label = addLegendLabel(palette[i], names[i]);
   legend.add(label);
 }  
 Map.add(legend);
}
var palette = ['FFFF75','FAE269','F7D365',
             'C7312C','C21F27','BD0026',
             '91345A','8C375D','8A3861',
             ];
var names = ["1986","1987","1988","...",
            "2002","...","2018","2019",
            "2020"];
//添加图例
addLegend(palette, names);
//controlPanel.add(addLegend)
Map.add(controlPanel)
//Map.centerObject(geometry)