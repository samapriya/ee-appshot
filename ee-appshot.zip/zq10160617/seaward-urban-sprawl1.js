var reclamation = ui.import && ui.import("reclamation", "image", {
      "id": "users/zq10160617/1reclaimed"
    }) || ee.Image("users/zq10160617/1reclaimed"),
    urban1 = ui.import && ui.import("urban1", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_1"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_1"),
    urban2 = ui.import && ui.import("urban2", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_2"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_2"),
    urban3 = ui.import && ui.import("urban3", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_3"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_3"),
    urban4 = ui.import && ui.import("urban4", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_6"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_6"),
    urban5 = ui.import && ui.import("urban5", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_7"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_7"),
    urban6 = ui.import && ui.import("urban6", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban8"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban8"),
    urban7 = ui.import && ui.import("urban7", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban9"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban9"),
    geometry = ui.import && ui.import("geometry", "table", {
      "id": "users/zq10160617/Chinafishnet"
    }) || ee.FeatureCollection("users/zq10160617/Chinafishnet");
function maskL457sr1(image) {
  var qaMask = image.select('QA_PIXEL').bitwiseAnd(parseInt('11111', 2)).eq(0);
  var saturationMask = image.select('QA_RADSAT').eq(0);
  var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  var thermalBand = image.select('ST_B6').multiply(0.00341802).add(149.0);
  return image.addBands(opticalBands, null, true)
      .addBands(thermalBand, null, true)
      .updateMask(qaMask)
      .updateMask(saturationMask);
}
var image = ee.ImageCollection('LANDSAT/LT05/C02/T1_L2')
                  .filterBounds(geometry)
                  .filterDate('1984-01-01','1987-01-01')
                  .map(maskL457sr1)
                  .select(['SR_B7','SR_B5','SR_B3'])
                  .median();
var urbancollection = ee.ImageCollection([urban1,urban2,urban3,urban4,urban5,urban6,urban7]);
var urban = urbancollection.mosaic()
var urban = urban.select('b1').rename('urban');
var reclamation1 = reclamation.select('b1').rename('land');
var zhang = reclamation1.addBands(urban);
var image = image.addBands(reclamation1).addBands(urban)
// Each map has a name and some visualization parameters.
// var MAP_PARAMS = {
//   'Landsat composite image in 1985':{min:0,max:0.3,bands:['SR_B7','SR_B5','SR_B3']},
//   'Seaward land increase':{min:1,max:35,bands:['land'],palette:['FDFFA5','F4F788','F3EB69','F6DD4E','F9CE38','FCBF25','FDB114',
//             'FDA208','FB9407','F9870E','F57A18','F06D22','EA622B','E25735',
//             'DA4D3D','D14546','C63D4E','BC3755','B0315C','A52C61','992866',
//             '8D236A','811F6C','751B6E','69166F','5D126F','510E6D','450A69',
//             '380962','2B0B56','1E0C46','130B33','0A0722','030311','000004']},
//   'Seaward urban sprawl':{min:1,max:35,bands:['land'],palette:['FDFFA5','F4F788','F3EB69','F6DD4E','F9CE38','FCBF25','FDB114',
//             'FDA208','FB9407','F9870E','F57A18','F06D22','EA622B','E25735',
//             'DA4D3D','D14546','C63D4E','BC3755','B0315C','A52C61','992866',
//             '8D236A','811F6C','751B6E','69166F','5D126F','510E6D','450A69',
//             '380962','2B0B56','1E0C46','130B33','0A0722','030311','000004']},
// };
var MAP_PARAMS = {
  'Landsat composite image in 1985': ['SR_B7','SR_B5','SR_B3'],
  'Seaward land increase': ['land'],
  'Seaward urban sprawl': ['urban'],
};
// Shared visualization parameters for the images.
function getVisualization(bands,palette) {
  return {gamma: 1.3, min:1, max:35, bands: bands,palette:palette};
}
// Create a map for each visualization option.
var maps = [];
Object.keys(MAP_PARAMS).forEach(function(name) {
  var map = ui.Map();
  map.add(ui.Label(name));
  map.addLayer(image, getVisualization(MAP_PARAMS[name]), name);
  map.setControlVisibility(false);
  maps.push(map);
});
var linker = ui.Map.Linker(maps);
// Enable zooming on the top-left map.
maps[0].setControlVisibility({zoomControl: true});
// Show the scale (e.g. '500m') on the bottom-right map.
maps[0].setControlVisibility({scaleControl: true});
// Create a grid of maps.
var mapGrid = ui.Panel(
    [
      ui.Panel([maps[0]], null, {stretch: 'both'}),
      ui.Panel([maps[1]], null, {stretch: 'both'}),
      ui.Panel([maps[2]], null, {stretch: 'both'}),
    ],
    ui.Panel.Layout.Flow('horizontal'), {stretch: 'both'});
// Center the map at an interesting spot in Greece. All
// other maps will align themselves to this parent map.
maps[0].setCenter(113.5,22.5,9);
// Add the maps and title to the ui.root.
ui.root.widgets().reset([mapGrid]);
ui.root.setLayout(ui.Panel.Layout.Flow('horizontal'));
// var chartPanel = ui.Panel({
//   style:
//       {height: '235px', width: '400px', position: 'bottom-right', shown: false}
// });
// // Add the panel to the Map.
// Map.add(chartPanel);
// Add a title and some explanatory text to a side panel.
var header = ui.Label('Coastal seaward urban sprawl', {fontSize: '36px', color: 'red'});
var text = ui.Label(
    'Multi-decadal coastal urban sprawl map for China in 1986-2020 derived from our FADUS classification framework on time series of Landsat imagery.',
    {fontSize: '11px'});
var toolPanel = ui.Panel([header, text], 'flow', {width: '300px'});
ui.root.widgets().add(toolPanel);
// Create a hyperlink to an external reference.
var link = ui.Label(
    'Paper by Zhang et al.', {},
    'https://cee.xmu.edu.cn/info/1032/6186.htm');
var linkPanel = ui.Panel(
    [ui.Label('For more information', {fontWeight: 'bold'}), link]);
toolPanel.add(linkPanel);
// Create the legend.
// Define a panel for the legend and give it a tile.
var legendPanel = ui.Panel({
  style:
      {fontWeight: 'bold', fontSize: '10px', margin: '0 0 0 8px', padding: '0'}
});
toolPanel.add(legendPanel);
// var legendTitle = ui.Label(
//     'Legend',
//     {fontWeight: 'bold', fontSize: '10px', margin: '0 0 4px 0', padding: '0'});
// legendPanel.add(legendTitle);
// var legendContent = ui.Label(
//   ['2016','red'],
//   {fontWeight: 'bold', fontSize: '10px', margin: '0 0 4px 0', padding: '0'});
// legendPanel.add(legendContent);
//////////////////////////////////
//////////////////////////
//添加图例
var layerProperties1 = {
  'Seaward land increase': {
    name:'land',
    visParams: {min:1,max:35,bands:['land'],palette:['FDFFA5','F4F788','F3EB69','F6DD4E','F9CE38','FCBF25','FDB114',
            'FDA208','FB9407','F9870E','F57A18','F06D22','EA622B','E25735',
            'DA4D3D','D14546','C63D4E','BC3755','B0315C','A52C61','992866',
            '8D236A','811F6C','751B6E','69166F','5D126F','510E6D','450A69',
            '380962','2B0B56','1E0C46','130B33','0A0722','030311','000004']},
        legend: [
      {'1986': 'FDFFA5'}, {'1995': 'F9870E'},{'...': 'A52C61'}, {'2010': '69166F'}, {'2020': '000004'},
    ],
    defaultVisibility: true
  },        
};
for (var key in layerProperties1) {
  var layer = layerProperties1[key];
  var image = zhang.select(layer.name).visualize(layer.visParams);
  //var masked = addZeroAndWaterMask(image, hansen.select(layer.name));
  //mapPanel.add(ui.Map.Layer(masked, {}, key, layer.defaultVisibility));
}
// Add a title and some explanatory text to a side panel.
// Create a layer selector pulldown.
// The elements of the pulldown are the keys of the layerProperties dictionary.
var selectItems = Object.keys(layerProperties1);
// Define the pulldown menu.  Changing the pulldown menu changes the map layer
// and legend.
var layerSelect = ui.Select({
  items: selectItems,
  value: selectItems[0],
  onChange: function(selected) {
    // Loop through the map layers and compare the selected element to the name
    // of the layer. If they're the same, show the layer and set the
    // corresponding legend.  Hide the others.
    mapPanel.layers().forEach(function(element, index) {
      element.setShown(selected == element.getName());
    });
    setLegend(layerProperties[selected].legend);
  }
});
// Add the select to the toolPanel with some explanatory text.
// toolPanel.add(ui.Label('View Different Layers', {'font-size': '24px'}));
// toolPanel.add(layerSelect);
// Create the legend.
// Define a panel for the legend and give it a tile.
var legendPanel = ui.Panel({
  style:
      {fontWeight: 'bold', fontSize: '10px', margin: '0 0 0 8px', padding: '0'}
});
toolPanel.add(legendPanel);
var legendTitle = ui.Label(
    'Legend',
    {fontWeight: 'bold', fontSize: '10px', margin: '0 0 4px 0', padding: '0'});
legendPanel.add(legendTitle);
// Define an area for the legend key itself.
// This area will be replaced every time the layer pulldown is changed.
var keyPanel = ui.Panel();
legendPanel.add(keyPanel);
function setLegend(legend) {
  // Loop through all the items in a layer's key property,
  // creates the item, and adds it to the key panel.
  keyPanel.clear();
  for (var i = 0; i < legend.length; i++) {
    var item = legend[i];
    var name = Object.keys(item)[0];
    var color = item[name];
    var colorBox = ui.Label('', {
      backgroundColor: color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0'
    });
    // Create the label with the description text.
    var description = ui.Label(name, {margin: '0 0 4px 6px'});
    keyPanel.add(
        ui.Panel([colorBox, description], ui.Panel.Layout.Flow('horizontal')));
  }
}
// Set the initial legend.
setLegend(layerProperties1[layerSelect.getValue()].legend);
// Create a visibility checkbox and an opacity slider.
//
// If the checkbox is clicked off, disable the layer pulldown and turn all the
// layers off. Otherwise, enable the select, and turn on the selected layer.
var checkbox = ui.Checkbox({
  label: 'Opacity',
  value: true,
  onChange: function(value) {
    var selected = layerSelect.getValue();
    // Loop through the layers in the mapPanel. For each layer,
    // if the layer's name is the same as the name selected in the layer
    // pulldown, set the visibility of the layer equal to the value of the
    // checkbox. Otherwise, set the visibility to false.
    mapPanel.layers().forEach(function(element, index) {
      element.setShown(selected == element.getName() ? value : false);
    });
    // If the checkbox is on, the layer pulldown should be enabled, otherwise,
    // it's disabled.
    layerSelect.setDisabled(!value);
  }
});
// Create an opacity slider. This tool will change the opacity for each layer.
// That way switching to a new layer will maintain the chosen opacity.
var opacitySlider = ui.Slider({
  min: 0,
  max: 1,
  value: 1,
  step: 0.01,
});
opacitySlider.onSlide(function(value) {
  mapPanel.layers().forEach(function(element, index) {
    element.setOpacity(value);
  });
});
var viewPanel =
    ui.Panel([checkbox, opacitySlider], ui.Panel.Layout.Flow('horizontal'));
toolPanel.add(viewPanel);