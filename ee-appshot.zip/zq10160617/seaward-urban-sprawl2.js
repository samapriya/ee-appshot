var reclamation = ui.import && ui.import("reclamation", "image", {
      "id": "users/zq10160617/1reclaimed"
    }) || ee.Image("users/zq10160617/1reclaimed"),
    urban1 = ui.import && ui.import("urban1", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_1"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_1"),
    urban2 = ui.import && ui.import("urban2", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_2"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_2"),
    urban3 = ui.import && ui.import("urban3", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_3"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_3"),
    urban4 = ui.import && ui.import("urban4", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_6"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_6"),
    urban5 = ui.import && ui.import("urban5", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban_7"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban_7"),
    urban6 = ui.import && ui.import("urban6", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban8"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban8"),
    urban7 = ui.import && ui.import("urban7", "image", {
      "id": "projects/ee-zhangqian0910/assets/urban9"
    }) || ee.Image("projects/ee-zhangqian0910/assets/urban9"),
    geometry = ui.import && ui.import("geometry", "table", {
      "id": "users/zq10160617/Chinafishnet"
    }) || ee.FeatureCollection("users/zq10160617/Chinafishnet");
function maskL457sr1(image) {
  var qaMask = image.select('QA_PIXEL').bitwiseAnd(parseInt('11111', 2)).eq(0);
  var saturationMask = image.select('QA_RADSAT').eq(0);
  var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  var thermalBand = image.select('ST_B6').multiply(0.00341802).add(149.0);
  return image.addBands(opticalBands, null, true)
      .addBands(thermalBand, null, true)
      .updateMask(qaMask)
      .updateMask(saturationMask);
}
function cloudMaskL8sr(image) {
  var cloudShadowBitMask = (1 << 3);
  var cloudsBitMask = (1 << 5);
  var qa = image.select('QA_PIXEL');
  var mask = qa.bitwiseAnd(cloudShadowBitMask).eq(0)
                .and(qa.bitwiseAnd(cloudsBitMask).eq(0));
  return image.updateMask(mask);
}
// Applies scaling factors.
function applyScaleFactors(image) {
  var opticalBands = image.select('SR_B.').multiply(0.0000275).add(-0.2);
  var thermalBands = image.select('ST_B.*').multiply(0.00341802).add(149.0);
  return image.addBands(opticalBands, null, true)
              .addBands(thermalBands, null, true);
}
var L5 = ee.ImageCollection('LANDSAT/LT05/C02/T1_L2')
                  .filterBounds(geometry)
                  .filterDate('1984-01-01','1988-01-01')
                  .map(maskL457sr1)
                  .select(['SR_B7','SR_B5','SR_B3'])
                  .median();
var L8 = ee.ImageCollection('LANDSAT/LC08/C02/T1_L2')
                  .filterDate('2019-01-01', '2022-01-01')
                  .filterBounds(geometry)
                  .map(cloudMaskL8sr)
                  .map(applyScaleFactors)
                  .select(['SR_B5'])
                  .median();
var urbancollection = ee.ImageCollection([urban1,urban2,urban3,urban4,urban5,urban6,urban7]);
var urban = urbancollection.mosaic()
var urban = urban.select('b1').rename('urban');
var reclamation1 = reclamation.select('b1').rename('land');
var reclamation1 = reclamation1.add(1985);
var urban = urban.add(1985);
var zhang = reclamation1.addBands(urban);     
// Create the left map, and have it display layer 0.
var leftMap = ui.Map();
leftMap.add(ui.Label('Median composite image in 1985',{fontSize: '18px',position:'bottom-left'}));
leftMap.setControlVisibility(false);
leftMap.addLayer(L5,{gamma:1.5,min:0,max:0.3},'Landsat5')
// Create the right map, and have it display layer 1.
var rightMap = ui.Map();
rightMap.add(ui.Label('Coatal seaward land increase/urban sprawl',{fontSize: '18px',position:'bottom-right'}));
rightMap.setControlVisibility(true, true, false, false, false, false, false);
rightMap.addLayer(L8,{gamma:1.5,min:0,max:0.3},'Landsat8 median composite image',true)
rightMap.addLayer(reclamation1,{min:1986,max:2020,palette: ['FEE825','ECE61A','D8E31A','C5E122','B0DE2F','9CDA32','89D648',
            '77D154','65CC5E','55C768','46C170','39BA77','2EB47D','26AD82',
            '21A686','1F9F89','1F988B','21918D','238A8E','26838F','297B8F',
            '2C748F','2F6D8F','32668E','355E8D','39568C','3D4E8B','404688',
            '443D85','463480','482A7A','482172','48176A','470C5F','440154']},'Seaward land increase')
rightMap.addLayer(urban,{min:1986,max:2020,palette: ['FEE825','ECE61A','D8E31A','C5E122','B0DE2F','9CDA32','89D648',
            '77D154','65CC5E','55C768','46C170','39BA77','2EB47D','26AD82',
            '21A686','1F9F89','1F988B','21918D','238A8E','26838F','297B8F',
            '2C748F','2F6D8F','32668E','355E8D','39568C','3D4E8B','404688',
            '443D85','463480','482A7A','482172','48176A','470C5F','440154']},'Seaward urban sprawl',false)
// Create a SplitPanel to hold the adjacent, linked maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in the UI root.
ui.root.widgets().reset([splitPanel]);
var linker = ui.Map.Linker([leftMap, rightMap]);
leftMap.setCenter(113.79,22.49,12);
var header = ui.Label('Coastal seaward urban sprawl', {fontWeight: 'bold', fontSize: '19px',margin: '5px 0 4px 6px',padding: '0'});
var text = ui.Label(
    'Multi-decadal coastal urban sprawl map for China in 1986-2020 derived from our FADUS (Fully Automated Detection of Urban Sprawl) classification framework on time series of Landsat imagery. This map uncovers a neglected but dramatic seaward urban sprawl process transferring sea area to urban space since 1985. The derived annual maps of seaward land extent indicated that 9901.61 km2 of coastal wetlands and nearshore waters were converted to land in the last 35 years, 44.82% of which was occupied by built-up land currently.',
    {fontSize: '14px',margin: '5px 0 4px 6px',padding: '0'});
var toolPanel = ui.Panel([header, text], 'flow', {width: '300px'});
ui.root.widgets().add(toolPanel);
// Create a hyperlink to an external reference.
var link = ui.Label(
    'Paper by Zhang et al.', {},
    'https://cee.xmu.edu.cn/info/1032/6186.htm');
var linkPanel = ui.Panel(
    [ui.Label('For more information', {fontWeight: 'bold', fontSize: '14px', margin: '5px 0 4px 6px', padding: '0'}), link]);
toolPanel.add(linkPanel);
var link1 = ui.Label(
    'Data download from figshare', {},
    'https://figshare.com/articles/dataset/FADUS_China/21129826');
var linkPanel1 = ui.Panel(
    [ui.Label('To download data', {fontWeight: 'bold', fontSize: '14px', margin: '5px 0 4px 6px', padding: '0'}), link1]);
toolPanel.add(linkPanel1);
// Create the legend.
// Define a panel for the legend and give it a tile.
// //添加图例
var layerProperties1 = {
  'Seaward land increase': {
    name:'land',
    visParams: {min:1,max:35,bands:['land'],palette:['FEE825','ECE61A','D8E31A','C5E122','B0DE2F','9CDA32','89D648',
            '77D154','65CC5E','55C768','46C170','39BA77','2EB47D','26AD82',
            '21A686','1F9F89','1F988B','21918D','238A8E','26838F','297B8F',
            '2C748F','2F6D8F','32668E','355E8D','39568C','3D4E8B','404688',
            '443D85','463480','482A7A','482172','48176A','470C5F','440154']},
        legend: [
      {'1986': 'FEE825'}, {'1987': 'ECE61A'}, {'...': '21918D'}, {'2019': '470C5F'}, {'2020': '440154'}],
    defaultVisibility: true
  },        
};
// Define a panel for the legend and give it a tile.
var legendPanel = ui.Panel({
  style:
      {fontWeight: 'bold', fontSize: '14px', margin: '5px 0 0 8px', padding: '0'}
});
toolPanel.add(legendPanel);
var legendzero = ui.Label(
    '',
    {fontWeight: 'bold', fontSize: '14px', margin: '5px 0 4px 0', padding: '0'});
legendPanel.add(legendzero);
var legendTitle = ui.Label(
    'Change Year',
    {fontWeight: 'bold', fontSize: '14px', margin: '5px 0 4px 0', padding: '0'});
legendPanel.add(legendTitle);
var legendzero1 = ui.Label(
    '',
    {fontWeight: 'bold', fontSize: '14px', margin: '5px 0 4px 0', padding: '0'});
legendPanel.add(legendzero1);
// Set the initial legend.
//setLegend(layerProperties1[layerSelect.getValue()].legend);
var legendPanel2 = ui.Panel({
  widgets: [
    ui.Label('',{backgroundColor: 'FFFF75',padding: '8px',margin: '0px 0px 0px 3px'}),
    ui.Label('1986',{margin: '0px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '77D154',padding: '8px',margin: '0px 0px 0px 3px'}),
    ui.Label('1993',{margin: '0px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '21A686',padding: '8px',margin: '0px 0px 0px 3px'}),
    ui.Label('2000',{margin: '0px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '2C748F',padding: '8px',margin: '0px 0px 0px 3px'}),
    ui.Label('2007',{margin: '0px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '443D85',padding: '8px',margin: '0px 0px 0px 3px'}),
    ui.Label('2014',{margin: '0px 0px 0px 3px'}),
  ],
  layout: ui.Panel.Layout.Flow('horizontal')
});
toolPanel.add(legendPanel2)
var legendPanel3 = ui.Panel({
  widgets: [
    ui.Label('',{backgroundColor: 'ECE61A',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1987',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '65CC5E',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1994',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '1F9F89',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2001',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '2F6D8F',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2008',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '463480',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2015',{margin: '5px 0px 0px 3px'}),
  ],
  layout: ui.Panel.Layout.Flow('horizontal')
});
toolPanel.add(legendPanel3)
var legendPanel4 = ui.Panel({
  widgets: [
    ui.Label('',{backgroundColor: 'D8E31A',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1988',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '55C768',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1995',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '1F988B',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2002',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '32668E',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2009',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '482A7A',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2016',{margin: '5px 0px 0px 3px'}),
  ],
  layout: ui.Panel.Layout.Flow('horizontal')
});
toolPanel.add(legendPanel4)
var legendPanel5 = ui.Panel({
  widgets: [
    ui.Label('',{backgroundColor: 'C5E122',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1989',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '46C170',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1996',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '21918D',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2003',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '355E8D',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2010',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '482172',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2017',{margin: '5px 0px 0px 3px'}),
  ],
  layout: ui.Panel.Layout.Flow('horizontal')
});
toolPanel.add(legendPanel5)
var legendPanel6 = ui.Panel({
  widgets: [
    ui.Label('',{backgroundColor: 'B0DE2F',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1990',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '39BA77',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1997',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '238A8E',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2004',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '39568C',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2011',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '48176A',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2018',{margin: '5px 0px 0px 3px'}),
  ],
  layout: ui.Panel.Layout.Flow('horizontal')
});
toolPanel.add(legendPanel6)
var legendPanel7 = ui.Panel({
  widgets: [
    ui.Label('',{backgroundColor: '9CDA32',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1991',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '2EB47D',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1998',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '26838F',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2005',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '3D4E8B',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2012',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '470C5F',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2019',{margin: '5px 0px 0px 3px'}),
  ],
  layout: ui.Panel.Layout.Flow('horizontal')
});
toolPanel.add(legendPanel7)
var legendPanel8 = ui.Panel({
  widgets: [
    ui.Label('',{backgroundColor: '89D648',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1992',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '26AD82',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('1999',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '297B8F',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2006',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '404688',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2013',{margin: '5px 0px 0px 3px'}),
    ui.Label('',{backgroundColor: '440154',padding: '8px',margin: '5px 0px 0px 3px'}),
    ui.Label('2020',{margin: '5px 0px 0px 3px'}),
  ],
  layout: ui.Panel.Layout.Flow('horizontal')
});
toolPanel.add(legendPanel8)
///////////////////////////////
////////////////////////////
var Assetzero = ui.Label(
    '',
    {fontWeight: 'bold', fontSize: '14px', margin: '5px 0 11px 0', padding: '0'});
toolPanel.add(Assetzero);
var AssetTitle = ui.Label(
    'Earth Engine Assets',
    {fontWeight: 'bold', fontSize: '14px', margin: '5px 0 4px 6px', padding: '0'});
toolPanel.add(AssetTitle);
var text1 = ui.Label(
    'var land_increase = ee.Image("projects/ee-zhangqian0910/assets/land_increase");',
    {fontSize: '14px',backgroundColor:'DEDEDE'});
toolPanel.add(text1);    
var text2 = ui.Label(
    'var urban_sprawl = ee.Image("projects/ee-zhangqian0910/assets/land_increase");',
    {fontSize: '14px',backgroundColor:'DEDEDE'});
toolPanel.add(text2);