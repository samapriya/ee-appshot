var aoi = ui.import && ui.import("aoi", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -61.20185375321847,
                -27.567969412730367
              ],
              [
                -61.20185375321847,
                -27.691462930310905
              ],
              [
                -61.0384321223591,
                -27.691462930310905
              ],
              [
                -61.0384321223591,
                -27.567969412730367
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ffc82d",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-61.20185375321847, -27.567969412730367],
          [-61.20185375321847, -27.691462930310905],
          [-61.0384321223591, -27.691462930310905],
          [-61.0384321223591, -27.567969412730367]]], null, false),
    l4toa = ui.import && ui.import("l4toa", "imageCollection", {
      "id": "LANDSAT/LT04/C01/T1_TOA"
    }) || ee.ImageCollection("LANDSAT/LT04/C01/T1_TOA"),
    l5toa = ui.import && ui.import("l5toa", "imageCollection", {
      "id": "LANDSAT/LT05/C01/T1_TOA"
    }) || ee.ImageCollection("LANDSAT/LT05/C01/T1_TOA"),
    l7toa = ui.import && ui.import("l7toa", "imageCollection", {
      "id": "LANDSAT/LE07/C01/T1_TOA"
    }) || ee.ImageCollection("LANDSAT/LE07/C01/T1_TOA"),
    l8toa = ui.import && ui.import("l8toa", "imageCollection", {
      "id": "LANDSAT/LC08/C01/T1_TOA"
    }) || ee.ImageCollection("LANDSAT/LC08/C01/T1_TOA");
//Mask Clouds on Landsat---------------------------------
var getQABits = function(image, start, end, newName) {
    var pattern = 0;
    for (var i = start; i <= end; i++) {
       pattern += Math.pow(2, i);
    }
    return image.select([0], [newName])
                  .bitwiseAnd(pattern)
                  .rightShift(start);
};
var cloud_shadows = function(image) {
  var QA = image.select(['BQA']);
  return getQABits(QA, 7,8, 'Cloud_shadows').eq(1);
};
var clouds = function(image) {
  var QA = image.select(['BQA']);
  return getQABits(QA, 4,4, 'Cloud').neq(1);
};
var maskClouds_TM5 = function(image) {
  var cs = cloud_shadows(image);
  var c = clouds(image);
  image = image.updateMask(cs);
  return image.updateMask(c);
};
//-------------------------------------------------------------
var app = function(image){return(image)
.addBands(image.normalizedDifference(['B4', 'B3']).rename('NDVI'))
.addBands(image.expression(
    '(nir - red) / (nir + red + 0.5) * (1 + 0.5)', 
    {
    'nir': image.select('B4'),
    'red': image.select('B3')
    }
      ).rename('SAVI'));};
//Criando a coleção Landasat 8 OLI e seleção das bandas de interesse. Renomeia para padronizar nomes
var collection_l8 = l8toa.filter(ee.Filter.lt('CLOUD_COVER', 25))
  .filterBounds(aoi)
  //.map(maskClouds_TM5)
  .filterDate('2013-04-04','2019-07-01')
  .select(['B7', 'B6', 'B5', 'B4', 'B3', 'B2'], ['B7', 'B5', 'B4', 'B3', 'B2', 'B1'])
  .map(app)
  .select(['NDVI', 'SAVI'])
  .map(function (x){
  var multiplied = x.multiply(10000).toInt16().select([0,1], ['NDVI', 'SAVI']).unmask(0)
  return x.addBands(multiplied);
  });
//Criando a coleção Landasat 5 TM e seleção das bandas de interesse.
var collection_l5 = l4toa.filter(ee.Filter.lt('CLOUD_COVER', 25))
  .filterBounds(aoi)
  .map(maskClouds_TM5)
  .filterDate('1984-12-01','2011-10-27')
  .select(['B7', 'B5', 'B4', 'B3', 'B2', 'B1'])
  .map(app)
  .select(['NDVI', 'SAVI']).map(function (x){
  var multiplied = x.multiply(10000).toInt16().select([0,1], ['NDVI', 'SAVI']).unmask(0)
  return x.addBands(multiplied);
  });
var collection_l4 = l4toa.filter(ee.Filter.lt('CLOUD_COVER', 25))
  .filterBounds(aoi)
  .map(maskClouds_TM5)
  .filterDate('1984-12-01','2011-10-27')
  .select(['B7', 'B5', 'B4', 'B3', 'B2', 'B1'])
  .map(app)
  .select(['NDVI', 'SAVI']).map(function (x){
  var multiplied = x.multiply(10000).toInt16().select([0,1], ['NDVI', 'SAVI']).unmask(0)
  return x.addBands(multiplied);
  });
//Criando a coleção Landasat 7 ETM e seleção das bandas de interesse.
var collection_l7 = l7toa.filter(ee.Filter.lt('CLOUD_COVER', 25))
  .filterBounds(aoi)
  .map(maskClouds_TM5)
  .filterDate('1984-12-01','2013-04-04')
  .select(['B7', 'B5', 'B4', 'B3', 'B2', 'B1'])
  .map(app)
  .select(['NDVI', 'SAVI']).map(function (x){
  var multiplied = x.multiply(10000).toInt16().select([0,1], ['NDVI', 'SAVI']).unmask(0)
  return x.addBands(multiplied);
  });
/*
Esta parte do código é usada para criar uma máscara com invertalos regulares, ou seja, a medição da ocorrência de água, 
vai ser feita de acordo com um intervalo de dias definido. No exemplo eu uso trinta anos de observação. Acho importante trabalhar
com longas janelas de tempo. Quanto maior a observação, melhor o estudo.
No intervalo que eu usei, seriam 349 índices de água a partir de 01 de janeiro de 1989 a 01 de janeiro de 2019 com intervalos de 30 dias
*/
//Unindo as três coleções landsat
var collection0 = ee.ImageCollection(collection_l8
.merge(collection_l5)
.merge(collection_l4)
.merge(collection_l7))
.sort('system:time_start', true)
.filterBounds(aoi)
.filterDate(ee.Date('2013-12-01'), ee.Date('2019-01-01'))
.select(['NDVI_1', 'SAVI_1'], ['NDVI', 'SAVI']);
var collection = ee.ImageCollection(collection0
    .map(function(image) {
      return image.clip(aoi)
      .set('count', image.bandNames().length());
    }).filter(ee.Filter.eq('count', 2))).sort('system:time_start', true);
//print(modis.limit(2))
var start_date = '2009-01-01'
var end_date = '2100-01-01'  // the Future
// Add predictors for SG fitting, using date difference
// We prepare for order 3 fitting, but can be adapted to lower order fitting later on
var modis_res = collection.filterDate(start_date, end_date).filterBounds(aoi).map(function(img) {
  var dstamp = ee.Date(img.get('system:time_start'))
  var ddiff = dstamp.difference(ee.Date(start_date), 'hour')
  img = img.select(['NDVI']).set('date', dstamp)
  return img.addBands(ee.Image(1).toFloat().rename('constant')).
    addBands(ee.Image(ddiff).toFloat().rename('t')).
    addBands(ee.Image(ddiff).pow(ee.Image(2)).toFloat().rename('t2')).
    addBands(ee.Image(ddiff).pow(ee.Image(3)).toFloat().rename('t3'))
})
print(modis_res)
// Step 2: Set up Savitzky-Golay smoothing
var window_size = 9
var half_window = (window_size - 1)/2
// Define the axes of variation in the collection array.
var imageAxis = 0;
var bandAxis = 1;
// Change to order = 2 as follows:
var order = 2
var coeffFlattener = [['constant', 'x', 'x2']]
var indepSelectors = ['constant', 't', 't2']
// Convert the collection to an array.
var array = modis_res.toArray();
// Solve 
function getLocalFit(i) {
  // Get a slice corresponding to the window_size of the SG smoother
  var subarray = array.arraySlice(imageAxis, ee.Number(i).int(), ee.Number(i).add(window_size).int())
  var predictors = subarray.arraySlice(bandAxis, 2, 2 + order + 1)
  var response = subarray.arraySlice(bandAxis, 0, 1); // NDVI
  var coeff = predictors.matrixSolve(response)
  coeff = coeff.arrayProject([0]).arrayFlatten(coeffFlattener)
  return coeff  
}
// For the remainder, use modis_res as a list of images
modis_res = modis_res.toList(modis_res.size())
var runLength = ee.List.sequence(0, modis_res.size().subtract(window_size))
// Run the SG solver over the series, and return the smoothed image version
var sg_series = runLength.map(function(i) {
  var ref = ee.Image(modis_res.get(ee.Number(i).add(half_window)))
  return getLocalFit(i).multiply(ref.select(indepSelectors)).reduce(ee.Reducer.sum()).copyProperties(ref)
})
//Juntando coleções-------------------------------------------
var innerJoin = ee.Join.inner();
var filterTimeEq = ee.Filter.equals({
  leftField: 'date',
  rightField: 'date'
});
var innerJoined = innerJoin.apply(ee.ImageCollection(modis_res), ee.ImageCollection(sg_series), filterTimeEq);
var base_collection = ee.ImageCollection(innerJoined.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
})).map(function(image) {
      var multi = image.select('sum').multiply(60000).clip(aoi)
      return image.addBands(multi)
      .set('count', image.bandNames().length());
});
print('Base Collection', base_collection);
Map.centerObject(aoi, 10);
Map.addLayer(base_collection.select('NDVI').median(),{min:0,max:5500},'Original')
Map.addLayer(base_collection.select('sum_1').median(),{min:0,max:5500},'Smoothed')
//FIM------------------------------------------------------------------------------------
///////////////Widget Para criação de Gráfico interativo para diferentes pontos no mapa//////////////
Map.style().set('cursor', 'crosshair');
// Criar um painel lateral em branco para apresentar o gráfico
var panel = ui.Panel({style: {width: '400px'}})
    .add(ui.Label('Clique no mapa para seleção de área de interesse'));
// Criando variável responsiva para seleção de pontos no mapa.
Map.onClick(function(coords) {
  var location = 'long: ' + coords.lon.toFixed(2) + ' ' +
                 'lati: ' + coords.lat.toFixed(2);
  panel.widgets().set(3, ui.Label(location));
// Adicionar um ponto vermelho no mapa onde for clicado para seleção da área de interesse.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  Map.layers().set(1, ui.Map.Layer(point, {color: 'FF0000'}, 'sampled point'));
//Criar o gráfico dinâmico.
  var chart = ui.Chart.image.series(base_collection
    .select(['NDVI', 'sum_1'])
    , point, ee.Reducer.mean(), 30)
    .setChartType('LineChart')
    .setSeriesNames(['NDVI Landsat', 'NDVI SG Landsat'])
    .setOptions({
      title: 'Dados de NDVI simulados 30m (2014-2019)',
      series: {
        0: {color: 'ff0000'},
        1: {color: '000000'}
      },
      lineWidth: 1,
      pointSize: 2,
      });
  panel.widgets().set(2, chart);
});
// Adicionar o painel ao layout
ui.root.add(panel);