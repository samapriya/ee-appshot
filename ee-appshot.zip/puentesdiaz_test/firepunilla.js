var dataset = ee.ImageCollection('FIRMS').filter(
    ee.Filter.date('2020-09-01', '2020-10-10'));
var fires = dataset.select('T21');
var firesVis = {
  min: 300.0,
  max: 370.0,
  palette: ['red', 'orange', 'yellow'],
};
Map.setOptions('SATELLITE');
Map.setCenter(-64.5, -31.39, 12);
Map.addLayer(fires, firesVis, 'Incendios');