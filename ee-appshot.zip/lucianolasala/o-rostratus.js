var Arg = ui.import && ui.import("Arg", "table", {
      "id": "users/lucianolasala/Wild_boar_app/Argentina"
    }) || ee.FeatureCollection("users/lucianolasala/Wild_boar_app/Argentina"),
    Bra = ui.import && ui.import("Bra", "table", {
      "id": "users/lucianolasala/Wild_boar_app/Brazil"
    }) || ee.FeatureCollection("users/lucianolasala/Wild_boar_app/Brazil"),
    Bol = ui.import && ui.import("Bol", "table", {
      "id": "users/lucianolasala/Wild_boar_app/Bolivia"
    }) || ee.FeatureCollection("users/lucianolasala/Wild_boar_app/Bolivia"),
    Par = ui.import && ui.import("Par", "table", {
      "id": "users/lucianolasala/Wild_boar_app/Paraguay"
    }) || ee.FeatureCollection("users/lucianolasala/Wild_boar_app/Paraguay"),
    M = ui.import && ui.import("M", "table", {
      "id": "users/lucianolasala/Ticks_app/O_rostratus_biomes"
    }) || ee.FeatureCollection("users/lucianolasala/Ticks_app/O_rostratus_biomes"),
    ENM_rostratus = ui.import && ui.import("ENM_rostratus", "image", {
      "id": "users/lucianolasala/Ticks_app/O_rostratus_enm"
    }) || ee.Image("users/lucianolasala/Ticks_app/O_rostratus_enm");
Map.centerObject(M, 4)
var pal = {
  min: 0,
  max: 1,
  palette: ["00007f","0000ff","007fff","00ffff","7fff7f","ffff00","ff7f00","ff0000","7f0000"],
};
Map.centerObject(M, 5)
Map.addLayer(ENM_rostratus, pal, 'O. rostratus ENM')
Map.addLayer(Arg.style({color:'black',fillColor:'FF000000', width:1}), null, 'Argentina')
Map.addLayer(Bra.style({color:'black',fillColor:'FF000000', width:1}), null, 'Brasil')
Map.addLayer(Bol.style({color:'black',fillColor:'FF000000', width:1}), null, 'Bolivia')
Map.addLayer(Par.style({color:'black',fillColor:'FF000000', width:1}), null, 'Paraguay')
Map.addLayer(M.style({color:'black',fillColor:'FF000000', width:1}), null, 'Calibration Area')