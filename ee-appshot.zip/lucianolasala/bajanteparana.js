var year_1 = ui.import && ui.import("year_1", "image", {
      "id": "users/lucianolasala/Parana_2019"
    }) || ee.Image("users/lucianolasala/Parana_2019"),
    year_2 = ui.import && ui.import("year_2", "image", {
      "id": "users/lucianolasala/Parana_2021"
    }) || ee.Image("users/lucianolasala/Parana_2021"),
    dif = ui.import && ui.import("dif", "image", {
      "id": "projects/ee-lucianolasala/assets/isodata_difference_reclass"
    }) || ee.Image("projects/ee-lucianolasala/assets/isodata_difference_reclass");
// App title
var header10 = ui.Label("Cobertura de agua asociada al Río Paraná: 2019-2021", 
            {fontSize: '18px', fontWeight: 'bold', color: '4A997E'});
// App summary
var text10 = ui.Label(
"Esta aplicación se presenta como complemento del trabajo final del curso Teledetección Óptica Avanzada, " +
"y permite comparar de forma dinámica la superficie cubierta por agua asociada al cauce del Río Paraná en dos fechas " + 
"específicas de 2019 y 2021. " , {fontSize: '14px'});
// Create a panel to hold text
var panel10 = ui.Panel({
  widgets:[header10, text10], // Adds header and text
  style:{width: '400px', position:'top-right', backgroundColor: 'white'}});
// Add our main panel to the root of our GUI
ui.root.insert(1, panel10)
// Configure our map with a minimal set of controls
Map.setControlVisibility(false, true, {scaleControl: true, zoomControl: true});
Map.style().set({cursor: 'crosshair'});
////////////////////////////////////////////////////////////////////
// Palette for binary and continuous models
////////////////////////////////////////////////////////////////////
var pal_3 = {
  min: 0,
  max: 1,
  palette: ["#08b7c1","#a52a2a"],
};
Map.addLayer(dif, pal_3, "Diferencia", true),
Map.centerObject(year_2, 10);
var pal_2 = {
  min: 0,
  max: 1,
  palette: ["#08b7c1","#a52a2a"],
};
Map.addLayer(year_2, pal_2, 'Nivel del agua 2021', true),
Map.centerObject(year_2, 10);
var pal_1 = {
  min: 0,
  max: 1,
  palette: ["#08b7c1","#a52a2a"],
};
Map.addLayer(year_1, pal_1, 'Nivel del agua 2019', true),
Map.centerObject(year_1, 10);
/////////////////////////////////////////////////////
// Add legend for binary models
/////////////////////////////////////////////////////
// set position of panel diff
var legend3 = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle3 = ui.Label({
  value: 'Diferencia 2021-2019',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend3.add(legendTitle3);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
// Create the label that is actually the colored box.
      var colorBox3 = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
// Create the label filled with the description text.
      var description3 = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox3, description3],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette3 =["08b7c1","a52a2a"];
// name of the legend
var names3 = ['Presente','Ausente'];
// Add color and and names
for (var i = 0; i < 2; i++) {
  legend3.add(makeRow(palette3[i], names3[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)  
Map.add(legend3);
//----------------------------------------------------------//
// set position of panel 2021
var legend2 = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle2 = ui.Label({
  value: 'Nivel de agua 2021',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend2.add(legendTitle2);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
// Create the label that is actually the colored box.
      var colorBox2 = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
// Create the label filled with the description text.
      var description2 = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox2, description2],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette2 =["08b7c1","a52a2a"];
// name of the legend
var names2 = ['Presente','Ausente'];
// Add color and and names
for (var i = 0; i < 2; i++) {
  legend2.add(makeRow(palette2[i], names2[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)  
Map.add(legend2);
//----------------------------------------------------------//
// set position of panel 2019
var legend1 = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle1 = ui.Label({
  value: 'Nivel del agua 2019',
  style: {
    fontWeight: 'bold',
    fontSize: '14px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend1.add(legendTitle1);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
// Create the label that is actually the colored box.
      var colorBox1 = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
// Create the label filled with the description text.
      var description1 = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox1, description1],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette1 =["08b7c1","a52a2a"];
// name of the legend
var names1 = ['Presente','Ausente'];
// Add color and and names
for (var i = 0; i < 2; i++) {
  legend1.add(makeRow(palette1[i], names1[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)  
Map.add(legend1);