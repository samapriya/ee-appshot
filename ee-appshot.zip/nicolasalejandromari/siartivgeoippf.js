//////////////////////////////////////////////////////////////////////////////////
////                                                                          ////
////              ÍNDICE DE PELIGRO DE PROPAGACIÓN DEL FUEGO                  ////
////                     DADA UNA FUENTE DE INGNICIÓN                         ////
////==========================================================================////
////                     Abril 2023  - L. Zalazar                             ////
////                                                                          ////  
////                             Descripción:                                 ////
////     -Incorpora variables combustibles (tipo y humedad) y topográficas.   ////
////     -Índice complementario al índice meteorológico.                      ////
////     -Desarrollado mediante el método de análisis multicriterio.          ////
////                                                                          ////
////                         Revisión: Nicolás A. Mari                        ////
////                                                                          ////
//////////////////////////////////////////////////////////////////////////////////
///============================= ÁREA DE ESTUDIO =============================///
var pais = ee.FeatureCollection("FAO/GAUL/2015/level0")
              .filter(ee.Filter.inList('ADM0_CODE', ee.List([12, 81]))); 
var provincias = ee.FeatureCollection("FAO/GAUL/2015/level1")
              .filter(ee.Filter.inList('ADM0_CODE', ee.List([12, 81]))); 
var borderStyle = { color: '000000', fillColor: '00000000', width: 1 };
provincias = provincias.style(borderStyle);
var corte = function(image){ return image.clip(pais); };
var maskOutside = function(image, geometry){
  var mask = ee.Image.constant(1).clip(geometry).mask(); 
  return image.updateMask(mask);
};
///============================ FECHA DE ANÁLISIS ============================///
var fecha = new Date(); 
var fechaConsulta = fecha;
// var fechaConsulta = new Date('2023/12/21'); // opcional
var dia = fechaConsulta.getDate();
var mes = fechaConsulta.getMonth() + 1;  
var anno = fechaConsulta.getFullYear(); 
var fechaHistIni = '2012-01-17'; 
var fechaHistFin = new Date(anno-1, mes-1, dia);
print('Fecha de Consulta', fechaConsulta);
///=========================== CAPA DE COMBUSTIBLES ===========================///
var coberturas = ee.Image("COPERNICUS/Landcover/100m/Proba-V-C3/Global/2019")
                   .select('discrete_classification')
                   .clip(pais);
var combustibles = coberturas.remap(
  [0,20,30,40,50,60,70,80,90,100,111,112,113,114,115,116,121,122,123,124,125,126,200],
  [0,4,3,90,91,92,93,94,95,96,9,9,9,9,9,9,7,7,7,7,11,11,99]);
var combustiblesr = combustibles.toFloat().reproject('EPSG:4326', null, 1000);
var claseCombustibles = combustiblesr.remap([0,3,4,7,9,11,90,91,92,93,94,95,96],[0,4,3,2,1,1,0,0,0,0,0,0,0]);
var noCombustibles = combustiblesr.remap([0,91,92,93,94,96,3,4,7,9,11,90,95],[0,0,0,0,0,0,1,1,1,1,1,1,1]);
///========================= CAPA DE ESTRÉS HÍDRICO ==========================///
var addNDII=function(image){
  var ndii=image.normalizedDifference(['NIR_reflectance','SWIR2_reflectance']).rename('NDII');
  return image.addBands(ndii);
};
var dataset = ee.ImageCollection('NASA/VIIRS/002/VNP13A1')
  .filter(ee.Filter.date(fechaHistIni, fechaHistFin))
  .filter(ee.Filter.calendarRange(mes,mes,'month'))
  .map(corte)
  .map(addNDII);
var NDII = dataset.select('NDII');
var promedio= NDII.mean();
var desvStand= NDII.reduce(ee.Reducer.stdDev());
var fechaMLS = new Date(fechaConsulta).getTime();
var fechaPrevia = ee.Date(fechaMLS - (35 * 24 * 60 * 60000)).format('YYYY-MM-dd');
var actual = ee.ImageCollection('NASA/VIIRS/002/VNP13A1')
  .filter(ee.Filter.date(fechaPrevia, fechaConsulta))
  .map(corte)
  .map(addNDII)
  .sort('system:time_start', false)
  .first();
var fechaIniNDII = ee.Date(actual.get('system:time_start'));
var fechaFinNDII = ee.Date(actual.get('system:time_end'));
print('Inicio Compuesto NDII', fechaIniNDII);
print('Fin Compuesto NDII', fechaFinNDII);
var anomalia = (actual.select('NDII')).subtract(promedio).divide(desvStand);
var anomaliar = anomalia.toFloat().reproject('EPSG:4326', null, 1000);
var claseAnomalia = ee.Image(1)
  .where(anomaliar.gte(0.5),1)
  .where(anomaliar.gt(-0.5).and(anomaliar.lt(0.5)),2)
  .where(anomaliar.gt(-1.5).and(anomaliar.lte(-0.5)),3)
  .where(anomaliar.lte(-1.5),4)
  .clip(pais);
///============================ CAPAS TOPOGRÁFICAS ============================///
var elevacion = ee.Image('CGIAR/SRTM90_V4').select('elevation').clip(pais);
var pendiente = ee.Terrain.slope(elevacion).clip(pais);
var pendienter = pendiente.toFloat().reproject('EPSG:4326', null, 1000);
var clasePendiente = ee.Image(1)
  .where(pendienter.lte(10),1)
  .where(pendienter.gt(10).and(pendienter.lte(25)),2)
  .where(pendienter.gt(25).and(pendienter.lte(31)),3)
  .where(pendienter.gt(31),4)
  .clip(pais);
var orientacion = ee.Terrain.aspect(elevacion).clip(pais);
var orientacionr = orientacion.toFloat().reproject('EPSG:4326', null, 1000);
var claseOrientacion = ee.Image(1)
  .where(orientacionr.lte(45),4)
  .where(orientacionr.gt(45).and(orientacionr.lte(135)),2)
  .where(orientacionr.gt(135).and(orientacionr.lte(225)),1)
  .where(orientacionr.gt(225).and(orientacionr.lte(315)),2)
  .where(orientacionr.gt(315),4)
  .clip(pais);
///========================== ÍNDICE DE PROPAGACIÓN ==========================///
var peligro = (claseCombustibles.multiply(0.306))
  .add(claseAnomalia.multiply(0.519))
  .add(clasePendiente.multiply(0.126))
  .add(claseOrientacion.multiply(0.05));
var mascaraPeligro = peligro.multiply(noCombustibles);
var clasePeligro = ee.Image(1)
  .where(mascaraPeligro.eq(0),0)
  .where(mascaraPeligro.gt(0).and(mascaraPeligro.lte(1)),1)
  .where(mascaraPeligro.gt(1).and(mascaraPeligro.lte(2)),2)
  .where(mascaraPeligro.gt(2).and(mascaraPeligro.lte(3)),3)
  .where(mascaraPeligro.gt(3),4)
  .clip(pais);
// Detecta píxeles sin datos en el NDII actual
var mascaraDatos = actual.select('NDII').mask();
// Aplica la máscara de validez: donde no hay datos, asigna -1
var clasePeligroConHuecos = clasePeligro
  .updateMask(mascaraDatos)
  .unmask(-1)
  .clip(pais);  // 🔒 restringe todos los valores (incluido -1) al país
///========================== VISUALIZACIÓN DEL IPPF ==========================///
var peligroVis = {
  min: -1,
  max: 4,
  palette: ["000000", "d9d6d5", "16e35b", "0c86ed", "f1fa0c", "ff921a"],
};
Map.centerObject(pais, 4);
Map.addLayer(clasePeligroConHuecos, peligroVis, 'IPPF');
Map.addLayer(provincias, {}, 'Provincias Argentinas');
var etiquetas = ['Sin datos','Muy Bajo o Nulo','Bajo','Moderado','Alto','Muy Alto'];
var simbologia = ["000000","d9d6d5","16e35b","0c86ed","f1fa0c","ff921a"];
var titulo = ui.Label({value: 'IPPF', style: {fontWeight: 'bold', fontSize: '18px', margin: '0 0 4px 0',padding: '0'}});
var leyenda = ui.Panel({style: {position: 'bottom-left', padding: '8px 15px'}});
leyenda.add(titulo);
var simbolos = function(simbolo, texto){
  var textoleyenda = ui.Label({value: texto, style: {margin: '6px 0px 10px 15px'}});
  var cajaleyenda = ui.Label({style: {backgroundColor: '#' + simbolo, padding: '15px', margin: '10 10 6px 0'}});
  return ui.Panel({widgets: [cajaleyenda, textoleyenda], layout: ui.Panel.Layout.Flow('horizontal')});
};
for (var i=0; i<6; i++) {leyenda.add(simbolos(simbologia[i], etiquetas[i]));}
Map.add(leyenda);
///=========================== EXPORTACIÓN DEL IPPF ===========================///
var clasePeligro = (maskOutside(clasePeligroConHuecos, pais));
Export.image.toDrive({
  image: clasePeligro,
  description: ('IPPF_' + anno +'-'+ mes +'-'+dia),
  folder: 'Peligro_Propagacion_Fuego',
  scale: 1000,
  crs: 'EPSG:4326',
  region: pais,
  maxPixels: 1e13
});