var Builtup = ui.import && ui.import("Builtup", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -14.95721996251025,
            16.64501566490445
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.956780080231807,
            16.644953989247796
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.95646894398608,
            16.64497711762137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.956275824937007,
            16.645226389914946
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.958260659608028,
            16.645326612704483
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.95721549239895,
            16.643960242049516
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.958395664365502,
            16.65004550942001
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.956679050595971,
            16.649613790739153
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.959275428922387,
            16.649737139032958
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.959168140561792,
            16.648133605019403
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.957945053251,
            16.648133605019403
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.956743423612329,
            16.648544768866373
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.958867733152124,
            16.646550615971286
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.958786082000143,
            16.655510908745146
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.960180830687888,
            16.65567536805612
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.958292555541403,
            16.65396909583688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.959944796294577,
            16.652283366187593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.956919264525778,
            16.65324957889886
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.956039499968893,
            16.654565264966507
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.956318449706442,
            16.652530059258044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.958185267180808,
            16.65238615500557
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.958013605803854,
            16.653516828362786
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.959343981475241,
            16.65341404015156
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.959944796294577,
            16.65337292485162
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.961232256621726,
            16.655367006732213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.961082052916892,
            16.656353761221034
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.957024708292057,
            16.65256575785033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.956327333948185,
            16.653480575042508
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.955805132096923,
            16.654156478988153
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.959286639398254,
            16.654511096709175
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.957312533563293,
            16.655251166359836
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.992441838081735,
            16.58874790749167
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.99281734734382,
            16.588439438618146
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.990457003410715,
            16.588357180168313
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.991111462410348,
            16.587812217049624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.99080032616462,
            16.58919004534765
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.991283123787301,
            16.589539642002563
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.989931290443796,
            16.589087222681158
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.989866917427438,
            16.588809601207018
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.991433327492135,
            16.590351937658816
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.99057502060737,
            16.59059871034326
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.990403359230417,
            16.59050617062371
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.9927958896717,
            16.590999715280102
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.992280905540841,
            16.591030561779057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.992989008720773,
            16.589416255020456
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.99282807617988,
            16.590156575725718
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.092142328532109,
            16.517886630800827
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.092018946917424,
            16.51826207191739
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.092528566630254,
            16.518143782329254
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.093166932375798,
            16.518380361433117
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.093719467432866,
            16.51827235796511
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.094266638071904,
            16.51820549864514
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.094674333842168,
            16.51811292416391
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.09234617641724,
            16.51712031721644
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.647098977724688,
            16.511099276047833
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.646101195971148,
            16.513177123589838
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.64930911795296,
            16.511922188637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.654491719897017,
            16.50902289873093
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.424683590178592,
            16.48824874925451
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.424946446662052,
            16.487929832012455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.425788660292728,
            16.487924688181657
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.424597759490116,
            16.488881438356966
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.424104233031375,
            16.489087190465007
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.425520439391239,
            16.487739510182173
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.758586418407093,
            16.54544137124427
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.756097328441273,
            16.545595640179705
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.755367767589222,
            16.54536937903217
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.76014209963573,
            16.545050556055592
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.76115061022533,
            16.545143117619208
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.75743843294872,
            16.544978563697622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.755614530818592,
            16.545019702191183
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.758361112849842,
            16.544927140568333
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.754021298663746,
            16.54856786424281
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.75365651823772,
            16.54849587319787
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.89927208035883,
            16.186866940081366
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.898993130621282,
            16.18750060550424
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.898499604162541,
            16.187459391554857
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.901144262251226,
            16.187778799437524
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.90079021066126,
            16.187768495965507
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.899824615415898,
            16.18752636421824
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.899610038694707,
            16.186954519976418
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.898960944113103,
            16.187881834128127
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 0
      },
      "color": "#d63000",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": true
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* locked: true */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-14.95721996251025, 16.64501566490445]),
            {
              "landuse": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.956780080231807, 16.644953989247796]),
            {
              "landuse": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.95646894398608, 16.64497711762137]),
            {
              "landuse": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.956275824937007, 16.645226389914946]),
            {
              "landuse": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.958260659608028, 16.645326612704483]),
            {
              "landuse": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.95721549239895, 16.643960242049516]),
            {
              "landuse": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.958395664365502, 16.65004550942001]),
            {
              "landuse": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.956679050595971, 16.649613790739153]),
            {
              "landuse": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.959275428922387, 16.649737139032958]),
            {
              "landuse": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.959168140561792, 16.648133605019403]),
            {
              "landuse": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.957945053251, 16.648133605019403]),
            {
              "landuse": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.956743423612329, 16.648544768866373]),
            {
              "landuse": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.958867733152124, 16.646550615971286]),
            {
              "landuse": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.958786082000143, 16.655510908745146]),
            {
              "landuse": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.960180830687888, 16.65567536805612]),
            {
              "landuse": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.958292555541403, 16.65396909583688]),
            {
              "landuse": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.959944796294577, 16.652283366187593]),
            {
              "landuse": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.956919264525778, 16.65324957889886]),
            {
              "landuse": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.956039499968893, 16.654565264966507]),
            {
              "landuse": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.956318449706442, 16.652530059258044]),
            {
              "landuse": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.958185267180808, 16.65238615500557]),
            {
              "landuse": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.958013605803854, 16.653516828362786]),
            {
              "landuse": 0,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.959343981475241, 16.65341404015156]),
            {
              "landuse": 0,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.959944796294577, 16.65337292485162]),
            {
              "landuse": 0,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.961232256621726, 16.655367006732213]),
            {
              "landuse": 0,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.961082052916892, 16.656353761221034]),
            {
              "landuse": 0,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.957024708292057, 16.65256575785033]),
            {
              "landuse": 0,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.956327333948185, 16.653480575042508]),
            {
              "landuse": 0,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.955805132096923, 16.654156478988153]),
            {
              "landuse": 0,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.959286639398254, 16.654511096709175]),
            {
              "landuse": 0,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.957312533563293, 16.655251166359836]),
            {
              "landuse": 0,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.992441838081735, 16.58874790749167]),
            {
              "landuse": 0,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.99281734734382, 16.588439438618146]),
            {
              "landuse": 0,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.990457003410715, 16.588357180168313]),
            {
              "landuse": 0,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.991111462410348, 16.587812217049624]),
            {
              "landuse": 0,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.99080032616462, 16.58919004534765]),
            {
              "landuse": 0,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.991283123787301, 16.589539642002563]),
            {
              "landuse": 0,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.989931290443796, 16.589087222681158]),
            {
              "landuse": 0,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.989866917427438, 16.588809601207018]),
            {
              "landuse": 0,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.991433327492135, 16.590351937658816]),
            {
              "landuse": 0,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.99057502060737, 16.59059871034326]),
            {
              "landuse": 0,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.990403359230417, 16.59050617062371]),
            {
              "landuse": 0,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.9927958896717, 16.590999715280102]),
            {
              "landuse": 0,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.992280905540841, 16.591030561779057]),
            {
              "landuse": 0,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.992989008720773, 16.589416255020456]),
            {
              "landuse": 0,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.99282807617988, 16.590156575725718]),
            {
              "landuse": 0,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.092142328532109, 16.517886630800827]),
            {
              "landuse": 0,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.092018946917424, 16.51826207191739]),
            {
              "landuse": 0,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.092528566630254, 16.518143782329254]),
            {
              "landuse": 0,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.093166932375798, 16.518380361433117]),
            {
              "landuse": 0,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.093719467432866, 16.51827235796511]),
            {
              "landuse": 0,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.094266638071904, 16.51820549864514]),
            {
              "landuse": 0,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.094674333842168, 16.51811292416391]),
            {
              "landuse": 0,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.09234617641724, 16.51712031721644]),
            {
              "landuse": 0,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.647098977724688, 16.511099276047833]),
            {
              "landuse": 0,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.646101195971148, 16.513177123589838]),
            {
              "landuse": 0,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.64930911795296, 16.511922188637]),
            {
              "landuse": 0,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.654491719897017, 16.50902289873093]),
            {
              "landuse": 0,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.424683590178592, 16.48824874925451]),
            {
              "landuse": 0,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.424946446662052, 16.487929832012455]),
            {
              "landuse": 0,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.425788660292728, 16.487924688181657]),
            {
              "landuse": 0,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.424597759490116, 16.488881438356966]),
            {
              "landuse": 0,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.424104233031375, 16.489087190465007]),
            {
              "landuse": 0,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.425520439391239, 16.487739510182173]),
            {
              "landuse": 0,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.758586418407093, 16.54544137124427]),
            {
              "landuse": 0,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.756097328441273, 16.545595640179705]),
            {
              "landuse": 0,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.755367767589222, 16.54536937903217]),
            {
              "landuse": 0,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.76014209963573, 16.545050556055592]),
            {
              "landuse": 0,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.76115061022533, 16.545143117619208]),
            {
              "landuse": 0,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.75743843294872, 16.544978563697622]),
            {
              "landuse": 0,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.755614530818592, 16.545019702191183]),
            {
              "landuse": 0,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.758361112849842, 16.544927140568333]),
            {
              "landuse": 0,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.754021298663746, 16.54856786424281]),
            {
              "landuse": 0,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.75365651823772, 16.54849587319787]),
            {
              "landuse": 0,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.89927208035883, 16.186866940081366]),
            {
              "landuse": 0,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.898993130621282, 16.18750060550424]),
            {
              "landuse": 0,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.898499604162541, 16.187459391554857]),
            {
              "landuse": 0,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.901144262251226, 16.187778799437524]),
            {
              "landuse": 0,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.90079021066126, 16.187768495965507]),
            {
              "landuse": 0,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.899824615415898, 16.18752636421824]),
            {
              "landuse": 0,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.899610038694707, 16.186954519976418]),
            {
              "landuse": 0,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.898960944113103, 16.187881834128127]),
            {
              "landuse": 0,
              "system:index": "81"
            })]),
    Water = ui.import && ui.import("Water", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -14.419986651533192,
            16.50416518342293
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.418484614484852,
            16.502210681887558
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.419882634624665,
            16.510610099461466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.37729376813434,
            16.515448477183334
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.555299933251824,
            16.53202913235518
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.55266063958117,
            16.530239479294952
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.550858195123162,
            16.52912865180933
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.54965656548449,
            16.52824409942571
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.606253684404185,
            16.522531719477698
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.603839696290782,
            16.52238771793493
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.602080167177013,
            16.52226428795569
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.65927652882153,
            16.524635091210367
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.657516999707761,
            16.523328801796545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.712785759275464,
            16.531941685885094
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.711605587308911,
            16.53339191047224
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.76198865075814,
            16.553613418824842
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.755830298859946,
            16.55176226042977
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.75400639672982,
            16.55040473297624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.832650939237636,
            16.609368035212448
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.831717530500454,
            16.608345054630433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.837285051092767,
            16.631774291827686
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.848472808228099,
            16.638636768249075
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.840404723511302,
            16.639849759163234
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.834096167908275,
            16.63703314136284
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.951522336324159,
            16.675205684586434
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.951179013570252,
            16.67323236489317
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.345962744322915,
            16.469827722785435
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.34630606707682,
            16.468171247408694
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.346906881896157,
            16.467327571278492
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.384988136434544,
            16.50175980894369
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.380675144338596,
            16.498303370874126
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.39233122903434,
            16.5047580974158
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.389262781921303,
            16.50393515433179
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.38682733613578,
            16.50305048661048
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.400699721160805,
            16.5031430683058
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.397620545211709,
            16.50437748667476
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.393747435394204,
            16.504500928078272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.395742998901284,
            16.50440834703302
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.399648295226967,
            16.504068882821255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.399959431472695,
            16.50354425514001
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.397287951293862,
            16.504182037624716
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.395367489639199,
            16.50420261121824
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.401493655029213,
            16.5027213068904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.402890599221095,
            16.501165877446383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.40303007408987,
            16.49978742019733
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.403405583351955,
            16.49870727892114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.403824007958278,
            16.497411101428483
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.40503636643301,
            16.495322797201496
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.405712283104762,
            16.494952455182545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.411870635002956,
            16.49279211261157
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.406731522530421,
            16.493615103101597
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.40977851197134,
            16.492154292574426
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.407385981530055,
            16.493090447068635
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.410711920708522,
            16.492637801505033
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.413973486870631,
            16.493913436289848
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.41301862046133,
            16.493111021841816
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.408855832070216,
            16.49259665185584
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.408845103234157,
            16.496639563083463
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.410647547692164,
            16.49684530694299
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.408040440529689,
            16.49623836192808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.40576592728506,
            16.496989327514456
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.624713883625155,
            16.53036944765541
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.62307237170804,
            16.530955714745698
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.626065716968661,
            16.52990660395807
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.71307749081269,
            16.523366430175
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.710802977568061,
            16.5230578566426
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.706425612455757,
            16.521967559546493
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.705052321440132,
            16.521638412043902
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.708549921995552,
            16.522564137965325
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.782730796102529,
            16.54509487068331
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.77908826209567,
            16.545980121232564
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.776685002818326,
            16.546586909971655
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.780525926127652,
            16.54526019991337
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.781620267405728,
            16.54573329136872
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.974366739815455,
            16.224192712567827
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.974044874733668,
            16.223203759486566
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.97350843293069,
            16.222482644733624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.972950533455592,
            16.222276611462046
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.974109247750025,
            16.22507864548525
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.973594263619166,
            16.226026383262788
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.973122194832545,
            16.227077130683142
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 1
      },
      "color": "#0b4a8b",
      "mode": "FeatureCollection",
      "shown": true,
      "locked": true
    }) || 
    /* color: #0b4a8b */
    /* locked: true */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-14.419986651533192, 16.50416518342293]),
            {
              "landuse": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.418484614484852, 16.502210681887558]),
            {
              "landuse": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.419882634624665, 16.510610099461466]),
            {
              "landuse": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.37729376813434, 16.515448477183334]),
            {
              "landuse": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.555299933251824, 16.53202913235518]),
            {
              "landuse": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.55266063958117, 16.530239479294952]),
            {
              "landuse": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.550858195123162, 16.52912865180933]),
            {
              "landuse": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.54965656548449, 16.52824409942571]),
            {
              "landuse": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.606253684404185, 16.522531719477698]),
            {
              "landuse": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.603839696290782, 16.52238771793493]),
            {
              "landuse": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.602080167177013, 16.52226428795569]),
            {
              "landuse": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.65927652882153, 16.524635091210367]),
            {
              "landuse": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.657516999707761, 16.523328801796545]),
            {
              "landuse": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.712785759275464, 16.531941685885094]),
            {
              "landuse": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.711605587308911, 16.53339191047224]),
            {
              "landuse": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.76198865075814, 16.553613418824842]),
            {
              "landuse": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.755830298859946, 16.55176226042977]),
            {
              "landuse": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.75400639672982, 16.55040473297624]),
            {
              "landuse": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.832650939237636, 16.609368035212448]),
            {
              "landuse": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.831717530500454, 16.608345054630433]),
            {
              "landuse": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.837285051092767, 16.631774291827686]),
            {
              "landuse": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.848472808228099, 16.638636768249075]),
            {
              "landuse": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.840404723511302, 16.639849759163234]),
            {
              "landuse": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.834096167908275, 16.63703314136284]),
            {
              "landuse": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.951522336324159, 16.675205684586434]),
            {
              "landuse": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.951179013570252, 16.67323236489317]),
            {
              "landuse": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.345962744322915, 16.469827722785435]),
            {
              "landuse": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.34630606707682, 16.468171247408694]),
            {
              "landuse": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.346906881896157, 16.467327571278492]),
            {
              "landuse": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.384988136434544, 16.50175980894369]),
            {
              "landuse": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.380675144338596, 16.498303370874126]),
            {
              "landuse": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.39233122903434, 16.5047580974158]),
            {
              "landuse": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.389262781921303, 16.50393515433179]),
            {
              "landuse": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.38682733613578, 16.50305048661048]),
            {
              "landuse": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.400699721160805, 16.5031430683058]),
            {
              "landuse": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.397620545211709, 16.50437748667476]),
            {
              "landuse": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.393747435394204, 16.504500928078272]),
            {
              "landuse": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.395742998901284, 16.50440834703302]),
            {
              "landuse": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.399648295226967, 16.504068882821255]),
            {
              "landuse": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.399959431472695, 16.50354425514001]),
            {
              "landuse": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.397287951293862, 16.504182037624716]),
            {
              "landuse": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.395367489639199, 16.50420261121824]),
            {
              "landuse": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.401493655029213, 16.5027213068904]),
            {
              "landuse": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.402890599221095, 16.501165877446383]),
            {
              "landuse": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.40303007408987, 16.49978742019733]),
            {
              "landuse": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.403405583351955, 16.49870727892114]),
            {
              "landuse": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.403824007958278, 16.497411101428483]),
            {
              "landuse": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.40503636643301, 16.495322797201496]),
            {
              "landuse": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.405712283104762, 16.494952455182545]),
            {
              "landuse": 1,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.411870635002956, 16.49279211261157]),
            {
              "landuse": 1,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.406731522530421, 16.493615103101597]),
            {
              "landuse": 1,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.40977851197134, 16.492154292574426]),
            {
              "landuse": 1,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.407385981530055, 16.493090447068635]),
            {
              "landuse": 1,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.410711920708522, 16.492637801505033]),
            {
              "landuse": 1,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.413973486870631, 16.493913436289848]),
            {
              "landuse": 1,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.41301862046133, 16.493111021841816]),
            {
              "landuse": 1,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.408855832070216, 16.49259665185584]),
            {
              "landuse": 1,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.408845103234157, 16.496639563083463]),
            {
              "landuse": 1,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.410647547692164, 16.49684530694299]),
            {
              "landuse": 1,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.408040440529689, 16.49623836192808]),
            {
              "landuse": 1,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.40576592728506, 16.496989327514456]),
            {
              "landuse": 1,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.624713883625155, 16.53036944765541]),
            {
              "landuse": 1,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.62307237170804, 16.530955714745698]),
            {
              "landuse": 1,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.626065716968661, 16.52990660395807]),
            {
              "landuse": 1,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.71307749081269, 16.523366430175]),
            {
              "landuse": 1,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.710802977568061, 16.5230578566426]),
            {
              "landuse": 1,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.706425612455757, 16.521967559546493]),
            {
              "landuse": 1,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.705052321440132, 16.521638412043902]),
            {
              "landuse": 1,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.708549921995552, 16.522564137965325]),
            {
              "landuse": 1,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.782730796102529, 16.54509487068331]),
            {
              "landuse": 1,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.77908826209567, 16.545980121232564]),
            {
              "landuse": 1,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.776685002818326, 16.546586909971655]),
            {
              "landuse": 1,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.780525926127652, 16.54526019991337]),
            {
              "landuse": 1,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.781620267405728, 16.54573329136872]),
            {
              "landuse": 1,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.974366739815455, 16.224192712567827]),
            {
              "landuse": 1,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.974044874733668, 16.223203759486566]),
            {
              "landuse": 1,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.97350843293069, 16.222482644733624]),
            {
              "landuse": 1,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.972950533455592, 16.222276611462046]),
            {
              "landuse": 1,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.974109247750025, 16.22507864548525]),
            {
              "landuse": 1,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.973594263619166, 16.226026383262788]),
            {
              "landuse": 1,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.973122194832545, 16.227077130683142]),
            {
              "landuse": 1,
              "system:index": "80"
            })]),
    Cropland = ui.import && ui.import("Cropland", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -14.924271934274186,
            16.59638491854199
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.92240511679982,
            16.597392540059484
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.921890132668961,
            16.59640548229923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.92167555594777,
            16.595562366448974
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.924207561257829,
            16.59393781572618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.921804301980485,
            16.593444278610843
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.919229381326188,
            16.593649919229527
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.918113582375993,
            16.594287403749703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.917147987130631,
            16.59591195151854
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.914894931558122,
            16.594349095687885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.913907878640641,
            16.594493043466635
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.913822047952165,
            16.593300330046915
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.92517315650319,
            16.592580585610758
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.863904298839278,
            16.58415105767582
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.860041917857833,
            16.58213567060164
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.865577997264571,
            16.57633617370756
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.864290536937423,
            16.581271926821813
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.858754457530685,
            16.578639540913475
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.861286462840743,
            16.57654183261451
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.859008940837771,
            16.572686374727986
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.856348189494998,
            16.569560273027697
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.851026686809451,
            16.574413935471277
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.85677734293738,
            16.56836740505409
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.853472861431033,
            16.56606391495429
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.850855025432498,
            16.564912159573538
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.857378157756717,
            16.565652574537467
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.813227719646399,
            16.556667146274435
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.808549947124426,
            16.55576215206223
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.813141888957922,
            16.551442802968804
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.818592137676184,
            16.555638743431327
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.816403455120032,
            16.553787604485958
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.825528089438578,
            16.538211140932084
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.821601335440775,
            16.538766529337916
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.81846851531138,
            16.538910518663656
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.81424135390391,
            16.53726491996628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.81696647826304,
            16.538170000986575
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.816151086722513,
            16.538252280868814
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.82546371642222,
            16.536915228435113
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.828403417502543,
            16.53806715108443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.757636818730822,
            16.53338220307571
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.763773712956896,
            16.53576836461749
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.764889511907091,
            16.53190112245344
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.774631295049181,
            16.53029660562209
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.775875840032091,
            16.533546766887778
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.768193993413439,
            16.5289389271179
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.764074120366564,
            16.53066687992071
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.759696755254259,
            16.53301193398557
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.506080901390753,
            16.509502797288132
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.505624925858221,
            16.509510512173637
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.505018746620856,
            16.509587661011803
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.504696881539068,
            16.509572231246644
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.504632508522711,
            16.50925592078924
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.505472039944372,
            16.50918391508435
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.506711220509253,
            16.509286780368853
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.506123816734991,
            16.509165913653934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.502070998913489,
            16.51167323960298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.501191234356604,
            16.510315430203292
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.330566356850351,
            16.440919225393063
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.318206737709726,
            16.442936085564416
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.315503071022714,
            16.443388847212972
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.313013981056894,
            16.44215404022983
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.31112570591041,
            16.438490733305308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.318035076332773,
            16.43766750875586
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.326317737770761,
            16.434292251620445
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.33082384891578,
            16.434827357273765
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.302757213783945,
            16.438120282689916
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.298208187294687,
            16.43762634743678
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.140205924638408,
            16.301644504583464
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.140715544351238,
            16.30152608321495
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.139830415376323,
            16.3012223063336
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.141638224252361,
            16.30180411587996
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.142571839747415,
            16.299015800180804
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.140007647929178,
            16.299458598430572
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.140876683650003,
            16.29874806121877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.148077467061006,
            16.299914498984815
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.147621491528474,
            16.299515466651332
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.148788252449952,
            16.299412490433358
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.148487845040284,
            16.29937129993101
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.147648313618623,
            16.29999173095549
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.844141254437353,
            16.088774661753437
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.840557823193457,
            16.090465269017876
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.845021018994238,
            16.087640709794858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.333177455407382,
            16.442569083701002
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.325624354821445,
            16.438658818136517
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.321161159020663,
            16.439852486501163
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.323349841576816,
            16.435324740044496
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.326611407738925,
            16.433390125282408
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.317899592858554,
            16.43639494418805
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.306183703881503,
            16.437753271723988
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.30202091549039,
            16.435036607152174
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.33124626491666,
            16.44664390822575
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.32946527813077,
            16.447261298418713
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.331653960686923,
            16.445635500020483
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.3307312807858,
            16.444709406237507
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.323671706658603,
            16.446479270509272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.32223404262662,
            16.444174327815688
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.333842643243075,
            16.444894625347565
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.343613129225869,
            16.46920011576818
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.345361929503579,
            16.46745103630741
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.344900589553017,
            16.46875770304294
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.344181757537026,
            16.467543635027496
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.365316973128328,
            16.500298572368727
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.36378274957181,
            16.499290443362625
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.365810499587068,
            16.499671064114956
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.366196737685213,
            16.500576321273712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.364469395079622,
            16.50032943337786
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.364909277358064,
            16.49976364742797
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.365198955931673,
            16.499979674985976
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.364480123915682,
            16.49903326675462
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.364308462538729,
            16.499979674985976
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.364877090849886,
            16.501039235229044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.366239653029451,
            16.500308859372314
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.365692482390413,
            16.49903326675462
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.363718376555452,
            16.499084702103573
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.38508926469413,
            16.505015266411323
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.383286820236123,
            16.50460379585432
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.382739649597085,
            16.504675803265005
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.385378943267739,
            16.5038734334593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.38559351998893,
            16.503482534142766
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.38358722764579,
            16.503986588377135
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.386237250152504,
            16.50549874319697
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.386816607299721,
            16.50566333076309
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.384906874481118,
            16.504737523881396
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.385947571578896,
            16.50483010476904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.38633380967704,
            16.50516956764447
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.384703026595986,
            16.50530329528026
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.384306059661782,
            16.504254045192457
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.384874687972939,
            16.50420261121824
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.407804406136378,
            16.500270910052496
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.406989014595851,
            16.50037378007852
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.406549132317409,
            16.49883072394369
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.407804406136378,
            16.49936565146439
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.405883944481715,
            16.500291484062075
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.404564297646388,
            16.500744111719204
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.405808842629298,
            16.49951995720508
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.406431115120753,
            16.499952012624124
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.40725723549734,
            16.499756559101712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.40702120110403,
            16.498552972532188
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.405959046334132,
            16.498563259628625
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.330776034645037,
            16.4734892625419
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.332406817726092,
            16.474044836887717
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.329070149711566,
            16.472388397558454
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.33345824365993,
            16.474353488613684
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.340721482048822,
            16.47409813214424
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.339219445000483,
            16.475404754059532
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.339369648705317,
            16.47480803018359
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.337374085198237,
            16.47484918361335
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.337009304772211,
            16.475867728214304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.341354483376337,
            16.473563134801626
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.340131396065546,
            16.474026113357244
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.642613496039209,
            16.522553833677755
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.643729294989404,
            16.523068123966617
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.64157279894143,
            16.521607535968304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.638987149451074,
            16.521926397670896
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.639695252631006,
            16.52078466462649
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.63810738489419,
            16.52113438537507
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.638751115057763,
            16.52142239022203
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.639866914007959,
            16.521874968399636
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.638439978812036,
            16.523098981340404
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.639555777762231,
            16.52288297962037
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.64058574602395,
            16.521802967396855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.643375243399438,
            16.522543547857996
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.64132603571206,
            16.52257440531559
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.688622514917075,
            16.527293541555256
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.687174122049033,
            16.527180400284774
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.684663574411093,
            16.527211257001483
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.689802686883628,
            16.526892404024412
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.688933651162802,
            16.525894699372362
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.691047231866538,
            16.52599755576038
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.69248489589852,
            16.527200971429792
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.692452709390341,
            16.525863842445265
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.68673423977059,
            16.526151840239674
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.684137861444174,
            16.525678700779196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.682539264871298,
            16.525565558562548
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.691154520227133,
            16.52555527290319
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.693085710717856,
            16.525287845567895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.681835120207221,
            16.524189290517832
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.782683758943742,
            16.540688620202044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.766032605379289,
            16.542745579878783
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.781911282747453,
            16.5380556798136
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.79495754739589,
            16.536656915618767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.785516171663469,
            16.531637737109858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.908097145900431,
            16.183608226934613
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.909073469981852,
            16.18320638263745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.906412718639078,
            16.184195536359155
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.905833361491862,
            16.1838246042943
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.904942868098917,
            16.18790649580447
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.903172610149088,
            16.18744283933114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.904846308574381,
            16.186360969991046
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.90237867628068,
            16.186670076121867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.903204796657267,
            16.18612398829626
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.982112959450465,
            16.2239866810855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.98048217636941,
            16.222977123705903
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.97799308640359,
            16.224790202647455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.979559496468287,
            16.226500250440743
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.981919840401392,
            16.225758544788118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.978829935616236,
            16.225408293925305
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.979023054665308,
            16.222853504079232
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 2
      },
      "color": "#42ff31",
      "mode": "FeatureCollection",
      "shown": true,
      "locked": true
    }) || 
    /* color: #42ff31 */
    /* locked: true */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-14.924271934274186, 16.59638491854199]),
            {
              "landuse": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.92240511679982, 16.597392540059484]),
            {
              "landuse": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.921890132668961, 16.59640548229923]),
            {
              "landuse": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.92167555594777, 16.595562366448974]),
            {
              "landuse": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.924207561257829, 16.59393781572618]),
            {
              "landuse": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.921804301980485, 16.593444278610843]),
            {
              "landuse": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.919229381326188, 16.593649919229527]),
            {
              "landuse": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.918113582375993, 16.594287403749703]),
            {
              "landuse": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.917147987130631, 16.59591195151854]),
            {
              "landuse": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.914894931558122, 16.594349095687885]),
            {
              "landuse": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.913907878640641, 16.594493043466635]),
            {
              "landuse": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.913822047952165, 16.593300330046915]),
            {
              "landuse": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.92517315650319, 16.592580585610758]),
            {
              "landuse": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.863904298839278, 16.58415105767582]),
            {
              "landuse": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.860041917857833, 16.58213567060164]),
            {
              "landuse": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.865577997264571, 16.57633617370756]),
            {
              "landuse": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.864290536937423, 16.581271926821813]),
            {
              "landuse": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.858754457530685, 16.578639540913475]),
            {
              "landuse": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.861286462840743, 16.57654183261451]),
            {
              "landuse": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.859008940837771, 16.572686374727986]),
            {
              "landuse": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.856348189494998, 16.569560273027697]),
            {
              "landuse": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.851026686809451, 16.574413935471277]),
            {
              "landuse": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.85677734293738, 16.56836740505409]),
            {
              "landuse": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.853472861431033, 16.56606391495429]),
            {
              "landuse": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.850855025432498, 16.564912159573538]),
            {
              "landuse": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.857378157756717, 16.565652574537467]),
            {
              "landuse": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.813227719646399, 16.556667146274435]),
            {
              "landuse": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.808549947124426, 16.55576215206223]),
            {
              "landuse": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.813141888957922, 16.551442802968804]),
            {
              "landuse": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.818592137676184, 16.555638743431327]),
            {
              "landuse": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.816403455120032, 16.553787604485958]),
            {
              "landuse": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.825528089438578, 16.538211140932084]),
            {
              "landuse": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.821601335440775, 16.538766529337916]),
            {
              "landuse": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.81846851531138, 16.538910518663656]),
            {
              "landuse": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.81424135390391, 16.53726491996628]),
            {
              "landuse": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.81696647826304, 16.538170000986575]),
            {
              "landuse": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.816151086722513, 16.538252280868814]),
            {
              "landuse": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.82546371642222, 16.536915228435113]),
            {
              "landuse": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.828403417502543, 16.53806715108443]),
            {
              "landuse": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.757636818730822, 16.53338220307571]),
            {
              "landuse": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.763773712956896, 16.53576836461749]),
            {
              "landuse": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.764889511907091, 16.53190112245344]),
            {
              "landuse": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.774631295049181, 16.53029660562209]),
            {
              "landuse": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.775875840032091, 16.533546766887778]),
            {
              "landuse": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.768193993413439, 16.5289389271179]),
            {
              "landuse": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.764074120366564, 16.53066687992071]),
            {
              "landuse": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.759696755254259, 16.53301193398557]),
            {
              "landuse": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.506080901390753, 16.509502797288132]),
            {
              "landuse": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.505624925858221, 16.509510512173637]),
            {
              "landuse": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.505018746620856, 16.509587661011803]),
            {
              "landuse": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.504696881539068, 16.509572231246644]),
            {
              "landuse": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.504632508522711, 16.50925592078924]),
            {
              "landuse": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.505472039944372, 16.50918391508435]),
            {
              "landuse": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.506711220509253, 16.509286780368853]),
            {
              "landuse": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.506123816734991, 16.509165913653934]),
            {
              "landuse": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.502070998913489, 16.51167323960298]),
            {
              "landuse": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.501191234356604, 16.510315430203292]),
            {
              "landuse": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.330566356850351, 16.440919225393063]),
            {
              "landuse": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.318206737709726, 16.442936085564416]),
            {
              "landuse": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.315503071022714, 16.443388847212972]),
            {
              "landuse": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.313013981056894, 16.44215404022983]),
            {
              "landuse": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.31112570591041, 16.438490733305308]),
            {
              "landuse": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.318035076332773, 16.43766750875586]),
            {
              "landuse": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.326317737770761, 16.434292251620445]),
            {
              "landuse": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.33082384891578, 16.434827357273765]),
            {
              "landuse": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.302757213783945, 16.438120282689916]),
            {
              "landuse": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.298208187294687, 16.43762634743678]),
            {
              "landuse": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.140205924638408, 16.301644504583464]),
            {
              "landuse": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.140715544351238, 16.30152608321495]),
            {
              "landuse": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.139830415376323, 16.3012223063336]),
            {
              "landuse": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.141638224252361, 16.30180411587996]),
            {
              "landuse": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.142571839747415, 16.299015800180804]),
            {
              "landuse": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.140007647929178, 16.299458598430572]),
            {
              "landuse": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.140876683650003, 16.29874806121877]),
            {
              "landuse": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.148077467061006, 16.299914498984815]),
            {
              "landuse": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.147621491528474, 16.299515466651332]),
            {
              "landuse": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.148788252449952, 16.299412490433358]),
            {
              "landuse": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.148487845040284, 16.29937129993101]),
            {
              "landuse": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.147648313618623, 16.29999173095549]),
            {
              "landuse": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.844141254437353, 16.088774661753437]),
            {
              "landuse": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.840557823193457, 16.090465269017876]),
            {
              "landuse": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.845021018994238, 16.087640709794858]),
            {
              "landuse": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.333177455407382, 16.442569083701002]),
            {
              "landuse": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.325624354821445, 16.438658818136517]),
            {
              "landuse": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.321161159020663, 16.439852486501163]),
            {
              "landuse": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.323349841576816, 16.435324740044496]),
            {
              "landuse": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.326611407738925, 16.433390125282408]),
            {
              "landuse": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.317899592858554, 16.43639494418805]),
            {
              "landuse": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.306183703881503, 16.437753271723988]),
            {
              "landuse": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.30202091549039, 16.435036607152174]),
            {
              "landuse": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.33124626491666, 16.44664390822575]),
            {
              "landuse": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.32946527813077, 16.447261298418713]),
            {
              "landuse": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.331653960686923, 16.445635500020483]),
            {
              "landuse": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.3307312807858, 16.444709406237507]),
            {
              "landuse": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.323671706658603, 16.446479270509272]),
            {
              "landuse": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.32223404262662, 16.444174327815688]),
            {
              "landuse": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.333842643243075, 16.444894625347565]),
            {
              "landuse": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.343613129225869, 16.46920011576818]),
            {
              "landuse": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.345361929503579, 16.46745103630741]),
            {
              "landuse": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.344900589553017, 16.46875770304294]),
            {
              "landuse": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.344181757537026, 16.467543635027496]),
            {
              "landuse": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.365316973128328, 16.500298572368727]),
            {
              "landuse": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.36378274957181, 16.499290443362625]),
            {
              "landuse": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.365810499587068, 16.499671064114956]),
            {
              "landuse": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.366196737685213, 16.500576321273712]),
            {
              "landuse": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.364469395079622, 16.50032943337786]),
            {
              "landuse": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.364909277358064, 16.49976364742797]),
            {
              "landuse": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.365198955931673, 16.499979674985976]),
            {
              "landuse": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.364480123915682, 16.49903326675462]),
            {
              "landuse": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.364308462538729, 16.499979674985976]),
            {
              "landuse": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.364877090849886, 16.501039235229044]),
            {
              "landuse": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.366239653029451, 16.500308859372314]),
            {
              "landuse": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.365692482390413, 16.49903326675462]),
            {
              "landuse": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.363718376555452, 16.499084702103573]),
            {
              "landuse": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.38508926469413, 16.505015266411323]),
            {
              "landuse": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.383286820236123, 16.50460379585432]),
            {
              "landuse": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.382739649597085, 16.504675803265005]),
            {
              "landuse": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.385378943267739, 16.5038734334593]),
            {
              "landuse": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.38559351998893, 16.503482534142766]),
            {
              "landuse": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.38358722764579, 16.503986588377135]),
            {
              "landuse": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.386237250152504, 16.50549874319697]),
            {
              "landuse": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.386816607299721, 16.50566333076309]),
            {
              "landuse": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.384906874481118, 16.504737523881396]),
            {
              "landuse": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.385947571578896, 16.50483010476904]),
            {
              "landuse": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.38633380967704, 16.50516956764447]),
            {
              "landuse": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.384703026595986, 16.50530329528026]),
            {
              "landuse": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.384306059661782, 16.504254045192457]),
            {
              "landuse": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.384874687972939, 16.50420261121824]),
            {
              "landuse": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.407804406136378, 16.500270910052496]),
            {
              "landuse": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.406989014595851, 16.50037378007852]),
            {
              "landuse": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.406549132317409, 16.49883072394369]),
            {
              "landuse": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.407804406136378, 16.49936565146439]),
            {
              "landuse": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.405883944481715, 16.500291484062075]),
            {
              "landuse": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.404564297646388, 16.500744111719204]),
            {
              "landuse": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.405808842629298, 16.49951995720508]),
            {
              "landuse": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.406431115120753, 16.499952012624124]),
            {
              "landuse": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.40725723549734, 16.499756559101712]),
            {
              "landuse": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.40702120110403, 16.498552972532188]),
            {
              "landuse": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.405959046334132, 16.498563259628625]),
            {
              "landuse": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.330776034645037, 16.4734892625419]),
            {
              "landuse": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.332406817726092, 16.474044836887717]),
            {
              "landuse": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.329070149711566, 16.472388397558454]),
            {
              "landuse": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.33345824365993, 16.474353488613684]),
            {
              "landuse": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.340721482048822, 16.47409813214424]),
            {
              "landuse": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.339219445000483, 16.475404754059532]),
            {
              "landuse": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.339369648705317, 16.47480803018359]),
            {
              "landuse": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.337374085198237, 16.47484918361335]),
            {
              "landuse": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.337009304772211, 16.475867728214304]),
            {
              "landuse": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.341354483376337, 16.473563134801626]),
            {
              "landuse": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.340131396065546, 16.474026113357244]),
            {
              "landuse": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.642613496039209, 16.522553833677755]),
            {
              "landuse": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.643729294989404, 16.523068123966617]),
            {
              "landuse": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.64157279894143, 16.521607535968304]),
            {
              "landuse": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.638987149451074, 16.521926397670896]),
            {
              "landuse": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.639695252631006, 16.52078466462649]),
            {
              "landuse": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.63810738489419, 16.52113438537507]),
            {
              "landuse": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.638751115057763, 16.52142239022203]),
            {
              "landuse": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.639866914007959, 16.521874968399636]),
            {
              "landuse": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.638439978812036, 16.523098981340404]),
            {
              "landuse": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.639555777762231, 16.52288297962037]),
            {
              "landuse": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.64058574602395, 16.521802967396855]),
            {
              "landuse": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.643375243399438, 16.522543547857996]),
            {
              "landuse": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.64132603571206, 16.52257440531559]),
            {
              "landuse": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.688622514917075, 16.527293541555256]),
            {
              "landuse": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.687174122049033, 16.527180400284774]),
            {
              "landuse": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.684663574411093, 16.527211257001483]),
            {
              "landuse": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.689802686883628, 16.526892404024412]),
            {
              "landuse": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.688933651162802, 16.525894699372362]),
            {
              "landuse": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.691047231866538, 16.52599755576038]),
            {
              "landuse": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.69248489589852, 16.527200971429792]),
            {
              "landuse": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.692452709390341, 16.525863842445265]),
            {
              "landuse": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.68673423977059, 16.526151840239674]),
            {
              "landuse": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.684137861444174, 16.525678700779196]),
            {
              "landuse": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.682539264871298, 16.525565558562548]),
            {
              "landuse": 2,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.691154520227133, 16.52555527290319]),
            {
              "landuse": 2,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.693085710717856, 16.525287845567895]),
            {
              "landuse": 2,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.681835120207221, 16.524189290517832]),
            {
              "landuse": 2,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.782683758943742, 16.540688620202044]),
            {
              "landuse": 2,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.766032605379289, 16.542745579878783]),
            {
              "landuse": 2,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.781911282747453, 16.5380556798136]),
            {
              "landuse": 2,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.79495754739589, 16.536656915618767]),
            {
              "landuse": 2,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.785516171663469, 16.531637737109858]),
            {
              "landuse": 2,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.908097145900431, 16.183608226934613]),
            {
              "landuse": 2,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.909073469981852, 16.18320638263745]),
            {
              "landuse": 2,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.906412718639078, 16.184195536359155]),
            {
              "landuse": 2,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.905833361491862, 16.1838246042943]),
            {
              "landuse": 2,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.904942868098917, 16.18790649580447]),
            {
              "landuse": 2,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.903172610149088, 16.18744283933114]),
            {
              "landuse": 2,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.904846308574381, 16.186360969991046]),
            {
              "landuse": 2,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.90237867628068, 16.186670076121867]),
            {
              "landuse": 2,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.903204796657267, 16.18612398829626]),
            {
              "landuse": 2,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.982112959450465, 16.2239866810855]),
            {
              "landuse": 2,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.98048217636941, 16.222977123705903]),
            {
              "landuse": 2,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.97799308640359, 16.224790202647455]),
            {
              "landuse": 2,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.979559496468287, 16.226500250440743]),
            {
              "landuse": 2,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.981919840401392, 16.225758544788118]),
            {
              "landuse": 2,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.978829935616236, 16.225408293925305]),
            {
              "landuse": 2,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.979023054665308, 16.222853504079232]),
            {
              "landuse": 2,
              "system:index": "197"
            })]),
    Bareland = ui.import && ui.import("Bareland", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -14.162905397784217,
            16.303616024510312
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.161145868670447,
            16.303780782898027
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.16209000624369,
            16.303059963928686
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.161896887194617,
            16.30281797410858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.161693039309485,
            16.303538793968364
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.172265235884632,
            16.309269274343222
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.171506170733418,
            16.30966313826452
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.170899991496052,
            16.309269274343222
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.17269707153603,
            16.30924353157568
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.172530774577107,
            16.309583335834663
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.168732033128386,
            16.308175172923107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.164472685212736,
            16.308463493299193
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.162680969590788,
            16.308617950468914
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.167702064866667,
            16.30708367051125
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.169257746095305,
            16.30677475362982
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.294675791265105,
            16.292524633867576
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.238199198247527,
            16.276541507616415
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.212793314458464,
            16.285274717391836
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.257940256597136,
            16.273740207047872
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.298624002935027,
            16.267807909161387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.305318796636199,
            16.285439491197586
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.511655771733855,
            16.353643939642698
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.854165985001853,
            16.133190094317996
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.503976776017478,
            16.17144344513274
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.972269012345603,
            16.05798095365432
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.798848469501658,
            16.389698076620416
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.811208088642283,
            16.340944965433767
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.418446858173533,
            16.301406483092418
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.911458332782908,
            16.321176722952977
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.664327086892174,
            16.30322234208775
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.473439635720299,
            16.252470068706398
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.659520568337486,
            16.370432379987435
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.792729796853111,
            16.231374356769887
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.365636290993736,
            16.217529066651956
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.064440921656692,
            16.56249532968169
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.15713806521138,
            16.55920452079533
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.898272708766067,
            16.55130635018884
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.86325378786763,
            16.555913655708455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.25326843630513,
            16.490742968994926
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.142031864039504,
            16.482841998593532
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.861880496852004,
            16.47954983243494
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.336201752128357,
            15.846984233293012
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.161793793143982,
            15.754486208033622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.474904144706482,
            15.856231709204245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.224965179862732,
            15.960566639586455
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.996998871268982,
            15.997533089245346
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.620663613455621,
            16.097685663202007
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.693448037283746,
            16.019823181993537
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.088955849783746,
            16.133307473429532
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.149380654471246,
            16.226949041299356
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.288083047049371,
            16.176836541908017
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.631649941580621,
            16.26913915081442
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.243008584158746,
            16.139903402435444
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.126278847830621,
            16.109560310845602
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.487454384939996,
            16.071295015039823
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.150426268577508,
            15.8019612948876
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.149739623069696,
            15.79964884476272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.154503226280145,
            15.80322074322051
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.176293087231349,
            15.81222594643126
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.172945690380763,
            15.808881313596533
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.151101780163478,
            15.816520208751001
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.1495568277709,
            15.81239111205225
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.148011875378321,
            15.819575686040423
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.388608908861325,
            15.967359239978908
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.383555627077268,
            15.967348925076449
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.382654404848264,
            15.96724577602263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.3917202713186,
            15.968844580385896
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.388887858598874,
            15.967039477755566
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.384950375765012,
            15.967194201475783
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.38850162050073,
            15.968854895211308
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.383909678667234,
            15.970783758222662
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.431672118653609,
            15.974989325724783
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.422445319642378,
            15.976969701667306
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.441413901795698,
            15.978475599423135
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.283575728450538,
            15.66591497659076
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.281226113353492,
            15.666359178458057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.285067036662818,
            15.666751728141527
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.297061875377418,
            15.664014194901604
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.292427018199684,
            15.664262123950847
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.315129235301734,
            15.666534792883368
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.901621695455876,
            16.187237866429445
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.901374932226506,
            16.1869184576714
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.900918956693975,
            16.186480557727563
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.90128373712,
            16.18652692364995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.901691432890264,
            16.1870730103608
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.096075204621245,
            16.18894178050641
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.094433692704131,
            16.190858205653758
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.092234281311919,
            16.190950935430774
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.08872595192044,
            16.19011636586896
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.08871522308438,
            16.18894178050641
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.097491410981108,
            16.1901266692184
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.099411872635772,
            16.188859353200918
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.094101098786284,
            16.189250882595395
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.11417475105374,
            16.187416869782165
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.103540730644381,
            16.193020791243526
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.106635999847567,
            16.19324230987734
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.102725339103854,
            16.193716255886486
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.314348709167769,
            16.52455063737487
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.314783227028181,
            16.524278065784618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.313141715111067,
            16.524442637356834
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.315748822273543,
            16.524247208599213
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.318087708534529,
            16.524303780102034
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.316258441986372,
            16.524771780080524
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.315502059044173,
            16.52496206546176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.315453779281905,
            16.524458065934535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.316510569633772,
            16.525193493375433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.317207943977644,
            16.52455578023137
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.984044149941187,
            16.226129397963703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.987927988594752,
            16.225531911948035
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.990159586495142,
            16.22485201186255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.98496682984231,
            16.223615823874045
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.97649104935525,
            16.222812297519766
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.985159948891383,
            16.225717338836596
          ]
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -14.534618054865257,
                16.569868244963647
              ],
              [
                -14.536334668634789,
                16.56945691267215
              ],
              [
                -14.537965451715843,
                16.569168979545328
              ],
              [
                -14.533330594538109,
                16.5666186959152
              ],
              [
                -14.529124890802757,
                16.562957745869358
              ],
              [
                -14.524962102411644,
                16.5622173205476
              ],
              [
                -14.52307382726516,
                16.564232916141567
              ],
              [
                -14.521958028314964,
                16.56192937659843
              ],
              [
                -14.52182928228225,
                16.566536428139063
              ],
              [
                -14.527451192377464,
                16.567605906487824
              ],
              [
                -14.5335451712593,
                16.56879877917823
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -14.213783099179889,
                16.48970971445573
              ],
              [
                -14.211690976148272,
                16.489370224452056
              ],
              [
                -14.208461596494342,
                16.490090354054797
              ],
              [
                -14.210821940427447,
                16.492230151921973
              ],
              [
                -14.213396861081744,
                16.49053271805374
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 3
      },
      "color": "#fdffef",
      "mode": "FeatureCollection",
      "shown": true,
      "locked": true
    }) || 
    /* color: #fdffef */
    /* locked: true */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-14.162905397784217, 16.303616024510312]),
            {
              "landuse": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.161145868670447, 16.303780782898027]),
            {
              "landuse": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.16209000624369, 16.303059963928686]),
            {
              "landuse": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.161896887194617, 16.30281797410858]),
            {
              "landuse": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.161693039309485, 16.303538793968364]),
            {
              "landuse": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.172265235884632, 16.309269274343222]),
            {
              "landuse": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.171506170733418, 16.30966313826452]),
            {
              "landuse": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.170899991496052, 16.309269274343222]),
            {
              "landuse": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.17269707153603, 16.30924353157568]),
            {
              "landuse": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.172530774577107, 16.309583335834663]),
            {
              "landuse": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.168732033128386, 16.308175172923107]),
            {
              "landuse": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.164472685212736, 16.308463493299193]),
            {
              "landuse": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.162680969590788, 16.308617950468914]),
            {
              "landuse": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.167702064866667, 16.30708367051125]),
            {
              "landuse": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.169257746095305, 16.30677475362982]),
            {
              "landuse": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.294675791265105, 16.292524633867576]),
            {
              "landuse": 3,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.238199198247527, 16.276541507616415]),
            {
              "landuse": 3,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.212793314458464, 16.285274717391836]),
            {
              "landuse": 3,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.257940256597136, 16.273740207047872]),
            {
              "landuse": 3,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.298624002935027, 16.267807909161387]),
            {
              "landuse": 3,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.305318796636199, 16.285439491197586]),
            {
              "landuse": 3,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.511655771733855, 16.353643939642698]),
            {
              "landuse": 3,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.854165985001853, 16.133190094317996]),
            {
              "landuse": 3,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.503976776017478, 16.17144344513274]),
            {
              "landuse": 3,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.972269012345603, 16.05798095365432]),
            {
              "landuse": 3,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.798848469501658, 16.389698076620416]),
            {
              "landuse": 3,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.811208088642283, 16.340944965433767]),
            {
              "landuse": 3,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.418446858173533, 16.301406483092418]),
            {
              "landuse": 3,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.911458332782908, 16.321176722952977]),
            {
              "landuse": 3,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.664327086892174, 16.30322234208775]),
            {
              "landuse": 3,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.473439635720299, 16.252470068706398]),
            {
              "landuse": 3,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.659520568337486, 16.370432379987435]),
            {
              "landuse": 3,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.792729796853111, 16.231374356769887]),
            {
              "landuse": 3,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.365636290993736, 16.217529066651956]),
            {
              "landuse": 3,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.064440921656692, 16.56249532968169]),
            {
              "landuse": 3,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.15713806521138, 16.55920452079533]),
            {
              "landuse": 3,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.898272708766067, 16.55130635018884]),
            {
              "landuse": 3,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.86325378786763, 16.555913655708455]),
            {
              "landuse": 3,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.25326843630513, 16.490742968994926]),
            {
              "landuse": 3,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.142031864039504, 16.482841998593532]),
            {
              "landuse": 3,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.861880496852004, 16.47954983243494]),
            {
              "landuse": 3,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.336201752128357, 15.846984233293012]),
            {
              "landuse": 3,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.161793793143982, 15.754486208033622]),
            {
              "landuse": 3,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.474904144706482, 15.856231709204245]),
            {
              "landuse": 3,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.224965179862732, 15.960566639586455]),
            {
              "landuse": 3,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.996998871268982, 15.997533089245346]),
            {
              "landuse": 3,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.620663613455621, 16.097685663202007]),
            {
              "landuse": 3,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.693448037283746, 16.019823181993537]),
            {
              "landuse": 3,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.088955849783746, 16.133307473429532]),
            {
              "landuse": 3,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.149380654471246, 16.226949041299356]),
            {
              "landuse": 3,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.288083047049371, 16.176836541908017]),
            {
              "landuse": 3,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.631649941580621, 16.26913915081442]),
            {
              "landuse": 3,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.243008584158746, 16.139903402435444]),
            {
              "landuse": 3,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.126278847830621, 16.109560310845602]),
            {
              "landuse": 3,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.487454384939996, 16.071295015039823]),
            {
              "landuse": 3,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.150426268577508, 15.8019612948876]),
            {
              "landuse": 3,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.149739623069696, 15.79964884476272]),
            {
              "landuse": 3,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.154503226280145, 15.80322074322051]),
            {
              "landuse": 3,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.176293087231349, 15.81222594643126]),
            {
              "landuse": 3,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.172945690380763, 15.808881313596533]),
            {
              "landuse": 3,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.151101780163478, 15.816520208751001]),
            {
              "landuse": 3,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.1495568277709, 15.81239111205225]),
            {
              "landuse": 3,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.148011875378321, 15.819575686040423]),
            {
              "landuse": 3,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.388608908861325, 15.967359239978908]),
            {
              "landuse": 3,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.383555627077268, 15.967348925076449]),
            {
              "landuse": 3,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.382654404848264, 15.96724577602263]),
            {
              "landuse": 3,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.3917202713186, 15.968844580385896]),
            {
              "landuse": 3,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.388887858598874, 15.967039477755566]),
            {
              "landuse": 3,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.384950375765012, 15.967194201475783]),
            {
              "landuse": 3,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.38850162050073, 15.968854895211308]),
            {
              "landuse": 3,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.383909678667234, 15.970783758222662]),
            {
              "landuse": 3,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.431672118653609, 15.974989325724783]),
            {
              "landuse": 3,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.422445319642378, 15.976969701667306]),
            {
              "landuse": 3,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.441413901795698, 15.978475599423135]),
            {
              "landuse": 3,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.283575728450538, 15.66591497659076]),
            {
              "landuse": 3,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.281226113353492, 15.666359178458057]),
            {
              "landuse": 3,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.285067036662818, 15.666751728141527]),
            {
              "landuse": 3,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.297061875377418, 15.664014194901604]),
            {
              "landuse": 3,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.292427018199684, 15.664262123950847]),
            {
              "landuse": 3,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.315129235301734, 15.666534792883368]),
            {
              "landuse": 3,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.901621695455876, 16.187237866429445]),
            {
              "landuse": 3,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.901374932226506, 16.1869184576714]),
            {
              "landuse": 3,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.900918956693975, 16.186480557727563]),
            {
              "landuse": 3,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.90128373712, 16.18652692364995]),
            {
              "landuse": 3,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.901691432890264, 16.1870730103608]),
            {
              "landuse": 3,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.096075204621245, 16.18894178050641]),
            {
              "landuse": 3,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.094433692704131, 16.190858205653758]),
            {
              "landuse": 3,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.092234281311919, 16.190950935430774]),
            {
              "landuse": 3,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.08872595192044, 16.19011636586896]),
            {
              "landuse": 3,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.08871522308438, 16.18894178050641]),
            {
              "landuse": 3,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.097491410981108, 16.1901266692184]),
            {
              "landuse": 3,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.099411872635772, 16.188859353200918]),
            {
              "landuse": 3,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.094101098786284, 16.189250882595395]),
            {
              "landuse": 3,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.11417475105374, 16.187416869782165]),
            {
              "landuse": 3,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.103540730644381, 16.193020791243526]),
            {
              "landuse": 3,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.106635999847567, 16.19324230987734]),
            {
              "landuse": 3,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.102725339103854, 16.193716255886486]),
            {
              "landuse": 3,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.314348709167769, 16.52455063737487]),
            {
              "landuse": 3,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.314783227028181, 16.524278065784618]),
            {
              "landuse": 3,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.313141715111067, 16.524442637356834]),
            {
              "landuse": 3,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.315748822273543, 16.524247208599213]),
            {
              "landuse": 3,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.318087708534529, 16.524303780102034]),
            {
              "landuse": 3,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.316258441986372, 16.524771780080524]),
            {
              "landuse": 3,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.315502059044173, 16.52496206546176]),
            {
              "landuse": 3,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.315453779281905, 16.524458065934535]),
            {
              "landuse": 3,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.316510569633772, 16.525193493375433]),
            {
              "landuse": 3,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.317207943977644, 16.52455578023137]),
            {
              "landuse": 3,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.984044149941187, 16.226129397963703]),
            {
              "landuse": 3,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.987927988594752, 16.225531911948035]),
            {
              "landuse": 3,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.990159586495142, 16.22485201186255]),
            {
              "landuse": 3,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.98496682984231, 16.223615823874045]),
            {
              "landuse": 3,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.97649104935525, 16.222812297519766]),
            {
              "landuse": 3,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.985159948891383, 16.225717338836596]),
            {
              "landuse": 3,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Polygon(
                [[[-14.534618054865257, 16.569868244963647],
                  [-14.536334668634789, 16.56945691267215],
                  [-14.537965451715843, 16.569168979545328],
                  [-14.533330594538109, 16.5666186959152],
                  [-14.529124890802757, 16.562957745869358],
                  [-14.524962102411644, 16.5622173205476],
                  [-14.52307382726516, 16.564232916141567],
                  [-14.521958028314964, 16.56192937659843],
                  [-14.52182928228225, 16.566536428139063],
                  [-14.527451192377464, 16.567605906487824],
                  [-14.5335451712593, 16.56879877917823]]]),
            {
              "landuse": 3,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Polygon(
                [[[-14.213783099179889, 16.48970971445573],
                  [-14.211690976148272, 16.489370224452056],
                  [-14.208461596494342, 16.490090354054797],
                  [-14.210821940427447, 16.492230151921973],
                  [-14.213396861081744, 16.49053271805374]]]),
            {
              "landuse": 3,
              "system:index": "114"
            })]),
    Vegetation = ui.import && ui.import("Vegetation", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            -13.790350584061613,
            16.105505874264118
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.787582544358244,
            16.105588336295593
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.78917041209506,
            16.105650182796722
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.790028718979826,
            16.10847448580727
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.788891462357512,
            16.10789725926356
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.795350221665373,
            16.107464338253685
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.793311742814055,
            16.108556946604985
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.779857782395354,
            16.106887108771122
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.78045859721469,
            16.105938799547083
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.784750131638518,
            16.113009778780956
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.782046464951506,
            16.113009778780956
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.817874254660076,
            16.105944803948255
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.815449537710613,
            16.10485218121286
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.81675845570988,
            16.10495525908641
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.815192045645183,
            16.103945093616858
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.819612326101726,
            16.10947001741231
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.816222013906902,
            16.108810333106966
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.812102140860027,
            16.11140782737262
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.810128035025066,
            16.11250041400441
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.821071447805828,
            16.110995528966413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -13.81802445836491,
            16.10905771497853
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.247284130857292,
            16.37720723130196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.245803551481071,
            16.37483970581218
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.239666657254997,
            16.378154233448086
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.237885670469108,
            16.375786719457857
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.251468376920524,
            16.376548444487252
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.252240853116813,
            16.374592658017747
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.196054801332227,
            16.3755275584068
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.195153579103224,
            16.373839398195116
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.194702967988722,
            16.375733430603464
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.194338187562696,
            16.37727746514953
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.196526870118849,
            16.377112768713875
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.21865251402583,
            16.390329215149386
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.219274786517285,
            16.38993808708353
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.217601088091993,
            16.38905289961365
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.223180082842969,
            16.389649886953546
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.229746130511426,
            16.39529029771666
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.229059485003614,
            16.393931673562204
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.217343596026563,
            16.39384933239972
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.23264291624751,
            16.3951873719762
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.229520824954175,
            16.39452864594899
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.22789004187312,
            16.394312500985794
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.231033590838575,
            16.39513590908555
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.254903414015251,
            16.395151044434726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.25416312432714,
            16.394327636398952
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.253787615065056,
            16.39415266174284
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.250397302870232,
            16.39558333225976
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.251255609754997,
            16.395748013083548
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.250472404722649,
            16.394986363106096
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.255053617720085,
            16.39464670742598
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.249581911329704,
            16.39388505314117
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.252028085951286,
            16.39417324700466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.255654432539421,
            16.395645087585013
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.255076503068961,
            16.39781680406758
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.254089450151481,
            16.39727130410111
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.254904841692008,
            16.39661258512349
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.265457475675948,
            16.401316708044636
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.290523929278454,
            16.401263115068325
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.289729995410045,
            16.40006920975985
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.29261605231007,
            16.400275056025095
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.290824336688122,
            16.40050148666546
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.28486983267506,
            16.400892593514826
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.09126994455727,
            16.54122145939528
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.088180039772114,
            16.54393663403643
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.080884431251606,
            16.538670805982107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.048011277565083,
            16.544594852436234
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.045865510353169,
            16.54953141882963
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.054105256446919,
            16.543442968762527
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.050929520973286,
            16.541961965360258
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.051701997169575,
            16.538177127233176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.044234727272114,
            16.542702468482712
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.047667954811176,
            16.539164483467914
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.087836717018208,
            16.53883536528439
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.092385743507466,
            16.538177127233176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.085605119117817,
            16.538094847318884
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.07006976450356,
            16.536860644394352
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.032493001951718,
            16.51488915946469
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.026871091856503,
            16.514632003604827
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.029113418592953,
            16.513788529982502
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.033158189787411,
            16.513829675122658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.027128583921932,
            16.515804631548153
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.025015003218197,
            16.514385133657406
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.027729398741268,
            16.513829675122658
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.03117335511639,
            16.513582804150307
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.029349452986263,
            16.515928065654556
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.030379421247982,
            16.514961163044116
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.029966361059689,
            16.514215410385624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.031039244665646,
            16.514529141165063
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.028507239355587,
            16.515053739035412
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.031123309697701,
            16.508359570036
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.028033404912545,
            16.511198643901867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.013141780461861,
            16.51189811946642
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.0186778598686,
            16.509511663008702
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.029363780583932,
            16.506796004305613
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.022540240850045,
            16.507042883945825
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.01391425665815,
            16.51004656098347
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.01168265875776,
            16.51198041054289
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.012841373052193,
            16.508565301427545
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.014772563542916,
            16.50700173736101
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.02666011389692,
            16.50564389514989
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.024514346685006,
            16.50560274826736
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.027604251470162,
            16.510087706920217
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.03417029913862,
            16.509511663008702
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.032496600713326,
            16.507948106596107
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.342640288811923,
            16.446294052911313
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.34397066448331,
            16.44666448793048
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.339443095666171,
            16.443454027611097
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.338520415765048,
            16.442939525828663
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.087871161580274,
            15.80241482992418
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.087356177449415,
            15.802063835516726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.083601084828565,
            15.803023907010498
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.09024223434944,
            15.802125775750508
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.09122928726692,
            15.803467809495228
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.088332501530836,
            15.801351521466335
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.083096829533766,
            15.801929631611879
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.0867231761219,
            15.801320551233383
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.090406564126484,
            15.779572661486494
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.084205296884052,
            15.780543164038745
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.07476392115163,
            15.780150833779146
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.071309235940449,
            15.779345521920453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.089677003274433,
            15.777982679180706
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.091114667306416,
            15.7821537750431
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.093281892190449,
            15.778230469451064
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.073304799447529,
            15.778085925163495
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.078583386788837,
            15.782071179918248
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.083239701638691,
            15.778560856007187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.160200238227777,
            15.799566256769792
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.159760355949334,
            15.79863713952834
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.15861237049096,
            15.80030954749339
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.154749989509515,
            15.799039757523065
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.161037087440423,
            15.798936522216126
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.159717440605096,
            15.798069343559913
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.158065199851922,
            15.799597227271082
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.14340960979455,
            15.802126468885863
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.144289374351434,
            15.799793373669266
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.16204519294424,
            15.816231174725646
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.162817669140528,
            15.812597568888867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.161058140026759,
            15.809129066072817
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.170671177136134,
            15.81565310543584
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.41886053480824,
            15.500720314629806
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.417036632678114,
            15.499210873937939
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.420748809954725,
            15.499727806923381
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.418334821841322,
            15.500017288830286
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.418055872103773,
            15.498456149456624
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.416907886645399,
            15.499965595662376
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.414923051974379,
            15.499334937972398
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.415094713351332,
            15.498683600960385
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.412948946139418,
            15.499365953969372
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.404177733533489,
            15.723668006776874
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.404370852582561,
            15.72291410797179
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.401313134305584,
            15.72360604259685
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.3989206038643,
            15.723884881258336
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.40041191207658,
            15.723946845353453
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.602632093075357,
            16.51449425886429
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.58134608233317,
            16.51301303339358
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.584264325741373,
            16.51992532178234
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.779871467128018,
            16.54423173622437
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.779689076915005,
            16.544314013521298
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.776470426097134,
            16.54529105373931
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.774775269999722,
            16.546072682350072
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.773981336131314,
            16.546298942672486
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.78155589438937,
            16.544375721470967
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.78281116820834,
            16.544046612177944
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.781008723750332,
            16.544509421960864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.78081560470126,
            16.5439540500881
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.773359063639859,
            16.549445990541106
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.77159953452609,
            16.55026873968461
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.76632094718478,
            16.550351014405866
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.76232982017062,
            16.551873090416212
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.713963643620644,
            16.22493545428199
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.71382416875187,
            16.224847891258648
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.713781253407632,
            16.224744875887204
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.713735655854379,
            16.224569749632067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.713765160153542,
            16.224546571145456
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.714148716042672,
            16.22482728818867
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.714272097657357,
            16.224956057340645
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.714194313595925,
            16.22499983883312
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.714642242501412,
            16.22464186046187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.714497403214608,
            16.224410075557806
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.409724932409413,
            15.950402820671336
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.409456711507923,
            15.951176502317896
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.408866625524647,
            15.951124923634357
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.409124117590077,
            15.951847023996178
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.403126698232777,
            15.950609136069057
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.419621556152324,
            15.956214976213683
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.418838351119975,
            15.956813272931862
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.422679274429301,
            15.955307212264627
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.420662253250102,
            15.957772607044465
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.422550528396586,
            15.959495270749652
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.421745865692118,
            15.960052296563152
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.420758812774638,
            15.960980669477303
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.422250120986918,
            15.95926833386311
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.397101944774754,
            15.96988272294245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.39594323048032,
            15.969305094866224
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.399161881298191,
            15.972482028661725
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.279702618633033,
            15.66545011313727
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.273436978374244,
            15.668383900315959
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.275175049815894,
            15.665935637164145
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.276870205913307,
            15.666927342229407
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.27902670196128,
            15.665822003984687
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.402564355697699,
            15.80003347429817
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.402440974083014,
            15.799968952554153
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.401121327247687,
            15.800064444728013
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.402089604702063,
            15.80022445854
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.403720387783117,
            15.800015408211923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.402502664890356,
            15.799814100284607
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.40054197010047,
            15.799989599514474
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.399179407920904,
            15.799953467332527
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.402349778976507,
            15.800758697286684
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.40426487621314,
            15.800789667605603
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.404082486000128,
            15.800103157758626
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.404409715499945,
            15.800211554205017
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.081657700447641,
            16.182742331877815
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.078138642220102,
            16.18385513208191
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.070671372322641,
            16.187234709062764
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.066122345833383,
            16.190160881413842
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.067667298225961,
            16.18595707090889
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.09571042419522,
            16.192073992603703
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.090914634476592,
            16.19062122935898
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.091483262787749,
            16.189951512204726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.091826585541655,
            16.189693928078672
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.100590300728,
            16.193685346398855
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.099742722679293,
            16.192634420938187
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.102628779579318,
            16.19470535693378
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.107542586494601,
            16.192902304430326
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.09008677022568,
            16.19666293813654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.095215153862155,
            16.19732232953618
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.096266579795993,
            16.194746569369805
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.110943627525485,
            16.196601120079812
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.11057884709946,
            16.195467785606535
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -15.10832579152695,
            16.196786574191886
          ]
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -14.560968076227562,
                16.562834341846692
              ],
              [
                -14.552041684626,
                16.563286822876712
              ],
              [
                -14.552685414789574,
                16.565590346188014
              ],
              [
                -14.555732404230492,
                16.569539179200742
              ],
              [
                -14.561397229669945,
                16.56649529423783
              ]
            ]
          ],
          "geodesic": true,
          "evenOdd": true
        },
        {
          "type": "Point",
          "coordinates": [
            -14.067990747502527,
            16.249171262391485
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.071981874516688,
            16.25189051246626
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.066016641667566,
            16.252302516771653
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.074084726384363,
            16.250572092885456
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.070286718419275,
            16.25018068537005
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.071273771336756,
            16.251396106159795
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            -14.075736967137537,
            16.251540308127662
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "landuse": 4
      },
      "color": "#63c213",
      "mode": "FeatureCollection",
      "shown": true,
      "locked": true
    }) || 
    /* color: #63c213 */
    /* locked: true */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-13.790350584061613, 16.105505874264118]),
            {
              "landuse": 4,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.787582544358244, 16.105588336295593]),
            {
              "landuse": 4,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.78917041209506, 16.105650182796722]),
            {
              "landuse": 4,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.790028718979826, 16.10847448580727]),
            {
              "landuse": 4,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.788891462357512, 16.10789725926356]),
            {
              "landuse": 4,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.795350221665373, 16.107464338253685]),
            {
              "landuse": 4,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.793311742814055, 16.108556946604985]),
            {
              "landuse": 4,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.779857782395354, 16.106887108771122]),
            {
              "landuse": 4,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.78045859721469, 16.105938799547083]),
            {
              "landuse": 4,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.784750131638518, 16.113009778780956]),
            {
              "landuse": 4,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.782046464951506, 16.113009778780956]),
            {
              "landuse": 4,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.817874254660076, 16.105944803948255]),
            {
              "landuse": 4,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.815449537710613, 16.10485218121286]),
            {
              "landuse": 4,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.81675845570988, 16.10495525908641]),
            {
              "landuse": 4,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.815192045645183, 16.103945093616858]),
            {
              "landuse": 4,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.819612326101726, 16.10947001741231]),
            {
              "landuse": 4,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.816222013906902, 16.108810333106966]),
            {
              "landuse": 4,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.812102140860027, 16.11140782737262]),
            {
              "landuse": 4,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.810128035025066, 16.11250041400441]),
            {
              "landuse": 4,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.821071447805828, 16.110995528966413]),
            {
              "landuse": 4,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-13.81802445836491, 16.10905771497853]),
            {
              "landuse": 4,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.247284130857292, 16.37720723130196]),
            {
              "landuse": 4,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.245803551481071, 16.37483970581218]),
            {
              "landuse": 4,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.239666657254997, 16.378154233448086]),
            {
              "landuse": 4,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.237885670469108, 16.375786719457857]),
            {
              "landuse": 4,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.251468376920524, 16.376548444487252]),
            {
              "landuse": 4,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.252240853116813, 16.374592658017747]),
            {
              "landuse": 4,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.196054801332227, 16.3755275584068]),
            {
              "landuse": 4,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.195153579103224, 16.373839398195116]),
            {
              "landuse": 4,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.194702967988722, 16.375733430603464]),
            {
              "landuse": 4,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.194338187562696, 16.37727746514953]),
            {
              "landuse": 4,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.196526870118849, 16.377112768713875]),
            {
              "landuse": 4,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.21865251402583, 16.390329215149386]),
            {
              "landuse": 4,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.219274786517285, 16.38993808708353]),
            {
              "landuse": 4,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.217601088091993, 16.38905289961365]),
            {
              "landuse": 4,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.223180082842969, 16.389649886953546]),
            {
              "landuse": 4,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.229746130511426, 16.39529029771666]),
            {
              "landuse": 4,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.229059485003614, 16.393931673562204]),
            {
              "landuse": 4,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.217343596026563, 16.39384933239972]),
            {
              "landuse": 4,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.23264291624751, 16.3951873719762]),
            {
              "landuse": 4,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.229520824954175, 16.39452864594899]),
            {
              "landuse": 4,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.22789004187312, 16.394312500985794]),
            {
              "landuse": 4,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.231033590838575, 16.39513590908555]),
            {
              "landuse": 4,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.254903414015251, 16.395151044434726]),
            {
              "landuse": 4,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.25416312432714, 16.394327636398952]),
            {
              "landuse": 4,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.253787615065056, 16.39415266174284]),
            {
              "landuse": 4,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.250397302870232, 16.39558333225976]),
            {
              "landuse": 4,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.251255609754997, 16.395748013083548]),
            {
              "landuse": 4,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.250472404722649, 16.394986363106096]),
            {
              "landuse": 4,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.255053617720085, 16.39464670742598]),
            {
              "landuse": 4,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.249581911329704, 16.39388505314117]),
            {
              "landuse": 4,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.252028085951286, 16.39417324700466]),
            {
              "landuse": 4,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.255654432539421, 16.395645087585013]),
            {
              "landuse": 4,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.255076503068961, 16.39781680406758]),
            {
              "landuse": 4,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.254089450151481, 16.39727130410111]),
            {
              "landuse": 4,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.254904841692008, 16.39661258512349]),
            {
              "landuse": 4,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.265457475675948, 16.401316708044636]),
            {
              "landuse": 4,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.290523929278454, 16.401263115068325]),
            {
              "landuse": 4,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.289729995410045, 16.40006920975985]),
            {
              "landuse": 4,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.29261605231007, 16.400275056025095]),
            {
              "landuse": 4,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.290824336688122, 16.40050148666546]),
            {
              "landuse": 4,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.28486983267506, 16.400892593514826]),
            {
              "landuse": 4,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.09126994455727, 16.54122145939528]),
            {
              "landuse": 4,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.088180039772114, 16.54393663403643]),
            {
              "landuse": 4,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.080884431251606, 16.538670805982107]),
            {
              "landuse": 4,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.048011277565083, 16.544594852436234]),
            {
              "landuse": 4,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.045865510353169, 16.54953141882963]),
            {
              "landuse": 4,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.054105256446919, 16.543442968762527]),
            {
              "landuse": 4,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.050929520973286, 16.541961965360258]),
            {
              "landuse": 4,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.051701997169575, 16.538177127233176]),
            {
              "landuse": 4,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.044234727272114, 16.542702468482712]),
            {
              "landuse": 4,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.047667954811176, 16.539164483467914]),
            {
              "landuse": 4,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.087836717018208, 16.53883536528439]),
            {
              "landuse": 4,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.092385743507466, 16.538177127233176]),
            {
              "landuse": 4,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.085605119117817, 16.538094847318884]),
            {
              "landuse": 4,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.07006976450356, 16.536860644394352]),
            {
              "landuse": 4,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.032493001951718, 16.51488915946469]),
            {
              "landuse": 4,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.026871091856503, 16.514632003604827]),
            {
              "landuse": 4,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.029113418592953, 16.513788529982502]),
            {
              "landuse": 4,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.033158189787411, 16.513829675122658]),
            {
              "landuse": 4,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.027128583921932, 16.515804631548153]),
            {
              "landuse": 4,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.025015003218197, 16.514385133657406]),
            {
              "landuse": 4,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.027729398741268, 16.513829675122658]),
            {
              "landuse": 4,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.03117335511639, 16.513582804150307]),
            {
              "landuse": 4,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.029349452986263, 16.515928065654556]),
            {
              "landuse": 4,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.030379421247982, 16.514961163044116]),
            {
              "landuse": 4,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.029966361059689, 16.514215410385624]),
            {
              "landuse": 4,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.031039244665646, 16.514529141165063]),
            {
              "landuse": 4,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.028507239355587, 16.515053739035412]),
            {
              "landuse": 4,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.031123309697701, 16.508359570036]),
            {
              "landuse": 4,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.028033404912545, 16.511198643901867]),
            {
              "landuse": 4,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.013141780461861, 16.51189811946642]),
            {
              "landuse": 4,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.0186778598686, 16.509511663008702]),
            {
              "landuse": 4,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.029363780583932, 16.506796004305613]),
            {
              "landuse": 4,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.022540240850045, 16.507042883945825]),
            {
              "landuse": 4,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.01391425665815, 16.51004656098347]),
            {
              "landuse": 4,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.01168265875776, 16.51198041054289]),
            {
              "landuse": 4,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.012841373052193, 16.508565301427545]),
            {
              "landuse": 4,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.014772563542916, 16.50700173736101]),
            {
              "landuse": 4,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.02666011389692, 16.50564389514989]),
            {
              "landuse": 4,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.024514346685006, 16.50560274826736]),
            {
              "landuse": 4,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.027604251470162, 16.510087706920217]),
            {
              "landuse": 4,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.03417029913862, 16.509511663008702]),
            {
              "landuse": 4,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.032496600713326, 16.507948106596107]),
            {
              "landuse": 4,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.342640288811923, 16.446294052911313]),
            {
              "landuse": 4,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.34397066448331, 16.44666448793048]),
            {
              "landuse": 4,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.339443095666171, 16.443454027611097]),
            {
              "landuse": 4,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.338520415765048, 16.442939525828663]),
            {
              "landuse": 4,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.087871161580274, 15.80241482992418]),
            {
              "landuse": 4,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.087356177449415, 15.802063835516726]),
            {
              "landuse": 4,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.083601084828565, 15.803023907010498]),
            {
              "landuse": 4,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.09024223434944, 15.802125775750508]),
            {
              "landuse": 4,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.09122928726692, 15.803467809495228]),
            {
              "landuse": 4,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.088332501530836, 15.801351521466335]),
            {
              "landuse": 4,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.083096829533766, 15.801929631611879]),
            {
              "landuse": 4,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.0867231761219, 15.801320551233383]),
            {
              "landuse": 4,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.090406564126484, 15.779572661486494]),
            {
              "landuse": 4,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.084205296884052, 15.780543164038745]),
            {
              "landuse": 4,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.07476392115163, 15.780150833779146]),
            {
              "landuse": 4,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.071309235940449, 15.779345521920453]),
            {
              "landuse": 4,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.089677003274433, 15.777982679180706]),
            {
              "landuse": 4,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.091114667306416, 15.7821537750431]),
            {
              "landuse": 4,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.093281892190449, 15.778230469451064]),
            {
              "landuse": 4,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.073304799447529, 15.778085925163495]),
            {
              "landuse": 4,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.078583386788837, 15.782071179918248]),
            {
              "landuse": 4,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.083239701638691, 15.778560856007187]),
            {
              "landuse": 4,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.160200238227777, 15.799566256769792]),
            {
              "landuse": 4,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.159760355949334, 15.79863713952834]),
            {
              "landuse": 4,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.15861237049096, 15.80030954749339]),
            {
              "landuse": 4,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.154749989509515, 15.799039757523065]),
            {
              "landuse": 4,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.161037087440423, 15.798936522216126]),
            {
              "landuse": 4,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.159717440605096, 15.798069343559913]),
            {
              "landuse": 4,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.158065199851922, 15.799597227271082]),
            {
              "landuse": 4,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.14340960979455, 15.802126468885863]),
            {
              "landuse": 4,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.144289374351434, 15.799793373669266]),
            {
              "landuse": 4,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.16204519294424, 15.816231174725646]),
            {
              "landuse": 4,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.162817669140528, 15.812597568888867]),
            {
              "landuse": 4,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.161058140026759, 15.809129066072817]),
            {
              "landuse": 4,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.170671177136134, 15.81565310543584]),
            {
              "landuse": 4,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.41886053480824, 15.500720314629806]),
            {
              "landuse": 4,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.417036632678114, 15.499210873937939]),
            {
              "landuse": 4,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.420748809954725, 15.499727806923381]),
            {
              "landuse": 4,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.418334821841322, 15.500017288830286]),
            {
              "landuse": 4,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.418055872103773, 15.498456149456624]),
            {
              "landuse": 4,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.416907886645399, 15.499965595662376]),
            {
              "landuse": 4,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.414923051974379, 15.499334937972398]),
            {
              "landuse": 4,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.415094713351332, 15.498683600960385]),
            {
              "landuse": 4,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.412948946139418, 15.499365953969372]),
            {
              "landuse": 4,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.404177733533489, 15.723668006776874]),
            {
              "landuse": 4,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.404370852582561, 15.72291410797179]),
            {
              "landuse": 4,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.401313134305584, 15.72360604259685]),
            {
              "landuse": 4,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.3989206038643, 15.723884881258336]),
            {
              "landuse": 4,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.40041191207658, 15.723946845353453]),
            {
              "landuse": 4,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.602632093075357, 16.51449425886429]),
            {
              "landuse": 4,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.58134608233317, 16.51301303339358]),
            {
              "landuse": 4,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.584264325741373, 16.51992532178234]),
            {
              "landuse": 4,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.779871467128018, 16.54423173622437]),
            {
              "landuse": 4,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.779689076915005, 16.544314013521298]),
            {
              "landuse": 4,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.776470426097134, 16.54529105373931]),
            {
              "landuse": 4,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.774775269999722, 16.546072682350072]),
            {
              "landuse": 4,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.773981336131314, 16.546298942672486]),
            {
              "landuse": 4,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.78155589438937, 16.544375721470967]),
            {
              "landuse": 4,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.78281116820834, 16.544046612177944]),
            {
              "landuse": 4,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.781008723750332, 16.544509421960864]),
            {
              "landuse": 4,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.78081560470126, 16.5439540500881]),
            {
              "landuse": 4,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.773359063639859, 16.549445990541106]),
            {
              "landuse": 4,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.77159953452609, 16.55026873968461]),
            {
              "landuse": 4,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.76632094718478, 16.550351014405866]),
            {
              "landuse": 4,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.76232982017062, 16.551873090416212]),
            {
              "landuse": 4,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.713963643620644, 16.22493545428199]),
            {
              "landuse": 4,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.71382416875187, 16.224847891258648]),
            {
              "landuse": 4,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.713781253407632, 16.224744875887204]),
            {
              "landuse": 4,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.713735655854379, 16.224569749632067]),
            {
              "landuse": 4,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.713765160153542, 16.224546571145456]),
            {
              "landuse": 4,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.714148716042672, 16.22482728818867]),
            {
              "landuse": 4,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.714272097657357, 16.224956057340645]),
            {
              "landuse": 4,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.714194313595925, 16.22499983883312]),
            {
              "landuse": 4,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.714642242501412, 16.22464186046187]),
            {
              "landuse": 4,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.714497403214608, 16.224410075557806]),
            {
              "landuse": 4,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.409724932409413, 15.950402820671336]),
            {
              "landuse": 4,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.409456711507923, 15.951176502317896]),
            {
              "landuse": 4,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.408866625524647, 15.951124923634357]),
            {
              "landuse": 4,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.409124117590077, 15.951847023996178]),
            {
              "landuse": 4,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.403126698232777, 15.950609136069057]),
            {
              "landuse": 4,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.419621556152324, 15.956214976213683]),
            {
              "landuse": 4,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.418838351119975, 15.956813272931862]),
            {
              "landuse": 4,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.422679274429301, 15.955307212264627]),
            {
              "landuse": 4,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.420662253250102, 15.957772607044465]),
            {
              "landuse": 4,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.422550528396586, 15.959495270749652]),
            {
              "landuse": 4,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.421745865692118, 15.960052296563152]),
            {
              "landuse": 4,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.420758812774638, 15.960980669477303]),
            {
              "landuse": 4,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.422250120986918, 15.95926833386311]),
            {
              "landuse": 4,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.397101944774754, 15.96988272294245]),
            {
              "landuse": 4,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.39594323048032, 15.969305094866224]),
            {
              "landuse": 4,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.399161881298191, 15.972482028661725]),
            {
              "landuse": 4,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.279702618633033, 15.66545011313727]),
            {
              "landuse": 4,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.273436978374244, 15.668383900315959]),
            {
              "landuse": 4,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.275175049815894, 15.665935637164145]),
            {
              "landuse": 4,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.276870205913307, 15.666927342229407]),
            {
              "landuse": 4,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.27902670196128, 15.665822003984687]),
            {
              "landuse": 4,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.402564355697699, 15.80003347429817]),
            {
              "landuse": 4,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.402440974083014, 15.799968952554153]),
            {
              "landuse": 4,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.401121327247687, 15.800064444728013]),
            {
              "landuse": 4,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.402089604702063, 15.80022445854]),
            {
              "landuse": 4,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.403720387783117, 15.800015408211923]),
            {
              "landuse": 4,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.402502664890356, 15.799814100284607]),
            {
              "landuse": 4,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.40054197010047, 15.799989599514474]),
            {
              "landuse": 4,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.399179407920904, 15.799953467332527]),
            {
              "landuse": 4,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.402349778976507, 15.800758697286684]),
            {
              "landuse": 4,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.40426487621314, 15.800789667605603]),
            {
              "landuse": 4,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.404082486000128, 15.800103157758626]),
            {
              "landuse": 4,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.404409715499945, 15.800211554205017]),
            {
              "landuse": 4,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.081657700447641, 16.182742331877815]),
            {
              "landuse": 4,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.078138642220102, 16.18385513208191]),
            {
              "landuse": 4,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.070671372322641, 16.187234709062764]),
            {
              "landuse": 4,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.066122345833383, 16.190160881413842]),
            {
              "landuse": 4,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.067667298225961, 16.18595707090889]),
            {
              "landuse": 4,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.09571042419522, 16.192073992603703]),
            {
              "landuse": 4,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.090914634476592, 16.19062122935898]),
            {
              "landuse": 4,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.091483262787749, 16.189951512204726]),
            {
              "landuse": 4,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.091826585541655, 16.189693928078672]),
            {
              "landuse": 4,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.100590300728, 16.193685346398855]),
            {
              "landuse": 4,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.099742722679293, 16.192634420938187]),
            {
              "landuse": 4,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.102628779579318, 16.19470535693378]),
            {
              "landuse": 4,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.107542586494601, 16.192902304430326]),
            {
              "landuse": 4,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.09008677022568, 16.19666293813654]),
            {
              "landuse": 4,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.095215153862155, 16.19732232953618]),
            {
              "landuse": 4,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.096266579795993, 16.194746569369805]),
            {
              "landuse": 4,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.110943627525485, 16.196601120079812]),
            {
              "landuse": 4,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.11057884709946, 16.195467785606535]),
            {
              "landuse": 4,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-15.10832579152695, 16.196786574191886]),
            {
              "landuse": 4,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Polygon(
                [[[-14.560968076227562, 16.562834341846692],
                  [-14.552041684626, 16.563286822876712],
                  [-14.552685414789574, 16.565590346188014],
                  [-14.555732404230492, 16.569539179200742],
                  [-14.561397229669945, 16.56649529423783]]]),
            {
              "landuse": 4,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.067990747502527, 16.249171262391485]),
            {
              "landuse": 4,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.071981874516688, 16.25189051246626]),
            {
              "landuse": 4,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.066016641667566, 16.252302516771653]),
            {
              "landuse": 4,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.074084726384363, 16.250572092885456]),
            {
              "landuse": 4,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.070286718419275, 16.25018068537005]),
            {
              "landuse": 4,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.071273771336756, 16.251396106159795]),
            {
              "landuse": 4,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-14.075736967137537, 16.251540308127662]),
            {
              "landuse": 4,
              "system:index": "238"
            })]),
    roi = ui.import && ui.import("roi", "table", {
      "id": "users/ndmorndiaye/dep_podor"
    }) || ee.FeatureCollection("users/ndmorndiaye/dep_podor");
//Elevation
var imageCollection = ee.ImageCollection("LANDSAT/LC08/C01/T1_SR");
var srtm=ee.Image("USGS/SRTMGL1_003").clip(roi);
Map.addLayer(srtm, {min:7.24, max: 66.76, 
palette: ["lightblue","green",'yellow',"red"]}, "Raw SRTM"); 
//slope
var slope = ee.Terrain.slope(srtm);
Map.addLayer(slope, {min:0.011, max:0.57, pallete: ["FFFFFF"]},"Slope");
//print(slope);
/// Add the Area of interest
var geometry= roi
//visualize parameters
var visParams = {
  bands: ['B4','B3','B2'],min: 0,max: 3000,gamma: 1.4,};
// Function to mask out clouds 
function maskL7sr(image) {
  var cloudShadowBitMask = (1 << 3);
  var cloudsBitMask = (1 << 5);
  var qa = image.select('pixel_qa');
  var mask = qa.bitwiseAnd(cloudShadowBitMask).eq(0) .and(qa.bitwiseAnd(cloudsBitMask).eq(0));return image.updateMask(mask);}
//Raw surface reflectance
var l8_2020 = imageCollection.filterDate('2020-01-01', '2020-07-07').map(maskL7sr);
//Filter scenes that intersect the study area
var areaofinterest=imageCollection.filterBounds(roi) 
//print to check the total number of images that year
//print('aoi', areaofinterest)
//print('Image collection 2020',l8_2020);
//Generate the median composites
var l8 = l8_2020.median();
//clipping
var clipped = l8.clip(roi)
// Visualize the composites
Map.centerObject(roi,6); 
Map.addLayer(clipped, {bands: ['B4', 'B5', 'B1'], min: 0, max: 10000}, 'Landsat 8');
//merge feature collections
var classNames = Builtup.merge(Water).merge(Cropland).merge(Bareland).merge(Vegetation)
print(classNames)
//Create training data
var bands = ['B2', 'B3', 'B4', 'B5', 'B6', 'B7'];
var training = clipped.select(bands).sampleRegions({
  collection: classNames,
  properties: ['landuse'],
  scale: 30
});
print(training)
// accuaracy of the classification
var random=training.randomColumn();
var validation=random.filter(ee.Filter.lt("random",0.2));
training=random.filter(ee.Filter.gte("random",0.2));
//NDVI
var ndvi=clipped.normalizedDifference(["B5","B4"]);
Map.addLayer(ndvi,{palette:['red', 'orange', 'yellow', 'lightgreen',"green"],min:0.11,max:0.44},"NDVI",false)
Map.addLayer(ee.Image().paint(roi,"black",2),{},"Limit")
//train classifier
var classifier = ee.Classifier.smileRandomForest(10).train({
  features: training,
  classProperty: 'landuse',
  inputProperties: bands
});
//Classify
var classified = clipped.select(bands).classify(classifier);
var palette =['d63000','0b4a8b', '42ff31', 'FFAA00','267300'];
//Display classification (-14.2179, 16.3697)
Map.setCenter((-14.6412, 16.5453), 8)
Map.addLayer(classified, {
  min:0,
  max: 4 ,
  palette: palette
}, '2020 Landcover',false)
// set position of panel
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '10px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0',
    }
});
// Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0',
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  Palette with the colors
var palette =['d63000','0070FF', 'AAFF00', 'FFAA00','267300'];
// name of the legend
var names = ['Builtup','Water', 'Cropland', 'Bareland', 'Others Vegetations'];
// Add color and names
for (var i = 0; i < 5; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
 //Map.add(legend)
// Test of accuaracy
 print("Accuracy",validation.classify(classifier).errorMatrix("landuse", "classification").accuracy())
print("Matrixerror",training.classify(classifier).errorMatrix("landuse", "classification").accuracy())
// Chart
var collect=ee.ImageCollection("LANDSAT/LC08/C01/T1_TOA").filterDate('2020-01-01', '2020-07-07')
var veg=collect.map(function(imag){var ndvi_Podor=imag.normalizedDifference(["B5","B4"]).rename("ndvi_Podor");
return imag.addBands(ndvi_Podor);
}).select("ndvi_Podor")
print(veg.limit(100))
print(ui.Chart.image.series(veg, roi, ee.Reducer.mean(), 200))
// Application
var Panel1 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    height: '100%',
    width: '30%',
  },
})
;
var titre=ui.Label({
  value: 'SENEGAL: PODOR LAND USE DECISION SUPPORT SYSTEM',
  style: {
    color:"green",
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
Panel1.add(titre);
var text3= ui.Label({value:"Purposes ",style:{
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0',
    position:"top-center"
    }})
var text= ui.Label({value:" This project will be in the near future an platform which policy makers can use in order to get intergrated insight for the main issues we are faced nowadays.This stuff isn't ready we will work on this for his improvment.I  will  share the link for person who can give a support. Basically if this tool is ready soon it's can push other departments in senegal to do the same things.And at the we can improve the way we manage all  ressources presents in our Department",style: {
    //fontWeight: 'bold',
    fontSize: '12px',
    margin: '0 0 4px 0',
    padding: '0'
    }})
var layer= ui.Label({value: [" Layers:LULC",
"True Composite" ,"NDVI","Elevation","Slope"],style: {
    //fontWeight: 'bold',
    fontSize: '12px',
    margin: '0 0 4px 0',
    padding: '0',
    fontWeight:"bold"
    }})    
Panel1.add(text3)
Panel1.add(text)
Panel1.add(layer)
Panel1.add(ui.Chart.image.series(veg, roi, ee.Reducer.mean(), 200).setChartType('ScatterChart').setOptions({
    title: 'NDVI in Podor Department',
    vAxis: {title: 'NDVI  '},
    hAxis: {title: 'Date', format: 'MM-yy', gridlines: {count: 7}},
    position:"top- center",
          lineWidth: 1,
          pointSize: 4,}))
// Add the title to the panel
var pal3=ui.Map();
pal3.addLayer(clipped, {bands: ['B4', 'B3', 'B2'], min: 600.24, max: 3491.76}, 'Landsat 8 True Composite',false);
pal3.addLayer(ee.Image().paint(roi,"black",2),{},"Limit");
pal3.addLayer(srtm, {min:7.24, max: 66.76, 
palette: ["lightblue","green",'yellow',"red"]}, "Raw SRTM",false); 
pal3.addLayer(slope, {min:0.011, max:0.57, pallete: ["FFFFFF"]},"Slope",false);
pal3.addLayer(classified, {
  min:0,
  max: 4 ,
  palette: palette
}, '2020 LULC')
pal3.setCenter(-14.8293, 16.5758,10)
pal3.addLayer(ndvi,{palette:['red', 'orange', 'yellow', 'lightgreen',"green"],min:0.11,max:0.44},"NDVI",false);
var splitPanel = ui.SplitPanel({
  firstPanel: Panel1,
  secondPanel: pal3,
});
var button = ui.Button({
    label: "GITHUB",
    onClick: function() {
        return("https://github.com/morandiaye");
    },
    style: {
        color: 'green',
        position: 'top-right',
    },
});
Panel1.add(button)
pal3.add(legend)
ui.root.clear();
ui.root.add(splitPanel);