var img = ui.import && ui.import("img", "image", {
      "id": "users/bw_chen1223/bloomExtraction"
    }) || ee.Image("users/bw_chen1223/bloomExtraction"),
    vis_mndwi = ui.import && ui.import("vis_mndwi", "imageVisParam", {
      "params": {
        "min": -1,
        "max": 1,
        "palette": [
          "#ece7f2",
          "#d0d1e6",
          "#a6bddb",
          "#74a9cf",
          "#3690c0",
          "#0570b0",
          "#045a8d",
          "#023858"
        ]
      }
    }) || {"min":-1,"max":1,"palette":["#ece7f2","#d0d1e6","#a6bddb","#74a9cf","#3690c0","#0570b0","#045a8d","#023858"]};
/*
Automatic extraction of water bloom.
Realization idea: 
The threshold value of algal bloom NDVI was determined by 
calculating the algal bloom boundary gradient value.
Implementation process:
1. Calculate NDVI and MNDWI;
2. Water mask with MNDWI;
3. Calculate the gradient of NDVI;
4. Assume the NDVI range of algal bloom and use the threshold within the range to make a binary graph;
5. Edge extraction of threshold binaries within a range;
6. Calculate the mean gradient of the boundary;
7. Mapping: Threshold --> Average Gradient;
8. Extract the key value corresponding to the maximum gradient and the maximum average gradient range.
*/
// 1. Use the normalizedDifference(A, B) to compute (A - B) / (A + B)
var ndvi = img.addBands(img.normalizedDifference(['b8', 'b4']).rename('ndvi'));
var mndwi = ndvi.addBands(img.normalizedDifference(['b3', 'b12']).rename('mndwi'));
Map.centerObject(img, 12);
print('ndvi', mndwi);
Map.addLayer(mndwi.select(['b8', 'b4', 'b3']),{min: -1, max: 1}, 'img');
// Make a palette: a list of hex strings.
var palette = ['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
               '74A901', '66A000', '529400', '3E8601', '207401', '056201',
               '004C00', '023B01', '012E01', '011D01', '011301'];
Map.addLayer(mndwi.select('ndvi'), {min:-1, max:1, palette: palette}, 'NDVI');
// 2. Function: water_extract
var water_extract = mndwi.updateMask(mndwi.select('mndwi').gt(ee.Number(0)));
print('water_extract', water_extract);
Map.addLayer(water_extract.select('mndwi'), vis_mndwi, 'water_extract');
// 3. Function: Compute the magnitude of the gradient.
function magnitude_gradient(xyGrad){
  return ee.Image(xyGrad).select('x').pow(2)
    .add(ee.Image(xyGrad).select('y').pow(2)).sqrt().rename('gradient');
  }
// Calculate the gradient of NDVI.
var gradient = mndwi.select('ndvi').gradient();
var magnitude_gradient = magnitude_gradient(gradient);
print('magnitude_gradient', magnitude_gradient);
Map.addLayer(magnitude_gradient, {}, 'magnitude_gradient');
// 4. Assume the NDVI range of algal bloom and use the threshold within the range to make a binary graph.
//// Configure the threshold traversal range
//var range = ee.List.sequence(-0.4, 0.4, 0.01);
var range = ee.List.sequence(-0.2, 0.2, 0.01);
print('range', range);
//// Function: ndvi_binary
function ndvi_binary(threshold){
  return water_extract.select('ndvi').gt(ee.Number(threshold));
  }
var range_binary = range.map(ndvi_binary);
print('binary', range_binary);
Map.addLayer(ee.Image(range_binary.get(0)),{}, "Result: binary's first");
// 5. Edge extraction of threshold binaries within a range
// Function:  edge detection 
function laplacian4(image){
  var kernel = ee.Kernel.laplacian4();
  return ee.Image(image).convolve(kernel);
  }
var range_edge = range_binary.map(laplacian4);
print('range_edge', range_edge);
print('range_edge first', range_edge.get(0));
Map.addLayer(ee.Image(range_edge.get(0)),{min: -4, max: 4}, "Result: canny's first");
// The gradient calculation of edge detection results is carried out.
var range_edge = range_edge.map(function(image){
  return ee.Image(image).abs().gt(0);
  });
Map.addLayer(ee.Image(range_edge.get(0)), {}, 'first of range_edge');
// Function: The boundary is multiplied by the pixel value of the NDVI gradient.
function edge_gradient(image){
  return magnitude_gradient.multiply(ee.Image(image));
  }
var range_gradient = range_edge.map(edge_gradient);
print('range_gradient', range_gradient);
Map.addLayer(ee.Image(range_gradient.get(0)), {}, 'gradient');
// convert imagecollection.
var list_gradient = ee.ImageCollection.fromImages(range_gradient);
// 6. Function: Calculate the mean of the gradient of each image.
function mean_gradient(image){
  return ee.Image(image).select('gradient').reduceRegion({
    'reducer': ee.Reducer.mean(),
    'geometry': img.geometry(),
    'scale': img.projection().nominalScale(),
    'maxPixels': 1e12
    });
  }
// Calculate mean
range_gradient = range_gradient.map(mean_gradient);
print('mean_range_gradient', range_gradient);
// 7. Mapping: Threshold -- average gradient;
var values = range_gradient.map(function(dict){
  return ee.Algorithms.Dictionary(dict).values().get(0);
  });
var keys = range.map(function(threshold){
  return ee.String(threshold);
  });
// print(keys, values);
var list = ee.Dictionary.fromLists(keys, values);
print('list', list);
// 8. Extract the key value corresponding to the maximum gradient and the maximum average gradient range
var printDict_max = function(dict){
  // Returns the key corresponding to the largest value in the dictionary as a number.
  var list = dict.values().zip(dict.keys());
  var key_maximum =  ee.Algorithms.Dictionary(list.reduce(ee.Reducer.max(2))).values().get(1);
  return ee.Number.parse(key_maximum);
  };
print("maximum of dict", printDict_max(list));
var threshold = printDict_max(list);
var result = water_extract.select('ndvi').gte(threshold);
Map.addLayer(result, {}, 'result');
//Export.image.toDrive(result);