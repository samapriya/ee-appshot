var dataset = ee.ImageCollection("YALE/YCEO/UHI/UHI_yearly_pixel/v4");
var visualization = {
  bands: ['Daytime'],
  min: -1.5,
  max: 7.5,
  palette: [
    "#313695","#74add1","#fed976","#feb24c","#fd8d3c","#fc4e2a",
    "#e31a1c","#b10026",
  ]
};
Map.setCenter(116.2056, 39.8904, 8);
Map.addLayer(dataset, visualization, "Daytime UHI");