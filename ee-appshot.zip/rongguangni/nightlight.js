var dataset = ee.ImageCollection('NOAA/VIIRS/DNB/MONTHLY_V1/VCMSLCFG')
                  .filter(ee.Filter.date('2017-05-01', '2017-05-31'));
var nighttime = dataset.select('avg_rad');
var nighttimeVis = {"min":0,"max":10,palette: [
    "black","#808080","#41CFDA","#5FD6C2",
    "#84DFA3","#B4EC78","#D3F457",
    "#F2FC33"
  ]};
Map.setCenter(116.2056, 39.8904, 8);
Map.addLayer(nighttime, nighttimeVis, 'Nighttime');