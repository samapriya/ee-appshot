var timeSinceVertex = ee.Image('users/ak_glaciers/reem_cf_outputs/LTOP_annual_time_since_vertex_Cambodia'); 
var segmentLength = ee.Image('users/ak_glaciers/reem_cf_outputs/LTOP_annual_segment_length_Cambodia'); 
var nbrTimeSeries = ee.Image('users/ak_glaciers/reem_cf_outputs/LTOP_NBR_change_detection_img_NBR'); 
var canopyCover = ee.Image('users/ak_glaciers/reem_cf_outputs/reem_canopy_cover_2000_pts_rma_nbr_timeseries_remapped_full')
Map.addLayer(segmentLength)