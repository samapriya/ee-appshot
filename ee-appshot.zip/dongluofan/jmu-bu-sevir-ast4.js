// NASA SERVIR AST-4 (WA)
// Visualization of Forest loss in Ghana
// ---------------------------------------------------------------
var api = require('users/dongluofan/util:api.js')
var text = require('users/gena/packages:text')
var utData = require('users/xjtang/servir:misc/utilities_data');
var utCCD = require('users/xjtang/servir:misc/utilities_ccd');
var uiUtil = require('users/dongluofan/util:uiUtils.js')
var uiUtil2 = require('users/lfdong/SEVIR_WA_Public:Multi_Sensor_Classification/uiUtils.js')
// ---------------------------------------------------------------
// 
// -------------------------- Initialization -------------------------------------
var url = 'https://docs.google.com/document/d/1hpS4EXWAbdjZvgI1wxOpFFIZyOStbM_s6ORDnHAjqE8/edit?usp=sharing'
var animationParams  = {
  area: 5000,
  cloudThreshold:0.95,
  start:'2022-01-01',
  end: '2026-01-01',
}
var videoArgs = {
  dimensions: 400, 
  region: region, 
  framesPerSecond: 1,
  min:0,
  max:1400,
  bands:['RED','GREEN','BLUE'],
  gamma:1.4,
  //crs: 'EPSG:3857',
}
var textProps = {
  fontSize: 32,
  textColor: 'black',
  outlineColor: 'black', outlineWidth: 1, outlineOpacity: 1,
};
// ---------------------------------------------------------------
var grid_af = 'users/ytzhang/GLANCE/GRIDS/GEOG/GLANCE_V01_AF_GEOG_TILE'
var region = ee.FeatureCollection('projects/ee-dongluofan12/assets/Southern_Ghana') 
var protectedArea = ee.FeatureCollection("projects/sevir-wa-ast4/assets/dnd_in_protected")
// -------------- Landsat ------------
var getLandsatTS = function(region, start, end) {
  var collection5 = ee.ImageCollection('LANDSAT/LT05/C02/T1_L2')
      .filterDate(start, end)
      .filterBounds(region).map(maskL457);
  var collection7 = ee.ImageCollection('LANDSAT/LE07/C02/T1_L2')
      .filterDate(start, end)
      .filterBounds(region).map(maskL457);
  var collection8 = ee.ImageCollection('LANDSAT/LC08/C02/T1_L2')
      .filterDate(start, end)
      .filterBounds(region).map(maskL89);
  var collection9 = ee.ImageCollection('LANDSAT/LC09/C02/T1_L2')
      .filterDate(start, end)
      .filterBounds(region).map(maskL89);
  var col = collection5.merge(collection7).merge(collection8).merge(collection9);
  return col
};
var maskL89 = function(image){
  var bandList = ['SR_B2', 'SR_B3', 'SR_B4', 'SR_B5', 'SR_B6', 'SR_B7'];
  var subBand = ['BLUE', 'GREEN', 'RED', 'NIR', 'SWIR1', 'SWIR2'];
  var opticalBands = image.select(bandList).multiply(0.0000275).add(-0.2).multiply(10000).rename(subBand);
  var validQA = [21824, 21888, 21952]; // 21952 is not in the guide
  var mask1 = ee.Image(image).select(['QA_PIXEL']).remap(validQA, ee.List.repeat(1, validQA.length), 0).unmask(0).rename('QA_PIXEL');
  return ee.Image(image).addBands(opticalBands).select(subBand).addBands(mask1)
};
var maskL457 = function(image){
  var bandList = ['SR_B1','SR_B2','SR_B3','SR_B4','SR_B5','SR_B7'];
  var subBand = ['BLUE', 'GREEN', 'RED', 'NIR', 'SWIR1', 'SWIR2'];
  var opticalBands = image.select(bandList).multiply(0.0000275).add(-0.2).multiply(10000).rename(subBand);
  var validQA = [5440, 5504];
  var mask1 = ee.Image(image).select(['QA_PIXEL']).remap(validQA, ee.List.repeat(1, validQA.length), 0).unmask(0).rename('QA_PIXEL');
  return ee.Image(image).addBands(opticalBands).select(subBand).addBands(mask1)
};
// ----------------------------- Set Layout ----------------------------------
var layout = api.uiUtils.layout0()
layout.mapObj.centerObject(region,8)
var Acknowledgement = function(){
  var title = 'Acknowledgement'
  var authors = 'Luofan Dong, Xiaojing Tang, Katelyn Tarrio, Kelsee Bratley, Foster Mensah, Bashara Ahmed Abubakari, Mary Amponsah, Curtis E. Woodcock'
  var institudes = 'Boston University (BU), James Madison University (JMU), GIS and Remote Sensing Centre in Ghana (CERSGIS)'
  var funding = 'This work is supported by NASA SEVIR and BU URBAN funding'
  var forUser = ''
  var titleLabel = ui.Label(title, api.uiUtils.vis)
  var authors = ui.Label(authors)
  var institudes = ui.Label(institudes)
  var funding= ui.Label(funding)
  var Panel = ui.Panel([titleLabel,authors,institudes,funding])
  return Panel
}
var ReadMe = function(){
  var title = 'Read me'
  var instruction = 'Click on a forest reserve to check forest rate'
  var titleLabel = ui.Label(title, api.uiUtils.vis)
  var instruction = ui.Label(instruction)
  var doc = ui.Label('For documentation, please click this link').setUrl(url)
  var Panel = ui.Panel([titleLabel,instruction,doc])
  return Panel
}
var Plot = function(options){
  options = options || {}
  var app = {}
  var title = 'Plot'
  var instruction = 'First figure shows the monthly forest loss area in 2023 and 2024. Second figure shows the the annual forest loss are since 2000 '
  app.setUtil = function(charts){
    app.plot_NRT.widgets().set(0, charts[0])
    app.plot_All.widgets().set(0, charts[1])
  }
  app.__init__ = function () {
    app.titleLabel = ui.Label(title, api.uiUtils.vis)
    app.instruction = ui.Label(instruction)
    app.plot_NRT = ui.Panel([])
    app.plot_All = ui.Panel([])
    app.Panel = ui.Panel([app.titleLabel,app.instruction,app.plot_NRT,app.plot_All])
    return app
  }
  return app.__init__()
}
var Statistic = function(options){
  var instruction = 
  options = options || {}
  var app = {}
  var title = 'Summary'
  var instruction = 'Here shows the name of the forest reserve you clicked on and the forest disturbance area for different time period'
  var placeholder = 'Click on a forest reserve to check the results'
  app.setValue = function(info){
    info.evaluate(function(info){
      app.name.widgets().get(1).setValue(info['name'])
      app.loss_2000.widgets().get(1).setValue(info['2000_2022'])
      app.loss_2000_annual.widgets().get(1).setValue(info['2000_2022_annual'])
      app.loss_2023.widgets().get(1).setValue(info[2023])
      app.loss_2024.widgets().get(1).setValue(info[2024])
    })
  }
  app.__init__ = function () {
    app.titleLabel = ui.Label(title, api.uiUtils.vis)
    app.instruction = ui.Label(instruction)
    app.name = uiUtil.textPanel('Name', placeholder)
    app.loss_2000 = uiUtil.textPanel('2000 to 2022 (ha)',placeholder)
    app.loss_2000_annual = uiUtil.textPanel('2000 to 2022 abnual (ha)',placeholder)
    app.loss_2023 = uiUtil.textPanel('2023 (ha)', placeholder)
    app.loss_2024 = uiUtil.textPanel('2024 (ha)', placeholder)
    app.Panel = ui.Panel([app.titleLabel,app.instruction,app.name,app.loss_2000,
            app.loss_2000_annual,app.loss_2023,app.loss_2024])
    return app
  }
  return app.__init__()
}
var Animation = function(options){
  options = options || {}
  var app = {}
  var title = 'Animation'
  app.mapObj = options.mapObj || Map
  var start = options.start || '2013-01-01'
  var end = options.end || '2025-01-01'
  var area = options.area || 5000
  var cloudThreshold = options.cloudThreshold || 0.9
  app.getValue = function(obj){
    obj = obj || {}
    obj.area = parseInt(app.areaLabel.widgets().get(1).getValue())
    obj.start = app.startLabel.widgets().get(1).getValue()
    obj.end = app.endLabel.widgets().get(1).getValue()
    obj.cloud = parseFloat(app.cloudLabel.widgets().get(1).getValue())
    return obj
  }
  app.setUtil = function(point){
    var params = app.getValue()
    var geometryBound = point.buffer(params.area).bounds()
    //  Get Landsat image 
    var images = getLandsatTS(geometryBound, params.start,params.end)
          .sort('system:time_start')
    var proj = images.first().projection().atScale(30)
    images = images.map(function(image){
        image = image.set('system:footprint',geometryBound).unmask(0)
        var cloud = image.select('QA_PIXEL').reduceRegion({geometry:geometryBound,reducer:ee.Reducer.mean(),scale:30})
        return image.set('cloud',cloud.get('QA_PIXEL'))
      }).select(['RED','GREEN','BLUE']).filter(ee.Filter.gt('cloud',params.cloud))
    images.size().evaluate(function(n){
      app.imageNumber.widgets().get(1).setValue(n)
    })
    var geometryLabel = ee.List(point.coordinates())
    geometryLabel = ee.Geometry.Point([ee.Number(geometryLabel.get(0)).subtract(params.area/100000*0.8),
          ee.Number(geometryLabel.get(1)).add(params.area/100000*0.8)])
    var blended = images.map(function(x){
      var dtext = text.draw(ee.Image(x).get("DATE_ACQUIRED"), geometryLabel, params.area/100*0.8, textProps);
      return ee.Image(x).blend(dtext)
    })
    videoArgs.region = geometryBound
    var video = ui.Thumbnail(blended, videoArgs)
    app.animation.widgets().set(0, video)
    var fc = ee.FeatureCollection(ee.Feature(geometryBound))
    var styled = fc.style({fillColor: "#00000000"})
    api.ut.rmLayerName(layout.mapObj, 'Animation Boundary')
    app.mapObj.addLayer(styled,{},'Animation Boundary')
    // -------- First and last ------
    var first = ui.Thumbnail(blended.first(), videoArgs)
    app.first_image.widgets().set(0, first)
    var last = ui.Thumbnail(blended.sort('system:time_start',false).first(), videoArgs)
    app.last_image.widgets().set(0, last)
  }
  app.__init__ = function () {
    app.titleLabel = ui.Label(title, api.uiUtils.vis)
    app.areaLabel = uiUtil.textPanel('Area (m)', area)
    app.startLabel = uiUtil.textPanel('Start', start)
    app.endLabel = uiUtil.textPanel('End', end)
    app.cloudLabel = uiUtil.textPanel('Cloud threshold', cloudThreshold)
    app.imageNumber = uiUtil.textPanel('Image number', 0)
    app.animation = ui.Panel([])
    app.first_image = ui.Panel([])
    app.last_image = ui.Panel([])
    app.Panel = ui.Panel([app.titleLabel,app.startLabel,app.endLabel,app.areaLabel,
          app.cloudLabel,app.imageNumber,app.animation,app.first_image,app.last_image])
    return app
  }
  return app.__init__()
}
var filterData = function(options){
  options = options || {}
  var app = {}
  var title = 'Filter date'
  var instruction = 'Filter the NRT result by date using "Start" and "End"'
  app.start = options.start || '2023-01-01'
  app.end = options.end || '2026-01-01'
  app.mapObj = options.mapObj || Map
  app.getValue = function(obj){
    obj = obj || {}
    obj.start = app.startLabel.widgets().get(1).getValue()
    obj.end = app.endLabel.widgets().get(1).getValue()
    return obj
  }  
  app.load = function(){
    var values = app.getValue()
    var start = api.ut.dateToFrac(values.start)
    var end  = api.ut.dateToFrac(values.end)
    var img = nrt.updateMask(nrt.gt(start)).updateMask(nrt.lt(end))
    api.ut.rmLayerName(app.mapObj,'Near-real-time')
    api.ut.rmLayerName(app.mapObj,'Near-real-time (In protected area)')
    app.mapObj.addLayer(img.selfMask(),vis,'Near-real-time',false);
    app.mapObj.addLayer(img.selfMask().clip(protectedArea),vis,'Near-real-time (In protected area)');
  }
  app.reset = function(){
    app.startLabel.widgets().get(1).setValue(app.start)
    app.endLabel.widgets().get(1).setValue(app.end)
    app.load()
  }
  app.__init__ = function () {
    app.titleLabel = ui.Label(title, api.uiUtils.vis)
    app.instruction = ui.Label(instruction)
    app.startLabel = uiUtil.textPanel('Start', app.start)
    app.endLabel = uiUtil.textPanel('End', app.end)
    app.loadButton = uiUtil.buttonPanel('Load', app.load)
    app.resetButton = uiUtil.buttonPanel('Reset', app.reset)
    app.Panel = ui.Panel([app.titleLabel, app.instruction, app.startLabel,
          app.endLabel,app.loadButton,app.resetButton])
    return app
  }
  return app.__init__()
}
var readmMePanel = ReadMe()
var plotPanel = Plot()
var acknowledgementPanel = Acknowledgement()
var statisticPanel = Statistic()
animationParams.mapObj= layout.mapObj
var filterDataPanel = filterData({mapObj:layout.mapObj})
var animationPanel = Animation(animationParams)
layout.setUtil(0, readmMePanel,'left')
layout.setUtil(1, plotPanel.Panel,'left')
layout.setUtil(2, statisticPanel.Panel,'left')
layout.setUtil(3, acknowledgementPanel,'left')
layout.setUtil(0, filterDataPanel.Panel,'right')
layout.setUtil(1, animationPanel.Panel,'right')
// --------------------- Load SMA ---------------------
layout.mapObj.addLayer(protectedArea ,{color:'Green'},'Protected Area')
var disturbance = ee.Image('projects/bu-nasacms/servir_wa/forest_disturbance_servir/forest_disturbance_v14')
var forest_mask = disturbance.select('forest_mask') 
var def_year = disturbance.select('def_year1').unmask(0)
//var def_driver = disturbance.select('def_driver1')
var deg_year = disturbance.select('degrad_year1')
//var deg_mag = disturbance.select('degrad_mag1')
var dnd = def_year.unmask(0).gt(0).multiply(10).add(deg_year.unmask(0).gt(0))
var tree_loss = disturbance.select('treeloss_year1').updateMask(dnd.eq(0))
var deg_year = deg_year.unmask(0).add(tree_loss.unmask(0)).updateMask(def_year.eq(0)).unmask(0)
var dnd = def_year.add(deg_year).selfMask()
var style = {
  min: 1997,
  max:  2022,
  palette: ['FCFDBF', 'FDAE78', 'EE605E', 'B63679', '711F81', '2C105C'],
  orientation: 'horizontal',
  title: 'Forest loss (2000-2022)',
  position:'bottom-left'
}
var vis = {min:style.min, max:style.max, palette:style.palette}
layout.mapObj.addLayer(dnd.clip(region),vis,'Forest loss 2000-2022',false)
layout.mapObj.addLayer(dnd.clip(protectedArea),vis,'Forest loss 2000-2022 in Protected Areas',false)
var legend = api.uiObj.colorbarLegend(style.min, style.max, style.palette,
        style.orientation, style.title, style.position)
layout.mapObj.add(legend)  
// -------------- LOAD NRT result -------------------
var alert_2023 = ee.ImageCollection('projects/fusionnrt/assets/ghana/2023/alerts').select('Filtered').mosaic();
var alert_2024 = ee.ImageCollection('projects/fusionnrt/assets/ghana/2024/alerts').select('Filtered').mosaic();
var alert_2025 = ee.ImageCollection('projects/fusionnrt/assets/ghana/2025/alerts').select('Filtered').mosaic();
alert_2024 = alert_2024.updateMask(alert_2023.unmask(0).eq(0))
alert_2025 = alert_2024.updateMask(alert_2024.unmask(0).eq(0)).updateMask(alert_2023.unmask(0).eq(0))
var nrt = alert_2023.divide(366).add(2023).unmask(0)
        .add(alert_2024.divide(366).add(2024).unmask(0))
        .add(alert_2025.divide(366).add(2025).unmask(0))
var style = {
  min: 2023,
  max:  2025,
  palette: ['yellow','red'],
  orientation: 'horizontal',
  title: 'Forest loss (Near-real-time)',
  position:'bottom-left'
}
var vis = {min:style.min, max:style.max, palette:style.palette}
var legend = api.uiObj.colorbarLegend(style.min, style.max, style.palette,
        style.orientation, style.title, style.position)
layout.mapObj.addLayer(nrt.selfMask(),vis,'Near-real-time',false);
layout.mapObj.addLayer(nrt.selfMask().clip(protectedArea),vis,'Near-real-time (In protected area)');
layout.mapObj.add(legend)  
// --------------------------
var addStatistic = function(coords){
  var point = ee.Geometry.Point([ coords.lon,coords.lat])
  var reserve = ee.Feature(protectedArea.filterBounds(point).first());
  var geometry = reserve.geometry()
  api.ut.rmLayerName(layout.mapObj, 'Reserve')
  var fc = ee.FeatureCollection(reserve).style({fillColor: "#00000000",color:'red'})
  layout.mapObj.addLayer(fc,{},'Reserve')
  // ----------- NRT PLOT  -----------
  var alert_2023_month = ee.List(ee.String(reserve.get('alert_2023_month')).decodeJSON()).map(function(n){
    return ee.Number(n).multiply(400).divide(10000)
  })
  var alert_2024_month = ee.List(ee.String(reserve.get('alert_2024_month')).decodeJSON()).map(function(n){
    return ee.Number(n).multiply(400).divide(10000)
  })
  var yValues = ee.List([alert_2023_month.cat(alert_2024_month)])
  var xValues = ee.List(ee.List.sequence({start:2023,end:2025,count:24}))
  //print(yValues, xValues)
  //print('sum',ee.Array(alert_2024_month).reduce(ee.Reducer.sum(),[0]))
  // Define the chart 
  var chart1 = ui.Chart.array.values({array: yValues, axis: 1, xLabels: xValues})
                  .setSeriesNames(['Forest loss'])
                  .setOptions({
                    title: 'Near-real-time',
                    colors: ['1d6b99'],
                    hAxis: {
                      'title': 'Year',
                      titleTextStyle: {italic: false, bold: true}
                    },
                    vAxis: {
                      'title': 'Area (ha)',
                      titleTextStyle: {italic: false, bold: true}
                    },
                    pointSize: 5,
                    lineSize: 3,
                  })
                  .setChartType('AreaChart'); 
  // --------- All time Plot -----------
  var dis_2023 = ee.Number(reserve.get('alert_2023')).multiply(400).divide(10000)
  var dis_2024 = ee.Number(reserve.get('alert_2024')).multiply(400).divide(10000)
  var dis_2000_2022 = ee.List(ee.String(reserve.get('dnd_year')).decodeJSON()).map(function(n){
    return ee.Number(n).divide(10000)
  })
  var yValues = ee.List([dis_2000_2022.cat([dis_2023,dis_2024])])
  var xValues = ee.List(ee.List.sequence(2000,2024,1));
  // Define the chart 
  var chart2 = ui.Chart.array.values({array: yValues, axis: 1, xLabels: xValues})
                  .setSeriesNames(['Forest loss'])
                  .setOptions({
                    title: 'Annual forest loss',
                    colors: ['1d6b99'],
                    hAxis: {
                      'title': 'Year',
                      titleTextStyle: {italic: false, bold: true}
                    },
                    vAxis: {
                      'title': 'Area (ha)',
                      titleTextStyle: {italic: false, bold: true}
                    },
                    pointSize: 5,
                    lineSize: 3,
                  })
                  .setChartType('AreaChart');
  // --------------- set            
  plotPanel.setUtil([chart1,chart2])
  // ------------------- show text ------------------------
  // forest loss, forest cover
  var dis_2000_2022_sum = ee.Number(ee.Array(dis_2000_2022).reduce(ee.Reducer.sum(),[0])
                              .toList().get(0))
  var info = ee.Dictionary({name:reserve.get('NAME'),2023:dis_2023.round(),
  2024:dis_2024.round(),'2000_2022':dis_2000_2022_sum.round(),
  '2000_2022_annual':dis_2000_2022_sum.divide(22).round()})
  statisticPanel.setValue(info)
  // ---------------------- animation --------
  animationPanel.setUtil(point)
}
layout.mapObj.onClick(addStatistic)
//layout.mapObj.addLayer(alert_2024.updateMask(alert_2024.gt(300)),{palette :'blue'},'alert_2024')
/*
var data = ee.FeatureCollection('projects/sevir-wa-ast4/assets/NRT_merged') 
layout.mapObj.addLayer(data,{},'all',false)
layout.mapObj.addLayer(data.filter(ee.Filter.gt('count',5000)),{},'filtered')
*/