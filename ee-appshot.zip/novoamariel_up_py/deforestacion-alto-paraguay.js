var image = ui.import && ui.import("image", "image", {
      "id": "UMD/hansen/global_forest_change_2021_v1_9"
    }) || ee.Image("UMD/hansen/global_forest_change_2021_v1_9"),
    ZI = ui.import && ui.import("ZI", "table", {
      "id": "users/novoamariel_up_py/ZI"
    }) || ee.FeatureCollection("users/novoamariel_up_py/ZI");
//Trabajo Final Especialización - Universidad del Pacifico - Py
/* Análisis de cambio de cobertura boscosa de los Distritos de Puerto Casado y Carmelo Peralta */
// Fuente Consultada: www.gisandbeers.com/
// Llamada a la ultima versiÃ³n de la coleccion Hansen Global Forest Change  
var Deforestacion = ee.Image("UMD/hansen/global_forest_change_2021_v1_9");
var PerdidasAnuales = Deforestacion.select('lossyear'); // Seleccion de la banda de perdidas anuales de masa forestal
var Perdida = Deforestacion.select('loss'); // Seleccion de la banda de perdida de masa forestal
var Ganancia = Deforestacion.select('gain'); // Seleccion de la banda de ganancia de masa forestal
// Calculo del NDVI inicial y final
var NDVI2019 = Deforestacion.normalizedDifference (['first_b40','first_b30']);
var NDVI2021 = Deforestacion.normalizedDifference (['last_b40','last_b30']);
// Calculo del NDVI para 2021, 2020 y 2019 bajo colecciones anteriores
var Deforestacion2021 = ee.Image("UMD/hansen/global_forest_change_2021_v1_9")
var Deforestacion2020 = ee.Image("UMD/hansen/global_forest_change_2020_v1_8");
var Deforestacion2019 = ee.Image("UMD/hansen/global_forest_change_2019_v1_7");
var NDVI2021 = Deforestacion2021.normalizedDifference (['last_b40','last_b30']);
var NDVI2020 = Deforestacion2020.normalizedDifference (['last_b40','last_b30']);
var NDVI2019 = Deforestacion2019.normalizedDifference (['last_b40','last_b30']);
// RepresentaciÃ³n de los indices de vegetacion NDVI temporales
Map.addLayer (NDVI2019,{min: 0.0, max: 1.0,
    palette: ['155de3','fcd163','bdd218','99b718','66a000','3e8601','207401','056201','004c00','022f02']},
    'NDVI - 2019',0);
Map.addLayer (NDVI2020,{min: 0.0, max: 1.0,
    palette: ['155de3','fcd163','bdd218','99b718','66a000','3e8601','207401','056201','004c00','022f02']},
    'NDVI - 2020',0);
Map.addLayer (NDVI2021,{min: 0.0, max: 1.0,
    palette: ['155de3','fcd163','bdd218','99b718','66a000','3e8601','207401','056201','004c00','022f02']},
    'NDVI - 2021',0);
// Representacion de valores de ganancia y perdidas de masa forestal
Map.addLayer (Ganancia,{min: 0.0, max: 1.0, // 2 clases, ganancia y no ganancia
    palette: ['000000', '22b219']},
    'Mapa de ganancias 2019-2021',0);
Map.addLayer (Perdida,{min: 0.0, max: 1.0, // 2 clases, perdida y no perdida
    palette: ['000000', 'ff0000']},
    'Mapa de perdidas 2019-2021',0);
Map.addLayer (PerdidasAnuales,{min: 0.0, max: 18.0, // 18 clases, una por cambio anual
    palette: ['#000000', 'fcd163','bdd218', '99b718', '66a000', '3e8601', '207401', '056201', '004c00', '022f02']},
    'Mapa de perdidas anuales 2019-2021',1); // Capa visible
var SELECTED_AREA = ZI
Map.addLayer( ZI, {}, 'ZI', true)
//Centrar
Map.setCenter(-58.3568738,-21.5838193,8)