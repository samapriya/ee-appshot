// Demonstrates how to efficiently display a number of layers of a dataset along
// with a legend for each layer, and some visualization controls.
/*
 * Configure layers and locations
 */
var lampung = ee.FeatureCollection("users/firstmile2019_diagram/Lampung");
var dataset = ee.ImageCollection ('users/potapovpeter/GEDI_V27')
var image1 = ee.Image("users/potapovpeter/GEDI_V27/GEDI_SASIA_v27").clip(lampung);
var image2 = ee.Image("UMD/hansen/global_forest_change_2019_v1_7").clip(lampung)
var image3 = ee.Image("UMD/hansen/global_forest_change_2019_v1_7").clip(lampung)
            .select('loss').rename('loss2')
var image4 = ee.Image("UMD/hansen/global_forest_change_2019_v1_7").clip(lampung)
            .select('lossyear').rename('lossyear2')
var image5 = ee.Image("UMD/hansen/global_forest_change_2019_v1_7").clip(lampung)
            .select('treecover2000').rename('treecover2')
var image6 = image2.addBands(image1)
var image7 = image4.addBands(image3)
var image8 = image6.addBands(image5)
var hansen = image8.addBands(image7)
print (hansen)
var layerProperties = {
  'Tahun Tutupan Hilang': {
    name: 'lossyear',
    visParams: {min: 0, max: 19, palette: ['yellow', 'orange', 'red']},
    legend: [
      {'2016 - 2019': 'red'}, {'2001 - 2015': 'orange'}, {'2000': 'yellow'},
      {'Tidak ada perubahan': 'black'}, {'Badan air/tidak ada data': 'grey'}
    ],
    defaultVisibility: true
  },
  'Tutupan Hilang (2000 - 2019)': {
    name: 'loss',
    visParams: {min: 0, max: 1, palette: ['black', 'red']},
    legend:
        [{'Tutupan hilang': 'red'}, {'Tidak ada perubahan': 'black'}, {'Badan air/tidak ada data': 'grey'}],
    defaultVisibility: false
  },
'Tutupan Tumbuh (2000 - 2012)': {
    name: 'gain',
    visParams: {min: 0, max: 1, palette: ['black', 'blue']},
    legend:
        [{'Tutupan tumbuh': 'blue'}, {'Tidak ada perubahan': 'black'}, {'Badan air/tidak ada data': 'grey'}],
    defaultVisibility: false
  },
  'Persen Tutupan Pohon (2000)': {
    name: 'treecover2000',
    visParams: {min: 0, max: 100, palette: ['#000000', '#00ff00']},
    legend: [
      {'75-100%': '#00ff00'}, {'50-75%': '#00aa00'}, {'25-50%': '#005500'},
      {'0-25%': '#000000'}, {'Badan air/tidak ada data': '#404040'}
    ],
    defaultVisibility: false
  },
  'Model Tinggi Kanopi (2019)': {
    name: 'b1',
    visParams: {min: 0, max: 60, palette: [
    '000000', '005500', '00aa00', '00ff00']},
    legend: [
      {'> 30 m': '#00ff00'}, {'15 - 30 m': '#00aa00'}, {'1 - 15 m': '#005500'},
      {'0 m': '#000000'}, {'Badan air/tidak ada data': '#404040'}
    ],
    defaultVisibility: false
  }
};
// Some pre-set locations of interest that will be loaded into a pulldown menu.
var locationDict = {
  'Bandar Lampung': {lon: 105.267, lat: -5.41538, zoom: 12},
  'Lampung Barat': {lon: 104.187, lat: -5.03042, zoom: 10},
  'Lampung Selatan': {lon: 105.501, lat: -5.53277, zoom: 10},
  'Lampung Tengah': {lon: 105.265, lat: -4.8613, zoom: 11},
  'Lampung Timur': {lon: 105.649, lat: -5.13665, zoom: 10},
  'Lampung Utara': {lon: 104.806, lat: -4.80924, zoom: 11},
  'Mesuji': {lon: 105.378, lat: -4.02374, zoom: 11},
  'Metro': {lon: 105.306, lat: -5.12182, zoom: 12},
  'Pesawaran': {lon: 105.11, lat: -5.47349, zoom: 11},
  'Pesisir Barat': {lon: 104.205, lat: -5.38274, zoom: 11},
  'Pringsewu': {lon: 104.92, lat: -5.33085, zoom: 12},
  'Tanggamus': {lon: 104.675, lat: -5.43586, zoom: 11},
  'Tulang Bawang Barat': {lon: 105.92, lat: -4.42482, zoom: 11},
  'Tulang Bawang': {lon: 105.532, lat: -4.37276, zoom: 11},
  'Way Kanan': {lon: 104.614, lat: -4.51645, zoom: 11},
};
/*
* Map panel configuration
*/
// Now let's do some overall layout.
// Create a map panel.
var mapPanel = ui.Map();
// Take all tools off the map except the zoom and mapTypeControl tools.
mapPanel.setControlVisibility(
    {all: false, zoomControl: true, mapTypeControl: true});
// Center the map
//var defaultLocation = locationDict['Deforestation in Paraguay'];
mapPanel.centerObject(lampung,8.5);
// Add these to the interface.
ui.root.widgets().reset([mapPanel]);
ui.root.setLayout(ui.Panel.Layout.flow('horizontal'));
// Add layers to the map and center it.
for (var key in layerProperties) {
  var layer = layerProperties[key];
  var image = hansen.select(layer.name).visualize(layer.visParams);
  var masked = addZeroAndWaterMask(image, hansen.select(layer.name));
  mapPanel.add(ui.Map.Layer(masked, {}, key, layer.defaultVisibility));
}
// Draws black and gray overlays for nodata/water/zero values.
function addZeroAndWaterMask(visualized, original) {
  // Places where there is nodata or water are drawn in gray.
  var zero1 =
      hansen.select('treecover2000').neq(1).selfMask().visualize({palette: 'black'});
  var zero2 = hansen.select('treecover2000').eq(1).selfMask().visualize({palette: 'black'});
  var water =
      hansen.select('datamask').neq(1).selfMask().visualize({palette: 'gray'});
  // Places were the underyling value is zero are drawn in black.
  // Stack the images, with the gray on top, black next, and the original below.
  return ee.ImageCollection([zero1, zero2, visualized, water]).mosaic();
}
/*
* Additional component configuration
*/
// Add a title and some explanatory text to a side panel.
var header = ui.Label('Peta Perubahan Tutupan Hutan Lampung', {fontWeight: 'bold', fontSize: '24px', color: 'red'});
var subheader = ui.Label('Dipublis oleh Digital Agroforestry Program (Rainforest Alliance)',
    {fontWeight: 'bold', fontSize: '16px', color: 'black'});
var text = ui.Label(
    'Berdasarkan data Global Forest Change ' +
    ' dan Global Forest Canopy Height, 2019. '+
    ' Hasil dari analisis citra Landsat resolusi spasial 30m ' +
    ' dengan mengkarakterisasi struktur, luas dan perubahan hutan.'+
    ' ("Kehilangan tutupan pohon tidak selalu merupakan deforestasi").',
    {fontSize: '11px'});
var toolPanel = ui.Panel([header, subheader, text], 'flow', {width: '330px'});
ui.root.widgets().add(toolPanel);
// Create a hyperlink to an external reference.
var linkPanel = ui.Label(
    'Citation : Science paper by Hansen, Potapov, Moore, Hancher et al.', {fontSize: '10px'},
    'http://science.sciencemag.org/content/342/6160/850');
toolPanel.add(linkPanel);
// Get the loss image.
// This dataset is updated yearly, so we get the latest version.
// Selected country (e.g. Bolivia).
var country = lampung;
// Canopy cover percentage (e.g. 10%).
var cc = ee.Number(10);
// Minimum forest area in pixels (e.g. 6 pixels, ~ 0.5 ha in this example).
var pixels = ee.Number(6);
// Minimum mapping area for tree loss (usually same as the minimum forest area).
var lossPixels = ee.Number(6);
var canopyCover = hansen.select(['treecover2']);
var canopyCover10 = canopyCover.gte(cc).selfMask();
// Use connectedPixelCount() to get contiguous area.
var contArea = canopyCover10.connectedPixelCount();
// Apply the minimum area requirement.
var minArea = contArea.gte(pixels).selfMask();
var prj = hansen.projection();
var scale = prj.nominalScale();
var forestArea = minArea.multiply(ee.Image.pixelArea()).divide(10000);
var forestSize = forestArea.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: lampung.geometry(),
    scale: 30,
    maxPixels: 1e13
});
var pixelCount = minArea.reduceRegion({
    reducer: ee.Reducer.count(),
    geometry: lampung.geometry(),
    scale: 30,
    maxPixels: 1e13
});
var onePixel = forestSize.getNumber('treecover2')
    .divide(pixelCount.getNumber('treecover2'));
var minAreaUsed = onePixel.multiply(pixels);
print('Minimum forest area used (ha)\n ', minAreaUsed);
var treeLoss = hansen.select(['lossyear2']);
var treeLoss01 = treeLoss.neq(0).selfMask(); // tree loss in year 2001
// Select the tree loss within the derived tree cover
// (>= canopy cover and area requirements).
var treecoverLoss01 = minArea.and(treeLoss01).rename('lossCover').selfMask();
// Create connectedPixelCount() to get contiguous area.
var contLoss = treecoverLoss01.connectedPixelCount();
// Apply the minimum area requirement.
var minLoss = contLoss.gte(lossPixels).selfMask();
var lossArea = minLoss.multiply(ee.Image.pixelArea()).divide(10000);
var lossYear = hansen.select(['lossyear2']);
var lossSize = lossArea.addBands(lossYear).reduceRegion({
    reducer: ee.Reducer.sum().group({
    groupField: 1
    }),
    geometry: lampung,
    scale: 30,
    maxPixels: 1e13
});
//
// var lossImage2 = hansen.select(['loss2']);
// var lossAreaImage = lossImage2.multiply(ee.Image.pixelArea());
// var lossYear2 =hansen.select(['lossyear2']);
// var lossByYearArea = lossAreaImage.addBands(lossYear2).reduceRegion({
//   reducer: ee.Reducer.sum().group({
//     groupField: 1
//     }),
//   geometry: lampung,
//   scale: 30,
//   maxPixels: 1e9
// });
// print(lossByYearArea);
var statsFormatted = ee.List(lossSize.get('groups'))
  .map(function(el) {
    var d = ee.Dictionary(el);
    return [ee.Number(d.get('group')).format("20%02d"), d.get('sum')];
  });
var statsDictionary = ee.Dictionary(statsFormatted.flatten());
print(statsDictionary);
var chart = ui.Chart.array.values({
  array: statsDictionary.values(),
  axis: 0,
  xLabels: statsDictionary.keys()
}).setChartType('ColumnChart')
  .setOptions({
    title: 'Perubahan Tutupan per Tahun',
    hAxis: {title: 'Tahun', format: '####'},
    vAxis: {title: 'Area (Ha)'},
    legend: { position: "none" },
    lineWidth: 1,
    pointSize: 3
  });
toolPanel.add(chart);
// Create a layer selector pulldown.
// The elements of the pulldown are the keys of the layerProperties dictionary.
var selectItems = Object.keys(layerProperties);
// Define the pulldown menu.  Changing the pulldown menu changes the map layer
// and legend.
var layerSelect = ui.Select({
  items: selectItems,
  value: selectItems[0],
  onChange: function(selected) {
    // Loop through the map layers and compare the selected element to the name
    // of the layer. If they're the same, show the layer and set the
    // corresponding legend.  Hide the others.
    mapPanel.layers().forEach(function(element, index) {
      element.setShown(selected == element.getName());
    });
    setLegend(layerProperties[selected].legend);
  }
});
// Add the select to the toolPanel with some explanatory text.
toolPanel.add(ui.Label('Lihat Layer Berbeda', {'font-size': '14px'}));
toolPanel.add(layerSelect);
// Create the legend.
// Define a panel for the legend and give it a tile.
var legendPanel = ui.Panel({
  style:
      {fontWeight: 'bold', fontSize: '10px', margin: '0 0 0 8px', padding: '0'}
});
toolPanel.add(legendPanel);
var legendTitle = ui.Label(
    'Keterangan',
    {fontWeight: 'bold', fontSize: '10px', margin: '0 0 4px 0', padding: '0'});
legendPanel.add(legendTitle);
// Define an area for the legend key itself.
// This area will be replaced every time the layer pulldown is changed.
var keyPanel = ui.Panel();
legendPanel.add(keyPanel);
function setLegend(legend) {
  // Loop through all the items in a layer's key property,
  // creates the item, and adds it to the key panel.
  keyPanel.clear();
  for (var i = 0; i < legend.length; i++) {
    var item = legend[i];
    var name = Object.keys(item)[0];
    var color = item[name];
    var colorBox = ui.Label('', {
      backgroundColor: color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0'
    });
    // Create the label with the description text.
    var description = ui.Label(name, {margin: '0 0 4px 6px'});
    keyPanel.add(
        ui.Panel([colorBox, description], ui.Panel.Layout.Flow('horizontal')));
  }
}
// Set the initial legend.
setLegend(layerProperties[layerSelect.getValue()].legend);
// Create a visibility checkbox and an opacity slider.
//
// If the checkbox is clicked off, disable the layer pulldown and turn all the
// layers off. Otherwise, enable the select, and turn on the selected layer.
var checkbox = ui.Checkbox({
  label: 'Opasitas',
  value: true,
  onChange: function(value) {
    var selected = layerSelect.getValue();
    // Loop through the layers in the mapPanel. For each layer,
    // if the layer's name is the same as the name selected in the layer
    // pulldown, set the visibility of the layer equal to the value of the
    // checkbox. Otherwise, set the visibility to false.
    mapPanel.layers().forEach(function(element, index) {
      element.setShown(selected == element.getName() ? value : false);
    });
    // If the checkbox is on, the layer pulldown should be enabled, otherwise,
    // it's disabled.
    layerSelect.setDisabled(!value);
  }
});
// Create an opacity slider. This tool will change the opacity for each layer.
// That way switching to a new layer will maintain the chosen opacity.
var opacitySlider = ui.Slider({
  min: 0,
  max: 1,
  value: 1,
  step: 0.01,
});
opacitySlider.onSlide(function(value) {
  mapPanel.layers().forEach(function(element, index) {
    element.setOpacity(value);
  });
});
var viewPanel =
    ui.Panel([checkbox, opacitySlider], ui.Panel.Layout.Flow('horizontal'));
toolPanel.add(viewPanel);
// Create the location pulldown.
var locations = Object.keys(locationDict);
var locationSelect = ui.Select({
  items: locations,
  value: locations[0],
  onChange: function(value) {
    var location = locationDict[value];
    mapPanel.setCenter(location.lon, location.lat, location.zoom);
  }
});
var locationPanel = ui.Panel([
  ui.Label('Kunjungi Contoh Lokasi', {'font-size': '14px'}), locationSelect
]);
toolPanel.add(locationPanel);