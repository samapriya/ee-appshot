var image = ui.import && ui.import("image", "image", {
      "id": "USGS/3DEP/10m"
    }) || ee.Image("USGS/3DEP/10m");
var terrain = ee.Algorithms.Terrain(image)
var geo_box = ee.Geometry.Polygon([[[-106.9, 36.2],[-106.9, 35.6], [-106.1, 35.6],[-106.1, 36.2]]]);
var params = {
  bands: ['elevation', 'slope', 'aspect'],
  min: [0,0,0],
  max: [1500, 10, 360]
};
var params2 = {
  bands: ['elevation', 'slope', 'aspect'],
  min: [0,0,0],
  max: [100, 10, 359]
};
var params3 = {
  bands: ['elevation', 'slope', 'aspect'],
  gain: [0.25, 10, -1],
  bias: [0, 0, -360]
};
var label = ui.Label('R = Elevation, G = Slope, B = Aspect', {position: 'top-left'})
Map.add(label)
Map.addLayer(terrain.select('hillshade'), {}, 'Hillshade')
var button = ui.Button({
  label: 'RGB Example 1',
  onClick: function() {
    var layers = Map.layers()
    Map.remove(layers.get(0))
    Map.addLayer(terrain,params,'HighEl Example');
    Map.setCenter(-83.4192, 36.0402, 8); // east Tennessee;
  }
});
Map.add(button);
var button2 = ui.Button({
  label: 'RGB Example 2',
  onClick: function() {
    var layers = Map.layers()
    Map.remove(layers.get(0))
    Map.addLayer( terrain,params2,'LowEl Example');
    Map.setCenter(-75.652, 35.9799, 13); // Nags Head, NC
  }
});
Map.add(button2);
var button3 = ui.Button({
  label: 'RGB Example 3',
  onClick: function() {
    var layers = Map.layers()
    Map.remove(layers.get(0))
    Map.addLayer(terrain,params3,'HighEl Example2');
    Map.setCenter(-83.4192, 36.0402, 8); // east Tennessee
  }
});
Map.add(button3);
var button4 = ui.Button({
  label: 'Meteor Crater (shaded)',
  onClick: function() {
    var layers = Map.layers()
    Map.remove(layers.get(0))
    Map.addLayer(terrain.select('hillshade'), {}, 'Hillshade')
    Map.setCenter(-111.02294, 35.02726, 14); // standing on a corner outside Winslow, AZ
  }
});
Map.add(button4);
var button7 = ui.Button({
  label: 'Meteor Crater, elev <2650',
  onClick: function() {
    var layers = Map.layers()
    Map.remove(layers.get(0))
    Map.addLayer(terrain.select('hillshade'), {}, 'Hillshade')
    Map.setCenter(-111.02294, 35.02726, 14); // not Valles
    var thres = terrain.select('elevation').lt(1700.0);
    Map.addLayer(thres.updateMask(thres), {palette: 'FF0000', opacity: 0.3}, '> 1700');
  }
});
Map.add(button7);
var button5 = ui.Button({
  label: 'Valles Caldera (shaded)',
  onClick: function() {
    var layers = Map.layers()
    Map.remove(layers.get(0))
    Map.addLayer(terrain.select('hillshade'), {}, 'Hillshade')
   Map.setCenter(-106.5646, 35.8935, 10); // Valles
  }
});
Map.add(button5);
var button6 = ui.Button({
  label: 'Valles, elev >1700',
  onClick: function() {
    var layers = Map.layers()
    Map.remove(layers.get(0))
    Map.addLayer(terrain.select('hillshade'), {}, 'Hillshade')
    Map.setCenter(-106.5646, 35.8935, 10); // Valles
    var thres = terrain.select('elevation').gt(2650.0);
    Map.addLayer(thres.updateMask(thres), {palette: '0000FF', opacity: 0.5}, '< 2650');
  }
});
Map.add(button6);