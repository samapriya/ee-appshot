Map.setCenter(-100.78728888888888, 20.9789, 11);
var point1 = ee.Geometry.Point([-100.78728888888888, 20.9789]);
Map.addLayer(point1, {color: 'red'});
var point2 = ee.Geometry.Point([-100.96112500000001, 21.08641111111111]);
Map.addLayer(point2);
var point3 = ee.Geometry.Point([-100.964675, 21.091216666666664]);
Map.addLayer(point3);