//Google Earth Engine Sea level (GEESeaL)
//© Copyright, Prof. James Lea, University of Liverpool 2025. All Rights Reserved.
//Email: j.lea@liverpool.ac.uk
var landMask = ee.Image("USGS/GTOPO30").unmask().not()
//JS function to count number of decimal places
Number.prototype.countDecimals = function() {
    if (Math.floor(this.valueOf()) === this.valueOf()) return 0;
    return this.toString().split(".")[1].length || 0;
}
var legendPanel = ui.Panel({
    style: {
        position: 'bottom-left'
    }
})
Map.add(legendPanel)
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(vis1) {
    return {
        bbox: [0, 0, 1, 0.1],
        dimensions: '100x10',
        format: 'png',
        min: 0,
        max: 1,
        palette: vis1,
    };
}
var makeColourBar = function(vis, option) {
    Map.remove(legendPanel)
    // Create the color bar for the legend.
    var colorBar = ui.Thumbnail({
        image: ee.Image.pixelLonLat().select(0),
        params: makeColorBarParams(vis.palette),
        style: {
            stretch: 'horizontal',
            margin: '0px 8px',
            maxHeight: '15px'
        },
    });
    // Update legend labels
    var legendLabels = ui.Panel({
        widgets: [
            ui.Label({value:vis.min,
                style:{fontSize:'10px',
                      margin: '1px 1px'
                }
            }),
            ui.Label({value:(vis.min + (vis.max - vis.min) / 2), 
                    style:{margin: '1px 1px',
                    fontSize:'10px',
                    textAlign: 'center',
                    stretch: 'horizontal'}
                }),
            ui.Label({value:vis.max,
                style:{fontSize:'10px',
                      margin: '1px 1px'
                }
            })
        ],
        layout: ui.Panel.Layout.flow('horizontal')
    })
    if (option === 'overall') {
        var legendTitle = ui.Label({
            value: 'Overall sea level change (m)',
            style: {fontSize:'10px',
                fontWeight: 'bold'
            }
        });
    } else {
        var legendTitle = ui.Label({
            value: 'Overall sea level change (m)',
            style: {fontSize:'10px',
                fontWeight: 'bold'
            }
        });
    }
    // Add the legendPanel to the map.
    legendPanel = ui.Panel({
        widgets: [legendTitle, colorBar, legendLabels],
        style: {
            position: 'bottom-left'
        }
    });
    Map.add(legendPanel)
}
//Function to add chart to sidebar
var showChart = function(pathwayValue, pathwaySelect, pathwayList, bandString, bandStringShort, mainPanel, coords, uncLogical,
                         plotSubPanel,plotSubSubPanel,plotSubSubPanel1) {
    //Set up loading messages
    var loadingMsg1=ui.Label({value:'Loading overall sea level change...',
          style: {
            margin: '30px 10px 1px 30px',
            textAlign: 'center',
            stretch: 'horizontal',
            fontWeight: 'bold',
            fontSize: '20px',
            color: 'black'
        }
    })
    var loadingMsg2=ui.Label({value:'Loading rate of sea level change...',
          style: {
            margin: '30px 10px 1px 30px',
            textAlign: 'center',
            stretch: 'horizontal',
            fontWeight: 'bold',
            fontSize: '20px',
            color: 'black'
        }
    })
    var loadingMsg3=ui.Label({value:'Loading sea level contributions...',
          style: {
            margin: '30px 10px 1px 30px',
            textAlign: 'center',
            stretch: 'horizontal',
            fontWeight: 'bold',
            fontSize: '20px',
            color: 'black'
        }
    })
    while (mainPanel.widgets().length() > 9) {
                mainPanel.remove(mainPanel.widgets().get(mainPanel.widgets().length()-1))
            }
    mainPanel.add(loadingMsg1).add(loadingMsg2).add(loadingMsg3)
    //Get line chart properties from pathwayList
    var listAllSSPs=['ssp119','ssp126','ssp245','ssp370','ssp585'];
    //create object linking all SSPs to a given colour
    var lineColoursInitial={0: { pathway:'ssp119',color: '#00ADCF' },
                      1: { pathway:'ssp126',color: '#173C66' },
                      2: { pathway:'ssp245',color: '#F79420' },
                      3: { pathway:'ssp370',color: '#E7271B' },
                      4: { pathway:'ssp585',color: '#951B1E' }}
    //Create function to find which SSPs have been passed to the function, and their order
    Array.prototype.diff = function(arr2) {
        var ret = [];
        this.sort();
        arr2.sort();
        for(var i = 0; i < this.length; i += 1) {
            if(arr2.indexOf(this[i]) > -1){
                ret.push(i);
            }
        }
        return ret;
    };
    //find indices of SSPs passed to function in original SSP list
    var intersection = listAllSSPs.diff(pathwayList);    
    //get colour properties of each SSP that have been passed to the showChart function
    var lineColours = [];
    for (var ssp in intersection) {
        lineColours.push(lineColoursInitial[intersection[ssp]]);
        lineColours[ssp]={color:lineColours[ssp].color}
    }
    ///////
    //Start main bit of function
    //Map.onClick(function(coords) {
    if (Map.layers().length() > 0) {
        while (Map.layers().length() > 1) {
            Map.remove(Map.layers().get(1));
        }
        var geomPoint = ee.Geometry.Point([coords.lon, coords.lat])
        Map.addLayer(geomPoint)
        var pathways=ee.List(pathwayList)
        var bandVals
        var bandRates
        if(uncLogical===true){
          bandVals=[bandStringShort+'_values_quantile_0_5',bandStringShort+'_values_quantile_0_167',bandStringShort+'_values_quantile_0_833']
          bandRates=[bandStringShort+'_rates_quantile_0_5',bandStringShort+'_rates_quantile_0_167',bandStringShort+'_rates_quantile_0_833']
        } else {
          bandVals=[bandStringShort+'_values_quantile_0_5']
          bandRates=[bandStringShort+'_rates_quantile_0_5']
        }
        //get sea level SUM curves for each pathway
        var totalResultsSumOut=ee.List(pathways).map(function(pathway){
          //Get total SLC
          var timeSeriesCollSum = ee.ImageCollection("IPCC/AR6/SLP")
              .filter(ee.Filter.stringStartsWith('system:index', pathway))
              .select(bandVals)
          var timeSeriesSumResults = ee.ImageCollection(timeSeriesCollSum).map(function(im) {
              var value = ee.Dictionary(ee.Image(im).reduceRegion({
                  reducer: ee.Reducer.mean(),
                  geometry: geomPoint,
                  scale: 1000,
              })).map(function(key,val){return ee.Number(val).divide(1000)})
              .values()
              var valsOut=ee.Algorithms.If(ee.List(value).size().gt(1),
                                            ee.List([value.get(1),value.get(0),value.get(2)]),
                                            ee.List([value.get(0)]))
              var featStart = ee.Feature(null).set('row',ee.List(valsOut))
                                              .set('year',ee.Number.parse(ee.Date(ee.Image(im).get('system:time_start')).format('YYYY')))
              return ee.Feature(featStart)
              // var featEnd=ee.Feature(null).set('SL',value,
              //                                   'system:time_start',ee.Image(im).get('system:time_end'))
              // return ee.FeatureCollection([featStart,featEnd])
          }).sort('system:time_start')
          //get results of SUMS into a table format
          var timeSeriesSumResultsTable=ee.FeatureCollection(timeSeriesSumResults).aggregate_array('row')
          //create table headers
          var columnHeader
          if(uncLogical===true){
            columnHeader=ee.List([[
                                    //{label: 'year', role: 'domain'},
                                    {label: ee.String(pathway), role: 'data'},
                                    {label: ee.String(pathway).cat(' 18.7%ile'), role: 'interval'},
                                    {label: ee.String(pathway).cat(' 83.3%ile'), role: 'interval'}
                                  ]]);
          } else {
            columnHeader=ee.List([[
                                    {label: ee.String(pathway), role: 'data'},
                                  ]]);
          }
          //append headers to data table
          var dataTableServerSum = columnHeader.cat(timeSeriesSumResultsTable);
          return ee.List(dataTableServerSum)
        })
        //create year list (domain) for plotting - HARD CODED
        var yearList=ee.List([{label: 'year', role: 'domain'}]).cat(ee.List.sequence(2020,2150,10))
        //map over all SUM results to get into a single table
        var listNum=ee.List.sequence(0,ee.Number(ee.List(totalResultsSumOut.get(0)).size()).subtract(1))
        var tableListSum
        if(pathwayList.length==5){
          tableListSum=ee.List(listNum).map(function(ind){
            return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsSumOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsSumOut.get(1)).get(ind)))
                    .cat(ee.List(ee.List(totalResultsSumOut.get(2)).get(ind))).cat(ee.List(ee.List(totalResultsSumOut.get(3)).get(ind)))
                    .cat(ee.List(ee.List(totalResultsSumOut.get(4)).get(ind)))
          })
        } else if (pathwayList.length==4){
          tableListSum=ee.List(listNum).map(function(ind){
            return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsSumOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsSumOut.get(1)).get(ind)))
                    .cat(ee.List(ee.List(totalResultsSumOut.get(2)).get(ind))).cat(ee.List(ee.List(totalResultsSumOut.get(3)).get(ind)))
          })
        } else if (pathwayList.length==3){
          tableListSum=ee.List(listNum).map(function(ind){
            return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsSumOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsSumOut.get(1)).get(ind)))
                    .cat(ee.List(ee.List(totalResultsSumOut.get(2)).get(ind)))
          })
        } else if (pathwayList.length==2){
          tableListSum=ee.List(listNum).map(function(ind){
            return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsSumOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsSumOut.get(1)).get(ind)))
          })
        } else if (pathwayList.length==1){
          tableListSum=ee.List(listNum).map(function(ind){
            return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsSumOut.get(0)).get(ind)))
          })
        }  
        //get sea level SUM curves for each pathway
        var totalResultsRatesOut=ee.List(pathways).map(function(pathway){
          //Get rates SLC
          var timeSeriesCollRates = ee.ImageCollection("IPCC/AR6/SLP")
              .filter(ee.Filter.stringStartsWith('system:index', pathway))
              .select(bandRates)
          var timeSeriesRatesResults = ee.ImageCollection(timeSeriesCollRates).map(function(im) {
              var value = ee.Dictionary(ee.Image(im).reduceRegion({
                  reducer: ee.Reducer.mean(),
                  geometry: geomPoint,
                  scale: 1000,
              })).map(function(key,val){return ee.Number(val).divide(10)})
              .values()
              var valsOut=ee.Algorithms.If(ee.List(value).size().gt(1),
                                            ee.List([value.get(1),value.get(0),value.get(2)]),
                                            ee.List([value.get(0)]))
              var featStart = ee.Feature(null).set('row',ee.List(valsOut))
                                              .set('year',ee.Number.parse(ee.Date(ee.Image(im).get('system:time_start')).format('YYYY')))
              return ee.Feature(featStart)
              // var featEnd=ee.Feature(null).set('SL',value,
              //                                   'system:time_start',ee.Image(im).get('system:time_end'))
              // return ee.FeatureCollection([featStart,featEnd])
          }).sort('system:time_start')
          //create table headers
          var columnHeader
          if(uncLogical===true){
            columnHeader=ee.List([[
                                    //{label: 'year', role: 'domain'},
                                    {label: ee.String(pathway), role: 'data'},
                                    {label: ee.String(pathway).cat(' 18.7%ile'), role: 'interval'},
                                    {label: ee.String(pathway).cat(' 83.3%ile'), role: 'interval'}
                                  ]]);
          } else {
            columnHeader=ee.List([[
                                    {label: ee.String(pathway), role: 'data'},
                                  ]]);
          }
          //get results of RATES into a table format
          var timeSeriesRatesResultsTable=ee.FeatureCollection(timeSeriesRatesResults).aggregate_array('row')
          //append headers to data table
          var dataTableServerRates = columnHeader.cat(timeSeriesRatesResultsTable);
          return ee.List(dataTableServerRates)
        })
        //create year list (domain) for plotting - HARD CODED
        var yearList=ee.List([{label: 'year', role: 'domain'}]).cat(ee.List.sequence(2020,2150,10))
        //map over all results to get into a single table
        var listNum=ee.List.sequence(0,ee.Number(ee.List(totalResultsRatesOut.get(0)).size()).subtract(1))
        var tableListRates
        if(pathwayList.length==5){
          tableListRates=ee.List(listNum).map(function(ind){
            return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsRatesOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsRatesOut.get(1)).get(ind)))
                    .cat(ee.List(ee.List(totalResultsRatesOut.get(2)).get(ind))).cat(ee.List(ee.List(totalResultsRatesOut.get(3)).get(ind)))
                    .cat(ee.List(ee.List(totalResultsRatesOut.get(4)).get(ind)))
          })
        } else if(pathwayList.length==4){
          tableListRates=ee.List(listNum).map(function(ind){
            return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsRatesOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsRatesOut.get(1)).get(ind)))
                    .cat(ee.List(ee.List(totalResultsRatesOut.get(2)).get(ind))).cat(ee.List(ee.List(totalResultsRatesOut.get(3)).get(ind)))
          })
        } else if (pathwayList.length==3){
          tableListRates=ee.List(listNum).map(function(ind){
            return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsRatesOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsRatesOut.get(1)).get(ind)))
                    .cat(ee.List(ee.List(totalResultsRatesOut.get(2)).get(ind)))
          })
        } else if (pathwayList.length==2){
          tableListRates=ee.List(listNum).map(function(ind){
            return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsRatesOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsRatesOut.get(1)).get(ind)))
          })
        } else if (pathwayList.length==1){
          tableListRates=ee.List(listNum).map(function(ind){
            return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsRatesOut.get(0)).get(ind)))
          })
        } 
        //Get SLC contributions breakdown
        var subString=bandString.slice(bandString.indexOf('_'))
        if(uncLogical===true){
          bands=[['AIS_values_quantile_0_5','AIS_values_quantile_0_167','AIS_values_quantile_0_833'],
                    ['GIS_values_quantile_0_5','GIS_values_quantile_0_167','GIS_values_quantile_0_833'],
                    ['glaciers_values_quantile_0_5','glaciers_values_quantile_0_167','glaciers_values_quantile_0_833'],
                    ['landwaterstorage_values_quantile_0_5','landwaterstorage_values_quantile_0_167','landwaterstorage_values_quantile_0_833'],
                    ['oceandynamics_values_quantile_0_5','oceandynamics_values_quantile_0_167','oceandynamics_values_quantile_0_833'],
                    ['verticallandmotion_values_quantile_0_5','verticallandmotion_values_quantile_0_167','verticallandmotion_values_quantile_0_833']];
          //bandRates=[bandStringShort+'_rates_quantile_0_5',bandStringShort+'_rates_quantile_0_167',bandStringShort+'_rates_quantile_0_833']
        } else {
          var bands=[['AIS_values_quantile_0_5'],
                ['GIS_values_quantile_0_5'],
                ['glaciers_values_quantile_0_5'],
                ['landwaterstorage_values_quantile_0_5'],
                ['oceandynamics_values_quantile_0_5'],
                ['verticallandmotion_values_quantile_0_5']];
          // bandVals=[bandStringShort+'_values_quantile_0_5']
          // bandRates=[bandStringShort+'_rates_quantile_0_5']
        }
        // var bands=['AIS'+subString, 
        //             'GIS'+subString, 
        //             'glaciers'+subString,
        //             'landwaterstorage'+subString, 
        //             'oceandynamics'+subString, 
        //             'verticallandmotion'+subString
        //           ]
        //get sea level SUM curves for each pathway
        var indivContribution=ee.List(bands).map(function(bandIn){
          var totalResultsContributionsOut=ee.List(pathways).map(function(pathway){
            var breakdownTimeSeriesColl = ee.ImageCollection("IPCC/AR6/SLP")
                .filter(ee.Filter.stringStartsWith('system:index', pathway))
                .select(bandIn)
            var breakdownTimeSeries = ee.ImageCollection(breakdownTimeSeriesColl).map(function(im) {
                var value = ee.List(ee.Dictionary(ee.Image(im).reduceRegion({
                    reducer: ee.Reducer.mean(),
                    geometry: geomPoint,
                    scale: 1000,
                })).map(function(key,val){return ee.Number(val).divide(1000)})
              .values())
              var valsOut=ee.Algorithms.If(ee.List(value).size().gt(1),
                                            ee.List([value.get(1),value.get(0),value.get(2)]),
                                            ee.List([value.get(0)]))
              var featStart = ee.Feature(null).set('row',ee.List(valsOut))
                                              .set('year',ee.Number.parse(ee.Date(ee.Image(im).get('system:time_start')).format('YYYY')))
                // var featEnd=ee.Feature(null).set('SL',value,
                //                                   'system:time_start',ee.Image(im).get('system:time_end'))
                // return ee.FeatureCollection([featStart,featEnd])
              return ee.Feature(featStart)
            }).sort('system:time_start')
            //get results of contribution into a table format
            var timeSeriesContributionResultsTable=ee.FeatureCollection(breakdownTimeSeries).aggregate_array('row')
            //create table headers
            var columnHeader
            if(uncLogical===true){
              columnHeader=ee.List([[
                                      //{label: 'year', role: 'domain'},
                                      {label: ee.String(pathway), role: 'data'},
                                      {label: ee.String(pathway).cat(' 18.7%ile'), role: 'interval'},
                                      {label: ee.String(pathway).cat(' 83.3%ile'), role: 'interval'}
                                    ]]);
            } else {
              columnHeader=ee.List([[
                                      {label: ee.String(pathway), role: 'data'},
                                    ]]);
            }
            //append headers to data table
            var dataTableServerContributions = columnHeader.cat(timeSeriesContributionResultsTable);
            return ee.List(dataTableServerContributions)
          })
          //map over all results to get into a single table
          var yearList=ee.List([{label: 'year', role: 'domain'}]).cat(ee.List.sequence(2020,2150,10))
          var listNum=ee.List.sequence(0,ee.Number(ee.List(totalResultsContributionsOut.get(0)).size()).subtract(1))
          var tableListContributions
          if(pathwayList.length==5){
            tableListContributions=ee.List(listNum).map(function(ind){
              return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsContributionsOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsContributionsOut.get(1)).get(ind)))
                      .cat(ee.List(ee.List(totalResultsContributionsOut.get(2)).get(ind))).cat(ee.List(ee.List(totalResultsContributionsOut.get(3)).get(ind)))
                      .cat(ee.List(ee.List(totalResultsContributionsOut.get(4)).get(ind)))
            })
          } else if(pathwayList.length==4){
            tableListContributions=ee.List(listNum).map(function(ind){
              return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsContributionsOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsContributionsOut.get(1)).get(ind)))
                      .cat(ee.List(ee.List(totalResultsContributionsOut.get(2)).get(ind))).cat(ee.List(ee.List(totalResultsContributionsOut.get(3)).get(ind)))
            })
          } else if (pathwayList.length==3){
            tableListContributions=ee.List(listNum).map(function(ind){
              return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsContributionsOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsContributionsOut.get(1)).get(ind)))
                      .cat(ee.List(ee.List(totalResultsContributionsOut.get(2)).get(ind)))
            })
          } else if (pathwayList.length==2){
            tableListContributions=ee.List(listNum).map(function(ind){
              return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsContributionsOut.get(0)).get(ind))).cat(ee.List(ee.List(totalResultsContributionsOut.get(1)).get(ind)))
            })
          } else if (pathwayList.length==1){
            tableListContributions=ee.List(listNum).map(function(ind){
              return ee.List(ee.List([ee.List(yearList).get(ind)]).cat(ee.List(totalResultsContributionsOut.get(0)).get(ind)))
            })
          } 
          return ee.List(tableListContributions)
        })
        // var timeline=ee.Feature(null).set('time',ee.Image(mapImage).get('SLC'),
        //                         'system:time_start',
        //                         ee.Date(ee.Image(mapImage).get('system:time_start')).advance(5,'year').millis())
        // ee.List([tableListSum,tableListRates,indivContribution]).evaluate(function(tableResults) {
        ee.List([tableListSum]).evaluate(function(tableResults) {
          print(tableResults)
          if(tableResults!==undefined){
            mainPanel.remove(loadingMsg1)
            var chartSum=ui.Chart(tableResults[0]).setChartType('LineChart')
                          .setOptions({intervals:{style:'area'},
                                       series: lineColours,
                                       title: 'Overall sea level change (m) at '+String(Math.round(coords.lat*100)/100)+'N '+String(Math.round(coords.lon*100)/100)+'W ',
                                       hAxis:{title:'Year',
                                              format:'####',
                                              viewWindow: {min: 2020, 
                                                           max: 2150
                                              }},
                                       vAxis:{title:'Projected change (m)'},
                                      }).setDownloadable(true)
            mainPanel.insert(9,chartSum)
          } else {
          var memoryLabelError=ui.Label({value:'Whoops! We ran into an error! Please wait a few seconds and try again...',
                                        style:{fontSize: '20px',
                                              textAlign: 'left',
                                              stretch: 'horizontal',
                                              fontWeight: 'bold'}
                                        })
          mainPanel.add(memoryLabelError)
          }//end if
        })
        ee.List([tableListRates]).evaluate(function(tableResults1) {
          if(tableResults1!==undefined){
            mainPanel.remove(loadingMsg2)
            var chartRates=ui.Chart(tableResults1[0]).setChartType('LineChart')
                          .setOptions({intervals:{style:'area'},
                                       series: lineColours,
                                       title: 'Rate of sea level change (cm/yr) at '+String(Math.round(coords.lat*100)/100)+'N '+String(Math.round(coords.lon*100)/100)+'W ',
                                       hAxis:{title:'Year',
                                              format:'####',
                                              viewWindow: {min: 2020, 
                                                           max: 2150
                                              }},
                                       vAxis:{title:'Projected rate of change (cm/yr)'}
                                      }).setDownloadable(true)
            mainPanel.insert(10,chartRates)
          } else {
            var memoryLabelError=ui.Label({value:'Whoops! We ran into an error! Please wait a few seconds and try again...',
                                          style:{fontSize: '20px',
                                                textAlign: 'left',
                                                stretch: 'horizontal',
                                                fontWeight: 'bold'}
                                          })
            mainPanel.add(memoryLabelError)
          }
        })
        ee.List(indivContribution).evaluate(function(tableResults2) {  
          if(tableResults2!==undefined){
            //Add breakdown of contributions to panel
            var contributionLabel=ui.Label({value:'Breakdown of total sea level contributions:',
                                        style:{fontSize: '14px',
                                              textAlign: 'left',
                                              stretch: 'horizontal',
                                              fontWeight: 'bold'}
                                        })
            mainPanel.insert(11,contributionLabel)
            var chartAnt=ui.Chart(tableResults2[0]).setChartType('LineChart')
                          .setOptions({intervals:{style:'area'},
                                       series: lineColours,
                                       title: 'Antarctica contribution (m) at '+String(Math.round(coords.lat*100)/100)+'N '+String(Math.round(coords.lon*100)/100)+'W ',
                                       hAxis:{title:'Year',
                                              format:'####',
                                              viewWindow: {min: 2020, 
                                                           max: 2150
                                              }},
                                       vAxis:{title:'Projected sea level change (m)'}
                                      }).setDownloadable(true)
            plotSubSubPanel.insert(0,chartAnt)
            var chartGris=ui.Chart(tableResults2[1]).setChartType('LineChart')
                            .setOptions({intervals:{style:'area'},
                                         series: lineColours,
                                         title: 'Greenland contribution (m) at '+String(Math.round(coords.lat*100)/100)+'N '+String(Math.round(coords.lon*100)/100)+'W ',
                                         hAxis:{title:'Year',
                                                format:'####',
                                                viewWindow: {min: 2020, 
                                                             max: 2150
                                                }},
                                         vAxis:{title:'Projected sea level change (m)'}
                                        }).setDownloadable(true)
              plotSubSubPanel1.insert(0,chartGris)
            var chartGlac=ui.Chart(tableResults2[2]).setChartType('LineChart')
                            .setOptions({intervals:{style:'area'},
                                         series: lineColours,
                                         title: 'Glacier contribution (m) at '+String(Math.round(coords.lat*100)/100)+'N '+String(Math.round(coords.lon*100)/100)+'W ',
                                         hAxis:{title:'Year',
                                                format:'####',
                                                viewWindow: {min: 2020, 
                                                             max: 2150
                                                }},
                                         vAxis:{title:'Projected sea level change (m)'}
                                        }).setDownloadable(true)
              plotSubSubPanel.insert(1,chartGlac)
            var chartLandWater=ui.Chart(tableResults2[3]).setChartType('LineChart')
                            .setOptions({intervals:{style:'area'},
                                         series: lineColours,
                                         title: 'Land water contribution (m) at '+String(Math.round(coords.lat*100)/100)+'N '+String(Math.round(coords.lon*100)/100)+'W ',
                                         hAxis:{title:'Year',
                                                format:'####',
                                                viewWindow: {min: 2020, 
                                                             max: 2150
                                                }},
                                         vAxis:{title:'Projected sea level change (m)'}
                                        }).setDownloadable(true)
              plotSubSubPanel1.insert(1,chartLandWater)
            var chartOcean=ui.Chart(tableResults2[4]).setChartType('LineChart')
                            .setOptions({intervals:{style:'area'},
                                         series: lineColours,
                                         title: 'Ocean circulation & thermal expansion contribution (m) at '+String(Math.round(coords.lat*100)/100)+'N '+String(Math.round(coords.lon*100)/100)+'W ',
                                         hAxis:{title:'Year',
                                                format:'####',
                                                viewWindow: {min: 2020, 
                                                             max: 2150
                                                }},
                                         vAxis:{title:'Projected sea level change (m)'}
                                        }).setDownloadable(true)
              plotSubSubPanel.insert(2,chartOcean)
            var chartLandMotion=ui.Chart(tableResults2[5]).setChartType('LineChart')
                            .setOptions({intervals:{style:'area'},
                                         series: lineColours,
                                         title: 'Vertical land motion contribution (m) at '+String(Math.round(coords.lat*100)/100)+'N '+String(Math.round(coords.lon*100)/100)+'W ',
                                         hAxis:{title:'Year',
                                                format:'####',
                                                viewWindow: {min: 2020, 
                                                             max: 2150
                                                }},
                                         vAxis:{title:'Projected sea level change (m)'}
                                        }).setDownloadable(true)
              plotSubSubPanel1.insert(2,chartLandMotion)
            mainPanel.remove(loadingMsg3)
            mainPanel.insert(12,plotSubPanel)
            while (mainPanel.widgets().length() > 13) {
                mainPanel.remove(mainPanel.widgets().get(mainPanel.widgets().length()-1))
            }
            while (plotSubSubPanel1.widgets().length() > 3) {
                plotSubSubPanel1.remove(plotSubSubPanel1.widgets().get(plotSubSubPanel1.widgets().length()-1))
            }
            while (plotSubSubPanel.widgets().length() > 3) {
                plotSubSubPanel.remove(plotSubSubPanel.widgets().get(plotSubSubPanel.widgets().length()-1))
            }
        } else {
          var memoryLabelError=ui.Label({value:'Whoops! We ran into an error! Please wait a few seconds and try again...',
                                        style:{fontSize: '20px',
                                              textAlign: 'left',
                                              stretch: 'horizontal',
                                              fontWeight: 'bold'}
                                        })
          mainPanel.add(memoryLabelError)
        }//end if
        })
        //var chart = ui.Chart.feature.byFeature(timeSeriesResults, 'system:time_start')
        //    .setOptions({
        //        title: pathwaySelect.getValue() + ' - ' + typeSelectValue + ' - ' + rateOrTotal.getValue(),
        //        vAxis:{title:'Sea level change (m)'},
        //        hAxis:{title:'Year'},
        //        legend:'right'
        //    })
        //var chart1 = ui.Chart.feature.byFeature(breakdownTimeSeries, 'system:time_start')
        //    .setOptions({
        //        title: pathwaySelect.getValue() +  ' - ' + 'Sea Level Contributions',
        //        vAxis:{title:'Sea level change (m)'},
        //        hAxis:{title:'Year'},
        //        isStacked:'percentage',
        //    }).setChartType('AreaChart')
       // mainPanel.add(chart1)
    }
    //})
}
//start main script
var restartScript = function() {
    Map.clear();
    //Map.add(clearMapPanel);
    var geometry;
    var drawingTools = Map.drawingTools();
    drawingTools.layers().reset();
    drawingTools.clear();
    drawingTools.setShown(false);
    //get screen info
    ui.root.onResize(function(screenInfo){
      print(screenInfo)
      print(screenInfo.is_landscape)
      var screenHeight=ee.String(ee.Number(screenInfo.height)).cat('px')
      var screenWidth=ee.String(ee.Number(screenInfo.width)).cat(' px')
      //Sets up main menu panel
      if (ui.root.widgets().length() === 2) {
          ui.root.remove(ui.root.widgets().get(0)); //adds panel to root (*not* Map)
      }
      var mainPanel
      if(screenInfo.is_landscape===true){
        ui.root.setLayout(ui.Panel.Layout.flow('horizontal'))
        mainPanel = ui.Panel({
            style: {height:String(Number(screenInfo.height)*0.9)+'px',
                width: String(Number(screenInfo.width/2))+'px',
                position: 'top-center'
            }
        });
        ui.root.insert(0, mainPanel);
      } else {
        ui.root.setLayout(ui.Panel.Layout.flow('vertical'))
        mainPanel = ui.Panel({
            style: {height:String(Number(screenInfo.height)/3)+'px',
                width: String(Number(screenInfo.width))+'px',
                position: 'top-center'
            }
        });
        ui.root.insert(1, mainPanel);
      }
      //Add labels
      Map.setOptions("SATELLITE");
      Map.style().set('cursor', 'crosshair');
      Map.setControlVisibility({layerList:false, mapTypeControl:false, fullscreenControl:false, zoomControl:true,drawingToolsControl:false})
      Map.setCenter(0, 30, 1.75);
      //Map visualisation options
      var labelSuffix = '_quantile_'
      var mapOptionsPanel = ui.Panel({
          style: {
              position: 'top-right'
          }
      })
      var mapGoButton = ui.Button({
          label: 'Visualise',
          style: {
              stretch: 'horizontal'
          }
      })
      var pathwayLabel = ui.Label({
          value: 'Select emission pathway:',
          style: {
              margin: '1px 10px 1px 10px',
              fontSize: '12px',
              textAlign: 'left',
              stretch: 'horizontal',
              fontWeight: 'bold'
          }
      });
      var pathwaySelect = ui.Select({
          items: ['SSP1-1.9 (low emission)',
              'SSP1-2.6 (low emission)',
              'SSP2-4.5 (medium emission)',
              'SSP3-7.0 (med-high emission)',
              'SSP5-8.5 (high emission)'
          ],
          value: 'SSP2-4.5 (medium emission)',
          style: {
              stretch: 'horizontal'
          }
      })
      var pathwayValue = 'ssp245'
      pathwaySelect.onChange(function() {
          if (pathwaySelect.getValue() === 'SSP1-1.9 (low emission)') {
              pathwayValue = 'ssp119'
          } else if (pathwaySelect.getValue() === 'SSP1-2.6 (low emission)') {
              pathwayValue = 'ssp126'
          } else if (pathwaySelect.getValue() === 'SSP2-4.5 (medium emission)') {
              pathwayValue = 'ssp245'
          } else if (pathwaySelect.getValue() === 'SSP3-7.0 (med-high emission)') {
              pathwayValue = 'ssp370'
          } else if (pathwaySelect.getValue() === 'SSP5-8.5 (high emission)') {
              pathwayValue = 'ssp585'
          }
          Map.unlisten()
      })
      var decadeLabel = ui.Label({
          value: 'Select decade:',
          style: {
              margin: '1px 10px 1px 10px',
              fontSize: '12px',
              textAlign: 'left',
              stretch: 'horizontal',
              fontWeight: 'bold'
          }
      })
      var decadeSelect = ui.Select({
          items: ['2020-2030',
              '2030-2040',
              '2040-2050',
              '2050-2060',
              '2060-2070',
              '2070-2080',
              '2080-2090',
              '2090-2100',
              '2100-2110',
              '2110-2120',
              '2120-2130',
              '2130-2140',
              '2140-2150',
              '2150-2160'
          ],
          value: '2090-2100',
          style: {
              stretch: 'horizontal'
          }
      })
      decadeSelect.onChange(function() {
          Map.unlisten()
      })
      var typeLabel = ui.Label({
          value: 'Select contribution option:',
          style: {
              margin: '1px 10px 1px 10px',
              fontSize: '12px',
              textAlign: 'left',
              stretch: 'horizontal',
              fontWeight: 'bold'
          }
      })
      var typeSelect = ui.Select({
          items: ['Total', 'Antarctica', 'Greenland', 'Glaciers',
              'Land water', 'Ocean dynamics', 'Vertical land motion'
          ],
          value: 'Total',
          style: {
              stretch: 'horizontal'
          }
      })
      typeSelect.onChange(function() {
          Map.unlisten()
      })
      var rateOrTotalLabel = ui.Label({
          value: 'View OVERALL or RATE of change:',
          style: {
              margin: '1px 10px 1px 10px',
              fontSize: '12px',
              textAlign: 'left',
              stretch: 'horizontal',
              fontWeight: 'bold'
          }
      })
      var rateOrTotal = ui.Select({
          items: ['Overall change (m)', 'Rate of change (mm/yr)'],
          value: 'Overall change (m)',
          style: {
              stretch: 'horizontal'
          }
      })
      rateOrTotal.onChange(function() {
          Map.unlisten()
      })
      var mapPercentileLabel = ui.Label({
          value: 'Low/mid/high (0-100)',
          style: {
              margin: '1px 10px 1px 10px',
              fontSize: '12px',
              textAlign: 'left',
              stretch: 'horizontal',
              fontWeight: 'bold'
          }
      })
      var mapPercentile = ui.Textbox({
          value: 50
      })
      var mapPcValue
      mapPercentile.onChange(function() {
          Map.unlisten()
          mapPcValue = mapPercentile.getValue()
          if (mapPcValue < 0 || mapPcValue > 100 || isNaN(mapPcValue)) {
              mapPercentile.setValue(50)
          }
          // if(((mapPcValue/100).countDecimals()>2&&mapPcValue!==16.7)
          //   ||((mapPcValue/100).countDecimals()>2&&mapPcValue!==83.3)
          //   ||((mapPcValue/100).countDecimals()>2&&mapPcValue!==0.5)
          //   ||((mapPcValue/100).countDecimals()>2&&mapPcValue!==0.1)
          //   ||((mapPcValue/100).countDecimals()>2&&mapPcValue!==0.5)
          //   ||((mapPcValue/100).countDecimals()>2&&mapPcValue!==99.5)
          //   ||((mapPcValue/100).countDecimals()>2&&mapPcValue!==99.9)
          //   ){
          //     mapPercentile.setValue(50)
          // }
          Map.unlisten()
      })
      mapOptionsPanel.add(pathwayLabel).add(pathwaySelect)
          .add(typeLabel).add(typeSelect)
          .add(decadeLabel).add(decadeSelect)
          .add(rateOrTotalLabel).add(rateOrTotal)
          .add(mapPercentileLabel).add(mapPercentile)
          .add(mapGoButton)
      //Map.add(mapOptionsPanel)
      if (Map.layers().length() === 0) {
          var openingImage = ee.Image(ee.ImageCollection("IPCC/AR6/SLP")
                  .filter(ee.Filter.stringStartsWith('system:index', 'ssp245'))
                  .filterDate('2099-01-01', '2105-01-01').aside(print).first())
              .select('total_values_quantile_0_5')
              .updateMask(landMask)
              .rename('SLC').divide(1000)
          makeColourBar({
              min: -1,
              max: 1,
              palette: ['blue', 'white', 'red']
          }, 'Overall')
          Map.addLayer(openingImage, {
              min: -1,
              max: 1,
              palette: ['blue', 'white', 'red']
          })
          //var pathwayList=ee.List(['ssp119','ssp126','ssp245','ssp370','ssp585'])
          //showChart('ssp245', pathwaySelect, pathwayList, 'total_values_quantile_0_5','total', mainPanel)
      }
      //map visualisation
      mapGoButton.onClick(function() {
          //clean up map and any existing panel plots
          while (Map.layers().length() > 0) {
              Map.remove(Map.layers().get(0));
          }
          if (mainPanel.widgets().length() > 9) {
              mainPanel.remove(mainPanel.widgets().get(mainPanel.widgets().length()-1))
          }
          var rateTotalString = ''
          var contributionString = ''
          //Get strings for construction of band name
          if (rateOrTotal.getValue() === 'Overall change (m)') {
              rateTotalString = '_values_quantile_'
          } else {
              rateTotalString = '_rates_quantile_'
          }
          var typeSelectValue = typeSelect.getValue()
          if (typeSelectValue === 'Total') {
              contributionString = 'total'
          } else if (typeSelectValue === 'Antarctica') {
              contributionString = 'AIS'
          } else if (typeSelectValue === 'Greenland') {
              contributionString = 'GIS'
          } else if (typeSelectValue === 'Glaciers') {
              contributionString = 'glaciers'
          } else if (typeSelectValue === 'Land water') {
              contributionString = 'landwaterstorage'
          } else if (typeSelectValue === 'Ocean dynamics') {
              contributionString = 'oceandynamics'
          } else if (typeSelectValue === 'Vertical land motion') {
              contributionString = 'verticallandmotion'
          }
          var percentileString = ((mapPercentile.getValue() / 100).toString()).replace(".", '_')
          var bandString = contributionString + rateTotalString + percentileString
          var bandStringShort=contributionString
          var mapDateStart = ee.Date.fromYMD((+(decadeSelect.getValue()).substring(0, 4)) - 1, 1, 1)
          var mapDateEnd = ee.Date.fromYMD((+(decadeSelect.getValue()).substring(0, 4)) + 5, 1, 1)
          var mapImage = ee.Image(ee.ImageCollection("IPCC/AR6/SLP")
                  .filter(ee.Filter.stringStartsWith('system:index', pathwayValue))
                  .filterDate(mapDateStart, mapDateEnd).first())
              .select(bandString)
              .updateMask(landMask)
              .rename('SLC')
          if (rateOrTotal.getValue() === 'Overall change (m)') {
              mapImage = mapImage.divide(1000)
          }
          //get range for colormap
          ee.List(ee.Image(mapImage).reduceRegion({
                  geometry: ee.Geometry.Polygon(ee.List([
                      [-180, -89.95],
                      [180, -89.95],
                      [180, 89.95],
                      [-180, 89.95],
                      [-180, -89.95]
                  ]), null, false),
                  scale: 50000,
                  reducer: ee.Reducer.percentile([5, 95])
              }).values()).map(function(num) {
                  return ee.Number(num).abs()
              }).reduce(ee.Reducer.max())
              .evaluate(function(result) {
                  var result1 = Math.round(result * 100) / 100
                  if (typeSelectValue !== 'Total') {
                      if (result1 < 0.25) {
                          result1 = 0.25
                      } else if (result1 < 0.5) {
                          result1 = 0.5
                      } else if (result1 < 0.75) {
                          result1 = 0.75
                      }
                  } else if (result1 < 1) {
                      result1 = 1
                  }
                  var visOpts
                  var colourBarOption
                  if (rateOrTotal.getValue() === 'Overall change (m)') {
                      colourBarOption = 'overall'
                      visOpts = {
                          min: -result1,
                          max: result1,
                          palette: ['blue', 'white', 'red']
                      }
                  } else {
                      visOpts = {
                          min: -result1,
                          max: result1,
                          palette: ['blue', 'white', 'red']
                      }
                      colourBarOption = 'rate'
                  }
                  makeColourBar(visOpts, colourBarOption)
                  Map.addLayer(mapImage, visOpts)
                  //var pathwayList=ee.List(['ssp119','ssp126','ssp245','ssp370','ssp585'])
                  //showChart(pathwayValue, pathwaySelect, pathwayList, bandString, bandStringShort, mainPanel)
              })
      })
      //Set up panel labels and options
      var welcomeTitle = ui.Label({
          value: 'IPCC Sea Level Projections',
          style: {
              margin: '1px 10px 1px 10px',
              fontSize: '20px',
              fontWeight: 'bold',
              textAlign: 'center',
              stretch: 'horizontal'
          }
      });
      var welcomeSubtitle = ui.Label({
          value: 'James M. Lea, University of Liverpool',
          style: {
              margin: '1px 10px 1px 10px',
              fontSize: '12px',
              textAlign: 'center',
              stretch: 'horizontal'
          }
      });
      var welcomeSubtitle1a = ui.Label({
          value: 'For educational and research purposes only.',
          style: {
              margin: '1px 10px 1px 10px',
              fontSize: '12px',
              fontWeight: 'bold',
              textAlign: 'center',
              stretch: 'horizontal'
          }
      });
      var welcomeSubtitle1b = ui.Label({
          value: 'For commercial applications or other uses, contact below.',
          style: {
              margin: '1px 10px 1px 10px',
              fontSize: '12px',
              fontWeight: 'bold',
              textAlign: 'center',
              stretch: 'horizontal'
          }
      });
      var welcomeSubtitle1 = ui.Label({
          value: 'Bluesky: @JamesMLea.bsky.social',
          style: {
              margin: '1px 10px 1px 10px',
              textAlign: 'center',
              stretch: 'horizontal',
              fontWeight: 'bold',
              fontSize: '12px',
              color: 'blue'
          }
      }).setUrl('https://bsky.app/profile/jamesmlea.bsky.social');
      var welcomeSubtitle2 = ui.Label({
          value: "How much sea level around the world will change isn't just a matter of how much water is in the ocean. The amount sea level will rise (or in some areas drop) over the coming century is affected by the melting of glaciers and ice sheets, small variations in gravity around the world, the circulation and warmth of the oceans, the thickness of the Earth's crust and what's going on underneath, and even hangover effects of how big ice sheets were during the last ice age.",
          style: {
              margin: '10px 10px 1px 10px',
              textAlign: 'center',
              stretch: 'horizontal',
              fontSize: '14px',
              fontStyle: 'italic'
          }})
      var welcomeSubtitle2a = ui.Label({
          value: "This tool allows you to explore the IPCC 6th Assessment Report projections for how sea level will change between 2020 and 2150 for anywhere on the planet. The results provided are from global scale projections, and for coastal regions local factors such as tides, the shape of the sea floor and coastline may exacerbate or mitigate the numbers reported.",
          style: {
              margin: '10px 10px 10px 10px',
              textAlign: 'center',
              stretch: 'horizontal',
              fontSize: '14px'
          }})
      var welcomeSubtitle3 = ui.Label({
          value: 'Getting started: Click on map to see sea level projection at that location',
          style: {
              margin: '10px 10px 1px 10px',
             // textAlign: 'center',
              stretch: 'horizontal',
              fontWeight: 'bold',
              //fontSize: '12px',
              color: 'black'
          }})
      var welcomeSubtitle4 = ui.Label({
          value: 'Click on another point on the map or explore more about this location:',
          style: {
              margin: '10px 10px 1px 10px',
             // textAlign: 'center',
              stretch: 'horizontal',
              fontWeight: 'bold',
              //fontSize: '12px',
              color: 'black'
          }})
      mainPanel.add(welcomeTitle).add(welcomeSubtitle).add(welcomeSubtitle1).add(welcomeSubtitle2).add(welcomeSubtitle2a).add(welcomeSubtitle3)
      //Map panel conditional on mobile or desktop
      var mapPanel
      var mapPanelLabel
      var mapPanelLabel1
      ui.root.onResize(function(screenInfo){
        print(screenInfo,'check')
        if(screenInfo.is_desktop===true || screenInfo.is_tablet===true){
          mapPanel = ui.Panel({style:{stretch:'horizontal',position: 'top-center'}}).setLayout(ui.Panel.Layout.flow('vertical'));
          mapPanelLabel=ui.Label({value:'Global sea level change in 2100 for SSP2-4.5 (medium emissions scenario)',
                                      style: {
                  margin: '1px 1px 1px 1px',
                  textAlign: 'center',
                  stretch: 'horizontal',
                  fontWeight: 'bold',
                  fontSize: '14px',
                  color: 'black'
              }})
          mapPanelLabel1=ui.Label({value:'Click on map to explore sea level projections for 2020-2150 for different IPCC emissions scenarios',
                                      style: {
                  margin: '1px 1px 1px 1px',
                  textAlign: 'center',
                  stretch: 'horizontal',
                  //fontWeight: 'bold',
                  fontSize: '10px',
                  color: 'black'
              }})
          mapPanel.add(mapPanelLabel).add(mapPanelLabel1)
          Map.add(mapPanel)
        } else if (screenInfo.is_mobile){
          mapPanel = ui.Panel({style:{stretch:'horizontal',position: 'top-center'}}).setLayout(ui.Panel.Layout.flow('vertical'));
          mapPanelLabel=ui.Label({value:'Global sea level change in 2100 for SSP2-4.5 (medium emissions scenario)',
                                      style: {
                  margin: '1px 1px 1px 1px',
                  textAlign: 'center',
                  stretch: 'horizontal',
                  fontWeight: 'bold',
                  fontSize: '10px',
                  color: 'black'
              }})
          mapPanelLabel1=ui.Label({value:'Click on map to explore sea level projections for 2020-2150 for different IPCC emissions scenarios',
                                      style: {
                  margin: '1px 1px 1px 1px',
                  textAlign: 'center',
                  stretch: 'horizontal',
                  //fontWeight: 'bold',
                  fontSize: '10px',
                  color: 'black'
              }})
          mapPanel.add(mapPanelLabel).add(mapPanelLabel1)
          Map.add(mapPanel)
        } //end if
      }) //end screen check
      // .add(welcomeSubtitle1a).add(welcomeSubtitle1b)
      //Set up menu options
      var pathwaySubPanel = ui.Panel({style:{stretch:'horizontal'}}).setLayout(ui.Panel.Layout.flow('horizontal'));
      var pathwaySubSubPanel = ui.Panel({style:{stretch:'horizontal'}}).setLayout(ui.Panel.Layout.flow('vertical'));
      var pathwaySubSubPanel1 = ui.Panel({style:{stretch:'horizontal'}}).setLayout(ui.Panel.Layout.flow('vertical'));
      var ssp119Check=ui.Checkbox({label:'SSP1-1.9 (low emission)',value:true, disabled:false});
      var ssp126Check=ui.Checkbox({label:'SSP1-2.6 (low emission)',value:true, disabled:false});
      var ssp445Check=ui.Checkbox({label:'SSP2-4.5 (medium emission)',value:true, disabled:false});
      var ssp370Check=ui.Checkbox({label:'SSP3-7.0 (medium to high emission)',value:true, disabled:false});
      var ssp585Check=ui.Checkbox({label:'SSP5-8.5 (high emission)',value:true, disabled:false})
      var showUncertaintiesCheck=ui.Checkbox({label:'Show uncertainties (Tip: select no more than 2 SSPs)',value:false, disabled:false})
      var updatePlotsButton=ui.Button({label:'Update plots',style:{stretch:'horizontal'}})
      var pathwaySubPanelLabel=ui.Label({value:'Select which IPCC Shared Socioeconomic Pathways (SSPs) to show:',style:{fontWeight:'bold'}});
      pathwaySubSubPanel.add(ssp119Check).add(ssp126Check).add(ssp445Check)
      pathwaySubSubPanel1.add(ssp370Check).add(ssp585Check).add(showUncertaintiesCheck)
      pathwaySubPanel.add(pathwaySubSubPanel).add(pathwaySubSubPanel1)
      //mainPanel.add(pathwaySubPanelLabel).add(pathwaySubPanel).add(updatePlotsButton)
      //set up plot subpanels
      var plotSubPanel = ui.Panel({style:{stretch:'horizontal'}}).setLayout(ui.Panel.Layout.flow('horizontal'));
      var plotSubSubPanel = ui.Panel({style:{stretch:'horizontal'}}).setLayout(ui.Panel.Layout.flow('vertical'));
      var plotSubSubPanel1 = ui.Panel({style:{stretch:'horizontal'}}).setLayout(ui.Panel.Layout.flow('vertical'));
      plotSubPanel.add(plotSubSubPanel).add(plotSubSubPanel1)
      var coordsIn
      var pathwayList=['ssp119','ssp126','ssp245','ssp370','ssp585']
      //IPCC colour schemes obtained from: https://www.ipcc.ch/site/assets/uploads/2022/09/IPCC_AR6_WGI_VisualStyleGuide_2022.pdf
      var lineColours={0: { pathway:'ssp119',color: '#00ADCF' },
                        1: { pathway:'ssp126',color: '#173C66' },
                        2: { pathway:'ssp245',color: '#F79420' },
                        3: { pathway:'ssp370',color: '#E7271B' },
                        4: { pathway:'ssp585',color: '#951B1E' }}
      var ind
      var flag=1
      ssp119Check.onChange(function(){
        if(ssp119Check.getValue()===true){
          pathwayList=pathwayList.concat('ssp119').sort()
          flag=1
        } else {
          ind=pathwayList.indexOf('ssp119')
          pathwayList=pathwayList.slice(0,ind).concat(pathwayList.slice(ind+1,8)).sort()
          flag=1
        }
        return pathwayList
      })
      ssp126Check.onChange(function(){
        if(ssp126Check.getValue()===true){
          pathwayList=pathwayList.concat('ssp126').sort()
          flag=1
        } else {
          ind=pathwayList.indexOf('ssp126')
          pathwayList=pathwayList.slice(0,ind).concat(pathwayList.slice(ind+1,8)).sort()
          flag=1
        }
        return pathwayList
      })
      ssp445Check.onChange(function(){
        if(ssp445Check.getValue()===true){
          pathwayList=pathwayList.concat('ssp245').sort()
          flag=1
        } else {
          ind=pathwayList.indexOf('ssp245')
          pathwayList=pathwayList.slice(0,ind).concat(pathwayList.slice(ind+1,8)).sort()
          flag=1
        }
        return pathwayList
      })
      ssp370Check.onChange(function(){
        if(ssp370Check.getValue()===true){
          pathwayList=pathwayList.concat('ssp370').sort()
          flag=1
        } else {
          ind=pathwayList.indexOf('ssp370')
          pathwayList=pathwayList.slice(0,ind).concat(pathwayList.slice(ind+1,8)).sort()
          flag=1
        }
        return pathwayList
      })
      ssp585Check.onChange(function(){
        if(ssp585Check.getValue()===true){
          pathwayList=pathwayList.concat('ssp585').sort()
          flag=1
        } else {
          ind=pathwayList.indexOf('ssp585')
          pathwayList=pathwayList.slice(0,ind).concat(pathwayList.slice(ind+1,8)).sort()
          flag=1
        }
        return pathwayList
      })
      showUncertaintiesCheck.onChange(function(){
        flag=1
      })
      var errorFunc=function(){
        while (mainPanel.widgets().length() > 9) {
                  mainPanel.remove(mainPanel.widgets().get(mainPanel.widgets().length()-1))
              }
          var warningLabel=ui.Label({value:'Whoops! You need to select at least one SSP! Please select at least 1 and try again...',
                                     style: {
                                              margin: '30px 10px 1px 10px',
                                              textAlign: 'center',
                                              stretch: 'horizontal',
                                              fontWeight: 'bold',
                                              fontSize: '20px',
                                              color: 'black'
                                          }})
          mainPanel.add(warningLabel)
      }
      var errorFunc1=function(){
        while (mainPanel.widgets().length() > 9) {
                  mainPanel.remove(mainPanel.widgets().get(mainPanel.widgets().length()-1))
              }
          var warningLabel=ui.Label({value:'Whoops! You have clicked a point on land! Please try again...',
                                     style: {
                                              margin: '30px 10px 1px 10px',
                                              textAlign: 'center',
                                              stretch: 'horizontal',
                                              fontWeight: 'bold',
                                              fontSize: '20px',
                                              color: 'black'
                                          }})
          mainPanel.add(warningLabel)
      }
      Map.onClick(function(coords){
        //If mobile, hide description
        ui.root.onResize(function(screenInfo){
          if(screenInfo.is_mobile===true){
            welcomeSubtitle2.style().set({shown:false})
            welcomeSubtitle2a.style().set({shown:false})
          }
        })
        var coordsIn=coords;
        //Temporarily disable checkboxes
        ssp119Check.setDisabled(true)
        ssp126Check.setDisabled(true)
        ssp445Check.setDisabled(true)
        ssp370Check.setDisabled(true)
        ssp585Check.setDisabled(true)
        showUncertaintiesCheck.setDisabled(true)
        //add in options on mainPanel
        if(mainPanel.widgets().length()<8){
          mainPanel.remove(welcomeSubtitle3)
          mainPanel.add(welcomeSubtitle4)
          mainPanel.add(pathwaySubPanelLabel).add(pathwaySubPanel).add(updatePlotsButton)
        }
        var landSeaCheck=ee.Number(ee.Image(openingImage).reduceRegion({
          reducer:ee.Reducer.mean(),
          scale:1000,
          geometry:ee.Geometry.Point([coords.lon,coords.lat])
        }).values().get(0))
        .evaluate(function(boundsCheck){
          if(boundsCheck!==null){
            if(pathwayList.length>0){
              showChart('ssp245', pathwaySelect, pathwayList, 'total_values_quantile_0_5','total', mainPanel,coordsIn,showUncertaintiesCheck.getValue(),
                           plotSubPanel,plotSubSubPanel,plotSubSubPanel1)
            } else {
              errorFunc()
            }
            updatePlotsButton.onClick(function(){
              if(flag==1){
                if(pathwayList.length>0){
                  showChart('ssp245', pathwaySelect, pathwayList, 'total_values_quantile_0_5','total', mainPanel,coordsIn,showUncertaintiesCheck.getValue(),
                           plotSubPanel,plotSubSubPanel,plotSubSubPanel1)
                } else {
                  errorFunc()
                }
              }
              flag=0
            }) 
          } else {
            while (Map.layers().length() > 1) {
                  Map.remove(Map.layers().get(1));
              }
            errorFunc1()
          }
          //Re-enable checkboxes
        //Temporarily disable checkboxes
        ssp119Check.setDisabled(false)
        ssp126Check.setDisabled(false)
        ssp445Check.setDisabled(false)
        ssp370Check.setDisabled(false)
        ssp585Check.setDisabled(false)
        showUncertaintiesCheck.setDisabled(false)
        })  //end evaluate
      })
      var seaLevelOptions = [
          ['Overall sea level change', 'total_values_quantile_'],
          ['Contribution from Antarctica', 'AIS_values_quantile_'],
          ['Contribution from Greenland', 'GIS_values_quantile_'],
          ['Contribution from glaciers', 'glaciers_values_quantile_'],
          ['Contribution from land water storage change', 'landwaterstorage_values_quantile_'],
          ['Contribution from ocean dynamics', 'oceandynamics_values_quantile_'],
          ['Overall sea level change rate', 'total_rates_quantile_'],
          ['Contribution rate from Antarctica', 'AIS_rates_quantile_'],
          ['Contribution rate from Greenland', 'GIS_rates_quantile_'],
          ['Contribution rate from glaciers', 'glaciers_rates_quantile_'],
          ['Contribution rate from land water storage change', 'landwaterstorage_rates_quantile_'],
          []
      ]
  })  //end get screen options
} //end restart script
var clearMapButton = ui.Button({
    label: 'Reset',
    style: {
        stretch: 'horizontal',
        margin: '1px 1px 1px 1px',
        width: '95%'
    }
});
var clearMapPanel = ui.Panel({
    style: {
        position: 'bottom-right',
        width: '14%'
    }
});
// clearMapPanel.add(clearMapButton);
// clearMapButton.onClick(function(){
//   restartScript();
// });
restartScript();