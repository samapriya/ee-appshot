var LC15RED = ee.Image("users/nai_rum/LC08_3May2015/03may2015_B4"),
    LC15NIR = ee.Image("users/nai_rum/LC08_3May2015/03may2015_B5"),
    LC16RED = ee.Image("users/nai_rum/LC08_5May2016/05may2016_B4"),
    LC16NIR = ee.Image("users/nai_rum/LC08_5May2016/05may2016_B5"),
    LC18RED = ee.Image("users/nai_rum/LC08_25Apr2018/25Apr2018_B4"),
    LC18NIR = ee.Image("users/nai_rum/LC08_25Apr2018/25Apr2018_B5"),
    LC19RED = ee.Image("users/nai_rum/LC08_28Apr2019/28apr2019_B4"),
    LC19NIR = ee.Image("users/nai_rum/LC08_28Apr2019/28apr2019_B5");
// (NDVI 05 MAY 2015).
var LC15RED
var LC15NIR
var NDVI2015 = LC15NIR.subtract(LC15RED).divide(LC15NIR.add(LC15RED)).rename('NDVI2015');
// (NDVI MAY 2016).
var LC16RED;
var LC16NIR;
var NDVI2016 = LC16NIR.subtract(LC16RED).divide(LC16NIR.add(LC16RED)).rename('NDVI2016');
//-----------------------------------------------------------------------------------//
// (NDVI MAY 2018).
var LC18RED
var LC18NIR
var NDVI2018 = LC18NIR.subtract(LC18RED).divide(LC18NIR.add(LC18RED)).rename('NDVI2018');
// (NDVI MAY 2019).
var LC19RED
var LC19NIR
var NDVI2019 = LC19NIR.subtract(LC19RED).divide(LC19NIR.add(LC19RED)).rename('NDVI2019');
//-----------------------------------------------------------------------------------//
var CNDVI1 = NDVI2016.subtract(NDVI2015)
var CNDVI2 = NDVI2019.subtract(NDVI2018)
//-----------------------------------------------------------------------------------//
var meanCNDVI1 = CNDVI1.reduceRegion({
  reducer: ee.Reducer.mean(),
  geometry: LC15RED.geometry(),
  maxPixels: 1e9
});
var minCNDVI1 = CNDVI1.reduceRegion({
  reducer: ee.Reducer.min(),
  geometry: LC15RED.geometry(),
  maxPixels: 1e9
});
var maxCNDVI1 = CNDVI1.reduceRegion({
  reducer: ee.Reducer.max(),
  geometry: LC15RED.geometry(),
  maxPixels: 1e9
});
var stdDevCNDVI1 = CNDVI1.reduceRegion({
  reducer: ee.Reducer.stdDev(),
  geometry: LC15RED.geometry(),
  maxPixels: 1e9
});
print ('meanCNDVI1',meanCNDVI1);
print ('minCNDVI1',minCNDVI1);
print ('maxCNDVI1',maxCNDVI1);
print ('stdDevCNDVI1',stdDevCNDVI1);
//----------------------------------------------------------------------------------------------//
var meanCNDVI2 = CNDVI2.reduceRegion({
  reducer: ee.Reducer.mean(),
  geometry: CNDVI2.geometry(),
  scale: 30,
  maxPixels: 1e9
});
var minCNDVI2 = CNDVI2.reduceRegion({
  reducer: ee.Reducer.min(),
  geometry: CNDVI1.geometry(),
  scale: 30,
  maxPixels: 1e9
});
var maxCNDVI2 = CNDVI2.reduceRegion({
  reducer: ee.Reducer.max(),
  geometry: CNDVI2.geometry(),
  scale: 30,
  maxPixels: 1e9
});
var stdDevCNDVI2 = CNDVI2.reduceRegion({
  reducer: ee.Reducer.stdDev(),
  geometry: CNDVI2.geometry(),
  scale: 30,
  maxPixels: 1e9
});
print ('meanCNDVI2',meanCNDVI2);
print ('minCNDVI2',minCNDVI2);
print ('maxCNDVI2',maxCNDVI2);
print ('stdDevCNDVI2',stdDevCNDVI2);
//----------------------------------------------------------------------------------------------//
Map.centerObject(CNDVI1, 10);
Map.addLayer(CNDVI1,{min:-0.0865 ,max:0.0649, z:1, 
palette: ['red','White', 'green']},'Vegetation Change1');
Map.addLayer(CNDVI2,{min:0.0332 ,max:-0.1024, z:1, 
palette: ['red','White', 'green']},'Vegetation Change2');