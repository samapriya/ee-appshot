var Aqua = ui.import && ui.import("Aqua", "imageCollection", {
      "id": "NASA/OCEANDATA/MODIS-Aqua/L3SMI"
    }) || ee.ImageCollection("NASA/OCEANDATA/MODIS-Aqua/L3SMI"),
    EEZ = ui.import && ui.import("EEZ", "table", {
      "id": "users/st121047/EEZ"
    }) || ee.FeatureCollection("users/st121047/EEZ");
//owner Amindika 
var constructMODDict = function(geometry)
{
  var startMonth = "-01-01"
  var endMonth = "-12-31"
  var y_list = ee.List.sequence(2002, 2020)
  var ystr_list = y_list.map(function(y){return ee.Number(y).format('%1d')})
var mod = y_list.map(function(y){
    var thisCollAq = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI')
     .filter(ee.Filter.or(ee.Filter.date('2002-01-01', '2020-12-31')))
              .select("sst");
    var thisCollTer = ee.ImageCollection('NASA/OCEANDATA/MODIS-Terra/L3SMI')
          .filter(ee.Filter.or(ee.Filter.date('2002-01-01', '2020-12-31')))
              .select("sst");
    var fullColl = thisCollAq.merge(thisCollTer);
    var output = fullColl.mean().clip(EEZ);
    return output;
  });
  Map.setCenter(80.38466285467146,7.522542880124877, 6);
  var mod = y_list.map(function(y){return ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI')
                                          .filterDate(ee.String(ee.Number(y).format('%1d')).cat(startMonth),
                                                      ee.String(ee.Number(y).format('%1d')).cat(endMonth))
                                           .select("sst")
                                          .mean()
                                          .clip(geometry)
                              })
  var mod_dict = ee.Dictionary.fromLists(ystr_list, mod);
  return mod_dict
};
var elements = constructMODDict(EEZ);
print(elements, "Image dictionary");
var collection2 = ee.ImageCollection.fromImages([
  ee.Image(elements.get('2002')),
  ee.Image(elements.get('2003')),
  ee.Image(elements.get('2004')),
  ee.Image(elements.get('2005')),
  ee.Image(elements.get('2006')),
  ee.Image(elements.get('2007')),
  ee.Image(elements.get('2008')),
  ee.Image(elements.get('2009')),
  ee.Image(elements.get('2010')),
  ee.Image(elements.get('2011')),
  ee.Image(elements.get('2012')),
  ee.Image(elements.get('2013')),
  ee.Image(elements.get('2014')),
  ee.Image(elements.get('2015')),
  ee.Image(elements.get('2016')),
  ee.Image(elements.get('2017')),
  ee.Image(elements.get('2018')),
  ee.Image(elements.get('2019')),
  ee.Image(elements.get('2020'))
  ]);
  var elements = constructMODDict(EEZ);
// spatial maps for seasons_FIM 
var FIMseasons = function(geometry1)
  {
  var startMonth1 = "-03-01"
  var endMonth1 = "-04-30"
  var y_list = ee.List.sequence(2002, 2020)
  var ystr_list1 = y_list.map(function(y1){return ee.Number(y1).format('%1d')})
  var mod1 = y_list.map(function(y1){
    var thisCollAq1 = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI')
          .filterDate(ee.String(ee.Number(y1).format('%1d')).cat(startMonth1),
            ee.String(ee.Number(y1).format('%1d')).cat(endMonth1))
          .select("sst");
    var thisCollTer1 = ee.ImageCollection('NASA/OCEANDATA/MODIS-Terra/L3SMI')
          .filterDate(ee.String(ee.Number(y1).format('%1d')).cat(startMonth1),
            ee.String(ee.Number(y1).format('%1d')).cat(endMonth1))
          .select("sst");
    var fullColl1 = thisCollAq1.merge(thisCollTer1);
    var output = fullColl1.mean().clip(EEZ);
    return output; 
  });
  var mod_dict1 = ee.Dictionary.fromLists(ystr_list1, mod1);
  return mod_dict1
};
// spatial maps for seasons_SWM 
var SWMseasons = function(geometry3)
  {
  var startMonth2 = "-05-01"
  var endMonth2 = "-09-30"
  var y_list = ee.List.sequence(2002, 2020)
  var ystr_list2 = y_list.map(function(y2){return ee.Number(y2).format('%1d')})
  var mod2 = y_list.map(function(y2){
    var thisCollAq2 = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI')
          .filterDate(ee.String(ee.Number(y2).format('%1d')).cat(startMonth2),
            ee.String(ee.Number(y2).format('%1d')).cat(endMonth2))
          .select("sst");
    var thisCollTer2 = ee.ImageCollection('NASA/OCEANDATA/MODIS-Terra/L3SMI')
          .filterDate(ee.String(ee.Number(y2).format('%1d')).cat(startMonth2),
            ee.String(ee.Number(y2).format('%1d')).cat(endMonth2))
          .select("sst");
    var fullColl2 = thisCollAq2.merge(thisCollTer2);
    var output = fullColl2.mean().clip(EEZ);
    return output;
  });
  var mod_dict2 = ee.Dictionary.fromLists(ystr_list2, mod2);
  return mod_dict2
};
// spatial maps for seasons_SIM
var SIMseasons = function(geometry4)
  {
  var startMonth3 = "-10-01"
  var endMonth3 = "-11-30"
  var y_list = ee.List.sequence(2002, 2020)
  var ystr_list3 = y_list.map(function(y3){return ee.Number(y3).format('%1d')})
  var mod3 = y_list.map(function(y3){
    var thisCollAq3 = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI')
          .filterDate(ee.String(ee.Number(y3).format('%1d')).cat(startMonth3),
            ee.String(ee.Number(y3).format('%1d')).cat(endMonth3))
          .select("sst");
    var thisCollTer3 = ee.ImageCollection('NASA/OCEANDATA/MODIS-Terra/L3SMI')
          .filterDate(ee.String(ee.Number(y3).format('%1d')).cat(startMonth3),
            ee.String(ee.Number(y3).format('%1d')).cat(endMonth3))
          .select("sst");
    var fullColl3 = thisCollAq3.merge(thisCollTer3);
    var output = fullColl3.mean().clip(EEZ);
    return output;
  });
  var mod_dict3 = ee.Dictionary.fromLists(ystr_list3, mod3);
  return mod_dict3
};
// // spatial maps for seasons_NEM
// var NEMseasons = function(geometry5)
// {
//   var startMonth4 = "-12-01"
//   var endMonth4 = "-02-27"
//   var y_list = ee.List.sequence(2002, 2020)
//   var ystr_list4 = y_list.map(function(y4){return ee.Number(y4).format('%1d')})}
//   var mod4 = y_list.map(function(y4){
//     var thisCollAq4 = ee.ImageCollection('NASA/OCEANDATA/MODIS-Aqua/L3SMI')
//           .filterDate(ee.String(ee.Number(y4).format('%1d')).cat(startMonth4),
//             ee.String(ee.Number(y4).format('%1d')).cat(endMonth4))
//           .select("sst");
//     var thisCollTer4 = ee.ImageCollection('NASA/OCEANDATA/MODIS-Terra/L3SMI')
//           .filterDate(ee.String(ee.Number(y4).format('%1d')).cat(startMonth4),
//             ee.String(ee.Number(y4).format('%1d')).cat(endMonth4))
//           .select("sst");
//     var fullColl4 = thisCollAq4.merge(thisCollTer4);
//     var output = fullColl4.mean().clip(EEZ);
//     return output;
//   });
var FIM = FIMseasons(EEZ);
 var SWM = SWMseasons(EEZ);
var SIM = SIMseasons(EEZ);
//var NEM = NEMseasons(EEZ);
//Map.addLayer(NEM),
var FIMs = ee.ImageCollection.fromImages([
  ee.Image(FIM.get('2002')),
  ee.Image(FIM.get('2003')),
  ee.Image(FIM.get('2004')),
  ee.Image(FIM.get('2005')),
  ee.Image(FIM.get('2006')),
  ee.Image(FIM.get('2007')),
  ee.Image(FIM.get('2008')),
  ee.Image(FIM.get('2009')),
  ee.Image(FIM.get('2010')),
  ee.Image(FIM.get('2011')),
  ee.Image(FIM.get('2012')),
  ee.Image(FIM.get('2013')),
  ee.Image(FIM.get('2014')),
  ee.Image(FIM.get('2015')),
  ee.Image(FIM.get('2016')),
  ee.Image(FIM.get('2017')),
  ee.Image(FIM.get('2018')),
  ee.Image(FIM.get('2019')),
  ee.Image(FIM.get('2020'))
  ]);
var SWMs = ee.ImageCollection.fromImages([
  ee.Image(SWM.get('2002')),
ee.Image(SWM.get('2003')),
ee.Image(SWM.get('2004')),
  ee.Image(SWM.get('2005')),
  ee.Image(SWM.get('2006')),
  ee.Image(SWM.get('2007')),
  ee.Image(SWM.get('2008')),
  ee.Image(SWM.get('2009')),
  ee.Image(SWM.get('2010')),
  ee.Image(SWM.get('2011')),
  ee.Image(SWM.get('2012')),
  ee.Image(SWM.get('2013')),
  ee.Image(SWM.get('2014')),
  ee.Image(SWM.get('2015')),
  ee.Image(SWM.get('2016')),
  ee.Image(SWM.get('2017')),
  ee.Image(SWM.get('2018')),
  ee.Image(SWM.get('2019')),
ee.Image(SWM.get('2020'))
  ]);
var SIMs = ee.ImageCollection.fromImages([
  ee.Image(SIM.get('2002')),
  ee.Image(SIM.get('2003')),
  ee.Image(SIM.get('2004')),
  ee.Image(SIM.get('2005')),
  ee.Image(SIM.get('2006')),
  ee.Image(SIM.get('2007')),
  ee.Image(SIM.get('2008')),
  ee.Image(SIM.get('2009')),
  ee.Image(SIM.get('2010')),
  ee.Image(SIM.get('2011')),
  ee.Image(SIM.get('2012')),
  ee.Image(SIM.get('2013')),
  ee.Image(SIM.get('2014')),
  ee.Image(SIM.get('2015')),
  ee.Image(SIM.get('2016')),
  ee.Image(SIM.get('2017')),
  ee.Image(SIM.get('2018')),
  ee.Image(SIM.get('2019')),
  ee.Image(SIM.get('2020')),
  ]);
// var NEMs = ee.ImageCollection.fromImages([
//   ee.Image(NEM.get('2002')),
//   ee.Image(NEM.get('2003')),
//   ee.Image(NEM.get('2004')),
//   ee.Image(NEM.get('2005')),
//   ee.Image(NEM.get('2006')),
//   ee.Image(NEM.get('2007')),
//   ee.Image(NEM.get('2008')),
//   ee.Image(NEM.get('2009')),
//   ee.Image(NEM.get('2010')),
//   ee.Image(NEM.get('2011')),
//   ee.Image(NEM.get('2012')),
//   ee.Image(NEM.get('2013')),
//   ee.Image(NEM.get('2014')),
//   ee.Image(NEM.get('2015')),
//   ee.Image(NEM.get('2016')),
//   ee.Image(NEM.get('2017')),
//   ee.Image(NEM.get('2018')),
//   ee.Image(NEM.get('2019')),
//   ee.Image(NEM.get('2020')),
//   ]);
  Map.addLayer(FIMs, {  min:24, max:33,  palette: ['blue', 'limegreen', 'red']},'FIM');
 Map.addLayer(SWMs, {  min:24, max:33,  palette: ['blue', 'limegreen', 'red']},'SWM');
 Map.addLayer(SIMs, {  min:24, max:33,  palette: ['blue', 'limegreen', 'red']},'SIM');
//EXPORT TO DRIVE ALL IMAGES FROM FIM SEASON 
Export.image.toDrive({
image: FIMs.select('sst').mean(), //visualize({palette:'limegreen, yellow, darkorange, red'}),
description:'FIM_2002-2020',
region: EEZ,
 scale: 500
 });
// Export.image.toDrive({
// image: NEMs.select('sst').mean(), //visualize({palette:'limegreen, yellow, darkorange, red'}),
// description:'NEM_2002-2020',
// region: EEZ,
// scale: 500  
// });
Export.image.toDrive({
image: SWMs.select('sst').mean(), //visualize({palette:'limegreen, yellow, darkorange, red'}),
description:'SWM_2002-2020',
region: EEZ,
 scale: 500
 });
Export.image.toDrive({
image: SIMs.select('sst').mean(), //visualize({palette:'limegreen, yellow, darkorange, red'}),
description:'SIM_2002-2020',
region: EEZ,
 scale: 500
 });
//export annual chl maps 
Export.image.toDrive({
image: collection2.select('sst').mean(), //visualize({palette:'limegreen, yellow, darkorange, red'}),
description:'2002-2020',
region: EEZ,
 scale: 500
 });