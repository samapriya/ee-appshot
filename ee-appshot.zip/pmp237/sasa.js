var MPL = ui.import && ui.import("MPL", "imageCollection", {
      "id": "NOAA/VIIRS/001/VNP13A1"
    }) || ee.ImageCollection("NOAA/VIIRS/001/VNP13A1"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "NDVI"
        ],
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["NDVI"],"gamma":1},
    OXLST = ui.import && ui.import("OXLST", "imageCollection", {
      "id": "Oxford/MAP/LST_Day_5km_Monthly"
    }) || ee.ImageCollection("Oxford/MAP/LST_Day_5km_Monthly"),
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "Mean"
        ],
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["Mean"],"gamma":1};
print(MPL);
var MPL=ee.Image('NOAA/VIIRS/001/VNP13A1/2021_12_11');
Map.addLayer(MPL);
print(OXLST);
var OXLST=ee.Image('Oxford/MAP/LST_Day_5km_Monthly/2015_05');
Map.addLayer(OXLST);