// Demonstrates before/after imagery comparison with a variety of dates.
var subset = Map.getBounds(true)
var geometry = /* color: #d63000 */ee.Geometry.Point([-122.924155, 38.84523]); //San Fransisco
// Create a panel to hold our widgets.
var panel = ui.Panel();
panel.style().set('width', '300px');
var filters = {
    startDate: ui.Textbox('YYYY-MM-DD', '2020-09-10'), //default
    //endDate: ui.Textbox('YYYY-MM-DD', '2021-01-01'), //default
    applyButton: ui.Button('Apply Dates', applyFilters),
    loadingLabel: ui.Label({
      value: 'Loading...',
      style: {stretch: 'vertical', color: 'gray', shown: false}
    })
  };
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: 'Sentinel-2 Level-2A Multi Image',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
  ui.Label('Sentinel-2 multi image on Date.'),
  ui.Label('If you set "Date", please push "Apply Date" button.'),
  ui.Label('Date'), filters.startDate,
  ui.Panel([
        filters.applyButton,
        filters.loadingLabel
      ], ui.Panel.Layout.flow('horizontal')),
  ui.Label({
    value: 'Sentinel-2 data Dataset Availability.',
    style: {fontSize: '14px', fontWeight: 'bold'}
  }),
  ui.Label('2017-03-28 -- 2 days before today.')
]);
// Set Date variables.
var start = filters.startDate.getValue();
if (start) start = ee.Date(start);
print(start)
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
panel.add(intro);
// Add the panel to the ui.root.
ui.root.insert(0, panel);
/*
 * Configure the imagery
 */
// Create an initial mosiac, which we'll visualize in a few different ways.
var image = ee.ImageCollection('COPERNICUS/S2_SR')
    .filterDate(start, start.advance(1, 'week'))
    // Scale the images to a smaller range, just for simpler visualization.
    .map(function f(e) { return e.divide(10000); })
    .median();
var images = {
  'Natural Color (B4/B3/B2)': getImage(['B4', 'B3', 'B2']),
  'Land/Water (B8/B11/B4)': getImage(['B8', 'B11', 'B4']),
  'Color Infrared (B8/B4/B3)':getImage(['B8', 'B4', 'B3']),
  'Vegetation (B12/B11/B4)':getImage(['B12', 'B11', 'B4']),
  'WildFire (B12/B11/B8A)':getImage( ['B12', 'B11', 'B8A'])
};
// Create an initial mosiac, which we'll visualize in a few different ways.
function getImage(bands) {
  var image = ee.ImageCollection('COPERNICUS/S2_SR')
    .filterDate(start, start.advance(1, 'week'))
    .map(function f(e) { return e.divide(10000); })
    .median();
  return image.visualize({bands: bands, gamma: 1.3, min: 0, max: 0.3});
}
// Shared visualization parameters for the images.
/*
 * Set up the maps and control widgets
 */
print(images)
print( Object.keys(images))
// Create the left map, and have it display layer 0.
var leftMap = ui.Map();
leftMap.setControlVisibility(false);
var leftSelector = addLayerSelector(leftMap, 0, 'top-left');
// Create the right map, and have it display layer 1.
var rightMap = ui.Map();
rightMap.setControlVisibility(false);
var rightSelector = addLayerSelector(rightMap, 1, 'top-right');
// Adds a layer selection widget to the given map, to allow users to change
// which image is displayed in the associated map.
function addLayerSelector(mapToChange, defaultValue, position) {
  var label = ui.Label('Choose an image to visualize');
  // This function changes the given map to show the selected image.
  function updateMap(selection) {
    mapToChange.layers().set(0, ui.Map.Layer(images[selection]));
  }
  // Configure a selection dropdown to allow the user to choose between images,
  // and set the map to update when a user makes a selection.
  var select = ui.Select({items: Object.keys(images), onChange: updateMap});
  select.setValue(Object.keys(images)[defaultValue], true);
  var controlPanel =
      ui.Panel({widgets: [label, select], style: {position: position}});
  mapToChange.add(controlPanel);
}
/*
 * Tie everything together
 */
// Create a SplitPanel to hold the adjacent, linked maps.
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in the UI root.
ui.root.widgets().reset([splitPanel]);
var linker = ui.Map.Linker([leftMap, rightMap]);
leftMap.setCenter(-122.924155, 38.84523, 8);
// Add the panel to the ui.root.
ui.root.insert(0, panel);
function applyFilters() {
  // Set Date variables.
  var start1 = filters.startDate.getValue();
  if (start) start1 = ee.Date(start1);
  //if (start) start = ee.Date(start);
  print(start1)
  var images = {
    'Natural Color (B4/B3/B2)': getImage(['B4', 'B3', 'B2']),
    'Land/Water (B8/B11/B4)': getImage(['B8', 'B11', 'B4']),
    'Color Infrared (B8/B4/B3)':getImage(['B8', 'B4', 'B3']),
    'Vegetation (B12/B11/B4)':getImage(['B12', 'B11', 'B4']),
    'WildFire (B12/B11/B8A)':getImage( ['B12', 'B11', 'B8A'])
  };
  function getImage(bands) {
    var image = ee.ImageCollection('COPERNICUS/S2_SR')
      .filterDate(start1, start1.advance(1, 'week'))
      .map(function f(e) { return e.divide(10000); })
      .median();
    return image.visualize({bands: bands, min: 0, max: 0.3});
  }
  // Create the left map, and have it display layer 0.
  var leftMap = ui.Map();
  leftMap.setControlVisibility(false);
  var leftSelector = addLayerSelector(leftMap, 0, 'top-left');
  // Create the right map, and have it display layer 1.
  var rightMap = ui.Map();
  rightMap.setControlVisibility(false);
  var rightSelector = addLayerSelector(rightMap, 1, 'top-right');
  function addLayerSelector(mapToChange, defaultValue, position) {
    var label = ui.Label('Choose an image to visualize');
    // This function changes the given map to show the selected image.
    function updateMap(selection) {
      mapToChange.layers().set(0, ui.Map.Layer(images[selection]));
    }
    // Configure a selection dropdown to allow the user to choose between images,
    // and set the map to update when a user makes a selection.
    var select = ui.Select({items: Object.keys(images), onChange: updateMap});
    select.setValue(Object.keys(images)[defaultValue], true);
    var controlPanel =
        ui.Panel({widgets: [label, select], style: {position: position}});
    mapToChange.add(controlPanel);
  }
  // Create a SplitPanel to hold the adjacent, linked maps.
  var splitPanel = ui.SplitPanel({
    firstPanel: leftMap,
    secondPanel: rightMap,
    wipe: true,
    style: {stretch: 'both'}
  });
  // Set the SplitPanel as the only thing in the UI root.
  ui.root.widgets().reset([splitPanel]);
  var linker = ui.Map.Linker([leftMap, rightMap]);
  leftMap.setCenter(-122.924155, 38.84523, 8);
  // Add the panel to the ui.root.
  ui.root.insert(0, panel);
}