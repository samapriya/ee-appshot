// Create a panel to hold our widgets.
Map.setCenter(128.1, 26.7, 11) // Okinawa in Japan.
//Map.setOptions('SATELLITE');
var filters = {
    startDate: ui.Textbox('YYYY-MM-DD', '2021-10-26'), //Tayphoon No.19, 2019.
    applyButton: ui.Button('実行', applyFilters),
    threshold:ui.Textbox('-0.1','-0.1'), // default
    loadingLabel: ui.Label({
      value: 'Loading...',
      style: {stretch: 'vertical', color: 'gray', shown: false}
    })
  };
var controlPanel = ui.Panel({
  widgets: [
    ui.Label({
      value: '人工衛星の観測画像検索',
      style: {fontSize: '18px', fontWeight: 'bold'}
    }),
    ui.Label('日付を入力後、実行ボタンを押してください.'),
    ui.Label('人工衛星の観測日 (YYYY-MM-DD)'), filters.startDate,
    ui.Label('軽石検知しきい値. (-1.0 to 1.0)'), filters.threshold,
    ui.Panel([
        filters.applyButton,
        filters.loadingLabel
    ], ui.Panel.Layout.flow('horizontal')),
    ui.Label({
      value: '@Contains modified Copernicus Sentinel data [2021].',
      style: {fontSize: "15px"},
      targetUrl: 'https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2#terms-of-use'
      }),
  ],
  style: {position: 'bottom-left'},
  layout: null,
});
var Panel = ui.Panel();
controlPanel.style().set('width', '250px');
//ui.root.insert(1,controlPanel); add in the panel
Map.add(controlPanel);
// Set Date variables.
var start = filters.startDate.getValue();
if (start) start = ee.Date(start);
print(start)
function applyFilters() {
  var date = filters.startDate.getValue();
  var date = ee.Date(date);
  var next_date= date.advance(1, 'days') //'2019-03-10';
  print(date)
  print(next_date)
  function maskS2clouds(image) {
    var qa = image.select('QA60');
    // Bits 10 and 11 are clouds and cirrus, respectively.
    var cloudBitMask = 1 << 10;
    var cirrusBitMask = 1 << 11;
    // Both flags should be set to zero, indicating clear conditions.
    var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
        .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
    return image.updateMask(mask).divide(10000);
  }
  var dataset_sentinel2= ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate(date, next_date)
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',100))
  var visualization = {
  min: 0,
  max: 3000,
  bands: ['B4', 'B3', 'B2'],
  };
  var layer_sentinel2 = ui.Map.Layer(dataset_sentinel2.mean(), visualization, 'Sentinel-2');
  var LULC=ee.ImageCollection("ESA/WorldCover/v100")
  var mask=LULC.map(function(image){
    return image.eq(80)
  }).max()
  var mask=LULC.map(function(image){
  return image.eq(80).not().unmask(0);
  }).max();
  var empty=ee.Image().unmask(0);
  var oceanMask=empty.blend(mask).not().eq(1).selfMask();
  var add_Index=function(image){
    var Index=ee.Image(0).expression(
      '(B8+B4-B2-B3)/(B8+B4+B2+B3)',{
        'B4':image.select('B4'),
        'B2':image.select('B2'),
        'B8':image.select('B8'),
        'B3':image.select('B3'),
      }
    )
    return image.addBands(Index.rename('Index'))
  }
  var mask_land=function(image){
    return image.updateMask(mask)
  }
  var cloud_Prob=ee.ImageCollection('COPERNICUS/S2_CLOUD_PROBABILITY')
  .filterDate(date, next_date)
  .map(function(image){
    return image
  }).max()
  var mask_cloud=function(image){
    var clouds=cloud_Prob.lt(10)
    return image.updateMask(clouds)
  }
  var S2L2A=dataset_sentinel2
  .map(add_Index)
  //.map(oceanMask)
  .map(mask_cloud)
  var dataset = ee.ImageCollection("ESA/WorldCover/v100").first();
  var land_mask = dataset.lte(70).selfMask()
  var sentinel2_mask = dataset_sentinel2.mean().mask(land_mask)
  var sentinel2_mask1 = sentinel2_mask.gt(0).selfMask()
  var difference_threshold =  ee.Number.parse(filters.threshold.getValue())
  var index_layer = S2L2A.select('Index').mean()//.mask(oceanMask)
  var pumise = index_layer.gt(difference_threshold).rename('pumise').selfMask()
  print(pumise)
  var pumice_ocean = pumise.multiply(oceanMask);
  //var recent_index = ee.Image(index_layer.sort('system:time_start', false).first());
  //print(recent_index)
  //var pumice_ocean = pumise.map(oceanMask)
  //var pumice2 = pumise.multiply(pumice_ocean)
  //var recent_index_layer = ui.Map.Layer(recent_index, {}, "recent_index")
  var pumise_layer = ui.Map.Layer(pumise, {palette: ['red'],min:0, max:1}, "pumice_layer",true,0.5)
  var pumise_ocean_layer = ui.Map.Layer(pumice_ocean,  {palette: ['green','red'],min:0.9, max:1},"pumice_layer",true, 0.8)
  //var pumise_land_layer = ui.Map.Layer(sentinel2_mask, {min:0, max:1}, "pumice_land_layer")
  var layer_pumise = ui.Map.Layer(S2L2A.select('Index'),{bands:['Index'],min:-0.15,max:-0.1,palette: ['blue','green','red']},'Possible Volcanic Rocks',true, 0.5);
  Map.layers().reset([layer_sentinel2, pumise_ocean_layer]);
}
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
Map.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
Map.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('経度: ' + coords.lon.toFixed(3)),
  lat.setValue('緯度: ' + coords.lat.toFixed(3));
  // Add a red dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'FF0000'});
  Map.layers().set(1, dot);
});