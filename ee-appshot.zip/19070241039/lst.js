var roi = ui.import && ui.import("roi", "table", {
      "id": "users/19070241039/PMC"
    }) || ee.FeatureCollection("users/19070241039/PMC");
// Importing image collection
var modis = ee.ImageCollection('MODIS/006/MOD11A2');
//defining start date  and the end date is and advancing 8 year from the start date.
var start = ee.Date('2010-01-01');
var daterange = ee.DateRange(start, start.advance(8, 'year'));
//Centrers the map on ROI/PMC boundary
Map.centerObject(roi,11);
// Filtering LST collection to include images on the basis of time frame and selecting day time temperature band
var modLSTfilter = modis.filterDate(daterange).select('LST_Day_1km');
// Scale to Kelvin and convert to Celsius, set image acquisition time.
var lst_Keltocel = modLSTfilter.map(function(image) {
  return image
    .multiply(0.02)
    .subtract(273.15)
    .copyProperties(image, ['system:time_start']);
});
// Createing panel to hold the widgets.
var panel = ui.Panel();
panel.style().set('width', '500px');
// Creating main heading of the panel with labels.
var mainhead = ui.Panel([
  ui.Label({
    value: 'Chart Inspector',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
  ui.Label('Click on the map to see the chart.')
]);
panel.add(mainhead);
// initialinsing onclick event to display the chart when the map is clicked
Map.onClick(function(coords) {
  // Creating an MODIS LST chart.
 var tempseries = ui.Chart.image.series({
  imageCollection: lst_Keltocel,
  region: roi,
  reducer: ee.Reducer.median(),
  scale: 1000,
  xProperty: 'system:time_start'})
  .setOptions({
    lineWidth: 1,
    pointSize: 3,
    trendlines: {0: {
        color: 'CC0000'
      }},
     title: 'LST  Time Series',
     vAxis: {title: 'LST Celsius'},
    hAxis: {title:'Year'}});
  panel.widgets().set(1,tempseries);
});
//Clip to roi
var LSTclip = lst_Keltocel.mean().clip(roi);
//styling the pointer
Map.style().set('cursor', 'crosshair');
// Adding clipped image to the map.
Map.addLayer(LSTclip, {
  min: 25, max: 50,
  palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},
  'Mean temperature');
// Add the panel to the ui.root.
ui.root.insert(0, panel);
 // create vizualization parameters
var viz = {min:25, max:50, palette:['blue', 'limegreen', 'yellow', 'darkorange', 'red']};
// set position of panel
var legend = ui.Panel({
style: {
position: 'bottom-right',
padding: '8px 15px'
}
});
// Create legend title
var legendTitle = ui.Label({
value: 'Mean LST in Celsius',
style: {
fontWeight: 'bold',
fontSize: '18px',
margin: '0 0 4px 0',
padding: '0'
}
});
// Add the title to the panel
legend.add(legendTitle);
// create the legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// labelling maximum temperature in legend
var panel1 = ui.Panel({
widgets: [
ui.Label(viz['max'])
],
});
legend.add(panel1);
// create thumbnail from the image
var thumbnail = ui.Thumbnail({
image: legendImage,
params: {bbox:'0,0,10,100', dimensions:'10x200'},
style: {padding: '1px', position: 'bottom-center'}
});
// add the thumbnail to the legend
legend.add(thumbnail);
// labelling minimum temperature in legend
var panel1 = ui.Panel({
widgets: [
ui.Label(viz['min'])
],
});
legend.add(panel1);
Map.add(legend);