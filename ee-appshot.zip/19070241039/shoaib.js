var roi = ui.import && ui.import("roi", "table", {
      "id": "users/shoaibpatel1997/pmc_boundary"
    }) || ee.FeatureCollection("users/shoaibpatel1997/pmc_boundary");
// Import image collection
var modis = ee.ImageCollection('MODIS/006/MOD11A2');
//print (modis);
// A start date is defined and the end date is determined by advancing 1 year from the start date.
var start = ee.Date('2011-01-01');
var end = ee.Date('2018-12-31');
var dateRange = ee.DateRange(start, end);
// Filter the LST collection to include only images from time frame and select day time temperature band
var modLSTday = modis.filterDate(dateRange).select('LST_Day_1km','LST_Night_1km');
//print (modLSTday);
//var modLSTnight = modis.filterDate(dateRange).select('LST_Night_1km');
//print (modLSTnight);
// Scale to Kelvin and convert to Celsius, set image acquisition time.
var modC = modLSTday.map(function(image) {
  return image
    .multiply(0.02)
    .subtract(273.15)
    .copyProperties(image, ['system:time_start']);
});
//print (modC);
// Chart the time-series
var temp_trend = ui.Chart.image.series({
  imageCollection: modC,
  region: roi,
  reducer: ee.Reducer.median(),
  scale: 500,
  xProperty: 'system:time_start'})
  .setOptions({
    lineWidth: 1,
    pointSize: 2,
    trendlines: {0: {color: 'C3C3C3'},
                 1: {color: 'C3C3C3'}},
     title: 'LST  Time Series',
     vAxis: {title: 'LST Celsius'},
     hAxis: {title: 'Year'}
  });
//print(temp_trend);
//Clip to roi
var LST_dayclip = modC.mean().select('LST_Day_1km').clip(roi);
var LST_nightclip = modC.mean().select('LST_Night_1km').clip(roi);
// Add clipped image layer to the map.
//Map.addLayer(LST_nightclip, {
  //min: 0, max: 40,
  //palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},
  //'Mean Night Temperature');
//Map.addLayer(LST_dayclip, {
  //min: 0, max: 40,
  //palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},
  //'Mean Day Temperature');
// Create a panel to hold the chart.
var panel = ui.Panel();
panel.style().set({
  width: '400px',
  //height: '220px',
  position: 'bottom-right'
});
Map.add(panel);
// Make a button widget.
var button_map2 = ui.Button('Click to get LST-Day map');
// Set a callback function to run when the
// button is clicked.
button_map2.onClick(function() {
  //print(temp_trend),
  Map.setCenter(73.8567,18.5204,11);
 Map.addLayer(LST_dayclip, {
  min: 0, max: 40,
  palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},
  'Mean Day Temperature');
});
// Display the button in the console.
print(button_map2);
// Make a button widget.
var button_map1 = ui.Button('Click to get LST-Night map');
// Set a callback function to run when the
// button is clicked.
button_map1.onClick(function() {
  //print(temp_trend),
  Map.setCenter(73.8567,18.5204,11);
  Map.addLayer(LST_nightclip, {
  min: 0, max: 40,
  palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},
  'Mean Night Temperature');
});
// Display the button in the console.
print(button_map1);
// Make a button widget.
var button_graph = ui.Button('Click to get graph');
// Set a callback function to run when the
// button is clicked.
button_graph.onClick(function() {
  //print(temp_trend),
  panel.add(temp_trend);
});
// Display the button in the console.
print(button_graph);