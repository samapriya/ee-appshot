var pmc = ui.import && ui.import("pmc", "table", {
      "id": "users/shindeak306/PMC"
    }) || ee.FeatureCollection("users/shindeak306/PMC");
// Collect bands and scale
var modisLSTday = ee.ImageCollection('MODIS/006/MOD11A2').select('LST_Day_1km');
var modisLSTnight = ee.ImageCollection('MODIS/006/MOD11A2').select('LST_Night_1km');
var modLSTday = modisLSTday.map(function(img) {
  return img.multiply(0.02).subtract(273.15).copyProperties(img,['system:time_start','system:time_end']); 
});
var modLSTnight = modisLSTnight.map(function(img) {
  return img.multiply(0.02).subtract(273.15).copyProperties(img,['system:time_start','system:time_end']); 
});
// Select dates
var collection2011night = ee.ImageCollection(modLSTnight.filterDate('2011-04-01', '2011-04-30'));
var collection2011day = ee.ImageCollection(modLSTday.filterDate('2011-04-01', '2011-04-30'));
var collection2018night = ee.ImageCollection(modLSTnight.filterDate('2018-04-01', '2018-04-30'));
var collection2018day = ee.ImageCollection(modLSTday.filterDate('2018-04-01', '2018-04-30'));
//Clip to Specified Region
var clipped2011night = collection2011night.mean().clip(pmc)
var clipped2011day = collection2011day.mean().clip(pmc)
var clipped2018night = collection2018night.mean().clip(pmc)
var clipped2018day = collection2018day.mean().clip(pmc)
// Charts For Day Time Year:2011
var day2011 = ui.Chart.image.series(collection2011day, pmc,  ee.Reducer.mean(), 1000, 'system:time_start').setOptions({
          title: 'LST For Day for Year:2011',
          vAxis: {title: 'LST Celsius'},
});
// Charts For Night Time Year:2011
var night2011 = ui.Chart.image.series(collection2011night, pmc,  ee.Reducer.mean(), 1000, 'system:time_start').setOptions({
          title: 'LST For Night for Year:2011',
          vAxis: {title: 'LST Celsius'},
});
// Charts For Day Time Year:2018
var day2018 = ui.Chart.image.series(collection2018day, pmc,  ee.Reducer.mean(), 1000, 'system:time_start').setOptions({
          title: 'LST For Day for Year:2018',
          vAxis: {title: 'LST Celsius'},
});
// Charts For Night Time Year:2018
var night2018 = ui.Chart.image.series(collection2018night, pmc,  ee.Reducer.mean(), 1000, 'system:time_start').setOptions({
          title: 'LST For Night for Year:2018',
          vAxis: {title: 'LST Celsius'},
});
//Set Center of Map & Add Clipped Image Layer
Map.centerObject(pmc, 11); 
// Create a panel to hold the chart.
var panel = ui.Panel();
panel.style().set({
  width: '350px',
  height: '220px',
  position: 'middle-left'
});
Map.add(panel);
// Make a button widget for night 2011.
var button2011night = ui.Button('Click to get LST-Night map of 2011');
button2011night.onClick(function() {
panel.clear();
Map.addLayer(clipped2011night, {min: 10, max: 35, palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},'LST-Night map of 2011');
panel.widgets().set(2, night2011);
});
// Make a button widget for day 2011.
var button2011day = ui.Button('Click to get LST-Day map of 2011');
button2011day.onClick(function() {
panel.clear();
Map.addLayer(clipped2011day, {min: 25, max: 50, palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},'LST-Day map of 2011');
panel.widgets().set(2, day2011);
});
// Make a button widget for night 2018.
var button2018night = ui.Button('Click to get LST-Night map of 2018');
button2018night.onClick(function() {
panel.clear();
Map.addLayer(clipped2018night, {min: 10, max: 35, palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},'LST-Night map of 2018');
panel.widgets().set(2, night2018);
});
// Make a button widget for day 2018.
var button2018day = ui.Button('Click to get LST-Day map of 2018');
button2018day.onClick(function() {
panel.clear();
Map.addLayer(clipped2018day, {min: 25, max: 50, palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},'LST-Day map of 2018');
panel.widgets().set(2, day2018);
});
// create vizualization parameters
var viz = {min:10, max:50, palette:['blue', 'limegreen', 'yellow', 'darkorange', 'red']};
// set position of panel
var legend = ui.Panel({
    style: {
            position: 'bottom-right',
            padding: '8px 15px'
          }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Mean LST in Celsius',
  style: {
          fontWeight: 'bold',
          fontSize: '18px',
          margin: '0 0 4px 0',
          padding: '0'
        }
});
// Add the title to the panel
legend.add(legendTitle);
// create the legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// labelling maximum temperature in legend
var panel1 = ui.Panel({widgets: [ui.Label(viz['max'])],});
legend.add(panel1);
// create thumbnail from the image
var thumbnail = ui.Thumbnail({
image: legendImage,
params: {bbox:'0,0,10,100', dimensions:'10x150'},
style: {padding: '1px', position: 'bottom-right'}
});
// add the thumbnail to the legend
legend.add(thumbnail);
// labelling minimum temperature in legend
var panel1 = ui.Panel({widgets: [ui.Label(viz['min'])],});
legend.add(panel1);
Map.add(legend);
// Add the button to the map and the panel to root.
Map.add(button2011night);
Map.add(button2011day);
Map.add(button2018night);
Map.add(button2018day);