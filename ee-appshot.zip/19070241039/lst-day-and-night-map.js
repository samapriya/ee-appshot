var pmc = ui.import && ui.import("pmc", "table", {
      "id": "users/19070241039/PMC"
    }) || ee.FeatureCollection("users/19070241039/PMC");
// Importing modis data
var modisLSTday = ee.ImageCollection('MODIS/006/MOD11A2').select('LST_Day_1km');
var modisLSTnight = ee.ImageCollection('MODIS/006/MOD11A2').select('LST_Night_1km');
// conversion of kelvin to celsius
var modLSTday = modisLSTday.map(function(img) {
  return img.multiply(0.02)
  .subtract(273.15)
  .copyProperties(img,['system:time_start','system:time_end']); 
});
var modLSTnight = modisLSTnight.map(function(img) {
  return img.multiply(0.02)
  .subtract(273.15)
  .copyProperties(img,['system:time_start','system:time_end']); 
});
// filtering dates
var collection2011night = ee.ImageCollection(modLSTnight.filterDate('2011-04-01', '2011-04-30'));
var collection2011day = ee.ImageCollection(modLSTday.filterDate('2011-04-01', '2011-04-30'));
var collection2018night = ee.ImageCollection(modLSTnight.filterDate('2018-04-01', '2018-04-30'));
var collection2018day = ee.ImageCollection(modLSTday.filterDate('2018-04-01', '2018-04-30'));
//Clip to Specified Region
var clipped2011night = collection2011night.mean().clip(pmc)
var clipped2011day = collection2011day.mean().clip(pmc)
var clipped2018night = collection2018night.mean().clip(pmc)
var clipped2018day = collection2018day.mean().clip(pmc)
// Charts For Day Time Year:2011
var day2011 = ui.Chart.image.series(collection2011day, pmc,  ee.Reducer.mean(),1000, 'system:time_start').setOptions({
          title: 'LST For Day for Year:2011',
          vAxis: {title: 'LST Celsius'},
});
// Charts For Night Time Year:2011
var night2011 = ui.Chart.image.series(collection2011night, pmc,  ee.Reducer.mean(), 1000, 'system:time_start').setOptions({
          title: 'LST For Night for Year:2011',
          vAxis: {title: 'LST Celsius'},
});
// Charts For Day Time Year:2018
var day2018 = ui.Chart.image.series(collection2018day, pmc,  ee.Reducer.mean(), 1000, 'system:time_start').setOptions({
          title: 'LST For Day for Year:2018',
          vAxis: {title: 'LST Celsius'},
});
// Charts For Night Time Year:2018
var night2018 = ui.Chart.image.series(collection2018night, pmc,  ee.Reducer.mean(), 1000, 'system:time_start').setOptions({
          title: 'LST For Night for Year:2018',
          vAxis: {title: 'LST Celsius'},
});
//Set Center of Map 
Map.centerObject(pmc, 11); 
// Create a panel to hold the chart.
var panel = ui.Panel();
panel.style().set({
  width: '350px',
  height: '220px',
  position: 'middle-left'
});
Map.add(panel);
// Make a button widget for night 2011.
var button2011night = ui.Button('Click to get LST-Night map and chart of 2011');
button2011night.onClick(function() {
panel.clear();
Map.addLayer(clipped2011night, {min: 10, max: 35, palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},'LST-Night map of 2011');
panel.widgets().set(2, night2011);
});
// Make a button widget for day 2011.
var button2011day = ui.Button('Click to get LST-Day map and chart of 2011');
button2011day.onClick(function() {
panel.clear();
Map.addLayer(clipped2011day, {min: 25, max: 50, palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},'LST-Day map of 2011');
panel.widgets().set(2, day2011);
});
// Make a button widget for night 2018.
var button2018night = ui.Button('Click to get LST-Night map and chart of 2018');
button2018night.onClick(function() {
panel.clear();
Map.addLayer(clipped2018night, {min: 10, max: 35, palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},'LST-Night map of 2018');
panel.widgets().set(2, night2018);
});
// Make a button widget for day 2018.
var button2018day = ui.Button('Click to get LST-Day map and chart of 2018');
button2018day.onClick(function() {
panel.clear();
Map.addLayer(clipped2018day, {min: 25, max: 50, palette: ['blue', 'limegreen', 'yellow', 'darkorange', 'red']},'LST-Day map of 2018');
panel.widgets().set(2, day2018);
});
// create vizualization parameters
var viz = {min:10, max:50, palette:['blue', 'limegreen', 'yellow', 'darkorange', 'red']};
// set position of panel
var legend = ui.Panel({
    style: {
            position: 'bottom-right',
            padding: '8px 15px'
          }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Mean LST in Celsius',
  style: {
          fontWeight: 'bold',
          fontSize: '18px',
          margin: '0 0 4px 0',
          padding: '0'
        }
});
// Add the title to the panel
legend.add(legendTitle);
// create the legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// labelling maximum temperature in legend
var panel1 = ui.Panel({widgets: [ui.Label(viz['max'])],});
legend.add(panel1);
// create thumbnail from the image
var thumbnail = ui.Thumbnail({
image: legendImage,
params: {bbox:'0,0,10,100', dimensions:'10x150'},
style: {padding: '1px', position: 'bottom-right'}
});
// add the thumbnail to the legend
legend.add(thumbnail);
// labelling minimum temperature in legend
var panel1 = ui.Panel({widgets: [ui.Label(viz['min'])],});
legend.add(panel1);
Map.add(legend);
var buttonpanel = ui.Panel({
  layout:ui.Panel.Layout.flow('vertical', true),
  style:
  {position:'bottom-left',width: '300px'}
  });
ui.root.widgets().add(buttonpanel);
var buttonpantitle = ui.Label({
  value: 'Click on the buttons to display LST chart and Map',
  style: {
          fontWeight: 'bold',
          fontSize: '18px',
          margin: '0 0 4px 0',
          padding: '0'
        }
});
buttonpanel.add(buttonpantitle);
//adding buttons to side panel
buttonpanel.add(button2011night);
buttonpanel.add(button2011day);
buttonpanel.add(button2018night);
buttonpanel.add(button2018day);
//Defining the title of the map
var heading = ui.Panel({
    style: {
            position: 'top-center',
            padding: '8px 15px'
          }
});
Map.add(heading);
var headtitle = ui.Label({
  value: 'LST of Pune PMC Boundary for April 2011 and April 2018',
  style: {
          fontWeight: 'bold',
          fontSize: '18px',
          margin: '0 0 4px 0',
          padding: '0'
        }
});
heading.add(headtitle);