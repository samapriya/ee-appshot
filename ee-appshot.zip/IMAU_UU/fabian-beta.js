var MOD09GA = ui.import && ui.import("MOD09GA", "imageCollection", {
      "id": "MODIS/006/MOD09GA"
    }) || ee.ImageCollection("MODIS/006/MOD09GA"),
    s2Sr = ui.import && ui.import("s2Sr", "imageCollection", {
      "id": "COPERNICUS/S2_SR"
    }) || ee.ImageCollection("COPERNICUS/S2_SR"),
    s2Clouds = ui.import && ui.import("s2Clouds", "imageCollection", {
      "id": "COPERNICUS/S2_CLOUD_PROBABILITY"
    }) || ee.ImageCollection("COPERNICUS/S2_CLOUD_PROBABILITY"),
    MYD09GA = ui.import && ui.import("MYD09GA", "imageCollection", {
      "id": "MODIS/006/MYD09GA"
    }) || ee.ImageCollection("MODIS/006/MYD09GA"),
    vizParams_MOD = ui.import && ui.import("vizParams_MOD", "imageVisParam", {
      "params": {
        "bands": [
          "sur_refl_b06",
          "sur_refl_b04",
          "sur_refl_b03"
        ],
        "min": 0,
        "max": 10000
      }
    }) || {"bands":["sur_refl_b06","sur_refl_b04","sur_refl_b03"],"min":0,"max":10000},
    vizParams_S2 = ui.import && ui.import("vizParams_S2", "imageVisParam", {
      "params": {
        "min": 0,
        "max": 10000,
        "bands": [
          "B12",
          "B8A",
          "B3"
        ]
      }
    }) || {"min":0,"max":10000,"bands":["B12","B8A","B3"]},
    ANT = ui.import && ui.import("ANT", "table", {
      "id": "users/huzhongyangintrier/Basemap"
    }) || ee.FeatureCollection("users/huzhongyangintrier/Basemap"),
    VAL_AOI1 = ui.import && ui.import("VAL_AOI1", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                10.813794128560206,
                -70.39880487320283
              ],
              [
                10.813794128560206,
                -72.00168347269866
              ],
              [
                15.911450378560206,
                -72.00168347269866
              ],
              [
                15.911450378560206,
                -70.39880487320283
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #d63000 */
    /* shown: false */
    /* locked: true */
    ee.Geometry.Polygon(
        [[[10.813794128560206, -70.39880487320283],
          [10.813794128560206, -72.00168347269866],
          [15.911450378560206, -72.00168347269866],
          [15.911450378560206, -70.39880487320283]]], null, false),
    VAL_AOI2 = ui.import && ui.import("VAL_AOI2", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                22.184643737935204,
                -71.32431276835761
              ],
              [
                22.184643737935204,
                -72.9379595338904
              ],
              [
                27.523999206685204,
                -72.9379595338904
              ],
              [
                27.523999206685204,
                -71.32431276835761
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    /* locked: true */
    ee.Geometry.Polygon(
        [[[22.184643737935204, -71.32431276835761],
          [22.184643737935204, -72.9379595338904],
          [27.523999206685204, -72.9379595338904],
          [27.523999206685204, -71.32431276835761]]], null, false),
    VAL_AOI3 = ui.import && ui.import("VAL_AOI3", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                33.7368634792369,
                -70.94635518967797
              ],
              [
                33.7368634792369,
                -72.43314310957905
              ],
              [
                38.5378888698619,
                -72.43314310957905
              ],
              [
                38.5378888698619,
                -70.94635518967797
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    /* locked: true */
    ee.Geometry.Polygon(
        [[[33.7368634792369, -70.94635518967797],
          [33.7368634792369, -72.43314310957905],
          [38.5378888698619, -72.43314310957905],
          [38.5378888698619, -70.94635518967797]]], null, false),
    VAL_AOI4 = ui.import && ui.import("VAL_AOI4", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                63.564744338611895,
                -72.54553320729839
              ],
              [
                63.564744338611895,
                -74.11989128307361
              ],
              [
                69.0359357448619,
                -74.11989128307361
              ],
              [
                69.0359357448619,
                -72.54553320729839
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#ffc82d",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #ffc82d */
    /* shown: false */
    /* locked: true */
    ee.Geometry.Polygon(
        [[[63.564744338611895, -72.54553320729839],
          [63.564744338611895, -74.11989128307361],
          [69.0359357448619, -74.11989128307361],
          [69.0359357448619, -72.54553320729839]]], null, false),
    VAL_AOI5 = ui.import && ui.import("VAL_AOI5", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                97.71926336008738,
                -65.43683730446347
              ],
              [
                97.71926336008738,
                -67.61469001005561
              ],
              [
                103.64089421946238,
                -67.61469001005561
              ],
              [
                103.64089421946238,
                -65.43683730446347
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#00ffff",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #00ffff */
    /* shown: false */
    /* locked: true */
    ee.Geometry.Polygon(
        [[[97.71926336008738, -65.43683730446347],
          [97.71926336008738, -67.61469001005561],
          [103.64089421946238, -67.61469001005561],
          [103.64089421946238, -65.43683730446347]]], null, false),
    VAL_AOI6 = ui.import && ui.import("VAL_AOI6", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                159.586986608372,
                -74.1189920642492
              ],
              [
                159.586986608372,
                -75.64220466551093
              ],
              [
                165.673412389622,
                -75.64220466551093
              ],
              [
                165.673412389622,
                -74.1189920642492
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#bf04c2",
      "mode": "Geometry",
      "shown": false,
      "locked": true
    }) || 
    /* color: #bf04c2 */
    /* shown: false */
    /* locked: true */
    ee.Geometry.Polygon(
        [[[159.586986608372, -74.1189920642492],
          [159.586986608372, -75.64220466551093],
          [165.673412389622, -75.64220466551093],
          [165.673412389622, -74.1189920642492]]], null, false),
    RMSE_STYLE = ui.import && ui.import("RMSE_STYLE", "imageVisParam", {
      "params": {
        "min": 0,
        "max": 1,
        "palette": [
          "lightyellow",
          "red",
          "darkred"
        ]
      }
    }) || {"min":0,"max":1,"palette":["lightyellow","red","darkred"]},
    BIF_STYLE = ui.import && ui.import("BIF_STYLE", "imageVisParam", {
      "params": {
        "min": 0,
        "max": 1,
        "palette": [
          "lightyellow",
          "blue",
          "darkblue"
        ]
      }
    }) || {"min":0,"max":1,"palette":["lightyellow","blue","darkblue"]},
    logoUU = ui.import && ui.import("logoUU", "image", {
      "id": "users/IMAU_UU/UU_LOGO"
    }) || ee.Image("users/IMAU_UU/UU_LOGO"),
    SGS_Mask = ui.import && ui.import("SGS_Mask", "image", {
      "id": "users/IMAU_UU/moa125_2009_grn_v1_1_mask"
    }) || ee.Image("users/IMAU_UU/moa125_2009_grn_v1_1_mask"),
    S2_ORI = ui.import && ui.import("S2_ORI", "imageCollection", {
      "id": "COPERNICUS/S2"
    }) || ee.ImageCollection("COPERNICUS/S2");
/*
Fabian Beta (22 August 2022) 
by: Zhongyang Hu @ IMAU-UU
It is the Beta Version of FABIAN
======================================================================================================================
Updates:
----------------------------------------------------------------------------------------------------------------------
======================================================================================================================
*/
var S2_Tools=require('users/IMAU_UU/FABIAN:Package/S2_Tools')
var MOD_Tools=require('users/IMAU_UU/FABIAN:Package/MOD_Tools')
// *****************************************************************************************************************************
// ---------- I. Configurations ************************************************************************************************
// *****************************************************************************************************************************
// --- Date Filtering
var START_DATE = ee.Date('2020-12-1');
var END_DATE = ee.Date('2021-03-31');
// --- Endmembers
var EM_BI =	[6694.8,        5048.333333,  7578.5,       7373.5,       1222.285714,    193.5,        86.46153846];
var EM_RO =	[6529.81369,    7316.147958,  3458.32002,   5456.471891,  7522.863005,    7309.626333,  7153.515196];
var EM_FS =	[9848.955764,   9473.286373,	9956.997034,  9924.224657,  7185.787365,    2859.039375,  1996.613724];
var EM_OS =	[9382.998917,   7982.821968,	9820.94247,   9686.258955,  2613.583414,    133.8069262,  70.98208104];
var EM_WA =	[868.5,         546,          1585.5,       1070.5,       599.5,          447.5,        430];
var EM_WS =	[8568.385442,   7624.143889,  8529.482253,  8623.912202,  3915.142302,    999.1616863,  450.8544853];
var EM_SL =	[7160.222222,   4049.666667,  9286.666667,  8473.5,       611.75,         121.5,        43.5];
var Benchmark_EMs_Array= ee.Array([EM_BI, EM_RO, EM_FS, EM_OS, EM_WA, EM_WS, EM_SL]); // EMs_Array
var Benchmark_EMs_SMA_in= [EM_BI, EM_RO, EM_FS, EM_OS, EM_WA, EM_WS, EM_SL]; // EMs_List
var Benchmark_EM_Names=['BI_EM', 'EM_RO', 'EM_FS', 'EM_OS', 'EM_WA', 'EM_WS', 'SL_EM']; // EMs_Names
// --- General Parameters
Map.setOptions('SATELLITE'); // Basemap Style
var MAX_CLOUD_PROBABILITY = 65; // Cloud Masking Parameters
var filter_SI = ee.Filter.equals({
  leftField: 'system:index',
  rightField: 'system:index'
});
var simpleJoin = ee.Join.inner();
var filter_S2_SMA = ee.Filter.equals({
  leftField: 'origional_id',
  rightField: 'system:index'
});
var filter_S2_SMA_BM = ee.Filter.equals({
  leftField: 'origional_id',
  rightField: 'origional_id'
});
// --- Projection Parameters
var modisProjection = ee.Image(MOD09GA.first()).select('sur_refl_b01').projection();
// --- AOI Dictionary
var AOI_GEO = ee.Dictionary({'AOI1': VAL_AOI1, 'AOI2': VAL_AOI2, 'AOI3': VAL_AOI3, 'AOI4': VAL_AOI4, 'AOI5': VAL_AOI5, 'AOI6':VAL_AOI6});
var AOI_Name = ee.Dictionary({'AOI1': ' @ AOI 1: Dronning Maud Land 1', 'AOI2': ' @ AOI 2: Dronning Maud Land 2', 'AOI3': ' @ AOI 3: Dronning Maud Land 3',
                'AOI4': ' @ AOI 4: Amery Ice Shelf', 'AOI5': ' @ AOI 5: Shackleton Ice Shelf', 'AOI6':' @ AOI 6: Victoria Land'});
var AOI_Lat = ee.Dictionary({'AOI1': 13.177,  'AOI2': 24.817, 'AOI3': 36.346,  'AOI4': 66.09,   'AOI5': 100.59, 'AOI6': 162.59});
var AOI_Lon = ee.Dictionary({'AOI1': -71.225, 'AOI2': -72.10, 'AOI3': -71.653, 'AOI4': -73.376, 'AOI5': -66.62, 'AOI6':-74.96});
// --- MODIS Preprocessing
// ---------- Function 6. MODIS Cloud Masking
// Calculate how frequently a location is labeled as clear (i.e. non-cloudy) according to the "internal cloud algorithm flag" of the MODIS "state 1km" QA band.
function maskEmptyPixels(img){
  // Find pixels that had observations.
  var withObs = img.select('num_observations_1km').gt(0)
  return img.updateMask(withObs)
}// A function to mask out pixels that did not have observations.
function maskClouds(img) {
  var QA = img.select('state_1km') // Select the QA band.
  var bitMask = 1 << 10; // Make a mask to get bit 10, the internal_cloud_algorithm_flag bit.
  return img.updateMask(QA.bitwiseAnd(bitMask).eq(0)) // Return an image masking out cloudy areas.
}// A function to mask out cloudy pixels.
// --- Sentinel-2 Spectra
var spectrum_s2_1=[1.0969705, 1.0454005, 0.9617810, 0.7993821, 0.7380503, 0.6799645, 0.6110014, 0.5828424, 0.5501633, 0.4897977, 0.03887049, 0.02438454];
var spectrum_s2_2=[1.1784207, 1.1680957, 1.1540451, 1.1287102, 1.1160456, 1.0982620, 1.0710024, 1.0536767, 1.0373651, 0.9961318, 0.16383059, 0.14069983];
var spectrum_s2_3=[0.3098443, 0.3915148, 0.5536394, 0.6631625, 0.6876641, 0.7126780, 0.7308948, 0.7301566, 0.7310324, 0.7349129, 0.73286857, 0.69058083];
var spectrum_s2_4=[0.9763262, 0.9763581, 0.9709808, 0.9400396, 0.9233158, 0.9059793, 0.8703512, 0.8479954, 0.8202709, 0.7414314,  0.01603177, 0.02257707];
var spectrum_s2_5=[0.8845522, 0.8882489, 0.8908897, 0.8681686, 0.8494540, 0.8126776, 0.7623277, 0.7232315, 0.7002102, 0.5601445,  0.01255629, 0.01418880];
var spectrum_s2_6=[0.8483086, 0.8558884, 0.8624021, 0.8538716, 0.8449567, 0.8315331, 0.7946534, 0.7710383, 0.7564364, 0.6898957,  0.08526128, 0.07580253];
var wavelengths_S2 = [443.9, 496.6, 560, 664.5, 703.9, 740.2, 782.5,835.1,864.8,945,1613.7,2202.4];
var EMChart_S2 = ui.Chart.array.values({array: [spectrum_s2_1,spectrum_s2_2,spectrum_s2_6], axis: 1, xLabels: wavelengths_S2})
    EMChart_S2.setChartType('LineChart');
    //EMChart_S2.setSeriesNames(['Blue Ice','Snow (Fresh)', 'Wet Snow']);
    EMChart_S2.setSeriesNames(['Blue Ice','Snow (Fresh)', 'Wet Snow']);
    EMChart_S2.setOptions({
      title: 'Sentinel-2 Reference Spectra',
      hAxis: {
        title: 'Wavelength [nm]', viewWindow: {min: 350, max: 2300}
      },
      vAxis: {
        title: 'Reflectance', minValue:0, maxValue:1
      },
      series: {
        0: {
          color: '#633974',
          lineWidth: 2,
          pointsVisible: true,
          pointSize: 3,
        },
        1: {
          color: '#AED6F1',
          lineWidth: 1,
          pointsVisible: true,
          pointSize: 2,
        },
        2: {
          color: '#1A5276',
          lineWidth: 1,
          pointsVisible: true,
          pointSize: 2,
        }
      }
    });
// #############################################################################################################################
// -------------------------------------- II. Main [UI] ------------------------------------------------------------------------
// #############################################################################################################################
var crs = 'EPSG:3031'
Map.setOptions('SATELLITE');
var filter_S2_SMA = ee.Filter.equals({
  leftField: 'origional_id',
  rightField: 'system:index'
});
var simpleJoin = ee.Join.inner();
// ---- Notification
var logo_show = logoUU.visualize({
    bands:  ['b1', 'b2', 'b3'],
    min: 0,
    max: 255
    });
var thumb = ui.Thumbnail({
    image: logo_show,
    params: {
        dimensions: '2285x349',
        format: 'png'
        },
    style: {height: '50px', width: '200px',padding :'0'}
    });
var piclogo = ui.Panel(thumb, 'flow', {'background-color':'rgba(255, 255, 255, 0)'});
/// --- Update
var Update = ui.Select({
  placeholder: '[Update History]',
  items: [{label:'19-08-22: Beta Launched', value:'1'}, {label:'Updating', value:'2'}],
});
/// --- Explore
var Explore = ui.Button({
  label: 'Explore FABIAN with Validation',
  onClick: function(){
  Map.clear();
// --- Panel Inspection [Begin]
// Create a panel to hold our widgets.
var panel_inspect = ui.Panel({style: {width: '25%'}});
// Add the panel to the ui.root.
ui.root.insert(0, panel_inspect);
//--Core
var panel_explore = ui.Panel();
panel_explore.style().set({width: '300px', position: 'top-left','background-color': 'rgba(255, 255, 255, 0)'});
Map.add(panel_explore);
var ReadME_select = ui.Select({
  placeholder: '[ReadMe]',
  items: [{label:'(1) Select Area of Interest (AOI).', value: 'View'}, {label:'(2) Check if you want to apply "Snow Grain Size Mask".', value:'Download'}, 
  {label:'(3) Click "Run Spectral Unmixing".', value:'Download'},{label:'(4) Click a pixel to validate the Results.', value:'Download'}, 
  {label:'(5) Refresh your browser to go back. (Optimizing).', value:'Classification'},{label:'(6) Start', value:'Classification'}],
});
var AOI_select = ui.Select({
        placeholder: '[Choose an AOI]',
        items: [{label:'Dronning Maud Land 1', value:'AOI1'}, {label:'Dronning Maud Land 2', value:'AOI2'}, {label:'Dronning Maud Land 3', value:'AOI3'}, 
                    {label:'Amery Ice Shelf', value:'AOI4'}, {label:'Shackleton Ice Shelf', value:'AOI5'}, {label:'Victoria Land', value:'AOI6'}],
})
var SGS=ui.Checkbox('Snow Grain Size Mask', {'background-color': 'rgba(255, 255, 255, 0)'})
// #############################################################################################################################
// -------------------------------------- IV. Legend ---------------------------------------------------------------------------
// #############################################################################################################################
// Constants used to visualize the data on the map.
var SMA_VIS_MAX_VALUE = 100;
var SMA_VIS_NONLINEARITY = 1;
// Styling for the legend title.
var LEGEND_TITLE_STYLE = {
  fontSize: '15px',
  fontWeight: 'bold',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '6px',
  backgroundColor: 'rgba(0,0,0,0)',
};
// Styling for the legend footnotes.
var LEGEND_FOOTNOTE_STYLE = {
  fontSize: '12px',
  stretch: 'horizontal',
  textAlign: 'left',
  margin: '6px',
  backgroundColor: 'rgba(255, 255, 255, 0)',
};
// Styling for the legend footnotes.
var LEGEND_Label = {
  fontSize: '16px',
  stretch: 'horizontal',
  textAlign: 'left',
  margin: '0px',
  backgroundColor: 'rgba(255, 255, 255, 0)',
};
// Assemble the legend panel.
Map.add(ui.Panel(
    [
      ui.Label('Blue Ice Fraction [%] ', LEGEND_TITLE_STYLE), makeLegend2(),
      ui.Label('0'+'⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀'+'50'+'⠀⠀⠀⠀⠀⠀⠀⠀'+'100',LEGEND_Label),    
      ui.Label('Median blue ice fraction derived from MODIS using SMA', LEGEND_FOOTNOTE_STYLE),
      ui.Label('BIF RMSE [%]', LEGEND_TITLE_STYLE), makeLegend(),
      ui.Label('0'+'⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀'+'50'+'⠀⠀⠀⠀⠀⠀⠀⠀'+'100',LEGEND_Label),    
      ui.Label('RMSE between MODIS and S2 in the bottom-right box', LEGEND_FOOTNOTE_STYLE)
    ],
    ui.Panel.Layout.flow('vertical'),
    {width: '260px', position: 'bottom-left',backgroundColor: 'rgba(0, 0, 0, 0)'}));
var getvalue = ui.Button({
  label: 'Run Spectral Unmixing',
  onClick: function() {
    var NNC = true;
    //print('NNC: ' + NNC);
    //print('EM: ' + secondname_select.getValue());
    //print('AOI: ' + thirdname_select.getValue());
    Map.setCenter(AOI_Lat.get(AOI_select.getValue()).getInfo(), AOI_Lon.get(AOI_select.getValue()).getInfo(), 8)
    if(AOI_select.getValue()=='AOI1'){
      var val_AOI=VAL_AOI1
    }else if(AOI_select.getValue()=='AOI2'){
      var val_AOI=VAL_AOI2
    }else if(AOI_select.getValue()=='AOI3'){
      var val_AOI=VAL_AOI3
    }else if(AOI_select.getValue()=='AOI4'){
      var val_AOI=VAL_AOI4
    }else if(AOI_select.getValue()=='AOI5'){
      var val_AOI=VAL_AOI5
    }else{var val_AOI=VAL_AOI6}
var MOD_in = MOD_Tools.Preprocess(START_DATE, END_DATE, val_AOI)
var EMs_Array= ee.Array([EM_BI, EM_RO, EM_FS, EM_OS, EM_WA, EM_WS, EM_SL]); // EMs_Array
var EMs_SMA_in= [EM_BI, EM_RO, EM_FS, EM_OS, EM_WA, EM_WS, EM_SL]; // EMs_List
var EM_Names=['BI_EM', 'EM_RO', 'EM_FS', 'EM_OS', 'EM_WA', 'EM_WS', 'SL_EM']; // EMs_Names
var SMA_Fraction_NN = MOD_in.map(MOD_Tools.SMA_R2F_NN(EMs_SMA_in, EM_Names, true)); // SMA Fraction
var SMA_Fraction_NN_with_MODIS=MOD_in.map(MOD_Tools.SMA_R2F_NNa(EMs_SMA_in, EM_Names, true));
var SMA_Reflectance=SMA_Fraction_NN.map(MOD_Tools.SMA_F2R(EMs_Array))
var SMA_innerJoin = ee.ImageCollection(simpleJoin.apply(SMA_Fraction_NN_with_MODIS.map(MOD_Tools.ORI_ID), SMA_Reflectance.map(MOD_Tools.ORI_ID), filter_SI))
var SMA_joined = SMA_innerJoin.map(function(feature) {
  return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
})
var User_SMA_with_RMSE = SMA_joined.map(MOD_Tools.SMA_RMSE).map(BIA_combi)
var SMA_Selected=User_SMA_with_RMSE.select('BS_EM').map(function(img){return img.clip(val_AOI)})
// --- Sentinel-2 Preprocessing
function BIA_Fix_Mod(img){
  var classified = (img.select("B8A").gt(3000)) 
    .and(img.select("B8A").lt(7000))
    .and(BR(img).gt(0.85))
    .multiply(ee.Image(1)).rename('BIA_Modified');
  var out = ee.Image(classified.toInt16());
  return out.copyProperties({
        source: img,
        properties: ['system:time_start']
      });
}
function S2_to_MOD(img){
  var crs = 'EPSG:3031'
  var BIA_SUB = img.select('BIA_Modified');
  var BIF_Full = BIA_SUB.reproject({crs:crs,crsTransform:[20,0,-3044500,0,-20,3044500]}).reduceResolution({
        reducer: ee.Reducer.count(), 
        maxPixels: 1e4}).reproject({crs:crs,crsTransform:[500,0,-3044500,0,-500,3044500]}).rename('BIC_Full');
  var BIA = BIA_SUB.eq(1);
  var IMG_Masked = BIA_SUB.updateMask(BIA);
  var BIF_Masked = IMG_Masked.reproject({crs:crs,crsTransform:[20,0,-3044500,0,-20,3044500]}).reduceResolution({
        reducer: ee.Reducer.count(), 
        maxPixels: 1e4}).reproject({crs:crs,crsTransform:[500,0,-3044500,0,-500,3044500]}).rename('BIC_Masked');
  var BIF_Percentage= BIF_Masked.divide(BIF_Full).rename('BIF_Percentage');
  return BIF_Full.addBands(BIF_Masked).addBands(BIF_Percentage)
}
var S2CloudMasked_in=S2_Tools.S2_CM_Hybrid(val_AOI, START_DATE, END_DATE)
var Results_Merge= S2CloudMasked_in.map(BIA_Fix_Mod); 
var Results_BIF = Results_Merge.map(S2_to_MOD);
var BIF_merge = S2_Tools.mosaicS2(Results_BIF).select('BIF_Percentage').map(function(img){return img.reproject({crs:crs,crsTransform:[500,0,-3044500,0,-500,3044500]}).clip(val_AOI).copyProperties({
        source: img,
        properties: ['system:time_start']
      });
})
var innerJoin_S2_User = ee.ImageCollection(simpleJoin.apply(SMA_Selected, BIF_merge, filter_S2_SMA)); // --- Join SMA and S2
var SMA_S2_User_joined = innerJoin_S2_User.map(function(feature) {
      return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
  })
print(SMA_S2_User_joined)
var VAL_SE=SMA_S2_User_joined.map(VAL_RMSE_Mask('BS_EM'));
var VAL_MSE = VAL_SE.mean();
var VAL_RMSE = VAL_MSE.pow(0.5).rename('RMSE')
  /*
    //print('User_SMA', User_SMA_Slim)
    //if (NNC) {var NNC_state = 'LSMA with NN-Constraint'} else {var NNC_state = 'LSMA without NN-Constraint'}
    //var model_mode = '('+NNC_state + ' using EMs: ' + EM_Names+')';
    //print(model_mode)
    //Map.layers().set(1, User_SMA_Slim);
    var Results_Merge= s2CloudMasked.map(add_BIA_mod_in); // --- Apply the Sentinel-2 BIA Classification
    var Results_BIF = Results_Merge.map(S2_to_MOD); // BIA to BIF
    var BIF_merge = mosaicS2(Results_BIF)
    // --- Join Sentinel-2 and User-SMA
    var innerJoin_S2_User = ee.ImageCollection(simpleJoin.apply(User_SMA_Slim, BIF_merge, filter_S2_SMA)); // --- Join SMA and S2
    var SMA_S2_User_joined = innerJoin_S2_User.map(function(feature) {
      return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
    })
    //print('Sentinel-2 and UD-SMA Joined Validation', SMA_S2_User_joined)
    // --- Join Sentinel-2 and User-SMA + Benchmark
    var innerJoin_S2_User_BM = ee.ImageCollection(simpleJoin.apply(Benchmark_SMA_NN_Slim.map(Benchmark_rename), SMA_S2_User_joined, filter_S2_SMA_BM)); // --- Join SMA and S2
    var SMA_S2_User_BM_joined = innerJoin_S2_User_BM.map(function(feature) {
      return ee.Image.cat(feature.get('primary'), feature.get('secondary'));
    })
    //print('Sentinel-2, UD-SMA, and Benchmark Joined Validation', SMA_S2_User_BM_joined)
    print(SMA_S2_User_BM_joined)
    // --- Validation
    var VAL_SE=SMA_S2_User_BM_joined.map(VAL_RMSE_Mask);
    var VAL_MSE = VAL_SE.mean();
    var VAL_RMSE = VAL_MSE.pow(0.5).rename('RMSE')
    */
    if(SGS.getValue()===true){
      Map.addLayer(User_SMA_with_RMSE.select('BS_EM').median().clip(ANT).updateMask(SGS_Mask), BIF_STYLE ,'BIF')
    }else{
      Map.addLayer(User_SMA_with_RMSE.select('BS_EM').median().clip(ANT), BIF_STYLE ,'BIF')
    }
    // Create an intro panel with labels.
    var intro = ui.Panel([
      ui.Label({
        value: 'Blue Ice Fraction Results' + AOI_Name.get(AOI_select.getValue()).getInfo(),
        style: {fontSize: '20px', fontWeight: 'bold'}
      }),
      ui.Label('Click a point on the map (within the rectangle) to inspect.'),
      ui.Label('Note: Please be aware that RMSE (REF) value has been multiplied by 10 for a better visulization in [%].',{color:'red'})
    ]);
    panel_inspect.add(intro);
    // Create panels to hold lon/lat values.
    var lon = ui.Label();
    var lat = ui.Label();
    panel_inspect.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
    //---
    Map.onClick(function(coords) {
    // Update the lon/lat panel with values from the click event.
      lon.setValue('lon: ' + coords.lon.toFixed(2)),
      lat.setValue('lat: ' + coords.lat.toFixed(2));
      centerZoomBox(coords.lon, coords.lat);
      // Add a red dot for the point clicked on.
      var point = ee.Geometry.Point(coords.lon, coords.lat);
      var dot = ui.Map.Layer(point, {color: 'FF0000'}, 'Location');
      Map.layers().set(2, dot);
      // ******************* Baseline Chart (NN Constraint LSMA)
      var SMA_Chart_NN = ui.Chart.image.series(User_SMA_with_RMSE.select(['BS_EM','RMSE']), point);
      SMA_Chart_NN.setSeriesNames(['Blue Ice Fraction','RMSE']).setOptions({
      title: '[FABIAN Results] Blue Ice Fraction time series',
      vAxis: {title: 'Blue Ice Fraction (x 100 [%]) & RMSE (REF) (x10/100 [%])', minValue:0, maxValue:1.0},
      hAxis: {title: 'Date', format: 'yyyy-MM', gridlines: {count: 7}},
      series: {
        0: {
          color: 'blue',
          lineWidth: 0,
          pointsVisible: true,
          pointSize: 2,
        },
        1: {
          color: 'red',
          lineWidth: 0,
          pointsVisible: true,
          pointSize: 2,
        },
      }
    });
    panel_inspect.widgets().set(2, SMA_Chart_NN);
  });
  Map.style().set('cursor', 'crosshair');
    //--
    //--
    // *****************************************************************************************************************************
    // ---------- VII. Zoom ********************************************************************************************************
    // *****************************************************************************************************************************
    // Step through thumbnails of an image collection showing the development
    // of an airstrip developed for gold mining in the 1980's and 1990's.
    // Create a map to be used as the zoom box.
    var zoomBox = ui.Map({style: {stretch: 'both', shown: false}})
        .setControlVisibility(true);
    zoomBox.setCenter(AOI_Lat.get(AOI_select.getValue()).getInfo(), AOI_Lon.get(AOI_select.getValue()).getInfo(), 8)    
    zoomBox.setOptions('SATELLITE')
    zoomBox.addLayer(VAL_RMSE, RMSE_STYLE ,'RMSE');
    zoomBox.add(ui.Label('FABIAN: RMSE(BIF) Results',{position: 'bottom-center' }));
    //zoomBox.addLayer(User_SMA_with_RMSE.select('BS_EM').median().clip(ANT), BIF_STYLE ,'BIF')
    // Update the center of the zoom box map when the base map is clicked.
    var centerZoomBox = function(lon, lat) {
      instructions.style().set('shown', false);
      zoomBox.style().set('shown', true);
      zoomBox.setCenter(lon, lat);
      zoomBox.setZoom(10);
      var bounds = zoomBox.getBounds();
      var w = bounds[0], e = bounds [2];
      var n = bounds[1], s = bounds [3];
      var outline = ee.Geometry.MultiLineString([
        [[w, s], [w, n]],
        [[e, s], [e, n]],
        [[w, s], [e, s]],
        [[w, n], [e, n]],
      ]);
      var layer_Zoom = ui.Map.Layer(outline, {color: 'FFFFFF'}, 'Zoom Box Bounds');
      Map.layers().set(1, layer_Zoom)
    };
    // Add a label and the zoom box map to the default map.
    var instructions = ui.Label('Click the map to see the SMA Validation Result in detail.', {
      stretch: 'both',
      textAlign: 'center',
      backgroundColor: '#d3d3d3'
    });
    var panel_Zoom = ui.Panel({
      widgets: [zoomBox, instructions],
      style: {
        position: 'bottom-right',
        height: '400px',
        width: '400px',
      }
    });
    Map.add(ui.Label('FABIAN: Median Blue Ice Fraction Results'));
    Map.add(panel_Zoom);
    //--
    function BIA_mod_in(img){
      var classified = (img.select("B8A").gt(3000)) 
        .and(img.select("B8A").lt(7000))
        .and(BR(img).gt(0.85))
      .multiply(ee.Image(1)).rename('BIA_Modified')
      return ee.Image(classified.toInt16()).clip(val_AOI)//.rename(ee.String(image.get("LANDSAT_ID")))  
    }// 2.2. BIA Classification
    function add_BIA_mod_in(img){
      return maskClouds_S2(img).addBands(BIA_mod_in(img))
    }// 2.3. add BIA Classification to the cloud masked image
  }
});
//-- Core
var secondname_select = ui.Select();
var thirdname_select = ui.Select();
panel_explore.widgets().set(1,ui.Label('Explore FABIAN with Validation', {fontWeight:'bold',color: 'black','background-color': 'rgba(255, 255, 255, 0)'}));
panel_explore.widgets().set(2,ui.Label('Check ReadMe for a quick start.', {color: 'black','background-color': 'rgba(255, 255, 255, 0)'}));
panel_explore.widgets().set(3, ReadME_select);
panel_explore.widgets().set(4, AOI_select);
panel_explore.widgets().set(5, SGS);
panel_explore.widgets().set(6, getvalue);
panel_explore.widgets().set(7,ui.Label('If you want to go to a new AOI, please refresh your browser.', {color: 'red','background-color': 'rgba(255, 255, 255, 0)'}));
panel_explore.widgets().set(8,ui.Label('DEMO: Austral Summer 2020/21. Gap-filling and user-defined date will be supported in 1.0.', {color: 'black','background-color': 'rgba(255, 255, 255, 0)'}));
  }
})
/// --- Download
var Download_dev = ui.Button({
  label: 'Download FABIAN Blue Ice Fraction',
  onClick: function(){
    //panel.clear();
    Map.clear();
}
})
var Download = ui.Select({
  placeholder: 'Download FABIAN Blue Ice Fraction',
  items: [{label:'Coming Soon', value:'1'}, {label:'in Version 1.0', value:'2'}],
});
/// --- Detail
var Detail = ui.Button({
  label: 'Exploring Sentinel-2 Blue Ice Areas',
  onClick: function(){
    //panel.clear();
    Map.clear();
    var panel_inspect_spa = ui.Panel({style: {width: '25%'}});
    ui.root.insert(0, panel_inspect_spa);
    var class_panel_spa = ui.Panel();
    class_panel_spa.style().set({width: '320px', position: 'top-left'});
    Map.add(class_panel_spa);
    var label_cloud_prob = ui.Label('MAX_CLOUD_PROBABILITY [%]');
    var slider_cloud_prob = ui.Slider({
      min:0,
      max:100,
      value:65,
      step:1,
      style: {stretch: 'horizontal', width:'300px' },
      onChange: function() {}
    })
        var AOI_select = ui.Select({
        placeholder: '[Choose an AOI]',
        items: [{label:'Dronning Maud Land 1', value:'AOI1'}, {label:'Dronning Maud Land 2', value:'AOI2'}, {label:'Dronning Maud Land 3', value:'AOI3'}, 
                    {label:'Amery Ice Shelf', value:'AOI4'}, {label:'Shackleton Ice Shelf', value:'AOI5'}, {label:'Victoria Land', value:'AOI6'}],
    })
    class_panel_spa.widgets().set(1, AOI_select);
    class_panel_spa.widgets().set(2, label_cloud_prob);
    class_panel_spa.widgets().set(3, slider_cloud_prob);
    var label_ratio = ui.Label('Ratio (NIR-SWIR)');
    var slider_ratio = ui.Slider({
      min:0,
      max:1,
      value:0.8,
      step:0.01,
      style: {stretch: 'horizontal', width:'300px' },
      onChange: function() {}
    })
    class_panel_spa.widgets().set(4, label_ratio);
    class_panel_spa.widgets().set(5, slider_ratio);
    var label_nir_min = ui.Label('Min Reflectance (NIR) [scale: 10000]');
    var slider_nir_min = ui.Slider({
      min:0,
      max:10000,
      value:3000,
      step:10,
      style: {stretch: 'horizontal', width:'300px' },
      onChange: function() {}
    })
    class_panel_spa.widgets().set(6, label_nir_min);
    class_panel_spa.widgets().set(7, slider_nir_min);
    var label_nir_max = ui.Label('Max Reflectance (NIR) [scale: 10000]');
    var slider_nir_max = ui.Slider({
      min:0,
     max:10000,
      value:7000,
      step:10,
      style: {stretch: 'horizontal', width:'300px' },
      onChange: function() {}
    })
    class_panel_spa.widgets().set(8, label_nir_max);
    class_panel_spa.widgets().set(9, slider_nir_max);
    var run_class = ui.Button({
      label: 'Run Blue Ice Area Classification',
      onClick: function() {
        var MAX_CLOUD_PROBABILITY=slider_cloud_prob.getValue()
        if(AOI_select.getValue()=='AOI1'){
         var val_AOI=VAL_AOI1
        }else if(AOI_select.getValue()=='AOI2'){
          var val_AOI=VAL_AOI2
        }else if(AOI_select.getValue()=='AOI3'){
          var val_AOI=VAL_AOI3
        }else if(AOI_select.getValue()=='AOI4'){
         var val_AOI=VAL_AOI4
        }else if(AOI_select.getValue()=='AOI5'){
          var val_AOI=VAL_AOI5
       }else{var val_AOI=VAL_AOI6}
        print(val_AOI)
        Map.setCenter(AOI_Lat.get(AOI_select.getValue()).getInfo(), AOI_Lon.get(AOI_select.getValue()).getInfo(), 8)
        //---S2
        var criteria = ee.Filter.and(ee.Filter.bounds(val_AOI), ee.Filter.date(START_DATE, END_DATE)); // Validation AOI Clipped
        s2Sr = s2Sr.filter(criteria).map(maskEdges);
        s2Clouds = s2Clouds.filter(criteria);
        var s2SrWithCloudMask = ee.Join.saveFirst('cloud_mask').apply({
          primary: s2Sr,
        secondary: s2Clouds,
          condition:
              ee.Filter.equals({leftField: 'system:index', rightField: 'system:index'})
       });
       var s2CloudMasked = ee.ImageCollection(s2SrWithCloudMask).map(maskClouds_S2).map(IC_Clip(val_AOI));
        var S2_merge = mosaicS2(s2CloudMasked)
        var S2_dates_list = S2_merge.map(function(image) {return ee.Feature(null, {'date': image.date().format('YYYY-MM-dd')})})
        .distinct('date')
        .aggregate_array('date')
        var S2_dates_list_string = S2_dates_list.getInfo() 
        var select = ui.Select({
          placeholder: '[Select a date to display the results]',
          items: S2_dates_list_string,
          onChange: function(key) {
            Map.layers().reset();
            print(select.getValue())
            var bia_ratio = slider_ratio.getValue()
            var nir_min = slider_nir_min.getValue()
            var nir_max = slider_nir_max.getValue()
            print(bia_ratio)
            print(nir_min)
            print(nir_max)
            // --- Original
            var s2_img_first_date=select.getValue()
            var s2_selected_img = S2_merge.filterDate(ee.Date(s2_img_first_date),ee.Date(s2_img_first_date).advance(1, 'day'))
            Map.addLayer(s2_selected_img,vizParams_S2,'Sentinel-2 False Color')
            // --- Classification
            var s2_selected_bia = BIA_mod_in(s2_selected_img.first())
            Map.addLayer(s2_selected_bia,{min: 0.2, max: 1, palette: ['00FFFF', '0000FF']},'Sentinel-2 Blue Ice Area')
            // Create an intro panel with labels.
            var intro = ui.Panel([
              ui.Label({
              value: 'Blue Ice Area' + AOI_Name.get(AOI_select.getValue()).getInfo(),
              style: {fontSize: '20px', fontWeight: 'bold'}
              }),
              ui.Label('Click a location within the displayed imagery to see its spectral profile. (It takes a while.)')
              ]);
            // Create panels to hold lon/lat values.
            var lon = ui.Label();
            var lat = ui.Label();
            // Add placeholders for the chart and legend.
        var inspect_spectra = ui.Button({
                label: 'Inspect Spectral Profile',
               onClick: function() {
                  panel_inspect_spa.add(intro);
                  panel_inspect_spa.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
                  panel_inspect_spa.add(ui.Label('Refresh your browser to get back to blue ice fraction.'));
                  Map.onClick(function(coords) {
              // Update the lon/lat panel with values from the click event.
              lon.setValue('lon: ' + coords.lon.toFixed(2)),
              lat.setValue('lat: ' + coords.lat.toFixed(2));
              // Add a red dot for the point clicked on.
              var point = ee.Geometry.Point(coords.lon, coords.lat);
              var dot = ui.Map.Layer(point, {color: 'FF0000'}, 'Location');
              Map.layers().set(3, dot);
              var wavelengths_S2 = [443.9, 496.6, 560, 664.5, 703.9, 740.2, 782.5,835.1,864.8,945,1613.7,2202.4];
              var bandChart_S2 = ui.Chart.image.regions({
                image: s2_selected_img.first().select(['B1','B2','B3','B4','B5','B6','B7','B8','B8A','B9','B11','B12']),
                regions: point,
                scale: 20,
                seriesProperty: 'label',
                xLabels: wavelengths_S2
              });
              bandChart_S2.setChartType('LineChart');
              bandChart_S2.setOptions({
              title: 'Sentinel-2 Spectra',
              hAxis: {
              title: 'Wavelength [nm]', viewWindow: {min: 350, max: 2300}
              },
              vAxis: {
                title: 'Reflectance', minValue:0, maxValue:10000
              },
              lineWidth: 1,
              pointSize: 4,
            });
           var stat_s2=s2_selected_img.first().sample({region:point,scale:20}).first()
           var stat_s2_b1=stat_s2.get('B1')
           var stat_s2_nir=stat_s2.get('B8A')
           var stat_s2_nir2=stat_s2.get('B9')
           var stat_s2_swir=stat_s2.get('B12')
           var ration_n =stat_s2_nir.getInfo()-stat_s2_swir.getInfo()
           var ratio_d =stat_s2_nir.getInfo()+stat_s2_swir.getInfo()
           var stat_s2_ratio = ration_n/ratio_d*1.0
            panel_inspect_spa.add(bandChart_S2);
            panel_inspect_spa.add(EMChart_S2);
            panel_inspect_spa.add(ui.Label('Inspection Short Summary:'));
            panel_inspect_spa.add(ui.Label('B1 (Blue) Reflectance: '+stat_s2_b1.getInfo()));
            panel_inspect_spa.add(ui.Label('B8A (NIR) Reflectance: '+stat_s2_nir.getInfo()));
            panel_inspect_spa.add(ui.Label('B9 (NIR) Reflectance: '+stat_s2_nir2.getInfo()));
            panel_inspect_spa.add(ui.Label('Ratio (NIR-SWIR): '+stat_s2_ratio));
          })
            }
          })
        class_panel_spa.widgets().set(12, inspect_spectra);
        function BIA_mod_in(img){
          var classified = (img.select("B8A").gt(nir_min)) 
            .and(img.select("B8A").lt(nir_max))
            .and(BR(img).gt(bia_ratio))
            .multiply(ee.Image(1)).rename('BIA_Modified')
          return ee.Image(classified.toInt16()).clip(val_AOI)//.rename(ee.String(image.get("LANDSAT_ID")))  
        }// 2.2. BIA Classification
        }
        })
        class_panel_spa.widgets().set(11, select);
        var NNC = slider_cloud_prob.getValue();
        print('NNC: ' + thirdname_select.getValue());
        print('NNC: ' + NNC);
        print('EM: ' + thirdname_select.getValue());
        function maskClouds_S2(img){
        var clouds = ee.Image(img.get('cloud_mask')).select('probability');
        var isNotCloud = clouds.lt(MAX_CLOUD_PROBABILITY);
        return img.updateMask(isNotCloud);
      }
  }
})
class_panel_spa.widgets().set(10, run_class);
  }
})
///------------Here------------------------------------------------------------------------------------- Look here
var secondname_select = ui.Select();
var thirdname_select = ui.Select();
var panel = ui.Panel();
panel.style().set({width: '300px', position: 'top-left','background-color': 'rgba(255, 255, 255, 0)'});
Map.add(panel);
panel.widgets().set(1,ui.Label('Welcome to FABIAN APP (Beta)', {fontWeight:'bold',color: 'black','background-color': 'rgba(255, 255, 255, 0)'}));
panel.widgets().set(2,ui.Label('Link to Publication', {color: 'black','background-color': 'rgba(255, 255, 255, 0)'},'https://doi.org/10.1016/j.rse.2022.113202'));
panel.widgets().set(3,ui.Label('Contact Dr. Zhongyang Hu (z.hu[at]uu.nl)', {color: 'black','background-color': 'rgba(255, 255, 255, 0)'}));
panel.widgets().set(4, Update);
panel.widgets().set(5, Explore);
panel.widgets().set(6, Download);
panel.widgets().set(7, Detail);
panel.widgets().set(8, piclogo);
Map.setCenter (66.27,-73,7);
// Clears the set of selected points and resets the overlay and results
// panel to their default state.
function clearResults() {
  Map.clear();
  panel_inspect.clear();
  Map.add(panel);
  Map.add(ui.Panel(
    [
      ui.Label('Blue Ice Fraction [%] ', LEGEND_TITLE_STYLE), makeLegend2(),
      ui.Label('(Median blue ice fraction derived from MODIS using SMA)', LEGEND_FOOTNOTE_STYLE),
      ui.Label('RMSE x1000 ', LEGEND_TITLE_STYLE), makeLegend(),
      ui.Label('(RMSE between MODIS and S2 in the bottom-right box)', LEGEND_FOOTNOTE_STYLE)
    ],
    ui.Panel.Layout.flow('vertical'),
    {width: '230px', position: 'bottom-left',backgroundColor: 'rgba(255, 255, 255, 0)'}));
}
// --- Function 9. Legends
var SMA_VIS_MAX_VALUE = 100;
var SMA_VIS_NONLINEARITY = 1;
// Apply a non-linear stretch (optional) to the SMA for visualization.
function colorStretch(image) {
  return image.divide(SMA_VIS_MAX_VALUE)
      .pow(1 / SMA_VIS_NONLINEARITY);
}
// Inverts the nonlinear stretch we apply to the SMAs for
// visualization, so that we can back out values to display in the legend.
// This uses ordinary JavaScript math functions, rather than Earth Engine
// functions, since we're going to call it from JS to compute label values.
function undoColorStretch(val) {
  return Math.pow(val, SMA_VIS_NONLINEARITY) * SMA_VIS_MAX_VALUE;
}
// A color bar widget. Makes a horizontal color bar to display the given
// color palette.
function ColorBar(palette) {
  return ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 1, 0.1],
      dimensions: '150x11',
      format: 'png',
      min: 0,
      max: 1,
      palette: palette,
      backgroundColor:'rgba(0,0,0,0.5)',
      backgroundColor: '#000',
    },
    style: {stretch: 'horizontal', margin: '0px 0px',backgroundColor: 'rgba(0,0,0,0)',},
  });
}
// Returns our labeled legend, with a color bar and three labels representing
// the minimum, middle, and maximum values.
function makeLegend() {
  var labelPanel = ui.Panel(
      [
        ui.Label(Math.round(undoColorStretch(0)), {margin: '0px 0px',backgroundColor: 'rgba(0,0,0,0)'}),
        ui.Label(
            Math.round(undoColorStretch(0.5)),
            {margin: '0px 0px', textAlign: 'center', stretch: 'horizontal'}),
        ui.Label(Math.round(undoColorStretch(1)), {margin: '0px 0px',backgroundColor: 'rgba(0,0,0,0)'})
      ],
      ui.Panel.Layout.flow('horizontal'));
  return ui.Panel([ColorBar(RMSE_STYLE.palette), /*labelPanel*/]);
}
function makeLegend2() {
  var labelPanel = ui.Panel(
      [
        ui.Label(Math.round(undoColorStretch(0)), {margin: '0px 0px',backgroundColor: 'rgba(0, 0, 0, 0)'}),
        ui.Label(
            Math.round(undoColorStretch(0.5)),
            {margin: '0px 0px', textAlign: 'center', stretch: 'horizontal',backgroundColor: 'rgba(0, 0, 0, 0)'}),
        ui.Label(Math.round(undoColorStretch(1)), {margin: '0px 0px',backgroundColor: 'rgba(0, 0, 0, 0)'})
      ],
      ui.Panel.Layout.flow('horizontal'));
  return ui.Panel([ColorBar(BIF_STYLE.palette), /*labelPanel*/]);
}
//******************************************************************************************************************************
// *****************************************************************************************************************************
// ---------- V. Functions ********************************************************************************************************
// *****************************************************************************************************************************
// ---------- Function 0. General
function Ori_ID(image) {
  return image.set('origional_id', image.get('system:index'));
} // Keep original ID
function Benchmark_rename(img){
  return img.rename(['BI_EM_BM', 'SN_EM_BM', 'RK_EM_BM', 'MS_EM_BM', 'CS_EM_BM', 'WA_EM_BM','RMSE_BM'])
}
// ---------- Function 1. Cloud Mask modified from https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2_CLOUD_PROBABILITY
// The masks for the 10m bands sometimes do not exclude bad data at scene edges, so we apply masks from the 20m and 60m bands as well.
function maskEdges(s2_img){
  return s2_img.updateMask(
      s2_img.select('B8A').mask().updateMask(s2_img.select('B9').mask()));
}
function maskClouds_S2(img){
  var clouds = ee.Image(img.get('cloud_mask')).select('probability');
  var isNotCloud = clouds.lt(MAX_CLOUD_PROBABILITY);
  return img.updateMask(isNotCloud);
}
// ---------- Function 2. Blue Ice Area from Hui et al., 2014
function BR(img){
  var ndsi = img.normalizedDifference(['B8A', 'B12']).rename('BR');
  return ee.Image(ndsi);
} // 2.1. Band Ratio 47
function BIA_mod(img){
  var classified = (img.select("B8A").gt(3000)) 
    .and(img.select("B8A").lt(7000))
    .and(BR(img).gt(0.85))
  .multiply(ee.Image(1)).rename('BIA_Modified')
  return ee.Image(classified.toInt16())//.rename(ee.String(image.get("LANDSAT_ID")))  
}// 2.2. BIA Classification
function add_BIA_mod(img){
  return maskClouds_S2(img).addBands(BIA_mod(img))
}// 2.3. add BIA Classification to the cloud masked image
// ---------- Function 3. Clipping Image Collection
function IC_Clip(aoi){
  return (function Do_clip(img){
    var Clipped_img=img.clip(aoi)
    return ee.Image(Clipped_img)
  });
}
function SMA_Ref_to_Fra(EMs, EM_Names, NNC) {
  return (function DO_SMA(img) {
    var SMA_Fra = img.unmix(EMs,true, NNC).rename(EM_Names);
    return ee.Image(SMA_Fra)
  }); 
} // SMA for ee.Collection https://developers.google.com/earth-engine/apidocs/ee-image-unmix
// ---------- Function 4. Only keep BIA
function only_BIA(img){
  var BIA = img.eq(1)
  return img.updateMask(BIA) 
}
// ---------- Function 5. S2 to MODIS
// https://developers.google.com/earth-engine/guides/resample
//https://gis.stackexchange.com/questions/380910/how-gee-align-pixels-and-projection-when-reduce-resolution
function S2_to_MOD(img){
  var BIA_SUB = img.select('BIA_Modified');
  var BIF_Full = BIA_SUB.reproject({crs:'SR-ORG:6974', scale: 20}).reduceResolution({
        reducer: ee.Reducer.count(), 
        maxPixels: 1e4}).reproject({crs:modisProjection}).rename('BIC_Full');
  var BIA = BIA_SUB.eq(1);
  var IMG_Masked = BIA_SUB.updateMask(BIA);
  var BIF_Masked = IMG_Masked.reproject({crs:'SR-ORG:6974', scale: 20}).reduceResolution({
        reducer: ee.Reducer.count(), 
        maxPixels: 1e4}).reproject({crs:modisProjection}).rename('BIC_Masked');
  var BIF_Percentage= BIF_Masked.divide(BIF_Full).rename('BIF_Percentage');
  return BIF_Full.addBands(BIF_Masked).addBands(BIF_Percentage)
}
// ---------- Function 6. MODIS Cloud Masking
// Calculate how frequently a location is labeled as clear (i.e. non-cloudy) according to the "internal cloud algorithm flag" of the MODIS "state 1km" QA band.
function maskEmptyPixels(img){
  // Find pixels that had observations.
  var withObs = img.select('num_observations_1km').gt(0)
  return img.updateMask(withObs)
}// A function to mask out pixels that did not have observations.
function maskClouds(img) {
  var QA = img.select('state_1km') // Select the QA band.
  var bitMask = 1 << 10; // Make a mask to get bit 10, the internal_cloud_algorithm_flag bit.
  return img.updateMask(QA.bitwiseAnd(bitMask).eq(0)) // Return an image masking out cloudy areas.
}// A function to mask out cloudy pixels.
function mosaicMOD(imcol){
  var imlist = imcol.toList(imcol.size());
  var unique_dates = imlist.map(function(im){
    return ee.Image(im).date().format("YYYY-MM-dd");
  }).distinct();
  var mosaic_imlist = unique_dates.map(function(d){
    d = ee.Date(d);
    var im = imcol
      .filterDate(d, d.advance(1, "day"))
      .mosaic();
    return im.set(
        "system:time_start", d.millis(), 
        "system:index", d.format("YYYY_MM_dd"))
  })
  return ee.ImageCollection(mosaic_imlist)
}
// ---------- Function 7. SMA
function SMA_Ref_to_Fra(EMs, EM_Names, NNC) {
  return (function DO_SMA(img) {
    var SMA_Fra = img.unmix(EMs,true, NNC).rename(EM_Names);
    return ee.Image(SMA_Fra)
  }); 
} // SMA for ee.Collection https://developers.google.com/earth-engine/apidocs/ee-image-unmix
function SMA_Ref_to_Fra_add(EMs, EM_Names, NNC) {
  return (function DO_SMA(img) {
    var SMA_Fra = img.unmix(EMs,true, NNC).rename(EM_Names);
    return img.addBands(ee.Image(SMA_Fra)) 
  }); 
} // MODIS + SMA Fractions
function SMA_Ref_to_Fra_NN(EMs, EM_Names) {
  return (function DO_SMA(img) {
    var SMA_Fra = img.unmix(EMs,true, true).rename(EM_Names);
    return ee.Image(SMA_Fra)
  }); 
} 
function SMA_Ref_to_Fra_NN_add(EMs, EM_Names) {
  return (function DO_SMA(img) {
    var SMA_Fra = img.unmix(EMs,true, true).rename(EM_Names);
    return img.addBands(ee.Image(SMA_Fra)) 
  }); 
} 
function SMA_Fra_to_Ref(EMs){
  return (function Apply_SMA(img) {
    var Fraction_Image1D = img.toArray();
    var Fraction_Image2D = Fraction_Image1D.toArray(1);
    var SMA_Ref = ee.Image(EMs.matrixTranspose()).matrixMultiply(Fraction_Image2D)
    .arrayProject([0])
    .arrayFlatten([['SMA_Ref_b01', 'SMA_Ref_b02', 'SMA_Ref_b03','SMA_Ref_b04', 'SMA_Ref_b05', 'SMA_Ref_b06','SMA_Ref_b07']]);
    return ee.Image(SMA_Ref); 
  }); 
} // SMA for ee.Collection https://developers.google.com/earth-engine/apidocs/ee-image-unmix
function SMA_RMSE(img){
  var img_ori = img.select(['sur_refl_b01', 'sur_refl_b02', 'sur_refl_b03','sur_refl_b04', 'sur_refl_b05', 'sur_refl_b06','sur_refl_b07']);
  var img_sma = img.select(['SMA_Ref_b01', 'SMA_Ref_b02', 'SMA_Ref_b03','SMA_Ref_b04', 'SMA_Ref_b05', 'SMA_Ref_b06','SMA_Ref_b07']);
  var diff = img_ori.subtract(img_sma);
  var SE = diff.pow(2);
  var SSE = SE.reduce('sum');
  var MSE = SSE.divide(7);
  var RMSE = MSE.pow(0.5);
  var RMSE_RN = RMSE.divide(10).rename('RMSE') 
  return img.addBands(RMSE_RN)
}
// --- Function 8. Validation S-2
function mosaicS2(imcol){
  var imlist = imcol.toList(imcol.size());
  var unique_dates = imlist.map(function(im){
    return ee.Image(im).date().format("YYYY-MM-dd");
  }).distinct();
  var mosaic_imlist = unique_dates.map(function(d){
    d = ee.Date(d);
    var im = imcol
      .filterDate(d, d.advance(1, "day"))
      .mosaic();
    return im.set(
        "system:time_start", d.millis(), 
        "system:index", d.format("YYYY_MM_dd"))
  })
  return ee.ImageCollection(mosaic_imlist)
}
function VAL_RMSE_Mask(BIF){
  return(function do_RMSE(img){
  var S2 = img.select('BIF_Percentage');
  var MOD = img.select(BIF);
  var MOD_mask = MOD.updateMask(S2);
  var S2_mask = S2.updateMask(MOD_mask);
  var diff = MOD_mask.subtract(S2_mask);
  var SE = diff.pow(2);
  return SE.rename('SE')
  });  
}
function VAL_Mask(img){
  var S2 = img.select('BIF_Percentage');
  var MOD = img.select('BI_EM');
  var MOD_BM = img.select('BI_EM_BM');
  var MOD_mask = MOD.updateMask(S2);
  var MOD_BM_mask = MOD_BM.updateMask(S2);
  var S2_mask = S2.updateMask(MOD_mask);
  return S2_mask.addBands(MOD_mask).addBands(MOD_BM_mask)
}
// Styling for the legend title.
var LEGEND_TITLE_STYLE = {
  fontSize: '15px',
  fontWeight: 'bold',
  stretch: 'horizontal',
  textAlign: 'center',
  margin: '6px',
  backgroundColor: 'rgba(0,0,0,0)',
};
// Styling for the legend footnotes.
var LEGEND_FOOTNOTE_STYLE = {
  fontSize: '12px',
  stretch: 'horizontal',
  textAlign: 'left',
  margin: '6px',
  backgroundColor: 'rgba(255, 255, 255, 0)',
};
// Styling for the legend footnotes.
var LEGEND_Label = {
  fontSize: '16px',
  stretch: 'horizontal',
  textAlign: 'left',
  margin: '0px',
  backgroundColor: 'rgba(255, 255, 255, 0)',
};
function undoColorStretch(val) {
  return Math.pow(val, SMA_VIS_NONLINEARITY) * SMA_VIS_MAX_VALUE;
}
// A color bar widget. Makes a horizontal color bar to display the given
// color palette.
function ColorBar(palette) {
  return ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 1, 0.1],
      dimensions: '150x11',
      format: 'png',
      min: 0,
      max: 1,
      palette: palette,
      backgroundColor:'rgba(0,0,0,0.5)',
      backgroundColor: '#000',
    },
    style: {stretch: 'horizontal', margin: '0px 0px',backgroundColor: 'rgba(0,0,0,0)',},
  });
}
// Returns our labeled legend, with a color bar and three labels representing
// the minimum, middle, and maximum values.
function makeLegend() {
  var labelPanel = ui.Panel(
      [
        ui.Label(Math.round(undoColorStretch(0)), {margin: '0px 0px',backgroundColor: 'rgba(0,0,0,0)'}),
        ui.Label(
            Math.round(undoColorStretch(0.5)),
            {margin: '0px 0px', textAlign: 'center', stretch: 'horizontal'}),
        ui.Label(Math.round(undoColorStretch(1)), {margin: '0px 0px',backgroundColor: 'rgba(0,0,0,0)'})
      ],
      ui.Panel.Layout.flow('horizontal'));
  return ui.Panel([ColorBar(RMSE_STYLE.palette), /*labelPanel*/]);
}
function makeLegend2() {
  var labelPanel = ui.Panel(
      [
        ui.Label(Math.round(undoColorStretch(0)), {margin: '0px 0px',backgroundColor: 'rgba(0, 0, 0, 0)'}),
        ui.Label(
            Math.round(undoColorStretch(0.5)),
            {margin: '0px 0px', textAlign: 'center', stretch: 'horizontal',backgroundColor: 'rgba(0, 0, 0, 0)'}),
        ui.Label(Math.round(undoColorStretch(1)), {margin: '0px 0px',backgroundColor: 'rgba(0, 0, 0, 0)'})
      ],
      ui.Panel.Layout.flow('horizontal'));
  return ui.Panel([ColorBar(BIF_STYLE.palette), /*labelPanel*/]);
}
function BIA_combi(img){
  var FBIA=img.select('BI_EM') 
  var FSL=img.select('SL_EM') 
  var FBIAC=FBIA.add(FSL).rename('BS_EM')
  return img.addBands(FBIAC)
}