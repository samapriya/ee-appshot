//PARTE 1. NDVI Threshold
//Agregar coleccion Landsat8 TOA
var l8 = ee.ImageCollection("LANDSAT/LC08/C01/T1_TOA")
// Defina una funcion que calculara NDVI a partir de una imagen Landsat 8.
var addNDVI = function(image) {
  var cloud = ee.Algorithms.Landsat.simpleCloudScore(image).select('cloud');
  var mask = cloud.lt(20);
  var ndvi = image.normalizedDifference(['B5', 'B4']).rename('NDVI');
  return image.addBands(ndvi).updateMask(mask);
};
// Filtre y asigne la funcion a la coleccion.
var withNDVI = l8.filterDate('2020-01-01', '2020-12-31')
    .map(addNDVI); // <-- map() the function over the collection.
var ndvi = withNDVI.median().select('NDVI');
var vis = {min: -0.2, max: 0.7, palette: ['blue', 'white', 'green']};
// Create and style widgets.
var minLabel = ui.Label({
  value: 'NDVI Minimo:',
  style: {stretch: 'vertical'}
});
var textbox = ui.Textbox({
  placeholder: 'entre -1 and 1',
  onChange: function(value) {
    Map.layers().reset();
    var threshold = Number(value);
    var mask = ndvi.gt(threshold);
    var masked = ndvi.updateMask(mask);
    Map.addLayer(masked, vis, 'NDVI');
  },
  style: {width: '120px'}
});
var panel = ui.Panel({
  widgets: [minLabel, textbox],
  layout: ui.Panel.Layout.flow('horizontal')
});
// Configurar el mapa.
Map.add(panel);
Map.style().set('cursor', 'crosshair');
Map.setCenter(-87, 14, 10);
Map.addLayer(ndvi, vis, 'NDVI');