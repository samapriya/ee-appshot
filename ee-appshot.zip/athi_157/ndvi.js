var ndviParams = ui.import && ui.import("ndviParams", "imageVisParam", {
      "params": {
        "min": -1,
        "max": 1,
        "palette": [
          "red",
          "yellow",
          "green"
        ]
      }
    }) || {"min":-1,"max":1,"palette":["red","yellow","green"]},
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            98.6347783966698,
            3.464049721378993
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #d63000 */ee.Geometry.Point([98.6347783966698, 3.464049721378993]);
ui.root.clear()
//Siapkan canvasnya
var mapndvi = ui.Map({
  lat: -1.52,
  lon: 102.53,
  zoom: 8});
//Siapkan shapefile batas administrasi kajian
var admin = ee.FeatureCollection("FAO/GAUL/2015/level2");
var filter = ee.Filter.inList('ADM1_NAME', ['Jambi']);
var deliserdang = admin.filter(filter);
//==================================================================================================
                  //=======NDVI 2020=======
//Load citra satelit (image collection)
var landsat_col = ee.ImageCollection("LANDSAT/LC08/C01/T1")
    .filterDate('2020-01-01', '2020-12-31')
    .filterBounds(deliserdang);
var composite = ee.Algorithms.Landsat.simpleComposite({
 collection: landsat_col,
 asFloat: true
});
print(composite);
mapndvi.style().set('cursor', 'crosshair');
// Metode 2) Fungsi NDVI GEE
var ndvi20 = composite.normalizedDifference(["B5", "B4"]);
//mapndvi.addLayer(ndvi20.clip(deliserdang), ndviParams, "NDVI 2020");
                    //=======NDVI 2019========
//Load citra satelit (image collection)
var landsat_col = ee.ImageCollection("LANDSAT/LC08/C01/T1")
    .filterDate('2019-01-01', '2019-12-31')
    .filterBounds(deliserdang);
var composite = ee.Algorithms.Landsat.simpleComposite({
 collection: landsat_col,
 asFloat: true
});
print(composite);
// Metode 2) Fungsi NDVI GEE
var ndvi19 = composite.normalizedDifference(["B5", "B4"]);
//mapndvi.addLayer(ndvi19.clip(deliserdang), ndviParams, "NDVI 2019");
                    //=======NDVI 2018=========
//Load citra satelit (image collection)
var landsat_col = ee.ImageCollection("LANDSAT/LC08/C01/T1")
    .filterDate('2018-01-01', '2018-12-31')
    .filterBounds(deliserdang);
var composite = ee.Algorithms.Landsat.simpleComposite({
 collection: landsat_col,
 asFloat: true
});
print(composite);
// Metode 2) Fungsi NDVI GEE
var ndvi18 = composite.normalizedDifference(["B5", "B4"]);
//mapndvi.addLayer(ndvi18.clip(deliserdang), ndviParams, "NDVI 2018");
                    //======NDVI 2017=========
//Load citra satelit (image collection)
var landsat_col = ee.ImageCollection("LANDSAT/LC08/C01/T1")
    .filterDate('2017-01-01', '2017-12-31')
    .filterBounds(deliserdang);
var composite = ee.Algorithms.Landsat.simpleComposite({
 collection: landsat_col,
 asFloat: true
});
print(composite);
// Metode 2) Fungsi NDVI GEE
var ndvi17 = composite.normalizedDifference(["B5", "B4"]);
//mapndvi.addLayer(ndvi17.clip(deliserdang), ndviParams, "NDVI 2017");
                    //=======NDVI 2016=========
//Load citra satelit (image collection)
var landsat_col = ee.ImageCollection("LANDSAT/LC08/C01/T1")
    .filterDate('2016-01-01', '2016-12-31')
    .filterBounds(deliserdang);
var composite = ee.Algorithms.Landsat.simpleComposite({
 collection: landsat_col,
 asFloat: true
});
print(composite);
// Metode 2) Fungsi NDVI GEE
var ndvi16 = composite.normalizedDifference(["B5", "B4"]);
//mapndvi.addLayer(ndvi16.clip(deliserdang), ndviParams, "NDVI 2016");
//==================================================================================================
////Membuat grafik time series ndvi 
// Import citra landsat Landsat 8 TOA image collection.
var l8 = ee.ImageCollection('LANDSAT/LC08/C01/T1_TOA')
    .filterDate('2016-01-01', '2020-12-31')
var cloudlessNDVI = l8.map(function(image) {
  // Cara menseleksi cloud score in [0, 100].
  var cloud = ee.Algorithms.Landsat.simpleCloudScore(image).select('cloud');
  // Batasan cloud cover yaitu 20.
  var mask = cloud.lte(20);
  // Compute NDVI.
  var ndvi = image.normalizedDifference(['B5', 'B4']).rename('NDVI');
// nggak tau
  var time = image.get('system:time_start');
  // Return the masked image with an NDVI band.
  return image.addBands(ndvi).updateMask(mask);
});
print(ui.Chart.image.series({
  imageCollection: cloudlessNDVI.select('NDVI'),
  region: geometry,
  reducer: ee.Reducer.first(),
  scale: 30,
})
.setOptions({title: 'NDVI 2016-2017 Provinsi Jambi'}));
/*
//===     kalau pakai slider, var ini dipakai   ===
var showLayer = function(year) {
  mapndvi.layers().reset();
  var date = ee.Date.fromYMD(2016, 1, 1);
  var dateRange = ee.DateRange(date, date.advance(1, 'year'), '+1 year');
  var image = landsat_col.filterDate(dateRange).first();
  mapndvi.addLayer({
    eeObject: ee.Image(image),
    visParams: {
      min: 0,
      max: 63,
      palette:['FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718',
               '74A901', '66A000', '529400', '3E8601', '207401', '056201',
               '004C00', '023B01', '012E01', '011D01', '011301']
    },
    name: String(year)
  });
}; 
*/
// =================================================================================================
// SETTING FONT
var colors = {'transparent': '#11ffee00', 'gray': '#F8F9FA'};
var TITLE_STYLE = {
  fontWeight: '100',
  fontSize: '32px',
  padding: '8px',
  color: '#616161',
  backgroundColor: colors.transparent,
};
var PARAGRAPH_STYLE = {
  fontSize: '18px',
  fontWeight: '60',
  color: '#616161',
  //padding: '18px',
  margin: '10px 0px 0px 18px',
  backgroundColor: colors.transparent,
};
var LABEL_STYLE = {
  fontWeight: '50',
  textAlign: 'center',
  fontSize: '11px',
  backgroundColor: colors.transparent,
};
var SUBTITLE_STYLE = {
  fontWeight: 'bold',
  fontSize: '22px',
  padding: '22px',
  color: '#616161',
  textAlign: 'center',
  margin: '4px',
  maxWidth: '450px',
  backgroundColor: colors.transparent,
};
//==================================================================================================
// Create a label and slider.
var label = ui.Label('Pilih tahun pada panel di samping');
/*
var slider = ui.Slider({
  min: 2016,
  max: 2020,
  step: 1,
  //onChange: showLayer, //variabel showlayer belum bisa dirunning
  style: {stretch: 'horizontal'}
});
*/
// Create a panel that contains both the slider and the label.
var panel = ui.Panel({
  widgets: [label],
  layout: ui.Panel.Layout.flow(),
  style: {
    position: 'top-center',
    padding: '7px',
    stretch: 'horizontal',
    height: '100%',
    width: '450px',
    //backgroundColor: colors.gray
  }
});
//==================================================================================================
///kalo bikin logo di panel
/*
var logo = ee.Image('users/<username>/<asetID>').visualize({
    bands:  ['b1', 'b2', 'b3'],
    min: 0,
    max: 255
    });
var thumb = ui.Thumbnail({
    image: logo,
    params: {
        dimensions: '642x291',
        format: 'png'
        },
    style: {height: '127px', width: '280px',padding :'0'}
    });
var toolPanel = ui.Panel(thumb, 'flow', {width: '300px'});
ui.root.widgets().add(toolPanel);
*/
//  LEGEND SETTING
// Creates a color bar thumbnail image for use in legend from the given color
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '100x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
// Create the color bar for the legend.
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(ndviParams.palette),
  style: {stretch: 'horizontal', margin: '0px 8px', maxHeight: '24px'},
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(ndviParams.min, {margin: '4px 8px'}),
    ui.Label(
        (ndviParams.max / 2),
        {margin: '4px 8px', textAlign: 'center', stretch: 'horizontal'}),
    ui.Label(ndviParams.max, {margin: '4px 8px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
var legendTitle = ui.Label({
  value: 'Legenda',
  style: {fontWeight: 'bold'}
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
panel.widgets().set(3, legendPanel);
// nambahin plot 
var timeseries = ui.Chart.image.series(cloudlessNDVI.select('NDVI'), geometry, ee.Reducer.first(), 30);
  timeseries.setOptions({title: 'NDVI 2016-2017 Provinsi Jambi'
  });
  panel.widgets().set(2, timeseries);
//==================================================================================================
// DESKRIPSI PANEL
// masukin JUDUL                            
var visPanel = ui.Panel({style: {backgroundColor: colors.transparent}}); 
panel.add(ui.Label('Analisis Perubahan Tutupan Lahan Akibat Kebakaran Hutan di Provinsi Jambi Tahun 2016-2020', TITLE_STYLE));
// masukin info
var descText =
    'Indeks vegetasi atau NDVI adalah indeks yang menggambarkan '+
    'tingkat kehijauan suatu tanaman. Indeks vegetasi merupakan ' +
    'kombinasi matematis antara band merah (Red) dan band NIR (Near-Infrared Radiation) '+
    'yang telah lama digunakan sebagai indikator keberadaan dan kondisi vegetasi. ' +
    '';
panel.add(ui.Label(descText, PARAGRAPH_STYLE));
var rentang =
    'Indeks NDVI mempunyai interval antara -1 hingga 1.'+
    'Nilai 1 menandakan tutupan vegetasi masih tinggi,'+
    'sedangkan -1 menandakan tutupan vegetasi sangat rendah.' +
    'NDVI dapat dihitung dengan rumus sebagai berikut : ' +
    '';
panel.add(ui.Label(rentang, PARAGRAPH_STYLE));
panel.add(ui.Label('NDVI = (NIR-Red/NIR+Red)', SUBTITLE_STYLE));
/*
panel.add(ui.Label('Rekapitulasi Luas Kebakaran Hutan dan Lahan Provinsi Jambi :', PARAGRAPH_STYLE));
var area = 
    '2016 = 8.281,25 Ha, ' +
    '2017 = 109,17 Ha, ' +
    '2018 = 1.577,75 Ha, ' +
    '2019 = 56.593,00 Ha, ' +
    '2020 = 1.002,00 Ha, ';
panel.add(ui.Label(area, PARAGRAPH_STYLE));
*/
var judul = ui.Panel(
  ui.Label({
    value: 'Rekapitulasi Luas Kebakaran Hutan dan Lahan Provinsi Jambi',
    style: {fontSize: '20px', fontWeight: 'bold', margin: '18px 0px 6px 18px'}
  }));
panel.add(judul);
var intro = ui.Panel([
  ui.Label(('2016 = 8.281,25 Ha'), {margin: '0 20px 0 20px', fontSize: '17px', color: '#616161'}),
  ui.Label(('2017 = 109,17 Ha'), {margin: '0 20px 0 20px', fontSize: '17px', color: '#616161'}),
  ui.Label(('2018 = 1.577,75 Ha'), {margin: '0px 20px 0 20px', fontSize: '17px', color: '#616161'}),
  ui.Label(('2019 = 56.593,00 Ha'), {margin: '0 20px 0 20px', fontSize: '17px', color: '#616161'}),
  ui.Label(('2020 = 1.002,00 Ha'), {margin: '0 20px 0 20px', fontSize: '17px', color: '#616161'}),
]);
panel.add(intro);
//==================================================================================================
//Bikin Checkbox
Map.setOptions('satellite');
//membuat checkbox
var ndvi2016 = ui.Checkbox('NDVI 2016', true);
var ndvi2017 = ui.Checkbox('NDVI 2017', true);
var ndvi2018 = ui.Checkbox('NDVI 2018', true);
var ndvi2019 = ui.Checkbox('NDVI 2019', true);
var ndvi2020 = ui.Checkbox('NDVI 2020', true);
ndvi2016.onChange(function(checked) {
  mapndvi.layers().get(0).setShown(checked);
});
ndvi2017.onChange(function(checked) {
  mapndvi.layers().get(1).setShown(checked);
});
ndvi2018.onChange(function(checked) {
  mapndvi.layers().get(2).setShown(checked);
});
ndvi2019.onChange(function(checked) {
  mapndvi.layers().get(3).setShown(checked);
});
ndvi2020.onChange(function(checked) {
  mapndvi.layers().get(4).setShown(checked);
});
mapndvi.addLayer(ndvi16.clip(deliserdang), ndviParams, "NDVI 2016");
mapndvi.addLayer(ndvi17.clip(deliserdang), ndviParams, "NDVI 2017");
mapndvi.addLayer(ndvi18.clip(deliserdang), ndviParams, "NDVI 2018");
mapndvi.addLayer(ndvi19.clip(deliserdang), ndviParams, "NDVI 2019");
mapndvi.addLayer(ndvi20.clip(deliserdang), ndviParams, "NDVI 2020");
var cb = ui.Panel({
  widgets: [ndvi2016, ndvi2017, ndvi2018, ndvi2019, ndvi2020,],
  style: {position: 'top-right', padding: '10px 16px'}
});
mapndvi.add(cb);
//==================================================================================================
var kel = ui.Panel(
  ui.Label({
    value: 'Oleh : Kelompok 2',
    style: {margin: '18px 20px 0 17px', fontSize: '15px', fontWeight: 'bold', padding: '0px'}
  }));
panel.add(kel);
var nm = ui.Panel([
  ui.Label(('Rahmi Syafura (G24180050)'), {margin: '0 20px 0 20px', fontSize: '13px', color: '#616161'}),
  ui.Label(('Athirotul Wardah MY (G24180058)'), {margin: '0 20px 0 20px', fontSize: '13px', color: '#616161'}),
  ui.Label(('Arman Effendi (G24180074)'), {margin: '0 20px 0 20px', fontSize: '13px', color: '#616161'}),
  ui.Label(('Ayu Idha Mufidha (G24180008)'), {margin: '0 20px 0 20px', fontSize: '13px', color: '#616161'}),
  ui.Label(('Maulida Hasanah (G24180042)'), {margin: '0 20px 0 20px', fontSize: '13px', color: '#616161'}),
  ui.Label(('Rendra Rizki Lutfiansyah (G24180020)'), {margin: '0 20px 0 20px', fontSize: '13px', color: '#616161'}),
  ui.Label(('Ikhsanul Putra Sandy (G24180028)'), {margin: '0 20px 0 20px', fontSize: '13px', color: '#616161'}),
  ui.Label(('Wulan Hidayah Azhar (G24180026)'), {margin: '0 20px 0 20px', fontSize: '13px', color: '#616161'}),  
]);
panel.add(nm);
ui.root.add(ui.SplitPanel(mapndvi, panel)); //map di kanan, panel di kiri