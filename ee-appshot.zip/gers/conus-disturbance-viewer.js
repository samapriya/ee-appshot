var agentImageCollection = ee.ImageCollection('users/ShiQiu/product/conus/disturbance/v00/APRI');
//******START OF PARAMETERS******
var globalYearStartDefault = 1985; var globalYearEndDefault = 2020;
var globalYearStart = globalYearStartDefault; var globalYearEnd = globalYearEndDefault;
var globalNumYears = globalYearEnd - globalYearStart + 1; // Number of years
// All years that will be shown in the 
var globalYearsString = [];
for (var iYear = globalYearStart; iYear <= globalYearEnd; iYear++) { // Loop selected years
  globalYearsString.push(iYear.toString());
}
// Some pre-set locations of interest that will be loaded into a pulldown menu.
var locationDict = {
  'CONUS-Wide': {lon: -91.03677, lat: 30.55435, zoom: 5},
  'Tornado in Alabama': {lon: -87.332, lat: 33.313, zoom: 11}
};
//******END OF PARAMETERS******
//******START OF STYPE******
// The below lists show the colorbar for each land disturbance agent from 1985 to most recent year like 2020
var colorbar_forest_management = 
['#DCF5E9', '#D5F0E2', '#CEEBDB', '#CAE8D6', '#C3E3D0', '#BDDEC9', '#B6D9C2', '#B2D6BE', '#ABD1B7', '#A5CCB2', '#9DC7AA', '#99C4A5', '#93BFA0', '#8DBA99', '#88B895', '#82B38E', '#7FB08B', '#78AB84', '#72A67E', '#6DA37A', '#689E75', '#649C71', '#5F966C', '#599166', '#548F62', '#4E8A5B', '#4A8758', '#458252', '#41804F', '#3D7D4C', '#387847', '#347543', '#2F703E', '#2B6E3A', '#266936', '#226633'] 
var colorbar_agriculture_activity = 
['#FFFFBE', '#FFFFB9', '#FFFFB3', '#FFFFAE', '#FFFFA8', '#FFFFA3', '#FFFF9D', '#FFFF98', '#FFFF93', '#FFFF8D', '#FFFF88', '#FFFF82', '#FFFF7D', '#FFFF77', '#FFFF72', '#FFFF6D', '#FFFF67', '#FFFF62', '#FFFF5C', '#FFFF57', '#FFFF51', '#FFFF4C', '#FFFF47', '#FFFF41', '#FFFF3C', '#FFFF36', '#FFFF31', '#FFFF2B', '#FFFF26', '#FFFF21', '#FFFF1B', '#FFFF16', '#FFFF10', '#FFFF0B', '#FFFF05', '#FFFF00']
var colorbar_construction = 
['#FFCCCC', '#FFC6C4', '#FFC1BD', '#FFBEB8', '#FFB8B0', '#FFB1A8', '#FFACA1', '#FFA79C', '#FFA294', '#FF9E8F', '#FF9787', '#FF9382', '#FF8E7A', '#FC8974', '#FC846F', '#FC806A', '#FA7A64', '#FA745C', '#F76F57', '#F76A52', '#F5654C', '#F56147', '#F25941', '#F2573F', '#F0523A', '#F04E35', '#ED462F', '#EB412A', '#E83C25', '#E83420', '#E6321E', '#E32A19', '#E02514', '#E01E10', '#DE1409', '#DB0000']
var colorbar_stress = 
['#F0ECAA', '#EBE6A7', '#E8E2A2', '#E3DC9F', '#DED699', '#D9D096', '#D6CC92', '#D1C68C', '#CCC089', '#C9BC85', '#C4B682', '#BFB07C', '#BDAC7B', '#B8A676', '#B5A372', '#B09E6F', '#AB976A', '#A89468', '#A38E64', '#A18A60', '#9C865D', '#99825A', '#947C56', '#917853', '#8C7350', '#8A704D', '#856B49', '#826746', '#806444', '#7A5F41', '#785C3E', '#73573B', '#705338', '#6E5036', '#694C32', '#664830'] 
var colorbar_debris = 
['#E5D5F2', '#E0CEED', '#DDCAEB', '#D8C3E6', '#D3BCE0', '#CFB8DE', '#CAB2D9', '#C8AED6', '#C2A7D1', '#BFA3CF', '#BB9DC9', '#B899C7', '#B291C2', '#AD8CBD', '#AA88BA', '#A582B5', '#A27FB3', '#A079B0', '#9A74AB', '#9871A8', '#926AA3', '#8F67A1', '#8A609C', '#885D99', '#855996', '#805491', '#7D508F', '#784A8A', '#754887', '#724485', '#6D3E80', '#6A3B7D', '#67377A', '#643478', '#602F73', '#5D2C70']
var colorbar_water_dynamic = 
['#D6D6FF', '#CDCEFA', '#C6C8F7', '#BCBEF5', '#B6B9F2', '#ADB1ED', '#A4A9EB', '#9EA4E8', '#959DE6', '#8F97E3', '#8791DE', '#7F8BDB', '#7986D9', '#7281D6', '#6C7DD4', '#6577CF', '#5E72CC', '#596FC9', '#5269C7', '#4D67C4', '#4763BF', '#405DBD', '#3C5BBA', '#3558B8', '#3154B5', '#2A50B0', '#264FAD', '#224BAB', '#1D49A8', '#1948A6', '#1342A1', '#10429E', '#0C419C', '#083D99', '#053C96', '#003994']
var colorbar_fire = 
['#FFEBCC', '#FFE8C7', '#FFE3BF', '#FFE0BA', '#FFDDB3', '#FFD9AD', '#FFD5A8', '#FFD1A1', '#FFCF9C', '#FFCB96', '#FFC78F', '#FFC48A', '#FFC085', '#FFBD80', '#FFBA7A', '#FFB875', '#FFB16E', '#FFAF69', '#FFAC63', '#FFA95E', '#FFA759', '#FCA253', '#FCA151', '#FC9E4C', '#FC9C47', '#FA9441', '#FA913C', '#F78D36', '#F78B31', '#F7882D', '#F58727', '#F58522', '#F2811D', '#F27D16', '#F0780E', '#F07605'] 
var colorbar_other = 
['#DBDBDB', '#D6D6D6', '#D1D1D1', '#CCCCCC', '#C7C7C7', '#C2C2C2', '#BDBDBD', '#B8B8B8', '#B3B3B3', '#ADADAD', '#A8A8A8', '#A6A6A6', '#A1A1A1', '#9C9C9C', '#969696', '#919191', '#8F8F8F', '#8A8A8A', '#858585', '#828282', '#7D7D7D', '#787878', '#757575', '#707070', '#6E6E6E', '#696969', '#666666', '#616161', '#5E5E5E', '#595959', '#575757', '#525252', '#4F4F4F', '#4D4D4D', '#474747', '#454545'] 
// Function of setting color for Legend, according to how many bands will be used to show
function getLegendColorbar(colorbar, nbands, binskip) {
  /*
  * colorbar: the default colorbar
  * nbands: the number of the bands that will be displayed
  */
  var legendColor = [];
  // var legendYear = [];
  var iLast = colorbar.length -1;
  if (nbands === 1) {
      legendColor.push(colorbar[iLast]); // use the last one
  }
  else {
    for (var i = 0; i < nbands; i++) {
      // binskip * i         is the orginal index
      // + (colorbar.length - 1 - binskip * (nbands -1))         is to move to the last index, which will be more colorful
      legendColor.push(colorbar[binskip * i + (colorbar.length - 1 - binskip * (nbands -1))]);
      // legendColor.push(colorbar[nbands- (nbands) * binskip  + binskip * i]);
    }
  }
  return legendColor;
}
// Function of setting color for Map
function getAgentMapSLD(yearStart, yearEnd,
  colForestManagement, colAgricultureActivity, colConstruction, colStress, colDebris, colWaterDynamic, colFire, colOther){
  var colorbinSkip = ee.Number(colForestManagement.length / globalNumYears).floor().getInfo();
  colForestManagement = getLegendColorbar(colForestManagement, globalNumYears, colorbinSkip);
  colAgricultureActivity = getLegendColorbar(colAgricultureActivity, globalNumYears, colorbinSkip);
  colConstruction = getLegendColorbar(colConstruction, globalNumYears, colorbinSkip);
  colStress = getLegendColorbar(colStress, globalNumYears, colorbinSkip);
  colDebris = getLegendColorbar(colDebris, globalNumYears, colorbinSkip);
  colWaterDynamic = getLegendColorbar(colWaterDynamic, globalNumYears, colorbinSkip);
  colFire = getLegendColorbar(colFire, globalNumYears, colorbinSkip);
  colOther = getLegendColorbar(colOther, globalNumYears, colorbinSkip);
  mapProperties['Primary Disturbance Agent'].forest_management.legend = colForestManagement;
  mapProperties['Primary Disturbance Agent'].agriculture_activity.legend = colAgricultureActivity;
  mapProperties['Primary Disturbance Agent'].construction.legend = colConstruction;
  mapProperties['Primary Disturbance Agent'].stress.legend = colStress;
  mapProperties['Primary Disturbance Agent'].debris.legend = colDebris;
  mapProperties['Primary Disturbance Agent'].water_dynamic.legend = colWaterDynamic;
  mapProperties['Primary Disturbance Agent'].fire.legend = colFire;
  mapProperties['Primary Disturbance Agent'].other.legend = colOther;
  var sld_agent_part = 
  '<RasterSymbolizer>' +
  '<ColorMap type="intervals" extended="false" >';
  for (var iYear = yearStart; iYear <= yearEnd; iYear++) { // Loop selected years
    var i = iYear - yearStart;
    sld_agent_part = sld_agent_part + '<ColorMapEntry color="'+ colForestManagement[i] +'" quantity="'+ (10000 + iYear).toString() +'" label=" " />';
    sld_agent_part = sld_agent_part + '<ColorMapEntry color="'+ colAgricultureActivity[i] +'" quantity="'+ (20000 + iYear).toString() +'" label=" " />';
    sld_agent_part = sld_agent_part + '<ColorMapEntry color="'+ colConstruction[i] +'" quantity="'+ (30000 + iYear).toString() +'" label=" " />';
    sld_agent_part = sld_agent_part + '<ColorMapEntry color="'+ colStress[i] +'" quantity="'+ (40000 + iYear).toString() +'" label=" " />';
    sld_agent_part = sld_agent_part + '<ColorMapEntry color="'+ colDebris[i] +'" quantity="'+ (50000 + iYear).toString() +'" label=" " />';
    sld_agent_part = sld_agent_part + '<ColorMapEntry color="'+ colWaterDynamic[i] +'" quantity="'+ (60000 + iYear).toString() +'" label=" " />';
    sld_agent_part = sld_agent_part + '<ColorMapEntry color="'+ colFire[i] +'" quantity="'+ (70000 + iYear).toString() +'" label=" " />';
    sld_agent_part = sld_agent_part + '<ColorMapEntry color="'+ colOther[i] +'" quantity="'+ (80000 + iYear).toString() +'" label=" " />';
  }
  // '<ColorMapEntry color="#E5D5F2" quantity="41985" label="debris in 1985" />' + 
  sld_agent_part = sld_agent_part + 
    '</ColorMap>' +
    '</RasterSymbolizer>';
  return sld_agent_part;
}
// Define a palette for the 7 distinct land disturbance agent classes. This is same to sld_agent. Since we will not change it, we do not design a function to re-generate it.
var mapProperties = {
  'Primary Disturbance Agent': {
    name: 'agent',
    forest_management:{
      legend: getLegendColorbar(colorbar_forest_management, globalNumYears, 1),
      defaultVisibility: true
    },
    agriculture_activity:{
      legend: getLegendColorbar(colorbar_agriculture_activity, globalNumYears, 1),
      defaultVisibility: true
    },
    construction:{
      legend: getLegendColorbar(colorbar_construction, globalNumYears, 1),
      defaultVisibility: true
    },
    stress:{
      legend: getLegendColorbar(colorbar_stress, globalNumYears, 1),
      defaultVisibility: true
    },
    debris:{
      legend: getLegendColorbar(colorbar_debris, globalNumYears, 1),
      defaultVisibility: true
    },
    water_dynamic:{
      legend: getLegendColorbar(colorbar_water_dynamic, globalNumYears, 1),
      defaultVisibility: true
    },
    fire:{
      legend: getLegendColorbar(colorbar_fire, globalNumYears, 1),
      defaultVisibility: true
    },
    other:{
      legend: getLegendColorbar(colorbar_other, globalNumYears, 1),
      defaultVisibility: true
    }
  }
  //,
  //'Disturbance Time': {}
};
// Default SLD for showing all agents and all years
var sld_agent = getAgentMapSLD(globalYearStart, globalYearEnd,
  colorbar_forest_management, colorbar_agriculture_activity, colorbar_construction, colorbar_stress, colorbar_debris, colorbar_water_dynamic, colorbar_fire, colorbar_other)
/*
* Display stype of the back background layer
* Based on Google Maps Documentation: https://developers.google.com/maps/documentation/javascript/reference#MapTypeStyle
* Examples from snazzy maps (https://snazzymaps.com/)
*/
var snazzyBlack = [
  {
    featureType: 'administrative',
    elementType: 'all',
    stylers: [{visibility: 'off'}]
  },
  {
    featureType: 'administrative',
    elementType: 'labels.text.fill',
    stylers: [{color: '#444444'}, {visibility: 'off'}]
  },
  {
    featureType: 'landscape',
    elementType: 'all',
    stylers: [{color: '#000000'}, {visibility: 'on'}]
  },
  {
    // Change icon properties.
    elementType: 'labels.icon',
    stylers: [{visibility: 'off'}]
  },
  {featureType: 'poi', elementType: 'all', stylers: [{visibility: 'off'}]}, {
    featureType: 'road',
    elementType: 'all',
    stylers: [{saturation: -100}, {lightness: 45}, {visibility: 'off'}]
  },
  {
    featureType: 'road',
    elementType: 'geometry.fill',
    stylers: [{color: '#ffffff'}, {visibility: 'off'}]
  },
  {featureType: 'road', elementType: 'labels', stylers: [{visibility: 'off'}]},
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{color: '#dedede'}, {visibility: 'off'}]
  },
  {
    featureType: 'road',
    elementType: 'labels.icon',
    stylers: [{visibility: 'off'}]
  },
  {featureType: 'road.highway', elementType: 'all', stylers: [{visibility: 'off'}]
  },
  {featureType: 'transit', elementType: 'all', stylers: [{visibility: 'off'}]},
  {featureType: 'water', elementType: 'all', stylers: [{color: '#434343'}, {visibility: 'off'}]
  }
];
//******END OF STYPE******
//******START OF FUNCIONS******
var globalAgentPixDicDefault = [0, 1, 2, 3, 4, 5, 6, 7, 8, 255];
var globalAgentPixDicDisplay = [0, 1, 2, 3, 4, 5, 6, 7, 8, 255];
// Update pixel value (disturbance type) as unique value according to disturbance year and disturbance type
var updateAgentImage  = function(image) {
  for (var iYear = globalYearStart; iYear <= globalYearEnd; iYear++) { // Loop selected years
    // var yearlyImage = image.select(iYear - yearStartDefault);
    // print(iYear - globalYearStartDefault);
    var reflBands = image.select(iYear - globalYearStartDefault);
    var bandname = reflBands.bandNames(); // keep the band name as orginal one
    // change pixel value to hide the agent we will not display
    reflBands = reflBands.remap({
      from: globalAgentPixDicDefault,
      to: globalAgentPixDicDisplay, // as a zero array of which size same as globalHideCode
      defaultValue: 0
    });
    reflBands = reflBands.rename(bandname);
    reflBands = reflBands.multiply(10000).add(iYear); // e.g., 0001985, 2551985
    image = image.addBands({srcImg: reflBands, overwrite: true}); // update the band using a same band name
  }
  // Reduce the image to get a one-band maximum value image.
  var maxValue = image.reduce(ee.Reducer.max());
  // Exclude no disturbnace and filled pixels
  maxValue = maxValue.updateMask(maxValue.gt(globalYearEnd) || maxValue.lt(globalYearEnd + 2550000)); // 255 *10000
  return maxValue.sldStyle(sld_agent);
}
//******END OF FUNCIONS******
//******START OF MAP Panel Configuration******
// Create a map panel.
var mapPanel = ui.Map();
// Take all tools off the map except the zoom,  mapTypeControl, and fullscreenControl tools.
mapPanel.setControlVisibility(
    {all: false, zoomControl: true, mapTypeControl: true, fullscreenControl: true});
// Center the map
// var defaultLocation = locationDict['CONUS-Wide'];
// mapPanel.setCenter(defaultLocation.lon, defaultLocation.lat, defaultLocation.zoom);
// Add these to the interface
ui.root.widgets().reset([mapPanel]);
ui.root.setLayout(ui.Panel.Layout.flow('horizontal'));
// Add land disturbance agent map
mapPanel.add(ui.Map.Layer(agentImageCollection.map(updateAgentImage), {}, 'agent'));
// Setup the background as back color
mapPanel.setOptions('Black', {'Black': snazzyBlack});
//******START OF MAP Panel Configuration******
//******START OF Component Configuration******
function setLegendPanel(checkboxAgent, legend_agent) {
  var legendList = [];
  if (legend_agent.defaultVisibility) {  
    var legend = legend_agent.legend;
    var len = ((202 - legend.length)/legend.length).toString(); //  - legend.length for adjusting the 1 pixel margin
    for (var i = 0; i < legend.length; i++) {
      var item = legend[i];
      // var colorBox = ui.Label('', { backgroundColor: item, padding: '0px 0px 15px 4.6px', margin: '0px 1px 0px 0px'});
      var colorBox = ui.Label('', { 
        backgroundColor: item,
        padding: '0px 0px 0px 0px', 
        margin: '0px 1px 0px 0px',
        width:len +'px', height: '15px'}
      );
      if (legendList.length === 0) {
        legendList.push(checkboxAgent);
        legendList.push(colorBox);
      }
      else {
        legendList.push(colorBox);
      }
    }
  }
  return legendList;
}
//******END OF Component Configuration******
//******START OF Configuring the Right Panel******
// Add a title and some explanatory text to a side panel.
var header = ui.Label('CONUS Land Disturbance', {fontSize: '16px', color: 'red'});
var text = ui.Label(
    'Land disturbance products over CONUS between 1985 and 2020 based on the COLD and ODACA algotithems and the Landsat time series. Note: This is preliminary product based on open-source datasets, which is being improved by interpreting new correction samples',
    {fontSize: '12px'});
var rightPanel = ui.Panel([header, text], 'flow', {width: '300px'});
ui.root.widgets().add(rightPanel);
// Create the legend panel, in which the years and layers can be selected
// Define a panel for the legend
var toolPanel = ui.Panel({
  style: {fontWeight: 'bold', fontSize: '12px', margin: '0 0 0 8px'} // left margin at 8 pixels
});
rightPanel.add(toolPanel);
// Create a map selector pulldown. The elements of the pulldown are the keys of the mapProperties dictionary.
var selectMapItems = Object.keys(mapProperties);
var mapSelect = ui.Select({
  items: selectMapItems,
  value: selectMapItems[0],
  style: {width: '200px', margin: '0px 0px 0px 3px'},
  onChange: function(selected) {
    // Single product will not triger this
    mapPanel.layers().forEach(function(element, index) {
      //element.setShown(selected == element.getName());
    });
    setLegend(mapProperties[selected]);
  }
});
// Add the select to the rightPanel with available [maps/products]
toolPanel.add(ui.Panel(
  [ui.Label('Select Layer:', {margin: '7px 0px 0px 0px'}), mapSelect], // 7px is to algin the right selector
  ui.Panel.Layout.Flow('horizontal')));
// Add the select to the rightPanel with [start and end years]
var labelSelectYear = ui.Label('Select Year:', {fontWeight: 'bold', 'font-size': '12px', margin: '14px 0px 0px 0px', padding: '0px 0px 0px 0px'});
var labelYearTo  = ui.Label('to', {fontWeight: 'bold', 'font-size': '12px', margin: '14px 0px 0px 26px', padding: '0px 30px 0px 0px'});
function updateYearRange(mapNameName, yearStart, yearEnd){
  // Update years
  globalYearStart = parseInt(yearStart);
  globalYearEnd = parseInt(yearEnd);
  globalNumYears = globalYearEnd - globalYearStart + 1; // Number of years
  // update the legend color
  sld_agent = getAgentMapSLD(globalYearStart, globalYearEnd,
  colorbarHarvest, colorbarMechanical, colorbarStress, colorbarDebris, colorbarHydrology, colorbarFire, colorbarOther)
  refreshDisplayMap(mapNameName);
  // Set the initial legend
  setAgentLegend(mapProperties[mapSelect.getValue()]);
}
function refreshDisplayMap(mapNameName){
  // Single product will not triger this
  mapPanel.layers().forEach(function(element, index) {
    if (mapNameName === 'agent'){
      element.setEeObject(agentImageCollection.map(updateAgentImage));
    }
  });
}
var selectYearStart = ui.Select({
  items: globalYearsString, value:globalYearsString[0], style: {width: '59px'},
  onChange: function(selected) {
    // Force to setup the one equal to the selected end year
    if (selected > selectYearEnd.getValue()){
      selectYearStart.setValue(selectYearEnd.getValue()); // will trigger the end year
    } else {
    // update the year range
    updateYearRange(mapProperties[mapSelect.getValue()].name, selected, selectYearEnd.getValue());
    }
  }
});
var selectYearEnd   = ui.Select({items: globalYearsString, value:globalYearsString[globalYearsString.length - 1], style: {width: '59px'},
    onChange: function(selected) {
    // Force to setup the one equal to the selected start year
    if (selected < selectYearStart.getValue()){
      selectYearEnd.setValue(selectYearStart.getValue()); // will trigger the start year
    }else {
    // update the year range
    updateYearRange(mapProperties[mapSelect.getValue()].name, selectYearStart.getValue(), selected);
    }
  }
});
var inputYearPanel = ui.Panel([labelSelectYear, selectYearStart, labelYearTo, selectYearEnd], ui.Panel.Layout.Flow('horizontal'));
toolPanel.add(inputYearPanel);
// Define an area for the legend key itself.
// This area will be replaced every time the map pulldown is changed.
var legendPanel = ui.Panel();
toolPanel.add(legendPanel);
function updateAgentPixelDic(agentVisible, iAgent){
  if (agentVisible) {
    globalAgentPixDicDisplay[iAgent] = globalAgentPixDicDefault[iAgent];
  } else {
    globalAgentPixDicDisplay[iAgent] = 0;
  }
}
// Function of adding the legends
function setAgentLegend(legend) {
  // Loop through all the items in a layer's key property,
  // creates the item, and adds it to the key panel.
  legendPanel.clear();
  // Define the checkboxes for the different disturbance types
  var checked = globalAgentPixDicDisplay[1] === globalAgentPixDicDefault[1];
  var checkbox_forest_management = ui.Checkbox({ label: 'For. mgt.',value: checked, style: {padding: '0px 0px 10px 0px', margin: '0px 1px 0px 0px', width: '71px'},
    onChange: function(value) {
      updateAgentPixelDic(value, 1);
      refreshDisplayMap(mapProperties[mapSelect.getValue()].name);
    }
  });
  checked = globalAgentPixDicDisplay[2] === globalAgentPixDicDefault[2];
  var checkbox_agriculture_activity = ui.Checkbox({ label: 'Agr. act.',value: checked, style: {padding: '0px 0px 10px 0px', margin: '0px 1px 0px 0px', width: '71px'},
    onChange: function(value) {
      updateAgentPixelDic(value, 2);
      refreshDisplayMap(mapProperties[mapSelect.getValue()].name);
    }
  });
  checked = globalAgentPixDicDisplay[3] === globalAgentPixDicDefault[3];
  var checkbox_construction = ui.Checkbox({ label: 'Constr.',value: checked, style: {padding: '0px 0px 10px 0px', margin: '0px 1px 0px 0px', width: '71px'},
    onChange: function(value) {
      updateAgentPixelDic(value, 3);
      refreshDisplayMap(mapProperties[mapSelect.getValue()].name);
    }
  });
  checked = globalAgentPixDicDisplay[4] === globalAgentPixDicDefault[4];
  var checkbox_stress = ui.Checkbox({ label: 'Stress',value: checked, style: {padding: '0px 0px 10px 0px', margin: '0px 1px 0px 0px', width: '71px'},
    onChange: function(value) {
      updateAgentPixelDic(value, 4);
      refreshDisplayMap(mapProperties[mapSelect.getValue()].name);
    }
  });
  checked = globalAgentPixDicDisplay[5] === globalAgentPixDicDefault[5];
  var checkbox_debris = ui.Checkbox({ label: 'Debris',value: checked, style: {padding: '0px 0px 10px 0px', margin: '0px 1px 0px 0px', width: '71px'},
    onChange: function(value) {
      updateAgentPixelDic(value, 5);
      refreshDisplayMap(mapProperties[mapSelect.getValue()].name);
    }
  });
  checked = globalAgentPixDicDisplay[6] === globalAgentPixDicDefault[6];
  var checkbox_water_dynamic = ui.Checkbox({ label: 'Wat. dyn.',value: checked, style: {padding: '0px 0px 10px 0px', margin: '0px 1px 0px 0px', width: '71px'},
    onChange: function(value) {
      updateAgentPixelDic(value, 6);
      refreshDisplayMap(mapProperties[mapSelect.getValue()].name);
    }
  });
  checked = globalAgentPixDicDisplay[7] === globalAgentPixDicDefault[7];
  var checkbox_fire = ui.Checkbox({ label: 'Fire',value: checked, style: {padding: '0px 0px 10px 0px', margin: '0px 1px 0px 0px', width: '71px'},
    onChange: function(value) {
      updateAgentPixelDic(value, 7);
      refreshDisplayMap(mapProperties[mapSelect.getValue()].name);
    }
  });
  checked = globalAgentPixDicDisplay[8] === globalAgentPixDicDefault[8];
  var checkbox_other = ui.Checkbox({ label: 'Other',value: checked, style: {padding: '0px 0px 10px 0px', margin: '0px 1px 0px 0px', width: '71px'},
    onChange: function(value) {
      updateAgentPixelDic(value, 8);
      refreshDisplayMap(mapProperties[mapSelect.getValue()].name);
    }
  });
  // Land disturbance agent product
  legendPanel.add(ui.Panel(setLegendPanel(checkbox_forest_management,    legend.forest_management),    ui.Panel.Layout.Flow('horizontal'))); // vertical  horizontal
  legendPanel.add(ui.Panel(setLegendPanel(checkbox_agriculture_activity, legend.agriculture_activity), ui.Panel.Layout.Flow('horizontal'))); // vertical  horizontal
  legendPanel.add(ui.Panel(setLegendPanel(checkbox_construction,     legend.construction),     ui.Panel.Layout.Flow('horizontal'))); // vertical  horizontal
  legendPanel.add(ui.Panel(setLegendPanel(checkbox_stress,     legend.stress),     ui.Panel.Layout.Flow('horizontal'))); // vertical  horizontal
  legendPanel.add(ui.Panel(setLegendPanel(checkbox_debris,  legend.debris),  ui.Panel.Layout.Flow('horizontal'))); // vertical  horizontal
  legendPanel.add(ui.Panel(setLegendPanel(checkbox_water_dynamic,       legend.water_dynamic),       ui.Panel.Layout.Flow('horizontal'))); // vertical  horizontal
  legendPanel.add(ui.Panel(setLegendPanel(checkbox_fire,      legend.fire),      ui.Panel.Layout.Flow('horizontal'))); // vertical  horizontal
  legendPanel.add(ui.Panel(setLegendPanel(checkbox_other,      legend.other),      ui.Panel.Layout.Flow('horizontal'))); // vertical  horizontal
}
// Set the initial legend
setAgentLegend(mapProperties[mapSelect.getValue()]);
// Create an opacity slider.
var labelAjustOpacity = ui.Label('Adjust Opacity:', {fontWeight: 'bold', 'font-size': '12px', margin: '9px 0px 0px 0px', padding: '0px 0px 0px 0px'});
// Create an opacity slider. This tool will change the opacity for each layer.
// That way switching to a new layer will maintain the chosen opacity.
var opacitySlider = ui.Slider({
  min: 0.00,
  max: 1.00,
  value: 1.00,
  step: 0.01,
  style: {width: '150px'}
});
opacitySlider.onSlide(function(value) {
  mapPanel.layers().forEach(function(element, index) {
    element.setOpacity(value);
  });
});
var viewPanel =
    ui.Panel([labelAjustOpacity, opacitySlider], ui.Panel.Layout.Flow('horizontal'));
toolPanel.add(viewPanel);
// Create the location pulldown.
var locations = Object.keys(locationDict);
var locationSelect = ui.Select({
  items: locations,
  value: locations[0],
  onChange: function(value) {
    var location = locationDict[value];
    mapPanel.setCenter(location.lon, location.lat, location.zoom);
  }
});
var locationPanel = ui.Panel([
  ui.Label('Visit Examples:', {fontWeight: 'bold', 'font-size': '12px'}), locationSelect
]);
// toolPanel.add(locationPanel);