var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#23cba7",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #23cba7 */ee.Geometry.MultiPoint();
Map.setCenter(78.481, 22.634,7)
var drawingTools = Map.drawingTools();
drawingTools.setShown(false);
while (drawingTools.layers().length() > 0) {
  var layer = drawingTools.layers().get(0);
  drawingTools.layers().remove(layer);
}
var dummyGeometry =
    ui.Map.GeometryLayer({geometries: null, name: 'geometry', color: '23cba7'});
drawingTools.layers().add(dummyGeometry);
function clearGeometry() {
  var layers = drawingTools.layers();
  layers.get(0).geometries().remove(layers.get(0).geometries().get(0));
}
function drawRectangle() {
  clearGeometry();
  drawingTools.setShape('rectangle');
  drawingTools.draw();
}
function drawPolygon() {
  clearGeometry();
  drawingTools.setShape('polygon');
  drawingTools.draw();
}
drawingTools.onDraw(ui.util.debounce(chartNdviTimeSeries, 500));
drawingTools.onEdit(ui.util.debounce(chartNdviTimeSeries, 500));
 // Get the drawn geometry; it will define the reduction region.
  var aoi = drawingTools.layers().get(0).getEeObject();
  // Set the drawing mode back to null; turns drawing off.
  drawingTools.setShape(null);
  var symbol = {
  rectangle: '⬛',
  polygon: '🔺',
};
var controlPanel = ui.Panel({
  widgets: [
    ui.Label('1. Select a drawing mode.'),
    ui.Button({
      label: symbol.rectangle + ' Rectangle',
      onClick: drawRectangle,
      style: {stretch: 'horizontal'}
    }),
    ui.Button({
      label: symbol.polygon + ' Polygon',
      onClick: drawPolygon,
      style: {stretch: 'horizontal'}
    }),
    ui.Label('2. Draw a geometry.'),
    ui.Label('3. Wait for chart to render.'),
    ui.Label(
        '4. Repeat 1-3 or edit/move\ngeometry for a new chart.',
        {whiteSpace: 'pre'})
  ],
  style: {position: 'bottom-right'},
  layout: null,
});
Map.add(controlPanel);
function chartNdviTimeSeries() {  
  var aoi = drawingTools.layers().get(0).getEeObject();
  var startDate = ui.Textbox({
      placeholder: 'YYYY-MM-DD',
      value: '2020-04-01',
      style: {width: '90px'},
      onChange: function(text) {
    var Start_base = text;
      }
    });
  var threshold = ui.Textbox({
      placeholder: 'enter threshold',
      value: -17,
      style: {width: '90px'},
      onChange: function(text) {
    var Start_base = text;
      }
    });
 var getImages = function()
 {
   var start = startDate.getValue();
    if (start) start = ee.Date(start);
      Map.clear();
      Map.centerObject(aoi, 10)
  var end = start.advance(1,'month');
  var date_range = ee.DateRange(start,end);
  var sent = ee.ImageCollection("COPERNICUS/S1_GRD")
        .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
        .filter(ee.Filter.eq('instrumentMode', 'IW'))
        .select('VV'  )
        .filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'))
        .filterDate(start, end)
        .filterBounds(aoi)
        .median()
Map.addLayer(sent.clip(aoi), {min: [-50], max: [20]}, ' Sentinel 1 Composite', 1);
return sent
}
var hist = function()
{
  var sent=getImages();
var histogram = sent.reduceRegion({  
  reducer: ee.Reducer.histogram(255, 2),
    geometry: aoi, 
  scale:100,
  bestEffort: true,
  maxPixels:1e12
});
panel.widgets().set(9, ui.Chart.image.histogram(sent, aoi, 100)); 
return histogram
}
var mapping= function()
{
    var sent = getImages()
    var thresh = parseFloat(threshold.getValue());
    //print(thresh) 
    if (thresh) thresh = thresh;
    var flood = ee.Image(sent).lt(thresh);  //value =1
Map.clear()
Map.addLayer(flood.mask(flood).clip(aoi), {palette: 'blue'}, 'Water_with_threshold==> '+thresh);
return flood
}
///..................Area.............../////////
var area= function()
{
  var thresh = parseFloat(threshold.getValue());
  var flood= mapping()
var areaImage=flood.mask(flood).multiply(ee.Image.pixelArea())
.multiply(0.000001).rename('area_Total');
var stats = areaImage.reduceRegion({
  reducer: ee.Reducer.sum(),
  geometry: aoi,
  scale: 10,
  maxPixels: 1e10
}).get('area_Total');
panel.add(ui.Label('For the Date==>   ' +startDate.getValue()));  
panel.add(ui.Label('Using Threshold=>   ' +thresh));
panel.add(ui.Label('Total Water (in sq. km.)==> ' +stats.getInfo().toFixed(2)));  
}
var exp= function()
{
  var img= area()
   var downloadArgs = {
    name: 'ee_image',
    scale: 10,
    region: aoi.toGeoJSONString()
 };
 var url = img.getDownloadURL(downloadArgs);
 urlLabel.setUrl(url);
 urlLabel.style().set({shown: true});
}
var mapPanel = ui.Map();
// Take all tools off the map except the zoom and mapTypeControl tools.
  mapPanel.setControlVisibility(
    {all: false, zoomControl: true, mapTypeControl: false});
Map.setOptions('SATELLITE');
var intro = ui.Panel([
  ui.Label({
    value: 'Monitor Surface Water',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
]);
var panel= ui.Panel();
//panel.style().set('width', '350px');
panel.add(intro);
panel.add(ui.Label('Compute Sentinel 1 Median Composite from ', {'font-size': '16px'}));
panel.add(startDate);
var   button = ui.Button({
       label: 'Get Images',
       onClick: function()
       {
         Map.clear();//
       //   var Lo = parseFloat(id.getValue());
        //  var data =table.filter(ee.Filter.eq('Id', Lo));
           return getImages();
       },
       disabled: false,
      });
panel.add(button);
var   button2 = ui.Button({
      label: 'Generate Histogram',
      onClick: function()
      {
         return hist();
      },
      disabled: false,
      });
panel.add(button2);
panel.add(ui.Label('Enter Threshold', {'font-size': '16px'})); 
panel.add(threshold);
var   button3 = ui.Button({
      label: 'Map Surface Water ',
      onClick: function()
      {
         return mapping();
      },
      disabled: false,
      });
panel.add(button3); 
 var   button4 = ui.Button({
      label: 'Estimate Area',
      onClick: function()
      {
         return area();
      },
      disabled: false,
      });
panel.add(button4); 
ui.root.insert(0, panel);
}
// Map.centerObject(geometry,9)
//   var   button5 = ui.Button({
//       label: 'Export',
//       onClick: function()
//       {
//         return exp();
//       },
//       disabled: false,
//       });
// panel1.add(button4); 
// // Add UI elements to the Map.
// //var downloadButton = ui.Button('Download viewport', exp);
// var urlLabel = ui.Label('Download', {shown: false});
// var panel1 = ui.Panel([button4, urlLabel]);
// Map.add(panel1);