var ROI = ui.import && ui.import("ROI", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#23cba7",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #23cba7 */ee.Geometry.MultiPoint();
// Set initial map view.
Map.setCenter(78.481, 22.634, 5);
// Add a map title label overlay.
var mapTitle = ui.Label('Water Surface Mapper', {
  fontWeight: 'bold',
  fontSize: '24px',
  color: '#000000',
  margin: '10px'
});
var mapTitlePanel = ui.Panel({
  widgets: [mapTitle],
  style: {position: 'top-center', padding: '8px'}
});
Map.add(mapTitlePanel);
// Initialize the drawing tools and clear any preexisting layers.
var drawTool = Map.drawingTools();
drawTool.setShown(false);
while (drawTool.layers().length() > 0) {
  drawTool.layers().remove(drawTool.layers().get(0));
}
// Create a dedicated ROI layer for drawing.
var roiLayer = ui.Map.GeometryLayer({
  geometries: null,
  name: 'ROI',
  color: '23cba7'
});
drawTool.layers().add(roiLayer);
// Clear existing geometries from the drawing tool.
function clearGeometry() {
  var geometries = roiLayer.geometries();
  if (geometries.length() > 0) {
    geometries.remove(geometries.get(0));
  }
}
// Functions to set drawing mode.
function drawRectangle() {
  clearGeometry();
  drawTool.setShape('rectangle');
  drawTool.draw();
}
function drawPolygon() {
  clearGeometry();
  drawTool.setShape('polygon');
  drawTool.draw();
}
// Create a control panel for drawing mode selection.
var symbol = { rectangle: '▢', polygon: '⬠' };
var controlPanel = ui.Panel({
  widgets: [
    ui.Label({
      value: 'Select a Drawing Mode:',
      style: {fontSize: '14px', fontWeight: 'bold', backgroundColor: '#ffffffaa', color: '#000000'}
    }),
    ui.Button({
      label: symbol.rectangle + '  Rectangle',
      onClick: drawRectangle,
      style: {stretch: 'horizontal', fontSize: '12px', color: '#000000'}
    }),
    ui.Button({
      label: symbol.polygon + '   Polygon',
      onClick: drawPolygon,
      style: {stretch: 'horizontal', fontSize: '12px', color: '#000000'}
    })
  ],
  style: {position: 'bottom-right', padding: '8px', backgroundColor: '#ffffffaa', border: '1px solid #ccc'}
});
Map.add(controlPanel);
// Create input controls for parameters: two date textboxes and a threshold textbox.
var startDateInput = ui.Textbox({
  placeholder: 'YYYY-MM-DD',
  value: '2020-04-01',
  style: {width: '90px', fontSize: '12px', color: '#000000', textAlign: 'center'}
});
var endDateInput = ui.Textbox({
  placeholder: 'YYYY-MM-DD',
  value: '2020-05-01',
  style: {width: '90px', fontSize: '12px', color: '#000000', textAlign: 'center'}
});
var thresholdInput = ui.Textbox({
  placeholder: 'Enter threshold',
  value: '-17',
  style: {width: '40px', fontSize: '12px', color: '#000000', textAlign: 'center'}
});
// Create the left (results) panel with dynamic width.
var resultsPanel = ui.Panel({
  style: {width: 'auto', padding: '10px', border: '1px solid #ccc'}
});
ui.root.insert(0, resultsPanel);
// Instructions panel that always remains visible.
var instructionsPanel = ui.Panel([
  ui.Label({value: "Instructions:", style: {fontSize: '16px', fontWeight: 'bold', margin: '0 0 12px 0', color: '#000000'}}),
  ui.Label({value: "Step 1: Draw Polygon", style: {fontSize: '14px', color: '#000000'}}),
  ui.Label({value: "Step 2: Select Dates", style: {fontSize: '14px', color: '#000000'}}),
  ui.Label({value: "Step 3: Click 'Generate Sentinel-1 Image & Histogram'", style: {fontSize: '14px', color: '#000000'}}),
  ui.Label({value: "Step 4: Map Water, Estimate Area, and Export as polygon", style: {fontSize: '14px', color: '#000000'}})
], ui.Panel.Layout.Flow('vertical'), {padding: '8px', border: '1px solid #ccc'});
resultsPanel.add(instructionsPanel);
// A dynamic panel for controls and outputs that will be updated after drawing.
var dynamicPanel = ui.Panel({style: {padding: '8px'}});
resultsPanel.add(dynamicPanel);
// Add a copyright disclaimer at the bottom.
resultsPanel.add(ui.Label({
  value: "© Dr Sachchidanand Singh, Scentist B, NIH-WHRC Jammu & Praveen Kalura, IIT Roorkee",
  style: {fontSize: '12px', color: '#000000', margin: '10px 0 0 0'}
}));
// Function to retrieve a Sentinel-1 composite for the drawn ROI.
function getComposite(aoi) {
  var start = ee.Date(startDateInput.getValue());
  var end = ee.Date(endDateInput.getValue());
  var composite = ee.ImageCollection("COPERNICUS/S1_GRD")
      .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
      .filter(ee.Filter.eq('instrumentMode', 'IW'))
      .select('VV')
      .filterDate(start, end)
      .filterBounds(aoi)
      .mosaic()
      .focal_median(100, 'circle', 'meters');
  return composite.clip(aoi);
}
// Function to add the composite image as a map layer.
function showComposite(aoi) {
  var composite = getComposite(aoi);
  // Remove any previous composite layer.
  Map.layers().forEach(function(layer) {
    if (layer.getName() === 'Sentinel-1 Composite') {
      Map.layers().remove(layer);
    }
  });
  Map.addLayer(composite, {min: -50, max: 20}, 'Sentinel-1 Composite', true);
  return composite;
}
// Function to display a histogram chart.
function showHistogram(composite, aoi) {
  var chart = ui.Chart.image.histogram(composite, aoi, 100)
      .setOptions({
        title: 'Histogram of VV Values',
        hAxis: {title: 'VV', textStyle: {color: '#000000'}},
        vAxis: {title: 'Frequency', textStyle: {color: '#000000'}},
        titleTextStyle: {color: '#000000'}
      });
  dynamicPanel.add(chart);
}
// Updated mapWater function now accepts an optional flag to add the layer.
function mapWater(composite, aoi, addLayer) {
  var thresh = parseFloat(thresholdInput.getValue());
  var waterMask = composite.lt(thresh).selfMask();
  if (addLayer === undefined || addLayer === true) {
    Map.addLayer(waterMask, {palette: ['blue']}, 'Water (Threshold: ' + thresh + ')', true);
  }
  return waterMask;
}
// Function to compute water area in square kilometers and display threshold.
function computeArea(waterMask, aoi) {
  var thresh = parseFloat(thresholdInput.getValue());
  var areaImage = waterMask.multiply(ee.Image.pixelArea())
      .multiply(0.000001).rename('water_area');
  var stats = areaImage.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: aoi,
    scale: 100,
    maxPixels: 1e10
  });
  var areaValue = ee.Number(stats.get('water_area')).format('%.2f');
  dynamicPanel.add(ui.Label({
    value: 'Threshold: ' + thresh + ' | Water Area (sq km): ' + areaValue.getInfo(),
    style: {fontSize: '12px', fontWeight: 'bold', color: '#000000'}
  }));
}
// Function to generate water vectors and provide a KML download link.
function generateKML(waterMask, aoi) {
  // Duplicate the waterMask so the reducer has two bands.
  var vectors = waterMask.addBands(waterMask).reduceToVectors({
    geometry: aoi,
    scale: 50,
    geometryType: 'polygon',
    eightConnected: false,
    labelProperty: 'zone',
    reducer: ee.Reducer.first(),
    maxPixels: 1e10
  });
  Map.addLayer(vectors, {}, 'Water Vector');
  var thresh = parseFloat(thresholdInput.getValue());
  var downloadUrl = vectors.getDownloadURL({
    filename: startDateInput.getValue() + '_Th_' + thresh,
    format: 'kml'
  });
  var kmlLabel = ui.Label({
    value: 'Download KML',
    targetUrl: downloadUrl,
    style: {fontSize: '14px', textDecoration: 'underline', color: '#000000'}
  });
  dynamicPanel.add(kmlLabel);
}
// New function: Combine composite generation and histogram into one button without clearing the dynamic panel.
function onGenerateImageAndHistogram(aoi) {
  // Generate and show the composite image.
  var composite = showComposite(aoi);
  // Immediately display the histogram.
  showHistogram(composite, aoi);
  // Append a header for subsequent processing options (center aligned).
  dynamicPanel.add(ui.Label({
    value: 'Click the Options One by One',
    style: {fontSize: '18px', fontWeight: 'bold', margin: '30px 0 5px 0', color: '#000000', textAlign: 'center'}
  }));
  // Create a horizontal buttons panel for subsequent processing steps.
  var buttonsPanel = ui.Panel({
    layout: ui.Panel.Layout.Flow('horizontal'),
    style: {margin: '5px 0'}
  });
  buttonsPanel.add(ui.Button({
    label: 'Map Surface Water',
    onClick: function() { mapWater(composite, aoi, true); },
    style: {fontSize: '12px', padding: '2px 4px', color: '#000000'}
  }));
  buttonsPanel.add(ui.Button({
    label: 'Estimate Area',
    onClick: function() {
      var waterMask = mapWater(composite, aoi, false);
      computeArea(waterMask, aoi);
    },
    style: {fontSize: '12px', padding: '2px 4px', color: '#000000'}
  }));
  buttonsPanel.add(ui.Button({
    label: 'Generate KML',
    onClick: function() {
      var waterMask = mapWater(composite, aoi, false);
      generateKML(waterMask, aoi);
    },
    style: {fontSize: '12px', padding: '2px 4px', color: '#000000'}
  }));
  // Create a horizontal panel for the threshold label and textbox.
  var thresholdPanel = ui.Panel({
    widgets: [
      ui.Label({
        value: 'Enter Threshold:',
        style: {fontSize: '12px', color: '#000000', margin: '10px 4px 10px 0', textAlign: 'center'}
      }),
      thresholdInput
    ],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
  dynamicPanel.add(thresholdPanel);
  dynamicPanel.add(buttonsPanel);
}
// Main callback function triggered when a drawing is created/edited.
function onDrawing() {
  // Retrieve the drawn ROI geometry.
  var aoi = roiLayer.getEeObject();
  if (!aoi) {
    ui.notify('Please draw an area first.');
    return;
  }
  // Remove any previous ROI layers from the map.
  Map.layers().forEach(function(layer) {
    if (layer.getName() === 'ROI') {
      Map.layers().remove(layer);
    }
  });
  // Remove the drawn polygon from the drawing tool.
  clearGeometry();
  // Add the new ROI as a separate layer.
  Map.addLayer(aoi, {color: '23cba7'}, 'ROI');
  // Switch to satellite view.
  Map.setOptions('SATELLITE');
  // Clear dynamic panel (but keep instructions intact).
  dynamicPanel.clear();
  // Add header and horizontal date input controls.
  dynamicPanel.add(ui.Label({
    value: 'Water Surface Mapper (WASAP)',
    style: {fontSize: '22px', fontWeight: 'bold', margin: '0 0 10px 0', color: '#000000'}
  }));
  dynamicPanel.add(ui.Label({
    value: 'Enter Start and End Date for Sentinel-1 Mosaic:',
    style: {fontSize: '14px', margin: '0 0 5px 0', color: '#000000'}
  }));
  // Create a horizontal panel for date inputs.
  var datePanel = ui.Panel({
    widgets: [
      ui.Label({value: "Start Date:", style: {fontSize: '12px', color: '#000000', margin: '10px 4px 10px 0'}}),
      startDateInput,
      ui.Label({value: "End Date:", style: {fontSize: '12px', color: '#000000', margin: '10px 4px 10px 0'}}),
      endDateInput
    ],
    layout: ui.Panel.Layout.Flow('horizontal'),
    style: {margin: '0 0 5px 0'}
  });
  dynamicPanel.add(datePanel);
  // Add a button to generate the composite image and histogram together.
  dynamicPanel.add(ui.Button({
    label: 'Generate Sentinel-1 Image & Histogram',
    onClick: function() { onGenerateImageAndHistogram(aoi); },
    style: {fontSize: '12px', padding: '4px 8px', margin: '5px 0 5px 40px', color: '#000000'}
  }));
}
// Debounce drawing events to avoid multiple rapid triggers.
drawTool.onDraw(ui.util.debounce(onDrawing, 500));
drawTool.onEdit(ui.util.debounce(onDrawing, 500));
// Turn off drawing mode.
drawTool.setShape(null);