var table = ui.import && ui.import("table", "table", {
      "id": "users/LearningIIT/India_New_State"
    }) || ee.FeatureCollection("users/LearningIIT/India_New_State"),
    table2 = ui.import && ui.import("table2", "table", {
      "id": "users/LearningIIT/India_New_Districts"
    }) || ee.FeatureCollection("users/LearningIIT/India_New_Districts");
Map.setControlVisibility({all: false,layerList:true,mapTypeControl:true,fullscreenControl:true})
var aoi=table.filter(ee.Filter.eq('stname','CHHATTISGARH'))
var roi=table2.filter(ee.Filter.eq('stname','CHHATTISGARH'))
Map.setOptions("HYBRID")
// Adds two charts next to the map to interactively display a
// time-series of NDVI and reflectance for each click on the map.
var col2001= ee.ImageCollection('LANDSAT/LT05/C01/T1_32DAY_NDVI').select('NDVI')
    .filterDate('2001-01-01', '2013-01-01')
var col2013= ee.ImageCollection('LANDSAT/LE07/C01/T1_32DAY_NDVI').select('NDVI')
    .filterDate('2013-01-01', '2015-01-01')
// Filter collection to dates of interest.
var col2015 = ee.ImageCollection('LANDSAT/LC08/C01/T1_32DAY_NDVI').select('NDVI')
    .filterDate('2015-01-01', '2022-01-01')
var ndvi = col2001.merge(col2013).merge(col2015).sort('system:time_start')    
var palette = ['#8bc4f9','#c9995c','#c7d270','#8add60','#097210'];
var ndviVis = {min:-0.5, max:0.5, palette: palette};
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '5px 10px'
  }
}); 
Map.addLayer(ndvi.median().clip(aoi), ndviVis, 'NDVI');
Map.centerObject(aoi,7);
// Create a panel to hold our widgets.
var panel = ui.Panel({style: {width: '400px', position:'top-left',color:'black'}});
// Create an intro panel with labels.
var intro = ui.Panel([
  ui.Label({
    value: 'NDVI Timeseries Chart ',
    style: {fontSize: '20px', fontWeight: 'bold'}
  }),
  ui.Label('Click a point on the map to generate.')
]);
panel.add(intro);
// Create panels to hold lon/lat values.
var lon = ui.Label();
var lat = ui.Label();
panel.add(ui.Panel([lon, lat], ui.Panel.Layout.flow('horizontal')));
function createColorBar(titleText, palette, min, max) {
  // Legend Title
  var title = ui.Label({
    value: titleText, 
    style: {fontWeight: 'bold', textAlign: 'center', stretch: 'horizontal'}});
  // Colorbar
  var legend = ui.Thumbnail({
    image: ee.Image.pixelLonLat().select(0),
    params: {
      bbox: [0, 0, 1, 0.1],
      dimensions: '120x10',
      format: 'png', 
      min: -1, max: 1,
      palette: palette},
    style: {stretch: 'horizontal', margin: '3px 3px', maxHeight: '20px'},
  });
  // Legend Labels
  var labels = ui.Panel({
    widgets: [
      ui.Label(min, {margin: '2px 5px',textAlign: 'left', stretch: 'horizontal'}),
      ui.Label((min+max)/2, {margin: '2px 10px', textAlign: 'center', stretch: 'horizontal'}),
      ui.Label(max, {margin: '2px 5px',textAlign: 'right', stretch: 'horizontal'})],
    layout: ui.Panel.Layout.flow('horizontal')});
  // Create a panel with all 3 widgets
  var legendPanel = ui.Panel({
    widgets: [title, legend, labels],
    style: {position: 'top-right', padding: '8px 15px'}
  });
  return legendPanel;
}
Map.add(createColorBar('NDVI Values', palette, -0.5, 0.5))
// Register a callback on the default map to be invoked when the map is clicked.
Map.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  lon.setValue('Longitude: ' + coords.lon.toFixed(2)),
  lat.setValue('Latitude: ' + coords.lat.toFixed(2));
  // Add a red dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'FF0000'});
  Map.layers().set(1, dot);
  // Create an NDVI chart.
  var ndviChart = ui.Chart.image.series(ndvi, point, ee.Reducer.mean(), 1000);
  ndviChart
  .setChartType('LineChart')
  .setOptions({
    title: 'NDVI Time Series of Clicked Location',
     trendlines: {0: {
        color: 'black'
      }},
    vAxis: {title: 'NDVI'},
    hAxis: {title: 'Date', format: 'MM-yy', gridlines: {count: 7}},
    interpolateNulls: true,
    series: {
    0: { curveType: 'function' , color: 'green', pointSize: 2},
  }
  });
  panel.widgets().set(2, ndviChart);
});
Map.style().set('cursor', 'crosshair');
Map.add(panel);