var s2viz = ui.import && ui.import("s2viz", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B4",
          "B3",
          "B2"
        ],
        "min": 491.6,
        "max": 1216.4,
        "gamma": 0.739
      }
    }) || {"opacity":1,"bands":["B4","B3","B2"],"min":491.6,"max":1216.4,"gamma":0.739},
    glims = ui.import && ui.import("glims", "table", {
      "id": "GLIMS/20210914"
    }) || ee.FeatureCollection("GLIMS/20210914"),
    s2 = ui.import && ui.import("s2", "imageCollection", {
      "id": "COPERNICUS/S2"
    }) || ee.ImageCollection("COPERNICUS/S2"),
    table = ui.import && ui.import("table", "table", {
      "id": "users/LearningIIT/Ladakh_sub_dist"
    }) || ee.FeatureCollection("users/LearningIIT/Ladakh_sub_dist"),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B11",
          "B8",
          "B2"
        ],
        "min": 184.16,
        "max": 6767.84,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B11","B8","B2"],"min":184.16,"max":6767.84,"gamma":1},
    dem = ui.import && ui.import("dem", "image", {
      "id": "MERIT/DEM/v1_0_3"
    }) || ee.Image("MERIT/DEM/v1_0_3");
Map.setCenter(77.177, 34.524, 5);
/**
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */ 
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask);
}
// Function to get the sentinel image collection based on shape and date
function getSentinelCollection(shape, startDate) {
  return ee.ImageCollection('COPERNICUS/S2')
    .filterBounds(shape)
    .filterDate(ee.Date(startDate), ee.Date(startDate).advance(1, 'month'))
    .map(addNDSI)
  //  .map(maskS2clouds)
    .median();
}
// Function to add NDSI band to an image
function addNDSI(image) {
  var NDSI = image.normalizedDifference(['B3', 'B11']).rename('NDSI');
  return image.addBands(NDSI);
}
function computeNDSIHistogram(image, shape, scale) {
  var ndsi = image.select('NDSI');
  var histogram = ndsi.reduceRegion({
    reducer: ee.Reducer.histogram(),
    geometry: shape.geometry(),
    scale: scale,
    maxPixels: 1e9
  });
  return histogram.get('NDSI');
}
// Function to update map layers with FCC and NDSI
function loadImages() {
  // Clear previous layers
  Map.layers().reset();
  var shapeId = dropdown.getValue();
  var selectedDates = dateSlider.getValue();
  var startDate = selectedDates[0]; // Using the start date
  var shape = table.filter(ee.Filter.eq('subdistric', shapeId));
  var sentinel = getSentinelCollection(shape, startDate);
  var NDSIParams = {min: -1, max: 1, bands: 'NDSI', palette: ['blue', 'purple', 'cyan', '#10cbdb'] };
  Map.centerObject(shape, 9);
  Map.addLayer(sentinel.clip(shape), {"opacity":1,"bands":["B11","B8","B2"],"min":184.16,"max":6767.84,"gamma":1}, 'FCC_'+shape.aggregate_array('subdistric').getInfo().toString()+'-'+ee.Date(startDate).format('YYYY-MM-dd').getInfo());
  Map.addLayer(sentinel.select('NDSI').clip(shape), NDSIParams, 'NDSI_'+shape.aggregate_array('subdistric').getInfo().toString()+'-'+ee.Date(startDate).format('YYYY-MM-dd').getInfo());
}
function computeHistogram (){
    var shapeId = dropdown.getValue();
    var selectedDates = dateSlider.getValue();
    var startDate = selectedDates[0];
    var shape = table.filter(ee.Filter.eq('subdistric', shapeId));
    var sentinel = getSentinelCollection(shape, startDate);
    var ndsiHistogram = computeNDSIHistogram(sentinel, shape, 100); // Adjust scale as needed
    ndsiHistogram.evaluate(function(result) {
    // Create the histogram chart
    var chart = ui.Chart.array.values({
      array: result.histogram,
      axis: 0,
      xLabels: result.bucketMeans
    })
    .setOptions({
      title: 'NDSI Histogram for '+shape.aggregate_array('subdistric').getInfo()+' on '+ee.Date(startDate).format('YYYY-MM-dd').getInfo(),
      hAxis: { title: 'NDSI Value' },
      vAxis: { title: 'Frequency' },
      legend: { position: 'none' },
      series: { 0: { color: 'blue' } }
    });
    histogramPanel.clear(); // Clear the panel before adding a new chart
    histogramPanel.add(chart);
  });
  }
// Load a DEM (e.g., SRTM) and compute the slope
 // SRTM DEM
// Function to update map layers with masked NDSI
function loadMaskedNDSI() {
// Clear previous layers
  Map.layers().reset();
  var shapeId = dropdown.getValue();
  var selectedDates = dateSlider.getValue();
  var startDate = selectedDates[0]; // Using the start date
  var shape = table.filter(ee.Filter.eq('subdistric', shapeId));
  var threshold = thresholdSlider.getValue();
  var sentinel = getSentinelCollection(shape, startDate);
  var slopeMask = ee.Terrain.slope(dem.select('dem')).gte(5);
  var maskedNDSI = sentinel.select('NDSI')
                            .updateMask(sentinel.select('NDSI')
                            .gte(threshold))
                            .updateMask(slopeMask);
  var mNDSIParams = {min: 0, max: 1, bands: 'NDSI', palette: ['#10cbdb']};
  Map.centerObject(shape, 9);
  Map.addLayer(sentinel.clip(shape), {"opacity":1,"bands":["B11","B8","B2"],"min":184.16,"max":6767.84,"gamma":1}, 'FCC_'+shape.aggregate_array('subdistric').getInfo().toString()+'-'+ee.Date(startDate).format('YYYY-MM-dd').getInfo());
  Map.addLayer(maskedNDSI.clip(shape), mNDSIParams, 'Snow-'+shape.aggregate_array('subdistric').getInfo().toString()+'-'+ee.Date(startDate).format('YYYY-MM-dd').getInfo());
  var areaImage = maskedNDSI.multiply(ee.Image.pixelArea());
  var totalArea = areaImage.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: shape.geometry(),
    scale: 20,
    maxPixels: 1e9
  });
  // Update the label with the total unmasked area
  totalArea = ee.Number(totalArea.get('NDSI')).divide(1e6); // Convert square meters to square kilometers
  totalArea.evaluate(function(result) {
    areaLabel.setValue('Total Area on '+ee.Date(startDate).format('YYYY-MM-dd').getInfo()+' is:'+ result.toFixed(3) + ' sq. km. for threshold: '+threshold.toFixed(3));
  });
  return maskedNDSI
}
function exportSnowMapAsKML() {
  var shapeId = dropdown.getValue();
  var selectedDates = dateSlider.getValue();
  var startDate = selectedDates[0]; // Using the start date
  var thresh = thresholdSlider.getValue();
  var shape = table.filter(ee.Filter.eq('subdistric', shapeId));
  var snow = loadMaskedNDSI(); // Assuming loadMaskedNDSI returns the snow map image
  var snowVectors = snow.addBands(snow).toInt()
      .reduceToVectors({
      reducer: ee.Reducer.mean(),
      geometry: shape.geometry(),
      scale: 30,
      geometryType: 'polygon',
      eightConnected: false,
      labelProperty: 'snow',
      maxPixels: 1e10
    });
  Map.addLayer(snowVectors,{color:'#10cbdb'},'Snow Vector')
  var kmlLink = snowVectors.getDownloadURL({    
    format: 'kml',
    filename: 'SnowCoverArea_'+shape.aggregate_array('subdistric').getInfo().toString()+'_'+ee.Date(startDate).format('YYYY-MM-dd').getInfo()
  });
  downloadLabel.setUrl(kmlLink);
  downloadLabel.setValue('Download Snow Vectors for '+shape.aggregate_array('subdistric').getInfo().toString()+'-'+ee.Date(startDate).format('YYYY-MM-dd').getInfo()+'_Th_'+thresh.toString() );
}
// UI Elements
var areaLabel = ui.Label();
var dateSlider = ui.DateSlider({
  start: '2016-01-01',
  end: '2026-01-01',
  value: '2020-10-20', // Default value
  period: 1, // one-day granularity
  style: {stretch: 'horizontal'},
  onChange: function(date) {
    // You can define what happens when the date changes
  }
});
var dropdown = ui.Select({
  items: ee.List(table.aggregate_array('subdistric')).getInfo()
});
var thresholdSlider = ui.Slider({
  min: -1,
  max: 1,
  value: 0.5, // Default value
  step: 0.01, // Increment size
  style: {stretch: 'horizontal'}
});
var loadImagesButton = ui.Button({
  label: 'Load FCC & NDSI Images',
  onClick: loadImages
});
var loadMaskedNDSIButton = ui.Button({
  label: 'Load Snow and Estimate Area',
  onClick: loadMaskedNDSI
});
var computeHistogramButton = ui.Button({
  label: 'Compute Histogram',
  onClick: computeHistogram
});
var exportButton = ui.Button({
  label: 'Export Snow Map as KML',
  onClick: exportSnowMapAsKML
});
var downloadLabel = ui.Label('Step 8: Download Snow Vectors', {
  margin: '8px 0px',
  fontSize: '12px', // Slightly larger for better readabilityd
  color: 'green', 
  fontWeight: 'bold', // Bold to emphasize instructions
  backgroundColor: '#f8f8f8', // Light background for contrast
  padding: '4px',
  border: '1px solid #e0e0e0', // Subtle border
 // borderRadius: '4px' // Rounded corners for a softer look
});
var map=ui.Map()
Map.setControlVisibility({
  all: false, // Hide all controls
  zoomControl: true, // Specifically ensure that zoom controls are off
  mapTypeControl: true ,// Disable changing map type (satellite, terrain, etc.)
  layerList:true
});
// Enhanced style for instruction labels
var enhancedInstructionStyle = {
  margin: '8px 0px',
  fontSize: '12px', // Slightly larger for better readability
  color: '#0055cc', // Using a softer blue for a modern look
  fontWeight: 'bold', // Bold to emphasize instructions
  backgroundColor: '#f8f8f8', // Light background for contrast
  padding: '4px',
  border: '1px solid #e0e0e0', // Subtle border
 // borderRadius: '4px' // Rounded corners for a softer look
};
// Define your instructional labels with the enhanced style
var step1Label = ui.Label('Step 1: Select a Date using the Date Slider.', enhancedInstructionStyle);
var step2Label = ui.Label('Step 2: Choose a Shape from the Dropdown Menu.', enhancedInstructionStyle);
var step3Label = ui.Label('Step 3: Click "Load Images" to display the images on the map.', enhancedInstructionStyle);
var step4Label = ui.Label('Step 4: Use the "Compute NDSI Histogram" button to analyze the threshold.', enhancedInstructionStyle);
var step5Label = ui.Label('Step 5: Adjust the NDSI Threshold Slider to refine snow cover detection.', enhancedInstructionStyle);
var step6Label = ui.Label('Step 6: Use the "Load Snow and Estimate Area" button to analyze snow cover.', enhancedInstructionStyle);
var step7Label = ui.Label('Step 7: Use the "Export Snow Map as KML" button to export snow cover.', enhancedInstructionStyle);
var mainPanelStyle = {
  padding: '12px',
  border: '2px solid #d0d0d0',  // Solid, subtle border
  width: '420px', // Slightly wider for a better layout
  backgroundColor: '#fafafa', // Light, neutral background color
 // boxShadow: '0 2px 6px rgba(0,0,0,0.1)', // Soft shadow for depth
 // borderRadius: '5px' // Rounded corners for a modern look
};
var panel = ui.Panel({  
  widgets: [
    ui.Label({
    value: 'Snow Area Mapper for Ladakh using Sentinel 2 Satellite ',
    style: {
    fontWeight: 'bold',
    color: 'blue',
    fontSize: '20px', // Adjust the font size as needed
    margin: '10px 0px', // Optional: Adds margin above and below the label,
      textAlign: 'center'  
      }
      }),
      step1Label,
    dateSlider,
    step2Label,
    dropdown,
    step3Label,
    loadImagesButton,
    step5Label,
    thresholdSlider,
    step6Label,
    loadMaskedNDSIButton,
    areaLabel,
    step7Label,
    exportButton,
    downloadLabel
  ],
  style: mainPanelStyle
});
// Create the histogram chart panel (empty initially)
var histogramPanel = ui.Panel({
  style: {
    width: '400px',
   // height: '100%',
    padding: '8px',
   // border: '1px solid black',
    margin: '8px 0'
  }
});
// Create a panel for histogram controls
var histogramControlPanel = ui.Panel({
  widgets: [
    step4Label,
    computeHistogramButton,
    histogramPanel // This panel will contain the histogram chart
  ],
  style: {
    position: 'bottom-left',
    padding: '2px',
   // border: '1px solid black',
    height: '300px',
    width: '450px'
  }
});
Map.add(histogramControlPanel);
var Titles =ui.Label({
    value: 'Snow Area Mapper for Ladakh using Sentinel 2 Satellite ',
    style: {
    fontWeight: 'bold',
    color: '#10cbdb',
    fontSize: '26px', // Adjust the font size as needed
    margin: '10px 0px', // Optional: Adds margin above and below the label,
      textAlign: 'center'  
      }
      });
 Map.add(Titles);     
// Add UI elements to map
ui.root.add(panel);