/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var roi = 
    /* color: #bf04c2 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[90.31272590612953, 23.853917457152328],
          [90.31272590612953, 23.70248316142564],
          [90.45657814001625, 23.70248316142564],
          [90.45657814001625, 23.853917457152328]]], null, false),
    tun = ee.FeatureCollection("users/Maninder_Rao/India_Boundry");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
//-----------------------------------------------------------------------------------------------------------//
//                                              INITIALISATION
//----------------------------------------------------------------------------------------------------------//
var mapPanel = ui.Map();
ui.root.widgets().reset([mapPanel]);
mapPanel.setOptions('HYBRID');
mapPanel.style().set('cursor', 'crosshair');
//-----------------------------------------------------------------------------------------------------------//
//                                              DATA PROCESSING
//----------------------------------------------------------------------------------------------------------//
var startYear = 2019;
var endYear = 2019;
var years = ee.List.sequence(startYear, endYear);
// Set the Area of Interest
//var tun = ee.FeatureCollection("users/labiadhmoez/ETHIO_adm");
// Add the CHRIPS daily precipitation collection
var Daily = ee.ImageCollection('UCSB-CHG/CHIRPS/DAILY')
                   .select('precipitation')
                   .filterDate('2019-01-01', '2022-12-31')
                   .filterBounds(tun);
// // Create a function to calculate Annual Precipitation from Daily Precipitation      
// function precAnnual (hour) {
//   var annual = Daily.filter(ee.Filter.calendarRange(day, day, 'day'))
//                       .sum()
//                       .rename('Daily Precipitation');
//   return annual.set('day', ee.Date.fromYMD(day, 1, 1)
//               .format('DD'));
// }
// // Apply the precAnnual to each year            
// var annualPrecip = ee.ImageCollection.fromImages(years.map(precAnnual));
// // Add MEAN, MIN, MAX bands to annualPrecip
// function addBands (image){
//   var annualMean = annualPrecip.mean()
//                               .rename('Long Term Average');
//   return image.addBands(annualMean);
// }
// Apply the addBands function to the collection
//var precCol = ee.ImageCollection(annualPrecip.map(addBands));
//var annualMean_show = ee.Image()
var pViz = {min: 0, max: 800, palette:'red,orange,yellow,aqua,blue,navy'};
mapPanel.centerObject(tun, 6);
//mapPanel.addLayer(annualMean_show, pViz, 'Average Annual Precipitation');
//-----------------------------------------------------------------------------------------------------------//
//                                              APP
//----------------------------------------------------------------------------------------------------------//
// ******Define the Onlick Function (chart) ******//
mapPanel.onClick(function(coords) {
  // Update the lon/lat panel with values from the click event.
  loc.setValue('Clicked Location Coordinates: ');
  lon.setValue('Longitude: ' + coords.lon.toFixed(2)),
  lat.setValue('Latitude: ' + coords.lat.toFixed(2));
  // Add a red dot for the point clicked on.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: '#fc0303'}, 'Clicked Location');
  mapPanel.layers().set(0, dot);
  // Inspect
  var options = {
     title: 'Daily Rainfall of India for Year 2019-2022 by EarthNow',
     hAxis: {title: 'Year'},
     vAxis: {title: 'Precipitation (mm)'},
     curveType: 'function',
     series: {
               0: {color: '#2B4EB6', lineWidth: 2}, // Prec 
               1: {color: '#F79C24', lineWidth:1}, //LT-MEAN
  }};
     var chart = ui.Chart.image.series({
     imageCollection: Daily,
     region: point,
     reducer: ee.Reducer.mean(),
     scale: 5000,
     //xProperty: 'year',
      }).setOptions(options)
        .setChartType('ColumnChart');
    panel.widgets().set(2, chart);
  });
// ******Create panel and Widgets******//
  var panel = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical', true),
    style: {
      stretch: 'vertical',
      height: '50%',
      width: '300px',
      position: 'top-left'
    }
  });
// Use a SplitPanel so it's possible to resize the two panels.
var splitPanel = ui.SplitPanel({
  firstPanel: mapPanel,
  secondPanel: panel,
  orientation: 'vertical',
  style: {stretch: 'both'}
});
// Set the SplitPanel as the only thing in root.
ui.root.widgets().reset([splitPanel]);
// Add title
var title = ui.Label({value: 'Rainfall Time-Series Inspector by EarthNow', 
                      style: {fontWeight: 'bold',
                              textAlign: 'center',
                              fontSize: '16px',
                              margin: '7.5px 2.5px 10px 2.5px',
                              color : '#273358',
                              stretch: 'horizontal'}});
//LEGEND
// palette.
function makeColorBarParams(palette) {
  return {
    bbox: [0, 0, 1, 0.1],
    dimensions: '80x10',
    format: 'png',
    min: 0,
    max: 1,
    palette: palette,
  };
}
//colorbar
var colorBar = ui.Thumbnail({
  image: ee.Image.pixelLonLat().select(0),
  params: makeColorBarParams(pViz.palette),
  style: {stretch: 'horizontal', margin: '0px 10px', Height: '5px'}
});
// Create a panel with three numbers for the legend.
var legendLabels = ui.Panel({
  widgets: [
    ui.Label(pViz.min, {margin: '2px 4px',fontSize: '10px'}),
    ui.Label(
        (pViz.max / 2),
        {margin: '2px 4px', textAlign: 'center', stretch: 'horizontal',fontSize: '10px'}),
    ui.Label(pViz.max + '+', {margin: '2px 10px',fontSize: '10px'})
  ],
  layout: ui.Panel.Layout.flow('horizontal')
});
//Legend title
var legendTitle = ui.Label({
  value: 'Daily Precipitation for Year 2019-22 (in mm)',
  style: {fontSize: '10px', 
          textAlign: 'center',
          fontWeight: 'bold',
  }
});
var legendPanel = ui.Panel([legendTitle, colorBar, legendLabels]);
// Add inspect and graph
var label = ui.Label({value: 'Click a point on the map to generate the chart.', 
                      style: {fontWeight: 'bold',
                              fontSize: '10px',
                              margin: '10px 2.5px 1.5px 2.5px'}});
var chart_desc = ui.Label({value:'The chart shows the annual total rainfall amounts of the last 4 years (2019 to 2022)' +
                                  ' as calculated from daily CHRIPS* rainfall data. Click on the maximize button ' +
                                  'to open the chart in a seperate window and save data as image or CSV.',
                           style: {fontSize: '10px', 
                                   textAlign: 'left', 
                                   stretch: 'horizontal'}});
var loc = ui.Label();
var lon = ui.Label();
var lat = ui.Label();
var latlong = ui.Panel([loc,lon, lat], ui.Panel.Layout.flow('horizontal'));
//source
var source = ui.Label({value:'*CHIRPS: Climate Hazards Group InfraRed Precipitation with Station data',
                      style: {fontSize: '9px', 
                              textAlign: 'left', 
                              margin: '10px 10px 20px 10px', 
                              stretch: 'horizontal'}});
// Add widgets to the Panel 
panel.widgets().set(0, title);
panel.widgets().set(1, legendPanel);
panel.widgets().set(2, label);
//panel.widgets().set(3, chart_desc);
//panel.widgets().set(4, source);
panel.widgets().set(5, latlong);   
//reserved for position 6 (chart)