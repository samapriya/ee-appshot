/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var region = ee.FeatureCollection("users/singh22pragati/India");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
// Create a label on the map.
var label = ui.Label('NDVI vs Rainfall by EARTHNOW', {fontWeight : 'bold'});
Map.add(label);
 function getPeriods(begin_year, end_year, period_length){
  var dates = [];
  for (var y = begin_year; y <= end_year; y++) {
    var first_of_year = new Date(Date.UTC(y, 0, 1));
    var start = first_of_year;
    for (var d = 0; d < 365/period_length; d++) {
      dates.push(start.toISOString());
      start.setDate(start.getDate() + period_length);
    }
  }
  return ee.List(dates).map(function(str){
    return ee.Date(str);
  });
}
Map.addLayer(region)
Map.centerObject(region,5)
var PERIOD_LENGTH = 5;
var YEAR1 = 2017;
var YEAR2 = 2022
var periods = getPeriods(YEAR1, YEAR2, PERIOD_LENGTH);
var rain = ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY")
                  .select('precipitation')
                  //.filter(ee.Filter.calendarRange(YEAR1,YEAR2,'year'));
var s2 = ee.ImageCollection("COPERNICUS/S2")                  
var collection = ee.ImageCollection(periods.map(function(dt) {
  var subset = rain.filterDate(dt, ee.Date(dt).advance(PERIOD_LENGTH, 'day'));
  var sum = subset.sum();
  sum = sum.set('system:time_start',ee.Date(dt).millis());
  var img = s2.filterDate(dt, ee.Date(dt).advance(PERIOD_LENGTH, 'day')).mosaic()
    var ndvi = img.normalizedDifference(['B8', 'B4']).rename('NDVI');
  ndvi = ndvi.set('system:time_start',ee.Date(dt).millis());
    return ndvi.addBands([sum])
}));
var title = ui.Label({
  value: 'Click Map for Time-Series Chart',
  style: {fontSize: '14px',fontWeight : 'bold'}
});
var lon = ui.Label();
var lat = ui.Label();
var sidebar = ui.Panel({
  widgets: [title, lon, lat],
  style: {width: '300px'}
});
ui.root.add(sidebar);
function updateChart(coords) {
  lon.setValue('Longitude: ' + coords.lon);
  lat.setValue('Lattitude: ' + coords.lat);
  // Add a red dot to the map.
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var dot = ui.Map.Layer(point, {color: 'FF0000'}, 'Clicked Point');
  Map.layers().set(1, dot);
  // Add an NDVI chart.
  var chart = ui.Chart.image.series({imageCollection: collection.select(['NDVI', 'precipitation']),
                                                  region:point, 
                                                  //maxPixels: 10e12,
                                                  reducer: ee.Reducer.mean(),
                                                  //bestEffort: true,
                                                  scale: 10
});
  chart.setOptions({
    title: 'NDVI & Rain Over Time',
    legend: {maxLines: 5, position: 'top'},
    series: {
          0: {targetAxisIndex: 0},
          1: {targetAxisIndex: 1}
        },
        vAxes: {
          // Adds titles to each axis.
          0: {title: 'NDVI'},
          1: {title: 'Precipitation'}
        },
  });
  /*var chart1 = ui.Chart.image.series(rain,  point, ee.Reducer.mean(), 400);
  chart.setOptions({
    title: 'Rain Over Time',
    vAxis: {title: 'RAIN'},
    hAxis: {title: 'date', format: 'MM-yy', gridlines: {count: 7}},
  });*/
  sidebar.add(chart);
}
Map.onClick(updateChart);