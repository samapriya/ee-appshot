// ALOS_AVNIR2_app
// ALOS/AVNIR-2 オルソ補正画像
var app = {}; //空のオブジェクト生成
// UIパネル作成開始
app.createPanels = function() {
  // 検索条件指定パネル
  app.filters = {
    closeButton: ui.Button({
      label: '閉じる',
      style: {margin: '0 0 0 6em'},
    }),
    sArea: ui.Select({
      items: Object.keys(app.places),
      placeholder: '地域選択',
      onChange: function(key) {
        Map.setCenter(app.places[key][0], app.places[key][1], 10);
      },
      style: {stretch: 'horizontal'},
    }),
    geoButton: ui.Button({
      label: '現在地',
      onClick: function() {
        ui.util.getCurrentPosition(
          function(position) {
            Map.centerObject(position,14);
          }
        );
      }
    }),
    selectYear: ui.Select({
      style: {stretch: 'horizontal'},
    }),
    selectMonth: ui.Select(),
    // cloudcover: ui.Slider({
    //   min: 10,
    //   max: 100,
    //   value: app.cloudCover,
    //   step: 10,
    //   onChange: function(value) {
    //     app.cloudCover = value;
    //   },
    //   style: {stretch: 'horizontal'}
    // }),
    applyButton: ui.Button({
      label: '検索実行',
      onClick: app.applyFilters,
      style: {stretch: 'horizontal'},
    }),
    loadingLabel: ui.Label({
      value: 'Loading...',
      style: {stretch: 'vertical', color: 'gray', shown: false}
    })
  };
  app.filters.panel = ui.Panel({
    widgets: [
      app.filters.closeButton,
      ui.Label({
        value: 'ALOS/AVNIR-2 オルソ補正画像',
        style: {
          fontWeight: 'bold',
          fontSize: '1em',
          margin: '0.4em 0'},
      }),
      ui.Label({
        value: '「だいち」(ALOS)搭載のAVNIR-2による解像度10m、日本領域のオルソ補正画像',
        style: {fontSize: '0.8em'},
      }),
      ui.Label('1. 検索条件', app.HEADER_TEXT_STYLE),
      ui.Panel([
        app.filters.sArea,
        app.filters.geoButton
      ], ui.Panel.Layout.flow('horizontal')),
      ui.Label('開始年・月', app.HELPER_TEXT_STYLE), 
      ui.Panel([
        app.filters.selectYear,
        app.filters.selectMonth
      ], ui.Panel.Layout.flow('horizontal')),
      // ui.Label('雲量の上限(%)', app.HELPER_TEXT_STYLE),
      // app.filters.cloudcover,
      ui.Panel([
        app.filters.applyButton,
        app.filters.loadingLabel
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    style: app.SECTION_STYLE
  });
  // 検索開始年・月リストのセット
  app.yearList.evaluate(function(ids){
    app.filters.selectYear.items().reset(ids);
    app.filters.selectYear.setValue(app.startYear);
  });
  app.monthList.evaluate(function(ids){
    app.filters.selectMonth.items().reset(ids);
    app.filters.selectMonth.setValue(app.startMonth);
  });
  // 検索結果撮影日のセレクタ
  app.picker = {
    select: ui.Select({
      placeholder: '検索待ち',
      onChange: app.refreshMapLayer,
      style: {stretch: 'horizontal'},
    }),
  };
  app.picker.panel = ui.Panel({
    widgets: [
      ui.Label('2. 撮影日を選択', app.HEADER_TEXT_STYLE),
      app.picker.select,
    ],
    style: app.SECTION_STYLE
  });
  // カラー合成画像の表示設定
  app.vis = {
    checkColorComp: ui.Checkbox({ // 表示ON/OFF
      value:true,
      onChange: function(checked) {
        Map.layers().get(0).setShown(checked);}
    }),
    select: ui.Select({ // カラー合成の選択
      items: Object.keys(app.VIS_OPTIONS),
      onChange: function(key) {
        var option = app.VIS_OPTIONS[key];
        app.vis.label.setValue(option.description);
        app.refreshMapLayer();
      },
      style: {stretch: 'horizontal', margin: '0 0.5em 0 -0.3em'},
    }),
    label: ui.Label({style: {fontSize: '0.75em'}}),
    checkAdBounds: ui.Checkbox({ // 市町村界描画
      label: '市町村界',
      onChange: function(checked) {
        Map.layers().get(2).setShown(checked);
      },
      style: {fontSize: '0.85em'}
    }),
  };
  app.vis.panel = ui.Panel({
    widgets: [
      ui.Label('3. カラー合成', app.HEADER_TEXT_STYLE),
      ui.Panel([
        app.vis.checkColorComp,
        app.vis.select
      ], ui.Panel.Layout.flow('horizontal')),
      app.vis.label,
      app.vis.checkAdBounds,
    ],
    style: app.SECTION_STYLE
  });
  // カラー合成選択の初期値
  app.vis.select.setValue(app.vis.select.items().get(0));
  // 主題図レイヤの表示設定
  app.visTmap = {
    checkVI: ui.Checkbox({ // レイヤ表示ON/OFF
      value:false,
      onChange: function(checked) {
        Map.layers().get(1).setShown(checked);
        Map.widgets().get(2).style().set('shown', checked);
      },
      style: {fontSize: '0.85em'}
    }),
    // 凡例用ラベル
    legendDate: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    legendBands: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    legendMin: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    legendMax: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    legendAve: ui.Label({
      style: {
        fontSize: '0.85em',
        margin: '0 0 0 0.3em',
        textAlign: 'center',
        stretch: 'horizontal'}
    }),
    select: ui.Select({ // 植生指数の選択
      items: Object.keys(app.VIS_OPTIONS2),
      onChange: function(key) {
        var option2 = app.VIS_OPTIONS2[key];
        app.visTmap.label.setValue(option2.description);
        app.visTmap.legendBands.setValue(option2.visParams.bands);
        var visMin = option2.visParams.min;
        var visMax = option2.visParams.max;
        var visAve = Math.round((visMin + visMax) * 100 / 2) / 100;
        app.visTmap.legendMin.setValue(visMin);
        app.visTmap.legendMax.setValue(visMax);
        app.visTmap.legendAve.setValue(visAve);
        app.refreshMapLayer();
      },
      style: {stretch: 'horizontal', margin: '0 0.5em 0 -0.3em'},
    }),
    label: ui.Label({style: {fontSize: '0.75em', whiteSpace: 'pre-wrap'}}),
    checkFude: ui.Checkbox({
      label: '農地区画のみ表示',
      onChange: app.refreshMapLayer,
      style: {fontSize: '0.85em'}
    }),
    selectColorScheme: ui.Select({
      items: Object.keys(app.colorSchemes),
      placeholder: 'レイヤ配色の変更',
      onChange: function(key) {
        app.colorRamp = app.colorSchemes[key];
        var optionTmap = app.VIS_OPTIONS2[app.visTmap.select.getValue()];
        var visParamsTmap = optionTmap.visParams;
        visParamsTmap.palette = app.colorRamp;
        Map.layers().get(1).setVisParams(visParamsTmap);
        app.legendLabels.clear();
        app.legendPanel.clear();
        app.dispLegend();
      },
      style: {stretch: 'horizontal'},
    }),
  };
  app.visTmap.panel = ui.Panel({
    widgets: [
      ui.Label('4. 植生指数レイヤ', app.HEADER_TEXT_STYLE),
      ui.Panel([
        app.visTmap.checkVI,
        app.visTmap.select
      ], ui.Panel.Layout.flow('horizontal')),
      app.visTmap.label,
      app.visTmap.checkFude,
      app.visTmap.selectColorScheme,
    ],
    style: app.SECTION_STYLE
  });
  // 植生指数選択の初期値
  app.visTmap.select.setValue(app.visTmap.select.items().get(0));
  // 凡例を表示
  app.dispLegend();
  // チャート用パネル
  app.charts = {
    setDrawingButton: ui.Button({
      label: '領域設定',
      onClick: app.setDrawingTools,
      style: {stretch: 'horizontal'},
    }),
    clearDrawingButton: ui.Button({
      label: 'クリア',
      onClick: function(){
        Map.drawingTools().clear();
        Map.drawingTools().setShown(false);
        Map.setControlVisibility({
          layerList: true,
          mapTypeControl: true
        });
        app.dispChartPanel.clear();
        app.dispChartPanel.style().set('shown', false);
      },
    }),
    drawChartButton: ui.Button({
      label: 'チャート作成',
      onClick: app.drawChart,
      style: {stretch: 'horizontal'},
    }),
  };
  app.charts.panel = ui.Panel({
    widgets: [
      ui.Label('5. スペクトル情報表示', app.HEADER_TEXT_STYLE),
      ui.Panel([
        app.charts.setDrawingButton,
        app.charts.clearDrawingButton,
      ], ui.Panel.Layout.flow('horizontal')),
      app.charts.drawChartButton,
    ],
    style: app.SECTION_STYLE
  });
}; 
// UIパネル作成終了
// 補助機能設定
app.createHelpers = function() {
  // 検索実行に合わせて入力ウィジエットを無効化・有効化
  app.setLoadingMode = function(enabled) {
    app.filters.loadingLabel.style().set('shown', enabled);
    var loadDependentWidgets = [
　　　app.filters.sArea,
      app.filters.geoButton,
      app.filters.selectYear,
      app.filters.selectMonth,
      // app.filters.cloudcover,
      app.filters.applyButton,
      app.picker.select,
    ];
    loadDependentWidgets.forEach(function(widget) {
      widget.setDisabled(enabled);
    });
  };
  // 指定条件による検索実行
  app.applyFilters = function() {
    app.setLoadingMode(true);
    var startY = app.filters.selectYear.getValue();
    var startM = app.filters.selectMonth.getValue();
    var startD = ee.Date(startY + '-' + startM + '-01');
    var filtered = app.imgCollection
          .filterBounds(Map.getCenter())
          .filterDate(startD, startD.advance(3, 'year'))
          // .filter(ee.Filter.lt('CLOUD_COVER', app.cloudCover))
          .sort('system:time_start')
          .limit(app.IMAGE_COUNT_LIMIT);
    // 検索条件を満たす撮影日リストを出力
    var computeDates = 
      ee.List(filtered.aggregate_array('system:time_start'))
      .map(function(d) { return ee.Date(d).format('YYYY-MM-dd')})
      .distinct() // 重複日付を除去
      .slice(0, app.IMAGE_LIST_LIMIT); // リスト先頭から指定件数を得る
    computeDates.evaluate(function(ids) {
      app.setLoadingMode(false);
      app.picker.select.items().reset(ids); // セレクタリスト更新
      // セレクタにリスト先頭の日付をセット
      app.picker.select.setValue(app.picker.select.items().get(0));
    });
  };
};　// 補助機能設定終了
// マップ画面の更新
app.refreshMapLayer = function() {
  var imageDateStr = app.picker.select.getValue();
  if (imageDateStr) {
    app.visTmap.legendDate.setValue(imageDateStr);
    // 衛星画像の加工とモザイク
    var imgDate = ee.Date(imageDateStr);
    var dateRange = ee.DateRange(imgDate, imgDate.advance(1, 'day'));
    app.mosaicimg = app.imgCollection
      .filterDate(dateRange)
      .map(app.ScaleResample).mosaic();
    // カラー合成画像の表示
    var visOption = app.VIS_OPTIONS[app.vis.select.getValue()];
    var imgname = 'Image:' + imageDateStr;
    var imgCheck = app.vis.checkColorComp.getValue();
    var ColorComposit = ui.Map.Layer(app.mosaicimg, visOption.visParams, imgname, imgCheck);
    Map.layers().set(0, ColorComposit);
    // 主題図レイヤの表示
    var visOption2 = app.VIS_OPTIONS2[app.visTmap.select.getValue()];
    visOption2.visParams.palette = app.colorRamp;
    var vegimg = app.mosaicimg.select('NDVI');
    var vegimgname = 'VI:' + imageDateStr;
    var vegimgCheck = app.visTmap.checkVI.getValue();
    // 植生指数の設定値以下をマスク
    var viMin = visOption2.visRange.min;
    var viBand = ee.List(visOption2.visParams.bands);
    var vimask = vegimg.select(viBand).gte(viMin);
    vegimg = vegimg.updateMask(vimask);
    // 筆ポリゴンによる植生指数画像切り抜き
    // Zoomスケール14以上で有効化
    // Zoom率変更に伴う制御を間隔300ミリ秒以上に（debounce）
    app.checkboxFudeControl = ui.util.debounce(function() {
      if (Map.getZoom()>13){
        app.visTmap.checkFude.setDisabled(false);
      } else {
        app.visTmap.checkFude.setValue(false);
        app.visTmap.checkFude.setDisabled(true);
      }
    }, 300);
    app.checkboxFudeControl();
    Map.onChangeZoom(app.checkboxFudeControl);
    var fudeCheck = app.visTmap.checkFude.getValue();
    if (fudeCheck) {
      vegimg = vegimg.clipToCollection(app.Fudepoly);
    }
    var VImap = ui.Map.Layer(vegimg, visOption2.visParams, vegimgname, vegimgCheck);
    Map.layers().set(1, VImap);
    // 市町村境界の表示
    var adminCheck = app.vis.checkAdBounds.getValue();
    var Admin = ui.Map.Layer(app.Admindivline, {palette: '#ffd700'}, 'Admin division', adminCheck);
    Map.layers().set(2, Admin);
    // 筆ポリゴン境界の表示
    var Fude = ui.Map.Layer(app.Fudeoutline, {palette: '#808080'}, 'Fude polygon', fudeCheck);
    Map.layers().set(3, Fude);
  }
}; // マップ画面の更新終了
// チャート描画関数
app.drawChart = function() {
  if (Map.drawingTools().layers().get(0)) {
  var aoi = Map.drawingTools().layers().get(0).toGeometry();
  var aoiCent = aoi.centroid().coordinates().getInfo();
  var lonlat = ('領域重心 E' + aoiCent[0].toFixed(6) + ', N' + aoiCent[1].toFixed(6));
    var chart1 = ui.Chart.image.regions({
      image: app.mosaicimg
        .select('B[1-4]','NDVI'),
      regions: aoi,
      reducer: ee.Reducer.mean(),
      scale: 10,
    });
    var chartOptions1 = {
      title: 'デジタル値・植生指数: ' + lonlat,
      vAxis: {title: 'デジタル値／255・NDVI'},
      legend: { position: "none" },
    };
    chart1.setChartType('ColumnChart');
    chart1.setOptions(chartOptions1);
    // app.charts.panel.widgets().set(3, chart1);
    app.dispChartPanel.style().set('shown', true);
    app.dispChartPanel.widgets().set(0, chart1);
  } // end of if
}; // チャート描画終了
// メインパネルの表示切り替え
app.mainPanelControl = function() {
  app.filters.closeButton.onClick(function() {
    app.main.style().set('shown', false);
    app.creditPanel.style().set('shown', false);
    app.openButton.style().set('shown', true);
    Map.setControlVisibility({
      layerList: false,
      mapTypeControl: false
    });
  });
  app.openButton = ui.Button({
    label: '設定',
    style: {position: 'top-left', 'padding': 0},
    onClick: function() {
      app.openButton.style().set('shown', false);
      app.main.style().set('shown', true);
      app.creditPanel.style().set('shown', true);
      Map.setControlVisibility({
        layerList: true,
        mapTypeControl: true
      });
    }
  });
  Map.add(app.openButton);
  app.openButton.style().set('shown', false);
};
// 初期設定
app.initialSetup = function() {
  // マップ画面の初期化
  Map.clear();
  Map.drawingTools().setShown(false);
  // Map.setControlVisibility({fullscreenControl : false});
  // Map.setOptions('SATELLITE');
  Map.setCenter(142.506, 43.566, 7);
  //衛星データセットの指定
  app.imgCollection = ee.ImageCollection('JAXA/ALOS/AVNIR-2/ORI');
  //農水省筆ポリゴン（北海道分） 
  app.Fudepoly = ee.FeatureCollection('users/hkrnhn/fude2021/Hokkaido');
  app.Fudeoutline = ee.Image().byte()
    .paint({
      featureCollection: app.Fudepoly,
      color: 1,
      width: 1
    });
  // 市町村境界（国土数値情報、北海道分）
  app.Admindiv = ee.FeatureCollection('users/hkrnhn/adminHokkaido');
  app.Admindivline = ee.Image().byte()
    .paint({
       featureCollection: app.Admindiv,
       color: 1,
       width: 2
    });
  app.SECTION_STYLE = {margin: '0'};
  app.HEADER_TEXT_STYLE = {
      margin: '0',
      fontSize: '0.85em',
      fontWeight: 'bold'
  };
  app.HELPER_TEXT_STYLE = {
      margin: '0 0 -0.1em 0.3em',
      fontSize: '0.85em',
      fontWeight: 'bold'
  };
  app.LEGEND_TEXT_STYLE = {
      margin: '0 0 0 0.5em',
      fontSize: '0.85em',
  };
  app.IMAGE_COUNT_LIMIT = 60; // 検索画像数の上限
  app.IMAGE_LIST_LIMIT = 13; // 検索結果リストの上限数
  // app.cloudCover = 50; // 検索条件の雲量初期値
  // 地域リスト
  app.places = {
    '空知': [141.766, 43.197],
    '石狩': [141.345, 43.064],
    '後志': [140.756, 42.902],
    '胆振': [140.971, 42.320],
    '日高': [142.768, 42.172],
    '渡島': [140.753, 41.819],
    '檜山': [140.127, 41.859],
    '上川': [142.439, 43.807],
    '留萌': [141.655, 43.934],
    '宗谷': [141.700, 45.397],
    'オホーツク': [144.260, 44.026],
    '十勝': [143.208, 42.929],
    '釧路': [144.384, 42.976],
    '根室': [145.584, 43.330],
    '実証農場': [143.698787, 43.743359],
  };
  // 検索開始年・月リストの生成
  // app.today = new Date();
  // app.thisYear = app.today.getFullYear();
  // app.startDate = new Date(app.today.setMonth(app.today.getMonth() - 3));
  app.startYear = '2006';
  app.startMonth = '05';
  app.yearList = ee.List.sequence({
    start: 2006, // データセットの初年目
    end: 2011,
    step: 1
  })
  .map(function(y) {
    return ee.Number(y).format('%04d');
  });
  app.monthList = ee.List.sequence({
    start: 1,
    end: 12,
    step: 1
  })
  .map(function(m) {
    return ee.Number(m).format('%02d');
  });
  // 植生指数バンドの計算
  app.calcNDVI = function(image) {
    var ndvi = image.normalizedDifference(['B4', 'B3'])
          .rename('NDVI');
    return ndvi;
  };
  // マップ表示用関数：植生指数付加、スケール変換、リサンプル
  app.ScaleResample = function(image) {
    var ndvi = app.calcNDVI(image);
    return image.select('B[1-4]').divide(255)
      .addBands(ndvi)
      .resample('bilinear');
  };
  // ジオメトリツール起動用関数
  app.setDrawingTools = function() {
    Map.setControlVisibility({
      layerList: false,
      mapTypeControl: false
    });
    Map.drawingTools().clear();
    Map.drawingTools().setShown(true);
    Map.drawingTools().setLinked(false);
    var mapCenter = [Map.getCenter()];
    Map.drawingTools().addLayer({geometries: mapCenter, color:'magenta'});
    Map.drawingTools().setDrawModes(['point', 'line', 'polygon']);
    //Map.drawingTools().draw(); // Enter drawing mode.
  };
  // カラー合成画像の表示オプション
  app.VIS_OPTIONS = {
    'トゥルーカラー': {
      description: '肉眼視に近い色づけ',
      visParams: {
        gamma: 1.1,
        min:[0.02, 0.04, 0.07],
        max:[0.72, 0.74, 0.77],
        bands: ['B3', 'B2', 'B1']
      }
    },
    'トゥルーカラー（明るく）': {
      description: '肉眼視に近い色づけ',
      visParams: {
        gamma: 1.1,
        min:[0.02, 0.04, 0.07],
        max:[0.45, 0.47, 0.50],
        bands: ['B3', 'B2', 'B1']
      }
    },
    'トゥルーカラー（暗く）': {
      description: '肉眼視に近い色づけ',
      visParams: {
        gamma: 1.1,
        min:[0.03, 0.05, 0.09],
        max:[0.93, 0.95, 0.99],
        bands: ['B3', 'B2', 'B1']
      }
    },
    // 'トゥルーカラー（積雪期用）': {
    //   description: '肉眼視に近い色づけ',
    //   visParams: {
    //     gamma: 1.1,
    //     min:[0.03, 0.03, 0.03],
    //     max:[0.98, 0.98, 0.98],
    //     bands: ['B3', 'B2', 'B1']
    //   }
    // },
    '赤外カラー': {
      description: 'RGB=近赤外/赤/緑：' +
                   '植生は赤く見える',
      visParams: {
        gamma: 1.1,
        min:[0.03, 0.01, 0.01],
        max:[0.6, 0.6, 0.6],
        bands: ['B4', 'B3', 'B2']
      }
    },
    // '赤外カラー（積雪期用）': {
    //   description: 'RGB=近赤外/赤/緑：' +
    //               '植生は赤く見える',
    //   visParams: {
    //     gamma: 1.1,
    //     min:[0.10, 0.10, 0.10],
    //     max:[0.95, 0.95, 0.95],
    //     bands: ['B4', 'B3', 'B2']
    //   }
    // },
  };
  // 主題図レイヤの表示オプション
  app.colorSchemes = {
    '紫～緑': ['#762a83','#af8dc3','#e7d4e8','#d9f0d3','#7fbf7b','#1b7837'],
    '黄～緑': ['#ffffcc','#d9f0a3','#addd8e','#78c679','#31a354','#006837'],
    '茶～青緑': ['#8c510a','#d8b365','#f6e8c3','#c7eae5','#5ab4ac','#01665e'],
    '赤～黄～青': ['#d73027','#fc8d59','#fee090','#e0f3f8','#91bfdb','#4575b4'],
    '紫～青～緑～黄～赤':['#990099','#005aff','#4dc4ff','#03af7a','#fff100','#f6aa00','#ff4b00'],
  };
  app.colorRamp = app.colorSchemes['紫～緑'];
  app.VIS_OPTIONS2 = {
    'NDVI': {
      description: '正規化植生指数\n' +
        'NDVI=(NIR-RED)/(NIR+RED)',
      visParams: {
        'bands': ['NDVI'],
        'min': 0.2,'max':0.9,
      },
      visRange: {
        'min': 0.2,'max':0.9,
      }
    },
    'NDVI(High)': {
      description: '正規化植生指数\n' +
        'NDVI=(NIR-RED)/(NIR+RED)',
      visParams: {
        'bands': ['NDVI'],
        'min': 0.4,'max':0.9,
      },
      visRange: {
        'min': 0.3,'max':0.9,
      }
    },
    'NDVI(Mid)': {
      description: '正規化植生指数\n' +
        'NDVI=(NIR-RED)/(NIR+RED)',
      visParams: {
        'bands': ['NDVI'],
        'min': 0.3,'max':0.6,
      },
      visRange: {
        'min': 0.2,'max':0.6,
      }
    },
    'NDVI(Low)': {
      description: '正規化植生指数\n' +
        'NDVI=(NIR-RED)/(NIR+RED)',
      visParams: {
        'bands': ['NDVI'],
        'min': 0.15,'max':0.4,
      },
      visRange: {
        'min': 0.12,'max':0.4,
      }
    },
  }; // End of app.VIS_OPTIONS2.
  // マップ画面にクレジットを表示
  app.creditPanel = ui.Panel({
    widgets: [
      ui.Label(
        '© JAXA ALOS Orthorectified Image Product (ALOS-ORI)',
        {fontSize: '0.6em'}),
    ],
  });
  app.creditPanel.style().set({
    'position': 'bottom-center',
    'margin': '-2.5em',
    'padding': '0'
  });
  Map.widgets().set(0, app.creditPanel); 
  // チャート表示用パネル
  app.dispChartPanel = ui.Panel({
    style: {
      position: 'bottom-left',
      // width: '600px',
      shown: false
    },
  });
  Map.widgets().set(1, app.dispChartPanel);
  // マップ画面に凡例を表示
  app.dispLegend = function() {
    app.makeColorBarParams = function(palette) {
      return {
        bbox: [0, 0, 1, 0.1],
        dimensions: '100x10',
        format: 'png',
        min: 0,
        max: 1,
        palette: palette,
      };
    };
    app.colorBar = ui.Thumbnail({
      image: ee.Image.pixelLonLat().select(0),
      params: app.makeColorBarParams(app.colorRamp),
      style: {
        stretch: 'horizontal',
        margin: '0 0.3em',
        maxHeight: '1.7em'},
    });
    app.legendLabels = ui.Panel({
      widgets: [
        app.visTmap.legendMin,
        app.visTmap.legendAve,
        app.visTmap.legendMax,
      ],
      layout: ui.Panel.Layout.flow('horizontal')
    });
    app.legendPanel = ui.Panel([
      app.visTmap.legendDate,
      app.visTmap.legendBands,
      app.colorBar,
      app.legendLabels
    ]);
    app.legendPanel.style().set({
      'position': 'bottom-right',
      'padding': '0.2em'
    });
    Map.widgets().set(2, app.legendPanel);
    Map.widgets().get(2).style()
      .set('shown', app.visTmap.checkVI.getValue());
  };　// 凡例表示終了
}; // 初期設定終了
// アプリケーション立ち上げ
app.boot = function() {
  app.initialSetup();
  app.createHelpers();
  app.createPanels();
  app.main = ui.Panel({
    widgets: [
      app.filters.panel,
      app.picker.panel,
      app.vis.panel,
      app.visTmap.panel,
      app.charts.panel
    ],
    style: {width: '13em', padding: '0.4em'}
  });
  app.mainPanelControl();
  ui.root.insert(0, app.main);
};
app.boot();