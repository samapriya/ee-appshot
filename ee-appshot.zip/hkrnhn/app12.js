// S2_SimpleApp
// Sentinel-2画像表示シンプル版
var app = {}; //空のオブジェクト生成
// UIパネル作成開始
app.createPanels = function() {
  // 検索条件設定パネル
  app.filters = {
    closeButton: ui.Button({ // パネルを隠す
      label: '＜＜',
      style: {margin: '0.2em'},
    }),
    geoButton: ui.Button({
      label: '現在地',
      onClick: function() {
        ui.util.getCurrentPosition(
          function(position) {Map.centerObject(position,14);}
        );
      },
      style: app.WIDGETS_STYLE,
    }),
    selectYear: ui.Select({ // 検索開始年選択
      items: app.yearList,
      value: app.startYear,
      placeholder: '年選択',
      style: app.WIDGETS_STYLE,
    }),
    selectMonth: ui.Select({ // 検索開始月選択
      items: app.monthList,
      value: app.startMonth,
      style: app.WIDGETS_STYLE,
    }),
    applyButton: ui.Button({ // 検索実行ボタン
      label: '検索実行',
      onClick: app.applyFilters,
      style: {
        stretch: 'horizontal',
        margin: '0.2em',
        fontSize: '0.8em',
        border: '1px solid black'
      },
    }),
    loadingLabel: ui.Label({
      value: 'Loading...',
      style: {stretch: 'vertical', color: 'gray', shown: false}
    })
  };
  app.filters.panel = ui.Panel({
    widgets: [
      app.filters.closeButton,
      ui.Label('Sentinel-2画像', app.HEADER_TEXT_STYLE),
      ui.Label('1. 画像検索', app.HEADER_TEXT_STYLE),
      app.filters.geoButton,
      ui.Label('開始年・月', app.HELPER_TEXT_STYLE), 
      app.filters.selectYear,
      app.filters.selectMonth,
      ui.Panel([
        app.filters.applyButton,
        app.filters.loadingLabel
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    style: app.SECTION_STYLE
  });
  // 観測日選択パネル
  app.picker = {
    select: ui.Select({
      placeholder: '検索待ち',
      onChange: function(key) {
        app.imageDateStr = key;
        app.refreshMapLayer0();
        app.refreshMapLayer1();
        },
      style: app.WIDGETS_STYLE,
    }),
  };
  app.picker.panel = ui.Panel({
    widgets: [
      ui.Label('2. 画像表示', app.HEADER_TEXT_STYLE),
      ui.Label('観測日を選択', app.HELPER_TEXT_STYLE),
      app.picker.select,
    ],
    style: app.SECTION_STYLE
  });
  // 画像表示パネル1
  app.vis = {
    checkColorComp: ui.Checkbox({ // 表示ON/OFF
      value:true,
      onChange: function(checked) {
        Map.layers().get(0).setShown(checked);},
      style: {margin: '0.2em'},
    }),
    select: ui.Select({ // カラー合成の選択
      items: Object.keys(app.VIS_OPTIONS),
      value: Object.keys(app.VIS_OPTIONS)[0],
      onChange: app.refreshMapLayer0,
      style: app.WIDGETS_STYLE,
    }),
    setVisButton: ui.Button({ // コントラスト調整
      label: '調整',
      onClick: app.setVisMinMax,
      style: app.WIDGETS_STYLE,
    }),
  };
  app.vis.panel = ui.Panel({
    widgets: [
      ui.Panel([
        app.vis.checkColorComp,
        ui.Label('カラー合成', app.SUBHEADER_TEXT_STYLE),
      ], ui.Panel.Layout.flow('horizontal')),
      app.vis.select,
      app.vis.setVisButton,
    ],
    style: app.SECTION_STYLE
  });
  // 画像表示パネル2
  app.visTmap = {
    checkVI: ui.Checkbox({ // レイヤ表示ON/OFF
      value:false,
      onChange: function(checked) {
        Map.layers().get(1).setShown(checked);
        app.legend.panel.style().set('shown', checked);
      },
      style: {margin: '0.2em'},
    }),
    select: ui.Select({ // 植生指数の選択
      items: Object.keys(app.VIS_OPTIONS2),
      value: Object.keys(app.VIS_OPTIONS2)[0],
      onChange: app.refreshMapLayer1,
      style: app.WIDGETS_STYLE,
    }),
    setVisTmapButton: ui.Button({
      label: '調整', // コントラスト自動調整
      onClick: app.setVisTmapMinMax,
      style: app.WIDGETS_STYLE,
    }),
  };
  app.visTmap.panel = ui.Panel({
    widgets: [
      ui.Panel([
        app.visTmap.checkVI,
        ui.Label('植生指数', app.SUBHEADER_TEXT_STYLE),
      ], ui.Panel.Layout.flow('horizontal')),
      app.visTmap.select,
      app.visTmap.setVisTmapButton,
    ],
    style: app.SECTION_STYLE
  });
  // データパネル
  app.data = {
    dispDataButton: ui.Button({
      label: '表示',
      onClick: function() {
        app.setLoadingMode2(true);
        app.dispMarkerData();
      },
      style: app.WIDGETS_STYLE,
    }),
    loadingLabel2: ui.Label({
      value: 'Loading...',
      style: {shown: false}
    }),
  };
  app.data.panel = ui.Panel({
    widgets: [
      ui.Label('3. 地点データ', app.HEADER_TEXT_STYLE),
      ui.Panel([
        app.data.dispDataButton,
        app.data.loadingLabel2,
      ], ui.Panel.Layout.flow('horizontal')),
      ui.Label('Credit', app.SUBHEADER_TEXT_STYLE),
      ui.Label(
        'Contains modified Copernicus Sentinel data ('
        + app.thisYear + ')',
        {margin: '0.2em', fontSize: '0.6em'})
    ],
    style: app.SECTION_STYLE
  });
  // メインパネルの再表示ボタン
  app.openButton = ui.Button({
    label: '＞＞',
    style: {
      position: 'top-left',
      margin: '-3em',
      padding: 0},
    onClick: function() {
      app.openButton.style().set('shown', false);
      app.main.style().set('shown', true);
      Map.setControlVisibility({
        mapTypeControl: true
      });
    }
  });
  // マップ画面に再表示ボタンをセット
  Map.widgets().set(0, app.openButton);
  app.openButton.style().set('shown', false);
  // 植生指数凡例パネルの設定
  app.legend = {
    date: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    bands: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    colorBar: app.setColorBar(app.colorRamp),
    min: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    ave: ui.Label({
    style: {
      fontSize: '0.85em',
      margin: '0.1em 0 0 0.3em',
      textAlign: 'center',
      stretch: 'horizontal'}
    }),
    max: ui.Label({style: app.LEGEND_TEXT_STYLE}),
  };
  app.legend.panel = ui.Panel({
    widgets: [
      app.legend.date,
      app.legend.bands,
      app.legend.colorBar,
      ui.Panel([
        app.legend.min,
        app.legend.ave,
        app.legend.max,
      ], ui.Panel.Layout.flow('horizontal')),
    ],
    style: {
      position: 'bottom-right',
      padding: '0.2em',
      shown: false,
    }
  });
  // マップ画面に凡例パネルをセット
  Map.widgets().set(1, app.legend.panel);
  // データ表示用パネル
  app.dispData = {
    refreshButton: ui.Button({
      label: '更新',
      onClick: app.dispMarkerData,
        style: app.WIDGETS_STYLE,
    }),
    closeButton: ui.Button({
      label: '閉じる',
      onClick: function() {
        app.dispData.panel.style().set('shown', false);
      },
      style: app.WIDGETS_STYLE,
    }),
    dateLabel: ui.Label({style:app.LEGEND_TEXT_STYLE}),
    NDVI_Label: ui.Label({style:app.LEGEND_TEXT_STYLE}),
    GNDVI_Label: ui.Label({style:app.LEGEND_TEXT_STYLE}),
    NDRE_Label: ui.Label({style:app.LEGEND_TEXT_STYLE}),
    EVI2_Label: ui.Label({style:app.LEGEND_TEXT_STYLE}),
    dlLabelJSON: ui.Label('GeoJSON', app.LEGEND_TEXT_STYLE),
  };
  app.dispData.panel = ui.Panel({
    widgets: [
      app.dispData.dateLabel,
      app.dispData.NDVI_Label,
      app.dispData.GNDVI_Label,
      app.dispData.NDRE_Label,
      app.dispData.EVI2_Label,
      app.dispData.dlLabelJSON,
      ui.Panel([
        app.dispData.refreshButton,
        app.dispData.closeButton,
      ], ui.Panel.Layout.flow('horizontal')),
    ],
    style: {
      position: 'bottom-left',
      margin: '0.2em 0 0 0',
      shown: false
    },
  });
  // マップ画面にデータ表示用パネルをセット
  Map.widgets().set(2, app.dispData.panel);
};
// UIパネル作成終了
// 画像検索設定
app.createHelpers = function() {
  // 検索実行中の表示
  app.setLoadingMode = function(enabled) {
    app.filters.loadingLabel.style().set('shown', enabled);
  };
  // 画像検索実行
  app.applyFilters = function() {
    app.setLoadingMode(true);
    // 検索開始日の設定
    var startY = app.filters.selectYear.getValue();
    var startM = app.filters.selectMonth.getValue();
    var startD = ee.Date(startY + '-' + startM + '-01');
    // 画像コレクションを絞り込み
    var filtered = app.imgCollection
          .filterBounds(Map.getCenter())
          .filterDate(startD, startD.advance(8, 'month'))
          .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',
            app.cloudCover))
          .sort('system:time_start')
          .limit(app.IMAGE_COUNT_LIMIT);
    // 検索条件を満たす観測日リストを出力
    var computeDates = 
      ee.List(filtered.aggregate_array('system:time_start'))
        .map(function(d) { return ee.Date(d).format('YYYY-MM-dd')})
        .distinct() // 重複日付を除去
        .slice(0, app.IMAGE_LIST_LIMIT); // リスト先頭から指定件数を得る
    computeDates.evaluate(function(ids) {
      app.setLoadingMode(false);
      if(ids.length) { // リストが空でなければ
        app.picker.select.items().reset(ids); // セレクタリスト更新
        // セレクタにリスト先頭の日付をセット
        app.picker.select.setValue(ids[0]);
      }
    });
  };
};　// 画像検索設定終了
// 初期設定
app.initialSetup = function() {
  // メインパネルの表示切り替え関数
  app.mainPanelControl = function() {
    app.filters.closeButton.onClick(function() {
      app.main.style().set('shown', false);
      app.openButton.style().set('shown', true);
      Map.setControlVisibility({
        mapTypeControl: false
      });
    });
  };
  //衛星データセット
  app.imgCollection = 
    ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED');
  // Sentinel-2雲識別スコア
  app.csPlus =  
    ee.ImageCollection('GOOGLE/CLOUD_SCORE_PLUS/V1/S2_HARMONIZED');
  // 検索開始年・月初期値設定（現在から2ヶ月前）
  app.today = new Date();
  app.startDate = new Date(app.today.setMonth(app.today.getMonth() - 2));
  app.startYear = app.startDate.getFullYear().toFixed();
  app.startMonth = ("00" + (app.startDate.getMonth() + 1)).slice(-2);
  // 月リスト
  app.monthList = ['01','02','03','04','05','06','07','08','09','10','11','12'];
  // 観測開始から現在までの年次リスト発生
  app.thisYear = app.today.getFullYear();
  var serialNumber = function(start, end) {
    var result = [];
    var i = start;
    while (i <= end) result.push((i++).toFixed(0));
    return result;
  };
  app.yearList = serialNumber(2018, app.thisYear);
  // 検索画像数・検索結果リストの上限数
  app.IMAGE_COUNT_LIMIT = 60; 
  app.IMAGE_LIST_LIMIT = 20;
  app.cloudCover = 50; // 画像検索の雲量上限
  // マップ初期設定
  Map.clear();
  Map.drawingTools().setShown(false);
  Map.drawingTools().setLinked(false);
  Map.setControlVisibility({layerList: false, fullscreenControl: false});
  // URLからマップ中心座標取得
  var urlLon = ui.url.get('lon', 142.506); // URLから経度取得
  var urlLat = ui.url.get('lat', 43.566); // URLから緯度取得
  var urlZoom = ui.url.get('zoom', 7); // URLからZoom倍率取得
  Map.setCenter(urlLon, urlLat, urlZoom);
  // マップ中心にマーカーセット
  app.setMarker = function() {
    var mapCenter = Map.getCenter();
    var marker = ui.Map.GeometryLayer({
      geometries: [mapCenter],
      color:'magenta'
    });
    Map.drawingTools().layers().set(0, marker);
    // URLにマップ中心座標セット
    var zoom = Map.getZoom();
    var centerCoords = mapCenter.coordinates();
    centerCoords.evaluate(function(coords) {
      var centerLon = coords[0].toFixed(6);
      var centerLat = coords[1].toFixed(6);
      var urlDic = {lon:centerLon, lat:centerLat, zoom:zoom};
      ui.url.set(urlDic);
    });
  };
  Map.onChangeBounds(ui.util.debounce(function() {
    app.setMarker();
  }, 200));
  // マップレイヤー設定
  Map.setOptions('TERRAIN'); // 地形表示
  Map.layers().set(0, ui.Map.Layer({name:'カラー合成画像', shown: false}));
  Map.layers().set(1, ui.Map.Layer({name:'植生指数', shown: false}));
  Map.layers().set(2, ui.Map.Layer({name:'aoi', shown: false}));
  // スタイル設定
  app.SECTION_STYLE = {margin: '0.2em 0 0 0'};
  app.WIDGETS_STYLE = {
    stretch: 'horizontal',
    margin: '0.2em',
    fontSize: '0.75em',
  };
  app.SLIDER_STYLE = {
    stretch: 'horizontal',
    margin: '0.2em 0 0.2em 0.2em',
    fontSize: '0.75em',
  };
  app.HEADER_TEXT_STYLE = {
      margin: '0',
      fontSize: '0.9em',
      fontWeight: 'bold'
  };
  app.SUBHEADER_TEXT_STYLE = {
      margin: '0',
      fontSize: '0.8em',
      fontWeight: 'bold'
  };
  app.HELPER_TEXT_STYLE = {
      margin: '0 0 0 2em',
      fontSize: '0.75em',
      whiteSpace: 'pre-wrap',
  };
  app.LEGEND_TEXT_STYLE = {
      margin: '0.1em 0 0 0.5em',
      fontSize: '0.85em',
  };
  // カラー合成画像の表示オプション
  app.VIS_OPTIONS = {
    'トゥルーカラー(B4/B3/B2)': {
      description: 'TrueColor',
      visParams: {
        gamma: 1.3,
        min: 0.02,
        max: 0.18,
        bands: ['B4', 'B3', 'B2']
      }
    },
    'フォールスカラー(B11/B8/B4)': {
      description: 'FalseColor',
      visParams: {
        gamma: 1.3,
        min: [0.028, 0.085, 0.032],
        max: [0.239, 0.399, 0.121],
        bands: ['B11', 'B8', 'B4']
      }
    },
  };
  // 植生指数バンドの計算
  app.calcNDVI = function(image) {
    var ndvi = image.normalizedDifference(['B8', 'B4'])
          .rename('NDVI');
    return ndvi;
  };
  app.calcGNDVI = function(image) {
    var gndvi = image.normalizedDifference(['B8', 'B3'])
          .rename('GNDVI');
    return gndvi;
  };
  app.calcNDRE = function(image) {
    var ndre = image.normalizedDifference(['B8', 'B5'])
          .rename('NDRE');
    return ndre;
  };
  app.calcEVI2 = function(image) {
    var evi2 = image.expression(
      '2.5 * ((NIR - RED) / (NIR + 2.4 * RED + 1))', {
      'NIR': image.select('B8'),
      'RED': image.select('B4'),
      }).rename('EVI2');
    return evi2;
  };
  // 画像への植生指数付加、スケール変換、リサンプル
  app.ScaleResample = function(image) {
    var scaledBands = image.select('B[2-8]', 'B8A', 'B11', 'B12')
      .divide(10000);
    var ndvi = app.calcNDVI(scaledBands);
    var gndvi = app.calcGNDVI(scaledBands);
    var ndre = app.calcNDRE(scaledBands);
    var evi2 = app.calcEVI2(scaledBands);
    return image.select('cs','cs_cdf')
      .addBands(scaledBands)
      .addBands(ndvi).addBands(gndvi)
      .addBands(ndre).addBands(evi2)
      .resample('bilinear');
  };
  // 植生指数レイヤのカラーパレット
  // 出典 https://colorbrewer2.org/#type=diverging&scheme=BrBG&n=7
  app.colorRamp = [
    '#8c510a','#d8b365','#f6e8c3','#f5f5f5','#c7eae5','#5ab4ac','#01665e'
    ];
  // 植生指数表示設定
  app.VIS_OPTIONS2 = {
    'NDVI': {
      description: 'NDVI=(NIR-RED)/(NIR+RED)',
      visParams: {
        'bands': ['NDVI'],
        'min': 0.2,'max':1.0,
      },
    },
    'GNDVI': {
      description: 'GNDVI=(NIR-GREEN)/(NIR+GREEN)',
      visParams: {
        'bands': ['GNDVI'],
        'min': 0.2,'max':0.9,
      },
    },
    'NDRE': {
      description: 'NDRE=(NIR-RedEdge1)/(NIR+RedEdge1)',
      visParams: {
        'bands': ['NDRE'],
        'min': 0.2,'max':0.9,
      },
    },
    'EVI2': {
      description: 'EVI2=2.5*(NIR-RED)/(NIR+2.4*RED+1)',
      visParams: {
        'bands': ['EVI2'],
        'min': 0.2,'max': 0.9,
      },
    },
  }; // End of app.VIS_OPTIONS2.
  // 凡例用カラーバー作成
  app.setColorBar = function(palette) {
    var colorBar = ui.Thumbnail({
      image: ee.Image.pixelLonLat().select(0),
      params:{
        bbox: [0, 0, 1, 0.1],
        dimensions: '100x10',
        format: 'png',
        min: 0,
        max: 1,
        palette: palette,
      },
      style: {
        stretch: 'horizontal',
        margin: '0.05em 0.3em',
        maxHeight: '0.8em',
      },
    });
    return colorBar;
  };
  // 植生指数凡例のテキスト更新
  app.setLegendText = function(bands, min, max) {
    app.legend.date.setValue(app.imageDateStr);
    app.legend.bands.setValue(bands);
    var visMin = Math.round(Math.max(min, 0) * 100) / 100;
    var visMax = Math.round(max * 100) / 100;
    var visAve = Math.round((min + max) * 100 / 2) / 100;
    app.legend.min.setValue(visMin);
    app.legend.max.setValue(visMax);
    app.legend.ave.setValue(visAve);
  };
  // モザイク画像、雲・影除去画像の生成
  app.imgMosaic = function() {
    var imgDate = ee.Date(app.imageDateStr);
    var dateRange = ee.DateRange(imgDate, imgDate.advance(1, 'day'));
    app.mosaicimg = app.imgCollection
      .filterDate(dateRange)
      .linkCollection(app.csPlus,['cs','cs_cdf']) // CLOUD_SCOREをリンク
      .map(app.ScaleResample) // スケーリング・植生指数付加
      .mean(); // 平均化して単一画像にモザイク
    // 雲・影除去画像の生成：THRESHOLDが大きいほど薄い雲まで除去
    var CS_THRESHOLD = 0.65;
    var CS_CDF_THRESHOLD = 0.65;
    var cloudMask = app.mosaicimg.select('cs').gte(CS_THRESHOLD) 
      .and(app.mosaicimg.select('cs_cdf').gte(CS_CDF_THRESHOLD));
    app.cloudlessImg = app.mosaicimg.updateMask(cloudMask);
  };
  // カラー合成画像の表示
  app.refreshMapLayer0 = function() {
    // if (app.imageDateStr) {
      app.imgMosaic(); // モザイク画像生成
      var visParams = app.VIS_OPTIONS[app.vis.select.getValue()].visParams;
      var imgNam = 'Img:' + app.imageDateStr;
      var imgCheck = app.vis.checkColorComp.getValue();
      var colorComposit = ui.Map.Layer(app.mosaicimg, visParams, imgNam, imgCheck);
      Map.layers().set(0, colorComposit);
    // }
  };
  // 植生指数レイヤの表示
  app.refreshMapLayer1 = function() {
    // if (app.cloudlessImg) {
      var option = app.VIS_OPTIONS2[app.visTmap.select.getValue()];
      // 植生指数凡例のテキスト更新
      var bands = option.visParams.bands;
      var visMin = option.visParams.min;
      var visMax = option.visParams.max;
      app.setLegendText(bands, visMin, visMax);
      // 植生指数画像の表示
      option.visParams.palette = app.colorRamp;
      var imgNam = bands + ':' + app.imageDateStr;
      var imgCheck = app.visTmap.checkVI.getValue();
      var VImap = ui.Map.Layer(app.cloudlessImg, option.visParams, imgNam, imgCheck);
      Map.layers().set(1, VImap);
    // }
  };
  // 画像のパーセンタイル取得
  app.imgPercentile = function(img, bands, pList) {
    var bounds = ee.Geometry.Rectangle(Map.getBounds());
    var scale = Math.round(Map.getScale() * 10);
    var stats = img // 対象画像
      .select(bands) // バンドリスト
      .reduceRegion({
        reducer: ee.Reducer.percentile(pList), // パーセンタイルリスト
        geometry: bounds,
        scale: scale,
        bestEffort: true,
      });
    return stats;
  };
  // カラー合成画像の明るさ自動調整
  app.setVisMinMax = function() {
    var img = app.cloudlessImg;
    var currentVisParams = Map.layers().get(0).getVisParams();
    var bands = currentVisParams.bands;
    var pList = [1,99]; // パーセンタイルリスト
    var bandsPmin = bands.map(function(band){return band + '_p1';});
    var bandsPmax = bands.map(function(band){return band + '_p99';});
    var imgStats = app.imgPercentile(img, bands, pList);
    imgStats.evaluate(function(stats) {
      var bandsMin = bandsPmin.map(function(band){return stats[band];});
      var bandsMax = bandsPmax.map(function(band){return stats[band];});
      if (bands[0] == 'B4'){ // トゥルーカラーはRGBバランスを保持
        currentVisParams.min = Math.min.apply(null, bandsMin);
        currentVisParams.max = Math.max.apply(null, bandsMax);
      } else { // RGB個別ストレッチ
        currentVisParams.min = bandsMin;
        currentVisParams.max = bandsMax;
      }
      Map.layers().get(0).setVisParams(currentVisParams);
    });
  };
  // 主題図レイヤのMinMax自動調整
 app.setVisTmapMinMax = function() {
    var img = app.cloudlessImg;
    var currentVisParams = Map.layers().get(1).getVisParams();
    var bands = currentVisParams.bands;
    var pList = [20,99];
    var imgStats = app.imgPercentile(img, bands, pList);
    imgStats.evaluate(function(stats) {
      var visMin = stats[bands[0] + '_p20'];
      var visMax = stats[bands[0] + '_p99'];
      currentVisParams.min = visMin;
      currentVisParams.max = visMax;
      app.setLegendText(bands, visMin, visMax);
      Map.layers().get(1).setVisParams(currentVisParams);
    });
  };
  // 集計実行中の表示
  app.setLoadingMode2 = function(enabled) {
    app.data.loadingLabel2.style().set('shown', enabled);
  };
  // マーカー地点情報表示関数
  app.dispMarkerData = function() {
    var obsDate = app.picker.select.getValue();
    var setDate = function(feature) {
      return feature.set({date: obsDate});
    };
    // マーカー地点データ取得
    var aoi = Map.drawingTools().layers().get(0).toGeometry();
    var aoiFC = ee.FeatureCollection(aoi);
    aoiFC = aoiFC.map(setDate);
    var sampleFC = (app.cloudlessImg).reduceRegions({
      collection: aoiFC,
      reducer: ee.Reducer.mean(),
      scale: 10,
    });
    // GeoJSONファイル保存用のリンク作成
    var fileNam = 'aoi' + obsDate;
    var dlUrlJSON = sampleFC
      .getDownloadURL({format: 'geojson', filename: fileNam});
    app.dispData.dlLabelJSON.setUrl(dlUrlJSON);
    // データ表示
    var sampleDic = sampleFC.first().toDictionary(['NDVI', 'GNDVI','NDRE','EVI2']);
    sampleDic.evaluate(function(stats) {
      app.setLoadingMode2(false);
      var NDVIstr = '●NDVI: ' + (Math.round(stats.NDVI * 1000) / 1000);
      var GNDVIstr = '●GNDVI: ' + (Math.round(stats.GNDVI * 1000) / 1000);
      var NDREstr = '●NDRE: ' + (Math.round(stats.NDRE * 1000) / 1000);
      var EVI2str = '●EVI2: ' + (Math.round(stats.EVI2 * 1000) / 1000);
      app.dispData.dateLabel.setValue(obsDate);
      app.dispData.NDVI_Label.setValue(NDVIstr);
      app.dispData.GNDVI_Label.setValue(GNDVIstr);
      app.dispData.NDRE_Label.setValue(NDREstr);
      app.dispData.EVI2_Label.setValue(EVI2str);
      app.dispData.panel.style().set('shown', true);
    });
  }; // マーカー地点情報表示終了
}; // 初期設定終了
// アプリケーション立ち上げ
app.boot = function() {
  app.initialSetup();
  app.createHelpers();
  app.createPanels();
  app.main = ui.Panel({
    widgets: [
      app.filters.panel,
      app.picker.panel,
      app.vis.panel,
      app.visTmap.panel,
      app.data.panel,
    ],
    style: {width: '8em', padding: '0.2em'}
  });
  ui.root.insert(0, app.main);
  app.mainPanelControl();
};
app.boot();