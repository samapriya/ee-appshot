// Sentinel-1_app
var app = {}; //空のオブジェクト生成
// UIパネル作成開始
app.createPanels = function() {
  // 検索条件指定パネル
  app.filters = {
    closeButton: ui.Button({
      label: '閉じる',
      style: {margin: '0 0 0 6em'},
    }),
    sArea: ui.Select({
      items: Object.keys(app.places),
      placeholder: '地域選択',
      onChange: function(key) {
        Map.setCenter(app.places[key][0], app.places[key][1], 10);
      },
      style: {stretch: 'horizontal'},
    }),
    geoButton: ui.Button({
      label: '現在地',
      onClick: function() {
        ui.util.getCurrentPosition(
          function(position) {
            Map.centerObject(position,14);
          }
        );
      }
    }),
    selectYear: ui.Select({
      style: {stretch: 'horizontal'},
    }),
    selectMonth: ui.Select(),
    sOrbit: ui.Select({
      items: Object.keys(app.orbitPass),
      placeholder: '軌道進行方向',
      onChange: function(key) {
        app.orbitDirection = app.orbitPass[key];
      },
      style: {stretch: 'horizontal'},
    }),
    applyButton: ui.Button({
      label: '検索実行',
      onClick: app.applyFilters,
      style: {stretch: 'horizontal'},
    }),
    loadingLabel: ui.Label({
      value: 'Loading...',
      style: {stretch: 'vertical', color: 'gray', shown: false}
    })
  };
  app.filters.panel = ui.Panel({
    widgets: [
      app.filters.closeButton,
      ui.Label({
        value: 'Sentinel-1 SAR画像',
        style: {
          fontWeight: 'bold',
          fontSize: '1em',
          margin: '0.4em 0'},
      }),
      ui.Label('1. 検索条件', app.HEADER_TEXT_STYLE),
      ui.Panel([
        app.filters.sArea,
        app.filters.geoButton
      ], ui.Panel.Layout.flow('horizontal')),
      ui.Label('開始年・月', app.HELPER_TEXT_STYLE), 
      ui.Panel([
        app.filters.selectYear,
        app.filters.selectMonth
      ], ui.Panel.Layout.flow('horizontal')),
      app.filters.sOrbit,
      ui.Panel([
        app.filters.applyButton,
        app.filters.loadingLabel
      ], ui.Panel.Layout.flow('horizontal'))
    ],
    style: app.SECTION_STYLE
  });
  // 検索開始年・月リストのセット
  app.yearList.evaluate(function(ids){
    app.filters.selectYear.items().reset(ids);
    app.filters.selectYear.setValue(app.startYear);
  });
  app.monthList.evaluate(function(ids){
    app.filters.selectMonth.items().reset(ids);
    app.filters.selectMonth.setValue(app.startMonth);
  });
  // 検索結果撮影日のセレクタ
  app.picker = {
    select: ui.Select({
      placeholder: '検索待ち',
      onChange: app.refreshMapLayer,
      style: {stretch: 'horizontal'},
    }),
  };
  app.picker.panel = ui.Panel({
    widgets: [
      ui.Label('2. 撮影日を選択', app.HEADER_TEXT_STYLE),
      app.picker.select,
    ],
    style: app.SECTION_STYLE
  });
  // 主題図レイヤの表示設定
  app.visTmap = {
    checkVI: ui.Checkbox({ // レイヤ表示ON/OFF
      value:true,
      onChange: function(checked) {
        Map.layers().get(0).setShown(checked);
        Map.widgets().get(2).style().set('shown', checked);
      },
      style: {fontSize: '0.85em'}
    }),
    // 凡例用ラベル
    legendDate: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    legendBands: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    legendMin: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    legendMax: ui.Label({style: app.LEGEND_TEXT_STYLE}),
    legendAve: ui.Label({
      style: {
        fontSize: '0.85em',
        margin: '0 0 0 0.3em',
        textAlign: 'center',
        stretch: 'horizontal'}
    }),
    select: ui.Select({ // 偏波の選択
      items: Object.keys(app.VIS_OPTIONS2),
      onChange: function(key) {
        var option2 = app.VIS_OPTIONS2[key];
        app.visTmap.label.setValue(option2.description);
        app.visTmap.legendBands.setValue(option2.visParams.bands);
        var visMin = option2.visParams.min;
        var visMax = option2.visParams.max;
        var visAve = Math.round((visMin + visMax) * 100 / 2) / 100;
        app.visTmap.legendMin.setValue(visMin);
        app.visTmap.legendMax.setValue(visMax);
        app.visTmap.legendAve.setValue(visAve);
        app.refreshMapLayer();
      },
      style: {stretch: 'horizontal', margin: '0 0.5em 0 -0.3em'},
    }),
    label: ui.Label({style: {fontSize: '0.75em', whiteSpace: 'pre-wrap'}}),
    checkFude: ui.Checkbox({
      label: '農地のみ表示',
      onChange: app.refreshMapLayer,
      style: {fontSize: '0.85em'}
    }),
    checkAdBounds: ui.Checkbox({ // 市町村界描画
      label: '町村界',
      onChange: function(checked) {
        Map.layers().get(1).setShown(checked);
      },
      style: {fontSize: '0.85em'}
    }),
    checkFudeBounds: ui.Checkbox({ // 筆ポリゴン描画
      label: '筆ポリゴン',
      onChange: function(checked) {
        if (checked) {
          Map.setLocked(false, 13);
        } else {
          Map.setLocked(false);
        }
        Map.layers().get(2).setShown(checked);
      },
      style: {fontSize: '0.85em'}
    }),
    selectColorScheme: ui.Select({
      items: Object.keys(app.colorSchemes),
      placeholder: 'レイヤ配色の変更',
      onChange: function(key) {
        app.colorRamp = app.colorSchemes[key];
        var optionTmap = app.VIS_OPTIONS2[app.visTmap.select.getValue()];
        var visParamsTmap = optionTmap.visParams;
        visParamsTmap.palette = app.colorRamp;
        Map.layers().get(0).setVisParams(visParamsTmap);
        app.legendLabels.clear();
        app.legendPanel.clear();
        app.dispLegend();
      },
      style: {stretch: 'horizontal'},
    }),
  };
  app.visTmap.panel = ui.Panel({
    widgets: [
      ui.Label('3. 画像表示', app.HEADER_TEXT_STYLE),
      ui.Panel([
        app.visTmap.checkVI,
        app.visTmap.select
      ], ui.Panel.Layout.flow('horizontal')),
      app.visTmap.label,
      app.visTmap.checkFude,
      ui.Panel([
        app.visTmap.checkAdBounds,
        app.visTmap.checkFudeBounds,
      ], ui.Panel.Layout.flow('horizontal')),
      app.visTmap.selectColorScheme,
    ],
    style: app.SECTION_STYLE
  });
  // 偏波選択の初期値
  app.visTmap.select.setValue(app.visTmap.select.items().get(0));
  // 凡例を表示
  app.dispLegend();
  // チャート用パネル
  app.charts = {
    setDrawingButton: ui.Button({
      label: '領域設定',
      onClick: app.setDrawingTools,
      style: {stretch: 'horizontal'},
    }),
    clearDrawingButton: ui.Button({
      label: 'クリア',
      onClick: function(){
        Map.drawingTools().clear();
        Map.drawingTools().setShown(false);
        Map.setControlVisibility({
          layerList: true,
          mapTypeControl: true
        });
        app.dispChartPanel.clear();
        app.dispChartPanel.style().set('shown', false);
      },
    }),
    drawChartButton: ui.Button({
      label: 'チャート作成',
      onClick: app.drawChart,
      style: {stretch: 'horizontal'},
    }),
  };
  app.charts.panel = ui.Panel({
    widgets: [
      ui.Label('4. 時系列チャート', app.HEADER_TEXT_STYLE),
      ui.Panel([
        app.charts.setDrawingButton,
        app.charts.clearDrawingButton,
      ], ui.Panel.Layout.flow('horizontal')),
      app.charts.drawChartButton,
    ],
    style: app.SECTION_STYLE
  });
}; 
// UIパネル作成終了
// 補助機能設定
app.createHelpers = function() {
  // 検索実行に合わせて入力ウィジエットを無効化・有効化
  app.setLoadingMode = function(enabled) {
    app.filters.loadingLabel.style().set('shown', enabled);
    var loadDependentWidgets = [
　　　app.filters.sArea,
      app.filters.geoButton,
      app.filters.selectYear,
      app.filters.selectMonth,
      app.filters.sOrbit,
      app.filters.applyButton,
      app.picker.select,
    ];
    loadDependentWidgets.forEach(function(widget) {
      widget.setDisabled(enabled);
    });
  };
  // 指定条件による検索実行
  app.applyFilters = function() {
    app.setLoadingMode(true);
    var startY = app.filters.selectYear.getValue();
    var startM = app.filters.selectMonth.getValue();
    var startD = ee.Date(startY + '-' + startM + '-01');
    var filtered = app.imgCollection
          .filter(ee.Filter.eq('orbitProperties_pass', app.orbitDirection))
          .filterBounds(Map.getCenter())
          .filterDate(startD, startD.advance(1, 'year'))
          .sort('system:time_start')
          .limit(app.IMAGE_COUNT_LIMIT);
    // 検索条件を満たす撮影日リストを出力
    var computeDates = 
      ee.List(filtered.aggregate_array('system:time_start'))
      .map(function(d) { return ee.Date(d).format('YYYY-MM-dd')})
      .distinct() // 重複日付を除去
      .slice(0, app.IMAGE_LIST_LIMIT); // リスト先頭から指定件数を得る
    computeDates.evaluate(function(ids) {
      app.setLoadingMode(false);
      app.picker.select.items().reset(ids); // セレクタリスト更新
      // セレクタにリスト先頭の日付をセット
      app.picker.select.setValue(app.picker.select.items().get(0));
    });
  };
};　// 補助機能設定終了
// マップ画面の更新
app.refreshMapLayer = function() {
  var imageDateStr = app.picker.select.getValue();
  if (imageDateStr) {
    app.visTmap.legendDate.setValue(imageDateStr);
    // 衛星画像の加工とモザイク
    var imgDate = ee.Date(imageDateStr);
    var dateRange = ee.DateRange(imgDate, imgDate.advance(1, 'day'));
    var mosaicimg = app.imgCollection
      .filter(ee.Filter.eq('orbitProperties_pass', app.orbitDirection))
      .filterDate(dateRange)
      .map(app.addBands).mosaic();
    // 主題図レイヤの表示
    var visOption2 = app.VIS_OPTIONS2[app.visTmap.select.getValue()];
    visOption2.visParams.palette = app.colorRamp;
    var imgname = 'Image:' + imageDateStr;
    var imgCheck = app.visTmap.checkVI.getValue();
    // 筆ポリゴン描画時は
    // Zoomスケールを12以上に限定
    var fudeCheck = app.visTmap.checkFude.getValue();
    if (fudeCheck) {
      Map.setLocked(false, 11);
      mosaicimg = mosaicimg.clipToCollection(app.Fudepoly);
    } else {
      Map.setLocked(false);
    }
    var tmap = ui.Map.Layer(mosaicimg, visOption2.visParams, imgname, imgCheck);
    Map.layers().set(0, tmap);
    // 市町村境界の表示
    var adminCheck = app.visTmap.checkAdBounds.getValue();
    var Admin = ui.Map.Layer(app.Admindivline, {palette: '#ffd700'}, 'Admin division', adminCheck);
    Map.layers().set(1, Admin);
    // 筆ポリゴン境界の表示
    var fudeBoundsCheck = app.visTmap.checkFudeBounds.getValue();
    var Fude = ui.Map.Layer(app.Fudeoutline, {palette: '#808080'}, 'Fude polygon', fudeBoundsCheck);
    Map.layers().set(2, Fude);
  }
}; // マップ画面の更新終了
// 時系列チャート描画関数
app.drawChart = ui.util.debounce(function() {
  if (Map.drawingTools().layers().get(0)) {
  var aoi = Map.drawingTools().layers().get(0).toGeometry();
  var aoiCent = aoi.centroid().coordinates().getInfo();
  var lonlat = ('領域重心 E' + aoiCent[0].toFixed(6) + ', N' + aoiCent[1].toFixed(6));
    // 時系列チャート用のイメージコレクション
    var yearS = app.filters.selectYear.getValue();
    var dateStart = ee.Date(yearS + '-03-01');
    var dateEnd = ee.Date(yearS + '-11-30');
    var chartCollection = app.imgCollection
      .filter(ee.Filter.eq('orbitProperties_pass', app.orbitDirection))
      .filterBounds(Map.getCenter())
      .filterDate(dateStart, dateEnd)
      .map(app.addBands);
    // 時系列チャート
    var chart1 = ui.Chart.image.series({
      imageCollection: chartCollection,
      region: aoi,
      reducer: ee.Reducer.mean(),
      scale: 10,
    });
    var chartOptions1 = {
      title: '後方散乱係数推移: ' + app.orbitDirection + ', ' + lonlat,
      vAxes: { // 注意!複数形Axes
        0: {title: 'VV, VH 後方散乱係数(dB)'},
        1: {title: 'VH/VV', baselineColor: 'transparent'}
      },
      hAxis: {title: 'Date', format: 'yyyy-MM-dd'},
      interpolateNulls: true,
      lineWidth: 1,
      pointsVisible: true,
      pointSize: 4,
      series: {
        0: {targetAxisIndex: 0},
        1: {targetAxisIndex: 1},
        2: {targetAxisIndex: 0},
      },
      legend: {position: 'top'},
    };
    chart1.setOptions(chartOptions1);
    // app.charts.panel.widgets().set(3, chart1);
    app.dispChartPanel.style().set('shown', true);
    app.dispChartPanel.widgets().set(0, chart1);
  } // end of if
}, 300); // 時系列チャート描画終了
// メインパネルの表示切り替え
app.mainPanelControl = function() {
  app.filters.closeButton.onClick(function() {
    app.main.style().set('shown', false);
    app.creditPanel.style().set('shown', false);
    app.openButton.style().set('shown', true);
    Map.setControlVisibility({
      layerList: false,
      mapTypeControl: false
    });
  });
  app.openButton = ui.Button({
    label: '設定',
    style: {position: 'top-left', 'padding': 0},
    onClick: function() {
      app.openButton.style().set('shown', false);
      app.main.style().set('shown', true);
      app.creditPanel.style().set('shown', true);
      Map.setControlVisibility({
        layerList: true,
        mapTypeControl: true
      });
    }
  });
  Map.add(app.openButton);
  app.openButton.style().set('shown', false);
};
// 初期設定
app.initialSetup = function() {
  // // マップ画面の初期化
  // Map.clear();
  // Map.drawingTools().setShown(false);
  // // Map.setControlVisibility({fullscreenControl : false});
  // Map.setOptions('SATELLITE');
  // Map.setCenter(142.506, 43.566, 7);
  //衛星データセットの指定
  app.imgCollection = ee.ImageCollection('COPERNICUS/S1_GRD')
  // Filter to get images with VV and VH dual polarization.
  　　.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
  　　.filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
  　　// Filter to get images collected in interferometric wide swath mode.
  　　.filter(ee.Filter.eq('instrumentMode', 'IW'));
  //農水省筆ポリゴン（北海道分） 
  app.Fudepoly = ee.FeatureCollection('users/hkrnhn/fude2021/Hokkaido');
  app.Fudeoutline = ee.Image().byte()
    .paint({
      featureCollection: app.Fudepoly,
      color: 1,
      width: 1
    });
  // 市町村境界（国土数値情報、北海道分）
  app.Admindiv = ee.FeatureCollection('users/hkrnhn/adminHokkaido');
  app.Admindivline = ee.Image().byte()
    .paint({
       featureCollection: app.Admindiv,
       color: 1,
       width: 2
    });
  // マップレイヤー初期設定、市町村境界・筆ポリゴン表示
  Map.clear();
  Map.drawingTools().setShown(false);
  Map.drawingTools().setLinked(false);
  Map.setOptions('SATELLITE');
  var urlLon = ui.url.get('lon', 142.506); // URLから経度取得
  var urlLat = ui.url.get('lat', 43.566); // URLから緯度取得
  var urlZoom = ui.url.get('zoom', 7); // URLからZoom倍率取得
  Map.setCenter(urlLon, urlLat, urlZoom);
  Map.layers().set(0, ui.Map.Layer({shown: false}));
  Map.layers().set(1, ui.Map.Layer({shown: false}));
  var Admin = ui.Map.Layer(app.Admindivline, {palette: '#ffd700'}, 'Admin division', false);
  Map.layers().set(2, Admin);
  var Fude = ui.Map.Layer(app.Fudeoutline, {palette: '#808080'}, 'Fude polygon', false);
  Map.layers().set(3, Fude);
  // マップ中心座標・ズーム倍率をURLに反映
  Map.onChangeCenter(ui.util.debounce(function() {
    var mapCenter = Map.getCenter();
    var centerCoords = mapCenter.coordinates();
    centerCoords.evaluate(function(coords) {
      var centerLon = coords[0].toFixed(6);
      var centerLat = coords[1].toFixed(6);
      ui.url.set('lon', centerLon);
      ui.url.set('lat', centerLat);
    });
  }, 200));
  Map.onChangeZoom(ui.util.debounce(function() {
    var zoom = Map.getZoom();
    ui.url.set('zoom', zoom);
  }, 200));
  // スタイル設定
  app.SECTION_STYLE = {margin: '0'};
  app.HEADER_TEXT_STYLE = {
      margin: '0',
      fontSize: '0.85em',
      fontWeight: 'bold'
  };
  app.HELPER_TEXT_STYLE = {
      margin: '0 0 -0.1em 0.3em',
      fontSize: '0.85em',
      fontWeight: 'bold'
  };
  app.LEGEND_TEXT_STYLE = {
      margin: '0 0 0 0.5em',
      fontSize: '0.85em',
  };
  app.IMAGE_COUNT_LIMIT = 60; // 検索画像数の上限
  app.IMAGE_LIST_LIMIT = 13; // 検索結果リストの上限数
  // app.cloudCover = 50; // 検索条件の雲量初期値
  // 地域リスト
  app.places = {
    '空知': [141.766, 43.197],
    '石狩': [141.345, 43.064],
    '後志': [140.756, 42.902],
    '胆振': [140.971, 42.320],
    '日高': [142.768, 42.172],
    '渡島': [140.753, 41.819],
    '檜山': [140.127, 41.859],
    '上川': [142.439, 43.807],
    '留萌': [141.655, 43.934],
    '宗谷': [141.700, 45.397],
    'オホーツク': [144.260, 44.026],
    '十勝': [143.208, 42.929],
    '釧路': [144.384, 42.976],
    '根室': [145.584, 43.330],
    '実証農場': [143.698787, 43.743359],
  };
  // 検索開始年・月リストの生成
  app.today = new Date();
  app.thisYear = app.today.getFullYear();
  app.startDate = new Date(app.today.setMonth(app.today.getMonth() - 3));
  app.startYear = app.startDate.getFullYear().toFixed();
  app.startMonth = ("00" + (app.startDate.getMonth() + 1)).slice(-2);
  app.yearList = ee.List.sequence({
    start: 2014, // データセットの初年目
    end: app.thisYear,
    step: 1
  })
  .map(function(y) {
    return ee.Number(y).format('%04d');
  });
  app.monthList = ee.List.sequence({
    start: 1,
    end: 12,
    step: 1
  })
  .map(function(m) {
    return ee.Number(m).format('%02d');
  });
  // 軌道進行方向orbitProperties_pass
  app.orbitPass = {
    '北行 Ascending': 'ASCENDING',
    '南行 Descending': 'DESCENDING',
  };
  // バンド比付加
  app.addBands = function(image) {
    var ratioVHVV = image.expression(
      'VH / VV', {
      'VH': image.select('VH'),
      'VV': image.select('VV')
      }).rename('VH/VV');
    return image.select('VH','VV')
       .addBands(ratioVHVV)
       .copyProperties(image, ['system:time_start']);
  };
  // ジオメトリツール起動用関数
  app.setDrawingTools = function() {
    Map.setControlVisibility({
      layerList: false,
      mapTypeControl: false
    });
    Map.drawingTools().clear();
    Map.drawingTools().setShown(true);
    Map.drawingTools().setLinked(false);
    var mapCenter = [Map.getCenter()];
    Map.drawingTools().addLayer({geometries: mapCenter, color:'magenta'});
    Map.drawingTools().setDrawModes(['point', 'line', 'polygon']);
    //Map.drawingTools().draw(); // Enter drawing mode.
  };
  // 主題図レイヤのカラーパレット
  // パレットライブラリ https://github.com/gee-community/ee-palettes
  var palettes = require('users/gena/packages:palettes');
  app.colorSchemes = {
    'グレースケール': ['black','white'],
    '赤～黄～緑':palettes.colorbrewer.RdYlGn[11],
    '茶～青緑':palettes.colorbrewer.BrBG[11],
    '緑（淡～濃）':palettes.colorbrewer.Greens[9],
    '茶～黄':palettes.colorbrewer.YlOrBr[5].reverse(),
    '虹色':palettes.kovesi.rainbow_bgyr_35_85_c73[7],
    '青-水-緑-黄-赤':['#0000cd','#87ceeb','#008000','#ffd700','#dc143c'],
  };
  app.colorRamp = app.colorSchemes['グレースケール'];
  app.VIS_OPTIONS2 = {
    'VV偏波': {
      description: '',
      visParams: {
        'bands': ['VV'],
        'min': -20.0,'max':-5.0,
      }
    },
    'VH偏波': {
      description: '',
      visParams: {
        'bands': ['VH'],
        'min': -25.0,'max':-10.0,
      }
    },
    'VH/VV': {
      description: '',
      visParams: {
        'bands': ['VH/VV'],
        'min': 0.5,'max':2.5,
      }
    }
  }; // End of app.VIS_OPTIONS2.
  // マップ画面にクレジットを表示
  app.creditPanel = ui.Panel({
    widgets: [
      ui.Label(
        'Contains modified Copernicus Sentinel data (2020)',
        {fontSize: '0.6em'}),
    ],
  });
  app.creditPanel.style().set({
    'position': 'bottom-center',
    'margin': '-2.5em',
    'padding': '0'
  });
  Map.widgets().set(0, app.creditPanel); 
  // チャート表示用パネル
  app.dispChartPanel = ui.Panel({
    style: {
      position: 'bottom-left',
      shown: false
    },
  });
  Map.widgets().set(1, app.dispChartPanel);
  // マップ画面に凡例を表示
  app.dispLegend = function() {
    app.makeColorBarParams = function(palette) {
      return {
        bbox: [0, 0, 1, 0.1],
        dimensions: '100x10',
        format: 'png',
        min: 0,
        max: 1,
        palette: palette,
      };
    };
    app.colorBar = ui.Thumbnail({
      image: ee.Image.pixelLonLat().select(0),
      params: app.makeColorBarParams(app.colorRamp),
      style: {
        stretch: 'horizontal',
        margin: '0 0.3em',
        maxHeight: '1.7em'},
    });
    app.legendLabels = ui.Panel({
      widgets: [
        app.visTmap.legendMin,
        app.visTmap.legendAve,
        app.visTmap.legendMax,
      ],
      layout: ui.Panel.Layout.flow('horizontal')
    });
    app.legendPanel = ui.Panel([
      app.visTmap.legendDate,
      app.visTmap.legendBands,
      app.colorBar,
      app.legendLabels
    ]);
    app.legendPanel.style().set({
      'position': 'bottom-right',
      'padding': '0.2em'
    });
    Map.widgets().set(2, app.legendPanel);
    Map.widgets().get(2).style()
      .set('shown', app.visTmap.checkVI.getValue());
  };　// 凡例表示終了
}; // 初期設定終了
// アプリケーション立ち上げ
app.boot = function() {
  app.initialSetup();
  app.createHelpers();
  app.createPanels();
  app.main = ui.Panel({
    widgets: [
      app.filters.panel,
      app.picker.panel,
      // app.vis.panel,
      app.visTmap.panel,
      app.charts.panel
    ],
    style: {width: '13em', padding: '0.4em'}
  });
  app.mainPanelControl();
  ui.root.insert(0, app.main);
};
app.boot();