var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            102.10167863932999,
            14.972331289585437
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #98ff00 */ee.Geometry.Point([102.10167863932999, 14.972331289585437]);
//1. ข้อมูลแผนที่พื้นที่ศึกษาจาก FAO กรองด้วยการใช้พิกัดภูมิศาสตร์ที่ได้จากกุเกิ้ล
var geometry = ee.Geometry.Point([102.10016846408685, 14.972372341131841]); //นครราชสีมา
//กรองพื้นที่จังหวัดด้วยจุดพิกัด geometry
var roi = ee.FeatureCollection('users/6240212101/Municipa') //หากต้องการใช้ขอบเขตอำเภอ ให้ใช้ 2015/level2หรือ uploadfile"zip"
                    .filterBounds(geometry);
print(roi, 'เมืองนครราชสีมา');//กดเข้าไปดูรายละเอียดข้อมูลในแอทริบิวต์ได้ที่ features > properties
Map.addLayer(roi, {},'แผนที่เมืองนครราชสีมา');
Map.centerObject(geometry,9);
//2.สร้างฟังค์ชันในการทำ cloud mask
//สร้างฟังค์ชันในการทำ cloud mask
function maskL8sr(col) {
  // Bits ที่ 3 และ 5 แทนเงาของเมฆและเมฆตามลำดับ
  // Bits 3 and 5 are cloud shadow and cloud, respectively.
  var cloudShadowBitMask = (1 << 3); //กำหนดตัวแปรเงาเมฆ
  var cloudsBitMask = (1 << 5); //กำหนดตัวแปรเมฆ
  // รับค่าจุดภาพที่อยู่ในแบนด์ควบคุมคุณภาพหรือ QA band.
  var qa = col.select('pixel_qa');
  // ค่า flags ของทั้งเงาเมฆและเมฆที่พบใน pixel_qa ที่มีค่าเป็น 0 จะถูกกำหนดให้เป็น mask เพื่อระบุว่าเป็นพื้นที่ทั้งสอง หากไม่ทำขั้นตอนนี้ การคำนวณ LST จะรวมพื้นที่ที่มีเมฆไปด้วย
  var mask = qa.bitwiseAnd(cloudShadowBitMask).eq(0)
                 .and(qa.bitwiseAnd(cloudsBitMask).eq(0));
  return col.updateMask(mask); //ทำการอัพเดท mask เข้าไปใน image collections ที่ใส่ผ่านฟังค์ชันนี้
}
//3.สร้างตัวแปรเพื่อปรับแต่งแผนที่ภาพดาวเทียม
var vizParams = {
bands: ['B4', 'B3', 'B2'], //RGB: จะได้ภาพสีผสมเท็จ
min: 0,
max: 4000,
gamma: [1, 0.9, 1.1]
};
var vizParams2 = {
bands: ['B3', 'B2', 'B1'],//RGB:จะได้ภาพสีผสมจริง
min: 0,
max: 3000,
gamma: 1.4,
};
//4.กรองภาพแลนด์แซท 8 ตามเวลาที่ต้องการ ด้วยการนำมาเก็บใน image collection
 {
var col = ee.ImageCollection('LANDSAT/LT05/C01/T1_SR')
.map(maskL8sr)
.filterDate('2009-04-18','2009-04-19') //ตรงนี้สามารถปรับช่วงเวลาได้ หากต้องการภาพเดียวให้ขยับวันให้ห่างกัน 16 วันตาม revisit time
.filterBounds(roi);
}
print(col, 'collection images');
//กด run ให้ตรวจสอบผลการกรองภาพว่ามีจำนวนภาพกี่ภาพที่ค้นหาได้ตามช่วงเวลาที่ได้ระบุไปด้านบน
//5.ลดขนาดภาพด้วยการหาค่ามัธยฐานของแต่ละจุดภาพใน image collection หรือ median
{
var image = col.median().clip(roi); //ตัดภาพด้วยขอบเขตเมืองนครราชสีมา หากต้องการดูทั้งซีนให้เอา clip ออก
print(image, 'image');
Map.addLayer(image, vizParams2); //เพิ่มแผนที่ภาพผลลัพธ์ลงในชั้นแผนที่
}
// กด run สังเกตว่าผลของข้อนี้จะได้ค่าเฉลี่ยของภาพที่อยู่ใน image collections ที่ต้องการ
// เป็นขั้นตอนลดขนาดข้อมูล
//6.คำนวณดัชนีพืชพรรณ NDVI
{
var ndvi = image.normalizedDifference(['B4', 
'B3']).rename('NDVI');
var ndviParams = {min: -1, max: 1, palette: ['blue', 'white', 
'green']};
print(ndvi,'ndvi');
Map.addLayer(ndvi, ndviParams, 'ndvi');//เพิ่มแผนที่ภาพผลลัพธ์ลงในชั้นแผนที่ชื่อว่า ndvi
}
//7.แสดงภาพในแบนด์ที่ 10 แล้วเพิ่มลงไปในแผนที่ ซึ่งยังไม่มีการคำนวณใดๆ
var thermal= image.select('B6').multiply(0.1);
var b6Params = {min: 291.918, max: 302.382, palette: ['blue', //ค่า min/max สามารถปรับได้ตามภาพของเรา
'white', 'green']};
Map.addLayer(thermal, b6Params, 'thermal');
//กด run ให้สังเกตแผนที่ภาพดาวเทียมว่าตรงไหนที่มีค่าสูงหร
//8.หาค่าต่ำสุดและสูงสุดของดัชนีพืชพรรณ min and max of NDVI
{
var min = ee.Number(ndvi.reduceRegion({
reducer: ee.Reducer.min(),
geometry: roi,
scale: 30,
maxPixels: 1e9
}).values().get(0));
print(min, 'min'); //ปริ้นค่าต่ำสุด
var max = ee.Number(ndvi.reduceRegion({
reducer: ee.Reducer.max(), 
geometry: roi,
scale: 30,
maxPixels: 1e9
}).values().get(0));
print(max, 'max')//ปริ้นค่าสูงสุด
}
//กด run ดูผลลัพธ์ค่าต่ำสุด สูงสุดใน console
//9.คำนวณค่าสัดส่วนพืชพรรณ fractional vegetation
{
var fv =(ndvi.subtract(min).divide(max.subtract(min))).pow(ee.Number(2)).rename('FV'); 
print(fv, 'fv');
Map.addLayer(fv);
}
// กด run ให้สังเกตถึงแผนที่ภาพ fv ว่ามีความสอดคล้องกับพืชพรรณหรือไม่
//10.คำนวณค่าสัมประสิทธิ์การแผ่รังสีความร้อน Emissivity
var a= ee.Number(0.004);
var b= ee.Number(0.986);
var EM=fv.multiply(a).add(b).rename('EMM');
var imageVisParam3 = {min: 0.9865619146722164, max:0.989699971371314};
Map.addLayer(EM, imageVisParam3,'EMM');
//กด run ให้สังเกตถึงแผนที่ภาพ ค่าสูงหรือต่ำอยู่ตรงไหน สอดคล้องกับแผนที่ภาพดาวเทียม ชนิดของสิ่งปก
//11.คำนวณค่า LST ขั้นสุดท้ายด้วยการใช้ข้อมูลแบนด์ 10 ของแลนด์แซทเป็นฐาน
//LST in Celsius Degree bring -273.15
//NB: In Kelvin don't bring -273.15
var LST = thermal.expression( //thermal นี้ได้มาจากด้านบน
'(Tb/(1 + (0.00115* (Tb / 1.438))*log(Ep)))-273.15', {
 'Tb': thermal.select('B6'), // ตัวแปร Tb คือภาพแบนด์ที่ 10
'Ep': EM.select('EMM') // EM ได้จากขั้นตอนคำนวณ Emissitivity
}).rename('LST'); //เปลี่ยนชื่อเป็น LST
Map.addLayer(LST, {min: 20.569706944223423, max:29.328077233404645, palette: [
'040274', '040281', '0502a3', '0502b8', '0502ce', '0502e6',
'0602ff', '235cb1', '307ef3', '269db1', '30c8e2', '32d3ef',
'3be285', '3ff38f', '86e26f', '3ae237', 'b5e22e', 'd6e21f',
'fff705', 'ffd611', 'ffb613', 'ff8b13', 'ff6e08', 'ff500d',
'ff0000', 'de0101', 'c21301', 'a71001', '911003'
 ]},'LST'); // กำหนด palatte ที่ใช้แสดงแผนที่ภาพ LST สามารถปรับแต่งค่า min/max ตามพื้นที่ได้
//กด run ให้สังเกตผลแผนที่ภาพดาวเทียมที่ได้ ว่าค่า LST สูงหรือต่ำอยู่ไหน สอดคล้องกับแผนที่สิ่งปกคลุมดินหรือไม่
 Export.image.toDrive({
  image: LST,
  description: 'LST',
  folder: "image EE",
  scale: 30,
  region: roi,
  fileFormat: 'GeoTIFF',
  formatOptions: {
    cloudOptimized: true
  }
});