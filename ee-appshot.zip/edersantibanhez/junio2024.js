var inra2018 = ui.import && ui.import("inra2018", "table", {
      "id": "users/edersantibanhez/inra"
    }) || ee.FeatureCollection("users/edersantibanhez/inra"),
    PredioSaneados21 = ui.import && ui.import("PredioSaneados21", "table", {
      "id": "users/edersantibanhez/PrediosSaneados21"
    }) || ee.FeatureCollection("users/edersantibanhez/PrediosSaneados21"),
    PrediosProceso21 = ui.import && ui.import("PrediosProceso21", "table", {
      "id": "users/edersantibanhez/PrediosProceso21"
    }) || ee.FeatureCollection("users/edersantibanhez/PrediosProceso21"),
    PrediosProceso20 = ui.import && ui.import("PrediosProceso20", "table", {
      "id": "users/edersantibanhez/PrediosProceso20"
    }) || ee.FeatureCollection("users/edersantibanhez/PrediosProceso20"),
    PrediosControl21 = ui.import && ui.import("PrediosControl21", "table", {
      "id": "users/edersantibanhez/PrediosControl21"
    }) || ee.FeatureCollection("users/edersantibanhez/PrediosControl21"),
    PrediosControl20 = ui.import && ui.import("PrediosControl20", "table", {
      "id": "users/edersantibanhez/PrediosControl20"
    }) || ee.FeatureCollection("users/edersantibanhez/PrediosControl20"),
    plus = ui.import && ui.import("plus", "table", {
      "id": "users/edersantibanhez/plus"
    }) || ee.FeatureCollection("users/edersantibanhez/plus"),
    Paquio = ui.import && ui.import("Paquio", "table", {
      "id": "users/edersantibanhez/paquio"
    }) || ee.FeatureCollection("users/edersantibanhez/paquio"),
    MunicipiosSCz = ui.import && ui.import("MunicipiosSCz", "table", {
      "id": "users/edersantibanhez/MunicipiosSCz"
    }) || ee.FeatureCollection("users/edersantibanhez/MunicipiosSCz"),
    Robore_Reconstruido = ui.import && ui.import("Robore_Reconstruido", "table", {
      "id": "users/edersantibanhez/Robore_Reconstruido"
    }) || ee.FeatureCollection("users/edersantibanhez/Robore_Reconstruido"),
    CuadroRobore = ui.import && ui.import("CuadroRobore", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -60.25029174495404,
                -17.594331056354036
              ],
              [
                -60.25029174495404,
                -18.703534396780697
              ],
              [
                -58.92643920589154,
                -18.703534396780697
              ],
              [
                -58.92643920589154,
                -17.594331056354036
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-60.25029174495404, -17.594331056354036],
          [-60.25029174495404, -18.703534396780697],
          [-58.92643920589154, -18.703534396780697],
          [-58.92643920589154, -17.594331056354036]]], null, false),
    Recorrido = ui.import && ui.import("Recorrido", "geometry", {
      "geometries": [
        {
          "type": "LineString",
          "coordinates": [
            [
              -59.59012185778919,
              -18.332085751094823
            ],
            [
              -59.58763276782337,
              -18.330130346340187
            ],
            [
              -59.586087815430794,
              -18.32866377826472
            ],
            [
              -59.58445703234974,
              -18.32776753609662
            ],
            [
              -59.583341233399544,
              -18.326626857529778
            ],
            [
              -59.580594651368294,
              -18.32621947050434
            ],
            [
              -59.579307191041146,
              -18.324589912808403
            ],
            [
              -59.57724725451771,
              -18.32287886070742
            ],
            [
              -59.57613145556751,
              -18.32067891171299
            ],
            [
              -59.57595979419056,
              -18.31937522503618
            ],
            [
              -59.57338487353626,
              -18.31872337801468
            ],
            [
              -59.57166825976673,
              -18.318478934748605
            ],
            [
              -59.57038079943958,
              -18.31986410869098
            ],
            [
              -59.56754838671986,
              -18.320190030360184
            ],
            [
              -59.56789170947376,
              -18.31888634000024
            ],
            [
              -59.569350831177864,
              -18.31733819494172
            ],
            [
              -59.57003747668568,
              -18.315464106079155
            ],
            [
              -59.566604249146614,
              -18.31530114087126
            ],
            [
              -59.56342851367298,
              -18.316523376190535
            ],
            [
              -59.560081116822396,
              -18.31717523149837
            ],
            [
              -59.55827867236439,
              -18.31562707113363
            ],
            [
              -59.555875413087044,
              -18.316115965376422
            ],
            [
              -59.5534721538097,
              -18.314812244326994
            ],
            [
              -59.55252801623646,
              -18.314730761435356
            ],
            [
              -59.55269967761341,
              -18.313508513458146
            ],
            [
              -59.55596124377552,
              -18.312123288651563
            ],
            [
              -59.554330460694466,
              -18.310575083104247
            ],
            [
              -59.55106889453236,
              -18.310086173213048
            ],
            [
              -59.548579804566536,
              -18.308537949449985
            ],
            [
              -59.54574739184681,
              -18.305848896329877
            ],
            [
              -59.54342996325794,
              -18.302181938424354
            ],
            [
              -59.54119836535755,
              -18.300226195799777
            ],
            [
              -59.537850968506966,
              -18.298025958956508
            ],
            [
              -59.53450357165638,
              -18.295988677707687
            ],
            [
              -59.532615296509896,
              -18.294440327939366
            ],
            [
              -59.52995454516712,
              -18.293380922758786
            ],
            [
              -59.52849542346302,
              -18.289958184842355
            ],
            [
              -59.52755128588978,
              -18.286127897996803
            ],
            [
              -59.52480470385853,
              -18.2839274821792
            ],
            [
              -59.5234314128429,
              -18.281564041496704
            ],
            [
              -59.523088090089,
              -18.27871157019435
            ],
            [
              -59.523088090089,
              -18.276429559378652
            ],
            [
              -59.521371476319466,
              -18.274310522457355
            ],
            [
              -59.52008401599232,
              -18.271050415121316
            ],
            [
              -59.51896821704212,
              -18.268686799004854
            ],
            [
              -59.51828157153431,
              -18.26664917306944
            ],
            [
              -59.54926645007435,
              -18.240402413791458
            ],
            [
              -59.58746110644642,
              -18.213254857657844
            ],
            [
              -59.60248147692982,
              -18.20428626609934
            ],
            [
              -59.61372529712025,
              -18.197029522287465
            ],
            [
              -59.62368165698353,
              -18.18846780682386
            ],
            [
              -59.62368165698353,
              -18.186103068460827
            ],
            [
              -59.61861764636341,
              -18.171587765234925
            ],
            [
              -59.607545487549935,
              -18.139617224277707
            ],
            [
              -59.6014515086681,
              -18.142227283590906
            ],
            [
              -59.595786683228646,
              -18.142064156025146
            ],
            [
              -59.5919243022472,
              -18.137251824377877
            ],
            [
              -59.58952104296986,
              -18.13782278590335
            ],
            [
              -59.58574449267689,
              -18.126811056471237
            ]
          ]
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.LineString(
        [[-59.59012185778919, -18.332085751094823],
         [-59.58763276782337, -18.330130346340187],
         [-59.586087815430794, -18.32866377826472],
         [-59.58445703234974, -18.32776753609662],
         [-59.583341233399544, -18.326626857529778],
         [-59.580594651368294, -18.32621947050434],
         [-59.579307191041146, -18.324589912808403],
         [-59.57724725451771, -18.32287886070742],
         [-59.57613145556751, -18.32067891171299],
         [-59.57595979419056, -18.31937522503618],
         [-59.57338487353626, -18.31872337801468],
         [-59.57166825976673, -18.318478934748605],
         [-59.57038079943958, -18.31986410869098],
         [-59.56754838671986, -18.320190030360184],
         [-59.56789170947376, -18.31888634000024],
         [-59.569350831177864, -18.31733819494172],
         [-59.57003747668568, -18.315464106079155],
         [-59.566604249146614, -18.31530114087126],
         [-59.56342851367298, -18.316523376190535],
         [-59.560081116822396, -18.31717523149837],
         [-59.55827867236439, -18.31562707113363],
         [-59.555875413087044, -18.316115965376422],
         [-59.5534721538097, -18.314812244326994],
         [-59.55252801623646, -18.314730761435356],
         [-59.55269967761341, -18.313508513458146],
         [-59.55596124377552, -18.312123288651563],
         [-59.554330460694466, -18.310575083104247],
         [-59.55106889453236, -18.310086173213048],
         [-59.548579804566536, -18.308537949449985],
         [-59.54574739184681, -18.305848896329877],
         [-59.54342996325794, -18.302181938424354],
         [-59.54119836535755, -18.300226195799777],
         [-59.537850968506966, -18.298025958956508],
         [-59.53450357165638, -18.295988677707687],
         [-59.532615296509896, -18.294440327939366],
         [-59.52995454516712, -18.293380922758786],
         [-59.52849542346302, -18.289958184842355],
         [-59.52755128588978, -18.286127897996803],
         [-59.52480470385853, -18.2839274821792],
         [-59.5234314128429, -18.281564041496704],
         [-59.523088090089, -18.27871157019435],
         [-59.523088090089, -18.276429559378652],
         [-59.521371476319466, -18.274310522457355],
         [-59.52008401599232, -18.271050415121316],
         [-59.51896821704212, -18.268686799004854],
         [-59.51828157153431, -18.26664917306944],
         [-59.54926645007435, -18.240402413791458],
         [-59.58746110644642, -18.213254857657844],
         [-59.60248147692982, -18.20428626609934],
         [-59.61372529712025, -18.197029522287465],
         [-59.62368165698353, -18.18846780682386],
         [-59.62368165698353, -18.186103068460827],
         [-59.61861764636341, -18.171587765234925],
         [-59.607545487549935, -18.139617224277707],
         [-59.6014515086681, -18.142227283590906],
         [-59.595786683228646, -18.142064156025146],
         [-59.5919243022472, -18.137251824377877],
         [-59.58952104296986, -18.13782278590335],
         [-59.58574449267689, -18.126811056471237]]),
    parks = ui.import && ui.import("parks", "table", {
      "id": "WCMC/WDPA/current/polygons"
    }) || ee.FeatureCollection("WCMC/WDPA/current/polygons"),
    CuadroRobore_min = ui.import && ui.import("CuadroRobore_min", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                -59.637099789906344,
                -18.109365407459563
              ],
              [
                -59.637099789906344,
                -18.236582426098078
              ],
              [
                -59.55264239244541,
                -18.236582426098078
              ],
              [
                -59.55264239244541,
                -18.109365407459563
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[-59.637099789906344, -18.109365407459563],
          [-59.637099789906344, -18.236582426098078],
          [-59.55264239244541, -18.236582426098078],
          [-59.55264239244541, -18.109365407459563]]], null, false),
    inra = ui.import && ui.import("inra", "table", {
      "id": "users/edersantibanhez/inra"
    }) || ee.FeatureCollection("users/edersantibanhez/inra"),
    predio_saneado_21 = ui.import && ui.import("predio_saneado_21", "table", {
      "id": "users/edersantibanhez/PrediosSaneados21"
    }) || ee.FeatureCollection("users/edersantibanhez/PrediosSaneados21"),
    table_plus = ui.import && ui.import("table_plus", "table", {
      "id": "users/edersantibanhez/plus"
    }) || ee.FeatureCollection("users/edersantibanhez/plus"),
    PLUS_SC = ui.import && ui.import("PLUS_SC", "table", {
      "id": "users/edersantibanhez/PLUS-SC"
    }) || ee.FeatureCollection("users/edersantibanhez/PLUS-SC");
function maskS2clouds(image) {
  var qa = image.select('SCL');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}
var dataset_2020 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2020-01-01', '2020-12-31')
                  // Prefiltrar para obtener granos menos nublados
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5))
                  .filterBounds(CuadroRobore)  // Filtrar por el polígono definido
                  .map(maskS2clouds);
var dataset_2021 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2021-01-01', '2021-12-31')
                  // Prefiltrar para obtener granos menos nublados
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5))
                  .filterBounds(CuadroRobore)  // Filtrar por el polígono definido
                  .map(maskS2clouds);
var dataset_2022 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2022-01-01', '2022-12-31')
                  // Prefiltrar para obtener granos menos nublados
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 5))
                  .filterBounds(CuadroRobore)  // Filtrar por el polígono definido
                  .map(maskS2clouds);
var dataset_2023 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2023-01-01', '2023-12-31')
                  // Prefiltrar para obtener granos menos nublados
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10))
                  .filterBounds(CuadroRobore)  // Filtrar por el polígono definido
                  .map(maskS2clouds);
var dataset_2024 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2024-06-01', '2024-06-30')
                  // Prefiltrar para obtener granos menos nublados
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10))
                  .filterBounds(CuadroRobore)  // Filtrar por el polígono definido
                  .map(maskS2clouds);
var dataset_2024_min = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2024-06-01', '2024-06-30')
                  // Prefiltrar para obtener granos menos nublados
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 10))
                  .filterBounds(CuadroRobore_min)  // Filtrar por el polígono definido
                  .map(maskS2clouds);
// Reducir la colección de imágenes a un solo mosaico
var image = dataset_2024_min.median();
// Aplicar un umbral para crear una máscara binaria
var thresholded = image.gt(0.3);  // Ajusta este umbral según tus datos
// Convertir la máscara binaria a polígonos
var vectors = thresholded.reduceToVectors({
  geometryType: 'polygon',
  reducer: ee.Reducer.countEvery(),
  scale: 10,
  geometry: CuadroRobore_min,
  maxPixels: 1e10,
  bestEffort: true
});
// Exportar los polígonos a un archivo shapefile
Export.table.toDrive({
  collection: vectors,
  description: 'Copernicus_Robore_Junio_2024_Exportados',
  fileFormat: 'SHP'
});
var visualization = {
  min: 0.0,
  max: 0.3,
  bands: ['B4', 'B3', 'B2'],
};
Map.addLayer(dataset_2020.mean(), visualization, 'Copernicus 2020',false);
Map.addLayer(dataset_2021.mean(), visualization, 'Copernicus 2021',false);
Map.addLayer(dataset_2022.mean(), visualization, 'Copernicus 2022',false);
Map.addLayer(dataset_2023.mean(), visualization, 'Copernicus 2023',false);
Map.addLayer(dataset_2024.mean(), visualization, 'Copernicus 2024');
// Definir el estilo para mostrar solo el contorno
var outline = ee.Image().byte().paint({
  featureCollection: Robore_Reconstruido,
  color: 1,
  width: 2  // Ajusta el ancho del contorno según sea necesario
});
// Añadir la capa al mapa
Map.addLayer(outline, {palette: 'FFFF00'}, 'Roboré', true);
// Centrar el mapa en la geometría
Map.centerObject(Robore_Reconstruido);
var Tucavaca = (parks).filter(ee.Filter.eq("NAME", "Valle de Tucavaca"));
var Style1 = {
  color: '01DF014D'  // Color verde con 50% de opacidad ('80' es el valor hexadecimal para 50% opacidad)
};
var Style2 = {
  color: '8B45134D'  // Color verde con 50% de opacidad ('80' es el valor hexadecimal para 50% opacidad)
};
Map.addLayer(Tucavaca.style(Style1), {},'Areas Protegidas Tucabaca',true);
// Añadir la capa al mapa con el estilo definido
Map.addLayer(Paquio.style(Style2), {}, 'Reserva Paquio', true);
var longitudMetros = Recorrido.length();
var longitudKilometros = ee.Number(longitudMetros).divide(1000);
// Imprime la longitud en kilómetros
var longitudKMRedondeada = ee.Number(longitudKilometros).format('%.2f');
var cadenaConcatenada = ee.String(longitudKMRedondeada).cat(' ').cat("kilómetros");
print('Longitud de Recorrido:', cadenaConcatenada);
var featureCollection = ee.FeatureCollection([ee.Feature(Recorrido)]);
// Función para filtrar solo los polígonos
function filterPolygons(geometry) {
  var geometries = geometry.geometries();
  var polygons = geometries.map(function(geom) {
    geom = ee.Geometry(geom);
    return ee.Algorithms.If(
      geom.type().equals('LineString'),
      geom,
      null
    );
  });
  return ee.List(polygons).removeAll([null]);
}
// Extraer solo los polígonos de la GeometryCollection
var polygonGeometries = filterPolygons(featureCollection.geometry());
// Convertir las geometrías de polígonos a Features
var polygons = polygonGeometries.map(function(geom) {
  return ee.Feature(ee.Geometry(geom));
});
// Crear una FeatureCollection a partir de los polígonos
var polygonCollection = ee.FeatureCollection(polygons);
// Verificar la colección de polígonos
print("Filtered Polygons Collection: ", polygonCollection);
// Exportar la FeatureCollection de polígonos a Google Drive como un archivo SHP
Export.table.toDrive({
  collection: polygonCollection,
  description: 'Recorrido',
  fileFormat: 'SHP',
  folder: 'shp_export'
});
var actual =new Date();
var desde = '2024-06-18T01:00';//new Date(actual.setDate(actual.getDate()-7));
var hasta = '2024-06-24T01:00';//new Date(actual.setDate(actual.getDate()-1));
//hace_n_dias = new Date(hace_n_dias.setDate(hace_n_dias.getDate()-4));
//hace_n_dias =  '2021-07-01T01:00';
//var collection = ee.ImageCollection('FIRMS').filter(ee.Filter.date(, ayer));
var collection = ee.ImageCollection('FIRMS').filter(ee.Filter.date(desde, hasta));
var collectionWithConfidence = collection.select(['T21', 'confidence']);
// Filtra imágenes con confianza mayor o igual a 10
var ConfianzaMaxima = collectionWithConfidence.map(function(image){
  var confianza = image.select('confidence').gte(10);
  return image.updateMask(confianza);
});
// Muestra la colección con confianza en el mapa
//Map.addLayer(ConfianzaMaxima, {palette: ['yellow', 'red']}, 'Incendio ' + desde + ' hasta ' + hasta, true);
Map.addLayer(inra,{color: 'FF4500'},'Tierras Tituladas hasta 2018 por el INRA',false);
Map.addLayer(predio_saneado_21,{color: 'ffff00'},'predio_saneado_21 INRA',false);
Map.addLayer(PrediosControl21,{color: 'ffff00'},'PrediosControl21 INRA',false);
Map.addLayer(PrediosProceso21,{color: 'ffff00'},'PrediosProceso21 INRA',false);
var colorTable = ee.Dictionary({
  'TIERRAS DE USO FORESTAL': 'GREEN',
  'TIERRAS DE USO AGROPECUARIO EXTENSIVO': 'YELLOW',
  'AREAS NATURALES PROTEGIDAS': 'RED',
  'TIERRAS DE USO RESTRINGIDO': 'BLUE',
  'TIERRAS DE USO AGROSILVOPASTORIL': 'BROWN'
});
var styled = table_plus.filter(ee.Filter.eq("USO1", "TIERRAS DE USO FORESTAL"))
  .map(function (feature) {
    return feature.set('style', {
      fillColor: colorTable.get(feature.get('USO1'), '777777')
    });
  })
  .style({
    styleProperty: 'style',
  });
var palette = ['GREEN', 'YELLOW', 'RED', 'BLUE','BROWN'];
Map.addLayer(styled,{},'PLUS-TIERRAS DE USO FORESTAL', false,0.15);
Map.addLayer(PLUS_SC,{color: 'ffff00'},'PLUS',false);
var tucabaca = ee.FeatureCollection("WCMC/WDPA/current/polygons")
.filter(ee.Filter.eq("NAME","Valle de Tucavaca"));
function buff(f){
  return f.buffer(5000);
}
var buff_tucabaca = tucabaca.map(buff);
Map.centerObject(tucabaca);
Map.addLayer(tucabaca,{color:"green"},"Ap Tucabaca");
Map.addLayer(buff_tucabaca,{color:"red"},"Area de influencia 5Km Tucabaca",false);
var Paraiso_Tit_2018 = (inra).filter(ee.Filter.eq("NOM_PRE", "LA TORMENTA"));
Map.addLayer(Paraiso_Tit_2018,{color: 'FF4500'},'LA TORMENTA hasta 2018',false);
//var Contiene_Tit_2018 = (inra).filter(ee.Filter.eq("NOM_PRE", "LA TORMENTA"));
var Contiene_Tit_2018 = inra.filter(ee.Filter.stringContains("NOM_TIT", "VARGAS SEGOVIA"));
Map.addLayer(Contiene_Tit_2018,{color: 'FF4500'},'Contiene hasta 2018',false);
print(Contiene_Tit_2018);
var Contiene_saneado_21 = predio_saneado_21.filter(ee.Filter.stringContains("NombreAgru", "BOLIVIA"));
Map.addLayer(Contiene_saneado_21,{color: 'ffff00'},'Contiene_saneado_21 INRA',true);