var app = {};
app.createConstants = function() {
  app.INFO_PANEL_STYLE = {width: '350px', position: 'middle-left'};
  app.TITLE_STYLE = {margin: '12px 0px 0px 8px', fontSize: 'x-large', fontWeight: 'bold'};
  app.SUBTITLE_STYLE = {margin: '12px 8px 0px', fontSize: 'medium', fontWeight: 'bold'};
  app.TEXT_STYLE = {margin: '12px 16px 0px 8px', fontSize: 'normal', fontWeight: '300'};
  app.CHART_PANEL_STYLE = {width: '400px', margin: '0px', padding: '0px'};
  app.COL = 'COPERNICUS/S2_SR';
  app.CLOUD_PROPERTY = 'CLOUDY_PIXEL_PERCENTAGE';
  app.BANDS_OF_INTEREST = ['B[2-4]', 'B8'];
  app.VIS_PARAMS = {bands: ['B4', 'B3', 'B2'], min: 0, max: 0.3};
  app.CHART_OPTIONS = {
    titlePosition: 'none',
    legend: {
      position: 'none'
    },
    vAxis: {
      title: 'Reflectance',
      viewWindow: {
        min: 0
      },
      // gridlines: {
      //   count: 5
      // },
      format : 'percent'
    },
    hAxis: {
      title: 'Wavelength (nm)'
    },
    curveType: 'function',
    chartArea: {top: '10%'}
  };
};
app.createPanels = function() {
  var title = 'Inspetor Espectral';
  var desc = 
  'Um gráfico da reflectância espectral de um objeto em função do comprimento de onda é chamado de curva de reflectância espectral.';
  var instructions = 
  'Selecione um objeto (vegetação, água, solo, etc.) e clique sobre ele para gerar uma curva de reflectância espectral.';
  var aboutMe = 
  'Clique nos links abaixo para conhecer outros trabalhos relacionados ao Google Earth Engine.';
  app.info = {
    panel: ui.Panel({
      widgets: [
        ui.Label(title, app.TITLE_STYLE),
        ui.Label(desc, app.TEXT_STYLE),
        ui.Label('Intruções', app.SUBTITLE_STYLE),
        ui.Label(instructions, {fontWeight: '300', whiteSpace: 'pre-wrap'}),
        ui.Label('Saiba mais', app.SUBTITLE_STYLE),
        ui.Label(aboutMe, {fontWeight: '300', whiteSpace: 'pre-wrap'}),
        ui.Panel({
          widgets: [
            ui.Label({value: 'GitHub', style: {fontSize: 'small', margin: '2px 0px 0px 8px'}, targetUrl: 'https://github.com/iagomoliv'}),
            ui.Label({value: 'LinkedIn', style: {fontSize: 'small', margin: '2px 0px 0px 8px'}, targetUrl: 'https://www.linkedin.com/in/iago-mendes/'}),
            ui.Label({value: 'Twitter', style: {fontSize: 'small', margin: '2px 0px 0px 8px'}, targetUrl: 'https://twitter.com/oiagomendes'}),
            ui.Label({value: 'Instagram', style: {fontSize: 'small', margin: '2px 0px 0px 8px'}, targetUrl: 'https://www.instagram.com/oiagomendes/'}),
            ui.Label({value: 'YouTube', style: {fontSize: 'small', margin: '2px 0px 8px 8px'}, targetUrl: 'https://www.youtube.com/c/IagoMendes/'})
          ],
          layout: ui.Panel.Layout.flow('horizontal'),
          style: {}
        })
      ], 
      layout: ui.Panel.Layout.flow('vertical'), 
      style: app.INFO_PANEL_STYLE
    })
  };
  app.chart = {
    button: ui.Button('Esconder'),
    panel: ui.Panel({
      widgets: [],
      style: app.CHART_PANEL_STYLE
    })
  };
  app.chart.container = ui.Panel({
    widgets: [
      app.chart.button,
      app.chart.panel
    ],
    style: {padding: '0px', position: 'bottom-right'}
  });
  Map.add(app.info.panel);
  Map.add(app.chart.container);
};
app.setInitialState = function() {
  app.chart.container.style().set('shown', false);
  app.chart.button.onClick(app.showHideChart);
  Map.setCenter(-50, -21.25, 16);
  Map.setOptions('SATELLITE');
  Map.setControlVisibility(false);
  Map.style().set('cursor', 'crosshair');
  Map.onClick(app.centerOnClickedPoint);
  Map.onClick(app.drawChart);
};
app.createHelpers = function() {
  app.centerOnClickedPoint = function(pt) {
    Map.setCenter(pt.lon, pt.lat);
  };
  app.getCleanestImage = function(pt) {
    var today = ee.Date(Date.now());
    return ee.ImageCollection(app.COL)
            .filterDate(today.advance(-3, 'month'), today)
            .filterBounds(pt)
            .sort(app.CLOUD_PROPERTY)
            .first()
            .select(app.BANDS_OF_INTEREST)
            .multiply(0.0001);
  };
  app.drawChart = function(pt) {
    /** Mostrar o gráfico caso não esteja sendo mostrado */
    if (!app.chart.container.style().get('shown')) {
      app.chart.container.style().set('shown', true);
    }
    var point = ee.Geometry.Point([pt.lon, pt.lat]);
    var image = app.getCleanestImage(point);
    var chart = ui.Chart.image.regions({
      image: image,
      regions: point,
      reducer: ee.Reducer.mean(),
      scale: 10,
      xLabels: ['496.6', '560', '664.5', '835.1']
    });
    chart.setOptions(app.CHART_OPTIONS);
    /** Adiciona o gráfico ao painel */
    app.chart.panel.widgets().reset([chart]);
    /** Adiciona a imagem mais limpa no mapa */
    var imageLayer = ui.Map.Layer(image, app.VIS_PARAMS, 'image');
    Map.layers().set(0, imageLayer);
    /** Adiciona o ponto clicado no mapa */
    var clickedPointLayer = ee.FeatureCollection(point).style({color: '#46F057', pointSize: 5, fillColor: '#46F05750'});
    Map.layers().set(1, clickedPointLayer);
  };
  app.showHideChart = function() {
    var shown = true;
    var label = 'Esconder';
    if (app.chart.panel.style().get('shown')) {
      shown = false;
      label = 'Mostrar';
    }
    app.chart.panel.style().set('shown', shown);
    app.chart.button.setLabel(label);
  };
};
app.run = function() {
  app.createConstants();
  app.createHelpers();
  app.createPanels();
  app.setInitialState();
};
app.run();