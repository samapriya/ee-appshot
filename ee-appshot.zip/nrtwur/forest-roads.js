var kleinschroth = ui.import && ui.import("kleinschroth", "table", {
      "id": "projects/wurnrt-loggingroads/assets/kleinschroth/kleinschroth_etal_2019_natsust_data"
    }) || ee.FeatureCollection("projects/wurnrt-loggingroads/assets/kleinschroth/kleinschroth_etal_2019_natsust_data"),
    fm = ui.import && ui.import("fm", "image", {
      "id": "projects/wurnrt-loggingroads/assets/distribution/forestmask"
    }) || ee.Image("projects/wurnrt-loggingroads/assets/distribution/forestmask"),
    roads = ui.import && ui.import("roads", "table", {
      "id": "projects/wurnrt-loggingroads/assets/distribution/forestroads_afr_2019-01_2024-12"
    }) || ee.FeatureCollection("projects/wurnrt-loggingroads/assets/distribution/forestroads_afr_2019-01_2024-12");
// Including roads 2019-2024
var font = 'Cambria'
Map.setControlVisibility({ 
  all: false,
  fullscreenControl: true, 
  scaleControl: true,
  zoomControl: true,
  mapTypeControl: true
})
Map.setOptions('Satellite')
Map.style().set('cursor', 'hand')
Map.setCenter(15, 1, 7)
// Convert new roads FC to ee.Image with Dates
var roads_img = roads.reduceToImage(['MonthNum'], ee.Reducer.first())
// Convert old roads FC to ee.Image with Dates
var oldroads_img = kleinschroth.reduceToImage(['concession'], ee.Reducer.first())
var geometry = roads.geometry().bounds()
var temporal_legend = {min:20000, max:21186, palette: ['pink', 'red', 'darkred']}
var roads_img = ui.Map.Layer(roads_img, {palette: ['pink', 'red', 'darkred'], min:0,max:72})
var oldroads_img = ui.Map.Layer(oldroads_img, {palette: ['black'], min:0,max:1}).setOpacity(0.3)
var forestmask = ui.Map.Layer(fm.selfMask(), {min:0, max:1, palette: ['black']}, 'Forestmask').setOpacity(0.2)
// Sentinel-2 stuff
var s2_vis = {bands: ['B4','B3','B2'], gain: 0.2}
var start_date_s2_collection = ee.Date('2019-01-01')
var s2 = ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
                .filterBounds(geometry)        
                .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 90))
                .filterDate(start_date_s2_collection, ee.Date('2035-12-31'))
                .select(['B4', 'B3', 'B2'])
var cloud_probability = 0.55
var cloud_band = 'cs'
var cloudscore = ee.ImageCollection('GOOGLE/CLOUD_SCORE_PLUS/V1/S2_HARMONIZED');
var s2 = s2.linkCollection(cloudscore, [cloud_band])
         .map(function(img) {return img.updateMask(img.select(cloud_band).gte(cloud_probability))})
         .select(['B4', 'B3', 'B2'])
var s2_1 = s2.filterDate(start_date_s2_collection, start_date_s2_collection.advance(12, 'month')).reduce(ee.Reducer.intervalMean(10,25)).rename(['B4', 'B3', 'B2'])
var s2_2 = s2.filterDate(start_date_s2_collection.advance(12, 'month'), start_date_s2_collection.advance(24, 'month')).reduce(ee.Reducer.intervalMean(10,25)).rename(['B4', 'B3', 'B2'])
var s2_3 = s2.filterDate(start_date_s2_collection.advance(24, 'month'), start_date_s2_collection.advance(36, 'month')).reduce(ee.Reducer.intervalMean(10,25)).rename(['B4', 'B3', 'B2'])
var s2_4 = s2.filterDate(start_date_s2_collection.advance(36, 'month'), start_date_s2_collection.advance(48, 'month')).reduce(ee.Reducer.intervalMean(10,25)).rename(['B4', 'B3', 'B2'])
var s2_5 = s2.filterDate(start_date_s2_collection.advance(48, 'month'), start_date_s2_collection.advance(60, 'month')).reduce(ee.Reducer.intervalMean(10,25)).rename(['B4', 'B3', 'B2'])
var s2_6 = s2.filterDate(start_date_s2_collection.advance(60, 'month'), start_date_s2_collection.advance(72, 'month')).reduce(ee.Reducer.intervalMean(10,25)).rename(['B4', 'B3', 'B2'])
var s2_7 = s2.filterDate(start_date_s2_collection.advance(72, 'month'), start_date_s2_collection.advance(84, 'month')).reduce(ee.Reducer.intervalMean(10,25)).rename(['B4', 'B3', 'B2'])
var s2_1_string = '2019'
var s2_2_string = '2020'
var s2_3_string = '2021'
var s2_4_string = '2022'
var s2_5_string = '2023'
var s2_6_string = '2024'
var s2_7_string = '2025'
var s2_1 = ui.Map.Layer(s2_1, s2_vis, s2_1_string, false)
var s2_2 = ui.Map.Layer(s2_2, s2_vis, s2_2_string, false)
var s2_3 = ui.Map.Layer(s2_3, s2_vis, s2_3_string, false)
var s2_4 = ui.Map.Layer(s2_4, s2_vis, s2_4_string, false)
var s2_5 = ui.Map.Layer(s2_5, s2_vis, s2_5_string, false)
var s2_6 = ui.Map.Layer(s2_6, s2_vis, s2_6_string, false)
var s2_7 = ui.Map.Layer(s2_7, s2_vis, s2_7_string, false)
Map.add(forestmask)
Map.add(s2_1)
Map.add(s2_2)
Map.add(s2_3)
Map.add(s2_4)
Map.add(s2_5)
Map.add(s2_6)
Map.add(s2_7)
Map.add(roads_img)
Map.add(oldroads_img)
// App Title
var header = ui.Label('Congo Basin forest roads', 
                      {fontFamily: font, fontSize: '20px', fontWeight: 'bold', color: 'darkblue'});
// Reference
var authors = ui.Label({
  value: '',
  style: {fontFamily: font, fontSize: '14px'},
  targetUrl: "https://www.wur.nl/en/research-results/chair-groups/environmental-sciences/laboratory-of-geo-information-science-and-remote-sensing/research/sensing-measuring/radar-remote-sensing.htm"})
var authors = ui.Panel([
    ui.Label({ 
      value: "Slagter B, Fesenmyer K, Hethcoat M, Belair E, Ellis P, Kleinschroth F, \nPeña-Claros M, Herold M, Reiche J,  Remote Sens. Environ. (2024)", 
      style: {fontFamily: font, whiteSpace: 'pre', fontSize: '13px', margin: '0px 0px 0px 8px' } 
    }),
    ui.Label({
      value: "https://doi.org/10.1016/j.rse.2024.114380", 
      style: {fontFamily: font, fontSize: '12px', margin: '0px 0px 0px 8px' }, 
      targetUrl: "https://doi.org/10.1016/j.rse.2024.114380" 
    })
  ], ui.Panel.Layout.flow('vertical'))
// Summary
var summary = ui.Label(
  'Road development in Congo Basin forests is mapped with Sentinel-1 and -2 satellite imagery and a deep learning model. The map presents roads developed between 2019 and 2024 (57,363 km) in high spatial and temporal detail. The majority of mapped roads relate to selective logging.',
{fontFamily: font, fontSize: '15px'})
var note =  ui.Label(
  'This updated map contains road development from 2019-2024, adding two extra years to the 2019-2022 map presented in Slagter et al. (2024).',
{fontFamily: font, fontStyle: 'italic', fontSize: '12px'});
var whiteSpace = ui.Panel([
    ui.Label('   ', {fontFamily: font, fontSize: '12px' , position: 'top-left', margin: '0px 0px 10px 14px'}),
  ])
// Links
var website = ui.Panel([
    ui.Label('Website:', {fontFamily: font, fontSize: '14px', margin: '0px', padding: '0px' }), 
    ui.Label('http://wur.eu/forest-roads', {fontFamily: font, fontSize: '12px', margin: '2px 0px 0px 0px', padding: '0px 0px 0px 4px'}, 'http://wur.eu/forest-roads')
    ], ui.Panel.Layout.flow('horizontal'), { margin: '0px, 0px, 0px, 0px', padding: '0px 0px 0px 8px' })
var linkToData = ui.Panel([
    ui.Label('Data access:', {fontFamily: font, fontSize: '14px', margin: '0px', padding: '0px' }), 
    ui.Label('https://doi.org/10.5281/zenodo.13269839', {fontFamily: font, fontSize: '12px', margin: '2px 0px 0px 0px', padding: '0px 0px 0px 4px'}, 'https://doi.org/10.5281/zenodo.13269839')
    ], ui.Panel.Layout.flow('horizontal'), { margin: '0px', padding: '0px 0px 0px 8px' })
var line1 = ui.Panel([ui.Label({value: '____________________________________________________________', style: {margin: '16px 0px 8px 8px', fontWeight: 'bold', color: 'darkblue'},})])
var line2 = ui.Panel([ui.Label({value: '____________________________________________________________', style: {margin: '16px 0px 8px 8px', fontWeight: 'bold', color: 'darkblue'},})])
var line3 = ui.Panel([ui.Label({value: '____________________________________________________________', style: {margin: '16px 0px 8px 8px', fontWeight: 'bold', color: 'darkblue'},})])
var line4 = ui.Panel([ui.Label({value: '____________________________________________________________', style: {margin: '16px 0px 8px 8px', fontWeight: 'bold', color: 'darkblue'},})])
var line5 = ui.Panel([ui.Label({value: '____________________________________________________________', style: {margin: '16px 0px 8px 8px', fontWeight: 'bold', color: 'darkblue'},})])
// Add panel
var panel = ui.Panel({
widgets:[header, authors, summary, note, whiteSpace, website, linkToData], // Adds header and authors and summary
style:{width: '415px',position:'middle-right', border: '2px solid grey'}});
// Function to make a legend row
var makeLegendRow = function(color, name, description_small) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: color,
          border: '1px solid black',
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 8px'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {fontFamily: font, fontSize: '14px', margin: '0 0 4px 6px'}
      });
      // Create a label description
      var description_small = ui.Label({
        value: description_small,
        style: {fontFamily: font, color: 'grey', fontSize: '12px', margin: '3px 0px 0px 8px'}
      });      
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description, description_small],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
}
// Function to make a legend row
var makeLegendRow_line = function(name, description_small) {
      // Create the label filled with the description text.
      var label = ui.Label({
        value:  '—',
        style: {fontFamily: font, fontSize: '18px', margin: '-4px -2px 4px 8px'}
      });      
      // Create the label filled with the description text.
      var description = ui.Label({
        value:  name,
        style: {fontFamily: font, fontSize: '14px', margin: '0px 0px 4px 8px'}
      });
      // Create a label description
      var description_small = ui.Label({
        value: description_small,
        style: {fontFamily: font, color: 'grey', fontSize: '11px', margin: '3px 0px 0px 8px'}
      });      
      // return the panel
      return ui.Panel({
        widgets: [label, description, description_small],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
}
//Add a panel to hold graphs within main panel
var panelGraph = ui.Panel({
  style:{width: '300px',position:'middle-right'}
})
//Construct Dropdown for S2
var selectS2Composites = ui.Select({
  items:['None', s2_1_string,s2_2_string,s2_3_string,s2_4_string,s2_5_string, s2_6_string, s2_7_string],
  placeholder:'None',
  onChange: selectComposite,
  style: {fontFamily: font, position:'top-right'}
})
//Write a function that runs on change of Dropdown
function selectComposite(){
  var graph = selectS2Composites.getValue() // get value from dropdown selection
  panelGraph.clear() //clear graph panel between selections so only one graph displays
  //We use "if else" statements to write instructions for drawing graphs
  if (graph == 'None'){
   s2_1.setShown(false)
   s2_2.setShown(false)
   s2_3.setShown(false)
   s2_4.setShown(false)
   s2_5.setShown(false)  
   s2_6.setShown(false)  
   s2_7.setShown(false)
  }
  else if (graph == s2_1_string){
   s2_1.setShown(true)
   s2_2.setShown(false)
   s2_3.setShown(false)
   s2_4.setShown(false)
   s2_5.setShown(false) 
   s2_6.setShown(false) 
   s2_7.setShown(false)
  }
  else if (graph == s2_2_string){
   s2_1.setShown(false)
   s2_2.setShown(true)
   s2_3.setShown(false)
   s2_4.setShown(false)
   s2_5.setShown(false)
   s2_6.setShown(false)
  }
  else if (graph == s2_3_string){
   s2_1.setShown(false)
   s2_2.setShown(false)
   s2_3.setShown(true)
   s2_4.setShown(false)
   s2_5.setShown(false)   
   s2_6.setShown(false)
   s2_7.setShown(false)
  }
  else if (graph == s2_4_string){
   s2_1.setShown(false)
   s2_2.setShown(false)
   s2_3.setShown(false)
   s2_4.setShown(true)
   s2_5.setShown(false)  
   s2_6.setShown(false)
   s2_7.setShown(false)
  }
  else if (graph == s2_5_string){
   s2_1.setShown(false)
   s2_2.setShown(false)
   s2_3.setShown(false)
   s2_4.setShown(false)
   s2_5.setShown(true)  
   s2_6.setShown(false)
   s2_7.setShown(false)
  }
  else if (graph == s2_6_string){
   s2_1.setShown(false)
   s2_2.setShown(false)
   s2_3.setShown(false)
   s2_4.setShown(false)
   s2_5.setShown(false)  
   s2_6.setShown(true)
   s2_7.setShown(false)
  }
  else if (graph == s2_7_string){
   s2_1.setShown(false)
   s2_2.setShown(false)
   s2_3.setShown(false)
   s2_4.setShown(false)
   s2_5.setShown(false)  
   s2_6.setShown(false)
   s2_7.setShown(true)
  }  
}
function makeLegend (temporal_legend) {
  var lon = ee.Image.pixelLonLat().select('longitude');
  var gradient = lon.multiply((temporal_legend.max-temporal_legend.min)/100.0).add(temporal_legend.min);
  var legendImage = gradient.visualize(temporal_legend);
  var thumb = ui.Thumbnail({
    image: legendImage, 
    params: {bbox:'0,0,100,8', dimensions:'260x16', format:'png'},  
    style: {position: 'bottom-center'}
  });
  var panel2 = ui.Panel({
    widgets: [
      ui.Label('Jan-2019', {fontFamily: font, fontSize: '12px', margin: '4px 0px 0px 8px'}), 
      ui.Label({style: {stretch: 'horizontal'}}),
      ui.Label('Dec-2024', {fontFamily: font, fontSize: '12px', margin: '4px 0px 0px 8px'}), 
    ],
    layout: ui.Panel.Layout.flow('horizontal'),
    style: {stretch: 'horizontal', maxWidth: '265px', padding: '0px 0px 0px 2px'}
  });
  return ui.Panel().add(panel2).add(thumb);
}
// Checkboxes
var roadExpansionCheckbox = ui.Checkbox().setValue(true)
var doCheckboxroadExpansion = function() {
  roadExpansionCheckbox.onChange(function(checked){
    // Disable or enable the currently displayed road map from the Map window
    var lastLayerNumber = Map.layers().length()-1
    var layerToBeEdited = Map.layers().get(lastLayerNumber)
    layerToBeEdited.setShown(checked)
    // Also do this for the old roads
    var lastLayerNumber = Map.layers().length()-2
    var layerToBeEdited = Map.layers().get(lastLayerNumber)
    layerToBeEdited.setShown(checked)
  })
}
doCheckboxroadExpansion()
// Map layer panels
var roadExpansion = ui.Panel([
    ui.Label('Road development ', {fontSize: '14px', fontFamily: font, fontWeight: 'bold', position: 'top-left', margin: '8px 10px 16px 8px'}),
    roadExpansionCheckbox
  ], ui.Panel.Layout.flow('horizontal'))
var whiteSpace = ui.Panel([
    ui.Label('   ', {fontFamily: font, fontSize: '12px' , position: 'top-left', margin: '0px 0px 20px 14px'}),
  ])
var sentinel2 = ui.Panel([
    ui.Label('Sentinel-2 composites', {fontSize: '14px', fontFamily: font, fontWeight: 'bold', position: 'top-left', margin: '8px 38px 8px 8px'}),
    ui.Label('Composites can be affected by cloud cover.', {fontFamily: font, color: 'grey', fontSize: '11px' , position: 'top-left', margin: '-4px 0px 8px 8px'})
  ], ui.Panel.Layout.flow('vertical'))
var forestMask = ui.Panel([
    ui.Label('Forest baseline map ', {fontSize: '14px', fontFamily: font, fontWeight: 'bold', position: 'top-left', margin: '8px 10px 8px 8px'}),
    //forestMaskCheckbox
  ], ui.Panel.Layout.flow('horizontal'))
var forestMaskDescription = ui.Panel([
    ui.Label('Primary humid tropical forest mask 2001 (Turubanova et al., 2018, Environ. Res. Lett.) with annual forest loss (Hansen et al., 2013, Science) until 2019 removed.', {fontFamily: font, color: 'grey', fontSize: '11.5px' , position: 'top-left', margin: '0px 0px 8px 8px'}),
  ])
///// Add to the panel in the order you want them to appear
panel.add(line1)
panel.add(roadExpansion)
panel.add(makeLegend(temporal_legend))
panel.add(whiteSpace)
panel.add(makeLegendRow_line('Old roads (pre-2019)', 'Kleinschroth et al. (2019)'))
panel.add(makeLegendRow('#213321', 'Forest baseline map'))
panel.add(line2)
panel.add(sentinel2)
panel.add(selectS2Composites)
panel.add(line3)
//panel.add(forestMask)
//panel.add(makeLegendRow('grey', 'Primary humid tropical forest'))
//panel.add(forestMaskDescription)
//panel.add(line5)
ui.root.insert(1,panel)
// Lastly, add copyright to the Map window
var labelAcknowledgement = ui.Label({
  value: 'Wageningen University, Laboratory of Geo-Information Science and Remote Sensing ©2024',
  style: {
    'backgroundColor': '#00000066',
    'color': 'white',
    'fontSize': '12px',
    // 'fontWeight': 'bold',
    padding: '0px 0px 0px 0px',
    margin: '0px 0px 12px 0px'
  }
})
Map.add(ui.Panel({ widgets: [labelAcknowledgement], style: { padding: '0px 0px 0px 0px', margin: '0px 0px 0px 0px',  position: 'bottom-center', 'backgroundColor': '#00000000' } }))