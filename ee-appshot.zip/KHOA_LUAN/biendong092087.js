var    anh2020 = ee.Image("users/KHOA_LUAN/anhgiaidoan2020_092"),
     khuvuc = ee.FeatureCollection("users/KHOA_LUAN/TP_THUDUC"),
     anh2015 = ee.Image("users/KHOA_LUAN/anhgiaidoan2015_087");
Map.centerObject(khuvuc,11);
// ----------------XAY DUNG GIAO DIEN-----------------------
//ui.Panel
var panel = ui.Panel ({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    width:'400px',
    backgroundColor: '90EE90'
    }
} );
// 1- right , 0-left
ui.root.insert(1,panel);
//------------- Ket qua phan loai rung 1995-2022----------------
//---------------------khai báo khu vực thực hiện------------------------
var khuvuc = ee.FeatureCollection("users/KHOA_LUAN/TP_THUDUC").geometry();
// Di chuyển bản đồ nền đến khu vực thực hiện
Map.centerObject(khuvuc,11);
var viz = {
  min: 1,
  max:5,
  palette: ['d63000',
  'e326ff',
  '18ba09',
  '0e7fff']
} 
var anh2015 = ee.Image("users/KHOA_LUAN/anhgiaidoan2015_087").visualize(viz);
var anh2020 = ee.Image("users/KHOA_LUAN/anhgiaidoan2020_092").visualize(viz); 
Map.addLayer(anh2015,{},'2015')   ; 
Map.addLayer(anh2020,{},'2020')   ; 
//-------------- chen thumbnail vao panel--------------------
var name_1 = ui.Label('Bản đồ biến động năm 2015 - 2020',{
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight:'bold',
  fontSize:'18px'
});
panel.add(name_1);
// tạo mảng
var list = [anh2015,anh2020,anh2015,anh2020,anh2015,anh2020,];
// Tạo tập ảnh
var collection_img =ee.ImageCollection.fromImages(list);
// Tạo thumbnail
// Khai báo params
var params_thumbnail={
  dimensions:'600',//Kích thước tối đa của hình thu nhỏ để hiển thị
  region:khuvuc,// sua khu vuc nghien cuu
   framesPerSecond: 0.5//The framerate of the exported video. Must be a value between 0.1 and 100. Defaults to 1
};
var style_thumbnail={
  position:'bottom-right',
  width:'250px',
  margin:'auto'
  };
// 
//ui.Thumbnail(image, params, onClick, style)
var thumbmail =  ui.Thumbnail({
  image: collection_img,
  params: params_thumbnail,
  style: style_thumbnail
}
  );
  // hiển thị thumbnail
 // Map.add(thumbmail);
  panel.add(thumbmail);
// 
var name_2 = ui.Label('Cảm ơn Thầy Cô đã lắng nghe bài bảo vệ khóa luận cuối kì này, Chúc Thầy Cô và Các bạn có một ngày thật vui vẻ =))',{
  stretch: 'horizontal',
  textAlign: 'center',
  fontWeight:'bold',
  fontSize:'18px'
});
panel.add(name_2);    
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '20px 40px',
    color:'black',
      }
});
// Create and add the legend title.
var legendTitle = ui.Label({
  value: 'CHÚ THÍCH',
  style: {
    fontWeight: 'bold',
    fontSize: '15px',
    margin: '0 0 4px 0',
    padding: '0', 
  }
});
legend.add(legendTitle);
var loading = ui.Label('Loading legend...', {margin: '2px 0 4px 0'});
legend.add(loading);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: '#' + color,
      // Use padding to give the box height and width.
      padding: '10px',
      margin: '0 0 4px 0',
         }});
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {margin: '0 0 4px 6px'},
     });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal')
  });
};
// Get the list of palette colors and class names from the image.
anh2015.toDictionary().evaluate(function(result) {
  var palette =['d63000',
  'e326ff',
  '18ba09',
  '0e7fff'];
  var names = ['Đất Trống', 'Công Trình Xây Dựng','Thực Vật','Nước'];
  loading.style().set('shown', false);
  for (var i = 0; i < names.length; i++) {
    legend.add(makeRow(palette[i], names[i]));
  }
  });
// Add the legend to the map.
Map.add(legend);
// panel.add(legend)