// GeoDEM Explorer: Interactive Topographic Analysis with Cascaded FAO Admin Boundaries
// --- 1. User Interface (UI) Panel Setup ---
// Create a UI panel for controls with enhanced styling.
var controlPanel = ui.Panel({
  style: {
    width: '320px', // Slightly wider for better spacing
    padding: '15px',
    backgroundColor: '#f0f8ff', // AliceBlue background
    border: '2px solid #4682b4', // SteelBlue border
    borderRadius: '10px', // Rounded corners
    margin: '10px'
  }
});
// Add a title and description with colorful and neat fonts.
controlPanel.add(ui.Label('🌍 GeoDEM Explorer', {
  fontWeight: 'bold',
  fontSize: '28px',
  color: '#2f4f4f', // DarkSlateGray
  textAlign: 'center',
  margin: '0 0 10px 0',
  fontFamily: 'Roboto, sans-serif' // Modern font
}));
controlPanel.add(ui.Label('Interactive Topographic Analysis Tool using SRTM DEM data and FAO Admin Boundaries.', {
  fontSize: '13px',
  color: '#696969', // DimGray
  textAlign: 'center',
  margin: '0 0 20px 0',
  fontFamily: 'Arial, sans-serif'
}));
// Load FAO GAUL boundaries (Admin Level 2 includes higher levels as properties).
var faoGaul = ee.FeatureCollection('FAO/GAUL_SIMPLIFIED_500m/2015/level2');
// Global variables to store selected AOI and filter states/admin2 levels.
var aoi = null;
var currentCountryFilter = null;
var currentStateFilter = null;
// Define a global list of application-added layer names for easier management.
var APP_LAYER_NAMES = [
  'Elevation (AOI)',
  'Slope (AOI)',
  'Aspect (AOI)',
  'Hillshade (AOI)',
  'Selected AOI Border', // The red border for the selected Admin2
  'SRTM Elevation' // Default SRTM base layer name
];
// --- Country Selection ---
var countrySelect = ui.Select({
  placeholder: 'Select a Country',
  onChange: function(countryName) {
    currentCountryFilter = ee.Filter.eq('ADM0_NAME', countryName);
    // Reset state and Admin2 selectors when country changes
    stateSelect.setPlaceholder('Select a State/Province');
    stateSelect.setValue(null, false); // Clear value, no onChange trigger
    admin2Select.setPlaceholder('Select a Region or District'); // Updated placeholder
    admin2Select.setValue(null, false); // Clear value, no onChange trigger
    // Clear map and products, but keep map centered if AOI is still valid
    clearAllAppLayers();
    legendPanel.clear(); // Clear legend as product is reset
    productSelect.setValue(null, false);
    // Populate state dropdown based on selected country
    populateStateDropdown();
  },
  style: {stretch: 'horizontal', margin: '5px 0'}
});
controlPanel.add(ui.Label('Country:', {fontWeight: 'bold', color: '#4682b4', fontSize: '15px'})); // Label styling
controlPanel.add(countrySelect);
// --- State/Province Selection ---
var stateSelect = ui.Select({
  placeholder: 'Select a State/Province',
  onChange: function(stateName) {
    currentStateFilter = ee.Filter.eq('ADM1_NAME', stateName);
    // Reset Admin2 selector when state changes
    admin2Select.setPlaceholder('Select a Region or District'); // Updated placeholder
    admin2Select.setValue(null, false); // Clear value, no onChange trigger
    // Clear map and products, but keep map centered if AOI is still valid
    clearAllAppLayers();
    legendPanel.clear(); // Clear legend as product is reset
    productSelect.setValue(null, false);
    // Populate Admin2 dropdown based on selected state
    populateAdmin2Dropdown();
  },
  style: {stretch: 'horizontal', margin: '5px 0'}
});
controlPanel.add(ui.Label('State/Province:', {fontWeight: 'bold', color: '#4682b4', fontSize: '15px'})); // Label styling
controlPanel.add(stateSelect);
// --- Admin Level 2 Selection (now "Select Region or District") ---
var admin2Select = ui.Select({
  placeholder: 'Select a Region or District', // Updated placeholder
  onChange: function(admin2Name) {
    // Filter the FAO Admin2 collection to get the selected boundary.
    // Use the combined filters for Country and State/Province to ensure uniqueness.
    var combinedFilter = ee.Filter.and(
        currentCountryFilter,
        currentStateFilter,
        ee.Filter.eq('ADM2_NAME', admin2Name)
    );
    aoi = faoGaul.filter(combinedFilter).geometry();
    // When AOI changes, force a map update if a product is already selected
    if (productSelect.getValue()) {
      updateMapAndDisplay();
    } else {
      // If no product is selected, just zoom to AOI and show border
      clearAllAppLayers();
      map.addLayer(aoi, {color: 'red', fillColor: '00000000'}, 'Selected AOI Border', false);
      map.centerObject(aoi);
    }
  },
  style: {stretch: 'horizontal', margin: '5px 0'}
});
controlPanel.add(ui.Label('Region/District:', {fontWeight: 'bold', color: '#4682b4', fontSize: '15px'})); // Label styling
controlPanel.add(admin2Select);
// Populate Country Dropdown (runs once on script load)
faoGaul.aggregate_array('ADM0_NAME').distinct().sort().evaluate(function(countryNames) {
  countrySelect.items().reset(countryNames);
});
// Function to populate State/Province Dropdown
function populateStateDropdown() {
  if (currentCountryFilter) {
    // Filter out features where ADM1_NAME is null before aggregating
    faoGaul.filter(currentCountryFilter)
           .filter(ee.Filter.notNull(['ADM1_NAME']))
           .aggregate_array('ADM1_NAME').distinct().sort().evaluate(function(stateNames) {
      stateSelect.items().reset(stateNames);
    });
  } else {
    stateSelect.items().reset([]); // Clear if no country selected
  }
}
// Function to populate Admin Level 2 Dropdown
function populateAdmin2Dropdown() {
  if (currentCountryFilter && currentStateFilter) {
    var combinedFilter = ee.Filter.and(currentCountryFilter, currentStateFilter);
    // Filter out features where ADM2_NAME is null before aggregating
    faoGaul.filter(combinedFilter)
           .filter(ee.Filter.notNull(['ADM2_NAME']))
           .aggregate_array('ADM2_NAME').distinct().sort().evaluate(function(admin2Names) {
      admin2Select.items().reset(admin2Names);
    });
  } else {
    admin2Select.items().reset([]); // Clear if no state selected
  }
}
// Create a dropdown for topographic products.
var productSelect = ui.Select({
  items: ['Elevation', 'Slope', 'Aspect', 'Hillshade'],
  placeholder: 'Select a topographic product',
  onChange: function(value) {
    updateMapAndDisplay();
  },
  style: {stretch: 'horizontal', margin: '5px 0'}
});
controlPanel.add(ui.Label('Topographic Product:', {fontWeight: 'bold', color: '#4682b4', fontSize: '15px'})); // Label styling
controlPanel.add(productSelect);
// Create clear results button with improved styling.
var clearResultsButton = ui.Button({
  label: '🗑️ Clear All', // Added an emoji
  onClick: function() {
    clearAllAppLayers(); // Execute the layer clearing function.
    // Reset all UI dropdowns to their initial, unselected states.
    aoi = null;
    currentCountryFilter = null;
    currentStateFilter = null;
    countrySelect.setValue(null, false);
    stateSelect.items().reset([]);
    stateSelect.setPlaceholder('Select a State/Province');
    admin2Select.setValue(null, false);
    admin2Select.items().reset([]);
    admin2Select.setPlaceholder('Select a Region or District'); // Updated placeholder
    productSelect.setValue(null, false);
    legendPanel.clear();
    // Re-add the initial SRTM base elevation layer to the map.
    map.addLayer(srtm.select('elevation'), {min: 0, max: 5000, palette: ['006633', 'E5FFCC', '662A00', 'EE9900', 'EEE000', 'CCCC00', 'D4A200', 'FFC800']}, 'SRTM Elevation', false);
  },
  style: {
    stretch: 'horizontal',
    margin: '15px 0 5px 0', // More margin above
    backgroundColor: '#dc3545', // Bootstrap Danger Red
    color: 'red',
    fontWeight: 'bold',
    borderRadius: '5px'
  }
});
controlPanel.add(clearResultsButton);
var legendPanel = ui.Panel({
  style: {
    padding: '10px',
    border: '1px solid #add8e6', // LightBlue border
    borderRadius: '8px',
    margin: '10px 0',
    backgroundColor: '#ffffff' // White background
  }
});
controlPanel.add(ui.Label('🎨 Legend:', {fontWeight: 'bold', color: '#2f4f4f', fontSize: '16px'})); // Label styling
controlPanel.add(legendPanel);
// Add the control panel to the UI.
ui.root.insert(0, controlPanel);
// --- 2. Map Functionality ---
// Set up the map.
var map = ui.Map();
map.setOptions('HYBRID'); // Set a good base map
map.setCenter(78.9629, 20.5937, 5); // Center over India (initial zoom)
ui.root.widgets().set(1, map); // Set the map to occupy the main space
map.setLocked(false); // Allow map pan/zoom by user
// --- 3. Data and Processing ---
var srtm = ee.Image('USGS/SRTMGL1_003');
// Function to generate topographic products.
function generateProduct(productType) { 
  var vizParams;
  var product;
  // For all current topographic products, we use the SRTM image.
  var imageToUse = srtm;
  switch (productType) {
    case 'Elevation':
      product = imageToUse.select('elevation');
      vizParams = {min: 0, max: 5000, palette: ['#006633', '#E5FFCC', '#662A00', '#EE9900', '#EEE000', '#CCCC00', '#D4A200', '#FFC800']};
      break;
    case 'Slope':
      product = ee.Terrain.slope(imageToUse);
      vizParams = {min: 0, max: 60, palette: ['#00FF00', '#FFFF00', '#FF0000']}; // Green to red
      break;
    case 'Aspect':
      product = ee.Terrain.aspect(imageToUse);
      vizParams = {min: 0, max: 360, palette: [
        '#FF0000', '#FF4500', '#FFA500', '#FFFF00', '#9ACD32', '#008000', '#00CED1', '#4169E1', '#8A2BE2', '#EE82EE', '#FF00FF', '#FF1493', '#FF0000'
      ]}; // Full spectrum for aspect
      break;
    case 'Hillshade':
      product = ee.Terrain.hillshade(imageToUse);
      vizParams = {min: 0, max: 255, palette: ['#000000', '#FFFFFF']}; // Black to white
      break;
    default:
      return null;
  }
  return {product: product, vizParams: vizParams};
}
// --- 4. Visualization Parameters and Legend ---
function updateLegend(productType, vizParams) {
  legendPanel.clear();
  legendPanel.add(ui.Label('Legend:'));
  if (!vizParams || !vizParams.palette) {
    legendPanel.add(ui.Label('No legend available for this product.'));
    return;
  }
  var makeColorBar = function(palette) {
    var colorBar = ui.Thumbnail({
      image: ee.Image.pixelLonLat().select(0),
      params: {
        bbox: [0, 0, 1, 0.1],
        dimensions: '100x10',
        format: 'png',
        min: 0,
        max: 1,
        palette: palette,
      },
      style: {stretch: 'horizontal', margin: '0px 8px'},
    });
    return colorBar;
  };
  var makeLabels = function(min, max, unit) {
    var labels = ui.Panel({
      widgets: [
        ui.Label(min.toFixed(0), {margin: '4px 8px'}),
        ui.Label(max.toFixed(0) + (unit ? ' ' + unit : ''), {margin: '4px 8px', textAlign: 'right', stretch: 'horizontal'})
      ],
      layout: ui.Panel.Layout.flow('horizontal')
    });
    return labels;
  };
  // Add specific labels for each product type
  if (productType === 'Elevation') {
    legendPanel.add(makeColorBar(vizParams.palette));
    legendPanel.add(makeLabels(vizParams.min, vizParams.max, 'm'));
  } else if (productType === 'Slope') {
    legendPanel.add(makeColorBar(vizParams.palette));
    legendPanel.add(makeLabels(vizParams.min, vizParams.max, 'degrees'));
  } else if (productType === 'Aspect') {
    legendPanel.add(ui.Label('0° (N) -> 360° (N)', {fontSize: '11px', color: '#555'})); // Smaller, muted label
    legendPanel.add(makeColorBar(vizParams.palette));
    legendPanel.add(makeLabels(0, 360, 'degrees'));
  } else if (productType === 'Hillshade') {
    legendPanel.add(makeColorBar(vizParams.palette));
    legendPanel.add(makeLabels(0, 255, ''));
    legendPanel.add(ui.Label('0 (Shadow) to 255 (Illuminated)', {fontSize: '11px', color: '#555'})); // Smaller, muted label
  }
}
// --- 5. Map Update and Display ---
function updateMapAndDisplay() { 
  clearAllAppLayers(); // Clear previous product layers on map
  var selectedProductType = productSelect.getValue();
  // Ensure a product is selected and AOI is defined.
  if (selectedProductType === null || aoi === null) {
    legendPanel.clear(); // Clear legend if no product or valid AOI
    return;
  }
  // Generate the product.
  var result = generateProduct(selectedProductType);
  if (!result) {
    return; // Exit if product generation failed
  }
  var product = result.product;
  var vizParams = result.vizParams;
  // Clip the product to AOI and add to map.
  var clippedProduct = product.clip(aoi);
  map.addLayer(clippedProduct, vizParams, selectedProductType + ' (AOI)');
  map.addLayer(aoi, {color: 'red', fillColor: '00000000'}, 'Selected AOI Border',false); // Add AOI border
  map.centerObject(aoi); // Zoom to the selected Admin2 region
  // Update legend.
  updateLegend(selectedProductType, vizParams);
}
// --- 6. Clear Results Functionality ---
/**
 * Removes a layer from the map by its display name.
 * This function handles both client-side string names and ee.String names.
 * @param {string} layerName The display name of the layer to remove.
 */
function removeLayerByName(layerName) {
  var layers = map.layers();
  // Iterate backwards to safely remove layers as we modify the collection.
  // Iterating backwards prevents issues with indices shifting after removal.
  for (var i = layers.length() - 1; i >= 0; i--) {
    var layer = layers.get(i);
    // Ensure layer and getName() method exist before proceeding.
    if (layer && typeof layer.getName === 'function') {
      var nameCandidate = layer.getName(); // This can be a string or an ee.String object.
      // Case 1: The layer's name is already a standard JavaScript string.
      if (typeof nameCandidate === 'string') {
        if (nameCandidate === layerName) {
          map.remove(layer);
          // Assuming layer names for app-added layers are unique,
          // we can stop after finding and removing the first match.
          return; 
        }
      } 
      // Case 2: The layer's name is an Earth Engine ee.String object.
      // It needs to be evaluated asynchronously to get its client-side string value.
      else if (nameCandidate && typeof nameCandidate.evaluate === 'function') {
        // Use an Immediately Invoked Function Expression (IIFE) to
        // capture the 'layer' variable for the asynchronous callback.
        // This ensures 'currentLayer' inside the callback refers to the
        // specific layer object from the current loop iteration,
        // not whatever 'layer' happens to be after the loop finishes.
        (function(currentLayer) {
            nameCandidate.evaluate(function(evaluatedName) {
                // Once the asynchronous evaluation returns the name,
                // compare it and remove the layer if it matches.
                if (evaluatedName === layerName) {
                    map.remove(currentLayer);
                }
            });
        })(layer); // Pass the 'layer' object from the current iteration to the IIFE.
      }
    }
  }
}
/**
 * Clears all application-specific layers from the map using their predefined names
 * and resets all relevant UI controls and global variables.
 */
function clearAllAppLayers() {
  // Loop through the list of known application layer names and remove them.
  APP_LAYER_NAMES.forEach(function(name) {
    removeLayerByName(name);
  });
}
// Attach the 'clearAllAppLayers' function to the 'Clear All' button's click event.
clearResultsButton.onClick(function() {
  clearAllAppLayers(); // Execute the layer clearing function.
  // Reset all UI dropdowns to their initial, unselected states.
  // Setting value to 'null' and 'false' for no onChange trigger.
  aoi = null; // Clear the Area of Interest geometry.
  currentCountryFilter = null; // Reset country filter.
  currentStateFilter = null; // Reset state filter.
  countrySelect.setValue(null, false);
  stateSelect.items().reset([]); // Clear options in the state dropdown.
  stateSelect.setPlaceholder('Select a State/Province'); // Reset placeholder.
  admin2Select.setValue(null, false);
  admin2Select.items().reset([]); // Clear options in the Admin2 dropdown.
  admin2Select.setPlaceholder('Select a Region or District'); // Updated placeholder
  productSelect.setValue(null, false); // Clear selected topographic product.
  legendPanel.clear(); // Clear the legend.
  // Re-add the initial SRTM base elevation layer to the map.
  // It's set to 'false' so it's initially hidden, providing context if needed later.
  map.addLayer(srtm.select('elevation'), {min: 0, max: 5000, palette: ['006633', 'E5FFCC', '662A00', 'EE9900', 'EEE000', 'CCCC00', 'D4A200', 'FFC800']}, 'SRTM Elevation', false);
});
// Initial setup: Add SRTM as a base layer when the script loads.
// This provides a default background elevation map that can be toggled.
map.addLayer(srtm.select('elevation'), {min: 0, max: 5000, palette: ['006633', 'E5FFCC', '662A00', 'EE9900', 'EEE000', 'CCCC00', 'D4A200', 'FFC800']}, 'SRTM Elevation', false);