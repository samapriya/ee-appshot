/*SRTM Data download for all districts of India*/
//Data Source Information
var DEM = ee.Image("USGS/SRTMGL1_003")
var India = ee.FeatureCollection("users/sachinbobbili/India_Dist");
//Areas of Interest/ Study Area Selection
// Change Area of Interest (AOI) district name (dtname) to get particular district
print(India.aggregate_array('dtname'));// See District Names in right side Console
var AOI = India.filter(ee.Filter.eq('dtname', 'Medak'));// Edit district name here, you may exact name of district in 
// Adding Data to desktop for visualization
Map.centerObject(AOI);// Zoom to AOI
var AOI_DEM = DEM.clip(AOI);// Cliping Data
Map.addLayer(AOI_DEM,  {'min':0,'max': 500,'palette': ["a0b8b5", "bf8e8e", "fffd99", 
                         "c1d48c", "dfc1eb", "f2b983", "cbf7fa", "94995c", "d791f2",
                         "f5e6a4", "b8e3d0", "e8c4b2"]}); //Edit colour,Max and Min Value(m) here
// Exporting Data to Drive
Export.image.toDrive({
  image: AOI_DEM,
  description: 'SRTM_DEM',//Change Name Here
  scale: 30,// max value is 30 m
  region: AOI,
  maxPixels: 1000000000 // increase if failed to store
})