var dataset = ee.FeatureCollection('NOAA/IBTrACS/v4');
// Define the range of seasons
var seasons = ee.List.sequence(1843, 2023).reverse();
// Transform the list of seasons into an array of objects for the dropdown
var seasonItems = ee.List(seasons).map(function(season) {
  var seasonInt = ee.Number(season).toInt();
  return {label: seasonInt.format(), value: seasonInt.format()};
}).getInfo();
// Create a dropdown widget for selecting the season
var seasonDropdown = ui.Select({
  items: seasonItems,
  placeholder: 'Select a Season',
  onChange: updateVisualization,
  style: {width: '200px'}
});
// Create a panel for the title and description
var headerPanel = ui.Panel({
  style: {
    padding: '16px',
    textAlign: 'center'
  }
});
var titleLabel = ui.Label({
  value: '🌀 Global Tropical Cyclone Tracks (1843-2023)',
  style: {
    fontSize: '20px',
    fontWeight: 'bold',
    margin: '0 0 8px 0'
  }
});
var descriptionLabel = ui.Label({
  value: 'Explore historical tropical cyclone tracks data from the NOAA IBTrACS dataset. Use the dropdown to visualize cyclone paths for different seasons.',
  style: {
    fontSize: '14px',
    margin: '0'
  }
});
headerPanel.add(titleLabel);
headerPanel.add(descriptionLabel);
// Create a main panel for controls (left side, full height)
var controlPanel = ui.Panel({
  widgets: [headerPanel, ui.Label('Select Season:', {fontWeight: 'bold', margin: '16px 0 4px 0'}), seasonDropdown],
  style: {
    position: 'top-left',
    padding: '8px',
    width: '300px',
    height: '100%',
   backgroundColor: '#f0f8ff' // Light Alice Blue
  }
});
ui.root.insert(0, controlPanel); // Insert control panel at the beginning of the UI root
// Create layers for points and tracks
var trackLayer = ui.Map.Layer(null, {color: 'red'}, 'Cyclone Tracks');
var pointLayer = ui.Map.Layer(null, {color: 'blue'}, 'Cyclone Points');
Map.layers().insert(0, trackLayer);
Map.layers().insert(1, pointLayer);
// Function to update the visualization based on the selected season
function updateVisualization(selectedSeason) {
  var selectedSeasonInt = ee.Number.parse(selectedSeason);
  var points = dataset.filter(ee.Filter.eq('SEASON', selectedSeasonInt));
  // Find all of the hurricane ids.
  var GetId = function(point) {
    return ee.Feature(point).get('SID');
  };
  var storm_ids = points.toList(5000).map(GetId).distinct();
  // Create a line for each hurricane.
  var lines = ee.FeatureCollection(storm_ids.map(function(storm_id) {
    var pts = points.filter(ee.Filter.eq('SID', ee.String(storm_id)));
    pts = pts.sort('ISO_TIME');
    var line = ee.Geometry.LineString(pts.geometry().coordinates());
    var feature = ee.Feature(line);
    return feature.set('SID', storm_id);
  }));
  trackLayer.setEeObject(lines);
  trackLayer.setName('Cyclone Tracks - Season ' + selectedSeason);
  pointLayer.setEeObject(points.style({
    pointSize: 2
  }));
  pointLayer.setName('Cyclone Points - Season ' + selectedSeason);
}
// Set initial map view
Map.setCenter(78.5,23.5, 4);
Map.setLocked(false, 4);
// Initialize the visualization with the latest season
var currentYear = new Date().getFullYear();
var initialSeason = Math.min(currentYear, 2023);
seasonDropdown.setValue(String(initialSeason));
updateVisualization(String(initialSeason));