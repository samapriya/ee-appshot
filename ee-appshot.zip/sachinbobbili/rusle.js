// Earth Engine Application for RUSLE Factor and Soil Loss Calculation
// --- Map and UI Setup ---
// Set a default map center (Hyderabad)
Map.setCenter(78.47, 17.38,10);
// Instruction label on the map
var instructionLabel = ui.Label({
  value: 'Draw a rectangle or polygon on the map to define your Area of Interest. Smaller AOI usually give better results.',
  style: {
    position: 'top-center',
    backgroundColor: '#FFFACD', // Light yellow background
    padding: '10px',
    fontWeight: 'bold',
    whiteSpace: 'pre',
    border: '1px solid #DAA520', // Goldenrod border
    color: '#8B0000' // Dark red text
  }
});
Map.add(instructionLabel);
var aoi; // Variable to store the drawn AOI
var legendAdded = false; // Flag to track if the legend has been added
// --- Drawing Tools ---
var drawingTools = Map.drawingTools();
drawingTools.setShown(true);
drawingTools.setDrawModes(['rectangle', 'polygon']); // you may change if you want
//----- Year Selection and analyze with selected year will work only after AOI ------------//
function onPolygonDrawnOrEdited(geometry) {
  aoi = geometry;
  Map.centerObject(aoi);
  yearSelect.setDisabled(false);
  analyzeButton.setDisabled(false);
  instructionLabel.setValue('AOI defined. Select a year and click "Analyze".');
  resultsPanel.clear(); // Clear previous messages/results
  resultsPanel.add(ui.Label({
    value: 'Analysis Results',
    style: {
      fontWeight: 'bold',
      fontSize: '14px',
      margin: '0 0 8px 0',
      color: '#333'
    }
  }));
  resultsPanel.add(ui.Label('Click "Analyze" to view results for the selected year.'));
}
// Register the drawing tool callbacks
drawingTools.onDraw(ui.util.debounce(onPolygonDrawnOrEdited, 500));
drawingTools.onEdit(ui.util.debounce(onPolygonDrawnOrEdited, 500));
/**
 * Function to reset map layers, drawn geometries, legend, and panel.
 * This is the robust reset method you provided.
 */
function resetMap() {
  // Clear drawing tools' layers
  drawingTools.layers().reset();
  drawingTools.setShape(null); // Ensure no shape is "active"
  // Clear all map layers
  Map.layers().reset();
  // Remove legend if it was added
  ui.root.widgets().forEach(function(widget) {
    if (widget.style().get('position') === 'bottom-right' && widget.widgets().get(0) && widget.widgets().get(0).getValue() === 'Soil Loss Severity (t/ha/yr)') {
      ui.root.remove(widget);
    }
  });
  if (legendAdded) {
    Map.widgets().reset(); // Remove all widgets from the map
    legendAdded = false;
  }
}
// --- UI Panel Setup (Main Control Panel) ---
var mainPanel = ui.Panel({
  style: {
    position: 'top-left',
    padding: '12px',
    width: '380px',
    border: '2px solid #4CAF50', // Green border
    backgroundColor: '#e8f5e9', // Light green background for the main panel
    stretch: 'vertical',
    borderRadius: '8px',
  }
});
ui.root.add(mainPanel);
// --- Application Title ---
var appTitle = ui.Label({
  value: '🌱 RUSLE Soil Loss Calculator',
  style: {
    fontWeight: 'bold',
    fontSize: '24px',
    color: '#1B5E20', // Dark green color
    textAlign: 'center',
    margin: '0 0 10px 0',
    backgroundColor: '#DCEDC8', // Lighter green background for title
    padding: '10px',
    borderRadius: '4px'
  }
});
mainPanel.add(appTitle);
// --- Section 1: AOI & Year Selection ---
var selectionSection = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    backgroundColor: 'white',
    padding: '10px',
    margin: '0 0 10px 0',
    border: '1px solid #c8e6c9', // Lighter green border
    borderRadius: '5px'
  }
});
selectionSection.add(ui.Label({
  value: 'Define Area & Select Year',
  style: {
    fontWeight: 'bold',
    fontSize: '16px',
    color: '#D32F2F', // Red color for section title
    margin: '0 0 8px 0',
  }
}));
selectionSection.add(ui.Label('Use the drawing tools on the map to define your Area of Interest (AOI). Once drawn, select a year below:'));
var years = ee.List.sequence(2000, 2023);
var yearSelect = ui.Select({
  items: years.getInfo().map(String),
  placeholder: 'Select a year',
  style: {
    margin: '10px 0 8px 0',
    stretch: 'horizontal',
    backgroundColor: '#F0F4C3' // Light yellow for select
  },
  disabled: true // Disabled until AOI is drawn
});
selectionSection.add(yearSelect);
var analyzeButton = ui.Button({
  label: 'Analyze with Selected Year',
  onClick: updateAnalysis,
  style: {
    margin: '0',
    color: 'blue', 
    fontWeight: 'bold',
    stretch: 'horizontal',
    padding: '8px',
    borderRadius: '5px'
  },
  disabled: true // Initially disabled
});
selectionSection.add(analyzeButton);
mainPanel.add(selectionSection);
// --- Section 2: Analysis Results ---
var resultsSection = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    backgroundColor: 'white',
    padding: '10px',
    margin: '0',
    border: '1px solid #c8e6c9', // Lighter green border
    borderRadius: '5px'
  }
});
resultsSection.add(ui.Label({
  value: 'Analysis Results',
  style: {
    fontWeight: 'bold',
    fontSize: '16px',
    color: '#D32F2F', // Red color for section title
    margin: '0 0 8px 0',
  }
}));
var resultsPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    padding: '8px',
    margin: '0',
    border: '1px solid #e0e0e0',
    borderRadius: '3px'
  }
});
resultsPanel.add(ui.Label('Please draw an AOI and select a year to view analysis results.')); // Initial placeholder
resultsSection.add(resultsPanel);
mainPanel.add(resultsSection);
// --- RUSLE Factor Calculations ---
/**
 * Calculates the LS (Length-Slope) Factor.
 * This is a simplified approach; a more rigorous calculation would involve flow accumulation.
 * @param {ee.Image} dem Digital Elevation Model.
 * @param {ee.Geometry} aoi The Area of Interest to clip the result.
 * @returns {ee.Image} The calculated LS factor image.
 */
function calculateLSFactor(dem, aoi) {
  var srtmSlope = ee.Terrain.slope(dem); // Slope in degrees
  var s = srtmSlope.multiply(Math.PI / 180); // Slope in radians
  // L factor (using common simplified formula - not standard, but for demonstration)
  var L = ee.Image(1.4).multiply(s.divide(s.add(0.017))).add(1).rename('L');
  // S factor (using Wischmeier and Smith, 1978, as commonly implemented)
  var S_calc = ee.Image(0.0).rename('S');
  S_calc = S_calc.where(srtmSlope.lt(5.14), srtmSlope.multiply(0.17453).sin().multiply(10.8).add(0.03)); // slope < 9% (approx 5.14 deg)
  S_calc = S_calc.where(srtmSlope.gte(5.14), srtmSlope.multiply(0.17453).sin().multiply(16.8).subtract(0.50)); // slope >= 9%
  var lsFactor = L.multiply(S_calc).rename('LS');
  return lsFactor.clip(aoi); // Clip LS factor to AOI
}
/**
 * Calculates the C (Cover-Management) Factor from NDVI.
 * Reference: https://www.researchgate.net/publication/282367180_Estimation_of_C-Factor_Using_NDVI_for_Soil_Erosion_Modeling_in_Central_Part_of_Nepal
 * @param {ee.Image} ndviImage Scaled NDVI image (0-1).
 * @param {ee.Geometry} aoi The Area of Interest to clip the result.
 * @returns {ee.Image} The calculated C factor image.
 */
var calculateCFactor = function(ndviImage, aoi) {
  // Simple linear relationship: C = 1 - NDVI
  var cFactor = ndviImage.multiply(-1.0).add(1.0);
  // Clamp C-factor to be between 0 and 1.
  cFactor = cFactor.max(0.0).min(1.0);
  return cFactor.rename('C_Factor').clip(aoi); // Clip C factor to AOI
};
/**
 * Calculates the P (Support Practice) Factor from LULC.
 * Reference values are indicative and may need adjustment based on local conditions.
 * MODIS Land Cover Type 1 (IGBP classification) is used.
 * @param {ee.Image} lulcImage Land Use/Land Cover image.
 * @param {ee.Geometry} aoi The Area of Interest to clip the result.
 * @returns {ee.Image} The calculated P factor image.
 */
var calculatePFactor = function(lulcImage, aoi) {
  var lulc = lulcImage.select('LC_Type1');
  // Define P-factor values for different LULC classes.
  var pFactor = lulc
    .eq(0).multiply(0.0) // Water - effectively no erosion, P=0
    .add(lulc.eq(1).multiply(0.05)) // Evergreen Needleleaf Forests
    .add(lulc.eq(2).multiply(0.05)) // Evergreen Broadleaf Forests
    .add(lulc.eq(3).multiply(0.05)) // Deciduous Needleleaf Forests
    .add(lulc.eq(4).multiply(0.05)) // Deciduous Broadleaf Forests
    .add(lulc.eq(5).multiply(0.05)) // Mixed Forests
    .add(lulc.eq(6).multiply(0.1)) // Closed Shrublands
    .add(lulc.eq(7).multiply(0.15)) // Open Shrublands
    .add(lulc.eq(8).multiply(0.1)) // Woody Savannas
    .add(lulc.eq(9).multiply(0.1)) // Savannas
    .add(lulc.eq(10).multiply(0.2)) // Grasslands
    .add(lulc.eq(11).multiply(0.0)) // Permanent Wetlands - effectively no erosion, P=0
    .add(lulc.eq(12).multiply(0.4)) // Croplands - higher P factor due to cultivation practices
    .add(lulc.eq(13).multiply(0.01)) // Urban and Built-up - very low P factor (impervious surfaces)
    .add(lulc.eq(14).multiply(0.3)) // Cropland/Natural Vegetation Mosaics
    .add(lulc.eq(15).multiply(0.0)) // Snow and Ice - effectively no erosion, P=0
    .add(lulc.eq(16).multiply(1.0)); // Barren - highest P factor (no vegetation or conservation practices)
  pFactor = pFactor.unmask(1.0);
  return pFactor.rename('P_Factor').clip(aoi); // Clip P factor to AOI
};
/**
 * Categorizes soil loss into severity classes and creates a legend.
 * @param {ee.Image} soilLossImage The calculated soil loss image in tons/ha/year.
 */
function createSoilLossSeverityMapAndLegend(soilLossImage) {
  // Soil loss categories (t/ha/year)
  var veryLow = 5;
  var low = 15;
  var moderate = 45;
  var high = 75;
  var soilLossSeverity = ee.Image(0).rename('severity');
  soilLossSeverity = soilLossSeverity.where(soilLossImage.gt(high), 5);
  soilLossSeverity = soilLossSeverity.where(soilLossImage.gt(moderate).and(soilLossImage.lte(high)), 4);
  soilLossSeverity = soilLossSeverity.where(soilLossImage.gt(low).and(soilLossImage.lte(moderate)), 3);
  soilLossSeverity = soilLossSeverity.where(soilLossImage.gt(veryLow).and(soilLossImage.lte(low)), 2);
  soilLossSeverity = soilLossSeverity.where(soilLossImage.lte(veryLow), 1);
  // Visualisation parameters for soil loss severity
  var severityVis = {
    min: 1,
    max: 5,
    palette: ['#006400', '#ADFF2F', '#FFFF00', '#FFA500', '#FF0000'] // Dark Green, Green-Yellow, Yellow, Orange, Red
  };
  Map.addLayer(soilLossSeverity.clip(aoi), severityVis, 'Analysis: Soil Loss Severity ');
  // Create a legend
  var legend = ui.Panel({
    style: {
      position: 'bottom-right',
      padding: '8px 15px',
      backgroundColor: 'white',
      border: '1px solid #ccc',
      borderRadius: '5px',
    }
  });
  var legendTitle = ui.Label({
    value: 'Soil Loss Severity (t/ha/yr)',
    style: {
      fontWeight: 'bold',
      fontSize: '14px',
      margin: '0 0 4px 0',
      padding: '0',
      color: '#333'
    }
  });
  legend.add(legendTitle);
  var makeRow = function(color, name, range) {
    var colorBox = ui.Label({
      style: {
        backgroundColor: color,
        padding: '8px',
        margin: '0 0 4px 0',
        border: '1px solid #ccc',
        borderRadius: '3px'
      }
    });
    var description = ui.Label({
      value: name + ' (' + range + ')',
      style: {
        margin: '0 0 4px 6px',
        fontSize: '11px'
      }
    });
    return ui.Panel({
      widgets: [colorBox, description],
      layout: ui.Panel.Layout.Flow('horizontal')
    });
  };
  legend.add(makeRow('#006400', 'Very Low', '0 - ' + veryLow));
  legend.add(makeRow('#ADFF2F', 'Low', (veryLow + ' - ' + low)));
  legend.add(makeRow('#FFFF00', 'Moderate', (low + ' - ' + moderate)));
  legend.add(makeRow('#FFA500', 'High', (moderate + ' - ' + high)));
  legend.add(makeRow('#FF0000', 'Extreme', '>' + high));
  Map.add(legend);
  legendAdded = true; // Set the flag
}
/**
 * Performs the RUSLE factor analysis for the selected AOI and year.
 */
function updateAnalysis() {
  var selectedYear = yearSelect.getValue();
  if (!aoi || !selectedYear) {
    resultsPanel.clear();
    resultsPanel.add(ui.Label({
      value: 'Analysis Results',
      style: {
        fontWeight: 'bold',
        fontSize: '14px',
        margin: '0 0 8px 0',
        color: '#333'
      }
    }));
    resultsPanel.add(ui.Label('Please ensure AOI is drawn and a year is selected.'));
    return;
  }
  resultsPanel.clear();
  resultsPanel.add(ui.Label({
    value: 'Analysis Results for ' + selectedYear,
    style: {
      fontWeight: 'bold',
      fontSize: '16px',
      margin: '0 0 8px 0',
      color: '#333'
    }
  }));
  resultsPanel.add(ui.Label('Processing... Please wait. This may take a moment. ⏳', {
    color: '#007BFF',
    fontWeight: 'bold'
  }));
  // Use the resetMap function to clear all layers and drawing tools before new analysis
  resetMap(); // This will clear existing layers and the drawn AOI
  // Add the drawn AOI back as a layer for visibility during analysis
  // The drawingTools.layers().add(aoi) is implicitly how the AOI is added.
  // If you want a *separate* visible layer for the AOI, add it here.
  // This will ensure it's cleared by resetMap next time.
  Map.addLayer(aoi, {
    color: 'blue'
  }, 'Drawn AOI', true, 0.5); // Add AOI back, partially transparent
  var startDate = ee.Date.fromYMD(ee.Number.parse(selectedYear), 1, 1);
  var endDate = startDate.advance(1, 'year');
  // Load SRTM DEM and calculate LS Factor
  var srtm = ee.Image('USGS/SRTMGL1_003');
  var lsFactor = calculateLSFactor(srtm, aoi); // Pass AOI to function
  var visParamsLS = {
    min: 0,
    max: 10,
    palette: ['006600', '00ff00', 'ffff00', 'ff9900', 'ff0000']
  };
  Map.addLayer(lsFactor, visParamsLS, 'Analysis: LS Factor');
  var statsLS = lsFactor.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: aoi,
    scale: 30,
    maxPixels: 1e9
  });
  // K Factor (Soil Erodibility Factor)
  var soil = ee.Image("OpenLandMap/SOL/SOL_TEXTURE-CLASS_USDA-TT_M/v02").select('b0').clip(aoi);
  var K = soil.expression(
    "(b('b0') > 11) ? 0.0053" +
    ": (b('b0') > 10) ? 0.0170" +
    ": (b('b0') > 9) ? 0.045" +
    ": (b('b0') > 8) ? 0.050" +
    ": (b('b0') > 7) ? 0.0499" +
    ": (b('b0') > 6) ? 0.0394" +
    ": (b('b0') > 5) ? 0.0264" +
    ": (b('b0') > 4) ? 0.0423" +
    ": (b('b0') > 3) ? 0.0394" +
    ": (b('b0') > 2) ? 0.036" +
    ": (b('b0') > 1) ? 0.0341" +
    ": (b('b0') > 0) ? 0.0288" +
    ": 0"
  ).rename('K').clip(aoi); // Ensure K factor is clipped
  Map.addLayer(K, {
    min: 0,
    max: 0.06,
    palette: ['a52508', 'ff3818', 'fbff18', '25cdff', '2f35ff', '0b2dab']
  }, 'Analysis: K Factor');
  var statsK = K.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: aoi,
    scale: 250,
    maxPixels: 1e9
  });
  // C Factor (Cover-Management) from MODIS NDVI
  var modisNdviCollection = ee.ImageCollection("MODIS/061/MOD13A1");
  var ndviImage = modisNdviCollection
    .filterDate(startDate, endDate)
    .filterBounds(aoi)
    .select('NDVI')
    .mean();
  if (ndviImage.bandNames().length().getInfo() === 0) {
    resultsPanel.add(ui.Label('Error: No NDVI data found for the selected year in the AOI.'));
    return;
  }
  var scaledNdvi = ndviImage.divide(10000); // Do not clip here, clip inside calculateCFactor
  var cFactor = calculateCFactor(scaledNdvi, aoi); // Pass AOI to function
  var cFactorVis = {
    min: 0,
    max: 1,
    palette: ['red', 'orange', 'yellow', 'lightgreen', 'darkgreen']
  };
  Map.addLayer(cFactor, cFactorVis, 'Analysis: C Factor (' + selectedYear + ')');
  var statsC = cFactor.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: aoi,
    scale: 500,
    maxPixels: 1e9
  });
  // P Factor (Support Practice) from MODIS LULC
  var modisLulcCollection = ee.ImageCollection("MODIS/061/MCD12Q1");
  var lulcImage = modisLulcCollection.select('LC_Type1')
    .filterDate(startDate, endDate)
    .filterBounds(aoi)
    .first();
  if (lulcImage.bandNames().length().getInfo() === 0) {
    resultsPanel.add(ui.Label('Error: No LULC data found for the selected year in the AOI.'));
    return;
  }
  var pFactor = calculatePFactor(lulcImage, aoi); // Pass AOI to function
  var pFactorVis = {
    min: 0,
    max: 1,
    palette: ['white', 'grey', 'brown', 'red']
  };
  Map.addLayer(pFactor, pFactorVis, 'Analysis: P Factor (' + selectedYear + ')');
  var statsP = pFactor.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: aoi,
    scale: 500,
    maxPixels: 1e9
  });
  // R Factor (Rainfall Erosivity) from CHIRPS
  var chirps = ee.ImageCollection('UCSB-CHG/CHIRPS/PENTAD');
  var annualPrecipitation = chirps.filter(ee.Filter.date(startDate, endDate))
    .sum()
    .rename('Rainfall');
  var clippedAnnualPrecipitation = annualPrecipitation.clip(aoi); // Ensure precipitation is clipped
  // R = 0.363 * Annual Precipitation (mm) + 79
  var rFactorImage = clippedAnnualPrecipitation.multiply(0.363).add(79).rename('R_Factor');
  var rFactor = rFactorImage.clip(aoi); // Ensure R factor is clipped
  var visParamsRFactor = {
    min: 200,
    max: 7000,
    palette: ['#FFF5EB', '#FEE6CE', '#FDD0A2', '#FDAE6B', '#FD8D3C', '#F16913', '#D94801', '#A63603', '#7F2704']
  };
  Map.addLayer(rFactor, visParamsRFactor, 'Analysis: R Factor (' + selectedYear + ')');
  var statsRFactor = rFactor.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: aoi,
    scale: 5566,
    maxPixels: 1e9
  });
  var visParamsRainfall = {
    min: 100,
    max: 1000,
    palette: ["#E0FFFF", "#D0F0FF", "#B0E0FF", "#9ACEEB", "#87CEFA", "#6495ED", "#4682B4", "#2E86C1", "#007BA7", "#006B8F"]
  };
  Map.addLayer(clippedAnnualPrecipitation, visParamsRainfall, 'Analysis: Rainfall (' + selectedYear + ')');
  var statsRainfall = clippedAnnualPrecipitation.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: aoi,
    scale: 5566,
    maxPixels: 1e9
  });
  // --- Calculate Annual Soil Loss (A) ---
  // Reproject all factors to a common scale (e.g., 30m from SRTM) and clip to AOI
  // Clipping individually in functions makes the images inherently restricted.
  var commonScale = 30;
  var rainfallResampled = clippedAnnualPrecipitation.reproject({
    crs: clippedAnnualPrecipitation.projection().crs(),
    scale: commonScale
  });
  var rFactorResampled = rFactor.reproject({
    crs: rFactor.projection().crs(),
    scale: commonScale
  });
  var kFactorResampled = K.reproject({
    crs: K.projection().crs(),
    scale: commonScale
  });
  var lsFactorResampled = lsFactor.reproject({
    crs: lsFactor.projection().crs(),
    scale: commonScale
  });
  var cFactorResampled = cFactor.reproject({
    crs: cFactor.projection().crs(),
    scale: commonScale
  });
  var pFactorResampled = pFactor.reproject({
    crs: pFactor.projection().crs(),
    scale: commonScale
  });
  // Calculate A = R * K * LS * C * P
  var annualSoilLoss = rFactorResampled
    .multiply(kFactorResampled)
    .multiply(lsFactorResampled)
    .multiply(cFactorResampled)
    .multiply(pFactorResampled)
    .rename('Annual_Soil_Loss_t_ha_yr')
    .clip(aoi); // Explicitly clip final soil loss map to AOI
  // Visualization for Annual Soil Loss (A)
  var soilLossVis = {
    min: 0,
    max: 50,
    palette: ['#00008B', '#ADD8E6', '#FFFF00', '#FFA500', '#FF0000', '#8B0000']
  };
  Map.addLayer(annualSoilLoss, soilLossVis, 'Analysis: Annual Soil Loss (t/ha/yr) (' + selectedYear + ')');
  // Calculate average annual soil loss for the AOI
  var statsAnnualSoilLoss = annualSoilLoss.reduceRegion({
    reducer: ee.Reducer.mean(),
    geometry: aoi,
    scale: commonScale,
    maxPixels: 1e9
  });
  // Display results in the panel asynchronously
  resultsPanel.clear();
  resultsPanel.add(ui.Label({
    value: '📊 Analysis Results for ' + selectedYear,
    style: {
      fontWeight: 'bold',
      fontSize: '16px',
      margin: '0 0 8px 0',
      color: '#333'
    }
  }));
  statsRainfall.evaluate(function(statsResult, error) {
    if (error) {
      resultsPanel.add(ui.Label('❌ Error calculating Rainfall: ' + error, {
        color: 'red'
      }));
      console.error('Error Rainfall:', error);
    } else {
      resultsPanel.add(ui.Label('🌧️ Avg Rainfall: ' + (statsResult.Rainfall ? statsResult.Rainfall.toFixed(2) + ' mm' : 'No data'), {
        color: '#0056b3'
      }));
    }
  });
  statsRFactor.evaluate(function(statsResult, error) {
    if (error) {
      resultsPanel.add(ui.Label('❌ Error calculating R Factor: ' + error, {
        color: 'red'
      }));
      console.error('Error R Factor:', error);
    } else {
      resultsPanel.add(ui.Label('💧 Avg R Factor: ' + (statsResult.R_Factor ? statsResult.R_Factor.toFixed(2) + ' MJ·mm·ha⁻¹·hr⁻¹·yr⁻¹' : 'No data'), {
        color: '#0056b3'
      }));
    }
  });
  statsLS.evaluate(function(statsResult, error) {
    if (error) {
      resultsPanel.add(ui.Label('❌ Error calculating LS Factor: ' + error, {
        color: 'red'
      }));
      console.error('Error LS Factor:', error);
    } else {
      resultsPanel.add(ui.Label('⛰️ Avg LS Factor: ' + (statsResult.LS ? statsResult.LS.toFixed(2) : 'No data'), {
        color: '#0056b3'
      }));
    }
  });
  statsK.evaluate(function(statsResult, error) {
    if (error) {
      resultsPanel.add(ui.Label('❌ Error calculating K Factor: ' + error, {
        color: 'red'
      }));
      console.error('Error K Factor:', error);
    } else {
      resultsPanel.add(ui.Label('🏜️ Avg K Factor: ' + (statsResult.K ? statsResult.K.toFixed(4) + ' t·ha⁻¹·MJ⁻¹·mm⁻¹' : 'No data'), {
        color: '#0056b3'
      }));
    }
  });
  statsC.evaluate(function(statsResult, error) {
    if (error) {
      resultsPanel.add(ui.Label('❌ Error calculating C Factor: ' + error, {
        color: 'red'
      }));
      console.error('Error C Factor:', error);
    } else {
      resultsPanel.add(ui.Label('🌿 Avg C Factor (Cover-Management): ' + (statsResult.C_Factor ? statsResult.C_Factor.toFixed(2) : 'No data'), {
        color: '#0056b3'
      }));
    }
  });
  statsP.evaluate(function(statsResult, error) {
    if (error) {
      resultsPanel.add(ui.Label('❌ Error calculating P Factor: ' + error, {
        color: 'red'
      }));
      console.error('Error P Factor:', error);
    } else {
      resultsPanel.add(ui.Label('🚜 Avg P Factor (Support Practice): ' + (statsResult.P_Factor ? statsResult.P_Factor.toFixed(2) : 'No data'), {
        color: '#0056b3'
      }));
    }
  });
  statsAnnualSoilLoss.evaluate(function(statsResult, error) {
    if (error) {
      resultsPanel.add(ui.Label('❌ Error calculating Annual Soil Loss: ' + error, {
        color: 'red'
      }));
      console.error('Error Annual Soil Loss:', error);
    } else {
      var soilLoss_t_ha_yr = statsResult.Annual_Soil_Loss_t_ha_yr;
      var soilLoss_tons_acre_yr = soilLoss_t_ha_yr ? soilLoss_t_ha_yr * 0.404686 : null;
      resultsPanel.add(ui.Label('Estimated Average Annual Soil Loss (A):', {
        fontWeight: 'bold',
        color: '#4CAF50'
      }));
      resultsPanel.add(ui.Label('➡️ ' + (soilLoss_t_ha_yr ? soilLoss_t_ha_yr.toFixed(2) + ' t/ha/yr' : 'No data')));
      resultsPanel.add(ui.Label('➡️ ' + (soilLoss_tons_acre_yr ? soilLoss_tons_acre_yr.toFixed(2) + ' tons/acre/yr' : 'No data')));
      if (soilLoss_t_ha_yr !== null) {
        var severityText = 'N/A';
        var severityColor = '#333';
        if (soilLoss_t_ha_yr <= 5) {
          severityText = 'Very Low';
          severityColor = '#006400';
        } else if (soilLoss_t_ha_yr <= 15) {
          severityText = 'Low';
          severityColor = '#ADFF2F';
        } else if (soilLoss_t_ha_yr <= 45) {
          severityText = 'Moderate';
          severityColor = '#FFA500';
        } else if (soilLoss_t_ha_yr <= 75) {
          severityText = 'High';
          severityColor = '#FF4500';
        } else {
          severityText = 'Extreme';
          severityColor = '#FF0000';
        }
        resultsPanel.add(ui.Label('⚠️ Severity: ' + severityText, {
          fontWeight: 'bold',
          color: severityColor,
          fontSize: '14px'
        }));
      }
    }
  });
  // Add the soil loss severity map and legend
  createSoilLossSeverityMapAndLegend(annualSoilLoss);
}
/**
 * Resets the application to its initial state, clearing AOI, analysis results, and map layers.
 */
function resetAnalysis() {
  // Use the robust resetMap function to clear all map layers and drawing tools
  resetMap();
  aoi = null; // Clear the AOI variable
  // Reset UI elements
  yearSelect.setDisabled(true);
  yearSelect.setValue(null); // Clear selected year
  analyzeButton.setDisabled(true);
  instructionLabel.setValue('Draw a rectangle or polygon on the map to define your Area of Interest. Smaller AOI usually give better results.');
  resultsPanel.clear();
  resultsPanel.add(ui.Label('Please draw an AOI and select a year to view analysis results.'));
}
// Add Reset Analysis Button
var resetButton = ui.Button({
  label: '🔄 Reset Analysis',
  onClick: resetAnalysis,
  style: {
    margin: '10px 0 0 0',
    color: 'blue', 
    fontWeight: 'bold',
    stretch: 'horizontal',
    padding: '8px',
    borderRadius: '5px'
  }
});
mainPanel.add(resetButton); // Add the reset button to the main panel
// Initial setup: Ensure buttons and select are disabled
yearSelect.setDisabled(true);
analyzeButton.setDisabled(true);