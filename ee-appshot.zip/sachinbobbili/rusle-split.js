// Earth Engine Application: RUSLE Soil Loss Calculator (Enhanced & Simplified)
// --- 1. Global Variables & UI Setup ---
var aoi = null; // Area of Interest, set after drawing
var commonScale = 30; // Common resolution for factor calculations
// Map panels
var leftMap = ui.Map();
var rightMap = ui.Map();
leftMap.setControlVisibility({zoomControl: true, layerList: false, scaleControl: true, mapTypeControl: false, fullscreenControl: false, drawingToolsControl: false});
rightMap.setControlVisibility({zoomControl: true, layerList: false, scaleControl: true, mapTypeControl: false, fullscreenControl: false, drawingToolsControl: false}); // Removed zoom controls here
// Link maps for synchronized viewing
var linker = ui.Map.Linker([leftMap, rightMap]);
// Create initial split panel
var splitPanel = ui.SplitPanel({
  firstPanel: leftMap,
  secondPanel: rightMap,
  wipe: true,
  orientation: 'horizontal',
  style: {
    stretch: 'both'
  }
});
ui.root.widgets().reset([splitPanel]);
// Main control panel
var mainPanel = ui.Panel({
  style: {
    position: 'top-left',
    padding: '12px',
    width: '380px',
    border: '2px solid #4CAF50',
    backgroundColor: '#e8f5e9',
    stretch: 'vertical',
    borderRadius: '8px',
  }
});
ui.root.add(mainPanel);
// --- 2. UI Elements ---
// App Title
mainPanel.add(ui.Label({
  value: '🌱 RUSLE Soil Loss Calculator',
  style: {
    fontWeight: 'bold',
    fontSize: '24px',
    color: '#1B5E20',
    textAlign: 'center',
    margin: '0 0 10px 0',
    backgroundColor: '#DCEDC8',
    padding: '10px',
    borderRadius: '4px'
  }
}));
// Instructions for drawing AOI
var instructionLabel = ui.Label({
  value: '1. Draw an Area of Interest (AOI) on the map.\n2. Select two years for comparison.\n3. Click "Analyze".',
  style: {
    backgroundColor: '#FFFACD',
    padding: '10px',
    fontWeight: 'bold',
    whiteSpace: 'pre',
    border: '1px solid #DAA520',
    color: '#8B0000',
    margin: '0 0 10px 0'
  }
});
mainPanel.add(instructionLabel);
// Year selection dropdowns (client-side array for speed)
var years = [];
for (var i = 2001; i <= 2023; i++) {
  years.push(String(i));
}
var yearSelectLeft = ui.Select({
  items: years,
  placeholder: 'Select Year (Left)',
  value: '2001',
  disabled: false,
  style: { stretch: 'horizontal' }
});
var yearSelectRight = ui.Select({
  items: years,
  placeholder: 'Select Year (Right)',
  value: '2023',
  disabled: false,
  style: { stretch: 'horizontal' }
});
// Add year selectors directly to maps, using panels for positioning
leftMap.add(ui.Panel(yearSelectLeft, ui.Panel.Layout.flow('horizontal'), {
  position: 'top-left',
  margin: '8px',
  width: '120px'
}));
rightMap.add(ui.Panel(yearSelectRight, ui.Panel.Layout.flow('horizontal'), {
  position: 'top-right',
  margin: '8px',
  width: '120px'
}));
// Analysis button
var analyzeButton = ui.Button({
  label: 'Analyze Selected Years',
  onClick: updateAnalysis,
  style: {
    margin: '0',
    color: 'blue',
    fontWeight: 'bold',
    stretch: 'horizontal',
    padding: '8px',
    borderRadius: '5px'
  },
  disabled: true
});
mainPanel.add(analyzeButton);
// Results display panel
var resultsPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    padding: '8px',
    margin: '10px 0 0 0',
    border: '1px solid #e0e0e0',
    borderRadius: '3px'
  }
});
resultsPanel.add(ui.Label('Please draw an AOI and click "Analyze" to view analysis results.'));
mainPanel.add(resultsPanel);
// Reset button
var resetButton = ui.Button({
  label: '🔄 Reset Analysis',
  onClick: resetAnalysis,
  style: {
    margin: '10px 0 0 0',
    color: 'blue',
    fontWeight: 'bold',
    stretch: 'horizontal',
    padding: '8px',
    borderRadius: '5px'
  }
});
mainPanel.add(resetButton);
// --- 3. Drawing Tools & Callbacks ---
var drawingTools = leftMap.drawingTools();
drawingTools.setShown(true);
drawingTools.setDrawModes(['rectangle', 'polygon']);
drawingTools.onDraw(ui.util.debounce(function(geometry) {
  aoi = geometry;
  leftMap.centerObject(aoi);
  analyzeButton.setDisabled(false);
  instructionLabel.setValue('AOI defined. Select years and click "Analyze".'); // Simplified message
  resultsPanel.clear();
  resultsPanel.add(ui.Label({
    value: 'Analysis Results',
    style: {
      fontWeight: 'bold',
      fontSize: '14px',
      margin: '0 0 8px 0',
      color: '#333'
    }
  }));
  resultsPanel.add(ui.Label('Click "Analyze" to view results for the selected years.'));
}, 500));
drawingTools.onEdit(ui.util.debounce(function(geometry) {
  aoi = geometry;
  leftMap.centerObject(aoi);
  analyzeButton.setDisabled(false);
  instructionLabel.setValue('AOI updated. Re-select years or click "Analyze".'); // Simplified message
  resultsPanel.clear();
  resultsPanel.add(ui.Label({
    value: 'Analysis Results',
    style: {
      fontWeight: 'bold',
      fontSize: '14px',
      margin: '0 0 8px 0',
      color: '#333'
    }
  }));
  resultsPanel.add(ui.Label('Click "Analyze" to view results for the selected years.'));
}, 500));
// --- 4. RUSLE Factor Calculation Functions ---
/**
 * Helper function to safely get the first image or mean from a collection.
 * Returns a default image if the collection is empty.
 * @param {ee.ImageCollection} collection The input image collection.
 * @param {string} method 'mean' or 'first' or 'sum'.
 * @param {ee.Image} defaultImage The image to return if collection is empty.
 * @param {string} warningMsg The warning message to print if collection is empty.
 * @returns {ee.Image} The image from collection or default.
 */
var getCollectionImage = function(collection, method, defaultImage, warningMsg) {
  if (collection.size().getInfo() === 0) {
    print('Warning:', warningMsg);
    return defaultImage;
  } else {
    if (method === 'mean') return collection.mean();
    if (method === 'first') return collection.first();
    if (method === 'sum') return collection.sum();
    // Default to first if method is unrecognized
    return collection.first();
  }
};
/**
 * Calculates the LS (Length-Slope) Factor.
 * @param {ee.Image} dem Digital Elevation Model.
 * @param {ee.Geometry} aoi The Area of Interest to clip the result.
 * @returns {ee.Image} The calculated LS factor image.
 */
var calculateLSFactor = function(dem, aoi) {
  var srtmSlope = ee.Terrain.slope(dem); // Slope in degrees
  var s = srtmSlope.multiply(Math.PI / 180); // Slope in radians
  // L factor (simplified)
  var L = ee.Image(1.4).multiply(s.divide(s.add(0.017))).add(1).rename('L');
  // S factor (Wischmeier and Smith, 1978)
  var S_calc = ee.Image(0.0).rename('S');
  S_calc = S_calc.where(srtmSlope.lt(5.14), srtmSlope.multiply(0.17453).sin().multiply(10.8).add(0.03));
  S_calc = S_calc.where(srtmSlope.gte(5.14), srtmSlope.multiply(0.17453).sin().multiply(16.8).subtract(0.50));
  return L.multiply(S_calc).rename('LS').clip(aoi).reproject({
    crs: dem.projection().crs(),
    scale: commonScale
  });
};
/**
 * Calculates the K (Soil Erodibility) Factor from OpenLandMap soil texture.
 * @param {ee.Image} soil Image with 'b0' band for texture class.
 * @param {ee.Geometry} aoi The Area of Interest.
 * @returns {ee.Image} The calculated K factor image.
 */
var calculateKFactor = function(soil, aoi) {
  return soil.expression(
    "(b('b0') > 11) ? 0.0053" +
    ": (b('b0') > 10) ? 0.0170" +
    ": (b('b0') > 9) ? 0.045" +
    ": (b('b0') > 8) ? 0.050" +
    ": (b('b0') > 7) ? 0.0499" +
    ": (b('b0') > 6) ? 0.0394" +
    ": (b('b0') > 5) ? 0.0264" +
    ": (b('b0') > 4) ? 0.0423" +
    ": (b('b0') > 3) ? 0.0394" +
    ": (b('b0') > 2) ? 0.036" +
    ": (b('b0') > 1) ? 0.0341" +
    ": (b('b0') > 0) ? 0.0288" +
    ": 0"
  ).rename('K').clip(aoi).reproject({
    crs: soil.projection().crs(),
    scale: commonScale
  });
};
/**
 * Calculates the C (Cover-Management) Factor from NDVI.
 * @param {ee.Image} ndviImage Scaled NDVI image (0-1).
 * @param {ee.Geometry} aoi The Area of Interest.
 * @returns {ee.Image} The calculated C factor image.
 */
var calculateCFactor = function(ndviImage, aoi) {
  var cFactor = ndviImage.multiply(-1.0).add(1.0).max(0.0).min(1.0);
  return cFactor.rename('C_Factor').clip(aoi);
};
/**
 * Calculates the P (Support Practice) Factor from LULC.
 * @param {ee.Image} lulcImage Land Use/Land Cover image.
 * @param {ee.Geometry} aoi The Area of Interest.
 * @returns {ee.Image} The calculated P factor image.
 */
var calculatePFactor = function(lulcImage, aoi) {
  var lulc = lulcImage.select('LC_Type1');
  var pFactor = lulc
    .eq(0).multiply(0.0) // Water - effectively no erosion, P=0
    .add(lulc.eq(1).multiply(0.05)) // Evergreen Needleleaf Forests
    .add(lulc.eq(2).multiply(0.05)) // Evergreen Broadleaf Forests
    .add(lulc.eq(3).multiply(0.05)) // Deciduous Needleleaf Forests
    .add(lulc.eq(4).multiply(0.05)) // Deciduous Broadleaf Forests
    .add(lulc.eq(5).multiply(0.05)) // Mixed Forests
    .add(lulc.eq(6).multiply(0.1)) // Closed Shrublands
    .add(lulc.eq(7).multiply(0.15)) // Open Shrublands
    .add(lulc.eq(8).multiply(0.1)) // Woody Savannas
    .add(lulc.eq(9).multiply(0.1)) // Savannas
    .add(lulc.eq(10).multiply(0.2)) // Grasslands
    .add(lulc.eq(11).multiply(0.0)) // Permanent Wetlands - effectively no erosion, P=0
    .add(lulc.eq(12).multiply(0.4)) // Croplands - higher P factor due to cultivation practices
    .add(lulc.eq(13).multiply(0.01)) // Urban and Built-up - very low P factor (impervious surfaces)
    .add(lulc.eq(14).multiply(0.3)) // Cropland/Natural Vegetation Mosaics
    .add(lulc.eq(15).multiply(0.0)) // Snow and Ice - effectively no erosion, P=0
    .add(lulc.eq(16).multiply(1.0)) // Barren - highest P factor (no vegetation or conservation practices)
    .unmask(1.0); // Ensure no nulls result in null P-factor
  return pFactor.rename('P_Factor').clip(aoi);
};
/**
 * Calculates the R (Rainfall Erosivity) Factor from CHIRPS precipitation.
 * @param {ee.Image} annualPrecipitation Annual precipitation image.
 * @param {ee.Geometry} aoi The Area of Interest.
 * @returns {ee.Image} The calculated R factor image.
 */
var calculateRFactor = function(annualPrecipitation, aoi) {
  // R = 0.363 * P + 79 (Approximate empirical formula for certain regions)
  var rFactor = annualPrecipitation.multiply(0.363).add(79).rename('R_Factor').clip(aoi);
  return rFactor;
};
// --- 5. Main Analysis Logic ---
/**
 * Calculates all RUSLE factors and annual soil loss for a given year.
 * This function now returns total soil loss in tonnes/year per pixel.
 * @param {string} year The year for calculation.
 * @param {ee.Geometry} aoi The Area of Interest.
 * @returns {ee.Image} Annual Total Soil Loss image (tonnes/year per pixel).
*/
var calculateRUSLEForYear = function(year, aoi) {
  var startDate = ee.Date.fromYMD(ee.Number.parse(year), 1, 1);
  var endDate = startDate.advance(1, 'year');
  // K Factor (Soil Erodibility Factor) - constant across years for simplicity
  var soil = ee.Image("OpenLandMap/SOL/SOL_TEXTURE-CLASS_USDA-TT_M/v02").select('b0').clip(aoi);
  var kFactor = calculateKFactor(soil, aoi);
  // LS Factor (Topography) - constant across years
  var srtm = ee.Image('USGS/SRTMGL1_003');
  var lsFactor = calculateLSFactor(srtm, aoi);
  // C Factor (Cover-Management) from MODIS NDVI
  var modisNdviCollection = ee.ImageCollection("MODIS/061/MOD13A1")
    .filterDate(startDate, endDate).filterBounds(aoi).select('NDVI');
  var ndviImage = getCollectionImage(modisNdviCollection, 'mean',
    ee.Image(1.0).rename('NDVI').reproject({ crs: srtm.projection().crs(), scale: commonScale }),
    'No valid NDVI data found for year ' + year + '. C Factor defaulted to 1.0.');
  var cFactor = calculateCFactor(ndviImage.divide(10000), aoi).reproject({
    crs: ndviImage.projection().crs(),
    scale: commonScale
  });
  // P Factor (Support Practice) from MODIS LULC
  var modisLulcCollection = ee.ImageCollection("MODIS/061/MCD12Q1")
    .filterDate(startDate, endDate).filterBounds(aoi).select('LC_Type1');
  var lulcImage = getCollectionImage(modisLulcCollection, 'first',
    ee.Image(0).rename('LC_Type1').reproject({ crs: srtm.projection().crs(), scale: commonScale }),
    'No valid LULC data found for year ' + year + '. P Factor defaulted based on empty LULC.');
  var pFactor = calculatePFactor(lulcImage, aoi).reproject({
    crs: lulcImage.projection().crs(),
    scale: commonScale
  });
  // R Factor (Rainfall Erosivity) from CHIRPS
  var chirpsCollection = ee.ImageCollection('UCSB-CHG/CHIRPS/PENTAD')
    .select('precipitation') // Crucial: Select the precipitation band
    .filterDate(startDate, endDate).filterBounds(aoi);
  var annualPrecipitation = getCollectionImage(chirpsCollection, 'sum',
    ee.Image(0).rename('precipitation').reproject({ crs: srtm.projection().crs(), scale: commonScale }),
    'No valid CHIRPS rainfall data found for year ' + year + '. R Factor defaulted to 0.');
  var rFactor = calculateRFactor(annualPrecipitation, aoi).reproject({
    crs: annualPrecipitation.projection().crs(),
    scale: commonScale
  });
  // Calculate A = R * K * LS * C * P in t/ha/year
  var annualSoilLoss_t_ha_yr = rFactor
    .multiply(kFactor)
    .multiply(lsFactor)
    .multiply(cFactor)
    .multiply(pFactor)
    .rename('Annual_Soil_Loss_t_ha_yr') // Keep this name for intermediate display
    .clip(aoi);
  // Get pixel area in hectares
  var pixelArea_ha = ee.Image.pixelArea().divide(10000).rename('pixel_area_ha'); // Convert m^2 to hectares
  // Multiply by pixel area to get total soil loss in tonnes per year per pixel
  var annualTotalSoilLoss_tonnes_yr_per_pixel = annualSoilLoss_t_ha_yr.multiply(pixelArea_ha).rename('Annual_Total_Soil_Loss_tonnes_yr');
  return annualTotalSoilLoss_tonnes_yr_per_pixel;
};
/**
 * Classifies continuous soil loss into severity categories.
 * This function expects soil loss in **tonnes per hectare per year (t/ha/yr)**.
 * @param {ee.Image} soilLossImage The continuous soil loss image in t/ha/yr.
 * @returns {ee.Image} The classified soil loss severity image.
 */
var getSoilLossSeverityImage = function(soilLossImage) {
  var veryLow = 5;
  var low = 15;
  var moderate = 45;
  var high = 75;
  var soilLossSeverity = ee.Image(0).rename('severity');
  soilLossSeverity = soilLossSeverity
    .where(soilLossImage.gt(high), 5)
    .where(soilLossImage.gt(moderate).and(soilLossImage.lte(high)), 4)
    .where(soilLossImage.gt(low).and(soilLossImage.lte(moderate)), 3)
    .where(soilLossImage.gt(veryLow).and(soilLossImage.lte(low)), 2)
    .where(soilLossImage.lte(veryLow), 1);
  return soilLossSeverity;
};
/**
 * Creates and displays a legend for soil loss severity, placed on leftMap.
 */
var createSoilLossSeverityLegend = function() {
  // Remove existing legend if present on the leftMap
  leftMap.widgets().forEach(function(widget) {
    if (widget.style().get('position') === 'bottom-left' &&
        widget.widgets().get(0) &&
        widget.widgets().get(0).getValue() === 'Soil Loss Severity (t/ha/yr)') {
      leftMap.remove(widget);
    }
  });
  var veryLow = 5;
  var low = 15;
  var moderate = 45;
  var high = 75;
  var severityVis = {
    min: 1,
    max: 5,
    palette: ['#006400', '#ADFF2F', '#FFFF00', '#FFA500', '#FF0000'] // Dark Green, Green-Yellow, Yellow, Orange, Red
  };
  var legend = ui.Panel({
    style: {
      position: 'bottom-left', // Position legend on the bottom-left of the map
      padding: '8px 15px',
      backgroundColor: 'white',
      border: '1px solid #ccc',
      borderRadius: '5px',
    }
  });
  legend.add(ui.Label({
    value: 'Soil Loss Severity (t/ha/yr)',
    style: {
      fontWeight: 'bold',
      fontSize: '14px',
      margin: '0 0 4px 0',
      padding: '0',
      color: '#333'
    }
  }));
  var makeRow = function(color, name, range) {
    var colorBox = ui.Label({
      style: {
        backgroundColor: color,
        padding: '8px',
        margin: '0 0 4px 0',
        border: '1px solid #ccc',
        borderRadius: '3px'
      }
    });
    var description = ui.Label({
      value: name + ' (' + range + ')',
      style: {
        margin: '0 0 4px 6px',
        fontSize: '11px'
      }
    });
    return ui.Panel({
      widgets: [colorBox, description],
      layout: ui.Panel.Layout.Flow('horizontal')
    });
  };
  legend.add(makeRow(severityVis.palette[0], 'Very Low', '0 - ' + veryLow));
  legend.add(makeRow(severityVis.palette[1], 'Low', (veryLow + ' - ' + low)));
  legend.add(makeRow(severityVis.palette[2], 'Moderate', (low + ' - ' + moderate)));
  legend.add(makeRow(severityVis.palette[3], 'High', (moderate + ' - ' + high)));
  legend.add(makeRow(severityVis.palette[4], 'Extreme', '>' + high));
  leftMap.add(legend); // Add legend directly to the left map
};
/**
 * Updates the map layers and results panel based on selected years.
 */
function updateAnalysis() {
  var selectedYearLeft = yearSelectLeft.getValue();
  var selectedYearRight = yearSelectRight.getValue();
  if (!aoi || !selectedYearLeft || !selectedYearRight) {
    resultsPanel.clear();
    resultsPanel.add(ui.Label({
      value: 'Analysis Results',
      style: { fontWeight: 'bold', fontSize: '14px', margin: '0 0 8px 0', color: '#333' }
    }));
    resultsPanel.add(ui.Label('Please ensure AOI is drawn and two years are selected.'));
    return;
  }
  resultsPanel.clear();
  resultsPanel.add(ui.Label({
    value: 'Processing Soil Loss for ' + selectedYearLeft + ' vs ' + selectedYearRight,
    style: { fontWeight: 'bold', fontSize: '16px', margin: '0 0 8px 0', color: '#333' }
  }));
  resultsPanel.add(ui.Label('Calculating factors and preparing maps... Please wait. This may take a moment. ⏳', {
    color: '#007BFF',
    fontWeight: 'bold'
  }));
  // Clear existing map layers
  leftMap.layers().reset();
  rightMap.layers().reset();
  // Calculate annual total soil loss for both years (tonnes/year per pixel)
  var annualTotalSoilLossLeft = calculateRUSLEForYear(selectedYearLeft, aoi);
  var annualTotalSoilLossRight = calculateRUSLEForYear(selectedYearRight, aoi);
  // For severity classification, we need to convert back to t/ha/yr
  var pixelArea_ha = ee.Image.pixelArea().divide(10000); // Convert m^2 to hectares
  var annualSoilLossLeft_t_ha_yr_for_severity = annualTotalSoilLossLeft.divide(pixelArea_ha);
  var annualSoilLossRight_t_ha_yr_for_severity = annualTotalSoilLossRight.divide(pixelArea_ha);
  // Get classified severity images
  var soilLossSeverityLeft = getSoilLossSeverityImage(annualSoilLossLeft_t_ha_yr_for_severity);
  var soilLossSeverityRight = getSoilLossSeverityImage(annualSoilLossRight_t_ha_yr_for_severity);
  // Define the visualization for severity maps
  var severityVis = {
    min: 1,
    max: 5,
    palette: ['#006400', '#ADFF2F', '#FFFF00', '#FFA500', '#FF0000'] // Dark Green, Green-Yellow, Yellow, Orange, Red
  };
  // Add classified severity layers to maps
  leftMap.addLayer(soilLossSeverityLeft.clip(aoi), severityVis, 'Soil Loss Severity ' + selectedYearLeft);
  rightMap.addLayer(soilLossSeverityRight.clip(aoi), severityVis, 'Soil Loss Severity ' + selectedYearRight);
  leftMap.centerObject(aoi); // Center both maps
  // Calculate total soil loss for the AOI by summing the 'Annual_Total_Soil_Loss_tonnes_yr' band
  var statsAnnualTotalSoilLossLeft = annualTotalSoilLossLeft.reduceRegion({
    reducer: ee.Reducer.sum(), // Sum for total soil loss
    geometry: aoi,
    scale: commonScale,
    maxPixels: 1e9
  });
  var statsAnnualTotalSoilLossRight = annualTotalSoilLossRight.reduceRegion({
    reducer: ee.Reducer.sum(), // Sum for total soil loss
    geometry: aoi,
    scale: commonScale,
    maxPixels: 1e9
  });
  // Fetch results and update UI
  ee.List([statsAnnualTotalSoilLossLeft, statsAnnualTotalSoilLossRight]).evaluate(function(results, error) {
    if (error) {
      resultsPanel.add(ui.Label('❌ Error fetching soil loss data: ' + error, { color: 'red' }));
      print('Error fetching soil loss data:', error);
      return;
    }
    var totalSoilLossLeft = results[0].Annual_Total_Soil_Loss_tonnes_yr;
    var totalSoilLossRight = results[1].Annual_Total_Soil_Loss_tonnes_yr;
    // Calculate the total area of the AOI in hectares.
    var aoiArea_ha = aoi.area({maxError: 10}).divide(10000).getInfo(); // Get AOI area in hectares
    // Calculate average soil loss in t/ha/yr from the total soil loss.
    var averageSoilLossLeft_t_ha_yr = (totalSoilLossLeft !== null && aoiArea_ha > 0) ? totalSoilLossLeft / aoiArea_ha : null;
    var averageSoilLossRight_t_ha_yr = (totalSoilLossRight !== null && aoiArea_ha > 0) ? totalSoilLossRight / aoiArea_ha : null;
    resultsPanel.clear(); // Clear 'processing' message
    resultsPanel.add(ui.Label({
      value: '📊 Comparison Results for ' + selectedYearLeft + ' vs ' + selectedYearRight,
      style: { fontWeight: 'bold', fontSize: '16px', margin: '0 0 8px 0', color: '#333' }
    }));
    // Display Total Annual Soil Loss
    resultsPanel.add(ui.Label('Total Annual Soil Loss (tonnes/year):', { fontWeight: 'bold', color: '#4CAF50', margin: '8px 0 0 0' }));
    resultsPanel.add(ui.Label('• ' + selectedYearLeft + ': ' + (totalSoilLossLeft !== null ? totalSoilLossLeft.toFixed(2) + ' tonnes/year' : 'No data')));
    resultsPanel.add(ui.Label('• ' + selectedYearRight + ': ' + (totalSoilLossRight !== null ? totalSoilLossRight.toFixed(2) + ' tonnes/year' : 'No data')));
    // Display Average Annual Soil Loss
    resultsPanel.add(ui.Label('Average Annual Soil Loss (tonnes/hectare/year):', { fontWeight: 'bold', color: '#007BFF', margin: '8px 0 0 0' }));
    resultsPanel.add(ui.Label('• ' + selectedYearLeft + ': ' + (averageSoilLossLeft_t_ha_yr !== null ? averageSoilLossLeft_t_ha_yr.toFixed(2) + ' t/ha/yr' : 'No data')));
    resultsPanel.add(ui.Label('• ' + selectedYearRight + ': ' + (averageSoilLossRight_t_ha_yr !== null ? averageSoilLossRight_t_ha_yr.toFixed(2) + ' t/ha/yr' : 'No data')));
    var getSeverityText = function(soilLoss_t_ha_yr) {
      if (soilLoss_t_ha_yr === null || isNaN(soilLoss_t_ha_yr)) return { text: 'N/A', color: '#333' };
      if (soilLoss_t_ha_yr <= 5) { return { text: 'Very Low', color: '#006400' }; }
      else if (soilLoss_t_ha_yr <= 15) { return { text: 'Low', color: '#ADFF2F' }; }
      else if (soilLoss_t_ha_yr <= 45) { return { text: 'Moderate', color: '#FFA500' }; }
      else if (soilLoss_t_ha_yr <= 75) { return { text: 'High', color: '#FF4500' }; }
      else { return { text: 'Extreme', color: '#FF0000' }; }
    };
    var severityLeft = getSeverityText(averageSoilLossLeft_t_ha_yr);
    var severityRight = getSeverityText(averageSoilLossRight_t_ha_yr);
    resultsPanel.add(ui.Label('Severity Status (based on Average t/ha/yr):', { fontWeight: 'bold', color: '#4CAF50', margin: '8px 0 0 0' }));
    resultsPanel.add(ui.Label('• ' + selectedYearLeft + ' Severity: ' + severityLeft.text, { fontWeight: 'bold', color: severityLeft.color, fontSize: '13px' }));
    resultsPanel.add(ui.Label('• ' + selectedYearRight + ' Severity: ' + severityRight.text, { fontWeight: 'bold', color: severityRight.color, fontSize: '13px' }));
    // Add severity legend (only once)
    createSoilLossSeverityLegend();
  });
}
/**
 * Resets the application to its initial state.
 */
function resetAnalysis() {
  drawingTools.layers().reset();
  drawingTools.setShape(null);
  leftMap.layers().reset();
  rightMap.layers().reset();
  aoi = null;
  // Remove legend if present on the leftMap
  leftMap.widgets().forEach(function(widget) {
    if (widget.style().get('position') === 'bottom-left' &&
        widget.widgets().get(0) &&
        widget.widgets().get(0).getValue() === 'Soil Loss Severity (t/ha/yr)') {
      leftMap.remove(widget);
    }
  });
  yearSelectLeft.setValue('2001');
  yearSelectRight.setValue('2023');
  analyzeButton.setDisabled(true);
  instructionLabel.setValue('1. Draw an Area of Interest (AOI) on the map.\n2. Select two years for comparison.\n3. Click "Analyze".'); // Reset to simplified message
  resultsPanel.clear();
  resultsPanel.add(ui.Label('Please draw an AOI and click "Analyze" to view analysis results.'));
  leftMap.setCenter(78.47, 17.38, 10);
}
// --- 6. Initial App Setup ---
leftMap.setCenter(78.47, 17.38, 10); 
rightMap.setCenter(78.47, 17.38, 10);
// Initial center for both maps