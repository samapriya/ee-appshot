// Import the feature collection for states and districts
var indiaDist = ee.FeatureCollection('users/sachinbobbili/India_Dist');
// Pre-process the Collection
// Yearly data from 2000-2022
var annual = ee.ImageCollection(
  'projects/sat-io/open-datasets/GLC-FCS30D/annual');
// Five-Yearly data for 1985-90, 1990-95 and 1995-2000
var fiveyear = ee.ImageCollection(
  'projects/sat-io/open-datasets/GLC-FCS30D/five-years-map');
// The classification scheme has 36 classes 
// (35 landcover class and 1 fill value)
var classValues = [
  10, 11, 12, 20, 51, 52, 61, 62, 71, 72, 81, 82, 91, 92, 120, 121, 122, 
  130, 140, 150, 152, 153, 181, 182, 183, 184, 185, 186, 187, 190, 200, 
  201, 202, 210, 220, 0
];
// Landcover class names
var classNames = [
  'Rainfed_cropland',
  'Herbaceous_cover_cropland',
  'Tree_or_shrub_cover_cropland',
  'Irrigated_cropland',
  'Open_evergreen_broadleaved_forest',
  'Closed_evergreen_broadleaved_forest',
  'Open_deciduous_broadleaved_forest',
  'Closed_deciduous_broadleaved_forest',
  'Open_evergreen_needle_leaved_forest',
  'Closed_evergreen_needle_leaved_forest',
  'Open_deciduous_needle_leaved_forest',
  'Closed_deciduous_needle_leaved_forest',
  'Open_mixed_leaf_forest',
  'Closed_mixed_leaf_forest',
  'Shrubland',
  'Evergreen_shrubland',
  'Deciduous_shrubland',
  'Grassland',
  'Lichens_and_mosses',
  'Sparse_vegetation',
  'Sparse_shrubland',
  'Sparse_herbaceous',
  'Swamp',
  'Marsh',
  'Flooded_flat',
  'Saline',
  'Mangrove',
  'Salt_marsh',
  'Tidal_flat',
  'Impervious_surfaces',
  'Bare_areas',
  'Consolidated_bare_areas',
  'Unconsolidated_bare_areas',
  'Water_body',
  'Permanent_ice_and_snow',
  'Filled_value'
];
var classColors = [
  '#ffff64', '#ffff64', '#ffff00', '#aaf0f0', '#4c7300',
  '#006400', '#a8c800', '#00a000', '#005000', '#003c00',
  '#286400', '#285000', '#a0b432', '#788200', '#966400', 
  '#964b00', '#966400', '#ffb432', '#ffdcd2', '#ffebaf', 
  '#ffd278', '#ffebaf', '#00a884', '#73ffdf', '#9ebb3b', 
  '#828282', '#f57ab6', '#66cdab', '#444f89', '#c31400', 
  '#fff5d7', '#dcdcdc', '#fff5d7', '#0046c8', '#ffffff',
  '#ffffff'
];
// The data is split into tiles
// Mosaic them into a single image
var annualMosaic = annual.mosaic();
var fiveYearMosaic = fiveyear.mosaic();
// Each image in five year image 3 bands,
// one for each year from 1985-90, 1990-95 and 1995-2000
// Create a list of year strings
var fiveYearsList = ee.List.sequence(1985, 1995, 5).map(function(year) {
  return ee.Number(year).format('%04d');
});
var fiveyearMosaicRenamed = fiveYearMosaic.rename(fiveYearsList);
// Each image in annual image 23 bands, one for each year from 2000-2022
// Rename bands from b1,b2.. to 2000,2001... etc.
var yearsList = ee.List.sequence(2000, 2022).map(function(year) {
  return ee.Number(year).format('%04d')
});
var annualMosaicRenamed = annualMosaic.rename(yearsList);
var years = fiveYearsList.cat(yearsList);
// Turn the multiband image to a ImageCollection
var fiveYearlyMosaics = fiveYearsList.map(function(year) {
  var date = ee.Date.fromYMD(ee.Number.parse(year), 1, 1);
  return fiveyearMosaicRenamed.select([year]).set({
    'system:time_start': date.millis(),
    'system:index': year,
    'year': ee.Number.parse(year)
  });
});
var yearlyMosaics = yearsList.map(function(year) {
  var date = ee.Date.fromYMD(ee.Number.parse(year), 1, 1);
  return annualMosaicRenamed.select([year]).set({
    'system:time_start': date.millis(),
    'system:index': year,
    'year': ee.Number.parse(year)
  });
});
var allMosaics = fiveYearlyMosaics.cat(yearlyMosaics);
var mosaicsCol = ee.ImageCollection.fromImages(allMosaics);
// For ease of visualization and analysis, it is recommended
// to recode the class values into sequential values
// We use remap() to convert the original values into new values
// from 1 to 36
var newClassValues = ee.List.sequence(1, ee.List(classValues).length());
var renameClasses = function(image) {
  var reclassified = image.remap(classValues, newClassValues)
    .rename('classification');
  return reclassified;
};
var landcoverCol = mosaicsCol.map(renameClasses);
// ***************************************************
// Single Map App
// ***************************************************
// Create the layout
var center = {lon:78.5, lat:17.5, zoom:10};
var map = ui.Map(center);
// Add dropdown year selector
var yearSelector = ui.Select({
  items: years.getInfo(),
  value: '2022',
  style: {
    'fontSize': '20px',
  },
});
// State and district selectors
var stateNames = indiaDist.aggregate_array('stname').distinct().sort().getInfo();
var stateSelector = ui.Select({
  items: stateNames,
  placeholder: 'Select a State',
  style: {fontSize: '20px'},
});
var districtSelector = ui.Select({
  placeholder: 'Select a District',
  style: {fontSize: '20px'},
});
stateSelector.onChange(function(selectedState) {
  var districts = indiaDist.filter(ee.Filter.eq('stname', selectedState))
    .aggregate_array('dtname').sort().getInfo();
  districtSelector.items().reset(districts);
});
var submitButton = ui.Button({
  label: 'Submit',
  style: {fontSize: '20px'}
});
// Legend panel
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px',
    backgroundColor: '#f0f0f0'
  }
});
// Add a checkbox to show/hide legend
var showLegend = ui.Checkbox({
  label: 'Show Legend',
  style: {
    fontSize: '10px',
    backgroundColor: '#f0f0f0',
  },
});
legend.add(showLegend);
var column1 = ui.Panel({
  style: {
    padding: '8px 15px',
    backgroundColor: '#f0f0f0'
  }
});
var column2 = ui.Panel({
  style: {
    padding: '8px 15px',
    backgroundColor: '#f0f0f0'
  }
});
var columns = ui.Panel({
  layout: ui.Panel.Layout.Flow('horizontal'),
   style: {
    backgroundColor: '#f0f0f0'
  }
});
columns.add(column1);
columns.add(column2);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
  // Create the label that is actually the colored box.
  var colorBox = ui.Label({
    style: {
      backgroundColor: color,
      // Use padding to give the box height and width.
      padding: '8px',
      margin: '0 0 4px 0'
    }
  });
  // Create the label filled with the description text.
  var description = ui.Label({
    value: name,
    style: {
      margin: '0 0 4px 6px',
      backgroundColor: '#f0f0f0'
    }
  });
  return ui.Panel({
    widgets: [colorBox, description],
    layout: ui.Panel.Layout.Flow('horizontal'),
    style: {backgroundColor: '#f0f0f0'}
  });
};
var totalItems = classNames.length;
for (var i = 0; i < totalItems/2; i++) {
  column1.add(makeRow(classColors[i], classNames[i]));
}
for (var i = totalItems/2; i < totalItems; i++) {
  column2.add(makeRow(classColors[i], classNames[i]));
}
map.add(legend);
// Configure the widgets
years.evaluate(function(yearsList) {
  yearSelector.items().reset(yearsList);
  // Set the value to the last year
  yearSelector.setValue(yearsList[yearsList.length -1]);
});
// Function to get a layer for the selected year and district
function getLayer(year, district) {
  var selectedLandcover = landcoverCol
    .filter(ee.Filter.eq('year', ee.Number.parse(year))).first();
  var districtGeom = indiaDist.filter(ee.Filter.eq('dtname', district)).geometry();
  var classVisParams = {min:1, max:36, palette: classColors};
  var layer = ui.Map.Layer(
    selectedLandcover.clip(districtGeom), classVisParams, 'Landcover ' + year);
  return layer;
}
submitButton.onClick(function() {
  var selectedYear = yearSelector.getValue();
  var selectedDistrict = districtSelector.getValue();
  if (selectedYear && selectedDistrict) {
    var layer = getLayer(selectedYear, selectedDistrict);
    map.layers().reset([]);
    map.add(layer);
    var districtGeom = indiaDist.filter(ee.Filter.eq('dtname', selectedDistrict)).geometry();
    map.centerObject(districtGeom, 10);
  }
});
function changeLegendVisibility(value) {
  if (value) {
    legend.add(columns);
  }
  else {
    legend.remove(columns);
  }
}
showLegend.onChange(changeLegendVisibility);
// Add UI components to the map
var controlPanel = ui.Panel({
  widgets: [
    yearSelector,
    stateSelector,
    districtSelector,
    submitButton
  ],
  style: {position: 'top-left', padding: '10px'}
});
// Add Title and Description
var title = ui.Label('Land Use Land Cover Analysis', {
  fontSize: '24px',
  fontWeight: 'bold',
  textAlign: 'center',
  stretch: 'horizontal',
  backgroundColor: '#cce5ff',
  padding: '10px',
});
var description = ui.Label(
  'Select a year, state, and district to view the land use land cover ' +
  'analysis. The map will update to show the selected district and the ' +
  'panel below will display the area of each land use class in the selected district.',
  {fontSize: '16px', textAlign: 'center', stretch: 'horizontal', backgroundColor: '#e2f0d9', padding: '10px'}
);
var headerPanel = ui.Panel([title, description], ui.Panel.Layout.Flow('vertical'), {width: '400px'});
var mainPanel = ui.Panel([headerPanel, controlPanel], ui.Panel.Layout.Flow('vertical'));
// Add the main panel to the root UI
ui.root.clear();
ui.root.add(mainPanel);
ui.root.add(map);