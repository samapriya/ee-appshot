// Load the FeatureCollection of districts
var indiaDist = ee.FeatureCollection("users/sachinbobbili/India_Dist");
// Get unique state names
var states = indiaDist.aggregate_array('stname').distinct().getInfo();
// Create UI elements
var stateSelect = ui.Select({
  items: states,
  placeholder: 'Select a State',
  onChange: function(stateName) {
    var districts = indiaDist.filter(ee.Filter.eq('stname', stateName))
                             .aggregate_array('dtname').distinct().getInfo();
    districtSelect.items().reset(districts);
  },
  style: {color: 'blue'}
});
var districtSelect = ui.Select({
  placeholder: 'Select a District',
  style: {color: 'blue'},
  onChange: function(districtName) {
    // Clear existing layers
    Map.layers().reset();
    // Filter the FeatureCollection for the selected district
    var selectedDistrict = indiaDist.filter(ee.Filter.and(
      ee.Filter.eq('stname', stateSelect.getValue()),
      ee.Filter.eq('dtname', districtName)
    ));
    // Center the map on the selected district
    Map.centerObject(selectedDistrict, 8);
    // Load datasets
    var dem = ee.Image("CGIAR/SRTM90_V4");
    var lulc = ee.ImageCollection('ESA/WorldCover/v100').first();
    var hillshade = ee.Terrain.hillshade(dem);
    var globalWater = ee.Image('JRC/GSW1_3/GlobalSurfaceWater');
    // Handling the GPW Population Density dataset
    var popDensity = ee.ImageCollection('CIESIN/GPWv411/GPW_Population_Density')
                      .filterBounds(selectedDistrict.geometry())
                      .first() // Get the most recent image or adjust as necessary
                      .clip(selectedDistrict);
    var ndvi = ee.ImageCollection('COPERNICUS/S2')
                  .filterBounds(selectedDistrict.geometry())
                  .filterDate('2023-01-01', '2023-12-31')
                  .median()
                  .normalizedDifference(['B8', 'B4'])
                  .clip(selectedDistrict);
    // Calculate slope and aspect
    var slope = ee.Terrain.slope(dem);
    var aspect = ee.Terrain.aspect(dem);
    var ffr_data = ee.FeatureCollection('WWF/HydroSHEDS/v1/FreeFlowingRivers');
    var ffr = ee.Image().byte().paint(ffr_data, 'RIV_ORD', 2);
    // Mask and clip to selected district
    var mask = selectedDistrict.geometry();
    dem = dem.clip(mask);
    slope = slope.clip(mask);
    aspect = aspect.clip(mask);
    hillshade = hillshade.clip(mask);
    lulc = lulc.clip(mask);
    globalWater = globalWater.clip(mask);
    popDensity = popDensity.clip(mask);
    ndvi = ndvi.clip(mask);
    ffr= ffr.clip(mask);
    // Add layers to the map
    //Map.addLayer(mask,{},'AOI');
    Map.addLayer(dem, {}, 'DEM');
    Map.addLayer(slope, {min: 0, max: 60, palette: ['#f7fcf0', '#e0f3f8', '#91bfdb', '#4575b4']}, 'Slope');
    Map.addLayer(aspect, {min: 0, max: 360, palette: ['#313695', '#4575b4', '#91bfdb', '#e0f3f8', '#f7fcf0']}, 'Aspect');
    Map.addLayer(hillshade, {min: 0, max: 255, palette: ['#000000', '#ffffff']}, 'Hillshade');
    Map.addLayer(lulc, {min: 0, max: 200, palette: ['#006400', '#228B22', '#FFD700', '#DAA520', '#FF4500', '#8B4513', '#A52A2A', '#D3D3D3']}, 'LULC');
    Map.addLayer(globalWater.select('occurrence'), {min: 0, max: 100, palette: ['#ffffff', '#0000ff']}, 'Global Water');
    Map.addLayer(popDensity, {min: 0, max: 1000, palette: ['#f7fcf0', '#d0d0d0', '#636363', '#252525']}, 'Population Density');
    Map.addLayer(ndvi, {min: -1, max: 1, palette: ['#0000ff', '#ffffff', '#00ff00']}, 'NDVI');
    Map.addLayer(ffr, {min: 1, max: 10,palette: ['08519c', '3182bd', '6baed6', 'bdd7e7', 'eff3ff']}, 'Free Flowing Rivers');
  }
});
// Function to create a color ramp
var createColorRamp = function(palette, min, max, label) {
  var numSteps = palette.length;
  var stepWidth = 200 / numSteps; // Fixed width for each color step
  var height = '15px'; // Fixed height for color ramps
  // Create a panel for the color ramp and label
  var rampPanel = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical'),
    style: {
      padding: '0',
      margin: '0',
      width: '220px' // Width to accommodate label and color ramp
    }
  });
  // Add the label above the color ramp
  rampPanel.add(ui.Label(label, {
    fontWeight: 'bold',
    margin: '0 0 4px 0'
  }));
  // Create the color ramp
  var colorRamp = ui.Panel({
    layout: ui.Panel.Layout.flow('horizontal'),
    style: {
      padding: '0',
      margin: '0'
    }
  });
  for (var i = 0; i < numSteps; i++) {
    colorRamp.add(ui.Label({
      style: {
        backgroundColor: palette[i],
        padding: '0',
        margin: '0',
        width: stepWidth + 'px',
        height: height
      }
    }));
  }
  // Add the color ramp panel
  rampPanel.add(colorRamp);
  // Add the data range below the color ramp
  rampPanel.add(ui.Label(min + ' - ' + max, {
    margin: '4px 0 0 0'
  }));
  return rampPanel;
};
// Create a legend panel with color ramps
var legend = ui.Panel({
  widgets: [
    ui.Label('Layer Legend', {fontWeight: 'bold'}),
    ui.Panel({
      widgets: [
        //createColorRamp(['#006400', '#228B22', '#FFD700', '#DAA520', '#FF4500', '#8B4513', '#A52A2A', '#D3D3D3'], 0, 6000, 'DEM'),
        createColorRamp(['#f7fcf0', '#e0f3f8', '#91bfdb', '#4575b4'], 0, 60, 'Slope'),
        createColorRamp(['#313695', '#4575b4', '#91bfdb', '#e0f3f8', '#f7fcf0'], 0, 360, 'Aspect'),
        createColorRamp(['#000000', '#ffffff'], 0, 255, 'Hillshade'),
        createColorRamp(['#006400', '#228B22', '#FFD700', '#DAA520', '#FF4500', '#8B4513', '#A52A2A', '#D3D3D3'], 0, 200, 'LULC'),
        createColorRamp(['#ffffff', '#0000ff'], 0, 100, 'Global Water'),
        createColorRamp(['#f7fcf0', '#d0d0d0', '#636363', '#252525'], 0, 1000, 'Population Density'),
        createColorRamp(['#0000ff', '#ffffff', '#00ff00'], (-1), (+1), 'NDVI')
      ],
      layout: ui.Panel.Layout.flow('vertical'),
      style: {
        padding: '0',
        margin: '0'
      }
    })
  ],
  style: {
    position: 'bottom-right',
    padding: '8px',
    backgroundColor: 'white',
    border: '1px solid black'
  }
});
Map.add(legend);
// Create an inspector panel for displaying information at the bottom center
var inspector = ui.Panel({
  widgets: [
    ui.Label('Layer Inspector', {fontWeight: 'bold',color:'blue', fontSize: '18px',textAlign: 'center'}),
    ui.Label('Click on the map to see layer values and coordinates.')
  ],
  style: {
    position: 'bottom-center',
    padding: '8px',
    backgroundColor: 'white',
    border: '1px solid black',
    width: '300px',
    textAlign: 'center'
  }
});
Map.add(inspector);
// Function to update the inspector panel with layer values and coordinates
var updateInspector = function(coords) {
  var point = ee.Geometry.Point([coords.lon, coords.lat]);
  var text = 'Coordinates: (' + coords.lon.toFixed(4) + ', ' + coords.lat.toFixed(4) + ')\n\n';
  // Clear previous content
  inspector.clear();
  // Add title and instructions
  inspector.add(ui.Label('Layer Inspector', {fontWeight: 'bold', fontSize: '18px'}));
  inspector.add(ui.Label('Click on the map to see layer values and coordinates.'));
  // Add coordinates
  inspector.add(ui.Label('Coordinates: (' + coords.lon.toFixed(4) + ', ' + coords.lat.toFixed(4) + ')'));
  // Add layer information to inspector panel
  Map.layers().forEach(function(layer) {
    var layerName = layer.get('name');
    var visParams = layer.get('visParams') || {};
    var min = visParams.min || 'N/A';
    var max = visParams.max || 'N/A';
    var image = ee.Image(layer.get('eeObject'));
    var maskedImage = image.clip(point.buffer(1000)); // 1 km buffer
    var stats = maskedImage.reduceRegion({
      reducer: ee.Reducer.mean(),
      geometry: point,
      scale: 30
    }).getInfo();
    if (stats) {
      var formattedStats = '';
      for (var key in stats) {
        if (stats.hasOwnProperty(key)) {
          var value = stats[key];
          formattedStats += key + ': ' + (value !== null ? value.toFixed(2) : 'N/A') + '\n'; // Format with 2 decimal places or 'N/A'
        }
      }
      //inspector.add(ui.Label(layerName + ':'));
      inspector.add(ui.Label(formattedStats));
    } else {
      inspector.add(ui.Label(layerName + ': No data available'));
    }
  });
};
// Add map click event handler
Map.onClick(function(coords) {
  // Update the inspector with the clicked coordinates and layer values
  updateInspector(coords);
});
// Create UI Panel for state and district selection with title and description
var controlPanel = ui.Panel({
  widgets: [
    ui.Label('Uncover India: District by District', {fontSize: '24px',position:'top-center', fontWeight: 'bold', margin: '0 0 10px 0',color:'red'}),
    ui.Label('This Earth Engine app creates an interactive web application to explore environmental data for Indian districts. Users can select a state and district to visualize layers like slope, aspect, land use, water bodies, population density, and vegetation health. A legend and inspector panel provide additional details.'),
    ui.Label('Select a State and District', {fontWeight: 'bold'}),
    stateSelect,
    districtSelect
  ],
  style: {
    position: 'top-left',
    width: '400px',
    padding: '8px',
    backgroundColor: 'white',
    border: '1px solid black'
  }
});
Map.add(controlPanel);
// Center the map over India
Map.setCenter(78.9629, 20.5937, 5);