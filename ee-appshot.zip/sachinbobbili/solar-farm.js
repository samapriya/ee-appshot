// Create the layout
var drawingTools = Map.drawingTools();
drawingTools.setShown(false);  // Hide drawing tools initially
// Set the map interaction mode to 'hand' by default
Map.setControlVisibility({layerList:true, drawingToolsControl:true});
// Center the map on India by default
Map.setCenter(78.9629, 20.5937, 4);
// Add instructions to the map
var instructions = ui.Label('Please Select your choice from the dropdown.', {
  fontSize: '14px',
  color: '#333333'
});
Map.add(instructions);
// Create UI elements
var panel = ui.Panel({
  style: {
    width: '450px',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    padding: '5px'
  }
});
// Main Title
var title = ui.Label('☀️ Solar Farm Geospatial Analysis', {
  fontWeight: 'bold',
  fontSize: '20px',
  color: '#1a73e8',
  margin: '10px 5px 5px 5px'
});
// Subtitle/description
var subtitle = ui.Label(
  'The Solar Farm Geospatial Analysis Application uses Google Earth Engine to determine the suitability of areas for solar farm development based on elevation, slope, and LULC data.',  
  {fontSize: '14px', color: '#444', margin: '0 5px 10px 5px'}
);
panel.add(title);
panel.add(subtitle);
// Add panel to the map
ui.root.insert(0, panel);
// Global variable to check if legend is added
var legendAdded = false;
// Function to get the pixel size of an image
function getPixelSize(img) {
  var projection = img.projection();
  var pixelSize = projection.nominalScale();
  return pixelSize;
}
// Function to create a grouped bar chart
function createGroupedBarChart(data) {
  var chart = ui.Chart.feature.groups(data, 'Suitability', 'Area', 'Type')
    .setChartType('ColumnChart')
    .setOptions({
      title: 'Suitable Areas (km²)',
      hAxis: { title: 'Suitability', textStyle: { fontSize: 9 } },
      vAxis: { title: 'Area (km²)' },
      bar: { groupWidth: "80%" },
      colors: ['#52E929', '#F5A742', '#AB2103', '#FF0000'],
      legend: { position: 'none'}
    });
  return chart;
}
// Function to perform analysis on the drawn geometry
function performAnalysis(aoi) {
  // Clear previous results
  panel.clear();
  panel.add(title);
  panel.add(subtitle);
  panel.add(aoiMethodSelect);
  // Clear previous layers
  Map.layers().reset();
  // 1. Elevation
  var dataset = ee.Image('USGS/SRTMGL1_003');
  var elevation = dataset.select('elevation').clip(aoi);
  var emptyImage = ee.Image(0).reproject({crs: elevation.projection(), scale: 500});
  var demClass = emptyImage.where(((elevation.lt(2000)).and(elevation.gt(30))), 1);
  Map.addLayer(demClass.clip(aoi), {min: 0, max: 1}, 'DEM Class', false);
  // 1. Max and Minimum elevation
  var stats = elevation.reduceRegion({
    reducer: ee.Reducer.minMax(),
    geometry: aoi,
    scale: 500,
    bestEffort: true
  });
  // 2. Slope
  var slope = ee.Terrain.slope(elevation).clip(aoi);
  var slopeClass = emptyImage.where((slope.lt(5)), 1)
                            .where(((slope.gt(5)).or(elevation.lt(10))), 0.6)
                            .where((slope.gt(10)), 0.4);
  Map.addLayer(slopeClass.clip(aoi), {min: 1, max: 3, palette: ['green', 'black', 'red']}, 'Slope Class', false);
  // 2. Minimum, average, max slope
  var slopeStats = slope.reduceRegion({
    reducer: ee.Reducer.minMax().combine({
      reducer2: ee.Reducer.mean(),
      sharedInputs: true
    }),
    geometry: aoi,
    scale: 500,
    bestEffort: true
  });
  // Combine elevation and slope stats into a single paragraph
  stats.evaluate(function(elevationResult) {
    slopeStats.evaluate(function(slopeResult) {
      var obs = ui.Label('📊 Observations from AOI 🗺️\n',{color: 'red',fontWeight: 'bold',fontSize: '14px'});
      var Elevation_Range = ui.Label(
        '📶 Elevation Range in Meters: ' + elevationResult.elevation_min.toFixed(0) +' - ' + elevationResult.elevation_max.toFixed(0),{color: '#073BD1'});
      var Slope_Range = ui.Label(  
        '📈 Slope Range in Degrees: ' + slopeResult.slope_min.toFixed(2) + ' - ' + slopeResult.slope_max.toFixed(2),
        {color: '#073BD1'}
      );
      panel.add(obs);
      panel.add(Elevation_Range);
      panel.add(Slope_Range);
    });
  });
  // 3. LULC
  var lulc = ee.ImageCollection('ESA/WorldCover/v200').first().clip(aoi);
  var classLULC = emptyImage.where((lulc.eq(20).or(lulc.eq(60))), 1);
  Map.addLayer(classLULC.updateMask(classLULC.eq(1)).clip(aoi), {min: 0, max: 1, palette: ['green', 'red']}, 'Barren Land', false);
  Map.addLayer(lulc.clip(aoi), {}, 'LULC All Class', false, 0.4);
  // Overlay
  var suitability = demClass.add(slopeClass).add(classLULC);
  suitability = emptyImage.where(suitability.eq(3), 1)
                         .where(suitability.eq(2.6), 2)
                         .where(suitability.eq(2.4), 3)
                         .where(suitability.lt(2.4), 4);
  suitability = suitability.updateMask(suitability.gte(1)).clip(aoi);
  Map.addLayer(suitability.clip(aoi), {min: 0, max: 4, palette: ['#FFFFFF', '#52E929', '#F5A742', '#AB2103', '#FF0000']}, 'Suitability');
  Map.addLayer(suitability.updateMask(suitability.eq(1)).clip(aoi), {min: 0, max: 1, palette: ['#52E929']}, 'Most Suitability');
  Map.addLayer(suitability.updateMask(suitability.eq(2)).clip(aoi), {min: 0, max: 1, palette: ['#F5A742']}, 'Medium Suitability');
  Map.addLayer(suitability.updateMask(suitability.eq(3)).clip(aoi), {min: 0, max: 1, palette: ['#AB2103']}, 'Less Suitability');
  Map.addLayer(suitability.updateMask(suitability.eq(4)).clip(aoi), {min: 0, max: 1, palette: ['#FF0000']}, 'Not Suitability');
  // 3. Resize the pixel and calculate the area.
  var names = ['Most Suitable', 'Medium Suitable', 'Less Suitable', 'Not Suitable'];
  var count = suitability.eq([1, 2, 3, 4]).rename(names);
  var total = count.multiply(ee.Image.pixelArea()).divide(1000 * 1000);
  var suitable_area = total.reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: aoi,
    scale: 100,
    maxPixels: 1e11,
    bestEffort: true
  });
  // Power Generation Calculation
  var area_pxa1 = ee.Number(suitable_area.get('Most Suitable')).multiply(1.7 * 0.85 * 300);
  area_pxa1.evaluate(function(result) {
    panel.add(ui.Label('⚡️ Power Generation for Most Suitable area (MWh): ' + result.toFixed(3), {color: '#D10784',fontWeight: 'bold',fontSize: '14px'}));
  });
  // Number of solar panels required
  var num_pan = ee.Number(suitable_area.get('Most Suitable')).multiply(1.7 * 0.85 * 1000000);
  num_pan.evaluate(function(result) {
    panel.add(ui.Label('🌤 Number of Solar Panels Required Based on Result: ' + result.toFixed(0), {color: '#D10784',fontWeight: 'bold',fontSize: '14px'}));
  });
  suitable_area.evaluate(function(result) {
    // Prepare data for the bar chart
    var data = ee.FeatureCollection([
      ee.Feature(null, {Suitability: 'Most Suitable', Area: result['Most Suitable'], Type: 'Most Suitable'}),
      ee.Feature(null, {Suitability: 'Medium Suitable', Area: result['Medium Suitable'], Type: 'Medium Suitable'}),
      ee.Feature(null, {Suitability: 'Less Suitable', Area: result['Less Suitable'], Type: 'Less Suitable'}),
      ee.Feature(null, {Suitability: 'Not Suitable', Area: result['Not Suitable'], Type: 'Not Suitable'})
    ]);
    // Create and add grouped bar chart to main panel
    var chart = createGroupedBarChart(data);
    panel.add(chart);
  });
  // Load ECMWF ERA5 Land Daily Aggregates data for solar radiation
  var solarRadiation = ee.ImageCollection("ECMWF/ERA5_LAND/DAILY_AGGR")
                         .filterDate('2023-01-01', '2023-12-31')
                         .mean()
                         .select("surface_solar_radiation_downwards_sum")
                         .clip(aoi);
  var solarClass = emptyImage.where(((solarRadiation.lt(10000000)).or(solarRadiation.gt(15000000))), 2)
                             .where((solarRadiation.gt(15000000)), 1)
                             .where((solarRadiation.lt(10000000)), 3);
    // Add solar radiation layer
  Map.addLayer(solarRadiation.clip(aoi), {min: 10000000, max: 20000000}, 'Solar Radiation', false);
  // Add legend to the map if not added
  if (!legendAdded) {
    addLegend('🗂 Legend', {
      'Most Suitable': '#52E929',
      'Medium Suitable': '#F5A742',
      'Less Suitable': '#AB2103',
      'Not Suitable': '#FF0000'
    });
    legendAdded = true;
  }
  // Add a download link for the results
  var vectors = suitability.reduceToVectors({
    geometry: aoi,
    scale: 100,
    maxPixels: 1e11,
    geometryType: 'polygon'
  }).map(function(feature) {
  var value = ee.Number(feature.get('label'));
  var label = ee.String(ee.Algorithms.If(value.eq(1), 'Most Suitable', 
                 ee.Algorithms.If(value.eq(2), 'Medium Suitable', 
                 ee.Algorithms.If(value.eq(3), 'Less Suitable', 
                 ee.Algorithms.If(value.eq(4),  'Not Suitable')))));
  return feature.set({ 'SuitabilityType': label });
});
  // Generate the download link for the KML file
  var kmlUrl = vectors.getDownloadURL({
    format: 'KML',
    filename: 'SuitableAreas'
  });
  // Add the download link to the panel
  var kmlLink = ui.Label({
    value: '⬇️ Click Here to Download Suitable Areas KML',
    style: {color: 'blue'},
    targetUrl: kmlUrl
  });
  panel.add(kmlLink);
}
// Create a dropdown for Select your choice methods
var aoiMethodSelect = ui.Select({
  items: ['✏️ Draw AOI', '📍 Define bounding box', '🔄 Reset AOI'],
  placeholder: 'Select AOI 🗺️ Method',
  value: '✏️ Draw AOI', // Set default value to 'Draw AOI'
  onChange: function(method) {
    // Clear panel and re-add essential elements
    panel.clear();
    panel.add(title);
    panel.add(subtitle);
    panel.add(ui.Label('Select AOI Method:', {fontWeight: 'bold'})); // Added label above dropdown
    panel.add(aoiMethodSelect);
    switch (method) {
      case '✏️ Draw AOI':
        drawingTools.setShown(true);
        instructions.setValue('Draw a rectangle/polygon on the map to define your area of interest (AOI).');
        panel.add(analyzeButton); // Add analyzeButton here
        break;
      case '📍 Define bounding box':
        drawingTools.setShown(false);
        instructions.setValue('Enter the coordinates for the bounding box.');
        var latLonPanel = ui.Panel({
          style: {width: '450px', backgroundColor: 'rgba(255, 255, 255, 0.8)', padding: '5px'}
        });
        latLonPanel.add(ui.Label('Enter the bounding box coordinates:'));
        var northLatInput = ui.Textbox({placeholder: 'North Latitude'});
        var southLatInput = ui.Textbox({placeholder: 'South Latitude'});
        var eastLonInput = ui.Textbox({placeholder: 'East Longitude'});
        var westLonInput = ui.Textbox({placeholder: 'West Longitude'});
        var submitButton = ui.Button({
          label: '📝 Analyze AOI',
          onClick: function() {
            var northLat = parseFloat(northLatInput.getValue());
            var southLat = parseFloat(southLatInput.getValue());
            var eastLon = parseFloat(eastLonInput.getValue());
            var westLon = parseFloat(westLonInput.getValue());
            var aoi = ee.Geometry.Rectangle([westLon, southLat, eastLon, northLat]);
            performAnalysis(aoi);
          }
        });
        latLonPanel.add(northLatInput);
        latLonPanel.add(southLatInput);
        latLonPanel.add(eastLonInput);
        latLonPanel.add(westLonInput);
        latLonPanel.add(submitButton);
        panel.add(latLonPanel);
        break;
      case '🔄 Reset AOI':
        instructions.setValue('Reset successful! Please select an option from the drop down menu to perform analysis.');
        resetMap();
        break;
    }
  }
});
// Add label above the dropdown
panel.add(ui.Label('Select AOI Method:', {fontWeight: 'bold'}));
panel.add(aoiMethodSelect);
// Function to reset map layers, drawn geometries, legend, and panel
function resetMap() {
  // Clear drawing tools
  drawingTools.layers().reset();
  // Clear map layers
  Map.layers().reset();
  // Remove legend if added
  if (legendAdded) {
    Map.widgets().reset();  // Remove all widgets from the map
    legendAdded = false;
  }
  // Clear panel
  panel.clear();
  panel.add(title);
  panel.add(subtitle);
  panel.add(aoiMethodSelect);
}
// Function to add the analyze button
var analyzeButton = ui.Button({
  label: '📝 Analyze AOI',
  onClick: function() {
    var geometry = drawingTools.layers();
    if (geometry.length() > 0) {
      var aoi = geometry.get(geometry.length() - 1).getEeObject();
      performAnalysis(aoi);
    } else {
      print('✏️ Use the draw tool to define an AOI.');
    }
  },
  style: {margin: '10px'}
});
// Add analyze button to the panel
panel.add(analyzeButton);
// Function to add legend to the map
function addLegend(title, items) {
  // Create a legend panel
  var legendPanel = ui.Panel({
    style: {
      position: 'bottom-right',
      padding: '8px',
      backgroundColor: 'white'
    }
  });
  // Add legend title
  var legendTitle = ui.Label({
    value: title,
    style: {
      fontWeight: 'bold',
      fontSize: '16px',
      margin: '0 0 4px 0',
      padding: '0'
    }
  });
  legendPanel.add(legendTitle);
  // Add legend items
  Object.keys(items).forEach(function(key) {
    var color = items[key];
    // Create legend item
    var legendItem = ui.Panel({
      widgets: [
        ui.Label({
          style: {
            backgroundColor: color,
            padding: '8px',
            margin: '0 0 4px 0',
            height: '18px',
            width: '18px'
          }
        }),
        ui.Label({
          value: key,
          style: { margin: '0 0 4px 6px' }
        })
      ],
      layout: ui.Panel.Layout.Flow('horizontal')
    });
    // Add legend item to panel
    legendPanel.add(legendItem);
  });
  // Add legend panel to the map
  Map.add(legendPanel);
  legendAdded = true;
}