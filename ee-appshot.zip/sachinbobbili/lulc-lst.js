var geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [],
      "displayProperties": [],
      "properties": {},
      "color": "#ffff99",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || /* color: #ffff99 */ee.Geometry.MultiPoint();
// Initialize the map and set the basemap to display as satellite.
Map.setOptions('HYBRID');
// Add title and description
var title = ui.Label('Landsat Surface Temperature Analysis');
title.style().set({
  fontSize: '24px',
  fontWeight: 'bold',
  textAlign: 'center',
  color: 'blue'
});
var description = ui.Label(
  'This application analyzes Landsat surface temperature data. ' +
  'You can select a region of interest (ROI) using the draw tool. ' +
  'The chart below will display the time series of surface temperatures for the selected region.'
);
description.style().set({
  fontSize: '16px',
  textAlign: 'left',
  maxWidth: '400px',
  maxHeight: '400px',
  color: 'black'
});
// Create a panel for the title and description
var infoPanel = ui.Panel([title, description]);
infoPanel.style().set({
  position: 'top-left',
  padding: '8px',
  width: '400px'
});
Map.add(infoPanel);
// Define the draw tool for user input
var drawingTools = Map.drawingTools();
drawingTools.setDrawModes(['point']);
drawingTools.setShape('point');
drawingTools.setLinked(false);
// Create a panel for the chart
var chartPanel = ui.Panel();
chartPanel.style().set({
  position: 'bottom-left',
  padding: '8px',
  width: '400px'
});
Map.add(chartPanel);
// Function to handle drawing completion
function handleDrawingCompleted(geometry) {
  var aoi = geometry.buffer(10000);  // Buffer the ROI by 10 km
  Map.centerObject(aoi, 11);
  Map.addLayer(aoi, {color: 'red'}, 'AOI');
  // Define the bands for Landsat 8 and 9
  var LC09_bands = ['ST_B10', 'QA_PIXEL'];
  var LC08_bands = ['ST_B10', 'QA_PIXEL'];
  var bandName = ['ST', 'QA_PIXEL'];
  // Cloud mask function
  function cloudMask(image) {
    var qa = image.select('QA_PIXEL');
    var mask = qa.bitwiseAnd(1 << 3)
      .or(qa.bitwiseAnd(1 << 4));
    return image.updateMask(mask.not());
  }
  // Load and filter Landsat image collections
  var L9 = ee.ImageCollection('LANDSAT/LC09/C02/T1_L2')
    .select(LC09_bands, bandName)
    .filterBounds(aoi)
    .map(cloudMask);
  var L8 = ee.ImageCollection('LANDSAT/LC08/C02/T1_L2')
    .select(LC08_bands, bandName)
    .filterBounds(aoi)
    .map(cloudMask);
  var filtered_L9 = L9.filter(ee.Filter.lt('CLOUD_COVER', 20));
  var filtered_L8 = L8.filter(ee.Filter.lt('CLOUD_COVER', 20));
  // Merge Landsat collections and apply scale factors
  var getband = function(landsat, bandname){
    var wrap = function(image){
      return image.select(bandname).rename(bandname.concat('_').concat(landsat));
    };
    return wrap;
  };
  var LandsatColl = filtered_L9.map(getband('L9', 'ST'))
    .merge(filtered_L8.map(getband('L8', 'ST')));
  function applyScaleFactors(image) {
    var thermalBands = image.select('ST.*').multiply(0.00341802).add(149.0)
      .subtract(273.15); // Convert from Kelvin to Celsius
    return image.addBands(thermalBands, null, true);
  }
  var landsatST = LandsatColl.map(applyScaleFactors);
  // Create and display the time series chart
  var TimeSeries = ui.Chart.image.series(
      landsatST, aoi, ee.Reducer.mean(), 30, 'system:time_start')
          .setChartType('LineChart')
          .setOptions({
            title: 'Landsat Surface Temperature Time Series',
            vAxis: {title: 'Surface Temperature (Celsius)'},
            hAxis: {title: 'Date'},
            lineWidth: 0.5,
            pointSize: 3.5,
            curveType: 'function'
          });
  // Clear previous chart and add new chart to the chart panel
  chartPanel.clear();
  chartPanel.add(TimeSeries);
}
// Set the drawing tools to trigger the function when a shape is completed
drawingTools.onDraw(handleDrawingCompleted);
drawingTools.onEdit(handleDrawingCompleted);