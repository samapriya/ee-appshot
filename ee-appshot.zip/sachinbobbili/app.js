/*SRTM Data download for all districts of India*/
//Data Source Information
var DEM = ee.Image("USGS/SRTMGL1_003")
var India = ee.FeatureCollection("users/sachinbobbili/India_Dist");
var AOI = India.filter(ee.Filter.eq('dtname', 'Medak'));// Edit district name here, you may exact name of district in 
var places = {
'Kupwara':0,
'Bandipore':0,
 'Baramula':0,
 'Ganderbal':0,
 'Anantnag':0,
'Kishtwar':0,
 'Srinagar':0,
 'Badgam':0,
 'Pulwama':0,
'Punch':0,
 'Shupiyan':0,
 'Kulgam':0,
'Rajouri':0,
'Ramban':0
};
var select = ui.Select({
  items: Object.keys(places),
  onChange: function(key) {
    select.setPlaceholder(key);
  }
});
print(select);
var button = ui.Button({
  label: 'Submit',
  onClick: function() {
    print(select.getPlaceholder());
    var AOI = India.filter(ee.Filter.eq('dtname', select.getPlaceholder()));// Edit district name here, you may exact name of district in 
    // Adding Data to desktop for visualization
    Map.centerObject(AOI);// Zoom to AOI
    var AOI_DEM = DEM.clip(AOI);// Cliping Data
    Map.addLayer(AOI_DEM,  {'min':0,'max': 500,'palette': ["a0b8b5", "bf8e8e", "fffd99", 
                             "c1d48c", "dfc1eb", "f2b983", "cbf7fa", "94995c", "d791f2",
                             "f5e6a4", "b8e3d0", "e8c4b2"]}); //Edit colour,Max and Min Value(m) here
    ///////////////////////////////////////////////////////////////
//      3) Set up panels and widgets for display             //
///////////////////////////////////////////////////////////////
//3.1) Set up title and summary widgets
//App title
var header = ui.Label('Guyana Mangrove Height, Extent, and Loss Explorer', {fontSize: '25px', fontWeight: 'bold', color: '4A997E'});
//App summary
var text = ui.Label(
  'This tool maps mangrove extent in the Guyana in 2000, 2010, and 2020 using a Random Forest Classification derived from Landsat imagery. ' +
  'Use the tools below to explore changes in mangrove extent, mangrove canopy height in 2000, and drivers of mangrove loss.',
    {fontSize: '15px'});
//3.2) Create a panel to hold text
var panel = ui.Panel({
  widgets:[header, text],//Adds header and text
  style:{width: '300px',position:'middle-right'}});
//3.3) Create variable for additional text and separators
//This creates another panel to house a line separator and instructions for the user
var intro = ui.Panel([
  ui.Label({
    value: '____________________________________________',
    style: {fontWeight: 'bold',  color: '4A997E'},
  }),
  ui.Label({
    value:'Select layers to display.',
    style: {fontSize: '15px', fontWeight: 'bold'}
  })]);
//Add this new panel to the larger panel we created 
panel.add(intro)
//3.4) Add our main panel to the root of our GUI
ui.root.insert(1,panel)
  }
});
print(button);
var header  =  ui.Label('Guyana  Mangrove  Height,  Extent,  and  Loss  Explorer', {fontSize: '25px',  fontWeight: 'bold', color: '4A997E'});