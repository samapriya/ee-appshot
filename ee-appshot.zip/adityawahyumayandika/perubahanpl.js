var wilKajian = ui.import && ui.import("wilKajian", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                123.94677035720935,
                0.9263448974336189
              ],
              [
                123.94677035720935,
                0.7821654055391953
              ],
              [
                124.14040439041247,
                0.7821654055391953
              ],
              [
                124.14040439041247,
                0.9263448974336189
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[123.94677035720935, 0.9263448974336189],
          [123.94677035720935, 0.7821654055391953],
          [124.14040439041247, 0.7821654055391953],
          [124.14040439041247, 0.9263448974336189]]], null, false),
    imageVisParam = ui.import && ui.import("imageVisParam", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "B4",
          "B3",
          "B2"
        ],
        "min": 61,
        "max": 993,
        "gamma": 1
      }
    }) || {"opacity":1,"bands":["B4","B3","B2"],"min":61,"max":993,"gamma":1},
    srtm = ui.import && ui.import("srtm", "image", {
      "id": "USGS/SRTMGL1_003"
    }) || ee.Image("USGS/SRTMGL1_003"),
    air = ui.import && ui.import("air", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            123.94559388774366,
            0.8907328337573235
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.95486360209912,
            0.8776881226455235
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.9922857822749,
            0.8907328337573235
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.02215486186475,
            0.9075535771989218
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.05442720073194,
            0.9188817889934153
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.04550080913037,
            0.9226578516305413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0252447666499,
            0.925747354444266
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.99503236430616,
            0.9226578516305413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.96001344340772,
            0.919568346133904
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.94628053325147,
            0.9175086743167133
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.94044404643506,
            0.9140758853210216
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.9534903110835,
            0.9106430930438498
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.95486360209912,
            0.902747658420191
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.95795350688428,
            0.8986282944100439
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.958983475146,
            0.8921059585684432
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.96550660747022,
            0.8917626774136737
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.94113069194287,
            0.8711657499853384
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.93495088237256,
            0.89416564482408
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.93495088237256,
            0.9137326062407626
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.94319062846631,
            0.9161355591129934
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.97271638530225,
            0.9240309643239512
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.99400239604444,
            0.9144191643684446
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 0
      },
      "color": "#1f02ff",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #1f02ff */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([123.94559388774366, 0.8907328337573235]),
            {
              "class": 0,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([123.95486360209912, 0.8776881226455235]),
            {
              "class": 0,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([123.9922857822749, 0.8907328337573235]),
            {
              "class": 0,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([124.02215486186475, 0.9075535771989218]),
            {
              "class": 0,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([124.05442720073194, 0.9188817889934153]),
            {
              "class": 0,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([124.04550080913037, 0.9226578516305413]),
            {
              "class": 0,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0252447666499, 0.925747354444266]),
            {
              "class": 0,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([123.99503236430616, 0.9226578516305413]),
            {
              "class": 0,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([123.96001344340772, 0.919568346133904]),
            {
              "class": 0,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([123.94628053325147, 0.9175086743167133]),
            {
              "class": 0,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([123.94044404643506, 0.9140758853210216]),
            {
              "class": 0,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([123.9534903110835, 0.9106430930438498]),
            {
              "class": 0,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([123.95486360209912, 0.902747658420191]),
            {
              "class": 0,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([123.95795350688428, 0.8986282944100439]),
            {
              "class": 0,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([123.958983475146, 0.8921059585684432]),
            {
              "class": 0,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([123.96550660747022, 0.8917626774136737]),
            {
              "class": 0,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([123.94113069194287, 0.8711657499853384]),
            {
              "class": 0,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([123.93495088237256, 0.89416564482408]),
            {
              "class": 0,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([123.93495088237256, 0.9137326062407626]),
            {
              "class": 0,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([123.94319062846631, 0.9161355591129934]),
            {
              "class": 0,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([123.97271638530225, 0.9240309643239512]),
            {
              "class": 0,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([123.99400239604444, 0.9144191643684446]),
            {
              "class": 0,
              "system:index": "21"
            })]),
    hutan = ui.import && ui.import("hutan", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            123.95314698832959,
            0.7994189241624028
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.96173005717725,
            0.7880903604955369
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.01563172954053,
            0.7860306183237387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0197516025874,
            0.814523627024343
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.01116853373975,
            0.8093743028106304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.002928787646,
            0.7997622134848239
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.99571900981397,
            0.7860306183237387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.03451448100537,
            0.7801946766623021
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.03108125346631,
            0.8110907449436755
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.02764802592725,
            0.7966726085508418
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.02078157084912,
            0.8080011485810846
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.00533204692334,
            0.814523627024343
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.98782258647412,
            0.7949561603636744
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.98301606791944,
            0.785344037373923
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.96276002543897,
            0.7805379675729397
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.94696717875928,
            0.7791648037623801
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.94387727397412,
            0.7774483483698951
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.94181733745069,
            0.7963293189705667
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.9373541416499,
            0.8076578599511466
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.93220430034131,
            0.8124638981260555
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.97168641704053,
            0.7808812584555501
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.980956131396,
            0.8042249720590714
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.98782258647412,
            0.8165833548699052
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.9754629673335,
            0.8213893824007824
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.97237306254834,
            0.8169266427416372
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.96687989848584,
            0.8134937627066261
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.03932099956006,
            0.7973591876255806
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.04618745463819,
            0.7839708751360459
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.14506440776319,
            0.7994189241624028
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.16944032329053,
            0.7836275845061877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.17768006938428,
            0.7836275845061877
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.17184358256787,
            0.8093743028106304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.1680670322749,
            0.8049115498688654
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.16120057719678,
            0.8021652379371808
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.15570741313428,
            0.7990756348112675
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.16394715922803,
            0.7819111309351429
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.00704866069287,
            0.7915232670886121
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.00567536967725,
            0.7918665570680087
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.00636201518506,
            0.7908366870445674
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.00807862895459,
            0.7908366870445674
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.00361543315381,
            0.7904933969799576
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.96104341166944,
            0.7753886062161751
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.96104341166944,
            0.7736721492906119
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.95520692485303,
            0.7812245545483417
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.95623689311475,
            0.7808812636937456
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.95658021586866,
            0.7747020235293821
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.17974000590772,
            0.7856873331011288
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.17974000590772,
            0.7815678453748599
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.18008332866162,
            0.778478226927426
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.18111329692334,
            0.7757318975178428
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.16429048198194,
            0.7935830065383517
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.16600709575147,
            0.7839708803742413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.16600709575147,
            0.7839708803742413
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.16600709575147,
            0.7822544269437387
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06713014262647,
            0.7913516220882526
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07159333842725,
            0.7872321399524446
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0743399204585,
            0.7865455592002176
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07880311625928,
            0.79306807177196
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.08223634379834,
            0.7937546514462334
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 1
      },
      "color": "#17b82c",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #17b82c */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([123.95314698832959, 0.7994189241624028]),
            {
              "class": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([123.96173005717725, 0.7880903604955369]),
            {
              "class": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([124.01563172954053, 0.7860306183237387]),
            {
              "class": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0197516025874, 0.814523627024343]),
            {
              "class": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([124.01116853373975, 0.8093743028106304]),
            {
              "class": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([124.002928787646, 0.7997622134848239]),
            {
              "class": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([123.99571900981397, 0.7860306183237387]),
            {
              "class": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([124.03451448100537, 0.7801946766623021]),
            {
              "class": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([124.03108125346631, 0.8110907449436755]),
            {
              "class": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([124.02764802592725, 0.7966726085508418]),
            {
              "class": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([124.02078157084912, 0.8080011485810846]),
            {
              "class": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([124.00533204692334, 0.814523627024343]),
            {
              "class": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([123.98782258647412, 0.7949561603636744]),
            {
              "class": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([123.98301606791944, 0.785344037373923]),
            {
              "class": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([123.96276002543897, 0.7805379675729397]),
            {
              "class": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([123.94696717875928, 0.7791648037623801]),
            {
              "class": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([123.94387727397412, 0.7774483483698951]),
            {
              "class": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([123.94181733745069, 0.7963293189705667]),
            {
              "class": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([123.9373541416499, 0.8076578599511466]),
            {
              "class": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([123.93220430034131, 0.8124638981260555]),
            {
              "class": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([123.97168641704053, 0.7808812584555501]),
            {
              "class": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([123.980956131396, 0.8042249720590714]),
            {
              "class": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([123.98782258647412, 0.8165833548699052]),
            {
              "class": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([123.9754629673335, 0.8213893824007824]),
            {
              "class": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([123.97237306254834, 0.8169266427416372]),
            {
              "class": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([123.96687989848584, 0.8134937627066261]),
            {
              "class": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([124.03932099956006, 0.7973591876255806]),
            {
              "class": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([124.04618745463819, 0.7839708751360459]),
            {
              "class": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([124.14506440776319, 0.7994189241624028]),
            {
              "class": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([124.16944032329053, 0.7836275845061877]),
            {
              "class": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([124.17768006938428, 0.7836275845061877]),
            {
              "class": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([124.17184358256787, 0.8093743028106304]),
            {
              "class": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([124.1680670322749, 0.8049115498688654]),
            {
              "class": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([124.16120057719678, 0.8021652379371808]),
            {
              "class": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([124.15570741313428, 0.7990756348112675]),
            {
              "class": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([124.16394715922803, 0.7819111309351429]),
            {
              "class": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([124.00704866069287, 0.7915232670886121]),
            {
              "class": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([124.00567536967725, 0.7918665570680087]),
            {
              "class": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([124.00636201518506, 0.7908366870445674]),
            {
              "class": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([124.00807862895459, 0.7908366870445674]),
            {
              "class": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([124.00361543315381, 0.7904933969799576]),
            {
              "class": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([123.96104341166944, 0.7753886062161751]),
            {
              "class": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([123.96104341166944, 0.7736721492906119]),
            {
              "class": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([123.95520692485303, 0.7812245545483417]),
            {
              "class": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([123.95623689311475, 0.7808812636937456]),
            {
              "class": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([123.95658021586866, 0.7747020235293821]),
            {
              "class": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([124.17974000590772, 0.7856873331011288]),
            {
              "class": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([124.17974000590772, 0.7815678453748599]),
            {
              "class": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([124.18008332866162, 0.778478226927426]),
            {
              "class": 1,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([124.18111329692334, 0.7757318975178428]),
            {
              "class": 1,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([124.16429048198194, 0.7935830065383517]),
            {
              "class": 1,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([124.16600709575147, 0.7839708803742413]),
            {
              "class": 1,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([124.16600709575147, 0.7839708803742413]),
            {
              "class": 1,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([124.16600709575147, 0.7822544269437387]),
            {
              "class": 1,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06713014262647, 0.7913516220882526]),
            {
              "class": 1,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07159333842725, 0.7872321399524446]),
            {
              "class": 1,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0743399204585, 0.7865455592002176]),
            {
              "class": 1,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07880311625928, 0.79306807177196]),
            {
              "class": 1,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([124.08223634379834, 0.7937546514462334]),
            {
              "class": 1,
              "system:index": "58"
            })]),
    bareSoil = ui.import && ui.import("bareSoil", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            123.98713594096631,
            0.8560612648309538
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.98164277690381,
            0.8656732168795421
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.98541932719678,
            0.8684194844300848
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.97855287211866,
            0.8574344023193702
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.97649293559522,
            0.8498821400593916
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.99400239604444,
            0.8540015576765793
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.99915223735303,
            0.8515985646017175
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.99640565532178,
            0.85091199487641
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.02970796245069,
            0.8557179803819821
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.02661805766553,
            0.8495388550593442
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.03245454448194,
            0.85091199487641
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.03691774028272,
            0.8495388550593442
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.04035096782178,
            0.8478224296018709
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.02833467143506,
            0.8848970476117161
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.02764802592725,
            0.8790612522853104
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.02661805766553,
            0.8756284272408303
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.02661805766553,
            0.8711657499853384
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.03897767680616,
            0.8969118913668682
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.035887772021,
            0.8921059585684432
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.03382783549756,
            0.8800910991838291
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06541352885694,
            0.8780314051027682
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07914643901319,
            0.8859268928945002
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.08498292582959,
            0.8831806381719234
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0911627353999,
            0.8818075100492864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.09493928569287,
            0.8783746875284747
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.09699922221631,
            0.8763149925015932
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.11794191020459,
            0.8728821649413452
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.1182852329585,
            0.8718523160616464
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.11210542338819,
            0.8598373917385278
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.11073213237256,
            0.8567478336366866
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.11141877788037,
            0.8536582730434915
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.12549501079053,
            0.7882620108687692
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.12274842875928,
            0.7868888495904528
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.05477052348584,
            0.8785463339675899
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.05305390971631,
            0.8764866390352091
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.05133729594678,
            0.8764866390352091
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0743399204585,
            0.8871283839340053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07399659770459,
            0.8871283839340053
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07605653422803,
            0.8840388482290704
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07708650248975,
            0.8823224383927515
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07708650248975,
            0.9111580173321586
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.08223634379834,
            0.9080685019279536
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0856695713374,
            0.9066953831224082
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.12171846049756,
            0.872023962799263
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.12103181498975,
            0.8699642642889235
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.11656861918897,
            0.8576060497089114
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.12171846049756,
            0.8545164898068763
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.10111909526319,
            0.7862022687817519
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.10386567729444,
            0.7827693630466885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.10558229106397,
            0.7827693630466885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.10386567729444,
            0.7827693630466885
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.10146241801709,
            0.7837992350628363
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.96893983500928,
            0.8514269274199628
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.97271638530225,
            0.8493672177859897
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07365327495069,
            0.8026801768031293
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07227998393506,
            0.8013070203184304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07365327495069,
            0.7978741270946895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07330995219678,
            0.7978741270946895
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07777314799756,
            0.8819791563304044
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.08429628032178,
            0.8830090024223726
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0381035596652,
            0.5883979572088456
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0403351575656,
            0.5938908289007304
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.04239509408903,
            0.6031600374769106
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.04497001474333,
            0.6110560175254824
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.04926154916716,
            0.6143173972108322
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.05320976083708,
            0.6112276691373245
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06728599374723,
            0.6107127142853483
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06539771860075,
            0.5962939585524523
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06144950693083,
            0.5964656106303348
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.05629966562223,
            0.6017868223818151
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.002226331882,
            0.5880546525480214
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.00892112558317,
            0.5885696095313508
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.01183936899137,
            0.5902861324654589
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.01080940072966,
            0.5796436817926988
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.98780677621794,
            0.5846216047805434
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.99038169687223,
            0.5815318599948492
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.99175498788786,
            0.5784421135179779
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.99003837411833,
            0.5799869869672589
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.98506019418669,
            0.5829050801089237
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.9773354322238,
            0.581360207457084
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.97544715707731,
            0.5798153343825742
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            123.97544715707731,
            0.5784421135179779
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07930229013395,
            0.5868530860689272
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.08822868173552,
            0.587024738438899
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.09252021615934,
            0.587024738438899
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.09629676645231,
            0.5849649096519457
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.11020133798552,
            0.5998986510617871
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.10796974008512,
            0.5952640459727696
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.08994529550505,
            0.6023017780830249
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.08943031137419,
            0.6117426239399131
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.08960197275114,
            0.6153473061720995
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.09131858652067,
            0.6194669400255439
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.09183357065153,
            0.6127725333968254
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.08908698862028,
            0.6072796806801043
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0842804700656,
            0.6055631630591001
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.08359382455778,
            0.6211834531871433
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0846237928195,
            0.6204968479893129
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 2
      },
      "color": "#c8c2ab",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #c8c2ab */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([123.98713594096631, 0.8560612648309538]),
            {
              "class": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([123.98164277690381, 0.8656732168795421]),
            {
              "class": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([123.98541932719678, 0.8684194844300848]),
            {
              "class": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([123.97855287211866, 0.8574344023193702]),
            {
              "class": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([123.97649293559522, 0.8498821400593916]),
            {
              "class": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([123.99400239604444, 0.8540015576765793]),
            {
              "class": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([123.99915223735303, 0.8515985646017175]),
            {
              "class": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([123.99640565532178, 0.85091199487641]),
            {
              "class": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([124.02970796245069, 0.8557179803819821]),
            {
              "class": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([124.02661805766553, 0.8495388550593442]),
            {
              "class": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([124.03245454448194, 0.85091199487641]),
            {
              "class": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([124.03691774028272, 0.8495388550593442]),
            {
              "class": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([124.04035096782178, 0.8478224296018709]),
            {
              "class": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([124.02833467143506, 0.8848970476117161]),
            {
              "class": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([124.02764802592725, 0.8790612522853104]),
            {
              "class": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([124.02661805766553, 0.8756284272408303]),
            {
              "class": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([124.02661805766553, 0.8711657499853384]),
            {
              "class": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([124.03897767680616, 0.8969118913668682]),
            {
              "class": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([124.035887772021, 0.8921059585684432]),
            {
              "class": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([124.03382783549756, 0.8800910991838291]),
            {
              "class": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06541352885694, 0.8780314051027682]),
            {
              "class": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07914643901319, 0.8859268928945002]),
            {
              "class": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([124.08498292582959, 0.8831806381719234]),
            {
              "class": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0911627353999, 0.8818075100492864]),
            {
              "class": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([124.09493928569287, 0.8783746875284747]),
            {
              "class": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([124.09699922221631, 0.8763149925015932]),
            {
              "class": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([124.11794191020459, 0.8728821649413452]),
            {
              "class": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([124.1182852329585, 0.8718523160616464]),
            {
              "class": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([124.11210542338819, 0.8598373917385278]),
            {
              "class": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([124.11073213237256, 0.8567478336366866]),
            {
              "class": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([124.11141877788037, 0.8536582730434915]),
            {
              "class": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([124.12549501079053, 0.7882620108687692]),
            {
              "class": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([124.12274842875928, 0.7868888495904528]),
            {
              "class": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([124.05477052348584, 0.8785463339675899]),
            {
              "class": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([124.05305390971631, 0.8764866390352091]),
            {
              "class": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([124.05133729594678, 0.8764866390352091]),
            {
              "class": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0743399204585, 0.8871283839340053]),
            {
              "class": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07399659770459, 0.8871283839340053]),
            {
              "class": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07605653422803, 0.8840388482290704]),
            {
              "class": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07708650248975, 0.8823224383927515]),
            {
              "class": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07708650248975, 0.9111580173321586]),
            {
              "class": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([124.08223634379834, 0.9080685019279536]),
            {
              "class": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0856695713374, 0.9066953831224082]),
            {
              "class": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([124.12171846049756, 0.872023962799263]),
            {
              "class": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([124.12103181498975, 0.8699642642889235]),
            {
              "class": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([124.11656861918897, 0.8576060497089114]),
            {
              "class": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([124.12171846049756, 0.8545164898068763]),
            {
              "class": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([124.10111909526319, 0.7862022687817519]),
            {
              "class": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([124.10386567729444, 0.7827693630466885]),
            {
              "class": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([124.10558229106397, 0.7827693630466885]),
            {
              "class": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([124.10386567729444, 0.7827693630466885]),
            {
              "class": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([124.10146241801709, 0.7837992350628363]),
            {
              "class": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([123.96893983500928, 0.8514269274199628]),
            {
              "class": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([123.97271638530225, 0.8493672177859897]),
            {
              "class": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07365327495069, 0.8026801768031293]),
            {
              "class": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07227998393506, 0.8013070203184304]),
            {
              "class": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07365327495069, 0.7978741270946895]),
            {
              "class": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07330995219678, 0.7978741270946895]),
            {
              "class": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07777314799756, 0.8819791563304044]),
            {
              "class": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([124.08429628032178, 0.8830090024223726]),
            {
              "class": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0381035596652, 0.5883979572088456]),
            {
              "class": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0403351575656, 0.5938908289007304]),
            {
              "class": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([124.04239509408903, 0.6031600374769106]),
            {
              "class": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([124.04497001474333, 0.6110560175254824]),
            {
              "class": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([124.04926154916716, 0.6143173972108322]),
            {
              "class": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([124.05320976083708, 0.6112276691373245]),
            {
              "class": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06728599374723, 0.6107127142853483]),
            {
              "class": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06539771860075, 0.5962939585524523]),
            {
              "class": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06144950693083, 0.5964656106303348]),
            {
              "class": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([124.05629966562223, 0.6017868223818151]),
            {
              "class": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([124.002226331882, 0.5880546525480214]),
            {
              "class": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([124.00892112558317, 0.5885696095313508]),
            {
              "class": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([124.01183936899137, 0.5902861324654589]),
            {
              "class": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([124.01080940072966, 0.5796436817926988]),
            {
              "class": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([123.98780677621794, 0.5846216047805434]),
            {
              "class": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([123.99038169687223, 0.5815318599948492]),
            {
              "class": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([123.99175498788786, 0.5784421135179779]),
            {
              "class": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([123.99003837411833, 0.5799869869672589]),
            {
              "class": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([123.98506019418669, 0.5829050801089237]),
            {
              "class": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([123.9773354322238, 0.581360207457084]),
            {
              "class": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([123.97544715707731, 0.5798153343825742]),
            {
              "class": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([123.97544715707731, 0.5784421135179779]),
            {
              "class": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07930229013395, 0.5868530860689272]),
            {
              "class": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([124.08822868173552, 0.587024738438899]),
            {
              "class": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([124.09252021615934, 0.587024738438899]),
            {
              "class": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([124.09629676645231, 0.5849649096519457]),
            {
              "class": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([124.11020133798552, 0.5998986510617871]),
            {
              "class": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([124.10796974008512, 0.5952640459727696]),
            {
              "class": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([124.08994529550505, 0.6023017780830249]),
            {
              "class": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([124.08943031137419, 0.6117426239399131]),
            {
              "class": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([124.08960197275114, 0.6153473061720995]),
            {
              "class": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([124.09131858652067, 0.6194669400255439]),
            {
              "class": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([124.09183357065153, 0.6127725333968254]),
            {
              "class": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([124.08908698862028, 0.6072796806801043]),
            {
              "class": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0842804700656, 0.6055631630591001]),
            {
              "class": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([124.08359382455778, 0.6211834531871433]),
            {
              "class": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0846237928195, 0.6204968479893129]),
            {
              "class": 2,
              "system:index": "96"
            })]),
    Mangrove = ui.import && ui.import("Mangrove", "geometry", {
      "geometries": [
        {
          "type": "Point",
          "coordinates": [
            124.06541352885694,
            0.9078968568677361
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06507020610303,
            0.9089266956785622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06507020610303,
            0.9089266956785622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06301026957959,
            0.9078968568677361
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06266694682569,
            0.9089266956785622
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06129365581006,
            0.9020610980753443
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06266694682569,
            0.8993148554015864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06266694682569,
            0.8993148554015864
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06266694682569,
            0.8986282944100439
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06163697856397,
            0.90034469664672
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.0633535923335,
            0.8986282944100439
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.06953340190381,
            0.9072102974975259
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.07056337016553,
            0.9051506186056619
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.05580049174756,
            0.9113296517612067
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.05683046000928,
            0.9102998136361209
          ]
        },
        {
          "type": "Point",
          "coordinates": [
            124.05992036479444,
            0.9109863724188827
          ]
        }
      ],
      "displayProperties": [],
      "properties": {
        "class": 3
      },
      "color": "#1f6c12",
      "mode": "FeatureCollection",
      "shown": false,
      "locked": false
    }) || 
    /* color: #1f6c12 */
    /* shown: false */
    ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([124.06541352885694, 0.9078968568677361]),
            {
              "class": 3,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06507020610303, 0.9089266956785622]),
            {
              "class": 3,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06507020610303, 0.9089266956785622]),
            {
              "class": 3,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06301026957959, 0.9078968568677361]),
            {
              "class": 3,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06266694682569, 0.9089266956785622]),
            {
              "class": 3,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06129365581006, 0.9020610980753443]),
            {
              "class": 3,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06266694682569, 0.8993148554015864]),
            {
              "class": 3,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06266694682569, 0.8993148554015864]),
            {
              "class": 3,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06266694682569, 0.8986282944100439]),
            {
              "class": 3,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06163697856397, 0.90034469664672]),
            {
              "class": 3,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([124.0633535923335, 0.8986282944100439]),
            {
              "class": 3,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([124.06953340190381, 0.9072102974975259]),
            {
              "class": 3,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([124.07056337016553, 0.9051506186056619]),
            {
              "class": 3,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([124.05580049174756, 0.9113296517612067]),
            {
              "class": 3,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([124.05683046000928, 0.9102998136361209]),
            {
              "class": 3,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([124.05992036479444, 0.9109863724188827]),
            {
              "class": 3,
              "system:index": "15"
            })]),
    imageVisParam2 = ui.import && ui.import("imageVisParam2", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "remapped"
        ],
        "palette": [
          "ff0000"
        ]
      }
    }) || {"opacity":1,"bands":["remapped"],"palette":["ff0000"]},
    imageVisParam3 = ui.import && ui.import("imageVisParam3", "imageVisParam", {
      "params": {
        "opacity": 1,
        "bands": [
          "classification"
        ],
        "min": 0,
        "max": 3,
        "palette": [
          "02d0ff",
          "0bd408",
          "ffb819",
          "39ba18"
        ]
      }
    }) || {"opacity":1,"bands":["classification"],"min":0,"max":3,"palette":["02d0ff","0bd408","ffb819","39ba18"]};
// fungsi masking
function maskL8sr(image) {
  // Bits 3 and 5 are cloud shadow and cloud, respectively.
  var cloudShadowBitMask = (1 << 3);
  var cloudsBitMask = (1 << 5);
  // Get the pixel QA band.
  var qa = image.select('pixel_qa');
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudShadowBitMask).eq(0)
                 .and(qa.bitwiseAnd(cloudsBitMask).eq(0));
  return image.updateMask(mask).clip(wilKajian);
}
// panggil data
var dataset = ee.ImageCollection('LANDSAT/LC08/C01/T1_SR')
                  .filterBounds(wilKajian)
                  .filterDate('2016-01-01', '2020-12-31')
                  .map(maskL8sr);
// buat data tahunan
var tahun = ee.List.sequence(2016, 2020);
var landsatCol = ee.ImageCollection(tahun.map(function(year){
  var mulai = ee.Date.fromYMD(year, 1, 1);
  var akhir = mulai.advance(1, 'year');
  var col = dataset.filter(ee.Filter.date(mulai, akhir)).select('B[1-7]');
  var img = col.median()
                .addBands(srtm.clip(wilKajian))
                .set('tahun', year);
  return img;
}));
var l8Tahunan = landsatCol.toList(landsatCol.size());
// panggil data tahun 2016 dan 2020
var tahun2016 = ee.Image(l8Tahunan.get(0));
var tahun2020 = ee.Image(l8Tahunan.get(4));
// persiapan sample
var sample = air.merge(hutan).merge(bareSoil).merge(Mangrove);
var sample = tahun2020.sampleRegions({
  collection: sample,
  properties: ['class'],
  scale: 30
});
var withRandom = sample.randomColumn('random');
var split = 0.7;  
var trainingPartition = withRandom.filter(ee.Filter.lt('random', split));
var testingPartition = withRandom.filter(ee.Filter.gte('random', split));
// membuat model RF
var bands = tahun2020.bandNames();
// print(bands)
var trainedClassifier = ee.Classifier.smileRandomForest(5).train({
  features: trainingPartition,
  classProperty: 'class',
  inputProperties: bands
});
// apply ke citra dan melakukan post processing
var classified2020 = tahun2020.classify(trainedClassifier).focal_mode();
var classified2016 = tahun2016.classify(trainedClassifier).focal_mode();
// tampilkan ke peta
Map.centerObject(wilKajian, 12)
Map.addLayer(tahun2016.eq(2).selfMask(), imageVisParam, 'tahun 2016', 0);
Map.addLayer(tahun2020.eq(2).selfMask(), imageVisParam, 'tahun 2020', 0);
Map.addLayer(classified2016, imageVisParam3,'pl tahun 2016', 1);
Map.addLayer(classified2020, imageVisParam3, 'pl tahun 2020', 1);
// remap
var remap2016 = classified2020.remap([0, 1, 2, 3], [1, 2, 1, 2]).multiply(10);
var remap2020 = classified2016.remap([0, 1, 2, 3], [1, 2, 1, 2]);
var defor = remap2016.add(remap2020).eq(21).selfMask();
// tampilkan remap ke peta
Map.addLayer(remap2016.randomVisualizer(), {}, 'remap2016', 0);
Map.addLayer(remap2020.randomVisualizer(), {}, 'remap2020', 0);
Map.addLayer(defor, imageVisParam2, 'perubahan hutan ke non hutan', 0);
var stats = defor.reduceRegion({
  reducer: ee.Reducer.sum(),
  geometry: wilKajian,
  scale: 30,
  maxPixels: 1e9
});
// print(
//   'Deforestasi',
//   stats,
//   'square meters'
// );
// -------------------------------------------------------------------- layout -------------------------------------------------------------------------------------
var myChange = [
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#ebe3cd"
      }
    ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#523735"
      }
    ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#f5f1e6"
      }
    ]
  },
  {
    "featureType": "administrative",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#c9b2a6"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#dcd2be"
      }
    ]
  },
  {
    "featureType": "administrative.land_parcel",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#ae9e90"
      }
    ]
  },
  {
    "featureType": "landscape.natural",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#93817c"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#a5b076"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#447530"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f5f1e6"
      }
    ]
  },
  {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#fdfcf8"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#f8c967"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#e9bc62"
      }
    ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#e98d58"
      }
    ]
  },
  {
    "featureType": "road.highway.controlled_access",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#db8555"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#806b63"
      }
    ]
  },
  {
    "featureType": "transit",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "transit.line",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
    ]
  },
  {
    "featureType": "transit.line",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#8f7d77"
      }
    ]
  },
  {
    "featureType": "transit.line",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#ebe3cd"
      }
    ]
  },
  {
    "featureType": "transit.station",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#dfd2ae"
      }
    ]
  },
  {
    "featureType": "water",
    "stylers": [
      {
        "visibility": "on"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#94c9fe"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry.fill",
    "stylers": [
      {
        "color": "#a9dae2"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#92998d"
      }
    ]
  }
];
Map.setOptions('mapStyle', {mapStyle: myChange});
var infoPanel = ui.Panel({
    style: {
      //stretch: 'horizontal',
      height: '100%',
      width: '30%',
      backgroundColor: '#11ffee00',
    }
});
ui.root.add(infoPanel);
var TITLE_STYLE = {
  fontWeight: '100',
  fontSize: '32px',
  padding: '8px',
  color: '#616161',
  backgroundColor: '#11ffee00',
};
var PARAGRAPH_STYLE = {
  fontSize: '20px',
  fontWeight: '50',
  color: '#616161',
  padding: '8px',
  maxWidth: '500px',
  backgroundColor: '#11ffee00',
};
var LEGEND_TITLE = {
  fontSize: '25px',
  fontWeight: '50',
  color: '#616161',
  maxWidth: '500px',
  backgroundColor: '#11ffee00',
};
var LEGEND = {
          margin: '0 0 4px 6px', 
          fontSize: '20px',
          fontWeight: '50',
          color: '#616161',
          //padding: '8px',
          maxWidth: '500px',
          backgroundColor: '#11ffee00'
};
infoPanel.add(ui.Label('Peta Perubahan Penutup Lahan', TITLE_STYLE));
var app_description = 'Ini merupakan latihan apps sederhana." ' + 
'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'+ 
'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.' +
'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';
infoPanel.add(ui.Label(app_description, PARAGRAPH_STYLE));
// set posisi
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px',
    width: '20%'
  }
});
// membuat title pada legend
var legendTitle = ui.Label({
  value: 'Legenda',
  style: LEGEND_TITLE
});
// tambahkan title ke legend
legend.add(legendTitle);
// membuat legenda dari legend
var makeRow = function(color, name) {
      // buat kotak warna
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '15px',
          margin: '0px 0px 4px 0px'
        }
      });
      // buat deskripsi
      var description = ui.Label({
        value: name,
        style: LEGEND,
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
//  menentukan pallete untuk legenda
var palette =['02d0ff','0bd408','ffb819','39ba18'];
// nama legenda
var names = ['Tubuh Air','Hutan Kering','Lahan Pertanian', 'Hutan Mangrove'];
// menambahkan nama dan warna
for (var i = 0; i < 4; i++) {
  legend.add(makeRow(palette[i], names[i]));
}  
// menambahkan legenda ke map
Map.add(legend);
// ------------------------------------------------------- membuat grafik-------------------------------------------------
// list kelas
var classList = ['Air', 'Hutan Kering', 'Lahan Pertanian', 'Hutan Mangrove'];
var create_chart = function(classification, AOI, classList, judul){ 
  var options = {
    hAxis: {title: 'Class'},
    vAxis: {title: 'Area'},
    title: judul,
    height: '25%',
    color: '#616161',
    series: { 
      0: {color: '02d0ff'},
      1: {color: '0bd408'},
      2: {color: 'ffb819'},
      3: {color: '39ba18'}}
  };
  // grafik batang berdasarkan luasan
  var areaChart = ui.Chart.image.byClass({
    image: ee.Image.pixelArea().addBands(classification),
    classBand: 'classification', 
    scale: 30,
    region: AOI,
    reducer: ee.Reducer.sum()
  }).setSeriesNames(classList)
  .setOptions(options);
  infoPanel.add(areaChart);
};
// apply fungsi untuk membuat grafik
var luasChart1 = create_chart(classified2016, wilKajian, classList, 'Luas Penutup Lahan 2016');
var luasChart2 = create_chart(classified2020, wilKajian, classList, 'Luas Penutup Lahan 2020');