var forest_2010 = ui.import && ui.import("forest_2010", "image", {
      "id": "projects/ee-narayanthapa/assets/forest_2010_updated"
    }) || ee.Image("projects/ee-narayanthapa/assets/forest_2010_updated"),
    forest_2020 = ui.import && ui.import("forest_2020", "image", {
      "id": "projects/ee-narayanthapa/assets/forest_2020_updated"
    }) || ee.Image("projects/ee-narayanthapa/assets/forest_2020_updated");
/// Model section ///
////// chat gpt code ///
// Import the Nightlight dataset
// var nightlight_1992 = forest_2020
// //print(forest_2010)
// var nightlight_2014 = forest_2010
var forestvis_2020= {bands: ['l20', 'c20', 'b20'],
  max: [10, 10, 10]}
var forestvis_2010={ bands: ['b1', 'c10', 'b10'],
  max: [10, 10, 10]
}
// Map.addLayer(forest_2020,{ 
// }, 'forest cover, loss, gain 2020')
// // Filter the data by year range
// var night_vis= {
//   bands:['b1'],
//   min:1,
//   max:11,
//   palette:['0046c7','368BC1','729DC8','228B22','556061','fa0000','f096ff','b4b4b4','9b7653','447741','fae6a0']
// }
var forestarea_2010=ee.Dictionary({ 'Gain in forest': 4396.2,
'Loss in forest':2615.8,
'No change forest': 55762.42})
var forestarea_2020=ee.Dictionary({'Gain in forest': 8848.2,
'Loss in forest': 3650.8,
'No change in forest': 54727.4})
var chartStyle = {
  title: 'Forest Loss and Gain of 2020 with respect to 2000 (Area in square km)',
  hAxis: {
    title: 'Categories',
    titleTextStyle: {italic: false, bold: true},
    gridlines: {color: 'FFFFFF'}
  },
  vAxis: {
    title: 'Area in square KM',
    titleTextStyle: {italic: false, bold: true},
    gridlines: {color: 'FFFFFF'},
    format: 'short',
    baselineColor: 'FFFFFF'
  },
  // series: {
  //   0: {lineWidth: 3, color: 'E37D05', pointSize: 7},
  //   1: {lineWidth: 7, color: '1D6B99', lineDashStyle: [4, 4]}
  // },
  chartArea: {backgroundColor: 'EBEBEB'},
  colors:['blue','red','green'],
};
var forest_chart=ui.Chart.array.values({
  array:forestarea_2020.values(),
  axis: 0,
  xLabels:forestarea_2020.keys(),
})//.setSeriesNames(area_2020.keys())
.setChartType('PieChart')///setChartType('PieChart')
.setOptions(chartStyle);
// Print the chart
//print(forest_chart);
//
//for 2010
var chartStyle_2010 = {
  title: 'Forest Loss and Gain of 2010 with respect to 2000 (Area in square km)',
  hAxis: {
    title: 'Categories',
    titleTextStyle: {italic: false, bold: true},
    gridlines: {color: 'FFFFFF'}
  },
  vAxis: {
    title: 'Area in square KM',
    titleTextStyle: {italic: false, bold: true},
    gridlines: {color: 'FFFFFF'},
    format: 'short',
    baselineColor: 'FFFFFF'
  },
  // series: {
  //   0: {lineWidth: 3, color: 'E37D05', pointSize: 7},
  //   1: {lineWidth: 7, color: '1D6B99', lineDashStyle: [4, 4]}
  // },
  chartArea: {backgroundColor: 'EBEBEB'},
  colors:['blue','red','green'],
};
// Define the chart.
// var chart =
//     ui.Chart.image
//         .doySeries({
//           imageCollection:
var forest_chart_2010=ui.Chart.array.values({
  array:forestarea_2010.values(),
  axis: 0,
  xLabels:forestarea_2010.keys(),
})//.setSeriesNames(area_2020.keys())
.setChartType('PieChart')///setChartType('PieChart')
.setOptions(chartStyle_2010);
// Print the chart
// Component section //
var c={};
//empty panel
c.controlPanel=ui.Panel();
// information
c.info={}
c.info.title=ui.Label("Assessing Two Decades of Forest Cover Change (2000-2020)");
c.info.subtitle=ui.Label('A Comprehensive Analysis of Forest Gain, Loss, and Stability, with Emphasis on 2000, 2010, and 2020 Land Cover Data of 30 meter resoultion. This product is available from regional database of ICIMOD.')
c.info.author= ui.Label('Developed by Narayan Thapa')
c.info.email=ui.Label('thapanarayan7571@gmail.com')
// c.info.author=ui.Label("Reshma Shrestha, Narayan Thapa, Sushma Ghimire, Rehana Shrestha , Sunil Babu Shrestha")
// c.info.about=ui.Label("This research aims in identifying the potential area at rooftop farming in Naya Basti Banepa and its methodological implication.     The results of the multi-criteria analysis for rooftop farming suitability revealed interesting findings based on the selected criteria. Among the evaluated rooftop areas, a significant portion, approximately 75.1%, exhibited moderate suitability for rooftop farming. This suggests that these areas possess favorable conditions and potential for successful agricultural activities. Additionally, 14.6% of the rooftop areas were classified as highly suitable, indicating exceptional suitability for rooftop farming. These areas likely fulfilled the criteria of having adequate water facility, a proportionate level of gardening, and a sufficient area for future farming. Conversely, 9.3% of the areas were found to have low suitability, implying potential constraints or limitations for rooftop farming. Notably, a small percentage of 0.9% demonstrated very high suitability, signifying exceptional rooftops that possess outstanding conditions and opportunities for agricultural endeavors. These outcomes highlight the importance of considering multiple criteria in assessing rooftop suitability and provide valuable insights for identifying the most suitable areas for implementing and promoting rooftop farming initiatives.")
// c.info.chart_title= ui.Label(" Result of Building");
// c.info.building= ui.Label("Total number of building in study area: 1055")
// c.info.concrete= ui.Label("Only concrete structure are considered for study as other have no access to roof")
// c.info.mixroof=ui.Label("Number of double roof building: 394");
// c.info.flatroof=ui.Label("Number of flat roof building: 176");
// c.info.greenroof=ui.Label("Number of house doing rooftop farming: 108 ")
// c.info.greenroofarea=ui.Label("Area used for rooftop farming: 505.42 square meter")
// c.info.estimated=ui.Label("Estimated area for rooftop farming is approximately: 48500 square meter ")
// creating the info panel
// Year from user
c.inputYear={}
c.inputYear.label1=ui.Label("Forest Loss and Gain in 2010 with respect to 2000")
c.inputYear.label2=ui.Label("Forest Loss and Gain in 2020 with respect to 2000")
// defining legend widiget
// Define a legend widget group.
/*composition***************************/
//default map
// dividing map into two component
c.leftmap=ui.Map({center: {lat:27.6332, lon:85.5277 , zoom:9}})
c.leftmap.setControlVisibility(false)
c.leftmap.setOptions('SATELLITE')
c.rightmap=ui.Map({center: {lat:27.6332, lon:85.5277, zoom:9}})
c.rightmap.setControlVisibility(true);
c.rightmap.setOptions('SATELLITE')
// Adding image to map:
var leftimage=ui.Map.Layer()
var rightimage=ui.Map.Layer()
c.rightmap.addLayer(forest_2020, forestvis_2020, 'Forest Loss and Gain of 2020 with respect to 2000')
c.leftmap.addLayer(forest_2010, forestvis_2010, 'Forest Loss and Gain of 2010 with respect to 2000')
c.splitPanel=ui.SplitPanel({
  firstPanel:c.leftmap,
  secondPanel:c.rightmap,
  orientation:'horizontal',
  wipe:true
})
ui.root.clear()
//adding to root
ui.root.add(c.controlPanel);
ui.root.add(c.splitPanel);
var linkPanel=ui.Map.Linker([c.rightmap, c.leftmap])
/***************************Style*****************/
/**************************Behaviour*************/
//Map.addLayer(nightlight_1992, night_vis, 'Night light 2000')
//Map.addLayer(nightlight_2014,night_vis,'Night light 2014')
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
//legend.add(night_vis)
// Add info
var info = ui.Panel({
  style: {
    position: 'bottom-center',
    padding: '8px 15px'
  }
});
var info1 = ui.Panel({
  style: {
    position: 'bottom-center',
    padding: '8px 15px'
  }
});
var info2 = ui.Label({
  value: 'Forest Loss and Gain of 2020 with respect to 2000',
  style: {
    fontSize: '16px',
    margin: '0 0 3px 0',
    padding: '0'
    }
});
var info3 = ui.Label({
  value: 'Forest Loss and Gain of 2010 with respect to 2000',
  style: {
    fontSize: '16px',
    margin: '0 0 3px 0',
    padding: '0'
    }
});
info.add(info2);
c.rightmap.add(info);
info1.add(info3)
c.leftmap.add(info1)
//Add legend
// Add map legend
var legend = ui.Panel({
  style: {
    position: 'bottom-right',
    padding: '8px 15px'
  }
});
var legend2 = ui.Label({
  value: 'Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '12px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
legend.add(legend2);
c.controlPanel.style().set({
  width:'600px',
  padding: '0px',
})
// Creates the content of the legend
var content = function(colour, label) {
      // Create the coloured boxes
      var box = ui.Label({
        style: {
          backgroundColor:colour,
          // Set box height and width
          padding: '9px',
          margin: '0 0 4px 0'
        }
      });
      // Create the labels
      var labels = ui.Label({
        value: label,
        style: {margin: '0 0 4px 6px'}
      });
      return ui.Panel({
        widgets: [box, labels],
        layout: ui.Panel.Layout.Flow('horizontal'),
      });
};
c.info.title.style().set({
  fontSize:'20px',
    fontWeight:'bold'
})
c.info.author.style().set({
  fontSize:16,
  color:'red'
})
//  Set legend colours
var classColour = ['blue','green','red','black'];
// Set legend labels
var labelName = ['Gain','No change','Loss','Other'];
// Combine legend colour and labels
for (var i = 0; i < 4; i++) {
  legend.add(content(classColour[i], labelName[i]));
  }  
// Add legend
c.rightmap.add(legend);
c.infoPanel=ui.Panel([c.info.title, c.info.subtitle]);//forest_chart_2010, //forest_chart, ]);
c.controlPanel.add(c.infoPanel);
c.controlPanel.add(forest_chart_2010);
c.controlPanel.add(forest_chart)
c.controlPanel.add(c.info.author)
c.controlPanel.add(c.info.email)