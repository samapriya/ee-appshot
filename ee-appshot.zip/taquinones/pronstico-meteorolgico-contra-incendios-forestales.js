var fecha_actual =  ee.Date(Date.now()).advance(-1,'day');
var Dia = ee.Number.parse(fecha_actual.format('DD'))
var Mes = ee.Number.parse(fecha_actual.format('MM'))
var Año = ee.Number.parse(fecha_actual.format('YYYY'))
// Funcion generadora de una etiqueta de la hora en chile 
// para cuando se genere un plot
var chile_hour = function(image) {
  var gmt_menos3 = ee.Number(image.get('forecast_time')).subtract(10800000);
  return image.set('Hora_Pronosticada',gmt_menos3)};
var GlobalForecastSystem = ee.ImageCollection("NOAA/GFS0P25")
                              .filter(ee.Filter.eq('creation_time',
                               ee.Date(0).update(Año,Mes,Dia,18,0,0).millis()))
                                  .map(chile_hour);
// Funcion para calcular Humedad del Combustible Fino Muerto
var addHCFM = function(image) {
  var HCFM = ee.Image(0).expression(
    '-2.97374 + (0.262*HR) - (0.00982*T)', {
      'T': image.select("temperature_2m_above_ground"),
      'HR': image.select("relative_humidity_2m_above_ground")});
  return image.addBands(HCFM.rename('HCFM'));};
//Funcion para convertir viento U y V en Viento (m/s)
var addViento = function(image) {
  var Viento = ee.Image(0).expression(
    '(sqrt((U*U) + (V*V))) * (3.6) ', {
      'U': image.select("u_component_of_wind_10m_above_ground"),
      'V': image.select("v_component_of_wind_10m_above_ground")});
  return image.addBands(Viento.rename('Viento'));};
// Agregar barras horizontales de umbrales para los charts
var umbral_hcfm = function(image) { 
                     return image.addBands(ee.Image(5).rename('Umbral 5% HCFM')) };
var umbral_viento = function(image) { 
                     return image.addBands(ee.Image(30).rename('Umbral 30 m/s')) };
var umbral_temperatura = function(image) { 
                     return image.addBands(ee.Image(30).rename('Umbral 30 °C')) };
// Abrir base de datos GFS
var GlobalForecastSystem = ee.ImageCollection("NOAA/GFS0P25")
                              .filter(ee.Filter.eq('creation_time',
                               ee.Date(0).update(Año,Mes,Dia,18,0,0).millis()))
                                  .map(chile_hour);
// Aplicar funcion, generar nuevos dataset HCFM y Viento
var HCFM = GlobalForecastSystem.map(addHCFM).select('HCFM');
var Viento = GlobalForecastSystem.map(addViento).select('Viento');
var Temperatura = GlobalForecastSystem
                       .map(function(img){
                        var temp = img.select('temperature_2m_above_ground')
                                      .rename('Temperatura')
                       return img.addBands(temp) })
                       .select('Temperatura')
var Precipitacion = GlobalForecastSystem
                       .map(function(img){
                        var temp = img.select('total_precipitation_surface')
                                      .rename('Precipitación')
                       return img.addBands(temp) })
                       .select('Precipitación')
//////////////////////////////////////
// Parámetros estéticos
var colors = {'cyan': '#24C1E0', 'transparent': '#11ffee00', 'gray': '#F8F9FA'};
var TITLE_STYLE = {
  fontWeight: 'bold',
  fontSize: '25px',
  padding: '5px',
    whiteSpace: 'pre',
  color: '#616161',
  backgroundColor: colors.transparent};
var PARAGRAPH_STYLE = {
  fontSize: '16px',
  fontWeight: '50',
  color: '#9E9E9E',
  padding: '8px',
    whiteSpace: 'pre',
  backgroundColor: colors.transparent};
var LABEL_STYLE = {
  fontWeight: '50',
  textAlign: 'center',
  fontSize: '11px',
  backgroundColor: colors.transparent};
var BORDER_STYLE = '4px solid rgba(97, 97, 97, 0.05)';
ui.root.setLayout(ui.Panel.Layout.absolute());
 var mainPanel = ui.Panel({
    layout: ui.Panel.Layout.flow('vertical', true),
    style: {
      stretch: 'horizontal',
      height: '100%',
      width: '700px',
      backgroundColor: '#F8F9FA',
      border: '4px solid rgba(97, 97, 97, 0.05)'}});
  // Add the app title to the side panel
  var titleLabel = ui.Label('Pronóstico Meteorológico contra Incendios Forestales', 
                               TITLE_STYLE);
  mainPanel.add(titleLabel);
   var titleLabel2 = ui.Label('Temperatura Superficial, Humedad del Combustible y Velocidad del Viento', 
                               {
  fontWeight: '20',
  whiteSpace: 'pre',
  height : '20px',
  fontSize: '18px',
  padding: '15px',
  color: '#616161',
  margin : 0,
  backgroundColor: colors.transparent});
  mainPanel.add(titleLabel2);
  // Add the app description to the main panel
  var descriptionText =
      'Aplicación generada para la estimación de pronósticos meteorológicos aplicados a\nla prevención y control de incendios forestales.\nHaz click en cualquier pixel para extraer información ambiental pronósticada \nde temperatura superficial, humedad del combustible y velocidad de viento.';
  var descriptionLabel = ui.Label(descriptionText, PARAGRAPH_STYLE);
  mainPanel.add(descriptionLabel);
      // Crear paneles para cada variable
var panel_temperatura = ui.Panel();
panel_temperatura.style().set({ width: '700px', position: 'bottom-center',backgroundColor: 'rgba(255, 255, 255, 0.5)'});
mainPanel.add(panel_temperatura);      
var panel_hcfm = ui.Panel();
panel_hcfm.style().set({ width: '700px', position: 'bottom-center',backgroundColor: 'rgba(255, 255, 255, 0.5)'});
mainPanel.add(panel_hcfm);
var panel_viento = ui.Panel();
panel_viento.style().set({ width: '700px', position: 'bottom-center',backgroundColor: 'rgba(255, 255, 255, 0.5)'});
mainPanel.add(panel_viento);
var panel_precipitacion = ui.Panel();
panel_precipitacion.style().set({ width: '700px', position: 'bottom-center',backgroundColor: 'rgba(255, 255, 255, 0.5)'});
mainPanel.add(panel_precipitacion);
var titleLabel3 = ui.Label('Corporación Nacional Forestal de Chile\nGerencia de Protección Contra Incendios Forestales\nDepartamento de Desarrollo e Investigación', 
                               {
  fontWeight: '20',
  whiteSpace: 'pre',
  height : '150px',
  fontSize: '20px',
  padding: '25px',
  color: '#616161',
  margin : 0,
  backgroundColor: colors.transparent});
  mainPanel.add(titleLabel3);
  var titleLabel4 = ui.Label('Fuente: Global Forecast System, National Centers for Environmental Prediction', 
                               {
  fontWeight: '20',
  whiteSpace: 'pre',
  height : '10px',
  fontSize: '13px',
  padding: '20px',
  color: '#616161',
  margin : 0,
  backgroundColor: colors.transparent});
  mainPanel.add(titleLabel4);
  ui.root.add(mainPanel)
Map.onClick(function(coords) {
  panel_viento.clear();
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chart =  ui.Chart.image.series({
          imageCollection: Viento.filter(ee.Filter.greaterThan('forecast_time',     ee.Date(0).update(Año,Mes,Dia,18,0,0).advance(8,'hour').millis()))
                                 .filter(ee.Filter.lessThanOrEquals('forecast_time',ee.Date(0).update(Año,Mes,Dia,18,0,0).advance(106,'hour').millis()))
                                 .map(umbral_viento),
          region: point,
          reducer: ee.Reducer.mean(),
          scale: 10000,
          xProperty: 'Hora_Pronosticada'})
        .setOptions({
          legend: {position: 'none'},
          series: {  0: {lineWidth: 1, color: '#E01212', lineDashStyle: [5, 5]},
                     1: {lineWidth: 3, color: '#5D6D7E'}},
          title: 'Velocidad del Viento',
          hAxis: {title: 'Horas Pronosticadas',
                  titleTextStyle: {italic: false, bold: true},
                  format: 'dd-MM-YYYY hh:mm',
                  scaleType: 'datetime',
                  gridlines: {count: 20}},
          vAxis: {title: 'Velocidad [km/h]',
                  titleTextStyle: {italic: false, bold: false},
                  gridlines : {count:2},
                  format: 'short',
             viewWindow: {min: 0, max: 40}},
            chartArea: {backgroundColor: '#F8F9FA'}});
   panel_viento.add(chart)
});
Map.onClick(function(coords) {
  panel_hcfm.clear();
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chart =  ui.Chart.image.series({
          imageCollection: HCFM.filter(ee.Filter.greaterThan('forecast_time',     ee.Date(0).update(Año,Mes,Dia,18,0,0).advance(8,'hour').millis()))
                                 .filter(ee.Filter.lessThanOrEquals('forecast_time',ee.Date(0).update(Año,Mes,Dia,18,0,0).advance(106,'hour').millis()))
                                 .map(umbral_hcfm),
          region: point,
          reducer: ee.Reducer.mean(),
          scale: 10000,
          xProperty: 'Hora_Pronosticada'})
        .setOptions({
          legend: {position: 'none'},
          series: {  0: {lineWidth: 3, color: '#1BA2E6'},
                     1: {lineWidth: 1, color: '#E01212', lineDashStyle: [5, 5]}},
          title: 'Humedad del Combustible Fino y Muerto',
          hAxis: {title: 'Horas Pronosticadas',
                  titleTextStyle: {italic: false, bold: true},
                  format: 'dd-MM-YYYY hh:mm',
                  scaleType: 'datetime',
                  gridlines: {count: 20}},
          vAxis: {title: 'Porcentaje Humedad [%]',
                  titleTextStyle: {italic: false, bold: false},
                  gridlines : {count:2},
                  format: 'short',
             viewWindow: {min: 0, max: 25}},
            chartArea: {backgroundColor: '#F8F9FA'}});
   panel_hcfm.add(chart)
});
Map.onClick(function(coords) {
  panel_temperatura.clear();
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chart =  ui.Chart.image.series({
          imageCollection: Temperatura.filter(ee.Filter.greaterThan('forecast_time',     ee.Date(0).update(Año,Mes,Dia,18,0,0).advance(8,'hour').millis()))
                                 .filter(ee.Filter.lessThanOrEquals('forecast_time',ee.Date(0).update(Año,Mes,Dia,18,0,0).advance(106,'hour').millis()))
                                 .map(umbral_temperatura),
          region: point,
          reducer: ee.Reducer.mean(),
          scale: 10000,
          xProperty: 'Hora_Pronosticada'})
        .setOptions({
          legend: {position: 'none'},
          series: {  0: {lineWidth: 3, color: '#E67A1B'},
                     1: {lineWidth: 1, color: '#E01212', lineDashStyle: [5, 5]}},
          title: 'Temperatura Superficial',
          hAxis: {title: 'Horas Pronosticadas',
                  titleTextStyle: {italic: false, bold: true},
                  format: 'dd-MM-YYYY hh:mm',
                  scaleType: 'datetime',
                  gridlines: {count: 20}},
          vAxis: {title: 'Temperatura [°C]',
                  titleTextStyle: {italic: false, bold: false},
                  gridlines : {count:2},
                  format: 'short',
             viewWindow: {min: 10, max: 40}},
            chartArea: {backgroundColor: '#F8F9FA'}});
   panel_temperatura.add(chart)
});
Map.onClick(function(coords) {
  panel_precipitacion.clear();
  var point = ee.Geometry.Point(coords.lon, coords.lat);
  var chart =  ui.Chart.image.series({
          imageCollection: Precipitacion.filter(ee.Filter.greaterThan('forecast_time',     ee.Date(0).update(Año,Mes,Dia,18,0,0).advance(8,'hour').millis()))
                                 .filter(ee.Filter.lessThanOrEquals('forecast_time',ee.Date(0).update(Año,Mes,Dia,18,0,0).advance(106,'hour').millis())),
          region: point,
          reducer: ee.Reducer.mean(),
          scale: 10000,
          xProperty: 'Hora_Pronosticada'})
         .setChartType('ColumnChart')
        .setOptions({
          legend: {position: 'none'},
          series: {  0: {lineWidth: 3, color: '#1B87E6'},
                     1: {lineWidth: 1, color: '#1B87E6', lineDashStyle: [5, 5]}},
          title: 'Precipitación Instantánea',
          hAxis: {title: 'Horas Pronosticadas',
                  titleTextStyle: {italic: false, bold: true},
                  format: 'dd-MM-YYYY hh:mm',
                  scaleType: 'datetime',
                  gridlines: {count: 20}},
          vAxis: {title: 'Precipitación/Hora [mm]',
                  titleTextStyle: {italic: false, bold: false},
                  gridlines : {count:2},
                  format: 'short',
             viewWindow: {min: 10, max: 20}},
            chartArea: {backgroundColor: '#F8F9FA'}});
   panel_precipitacion.add(chart)
}); 
  Map.style().set('cursor', 'crosshair');
    Map.add(ui.Label('Click en el mapa para generar pronósticos meteorológicos',
    {backgroundColor: 'rgba(255, 255, 255, 0.7)',
      position:'top-center'
    }));
    Map.add(ui.Label('Pronóstico realizado el ' + fecha_actual.format('DD MM YYYY').getInfo() + ' a las 15:00 Hrs.',
    {backgroundColor: 'rgba(255, 255, 255, 0.7)',
      position:'bottom-center'}));
var Chile = ee.FeatureCollection("USDOS/LSIB_SIMPLE/2017")
                  .filter(ee.Filter.eq('country_na', 'Chile'))
var firms = ee.ImageCollection('FIRMS').filter(
    ee.Filter.date(ee.Date(Date.now()).advance(-7,'days'), Date.now()))
    .sum()
    .neq(0)
var incendios = firms.select('T21');
var firesVis = {min: 0,max: 1,palette: 'red'};
Map.addLayer(incendios.clip(Chile), firesVis, 'Incendios');
Map.setOptions('SATELLITE')
// Leyenda de Incendios
// set position of panel
var leyenda = ui.Panel({
  style: {
    position: 'top-right',
    padding: '4px 10px'
  }
});
// Create legend title
var leyenda_titulo = ui.Label({
  value: 'My Legend',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
leyenda.add(leyenda_titulo);
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: 'red',
          padding: '8px',
          margin: '0 0 4px 0'        }    });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: 'Incendios activos de la semana',
        style: {margin: '0 0 4px 6px',backgroundColor : 'rgba(255, 255, 255, 0.1)'}
      });
      // return the panel
      var neopanel= ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal'),
        style : {position:'bottom-right',backgroundColor:'rgba(255, 255, 255, 0.7)'}
      });
// add legend to map (alternatively you can also print the legend to the console)
Map.add(neopanel);
Map.centerObject(ee.Geometry.Point([-75.33,-33.83]),7)