var dataset = ee.ImageCollection('MODIS/006/MOD14A1')
                  .filter(ee.Filter.date('2018-01-01', '2019-08-01')); //format date YYYY-MM-DD
var fireMaskVis = {
  min: 0.0,
  max: 9000.0,
  bands: ['MaxFRP', 'FireMask', 'FireMask'],
};
Map.setCenter(113.5497, -8.0349, 10);
Map.addLayer(dataset, fireMaskVis, 'Max FRP');