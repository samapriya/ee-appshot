var June = ui.import && ui.import("June", "image", {
      "id": "users/benjaminpage8/06_CONUS_Smoothed_clarity"
    }) || ee.Image("users/benjaminpage8/06_CONUS_Smoothed_clarity"),
    temp = ui.import && ui.import("temp", "image", {
      "id": "users/benjaminpage8/06_CONUS_temp"
    }) || ee.Image("users/benjaminpage8/06_CONUS_temp"),
    May = ui.import && ui.import("May", "image", {
      "id": "users/benjaminpage8/05_CONUS_Smoothed_Clarity"
    }) || ee.Image("users/benjaminpage8/05_CONUS_Smoothed_Clarity"),
    July = ui.import && ui.import("July", "image", {
      "id": "users/benjaminpage8/07_CONUS_Smoothed_Clarity"
    }) || ee.Image("users/benjaminpage8/07_CONUS_Smoothed_Clarity"),
    August = ui.import && ui.import("August", "image", {
      "id": "users/benjaminpage8/08_CONUS_IONLAKES_Clarity_10yr_Average_v1"
    }) || ee.Image("users/benjaminpage8/08_CONUS_IONLAKES_Clarity_10yr_Average_v1"),
    September = ui.import && ui.import("September", "image", {
      "id": "users/benjaminpage8/09_CONUS_IONLAKES_Clarity_10yr_Average_v1"
    }) || ee.Image("users/benjaminpage8/09_CONUS_IONLAKES_Clarity_10yr_Average_v1");
// white/black backgrounds
Map.addLayer(ee.Image(1), {min:0, max: 1}, 'white background', false)
Map.addLayer(ee.Image(0), {min:0, max: 1}, 'black background', false)
// display US states
var fvLayer = ui.Map.FeatureViewLayer('TIGER/2018/States_FeatureView');
fvLayer.setName('US census states');
Map.setCenter(-99.844, 37.649, 5);
Map.add(fvLayer);
Map.addLayer(May, {min: 0, max: 200, palette: ['darkblue', 'blue', 'cyan', 'limegreen', 'yellow', 'orange', 'orangered', 'darkred']}, 'May 10yr Average', false)
Map.addLayer(June, {min: 0, max: 200, palette: ['darkblue', 'blue', 'cyan', 'limegreen', 'yellow', 'orange', 'orangered', 'darkred']}, 'June 10yr Average', true)
Map.addLayer(July, {min: 0, max: 200, palette: ['darkblue', 'blue', 'cyan', 'limegreen', 'yellow', 'orange', 'orangered', 'darkred']}, 'July 10yr Average', false)
Map.addLayer(August, {min: 0, max: 200, palette: ['darkblue', 'blue', 'cyan', 'limegreen', 'yellow', 'orange', 'orangered', 'darkred']}, 'August 10yr Average', false)
Map.addLayer(September, {min: 0, max: 200, palette: ['darkblue', 'blue', 'cyan', 'limegreen', 'yellow', 'orange', 'orangered', 'darkred']}, 'September 10yr Average', false)
Map.addLayer(temp, {min: 55, max: 85, palette: ['darkblue', 'blue', 'white', 'red', 'darkred']}, 'temp', false)
// ***Panel*** \\
var viz = {min:0, max: 0.1, palette: ['darkblue', 'blue', 'cyan', 'limegreen', 'yellow', 'orange', 'orangered', 'red', 'darkred']};
// set position of panel
var legend = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    position: 'bottom-left',
    padding: '30x 30px',
    color: '000000'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Clarity',
  style: {
    fontWeight: 'bold',
    fontSize: '18px',
    margin: '0 0 0 0',
    padding: '0'
    }
});
// Add the title to the panel
legend.add(legendTitle); 
// create the legend image
var lon = ee.Image.pixelLonLat().select('latitude');
var gradient = lon.multiply((viz.max-viz.min)/100.0).add(viz.min);
var legendImage = gradient.visualize(viz);
// create text on top of legend
var panel = ui.Panel({
    widgets: [
      ui.Label('Low')
    ],
  });
legend.add(panel);
// create thumbnail from the image
var thumbnail = ui.Thumbnail({
  image: legendImage,
    params: {bbox:'0,0,10,100', dimensions:'20x200'},  
    style: {padding: '1px', position: 'bottom-center'},
  });
// add the thumbnail to the legend
legend.add(thumbnail);
// create text on top of legend
var panel = ui.Panel({
    widgets: [
      ui.Label('High')
    ],
  });
legend.add(panel);
Map.add(legend);
function current_position(point) {
  Map.addLayer(point, {}, 'You Are Here');
  Map.centerObject(point, 12);
  print(point);
}
function Error(error) {
  print(error);
}
ui.util.getCurrentPosition(current_position,Error);