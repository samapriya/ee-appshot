var District = ui.import && ui.import("District", "table", {
      "id": "users/nabinyadav34/Madesh_province"
    }) || ee.FeatureCollection("users/nabinyadav34/Madesh_province"),
    Pallika = ui.import && ui.import("Pallika", "table", {
      "id": "users/nabinyadav34/Pallika"
    }) || ee.FeatureCollection("users/nabinyadav34/Pallika"),
    State = ui.import && ui.import("State", "table", {
      "id": "projects/elephant-nepal/assets/State_madesh"
    }) || ee.FeatureCollection("projects/elephant-nepal/assets/State_madesh");
//  * Author:Nabin Kumar Yadav 
//  * Email:nabin.yadav34@gmail.com
Map.centerObject(District, 9.5)
     var display1= ee.Image(0).updateMask(0).paint(District, '000000',1);
     Map.addLayer(display1,{palette: '#000000'},'Boundary');
Map.setOptions('hybrid');
var mapStyle = [
  {"featureType": "administrative", "elementType": "labels.text.fill", "stylers": [{"color": "#000000"}]},
  {"featureType": "landscape", "elementType": "all", "stylers": [{"color": "#f2f2f2"}]},
  {"featureType": "poi", "elementType": "all", "stylers": [{"visibility": "on"}]},
  {"featureType": "road", "elementType": "all", "stylers": [{"saturation": 1}, {"lightness": 40}]},
  {"featureType": "road.highway", "elementType": "all", "stylers": [{"visibility": "simplified"}]},
  {"featureType": "road.arterial", "elementType": "labels.icon", "stylers": [{"visibility": "off"}]},
  {"featureType": "transit", "elementType": "all", "stylers": [{"visibility": "off"}]},
  {"featureType": "water", "elementType": "all", "stylers": [{"color": "#46bcec"}, {"visibility": "on"}]}
];
Map.setOptions('mapStyle', {mapStyle: mapStyle});
//////////////////////////////////////////////////////////////////// Adding Panel and items for selecting option
Map.style().set('cursor', 'hand');
var panel = ui.Panel({
  style: {
    width: '350px',
    border : '1px solid #000000',
    shown: true
  }
});
///////////-------------------------------------------
var Header = ui.Label('बाढी प्रभावित क्षेत्र नक्शांकन ',{fontWeight: 'bold',color:'black', fontSize: '20px', textAlign: 'left'});
var Subheader0 = ui.Label('Developed by : Ministry of Forest and Environment, Madhesh Pradesh' ,{fontWeight: 'bold', fontSize: '10px', textAlign: 'left'});
var Subheader1 = ui.Label('After Flood (बाढी आएको अवधि) :',{fontWeight: 'bold',color:'blue'});
var label_Start_second_select = ui.Label('Start:(YYYY-MM-DD)');
var Start_second_select = ui.Textbox({
  value: '2024-06-20',
  style: {width : '150px'},
  onChange: function(text) {
    var Start_second = text
  }
});
var label_End_second_select = ui.Label('End:(YYYY-MM-DD)');
var End_second_select = ui.Textbox({
  value: '2024-06-30',
  style: {width : '150px', textAlign: 'right'},
  onChange: function(text) {
    var End_second = text
  }
});
var Subheader2 = ui.Label('Before Flood (बाढी नभएको अवधि) :',{fontWeight: 'bold',color:'blue'});
var label_Start_base_select = ui.Label('Start:(YYYY-MM-DD)');
var Start_base_select = ui.Textbox({
  value: '2024-01-01',
  style: {width : '150px'},
  onChange: function(text) {
    var Start_base = text
  }
});
var label_End_base_select = ui.Label('End:(YYYY-MM-DD)');
var End_base_select = ui.Textbox({
  value: '2024-02-28',
  style: {width : '150px'},
  onChange: function(text) {
    var End_base = text
  }
});
var label_Sensor_select = ui.Label('Sensor selection:',{fontWeight: 'bold'});
var Sensor_select = ui.Select({
  items: [{label: 'Sentinel-1 SAR ', value: 'S1'},{label: 'Sentinel-1 SAR & Sentinel-2 MSI Integration (Not active)', value: 'S2'}],
  value: 'S1',
  onChange: function(value) {
    var Sensor = value
  },
  style: {width: '200px'}
});
///////////////////////////////// Selecting District and Pallika /////////
var district = ['Bara', 'Dhanusha','Mahottari','Parsa','Rautahat','Saptari','Sarlahi','Siraha'];
var pallika = {'Bara':['Adarshkotwal','Baragadhi','Bishrampur','Devtal','Jitpur Simara','Kalaiya','Karaiyamai','Kolhabi','Mahagadhimai','Nijgadh','Pacharauta','Parwanipur','Pheta','Prasauni','Simraungadh','Suwarna','Parsa'],
              'Dhanusha':['Aaurahi','Bateshwor','Bideha','Chhireshwornath','Dhanauji','Dhanusadham','Ganeshman Charnath','Hansapur','Janaknandani','Janakpur','Kamala','Lakshminiya','Mithila','Mithila Bihari','Mukhiyapatti Musarmiya','Nagarain','Sabaila','Sahidnagar'],
              'Mahottari':['Aurahi','Balwa','Bardibas','Bhangaha','Ekdanra','Gaushala','Jaleswor','Loharpatti','Mahottari','Manra Siswa','Matihani','Pipra','Ramgopalpur','Samsi','Sonama'],
              'Parsa':['Bahudaramai','Bindabasini','Birgunj','Chhipaharmai','Dhobini','Jagarnathpur','Jirabhawani','Kalikamai','Pakahamainpur','Parsagadhi','Paterwasugauli','Pokhariya','SakhuwaPrasauni','Thori','Parsa','Chitawan'],
              'Rautahat':['Baudhimai','Brindaban','Chandrapur','Dewahhi Gonahi','Durga Bhagwati','Gadhimai','Garuda','Gaur','Gujara','Ishanath','Katahariya','Madhav Narayan','Maulapur','Paroha','Phatuwa Bijayapur','Rajdevi','Rajpur','Yemunamai'],
              'Saptari':['Agnisair Krishna Savaran','Balan Bihul','Belhi Chapena','Bishnupur','Bode Barsain','Chhinnamasta','Dakneshwori','Hanumannagar Kankalini','Kanchanrup','Khadak','Mahadeva','Rajbiraj','Rupani','Saptakoshi','Shambhunath','Surunga','Tilathi Koiladi','Tirahut','Koshi Tappu'],
              'Sarlahi':['Bagmati','Balara','Barahathawa','Basbariya','Bishnu','Bramhapuri','Chakraghatta','Chandranagar','Dhankaul','Godaita','Haripur','Haripurwa','Hariwan','Ishworpur','Kabilasi','Kaudena','Lalbandi','Malangawa','Parsa','Ramnagar'],
              'Siraha':['Arnama','Aurahi','Bariyarpatti','Bhagawanpur','Bishnupur','Dhangadhimai','Golbazar','Kalyanpur','Karjanha','Lahan','Laxmipur Patari','Mirchaiya','Naraha','Nawarajpur','Sakhuwanankarkatti','Siraha','Sukhipur']};
var label_district_select = ui.Label('Select District(जिल्ला छान्नुस)',{fontWeight: 'bold',color:'blue'});
var district_select = ui.Select({
  items: district,
  placeholder: 'Select a District',
  onChange: updatePallikas
});
//// Select pallika
var label_pallika_select = ui.Label('Select Pallika(पालिका छान्नुस)',{fontWeight: 'bold',color:'blue'});
// Create a pallika  selector.
var pallika_select = ui.Select({
  items: [],
  placeholder: 'Select a Pallika'
});
// Function to update pallikas based on the selected district.
function updatePallikas(selectedDistrict) {
  if (selectedDistrict) {
    var pallikaList = pallika[selectedDistrict];
    pallika_select.items().reset(pallikaList);
    pallika_select.setPlaceholder('Select a pallika');
  } else {
    pallika_select.items().reset([]);
    pallika_select.setPlaceholder('Select a pallika');
  }
}
//////////// Center Select and Zoom level
var center_select = ui.Checkbox({
  label: 'Center on selected area',  
  value: true,
  onChange: function(value) {
    var center = value
  }
});
var label_zoomlevel_select = ui.Label('Zoomlevel under center option (1 - 24):');
var zoomlevel_select = ui.Slider({
  min: 1,
  max: 24, 
  value: 12.5, 
  step: 1,
  onChange: function(value) {
    var zoomlevel = value
  },
  style: {width: '250px'}
});
//panel.add(toolPanel);
panel.add(Header);
panel.add(Subheader0);
panel.add(label_district_select);
panel.add(district_select);
panel.add(label_pallika_select);
panel.add(pallika_select);
panel.add(Subheader1);
panel.add(label_Start_second_select);
panel.add(Start_second_select);
panel.add(label_End_second_select);
panel.add(End_second_select);
panel.add(Subheader2);
panel.add(label_Start_base_select);
panel.add(Start_base_select);
panel.add(label_End_base_select);
panel.add(End_base_select);
////This Section run when Run byttom is presses
ui.root.insert(0, panel);
var button = ui.Button('Click to Run (प्रक्रिया सुरु गर्न यँहा क्लीक गर्नुस)');
button.style().set({
    fontSize: '5px',
    backgroundColor: 'blue',
    padding: '5px',
    margin: '5px',
    position: 'top-center',
    border : '2px solid #000000',
    width: '250px',
    color:'Green'
});
panel.add(button);
// Functions of the script **********************
// **********************************************
button.onClick(function() {
    Map.clear();
    Map.setOptions('hybrid');
    Map.setOptions('mapStyle', { mapStyle: mapStyle });
    // Add the button to the map and the panel to root.
    var Start_base = Start_base_select.getValue();
    var Start_base_number = ee.Number.parse(Start_base.replace(/-/g,'')).getInfo();
    var End_base = End_base_select.getValue();
    var End_base_number = ee.Number.parse(End_base.replace(/-/g,'')).getInfo();
    var Start_second = Start_second_select.getValue();
    var Start_second_number = ee.Number.parse(Start_second.replace(/-/g,'')).getInfo();
    var End_second = End_second_select.getValue();
    var End_second_number = ee.Number.parse(End_second.replace(/-/g,'')).getInfo();
    var Sensor = Sensor_select.getValue();
    var district = district_select.getValue();
    var pallika = pallika_select.getValue();
    var center = center_select.getValue();
    var zoomlevel = zoomlevel_select.getValue();
    // *********************************************************************************************************************************************************
     // Define District 
     var geometry =District.filterMetadata('DISTRICT','equals',district); // Please Write District Name here. Don't Change any code 
     var geometry =Pallika.filterMetadata('LOCAL','equals',pallika); // Please Write District Name here. Don't Change any code
     //var geometry = AOI_select
     var display1= ee.Image(0).updateMask(0).paint(geometry, '000000',2);
     Map.addLayer(display1,{palette: '#000000'},'Boundary');
     var aoi = geometry
    // Adjustments according to above user selections
    if (center === true){
      Map.centerObject(aoi, zoomlevel);
    }
    if (Sensor === 'S1'){   
      var polarization = "VH"; 
      var pass_direction = "DESCENDING";
      var difference_threshold = 1.25;
     // Load and filter Sentinel-1 GRD data by predefined parameters 
     var collection= ee.ImageCollection('COPERNICUS/S1_GRD')
      .filter(ee.Filter.eq('instrumentMode','IW'))
      .filter(ee.Filter.listContains('transmitterReceiverPolarisation', polarization))
      .filter(ee.Filter.eq('orbitProperties_pass',pass_direction)) 
      .filter(ee.Filter.eq('resolution_meters',10))
      .filterBounds(aoi)
      .select(polarization);
     // Select images by predefined dates
     var before_collection = collection.filterDate(Start_base, End_base);
     var after_collection = collection.filterDate(Start_second, End_second);
      // Extract date from meta data
      function dates(imgcol){
        var range = imgcol.reduceColumns(ee.Reducer.minMax(), ["system:time_start"]);
        var printed = ee.String('from ')
          .cat(ee.Date(range.get('min')).format('YYYY-MM-dd'))
          .cat(' to ')
          .cat(ee.Date(range.get('max')).format('YYYY-MM-dd'));
        return printed;
      }
       // Create a mosaic of selected tiles and clip to study area
       var before = before_collection.mosaic().clip(aoi);
       var after = after_collection.mosaic().clip(aoi);
       // Apply reduce the radar speckle by smoothing  
       var smoothing_radius = 50;
       var before_filtered = before.focal_mean(smoothing_radius, 'circle', 'meters');
       var after_filtered = after.focal_mean(smoothing_radius, 'circle', 'meters');
      //------------------------------- FLOOD EXTENT CALCULATION -------------------------------//
       // Calculate the difference between the before and after images
       var difference = after_filtered.divide(before_filtered);
       var threshold = difference_threshold;
       var difference_binary = difference.gt(threshold);
       // Refine flood result using additional datasets
      // Include JRC layer on surface water seasonality to mask flood pixels from areasm of "permanent" water (where there is water > 10 months of the year)
      var swater = ee.Image('JRC/GSW1_4/GlobalSurfaceWater').select('seasonality');
      var swater_mask = swater.gte(10).updateMask(swater.gte(10));
      //Flooded layer where perennial water bodies (water > 10 mo/yr) is assigned a 0 value
      var flooded_mask = difference_binary.where(swater_mask,0);
      // final flooded area without pixels in perennial waterbodies
      var flooded = flooded_mask.updateMask(flooded_mask);
      // Compute connectivity of pixels to eliminate those connected to 8 or fewer neighbours
      // This operation reduces noise of the flood extent product 
      var connections = flooded.connectedPixelCount();    
      var flooded = flooded.updateMask(connections.gte(8));
      // Mask out areas with more than 5 percent slope using a Digital Elevation Model 
      var DEM = ee.Image('WWF/HydroSHEDS/03VFDEM');
      var terrain = ee.Algorithms.Terrain(DEM);
      var slope = terrain.select('slope');
      var flooded = flooded.updateMask(slope.lt(5));
      // Calculate flood extent area
      // Create a raster layer containing the area information of each pixel 
      var flood_pixelarea = flooded.select(polarization)
                                   .multiply(ee.Image.pixelArea());
      // Sum the areas of flooded pixels 
     var flood_stats = flood_pixelarea.reduceRegion({
         reducer: ee.Reducer.sum(),              
         geometry: aoi,
         scale: 10,
         maxPixels: 1e9,
         bestEffort: true
         });
    // Convert the flood extent to hectares (area calculations are originally given in meters)  
     var flood_area_ha = flood_stats
         .getNumber(polarization)
         .divide(10000)
         .round(); 
     //------------------------------  DAMAGE ASSSESSMENT  ----------------------------------//
     //----------------------------- Exposed population density ----------------------------//
     // Load JRC Global Human Settlement Popluation Density layer
     // Resolution: 250. Number of people per cell is given.
     var population_count = ee.Image('JRC/GHSL/P2016/POP_GPW_GLOBE_V1/2015').clip(aoi);
     var GHSLprojection = population_count.projection();
     var flooded_res1 = flooded
       .reproject({
       crs: GHSLprojection
      });
     // Create a raster showing exposed population only using the resampled flood layer
      var population_exposed = population_count
     .updateMask(flooded_res1)
     .updateMask(population_count);
     //Sum pixel values of exposed population raster 
     var stats = population_exposed.reduceRegion({
        reducer: ee.Reducer.sum(),
        geometry: aoi,
        scale: 250,
        maxPixels:1e9 
        });
     // get number of exposed people as integer
     var number_pp_exposed = stats.getNumber('population_count').round();
     //----------------------------- Affected agricultural land ----------------------------//
     var LC = ee.ImageCollection("projects/sat-io/open-datasets/landcover/ESRI_Global-LULC_10m_TS").filterDate('2023-01-01','2023-12-31').mosaic()
        .select("b1")
        .clip(aoi);
     // Extract only cropland pixels 
     var cropmask = LC.eq(05)
     var cropland = LC.updateMask(cropmask)
     // get ESRI projection
     var esriprojection = LC.projection();
     var flooded_res = flooded
         .reproject({
          crs: esriprojection
        });
     // Calculate affected cropland using the resampled flood layer
     var cropland_affected = flooded.updateMask(cropland)
     // get pixel area of affected cropland layer
     var crop_pixelarea = cropland_affected.multiply(ee.Image.pixelArea()); //calcuate the area of each pixel 
     // sum pixels of affected cropland layer
     var crop_stats = crop_pixelarea.reduceRegion({
         reducer: ee.Reducer.sum(), //sum all pixels with area information                
         geometry: aoi,
           scale: 10,
       maxPixels: 1e9
       });
      // convert area to hectares
     var crop_area_ha = crop_stats
         .getNumber(polarization)
         .divide(10000)
         .round();
      //-------------------------------- Affected urban area ------------------------------//
      // Filter urban areas
      var urbanmask = LC.eq(07)
      var urban = LC.updateMask(urbanmask)
     //Calculate affected urban areas using the resampled flood layer
     var urban_affected = flooded.updateMask(urban);
      // get pixel area of affected urban layer
     var urban_pixelarea = urban_affected.multiply(ee.Image.pixelArea()); //calcuate the area of each pixel 
      // sum pixels of affected cropland layer
      var urban_stats = urban_pixelarea.reduceRegion({
          reducer: ee.Reducer.sum(), //sum all pixels with area information                
          geometry: aoi,
          scale: 10,
          maxPixels: 1e9
          });
      // convert area to hectares
      var urban_area_ha = urban_stats
         .getNumber(polarization)
         .divide(10000)
         .round();
     //------------------------------  DISPLAY PRODUCTS  ----------------------------------//
     Map.addLayer(flooded,{palette:"0000FF"},'Flooded areas');
     // Population Density
     var populationCountVis = {
        min: 0,
        max: 200.0,
        palette: ['060606','337663','337663','ffffff'],
          };
    // Exposed Population
     var populationExposedVis = {
      min: 0,
      max: 200.0,
      palette: ['yellow', 'orange', 'red'],
      };
     // ESRI
     var LCVis = {
       min: 1,
       max: 10,
        palette: [
    "#1A5BAB",
    "#358221",
    "#A7D282",
    "#87D19E",
    "#FFDB5C",
    "#EECFA8",
    "#ED022A",
    "#EDE9E4",
    "#F2FAFF",
    "#C8C8C8"
  ],
          };
     // Cropland
     var croplandVis = {
         min: 0,
         max: 5.0,
         palette: ['f0ff4e'],
         };
      // Affected cropland
      Map.addLayer(cropland_affected, croplandVis, 'Affected Cropland'); 
      // Urban
      var urbanVis = {
       min: 0,
       max: 7,
       palette: ['red'],
       };
       // Affected urban
       Map.addLayer(urban_affected, urbanVis, 'Affected Urban'); 
    //---------------------------------- MAP PRODUCTION --------------------------------//
    //-------------------------- Display the results on the map -----------------------//
    // set position of panel where the results will be displayed 
     var results = ui.Panel({
         style: {
         position: 'bottom-right',
         padding: '15px 15px',
         width: '250px'
       }
      });
     //Prepare the visualtization parameters of the labels 
      var textVis = {
       'margin':'0px 8px 2px 0px',
       'fontWeight':'bold'
       };
      var numberVIS = {
       'margin':'0px 0px 15px 0px', 
       'color':'bf0f19',
       'fontWeight':'bold'
       };
      var subTextVis = {
       'margin':'0px 0px 2px 0px',
       'fontSize':'12px',
       'color':'grey'
       };
      var titleTextVis = {
       'margin':'0px 0px 15px 0px',
       'fontSize': '18px', 
       'font-weight':'', 
       'color': '3333ff'
       };
     // Create lables of the results 
     // Titel and time period
     var title = ui.Label('Flood Status of:', titleTextVis);
     var title_2 = ui.Label(pallika,titleTextVis);
     var text1 = ui.Label('Flood status between:',textVis);
     var number1 = ui.Label(Start_second.concat(" and ",End_second),numberVIS);
     // Estimated flood extent 
     var text2 = ui.Label('Estimated flood extent:',textVis);
     var text2_2 = ui.Label('Please wait...',subTextVis);
     dates(after_collection).evaluate(function(val){text2_2.setValue('based on Senintel-1 imagery '+val)});
     var number2 = ui.Label('Please wait...',numberVIS); 
     flood_area_ha.evaluate(function(val){number2.setValue(val+' hectares')}),numberVIS;
     // Estimated number of exposed people
     var text3 = ui.Label('Estimated number of exposed people: ',textVis);
     var text3_2 = ui.Label('based on GHSL 2015 (250m)',subTextVis);
     var number3 = ui.Label('Please wait...',numberVIS);
     number_pp_exposed.evaluate(function(val){number3.setValue(val)}),numberVIS;
     // Estimated area of affected cropland 
     var MODIS_date = ee.String(LC.get('system:index')).slice(0,4);
     var text4 = ui.Label('Estimated affected cropland:',textVis);
     var text4_2 = ui.Label('Please wait', subTextVis)
     MODIS_date.evaluate(function(val){text4_2.setValue('ESRI_LULC 2023 (10m)')}), subTextVis;
     var number4 = ui.Label('Please wait...',numberVIS);
     crop_area_ha.evaluate(function(val){number4.setValue(val+' hectares')}),numberVIS;
     // Estimated area of affected urban
     var text5 = ui.Label('Estimated affected urban areas:',textVis);
     var text5_2 = ui.Label('Please wait', subTextVis)
     MODIS_date.evaluate(function(val){text5_2.setValue('ESRI LULC 2023 (10m)')}), subTextVis;
     var number5 = ui.Label('Please wait...',numberVIS);
     urban_area_ha.evaluate(function(val){number5.setValue(val+' hectares')}),numberVIS;
      // Add the labels to the panel 
      results.add(ui.Panel([
             title,
             title_2,
             text1,
             number1,
             text2,
             text2_2,
             number2,
             text4,
             text4_2,
             number4,
            text5,
            text5_2,
             number5,
             text3,
             text3_2,
             number3
             ]
            ));
       // Add the panel to the map 
      Map.add(results);
     // set position of panel
     var legend = ui.Panel({
       style: {
       position: 'bottom-left',
      padding: '10px 10px',
       }
      });
     // Create legend title
     var legendTitle = ui.Label('Legend',titleTextVis);
     // Add the title to the panel
     legend.add(legendTitle);
     // Creates and styles 1 row of the legend.
     var makeRow = function(color, name) {
           // Create the label that is actually the colored box.
           var colorBox = ui.Label({
             style: {
              backgroundColor: color,
              // Use padding to give the box height and width.
              padding: '8px',
              margin: '0 0 4px 0'
             }
            });
           // Create the label filled with the description text.
          var description = ui.Label({
          value: name,
          style: {margin: '0 0 4px 6px'}
           });
        // return the panel
         return ui.Panel({
         widgets: [colorBox, description],
         layout: ui.Panel.Layout.Flow('horizontal')
         });
       };
     //  Palette with the colors
     var palette =['#0000FF', '#fff135', 'red'];
      // name of the legend
     var names = ['बाढी प्रभावित क्षेत्र (flooded areas)', 'प्रभावित कृषि क्षेत्र (affected cropland)','प्रभावित  वस्ती क्षेत्र (affected settlement'];
     // Add color and and names
     for (var i = 0; i < 3; i++) {
      legend.add(makeRow(palette[i], names[i]));
       }  
     Map.add(legend);
    }
});
// ******************************************************************* END *********************************************************************************