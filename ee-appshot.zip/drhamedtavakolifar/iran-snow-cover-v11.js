/**** =====================================================================
 *  IRAN SNOW COVER DASHBOARD
 *  - Computes recent 8-day max snow cover over Iran
 *  - Compares with same 8-day period in previous year
 *  - Provides zonal stats by main basins, sub-basins, and provinces
 *  Author: Hamed Tavakolifar (visual + QA + interaction improved)
 * ===================================================================== */
/* ======================================================================
 * BLOCK 1 – DATASETS, MAP, BASE UI, HEADER
 * ==================================================================== */
// 1. INPUT DATASETS & GEOMETRIES
var Iran      = ee.FeatureCollection("users/drhamedtavakolifar/Iran"),
    Province  = ee.FeatureCollection("projects/ee-drhamedtavakolifar/assets/Province"),
    lakemask  = ee.Image("projects/ee-drhamedtavakolifar/assets/new_mask"),
    M9Basin   = ee.FeatureCollection("projects/ee-drhamedtavakolifar/assets/Iran_Water_Layer/T9_Main_Basins"),
    M30Basin  = ee.FeatureCollection("projects/ee-drhamedtavakolifar/assets/Iran_Water_Layer/T30_Sub_Basin");
// Clear default UI and create main panel + map
ui.root.clear();
// Main control panel (left sidebar)
var mainpanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    width: '360px',
    position: 'top-left',
    padding: '8px',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    border: '1px solid #cccccc',
    borderRadius: '8px'
  }
});
// Map
var maP = ui.Map();
// Add to root
ui.root.add(mainpanel).add(maP);
// BACKGROUND DEM LAYER (ELEVATION)
var dsm_iran = ee.Image('CGIAR/SRTM90_V4').clip(Iran);
var elevPalette_dem = ['#84AB84', '#DFDBB5', '#AF8467', '#7F4F4B', '#5E3942', '#422B3E'];
var elevParams_dem = {min: 10, max: 4000, palette: elevPalette_dem};
// Base map init
function initialmap() {
  maP.centerObject(Iran, 5);
  maP.setOptions("TERRAIN");
  maP.addLayer(Iran, {}, 'Iran Base Map', true, 0.4);
  maP.addLayer(dsm_iran, elevParams_dem, 'Elevation Model', false, 0.6);
  maP.addLayer(M30Basin, {color: 'blue'}, '2nd Degree Basins', false, 0.8);
  maP.addLayer(Province, {color: 'red'}, 'Provinces', false, 0.8);
}
initialmap();
// Map title on the map
var maptitle = ui.Label({
  value: 'Iran Snow Cover Map',
  style: {
    position: 'top-center',
    fontSize: '24px',
    color: '#333333',
    fontWeight: 'bold',
    backgroundColor: 'rgba(255,255,255,0.8)',
    padding: '4px 10px',
    borderRadius: '6px'
  }
});
maP.add(maptitle);
// Header in the side panel
var headerPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    margin: '0 0 8px 0',
    padding: '8px',
    backgroundColor: '#1976D2',
    borderRadius: '6px'
  }
});
var headerTitle = ui.Label('Iran Snow Cover Dashboard', {
  fontSize: '18px',
  fontWeight: 'bold',
  color: 'black',
  margin: '0 0 4px 0'
});
var headerSubtitle = ui.Label(
  '8-day max MODIS snow cover • Current vs previous year',
  {
    fontSize: '11px',
    color: 'black',
    margin: '0'
  }
);
headerPanel.add(headerTitle);
headerPanel.add(headerSubtitle);
mainpanel.add(headerPanel);
/* ======================================================================
 * BLOCK 2 – MODIS COLLECTION, QA MASK, DATE WINDOWS, GLOBAL IMAGES
 * ==================================================================== */
var MOD10A1_collection = ee.ImageCollection('MODIS/061/MOD10A1');
// QA masking function for MODIS snow
function applySnowQAMask(img) {
  var basicQA = img.select('NDSI_Snow_Cover_Basic_QA');
  var goodQuality = basicQA.lte(2);  // Best / Good / OK
  return img.updateMask(goodQuality);
}
// Last available MODIS date
var lastDate = ee.Image(
  MOD10A1_collection.sort('system:time_end', false).first()
).date();
// Current-year 8-day window
var currentStartDate = lastDate.advance(-8, 'day');
var currentEndDate   = lastDate;
// Previous-year 8-day window
var prevLastDate  = lastDate.advance(-365, 'day');
var prevStartDate = prevLastDate.advance(-8, 'day');
// Current window: 8-day max snow (QA-filtered)
var snowCover_collection_current = MOD10A1_collection
  .filter(ee.Filter.date(currentStartDate, currentEndDate))
  .map(applySnowQAMask)
  .select('NDSI_Snow_Cover');
var snowCover8_current = snowCover_collection_current.max();
var snowCover_iran8_current = snowCover8_current.clip(Iran);
// Previous-year window: 8-day max snow (QA-filtered)
var snowCover_collection_prev = MOD10A1_collection
  .filter(ee.Filter.date(prevStartDate, prevLastDate))
  .map(applySnowQAMask)
  .select('NDSI_Snow_Cover');
var snowCover8_prev = snowCover_collection_prev.max();
var snowCover_iran8_prev = snowCover8_prev.clip(Iran);
// Formatted date strings
var currentStartStr = currentStartDate.format("YYYY-MM-dd");
var currentEndStr   = currentEndDate.format("YYYY-MM-dd");
var prevStartStr = prevStartDate.format("YYYY-MM-dd");
var prevEndStr   = prevLastDate.format("YYYY-MM-dd");
// Placeholders for threshold-filtered snow images
var IranSnowCoverImageCurrentYear  = ee.Image();
var IranSnowCoverImagePreviousYear = ee.Image();
/* ======================================================================
 * BLOCK 3 – DATA SOURCE PANEL
 * ==================================================================== */
var sourcePanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    margin: '4px 0 8px 0',
    padding: '6px 8px',
    backgroundColor: '#f5f5f5',
    borderRadius: '6px'
  }
});
var srcTitle = ui.Label('Data source', {
  fontSize: '12px',
  fontWeight: 'bold',
  color: '#444444',
  margin: '0 0 4px 0',
  textAlign: 'left'
});
var srcLine1 = ui.Label(
  '• MODIS MOD10A1 V6 – daily snow cover (500 m)',
  {fontSize: '11px', color: '#555555', margin: '0 0 2px 0'}
);
var srcLink = ui.Label(
  'Dataset documentation',
  {
    fontSize: '11px',
    color: '#1976D2',
    margin: '0 0 2px 0'
  },
  'https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MOD10A1'
);
sourcePanel.add(srcTitle);
sourcePanel.add(srcLine1);
sourcePanel.add(srcLink);
mainpanel.add(sourcePanel);
/* ======================================================================
 * BLOCK 4 – BUTTONS (CALC + RESULTS), BUTTON PANEL, FLAGS
 * ==================================================================== */
var calbot;
var B1resbot;
var B2resbot;
var Prresbot;
var buttonPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {margin: '0 0 8px 0'}
});
// Calculation button
calbot = ui.Button('Run snow cover calculation');
calbot.style().set({
  width: '100%',
  backgroundColor: '#e0e0e0',
  color: 'black',
  fontWeight: 'bold',
  border: '1px solid #cccccc',
  borderRadius: '4px',
  margin: '4px 0'
});
// Result buttons (created now, added later after first run)
B1resbot = ui.Button('Main basins (T9) results');
B1resbot.style().set({
  width: '100%',
  backgroundColor: '#e0e0e0',
  color: 'black',
  fontSize: '11px',
  border: '1px solid #cccccc',
  borderRadius: '4px',
  margin: '2px 0'
});
B1resbot.setDisabled(true);
B2resbot = ui.Button('2nd-degree basins (T30) results');
B2resbot.style().set({
  width: '100%',
  backgroundColor: '#e0e0e0',
  color: 'black',
  fontSize: '11px',
  border: '1px solid #cccccc',
  borderRadius: '4px',
  margin: '2px 0'
});
B2resbot.setDisabled(true);
Prresbot = ui.Button('Provinces results');
Prresbot.style().set({
  width: '100%',
  backgroundColor: '#e0e0e0',
  color: 'black',
  fontSize: '11px',
  border: '1px solid #cccccc',
  borderRadius: '4px',
  margin: '2px 0'
});
Prresbot.setDisabled(true);
// At start, only the calculation button is visible
buttonPanel.add(calbot);
mainpanel.add(buttonPanel);
// Flag so we only add result buttons once
var resultsButtonsAdded = false;
/* ======================================================================
 * BLOCK 5 – THRESHOLD CONTROLS (SLIDERS + RESET)
 * ==================================================================== */
// Helper: when thresholds change, allow recalc & disable results
function setInteractionState() {
  calbot.setDisabled(false);
  B1resbot.setDisabled(true);
  B2resbot.setDisabled(true);
  Prresbot.setDisabled(true);
}
// Controls panel
var controlPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    margin: '0 0 8px 0',
    padding: '8px',
    backgroundColor: '#fafafa',
    borderRadius: '6px',
    border: '1px solid #e0e0e0'
  }
});
var controlTitle = ui.Label('Snow detection thresholds', {
  fontSize: '13px',
  fontWeight: 'bold',
  color: '#333333',
  margin: '0 0 6px 0'
});
controlPanel.add(controlTitle);
// NDSI slider
var NDSI_title = ui.Label('NDSI cut-off (%)', {
  fontSize: '11px',
  color: '#555555',
  margin: '4px 0 2px 0'
});
controlPanel.add(NDSI_title);
var NDSI_slider = ui.Slider({
  min: 0,
  max: 100,
  value: 10,
  step: 5,
  style: {width: '100%'}
});
NDSI_slider.onChange(setInteractionState);
controlPanel.add(NDSI_slider);
// Elevation slider
var elv_title = ui.Label('Elevation cut-off (m)', {
  fontSize: '11px',
  color: '#555555',
  margin: '6px 0 2px 0'
});
controlPanel.add(elv_title);
var elv_slider = ui.Slider({
  min: 100,
  max: 2000,
  value: 100,
  step: 100,
  style: {width: '100%'}
});
elv_slider.onChange(setInteractionState);
controlPanel.add(elv_slider);
// Reset thresholds button
var button_default = ui.Button('Reset thresholds to default');
button_default.style().set({
  width: '100%',
  margin: '6px 0 0 0',
  backgroundColor: '#e0e0e0',
  color: 'black',
  border: '1px solid #cccccc',
  borderRadius: '4px',
  fontSize: '11px'
});
button_default.onClick(function() {
  elv_slider.setValue(100);
  NDSI_slider.setValue(10);
});
controlPanel.add(button_default);
mainpanel.add(controlPanel);
/* ======================================================================
 * BLOCK 6 – SUMMARY PANEL + DETAILED PANEL
 * ==================================================================== */
// Summary result panel
var resultpanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    width: '100%',
    margin: '0 0 8px 0',
    padding: '8px',
    backgroundColor: '#fdfdfd',
    borderRadius: '6px',
    border: '1px solid #e0e0e0'
  }
});
var summaryTitle = ui.Label('National summary', {
  fontSize: '13px',
  fontWeight: 'bold',
  color: '#333333',
  margin: '0 0 4px 0'
});
resultpanel.add(summaryTitle);
mainpanel.add(resultpanel);
// Detailed result panel (for charts)
var resultpanel2 = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    width: '320px',
    position: 'bottom-left',
    padding: '8px',
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: '8px',
    border: '1px solid #cccccc'
  }
});
var respantitle = ui.Label('Detailed zonal statistics', {
  fontSize: '13px',
  fontWeight: 'bold',
  color: '#333333',
  margin: '0 0 4px 0'
});
resultpanel2.add(respantitle);
maP.add(resultpanel2);
/* ======================================================================
 * BLOCK 7 – SNOW VIS PARAMETERS + LEGEND
 * ==================================================================== */
var snowCoverVis = {
  min: 0.0,
  max: 100,
  palette: ['black', '0dffff', '0524ff', 'ffffff']
};
var snowLegend = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    position: 'bottom-right',
    padding: '8px',
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: '6px',
    border: '1px solid #cccccc'
  }
});
function buildSnowLegend() {
  snowLegend.clear();
  var legendTitle = ui.Label('Snow cover (%)', {
    fontSize: '12px',
    fontWeight: 'bold',
    color: '#333333',
    margin: '0 0 4px 0'
  });
  snowLegend.add(legendTitle);
  function makeLegendRow(color, label) {
    var colorBox = ui.Label('', {
      backgroundColor: color,
      padding: '6px',
      margin: '0 4px 0 0',
      border: '1px solid #cccccc',
      borderRadius: '2px'
    });
    var text = ui.Label(label, {
      fontSize: '11px',
      color: '#555555',
      margin: '0'
    });
    return ui.Panel({
      widgets: [colorBox, text],
      layout: ui.Panel.Layout.flow('horizontal'),
      style: {margin: '2px 0'}
    });
  }
  snowLegend.add(makeLegendRow('black',   '0 – 10'));
  snowLegend.add(makeLegendRow('0dffff',  '10 – 40'));
  snowLegend.add(makeLegendRow('0524ff',  '40 – 80'));
  snowLegend.add(makeLegendRow('ffffff',  '80 – 100'));
  maP.add(snowLegend);
}
/* ======================================================================
 * BLOCK 8 – CUSTOM ALWAYS-VISIBLE SNOW LAYERS PANEL (HIDDEN AT START)
 * ==================================================================== */
var currentLayer;
var prevLayer;
// Create the panel but keep it hidden initially
var layerPanel = ui.Panel({
  layout: ui.Panel.Layout.flow('vertical'),
  style: {
    position: 'top-right',
    padding: '8px',
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderRadius: '6px',
    border: '1px solid #cccccc'
  }
});
// Panel contents
var layerTitle = ui.Label('Snow layers', {
  fontSize: '12px',
  fontWeight: 'bold',
  color: '#333333',
  margin: '0 0 4px 0'
});
var currentCheckbox = ui.Checkbox('Current year (8-day max)', true);
var prevCheckbox    = ui.Checkbox('Previous year (8-day max)', false);
layerPanel.add(layerTitle);
layerPanel.add(currentCheckbox);
layerPanel.add(prevCheckbox);
// IMPORTANT: Hidden at the start
layerPanel.style().set('shown', false);
// DO NOT add it to the map yet
/* ======================================================================
 * BLOCK 9 – MAIN CALCULATION LOGIC (calbot.onClick)
 * ==================================================================== */
calbot.onClick(function() {
  // Read thresholds
  var elv_th  = elv_slider.getValue();
  var NDSI_th = NDSI_slider.getValue();
  // Reset summary panel and map
  resultpanel.clear();
  resultpanel.add(summaryTitle);
  maP.clear();
  initialmap();
  maP.add(maptitle);
  maP.add(resultpanel2);
// Make Snow layers panel visible AFTER calculation
layerPanel.style().set('shown', true);
maP.add(layerPanel);
  // Reset detailed panel
  resultpanel2.clear();
  var respantitle = ui.Label('Detailed zonal statistics', {
    fontSize: '13px',
    fontWeight: 'bold',
    color: '#333333',
    margin: '0 0 4px 0'
  });
  resultpanel2.add(respantitle);
  // Add result buttons on first run
  if (!resultsButtonsAdded) {
    buttonPanel.add(B1resbot);
    buttonPanel.add(B2resbot);
    buttonPanel.add(Prresbot);
    resultsButtonsAdded = true;
  }
  // Enable results buttons, disable calc until thresholds change again
  B1resbot.setDisabled(false);
  B2resbot.setDisabled(false);
  Prresbot.setDisabled(false);
  calbot.setDisabled(true);
  // Apply elevation + NDSI + lake masks
  IranSnowCoverImageCurrentYear =
    iransnowcover_filter(NDSI_th, elv_th, snowCover_iran8_current);
  IranSnowCoverImagePreviousYear =
    iransnowcover_filter(NDSI_th, elv_th, snowCover_iran8_prev);
  // Total snow area (km²)
  var totalCurrent = sumtotal(IranSnowCoverImageCurrentYear);
  var totalPrev    = sumtotal(IranSnowCoverImagePreviousYear);
  // Add/update snow layers controlled by our custom checkboxes
  if (!currentLayer) {
    // First run – create layers
    currentLayer = ui.Map.Layer(
      IranSnowCoverImageCurrentYear,
      snowCoverVis,
      'Current Year 8-day MAX Snow Cover',
      true      // shown
    );
    prevLayer = ui.Map.Layer(
      IranSnowCoverImagePreviousYear,
      snowCoverVis,
      'Previous Year 8-day MAX Snow Cover',
      false     // hidden by default
    );
    maP.layers().add(currentLayer);
    maP.layers().add(prevLayer);
    // Link checkboxes to visibility
    currentCheckbox.onChange(function(checked) {
      currentLayer.setShown(checked);
    });
    prevCheckbox.onChange(function(checked) {
      prevLayer.setShown(checked);
    });
  } else {
    // Later runs – update layer images
    currentLayer.setEeObject(IranSnowCoverImageCurrentYear);
    prevLayer.setEeObject(IranSnowCoverImagePreviousYear);
  }
  // Reset checkbox states each run
  currentCheckbox.setValue(true);
  prevCheckbox.setValue(false);
  // Legend
  buildSnowLegend();
  // Summary labels
  var lineCurrent1 = ui.Label(
    'Current period: ' +
    currentStartStr.getInfo() + ' → ' + currentEndStr.getInfo(),
    {fontSize: '11px', color: '#555555', margin: '2px 0'}
  );
  var lineCurrent2 = ui.Label(
    'Snow-covered area: ' + totalCurrent.getInfo() + ' km²',
    {fontSize: '12px', color: '#1976D2', fontWeight: 'bold', margin: '2px 0 4px 0'}
  );
  var separator = ui.Label(' ', {margin: '2px 0 2px 0'});
  var linePrev1 = ui.Label(
    'Previous year period: ' +
    prevStartStr.getInfo() + ' → ' + prevEndStr.getInfo(),
    {fontSize: '11px', color: '#555555', margin: '4px 0 2px 0'}
  );
  var linePrev2 = ui.Label(
    'Snow-covered area: ' + totalPrev.getInfo() + ' km²',
    {fontSize: '12px', color: '#555555', fontWeight: 'bold', margin: '2px 0'}
  );
  resultpanel.add(lineCurrent1);
  resultpanel.add(lineCurrent2);
  resultpanel.add(separator);
  resultpanel.add(linePrev1);
  resultpanel.add(linePrev2);
});
/* ======================================================================
 * BLOCK 10 – FILTER, STATS, CHARTS, ZONAL BUTTON CALLBACKS
 * ==================================================================== */
// Elevation + NDSI + lake mask
function iransnowcover_filter(NDSI, elv, map) {
  var new_mask = dsm_iran.gt(elv)     // elevation > threshold
    .multiply(map.gt(NDSI))           // NDSI > threshold
    .multiply(lakemask.eq(1));        // not lake
  return map.updateMask(new_mask);
}
// Total snow area over Iran (km²)
function sumtotal(map) {
  var sum_iransnowcoverarea = map.mask()
    .multiply(ee.Image.pixelArea()) // m²
    .reduceRegion({
      reducer: ee.Reducer.sum(),
      geometry: Iran,
      scale: 500,
      maxPixels: 1e9
    });
  var area_m2 = ee.Number(sum_iransnowcoverarea.get('NDSI_Snow_Cover'));
  var area_km2 = area_m2.multiply(1e-6).round();  // m² → km²
  return area_km2;
}
// Zonal stats: snow area per polygon (km²)
function zonalstat(map, zones) {
  var zonstat = map.gt(0)
    .multiply(ee.Image.pixelArea())           // m²
    .multiply(ee.Image(ee.Number(1e-6)))      // km²
    .reduceRegions({
      reducer: ee.Reducer.sum(),
      collection: zones,
      scale: 500
    });
  return zonstat;
}
// Bar chart by zone name
function cartet(fetucol, Title) {
  var sorted = fetucol.sort('sum', false);  // descending by snow area
  var keys = sorted.aggregate_array('Name');
  var values = sorted.aggregate_array('sum').map(function(number) {
    return ee.Number(number).round();
  });
  var chart = ui.Chart.array.values({
      array: values,
      axis: 0,
      xLabels: keys
    })
    .setChartType('ColumnChart')
    .setSeriesNames(['Snow Cover'])
    .setOptions({
      title: Title,
      fontName: 'Arial',
      backgroundColor: '#fafafa',
      titleTextStyle: {fontSize: 13, bold: true},
      legend: {position: 'none'},
      bar: {groupWidth: '80%'},
      chartArea: {left: 80, top: 40, width: '70%', height: '55%'},
      colors: ['#1976D2'],
      hAxis: {
        title: 'Name of Places',
        titleTextStyle: {italic: false, bold: true},
        textStyle: {fontSize: 10}
      },
      vAxis: {
        title: 'Snow Cover Area – km²',
        titleTextStyle: {italic: false, bold: true},
        textStyle: {fontSize: 10}
      }
    });
  resultpanel2.add(chart);
}
// Zonal results buttons
B1resbot.onClick(function() {
  resultpanel2.clear();
  var respantitle = ui.Label('Detailed zonal statistics – Main basins (T9)', {
    fontSize: '13px',
    fontWeight: 'bold',
    color: '#333333',
    margin: '0 0 4px 0'
  });
  resultpanel2.add(respantitle);
  var B1 = zonalstat(IranSnowCoverImageCurrentYear, M9Basin);
  cartet(B1, 'Snow Cover Area – Current Year (Main Basins)');
  var B2 = zonalstat(IranSnowCoverImagePreviousYear, M9Basin);
  cartet(B2, 'Snow Cover Area – Previous Year (Main Basins)');
});
B2resbot.onClick(function() {
  resultpanel2.clear();
  var respantitle = ui.Label('Detailed zonal statistics – 2nd-degree basins (T30)', {
    fontSize: '13px',
    fontWeight: 'bold',
    color: '#333333',
    margin: '0 0 4px 0'
  });
  resultpanel2.add(respantitle);
  var C1 = zonalstat(IranSnowCoverImageCurrentYear, M30Basin);
  cartet(C1, 'Snow Cover Area – Current Year (2nd-Degree Basins)');
  var C2 = zonalstat(IranSnowCoverImagePreviousYear, M30Basin);
  cartet(C2, 'Snow Cover Area – Previous Year (2nd-Degree Basins)');
});
Prresbot.onClick(function() {
  resultpanel2.clear();
  var respantitle = ui.Label('Detailed zonal statistics – Provinces', {
    fontSize: '13px',
    fontWeight: 'bold',
    color: '#333333',
    margin: '0 0 4px 0'
  });
  resultpanel2.add(respantitle);
  var D1 = zonalstat(IranSnowCoverImageCurrentYear, Province);
  cartet(D1, 'Snow Cover Area – Current Year (Provinces)');
  var D2 = zonalstat(IranSnowCoverImagePreviousYear, Province);
  cartet(D2, 'Snow Cover Area – Previous Year (Provinces)');
});
// END OF SCRIPT