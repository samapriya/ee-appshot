var lowResImage = ui.import && ui.import("lowResImage", "image", {
      "id": "users/esra_kumi/Maxar/21OCT29041028-M3DS-014467832010_01_P001"
    }) || ee.Image("users/esra_kumi/Maxar/21OCT29041028-M3DS-014467832010_01_P001"),
    highResImage = ui.import && ui.import("highResImage", "image", {
      "id": "users/esra_kumi/21oct_P001_ENVI_Pan_Sharp_GS"
    }) || ee.Image("users/esra_kumi/21oct_P001_ENVI_Pan_Sharp_GS"),
    targetImageLR = ui.import && ui.import("targetImageLR", "image", {
      "id": "users/esra_kumi/Shadowtest_copy_arcgis"
    }) || ee.Image("users/esra_kumi/Shadowtest_copy_arcgis"),
    visParams = ui.import && ui.import("visParams", "imageVisParam", {
      "params": {
        "bands": [
          "b4",
          "b3",
          "b2"
        ],
        "min": [
          0,
          0,
          0
        ],
        "max": [
          400,
          400,
          400
        ]
      }
    }) || {"bands":["b4","b3","b2"],"min":[0,0,0],"max":[400,400,400]},
    refArea = ui.import && ui.import("refArea", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                98.15353849613753,
                4.1720648242294365
              ],
              [
                98.15353849613753,
                4.17045976178571
              ],
              [
                98.1547401257762,
                4.17045976178571
              ],
              [
                98.1547401257762,
                4.1720648242294365
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#d63000",
      "mode": "Geometry",
      "shown": true,
      "locked": false
    }) || 
    /* color: #d63000 */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[98.15353849613753, 4.1720648242294365],
          [98.15353849613753, 4.17045976178571],
          [98.1547401257762, 4.17045976178571],
          [98.1547401257762, 4.1720648242294365]]], null, false),
    targetArea = ui.import && ui.import("targetArea", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                98.24444446887027,
                4.198212940232366
              ],
              [
                98.2443586381818,
                4.198330640751804
              ],
              [
                98.24400458659183,
                4.198464391320539
              ],
              [
                98.2437470945264,
                4.198667692141104
              ],
              [
                98.24366126383792,
                4.198903093025086
              ],
              [
                98.24339840735446,
                4.199133143820383
              ],
              [
                98.24317310179721,
                4.1991973440302175
              ],
              [
                98.24246499861728,
                4.199218744098979
              ],
              [
                98.24196074332248,
                4.1990635935870895
              ],
              [
                98.24179309109098,
                4.198941894793939
              ],
              [
                98.24175554016477,
                4.198797444267111
              ],
              [
                98.2420291254843,
                4.198551343307941
              ],
              [
                98.24227852571192,
                4.198182281902618
              ],
              [
                98.24257893312159,
                4.197877330462248
              ],
              [
                98.24295980680171,
                4.197732879738404
              ],
              [
                98.24337286699,
                4.197829180223927
              ],
              [
                98.24365181672755,
                4.197973630929984
              ],
              [
                98.2435177062768,
                4.198225082095241
              ],
              [
                98.24369473207179,
                4.198390932819489
              ],
              [
                98.24389321553889,
                4.198278582332722
              ],
              [
                98.24445647943202,
                4.198080631435734
              ]
            ]
          ],
          "evenOdd": true
        },
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                98.24242316434253,
                4.199661874328364
              ],
              [
                98.24255727479327,
                4.1995976741567596
              ],
              [
                98.242868411039,
                4.199677924370447
              ],
              [
                98.2431205386864,
                4.19984377478594
              ],
              [
                98.24336193749774,
                4.200020325189486
              ],
              [
                98.24371062466967,
                4.200212925584176
              ],
              [
                98.24385546395648,
                4.20030387575401
              ],
              [
                98.24405394742358,
                4.20040017592229
              ],
              [
                98.2441666002022,
                4.200619526261229
              ],
              [
                98.24418251573374,
                4.2008525174210485
              ],
              [
                98.24389820157816,
                4.201061167623886
              ],
              [
                98.24367289602091,
                4.201264467767845
              ],
              [
                98.24348514138987,
                4.201489167865315
              ],
              [
                98.24327056466868,
                4.201334017804936
              ],
              [
                98.24311499654581,
                4.2012270177453175
              ],
              [
                98.24321155607035,
                4.20102906759632
              ],
              [
                98.2434905058079,
                4.20093276750567
              ],
              [
                98.2434905058079,
                4.200762351436526
              ],
              [
                98.24327056466868,
                4.200559051161705
              ],
              [
                98.24303453027537,
                4.200489501055519
              ],
              [
                98.24305062352946,
                4.200339700805757
              ],
              [
                98.24303453027537,
                4.2000615002656225
              ],
              [
                98.2427341228657,
                4.199959850043514
              ],
              [
                98.24236934243967,
                4.199831449744031
              ]
            ]
          ],
          "evenOdd": true
        }
      ],
      "displayProperties": [],
      "properties": {},
      "color": "#98ff00",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.MultiPolygon(
        [[[[98.24444446887027, 4.198212940232366],
           [98.2443586381818, 4.198330640751804],
           [98.24400458659183, 4.198464391320539],
           [98.2437470945264, 4.198667692141104],
           [98.24366126383792, 4.198903093025086],
           [98.24339840735446, 4.199133143820383],
           [98.24317310179721, 4.1991973440302175],
           [98.24246499861728, 4.199218744098979],
           [98.24196074332248, 4.1990635935870895],
           [98.24179309109098, 4.198941894793939],
           [98.24175554016477, 4.198797444267111],
           [98.2420291254843, 4.198551343307941],
           [98.24227852571192, 4.198182281902618],
           [98.24257893312159, 4.197877330462248],
           [98.24295980680171, 4.197732879738404],
           [98.24337286699, 4.197829180223927],
           [98.24365181672755, 4.197973630929984],
           [98.2435177062768, 4.198225082095241],
           [98.24369473207179, 4.198390932819489],
           [98.24389321553889, 4.198278582332722],
           [98.24445647943202, 4.198080631435734]]],
         [[[98.24242316434253, 4.199661874328364],
           [98.24255727479327, 4.1995976741567596],
           [98.242868411039, 4.199677924370447],
           [98.2431205386864, 4.19984377478594],
           [98.24336193749774, 4.200020325189486],
           [98.24371062466967, 4.200212925584176],
           [98.24385546395648, 4.20030387575401],
           [98.24405394742358, 4.20040017592229],
           [98.2441666002022, 4.200619526261229],
           [98.24418251573374, 4.2008525174210485],
           [98.24389820157816, 4.201061167623886],
           [98.24367289602091, 4.201264467767845],
           [98.24348514138987, 4.201489167865315],
           [98.24327056466868, 4.201334017804936],
           [98.24311499654581, 4.2012270177453175],
           [98.24321155607035, 4.20102906759632],
           [98.2434905058079, 4.20093276750567],
           [98.2434905058079, 4.200762351436526],
           [98.24327056466868, 4.200559051161705],
           [98.24303453027537, 4.200489501055519],
           [98.24305062352946, 4.200339700805757],
           [98.24303453027537, 4.2000615002656225],
           [98.2427341228657, 4.199959850043514],
           [98.24236934243967, 4.199831449744031]]]]),
    geometry = ui.import && ui.import("geometry", "geometry", {
      "geometries": [
        {
          "type": "Polygon",
          "coordinates": [
            [
              [
                98.24004208519754,
                4.2048115066464415
              ],
              [
                98.24004208519754,
                4.195352686855629
              ],
              [
                98.24647938683329,
                4.195352686855629
              ],
              [
                98.24647938683329,
                4.2048115066464415
              ]
            ]
          ],
          "geodesic": false,
          "evenOdd": true
        }
      ],
      "displayProperties": [
        {
          "type": "rectangle"
        }
      ],
      "properties": {},
      "color": "#0b4a8b",
      "mode": "Geometry",
      "shown": false,
      "locked": false
    }) || 
    /* color: #0b4a8b */
    /* shown: false */
    /* displayProperties: [
      {
        "type": "rectangle"
      }
    ] */
    ee.Geometry.Polygon(
        [[[98.24004208519754, 4.2048115066464415],
          [98.24004208519754, 4.195352686855629],
          [98.24647938683329, 4.195352686855629],
          [98.24647938683329, 4.2048115066464415]]], null, false),
    table = ui.import && ui.import("table", "table", {
      "id": "users/esra_kumi/class7evf_shp"
    }) || ee.FeatureCollection("users/esra_kumi/class7evf_shp"),
    image = ui.import && ui.import("image", "image", {
      "id": "projects/ee-kumi-mangrove/assets/WV2_Cloud_Project/21oct_P00123_mosaic"
    }) || ee.Image("projects/ee-kumi-mangrove/assets/WV2_Cloud_Project/21oct_P00123_mosaic"),
    table2 = ui.import && ui.import("table2", "table", {
      "id": "projects/ee-kumi-mangrove/assets/GMT_Priority_Rev15feb2022"
    }) || ee.FeatureCollection("projects/ee-kumi-mangrove/assets/GMT_Priority_Rev15feb2022"),
    table3 = ui.import && ui.import("table3", "table", {
      "id": "users/esra_kumi/class7evf_shp_buffered"
    }) || ee.FeatureCollection("users/esra_kumi/class7evf_shp_buffered");
Map.centerObject(highResImage, '10'); 
// var referanceImage = lowResImage.clip(refArea);
var referanceImage = image.clip(refArea);
var targetImageLR = image.clip(table);
//var targetImageHR = highResImage.clip(targetArea);
//Map.addLayer(lowResImage, visParams, "LRI");
Map.addLayer(targetImageLR, visParams, "Target LR");
Map.addLayer(highResImage, visParams, "HRI");
//Map.addLayer(targetImageHR, visParams, "Target HR");
//Map.addLayer(referanceImage, visParams, "Ref");
Map.addLayer(image, visParams, "img");
Map.addLayer(table, {}, "full shdw ply");
Map.addLayer(table3, {}, "full shdw ply_buffer");
Map.addLayer(table2, {}, "study area");
// Create a lookup table to make sourceHist match targetHist.
var lookup = function(sourceHist, targetHist) {
  // Split the histograms by column and normalize the counts.
  var sourceValues = sourceHist.slice(1, 0, 1).project([0])
  var sourceCounts = sourceHist.slice(1, 1, 2).project([0])
  sourceCounts = sourceCounts.divide(sourceCounts.get([-1]))
  var targetValues = targetHist.slice(1, 0, 1).project([0])
  var targetCounts = targetHist.slice(1, 1, 2).project([0])
  targetCounts = targetCounts.divide(targetCounts.get([-1]))
  // Find first position in target where targetCount >= srcCount[i], for each i.
  var lookup = sourceCounts.toList().map(function(n) {
    var index = targetCounts.gte(n).argmax()
    return targetValues.get(index)
  })
  return {x: sourceValues.toList(), y: lookup}
}
// Make the histogram of sourceImg match targetImg.
var histogramMatch = function(sourceImg, targetImg) {
  var args = {
    reducer: ee.Reducer.autoHistogram({maxBuckets: 65536, cumulative: true}), 
    geometry:  table,
    scale: 2, // Need to specify a scale, but it doesn't matter what it is because bestEffort is true.
    maxPixels: 65536 * 8 - 1,//8 tiles or 4 tiles
    bestEffort: true
  }
  var args2 = {
    reducer: ee.Reducer.autoHistogram({maxBuckets: 65536, cumulative: true}), 
    geometry: targetImg.geometry(),
    scale: 2, // Need to specify a scale, but it doesn't matter what it is because bestEffort is true.
    maxPixels: 65536 * 8 - 1,//8 tiles or 4 tiles
    bestEffort: true
  }
  // Only use pixels in target that have a value in source
  // (inside the footprint and unmasked).
  var source = sourceImg.reduceRegion(args)
  var target = targetImg.reduceRegion(args2)
  return ee.Image.cat(
    sourceImg.select(['b1'])
      .interpolate(lookup(source.getArray('b1'), target.getArray('b1'))),
    sourceImg.select(['b2'])
      .interpolate(lookup(source.getArray('b2'), target.getArray('b2'))),
    sourceImg.select(['b3'])
      .interpolate(lookup(source.getArray('b3'), target.getArray('b3'))),
    sourceImg.select(['b4'])
      .interpolate(lookup(source.getArray('b4'), target.getArray('b4'))),
    sourceImg.select(['b5'])
      .interpolate(lookup(source.getArray('b5'), target.getArray('b5'))),
    sourceImg.select(['b6'])
      .interpolate(lookup(source.getArray('b6'), target.getArray('b6'))),
    sourceImg.select(['b7'])
      .interpolate(lookup(source.getArray('b7'), target.getArray('b7'))),
    sourceImg.select(['b8'])
      .interpolate(lookup(source.getArray('b8'), target.getArray('b8')))
  )
}
var result = histogramMatch(targetImageLR, referanceImage);
var result2 = result.uint16();
Map.addLayer(result2, visParams, "Result 2");
print(result2)
print(image)
var imagesm = ee.ImageCollection([ image, result2]).mosaic();
Map.addLayer(imagesm, visParams, "Result rr");
// mong suan gave 
//var bufferSize = 2 // in meters
//var edgeBuffer = result.focal_max(bufferSize, 'square', 'meters');
//Map.addLayer(edgeBuffer, visParams, "Result 2");
/*//  Approach 1 start
var clippedHRI = highResImage.clip(geometry);
Map.addLayer(clippedHRI, visParams, "HRI");
var imageBands = clippedHRI.select(['b3', 'b5', 'b8']);
var maxValue = imageBands.reduce(ee.Reducer.max());
print(maxValue);
var imageMax = clippedHRI.addBands(maxValue.select(["max"]), ["max"]);
var C3 = imageMax.expression(
    'atan(B/max)', {
      'B': imageMax.select('b2'),
      'max': imageMax.select('max')
    });
print(ui.Chart.image.histogram(C3, imageMax.geometry(), 1));
var shadowMask = C3.select('b2').gte(0.85);
var C3shadow = C3.updateMask(shadowMask);
var NDWI = imageMax.expression(
    '(G-N)/(G+N)', {
      'G': imageMax.select('b3'),
      'N': imageMax.select('b8')
    });
Map.addLayer(NDWI);
print(ui.Chart.image.histogram(NDWI, imageMax.geometry(), 1));
var NDWImask = NDWI.select('b3').lte(0.6);
var C3shadow = C3shadow.updateMask(NDWImask);
Map.addLayer(C3shadow, {palette: 'FF0000'}, 'shadow_NDWI');
 // Approach 1 start end*/
 /*
var clippedHRI = lowResImage.clip(geometry);
var imageBands = clippedHRI.select(['b5', 'b3', 'b2']).divide(255);
var hriHSV = imageBands.rgbToHsv();
var NSVDI = hriHSV.expression(
  '(S-V)/(S+V)', {
    'S': hriHSV.select('saturation'),
    'V': hriHSV.select('value')
  });
 print(ui.Chart.image.histogram(NSVDI, clippedHRI.geometry(), 1));
 var NSVDIMask = NSVDI.select('saturation').gte(-0.2);
 var NSVDIshadow = NSVDI.updateMask(NSVDIMask);
 Map.addLayer(NSVDIshadow, {palette: 'FF0000'}, 'shadow_NSVDI');*/
Export.image.toDrive({ 
  image: imagesm,
  description: 'full-image-shadow-enhancement',
  scale: 2, 
  maxPixels: 1e13, 
  region: image.geometry()
});