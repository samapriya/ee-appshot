/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var geometry = 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[60.40042856440581, 38.50542859122749],
          [60.40042856440581, 28.93151224241641],
          [74.92435434565581, 28.93151224241641],
          [74.92435434565581, 38.50542859122749]]], null, false),
    geometry2 = 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.MultiPoint(
        [[64.42886328682441, 31.725518839666588],
         [65.29763335484876, 31.53209263994814]]),
    geometry3 = 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[64.0277371842785, 31.513005708499442],
          [64.0277371842785, 31.416661099816373],
          [64.17845587324334, 31.416661099816373],
          [64.17845587324334, 31.513005708499442]]], null, false),
    geometry4 = 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Point([64.08533167172206, 31.51707761372611]),
    geometry5 = 
    /* color: #98ff00 */
    /* shown: false */
    ee.Geometry.Point([64.11312813425113, 31.465128271794683]),
    aoi = 
    /* color: #d63000 */
    /* shown: false */
    ee.Geometry.Polygon(
        [[[63.75751015625002, 33.30875616512593],
          [62.46112343750002, 29.330739248382244],
          [64.57049843750002, 29.40733407079057],
          [65.62518593750002, 33.21689252732533]]], null, false),
    geometry6 = /* color: #98ff00 */ee.Geometry.Point([64.15912625973152, 31.45332440491417]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
//Map.setOptions("HYBRID"); 
var label = ui.Label("IWMI's Crop Health Analyzer", 
{fontWeight: 'bold', fontSize: '22px', margin: '0 0 0 0',padding: '0', position:'top-center'});
//var inspector = ui.Panel([label]);
var inspector = ui.Panel([label], ui.Panel.Layout.Flow('vertical'),{position:'top-center'});
Map.add(inspector);
// var label = ui.Label('',{fontWeight: 'bold', fontSize: '9px', margin: '0 0 0 0',padding: '0', position:'bottom-center'});
// //var inspector = ui.Panel([label]);
// var inspector = ui.Panel([label], ui.Panel.Layout.Flow('vertical'),{position:'bottom-center'});
// Map.add(inspector);
/**
 * //Mask with Lulc and //ndvi - 0 values
 * //snow mask
 * // water body area
 * // implement for s2 or l8 
 * 
 * Function to mask clouds using the Sentinel-2 QA band
 * @param {ee.Image} image Sentinel-2 image
 * @return {ee.Image} cloud masked Sentinel-2 image
 */
var long_start=2020
var long_end=2020
var curr=2021
//var curr_end=
var LULC = ee.Image('users/wrd_iwmi/afghanistan/LULC')//("users/wrd_iwmi/afghanistan/LC_AFGH_Resample")
//       .select(['b1'])
//Map.addLayer(LULC)
var LULC = ee.Image('users/wrd_iwmi/afghanistan/LULC')//("users/wrd_iwmi/afghanistan/LC_AFGH_Resample")
//       .select(['b1'])
      .remap
      ([0,	10,	11,	12,	13,	14,	15,	16,	17,	18,	20,	21,	22,	23,	24,	25,	26,	27,	30,	31,	32,	33,	34,	35,	36,	37,	38,	40,	41,	42,	43,	44,	50,	51,	52,	53,	60,	61,	70,	71,	72,	73,	74,	75,	76,	80,	81,	82,	83,	84,	85,	86,	87,	88,	89,	90,	100,	101,	102,	103,	104,	105,	106,	107,	108,	110,	111,	112,	113,	114,	115,	116],
       [0,	1,	 0,	 1,	 1,	 0,	 0,	 1,	 1,	 0,	 2,	 2,	 2,	 0,	 0,	 2,	 0,	 0,	 3,	 3,	 3,	 3,	 3,	 3,	 3,	 0,	 0,	 4,	 4,	 4,	 0,	 0,	 1,	 0,	 0,	 0,	 0,	 6,	 0,	 0,	 0,	 0,	 0,	 0,	 0,	 7,  7,	 7,	 7,	 0,	 0,	 0,	 0,	 0,	 0,	 0,	  0,	  9,	  9,	  9,	  9,	  0,	  0,	  0,	  0,	  0,	  0,	  0,	  0,	  0,	  0,	  0]);
//Map.addLayer(LULC)
var LULC=LULC.select(['remapped'])
          .remap
          ([0,1,2,3,4,5,6,7,9],
          [ 0,1,1,1,1,1,1,1,1]);
//LULC=LULC.clip(roi)        //  https://maps.gstatic.com/mapfiles/mv/imgs8.png
//Map.addLayer(LULC)
var roi=ee.FeatureCollection('projects/Afghan-DEWS/ADM2_DIST_ARAZI_Official_OCT17')//.geometry()
var roi_prov=ee.FeatureCollection('projects/Afghan-DEWS/Province_dissove_new')
var roi1=roi.geometry()
//geometry=roi1
var hilmand_prov=roi_prov.filter(ee.Filter.eq('Prov_name', 'Hilmand'))
//Map.centerObject(hilmand_prov, 7);
Map.setCenter(64.0871, 31.4533,15)
function maskS2clouds(image) {
  var qa = image.select('QA60');
  // Bits 10 and 11 are clouds and cirrus, respectively.
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  // Both flags should be set to zero, indicating clear conditions.
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
      .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000).set('system:time_start',image.get('system:time_start'));;
}
function getVegetationIndices(img){
  var ndvi = img.normalizedDifference(['B8','B4'])  
  return img.select([]) 
              .addBands([ndvi]) 
              .select([0],['ndvi']) 
              //.copyProperties(img,img.propertyNames())
              .set('system:time_start',img.get('system:time_start'));
}
var visualization = { 
  min: 0.0,
  max: 0.3,
  bands: ['B8', 'B4', 'B3'],
};
var colorizedVis = {
    min: -0.2,
  max: 1,
  palette: [
    'FFFFFF', 'CE7E45', 'DF923D', 'F1B555', 'FCD163', '99B718', '74A901',
    '66A000', '529400', '3E8601', '207401', '056201', '004C00', '023B01',
    '012E01', '011D01', '011301'
  ],
};
// var dataset_2018 = ee.ImageCollection('COPERNICUS/S2_SR')
//                   .filterDate('2018-03-01', '2018-03-30')
//                   // Pre-filter to get less cloudy granules.
//                   .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',40))
//                   .map(maskS2clouds)
//                   .filterBounds(geometry)
// var dataset_2021 = ee.ImageCollection('COPERNICUS/S2_SR')
//                   .filterDate('2021-03-01', '2021-03-30')
//                   // Pre-filter to get less cloudy granules.
//                   .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',40))
//                   .map(maskS2clouds)
//                   .filterBounds(geometry)
// var dataset_2019 = ee.ImageCollection('COPERNICUS/S2_SR')
//                   .filterDate('2019-03-01', '2019-03-30')
//                   // Pre-filter to get less cloudy granules.
//                   .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',40))
//                   .map(maskS2clouds)
//                   .filterBounds(geometry)
// var dataset_2020 = ee.ImageCollection('COPERNICUS/S2_SR')
//                   .filterDate('2020-03-01', '2020-03-30')
//                   // Pre-filter to get less cloudy granules.
//                   .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',40))
//                   .map(maskS2clouds)
//                   .filterBounds(geometry)
// var dataset_2019_2020=dataset_2019.merge(dataset_2020)                  
//Map.addLayer(dataset_2019_2020.mean(), visualization, '2019_2020 RGB');
//Map.addLayer(dataset_2018.mean(), visualization, 'RGB 2018');
//Map.addLayer(dataset_2019.mean(), visualization, 'RGB 2019');
//Map.addLayer(dataset_2020.mean(), visualization, 'RGB 2020');
//Map.addLayer(dataset_2021.mean(), visualization, 'RGB 2021');
// var ndviCollection_2020 = dataset_2020.map(getVegetationIndices)
// var ndviCollection_2021 = dataset_2021.map(getVegetationIndices)
// var ndviCollection_2019 = dataset_2019.map(getVegetationIndices)
// var dataset = ee.ImageCollection('LANDSAT/LC08/C01/T1_32DAY_ndvi')
//                   .filterDate('2018-03-01', '2018-3-30');
// var colorized = dataset.select('ndvi');
//Map.setCenter(6.746, 46.529, 6);
//Map.addLayer(colorized, colorizedVis, 'ndvi 2018');
//Map.addLayer(ndviCollection_2019.select('ndvi').median(),colorizedVis,'ndvi 2019') //.mean().clip(geometry)
//Map.addLayer(ndviCollection_2020.select('ndvi').median(),colorizedVis,'ndvi 2020') //.mean().clip(geometry)
//Map.addLayer(ndviCollection_2021.select('ndvi').median(),colorizedVis,'ndvi 2021') //.mean().clip(geometry)
var dataset = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2015-03-01', '2021-03-31')
                  // Pre-filter to get less cloudy granules.
                  //.filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',40))
                  //.map(maskS2clouds)
                  .filterBounds(aoi)
var dataset1 = ee.ImageCollection('COPERNICUS/S2_SR')
                  .filterDate('2015-03-01', '2021-03-31')
                  // Pre-filter to get less cloudy granules.
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE',40))
                  .map(maskS2clouds)
                  .filterBounds(aoi)
var dataset = dataset.map(getVegetationIndices)                  
function convert(image){
  var result = image.toFloat().multiply(0.0001)//.subtract(273.15)
  result = result.copyProperties(image, ['system:time_start']) 
  return result 
}
//var dataset = ee.ImageCollection('MODIS/006/MOD13Q1')
                 // .filter(ee.Filter.date('2019-01-01', '2020-12-30'));
//var dataset = dataset.select('ndvi').map(convert);
var geometry=aoi
var jan_max = dataset
  .filterBounds(geometry)
  .filter(ee.Filter.calendarRange(1,1,'month'))
   .filter(ee.Filter.calendarRange(long_start,long_end,'year'))
  .max()
var feb_max = dataset
  .filterBounds(geometry)
  .filter(ee.Filter.calendarRange(2,2,'month'))
   .filter(ee.Filter.calendarRange(long_start,long_end,'year'))
  .max()
var mar_max = dataset
  .filterBounds(geometry)
  .filter(ee.Filter.calendarRange(3,3,'month'))
  .filter(ee.Filter.calendarRange(long_start,long_end,'year'))
  .max()
var mar_max_l = dataset
  .filterBounds(geometry)
  .filter(ee.Filter.calendarRange(3,3,'month'))
  .filter(ee.Filter.calendarRange(2001,2020,'year'))
  .max()
//var jan_max = jan.map(getVegetationIndices)//.max()
//var feb_max = feb.map(getVegetationIndices)//.max()
//var mar_max = jan.map(getVegetationIndices)//.max()
//Map.addLayer(jan_max,colorizedVis,'jan_max') //.mean().clip(geometry)
//Map.addLayer(feb_max,colorizedVis,'feb_max') //.mean().clip(geometry)
Map.addLayer(dataset1.filterDate('2020-03-01', '2020-03-31').median(), visualization, 'Satellite Imagery (Historical)',false);  
Map.addLayer(dataset1.filterDate('2021-03-01', '2021-03-31').median(), visualization, 'Satellite Imagery (March 2021)',false);
Map.addLayer(mar_max,colorizedVis,'March NDVI (Historical)',false) //.mean().clip(geometry)
var jan_curr = dataset
  .filterBounds(geometry)
  .filter(ee.Filter.calendarRange(1,1,'month'))
   .filter(ee.Filter.calendarRange(curr,curr,'year'))
  .max()
var feb_curr = dataset
  .filterBounds(geometry)
  .filter(ee.Filter.calendarRange(2,2,'month'))
   .filter(ee.Filter.calendarRange(curr,curr,'year'))
  .max()
var mar_curr = dataset
  .filterBounds(geometry)
  .filter(ee.Filter.calendarRange(3,3,'month'))
  .filter(ee.Filter.calendarRange(curr,curr,'year'))
  .max()  
//Map.addLayer(jan_curr,colorizedVis,'jan_curr') //.mean().clip(geometry)
//Map.addLayer(feb_curr,colorizedVis,'feb_curr') //.mean().clip(geometry)
Map.addLayer(mar_curr,colorizedVis,'March NDVI (2021)',true) //.mean().clip(geometry)
var mar_curr_class= mar_curr.expression(
    "(b('ndvi') > 0.7) ? 5" +    // very healthy 
   //   ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
      ": (b('ndvi') >0.4 and b('ndvi')<=0.7) ? 4" + //healthy 
        ": (b('ndvi') >0.2 and b('ndvi')<=0.4) ? 3" + //moderate
        ": (b('ndvi') >0 and b('ndvi')<=0.2) ? 2" + //poor vegetation
        ": (b('ndvi') <=0) ? 1" +
          ": 0"
    );
//Map.addLayer(mar_curr_class,{},'mar_curr_class')
var mar_max_class= mar_max.expression(
    "(b('ndvi') > 0.7) ? 5" +    // very healthy 
   //   ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
      ": (b('ndvi') >0.4 and b('ndvi')<=0.7) ? 4" + //healthy 
        ": (b('ndvi') >0.2 and b('ndvi')<=0.4) ? 3" + //moderate
        ": (b('ndvi') >0 and b('ndvi')<=0.2) ? 2" + //poor vegetation
        ": (b('ndvi') <=0) ? 1" +
          ": 0"
    );
//Map.addLayer(mar_max_class,{},'mar_max_class')
var feb_max_class= feb_max.expression(
    "(b('ndvi') > 0.7) ? 5" +    // very healthy 
   //   ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
      ": (b('ndvi') >0.4 and b('ndvi')<=0.7) ? 4" + //healthy 
        ": (b('ndvi') >0.2 and b('ndvi')<=0.4) ? 3" + //moderate
        ": (b('ndvi') >0 and b('ndvi')<=0.2) ? 2" + //poor vegetation
        ": (b('ndvi') <=0) ? 1" +
          ": 0"
    );
var jan_max_class= jan_max.expression(
    "(b('ndvi') > 0.7) ? 5" +    // very healthy 
   //   ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
      ": (b('ndvi') >0.4 and b('ndvi')<=0.7) ? 4" + //healthy 
        ": (b('ndvi') >0.2 and b('ndvi')<=0.4) ? 3" + //moderate
        ": (b('ndvi') >0 and b('ndvi')<=0.2) ? 2" + //poor vegetation
        ": (b('ndvi') <=0) ? 1" +
          ": 0"
    );
var mar_curr_class1= mar_curr.expression(
    "(b('ndvi') > 0.7) ? 500" +    // very healthy 
   //   ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
      ": (b('ndvi') >0.4 and b('ndvi')<=0.7) ? 400" + //healthy 
        ": (b('ndvi') >0.2 and b('ndvi')<=0.4) ? 300" + //moderate
        ": (b('ndvi') >0 and b('ndvi')<=0.2) ? 200" + //poor vegetation
        ": (b('ndvi') <=0) ? 100" +
          ": 0"
    );   
var feb_curr_class1= feb_curr.expression(
    "(b('ndvi') > 0.7) ? 500" +    // very healthy 
   //   ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
      ": (b('ndvi') >0.4 and b('ndvi')<=0.7) ? 400" + //healthy 
        ": (b('ndvi') >0.2 and b('ndvi')<=0.4) ? 300" + //moderate
        ": (b('ndvi') >0 and b('ndvi')<=0.2) ? 200" + //poor vegetation
        ": (b('ndvi') <=0) ? 100" +
          ": 0"
    );   
var jan_curr_class1= jan_curr.expression(
    "(b('ndvi') > 0.7) ? 500" +    // very healthy 
   //   ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
      ": (b('ndvi') >0.4 and b('ndvi')<=0.7) ? 400" + //healthy 
        ": (b('ndvi') >0.2 and b('ndvi')<=0.4) ? 300" + //moderate
        ": (b('ndvi') >0 and b('ndvi')<=0.2) ? 200" + //poor vegetation
        ": (b('ndvi') <=0) ? 100" +
          ": 0"
    ); 
var mat=mar_curr_class1.add(mar_max_class)
var vhCondition = (mat.updateMask(mat.gt(500)))
var hCondition = (mat.updateMask(mat.gt(400))).and(mat.lt(500))
var modCondition = (mat.updateMask(mat.gt(299))).and(mat.lt(305))
var poorCondition = (mat.updateMask(mat.gt(100))).and(mat.lt(103))                 
var poorCondition1 = (mat.updateMask(mat.gt(200))).and(mat.lt(204))
var poorCondition2 = (mat.updateMask(mat.eq(305)));
var ripCondition=mat.updateMask(mat.gt(102)).and(mat.lt(106))
var ripCondition1=mat.updateMask(mat.gt(203)).and(mat.lt(206))
var fl_mar = ee.Image(0)
                  .where(vhCondition,1)
                  .where(hCondition,2)
                  .where(modCondition,3)
                  .where(poorCondition,4)
                  .where(poorCondition1,4)
                  .where(poorCondition2,4)
                  .where(ripCondition,5) 
                  .where(ripCondition1,5)
var mat=feb_curr_class1.add(feb_max_class)
var vhCondition = (mat.updateMask(mat.gt(500)))
var hCondition = (mat.updateMask(mat.gt(400))).and(mat.lt(500))
var modCondition = (mat.updateMask(mat.gt(299))).and(mat.lt(305))
var poorCondition = (mat.updateMask(mat.gt(100))).and(mat.lt(103))                 
var poorCondition1 = (mat.updateMask(mat.gt(200))).and(mat.lt(204))
var poorCondition2 = (mat.updateMask(mat.eq(305)));
var ripCondition=mat.updateMask(mat.gt(102)).and(mat.lt(106))
var ripCondition1=mat.updateMask(mat.gt(203)).and(mat.lt(206))
var fl_feb = ee.Image(0)
                  .where(vhCondition,1)
                  .where(hCondition,2)
                  .where(modCondition,3)
                  .where(poorCondition,4)
                  .where(poorCondition1,4)
                  .where(poorCondition2,4)
                  .where(ripCondition,5) 
                  .where(ripCondition1,5)                
var mat=jan_curr_class1.add(jan_max_class)
var vhCondition = (mat.updateMask(mat.gt(500)))
var hCondition = (mat.updateMask(mat.gt(400))).and(mat.lt(500))
var modCondition = (mat.updateMask(mat.gt(299))).and(mat.lt(305))
var poorCondition = (mat.updateMask(mat.gt(100))).and(mat.lt(103))                 
var poorCondition1 = (mat.updateMask(mat.gt(200))).and(mat.lt(204))
var poorCondition2 = (mat.updateMask(mat.eq(305)));
var ripCondition=mat.updateMask(mat.gt(102)).and(mat.lt(106))
var ripCondition1=mat.updateMask(mat.gt(203)).and(mat.lt(206))
var fl_jan = ee.Image(0)
                  .where(vhCondition,1)
                  .where(hCondition,2)
                  .where(modCondition,3)
                  .where(poorCondition,4)
                  .where(poorCondition1,4)
                  .where(poorCondition2,4)
                  .where(ripCondition,5) 
                  .where(ripCondition1,5)    
//Map.addLayer(fl.updateMask(fl.eq(1)),{palette:'#1a9641'},'vh')    
//Map.addLayer(fl.updateMask(fl.eq(2)),{palette:'a6d96a'},'h') 
//Map.addLayer(fl.updateMask(fl.eq(3)),{palette:'fdae61'},'m') 
//Map.addLayer(fl.updateMask(fl.eq(4)),{palette:'d7191c'},'p') 
//Map.addLayer(fl.updateMask(fl.eq(5)),{palette:'brown'},'r') 
var vis5 = {
  min: 1,
  max: 5,
  palette:
   //   ['#ffffe5','#f7fcb9','#d9f0a3','#addd8e','#78c679','#41ab5d','#238443','#006837','#004529']
  // ['#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850']
  ['#A52A2A','#d7191c','#fdae61','#a6d96a','#1a9641'].reverse()
};
var dataset = ee.ImageCollection('MODIS/006/MOD10A1')
var snowCover_mar = dataset 
   .filterBounds(geometry)
  .filter(ee.Filter.calendarRange(3,3,'month'))
  .filter(ee.Filter.calendarRange(curr,curr,'year'))
//.filter(ee.Filter.date(curr+'-03-01', curr+'-03-31'))
.select('NDSI_Snow_Cover');
var snowCoverVis = {
  min: 0.0,
  max: 100.0,
  palette: ['black', '0dffff', '0524ff', 'ffffff'],
};
snowCover_mar=snowCover_mar.mean()
var snowCover_feb = dataset.filterBounds(geometry)
  .filter(ee.Filter.calendarRange(2,2,'month'))
  .filter(ee.Filter.calendarRange(curr,curr,'year'))
//.filter(ee.Filter.date(curr+'-03-01', curr+'-03-31'))
.select('NDSI_Snow_Cover');
snowCover_feb=snowCover_feb.mean()
var snowCover_jan = dataset.filterBounds(geometry)
  .filter(ee.Filter.calendarRange(1,1,'month'))
  .filter(ee.Filter.calendarRange(curr,curr,'year'))
//.filter(ee.Filter.date(curr+'-03-01', curr+'-03-31'))
.select('NDSI_Snow_Cover');
snowCover_jan=snowCover_jan.mean()
//Map.addLayer(snowCover, snowCoverVis, 'Snow Cover');
//fl_mar=fl_mar.updateMask(fl_mar.gt(0))
//fl_feb=fl_feb.updateMask(fl_feb.gt(0))
//fl_jan=fl_jan.updateMask(fl_jan.gt(0))
fl_mar=fl_mar.updateMask(LULC.gt(0))//.updateMask(mar_max_l.gt(0.19))//.updateMask(snowCover_mar.lt(1))//.updateMask(snowCover_mar.lt(1))
fl_feb=fl_feb.updateMask(LULC.gt(0))//.updateMask(mar_max_l.gt(0.19))//.updateMask(snowCover_feb.lt(1))//.updateMask(snowCover_feb.lt(1))
fl_jan=fl_jan.updateMask(LULC.gt(0))//.updateMask(mar_max_l.gt(0.19))//.updateMask(snowCover_jan.lt(1))//.updateMask(snowCover_jan.lt(1))
//Map.addLayer(fl_mar,vis5,'fl_mar') //.updateMask(mar_curr.gt(0.19))
//Map.addLayer(fl_feb,vis5,'fl_feb') //.updateMask(mar_curr.gt(0.19))
//Map.addLayer(fl_jan,vis5,'fl_jan') //.updateMask(mar_curr.gt(0.19))
var fl_jan_mod=fl_jan.multiply(100)
var fl_feb_mod=fl_feb.multiply(10)
var fl_season=fl_jan_mod.add(fl_feb_mod).add(fl_mar)
//var cond=(fl_mar.eq(1)).updateMask(fl_feb.eq(2)).updateMask(fl_jan.eq(2))
var svhCondition = (fl_season.updateMask(fl_season.eq(321))).or(fl_season.eq(421).or(fl_season.eq(431))) //321,421
var shCondition = (fl_season.updateMask(fl_season.eq(432).or(fl_season.eq(422)).or(fl_season.eq(322)).or(fl_season.eq(222))))//432,422,322
//Map.addLayer(shCondition)
var smodCondition = (fl_season.updateMask(fl_season.eq(433).or(fl_season.eq(333)).or(fl_season.eq(443)))) //433,333,443
var spoorCondition = (fl_season.updateMask(fl_season.eq(444)))   //444 ,
//var spoorCondition1 = (fl_season.updateMask(fl_season.gt(200))).and(fl_season.lt(204))
//var spoorCondition2 = (fl_season.updateMask(fl_season.eq(305)));
var sripCondition=fl_season.updateMask(fl_season.eq(445))//.and(fl_season.lt(106))//445
//var sripCondition1=fl_season.updateMask(fl_season.gt(203)).and(fl_season.lt(206))
var fl_season1 = ee.Image(0)
                  .where(svhCondition,1)
                  .where(shCondition,2)
                  .where(smodCondition,3)
                  .where(spoorCondition,4)
                 // .where(spoorCondition1,4)
                  //.where(spoorCondition2,4)
                  .where(sripCondition,5) 
                  //.where(sripCondition1,5)    
//fl_season1=fl_season1.updateMask(fl_season1.gt(0))
Map.addLayer(fl_season1.updateMask(LULC.gt(0)).updateMask(mar_max_l.gt(0.19)).updateMask(snowCover_mar.lt(1)),vis5,'Crop Health Index (Jan- March 2021)',false)//.clip(hilmand_prov)
//.updateMask(mar_max_l.gt(0.19)).updateMask(snowCover_mar.lt(1))
//march 2021 March NDVI (2021)
//historical march NDVI (hISTORICAL)
//SATELLITE IMAGERY S2 (mARCH 2021) 
//SATELLITE IMAGERY S2 (mARCH 2020) 
//crop health analyzer (Jan- March 2021) - app name 
//crop health index 
// district boundary 
var senarioCondition = (fl_season.updateMask(fl_season.eq(211))) //321,421.or(fl_season.eq(421))
var fl_senario = ee.Image(0)
                  .where(senarioCondition,1)
                //   .where(shCondition,2)
                //   .where(smodCondition,3)
                //   .where(spoorCondition,4)
                // // .where(spoorCondition1,4)
                //   //.where(spoorCondition2,4)
                //   .where(sripCondition,5) 
                //   //.where(sripCondition1,5)  
fl_senario=fl_senario.updateMask(fl_senario.gt(0))
//Map.addLayer(fl_senario.updateMask(LULC.gt(0)).updateMask(mar_max_l.gt(0.19)).updateMask(snowCover_mar.lt(1)),vis5,'fl_senario')
 /************************ Title ****************************/
//var hCondition = (mat.updateMask(mat.gt(400))).and(mat.lt(500))
//////////////////////////////////////////////////////////////    
// var vis4 = {
//   min: 1,
//   max: 4,
//   palette:
//   //   ['#ffffe5','#f7fcb9','#d9f0a3','#addd8e','#78c679','#41ab5d','#238443','#006837','#004529']
//   // ['#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850']
//   ['#d7191c','#fdae61','#a6d96a','#1a9641']
// };
// //Map.addLayer(mar_max_class,vis4,'mar_max_class') 
// //Map.addLayer(mar_curr_class,vis4,'mar_curr_class') 
// var diff=mar_curr_class.subtract(mar_max_class)
// var maxPrcW1 = diff.reduceRegion({
//   reducer: ee.Reducer.max(),
//   geometry: roi.geometry(),
//   scale: 250,
//   maxPixels: 1e9
// });
// print(maxPrcW1)
// var maxPrcW1 = diff.reduceRegion({
//   reducer: ee.Reducer.min(),
//   geometry: roi.geometry(),
//   scale: 250,
//   maxPixels: 1e9
// });
// print(maxPrcW1)
// var vis3 = {
//   min: -3,
//   max: 3,
//   palette:
//   //   ['#ffffe5','#f7fcb9','#d9f0a3','#addd8e','#78c679','#41ab5d','#238443','#006837','#004529']
//   // ['#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850']
//   //['red','yellow','#1a9641']
//   ['d7191c','fdae61','a6d96a','1a9641']
// };
// // var diff_class= diff.expression(
// //     "(b('constant') > 0) ? 3" + 
// //   //   ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
// //   //   ": (b('ndvi') >0.50 and b('ndvi')<=0.75) ? 3" +
// //     //    ": (b('constant') >0.2 and b('constant')<=0.6) ? 3" +
// //         ": (b('constant') =>0 and b('constant')<=0) ? 2" +
// //         ": (b('constant') <0) ? 1" +
// //           ": 0"
// //    );
// var diff_class= diff.expression(
//     "(b('constant') > 0.02) ? 3" +    // very healthy 
//   //   ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
//     // ": (b('ndvi') >0.4 and b('ndvi')<=0.7) ? 4" + //healthy 
//       // ": (b('ndvi') >0.2 and b('ndvi')<=0.4) ? 3" + //moderate
//         ": (b('constant') >=0 and b('constant')<=0.02) ? 2" + //poor vegetation
//         ": (b('constant') <0) ? 1" +
//           ": 0"
//     );
//   //   var diff_class= diff.expression(
//   //   "(b('constant') > 0.02) ? 5" +    // very healthy 
//   // //   ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
//   //   // ": (b('ndvi') >0.4 and b('ndvi')<=0.7) ? 4" + //healthy 
//   //   ": (b('constant') >=0 and b('constant')<=0.02) ? 4" + //poor vegetation
//   //       ": (b('constant') >-2 and b('constant')<0) ? 3" + //moderate
//   //       ": (b('constant') >=-4 and b('constant')<-2) ? 2" + //poor vegetation
//   //       ": (b('constant') <-4) ? 1" +
//   //         ": 0"
//   //   );
// //Map.addLayer(diff.updateMask(mar_curr.gt(0.0)),vis3,'differ') //.updateMask(LULC.gt(0.0))
// var vis = {
//   min: 1,
//   max: 3,
//   palette:
//   //   ['#ffffe5','#f7fcb9','#d9f0a3','#addd8e','#78c679','#41ab5d','#238443','#006837','#004529']
//   // ['#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850']
//   //['red','yellow','#1a9641']
//   ['d7191c','a6d96a','1a9641']
// };
// //Map.addLayer(diff_class.updateMask(mar_curr.gt(0.0)),vis3,'diff_class') //.updateMask(LULC.gt(0.0))
// var jan_def=jan_curr.divide(jan_max)
// var feb_def=feb_curr.divide(feb_max)
// var mar_def=mar_curr.divide(mar_max)
// //Map.addLayer(jan_def)
// //Map.addLayer(jan_def,colorizedVis,'jan_def') //.mean().clip(geometry)
// //Map.addLayer(feb_def,colorizedVis,'feb_def') //.mean().clip(geometry)
// //Map.addLayer(mar_def,colorizedVis,'mar_def') //.mean().clip(geometry)
// var jan_def_class= jan_def.expression(
//     "(b('ndvi') > 1) ? 5" + 
//       ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
//       ": (b('ndvi') >0.50 and b('ndvi')<=0.75) ? 3" +
//         ": (b('ndvi') >0.25 and b('ndvi')<=0.50) ? 2" +
//         ": (b('ndvi') >0 and b('ndvi')<=0.25) ? 1" +
//         ": (b('ndvi') <=0) ? 0" +
//           ": 0"
//     );
// var feb_def_class= feb_def.expression(
//     "(b('ndvi') > 1) ? 5" + 
//       ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
//       ": (b('ndvi') >0.50 and b('ndvi')<=0.75) ? 3" +
//         ": (b('ndvi') >0.25 and b('ndvi')<=0.50) ? 2" +
//         ": (b('ndvi') >0 and b('ndvi')<=0.25) ? 1" +
//         ": (b('ndvi') <=0) ? 0" +
//           ": 0"
//     );
// var mar_def_class= mar_def.expression(
//     "(b('ndvi') > 1) ? 5" + 
//       ": (b('ndvi') >0.75 and b('ndvi')<=1) ? 4" +
//       ": (b('ndvi') >0.50 and b('ndvi')<=0.75) ? 3" +
//         ": (b('ndvi') >0.25 and b('ndvi')<=0.50) ? 2" +
//         ": (b('ndvi') >0 and b('ndvi')<=0.25) ? 1" +
//         ": (b('ndvi') <=0) ? 0" +
//           ": 0"
//     );
// var ch=mar_def_class.add(feb_def_class).add(jan_def_class)
// var vis = {
//   min: 1,
//   max: 15,
//   palette:
//   //   ['#ffffe5','#f7fcb9','#d9f0a3','#addd8e','#78c679','#41ab5d','#238443','#006837','#004529']
//   ['#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850']
// }; 
// //Map.addLayer(ch.updateMask(LULC.gt(0)).updateMask(mar_curr.gt(0)),vis,'crop health')
// var ch_class= ch.expression(
//     "(b('constant') > 12) ? 4" + 
//     //  ": (b('constant') >0.75 and b('constant')<=1) ? 4" +
//       ": (b('constant') >9 and b('constant')<=12) ? 3" +
//         ": (b('constant') >4 and b('constant')<=9) ? 2" +
//         ": (b('constant') >0 and b('constant')<=4) ? 1" +
//         ": (b('constant') <=0) ? 0" +
//           ": 0"
//     );
// ch_class=ch_class.updateMask(LULC.gt(0))//.updateMask(mar_curr.gt(0.1))
// //Map.addLayer(ch_class.updateMask(mar_curr.gt(0)),vis4,'crop health class')
//Map.addLayer(mar_curr.updateMask(mar_curr.lt(0.1)).updateMask(LULC.gt(0)),{palette:'black'},'No crop')
Map.addLayer(ee.Image().paint(roi, 0, 0.6), {palette:'grey'}, 'Afghanistan Districts',false);
Map.addLayer(ee.Image().paint(roi_prov, 0, 0.6), {palette:'black'}, 'Afghanistan Province',false);
//Map.addLayer(ee.Image().paint(geometry3, 0, 0.6), {palette:'black'}, 'hilmand');
////////Legend//////////////////////////////////////////
/////////////////////////////////////////////////////////
var legend = ui.Panel({
  style: {
    position: 'bottom-left',
    padding: '8px 15px'
  }
});
// Create legend title
var legendTitle = ui.Label({
  value: 'Crop Health Index', 
  style: {
    fontWeight: 'bold',
    fontSize: '14px', 
    margin: '0 0 4px 0',
    padding: '0'
    }
});
// Add the title to the panel
legend.add(legendTitle);
// Creates and styles 1 row of the legend.
var makeRow = function(color, name) {
      // Create the label that is actually the colored box.
      var colorBox = ui.Label({
        style: {
          backgroundColor: '#' + color,
          // Use padding to give the box height and width.
          padding: '8px',
          margin: '0 0 4px 0'
        }
      });
      // Create the label filled with the description text.
      var description = ui.Label({
        value: name,
        style: {margin: '0 0 4px 6px'}
      });
      // return the panel
      return ui.Panel({
        widgets: [colorBox, description],
        layout: ui.Panel.Layout.Flow('horizontal')
      });
};
var palette =['A52A2A','d7191c','fdae61','a6d96a','1a9641']//['5C0000','E60000','E69800','a6d96a']                                                                                                                                                               
// name of the legend
var names = ['RIP','Poor','Moderate','Healthy','Very Healthy']
// Add color and and names
for (var i = 0; i < 5; i++) {
  legend.add(makeRow(palette[i], names[i]));
  }  
// add legend to map (alternatively you can also print the legend to the console)
Map.add(legend);
var TitleLabel = ui.Label("IWMI's Crop Health Analyzer (v1)",{height: 18, fontWeight: 'bold'});
var ExplaLabel = ui.Label('IWMI’s Crop Health Analyzer uses high resolution satellite data (10 meters) to understand your crops’ health without the need for field inspection. The tool uses spatio-temporal Normalized Difference Vegetation Index (NDVI) data both and can easily identify problematic areas in your field and assess the health of plants, their status and progress over time.',{textAlign:'justify',fontSize: '11px', width: '270px', height: '90px'});
var ExplaLabel1 = ui.Label('   The application will be handy for irrigation officials to have production forecast to assess market risks, it also helps the government to evaluate drought situation rapidly for early action and adaptive drought response. This tool is scalable to any region and can customize to specific irrigation scheme for periodic monitoring and evaluation.',{textAlign:'justify',fontSize: '11px', width: '270px', height: '90px'});
var ExplaLabel2 = ui.Label('   Thanks to CGIAR Research Program on Water, Land and Ecosystems (WLE) for the funding support.',{textAlign:'justify',fontSize: '11px', width: '270px', height: '30px'});
//var ExplaLabel2 = ui.Label('   The application will be handy for irrigation officials to have production forecast to assess market risks, it also helps the government to evaluate drought situation rapidly for early action and adaptive drought response. This tool is scalable to any region and can customize to specific irrigation scheme for periodic monitoring and evaluation. Thanks to CGIAR Research Program on Water, Land and Ecosystems (WLE) for the funding support.',{textAlign:'justify',fontSize: '11px', width: '270px', height: '240px'});
//var info= (ui.Label('For more Info, please visit: http://...',{fontWeight: 'bold',fontSize: '09px',position: 'top-right'}));
//panel.add(info);
var TitleLabel0 = ui.Label('Disclaimer: The tool is created by the International Water Management Institute (IWMI) has not been validated in the field and use of national borders are purely a graphical representation, only intended to be indicative, and do not reflect the official position of the IWMI or CGIAR WLE. Neither the IWMI nor any person acting on behalf of the program are not responsible for the use that might be made of this application.',{width: '270px',height: 100, textAlign:'justify',fontSize: '9px', fontWeight: 'Italic'});
var EarthPanel0 = ui.Panel([TitleLabel0],ui.Panel.Layout.flow('horizontal'),{width: '300px', height: '1000px', position: 'bottom-left'});
//var ExplaLabel2 = ui.Label('Long term mean annual precipitation',{textAlign:'justify',fontSize: '14px', width: '400px', height: '100px'});
//var ExplaLabel2 = ui.Label('Long term mean annual precipitation',{height: 10, fontWeight: 'bold'});
//// Add minimap
var EarthMap = ui.Map();
EarthMap.setControlVisibility(false);
//EarthMap.addLayer(300,{palette: 'FFFF0000'});
var empty = ee.Image().byte();
var outline1 = empty.paint({
  featureCollection: roi,
  color: 1,
  width: 0.3
});
//EarthMap.addLayer(outline1,{palette: 'black'});
//Map.addLayer(outline1, {palette: 'black'}, 'India Boundary');
//Map.setOptions("HYBRID");
//EarthMap.centerObject(aoi,2.2);
//EarthMap.setCenter(78.17, 26.125,2.2) 
var EarthPanel = ui.Panel([EarthMap],ui.Panel.Layout.flow('horizontal'),{width: '300px', height: '270px', position: 'bottom-left'});
//var TitleLabel12 = ui.Label('Long term mean monthly precipitation',{height: 10, fontWeight: 'bold'});
//var EarthPanel12 = ui.Panel([TitleLabel2],ui.Panel.Layout.flow('horizontal'),{width: '520px', height: '320px', position: 'bottom-left'});
var TitleLabel01 = ui.Label('',{height: 10, fontWeight: 'bold'});
var TitleLabel1 = ui.Label('',{height: 10, fontWeight: 'bold'});
var TitleLabel2 = ui.Label('',{height: 10, fontWeight: 'bold'});
var EarthPanel01 = ui.Panel([TitleLabel01],ui.Panel.Layout.flow('horizontal'),{width: '300px', height: '200px', position: 'bottom-left'});
var EarthPanel1 = ui.Panel([TitleLabel1],ui.Panel.Layout.flow('horizontal'),{width: '300px', height: '200px', position: 'bottom-left'});
//var EarthPanel2 = ui.Panel([TitleLabel2],ui.Panel.Layout.flow('horizontal'),{width: '400px', height: '200px', position: 'bottom-left'});
var TitleLabel3 = ui.Label('',{width: '380px', height: 10,textAlign:'justify'});
var EarthPanel3 = ui.Panel([TitleLabel3],ui.Panel.Layout.flow('horizontal'),{width: '300px', height: '200px', position: 'bottom-left'});
// Setup screen
//ui.root.clear();
// Create User Interface portion --------------------------------------------------
// Create a panel to hold our widgets.
var panel = ui.Panel();
panel.style().set('width', '300px');
// Create an intro panel with labels.
var intro = ui.Panel([
 /*
 ui.Label({
    value: 'Statistics',
    style: {fontSize: '14px', fontWeight: 'bold'}
  }),
  */
  ui.Label
  ({
    value: '........',
    style: {fontSize: '10px', fontWeight: 'bold'}
  })
]);
//panel.add(intro);
/// Define a DataTable using a JavaScript literal.
// Define a dictionary of customization options.
var options = {
 // title: 'Cactus Suitability Status: India',
  /*hAxis: {title: 'Suitability class'},
  legend: {position: 'none'},
  vAxis: {
    title: 'Suitability value (%)',
    logScale: true
  },*/
  width:300,
  height: 100,
  title: '.....',
  colors: ['00FF00', 'yellow','orange', 'FF0000'],// less
 // fontcolor: 'black',
  // pieSliceText: 'label'
  pieSliceTextStyle: {color:'black'}
};
// var image = ee.Image('users/wrd_iwmi/iwmi_logo').visualize({
//   bands: ['b1', 'b2', 'b3'],
//   min: 0,
//   max: 255,
//   //gamma: [1, 1, 1]
// });
// // Print a thumbnail to the console.
// var p1=ui.Thumbnail({
//   image: image,
//   params: {
//     dimensions: '100x100',
//     //region: box,
//     format: 'png'
//   },
//   style: {backgroundColor: 'white', position: 'top-left', textAlign:'justify',height: '90px', width: '140px'}
// });
 //ui.root.add(p1);
// EarthPanel0.widgets().set(2, p1);
//ui.root.add(ui.Panel([TitleLabel, EarthPanel0,  ExplaLabel, EarthPanel,EarthPanel3],ui.Panel.Layout.flow('vertical'),{width: '400px'}));
ui.root.add(ui.Panel([TitleLabel,  ExplaLabel,ExplaLabel1,ExplaLabel2, EarthPanel0,EarthPanel3],ui.Panel.Layout.flow('vertical'),{width: '300px'}));
//EarthPanel,